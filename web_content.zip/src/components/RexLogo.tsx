import React from 'react';

interface RexLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  animated?: boolean;
  className?: string;
}

export const RexLogo: React.FC<RexLogoProps> = ({
  size = 'md',
  showText = true,
  animated = true,
  className = '',
}) => {
  const sizeMap = {
    sm: { icon: 'w-8 h-8', text: 'text-lg', sub: 'text-[9px]' },
    md: { icon: 'w-12 h-12', text: 'text-2xl', sub: 'text-xs' },
    lg: { icon: 'w-16 h-16', text: 'text-3xl', sub: 'text-sm' },
    xl: { icon: 'w-24 h-24', text: 'text-5xl', sub: 'text-base' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Cyber T-Rex Skull Crest Logo */}
      <div className={`relative ${currentSize.icon} flex items-center justify-center shrink-0`}>
        {/* Glowing backdrop aura */}
        <div
          className={`absolute inset-0 rounded-xl bg-gradient-to-br from-red-600/30 via-transparent to-cyan-500/30 blur-md ${
            animated ? 'animate-pulse' : ''
          }`}
        />

        {/* Outer Shield Hex Frame */}
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-[0_0_12px_rgba(255,30,68,0.6)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="rexGradientRed" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FF1E44" />
              <stop offset="100%" stopColor="#99001A" />
            </linearGradient>
            <linearGradient id="rexGradientBlue" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="100%" stopColor="#0055FF" />
            </linearGradient>
            <linearGradient id="metalDark" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1C1E29" />
              <stop offset="100%" stopColor="#0B0C11" />
            </linearGradient>
            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Hex Shield Border */}
          <polygon
            points="50,4 92,26 92,74 50,96 8,74 8,26"
            fill="url(#metalDark)"
            stroke="url(#rexGradientRed)"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />

          {/* Internal Cyber Tech Lines */}
          <polyline
            points="24,34 50,20 76,34"
            stroke="#00E5FF"
            strokeWidth="1.5"
            strokeOpacity="0.8"
          />
          <polyline
            points="18,50 30,50 38,62 62,62 70,50 82,50"
            stroke="#FF1E44"
            strokeWidth="1.5"
            strokeOpacity="0.5"
          />

          {/* Aggressive Cyber T-Rex Head Profile */}
          {/* Main Skull Crown & Snout */}
          <path
            d="M 32 30 
               L 64 26 
               L 80 42 
               L 75 52 
               L 62 50 
               L 54 56 
               L 72 58 
               L 66 66 
               L 42 66 
               L 36 58 
               L 38 46 
               L 26 38 Z"
            fill="url(#rexGradientRed)"
            filter="url(#neonGlow)"
          />

          {/* Lower Jaw */}
          <path
            d="M 44 68 
               L 68 68 
               L 62 76 
               L 40 76 
               L 36 71 Z"
            fill="#FF1E44"
          />

          {/* Cyber Visor Eye (Neon Blue) */}
          <polygon
            points="48,38 60,37 54,43 45,43"
            fill="#00E5FF"
            filter="url(#neonGlow)"
          />

          {/* Razor Teeth */}
          <polygon points="56,50 58,54 60,50" fill="#FFFFFF" />
          <polygon points="63,50 65,55 67,50" fill="#FFFFFF" />
          <polygon points="70,50 72,55 74,50" fill="#FFFFFF" />

          {/* Lower Teeth */}
          <polygon points="50,68 52,64 54,68" fill="#FFFFFF" />
          <polygon points="58,68 60,63 62,68" fill="#FFFFFF" />

          {/* Dual Cyber Fang Highlights */}
          <circle cx="50" cy="90" r="2.5" fill="#00E5FF" />
          <line x1="50" y1="80" x2="50" y2="88" stroke="#00E5FF" strokeWidth="2" />
        </svg>
      </div>

      {/* Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span
              className={`font-orbitron font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-cyan-400 ${currentSize.text} drop-shadow-[0_2px_10px_rgba(255,30,68,0.4)]`}
            >
              REX
            </span>
            <span
              className={`font-orbitron font-bold tracking-widest text-cyan-400 ${currentSize.text} drop-shadow-[0_2px_10px_rgba(0,229,255,0.4)]`}
            >
              TEAM
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`font-chakra font-bold tracking-widest uppercase text-slate-400 ${currentSize.sub}`}
            >
              Gaming Soundboard
            </span>
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
            <span className="text-[10px] text-cyan-400 font-mono">v2.4 PRO</span>
          </div>
        </div>
      )}
    </div>
  );
};
