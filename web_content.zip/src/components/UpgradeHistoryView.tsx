import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Info,
  Loader2,
  RefreshCw,
  Search,
} from 'lucide-react';
import {
  ClanDashboardState,
  DataSourceType,
  SyncProgressInfo,
  SyncRunSummary,
  TrackedUpgradeStatus,
  UpgradeDetailType,
  VillageId,
} from '../shared/cocData';
import { formatDateTimeRu, formatRelativeTimeRu } from '../utils/formatters';
import {
  CocUnitBadge,
  UPGRADE_PERIOD_OPTIONS,
  UpgradePeriodId,
  formatCountdownRu,
  getDataSourceLabel,
  getUpgradeCategoryShortLabel,
  getVillageRuTitle,
  getVillageShortTitle,
  isActualUpgradeEvent,
  matchesUpgradePeriod,
  resolveUpgradeDetailType,
  resolveUpgradeVillage,
} from './CocUnitBadge';

interface UpgradeHistoryViewProps {
  state: ClanDashboardState;
  nowMs: number;
  isSyncing: boolean;
  syncProgress: SyncProgressInfo | null;
  lastSyncSummary: SyncRunSummary | null;
  onSyncNow: () => void;
  onOpenJsonImport?: (playerTag?: string) => void;
  onSelectPlayer: (tag: string) => void;
}

interface UnifiedUpgradeRow {
  id: string;
  village: VillageId;
  status: TrackedUpgradeStatus;
  playerTag: string;
  playerName: string;
  townHallLevel: number;
  detailType: UpgradeDetailType;
  objectName: string;
  objectNameRu: string;
  instanceNumber?: number;
  isSuperTroop?: boolean;
  fromLevel: number;
  toLevel: number;
  source: DataSourceType;
  detectedAt: string;
  lastConfirmedAt: string;
  prevCheckAt?: string;
  estimatedFinishesAt?: string;
}

const VILLAGE_FILTER_OPTIONS: Array<{ id: 'all' | VillageId; label: string }> = [
  { id: 'all', label: 'Все деревни' },
  { id: 'home', label: 'Родная деревня' },
  { id: 'builderBase', label: 'Деревня строителя' },
  { id: 'clanCapital', label: 'Столица клана' },
];

const STATUS_FILTER_OPTIONS: Array<{ id: 'all' | TrackedUpgradeStatus; label: string }> = [
  { id: 'all', label: 'Все статусы' },
  { id: 'in_progress', label: 'Только текущие улучшения' },
  { id: 'completed', label: 'Только завершённые улучшения' },
];

const CATEGORY_FILTER_OPTIONS: Array<{ id: 'all' | UpgradeDetailType; label: string }> = [
  { id: 'all', label: 'Все категории' },
  { id: 'building', label: 'Здания / Защита' },
  { id: 'hero', label: 'Герои' },
  { id: 'equipment', label: 'Оборудование' },
  { id: 'troop', label: 'Войска' },
  { id: 'spell', label: 'Заклинания' },
  { id: 'pet', label: 'Питомцы' },
  { id: 'siege', label: 'Осадные машины' },
  { id: 'townhall', label: 'Ратуша / Дом' },
];

function formatLevelDeltaLabel(diff: number): string {
  const abs = Math.abs(diff);
  const mod10 = abs % 10;
  const mod100 = abs % 100;
  let word = 'уровней';
  if (mod10 === 1 && mod100 !== 11) word = 'уровень';
  else if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) word = 'уровня';
  return `${diff >= 0 ? '+' : '-'}${abs} ${word}`;
}

export const UpgradeHistoryView: React.FC<UpgradeHistoryViewProps> = ({
  state,
  nowMs,
  isSyncing,
  syncProgress,
  lastSyncSummary,
  onSyncNow,
  onSelectPlayer,
}) => {
  const [villageFilter, setVillageFilter] = useState<'all' | VillageId>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | TrackedUpgradeStatus>('all');
  const [period, setPeriod] = useState<UpgradePeriodId>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | UpgradeDetailType>('all');
  const [playerFilter, setPlayerFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Combine in-progress activeUpgrades + all completed UpgradeEvents without double counting
  const allRows: UnifiedUpgradeRow[] = useMemo(() => {
    const rows: UnifiedUpgradeRow[] = [];

    for (const act of state.activeUpgrades ?? []) {
      if (act.status === 'in_progress') {
        rows.push({
          id: `act-${act.id}`,
          village: act.village,
          status: 'in_progress',
          playerTag: act.playerTag,
          playerName: act.playerName,
          townHallLevel: act.townHallLevel,
          detailType: act.detailType,
          objectName: act.objectName,
          objectNameRu: act.objectNameRu,
          fromLevel: act.fromLevel,
          toLevel: act.toLevel,
          source: act.source,
          detectedAt: act.detectedAt,
          lastConfirmedAt: act.lastConfirmedAt,
          estimatedFinishesAt: act.estimatedFinishesAt,
        });
      }
    }

    for (const ev of state.events) {
      if (!isActualUpgradeEvent(ev)) continue;
      rows.push({
        id: `ev-${ev.id}`,
        village: resolveUpgradeVillage(ev),
        status: ev.status ?? 'completed',
        playerTag: ev.playerTag,
        playerName: ev.playerName,
        townHallLevel: ev.townHallLevel,
        detailType: resolveUpgradeDetailType(ev),
        objectName: ev.apiName || ev.itemNameRu,
        objectNameRu: ev.itemNameRu,
        instanceNumber: ev.instanceNumber,
        isSuperTroop: ev.isSuperTroop,
        fromLevel: ev.fromLevel,
        toLevel: ev.toLevel,
        source: ev.source,
        detectedAt: ev.detectedAt || ev.timestamp,
        lastConfirmedAt: ev.lastConfirmedAt || ev.timestamp,
        prevCheckAt: ev.previousCheckAt || ev.previousSnapshotAt,
        estimatedFinishesAt: ev.estimatedFinishesAt,
      });
    }

    return rows.sort((a, b) => {
      if (a.status !== b.status) return a.status === 'in_progress' ? -1 : 1;
      return new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime();
    });
  }, [state.activeUpgrades, state.events]);

  const periodCounts = useMemo(() => {
    const counts: Record<UpgradePeriodId, number> = {
      today: 0,
      yesterday: 0,
      '7d': 0,
      '30d': 0,
      all: allRows.length,
    };
    for (const row of allRows) {
      if (matchesUpgradePeriod(row.detectedAt, 'today', nowMs)) counts.today += 1;
      if (matchesUpgradePeriod(row.detectedAt, 'yesterday', nowMs)) counts.yesterday += 1;
      if (matchesUpgradePeriod(row.detectedAt, '7d', nowMs)) counts['7d'] += 1;
      if (matchesUpgradePeriod(row.detectedAt, '30d', nowMs)) counts['30d'] += 1;
    }
    return counts;
  }, [allRows, nowMs]);

  const filteredRows = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allRows.filter((row) => {
      if (villageFilter !== 'all' && row.village !== villageFilter) return false;
      if (statusFilter !== 'all' && row.status !== statusFilter) return false;
      if (!matchesUpgradePeriod(row.detectedAt, period, nowMs)) return false;
      if (categoryFilter !== 'all' && row.detailType !== categoryFilter) return false;
      if (playerFilter !== 'all' && row.playerTag !== playerFilter) return false;
      if (q) {
        const hay = `${row.playerName} ${row.playerTag} ${row.objectName} ${row.objectNameRu}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [allRows, villageFilter, statusFilter, period, nowMs, categoryFilter, playerFilter, searchQuery]);

  const summaryStats = useMemo(() => {
    let inProgressCount = 0;
    let completedCount = 0;
    let homeCount = 0;
    let bbCount = 0;
    let capitalCount = 0;

    for (const r of filteredRows) {
      if (r.status === 'in_progress') inProgressCount += 1;
      else completedCount += 1;
      if (r.village === 'home') homeCount += 1;
      else if (r.village === 'builderBase') bbCount += 1;
      else capitalCount += 1;
    }

    return {
      total: filteredRows.length,
      inProgressCount,
      completedCount,
      homeCount,
      bbCount,
      capitalCount,
    };
  }, [filteredRows]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы отслеживать текущие и завершённые улучшения участников по всем трём деревням.
      </div>
    );
  }

  const showLiveProgress = isSyncing || Boolean(syncProgress?.inProgress);
  const checkedNow = syncProgress?.checkedMembers ?? 0;
  const totalNow = syncProgress?.totalMembers || state.players.length;
  const pctNow = totalNow > 0 ? Math.min(100, Math.round((checkedNow / totalNow) * 100)) : 0;

  return (
    <div className="space-y-6">
      {/* Header + Sync & Import CTA */}
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-5 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            История улучшений (все три деревни)
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Подробный журнал текущих и завершённых повышений уровней с указанием деревни, источника данных и времени обнаружения
          </p>
          {state.syncConfig.lastSyncAt && (
            <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
              <Clock className="h-3.5 w-3.5 text-amber-400" />
              <span>
                Последняя синхронизация: {formatDateTimeRu(state.syncConfig.lastSyncAt)} ({formatRelativeTimeRu(state.syncConfig.lastSyncAt, nowMs)})
              </span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onSyncNow}
            disabled={showLiveProgress}
            className="inline-flex items-center justify-center gap-2.5 rounded-lg bg-amber-500 px-5 py-3 text-xs sm:text-sm font-bold text-slate-950 transition-colors hover:bg-amber-400 disabled:opacity-60 whitespace-nowrap"
          >
            <RefreshCw className={`h-4 w-4 ${showLiveProgress ? 'animate-spin' : ''}`} />
            <span>{showLiveProgress ? 'СИНХРОНИЗАЦИЯ...' : 'СИНХРОНИЗИРОВАТЬ ДАННЫЕ'}</span>
          </button>
        </div>
      </section>

      {/* Live Progress / Sync Result */}
      {showLiveProgress && (
        <section className="rounded-lg border border-amber-500/40 bg-[#121824] p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-sm font-semibold text-amber-300">
              <Loader2 className="h-4 w-4 animate-spin shrink-0" />
              <span>{syncProgress?.statusText || 'Запрос свежих данных из Supercell API...'}</span>
            </div>
            <span className="font-mono text-xs tabular-nums text-slate-300">{pctNow}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
            <div className="h-full bg-amber-500 transition-all duration-200" style={{ width: `${pctNow}%` }} />
          </div>
          <div className="grid grid-cols-1 gap-3 pt-1 text-xs sm:grid-cols-3 font-mono tabular-nums">
            <div className="text-slate-300">
              Проверено участников: <strong className="text-slate-100">{checkedNow} / {totalNow}</strong>
            </div>
            <div className="text-slate-300">
              Обнаружено улучшений: <strong className="text-emerald-400">{syncProgress?.upgradesFound ?? 0}</strong>
            </div>
            <div className="text-slate-300">
              Ошибок: <strong className={(syncProgress?.errorsCount ?? 0) > 0 ? 'text-rose-400' : 'text-slate-200'}>{syncProgress?.errorsCount ?? 0}</strong>
            </div>
          </div>
        </section>
      )}

      {!showLiveProgress && lastSyncSummary && (
        <section
          className={`rounded-lg border p-4 space-y-2 ${
            lastSyncSummary.errorMessage
              ? 'border-rose-500/40 bg-rose-500/10'
              : lastSyncSummary.upgradesFound > 0
              ? 'border-emerald-500/40 bg-emerald-500/10'
              : 'border-slate-700 bg-[#121824]'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
            <div className="flex items-center gap-2 font-semibold text-slate-100">
              {lastSyncSummary.errorMessage ? (
                <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className={`h-4 w-4 shrink-0 ${lastSyncSummary.upgradesFound > 0 ? 'text-emerald-400' : 'text-slate-400'}`} />
              )}
              <span>
                {lastSyncSummary.errorMessage
                  ? `Ошибка синхронизации: ${lastSyncSummary.errorMessage}`
                  : `Синхронизация завершена · Проверено участников: ${lastSyncSummary.checkedMembers} · Новых завершений API: ${lastSyncSummary.upgradesFound}`}
              </span>
            </div>
            <span className="font-mono text-xs text-slate-400">{formatDateTimeRu(lastSyncSummary.completedAt)}</span>
          </div>
        </section>
      )}

      {/* Honest Data Sources Note */}
      <section className="flex items-start gap-3 rounded-lg border border-slate-800 bg-[#121824] px-4 py-3 text-xs text-slate-300 leading-relaxed">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <div>
          При каждой синхронизации сервер сравнивает актуальные профили из <strong className="text-emerald-300">Supercell API</strong> с последними сохранёнными данными и автоматически записывает все повышения уровней (Ратуша, Оружие Ратуши, Дом строителя, герои, оборудование героев, войска, заклинания, питомцы, осадные машины и районы Столицы). Предыдущие события сохраняются в базе данных и не удаляются при следующих синхронизациях.
        </div>
      </section>

      {/* Summary KPIs */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Всего в выборке</div>
          <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-slate-100">
            {summaryStats.total}
          </div>
        </div>
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Сейчас в процессе</div>
          <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-amber-400">
            {summaryStats.inProgressCount}
          </div>
        </div>
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Завершено</div>
          <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-emerald-400">
            {summaryStats.completedCount}
          </div>
        </div>
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Home / BB / Capital</div>
          <div className="mt-1.5 font-mono text-lg font-bold tabular-nums text-sky-400">
            {summaryStats.homeCount} / {summaryStats.bbCount} / {summaryStats.capitalCount}
          </div>
        </div>
      </section>

      {/* Filters Toolbar */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-4 sm:p-5 space-y-4">
        {/* Village + Status Row */}
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-1.5">
            {VILLAGE_FILTER_OPTIONS.map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => setVillageFilter(v.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  villageFilter === v.id
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'bg-[#0B0F17] text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {STATUS_FILTER_OPTIONS.map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => setStatusFilter(st.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  statusFilter === st.id
                    ? 'bg-sky-500 text-slate-950 font-semibold'
                    : 'bg-[#0B0F17] text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>

        {/* Period + Search + Player Row */}
        <div className="flex flex-col gap-3 border-t border-slate-800/80 pt-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-1 overflow-x-auto pb-1 lg:pb-0">
            {UPGRADE_PERIOD_OPTIONS.map((opt) => {
              const active = period === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setPeriod(opt.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-slate-800 text-amber-400 border border-amber-500/40'
                      : 'bg-[#0B0F17] text-slate-400 hover:text-slate-100 border border-slate-800'
                  }`}
                >
                  <span>{opt.label}</span>
                  <span className="font-mono text-[11px] tabular-nums text-slate-400">
                    {periodCounts[opt.id]}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Поиск игрока, #тега или объекта..."
                className="w-full rounded-md border border-slate-800 bg-[#0B0F17] py-2 pl-9 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <select
              value={playerFilter}
              onChange={(e) => setPlayerFilter(e.target.value)}
              className="w-full sm:w-auto rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">Все участники ({state.players.length})</option>
              {state.players.map((p) => (
                <option key={p.tag} value={p.tag}>
                  {p.name} ({p.tag})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Category Filter Strip */}
        <div className="flex items-center gap-1 overflow-x-auto border-t border-slate-800/80 pt-3">
          {CATEGORY_FILTER_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setCategoryFilter(opt.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                categoryFilter === opt.id
                  ? 'bg-slate-800 text-amber-400 border border-amber-500/40'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </section>

      {/* Cards Feed */}
      {filteredRows.length === 0 ? (
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-10 text-center space-y-3">
          <p className="text-sm font-medium text-slate-200">
            {allRows.length === 0
              ? 'Начальная база уровней сохранена. Пока новых улучшений не обнаружено.'
              : 'По выбранным фильтрам улучшений не найдено.'}
          </p>
          <p className="mx-auto max-w-xl text-xs text-slate-400 leading-relaxed">
            Нажмите «СИНХРОНИЗИРОВАТЬ ДАННЫЕ», чтобы получить свежие профили участников из Supercell API и автоматически зафиксировать новые повышения уровней.
          </p>
        </section>
      ) : (
        <section className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          {filteredRows.map((row) => {
            const isInProgress = row.status === 'in_progress';
            const countdown = isInProgress ? formatCountdownRu(row.estimatedFinishesAt, nowMs) : null;
            const levelsGained = row.toLevel - row.fromLevel;
            const showRuSub =
              row.objectNameRu && row.objectName.toLowerCase() !== row.objectNameRu.toLowerCase();

            return (
              <article
                key={row.id}
                className={`rounded-lg border p-4 sm:p-5 flex flex-col justify-between gap-4 transition-colors ${
                  isInProgress
                    ? 'border-amber-500/50 bg-[#121824]'
                    : 'border-slate-800 bg-[#121824] hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <CocUnitBadge
                      detailType={row.detailType}
                      apiName={row.objectName}
                      isSuperTroop={row.isSuperTroop}
                      size="lg"
                    />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
                        {row.village === 'clanCapital' ? (
                          <span className="text-sm font-bold text-emerald-300">{row.playerName}</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectPlayer(row.playerTag)}
                            className="text-sm font-bold text-slate-100 hover:text-amber-400 transition-colors truncate text-left"
                          >
                            {row.playerName}
                          </button>
                        )}
                        <span className="font-mono text-slate-500">{row.playerTag}</span>
                        {row.village !== 'clanCapital' && (
                          <span className="font-mono text-amber-400">TH{row.townHallLevel}</span>
                        )}
                      </div>

                      <div className="mt-1 font-display text-base sm:text-lg font-extrabold tracking-wide text-amber-400 break-words">
                        {row.objectName}
                        {row.instanceNumber ? ` #${row.instanceNumber}` : ''}
                      </div>

                      <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                        <span className="font-semibold text-sky-300">
                          {getVillageShortTitle(row.village)} ({getVillageRuTitle(row.village)})
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-300">{getUpgradeCategoryShortLabel(row.detailType)}</span>
                        {showRuSub && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{row.objectNameRu}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span
                      className={`rounded border px-2 py-0.5 font-mono text-[11px] font-bold ${
                        isInProgress
                          ? 'border-amber-500/50 bg-amber-500/15 text-amber-300'
                          : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                      }`}
                    >
                      {isInProgress ? 'УЛУЧШАЕТСЯ' : 'ЗАВЕРШЕНО'}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {getDataSourceLabel(row.source)}
                    </span>
                  </div>
                </div>

                {/* Large Level Transition */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-3">
                  <div className="flex items-center gap-2.5 font-mono tabular-nums">
                    <span className="text-xs text-slate-400">Уровень</span>
                    <span className="text-xl font-bold text-slate-300">{row.fromLevel}</span>
                    <ArrowRight className={`h-4 w-4 shrink-0 ${isInProgress ? 'text-amber-400' : 'text-emerald-400'}`} />
                    <span className={`text-2xl font-extrabold ${isInProgress ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {row.toLevel}
                    </span>
                  </div>

                  <span className={`font-mono text-xs font-semibold tabular-nums ${isInProgress ? 'text-amber-300' : 'text-emerald-400'}`}>
                    {formatLevelDeltaLabel(levelsGained)}
                  </span>
                </div>

                {/* Timestamps + Timer */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/60 pt-2.5 text-xs text-slate-400 font-mono">
                  <span className="inline-flex items-center gap-1.5 text-slate-300">
                    <Clock className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                    <span>Обнаружено: {formatDateTimeRu(row.detectedAt)}</span>
                  </span>
                  {isInProgress && countdown ? (
                    <span className="font-semibold text-amber-300">{countdown.label}</span>
                  ) : (
                    <span className="text-[11px] text-slate-500">
                      Подтверждено: {formatDateTimeRu(row.lastConfirmedAt)}
                    </span>
                  )}
                </div>
              </article>
            );
          })}
        </section>
      )}
    </div>
  );
};
