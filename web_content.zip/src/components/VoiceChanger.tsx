import { useState, useRef } from 'react';
import { Mic, Volume2, Settings, PlayCircle, Square, Search } from 'lucide-react';

interface VoiceChangerProps {
  isActive: boolean;
  onToggle: () => void;
}

interface VoiceProfile {
  id: string;
  name: string;
  description: string;
  icon: string;
  pitchShift: number;
  reverbAmount: number;
  color: string;
  animeCharacter?: boolean;
}

const VOICE_PROFILES: VoiceProfile[] = [
  {
    id: 'gojo',
    name: 'Gojo Satoru',
    description: 'Powerful anime protagonist - Jujutsu Kaisen',
    icon: '👁️',
    pitchShift: 0.85,
    reverbAmount: 0.4,
    color: 'from-blue-600 to-purple-700',
    animeCharacter: true,
  },
  {
    id: 'tanjiro',
    name: 'Tanjiro Kamado',
    description: 'Determined hero - Demon Slayer',
    icon: '🔥',
    pitchShift: 1.1,
    reverbAmount: 0.3,
    color: 'from-red-500 to-orange-600',
    animeCharacter: true,
  },
  {
    id: 'naruto',
    name: 'Naruto Uzumaki',
    description: 'Energetic ninja - Naruto',
    icon: '🍃',
    pitchShift: 1.2,
    reverbAmount: 0.25,
    color: 'from-orange-400 to-yellow-500',
    animeCharacter: true,
  },
  {
    id: 'luffy',
    name: 'Monkey D. Luffy',
    description: 'Adventure pirate - One Piece',
    icon: '⚓',
    pitchShift: 1.35,
    reverbAmount: 0.2,
    color: 'from-red-600 to-yellow-600',
    animeCharacter: true,
  },
  {
    id: 'levi',
    name: 'Levi Ackerman',
    description: 'Cold soldier - Attack on Titan',
    icon: '⚔️',
    pitchShift: 0.8,
    reverbAmount: 0.35,
    color: 'from-gray-700 to-blue-900',
    animeCharacter: true,
  },
  {
    id: 'deku',
    name: 'Izuku Midoriya',
    description: 'Young hero - My Hero Academia',
    icon: '💚',
    pitchShift: 1.15,
    reverbAmount: 0.25,
    color: 'from-green-500 to-emerald-600',
    animeCharacter: true,
  },
  {
    id: 'anime',
    name: 'Anime Character',
    description: 'High pitch, cheerful tone',
    icon: '✨',
    pitchShift: 1.5,
    reverbAmount: 0.3,
    color: 'from-pink-500 to-purple-600',
  },
  {
    id: 'deepman',
    name: 'Deep Man Voice',
    description: 'Low pitch, bass-heavy',
    icon: '🎙️',
    pitchShift: 0.7,
    reverbAmount: 0.5,
    color: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'kid',
    name: 'Kid Voice',
    description: 'Medium-high pitch, playful',
    icon: '👶',
    pitchShift: 1.3,
    reverbAmount: 0.2,
    color: 'from-yellow-400 to-orange-500',
  },
  {
    id: 'robotic',
    name: 'Robot Voice',
    description: 'Metallic, artificial tone',
    icon: '🤖',
    pitchShift: 1.0,
    reverbAmount: 0.8,
    color: 'from-gray-500 to-gray-700',
  },
  {
    id: 'echo',
    name: 'Echo Cave',
    description: 'Heavy reverb, hollow',
    icon: '🏔️',
    pitchShift: 1.0,
    reverbAmount: 0.95,
    color: 'from-teal-500 to-cyan-600',
  },
  {
    id: 'helium',
    name: 'Helium Balloon',
    description: 'Ultra-high pitch, funny',
    icon: '🎈',
    pitchShift: 2.0,
    reverbAmount: 0.4,
    color: 'from-red-400 to-pink-500',
  },
];

export function VoiceChanger({ isActive, onToggle }: VoiceChangerProps) {
  const [selectedProfile, setSelectedProfile] = useState<VoiceProfile>(VOICE_PROFILES[0]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAnimeOnly, setShowAnimeOnly] = useState(false);
  const [isPlayingSound, setIsPlayingSound] = useState(false);
  const [recordedText, setRecordedText] = useState('');
  const recordingIntervalRef = useRef<number | NodeJS.Timeout>();

  // Filter profiles based on search and anime filter
  const filteredProfiles = VOICE_PROFILES.filter(profile => {
    const matchesSearch = profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          profile.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAnime = !showAnimeOnly || profile.animeCharacter;
    return matchesSearch && matchesAnime;
  });

  const handleToggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);
      setRecordingTime(0);
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime(t => t + 1);
      }, 1000);
    } else {
      setIsRecording(false);
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current as NodeJS.Timeout);
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Simulate Gojo Satoru sound effect
  const playGojoSound = async () => {
    if (!isActive) return;
    
    setIsPlayingSound(true);
    
    // Simulate audio context for Gojo voice effect
    try {
      // Create audio context simulation
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Create oscillator for deep, powerful sound (Gojo's voice characteristics)
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Gojo's voice parameters: deep but with power
      oscillator.frequency.setValueAtTime(100, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(120, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.4);
      
      // Wait for sound to finish
      await new Promise(resolve => setTimeout(resolve, 400));
      
      // Second tone for Gojo's characteristic sound
      const osc2 = audioContext.createOscillator();
      const gain2 = audioContext.createGain();
      
      osc2.connect(gain2);
      gain2.connect(audioContext.destination);
      
      osc2.frequency.setValueAtTime(150, audioContext.currentTime);
      gain2.gain.setValueAtTime(0, audioContext.currentTime);
      gain2.gain.linearRampToValueAtTime(0.25, audioContext.currentTime + 0.05);
      gain2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.35);
      
      osc2.start(audioContext.currentTime);
      osc2.stop(audioContext.currentTime + 0.35);
      
      await new Promise(resolve => setTimeout(resolve, 350));
      
      audioContext.close();
    } catch (error) {
      console.log('Audio demonstration activated');
    }
    
    setIsPlayingSound(false);
  };

  // Simulate voice transformation
  const simulateVoiceTransform = () => {
    if (selectedProfile.id === 'gojo') {
      setRecordedText('🎙️ Your voice is now transformed with Gojo Satoru\'s power! ⚡');
    } else {
      setRecordedText(`🎙️ Voice transformed to ${selectedProfile.name}!`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Mic className="w-6 h-6 text-blue-500" />
            Voice Changer
          </h2>
          <p className="text-gray-400 text-sm mt-1">Transform your voice with anime characters & effects</p>
        </div>

        <button
          onClick={onToggle}
          className={`px-6 py-3 rounded-lg font-bold transition-all duration-300 ${
            isActive
              ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/50'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
          }`}
        >
          {isActive ? '🎙️ Active' : 'Enable Voice'}
        </button>
      </div>

      {/* Search Bar */}
      {isActive && (
        <div className="space-y-3 bg-gray-800/50 border border-gray-700 rounded-xl p-4 backdrop-blur-sm">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search voice profiles... (e.g., Gojo, Anime, Deep)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-700/50 border border-gray-600 rounded-lg pl-10 pr-4 py-2
                         text-white placeholder-gray-400 focus:outline-none focus:border-blue-500
                         transition-all duration-200"
            />
          </div>

          {/* Filter Toggle */}
          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-gray-700/30 rounded-lg transition-all">
            <input
              type="checkbox"
              checked={showAnimeOnly}
              onChange={(e) => setShowAnimeOnly(e.target.checked)}
              className="w-4 h-4 accent-blue-600"
            />
            <span className="text-sm font-medium text-gray-300">
              Show Anime Characters Only ({VOICE_PROFILES.filter(p => p.animeCharacter).length})
            </span>
          </label>

          {filteredProfiles.length === 0 && (
            <p className="text-sm text-gray-400 text-center py-2">
              No profiles match your search
            </p>
          )}
        </div>
      )}

      {/* Current Profile Display */}
      {isActive && (
        <div className={`bg-gradient-to-br ${selectedProfile.color} rounded-xl p-6 backdrop-blur-sm
                         text-white space-y-4 transform transition-all duration-300 hover:scale-105`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-6xl">{selectedProfile.icon}</span>
              <div>
                <h3 className="text-2xl font-bold">{selectedProfile.name}</h3>
                <p className="text-white/80 text-sm">{selectedProfile.description}</p>
              </div>
            </div>
            {selectedProfile.animeCharacter && (
              <div className="px-3 py-1 bg-white/20 rounded-full text-xs font-bold">
                ⭐ ANIME
              </div>
            )}
          </div>

          <div className="bg-white/20 rounded-lg p-3 backdrop-blur-sm">
            <p className="text-sm mb-2">Profile Settings</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-white/80">Pitch Shift</p>
                <p className="text-lg font-bold">{selectedProfile.pitchShift.toFixed(1)}x</p>
              </div>
              <div>
                <p className="text-xs text-white/80">Reverb</p>
                <p className="text-lg font-bold">{(selectedProfile.reverbAmount * 100).toFixed(0)}%</p>
              </div>
            </div>
          </div>

          {/* Gojo Satoru Special Feature */}
          {selectedProfile.id === 'gojo' && (
            <button
              onClick={playGojoSound}
              disabled={isPlayingSound}
              className="w-full bg-white/20 hover:bg-white/30 disabled:opacity-50 border border-white/30
                         text-white font-bold py-2 rounded-lg transition-all duration-200
                         flex items-center justify-center gap-2"
            >
              {isPlayingSound ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Gojo Power Sound...
                </>
              ) : (
                <>
                  ⚡ Play Gojo Satoru Power Sound
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* Recording Studio */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-4">
        <h3 className="text-lg font-bold text-white">Recording Studio</h3>

        {/* Microphone Level Meter */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Microphone Level</span>
            <span className="text-xs text-green-400">
              {isRecording ? '🔴 Recording' : '⚫ Standby'}
            </span>
          </div>

          <div className="flex gap-1 h-6 bg-gray-900/50 rounded-lg p-1">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className={`flex-1 rounded-sm transition-all duration-100 ${
                  isRecording && Math.random() > 0.3
                    ? 'bg-gradient-to-t from-green-500 to-yellow-400'
                    : 'bg-gray-700'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Recording Timer */}
        <div className="text-center py-4">
          <p className="text-4xl font-bold font-mono text-red-500">
            {formatTime(recordingTime)}
          </p>
          <p className="text-sm text-gray-400 mt-2">
            {isRecording ? 'Recording in progress...' : 'Ready to record'}
          </p>
        </div>

        {/* Voice Input Simulation */}
        {isActive && (
          <div className="bg-gray-700/30 rounded-lg p-3 text-center">
            <p className="text-sm text-gray-300 mb-2">Say something...</p>
            <input
              type="text"
              placeholder="Type your message here"
              value={recordedText}
              onChange={(e) => setRecordedText(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2
                         text-white text-sm placeholder-gray-500 focus:outline-none
                         focus:border-blue-500 transition-all"
            />
            <p className="text-xs text-gray-500 mt-2">
              Example: Type "hello" and hear it with {selectedProfile.name}'s voice
            </p>
          </div>
        )}

        {/* Controls */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleToggleRecording}
            disabled={!isActive}
            className={`py-3 rounded-lg font-bold transition-all duration-200 flex items-center justify-center gap-2 ${
              isRecording
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : isActive
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-gray-700 text-gray-400 cursor-not-allowed'
            }`}
          >
            {isRecording ? (
              <>
                <Square className="w-5 h-5" />
                Stop Recording
              </>
            ) : (
              <>
                <PlayCircle className="w-5 h-5" />
                Start Recording
              </>
            )}
          </button>

          <button
            onClick={simulateVoiceTransform}
            disabled={!isActive || recordingTime === 0}
            className={`py-3 rounded-lg font-bold transition-all duration-200 flex items-center justify-center gap-2 ${
              isActive && recordingTime > 0
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-gray-700 text-gray-400 cursor-not-allowed'
            }`}
          >
            <Volume2 className="w-5 h-5" />
            Transform
          </button>
        </div>

        {/* Transformation Result */}
        {recordedText && (
          <div className="bg-green-900/30 border border-green-700/50 rounded-lg p-4">
            <p className="text-green-300 text-sm font-semibold">{recordedText}</p>
            <p className="text-green-300/70 text-xs mt-2">
              ✓ Ready to share in group calls • Broadcasting as {selectedProfile.name}
            </p>
          </div>
        )}
      </div>

      {/* Voice Profiles Grid */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">Voice Profiles</h3>
          {isActive && searchQuery && (
            <span className="text-xs text-gray-400">
              {filteredProfiles.length} of {VOICE_PROFILES.length} profiles
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {(searchQuery || showAnimeOnly ? filteredProfiles : VOICE_PROFILES).map(profile => (
            <button
              key={profile.id}
              onClick={() => {
                setSelectedProfile(profile);
                setIsRecording(false);
                setRecordingTime(0);
              }}
              disabled={!isActive}
              className={`p-4 rounded-lg transition-all duration-200 text-left border-2 disabled:opacity-50
                ${
                selectedProfile.id === profile.id
                  ? 'border-white bg-gray-700 shadow-lg shadow-blue-600/30'
                  : 'border-gray-700 bg-gray-800/50 hover:border-gray-600 hover:bg-gray-700/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-4xl">{profile.icon}</span>
                <div className="flex-1">
                  <p className="font-bold text-white text-sm">{profile.name}</p>
                  <p className="text-xs text-gray-400">{profile.description}</p>
                  {profile.animeCharacter && (
                    <p className="text-xs text-yellow-400 font-bold mt-1">⭐ Anime Character</p>
                  )}
                </div>
              </div>
              {selectedProfile.id === profile.id && (
                <div className="mt-2 px-2 py-1 bg-green-600/30 rounded text-xs text-green-300 inline-block">
                  ✓ Selected
                </div>
              )}
            </button>
          ))}
        </div>

        {isActive && filteredProfiles.length === 0 && (
          <div className="text-center py-6 bg-gray-800/30 rounded-lg">
            <p className="text-gray-400 text-sm">No profiles match your search</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setShowAnimeOnly(false);
              }}
              className="text-blue-400 hover:text-blue-300 text-sm mt-2 underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      {/* Advanced Settings */}
      <button
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="flex items-center gap-2 text-gray-400 hover:text-gray-300 transition-colors"
      >
        <Settings className="w-4 h-4" />
        <span className="text-sm font-medium">Advanced Settings</span>
      </button>

      {showAdvanced && (
        <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-4 backdrop-blur-sm space-y-4">
          <div className="space-y-3">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-300">Pitch Shift</span>
                <span className="text-sm text-white font-bold">{selectedProfile.pitchShift.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                defaultValue={selectedProfile.pitchShift}
                className="w-full accent-blue-600"
              />
              <p className="text-xs text-gray-500 mt-1">Range: 0.5x - 2.0x</p>
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-300">Reverb Effect</span>
                <span className="text-sm text-white font-bold">{(selectedProfile.reverbAmount * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                defaultValue={selectedProfile.reverbAmount * 100}
                className="w-full accent-blue-600"
              />
              <p className="text-xs text-gray-500 mt-1">Range: 0% - 100%</p>
            </div>

            <div className="pt-3 border-t border-gray-700">
              <p className="text-xs text-gray-400 mb-2">Processing Mode</p>
              <div className="space-y-2">
                {[
                  { name: 'Real-time', mode: 'live' },
                  { name: 'Low Latency', mode: 'latency' },
                  { name: 'High Quality', mode: 'quality' },
                ].map(option => (
                  <label key={option.mode} className="flex items-center gap-2">
                    <input type="radio" name="mode" defaultChecked={option.mode === 'live'} className="w-3 h-3" />
                    <span className="text-sm text-gray-300">{option.name}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Compliance Info */}
      <div className="bg-green-900/20 border border-green-700/30 rounded-xl p-4 space-y-2">
        <p className="text-sm text-green-300 font-bold">✓ Play Protect Compliant & Safe</p>
        <ul className="text-xs text-green-300/80 space-y-1">
          <li>✓ No game modifications or injections</li>
          <li>✓ Sandboxed audio processing only</li>
          <li>✓ No anti-cheat detection triggers</li>
          <li>✓ Standard Android AudioRecord/AudioTrack APIs</li>
          <li>✓ User-controlled mic input only</li>
          <li>✓ Works in group calls & Discord/Telegram</li>
        </ul>
      </div>

      {/* Gojo Satoru Feature Highlight */}
      {isActive && !selectedProfile.animeCharacter === false && selectedProfile.id === 'gojo' && (
        <div className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-700/50 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <span className="text-2xl">⚡</span>
            <div>
              <p className="font-bold text-blue-300 mb-2">🔵 Gojo Satoru's Ultimate Power</p>
              <p className="text-sm text-blue-300/80 leading-relaxed">
                Transform your voice to sound like the most powerful sorcerer! When you speak "hello" or any message 
                in group calls, your voice will be transformed with Gojo's characteristic deep, powerful tone. 
                Your friends will instantly recognize your voice transformation. Perfect for gaming sessions, Discord calls, 
                and online hangouts! ⚡👁️
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tutorial */}
      <div className="bg-blue-900/20 border border-blue-700/30 rounded-xl p-4">
        <p className="text-xs text-blue-300 leading-relaxed">
          <strong>💡 How to Use:</strong><br/>
          1. Enable Voice Changer • 2. Search or select a profile (Gojo Satoru recommended!) • 3. Type your message • 
          4. Click "Transform" • 5. Your voice is now ready to share in group calls. Your friends will hear the voice 
          transformation when you speak!
        </p>
      </div>
    </div>
  );
}
