import { useEffect, useRef, useState } from "react";
import { Game, GameCallbacks, Settings } from "../game/Game";

interface Props {
  settings: Settings;
  callbacks: GameCallbacks;
  onReady: (g: Game) => void;
  onLoadingDone: () => void;
}

export function GameView({ settings, callbacks, onReady, onLoadingDone }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cbRef = useRef(callbacks);
  cbRef.current = callbacks;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const gameRef = useRef<Game | null>(null);

  useEffect(() => {
    let game: Game | null = null;
    const t = setTimeout(() => {
      if (!canvasRef.current) return;
      const proxy: GameCallbacks = {
        onState: (s) => cbRef.current.onState(s),
        onToast: (m) => cbRef.current.onToast(m),
        onDialog: (a, b) => cbRef.current.onDialog(a, b),
        onFade: (v) => cbRef.current.onFade(v),
        onToggleMap: () => cbRef.current.onToggleMap(),
        onInventory: (s) => cbRef.current.onInventory?.(s),
        onHurt: () => cbRef.current.onHurt?.(),
        onToggleInventory: () => cbRef.current.onToggleInventory?.(),
      };
      game = new Game(canvasRef.current, proxy, settingsRef.current);
      gameRef.current = game;
      game.start();
      onReady(game);
      onLoadingDone();
    }, 60);
    return () => {
      clearTimeout(t);
      game?.dispose();
      gameRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    gameRef.current?.applySettings(settings);
  }, [settings]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 h-full w-full"
      style={{ imageRendering: "pixelated", touchAction: "none" }}
    />
  );
}

interface ControlsProps {
  game: Game | null;
  interactLabel: string | null;
  running: boolean;
  onRunToggle: () => void;
  panorama: string | null;
}

export function Controls({ game, interactLabel, running, onRunToggle, panorama }: ControlsProps) {
  const layerRef = useRef<HTMLDivElement>(null);
  const joy = useRef<{ id: number; ox: number; oy: number } | null>(null);
  const looks = useRef(new Map<number, { x: number; y: number }>());
  const clickStart = useRef(new Map<number, { x: number; y: number; t: number }>());
  const [stick, setStick] = useState<{ ox: number; oy: number; kx: number; ky: number } | null>(null);
  const R = 56;

  useEffect(() => {
    if (game) game.input.run = running;
  }, [running, game]);

  const onDown = (e: React.PointerEvent) => {
    if (!game) return;
    const el = layerRef.current!;
    el.setPointerCapture(e.pointerId);
    const w = el.clientWidth;
    if (e.pointerType !== "mouse" && e.clientX < w * 0.45 && !joy.current) {
      joy.current = { id: e.pointerId, ox: e.clientX, oy: e.clientY };
      setStick({ ox: e.clientX, oy: e.clientY, kx: 0, ky: 0 });
    } else {
      looks.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (e.pointerType === "mouse" && e.button === 0) clickStart.current.set(e.pointerId, { x: e.clientX, y: e.clientY, t: performance.now() });
    }
  };
  const onMove = (e: React.PointerEvent) => {
    if (!game) return;
    const j = joy.current;
    if (j && j.id === e.pointerId) {
      let dx = e.clientX - j.ox, dy = e.clientY - j.oy;
      const l = Math.hypot(dx, dy);
      if (l > R) {
        // drag origin along for comfort
        const k = (l - R) / l;
        j.ox += dx * k;
        j.oy += dy * k;
        dx = e.clientX - j.ox;
        dy = e.clientY - j.oy;
      }
      game.input.mx = dx / R;
      game.input.my = -dy / R;
      setStick({ ox: j.ox, oy: j.oy, kx: dx, ky: dy });
      return;
    }
    const p = looks.current.get(e.pointerId);
    if (p) {
      game.input.lookDX += e.clientX - p.x;
      game.input.lookDY += e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
    }
  };
  const onUp = (e: React.PointerEvent) => {
    if (joy.current && joy.current.id === e.pointerId) {
      joy.current = null;
      setStick(null);
      if (game) { game.input.mx = 0; game.input.my = 0; }
    }
    looks.current.delete(e.pointerId);
    // quick mouse click (no drag) = attack
    const c = clickStart.current.get(e.pointerId);
    if (c) {
      clickStart.current.delete(e.pointerId);
      if (game && performance.now() - c.t < 260 && Math.hypot(e.clientX - c.x, e.clientY - c.y) < 6) game.attack();
    }
  };
  const onWheel = (e: React.WheelEvent) => {
    if (game) game.input.zoom += Math.sign(e.deltaY) * 1.2;
  };

  const stop = (e: React.PointerEvent) => e.stopPropagation();

  return (
    <>
      <div
        ref={layerRef}
        className="absolute inset-0 z-10 select-none"
        style={{ touchAction: "none" }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        onWheel={onWheel}
        onContextMenu={(e) => e.preventDefault()}
      />
      {stick && (
        <div className="pointer-events-none fixed z-20" style={{ left: stick.ox - R, top: stick.oy - R, width: R * 2, height: R * 2 }}>
          <div className="absolute inset-0 rounded-full border-4 border-white/30 bg-black/20" />
          <div
            className="absolute rounded-full border-2 border-white/70 bg-white/40"
            style={{ width: 48, height: 48, left: R - 24 + stick.kx, top: R - 24 + stick.ky }}
          />
        </div>
      )}
      {/* hint for joystick area on touch devices */}
      {!stick && (
        <div className="pointer-events-none absolute bottom-10 left-10 z-20 hidden h-28 w-28 max-sm:bottom-24 items-center justify-center rounded-full border-4 border-dashed border-white/20 coarse:flex">
          <span className="text-[10px] text-white/50">MOVER</span>
        </div>
      )}
      <div className="pointer-events-none absolute bottom-5 right-5 z-30 flex flex-col items-end gap-3 max-sm:bottom-[74px] max-sm:right-3 sm:bottom-8 sm:right-8">
        {(interactLabel || panorama) && (
          <button
            onPointerDown={(e) => { stop(e); game?.interact(); }}
            className="pixel-btn pointer-events-auto animate-pulse bg-amber-500/90 px-4 py-3 text-sm text-black"
          >
            {panorama ? "✕ Voltar" : `✋ ${interactLabel}`}
          </button>
        )}
        <div className="flex items-end gap-3">
          <button
            onPointerDown={(e) => { stop(e); onRunToggle(); }}
            className={`pixel-btn pointer-events-auto h-16 w-16 rounded-full text-xs ${running ? "bg-fuchsia-500/90 text-white" : "bg-black/45 text-white"}`}
          >
            🏃<br />{running ? "ON" : "Correr"}
          </button>
          <button
            onPointerDown={(e) => { stop(e); if (game) game.input.jump = true; }}
            className="pixel-btn pointer-events-auto h-20 w-20 rounded-full bg-sky-500/80 text-sm text-white"
          >
            ⤒<br />Pular
          </button>
          <button
            onPointerDown={(e) => { stop(e); if (game) { game.input.attack = true; game.attack(); } }}
            onPointerUp={(e) => { stop(e); if (game) game.input.attack = false; }}
            onPointerCancel={() => { if (game) game.input.attack = false; }}
            onPointerLeave={() => { if (game) game.input.attack = false; }}
            className="pixel-btn pointer-events-auto h-[88px] w-[88px] rounded-full bg-rose-600/85 text-sm text-white"
            aria-label="Atacar"
          >
            <span className="text-2xl leading-none">⚔️</span><br />Atacar
          </button>
        </div>
        <div className="pointer-events-auto flex gap-2">
          <button onPointerDown={(e) => { stop(e); if (game) game.input.zoom -= 2; }} className="pixel-btn h-9 w-9 bg-black/45 text-white">＋</button>
          <button onPointerDown={(e) => { stop(e); if (game) game.input.zoom += 2; }} className="pixel-btn h-9 w-9 bg-black/45 text-white">－</button>
        </div>
      </div>
    </>
  );
}
