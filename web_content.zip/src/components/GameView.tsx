import { useEffect, useRef, useState } from 'react';
import { Engine, MODES, type GameConfig, type HudState, type MatchResult } from '../game/Engine';
import { W, WEAPONS, TYPE_FA, type WeaponType } from '../game/weapons';
import { fa, faNum, getSave, setSave, useSave } from '../game/store';
import { audio } from '../game/audio';
import { GunSil, Ico } from './Icons';

interface Props { cfg: GameConfig; onEnd: (r: MatchResult | null) => void }

type Role = { role: 'joy' | 'look' | 'fire'; x: number; y: number; ox: number; oy: number; look: boolean };

const STREAK = ['', '', 'دابل کیل!', 'تریپل کیل!', 'کوادرا کیل!', 'ایس! 🔥', 'غیرقابل توقف!'];

export default function GameView({ cfg, onEnd }: Props) {
  const save = useSave();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const radarRef = useRef<HTMLCanvasElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const joyBase = useRef<HTMLDivElement>(null);
  const joyKnob = useRef<HTMLDivElement>(null);
  const engRef = useRef<Engine | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [buyOpen, setBuyOpen] = useState(false);
  const [paused, setPaused] = useState(false);
  const [board, setBoard] = useState(false);
  const [locked, setLocked] = useState(false);
  const buyRef = useRef(false); buyRef.current = buyOpen;
  const pauseRef = useRef(false); pauseRef.current = paused;
  const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  useEffect(() => {
    const eng = new Engine(canvasRef.current!, cfg, getSave(), {
      onHud: setHud,
      onEnd: (r) => onEnd(r),
      onPause: () => { setPaused(true); eng.setPaused(true); },
      onBuyToggle: () => toggleBuy(),
      onScoreboard: setBoard,
    });
    engRef.current = eng;
    (window as unknown as { __eng: Engine }).__eng = eng;
    eng.setRadar(radarRef.current);
    const plc = () => setLocked(document.pointerLockElement === canvasRef.current);
    document.addEventListener('pointerlockchange', plc);
    return () => { eng.dispose(); engRef.current = null; document.removeEventListener('pointerlockchange', plc); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function toggleBuy() {
    const eng = engRef.current; if (!eng) return;
    const open = !buyRef.current;
    if (open && !eng.canBuy()) { audio.error(); return; }
    setBuyOpen(open);
    eng.setUiOpen(open);
    if (!open) eng.lockPointer();
  }

  useEffect(() => { if (buyOpen && hud && !hud.canBuy) { setBuyOpen(false); engRef.current?.setUiOpen(false); } }, [hud, buyOpen]);

  // live mods sync
  useEffect(() => { if (engRef.current) engRef.current.save = save; }, [save]);

  /* ---------- touch controls ---------- */
  useEffect(() => {
    const root = rootRef.current!;
    const roles = new Map<number, Role>();
    const JR = 55;
    const resetJoy = () => {
      if (joyBase.current) { joyBase.current.style.opacity = '0.45'; joyBase.current.style.left = ''; joyBase.current.style.top = ''; }
      if (joyKnob.current) joyKnob.current.style.transform = 'translate(-50%,-50%)';
    };
    const start = (ev: TouchEvent) => {
      audio.init();
      const eng = engRef.current; if (!eng) return;
      let prevent = false;
      for (const t of Array.from(ev.changedTouches)) {
        const el = t.target as Element;
        if (el.closest && el.closest('[data-ui]')) continue;
        prevent = true;
        const btn = el.closest ? (el.closest('[data-btn]') as HTMLElement | null) : null;
        if (pauseRef.current || buyRef.current) continue;
        if (btn) {
          const b = btn.dataset.btn!;
          btn.classList.add('scale-90', 'brightness-150');
          if (b === 'fire' || b === 'fireL') { eng.input.fire = true; roles.set(t.identifier, { role: 'fire', x: t.clientX, y: t.clientY, ox: 0, oy: 0, look: b === 'fire' }); continue; }
          if (b === 'aim') eng.toggleAim();
          if (b === 'reload') eng.reload();
          if (b === 'jump') eng.jump();
          if (b === 'crouch') eng.toggleCrouch();
          if (b === 'grenade') eng.switchSlot(eng.player.cur === 3 ? (eng.player.weapons[0] ? 0 : 1) : 3);
          if (b === 'buy') toggleBuy();
          if (b === 'pause') { setPaused(true); eng.setPaused(true); }
          if (b === 'score') setBoard(true);
          if (b.startsWith('slot')) eng.switchSlot(+b.slice(4));
          roles.set(t.identifier, { role: 'look', x: t.clientX, y: t.clientY, ox: 0, oy: 0, look: false });
          setTimeout(() => btn.classList.remove('scale-90', 'brightness-150'), 120);
          if (b === 'score') btn.dataset.holding = String(t.identifier);
          continue;
        }
        const hasJoy = [...roles.values()].some(r => r.role === 'joy');
        if (t.clientX < window.innerWidth * 0.42 && !hasJoy) {
          roles.set(t.identifier, { role: 'joy', x: t.clientX, y: t.clientY, ox: t.clientX, oy: t.clientY, look: false });
          if (joyBase.current) {
            joyBase.current.style.left = t.clientX + 'px'; joyBase.current.style.top = t.clientY + 'px'; joyBase.current.style.opacity = '0.9';
          }
        } else {
          roles.set(t.identifier, { role: 'look', x: t.clientX, y: t.clientY, ox: 0, oy: 0, look: true });
        }
      }
      if (prevent && ev.cancelable) ev.preventDefault();
    };
    const move = (ev: TouchEvent) => {
      const eng = engRef.current; if (!eng) return;
      let handled = false;
      for (const t of Array.from(ev.changedTouches)) {
        const r = roles.get(t.identifier); if (!r) continue;
        handled = true;
        if (r.role === 'joy') {
          let dx = t.clientX - r.ox, dy = t.clientY - r.oy;
          const d = Math.hypot(dx, dy);
          if (d > JR) { dx = dx / d * JR; dy = dy / d * JR; }
          eng.input.moveX = dx / JR; eng.input.moveY = -dy / JR;
          if (joyKnob.current) joyKnob.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        } else if (r.look) {
          eng.look((t.clientX - r.x) * 1.1, (t.clientY - r.y) * 1.1);
        }
        r.x = t.clientX; r.y = t.clientY;
      }
      if (handled && ev.cancelable) ev.preventDefault();
    };
    const end = (ev: TouchEvent) => {
      const eng = engRef.current; if (!eng) return;
      for (const t of Array.from(ev.changedTouches)) {
        const r = roles.get(t.identifier); if (!r) continue;
        if (r.role === 'joy') { eng.input.moveX = 0; eng.input.moveY = 0; resetJoy(); }
        if (r.role === 'fire') { if (![...roles.entries()].some(([id, x]) => id !== t.identifier && x.role === 'fire')) eng.input.fire = false; }
        roles.delete(t.identifier);
        const sb = root.querySelector('[data-btn="score"]') as HTMLElement | null;
        if (sb && sb.dataset.holding === String(t.identifier)) { setBoard(false); sb.dataset.holding = ''; }
      }
    };
    root.addEventListener('touchstart', start, { passive: false });
    root.addEventListener('touchmove', move, { passive: false });
    root.addEventListener('touchend', end);
    root.addEventListener('touchcancel', end);
    return () => {
      root.removeEventListener('touchstart', start); root.removeEventListener('touchmove', move);
      root.removeEventListener('touchend', end); root.removeEventListener('touchcancel', end);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resume = () => { setPaused(false); engRef.current?.setPaused(false); engRef.current?.lockPointer(); };
  const quit = () => { engRef.current?.setPaused(true); onEnd(null); };

  const h = hud;
  const t = engRef.current?.time ?? 0;
  const bs = save.settings.btnScale;
  const def = h ? W[h.weaponId] : W.knife;
  const mode = MODES.find(m => m.id === cfg.mode)!;
  const gap = h ? 6 + Math.min(40, h.spread * 900) : 8;
  const timerStr = h ? `${Math.floor(h.timer / 60)}:${String(Math.floor(h.timer % 60)).padStart(2, '0')}` : '';

  return (
    <div ref={rootRef} className="fixed inset-0 overflow-hidden bg-black select-none" style={{ touchAction: 'none' }} dir="ltr">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />

      {/* scope overlay */}
      {h?.scoped && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at center, transparent 0, transparent 38vh, rgba(0,0,0,.6) 38.5vh, #000 39.5vh)' }} />
          <div className="absolute left-0 right-0 top-1/2 h-px bg-black" />
          <div className="absolute top-0 bottom-0 left-1/2 w-px bg-black" />
          <div className="absolute left-1/2 top-1/2 w-1.5 h-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-red-500" />
        </div>
      )}

      {/* damage */}
      {h && t - h.dmgT < 0.6 && (
        <div key={h.dmgT} className="absolute inset-0 pointer-events-none dmg-flash" style={{ boxShadow: 'inset 0 0 120px 40px rgba(200,0,0,.65)' }}>
          <div className="absolute left-1/2 top-1/2 w-[260px] h-[260px] -translate-x-1/2 -translate-y-1/2" style={{ transform: `translate(-50%,-50%) rotate(${-h.dmgDir}rad)` }}>
            <div className="absolute left-1/2 -top-2 -translate-x-1/2 w-0 h-0 border-l-[18px] border-r-[18px] border-b-[26px] border-l-transparent border-r-transparent border-b-red-600/90" />
          </div>
        </div>
      )}
      {h && h.hp > 0 && h.hp < 30 && <div className="absolute inset-0 pointer-events-none animate-pulse" style={{ boxShadow: 'inset 0 0 90px 20px rgba(160,0,0,.5)' }} />}

      {/* crosshair */}
      {h && !h.dead && !h.scoped && (
        <div className="absolute left-1/2 top-1/2 pointer-events-none">
          {def.type === 'knife' ? <div className="w-1.5 h-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-lime-300 shadow-[0_0_3px_#000]" /> : (
            <>
              {[0, 90, 180, 270].map(r => (
                <div key={r} className="absolute bg-lime-300 shadow-[0_0_2px_#000]" style={{ width: 2, height: 9, left: -1, top: -4.5, transform: `rotate(${r}deg) translateY(${-gap - 4}px)` }} />
              ))}
              <div className="absolute w-[3px] h-[3px] -left-[1.5px] -top-[1.5px] bg-lime-300 rounded-full" />
            </>
          )}
        </div>
      )}
      {h && t - h.hitT < 0.3 && (
        <div key={'h' + h.hitT} className="absolute left-1/2 top-1/2 hitmarker pointer-events-none">
          {[45, 135, 225, 315].map(r => <div key={r} className="absolute" style={{ width: 2, height: 9, left: -1, top: -4.5, background: h.hitHead ? '#ff3030' : '#fff', transform: `rotate(${r}deg) translateY(-11px)` }} />)}
        </div>
      )}
      {h && t - h.killT < 1.4 && (
        <div key={'k' + h.killT} className="absolute left-1/2 top-[60%] -translate-x-1/2 pointer-events-none pop-in text-center" dir="rtl">
          <div className="w-9 h-9 mx-auto text-red-500 drop-shadow-[0_0_6px_#f00]">{Ico.skull()}</div>
          {h.streak >= 2 && <div className="title-grunge text-2xl mt-1">{STREAK[Math.min(h.streak, 6)]}</div>}
        </div>
      )}

      {/* center message */}
      {h?.center && (
        <div key={h.center.key} className="absolute left-0 right-0 top-[22%] text-center pointer-events-none pop-in" dir="rtl">
          <div className="inline-block px-10 py-3 bg-gradient-to-r from-transparent via-black/70 to-transparent">
            <div className="text-3xl tall:text-5xl font-black hud-text" style={{ color: h.center.color }}>{h.center.text}</div>
            <div className="text-sm tall:text-lg text-white/90 mt-1 hud-text">{h.center.sub}</div>
          </div>
        </div>
      )}

      {/* reload */}
      {h && h.reload >= 0 && (
        <div className="absolute left-1/2 top-[58%] -translate-x-1/2 pointer-events-none text-center" dir="rtl">
          <div className="w-40 h-1.5 bg-black/60 rounded overflow-hidden"><div className="h-full bg-amber-400" style={{ width: `${h.reload * 100}%` }} /></div>
          <div className="text-xs text-amber-200 mt-1 hud-text font-bold">در حال خشاب‌گذاری...</div>
        </div>
      )}

      {/* dead */}
      {h?.dead && h.phase !== 'over' && (
        <div className="absolute inset-x-0 bottom-[18%] text-center pointer-events-none" dir="rtl">
          {h.respawnIn >= 0 ? (
            <div className="text-xl font-black text-white hud-text">زنده شدن در {fa(Math.ceil(h.respawnIn))} ثانیه</div>
          ) : h.spectating ? (
            <div className="text-lg font-bold text-white hud-text bg-black/50 inline-block px-6 py-2 rounded">👁 در حال تماشای <span className="text-amber-300">{h.spectating}</span></div>
          ) : null}
        </div>
      )}

      {/* ===== TOP LEFT: pause + radar + stats ===== */}
      <div className="absolute left-2 top-2 flex gap-2 items-start" style={{ paddingLeft: 'env(safe-area-inset-left)' }}>
        <div className="flex flex-col gap-2">
          <button data-btn="pause" onClick={() => { if (!isTouch) { setPaused(true); engRef.current?.setPaused(true); } }} className="w-10 h-10 p-2 rounded-md bg-black/55 border border-amber-500/70 text-amber-400 transition">{Ico.menu()}</button>
          <button data-btn="score" onMouseDown={() => setBoard(true)} onMouseUp={() => setBoard(false)} className="w-10 h-10 p-2 rounded-md bg-black/55 border border-white/20 text-white/80 transition">{Ico.list()}</button>
          {isTouch && h?.canBuy && !h.dead && <button data-btn="buy" className="w-10 h-10 p-1.5 rounded-md bg-lime-600/50 border-2 border-lime-300 text-lime-100 transition pulse-red">{Ico.cart()}</button>}
        </div>
        <canvas ref={radarRef} width={150} height={150} className="w-[104px] h-[104px] tall:w-[140px] tall:h-[140px] rounded-full" />
        {h && (
          <div className="flex flex-col gap-0.5 hud-text font-black text-[15px] tall:text-lg leading-tight" dir="ltr">
            <div className="flex items-center gap-1.5" style={{ color: h.hp > 30 ? '#fff' : '#ff4040' }}><span className="w-4 h-4 text-red-500">{Ico.heart()}</span>{h.hp}</div>
            <div className="flex items-center gap-1.5 text-sky-200"><span className="w-4 h-4 text-sky-400">{Ico.shield()}</span>{h.armor}{h.helmet && <span className="text-[10px] text-sky-300">+H</span>}</div>
            {h.buyMode === 'money' && <div className="text-lime-400">${h.money.toLocaleString()}</div>}
            {save.settings.showFps && <div className="text-[10px] text-white/60">{h.fps} FPS</div>}
            {(save.mods.god || save.mods.oneShot || save.mods.infMoney) && <div className="text-[9px] px-1 rounded bg-red-600/80 text-white w-fit shine">MOD</div>}
          </div>
        )}
      </div>

      {/* ===== TOP CENTER: score ===== */}
      {h && (
        <div className="absolute left-1/2 -translate-x-1/2 top-1.5 flex items-stretch pointer-events-none hud-text" dir="ltr">
          <div className="flex flex-col items-center px-3 py-0.5 rounded-l-md bg-black/45 min-w-[70px]" style={{ borderBottom: `2px solid ${h.colorA}` }}>
            <div className="text-[10px] font-bold opacity-90 truncate max-w-[90px]" style={{ color: h.colorA }}>{h.labelA}</div>
            <div className="text-xl font-black leading-none" style={{ color: h.colorA }}>{h.scoreA}</div>
          </div>
          <div className="flex flex-col items-center justify-center px-3 bg-black/65">
            {h.mode === 'zombie' ? <div className="text-lg font-black text-lime-300">{h.phase === 'break' ? `⏱ ${Math.ceil(h.timer)}` : '🧟'}</div>
              : <div className={`text-lg font-black ${h.timer < 15 && h.phase === 'live' ? 'text-red-400' : 'text-white'}`}>{h.phase === 'freeze' ? Math.ceil(h.timer) : timerStr}</div>}
            <div className="text-[9px] text-white/70 font-bold" dir="rtl">{h.mode === 'classic' ? `دور ${fa(h.round)}` : h.mode === 'armsrace' ? `سطح ${fa(h.armsLevel + 1)}/${fa(h.armsTotal)}` : mode.name}</div>
          </div>
          <div className="flex flex-col items-center px-3 py-0.5 rounded-r-md bg-black/45 min-w-[70px]" style={{ borderBottom: `2px solid ${h.colorB}` }}>
            <div className="text-[10px] font-bold opacity-90 truncate max-w-[90px]" style={{ color: h.colorB }}>{h.labelB}</div>
            <div className="text-xl font-black leading-none" style={{ color: h.colorB }}>{h.scoreB}</div>
          </div>
        </div>
      )}
      {h && (h.mode === 'classic') && (
        <div className="absolute left-1/2 -translate-x-1/2 top-[52px] flex gap-3 text-[11px] font-bold pointer-events-none hud-text" dir="ltr">
          <span className="text-sky-300">● {h.aliveA}</span><span className="text-orange-300">● {h.aliveB}</span>
        </div>
      )}

      {/* ===== TOP RIGHT: killfeed + slots ===== */}
      <div className="absolute right-2 top-2 flex flex-col items-end gap-1 pointer-events-none" style={{ paddingRight: 'env(safe-area-inset-right)' }}>
        {h?.killfeed.map(k => (
          <div key={k.id} className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] tall:text-xs font-bold fade-up ${k.me ? 'bg-black/75 border border-red-500/70' : 'bg-black/50'}`} dir="ltr">
            <span style={{ color: k.kc }}>{k.killer}</span>
            <span className="text-white/80 text-[9px] px-1 bg-white/10 rounded">{k.weapon}</span>
            {k.hs && <span className="w-3.5 h-3.5 text-red-400">{Ico.skull()}</span>}
            <span style={{ color: k.vc }}>{k.victim}</span>
          </div>
        ))}
      </div>
      {h && !h.dead && (
        <div className={`absolute flex flex-col gap-1 pointer-events-none ${isTouch ? 'left-1/2 -translate-x-1/2 bottom-1.5 items-center' : 'right-4 bottom-4 items-end'}`} dir="ltr">
          <div className={`flex gap-1 pointer-events-auto ${isTouch ? 'flex-row' : 'flex-col items-end'}`}>
            {h.slots.map((id, i) => id && (
              <button key={i} data-btn={'slot' + i} onClick={() => engRef.current?.switchSlot(i)}
                className={`flex items-center gap-1 px-1.5 py-1 rounded-md transition ${h.curSlot === i ? 'bg-amber-500/30 border border-amber-400 text-white' : 'bg-black/35 border border-white/10 text-white/55'}`}>
                {i === 3 && <span className="text-[10px] font-black">x{h.grenades}</span>}
                <GunSil type={W[id].type} className={isTouch ? 'w-11 h-4' : 'w-14 h-5'} />
              </button>
            ))}
          </div>
          <div className={`hud-text flex items-baseline gap-2 ${isTouch ? '' : 'flex-col items-end gap-0'}`}>
            {def.mag > 0 && (
              <div className="font-black leading-none">
                <span className={`text-3xl ${h.mag <= def.mag * 0.25 ? 'text-red-400' : 'text-white'}`}>{save.mods.infAmmo ? '∞' : h.mag}</span>
                <span className="text-base text-white/70"> / {save.mods.infAmmo ? '∞' : h.res}</span>
              </div>
            )}
            <div className="text-[11px] text-amber-300 font-bold" dir="rtl">{h.weaponName}</div>
          </div>
        </div>
      )}

      {/* desktop hints */}
      {!isTouch && !locked && !paused && !buyOpen && h && h.phase !== 'over' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none" dir="rtl">
          <div className="metal-panel rounded-xl px-8 py-5 text-center">
            <div className="text-2xl font-black text-amber-400 mb-2">برای ادامه کلیک کنید</div>
            <div className="text-xs text-white/70 leading-6">WASD حرکت • ماوس نشانه‌گیری • کلیک چپ شلیک • کلیک راست دوربین<br />R خشاب • Space پرش • C نشستن • 1-4 اسلحه • G نارنجک • B خرید • Tab جدول</div>
          </div>
        </div>
      )}

      {/* ===== MOBILE CONTROLS ===== */}
      {isTouch && h && !h.dead && h.phase !== 'over' && (
        <>
          <div ref={joyBase} className="absolute w-[130px] h-[130px] rounded-full border-2 border-white/50 bg-white/5 -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-opacity"
            style={{ left: 'calc(120px + env(safe-area-inset-left))', top: 'calc(100% - 92px)', opacity: 0.45 }}>
            <div className="absolute inset-0 flex items-center justify-center text-white/40 text-xs">
              <span className="absolute top-1.5">▲</span><span className="absolute bottom-1.5">▼</span><span className="absolute left-2">◀</span><span className="absolute right-2">▶</span>
            </div>
            <div ref={joyKnob} className="absolute left-1/2 top-1/2 w-[54px] h-[54px] rounded-full bg-white/35 border-2 border-white/80" style={{ transform: 'translate(-50%,-50%)' }} />
          </div>
          {save.settings.leftFire && def.type !== 'grenade' && (
            <div data-btn="fireL" className="absolute rounded-full bg-black/30 border-2 border-red-400/70 text-red-300 p-3 transition"
              style={{ width: 64 * bs, height: 64 * bs, left: 'calc(22px + env(safe-area-inset-left))', top: '40%' }}>{Ico.fire('#ff8080')}</div>
          )}
          {/* right cluster */}
          <div className="absolute" style={{ right: 'calc(16px + env(safe-area-inset-right))', bottom: 16, width: 250 * bs, height: 230 * bs }}>
            <div data-btn="fire" className="absolute rounded-full bg-red-600/35 border-[3px] border-red-400/80 p-4 transition shadow-[0_0_20px_rgba(255,0,0,.3)]"
              style={{ width: 96 * bs, height: 96 * bs, right: 20 * bs, bottom: 30 * bs }}>{Ico.fire('#ffd0d0')}</div>
            {def.type !== 'knife' && def.type !== 'grenade' && (
              <div data-btn="aim" className={`absolute rounded-full border-2 p-2.5 transition ${h.aiming ? 'bg-amber-500/50 border-amber-300 text-white' : 'bg-black/35 border-white/50 text-white/80'}`}
                style={{ width: 56 * bs, height: 56 * bs, right: 125 * bs, bottom: 110 * bs }}>{Ico.scope()}</div>
            )}
            {def.mag > 0 && (
              <div data-btn="reload" className="absolute rounded-full bg-black/35 border-2 border-white/50 text-white/85 p-3 transition"
                style={{ width: 50 * bs, height: 50 * bs, right: 30 * bs, bottom: 140 * bs }}>{Ico.reload()}</div>
            )}
            <div data-btn="jump" className="absolute rounded-full bg-black/35 border-2 border-white/50 text-white/85 p-2.5 transition"
              style={{ width: 56 * bs, height: 56 * bs, right: 135 * bs, bottom: 30 * bs }}>{Ico.jump()}</div>
            <div data-btn="crouch" className={`absolute rounded-full border-2 p-2.5 transition ${h.crouch ? 'bg-sky-500/50 border-sky-300 text-white' : 'bg-black/35 border-white/50 text-white/85'}`}
              style={{ width: 50 * bs, height: 50 * bs, right: 195 * bs, bottom: 70 * bs }}>{Ico.crouch()}</div>
            {h.grenades > 0 && (
              <div data-btn="grenade" className={`absolute rounded-full border-2 p-2.5 transition ${h.curSlot === 3 ? 'bg-lime-600/50 border-lime-300 text-white' : 'bg-black/35 border-white/50 text-white/85'}`}
                style={{ width: 48 * bs, height: 48 * bs, right: 85 * bs, bottom: 175 * bs }}>{Ico.grenade()}</div>
            )}
          </div>
        </>
      )}
      {!isTouch && h?.canBuy && !buyOpen && (
        <div className="absolute left-4 bottom-4 text-lime-300 font-bold text-sm hud-text pointer-events-none" dir="rtl">🛒 برای خرید کلید B را بزنید</div>
      )}

      {/* ===== SCOREBOARD ===== */}
      {board && h && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none" dir="rtl">
          <div className="metal-panel rounded-xl w-[min(640px,92vw)] max-h-[82vh] overflow-hidden">
            <div className="px-4 py-2 bg-amber-500/90 text-black font-black flex justify-between"><span>{mode.icon} {mode.name}</span><span>جدول امتیازات</span></div>
            <table className="w-full text-sm">
              <thead><tr className="text-white/60 text-xs"><th className="text-right px-4 py-1.5">بازیکن</th><th>کشته</th><th>مرگ</th><th>امتیاز</th></tr></thead>
              <tbody>
                {h.rows.map((r, i) => (
                  <tr key={i} className={`${r.me ? 'bg-amber-500/20' : i % 2 ? 'bg-white/5' : ''} ${r.alive ? '' : 'opacity-50'}`}>
                    <td className="px-4 py-1 font-bold" style={{ color: r.color }}>{!r.alive && '☠ '}{r.name}</td>
                    <td className="text-center">{fa(r.kills)}</td><td className="text-center">{fa(r.deaths)}</td><td className="text-center text-amber-300">{fa(r.score)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===== BUY MENU ===== */}
      {buyOpen && h && <BuyMenu hud={h} onBuy={(id) => engRef.current?.buy(id)} onClose={toggleBuy} />}

      {/* ===== PAUSE ===== */}
      {paused && (
        <div data-ui className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" dir="rtl">
          <div className="metal-panel rounded-2xl p-6 w-[min(420px,90vw)] pop-in">
            <div className="title-grunge text-3xl text-center mb-4">توقف بازی</div>
            <button onClick={resume} className="btn-mil btn-gold w-full py-3 rounded-lg text-lg mb-3">▶ ادامه بازی</button>
            <div className="text-sm mb-1 flex justify-between"><span>حساسیت نشانه‌گیری</span><span className="text-amber-300">{fa(save.settings.sens.toFixed(1))}</span></div>
            <input type="range" min={0.2} max={3} step={0.1} value={save.settings.sens} className="w-full mb-3" onChange={e => setSave(s => ({ ...s, settings: { ...s.settings, sens: +e.target.value } }))} />
            <div className="text-sm mb-1 flex justify-between"><span>صدا</span><span className="text-amber-300">{fa(Math.round(save.settings.volume * 100))}٪</span></div>
            <input type="range" min={0} max={1} step={0.05} value={save.settings.volume} className="w-full mb-4" onChange={e => { setSave(s => ({ ...s, settings: { ...s.settings, volume: +e.target.value } })); audio.setVolume(+e.target.value); }} />
            <button onClick={quit} className="btn-mil w-full py-2.5 rounded-lg text-red-300">✖ خروج به منو</button>
          </div>
        </div>
      )}
    </div>
  );
}

function BuyMenu({ hud, onBuy, onClose }: { hud: HudState; onBuy: (id: string) => void; onClose: () => void }) {
  const save = useSave();
  const cats: { t: string; types: WeaponType[] }[] = [
    { t: 'کلت', types: ['pistol'] },
    { t: 'مسلسل دستی', types: ['smg'] },
    { t: 'سنگین', types: ['shotgun', 'lmg'] },
    { t: 'تفنگ', types: ['rifle'] },
    { t: 'تک‌تیرانداز', types: ['sniper'] },
  ];
  const [cat, setCat] = useState(3);
  const free = hud.buyMode === 'free' || save.mods.infMoney;
  const owned = (id: string) => save.owned.includes(id) || save.mods.allUnlocked;
  const items = WEAPONS.filter(w => cats[cat].types.includes(w.type));
  return (
    <div data-ui className="absolute inset-0 z-40 flex items-center justify-center bg-black/60" dir="rtl">
      <div className="metal-panel rounded-xl w-[min(820px,96vw)] h-[min(440px,92vh)] flex flex-col overflow-hidden pop-in">
        <div className="flex items-center justify-between px-4 py-2 bg-black/40 border-b border-white/10">
          <div className="font-black text-amber-400 text-lg">🛒 منوی خرید</div>
          <div className="font-black text-lime-400 text-lg" dir="ltr">{free ? 'FREE' : `$${hud.money.toLocaleString()}`}</div>
          <button onClick={onClose} className="btn-mil px-4 py-1 rounded text-red-400 text-lg">✕</button>
        </div>
        <div className="flex flex-1 min-h-0">
          <div className="w-32 md:w-40 flex flex-col gap-1 p-2 border-l border-white/10 scroll-y">
            {cats.map((c, i) => (
              <button key={i} onClick={() => setCat(i)} className={`btn-mil py-2 rounded text-sm ${cat === i ? 'border-amber-400 text-amber-300' : ''}`}>{c.t}</button>
            ))}
            <div className="h-px bg-white/10 my-1" />
            <button onClick={() => onBuy('armor')} className="btn-mil py-1.5 rounded text-xs">جلیقه <span className="text-lime-400">$650</span></button>
            <button onClick={() => onBuy('armorh')} className="btn-mil py-1.5 rounded text-xs">جلیقه+کلاه <span className="text-lime-400">$1000</span></button>
            <button onClick={() => onBuy('he')} className="btn-mil py-1.5 rounded text-xs">نارنجک <span className="text-lime-400">$300</span></button>
          </div>
          <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-2 p-2 scroll-y content-start">
            {items.map(w => {
              const ok = owned(w.id);
              const afford = free || hud.money >= w.price;
              return (
                <button key={w.id} disabled={!ok} onClick={() => onBuy(w.id)}
                  className={`relative rounded-lg p-2 text-right border transition ${ok ? (afford ? 'bg-white/5 border-white/15 hover:border-amber-400 active:scale-95' : 'bg-white/5 border-red-500/30 opacity-60') : 'bg-black/40 border-white/5 opacity-50'}`}>
                  <GunSil type={w.type} className="w-full h-12 text-white/85" />
                  <div className="font-bold text-sm mt-1">{w.name}</div>
                  <div className="flex justify-between text-xs mt-0.5">
                    <span className="text-white/50">{TYPE_FA[w.type]}</span>
                    <span className={afford ? 'text-lime-400 font-bold' : 'text-red-400 font-bold'} dir="ltr">${w.price}</span>
                  </div>
                  {!ok && <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 rounded-lg"><div className="w-6 h-6 text-amber-400">{Ico.lock()}</div><div className="text-[10px] text-amber-200 mt-1">در اسلحه‌خانه باز کنید</div></div>}
                </button>
              );
            })}
          </div>
        </div>
        <div className="px-4 py-1.5 text-[11px] text-white/50 border-t border-white/10">💡 سکه‌هایت را در بخش اسلحه‌خانه خرج کن تا اسلحه‌های بیشتری باز شود · {faNum(save.coins)} سکه</div>
      </div>
    </div>
  );
}
