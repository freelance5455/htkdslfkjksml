import { useEffect, useRef, useState } from "react";
import {
  BedDouble, Brush, Camera, Cat as CatIcon, Cookie, Crown, Download, Droplets, Fish, Flower2, Gamepad2,
  Gem, Heart, Moon, Share2, Sparkles, Star, Sun, Trophy, UtensilsCrossed, X,
} from "lucide-react";
import Cat from "./Cat";
import { EndScreen, GameShell, IntroScreen, type GameProps } from "./GamesA";
import type { AccessoryItem, CatalogCat, FurStyle } from "../data/catalog";
import { ItemPreview } from "./Panels";
import { sfx } from "../lib/sound";

/* ================================================================
   D. MEMORIA GATUNA
   ================================================================ */
const MEM_ICONS = [
  { Icon: CatIcon, color: "#f9a8d4", label: "gatito" },
  { Icon: Fish, color: "#7dd3fc", label: "pez" },
  { Icon: Star, color: "#f5c451", label: "estrella" },
  { Icon: Heart, color: "#fb7185", label: "corazón" },
  { Icon: Moon, color: "#c4b5fd", label: "luna" },
  { Icon: Sun, color: "#fbbf24", label: "sol" },
  { Icon: Flower2, color: "#6ee7b7", label: "flor" },
  { Icon: Crown, color: "#fde68a", label: "corona" },
  { Icon: Gem, color: "#93c5fd", label: "gema" },
  { Icon: Cookie, color: "#d99a55", label: "galleta" },
];

const MEM_SIZES = [
  { label: "Pequeño 4×3", cols: 4, pairs: 6 },
  { label: "Mediano 4×4", cols: 4, pairs: 8 },
  { label: "Grande 5×4", cols: 5, pairs: 10 },
];

export function MemoryGame({ catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [sizeIdx, setSizeIdx] = useState(1);
  const [deck, setDeck] = useState<number[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const startedAt = useRef(0);
  const finished = useRef(false);
  const lock = useRef(false);

  const size = MEM_SIZES[sizeIdx];

  const start = () => {
    const cards = [...Array(size.pairs).keys(), ...Array(size.pairs).keys()]
      .sort(() => Math.random() - 0.5);
    setDeck(cards);
    setFlipped([]);
    setMatched([]);
    setMoves(0);
    setSeconds(0);
    startedAt.current = Date.now();
    finished.current = false;
    lock.current = false;
    setPhase("play");
    sfx.pop();
  };

  useEffect(() => {
    if (phase !== "play") return;
    const iv = setInterval(() => setSeconds(Math.floor((Date.now() - startedAt.current) / 1000)), 500);
    return () => clearInterval(iv);
  }, [phase]);

  const score = Math.max(10, size.pairs * 100 - moves * 4 - seconds * 2);
  const coins = size.pairs * 2 + Math.max(0, 10 - Math.floor(seconds / 10));

  useEffect(() => {
    if (phase === "play" && deck.length > 0 && matched.length === deck.length && !finished.current) {
      finished.current = true;
      sfx.sparkle();
      setTimeout(() => { onFinish(score, coins); setPhase("end"); }, 600);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matched]);

  const flip = (idx: number) => {
    if (lock.current || flipped.includes(idx) || matched.includes(idx)) return;
    const next = [...flipped, idx];
    setFlipped(next);
    sfx.pop();
    if (next.length === 2) {
      setMoves((m) => m + 1);
      if (deck[next[0]] === deck[next[1]]) {
        setMatched((m) => [...m, next[0], next[1]]);
        setFlipped([]);
        sfx.coin();
      } else {
        lock.current = true;
        setTimeout(() => { setFlipped([]); lock.current = false; }, 750);
      }
    }
  };

  return (
    <GameShell title="Memoria Gatuna" subtitle={`${catName} ejercita su memoria mágica`} onClose={onClose} bg="bg-gradient-to-b from-[#123] to-[#0a0f1e]">
      {phase === "intro" && (
        <div className="flex flex-1 flex-col">
          <div className="grid grid-cols-3 gap-2 p-4 pb-0">
            {MEM_SIZES.map((s, i) => (
              <button key={s.label} onClick={() => setSizeIdx(i)} className={`min-h-[48px] rounded-2xl px-1 font-display text-[12px] font-semibold ${sizeIdx === i ? "bg-[#f5c451] text-[#241a02]" : "border border-white/15 bg-white/8 text-white/75"}`}>
                {s.label}
              </button>
            ))}
          </div>
          <IntroScreen text="Toca las cartas para voltearlas y encuentra las parejas de gatitos y accesorios. Termina en pocos movimientos y segundos para ganar más puntos." record={record} recordLabel="Récord de puntos" onStart={start} />
        </div>
      )}
      {phase === "end" && <EndScreen score={score} scoreLabel="Puntos de memoria" coins={coins} record={Math.max(record, score)} isNewRecord={score > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div className="flex flex-1 flex-col p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-extrabold text-white">Movimientos: {moves}</span>
            <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-extrabold text-white">{seconds}s</span>
            <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-extrabold text-pink-300">Parejas: {matched.length / 2}/{size.pairs}</span>
          </div>
          <div className="grid flex-1 content-center gap-2" style={{ gridTemplateColumns: `repeat(${size.cols}, 1fr)` }}>
            {deck.map((card, idx) => {
              const up = flipped.includes(idx) || matched.includes(idx);
              const { Icon, color } = MEM_ICONS[card];
              return (
                <button
                  key={idx}
                  onClick={() => flip(idx)}
                  aria-label={up ? MEM_ICONS[card].label : "Carta boca abajo"}
                  className={`flex aspect-[3/4] items-center justify-center rounded-2xl border-2 transition active:scale-95 ${
                    matched.includes(idx) ? "border-emerald-300 bg-emerald-400/15" : up ? "border-[#caa25a] bg-[#241a02]" : "border-white/15 bg-gradient-to-br from-[#3b2d5c] to-[#1d1836]"
                  }`}
                >
                  {up ? <Icon style={{ color, width: "55%", height: "55%" }} /> : <Star className="h-6 w-6 text-[#caa25a]/60" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   G. SALÓN DE BELLEZA — bañar, secar y peinar
   ================================================================ */
export function SalonGame({ fur, eyeColor, catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [step, setStep] = useState(0);
  const [bubbles, setBubbles] = useState<{ id: number; x: number; y: number; r: number }[]>([]);
  const [dry, setDry] = useState(0);
  const [brush, setBrush] = useState(0);
  const [hearts, setHearts] = useState(0);
  const drying = useRef(false);
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const finished = useRef(false);

  const start = () => {
    setStep(0);
    setDry(0);
    setBrush(0);
    setHearts(0);
    finished.current = false;
    setBubbles(Array.from({ length: 12 }, (_, i) => ({ id: i, x: 12 + (i % 4) * 24 + Math.random() * 8, y: 18 + Math.floor(i / 4) * 26 + Math.random() * 8, r: 15 + Math.random() * 12 })));
    setPhase("play");
    sfx.pop();
  };

  useEffect(() => {
    if (phase !== "play" || step !== 1) return;
    let raf = 0;
    const loop = () => {
      if (drying.current) setDry((d) => Math.min(100, d + 1.1));
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase, step]);

  useEffect(() => { if (dry >= 100 && step === 1) { setStep(2); setHearts((h) => h + 1); sfx.sparkle(); } }, [dry, step]);
  useEffect(() => { if (brush >= 100 && step === 2) { setStep(3); setHearts((h) => h + 1); sfx.sparkle(); } }, [brush, step]);

  const popBubble = (id: number) => {
    sfx.pop();
    setBubbles((prev) => {
      const next = prev.filter((b) => b.id !== id);
      if (next.length === 0) { setStep(1); setHearts((h) => h + 1); sfx.sparkle(); }
      return next;
    });
  };

  const claim = () => {
    if (!finished.current) { finished.current = true; onFinish(100 + hearts * 10, 8 + hearts); }
    setPhase("end");
  };

  const STEPS = ["Bañar", "Secar", "Peinar", "¡Listo!"];

  return (
    <GameShell title="Salón de Belleza" subtitle={`Día de spa para ${catName}`} onClose={onClose} bg="bg-gradient-to-b from-[#3a2140] to-[#1c1024]">
      {phase === "intro" && <IntroScreen text="Deja a tu gatito hermoso en 3 pasos: revienta las burbujitas del baño, mantén presionado para secar con la toalla, y arrastra el cepillo sobre su pelaje. Termina con un look brillante." record={record} recordLabel="Mejor sesión de spa" onStart={start} />}
      {phase === "end" && <EndScreen score={100 + hearts * 10} scoreLabel="Puntos de belleza" coins={8 + hearts} record={Math.max(record, 100 + hearts * 10)} isNewRecord={100 + hearts * 10 > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div className="flex flex-1 flex-col p-4">
          <div className="mb-3 flex items-center justify-center gap-1.5">
            {STEPS.map((label, i) => (
              <span key={label} className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold ${step === i ? "bg-[#f5c451] text-[#241a02]" : step > i ? "bg-emerald-400/25 text-emerald-300" : "bg-white/8 text-white/40"}`}>
                {i + 1}. {label}
              </span>
            ))}
          </div>
          <div className="flex items-center justify-center gap-1.5">
            {[0, 1, 2].map((i) => <Heart key={i} className={`h-5 w-5 ${i < hearts ? "text-pink-400" : "text-white/20"}`} fill="currentColor" />)}
            <span className="ml-1 text-xs font-bold text-white/55">satisfacción</span>
          </div>

          <div
            className="relative mx-auto mt-2 w-[min(78vw,290px)] touch-none"
            onPointerMove={(e) => {
              if (step !== 2 || !lastPos.current) return;
              const d = Math.hypot(e.clientX - lastPos.current.x, e.clientY - lastPos.current.y);
              lastPos.current = { x: e.clientX, y: e.clientY };
              if (d > 4) setBrush((b) => Math.min(100, b + d / 14));
            }}
            onPointerDown={(e) => { lastPos.current = { x: e.clientX, y: e.clientY }; }}
            onPointerUp={() => { lastPos.current = null; }}
          >
            <div key={`${step}-${Math.floor(brush / 20)}`} className={step === 1 && dry > 0 && dry < 100 ? "anim-purr" : undefined}>
              <Cat mood={step === 3 ? "happy" : "normal"} fur={fur} eyeColor={eyeColor} />
            </div>
            {step === 0 && bubbles.map((b) => (
              <button
                key={b.id}
                onPointerDown={() => popBubble(b.id)}
                aria-label="Burbuja de jabón"
                className="absolute rounded-full border border-sky-200/80 bg-sky-300/30"
                style={{ left: `${b.x}%`, top: `${b.y}%`, width: b.r, height: b.r }}
              />
            ))}
            {step === 0 && <p className="absolute -bottom-9 inset-x-0 text-center text-sm font-bold text-sky-200">Toca las burbujitas para bañar ({12 - bubbles.length}/12)</p>}
            {step === 3 && (
              <>
                <Sparkles className="sparkle-spin absolute left-2 top-6 h-7 w-7 text-[#f5c451]" />
                <Sparkles className="sparkle-spin absolute right-3 top-16 h-6 w-6 text-pink-300" />
                <Sparkles className="sparkle-spin absolute bottom-10 left-6 h-5 w-5 text-emerald-300" />
              </>
            )}
          </div>

          {step === 1 && (
            <div className="mt-auto">
              <div className="mb-2 h-3 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-sky-300 transition-all" style={{ width: `${dry}%` }} />
              </div>
              <button
                onPointerDown={() => { drying.current = true; }}
                onPointerUp={() => { drying.current = false; }}
                onPointerLeave={() => { drying.current = false; }}
                className="min-h-[58px] w-full rounded-2xl bg-sky-400 font-display text-lg font-bold text-sky-950 active:scale-[0.98]"
              >
                <Droplets className="mr-1 inline h-5 w-5" /> Mantén para secar
              </button>
            </div>
          )}
          {step === 2 && (
            <p className="mt-auto flex items-center justify-center gap-2 pb-2 text-center text-sm font-bold text-pink-200">
              <Brush className="h-5 w-5" /> Arrastra tu dedo sobre el gatito para peinarlo ({Math.floor(brush)}%)
            </p>
          )}
          {step === 3 && (
            <button onClick={claim} className="mt-auto min-h-[56px] w-full rounded-2xl bg-[#f5c451] font-display text-lg font-bold text-[#241a02] active:scale-[0.98]">
              ¡Quedó hermoso! Reclamar recompensa
            </button>
          )}
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   H. DESFILE DE MODA
   ================================================================ */
export interface FavoriteLook { name: string; hatId: string | null; bowId: string | null; collarId: string | null; theme: string }

interface FashionProps extends GameProps {
  ownedAccessories: AccessoryItem[];
  hat: AccessoryItem | null;
  bow: AccessoryItem | null;
  collar: AccessoryItem | null;
  onSaveFavorite: (fav: FavoriteLook) => void;
}

const THEMES = [
  { name: "Fiesta de Cumpleaños", keywords: ["Cumpleaños", "Fiesta", "Dorado", "Rosa"], styles: ["corona", "grande"], charms: ["star", "heart"] },
  { name: "Noche Mágica", keywords: ["Luna", "Medianoche", "Lavanda", "Mágica"], styles: ["bruja", "diadema", "halo"], charms: ["moon", "star"] },
  { name: "Jardín de Primavera", keywords: ["Jardín", "Primavera", "Menta", "Flor"], styles: ["flores", "flor"], charms: ["flower", "bell"] },
  { name: "Día de Playa", keywords: ["Playa", "Verano", "Cielo", "Coral"], styles: ["gorra", "mini"], charms: ["fish", "bellSilver"] },
  { name: "Invierno Acogedor", keywords: ["Invierno", "Nube", "Blanco", "Suave"], styles: ["gorro", "boina"], charms: ["bell", "paw"] },
];

export function FashionGame({ fur, eyeColor, catName, record, onFinish, onClose, ownedAccessories, hat, bow, collar, onSaveFavorite }: FashionProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [theme, setTheme] = useState(THEMES[0]);
  const [sel, setSel] = useState<{ hat: AccessoryItem | null; bow: AccessoryItem | null; collar: AccessoryItem | null }>({ hat, bow, collar });
  const [result, setResult] = useState<{ score: number; lines: string[] } | null>(null);
  const finished = useRef(false);

  const bySlot = (slot: string) => ownedAccessories.filter((i) => i.slot === slot);

  const judge = () => {
    const lines: string[] = [];
    let score = 0;
    const check = (item: AccessoryItem | null, label: string) => {
      if (!item) { lines.push(`${label}: sin accesorio (+0)`); return; }
      let pts = 10;
      if (theme.keywords.some((k) => item.name.includes(k))) { pts += 25; lines.push(`${label}: ¡color/tema perfecto! (+35)`); }
      else if (theme.styles.includes(item.style)) { pts += 18; lines.push(`${label}: estilo ideal para el tema (+28)`); }
      else lines.push(`${label}: bonito, aunque no es del tema (+10)`);
      if (item.charm && theme.charms.includes(item.charm)) { pts += 12; lines.push(`${label}: el dije combina de maravilla (+12)`); }
      score += pts;
    };
    check(sel.hat, "Sombrero");
    check(sel.bow, "Moño");
    check(sel.collar, "Collar");
    const colors = [sel.hat?.primary, sel.bow?.primary, sel.collar?.primary].filter(Boolean);
    if (colors.length === 3 && new Set(colors).size === 1) { score += 10; lines.push("¡Las tres piezas son del mismo color! Armonía total (+10)"); }
    setResult({ score, lines });
    sfx.sparkle();
  };

  const stars = result ? Math.max(1, Math.min(5, Math.ceil(result.score / 20))) : 0;

  const finish = () => {
    if (!result) return;
    if (!finished.current) { finished.current = true; onFinish(result.score, stars * 3); }
    setPhase("end");
  };

  const saveFav = () => {
    onSaveFavorite({ name: `Look ${theme.name}`, hatId: sel.hat?.id ?? null, bowId: sel.bow?.id ?? null, collarId: sel.collar?.id ?? null, theme: theme.name });
    sfx.coin();
  };

  const row = (label: string, slot: "hat" | "bow" | "collar") => (
    <div>
      <p className="mb-1 font-display text-[13px] font-semibold text-white/70">{label}</p>
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
        <button
          onClick={() => setSel((s) => ({ ...s, [slot]: null }))}
          className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border font-display text-[10px] font-bold ${sel[slot] === null ? "border-[#f5c451] bg-[#2a2210] text-[#ffe9a8]" : "border-white/12 bg-[#1a1828] text-white/50"}`}
        >
          Ninguno
        </button>
        {bySlot(slot).map((item) => (
          <button
            key={item.id}
            onClick={() => setSel((s) => ({ ...s, [slot]: item }))}
            aria-label={item.name}
            className={`flex h-14 w-16 shrink-0 items-center justify-center rounded-xl border ${sel[slot]?.id === item.id ? "border-[#f5c451] bg-[#2a2210]" : "border-white/12 bg-[#1a1828]"}`}
          >
            <ItemPreview item={item} />
          </button>
        ))}
        {bySlot(slot).length === 0 && <p className="py-3 text-xs font-bold text-white/40">No tienes piezas de esta categoría todavía.</p>}
      </div>
    </div>
  );

  return (
    <GameShell title="Desfile de Moda" subtitle={`Viste a ${catName} según el tema`} onClose={onClose} bg="bg-gradient-to-b from-[#2e1a3d] to-[#170d24]">
      {phase === "intro" && (
        <div className="flex flex-1 flex-col">
          <div className="flex flex-wrap gap-1.5 p-4 pb-0">
            {THEMES.map((t) => (
              <button key={t.name} onClick={() => setTheme(t)} className={`rounded-full px-3 py-2 font-display text-[12px] font-semibold ${theme.name === t.name ? "bg-[#f5c451] text-[#241a02]" : "border border-white/15 bg-white/8 text-white/75"}`}>
                {t.name}
              </button>
            ))}
          </div>
          <IntroScreen text={`El jurado puntúa: piezas acordes al tema "${theme.name}", dijes que combinen y armonía de colores. Arma tu look con las prendas de tu vestidor, guarda tus favoritos y gana hasta 5 estrellas.`} record={record} recordLabel="Mejor puntuación" onStart={() => setPhase("play")} />
        </div>
      )}
      {phase === "end" && result && <EndScreen score={result.score} scoreLabel="Puntos del jurado" coins={stars * 3} record={Math.max(record, result.score)} isNewRecord={result.score > record} onReplay={() => { setResult(null); finished.current = false; setPhase("play"); }} onExit={onClose} />}
      {phase === "play" && (
        <div className="no-scrollbar flex flex-1 flex-col gap-2 overflow-y-auto p-4">
          <p className="text-center font-display text-base font-semibold text-[#ffe9a8]">Tema: {theme.name}</p>
          <div className="mx-auto w-[min(52vw,190px)]">
            <Cat mood="happy" fur={fur} eyeColor={eyeColor} hat={sel.hat} bow={sel.bow} collar={sel.collar} />
          </div>
          {row("Sombrero", "hat")}
          {row("Moño", "bow")}
          {row("Collar", "collar")}
          {!result ? (
            <button onClick={judge} className="mt-1 flex min-h-[54px] items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] active:scale-[0.98]">
              <Trophy className="h-5 w-5" /> ¡A la pasarela!
            </button>
          ) : (
            <div className="rounded-3xl border border-[#caa25a]/60 bg-black/40 p-4">
              <p className="flex items-center justify-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => <Star key={i} className={`h-7 w-7 ${i <= stars ? "text-[#f5c451]" : "text-white/20"}`} fill="currentColor" />)}
              </p>
              <p className="mt-1 text-center font-display text-xl font-bold text-white">{result.score} puntos</p>
              <ul className="mt-2 space-y-1">
                {result.lines.map((l, i) => <li key={i} className="text-center text-[13px] font-semibold text-white/70">{l}</li>)}
              </ul>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button onClick={saveFav} className="flex min-h-[48px] items-center justify-center gap-1.5 rounded-xl border border-pink-300/50 bg-pink-400/15 font-display text-sm font-bold text-pink-200 active:scale-95">
                  <Heart className="h-4 w-4" /> Guardar look
                </button>
                <button onClick={finish} className="min-h-[48px] rounded-xl bg-[#f5c451] font-display text-sm font-bold text-[#241a02] active:scale-95">
                  Terminar
                </button>
              </div>
              <button onClick={() => setResult(null)} className="mt-2 w-full py-1 text-center text-xs font-bold text-white/50">Seguir combinando</button>
            </div>
          )}
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   I. CUIDADO DEL GATITO — rutina completa de cuidados
   ================================================================ */
interface CareProps extends GameProps { onCareComplete: () => void }

export function CareGame({ fur, eyeColor, catName, record, onFinish, onClose, onCareComplete }: CareProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [done, setDone] = useState<boolean[]>([false, false, false, false, false]);
  const [taps, setTaps] = useState(0);
  const [fill, setFill] = useState(0);
  const holding = useRef(false);
  const brushDist = useRef(0);
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const finished = useRef(false);
  const active = done.findIndex((d) => !d);

  useEffect(() => {
    if (phase !== "play") return;
    let raf = 0;
    const loop = () => {
      if (holding.current && active === 1) setFill((f) => Math.min(100, f + 1.2));
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase, active]);

  const completeTask = (i: number) => {
    sfx.sparkle();
    setTaps(0);
    setFill(0);
    brushDist.current = 0;
    setDone((prev) => {
      const next = [...prev];
      next[i] = true;
      if (next.every(Boolean) && !finished.current) {
        finished.current = true;
        onCareComplete();
        setTimeout(() => { onFinish(50, 12); setPhase("end"); }, 900);
      }
      return next;
    });
  };

  useEffect(() => { if (fill >= 100 && active === 1) completeTask(1); }, [fill, active]);
  useEffect(() => { if (active === 0 && taps >= 3) completeTask(0); }, [taps, active]);
  useEffect(() => { if (active === 3 && taps >= 3) completeTask(3); }, [taps, active]);
  useEffect(() => { if (active === 4 && taps >= 5) completeTask(4); }, [taps, active]);

  const TASKS = [
    { label: "Alimentar", Icon: UtensilsCrossed, hint: "Toca el platito 3 veces para servir comidita" },
    { label: "Dar agua", Icon: Droplets, hint: "Mantén presionado para llenar el bebedero" },
    { label: "Cepillar", Icon: Brush, hint: "Arrastra el cepillo sobre el pelaje" },
    { label: "Preparar la cama", Icon: BedDouble, hint: "Toca la almohada 3 veces para esponjarla" },
    { label: "Jugar con juguetes", Icon: Gamepad2, hint: "Toca la bolita de estambre 5 veces" },
  ];

  return (
    <GameShell title="Cuidado del Gatito" subtitle={`Rutina de mimos para ${catName}`} onClose={onClose} bg="bg-gradient-to-b from-[#1f2c1a] to-[#101a0e]">
      {phase === "intro" && <IntroScreen text="Completa la rutina de cuidados: alimentar, dar agua, cepillar, preparar la camita y jugar. Cada tarea hace muy feliz a tu gatito y al terminar, sus barras de cuidado suben muchísimo." record={record} recordLabel="Rutinas completadas" onStart={() => setPhase("play")} />}
      {phase === "end" && <EndScreen score={50} scoreLabel="Puntos de cuidado" coins={12} record={Math.max(record, 50)} isNewRecord={false} onReplay={() => { setDone([false, false, false, false, false]); finished.current = false; setPhase("play"); }} onExit={onClose} />}
      {phase === "play" && (
        <div className="flex flex-1 flex-col p-4">
          <div className="mb-2 flex flex-wrap justify-center gap-1.5">
            {TASKS.map((t, i) => (
              <span key={t.label} className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold ${done[i] ? "bg-emerald-400/25 text-emerald-300" : i === active ? "bg-[#f5c451] text-[#241a02]" : "bg-white/8 text-white/40"}`}>
                <t.Icon className="h-3.5 w-3.5" /> {t.label}
              </span>
            ))}
          </div>
          <p className="mb-1 text-center text-sm font-bold text-[#ffe9a8]">{active >= 0 ? TASKS[active].hint : "¡Rutina completa!"}</p>

          <div
            className="relative mx-auto w-[min(72vw,260px)] touch-none"
            onPointerMove={(e) => {
              if (active !== 2) return;
              if (lastPos.current) {
                brushDist.current += Math.hypot(e.clientX - lastPos.current.x, e.clientY - lastPos.current.y);
                if (brushDist.current > 700) completeTask(2);
              }
              lastPos.current = { x: e.clientX, y: e.clientY };
            }}
            onPointerDown={(e) => { lastPos.current = { x: e.clientX, y: e.clientY }; }}
          >
            <Cat mood={done.every(Boolean) ? "happy" : "normal"} fur={fur} eyeColor={eyeColor} />
          </div>

          <div className="mt-auto flex flex-col items-center gap-2 pb-1">
            {active === 0 && (
              <button onClick={() => { setTaps((t) => t + 1); sfx.nom(); }} className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-2xl bg-sky-400 font-display text-lg font-bold text-sky-950 active:scale-[0.98]">
                <Fish className="h-6 w-6" /> Servir comidita ({taps}/3)
              </button>
            )}
            {active === 1 && (
              <>
                <div className="h-3 w-full overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-sky-300" style={{ width: `${fill}%` }} /></div>
                <button
                  onPointerDown={() => { holding.current = true; }}
                  onPointerUp={() => { holding.current = false; }}
                  onPointerLeave={() => { holding.current = false; }}
                  className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-2xl bg-sky-400 font-display text-lg font-bold text-sky-950 active:scale-[0.98]"
                >
                  <Droplets className="h-6 w-6" /> Mantén para llenar el agua
                </button>
              </>
            )}
            {active === 2 && <p className="flex items-center gap-2 py-3 text-sm font-bold text-pink-200"><Brush className="h-5 w-5" /> Cepilla arrastrando sobre el gatito...</p>}
            {active === 3 && (
              <button onClick={() => { setTaps((t) => t + 1); sfx.pop(); }} className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-2xl bg-violet-400 font-display text-lg font-bold text-violet-950 active:scale-[0.98]">
                <BedDouble className="h-6 w-6" /> Esponjar la almohada ({taps}/3)
              </button>
            )}
            {active === 4 && (
              <button onClick={() => { setTaps((t) => t + 1); sfx.boing(); }} className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-2xl bg-emerald-400 font-display text-lg font-bold text-emerald-950 active:scale-[0.98]">
                <Sparkles className="h-6 w-6" /> Tocar la bolita de estambre ({taps}/5)
              </button>
            )}
            {active === -1 && <p className="py-3 font-display text-lg font-bold text-emerald-300">¡Rutina completa! Tu gatito está feliz y cuidado.</p>}
          </div>
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   J. FOTOGRAFÍA MÁGICA — poses, fondos, marcos y guardar foto
   ================================================================ */
interface PhotoProps extends GameProps {
  cats: { cat: CatalogCat; name: string; fur: FurStyle }[];
  hat: AccessoryItem | null;
  bow: AccessoryItem | null;
  collar: AccessoryItem | null;
}

const PHOTO_BGS = [
  { name: "Atardecer Rosa", css: "linear-gradient(160deg,#f9a8d4,#c4b5fd 55%,#7dd3fc)", c1: "#f9a8d4", c2: "#7dd3fc" },
  { name: "Noche Estrellada", css: "linear-gradient(160deg,#1e1b4b,#312e81 60%,#0ea5e9)", c1: "#1e1b4b", c2: "#312e81" },
  { name: "Jardín Menta", css: "linear-gradient(160deg,#a7f3d0,#6ee7b7 55%,#fef9c3)", c1: "#a7f3d0", c2: "#fef9c3" },
  { name: "Dorado Real", css: "linear-gradient(160deg,#f5c451,#f59e0b 55%,#7c2d12)", c1: "#f5c451", c2: "#7c2d12" },
];
const FRAMES = [
  { name: "Dorado", css: "10px solid #f5c451" },
  { name: "Rosa", css: "10px solid #f472b6" },
  { name: "Lavanda", css: "10px solid #c4b5fd" },
  { name: "Arcoíris", css: "10px solid #6ee7b7" },
];

export function PhotoGame({ record, onFinish, onClose, cats, hat, bow, collar }: PhotoProps) {
  const [catIdx, setCatIdx] = useState(0);
  const [pose, setPose] = useState<"normal" | "happy" | "sleep">("happy");
  const [bg, setBg] = useState(0);
  const [frame, setFrame] = useState(0);
  const [stickers, setStickers] = useState(true);
  const [saved, setSaved] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  const current = cats[Math.min(catIdx, cats.length - 1)];

  const savePhoto = async () => {
    const svg = stageRef.current?.querySelector("svg");
    if (!svg || !current) return;
    try {
      const xml = new XMLSerializer().serializeToString(svg);
      const img = new Image();
      const url = URL.createObjectURL(new Blob([xml], { type: "image/svg+xml;charset=utf-8" }));
      await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
      const canvas = document.createElement("canvas");
      canvas.width = 720; canvas.height = 720;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const grad = ctx.createLinearGradient(0, 0, 720, 720);
      grad.addColorStop(0, PHOTO_BGS[bg].c1);
      grad.addColorStop(1, PHOTO_BGS[bg].c2);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 720, 720);
      ctx.drawImage(img, 110, 90, 500, 515);
      ctx.strokeStyle = ["#f5c451", "#f472b6", "#c4b5fd", "#6ee7b7"][frame];
      ctx.lineWidth = 26;
      ctx.strokeRect(13, 13, 694, 694);
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fillRect(0, 636, 720, 84);
      ctx.fillStyle = "#ffe9a8";
      ctx.font = "bold 34px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(`${current.name} · MICHILICIAS`, 360, 688);
      URL.revokeObjectURL(url);
      const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
      if (!blob) return;
      const file = new File([blob], `michilicias-${current.name}.png`, { type: "image/png" });
      const nav = navigator as Navigator & { canShare?: (d: { files: File[] }) => boolean };
      if (nav.canShare && nav.canShare({ files: [file] }) && navigator.share) {
        try { await navigator.share({ files: [file], title: "Mi foto MICHILICIAS" }); } catch { /* cancelado */ }
      } else {
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = file.name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      }
      if (!saved) { setSaved(true); onFinish(10, 3); }
      sfx.sparkle();
    } catch {
      sfx.error();
    }
  };

  if (!current) {
    return (
      <GameShell title="Fotografía Mágica" subtitle="Estudio de fotos" onClose={onClose} bg="bg-[#171225]">
        <p className="p-6 text-center font-bold text-white/70">Adopta un gatito para hacer fotos.</p>
      </GameShell>
    );
  }

  return (
    <GameShell title="Fotografía Mágica" subtitle="Crea recuerdos y compártelos" onClose={onClose} bg="bg-gradient-to-b from-[#241a38] to-[#120c22]">
      <div className="no-scrollbar flex flex-1 flex-col gap-3 overflow-y-auto p-4">
        <div
          ref={stageRef}
          className="relative mx-auto aspect-square w-full max-w-[330px] overflow-hidden rounded-[26px]"
          style={{ background: PHOTO_BGS[bg].css, border: FRAMES[frame].css }}
        >
          {stickers && (
            <>
              <Star className="absolute left-4 top-4 h-7 w-7 text-white/85" fill="currentColor" />
              <Heart className="absolute right-5 top-8 h-6 w-6 text-pink-500/90" fill="currentColor" />
              <Sparkles className="absolute bottom-6 left-5 h-6 w-6 text-white/85" />
              <Star className="absolute bottom-8 right-6 h-5 w-5 text-amber-300" fill="currentColor" />
            </>
          )}
          <div className="absolute inset-x-8 bottom-4 top-8">
            <Cat mood={pose} fur={current.fur} eyeColor={current.cat.eye} hat={hat} bow={bow} collar={collar} />
          </div>
          <p className="absolute inset-x-0 bottom-2 text-center font-display text-sm font-bold text-white drop-shadow">{current.name}</p>
        </div>

        <div>
          <p className="mb-1 font-display text-[13px] font-semibold text-white/70">Gatito</p>
          <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
            {cats.map((c, i) => (
              <button key={c.cat.id} onClick={() => setCatIdx(i)} className={`shrink-0 rounded-full px-3 py-2 text-xs font-extrabold ${i === catIdx ? "bg-[#f5c451] text-[#241a02]" : "bg-white/8 text-white/65"}`}>
                {c.name}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-1 font-display text-[13px] font-semibold text-white/70">Pose</p>
          <div className="grid grid-cols-3 gap-1.5">
            {([["normal", "Tranquilo"], ["happy", "Feliz"], ["sleep", "Dormido"]] as const).map(([p, label]) => (
              <button key={p} onClick={() => setPose(p)} className={`min-h-[44px] rounded-xl font-display text-[13px] font-semibold ${pose === p ? "bg-[#f5c451] text-[#241a02]" : "bg-white/8 text-white/65"}`}>{label}</button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="mb-1 font-display text-[13px] font-semibold text-white/70">Fondo</p>
            <div className="flex flex-wrap gap-1.5">
              {PHOTO_BGS.map((b, i) => (
                <button key={b.name} onClick={() => setBg(i)} aria-label={b.name} className={`h-10 w-10 rounded-xl border-2 ${bg === i ? "border-white" : "border-white/20"}`} style={{ background: b.css }} />
              ))}
            </div>
          </div>
          <div>
            <p className="mb-1 font-display text-[13px] font-semibold text-white/70">Marco y brillos</p>
            <div className="flex flex-wrap items-center gap-1.5">
              {FRAMES.map((f, i) => (
                <button key={f.name} onClick={() => setFrame(i)} aria-label={f.name} className={`h-10 w-10 rounded-xl border-2 ${frame === i ? "border-white" : "border-white/20"}`} style={{ border: f.css }} />
              ))}
              <button onClick={() => setStickers((s) => !s)} className={`flex h-10 items-center gap-1 rounded-xl px-2.5 text-xs font-extrabold ${stickers ? "bg-[#f5c451] text-[#241a02]" : "bg-white/8 text-white/60"}`}>
                <Sparkles className="h-4 w-4" /> Brillos
              </button>
            </div>
          </div>
        </div>

        <button onClick={savePhoto} className="flex min-h-[56px] items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-lg font-bold text-[#241a02] active:scale-[0.98]">
          <Camera className="h-5 w-5" /> {saved ? "Guardar otra foto" : "Guardar foto (+3 monedas)"}
        </button>
        <p className="flex items-center justify-center gap-3 pb-1 text-[11px] font-bold text-white/40">
          <span className="flex items-center gap-1"><Download className="h-3.5 w-3.5" /> Se descarga en tu teléfono</span>
          <span className="flex items-center gap-1"><Share2 className="h-3.5 w-3.5" /> Compartir si tu Android lo permite</span>
        </p>
        {record > 0 && <p className="flex items-center justify-center gap-1 text-center text-xs font-bold text-amber-300/80"><Trophy className="h-3.5 w-3.5" /> Fotos guardadas con recompensa</p>}
        <button onClick={onClose} className="flex items-center justify-center gap-1 pb-2 text-sm font-bold text-white/50"><X className="h-4 w-4" /> Salir del estudio</button>
      </div>
    </GameShell>
  );
}
