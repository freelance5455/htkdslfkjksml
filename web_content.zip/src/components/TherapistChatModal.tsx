import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Heart,
  AlertTriangle,
  PhoneCall,
  Sparkles,
  Bot,
  User,
  ArrowRight,
  Shield,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { ChatMessage, SpaceType } from '../types/index.ts';

interface TherapistChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  space: SpaceType;
  onOpenTool: (toolId: string) => void;
}

const CLIENT_CRISIS_KEYWORDS = [
  'suicide',
  'suicider',
  'me tuer',
  'mourir',
  'en finir',
  'fin à mes jours',
  'plus envie de vivre',
  'veux mourir',
  'faire du mal',
  'mutiler',
  'scarifier',
  'overdose',
  'frapper mon enfant',
  'secouer mon bébé',
  'secouer mon bebe',
  'maltraitance',
  'danger immediat',
  'danger immédiat',
];

export const TherapistChatModal: React.FC<TherapistChatModalProps> = ({
  isOpen,
  onClose,
  space,
  onOpenTool,
}) => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init',
      sender: 'assistant',
      content:
        space === 'parents'
          ? "Bonjour. Je suis votre accompagnateur virtuel humaniste. Être parent d'un enfant en détresse ou en colère est souvent bouleversant. Respirez profondément, déposez vos soucis ici : que traversez-vous avec votre enfant en ce moment ?"
          : "Bonjour et bienvenue. Je suis votre accompagnateur virtuel centré sur le cœur. Je suis là pour vous écouter avec bienveillance et vous aider à stabiliser votre système nerveux. Comment vous sentez-vous dans votre corps aujourd'hui ?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputValue, setInputValue] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showEmergencyBanner, setShowEmergencyBanner] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanText = inputValue.trim();
    if (!cleanText || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      content: cleanText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');

    // Check crisis keywords client-side
    const lower = cleanText.toLowerCase();
    const isCrisis = CLIENT_CRISIS_KEYWORDS.some((kw) => lower.includes(kw));

    if (isCrisis) {
      setShowEmergencyBanner(true);
      const crisisMsg: ChatMessage = {
        id: `sys_${Date.now()}`,
        sender: 'assistant',
        content:
          "Je ressens une très vive souffrance dans ce que vous partagez. Votre vie et votre sécurité sont précieuses. En tant qu'IA d'accompagnement, je ne peux pas me substituer à des soignants humains. S'il vous plaît, appelez le 3114 (gratuit, 24h/24 en France) ou les secours au 112 / 988. Vous méritez un soutien bienveillant et immédiat.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isEmergencyAlert: true,
        recommendedToolId: 'panic_protocol',
      };
      setMessages((prev) => [...prev, crisisMsg]);
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userMessage: cleanText,
          space,
          messages: messages.slice(-4),
        }),
      });

      const data = await res.json();

      if (data.isCrisis) {
        setShowEmergencyBanner(true);
      }

      const botMsg: ChatMessage = {
        id: `bot_${Date.now()}`,
        sender: 'assistant',
        content: data.reply || "Prenez une grande inspiration douce. Comment résonne ce que vous ressentez dans votre poitrine ?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isEmergencyAlert: data.isCrisis,
        recommendedToolId: data.recommendedTool,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch {
      // Local fallback
      const fallbackMsg: ChatMessage = {
        id: `fallback_${Date.now()}`,
        sender: 'assistant',
        content:
          "Je vous entends avec compassion. Rappelez-vous que chaque émotion est passagère, comme une vague. Prenez une respiration ventrale lente. Voulez-vous qu'on active un exercice d'ancrage corporel ?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in overflow-hidden">
      <div className="relative w-full max-w-2xl h-[90vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-100 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-rose-50/80 via-white to-teal-50/80 dark:from-slate-900 dark:to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-teal-500 text-white flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base sm:text-lg">
                  {t('chat.title')}
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
                  Humaniste
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Centré sur le cœur • Ne diagnostique pas • Soutien & Stabilisation
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Persistent Emergency Hotline Banner when crisis detected */}
        {showEmergencyBanner && (
          <div className="p-3.5 bg-rose-600 text-white text-xs font-semibold flex flex-wrap items-center justify-between gap-2 shadow-inner animate-pulse">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Détresse importante détectée : Ligne d'écoute d'urgence 24h/24 disponible</span>
            </div>
            <div className="flex items-center gap-2">
              <a
                href="tel:3114"
                className="px-3 py-1 rounded-full bg-white text-rose-700 font-bold hover:bg-rose-50 flex items-center gap-1 shadow-xs"
              >
                <PhoneCall className="w-3 h-3" />
                <span>3114 (France)</span>
              </a>
              <a
                href="tel:112"
                className="px-3 py-1 rounded-full bg-rose-800 text-white font-bold hover:bg-rose-900 flex items-center gap-1"
              >
                <span>112 (Europe)</span>
              </a>
            </div>
          </div>
        )}

        {/* Chat Message Flow */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 text-xs text-center">
            {t('chat.disclaimer')}
          </div>

          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-300 flex items-center justify-center shrink-0 mt-1 shadow-2xs">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-3xl p-4 text-sm leading-relaxed shadow-xs ${
                    isUser
                      ? 'bg-gradient-to-r from-rose-500 to-rose-600 text-white rounded-tr-xs'
                      : msg.isEmergencyAlert
                      ? 'bg-rose-50 dark:bg-rose-950/60 border-2 border-rose-400 text-rose-950 dark:text-rose-100 rounded-tl-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.content}</p>

                  {/* If emergency alert in message, show big call buttons */}
                  {msg.isEmergencyAlert && (
                    <div className="mt-3 pt-3 border-t border-rose-200 dark:border-rose-800 flex flex-wrap gap-2">
                      <a
                        href="tel:3114"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold shadow-xs hover:bg-rose-700"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>{t('chat.call3114')}</span>
                      </a>
                      <a
                        href="tel:112"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-700 text-white text-xs font-bold hover:bg-slate-800"
                      >
                        <span>{t('chat.call112')}</span>
                      </a>
                      <a
                        href="tel:988"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-700 text-white text-xs font-bold hover:bg-teal-800"
                      >
                        <span>{t('chat.call988')}</span>
                      </a>
                    </div>
                  )}

                  {/* Recommended tool launcher inside message */}
                  {msg.recommendedToolId && (
                    <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700 flex items-center justify-between">
                      <span className="text-xs font-semibold text-teal-700 dark:text-teal-300">
                        {t('chat.suggestedTools')}
                      </span>
                      <button
                        onClick={() => {
                          onOpenTool(msg.recommendedToolId!);
                        }}
                        className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-teal-600 text-white font-bold hover:bg-teal-700"
                      >
                        <span>{t('chat.launchTool')}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  <div
                    className={`text-[10px] mt-1 text-right ${
                      isUser ? 'text-rose-100' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center shrink-0 mt-1 shadow-2xs">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-950/50 text-rose-600 flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3 text-xs text-slate-500 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
                <span>Le thérapeute écoute et rédige avec bienveillance...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggested Regulation Tools Row */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
          <span className="font-semibold text-slate-400 shrink-0">Outils :</span>
          <button
            onClick={() => onOpenTool('grounding_54321')}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-400 text-slate-700 dark:text-slate-200 shrink-0 shadow-2xs"
          >
            👀 Grounding 5-4-3-2-1
          </button>
          <button
            onClick={() => onOpenTool('coherence_cardiaque')}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-rose-400 text-slate-700 dark:text-slate-200 shrink-0 shadow-2xs"
          >
            🫀 Cohérence Cardiaque
          </button>
          <button
            onClick={() => onOpenTool('butterfly_hug')}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-400 text-slate-700 dark:text-slate-200 shrink-0 shadow-2xs"
          >
            🫂 Étreinte du Papillon
          </button>
          <button
            onClick={() => onOpenTool('parent_child_crisis')}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-400 text-slate-700 dark:text-slate-200 shrink-0 shadow-2xs"
          >
            🧸 Enfant en crise
          </button>
          <button
            onClick={() => onOpenTool('parental_stress_reset')}
            className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-400 text-slate-700 dark:text-slate-200 shrink-0 shadow-2xs"
          >
            ☕ Reset Parent 90s
          </button>
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSendMessage}
          className="p-3 sm:p-4 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={t('chat.placeholder')}
            className="flex-1 px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className={`p-3 rounded-2xl bg-rose-500 text-white font-bold transition-all shadow-md ${
              !inputValue.trim() || isLoading
                ? 'opacity-40 cursor-not-allowed'
                : 'hover:bg-rose-600 hover:scale-105 active:scale-95'
            }`}
            title={t('chat.send')}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
