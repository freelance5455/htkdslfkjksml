import type { ReactNode } from "react";

export function PhoneShell({ children }: { children: ReactNode }) {
  return (
    <div className="phone-stage">
      <div className="phone-device">
        <div className="phone-notch" aria-hidden="true" />
        <div className="phone-screen">{children}</div>
        <div className="phone-home" aria-hidden="true" />
      </div>
    </div>
  );
}
