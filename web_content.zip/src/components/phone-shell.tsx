import { cn } from "@/lib/cn";
import { LisaMark } from "@/components/logo";
import type { AppTab } from "@/lib/types";
import { AudioLines, Clock3, Grid3x3, Settings2, Users } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

const TABS: { id: AppTab; label: string; icon: typeof Grid3x3 }[] = [
  { id: "keypad", label: "Keypad", icon: Grid3x3 },
  { id: "recents", label: "Recents", icon: Clock3 },
  { id: "contacts", label: "Contacts", icon: Users },
  { id: "ai", label: "AI Calls", icon: AudioLines },
  { id: "settings", label: "Settings", icon: Settings2 },
];

function StatusBar() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);
  const time = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  return (
    <div className="flex items-center justify-between px-6 pt-[max(0.6rem,env(safe-area-inset-top))] pb-1 text-xs text-muted-foreground">
      <span className="tabular-nums font-medium text-foreground/80">{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="inline-block h-2 w-4 rounded-[2px] border border-foreground/50">
          <span className="ml-[1px] mt-[1px] block h-1.5 w-2.5 rounded-[1px] bg-foreground/70" />
        </span>
      </div>
    </div>
  );
}

export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh justify-center bg-studio">
      <div className="relative flex min-h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-background lg:my-4 lg:min-h-[min(100dvh,900px)] lg:rounded-[2rem] lg:border lg:border-border lg:shadow-soft">
        {children}
      </div>
    </div>
  );
}

export function PhoneShell({
  tab,
  onTab,
  children,
  hideTabs,
}: {
  tab: AppTab;
  onTab: (t: AppTab) => void;
  children: ReactNode;
  hideTabs?: boolean;
}) {
  return (
    <>
      <StatusBar />
      <div className="flex-1 overflow-y-auto">{children}</div>
      {!hideTabs ? (
        <nav className="grid grid-cols-5 border-t border-border bg-background pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onTab(t.id)}
                className={cn(
                  "flex min-h-12 flex-col items-center justify-center gap-0.5 text-[0.65rem] tracking-wide",
                  active ? "text-accent" : "text-subtle",
                )}
              >
                <Icon className="size-[1.15rem]" strokeWidth={active ? 2.2 : 1.8} />
                {t.label}
              </button>
            );
          })}
        </nav>
      ) : null}
    </>
  );
}

export function ScreenHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-end justify-between px-5 pt-3 pb-4">
      <div>
        <div className="mb-2 flex items-center gap-2">
          <LisaMark className="size-7" />
          <span className="text-[0.7rem] font-medium tracking-[0.18em] text-muted-foreground uppercase">
            Lisa Call
          </span>
        </div>
        <h1 className="text-[1.75rem] leading-tight font-medium tracking-tight">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}
