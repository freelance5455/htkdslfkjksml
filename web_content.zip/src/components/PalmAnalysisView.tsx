import React, { useEffect, useState } from 'react';
import {
  Briefcase,
  Heart,
  Shield,
  Compass,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  X,
  Share2,
} from 'lucide-react';
import { PalmReadingResult } from '../types';

interface PalmAnalysisViewProps {
  isLoading: boolean;
  progressPercent: number;
  readingResult: PalmReadingResult | null;
  onClose: () => void;
  onRescan: () => void;
  onSpeakSummary?: (text: string) => void;
}

export const PalmAnalysisView: React.FC<PalmAnalysisViewProps> = ({
  isLoading,
  progressPercent,
  readingResult,
  onClose,
  onRescan,
  onSpeakSummary,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Auto trigger companion speech when result is ready
  useEffect(() => {
    if (readingResult?.summary && onSpeakSummary) {
      onSpeakSummary(readingResult.summary);
      setIsPlayingAudio(true);
    }
  }, [readingResult, onSpeakSummary]);

  // Loading Screen (Screen 3 from Screenshot)
  if (isLoading) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-between py-12 px-6 bg-[#070913] text-white select-none animate-fade-in">
        {/* Top Header */}
        <div className="w-full flex items-center justify-between">
          <h2 className="text-xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
            AI.P 💜
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full glass-panel text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center: Glowing Rotating Chakra Mandala */}
        <div className="relative flex flex-col items-center my-auto">
          <div className="relative w-56 h-56 flex items-center justify-center">
            {/* Outer pulsating aura */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-600/50 via-pink-600/40 to-cyan-500/50 blur-2xl animate-pulse" />

            {/* Rotating Astrology Chakra Rings */}
            <div className="absolute inset-1 rounded-full border border-purple-400/40 border-dashed animate-spin-slow" />
            <div className="absolute inset-4 rounded-full border border-cyan-400/40 border-dotted animate-spin-reverse-slow" />

            {/* Inner Sacred Chakra Orb */}
            <div className="relative w-36 h-36 rounded-full bg-gradient-to-tr from-purple-950 via-[#11162e] to-cyan-950 border-2 border-purple-400/60 shadow-[0_0_25px_rgba(168,85,247,0.5)] flex items-center justify-center">
              <span className="text-3xl font-bold bg-gradient-to-r from-cyan-200 via-white to-pink-300 bg-clip-text text-transparent animate-pulse">
                ॐ
              </span>
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mt-6 tracking-wide">
            Analyzing your palm...
          </h3>

          {/* Progress Bar & Percentage (Screen 3: 68%) */}
          <div className="w-64 mt-4">
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden p-[1px]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 transition-all duration-300 shadow-[0_0_12px_rgba(168,85,247,0.8)]"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="text-center text-xs font-semibold text-purple-300 mt-2">
              {progressPercent}%
            </div>
          </div>

          {/* Waveform graphic */}
          <div className="flex items-center justify-center space-x-1.5 mt-6 h-6">
            {[0.4, 0.8, 1, 0.6, 0.9, 0.3, 0.7, 0.5, 0.85].map((h, i) => (
              <span
                key={i}
                className="w-1 bg-gradient-to-t from-purple-400 to-cyan-400 rounded-full animate-pulse"
                style={{
                  height: `${h * 24}px`,
                  animationDelay: `${i * 0.15}s`,
                }}
              />
            ))}
          </div>

          <p className="text-xs text-slate-400 mt-3 font-medium tracking-wide">
            Reading the lines of your life...
          </p>
        </div>

        <div className="text-[11px] text-slate-500 text-center">
          Traditional Indian Palmistry • For entertainment & positive inspiration
        </div>
      </div>
    );
  }

  // Result Screen (Screen 4 from Screenshot)
  if (!readingResult) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#070913] text-white select-none overflow-y-auto pb-10 animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4 bg-[#070913]/90 backdrop-blur-md border-b border-white/5">
        <h2 className="text-xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
          AI.P 💜
        </h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={onRescan}
            className="p-2 rounded-full glass-panel text-purple-300 hover:text-white"
            title="Scan Again"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-full glass-panel text-slate-400 hover:text-white"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-md w-full mx-auto px-5 pt-3">
        {/* Companion Speech Card (Top of Screen 4) */}
        <div className="flex items-center space-x-3 mb-5">
          <div className="relative w-12 h-12 rounded-full bg-gradient-to-tr from-purple-900 to-cyan-900 border border-purple-400 shrink-0 shadow-lg flex items-center justify-center">
            <span className="text-lg font-bold text-cyan-200">ॐ</span>
          </div>
          <div className="relative flex-1 p-3 rounded-2xl glass-panel border border-purple-500/30 text-xs text-purple-100">
            <p className="leading-relaxed">
              "Hmm... interesting lines! Let me tell you what I see..."
            </p>
          </div>
        </div>

        {/* Captured Palm Thumbnail if available */}
        {readingResult.capturedImageUrl && (
          <div className="mb-4 rounded-2xl overflow-hidden border border-purple-500/30 h-32 relative group">
            <img
              src={readingResult.capturedImageUrl}
              alt="Captured Palm"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2.5">
              <span className="text-[10px] font-semibold text-purple-300 tracking-wider">
                CAPTURED PALM SCAN
              </span>
            </div>
          </div>
        )}

        {/* Section Header: Your Palm Reading */}
        <div className="flex items-center space-x-2 mb-3">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h3 className="text-base font-bold text-white tracking-wide">
            Your Palm Reading
          </h3>
        </div>

        {/* 4 Cards (Career, Love Life, Health, Future) */}
        <div className="space-y-3">
          {/* 1. Career */}
          <div className="p-4 rounded-2xl glass-panel border border-cyan-500/20 hover:border-cyan-500/40 transition">
            <div className="flex items-center space-x-3 mb-1.5">
              <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300">
                <Briefcase className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-white">Career</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed pl-11">
              {readingResult.career}
            </p>
          </div>

          {/* 2. Love Life */}
          <div className="p-4 rounded-2xl glass-panel border border-pink-500/20 hover:border-pink-500/40 transition">
            <div className="flex items-center space-x-3 mb-1.5">
              <div className="p-2 rounded-xl bg-pink-500/20 text-pink-300">
                <Heart className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-white">Love Life</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed pl-11">
              {readingResult.loveLife}
            </p>
          </div>

          {/* 3. Health */}
          <div className="p-4 rounded-2xl glass-panel border border-blue-500/20 hover:border-blue-500/40 transition">
            <div className="flex items-center space-x-3 mb-1.5">
              <div className="p-2 rounded-xl bg-blue-500/20 text-blue-300">
                <Shield className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-white">Health</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed pl-11">
              {readingResult.health}
            </p>
          </div>

          {/* 4. Future */}
          <div className="p-4 rounded-2xl glass-panel border border-purple-500/20 hover:border-purple-500/40 transition">
            <div className="flex items-center space-x-3 mb-1.5">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300">
                <Compass className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-white">Future</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed pl-11">
              {readingResult.future}
            </p>
          </div>
        </div>

        {/* Audio Speaking Wave Status (Bottom of Screen 4) */}
        <div className="mt-6 flex flex-col items-center justify-center p-4 rounded-2xl bg-black/40 border border-purple-500/20">
          <div className="flex items-center space-x-1.5 h-6">
            {[0.3, 0.7, 1, 0.8, 0.4, 0.9, 0.6, 0.3].map((h, i) => (
              <span
                key={i}
                className="w-1 bg-gradient-to-t from-pink-400 to-purple-400 rounded-full animate-wave-bounce"
                style={{
                  height: `${h * 20}px`,
                  animationDuration: `${0.8 + i * 0.1}s`,
                }}
              />
            ))}
          </div>
          <span className="text-xs text-purple-300 font-medium mt-2 flex items-center space-x-1.5">
            <Volume2 className="w-3.5 h-3.5" />
            <span>Speaking your reading...</span>
          </span>
        </div>

        {/* Bottom Actions */}
        <div className="mt-5 flex space-x-3">
          <button
            onClick={onRescan}
            className="flex-1 py-3 px-4 rounded-2xl glass-panel text-purple-300 hover:text-white font-medium text-xs flex items-center justify-center space-x-2 transition active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Scan Another Hand</span>
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-purple-500/25 active:scale-95"
          >
            <span>Done</span>
          </button>
        </div>
      </div>
    </div>
  );
};
