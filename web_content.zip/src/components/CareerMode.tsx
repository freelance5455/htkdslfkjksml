import React, { useState } from 'react';
import { Play, FastForward, RotateCcw, TrendingUp } from 'lucide-react';
import { TRANSLATIONS } from '../i18n/translations';
import { CareerState, Club, Language } from '../types/game';
import { ClubCrest } from './ClubCrest';

interface CareerModeProps {
  clubs: Club[];
  career: CareerState | null;
  language: Language;
  onStartNewCareer: (clubId: string, league: 'brasileirao' | 'europe') => void;
  onResetCareer: () => void;
  onPlayMatch: (fixtureId: string, homeId: string, awayId: string) => void;
  onSimulateRound: () => void;
  onBoostPlayer: (playerId: string) => void;
}

export const CareerMode: React.FC<CareerModeProps> = ({
  clubs,
  career,
  language,
  onStartNewCareer,
  onResetCareer,
  onPlayMatch,
  onSimulateRound,
  onBoostPlayer,
}) => {
  const t = TRANSLATIONS[language];
  const [selectedLeague, setSelectedLeague] = useState<'brasileirao' | 'europe'>('brasileirao');
  const [selectedClubId, setSelectedClubId] = useState<string>('atletico_carioca');
  const [tab, setTab] = useState<'standings' | 'fixtures' | 'training'>('standings');

  const leagueClubs = clubs.filter((c) => c.league === selectedLeague);

  if (!career) {
    return (
      <div className="relative z-10 h-full overflow-y-auto px-4 sm:px-8 py-6 max-w-5xl mx-auto">
        <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xl">
          <h2 className="font-display font-extrabold text-3xl text-slate-900 dark:text-white">
            {t.careerLeagueSelect}
          </h2>

          <div className="mt-4 flex gap-2">
            <button
              onClick={() => {
                setSelectedLeague('brasileirao');
                const first = clubs.find((c) => c.league === 'brasileirao');
                if (first) setSelectedClubId(first.id);
              }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold ${
                selectedLeague === 'brasileirao'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {t.brasileirao}
            </button>
            <button
              onClick={() => {
                setSelectedLeague('europe');
                const first = clubs.find((c) => c.league === 'europe');
                if (first) setSelectedClubId(first.id);
              }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold ${
                selectedLeague === 'europe'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {t.europe}
            </button>
          </div>

          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {leagueClubs.map((club) => (
              <button
                key={club.id}
                onClick={() => setSelectedClubId(club.id)}
                className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-colors ${
                  selectedClubId === club.id
                    ? 'border-amber-400 bg-amber-400/10'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70'
                }`}
              >
                <ClubCrest club={club} size={38} />
                <div className="min-w-0">
                  <div className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                    {club.name}
                  </div>
                  <div className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                    OVR {club.ovr}
                  </div>
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={() => onStartNewCareer(selectedClubId, selectedLeague)}
            className="mt-6 px-6 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-xl tracking-wide uppercase"
          >
            {t.startCareer}
          </button>
        </div>
      </div>
    );
  }

  const myClub = clubs.find((c) => c.id === career.clubId) || clubs[0];
  const sortedStandings = [...career.standings].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    const gdA = a.gf - a.ga;
    const gdB = b.gf - b.ga;
    if (gdB !== gdA) return gdB - gdA;
    return b.gf - a.gf;
  });

  const roundFixtures = career.fixtures.filter((f) => f.round === career.currentRound);
  const myNextFixture = roundFixtures.find(
    (f) => !f.played && (f.homeClubId === career.clubId || f.awayClubId === career.clubId)
  );
  const nextHome = myNextFixture ? clubs.find((c) => c.id === myNextFixture.homeClubId) : null;
  const nextAway = myNextFixture ? clubs.find((c) => c.id === myNextFixture.awayClubId) : null;

  return (
    <div className="relative z-10 h-full overflow-y-auto px-4 sm:px-8 py-5 max-w-6xl mx-auto">
      {/* Career Header Card */}
      <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <ClubCrest club={myClub} size={50} />
          <div>
            <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">
              {career.league === 'brasileirao' ? t.brasileirao : t.europe} · {t.roundLabel} {career.currentRound}
            </div>
            <div className="font-display font-extrabold text-2xl text-slate-900 dark:text-white">
              {myClub.name}
            </div>
            <div className="font-mono-num text-xs text-slate-600 dark:text-slate-300">
              {t.devPoints}: {career.trainingPoints}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {myNextFixture && nextHome && nextAway && (
            <button
              onClick={() => onPlayMatch(myNextFixture.id, nextHome.id, nextAway.id)}
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>
                {t.playNextRound} ({nextHome.abbr} vs {nextAway.abbr})
              </span>
            </button>
          )}
          <button
            onClick={onSimulateRound}
            className="px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-semibold text-xs flex items-center gap-1.5"
          >
            <FastForward className="w-4 h-4 text-sky-500" />
            <span>{t.simRound}</span>
          </button>
          <button
            onClick={onResetCareer}
            className="px-3 py-2.5 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-semibold text-xs flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetCareer}</span>
          </button>
        </div>
      </div>

      {/* Sub-navigation tabs */}
      <div className="mt-4 flex gap-1.5 p-1 bg-white/90 dark:bg-[#0B1120]/90 border border-slate-200 dark:border-slate-800 rounded-xl w-fit">
        {(
          [
            ['standings', t.standings],
            ['fixtures', t.fixtures],
            ['training', t.training],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              tab === k
                ? 'bg-amber-400 text-slate-950'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="mt-4 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl">
        {tab === 'standings' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <th className="py-2 pr-3">#</th>
                  <th className="py-2 pr-4">Clube</th>
                  <th className="py-2 px-2 text-right">J</th>
                  <th className="py-2 px-2 text-right">V</th>
                  <th className="py-2 px-2 text-right">E</th>
                  <th className="py-2 px-2 text-right">D</th>
                  <th className="py-2 px-2 text-right">SG</th>
                  <th className="py-2 pl-2 text-right">PTS</th>
                </tr>
              </thead>
              <tbody>
                {sortedStandings.map((row, idx) => {
                  const club = clubs.find((c) => c.id === row.clubId);
                  if (!club) return null;
                  const isMine = club.id === career.clubId;
                  return (
                    <tr
                      key={row.clubId}
                      className={`border-b border-slate-100 dark:border-slate-800/60 ${
                        isMine ? 'bg-amber-400/12 font-semibold' : ''
                      }`}
                    >
                      <td className="py-2.5 pr-3 font-mono-num text-xs text-slate-500">{idx + 1}</td>
                      <td className="py-2.5 pr-4">
                        <div className="flex items-center gap-2.5">
                          <ClubCrest club={club} size={24} />
                          <span className="text-slate-900 dark:text-white">{club.name}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono-num">{row.played}</td>
                      <td className="py-2.5 px-2 text-right font-mono-num">{row.won}</td>
                      <td className="py-2.5 px-2 text-right font-mono-num">{row.drawn}</td>
                      <td className="py-2.5 px-2 text-right font-mono-num">{row.lost}</td>
                      <td className="py-2.5 px-2 text-right font-mono-num">{row.gf - row.ga}</td>
                      <td className="py-2.5 pl-2 text-right font-mono-num font-bold text-amber-600 dark:text-amber-400">
                        {row.points}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'fixtures' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {roundFixtures.map((fix) => {
              const hc = clubs.find((c) => c.id === fix.homeClubId);
              const ac = clubs.find((c) => c.id === fix.awayClubId);
              if (!hc || !ac) return null;
              return (
                <div
                  key={fix.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
                >
                  <div className="flex items-center gap-2">
                    <ClubCrest club={hc} size={28} />
                    <span className="text-sm font-semibold text-slate-900 dark:text-white">{hc.abbr}</span>
                  </div>
                  <div className="font-mono-num font-bold text-sm text-amber-600 dark:text-amber-400">
                    {fix.played ? `${fix.homeScore} - ${fix.awayScore}` : 'VS'}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-900 dark:text-white">{ac.abbr}</span>
                    <ClubCrest club={ac} size={28} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'training' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {myClub.players.map((pl) => (
              <div
                key={pl.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
              >
                <div>
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">{pl.name}</div>
                  <div className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                    {pl.position} · #{pl.number} · OVR {pl.ovr}
                  </div>
                </div>
                <button
                  disabled={career.trainingPoints < 1 || pl.ovr >= 99}
                  onClick={() => onBoostPlayer(pl.id)}
                  className="px-3 py-1.5 rounded-lg bg-amber-400 disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center gap-1"
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{t.boostOvr}</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
