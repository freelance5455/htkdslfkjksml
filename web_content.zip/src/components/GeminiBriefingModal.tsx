import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  Volume2, 
  Play, 
  Pause, 
  RotateCcw, 
  TrendingUp, 
  TrendingDown, 
  Gauge, 
  Loader2,
  CheckCircle,
  Radio
} from 'lucide-react';
import { GeminiMarketBriefing, AudioSettings } from '../types/market';
import { fetchGeminiBriefing } from '../services/marketApi';
import { executeVoiceAlert } from '../services/audioEngine';

interface GeminiBriefingModalProps {
  isOpen: boolean;
  onClose: () => void;
  audioSettings: AudioSettings;
  language: 'fr' | 'en';
}

export const GeminiBriefingModal: React.FC<GeminiBriefingModalProps> = ({
  isOpen,
  onClose,
  audioSettings,
  language,
}) => {
  const [briefing, setBriefing] = useState<GeminiMarketBriefing | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  const loadBriefing = async () => {
    setIsLoading(true);
    try {
      const data = await fetchGeminiBriefing(language);
      setBriefing(data);
    } catch (e) {
      console.warn('Failed to fetch Gemini briefing', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    loadBriefing();
  }, [isOpen, language]);

  if (!isOpen) return null;

  const handlePlaySpokenBriefing = async () => {
    if (!briefing) return;
    setIsPlayingAudio(true);
    await executeVoiceAlert('sonar', briefing.spokenScript, audioSettings, language);
    setIsPlayingAudio(false);
  };

  const handleStopAudio = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-slate-950 border border-purple-500/30 rounded-3xl shadow-2xl shadow-purple-500/10 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-purple-500/20 bg-gradient-to-r from-purple-950/40 via-slate-900 to-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Sparkles className="w-6 h-6 text-purple-400 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg text-white font-['Chakra_Petch']">
                  BRIEFING AUDIO MARCHÉ PAR GEMINI IA
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-200 border border-purple-500/40">
                  gemini-3.8-flash
                </span>
              </div>
              <p className="text-xs text-purple-200/70">
                Synthèse macroéconomique, flux de capitaux et alertes tactiques
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {isLoading ? (
            <div className="py-16 text-center space-y-4">
              <Loader2 className="w-10 h-10 animate-spin text-purple-400 mx-auto" />
              <div className="font-mono text-sm text-purple-200 font-semibold">
                Gemini compile les flux réels d'actifs et génère le broadcast audio...
              </div>
            </div>
          ) : briefing ? (
            <>
              {/* Top Headline Banner */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 flex items-start justify-between gap-3 shadow-inner">
                <div>
                  <span className="text-[10px] font-mono uppercase text-purple-300 font-bold tracking-wider block mb-1">
                    FLASH INFOS MARCHÉ EN TEMPS RÉEL
                  </span>
                  <h4 className="text-lg font-bold text-white leading-snug">
                    {briefing.headline}
                  </h4>
                </div>

                <button
                  onClick={loadBriefing}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Rafraîchir le briefing"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Gauges & Sentiment Indicators */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">ORIENTATION MARCHÉ</span>
                    <span className={`text-base font-bold font-['Chakra_Petch'] ${
                      briefing.sentiment === 'Bullish'
                        ? 'text-emerald-400'
                        : briefing.sentiment === 'Bearish'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}>
                      {briefing.sentiment}
                    </span>
                  </div>
                  {briefing.sentiment === 'Bullish' ? (
                    <TrendingUp className="w-6 h-6 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-6 h-6 text-rose-400" />
                  )}
                </div>

                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">INDICE PEUR & CUPIDITÉ</span>
                    <span className="text-base font-bold font-mono text-amber-400">
                      {briefing.fearGreedIndex} / 100
                    </span>
                  </div>
                  <Gauge className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              {/* Audio Broadcast Player */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-indigo-950/40 to-slate-900 border border-purple-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Radio className={`w-4 h-4 ${isPlayingAudio ? 'text-emerald-400 animate-pulse' : 'text-purple-400'}`} />
                    <span className="font-mono text-xs font-bold text-white uppercase">
                      LECTEUR BROADCAST VOCAL (45 SECONDES)
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-purple-300">
                    {audioSettings.selectedPersona} &bull; {audioSettings.rate}x débit
                  </span>
                </div>

                {/* Animated Sound Wave Graphic */}
                <div className="h-10 flex items-center justify-center gap-1 bg-slate-950/80 rounded-xl px-4 border border-purple-500/20 overflow-hidden">
                  {Array.from({ length: 32 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-1 rounded-full transition-all duration-150 ${
                        isPlayingAudio
                          ? 'bg-gradient-to-t from-purple-500 to-amber-400'
                          : 'bg-slate-700'
                      }`}
                      style={{
                        height: isPlayingAudio
                          ? `${Math.max(15, Math.sin((i + Date.now() / 200) * 0.8) * 85)}%`
                          : `${((i % 4) + 1) * 20}%`,
                      }}
                    />
                  ))}
                </div>

                {/* Player Controls */}
                <div className="flex items-center justify-between pt-1">
                  <div className="text-xs text-slate-400 font-mono">
                    {isPlayingAudio ? 'Diffusion vocale en cours...' : 'Prêt pour l\'écoute'}
                  </div>

                  <div className="flex items-center gap-2">
                    {isPlayingAudio ? (
                      <button
                        onClick={handleStopAudio}
                        className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-rose-500/20"
                      >
                        <Pause className="w-3.5 h-3.5 fill-white" />
                        <span>Arrêter</span>
                      </button>
                    ) : (
                      <button
                        onClick={handlePlaySpokenBriefing}
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/20"
                      >
                        <Play className="w-3.5 h-3.5 fill-slate-950" />
                        <span>Écouter le Briefing Audio</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Spoken Script Transcript */}
              <div className="space-y-1.5">
                <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">
                  TRANSCRIPTION DU MESSAGE VOCAL :
                </span>
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs sm:text-sm text-slate-300 font-mono leading-relaxed italic">
                  "{briefing.spokenScript}"
                </div>
              </div>

              {/* Tactical Advice Box */}
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-2.5 text-xs text-emerald-300">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold block mb-0.5">Conseil Tactique d'Alerte :</strong>
                  <span>{briefing.keyAdvice}</span>
                </div>
              </div>
            </>
          ) : (
            <div className="py-8 text-center text-slate-400">
              Impossible de charger le briefing. Veuillez réessayer.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
