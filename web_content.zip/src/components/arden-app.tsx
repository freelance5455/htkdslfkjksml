import { useEffect, useRef, useState, type ReactNode } from "react";
import { Bell, Download, MapPin, Mic, Send, Square } from "lucide-react";
import { askArden, speakArden, transcribeArden } from "@/lib/arden.functions";
import { localPlan, weatherLabel, type Action, type PhoneSnapshot, type Plan } from "@/lib/arden";

type Gate = "unknown" | "on" | "blocked";
type Phase = "ready" | "listening" | "transcribing" | "thinking" | "speaking";
type Bubble = {
  id: string;
  role: "user" | "assistant";
  text: string;
  thought?: string;
  links?: { href: string; label: string }[];
  note?: string;
};

type Rec = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((ev: { results: SpeechResultList }) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
};

type SpeechResultList = ArrayLike<ArrayLike<{ transcript: string }> & { isFinal?: boolean }>;

type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<unknown> };

const NOTES_KEY = "arden-notes";
const SILENCE = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";

function deviceLabel() {
  const ua = navigator.userAgent;
  if (/iPhone|iPad|iPod/.test(ua)) return "iPhone";
  if (/Android/.test(ua)) return "Android";
  return "This browser";
}

function clock() {
  return new Intl.DateTimeFormat(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date());
}

async function batteryLine() {
  const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }> };
  if (!nav.getBattery) return undefined;
  try {
    const battery = await nav.getBattery();
    return `${Math.round(battery.level * 100)}%${battery.charging ? ", charging" : ""}`;
  } catch {
    return undefined;
  }
}

function recognizer() {
  const w = window as Window & {
    SpeechRecognition?: new () => Rec;
    webkitSpeechRecognition?: new () => Rec;
  };
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
  return Ctor ? new Ctor() : null;
}

function toBase64(bytes: Uint8Array) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}

export function ArdenApp() {
  const [phase, setPhase] = useState<Phase>("ready");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<Bubble[]>([]);
  const [notes, setNotes] = useState<string[]>([]);
  const [mic, setMic] = useState<Gate>("unknown");
  const [placeGate, setPlaceGate] = useState<Gate>("unknown");
  const [alerts, setAlerts] = useState<Gate>("unknown");
  const [battery, setBattery] = useState<string>();
  const [place, setPlace] = useState<string>();
  const [installed, setInstalled] = useState(false);
  const [installEvent, setInstallEvent] = useState<InstallEvent | null>(null);
  const [ios, setIos] = useState(false);
  const notesRef = useRef<string[]>([]);
  const draftRef = useRef("");
  const phaseRef = useRef<Phase>("ready");
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recRef = useRef<Rec | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const timers = useRef<number[]>([]);
  const locRef = useRef<{ lat: number; lon: number; place?: string; weather?: string; at: number } | null>(null);
  const scroller = useRef<HTMLDivElement | null>(null);
  const messagesRef = useRef<Bubble[]>([]);

  useEffect(() => {
    draftRef.current = draft;
  }, [draft]);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    messagesRef.current = messages;
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
  }, [messages]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]") as unknown;
      if (Array.isArray(saved)) {
        const next = saved.map((item) => String(item)).slice(-20);
        notesRef.current = next;
        setNotes(next);
      }
    } catch {
      /* ignore broken local notes */
    }
    const apple = (navigator as Navigator & { standalone?: boolean }).standalone;
    setInstalled(window.matchMedia("(display-mode: standalone)").matches || Boolean(apple));
    setIos(/iPhone|iPad|iPod/.test(navigator.userAgent));
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as InstallEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    void batteryLine().then(setBattery);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      timers.current.forEach((id) => window.clearTimeout(id));
      audioRef.current?.pause();
      window.speechSynthesis?.cancel();
    };
  }, []);

  function unlockAudio() {
    const audio = audioRef.current ?? new Audio();
    audioRef.current = audio;
    if (audio.dataset.armed === "1") return;
    audio.src = SILENCE;
    void audio.play().then(() => audio.pause()).catch(() => undefined);
    audio.dataset.armed = "1";
  }

  function stopAudio() {
    audioRef.current?.pause();
    window.speechSynthesis?.cancel();
  }

  async function speak(text: string) {
    stopAudio();
    setPhase("speaking");
    try {
      const result = await speakArden({ data: { text } });
      if (result.ok && audioRef.current) {
        const bytes = Uint8Array.from(atob(result.audio), (char) => char.charCodeAt(0));
        const url = URL.createObjectURL(new Blob([bytes], { type: result.mime }));
        const audio = audioRef.current;
        audio.src = url;
        await audio.play();
        await new Promise<void>((resolve) => {
          audio.onended = () => resolve();
          audio.onerror = () => resolve();
        });
        URL.revokeObjectURL(url);
        return;
      }
    } catch {
      /* fall through to the browser voice */
    }
    await new Promise<void>((resolve) => {
      if (!window.speechSynthesis) {
        resolve();
        return;
      }
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 1;
      utter.onend = () => resolve();
      utter.onerror = () => resolve();
      window.speechSynthesis.speak(utter);
    });
  }

  function remember(next: string[]) {
    const trimmed = next.slice(-20);
    notesRef.current = trimmed;
    setNotes(trimmed);
    localStorage.setItem(NOTES_KEY, JSON.stringify(trimmed));
  }

  function apply(actions: Action[]) {
    let nextNotes = notesRef.current;
    const links: { href: string; label: string }[] = [];
    const extra: string[] = [];
    for (const action of actions) {
      if (action.type === "note") nextNotes = [...nextNotes, action.text];
      if (action.type === "forget") {
        const query = action.text.toLowerCase();
        nextNotes = nextNotes.filter((note) => !note.toLowerCase().includes(query));
      }
      if (action.type === "timer") {
        const id = window.setTimeout(() => {
          if (Notification.permission === "granted") new Notification("Arden", { body: action.label });
          void speak(`${action.label} is done.`);
        }, action.seconds * 1000);
        timers.current.push(id);
      }
      if (action.type === "open") {
        links.push({ href: action.url, label: new URL(action.url).hostname });
        window.open(action.url, "_blank", "noopener,noreferrer");
      }
      if (action.type === "copy") void navigator.clipboard?.writeText(action.text).catch(() => undefined);
      if (action.type === "notify") {
        if (Notification.permission === "granted") new Notification(action.title, { body: action.body });
        else extra.push("Alerts are off, so that notice stayed here.");
      }
      if (action.type === "vibrate") navigator.vibrate?.(40);
      if (action.type === "share") {
        if (navigator.share) void navigator.share({ text: action.text }).catch(() => undefined);
        else void navigator.clipboard?.writeText(action.text).catch(() => undefined);
      }
    }
    remember(nextNotes);
    return { links, note: extra.join(" ") };
  }

  async function refreshPlace() {
    if (!navigator.geolocation) return locRef.current;
    if (placeGate !== "on" && !locRef.current) return locRef.current;
    const cached = locRef.current;
    if (cached && Date.now() - cached.at < 120_000) return cached;
    const position = await new Promise<GeolocationPosition | null>((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve(pos),
        () => resolve(null),
        { enableHighAccuracy: false, timeout: 4000, maximumAge: 120_000 },
      );
    });
    if (!position) return cached;
    const lat = Number(position.coords.latitude.toFixed(3));
    const lon = Number(position.coords.longitude.toFixed(3));
    const next = { lat, lon, place: cached?.place, weather: cached?.weather, at: Date.now() };
    try {
      const geo = await fetch(`https://geocoding-api.open-meteo.com/v1/reverse?latitude=${lat}&longitude=${lon}&language=en`);
      if (geo.ok) {
        const body = (await geo.json()) as { results?: { name?: string; admin1?: string }[] };
        const hit = body.results?.[0];
        if (hit?.name) next.place = hit.admin1 ? `${hit.name}, ${hit.admin1}` : hit.name;
      }
      const sky = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code,wind_speed_10m`,
      );
      if (sky.ok) {
        const body = (await sky.json()) as {
          current?: { temperature_2m?: number; weather_code?: number; wind_speed_10m?: number };
        };
        const current = body.current;
        if (current?.temperature_2m != null && current.weather_code != null) {
          next.weather = `${Math.round(current.temperature_2m)} degrees, ${weatherLabel(current.weather_code)}, wind ${Math.round(current.wind_speed_10m ?? 0)} kilometers an hour`;
        }
      }
    } catch {
      /* location still usable without a place name */
    }
    locRef.current = next;
    if (next.place) setPlace(next.place);
    return next;
  }

  async function snapshot(): Promise<PhoneSnapshot> {
    const located = await refreshPlace();
    const power = (await batteryLine()) ?? battery;
    if (power) setBattery(power);
    return {
      now: clock(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "unknown",
      platform: deviceLabel(),
      online: navigator.onLine,
      battery: power,
      place: located?.place,
      location: located ? `${located.lat}, ${located.lon}` : undefined,
      weather: located?.weather,
      notes: notesRef.current,
    };
  }

  async function runCommand(command: string) {
    const text = command.trim();
    if (!text || phaseRef.current === "thinking") return;
    setDraft("");
    const history = messagesRef.current.slice(-6).map((item) => ({ role: item.role, content: item.text }));
    const userBubble: Bubble = { id: crypto.randomUUID(), role: "user", text };
    setMessages((curr) => [...curr, userBubble].slice(-30));
    setPhase("thinking");
    phaseRef.current = "thinking";
    try {
      const phone = await snapshot();
      let plan: Plan | null = null;
      try {
        const result = await askArden({ data: { command: text, history, phone } });
        plan = result.ok ? result.plan : localPlan(text, phone);
        if (!plan) {
          setMessages((curr) => [
            ...curr,
            { id: crypto.randomUUID(), role: "assistant", text: result.ok ? "Done." : result.error },
          ]);
          setPhase("ready");
          return;
        }
      } catch {
        plan = localPlan(text, phone);
        if (!plan) {
          setMessages((curr) => [
            ...curr,
            { id: crypto.randomUUID(), role: "assistant", text: "I couldn't reach my reasoning just then. Try again." },
          ]);
          setPhase("ready");
          return;
        }
      }
      const side = apply(plan.actions);
      const reply: Bubble = {
        id: crypto.randomUUID(),
        role: "assistant",
        text: plan.say,
        thought: plan.thought,
        links: side.links,
        note: side.note || undefined,
      };
      setMessages((curr) => [...curr, reply].slice(-30));
      await speak(plan.say);
    } finally {
      setPhase("ready");
    }
  }

  function stopRecorder() {
    const media = mediaRef.current;
    if (media && media.state === "recording") media.stop();
    recRef.current?.stop();
  }

  async function startListen() {
    unlockAudio();
    setPhase("listening");
    phaseRef.current = "listening";
    const native = recognizer();
    if (native) {
      native.lang = navigator.language || "en-US";
      native.interimResults = true;
      native.continuous = false;
      native.onresult = (event) => {
        let heard = "";
        for (let i = 0; i < event.results.length; i += 1) {
          heard += event.results[i]?.[0]?.transcript ?? "";
        }
        setDraft(heard);
      };
      native.onerror = (event) => {
        if (event.error === "not-allowed") setMic("blocked");
        setPhase("ready");
      };
      native.onend = () => {
        recRef.current = null;
        if (phaseRef.current !== "listening") return;
        const heard = draftRef.current.trim();
        if (heard) void runCommand(heard);
        else setPhase("ready");
      };
      recRef.current = native;
      try {
        native.start();
        setMic("on");
      } catch {
        setPhase("ready");
      }
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setMic("on");
      const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
      const recorder = new MediaRecorder(stream, { mimeType: mime });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size) chunks.push(event.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(chunks, { type: recorder.mimeType || mime });
        void transcribe(blob);
      };
      mediaRef.current = recorder;
      recorder.start();
      window.setTimeout(() => {
        if (recorder.state === "recording") recorder.stop();
      }, 12000);
    } catch {
      setMic("blocked");
      setPhase("ready");
    }
  }

  async function transcribe(blob: Blob) {
    setPhase("transcribing");
    phaseRef.current = "transcribing";
    try {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const result = await transcribeArden({ data: { audio: toBase64(bytes), mime: blob.type || "audio/webm" } });
      if (!result.ok) {
        setMessages((curr) => [...curr, { id: crypto.randomUUID(), role: "assistant", text: result.error }]);
        setPhase("ready");
        return;
      }
      await runCommand(result.text);
    } catch {
      setMessages((curr) => [
        ...curr,
        { id: crypto.randomUUID(), role: "assistant", text: "I couldn't hear that. Type the command instead." },
      ]);
      setPhase("ready");
    }
  }

  function onOrb() {
    if (phase === "speaking") {
      stopAudio();
      setPhase("ready");
      return;
    }
    if (phase === "listening") {
      stopRecorder();
      return;
    }
    if (phase === "thinking" || phase === "transcribing") return;
    void startListen();
  }

  async function linkPhone() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      setMic("on");
    } catch {
      setMic("blocked");
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          setPlaceGate("on");
          locRef.current = {
            lat: Number(pos.coords.latitude.toFixed(3)),
            lon: Number(pos.coords.longitude.toFixed(3)),
            at: 0,
          };
          const located = await refreshPlace();
          if (located?.place) setPlace(located.place);
        },
        () => setPlaceGate("blocked"),
        { enableHighAccuracy: false, timeout: 8000 },
      );
    }
    if ("Notification" in window) {
      const permission = await Notification.requestPermission();
      setAlerts(permission === "granted" ? "on" : "blocked");
    }
    const power = await batteryLine();
    if (power) setBattery(power);
  }

  const status =
    phase === "listening"
      ? "Listening"
      : phase === "transcribing"
        ? "Hearing"
        : phase === "thinking"
          ? "Thinking"
          : phase === "speaking"
            ? "Speaking"
            : "Ready";

  return (
    <main className="shell mx-auto flex min-h-dvh w-full max-w-lg flex-col">
      <header className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs tracking-widest text-amber uppercase">Voice aide</p>
          <h1 className="text-3xl font-semibold tracking-tight text-balance">Arden</h1>
        </div>
        <p className="pt-1 font-mono text-xs tracking-widest text-muted uppercase">{status}</p>
      </header>

      {!installed ? (
        <section className="mt-4 rounded-3xl border border-line bg-panel p-4">
          <div className="flex items-start gap-3">
            <Download className="mt-0.5 size-5 shrink-0 text-amber" aria-hidden="true" />
            <div className="min-w-0">
              <h2 className="text-base font-medium">Put Arden on your phone</h2>
              <p className="mt-1 text-sm leading-relaxed text-muted">
                Add it to your home screen. It stays there like an app. It can use the microphone, location, and alerts you allow. It cannot read your messages or control other apps.
              </p>
              {installEvent ? (
                <button
                  type="button"
                  className="press mt-3 min-h-11 rounded-full bg-amber px-4 text-sm font-medium text-on-amber"
                  onClick={() => void installEvent.prompt()}
                >
                  Install
                </button>
              ) : ios ? (
                <a
                  href="/?install=1&platform=ios"
                  className="mt-3 inline-flex min-h-11 items-center text-sm font-medium text-amber"
                >
                  Show iPhone steps
                </a>
              ) : (
                <p className="mt-3 text-sm text-paper">Use the browser menu, then Install app or Add to Home screen.</p>
              )}
            </div>
          </div>
        </section>
      ) : null}

      <section className="mt-4" aria-label="Phone access">
        <div className="grid grid-cols-3 gap-2">
          <Status icon={<Mic className="size-4" aria-hidden="true" />} label="Mic" value={mic === "on" ? "On" : mic === "blocked" ? "Blocked" : "Off"} />
          <Status icon={<MapPin className="size-4" aria-hidden="true" />} label="Place" value={place ?? (placeGate === "blocked" ? "Blocked" : "Off")} />
          <Status icon={<Bell className="size-4" aria-hidden="true" />} label="Alerts" value={alerts === "on" ? "On" : alerts === "blocked" ? "Blocked" : "Off"} />
        </div>
        <button
          type="button"
          onClick={() => void linkPhone()}
          className="press mt-3 min-h-11 w-full rounded-full border border-line bg-panel text-sm font-medium text-paper"
        >
          {mic === "on" || placeGate === "on" ? "Update phone access" : "Allow phone access"}
        </button>
        {battery ? <p className="mt-2 text-center font-mono text-xs text-muted">Battery {battery}</p> : null}
      </section>

      <div ref={scroller} className="mt-4 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto" aria-live="polite">
        {messages.length === 0 ? (
          <p className="text-sm leading-relaxed text-pretty text-muted">
            Try “What time is it?”, “Remember I take tea at four”, or “Set a timer for 10 minutes”. Tap the orb to speak.
            {notes.length ? ` ${notes.length} saved on this phone.` : ""}
          </p>
        ) : (
          messages.map((item) => (
            <article
              key={item.id}
              className={
                item.role === "user"
                  ? "ml-8 rounded-3xl bg-amber px-4 py-3 text-on-amber"
                  : "mr-6 rounded-3xl border border-line bg-panel px-4 py-3"
              }
            >
              {item.thought ? (
                <p className="font-mono text-xs leading-relaxed text-muted">
                  <span className="text-amber">Reasoning. </span>
                  {item.thought}
                </p>
              ) : null}
              <p className={`text-base leading-relaxed ${item.thought ? "mt-2" : ""}`}>{item.text}</p>
              {item.links?.map((link) => (
                <a key={link.href} href={link.href} target="_blank" rel="noreferrer noopener" className="mt-2 block text-sm text-amber">
                  Open {link.label}
                </a>
              ))}
              {item.note ? <p className="mt-2 text-sm text-muted">{item.note}</p> : null}
            </article>
          ))
        )}
      </div>

      <footer className="mt-4 flex flex-col items-center gap-3 border-t border-line pt-4">
        <button
          type="button"
          className={`orb press is-${phase}`}
          aria-label={phase === "listening" ? "Stop listening" : phase === "speaking" ? "Stop speaking" : "Speak"}
          onPointerDown={unlockAudio}
          onClick={onOrb}
        >
          {phase === "listening" ? <Square className="size-6" aria-hidden="true" /> : <Mic className="size-7" aria-hidden="true" />}
        </button>
        <form
          className="flex w-full gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            void runCommand(draft);
          }}
        >
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            aria-label="Command"
            placeholder="Type a command"
            enterKeyHint="send"
            className="min-h-11 min-w-0 flex-1 rounded-full border border-line bg-panel px-4 text-base text-paper outline-none"
          />
          <button
            type="submit"
            aria-label="Send command"
            onPointerDown={unlockAudio}
            disabled={!draft.trim() || phase === "thinking" || phase === "transcribing"}
            className="press grid size-11 shrink-0 place-items-center rounded-full bg-amber text-on-amber disabled:opacity-40"
          >
            <Send className="size-4" aria-hidden="true" />
          </button>
        </form>
      </footer>
    </main>
  );
}

function Status({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="min-h-16 rounded-2xl border border-line bg-panel px-2 py-2">
      <div className="flex items-center gap-1 text-amber">{icon}</div>
      <p className="mt-1 text-xs text-muted">{label}</p>
      <p className="truncate text-sm text-paper">{value}</p>
    </div>
  );
}
