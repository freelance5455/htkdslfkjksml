import React from 'react';
import { Message } from '../types/jarvis';
import {
  Volume2,
  Copy,
  Check,
  Trash2,
  User,
  Sparkles,
  ChevronDown,
} from 'lucide-react';

interface ConsoleDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
  onClearMessages: () => void;
  onReplayAudio: (text: string) => void;
  onSelectPrompt: (prompt: string) => void;
  currentLanguage: string;
}

export const ConsoleDrawer: React.FC<ConsoleDrawerProps> = ({
  isOpen,
  onClose,
  messages,
  onClearMessages,
  onReplayAudio,
  onSelectPrompt,
  currentLanguage,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Quick suggestion chips based on selected language
  const suggestedPrompts =
    currentLanguage === 'bn'
      ? [
          'আজকের তারিখ কত?',
          'আজকের দিনটি কেমন হতে পারে?',
          'আমাকে একটি অনুপ্রেরণামূলক উক্তি শোনান',
          'জার্ভিস, তোমার মূল কাজ কী?',
        ]
      : [
          "What is today's date?",
          'JARVIS, run a full system status check',
          'Explain quantum computing in 2 sentences',
          'Give me a productive quote for today',
        ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-md flex flex-col justify-end animate-fade-in sm:items-center sm:justify-center p-0 sm:p-4">
      {/* Drawer Container */}
      <div className="bg-slate-950/95 border border-cyan-500/30 rounded-t-3xl sm:rounded-2xl w-full max-w-xl h-[85vh] sm:h-[80vh] flex flex-col shadow-2xl shadow-cyan-950/50 overflow-hidden">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-cyan-500/20 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse glow-cyan" />
            <h3 className="text-base font-bold font-tech text-cyan-300 tracking-wider">
              TACTICAL LOG CONSOLE
            </h3>
            <span className="text-xs px-2 py-0.5 rounded border border-cyan-500/30 text-cyan-400 font-mono">
              {messages.length} ENTRIES
            </span>
          </div>

          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <button
                onClick={onClearMessages}
                title="Clear conversation"
                className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-950/30 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors"
            >
              <ChevronDown className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Suggested Quick Prompts Bar */}
        <div className="px-4 py-2.5 bg-slate-900/40 border-b border-cyan-500/10 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[11px] text-cyan-400/80 font-mono uppercase shrink-0 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-cyan-400" /> QUICK ORDERS:
          </span>
          {suggestedPrompts.map((prompt, index) => (
            <button
              key={index}
              onClick={() => {
                onSelectPrompt(prompt);
                onClose();
              }}
              className="shrink-0 px-3 py-1 rounded-full text-xs bg-cyan-950/50 hover:bg-cyan-900/60 text-cyan-200 border border-cyan-500/30 transition-colors whitespace-nowrap active:scale-95"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Message Log List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <div className="w-16 h-16 rounded-full border border-dashed border-cyan-500/40 flex items-center justify-center mb-4">
                <Sparkles className="w-8 h-8 text-cyan-500/60" />
              </div>
              <p className="text-sm font-tech text-slate-300 uppercase tracking-wider">
                NO COMMANDS LOGGED
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Speak directly or select a quick order prompt above to initiate protocol with JARVIS.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-1.5 mb-1 px-1 text-[11px] font-mono text-cyan-400/70">
                    {isUser ? (
                      <>
                        <span>USER COMMAND</span>
                        <User className="w-3 h-3 text-cyan-400" />
                      </>
                    ) : (
                      <>
                        <div className="w-2 h-2 rounded-full bg-cyan-400 glow-cyan" />
                        <span className="font-bold text-cyan-300">J.A.R.V.I.S.</span>
                      </>
                    )}
                    <span>• {msg.timestamp}</span>
                  </div>

                  <div
                    className={`relative group max-w-[88%] rounded-2xl p-3.5 text-sm leading-relaxed ${
                      isUser
                        ? 'bg-cyan-950/80 text-cyan-100 border border-cyan-500/40 rounded-tr-none'
                        : 'bg-slate-900/90 text-slate-200 border border-slate-700/60 rounded-tl-none shadow-md shadow-cyan-950/20'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>

                    {/* Action buttons (Replay voice / Copy) */}
                    <div className="mt-2.5 pt-2 border-t border-cyan-500/10 flex items-center justify-end gap-1.5">
                      {!isUser && (
                        <button
                          onClick={() => onReplayAudio(msg.text)}
                          title="Speak again"
                          className="px-2 py-1 rounded text-xs text-cyan-300 hover:text-cyan-100 bg-cyan-900/30 hover:bg-cyan-800/40 flex items-center gap-1 border border-cyan-500/20 transition-colors"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>Vocalize</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        title="Copy text"
                        className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-green-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Close Button */}
        <div className="p-3 border-t border-cyan-500/20 bg-slate-950 flex justify-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 text-xs font-tech tracking-wider uppercase hover:bg-cyan-900/50 transition-colors"
          >
            RETURN TO CORE HUD
          </button>
        </div>
      </div>
    </div>
  );
};
