import React, { useRef, useEffect, useState, useMemo } from "react";
import {
  PaperThemeId,
  PAPER_THEME_DEFINITIONS,
  usePaperNotebook,
  computeNotebookMetrics,
} from "../utils/paperNotebookConfig";
import { useDisplayScale } from "../utils/displayScaleManager";
import {
  Palette,
  Calendar,
  Eye,
  Edit3,
  Sliders,
  Type,
  Check,
  RotateCcw,
  Sparkles,
  Maximize2,
  Minimize2,
} from "lucide-react";

interface FullBleedRuledEditorProps {
  content: string;
  onChangeContent: (newContent: string) => void;
  title: string;
  onChangeTitle: (newTitle: string) => void;
  updatedAt?: string | number;
  createdAt?: string | number;
  isEditing: boolean;
  onToggleEditMode: () => void;
  fontFamily?: string;
  category?: string;
  tags?: string[];
  stylusLayer?: React.ReactNode;
  placeholder?: string;
  children?: React.ReactNode;
}

export const FullBleedRuledEditor: React.FC<FullBleedRuledEditorProps> = ({
  content,
  onChangeContent,
  title,
  onChangeTitle,
  updatedAt,
  createdAt,
  isEditing,
  onToggleEditMode,
  fontFamily,
  category,
  tags,
  stylusLayer,
  placeholder = "Yazmak için dokunun...",
  children,
}) => {
  const { config, themeDef, setTheme, setFontSize, setLineHeightRatio } = usePaperNotebook();
  const { scaleConfig } = useDisplayScale();
  const [showThemePicker, setShowThemePicker] = useState<boolean>(false);
  const [activeLineIndex, setActiveLineIndex] = useState<number>(0);

  const editorContainerRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Computed notebook metrics with baseline alignment mathematics
  const metrics = useMemo(() => {
    return computeNotebookMetrics(
      config.fontSize,
      scaleConfig.typographyScale,
      config.lineHeightRatio,
      themeDef.lineColor,
      themeDef.marginLineColor,
      config.showMarginLine
    );
  }, [config.fontSize, scaleConfig.typographyScale, config.lineHeightRatio, themeDef, config.showMarginLine]);

  // Formatted date for ColorNote header (e.g. "15 Ağustos 18:06")
  const formattedDate = useMemo(() => {
    const rawDate = updatedAt || createdAt || Date.now();
    const d = new Date(rawDate);
    const months = [
      "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
      "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"
    ];
    const day = d.getDate();
    const month = months[d.getMonth()];
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    return `${day} ${month} ${hours}:${minutes}`;
  }, [updatedAt, createdAt]);

  // Sync cursor position to calculate active line for highlight
  const handleTextareaKeyUpOrClick = (e: React.SyntheticEvent<HTMLTextAreaElement>) => {
    const textarea = e.currentTarget;
    const textBeforeCursor = textarea.value.substring(0, textarea.selectionStart);
    const lineNum = textBeforeCursor.split("\n").length - 1;
    setActiveLineIndex(lineNum);
  };

  // Auto-focus and resize when entering edit mode
  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [isEditing]);

  // Effective font family
  const effectiveFontFamily = fontFamily || "'Plus Jakarta Sans', system-ui, sans-serif";

  // Calculate top padding to sit letters right onto the first rule
  // Top header height is fixed, lines start right below
  const lineSpacingPx = metrics.lineHeight;

  return (
    <div
      ref={editorContainerRef}
      style={{
        backgroundColor: themeDef.bgColor,
        backgroundImage: themeDef.bgGradient,
        color: themeDef.textColor,
      }}
      className="relative w-full flex-1 flex flex-col overflow-hidden select-text transition-colors duration-200"
    >
      {/* ======================================================================= */}
      {/* 1. TOP HEADER & PAPER METADATA BAR (Above First Notebook Line)          */}
      {/* ======================================================================= */}
      <div
        className="w-full shrink-0 flex items-center justify-between px-4 sm:px-6 py-2.5 border-b select-none transition-colors"
        style={{
          borderColor: themeDef.lineColor,
          backgroundColor: "rgba(0, 0, 0, 0.02)",
        }}
      >
        {/* Left: Date Display & Category Info */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5" style={{ color: themeDef.dateColor }}>
            <Calendar className="w-3.5 h-3.5 opacity-80" />
            <span className="text-xs font-semibold tracking-wide font-mono">
              {formattedDate}
            </span>
          </div>

          {category && (
            <span
              className="text-[11px] font-bold px-2 py-0.5 rounded-md border truncate max-w-[120px] sm:max-w-xs"
              style={{
                borderColor: themeDef.lineColor,
                color: themeDef.dateColor,
                backgroundColor: "rgba(0,0,0,0.03)",
              }}
            >
              {category}
            </span>
          )}
        </div>

        {/* Right: Paper Theme Picker & Reading/Writing Switch */}
        <div className="flex items-center gap-1.5">
          {/* Quick Paper Themes Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowThemePicker(!showThemePicker)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold border transition-all cursor-pointer shadow-2xs"
              style={{
                borderColor: themeDef.lineColor,
                color: themeDef.textColor,
                backgroundColor: "rgba(255, 255, 255, 0.15)",
              }}
              title="Defter Kağıt Temasını Değiştir"
            >
              <span
                className="w-3.5 h-3.5 rounded-full border shadow-2xs shrink-0"
                style={{ backgroundColor: themeDef.bgColor, borderColor: themeDef.lineColor }}
              />
              <span className="hidden sm:inline text-[11px]">{themeDef.name.split(" ")[0]}</span>
            </button>

            {showThemePicker && (
              <div
                className="absolute right-0 mt-1 w-56 rounded-2xl border shadow-xl z-50 p-2 space-y-1 animate-in fade-in"
                style={{
                  backgroundColor: themeDef.bgColor === "#18181B" ? "#27272A" : "#FFFFFF",
                  borderColor: themeDef.lineColor,
                  color: themeDef.bgColor === "#18181B" ? "#F4F4F5" : "#0F172A",
                }}
              >
                <div className="text-[10px] font-black uppercase tracking-wider px-2 py-1 text-slate-400">
                  ColorNote Kağıt Temaları
                </div>
                {Object.values(PAPER_THEME_DEFINITIONS).map((thm) => {
                  const isSel = config.activeTheme === thm.id;
                  return (
                    <button
                      key={thm.id}
                      type="button"
                      onClick={() => {
                        setTheme(thm.id);
                        setShowThemePicker(false);
                      }}
                      className={`w-full flex items-center justify-between p-2 rounded-xl text-left text-xs transition-all cursor-pointer ${
                        isSel
                          ? "font-extrabold ring-1 ring-teal-500 bg-teal-500/10 text-teal-600 dark:text-teal-400"
                          : "hover:bg-slate-100 dark:hover:bg-slate-700/60"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-4 h-4 rounded-full border shadow-2xs shrink-0"
                          style={{ backgroundColor: thm.bgColor, borderColor: thm.lineColor }}
                        />
                        <div>
                          <div className="font-bold leading-tight">{thm.name}</div>
                          <div className="text-[9px] opacity-70">{thm.badge}</div>
                        </div>
                      </div>
                      {isSel && <Check className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}

                {/* Font Size Quick Slider */}
                <div className="pt-2 mt-2 border-t border-slate-200 dark:border-slate-700 px-2 space-y-1">
                  <div className="flex justify-between text-[10px] font-bold opacity-80">
                    <span>Yazı Boyutu:</span>
                    <span>{metrics.fontSize}px</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFontSize(config.fontSize - 1)}
                      className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-xs font-bold"
                    >
                      -
                    </button>
                    <input
                      type="range"
                      min="14"
                      max="24"
                      value={config.fontSize}
                      onChange={(e) => setFontSize(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded cursor-pointer accent-teal-600"
                    />
                    <button
                      type="button"
                      onClick={() => setFontSize(config.fontSize + 1)}
                      className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-xs font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Edit / Read Mode Pill */}
          <button
            type="button"
            onClick={onToggleEditMode}
            className={`flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-2xs ${
              isEditing
                ? "bg-teal-600 text-white shadow-teal-600/30"
                : "border hover:bg-black/5"
            }`}
            style={{
              borderColor: isEditing ? undefined : themeDef.lineColor,
              color: isEditing ? "#FFFFFF" : themeDef.textColor,
            }}
          >
            {isEditing ? <Eye className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
            <span>{isEditing ? "Okuma Modu" : "Yaz"}</span>
          </button>
        </div>
      </div>

      {/* ======================================================================= */}
      {/* 2. FULL-BLEED NOTE TITLE (Directly on Ruled Paper Grid)                 */}
      {/* ======================================================================= */}
      <div
        className="w-full shrink-0 px-4 sm:px-6 pt-3 pb-1 border-b"
        style={{
          borderColor: themeDef.lineColor,
          paddingLeft: config.showMarginLine ? "calc(48px + 16px)" : undefined,
        }}
      >
        {isEditing ? (
          <input
            type="text"
            value={title}
            onChange={(e) => onChangeTitle(e.target.value)}
            placeholder="Başlık..."
            className="w-full text-xl sm:text-2xl font-black bg-transparent border-0 focus:outline-hidden placeholder:opacity-40 tracking-tight"
            style={{
              fontFamily: effectiveFontFamily,
              color: themeDef.textColor,
            }}
          />
        ) : (
          <h1
            onClick={onToggleEditMode}
            className="text-xl sm:text-2xl font-black tracking-tight cursor-pointer hover:opacity-85 transition-opacity"
            style={{
              fontFamily: effectiveFontFamily,
              color: themeDef.textColor,
            }}
            title="Düzenlemek için dokunun"
          >
            {title || <span className="opacity-40 italic font-normal">Başlıksız Not</span>}
          </h1>
        )}
      </div>

      {/* ======================================================================= */}
      {/* 3. FULL-BLEED RULED PAPER BODY (Baseline Grid Alignment Architecture)    */}
      {/* ======================================================================= */}
      <div
        className="relative flex-1 w-full overflow-y-auto overflow-x-hidden scroll-smooth"
        style={{
          // Ruled Lines Background
          backgroundImage: config.showRuledLines ? metrics.backgroundImage : undefined,
          backgroundSize: config.showRuledLines ? metrics.backgroundSize : undefined,
          backgroundRepeat: config.showRuledLines ? "repeat-y" : undefined,
          backgroundAttachment: "local", // Ensures lines scroll with content seamlessly!
        }}
      >
        {/* Optional Stylus Canvas Overlay Floating Above */}
        {stylusLayer && (
          <div className="absolute inset-0 z-30 pointer-events-none">
            {stylusLayer}
          </div>
        )}

        {/* Full-bleed Ruled Container */}
        <div
          className="w-full min-h-full"
          style={{
            // 18dp/16px padding on right and left (+ margin line compensation)
            paddingLeft: config.showMarginLine ? "calc(48px + 18px)" : "18px",
            paddingRight: "18px",
            paddingTop: "6px",
            paddingBottom: "80px",
          }}
        >
          {isEditing ? (
            /* =============================================================== */
            /* 3A. EDITING MODE (Synchronized Caret, Baseline & Line Height)   */
            /* =============================================================== */
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => onChangeContent(e.target.value)}
              onKeyUp={handleTextareaKeyUpOrClick}
              onClick={handleTextareaKeyUpOrClick}
              placeholder={placeholder}
              rows={Math.max(14, (content.split("\n").length || 1) + 4)}
              className="w-full bg-transparent border-0 focus:outline-hidden resize-none overflow-hidden m-0 p-0 block transition-all"
              style={{
                fontFamily: effectiveFontFamily,
                fontSize: `${metrics.fontSize}px`,
                lineHeight: `${metrics.lineHeight}px`,
                color: themeDef.textColor,
                caretColor: themeDef.caretColor,
                minHeight: "500px",
                letterSpacing: "0.01em",
              }}
            />
          ) : (
            /* =============================================================== */
            /* 3B. READING MODE (Full-Bleed Distraction-Free Render)           */
            /* =============================================================== */
            <div
              onDoubleClick={onToggleEditMode}
              className="w-full cursor-text select-text"
              style={{
                fontFamily: effectiveFontFamily,
                fontSize: `${metrics.fontSize}px`,
                lineHeight: `${metrics.lineHeight}px`,
                color: themeDef.textColor,
                minHeight: "500px",
                letterSpacing: "0.01em",
              }}
            >
              {content ? (
                content.split("\n").map((line, idx) => (
                  <div
                    key={idx}
                    className="w-full relative transition-colors duration-150"
                    style={{
                      minHeight: `${metrics.lineHeight}px`,
                      lineHeight: `${metrics.lineHeight}px`,
                    }}
                  >
                    {line.trim() === "" ? (
                      // Empty line preserves exact baseline rhythm
                      <span className="invisible">&nbsp;</span>
                    ) : (
                      line
                    )}
                  </div>
                ))
              ) : (
                <div
                  className="opacity-40 italic cursor-pointer"
                  style={{
                    minHeight: `${metrics.lineHeight}px`,
                    lineHeight: `${metrics.lineHeight}px`,
                  }}
                  onClick={onToggleEditMode}
                >
                  {placeholder}
                </div>
              )}
            </div>
          )}

          {/* Optional Children (Tasks, Attachments, Media on Ruled Page) */}
          {children && (
            <div className="mt-6 pt-4 space-y-4 border-t" style={{ borderColor: themeDef.lineColor }}>
              {children}
            </div>
          )}
        </div>
      </div>

      {/* ======================================================================= */}
      {/* 4. BOTTOM STATUS BAR (Lines, Words, Theme Indicator)                    */}
      {/* ======================================================================= */}
      <div
        className="w-full shrink-0 flex items-center justify-between px-4 sm:px-6 py-1.5 border-t text-[11px] font-mono select-none"
        style={{
          borderColor: themeDef.lineColor,
          color: themeDef.dateColor,
          backgroundColor: "rgba(0, 0, 0, 0.02)",
        }}
      >
        <div className="flex items-center gap-3">
          <span>{content.split("\n").length} Satır</span>
          <span>•</span>
          <span>{content.trim() ? content.trim().split(/\s+/).length : 0} Kelime</span>
          <span>•</span>
          <span>{content.length} Karakter</span>
        </div>

        <div className="flex items-center gap-2 text-[10px]">
          <span className="hidden sm:inline">Satır Aralığı: {metrics.lineHeight}px</span>
          <span className="font-bold opacity-80">{themeDef.name}</span>
        </div>
      </div>
    </div>
  );
};
