import React, { useState } from 'react';
import { Archive, ArrowDown, ArrowUp, Edit2, Eye, EyeOff, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { COLOR_SWATCHES, ICON_OPTIONS } from '../../db/defaults';
import type { CustomModule, CustomSubmodule, EntityStatus } from '../../types/app';
import { ConfirmDialog } from '../ConfirmDialog';
import { DynamicIcon } from '../DynamicIcon';

export const ModuleManagementPanel: React.FC = () => {
  const { snapshot, saveModule, deleteModule, notify } = useApp();
  const [editing, setEditing] = useState<CustomModule | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [icon, setIcon] = useState('Package');
  const [color, setColor] = useState('#059669');
  const [visible, setVisible] = useState(true);
  const [status, setStatus] = useState<EntityStatus>('published');
  const [confirmDel, setConfirmDel] = useState<CustomModule | null>(null);

  const modules = [...snapshot.modules].sort((a, b) => a.position - b.position);

  const resetForm = () => {
    setEditing(null);
    setName('');
    setDescription('');
    setIcon('Package');
    setColor('#059669');
    setVisible(true);
    setStatus('published');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveModule({
      id: editing?.id,
      name,
      description,
      icon,
      color,
      position: editing ? editing.position : modules.length,
      visible,
      archived: editing?.archived ?? false,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save module', 'error');
      return;
    }
    notify(editing ? `Updated module "${name}"` : `Created module "${name}"`);
    resetForm();
  };

  const moveModule = async (mod: CustomModule, dir: -1 | 1) => {
    const idx = modules.findIndex((m) => m.id === mod.id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= modules.length) return;
    const other = modules[swapIdx];
    await saveModule({ ...mod, position: other.position });
    await saveModule({ ...other, position: mod.position });
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-display text-base font-bold text-slate-900">
            {editing ? `Edit Module: ${editing.name}` : 'Create New Module'}
          </h3>
          {editing && (
            <button type="button" onClick={resetForm} className="text-xs font-medium text-slate-500 hover:text-slate-800 cursor-pointer">
              Cancel Edit
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label htmlFor="mod-name" className="block text-xs font-semibold text-slate-700 mb-1">
              Module Name *
            </label>
            <input
              id="mod-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Inventory, Property, Sales"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="mod-icon" className="block text-xs font-semibold text-slate-700 mb-1">
              Icon
            </label>
            <select
              id="mod-icon"
              value={icon}
              onChange={(e) => setIcon(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              {ICON_OPTIONS.map((ic) => (
                <option key={ic} value={ic}>
                  {ic}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="mod-status" className="block text-xs font-semibold text-slate-700 mb-1">
              Publish Status
            </label>
            <select
              id="mod-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as EntityStatus)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="published">Published (Live on Dashboard)</option>
              <option value="draft">Draft (Test in Preview First)</option>
            </select>
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="mod-desc" className="block text-xs font-semibold text-slate-700 mb-1">
              Description
            </label>
            <input
              id="mod-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Short description of this module"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <span className="block text-xs font-semibold text-slate-700 mb-1">Module Colour</span>
            <div className="flex flex-wrap items-center gap-1.5">
              {COLOR_SWATCHES.map((sw) => (
                <button
                  key={sw}
                  type="button"
                  aria-label={`Select color ${sw}`}
                  onClick={() => setColor(sw)}
                  className={`w-6 h-6 rounded-md cursor-pointer ${
                    color === sw ? 'ring-2 ring-offset-1 ring-slate-900' : ''
                  }`}
                  style={{ backgroundColor: sw }}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
            <input type="checkbox" checked={visible} onChange={(e) => setVisible(e.target.checked)} />
            <span>Visible on Dashboard &amp; Navigation</span>
          </label>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{editing ? 'Update Module' : 'Create Module'}</span>
          </button>
        </div>
      </form>

      {/* Module List */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Configured Custom Modules ({modules.length})
        </div>
        {modules.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No custom modules created yet. Create your first module above.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {modules.map((m, idx) => (
              <div key={m.id} className="p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white shrink-0"
                    style={{ backgroundColor: m.color }}
                  >
                    <DynamicIcon name={m.icon} className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-sm text-slate-900 truncate">
                      {m.name} {m.archived ? '(Archived)' : ''}
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {m.status === 'draft' ? 'Draft' : 'Published'} · {m.visible ? 'Visible' : 'Hidden'} ·{' '}
                      {m.description || 'No description'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label={`Move ${m.name} up`}
                    disabled={idx === 0}
                    onClick={() => moveModule(m, -1)}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={`Move ${m.name} down`}
                    disabled={idx === modules.length - 1}
                    onClick={() => moveModule(m, 1)}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={m.visible ? `Hide ${m.name}` : `Show ${m.name}`}
                    onClick={() => saveModule({ ...m, visible: !m.visible })}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                  >
                    {m.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    aria-label={m.archived ? `Unarchive ${m.name}` : `Archive ${m.name}`}
                    onClick={() => saveModule({ ...m, archived: !m.archived })}
                    className="p-1.5 rounded text-slate-500 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={`Edit ${m.name}`}
                    onClick={() => {
                      setEditing(m);
                      setName(m.name);
                      setDescription(m.description);
                      setIcon(m.icon);
                      setColor(m.color);
                      setVisible(m.visible);
                      setStatus(m.status);
                    }}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete ${m.name}`}
                    onClick={() => setConfirmDel(m)}
                    className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!confirmDel}
        title={`Delete Module "${confirmDel?.name}"?`}
        message="This moves the module, its submodules, fields, and records to the Recycle Bin."
        destructive
        confirmLabel="Delete Module"
        onConfirm={async () => {
          if (confirmDel) {
            await deleteModule(confirmDel.id);
            notify(`Deleted module "${confirmDel.name}"`);
          }
          setConfirmDel(null);
        }}
        onCancel={() => setConfirmDel(null)}
      />
    </div>
  );
};

export const SubmoduleManagementPanel: React.FC = () => {
  const { snapshot, saveSubmodule, deleteSubmodule, notify } = useApp();
  const [moduleId, setModuleId] = useState(snapshot.modules[0]?.id || '');
  const [editing, setEditing] = useState<CustomSubmodule | null>(null);
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('FileText');
  const [color, setColor] = useState('#0B1F3A');
  const [visible, setVisible] = useState(true);
  const [status, setStatus] = useState<EntityStatus>('published');
  const [confirmDel, setConfirmDel] = useState<CustomSubmodule | null>(null);

  const subs = snapshot.submodules
    .filter((s) => !moduleId || s.moduleId === moduleId)
    .sort((a, b) => a.position - b.position);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveSubmodule({
      id: editing?.id,
      moduleId,
      name,
      icon,
      color,
      position: editing ? editing.position : subs.length,
      visible,
      archived: editing?.archived ?? false,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save submodule', 'error');
      return;
    }
    notify(editing ? `Updated submodule "${name}"` : `Added submodule "${name}"`);
    setEditing(null);
    setName('');
  };

  const moveSub = async (sub: CustomSubmodule, dir: -1 | 1) => {
    const idx = subs.findIndex((s) => s.id === sub.id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= subs.length) return;
    const other = subs[swapIdx];
    await saveSubmodule({ ...sub, position: other.position });
    await saveSubmodule({ ...other, position: sub.position });
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          {editing ? `Edit Submodule: ${editing.name}` : 'Add Submodule to Module'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label htmlFor="sub-parent" className="block text-xs font-semibold text-slate-700 mb-1">
              Parent Module *
            </label>
            <select
              id="sub-parent"
              required
              value={moduleId}
              onChange={(e) => setModuleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Module...</option>
              {snapshot.modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="sub-name" className="block text-xs font-semibold text-slate-700 mb-1">
              Submodule Name *
            </label>
            <input
              id="sub-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Stock Items, Invoices"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="sub-icon" className="block text-xs font-semibold text-slate-700 mb-1">
              Icon
            </label>
            <select
              id="sub-icon"
              value={icon}
              onChange={(e) => setIcon(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              {ICON_OPTIONS.map((ic) => (
                <option key={ic} value={ic}>
                  {ic}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="sub-status" className="block text-xs font-semibold text-slate-700 mb-1">
              Status
            </label>
            <select
              id="sub-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as EntityStatus)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-700">Colour:</span>
            {COLOR_SWATCHES.slice(0, 6).map((sw) => (
              <button
                key={sw}
                type="button"
                aria-label={`Select color ${sw}`}
                onClick={() => setColor(sw)}
                className={`w-5 h-5 rounded cursor-pointer ${color === sw ? 'ring-2 ring-offset-1 ring-slate-900' : ''}`}
                style={{ backgroundColor: sw }}
              />
            ))}
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{editing ? 'Update Submodule' : 'Add Submodule'}</span>
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Submodules ({subs.length})
        </div>
        {subs.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            Select or create a parent module and add submodules above.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {subs.map((s, idx) => {
              const parent = snapshot.modules.find((m) => m.id === s.moduleId);
              return (
                <div key={s.id} className="p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center text-white"
                      style={{ backgroundColor: s.color }}
                    >
                      <DynamicIcon name={s.icon} className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-slate-900">{s.name}</div>
                      <div className="text-xs text-slate-500">
                        Module: {parent?.name || 'Unknown'} · {s.status} · {s.visible ? 'Visible' : 'Hidden'}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button type="button" aria-label={`Move ${s.name} up`} disabled={idx === 0} onClick={() => moveSub(s, -1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"><ArrowUp className="w-4 h-4" /></button>
                    <button type="button" aria-label={`Move ${s.name} down`} disabled={idx === subs.length - 1} onClick={() => moveSub(s, 1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"><ArrowDown className="w-4 h-4" /></button>
                    <button type="button" aria-label={`Toggle ${s.name} visibility`} onClick={() => saveSubmodule({ ...s, visible: !s.visible })} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer">
                      {s.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                    <button type="button" aria-label={`Archive ${s.name}`} onClick={() => saveSubmodule({ ...s, archived: !s.archived })} className="p-1.5 rounded text-slate-500 hover:bg-amber-50 cursor-pointer"><Archive className="w-4 h-4" /></button>
                    <button
                      type="button"
                      aria-label={`Edit ${s.name}`}
                      onClick={() => {
                        setEditing(s);
                        setModuleId(s.moduleId);
                        setName(s.name);
                        setIcon(s.icon);
                        setColor(s.color);
                        setVisible(s.visible);
                        setStatus(s.status);
                      }}
                      className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button type="button" aria-label={`Delete ${s.name}`} onClick={() => setConfirmDel(s)} className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!confirmDel}
        title={`Delete Submodule "${confirmDel?.name}"?`}
        message="This moves the submodule, its fields, and records to the Recycle Bin."
        destructive
        confirmLabel="Delete"
        onConfirm={async () => {
          if (confirmDel) {
            await deleteSubmodule(confirmDel.id);
            notify(`Deleted submodule "${confirmDel.name}"`);
          }
          setConfirmDel(null);
        }}
        onCancel={() => setConfirmDel(null)}
      />
    </div>
  );
};
