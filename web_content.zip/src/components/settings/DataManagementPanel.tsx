import React, { useMemo, useState } from 'react';
import { Archive, Search, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatDisplayDate, formatMoney } from '../../engine/calculations';

export const DataManagementPanel: React.FC = () => {
  const {
    snapshot,
    toggleArchiveCustomRecord,
    deleteCustomRecord,
    deleteLoanTransaction,
    deleteCommitteeTransaction,
    setActiveRoute,
    notify,
  } = useApp();

  const [sourceFilter, setSourceFilter] = useState<'all' | 'loan' | 'committee' | 'custom'>('all');
  const [showArchived, setShowArchived] = useState(false);
  const [search, setSearch] = useState('');

  const allRecords = useMemo(() => {
    const rows: {
      id: string;
      source: 'loan' | 'committee' | 'custom';
      label: string;
      details: string;
      date: string;
      archived: boolean;
    }[] = [];

    if (sourceFilter === 'all' || sourceFilter === 'loan') {
      for (const tx of snapshot.loanTransactions) {
        const p = snapshot.loanPersons.find((x) => x.id === tx.personId);
        rows.push({
          id: tx.id,
          source: 'loan',
          label: `${p?.name || 'Unknown'} (${tx.type === 'received' ? 'Loan Received' : 'Repayment'})`,
          details: formatMoney(tx.amount, snapshot.settings),
          date: tx.date,
          archived: false,
        });
      }
    }

    if (sourceFilter === 'all' || sourceFilter === 'committee') {
      for (const tx of snapshot.committeeTransactions) {
        const c = snapshot.committees.find((x) => x.id === tx.committeeId);
        rows.push({
          id: tx.id,
          source: 'committee',
          label: `${c?.name || 'Committee'} · ${tx.personName} (${tx.type})`,
          details: formatMoney(tx.amount, snapshot.settings),
          date: tx.date,
          archived: false,
        });
      }
    }

    if (sourceFilter === 'all' || sourceFilter === 'custom') {
      for (const r of snapshot.customRecords) {
        const m = snapshot.modules.find((x) => x.id === r.moduleId);
        const s = snapshot.submodules.find((x) => x.id === r.submoduleId);
        rows.push({
          id: r.id,
          source: 'custom',
          label: `${m?.name || 'Module'} / ${s?.name || 'Submodule'}`,
          details: Object.entries(r.values)
            .slice(0, 3)
            .map(([k, v]) => `${k}: ${v}`)
            .join(' · '),
          date: r.createdAt.slice(0, 10),
          archived: r.archived,
        });
      }
    }

    return rows
      .filter((r) => (showArchived ? r.archived : !r.archived))
      .filter((r) => {
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        return r.label.toLowerCase().includes(q) || r.details.toLowerCase().includes(q);
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [snapshot, sourceFilter, showArchived, search]);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-bold text-slate-900">Data Management</h3>
          <p className="text-xs text-slate-500">
            Search, filter, archive, restore, or manage all records across the database.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setActiveRoute('recycle-bin')}
          className="px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          Open Recycle Bin ({snapshot.recycleBin.length})
        </button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" aria-hidden="true" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search all records..."
            aria-label="Search all records"
            className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300"
          />
        </div>
        <select
          aria-label="Filter record source"
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value as typeof sourceFilter)}
          className="px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
        >
          <option value="all">All Sources</option>
          <option value="loan">Loans</option>
          <option value="committee">Committees</option>
          <option value="custom">Custom Modules</option>
        </select>
        <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
          <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} />
          <span>Archived Only</span>
        </label>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        {allRecords.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No records match these filters.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {allRecords.map((r) => (
              <div key={r.id} className="p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold text-sm text-slate-900 truncate">{r.label}</div>
                  <div className="text-xs text-slate-500 truncate">
                    {formatDisplayDate(r.date, snapshot.settings.dateFormat)} · {r.details}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {r.source === 'custom' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await toggleArchiveCustomRecord(r.id, !r.archived);
                        notify(r.archived ? 'Record restored from archive' : 'Record archived');
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                    >
                      <Archive className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{r.archived ? 'Restore' : 'Archive'}</span>
                    </button>
                  )}
                  <button
                    type="button"
                    aria-label={`Move ${r.label} to recycle bin`}
                    onClick={async () => {
                      if (r.source === 'loan') await deleteLoanTransaction(r.id);
                      else if (r.source === 'committee') await deleteCommitteeTransaction(r.id);
                      else await deleteCustomRecord(r.id);
                      notify('Moved to Recycle Bin');
                    }}
                    className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
