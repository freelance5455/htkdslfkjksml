import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, Save, Download, Upload, 
  RotateCcw, Monitor, CheckCircle, Store, ShieldCheck, 
  Receipt, Laptop, Sparkles, HardDrive, RefreshCw 
} from 'lucide-react';
import { StoreSettings } from '../../types';
import { exportAllDataBackup, importAllDataBackup, resetToDefaultData } from '../../utils/storage';

interface Props {
  settings: StoreSettings;
  onUpdateSettings: (newSettings: StoreSettings) => void;
  onDataReload: () => void;
  canInstallPwa: boolean;
  onInstallPwa: () => void;
  onOpenDownloadModal?: () => void;
}

export const SettingsManager: React.FC<Props> = ({
  settings,
  onUpdateSettings,
  onDataReload,
  canInstallPwa,
  onInstallPwa,
  onOpenDownloadModal,
}) => {
  const [formData, setFormData] = useState<StoreSettings>(settings);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleBackupExport = () => {
    exportAllDataBackup();
  };

  const handleBackupImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ok = confirm('هل تريد بالتأكيد استعادة النسخة الاحتياطية؟ سيتم تحديث المنتجات والفواتير الحالية.');
    if (!ok) return;

    const success = await importAllDataBackup(file);
    if (success) {
      alert('تم استيراد البيانات والنسخة الاحتياطية بنجاح!');
      onDataReload();
    } else {
      alert('فشل استيراد الملف، تأكد من صحة ملف النسخة الاحتياطية.');
    }
  };

  const handleResetData = () => {
    const ok = confirm('تنبيه: هل أنت متأكد من استعادة البيانات الافتراضية الأولية؟ سيتم مسح التغييرات غير المحفوظة.');
    if (ok) {
      resetToDefaultData();
      onDataReload();
      alert('تمت استعادة البيانات الأولية بنجاح.');
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto p-4 md:p-6 text-slate-100">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <SettingsIcon className="w-5 h-5 text-blue-400" />
              إعدادات نقطة البيع والنسخ الاحتياطي
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              تخصيص بيانات المتجر، الفواتير، ونظام التشغيل على Windows
            </p>
          </div>

          {savedSuccess && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs font-semibold animate-in fade-in">
              <CheckCircle className="w-4 h-4" />
              <span>تم حفظ التعديلات بنجاح</span>
            </div>
          )}
        </div>

        {/* Windows Native Installation Banner */}
        <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900 border border-blue-500/30 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <Laptop className="w-7 h-7 text-blue-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base">
                  تشغيل البرنامج كتطبيق أصلي على Windows 10/11
                </h3>
                <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full border border-blue-500/30 font-semibold">
                  PWA / Desktop
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                يعمل البرنامج بدون إنترنت (Offline) على أجهزة الكاشير بنظام ويندوز مع دعم أجهزة قراءة الباركود وطابعات الإيصالات الحرارية 80mm وشاشات اللمس.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {canInstallPwa && (
              <button
                onClick={onInstallPwa}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/30 transition flex items-center gap-2"
              >
                <Monitor className="w-4 h-4" />
                <span>تثبيت على ويندوز الآن</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="px-3.5 py-2.5 bg-slate-850 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-600 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>فحص التحديثات والتحميل</span>
            </button>
          </div>
        </div>

        {/* Store Settings Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* General Information Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <h4 className="font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-slate-800">
              <Store className="w-4 h-4 text-blue-400" />
              بيانات المنشأة والمتجر
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم المتجر / الشركة (بالعربية):
                </label>
                <input
                  type="text"
                  required
                  value={formData.storeName}
                  onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم المتجر (بالإنجليزية):
                </label>
                <input
                  type="text"
                  value={formData.storeNameEn}
                  onChange={(e) => setFormData({ ...formData, storeNameEn: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  الرقم الضريبي (VAT Number):
                </label>
                <input
                  type="text"
                  value={formData.taxNumber}
                  onChange={(e) => setFormData({ ...formData, taxNumber: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  رقم السجل التجاري:
                </label>
                <input
                  type="text"
                  value={formData.commercialReg}
                  onChange={(e) => setFormData({ ...formData, commercialReg: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">رقم الهاتف:</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">العنوان:</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Tax & POS Preferences */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <h4 className="font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              الضريبة والعملة وإيصالات الكاشير
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  العملة المعروضة:
                </label>
                <input
                  type="text"
                  value={formData.currency}
                  onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  نسبة ضريبة القيمة المضافة (%):
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={formData.vatRate}
                  onChange={(e) =>
                    setFormData({ ...formData, vatRate: parseFloat(e.target.value) || 0 })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم الكاشير الافتراضي:
                </label>
                <input
                  type="text"
                  value={formData.cashierName}
                  onChange={(e) => setFormData({ ...formData, cashierName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                العبارة الترحيبية أسفل الإيصال الحراري (تذييل الفاتورة):
              </label>
              <input
                type="text"
                value={formData.receiptFooter}
                onChange={(e) => setFormData({ ...formData, receiptFooter: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/25 transition"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>
        </form>

        {/* Windows App Installation Card */}
        <div className="bg-slate-900 border border-blue-500/30 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <Laptop className="w-4 h-4 text-blue-400" />
              تثبيت البرنامج على نظام Windows
            </h4>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full font-bold">
              تطبيق سطح مكتب
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            قم بتثبيت البرنامج ليعمل كنافذة مستقلة وسريعة على سطح مكتب Windows 10/11 مع اختصار في قائمة ابدأ ودعم العمل دون اتصال بالإنترنت.
          </p>

          <div className="pt-1 flex gap-3">
            <button
              onClick={onOpenDownloadModal}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>خيارات تحميل وتثبيت التطبيق على Windows</span>
            </button>
          </div>
        </div>

        {/* Windows Data Backup & Safety Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <h4 className="font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-slate-800">
            <HardDrive className="w-4 h-4 text-amber-400" />
            حفظ واسترجاع النسخ الاحتياطية المحلية
          </h4>

          <p className="text-xs text-slate-400 leading-relaxed">
            يمكنك حفظ نسخة كاملة من جميع المنتجات والمخزون وسجل الفواتير والعملاء في ملف آمن على جهازك الكمبيوتر بصيغة JSON، واسترجاعها في أي وقت دون الحاجة لشبكة الإنترنت.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={handleBackupExport}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>تحميل نسخة احتياطية (.json)</span>
            </button>

            <label className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer">
              <Upload className="w-4 h-4 text-blue-400" />
              <span>استعادة نسخة احتياطية</span>
              <input
                type="file"
                accept=".json"
                onChange={handleBackupImport}
                className="hidden"
              />
            </label>

            <button
              onClick={handleResetData}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-xs font-bold transition mr-auto"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة ضبط المصنع (بيانات افتراضية)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
