import React, { useState } from 'react';
import { RotateCcw, Save } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { THEME_PRESETS } from '../../db/defaults';
import type { AppSettings, ThemeConfig } from '../../types/app';

export const GeneralSettingsPanel: React.FC = () => {
  const { snapshot, updateSettings, notify } = useApp();
  const s = snapshot.settings;

  const [appName, setAppName] = useState(s.appName);
  const [appSubtitle, setAppSubtitle] = useState(s.appSubtitle);
  const [language, setLanguage] = useState<AppSettings['language']>(s.language);
  const [currency, setCurrency] = useState(s.currency);
  const [dateFormat, setDateFormat] = useState<AppSettings['dateFormat']>(s.dateFormat);
  const [numberFormat, setNumberFormat] = useState<AppSettings['numberFormat']>(s.numberFormat);
  const [defaultDashboardView, setDefaultDashboardView] = useState<AppSettings['defaultDashboardView']>(s.defaultDashboardView);
  const [layoutMode, setLayoutMode] = useState<AppSettings['layoutMode']>(s.layoutMode);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings({
      appName: appName.trim() || 'Saif Ullah',
      appSubtitle: appSubtitle.trim() || 'Loan & Committee Manager',
      language,
      currency: currency.trim() || 'Rs.',
      dateFormat,
      numberFormat,
      defaultDashboardView,
      layoutMode,
    });
    notify('General settings saved');
  };

  return (
    <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
      <div>
        <h3 className="font-display text-base font-bold text-slate-900">General Settings</h3>
        <p className="text-xs text-slate-500">
          Configure application title, currency symbol, date formatting, and layout defaults.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="gen-app-name" className="block text-xs font-semibold text-slate-700 mb-1">
            Application Name
          </label>
          <input
            id="gen-app-name"
            type="text"
            value={appName}
            onChange={(e) => setAppName(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
          />
        </div>
        <div>
          <label htmlFor="gen-app-sub" className="block text-xs font-semibold text-slate-700 mb-1">
            Application Subtitle
          </label>
          <input
            id="gen-app-sub"
            type="text"
            value={appSubtitle}
            onChange={(e) => setAppSubtitle(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
          />
        </div>
        <div>
          <label htmlFor="gen-lang" className="block text-xs font-semibold text-slate-700 mb-1">
            Language
          </label>
          <select
            id="gen-lang"
            value={language}
            onChange={(e) => setLanguage(e.target.value as AppSettings['language'])}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
          >
            <option value="English">English</option>
            <option value="Urdu (Roman)">Urdu (Roman)</option>
          </select>
        </div>
        <div>
          <label htmlFor="gen-curr" className="block text-xs font-semibold text-slate-700 mb-1">
            Currency Symbol
          </label>
          <input
            id="gen-curr"
            type="text"
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
          />
        </div>
        <div>
          <label htmlFor="gen-datefmt" className="block text-xs font-semibold text-slate-700 mb-1">
            Date Format
          </label>
          <select
            id="gen-datefmt"
            value={dateFormat}
            onChange={(e) => setDateFormat(e.target.value as AppSettings['dateFormat'])}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
          >
            <option value="DD MMM YYYY">DD MMM YYYY (15 Nov 2026)</option>
            <option value="DD/MM/YYYY">DD/MM/YYYY (15/11/2026)</option>
            <option value="MM/DD/YYYY">MM/DD/YYYY (11/15/2026)</option>
            <option value="YYYY-MM-DD">YYYY-MM-DD (2026-11-15)</option>
          </select>
        </div>
        <div>
          <label htmlFor="gen-numfmt" className="block text-xs font-semibold text-slate-700 mb-1">
            Number Format
          </label>
          <select
            id="gen-numfmt"
            value={numberFormat}
            onChange={(e) => setNumberFormat(e.target.value as AppSettings['numberFormat'])}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
          >
            <option value="en-PK">Standard Comma (1,00,000 / en-PK)</option>
            <option value="en-US">International (100,000 / en-US)</option>
            <option value="en-GB">UK Format (100,000 / en-GB)</option>
          </select>
        </div>
        <div>
          <label htmlFor="gen-dashview" className="block text-xs font-semibold text-slate-700 mb-1">
            Default Dashboard View
          </label>
          <select
            id="gen-dashview"
            value={defaultDashboardView}
            onChange={(e) => setDefaultDashboardView(e.target.value as AppSettings['defaultDashboardView'])}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
          >
            <option value="overview">Full Overview</option>
            <option value="compact">Compact Summary</option>
          </select>
        </div>
        <div>
          <label htmlFor="gen-layout" className="block text-xs font-semibold text-slate-700 mb-1">
            Desktop / Mobile Layout
          </label>
          <select
            id="gen-layout"
            value={layoutMode}
            onChange={(e) => setLayoutMode(e.target.value as AppSettings['layoutMode'])}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
          >
            <option value="auto">Responsive Auto</option>
            <option value="desktop">Desktop Density</option>
            <option value="mobile">Touch-Friendly Mobile</option>
          </select>
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button
          type="submit"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
        >
          <Save className="w-4 h-4" aria-hidden="true" />
          <span>Save General Settings</span>
        </button>
      </div>
    </form>
  );
};

export const ThemeSettingsPanel: React.FC = () => {
  const { snapshot, updateSettings, resetTheme, notify } = useApp();
  const [theme, setTheme] = useState<ThemeConfig>(snapshot.settings.theme);

  const applyPreset = async (presetId: string) => {
    const found = THEME_PRESETS.find((p) => p.id === presetId);
    if (!found) return;
    setTheme(found.theme);
    await updateSettings({ theme: found.theme });
    notify(`Applied theme preset: ${found.name}`);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings({ theme });
    notify('Custom theme colours saved');
  };

  const colorFields: { key: keyof Omit<ThemeConfig, 'presetId'>; label: string }[] = [
    { key: 'primaryColor', label: 'Primary Colour' },
    { key: 'secondaryColor', label: 'Secondary (Emerald) Colour' },
    { key: 'sidebarColor', label: 'Sidebar Colour' },
    { key: 'backgroundColor', label: 'Background Colour' },
    { key: 'cardColor', label: 'Card Surface Colour' },
    { key: 'textColor', label: 'Text Colour' },
    { key: 'buttonColor', label: 'Action Button Colour' },
    { key: 'loanModuleColor', label: 'Loan Module Card Colour' },
    { key: 'committeeModuleColor', label: 'Committee Module Card Colour' },
  ];

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-bold text-slate-900">Theme &amp; Colours</h3>
          <p className="text-xs text-slate-500">
            Customize dashboard colours or switch preset themes. Financial data is never affected.
          </p>
        </div>
        <button
          type="button"
          onClick={async () => {
            await resetTheme();
            setTheme(THEME_PRESETS[0].theme);
            notify('Theme reset to original Navy & Emerald');
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Reset Theme</span>
        </button>
      </div>

      {/* Presets */}
      <div>
        <div className="text-xs font-semibold text-slate-700 mb-2">Preset Themes</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {THEME_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => applyPreset(p.id)}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                theme.presetId === p.id
                  ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/30'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="w-5 h-5 rounded" style={{ backgroundColor: p.theme.primaryColor }} />
                <span className="w-5 h-5 rounded" style={{ backgroundColor: p.theme.secondaryColor }} />
                <span className="w-5 h-5 rounded border border-slate-200" style={{ backgroundColor: p.theme.backgroundColor }} />
              </div>
              <div className="text-xs font-bold text-slate-900">{p.name}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Individual Color Pickers */}
      <form onSubmit={handleSave} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {colorFields.map((cf) => (
            <div key={cf.key} className="flex items-center justify-between gap-3 p-3 rounded-lg border border-slate-200">
              <label htmlFor={`color-${cf.key}`} className="text-xs font-medium text-slate-700">
                {cf.label}
              </label>
              <div className="flex items-center gap-2">
                <span className="font-mono-num text-[11px] text-slate-500">{theme[cf.key]}</span>
                <input
                  id={`color-${cf.key}`}
                  type="color"
                  value={theme[cf.key]}
                  onChange={(e) => setTheme((prev) => ({ ...prev, presetId: 'custom', [cf.key]: e.target.value }))}
                  className="w-8 h-8 rounded cursor-pointer border-0 bg-transparent"
                />
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <Save className="w-4 h-4" aria-hidden="true" />
            <span>Apply Custom Colours</span>
          </button>
        </div>
      </form>
    </div>
  );
};
