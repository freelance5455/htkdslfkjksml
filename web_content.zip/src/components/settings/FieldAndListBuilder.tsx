import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Edit2, Eye, EyeOff, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { generateId } from '../../db/indexedDb';
import { COLOR_SWATCHES } from '../../db/defaults';
import type { EntityStatus, FieldDefinition, FieldType, MasterList, MasterListOption } from '../../types/app';
import { ConfirmDialog } from '../ConfirmDialog';

const FIELD_TYPES: { value: FieldType; label: string }[] = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'currency', label: 'Currency (Rs.)' },
  { value: 'date', label: 'Date' },
  { value: 'time', label: 'Time' },
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'multiselect', label: 'Multi-Select' },
  { value: 'checkbox', label: 'Checkbox' },
  { value: 'yesno', label: 'Yes / No' },
  { value: 'percentage', label: 'Percentage (%)' },
  { value: 'formula', label: 'Formula / Calculated Field' },
  { value: 'notes', label: 'Notes / Remarks' },
];

export const FieldBuilderPanel: React.FC = () => {
  const { snapshot, saveField, deleteField, notify } = useApp();
  const [moduleId, setModuleId] = useState(snapshot.modules[0]?.id || '');
  const subsForMod = useMemo(
    () => snapshot.submodules.filter((s) => s.moduleId === moduleId).sort((a, b) => a.position - b.position),
    [snapshot.submodules, moduleId]
  );
  const [submoduleId, setSubmoduleId] = useState(subsForMod[0]?.id || '');

  const [editing, setEditing] = useState<FieldDefinition | null>(null);
  const [label, setLabel] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<FieldType>('text');
  const [placeholder, setPlaceholder] = useState('');
  const [defaultValue, setDefaultValue] = useState('');
  const [required, setRequired] = useState(false);
  const [editable, setEditable] = useState(true);
  const [visible, setVisible] = useState(true);
  const [decimalPlaces, setDecimalPlaces] = useState('2');
  const [minValue, setMinValue] = useState('');
  const [maxValue, setMaxValue] = useState('');
  const [optionsText, setOptionsText] = useState('');
  const [masterListId, setMasterListId] = useState('');
  const [color, setColor] = useState('#0B1F3A');
  const [formulaExpression, setFormulaExpression] = useState('');
  const [status, setStatus] = useState<EntityStatus>('published');
  const [confirmDel, setConfirmDel] = useState<FieldDefinition | null>(null);

  const activeSubId = subsForMod.some((s) => s.id === submoduleId) ? submoduleId : subsForMod[0]?.id || '';

  const subFields = useMemo(
    () => snapshot.fields.filter((f) => f.submoduleId === activeSubId).sort((a, b) => a.position - b.position),
    [snapshot.fields, activeSubId]
  );

  const resetForm = () => {
    setEditing(null);
    setLabel('');
    setName('');
    setType('text');
    setPlaceholder('');
    setDefaultValue('');
    setRequired(false);
    setEditable(true);
    setVisible(true);
    setDecimalPlaces('2');
    setMinValue('');
    setMaxValue('');
    setOptionsText('');
    setMasterListId('');
    setColor('#0B1F3A');
    setFormulaExpression('');
    setStatus('published');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const safeName = (name.trim() || label.trim()).replace(/[^A-Za-z0-9_]/g, '');
    if (!safeName) {
      notify('Field name must contain alphanumeric characters.', 'error');
      return;
    }
    const res = await saveField({
      id: editing?.id,
      moduleId,
      submoduleId: activeSubId,
      name: safeName,
      label: label.trim() || safeName,
      type,
      placeholder,
      defaultValue,
      required,
      editable: type === 'formula' ? false : editable,
      visible,
      position: editing ? editing.position : subFields.length,
      decimalPlaces: Number(decimalPlaces) || 0,
      minValue: minValue !== '' ? Number(minValue) : undefined,
      maxValue: maxValue !== '' ? Number(maxValue) : undefined,
      dropdownOptions: optionsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      masterListId: masterListId || undefined,
      color,
      formulaExpression: type === 'formula' ? formulaExpression : undefined,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save field', 'error');
      return;
    }
    notify(editing ? `Updated field "${label || safeName}"` : `Added field "${label || safeName}"`);
    resetForm();
  };

  const moveField = async (fld: FieldDefinition, dir: -1 | 1) => {
    const idx = subFields.findIndex((f) => f.id === fld.id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= subFields.length) return;
    const other = subFields[swapIdx];
    await saveField({ ...fld, position: other.position });
    await saveField({ ...other, position: fld.position });
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-display text-base font-bold text-slate-900">
            {editing ? `Edit Field: ${editing.label}` : 'Dynamic Field Builder'}
          </h3>
          {editing && (
            <button type="button" onClick={resetForm} className="text-xs font-medium text-slate-500 cursor-pointer">
              Cancel Edit
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label htmlFor="fb-mod" className="block text-xs font-semibold text-slate-700 mb-1">
              Module *
            </label>
            <select
              id="fb-mod"
              required
              value={moduleId}
              onChange={(e) => setModuleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Module...</option>
              {snapshot.modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fb-sub" className="block text-xs font-semibold text-slate-700 mb-1">
              Submodule *
            </label>
            <select
              id="fb-sub"
              required
              value={activeSubId}
              onChange={(e) => setSubmoduleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Submodule...</option>
              {subsForMod.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fb-type" className="block text-xs font-semibold text-slate-700 mb-1">
              Field Type *
            </label>
            <select
              id="fb-type"
              value={type}
              onChange={(e) => setType(e.target.value as FieldType)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              {FIELD_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fb-label" className="block text-xs font-semibold text-slate-700 mb-1">
              Field Label *
            </label>
            <input
              id="fb-label"
              type="text"
              required
              value={label}
              onChange={(e) => {
                const nextLabel = e.target.value;
                setLabel(nextLabel);
                if (!editing) {
                  setName(nextLabel.replace(/[^A-Za-z0-9_]/g, ''));
                }
              }}
              placeholder="e.g. Unit Rate"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="fb-name" className="block text-xs font-semibold text-slate-700 mb-1">
              Field Key Name (Formula ID) *
            </label>
            <input
              id="fb-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rate"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono"
            />
          </div>
          <div>
            <label htmlFor="fb-status" className="block text-xs font-semibold text-slate-700 mb-1">
              Status
            </label>
            <select
              id="fb-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as EntityStatus)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>

          <div>
            <label htmlFor="fb-placeholder" className="block text-xs font-semibold text-slate-700 mb-1">
              Placeholder
            </label>
            <input
              id="fb-placeholder"
              type="text"
              value={placeholder}
              onChange={(e) => setPlaceholder(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="fb-default" className="block text-xs font-semibold text-slate-700 mb-1">
              Default Value
            </label>
            <input
              id="fb-default"
              type="text"
              value={defaultValue}
              onChange={(e) => setDefaultValue(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="fb-dec" className="block text-xs font-semibold text-slate-700 mb-1">
              Decimal Places
            </label>
            <input
              id="fb-dec"
              type="number"
              min="0"
              max="6"
              value={decimalPlaces}
              onChange={(e) => setDecimalPlaces(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
            />
          </div>

          {(type === 'number' || type === 'currency' || type === 'percentage') && (
            <>
              <div>
                <label htmlFor="fb-min" className="block text-xs font-semibold text-slate-700 mb-1">
                  Minimum Value
                </label>
                <input
                  id="fb-min"
                  type="number"
                  step="any"
                  value={minValue}
                  onChange={(e) => setMinValue(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
              <div>
                <label htmlFor="fb-max" className="block text-xs font-semibold text-slate-700 mb-1">
                  Maximum Value
                </label>
                <input
                  id="fb-max"
                  type="number"
                  step="any"
                  value={maxValue}
                  onChange={(e) => setMaxValue(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
            </>
          )}

          {(type === 'dropdown' || type === 'multiselect') && (
            <>
              <div>
                <label htmlFor="fb-ml" className="block text-xs font-semibold text-slate-700 mb-1">
                  Link Master List (Recommended)
                </label>
                <select
                  id="fb-ml"
                  value={masterListId}
                  onChange={(e) => setMasterListId(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                >
                  <option value="">Custom Inline Options</option>
                  {snapshot.masterLists.map((ml) => (
                    <option key={ml.id} value={ml.id}>
                      {ml.name} ({ml.options.length} items)
                    </option>
                  ))}
                </select>
              </div>
              {!masterListId && (
                <div className="sm:col-span-2">
                  <label htmlFor="fb-opts" className="block text-xs font-semibold text-slate-700 mb-1">
                    Dropdown Options (comma separated)
                  </label>
                  <input
                    id="fb-opts"
                    type="text"
                    value={optionsText}
                    onChange={(e) => setOptionsText(e.target.value)}
                    placeholder="Option 1, Option 2, Option 3"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
                  />
                </div>
              )}
            </>
          )}

          {type === 'formula' && (
            <div className="sm:col-span-2">
              <label htmlFor="fb-formula" className="block text-xs font-semibold text-slate-700 mb-1">
                Formula Expression (or configure visually in Formula Builder)
              </label>
              <input
                id="fb-formula"
                type="text"
                value={formulaExpression}
                onChange={(e) => setFormulaExpression(e.target.value)}
                placeholder="e.g. Quantity * Rate"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono"
              />
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-700">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={required} onChange={(e) => setRequired(e.target.checked)} />
              <span>Required</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={editable} onChange={(e) => setEditable(e.target.checked)} />
              <span>Editable</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={visible} onChange={(e) => setVisible(e.target.checked)} />
              <span>Show in Forms</span>
            </label>
            <div className="flex items-center gap-1.5">
              <span>Colour:</span>
              {COLOR_SWATCHES.slice(0, 5).map((sw) => (
                <button
                  key={sw}
                  type="button"
                  aria-label={`Field color ${sw}`}
                  onClick={() => setColor(sw)}
                  className={`w-4 h-4 rounded cursor-pointer ${color === sw ? 'ring-2 ring-slate-900' : ''}`}
                  style={{ backgroundColor: sw }}
                />
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{editing ? 'Update Field' : 'Add Field'}</span>
          </button>
        </div>
      </form>

      {/* Field List */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Fields in Selected Submodule ({subFields.length})
        </div>
        {subFields.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No fields added to this submodule yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {subFields.map((f, idx) => (
              <div key={f.id} className="p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="w-3 h-3 rounded-xs shrink-0" style={{ backgroundColor: f.color }} />
                  <div>
                    <div className="font-semibold text-sm text-slate-900">
                      {f.label} <span className="font-mono text-xs text-slate-500">({f.name})</span>
                    </div>
                    <div className="text-xs text-slate-500">
                      Type: {f.type} · {f.required ? 'Required' : 'Optional'} · {f.status}
                      {f.formulaExpression ? ` · = ${f.formulaExpression}` : ''}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button type="button" aria-label={`Move ${f.label} up`} disabled={idx === 0} onClick={() => moveField(f, -1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"><ArrowUp className="w-4 h-4" /></button>
                  <button type="button" aria-label={`Move ${f.label} down`} disabled={idx === subFields.length - 1} onClick={() => moveField(f, 1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"><ArrowDown className="w-4 h-4" /></button>
                  <button type="button" aria-label={`Toggle ${f.label} visibility`} onClick={() => saveField({ ...f, visible: !f.visible })} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer">
                    {f.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    aria-label={`Edit ${f.label}`}
                    onClick={() => {
                      setEditing(f);
                      setModuleId(f.moduleId);
                      setSubmoduleId(f.submoduleId);
                      setLabel(f.label);
                      setName(f.name);
                      setType(f.type);
                      setPlaceholder(f.placeholder);
                      setDefaultValue(f.defaultValue);
                      setRequired(f.required);
                      setEditable(f.editable);
                      setVisible(f.visible);
                      setDecimalPlaces(String(f.decimalPlaces));
                      setMinValue(f.minValue !== undefined ? String(f.minValue) : '');
                      setMaxValue(f.maxValue !== undefined ? String(f.maxValue) : '');
                      setOptionsText(f.dropdownOptions.join(', '));
                      setMasterListId(f.masterListId || '');
                      setColor(f.color);
                      setFormulaExpression(f.formulaExpression || '');
                      setStatus(f.status);
                    }}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button type="button" aria-label={`Delete ${f.label}`} onClick={() => setConfirmDel(f)} className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!confirmDel}
        title={`Delete Field "${confirmDel?.label}"?`}
        message="Dependency protection will block deletion if any formula, field mapping, or dashboard card references this field."
        destructive
        confirmLabel="Delete Field"
        onConfirm={async () => {
          if (confirmDel) {
            const res = await deleteField(confirmDel.id);
            if (!res.ok) notify(res.error || 'Cannot delete field', 'error');
            else notify(`Deleted field "${confirmDel.label}"`);
          }
          setConfirmDel(null);
        }}
        onCancel={() => setConfirmDel(null)}
      />
    </div>
  );
};

export const MasterListsPanel: React.FC = () => {
  const { snapshot, saveMasterList, deleteMasterList, notify } = useApp();
  const [editing, setEditing] = useState<MasterList | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [options, setOptions] = useState<MasterListOption[]>([]);
  const [newOptionText, setNewOptionText] = useState('');

  const handleAddOption = () => {
    const label = newOptionText.trim();
    if (!label) return;
    setOptions((prev) => [
      ...prev,
      { id: generateId('opt'), label, value: label, position: prev.length },
    ]);
    setNewOptionText('');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveMasterList({
      id: editing?.id,
      name,
      description,
      options: options.map((o, idx) => ({ ...o, position: idx })),
    });
    if (!res.ok) {
      notify(res.error || 'Could not save master list', 'error');
      return;
    }
    notify(editing ? `Updated list "${name}"` : `Created master list "${name}"`);
    setEditing(null);
    setName('');
    setDescription('');
    setOptions([]);
  };

  const moveOpt = (idx: number, dir: -1 | 1) => {
    const next = [...options];
    const target = idx + dir;
    if (target < 0 || target >= next.length) return;
    [next[idx], next[target]] = [next[target], next[idx]];
    setOptions(next);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          {editing ? `Edit Master List: ${editing.name}` : 'Create Dropdown & Master List'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="ml-name" className="block text-xs font-semibold text-slate-700 mb-1">
              List Name *
            </label>
            <input
              id="ml-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Payment Categories, Cities, Suppliers"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="ml-desc" className="block text-xs font-semibold text-slate-700 mb-1">
              Description
            </label>
            <input
              id="ml-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
        </div>

        {/* Option Manager */}
        <div className="space-y-2">
          <label htmlFor="ml-add-opt" className="block text-xs font-semibold text-slate-700">
            List Options
          </label>
          <div className="flex gap-2">
            <input
              id="ml-add-opt"
              type="text"
              value={newOptionText}
              onChange={(e) => setNewOptionText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddOption();
                }
              }}
              placeholder="Type an option and click Add"
              className="flex-1 px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
            <button
              type="button"
              onClick={handleAddOption}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer"
            >
              Add Option
            </button>
          </div>
          {options.length > 0 && (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
              {options.map((opt, idx) => (
                <div key={opt.id} className="p-2.5 flex items-center gap-2">
                  <input
                    type="text"
                    value={opt.label}
                    aria-label={`Option ${idx + 1}`}
                    onChange={(e) =>
                      setOptions((prev) =>
                        prev.map((o) => (o.id === opt.id ? { ...o, label: e.target.value, value: e.target.value } : o))
                      )
                    }
                    className="flex-1 px-2.5 py-1 text-sm rounded border border-slate-200"
                  />
                  <button type="button" onClick={() => moveOpt(idx, -1)} disabled={idx === 0} className="p-1 text-slate-500 disabled:opacity-30 cursor-pointer"><ArrowUp className="w-3.5 h-3.5" /></button>
                  <button type="button" onClick={() => moveOpt(idx, 1)} disabled={idx === options.length - 1} className="p-1 text-slate-500 disabled:opacity-30 cursor-pointer"><ArrowDown className="w-3.5 h-3.5" /></button>
                  <button type="button" onClick={() => setOptions((prev) => prev.filter((o) => o.id !== opt.id))} className="p-1 text-red-500 cursor-pointer"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2">
          {editing && (
            <button
              type="button"
              onClick={() => {
                setEditing(null);
                setName('');
                setDescription('');
                setOptions([]);
              }}
              className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
            >
              Cancel
            </button>
          )}
          <button
            type="submit"
            className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            {editing ? 'Update Master List' : 'Save Master List'}
          </button>
        </div>
      </form>

      {/* Saved Master Lists */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Saved Master Lists ({snapshot.masterLists.length})
        </div>
        {snapshot.masterLists.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No master lists created yet.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {snapshot.masterLists.map((ml) => {
              const linkedCount = snapshot.fields.filter((f) => f.masterListId === ml.id).length;
              return (
                <div key={ml.id} className="p-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-sm text-slate-900">{ml.name}</div>
                    <div className="text-xs text-slate-500">
                      {ml.options.length} option(s) · Used by {linkedCount} field(s)
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      aria-label={`Edit list ${ml.name}`}
                      onClick={() => {
                        setEditing(ml);
                        setName(ml.name);
                        setDescription(ml.description);
                        setOptions(ml.options);
                      }}
                      className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete list ${ml.name}`}
                      onClick={async () => {
                        const res = await deleteMasterList(ml.id);
                        if (!res.ok) notify(res.error || 'Cannot delete list', 'error');
                        else notify(`Deleted master list "${ml.name}"`);
                      }}
                      className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
