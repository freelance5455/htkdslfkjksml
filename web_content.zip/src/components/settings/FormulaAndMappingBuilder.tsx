import React, { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { checkGlobalCircularReferences } from '../../engine/calculations';
import { validateFormulaSyntaxAndReferences } from '../../engine/formulaParser';
import type { EntityStatus, FormulaDefinition, MappingType } from '../../types/app';

export const FormulaBuilderPanel: React.FC = () => {
  const { snapshot, saveFormula, deleteFormula, notify } = useApp();
  const [moduleId, setModuleId] = useState(snapshot.modules[0]?.id || '');
  const subs = useMemo(
    () => snapshot.submodules.filter((s) => s.moduleId === moduleId),
    [snapshot.submodules, moduleId]
  );
  const [submoduleId, setSubmoduleId] = useState(subs[0]?.id || '');
  const activeSubId = subs.some((s) => s.id === submoduleId) ? submoduleId : subs[0]?.id || '';

  const subFields = useMemo(
    () => snapshot.fields.filter((f) => f.submoduleId === activeSubId),
    [snapshot.fields, activeSubId]
  );
  const formulaTargetFields = subFields.filter((f) => f.type === 'formula');

  const [editing, setEditing] = useState<FormulaDefinition | null>(null);
  const [name, setName] = useState('');
  const [targetFieldId, setTargetFieldId] = useState('');
  const [expression, setExpression] = useState('');
  const [decimalPlaces, setDecimalPlaces] = useState('2');
  const [status, setStatus] = useState<EntityStatus>('published');
  const [insertFieldKey, setInsertFieldKey] = useState('');
  const [crossFieldKey, setCrossFieldKey] = useState('');

  // Build available field names (local + Module.Submodule.Field)
  const availableFieldNames = useMemo(() => {
    const names = subFields.map((f) => f.name);
    for (const f of snapshot.fields) {
      const m = snapshot.modules.find((x) => x.id === f.moduleId);
      const s = snapshot.submodules.find((x) => x.id === f.submoduleId);
      if (m && s) {
        names.push(`${m.name}.${s.name}.${f.name}`);
      }
    }
    return Array.from(new Set(names));
  }, [subFields, snapshot.fields, snapshot.modules, snapshot.submodules]);

  const crossFieldOptions = useMemo(() => {
    return snapshot.fields
      .filter((f) => f.submoduleId !== activeSubId)
      .map((f) => {
        const m = snapshot.modules.find((x) => x.id === f.moduleId);
        const s = snapshot.submodules.find((x) => x.id === f.submoduleId);
        return {
          id: f.id,
          label: `${m?.name || '?'}.${s?.name || '?'}.${f.name}`,
        };
      });
  }, [snapshot.fields, snapshot.modules, snapshot.submodules, activeSubId]);

  const validation = useMemo(() => {
    if (!expression.trim()) return null;
    const syntax = validateFormulaSyntaxAndReferences(expression, availableFieldNames);
    if (!syntax.valid) return { ok: false, message: syntax.error || 'Invalid formula' };

    const targetField = subFields.find((f) => f.id === targetFieldId);
    if (targetField) {
      const simulatedFields = snapshot.fields.map((f) =>
        f.id === targetField.id ? { ...f, formulaExpression: expression } : f
      );
      const simulatedFormulas = [
        ...snapshot.formulas.filter((fm) => fm.targetFieldId !== targetField.id),
        {
          id: editing?.id || 'sim_fm',
          name: name || 'Formula',
          moduleId,
          submoduleId: activeSubId,
          targetFieldId: targetField.id,
          expression,
          decimalPlaces: Number(decimalPlaces) || 2,
          status,
          createdAt: '',
          updatedAt: '',
        },
      ];
      const cycle = checkGlobalCircularReferences(
        simulatedFields,
        simulatedFormulas,
        snapshot.fieldMappings,
        snapshot.modules,
        snapshot.submodules
      );
      if (cycle.hasCycle) {
        return {
          ok: false,
          message: `Circular formula prevented: ${cycle.cyclePath.join(' → ')}`,
        };
      }
    }
    return { ok: true, message: 'Formula syntax and field references validated.' };
  }, [
    expression,
    availableFieldNames,
    subFields,
    targetFieldId,
    snapshot.fields,
    snapshot.formulas,
    snapshot.fieldMappings,
    snapshot.modules,
    snapshot.submodules,
    editing,
    name,
    moduleId,
    activeSubId,
    decimalPlaces,
    status,
  ]);

  const appendToken = (token: string) => {
    setExpression((prev) => (prev ? `${prev} ${token}` : token));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetFieldId) {
      notify('Select a Formula target field first (create one in Field Builder if needed).', 'error');
      return;
    }
    if (!validation || !validation.ok) {
      notify(validation?.message || 'Formula validation failed. Cannot save invalid formula.', 'error');
      return;
    }
    const targetFld = subFields.find((f) => f.id === targetFieldId);
    const res = await saveFormula({
      id: editing?.id,
      name: name.trim() || `${targetFld?.label || 'Formula'} Calculation`,
      moduleId,
      submoduleId: activeSubId,
      targetFieldId,
      expression: expression.trim(),
      decimalPlaces: Number(decimalPlaces) || 2,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save formula', 'error');
      return;
    }
    notify('Formula saved & existing records recalculated');
    setEditing(null);
    setName('');
    setExpression('');
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          Visual Formula &amp; Calculation Builder
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label htmlFor="fm-mod" className="block text-xs font-semibold text-slate-700 mb-1">
              Module *
            </label>
            <select
              id="fm-mod"
              value={moduleId}
              onChange={(e) => setModuleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Module...</option>
              {snapshot.modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fm-sub" className="block text-xs font-semibold text-slate-700 mb-1">
              Submodule *
            </label>
            <select
              id="fm-sub"
              value={activeSubId}
              onChange={(e) => setSubmoduleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Submodule...</option>
              {subs.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fm-target" className="block text-xs font-semibold text-slate-700 mb-1">
              Target Formula Field *
            </label>
            <select
              id="fm-target"
              required
              value={targetFieldId}
              onChange={(e) => setTargetFieldId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Formula Field...</option>
              {formulaTargetFields.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.label} ({f.name})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fm-dec" className="block text-xs font-semibold text-slate-700 mb-1">
              Decimal Precision
            </label>
            <input
              id="fm-dec"
              type="number"
              min="0"
              max="6"
              value={decimalPlaces}
              onChange={(e) => setDecimalPlaces(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
            />
          </div>
        </div>

        {/* Visual Insert Controls */}
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-4 space-y-3">
          <div className="text-xs font-semibold text-slate-700">
            Insert Fields &amp; Operations (No manual typing required)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex gap-2">
              <select
                aria-label="Insert local field"
                value={insertFieldKey}
                onChange={(e) => setInsertFieldKey(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Pick field from this submodule...</option>
                {subFields
                  .filter((f) => f.id !== targetFieldId)
                  .map((f) => (
                    <option key={f.id} value={f.name}>
                      {f.label} ({f.name})
                    </option>
                  ))}
              </select>
              <button
                type="button"
                onClick={() => {
                  if (insertFieldKey) appendToken(`[${insertFieldKey}]`);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold cursor-pointer"
              >
                Insert
              </button>
            </div>

            <div className="flex gap-2">
              <select
                aria-label="Insert cross-module field"
                value={crossFieldKey}
                onChange={(e) => setCrossFieldKey(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Reference field from another module...</option>
                {crossFieldOptions.map((c) => (
                  <option key={c.id} value={c.label}>
                    {c.label}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => {
                  if (crossFieldKey) appendToken(`[${crossFieldKey}]`);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold cursor-pointer"
              >
                Insert
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {['+', '-', '*', '/', '%', '(', ')', ',', '>', '<', '>=', '==', 'SUM(', 'MIN(', 'MAX(', 'AVERAGE(', 'IF('].map(
              (op) => (
                <button
                  key={op}
                  type="button"
                  onClick={() => appendToken(op)}
                  className="px-2.5 py-1 rounded border border-slate-300 bg-white hover:bg-slate-100 text-xs font-mono font-semibold text-slate-800 cursor-pointer"
                >
                  {op}
                </button>
              )
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="fm-expr" className="block text-xs font-semibold text-slate-700 mb-1">
              Formula Expression *
            </label>
            <input
              id="fm-expr"
              type="text"
              required
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="e.g. [Quantity] * [Rate]"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono"
            />
          </div>
          <div>
            <label htmlFor="fm-status" className="block text-xs font-semibold text-slate-700 mb-1">
              Status
            </label>
            <select
              id="fm-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as EntityStatus)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="published">Published (Active)</option>
              <option value="draft">Draft (Test in Preview)</option>
            </select>
          </div>
        </div>

        {validation && (
          <div
            className={`rounded-lg px-3.5 py-2.5 text-xs flex items-center gap-2 ${
              validation.ok
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                : 'bg-red-50 border border-red-200 text-red-800'
            }`}
          >
            {validation.ok ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0" aria-hidden="true" />
            )}
            <span>{validation.message}</span>
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button
            type="button"
            onClick={() => setExpression('')}
            className="px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Clear
          </button>
          <button
            type="submit"
            disabled={!validation?.ok}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Save Formula</span>
          </button>
        </div>
      </form>

      {/* Saved Formulas */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Saved Formulas ({snapshot.formulas.length})
        </div>
        {snapshot.formulas.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No formulas saved yet.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {snapshot.formulas.map((fm) => {
              const target = snapshot.fields.find((f) => f.id === fm.targetFieldId);
              return (
                <div key={fm.id} className="p-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-sm text-slate-900">
                      {target?.label || fm.name} <span className="font-mono text-xs text-emerald-700">= {fm.expression}</span>
                    </div>
                    <div className="text-xs text-slate-500">
                      Precision: {fm.decimalPlaces} decimals · {fm.status}
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={`Delete formula ${fm.name}`}
                    onClick={async () => {
                      await deleteFormula(fm.id);
                      notify('Formula deleted');
                    }}
                    className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export const FieldMappingPanel: React.FC = () => {
  const { snapshot, saveFieldMapping, deleteFieldMapping, notify } = useApp();
  const [name, setName] = useState('');
  const [srcModId, setSrcModId] = useState(snapshot.modules[0]?.id || '');
  const srcSubs = snapshot.submodules.filter((s) => s.moduleId === srcModId);
  const [srcSubId, setSrcSubId] = useState(srcSubs[0]?.id || '');
  const activeSrcSub = srcSubs.some((s) => s.id === srcSubId) ? srcSubId : srcSubs[0]?.id || '';
  const srcFields = snapshot.fields.filter((f) => f.submoduleId === activeSrcSub);
  const [srcFieldId, setSrcFieldId] = useState('');

  const [destModId, setDestModId] = useState(snapshot.modules[0]?.id || '');
  const destSubs = snapshot.submodules.filter((s) => s.moduleId === destModId);
  const [destSubId, setDestSubId] = useState(destSubs[0]?.id || '');
  const activeDestSub = destSubs.some((s) => s.id === destSubId) ? destSubId : destSubs[0]?.id || '';
  const destFields = snapshot.fields.filter((f) => f.submoduleId === activeDestSub);
  const [destFieldId, setDestFieldId] = useState('');

  const [mappingType, setMappingType] = useState<MappingType>('direct');
  const [formulaExpression, setFormulaExpression] = useState('');
  const [status, setStatus] = useState<EntityStatus>('published');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!srcFieldId || !destFieldId) {
      notify('Select both source and destination fields.', 'error');
      return;
    }
    if (srcFieldId === destFieldId) {
      notify('Source and destination field cannot be identical (self-reference).', 'error');
      return;
    }

    const simulated = [
      ...snapshot.fieldMappings,
      {
        id: 'sim_map',
        name: name || 'Mapping',
        sourceModuleId: srcModId,
        sourceSubmoduleId: activeSrcSub,
        sourceFieldId: srcFieldId,
        destModuleId: destModId,
        destSubmoduleId: activeDestSub,
        destFieldId: destFieldId,
        mappingType,
        formulaExpression,
        status,
        validationStatus: 'valid' as const,
        createdAt: '',
        updatedAt: '',
      },
    ];

    const cycle = checkGlobalCircularReferences(
      snapshot.fields,
      snapshot.formulas,
      simulated,
      snapshot.modules,
      snapshot.submodules
    );
    if (cycle.hasCycle) {
      notify(`Circular mapping prevented: ${cycle.cyclePath.join(' → ')}`, 'error');
      return;
    }

    const srcFld = snapshot.fields.find((f) => f.id === srcFieldId);
    const destFld = snapshot.fields.find((f) => f.id === destFieldId);
    await saveFieldMapping({
      name: name.trim() || `${srcFld?.label || 'Source'} → ${destFld?.label || 'Dest'}`,
      sourceModuleId: srcModId,
      sourceSubmoduleId: activeSrcSub,
      sourceFieldId: srcFieldId,
      destModuleId: destModId,
      destSubmoduleId: activeDestSub,
      destFieldId: destFieldId,
      mappingType,
      formulaExpression: mappingType === 'formula' ? formulaExpression : '',
      status,
      validationStatus: 'valid',
      validationMessage: 'Validated acyclic mapping',
    });
    notify('Field mapping saved');
    setName('');
    setFormulaExpression('');
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          Field / Cell Mapping (Cross-Module &amp; Submodule)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Source */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
            <div className="text-xs font-bold text-slate-800">Source (Cell A)</div>
            <select aria-label="Source module" value={srcModId} onChange={(e) => setSrcModId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Source Module...</option>
              {snapshot.modules.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
            <select aria-label="Source submodule" value={activeSrcSub} onChange={(e) => setSrcSubId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Source Submodule...</option>
              {srcSubs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select aria-label="Source field" value={srcFieldId} onChange={(e) => setSrcFieldId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Source Field...</option>
              {srcFields.map((f) => <option key={f.id} value={f.id}>{f.label} ({f.name})</option>)}
            </select>
          </div>

          {/* Destination */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
            <div className="text-xs font-bold text-slate-800">Destination (Cell C)</div>
            <select aria-label="Destination module" value={destModId} onChange={(e) => setDestModId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Destination Module...</option>
              {snapshot.modules.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
            <select aria-label="Destination submodule" value={activeDestSub} onChange={(e) => setDestSubId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Destination Submodule...</option>
              {destSubs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select aria-label="Destination field" value={destFieldId} onChange={(e) => setDestFieldId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">Destination Field...</option>
              {destFields.map((f) => <option key={f.id} value={f.id}>{f.label} ({f.name})</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label htmlFor="map-name" className="block text-xs font-semibold text-slate-700 mb-1">
              Mapping Name
            </label>
            <input
              id="map-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Price Sync"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="map-type" className="block text-xs font-semibold text-slate-700 mb-1">
              Mapping Type
            </label>
            <select
              id="map-type"
              value={mappingType}
              onChange={(e) => setMappingType(e.target.value as MappingType)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="direct">Direct Cell Copy (C = A)</option>
              <option value="formula">Formula Expression (C = A * B)</option>
              <option value="aggregate_sum">Aggregate SUM of Source Records</option>
              <option value="aggregate_avg">Aggregate AVERAGE of Source Records</option>
            </select>
          </div>
          <div>
            <label htmlFor="map-status" className="block text-xs font-semibold text-slate-700 mb-1">
              Status
            </label>
            <select
              id="map-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as EntityStatus)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>

        {mappingType === 'formula' && (
          <div>
            <label htmlFor="map-expr" className="block text-xs font-semibold text-slate-700 mb-1">
              Mapping Formula (Use <code className="font-mono">A</code> for Source Field, or destination field names)
            </label>
            <input
              id="map-expr"
              type="text"
              required
              value={formulaExpression}
              onChange={(e) => setFormulaExpression(e.target.value)}
              placeholder="e.g. A * [Rate]"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono"
            />
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Validate &amp; Save Mapping</span>
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Field Mappings ({snapshot.fieldMappings.length})
        </div>
        {snapshot.fieldMappings.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No field mappings configured.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {snapshot.fieldMappings.map((m) => (
              <div key={m.id} className="p-4 flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-sm text-slate-900">{m.name}</div>
                  <div className="text-xs text-slate-500">
                    Type: {m.mappingType} {m.formulaExpression ? `· = ${m.formulaExpression}` : ''} ·{' '}
                    <span className={m.validationStatus === 'valid' ? 'text-emerald-700' : 'text-red-600'}>
                      {m.validationStatus}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  aria-label={`Delete mapping ${m.name}`}
                  onClick={async () => {
                    await deleteFieldMapping(m.id);
                    notify('Mapping deleted');
                  }}
                  className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
