import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Edit2, Eye, EyeOff, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { COLOR_SWATCHES, ICON_OPTIONS } from '../../db/defaults';
import type {
  CustomReportConfig,
  DashboardCalculationType,
  DashboardCardConfig,
  EntityStatus,
} from '../../types/app';

export const DashboardCardBuilderPanel: React.FC = () => {
  const { snapshot, saveDashboardCard, deleteDashboardCard, notify } = useApp();
  const [editing, setEditing] = useState<DashboardCardConfig | null>(null);
  const [title, setTitle] = useState('');
  const [sourceType, setSourceType] = useState<'loan' | 'committee' | 'custom'>('custom');
  const [moduleId, setModuleId] = useState(snapshot.modules[0]?.id || '');
  const subs = snapshot.submodules.filter((s) => s.moduleId === moduleId);
  const [submoduleId, setSubmoduleId] = useState(subs[0]?.id || '');
  const activeSubId = subs.some((s) => s.id === submoduleId) ? submoduleId : subs[0]?.id || '';
  const subFields = snapshot.fields.filter((f) => f.submoduleId === activeSubId);

  const [fieldId, setFieldId] = useState('');
  const [calculation, setCalculation] = useState<DashboardCalculationType>('sum');
  const [customFormula, setCustomFormula] = useState('');
  const [color, setColor] = useState('#059669');
  const [icon, setIcon] = useState('Wallet');
  const [status, setStatus] = useState<EntityStatus>('published');

  const cards = [...snapshot.dashboardCards].sort((a, b) => a.position - b.position);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveDashboardCard({
      id: editing?.id,
      title,
      sourceType,
      moduleId: sourceType === 'custom' ? moduleId : undefined,
      submoduleId: sourceType === 'custom' ? activeSubId : undefined,
      fieldId: fieldId || undefined,
      calculation,
      customFormula: calculation === 'custom_formula' ? customFormula : undefined,
      color,
      icon,
      position: editing ? editing.position : cards.length,
      visible: editing ? editing.visible : true,
      isSystem: editing?.isSystem,
      systemKey: editing?.systemKey,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Failed to save card', 'error');
      return;
    }
    notify(editing ? `Updated card "${title}"` : `Added dashboard card "${title}"`);
    setEditing(null);
    setTitle('');
    setCustomFormula('');
  };

  const moveCard = async (card: DashboardCardConfig, dir: -1 | 1) => {
    const idx = cards.findIndex((c) => c.id === card.id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= cards.length) return;
    const other = cards[swapIdx];
    await saveDashboardCard({ ...card, position: other.position });
    await saveDashboardCard({ ...other, position: card.position });
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          {editing ? `Edit Dashboard Card: ${editing.title}` : 'Dashboard Card Builder'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label htmlFor="dc-title" className="block text-xs font-semibold text-slate-700 mb-1">
              Card Name *
            </label>
            <input
              id="dc-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Total Inventory Value"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="dc-src" className="block text-xs font-semibold text-slate-700 mb-1">
              Data Source *
            </label>
            <select
              id="dc-src"
              value={sourceType}
              onChange={(e) => setSourceType(e.target.value as 'loan' | 'committee' | 'custom')}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="custom">Custom Module</option>
              <option value="loan">Loan Management</option>
              <option value="committee">Committee Management</option>
            </select>
          </div>
          <div>
            <label htmlFor="dc-calc" className="block text-xs font-semibold text-slate-700 mb-1">
              Calculation *
            </label>
            <select
              id="dc-calc"
              value={calculation}
              onChange={(e) => setCalculation(e.target.value as DashboardCalculationType)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="sum">Total / SUM</option>
              <option value="count">Count</option>
              <option value="average">Average</option>
              <option value="min">Minimum</option>
              <option value="max">Maximum</option>
              <option value="remaining_balance">Remaining Balance</option>
              <option value="custom_formula">Custom Formula</option>
            </select>
          </div>

          {sourceType === 'custom' && (
            <>
              <div>
                <label htmlFor="dc-mod" className="block text-xs font-semibold text-slate-700 mb-1">
                  Module
                </label>
                <select id="dc-mod" value={moduleId} onChange={(e) => setModuleId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                  <option value="">Select Module...</option>
                  {snapshot.modules.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="dc-sub" className="block text-xs font-semibold text-slate-700 mb-1">
                  Submodule
                </label>
                <select id="dc-sub" value={activeSubId} onChange={(e) => setSubmoduleId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                  <option value="">All Submodules</option>
                  {subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="dc-fld" className="block text-xs font-semibold text-slate-700 mb-1">
                  Field
                </label>
                <select id="dc-fld" value={fieldId} onChange={(e) => setFieldId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                  <option value="">Select Field...</option>
                  {subFields.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
                </select>
              </div>
            </>
          )}

          {sourceType === 'loan' && (
            <div>
              <label htmlFor="dc-loan-fld" className="block text-xs font-semibold text-slate-700 mb-1">
                Loan Metric Field
              </label>
              <select id="dc-loan-fld" value={fieldId} onChange={(e) => setFieldId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                <option value="received">Loan Received</option>
                <option value="repayment">Repayments</option>
                <option value="openingBalance">Opening Balances</option>
              </select>
            </div>
          )}

          {sourceType === 'committee' && (
            <div>
              <label htmlFor="dc-comm-fld" className="block text-xs font-semibold text-slate-700 mb-1">
                Committee Metric Field
              </label>
              <select id="dc-comm-fld" value={fieldId} onChange={(e) => setFieldId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                <option value="installment">Installments Paid</option>
                <option value="payout">Payouts Received</option>
                <option value="totalCommitteeAmount">Total Committee Pool</option>
              </select>
            </div>
          )}

          {calculation === 'custom_formula' && (
            <div className="sm:col-span-2">
              <label htmlFor="dc-cform" className="block text-xs font-semibold text-slate-700 mb-1">
                Custom Formula (Vars: LoanReceived, LoanRepaid, LoanRemaining, CommitteeReceivable, CommitteePaid)
              </label>
              <input
                id="dc-cform"
                type="text"
                value={customFormula}
                onChange={(e) => setCustomFormula(e.target.value)}
                placeholder="e.g. CommitteeReceivable - LoanRemaining"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono"
              />
            </div>
          )}

          <div>
            <label htmlFor="dc-icon" className="block text-xs font-semibold text-slate-700 mb-1">Icon</label>
            <select id="dc-icon" value={icon} onChange={(e) => setIcon(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              {ICON_OPTIONS.map((ic) => <option key={ic} value={ic}>{ic}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="dc-status" className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
            <select id="dc-status" value={status} onChange={(e) => setStatus(e.target.value as EntityStatus)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
          <div>
            <span className="block text-xs font-semibold text-slate-700 mb-1">Card Colour</span>
            <div className="flex flex-wrap gap-1.5">
              {COLOR_SWATCHES.slice(0, 6).map((sw) => (
                <button key={sw} type="button" onClick={() => setColor(sw)} className={`w-6 h-6 rounded cursor-pointer ${color === sw ? 'ring-2 ring-slate-900' : ''}`} style={{ backgroundColor: sw }} aria-label={`Color ${sw}`} />
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          {editing && (
            <button type="button" onClick={() => { setEditing(null); setTitle(''); }} className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer">
              Cancel
            </button>
          )}
          <button type="submit" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer">
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{editing ? 'Update Card' : 'Add Dashboard Card'}</span>
          </button>
        </div>
      </form>

      {/* Card List */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 font-display text-sm font-bold text-slate-900">
          Configured Dashboard Cards ({cards.length})
        </div>
        <div className="divide-y divide-slate-100">
          {cards.map((c, idx) => (
            <div key={c.id} className="p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="w-4 h-4 rounded" style={{ backgroundColor: c.color }} />
                <div>
                  <div className="font-semibold text-sm text-slate-900">
                    {c.title} {c.isSystem ? '(System)' : ''}
                  </div>
                  <div className="text-xs text-slate-500">
                    Source: {c.sourceType} · Calculation: {c.calculation} · {c.status} · {c.visible ? 'Visible' : 'Hidden'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button type="button" disabled={idx === 0} onClick={() => moveCard(c, -1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer" aria-label={`Move ${c.title} up`}><ArrowUp className="w-4 h-4" /></button>
                <button type="button" disabled={idx === cards.length - 1} onClick={() => moveCard(c, 1)} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer" aria-label={`Move ${c.title} down`}><ArrowDown className="w-4 h-4" /></button>
                <button type="button" onClick={() => saveDashboardCard({ ...c, visible: !c.visible })} className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer" aria-label={`Toggle ${c.title} visibility`}>
                  {c.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  aria-label={`Edit ${c.title}`}
                  onClick={() => {
                    setEditing(c);
                    setTitle(c.title);
                    setSourceType(c.sourceType);
                    if (c.moduleId) setModuleId(c.moduleId);
                    if (c.submoduleId) setSubmoduleId(c.submoduleId);
                    setFieldId(c.fieldId || '');
                    setCalculation(c.calculation);
                    setCustomFormula(c.customFormula || '');
                    setColor(c.color);
                    setIcon(c.icon);
                    setStatus(c.status);
                  }}
                  className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                {!c.isSystem && (
                  <button
                    type="button"
                    aria-label={`Delete ${c.title}`}
                    onClick={async () => {
                      await deleteDashboardCard(c.id);
                      notify(`Deleted card "${c.title}"`);
                    }}
                    className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const ReportsBuilderPanel: React.FC = () => {
  const { snapshot, saveReport, deleteReport, setActiveRoute, notify } = useApp();
  const [editing, setEditing] = useState<CustomReportConfig | null>(null);
  const [name, setName] = useState('');
  const [sourceType, setSourceType] = useState<'loan' | 'committee' | 'custom'>('custom');
  const [moduleId, setModuleId] = useState(snapshot.modules[0]?.id || '');
  const subs = snapshot.submodules.filter((s) => s.moduleId === moduleId);
  const [submoduleId, setSubmoduleId] = useState(subs[0]?.id || '');
  const activeSubId = subs.some((s) => s.id === submoduleId) ? submoduleId : subs[0]?.id || '';

  const availableFields = useMemo(() => {
    if (sourceType === 'loan') {
      return [
        { id: 'date', label: 'Date' },
        { id: 'personName', label: 'Person Name' },
        { id: 'type', label: 'Type' },
        { id: 'amount', label: 'Amount' },
        { id: 'paymentMethod', label: 'Method' },
        { id: 'transactionRef', label: 'Reference' },
        { id: 'remarks', label: 'Remarks' },
      ];
    }
    if (sourceType === 'committee') {
      return [
        { id: 'date', label: 'Date' },
        { id: 'committeeName', label: 'Committee' },
        { id: 'personName', label: 'Person Name' },
        { id: 'type', label: 'Direction' },
        { id: 'amount', label: 'Amount' },
        { id: 'paymentMethod', label: 'Method' },
        { id: 'remarks', label: 'Remarks' },
      ];
    }
    return snapshot.fields
      .filter((f) => f.submoduleId === activeSubId)
      .map((f) => ({ id: f.name, label: f.label }));
  }, [sourceType, snapshot.fields, activeSubId]);

  const [selectedFieldIds, setSelectedFieldIds] = useState<string[]>([]);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [groupBy, setGroupBy] = useState('');
  const [calculation, setCalculation] = useState<'none' | 'sum' | 'avg' | 'min' | 'max' | 'count'>('sum');
  const [status, setStatus] = useState<EntityStatus>('published');

  const toggleField = (id: string) => {
    setSelectedFieldIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveReport({
      id: editing?.id,
      name,
      sourceType,
      moduleId: sourceType === 'custom' ? moduleId : undefined,
      submoduleId: sourceType === 'custom' ? activeSubId : undefined,
      fieldIds: selectedFieldIds.length > 0 ? selectedFieldIds : availableFields.map((f) => f.id),
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      filters: [],
      sortBy: sortBy || undefined,
      sortDir,
      groupBy: groupBy || undefined,
      calculation,
      status,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save report', 'error');
      return;
    }
    notify(editing ? `Updated report "${name}"` : `Saved custom report "${name}"`);
    setEditing(null);
    setName('');
    setSelectedFieldIds([]);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSave} className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          Dynamic Reports Builder
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label htmlFor="rb-name" className="block text-xs font-semibold text-slate-700 mb-1">Report Name *</label>
            <input id="rb-name" type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Monthly Spend Summary" className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300" />
          </div>
          <div>
            <label htmlFor="rb-src" className="block text-xs font-semibold text-slate-700 mb-1">Data Source</label>
            <select id="rb-src" value={sourceType} onChange={(e) => { setSourceType(e.target.value as 'loan' | 'committee' | 'custom'); setSelectedFieldIds([]); }} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="custom">Custom Module</option>
              <option value="loan">Loan Management</option>
              <option value="committee">Committee Management</option>
            </select>
          </div>
          <div>
            <label htmlFor="rb-calc" className="block text-xs font-semibold text-slate-700 mb-1">Summary Calculation</label>
            <select id="rb-calc" value={calculation} onChange={(e) => setCalculation(e.target.value as typeof calculation)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="sum">SUM</option>
              <option value="avg">AVERAGE</option>
              <option value="min">MIN</option>
              <option value="max">MAX</option>
              <option value="count">COUNT</option>
              <option value="none">None</option>
            </select>
          </div>

          {sourceType === 'custom' && (
            <>
              <div>
                <label htmlFor="rb-mod" className="block text-xs font-semibold text-slate-700 mb-1">Module</label>
                <select id="rb-mod" value={moduleId} onChange={(e) => setModuleId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                  <option value="">Select Module...</option>
                  {snapshot.modules.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="rb-sub" className="block text-xs font-semibold text-slate-700 mb-1">Submodule</label>
                <select id="rb-sub" value={activeSubId} onChange={(e) => setSubmoduleId(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                  <option value="">Select Submodule...</option>
                  {subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </>
          )}

          <div>
            <label htmlFor="rb-status" className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
            <select id="rb-status" value={status} onChange={(e) => setStatus(e.target.value as EntityStatus)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>

          <div>
            <label htmlFor="rb-from" className="block text-xs font-semibold text-slate-700 mb-1">Date From</label>
            <input id="rb-from" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300" />
          </div>
          <div>
            <label htmlFor="rb-to" className="block text-xs font-semibold text-slate-700 mb-1">Date To</label>
            <input id="rb-to" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300" />
          </div>
          <div>
            <label htmlFor="rb-sort" className="block text-xs font-semibold text-slate-700 mb-1">Sort By</label>
            <div className="flex gap-2">
              <select id="rb-sort" value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="flex-1 px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                <option value="">Default</option>
                {availableFields.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
              </select>
              <select aria-label="Sort direction" value={sortDir} onChange={(e) => setSortDir(e.target.value as 'asc' | 'desc')} className="px-2 py-2 text-sm rounded-lg border border-slate-300 bg-white">
                <option value="desc">Desc</option>
                <option value="asc">Asc</option>
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="rb-group" className="block text-xs font-semibold text-slate-700 mb-1">Group By</label>
            <select id="rb-group" value={groupBy} onChange={(e) => setGroupBy(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white">
              <option value="">No Grouping</option>
              {availableFields.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
            </select>
          </div>
        </div>

        <div>
          <span className="block text-xs font-semibold text-slate-700 mb-1.5">Select Columns to Include</span>
          <div className="flex flex-wrap gap-2">
            {availableFields.map((f) => (
              <label key={f.id} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedFieldIds.includes(f.id)}
                  onChange={() => toggleField(f.id)}
                />
                <span>{f.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <button type="submit" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer">
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{editing ? 'Update Report' : 'Save Custom Report'}</span>
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <span className="font-display text-sm font-bold text-slate-900">Saved Custom Reports ({snapshot.reports.length})</span>
          <button type="button" onClick={() => setActiveRoute('reports')} className="text-xs font-semibold text-emerald-700 cursor-pointer">
            Open Reports Runner →
          </button>
        </div>
        {snapshot.reports.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No custom reports saved yet.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {snapshot.reports.map((r) => (
              <div key={r.id} className="p-4 flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-sm text-slate-900">{r.name}</div>
                  <div className="text-xs text-slate-500">
                    Source: {r.sourceType} · Calc: {r.calculation} · {r.status}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label={`Edit report ${r.name}`}
                    onClick={() => {
                      setEditing(r);
                      setName(r.name);
                      setSourceType(r.sourceType);
                      if (r.moduleId) setModuleId(r.moduleId);
                      if (r.submoduleId) setSubmoduleId(r.submoduleId);
                      setSelectedFieldIds(r.fieldIds);
                      setDateFrom(r.dateFrom || '');
                      setDateTo(r.dateTo || '');
                      setSortBy(r.sortBy || '');
                      setSortDir(r.sortDir);
                      setGroupBy(r.groupBy || '');
                      setCalculation(r.calculation);
                      setStatus(r.status);
                    }}
                    className="p-1.5 rounded text-slate-500 hover:bg-slate-100 cursor-pointer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete report ${r.name}`}
                    onClick={async () => {
                      await deleteReport(r.id);
                      notify(`Moved report "${r.name}" to Recycle Bin`);
                    }}
                    className="p-1.5 rounded text-red-500 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
