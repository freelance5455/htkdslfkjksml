import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Edit2,
  FlaskConical,
  Play,
  Rocket,
  XCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  checkGlobalCircularReferences,
  computeDashboardCardValue,
  formatMoney,
  runDynamicReport,
} from '../../engine/calculations';
import { evaluateFormula, validateFormulaSyntaxAndReferences } from '../../engine/formulaParser';
import type { CustomRecord } from '../../types/app';
import { DynamicFormRenderer } from '../DynamicFormRenderer';
import { DynamicIcon } from '../DynamicIcon';

interface PreviewAndTestPanelProps {
  onJumpToSection: (section: string) => void;
}

export const PreviewAndTestPanel: React.FC<PreviewAndTestPanelProps> = ({ onJumpToSection }) => {
  const {
    snapshot,
    saveModule,
    saveSubmodule,
    saveField,
    saveFormula,
    saveFieldMapping,
    saveDashboardCard,
    saveReport,
    notify,
  } = useApp();

  const [selectedModuleId, setSelectedModuleId] = useState(snapshot.modules[0]?.id || '');
  const subsForMod = useMemo(
    () => snapshot.submodules.filter((s) => s.moduleId === selectedModuleId),
    [snapshot.submodules, selectedModuleId]
  );
  const [selectedSubId, setSelectedSubId] = useState(subsForMod[0]?.id || '');
  const activeSubId = subsForMod.some((s) => s.id === selectedSubId)
    ? selectedSubId
    : subsForMod[0]?.id || '';

  // In-memory sandbox sample records (NEVER saved to IndexedDB!)
  const [sandboxRecords, setSandboxRecords] = useState<CustomRecord[]>([]);

  // Formula quick tester state
  const [testExpr, setTestExpr] = useState('Quantity * Rate');
  const [sampleQty, setSampleQty] = useState('10');
  const [sampleRate, setSampleRate] = useState('500');
  const [sampleExtraA, setSampleExtraA] = useState('100');

  const selectedMod = snapshot.modules.find((m) => m.id === selectedModuleId);
  const selectedSub = snapshot.submodules.find((s) => s.id === activeSubId);

  // Run comprehensive validation across Draft & Published configs
  const validationReport = useMemo(() => {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Check global circular references
    const cycle = checkGlobalCircularReferences(
      snapshot.fields,
      snapshot.formulas,
      snapshot.fieldMappings,
      snapshot.modules,
      snapshot.submodules
    );
    if (cycle.hasCycle) {
      errors.push(`Circular reference detected: ${cycle.cyclePath.join(' → ')}`);
    }

    // 2. Validate every formula field & formula definition
    for (const fm of snapshot.formulas) {
      const subFields = snapshot.fields.filter((f) => f.submoduleId === fm.submoduleId);
      const avail = [
        ...subFields.map((f) => f.name),
        ...snapshot.fields.map((f) => {
          const m = snapshot.modules.find((x) => x.id === f.moduleId);
          const s = snapshot.submodules.find((x) => x.id === f.submoduleId);
          return m && s ? `${m.name}.${s.name}.${f.name}` : f.name;
        }),
      ];
      const res = validateFormulaSyntaxAndReferences(fm.expression, avail);
      if (!res.valid) {
        errors.push(`Formula "${fm.name}": ${res.error}`);
      }
    }

    // 3. Validate field mappings
    for (const mp of snapshot.fieldMappings) {
      const srcExists = snapshot.fields.some((f) => f.id === mp.sourceFieldId);
      const dstExists = snapshot.fields.some((f) => f.id === mp.destFieldId);
      if (!srcExists || !dstExists) {
        errors.push(`Mapping "${mp.name}" references a missing source or destination field.`);
      }
    }

    // 4. Draft items count
    const draftCount =
      snapshot.modules.filter((m) => m.status === 'draft').length +
      snapshot.submodules.filter((s) => s.status === 'draft').length +
      snapshot.fields.filter((f) => f.status === 'draft').length +
      snapshot.formulas.filter((f) => f.status === 'draft').length +
      snapshot.fieldMappings.filter((m) => m.status === 'draft').length +
      snapshot.dashboardCards.filter((c) => c.status === 'draft').length +
      snapshot.reports.filter((r) => r.status === 'draft').length;

    if (snapshot.modules.length === 0) {
      warnings.push('No custom modules created yet. Create a module first to preview forms.');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      draftCount,
    };
  }, [snapshot]);

  // Live Formula Sandbox Output
  const formulaSandboxResult = useMemo(() => {
    return evaluateFormula(testExpr, {
      Quantity: Number(sampleQty) || 0,
      Rate: Number(sampleRate) || 0,
      A: Number(sampleExtraA) || 0,
      Amount: Number(sampleQty) * Number(sampleRate) || 0,
    });
  }, [testExpr, sampleQty, sampleRate, sampleExtraA]);

  // Publish all validated draft configurations
  const handlePublishAll = async () => {
    if (!validationReport.isValid) {
      notify('Cannot publish while validation errors exist. Fix errors shown below first.', 'error');
      return;
    }
    for (const m of snapshot.modules.filter((x) => x.status === 'draft')) {
      await saveModule({ ...m, status: 'published' });
    }
    for (const s of snapshot.submodules.filter((x) => x.status === 'draft')) {
      await saveSubmodule({ ...s, status: 'published' });
    }
    for (const f of snapshot.fields.filter((x) => x.status === 'draft')) {
      await saveField({ ...f, status: 'published' });
    }
    for (const fm of snapshot.formulas.filter((x) => x.status === 'draft')) {
      await saveFormula({ ...fm, status: 'published' });
    }
    for (const mp of snapshot.fieldMappings.filter((x) => x.status === 'draft')) {
      await saveFieldMapping({ ...mp, status: 'published' });
    }
    for (const c of snapshot.dashboardCards.filter((x) => x.status === 'draft')) {
      await saveDashboardCard({ ...c, status: 'published' });
    }
    for (const r of snapshot.reports.filter((x) => x.status === 'draft')) {
      await saveReport({ ...r, status: 'published' });
    }
    notify('All validated draft configurations published and activated!');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner + Validation Gate */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <FlaskConical className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-slate-900">
                Preview &amp; Test Sandbox
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Test modules, forms, formulas, mappings, master lists, dashboard cards, and reports with sample data. Real IndexedDB financial records are never modified here.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setSandboxRecords([]);
                notify('Sandbox sample data cleared', 'info');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Reset Sandbox</span>
            </button>
            <button
              type="button"
              onClick={handlePublishAll}
              disabled={!validationReport.isValid}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
            >
              <Rocket className="w-3.5 h-3.5" aria-hidden="true" />
              <span>
                Activate / Publish {validationReport.draftCount > 0 ? `(${validationReport.draftCount} Drafts)` : 'All'}
              </span>
            </button>
          </div>
        </div>

        {/* Validation Summary */}
        {validationReport.isValid ? (
          <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3.5 flex items-center gap-2.5 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
            <span>
              Validation passed: Zero circular formulas, zero broken field mappings, and all field references are valid.
            </span>
          </div>
        ) : (
          <div className="rounded-lg bg-red-50 border border-red-200 p-4 space-y-1.5 text-xs text-red-800">
            <div className="font-bold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" aria-hidden="true" />
              <span>Validation Errors Found — Publishing Blocked</span>
            </div>
            <ul className="list-disc pl-5 space-y-1">
              {validationReport.errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* 1. Interactive Module & Form Sandbox */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <h4 className="font-display text-sm font-bold text-slate-900">
            1. Preview Module, Submodule &amp; Test Data-Entry Form
          </h4>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => onJumpToSection('modules')} className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:underline cursor-pointer">
              <Edit2 className="w-3 h-3" /> Edit Modules
            </button>
            <button type="button" onClick={() => onJumpToSection('fields')} className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:underline cursor-pointer">
              <Edit2 className="w-3 h-3" /> Edit Fields
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="prev-mod" className="block text-xs font-semibold text-slate-700 mb-1">
              Preview Module (Includes Drafts)
            </label>
            <select
              id="prev-mod"
              value={selectedModuleId}
              onChange={(e) => setSelectedModuleId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Module...</option>
              {snapshot.modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.status})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="prev-sub" className="block text-xs font-semibold text-slate-700 mb-1">
              Preview Submodule
            </label>
            <select
              id="prev-sub"
              value={activeSubId}
              onChange={(e) => setSelectedSubId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Select Submodule...</option>
              {subsForMod.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.status})
                </option>
              ))}
            </select>
          </div>
        </div>

        {selectedMod && (
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white" style={{ backgroundColor: selectedMod.color }}>
              <DynamicIcon name={selectedMod.icon} className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">
                {selectedMod.name} {selectedSub ? `→ ${selectedSub.name}` : ''}
              </div>
              <div className="text-xs text-slate-500">
                {selectedMod.status.toUpperCase()} preview · {sandboxRecords.filter((r) => r.submoduleId === activeSubId).length} sample test record(s) in sandbox
              </div>
            </div>
          </div>
        )}

        {activeSubId && (
          <DynamicFormRenderer
            submoduleId={activeSubId}
            fields={snapshot.fields}
            formulas={snapshot.formulas}
            mappings={snapshot.fieldMappings}
            masterLists={snapshot.masterLists}
            allRecords={[...snapshot.customRecords, ...sandboxRecords]}
            modules={snapshot.modules}
            submodules={snapshot.submodules}
            currency={snapshot.settings.currency}
            submitLabel="Test Sample Entry (Sandbox Only)"
            sandboxNotice="Sandbox Mode: Submitting here calculates formulas & mappings and stores the test entry in temporary memory only."
            onSubmit={(values) => {
              const sampleRec: CustomRecord = {
                id: `sample_${Date.now()}`,
                moduleId: selectedModuleId,
                submoduleId: activeSubId,
                values,
                archived: false,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              };
              setSandboxRecords((prev) => [...prev, sampleRec]);
              notify('Sample test record evaluated in Sandbox (real database untouched)', 'info');
            }}
          />
        )}
      </div>

      {/* 2. Interactive Formula & Cell Mapping Tester */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h4 className="font-display text-sm font-bold text-slate-900">
            2. Formula &amp; Sample Value Tester
          </h4>
          <button type="button" onClick={() => onJumpToSection('formulas')} className="text-xs font-medium text-emerald-700 hover:underline cursor-pointer">
            Open Formula Builder
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div>
            <label htmlFor="test-qty" className="block text-xs font-semibold text-slate-700 mb-1">Sample Quantity</label>
            <input id="test-qty" type="number" value={sampleQty} onChange={(e) => setSampleQty(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num" />
          </div>
          <div>
            <label htmlFor="test-rate" className="block text-xs font-semibold text-slate-700 mb-1">Sample Rate</label>
            <input id="test-rate" type="number" value={sampleRate} onChange={(e) => setSampleRate(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num" />
          </div>
          <div>
            <label htmlFor="test-a" className="block text-xs font-semibold text-slate-700 mb-1">Sample Cell A</label>
            <input id="test-a" type="number" value={sampleExtraA} onChange={(e) => setSampleExtraA(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num" />
          </div>
          <div>
            <label htmlFor="test-expr" className="block text-xs font-semibold text-slate-700 mb-1">Test Expression</label>
            <input id="test-expr" type="text" value={testExpr} onChange={(e) => setTestExpr(e.target.value)} className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono" />
          </div>
        </div>

        <div
          className={`rounded-lg p-3.5 flex items-center justify-between text-sm ${
            formulaSandboxResult.ok
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
              : 'bg-red-50 border border-red-200 text-red-800'
          }`}
        >
          <span className="font-medium flex items-center gap-2">
            <Play className="w-4 h-4" aria-hidden="true" />
            {formulaSandboxResult.ok ? 'Calculated Result:' : 'Formula Error:'}
          </span>
          <span className="font-mono-num font-bold">
            {formulaSandboxResult.ok ? String(formulaSandboxResult.value) : formulaSandboxResult.error}
          </span>
        </div>
      </div>

      {/* 3. Preview Dashboard Cards (including Drafts & Sandbox values) */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h4 className="font-display text-sm font-bold text-slate-900">
            3. Preview Dashboard Cards (With Sandbox Samples)
          </h4>
          <button type="button" onClick={() => onJumpToSection('cards')} className="text-xs font-medium text-emerald-700 hover:underline cursor-pointer">
            Edit Cards
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {snapshot.dashboardCards.map((card) => {
            const res = computeDashboardCardValue({
              card,
              loanPersons: snapshot.loanPersons,
              loanTransactions: snapshot.loanTransactions,
              committees: snapshot.committees,
              committeeTransactions: snapshot.committeeTransactions,
              customRecords: [...snapshot.customRecords, ...sandboxRecords],
              fields: snapshot.fields,
            });
            return (
              <div key={card.id} className="rounded-lg border border-slate-200 p-3.5 bg-slate-50">
                <div className="text-xs text-slate-500 flex items-center justify-between">
                  <span className="truncate">{card.title}</span>
                  <span>{card.status}</span>
                </div>
                <div className="mt-1 font-mono-num text-lg font-bold text-slate-900">
                  {card.calculation === 'count' ? res.value : formatMoney(res.value, snapshot.settings)}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">{res.formattedHint}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Preview Reports */}
      {snapshot.reports.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h4 className="font-display text-sm font-bold text-slate-900">
            4. Custom Reports Preview ({snapshot.reports.length})
          </h4>
          {snapshot.reports.slice(0, 2).map((rep) => {
            const out = runDynamicReport({
              report: rep,
              loanPersons: snapshot.loanPersons,
              loanTransactions: snapshot.loanTransactions,
              committees: snapshot.committees,
              committeeTransactions: snapshot.committeeTransactions,
              customRecords: [...snapshot.customRecords, ...sandboxRecords],
              fields: snapshot.fields,
            });
            return (
              <div key={rep.id} className="rounded-lg border border-slate-200 p-3 text-xs">
                <div className="font-bold text-slate-900">
                  {rep.name} ({rep.status}) — {out.rows.length} row(s), Aggregate:{' '}
                  <span className="font-mono-num text-emerald-700">{out.totalAggregate}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
