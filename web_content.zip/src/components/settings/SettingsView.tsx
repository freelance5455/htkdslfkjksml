import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  Download,
  Upload,
  RotateCcw,
  Bell,
  Volume2,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Cloud,
  Smartphone,
  Mail,
  RefreshCw,
} from 'lucide-react';
import { requestBrowserNotificationPermission } from '../../utils/notifications';

interface SettingsViewProps {
  onOpenAuth?: () => void;
  onOpenApkModal?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenAuth, onOpenApkModal }) => {
  const {
    currentUser,
    isSyncing,
    lastSyncTime,
    triggerManualSync,
    studyPreferences,
    updateStudyPreferences,
    prayerSettings,
    updatePrayerSettings,
    exportDataJSON,
    importDataJSON,
    resetToDemoData,
  } = useApp();

  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [notificationPermStatus, setNotificationPermStatus] = useState<string | null>(null);
  const [resetConfirm, setResetConfirm] = useState(false);

  // Export handler
  const handleExport = () => {
    const jsonStr = exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `my_smart_day_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Import handler
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDataJSON(content);
      if (success) {
        setImportStatus('تمت استعادة البيانات والجدول بنجاح!');
      } else {
        setImportStatus('خطأ في صيغة ملف النسخة الاحتياطية.');
      }
      setTimeout(() => setImportStatus(null), 4000);
    };
    reader.readAsText(file);
  };

  const handleRequestNotifications = async () => {
    const granted = await requestBrowserNotificationPermission();
    if (granted) {
      setNotificationPermStatus('تم تفعيل إشعارات المتصفح بنجاح!');
    } else {
      setNotificationPermStatus('تم رفض أو تعطيل إذن الإشعارات من المتصفح.');
    }
    setTimeout(() => setNotificationPermStatus(null), 4000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Title */}
      <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div className="flex items-center gap-2">
          <Settings className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          <h2 className="text-xl font-bold text-slate-900 dark:text-rose-50">
            الإعدادات وتخصيص النظام
          </h2>
        </div>
        <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-1">
          تخصيص أوقات الدراسة، إعدادات التنبيهات، والنسخ الاحتياطي لبياناتك المحلية
        </p>
      </div>

      {/* Cloud & Email Sync Card */}
      <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-200/80 dark:border-rose-900/60 transition-colors shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-500 to-pink-500 flex items-center justify-center text-white shrink-0 shadow-sm shadow-rose-500/25">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900 dark:text-rose-50">
                  ربط الحساب بالميل والمزامنة السحابية
                </h3>
                {currentUser && (
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 px-2 py-0.5 rounded-full">
                    متصل
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-1 leading-relaxed">
                {currentUser
                  ? `الحساب المرتبط: ${currentUser.email} • يتم حفظ بياناتك ومزامنتها تلقائياً مع السحابة.`
                  : 'اربط بريدك الإلكتروني للحفاظ على جدولك وموادك ومواعيد أدويتك في أمان ومزامنتها تلقائياً أياً كان الجهاز المستخدم.'}
              </p>
              {lastSyncTime && (
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                  آخر مزامنة ناجحة: {lastSyncTime}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            {currentUser && (
              <button
                onClick={triggerManualSync}
                disabled={isSyncing}
                className="px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-1.5 transition disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'مزامنة...' : 'مزامنة الآن'}</span>
              </button>
            )}

            <button
              onClick={onOpenAuth}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white text-xs font-bold shadow-sm shadow-rose-500/20 transition flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{currentUser ? 'إدارة الحساب' : 'ربط الحساب بالميل'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Android Phone & APK Card */}
      <div className="bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-transparent p-5 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/60 transition-colors shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shrink-0 shadow-sm shadow-emerald-500/25">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900 dark:text-rose-50">
                  تطبيق أندرويد وتجميع ملف APK
                </h3>
                <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                  Android APK
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-rose-200/80 mt-1 leading-relaxed">
                تطبيق متوافق 100% مع هواتف أندرويد: شريط تنقل سفلي، دعم العمل بدون إنترنت، وتثبيت فوري كـ WebAPK أو تنزيل حزمة التثبيت.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenApkModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-sm shadow-emerald-600/20 transition flex items-center gap-1.5 shrink-0 self-end sm:self-center"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>تنزيل وتثبيت APK</span>
          </button>
        </div>
      </div>

      {/* Rose Theme Visual Showcase */}
      <div className="relative overflow-hidden rounded-2xl border border-rose-200/80 dark:border-rose-900/60 p-5 shadow-xs bg-gradient-to-r from-rose-500/10 via-pink-500/10 to-rose-400/10 dark:from-rose-950/40 dark:to-[#1a0f18]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <img
              src="/public/assets/aistudio/images_5d51feea.jpg"
              alt="Rose Theme Palette"
              className="w-14 h-14 rounded-xl object-cover ring-2 ring-rose-400/60 shadow-md shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-900 dark:text-rose-50">
                  ثيم باقة الورد الوردي الفاخر (Rose Floral Palette)
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-600 text-white">
                  نشط الآن
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-0.5">
                مستوحى من درجات زهور الورد الجوري الوردي، الأحمر القاني، والوردي المخملي المتناغم
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 self-start sm:self-auto">
            <span className="w-5 h-5 rounded-full bg-[#e11d48] border border-white/50 shadow-xs" title="Rose Red #E11D48" />
            <span className="w-5 h-5 rounded-full bg-[#f43f5e] border border-white/50 shadow-xs" title="Coral Rose #F43F5E" />
            <span className="w-5 h-5 rounded-full bg-[#db2777] border border-white/50 shadow-xs" title="Rose Pink #DB2777" />
            <span className="w-5 h-5 rounded-full bg-[#be185d] border border-white/50 shadow-xs" title="Deep Rose #BE185D" />
            <span className="w-5 h-5 rounded-full bg-[#9d174d] border border-white/50 shadow-xs" title="Velvet Plum #9D174D" />
          </div>
        </div>
      </div>

      {/* Notifications and Audio Settings */}
      <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 space-y-4 shadow-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 pb-3 border-b border-rose-50 dark:border-rose-950/50 flex items-center gap-2">
          <Bell className="w-4 h-4 text-rose-600" />
          <span>تنبيهات المتصفح والتنبيه الصوتي</span>
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-rose-50/30 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/40">
            <div>
              <div className="font-semibold text-slate-900 dark:text-rose-100">
                إشعارات سطح المكتب والهاتف (Web Push Notifications)
              </div>
              <p className="text-slate-500 dark:text-rose-200/70 mt-0.5">
                تلقي إشعارات بمواعيد المحاضرات، وتناول الدواء، ودخول وقت الصلاة، وجلسات المذاكرة
              </p>
            </div>

            <button
              onClick={handleRequestNotifications}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold shrink-0 transition-colors self-start sm:self-auto shadow-xs"
            >
              تفعيل إشعارات المتصفح
            </button>
          </div>

          {notificationPermStatus && (
            <div className="text-rose-700 dark:text-rose-300 font-semibold text-xs">
              ✓ {notificationPermStatus}
            </div>
          )}
        </div>
      </div>

      {/* Study Preferences Section */}
      <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 space-y-4 shadow-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 pb-3 border-b border-rose-50 dark:border-rose-950/50 flex items-center gap-2">
          <Clock className="w-4 h-4 text-rose-600" />
          <span>تفضيلات جدول المذاكرة الافتراضية</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
              الهدف اليومي لساعات المذاكرة
            </label>
            <input
              type="number"
              min={1}
              max={14}
              value={studyPreferences.dailyTargetHours}
              onChange={(e) => updateStudyPreferences({ dailyTargetHours: Number(e.target.value) })}
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
              مدة جلسة الاستذكار الافتراضية (دقائق)
            </label>
            <select
              value={studyPreferences.defaultSessionDuration}
              onChange={(e) =>
                updateStudyPreferences({ defaultSessionDuration: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
            >
              <option value={25}>25 دقيقة (بومودورو)</option>
              <option value={45}>45 دقيقة (الموصى بها)</option>
              <option value={60}>60 دقيقة</option>
              <option value={90}>90 دقيقة</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
              مدة الاستراحة بين الجلسات
            </label>
            <select
              value={studyPreferences.defaultBreakDuration}
              onChange={(e) =>
                updateStudyPreferences({ defaultBreakDuration: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
            >
              <option value={5}>5 دقائق</option>
              <option value={10}>10 دقائق</option>
              <option value={15}>15 دقيقة</option>
              <option value={20}>20 دقيقة</option>
            </select>
          </div>
        </div>
      </div>

      {/* Backup, Export & Reset Section */}
      <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 space-y-4 shadow-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 pb-3 border-b border-rose-50 dark:border-rose-950/50 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-rose-600" />
          <span>النسخ الاحتياطي وحفظ البيانات (Data Backup & Restore)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Export Box */}
          <div className="p-4 rounded-xl border border-rose-100 dark:border-rose-900/40 bg-rose-50/20 dark:bg-rose-950/20 space-y-2.5">
            <div className="font-semibold text-slate-900 dark:text-rose-100">
              تصدير نسخة احتياطية كاملة (JSON)
            </div>
            <p className="text-slate-500 dark:text-rose-200/70 leading-relaxed">
              قم بتنزيل كافة بياناتك وموادك وجدولك وأدويتك في ملف مشفر محلياً لحمايتها من الضياع.
            </p>
            <button
              onClick={handleExport}
              className="px-4 py-2 rounded-xl bg-rose-950 dark:bg-rose-900 text-white font-semibold hover:bg-rose-900 dark:hover:bg-rose-800 transition-colors inline-flex items-center gap-1.5 shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل ملف النسخة الاحتياطية</span>
            </button>
          </div>

          {/* Import Box */}
          <div className="p-4 rounded-xl border border-rose-100 dark:border-rose-900/40 bg-rose-50/20 dark:bg-rose-950/20 space-y-2.5">
            <div className="font-semibold text-slate-900 dark:text-rose-100">
              استيراد واستعادة من ملف (JSON)
            </div>
            <p className="text-slate-500 dark:text-rose-200/70 leading-relaxed">
              اختر ملف نسخة احتياطية محفوظ سابقاً لاستعادة جميع المواد والجداول فوراً.
            </p>
            <label className="px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-800/80 hover:bg-rose-50 dark:hover:bg-rose-950/40 font-semibold cursor-pointer inline-flex items-center gap-1.5 text-slate-700 dark:text-rose-200">
              <Upload className="w-3.5 h-3.5" />
              <span>اختر ملف الاستعادة</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>
          </div>
        </div>

        {importStatus && (
          <div className="text-rose-700 dark:text-rose-300 font-semibold text-xs">
            ✓ {importStatus}
          </div>
        )}

        {/* Reset to Demo Data */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="font-semibold text-xs text-rose-700 dark:text-rose-400">
              إعادة تعيين إلى البيانات النموذجية الأولية
            </div>
            <p className="text-[11px] text-slate-400">
              سيعيد هذا ضبط الجدول والمواد والأدوية إلى النموذج التوضيحي الأصلي.
            </p>
          </div>

          {resetConfirm ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  resetToDemoData();
                  setResetConfirm(false);
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold"
              >
                تأكيد الاستعادة
              </button>
              <button
                onClick={() => setResetConfirm(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs text-slate-600 dark:text-slate-300"
              >
                إلغاء
              </button>
            </div>
          ) : (
            <button
              onClick={() => setResetConfirm(true)}
              className="px-3 py-1.5 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>استعادة النموذج التجريبي</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
