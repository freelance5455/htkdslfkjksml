import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  Eye,
  Star,
  Database,
  Shield,
  Info,
  LogOut,
  ChevronRight,
  Moon,
  Lock,
  Palette,
  Trash2,
  ExternalLink,
  Code,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { useLock } from '../../contexts/LockContext';
import { AppTheme } from '../../types';
import { StarredMessagesModal } from '../chat/StarredMessagesModal';
import { SetupWizardModal } from '../common/SetupWizardModal';
import { ConfirmationDialog } from '../common/ConfirmationDialog';
import { NEXA_DATABASE_MIGRATION_SQL } from '../../lib/migration-sql';

export const SettingsView: React.FC = () => {
  const { logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const { isLockEnabled, enableLock, disableLock, lockNow, autoLockMinutes, setAutoLockMinutes } = useLock();

  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [lastSeenPrivacy, setLastSeenPrivacy] = useState<'everyone' | 'friends' | 'nobody'>('friends');
  const [isStarredModalOpen, setIsStarredModalOpen] = useState(false);
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isSqlModalOpen, setIsSqlModalOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // App Lock PIN input states
  const [isSettingPin, setIsSettingPin] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const themes: { id: AppTheme; label: string; desc: string; bg: string }[] = [
    { id: 'dark', label: 'Dark Obsidian', desc: 'Sleek dark gray palette', bg: '#171717' },
    { id: 'amoled', label: 'AMOLED Black', desc: 'Pure #000000 true black', bg: '#000000' },
    { id: 'light', label: 'Clean Light', desc: 'Crisp high-contrast day mode', bg: '#f8fafc' },
    { id: 'blue', label: 'Midnight Blue', desc: 'Deep sapphire navy accents', bg: '#0f172a' },
    { id: 'purple', label: 'Amethyst Twilight', desc: 'Rich violet ambient glow', bg: '#1e1035' },
  ];

  const handleSavePin = async () => {
    if (pinInput.length < 4) {
      setPinError('PIN must be at least 4 digits');
      return;
    }

    if (isLockEnabled) {
      const ok = await disableLock(pinInput);
      if (!ok) {
        setPinError('Incorrect current PIN');
        return;
      }
      setIsSettingPin(false);
      setPinInput('');
      setPinError('');
    } else {
      await enableLock(pinInput);
      setIsSettingPin(false);
      setPinInput('');
      setPinError('');
    }
  };

  const handleClearCache = () => {
    try {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && !key.startsWith('sb-') && !key.startsWith('nexa_app_lock')) {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
      alert('Local cache and temporary data cleared.');
    } catch {
      alert('Failed to clear cache.');
    }
  };

  const copySql = () => {
    navigator.clipboard.writeText(NEXA_DATABASE_MIGRATION_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div id="settings-view-container" className="h-full flex flex-col bg-neutral-900 text-white select-none overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-950/40">
        <h2 className="text-lg font-bold text-white">Settings & Privacy</h2>
        <p className="text-xs text-neutral-400">Security, themes, notifications, and preferences</p>
      </div>

      <div className="p-6 max-w-lg mx-auto w-full space-y-6">
        {/* Appearance & Themes */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
            Appearance & Themes (5 Themes)
          </h3>
          <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-3 grid grid-cols-1 gap-2">
            {themes.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTheme(t.id)}
                className={`p-3 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                  theme === t.id
                    ? 'border-emerald-500 bg-emerald-950/20 shadow-sm shadow-emerald-500/10'
                    : 'border-neutral-800 hover:bg-neutral-900/60'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div
                    className="w-7 h-7 rounded-lg border border-white/20 shrink-0"
                    style={{ backgroundColor: t.bg }}
                  />
                  <div>
                    <p className="text-xs font-semibold text-neutral-200">{t.label}</p>
                    <p className="text-[10px] text-neutral-400">{t.desc}</p>
                  </div>
                </div>
                {theme === t.id && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Active
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* App Lock & Security */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
            App Security & Privacy
          </h3>
          <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl divide-y divide-neutral-800/60 overflow-hidden">
            {/* PIN Lock Toggle */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Lock className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">App Lock (PIN / Biometrics)</p>
                  <p className="text-[11px] text-neutral-500">
                    {isLockEnabled ? 'PIN lock is active' : 'Require PIN code to open Nexa'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsSettingPin(true);
                  setPinInput('');
                  setPinError('');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                  isLockEnabled
                    ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                {isLockEnabled ? 'Change / Disable' : 'Set Up PIN'}
              </button>
            </div>

            {/* If enabled: Auto Lock Timeout */}
            {isLockEnabled && (
              <>
                <div className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-neutral-200">Auto-lock after</p>
                    <p className="text-[11px] text-neutral-500">Inactivity timeout duration</p>
                  </div>
                  <select
                    value={autoLockMinutes}
                    onChange={(e) => setAutoLockMinutes(parseInt(e.target.value, 10))}
                    className="bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none"
                  >
                    <option value="1">1 minute</option>
                    <option value="5">5 minutes</option>
                    <option value="15">15 minutes</option>
                    <option value="30">30 minutes</option>
                  </select>
                </div>

                <div className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-neutral-200">Lock Immediately</p>
                    <p className="text-[11px] text-neutral-500">Lock app now</p>
                  </div>
                  <button
                    type="button"
                    onClick={lockNow}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded-xl font-medium"
                  >
                    Lock Now
                  </button>
                </div>
              </>
            )}

            {/* Read Receipts */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CheckCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">Read Receipts</p>
                  <p className="text-[11px] text-neutral-500">Send double checkmarks when messages are read</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReadReceipts(!readReceipts)}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  readReceipts ? 'bg-emerald-600' : 'bg-neutral-800'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    readReceipts ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            {/* Last Seen Privacy */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Eye className="w-5 h-5 text-cyan-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">Who can see when I'm online</p>
                  <p className="text-[11px] text-neutral-500">Realtime presence indicator</p>
                </div>
              </div>
              <select
                value={lastSeenPrivacy}
                onChange={(e: any) => setLastSeenPrivacy(e.target.value)}
                className="bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none"
              >
                <option value="everyone">Everyone</option>
                <option value="friends">Friends Only</option>
                <option value="nobody">Nobody</option>
              </select>
            </div>

            {/* Starred Messages */}
            <button
              onClick={() => setIsStarredModalOpen(true)}
              className="w-full p-4 flex items-center justify-between hover:bg-neutral-800/40 text-left transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Star className="w-5 h-5 text-amber-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">Starred Messages</p>
                  <p className="text-[11px] text-neutral-500">View all bookmarked messages</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
            Notifications
          </h3>
          <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5 text-emerald-400" />
              <div>
                <p className="text-xs font-semibold text-neutral-200">Message & Call Alerts</p>
                <p className="text-[11px] text-neutral-500">Play sounds and desktop alerts for incoming calls</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                notificationsEnabled ? 'bg-emerald-600' : 'bg-neutral-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  notificationsEnabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Storage & Cache */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
            Storage & Data
          </h3>
          <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Trash2 className="w-5 h-5 text-neutral-400" />
              <div>
                <p className="text-xs font-semibold text-neutral-200">Clear Cache & Local Storage</p>
                <p className="text-[11px] text-neutral-500">Free up device storage</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleClearCache}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded-xl font-medium transition-colors"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Database & Infrastructure */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
            Infrastructure & Setup
          </h3>
          <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl divide-y divide-neutral-800/60 overflow-hidden">
            <button
              onClick={() => setIsWizardOpen(true)}
              className="w-full p-4 flex items-center justify-between hover:bg-neutral-800/40 text-left transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Database className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">Supabase Connection Settings</p>
                  <p className="text-[11px] text-neutral-500">Configure or re-connect your Supabase credentials</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </button>

            <button
              onClick={() => setIsSqlModalOpen(true)}
              className="w-full p-4 flex items-center justify-between hover:bg-neutral-800/40 text-left transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Code className="w-5 h-5 text-purple-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-200">View SQL Migration Schema</p>
                  <p className="text-[11px] text-neutral-500">Copy database tables, triggers & RLS policies</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </button>
          </div>
        </div>

        {/* About Nexa */}
        <div className="p-4 bg-neutral-950/40 border border-neutral-800/80 rounded-2xl space-y-2 text-xs text-neutral-400">
          <div className="flex items-center space-x-2 text-neutral-200 font-semibold">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Nexa Secure Messenger v1.0</span>
          </div>
          <p className="text-[11px] text-neutral-500 leading-relaxed">
            Nexa delivers private 1-to-1 & group realtime messaging, status stories, voice notes, stickers, and encrypted peer-to-peer WebRTC voice & video calls.
          </p>
        </div>

        {/* Logout */}
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full p-3.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold text-xs rounded-2xl border border-red-500/20 flex items-center justify-center space-x-2 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out of Nexa</span>
        </button>
      </div>

      {/* Set / Change PIN Modal */}
      {isSettingPin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-2xl p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold mb-1">
              {isLockEnabled ? 'Change / Disable App Lock' : 'Create Security PIN'}
            </h3>
            <p className="text-xs text-neutral-400 mb-4">
              {isLockEnabled
                ? 'Enter your current PIN to disable or change it.'
                : 'Enter a 4-6 digit numeric PIN to protect Nexa.'}
            </p>

            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
              placeholder="Enter PIN..."
              className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 rounded-xl text-center text-xl tracking-widest font-mono text-white focus:outline-none focus:border-emerald-500"
              autoFocus
            />

            {pinError && <p className="text-xs text-red-400 mt-2 text-center">{pinError}</p>}

            <div className="flex items-center space-x-2 mt-5">
              <button
                type="button"
                onClick={() => {
                  setIsSettingPin(false);
                  setPinInput('');
                  setPinError('');
                }}
                className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSavePin}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-950/40"
              >
                {isLockEnabled ? 'Confirm / Remove' : 'Save PIN'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Starred Messages Modal */}
      <StarredMessagesModal
        isOpen={isStarredModalOpen}
        onClose={() => setIsStarredModalOpen(false)}
      />

      {/* Setup Wizard */}
      <SetupWizardModal
        isOpen={isWizardOpen}
        onClose={() => setIsWizardOpen(false)}
      />

      {/* SQL Migration Modal */}
      {isSqlModalOpen && (
        <div
          id="sql-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
        >
          <div className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl flex flex-col max-h-[85vh] text-white overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
              <h3 className="text-sm font-semibold">Supabase Migration SQL</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={copySql}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium"
                >
                  {copiedSql ? 'Copied!' : 'Copy SQL'}
                </button>
                <button
                  onClick={() => setIsSqlModalOpen(false)}
                  className="px-3 py-1 bg-neutral-800 text-neutral-300 rounded-lg text-xs"
                >
                  Close
                </button>
              </div>
            </div>
            <pre className="flex-1 overflow-auto p-4 text-[11px] font-mono text-neutral-300 bg-neutral-950">
              {NEXA_DATABASE_MIGRATION_SQL}
            </pre>
          </div>
        </div>
      )}

      {/* Logout Confirmation */}
      <ConfirmationDialog
        isOpen={showLogoutConfirm}
        title="Sign Out"
        message="Are you sure you want to sign out of this device?"
        confirmLabel="Sign Out"
        onConfirm={async () => {
          setShowLogoutConfirm(false);
          await logout();
        }}
        onCancel={() => setShowLogoutConfirm(false)}
      />
    </div>
  );
};
