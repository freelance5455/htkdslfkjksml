import React, { useRef, useState } from 'react';
import { AppSettings, AppTheme, ShelfViewMode, SortOption, ReaderProgressMode } from '../../types';
import { LED_PRESET_COLORS } from '../../constants/reactions';
import {
  X,
  Moon,
  Sun,
  Laptop,
  Zap,
  Sliders,
  BookOpen,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Check,
  AlertCircle,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onExportBackup: () => Promise<void>;
  onImportBackup: (jsonContent: string, mode?: 'merge' | 'replace') => Promise<boolean>;
  onClearAllData: () => Promise<void>;
  onRestoreSampleData: () => Promise<void>;
  onOpenBackupModal?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onExportBackup,
  onImportBackup,
  onClearAllData,
  onRestoreSampleData,
  onOpenBackupModal,
}) => {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleThemeChange = (theme: AppTheme) => {
    onUpdateSettings({ ...settings, theme });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const text = event.target?.result as string;
        try {
          const success = await onImportBackup(text);
          if (success) {
            setImportStatus('Copia de seguridad restaurada correctamente.');
            setTimeout(() => setImportStatus(null), 3000);
          } else {
            setImportStatus('Error: Archivo de copia no válido.');
          }
        } catch {
          setImportStatus('Error al leer el archivo.');
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-2xl glass-panel rounded-3xl p-5 sm:p-8 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <h2 className="text-base sm:text-lg font-bold text-white font-['Syne']">
              Configuración de la Aplicación
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-4 space-y-6 text-xs divide-y divide-white/10">
          {/* 1. APARIENCIA & TEMA (Section 52, 53, 54) */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-2">
              <Sun className="w-4 h-4 text-zinc-300" />
              <span>Apariencia y Tema</span>
            </h3>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleThemeChange('dark')}
                className={`py-3 px-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                  settings.theme === 'dark'
                    ? 'bg-white/15 border-white/30 text-white font-semibold shadow-sm'
                    : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <Moon className="w-5 h-5" />
                <span>Oscuro Glass</span>
              </button>

              <button
                type="button"
                onClick={() => handleThemeChange('light')}
                className={`py-3 px-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                  settings.theme === 'light'
                    ? 'bg-white/15 border-white/30 text-white font-semibold shadow-sm'
                    : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <Sun className="w-5 h-5" />
                <span>Claro Glass</span>
              </button>

              <button
                type="button"
                onClick={() => handleThemeChange('auto')}
                className={`py-3 px-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                  settings.theme === 'auto'
                    ? 'bg-white/15 border-white/30 text-white font-semibold shadow-sm'
                    : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <Laptop className="w-5 h-5" />
                <span>Automático</span>
              </button>
            </div>

            {/* Requisito 15: COLOR PERSONALIZABLE DEL SISTEMA */}
            <div className="pt-3 border-t border-white/[0.06] space-y-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-zinc-200 font-semibold block text-xs">
                    Color del sistema (Acento)
                  </label>
                  <span className="text-[11px] text-zinc-400 block mt-0.5">
                    Se aplica a botones seleccionados, indicadores, iconos activos y barras de progreso sin alterar el fondo oscuro.
                  </span>
                </div>
                <div
                  className="w-5 h-5 rounded-full border border-white/40 shadow-sm shrink-0"
                  style={{ backgroundColor: settings.systemAccentColor || '#06b6d4' }}
                />
              </div>

              <div className="flex items-center gap-2 flex-wrap pt-1">
                {[
                  { id: 'cyan', hex: '#06b6d4', label: 'Cian' },
                  { id: 'gold', hex: '#f59e0b', label: 'Dorado' },
                  { id: 'emerald', hex: '#10b981', label: 'Esmeralda' },
                  { id: 'purple', hex: '#a855f7', label: 'Morado' },
                  { id: 'rose', hex: '#ec4899', label: 'Rosa' },
                  { id: 'blue', hex: '#3b82f6', label: 'Azul' },
                  { id: 'wine', hex: '#e11d48', label: 'Rojo' },
                  { id: 'white', hex: '#ffffff', label: 'Blanco' },
                ].map((c) => {
                  const isSelected = (settings.systemAccentColor || '#06b6d4').toLowerCase() === c.hex.toLowerCase();
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ ...settings, systemAccentColor: c.hex })
                      }
                      title={c.label}
                      className={`w-7 h-7 rounded-full border transition-all ${
                        isSelected
                          ? 'scale-125 border-white ring-2 ring-white/50 shadow-md'
                          : 'border-white/20 hover:scale-110'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  );
                })}

                {/* Free color picker */}
                <div className="flex items-center gap-1.5 ml-2">
                  <span className="text-[11px] text-zinc-400">Personalizado:</span>
                  <input
                    type="color"
                    value={settings.systemAccentColor || '#06b6d4'}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, systemAccentColor: e.target.value })
                    }
                    className="w-7 h-7 rounded-full cursor-pointer bg-transparent border-0"
                    title="Elegir cualquier color personalizado"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 2. BIBLIOTECA & VISTAS PREDETERMINADAS */}
          <div className="space-y-3 pt-4">
            <h3 className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-2">
              <Sliders className="w-4 h-4 text-zinc-300" />
              <span>Preferencias de Biblioteca</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Vista predeterminada</label>
                <select
                  value={settings.defaultView}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, defaultView: e.target.value as ShelfViewMode })
                  }
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none"
                >
                  <option value="shelf">Estantería moderna</option>
                  <option value="grid">Cuadrícula</option>
                  <option value="list">Lista detallada</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Orden predeterminado</label>
                <select
                  value={settings.defaultSort}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, defaultSort: e.target.value as SortOption })
                  }
                  className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white focus:outline-none"
                >
                  <option value="title">Título (A-Z)</option>
                  <option value="author">Autor</option>
                  <option value="dateAdded">Fecha añadida</option>
                  <option value="progress">Progreso</option>
                  <option value="rating">Valoración</option>
                </select>
              </div>
            </div>
          </div>

          {/* 3. ILUMINACIÓN LED DE ESTANTERÍA */}
          <div className="space-y-3 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-2">
                <Zap className="w-4 h-4 text-zinc-300" />
                <span>LED de Estantería</span>
              </h3>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.led.enabled}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      led: { ...settings.led, enabled: e.target.checked },
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-white/40"></div>
              </label>
            </div>

            {settings.led.enabled && (
              <div className="space-y-3 p-3 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
                <div>
                  <label className="text-slate-400 font-medium block mb-1.5">Color del resplandor</label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {LED_PRESET_COLORS.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() =>
                          onUpdateSettings({
                            ...settings,
                            led: { ...settings.led, color: preset.hex },
                          })
                        }
                        title={preset.label}
                        className={`w-6 h-6 rounded-full border transition-transform ${
                          settings.led.color === preset.hex
                            ? 'scale-125 border-white ring-2 ring-white/30'
                            : 'border-white/20'
                        }`}
                        style={{ backgroundColor: preset.hex }}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-slate-400 mb-1">
                    <span>Brillo ({settings.led.brightness}%)</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={settings.led.brightness}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        led: { ...settings.led, brightness: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-white bg-white/10 h-1.5 rounded cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 4. COPIAS DE SEGURIDAD (EXPORTAR & IMPORTAR JSON) (Section 55) */}
          <div className="space-y-3 pt-4">
            <h3 className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-2">
              <Download className="w-4 h-4 text-zinc-300" />
              <span>Copia de Seguridad y Datos (JSON)</span>
            </h3>
            <p className="text-xs text-slate-400">
              Guarda todos tus libros, sesiones, frases, colecciones y configuración en un archivo portable o restáuralos en otro dispositivo.
            </p>

            {importStatus && (
              <div className="p-3 rounded-xl bg-white/10 border border-white/20 text-white text-xs flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{importStatus}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={onOpenBackupModal ? onOpenBackupModal : onExportBackup}
                className="py-2.5 px-4 rounded-xl bg-white/[0.06] hover:bg-white/10 border border-white/15 text-white font-semibold flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Download className="w-4 h-4 text-zinc-300" />
                <span>Exportar mis datos</span>
              </button>

              <button
                type="button"
                onClick={onOpenBackupModal ? onOpenBackupModal : () => fileInputRef.current?.click()}
                className="py-2.5 px-4 rounded-xl bg-white/[0.06] hover:bg-white/10 border border-white/15 text-white font-semibold flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Upload className="w-4 h-4 text-zinc-300" />
                <span>Importar datos</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileUpload}
                className="sr-only"
              />
            </div>
          </div>

          {/* 5. GESTIÓN DE DATOS / DATOS DE EJEMPLO */}
          <div className="space-y-3 pt-4">
            <h3 className="font-bold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-zinc-300" />
              <span>Gestión y Reinicio de Datos</span>
            </h3>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                onClick={onRestoreSampleData}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5 text-zinc-300" />
                <span>Restaurar datos de muestra</span>
              </button>

              {showClearConfirm ? (
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={async () => {
                      await onClearAllData();
                      setShowClearConfirm(false);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs border border-white/20 shadow"
                  >
                    Confirmar borrado total
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowClearConfirm(false)}
                    className="px-2 py-1.5 text-slate-400 hover:text-white text-xs"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowClearConfirm(true)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/15 text-zinc-300 hover:text-white transition-all flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Borrar todos los datos</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
