import React, { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Moon,
  Sun,
  Globe,
  Vibrate,
  Calculator,
  HardDrive,
  Download,
  Upload,
  Trash2,
  ShieldCheck,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { ThemeMode, AngleMode, Language } from '../../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const {
    settings,
    updateSettings,
    triggerHaptic,
    showToast,
    exportAllData,
    importAllData,
    clearAllAppData,
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showConfirmReset, setShowConfirmReset] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleExportBackup = () => {
    triggerHaptic();
    const dataStr = exportAllData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PocketToolkit-Backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Local backup exported successfully', 'success');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        importAllData(content);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#1B221E] w-full max-w-md rounded-3xl p-5 shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center space-x-2">
            <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">Preferences & Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto py-3 space-y-4 text-xs">
          {/* Theme Mode */}
          <div className="space-y-1.5">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300">Display Theme</span>
            <div className="grid grid-cols-3 gap-2">
              {(['system', 'light', 'dark'] as ThemeMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => {
                    triggerHaptic();
                    updateSettings({ theme: mode });
                  }}
                  className={`py-2 px-3 rounded-xl border font-semibold capitalize transition-all ${
                    settings.theme === mode
                      ? 'bg-[#006C4C] text-white border-[#006C4C]'
                      : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Language Toggle */}
          <div className="space-y-1.5">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300">Application Language</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  triggerHaptic();
                  updateSettings({ language: 'en' });
                }}
                className={`py-2 px-3 rounded-xl border font-semibold transition-all ${
                  settings.language === 'en'
                    ? 'bg-[#006C4C] text-white border-[#006C4C]'
                    : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
                }`}
              >
                English (Default)
              </button>
              <button
                onClick={() => {
                  triggerHaptic();
                  updateSettings({ language: 'ur' });
                }}
                className={`py-2 px-3 rounded-xl border font-semibold transition-all font-urdu ${
                  settings.language === 'ur'
                    ? 'bg-[#006C4C] text-white border-[#006C4C]'
                    : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
                }`}
              >
                اردو (Urdu)
              </button>
            </div>
          </div>

          {/* Haptic Feedback */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-700">
            <div>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 block">Haptic Feedback</span>
              <span className="text-[11px] text-neutral-500">Vibrate phone on keypad and button presses</span>
            </div>
            <input
              type="checkbox"
              checked={settings.hapticFeedback}
              onChange={(e) => updateSettings({ hapticFeedback: e.target.checked })}
              className="rounded text-[#006C4C] focus:ring-[#006C4C] w-4 h-4"
            />
          </div>

          {/* Calculator Default Angle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200 dark:border-neutral-700">
            <div>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 block">Default Trigonometric Unit</span>
              <span className="text-[11px] text-neutral-500">Angle calculation mode for sine, cosine, tangent</span>
            </div>
            <div className="flex space-x-1">
              {(['deg', 'rad'] as AngleMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => {
                    triggerHaptic();
                    updateSettings({ angleMode: mode });
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold uppercase ${
                    settings.angleMode === mode ? 'bg-[#006C4C] text-white' : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Backup & Export */}
          <div className="space-y-2 pt-2 border-t border-neutral-200 dark:border-neutral-800">
            <span className="font-bold text-neutral-800 dark:text-neutral-200 block">Local Data Backup</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleExportBackup}
                className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold flex items-center justify-center gap-1.5 hover:bg-neutral-200"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold flex items-center justify-center gap-1.5 hover:bg-neutral-200"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import JSON</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </div>
          </div>

          {/* Reset App Data */}
          <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800">
            {!showConfirmReset ? (
              <button
                onClick={() => setShowConfirmReset(true)}
                className="w-full py-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 font-bold flex items-center justify-center gap-1.5 hover:bg-rose-100"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Application Data</span>
              </button>
            ) : (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-300 dark:border-rose-800 space-y-2">
                <div className="flex items-center space-x-1.5 text-rose-700 dark:text-rose-300 font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Confirm Complete Reset?</span>
                </div>
                <p className="text-[11px] text-neutral-600 dark:text-neutral-300">
                  This will erase all locally saved notes, calculation history, to-do items, and shopping lists from this device.
                </p>
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      clearAllAppData();
                      setShowConfirmReset(false);
                      onClose();
                    }}
                    className="flex-1 py-1.5 rounded-lg bg-rose-600 text-white font-bold text-xs"
                  >
                    Yes, Delete All
                  </button>
                  <button
                    onClick={() => setShowConfirmReset(false)}
                    className="flex-1 py-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-semibold text-xs"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#006C4C] text-white text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
