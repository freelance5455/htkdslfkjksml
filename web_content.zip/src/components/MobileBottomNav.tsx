import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Grid, BookMarked, ShoppingBag, User } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { activeTab, setActiveTab, cart, t } = useApp();
  const cartCount = cart.length;

  const navItems = [
    { id: 'home', label: t.home, icon: Home },
    { id: 'categories', label: t.categories, icon: Grid },
    { id: 'my-books', label: t.myBooks, icon: BookMarked },
    { id: 'cart', label: t.cart, icon: ShoppingBag, badge: cartCount },
    { id: 'profile', label: t.profile, icon: User },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0B192C]/95 backdrop-blur-md border-t border-[#1E3E62] shadow-[0_-4px_20px_rgba(0,0,0,0.3)] pb-safe">
      <div className="flex items-center justify-around h-15 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1 transition-all relative ${
                isActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 stroke-[2.5]' : 'stroke-[1.75]'
                  }`}
                />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-4 h-4 bg-amber-400 text-slate-950 font-extrabold text-[10px] rounded-full flex items-center justify-center px-1 shadow">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[64px]">
                {item.label}
              </span>
              {isActive && (
                <span className="absolute bottom-0 w-8 h-0.5 bg-amber-400 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
