import React, { useState } from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { 
  LayoutDashboard, 
  Grid, 
  Camera, 
  MapPin, 
  MoreHorizontal, 
  Bell, 
  Sliders, 
  PlusCircle, 
  Smartphone, 
  PackageCheck, 
  Code2, 
  KeyRound, 
  Globe, 
  Volume2, 
  Lock, 
  Unlock, 
  Cloud, 
  X, 
  Battery,
  Moon,
  Sun,
  Sparkles
} from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenChildMode: () => void;
  onOpenPinModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenChildMode,
  onOpenPinModal,
}) => {
  const { 
    language, 
    toggleLanguage,
    activeDevice,
    unreadAlertsCount, 
    isLiveCameraStreaming, 
    isMicListening,
    setIsSimulatorOpen,
    setDeviceLockdown,
    triggerEmergencySiren,
    stopEmergencySiren,
    sirenPlaying,
    cloudSyncStatus,
    lockParentDashboard,
    themeMode,
    isDarkMode,
    setThemeMode
  } = useParentControl();

  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const isAr = language === 'ar';
  const isLocked = activeDevice?.settings?.screenLocked;

  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId);
    setIsMoreMenuOpen(false);
  };

  const isMoreTabActive = ['settings', 'alerts', 'pair', 'flutter', 'apk'].includes(activeTab);

  return (
    <>
      {/* Fixed Bottom Bar on Mobile Screens (sm:hidden) */}
      <nav 
        id="mobile-bottom-navigation-bar"
        className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200/90 dark:border-slate-800 sm:hidden shadow-[0_-4px_20px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_20px_rgba(0,0,0,0.4)] transition-colors duration-200 pb-[env(safe-area-inset-bottom,0px)]"
      >
        <div className="flex items-center justify-around px-2 py-1.5 max-w-md mx-auto">
          {/* 1. Dashboard */}
          <button
            id="mobile-tab-dashboard"
            onClick={() => handleSelectTab('dashboard')}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-h-[46px] min-w-[56px] ${
              activeTab === 'dashboard'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'dashboard' ? 'bg-indigo-50 dark:bg-indigo-950/60' : ''}`}>
              <LayoutDashboard className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 leading-tight">
              {isAr ? 'الرئيسية' : 'Home'}
            </span>
          </button>

          {/* 2. Apps */}
          <button
            id="mobile-tab-apps"
            onClick={() => handleSelectTab('apps')}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-h-[46px] min-w-[56px] ${
              activeTab === 'apps'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'apps' ? 'bg-indigo-50 dark:bg-indigo-950/60' : ''}`}>
              <Grid className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 leading-tight">
              {isAr ? 'التطبيقات' : 'Apps'}
            </span>
          </button>

          {/* 3. Camera & Mic (with live recording pulsing dot) */}
          <button
            id="mobile-tab-camera"
            onClick={() => handleSelectTab('camera_mic')}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-h-[46px] min-w-[56px] relative ${
              activeTab === 'camera_mic'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors relative ${activeTab === 'camera_mic' ? 'bg-indigo-50 dark:bg-indigo-950/60' : ''}`}>
              <Camera className="w-5 h-5" />
              {(isLiveCameraStreaming || isMicListening) && (
                <span className="absolute -top-0.5 -end-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full animate-ping" />
              )}
            </div>
            <span className="text-[10px] mt-0.5 leading-tight">
              {isAr ? 'المراقبة' : 'Live'}
            </span>
          </button>

          {/* 4. GPS & Geofences */}
          <button
            id="mobile-tab-location"
            onClick={() => handleSelectTab('location')}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-h-[46px] min-w-[56px] ${
              activeTab === 'location'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'location' ? 'bg-indigo-50 dark:bg-indigo-950/60' : ''}`}>
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 leading-tight">
              {isAr ? 'الموقع' : 'GPS'}
            </span>
          </button>

          {/* 5. More Menu Sheet Trigger */}
          <button
            id="mobile-tab-more"
            onClick={() => setIsMoreMenuOpen(true)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-h-[46px] min-w-[56px] relative ${
              isMoreTabActive || isMoreMenuOpen
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors relative ${(isMoreTabActive || isMoreMenuOpen) ? 'bg-indigo-50 dark:bg-indigo-950/60' : ''}`}>
              <MoreHorizontal className="w-5 h-5" />
              {unreadAlertsCount > 0 && (
                <span className="absolute -top-0.5 -end-1 px-1 min-w-4 h-4 bg-rose-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900">
                  {unreadAlertsCount}
                </span>
              )}
            </div>
            <span className="text-[10px] mt-0.5 leading-tight">
              {isAr ? 'المزيد' : 'More'}
            </span>
          </button>
        </div>
      </nav>

      {/* Slide-Up Mobile Bottom Sheet for "More" tools */}
      {isMoreMenuOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-xs sm:hidden animate-in fade-in duration-200">
          <div 
            className="w-full bg-white dark:bg-slate-900 rounded-t-3xl max-h-[85vh] flex flex-col shadow-2xl border-t border-slate-200/80 dark:border-slate-800 animate-in slide-in-from-bottom duration-250 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sheet Handle and Header */}
            <div className="p-4 pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-800 flex items-center justify-center">
                  <MoreHorizontal className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? 'المزيد من الأدوات والتحكم' : 'More Tools & Remote Controls'}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {isAr ? 'إدارة التنبيهات، الإعدادات، والمحاكي' : 'Manage alerts, settings, and apps'}
                  </p>
                </div>
              </div>

              <button
                id="close-mobile-more-sheet-btn"
                onClick={() => setIsMoreMenuOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Sheet Content */}
            <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(85vh-70px)]">
              {/* Active Child Mini Status Card */}
              {activeDevice && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img 
                      src={activeDevice.avatarUrl} 
                      alt="" 
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700" 
                    />
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {activeDevice.childNameAr} ({activeDevice.deviceName})
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="flex items-center gap-1 font-mono">
                          <Battery className={`w-3.5 h-3.5 ${activeDevice.batteryLevel < 25 ? 'text-rose-600' : 'text-emerald-500'}`} />
                          {activeDevice.batteryLevel}%
                        </span>
                        <span>•</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                          {activeDevice.lastSyncTime}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Fast Action: Siren Toggle */}
                  <button
                    onClick={() => {
                      if (sirenPlaying) stopEmergencySiren();
                      else triggerEmergencySiren();
                    }}
                    className={`p-2 rounded-xl border text-xs font-bold transition-all ${
                      sirenPlaying 
                        ? 'bg-rose-600 text-white border-rose-500 animate-pulse' 
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                    title={isAr ? 'صفارة الإنذار' : 'Siren'}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Theme Mode Selector (Light / Dark / Auto) */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-2xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    {isDarkMode ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                    {isAr ? 'مظهر واجهة التطبيق' : 'Appearance / Theme'}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400">
                    {themeMode === 'auto' ? (isAr ? 'تلقائي (19:00 - 06:00)' : 'Auto Night') : themeMode === 'dark' ? (isAr ? 'ليلي' : 'Dark') : (isAr ? 'نهاري' : 'Light')}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5 bg-slate-200/60 dark:bg-slate-900/80 p-1 rounded-xl">
                  <button
                    onClick={() => setThemeMode('light')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                      themeMode === 'light'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>{isAr ? 'نهاري' : 'Light'}</span>
                  </button>
                  <button
                    onClick={() => setThemeMode('dark')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                      themeMode === 'dark'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5" />
                    <span>{isAr ? 'ليلي' : 'Dark'}</span>
                  </button>
                  <button
                    onClick={() => setThemeMode('auto')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                      themeMode === 'auto'
                        ? 'bg-white dark:bg-indigo-600 text-indigo-700 dark:text-white shadow-xs font-bold'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-300" />
                    <span>{isAr ? 'تلقائي' : 'Auto'}</span>
                  </button>
                </div>
              </div>

              {/* Main Actions Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                {/* Alerts */}
                <button
                  id="mobile-sheet-alerts-btn"
                  onClick={() => handleSelectTab('alerts')}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                    activeTab === 'alerts' 
                      ? 'bg-indigo-50/80 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-300 font-bold' 
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 relative shrink-0">
                    <Bell className="w-4 h-4" />
                    {unreadAlertsCount > 0 && (
                      <span className="absolute -top-1 -end-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-bold flex items-center justify-center">
                        {unreadAlertsCount}
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'التنبيهات' : 'Alerts'}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'سجل الإشعارات' : 'Notifications'}</div>
                  </div>
                </button>

                {/* Device Settings */}
                <button
                  id="mobile-sheet-settings-btn"
                  onClick={() => handleSelectTab('settings')}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                    activeTab === 'settings' 
                      ? 'bg-indigo-50/80 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-300 font-bold' 
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                    <Sliders className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'إعدادات الجهاز' : 'Settings'}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'الهاردوير والشبكات' : 'Hardware & Radios'}</div>
                  </div>
                </button>

                {/* Live Simulator Modal */}
                <button
                  id="mobile-sheet-simulator-btn"
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    setIsSimulatorOpen(true);
                  }}
                  className="p-3 rounded-2xl border border-indigo-100 dark:border-indigo-900/60 bg-indigo-50/60 dark:bg-indigo-950/40 hover:bg-indigo-50 dark:hover:bg-indigo-950/70 text-start flex items-center gap-2.5 transition-all text-indigo-950 dark:text-indigo-200"
                >
                  <div className="p-2 rounded-xl bg-indigo-600 dark:bg-indigo-500 text-white shrink-0 shadow-xs">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold flex items-center gap-1">
                      <span>{isAr ? 'محاكي الطفل' : 'Child Simulator'}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    </div>
                    <div className="text-[10px] text-indigo-700 dark:text-indigo-400">{isAr ? 'تجربة تفاعلية مباشرة' : 'Interactive'}</div>
                  </div>
                </button>

                {/* Real Child Mode */}
                <button
                  id="mobile-sheet-childmode-btn"
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onOpenChildMode();
                  }}
                  className="p-3 rounded-2xl border border-purple-200 dark:border-purple-900/60 bg-purple-50/60 dark:bg-purple-950/40 hover:bg-purple-50 dark:hover:bg-purple-950/70 text-start flex items-center gap-2.5 transition-all text-purple-950 dark:text-purple-200"
                >
                  <div className="p-2 rounded-xl bg-purple-600 dark:bg-purple-500 text-white shrink-0 shadow-xs">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'هاتف الطفل الفعلي' : 'Child Device'}</div>
                    <div className="text-[10px] text-purple-700 dark:text-purple-400">{isAr ? 'وضع مرافق الطفل' : 'Companion View'}</div>
                  </div>
                </button>

                {/* Pair Device */}
                <button
                  id="mobile-sheet-pair-btn"
                  onClick={() => handleSelectTab('pair')}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                    activeTab === 'pair' 
                      ? 'bg-indigo-50/80 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-300 font-bold' 
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shrink-0">
                    <PlusCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'إقران جهاز' : 'Pair Device'}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'رمز QR أو الكود' : 'QR & Code'}</div>
                  </div>
                </button>

                {/* APK Export */}
                <button
                  id="mobile-sheet-apk-btn"
                  onClick={() => handleSelectTab('apk')}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                    activeTab === 'apk' 
                      ? 'bg-indigo-50/80 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-300 font-bold' 
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-750 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 shrink-0">
                    <PackageCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'تنزيل APK' : 'Export APK'}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'حزم أندرويد' : 'Installers'}</div>
                  </div>
                </button>

                {/* Flutter Code */}
                <button
                  id="mobile-sheet-flutter-btn"
                  onClick={() => handleSelectTab('flutter')}
                  className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all col-span-2 ${
                    activeTab === 'flutter' 
                      ? 'bg-indigo-50/80 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-300 font-bold' 
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 shrink-0">
                    <Code2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold">{isAr ? 'أكواد Flutter المفتوحة' : 'Flutter Source Code'}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'مشروع كامل مع background service' : 'Full cross-platform source'}</div>
                  </div>
                </button>
              </div>

              {/* Utility Row: Lock PIN, Language, Lock Screen */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <button
                  id="mobile-sheet-pin-btn"
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onOpenPinModal();
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <KeyRound className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>{isAr ? 'رمز PIN' : 'Master PIN'}</span>
                </button>

                <button
                  id="mobile-sheet-lang-btn"
                  onClick={toggleLanguage}
                  className="py-2.5 px-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Globe className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                  <span>{isAr ? 'English' : 'عربي'}</span>
                </button>

                <button
                  id="mobile-sheet-lockdash-btn"
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    lockParentDashboard();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-1.5 transition-colors border border-rose-200 dark:border-rose-800"
                >
                  <Lock className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span>{isAr ? 'قفل اللوحة' : 'Lock'}</span>
                </button>
              </div>

              {/* Firebase Cloud Sync pill */}
              <div className="text-center pt-1 text-[11px] text-slate-400 dark:text-slate-500 flex items-center justify-center gap-1.5 font-mono">
                <Cloud className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                <span>Firebase Cloud Sync:</span>
                <span className={cloudSyncStatus === 'connected' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-amber-500'}>
                  {cloudSyncStatus === 'connected' ? 'ONLINE' : 'CONNECTING'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
