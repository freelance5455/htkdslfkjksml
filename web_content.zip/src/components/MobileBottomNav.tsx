import React from 'react';
import { 
  LayoutDashboard, 
  Briefcase, 
  CheckSquare, 
  Users, 
  Menu,
  FileText,
  UserCheck
} from 'lucide-react';
import { useApp, AppView } from '../context/AppContext';

interface MobileBottomNavProps {
  onOpenMobileMenu: () => void;
  isMobileMenuOpen: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ 
  onOpenMobileMenu,
  isMobileMenuOpen 
}) => {
  const { currentUser, activeView, setActiveView, tasks } = useApp();

  const myOpenTasksCount = currentUser.role === 'Employee'
    ? tasks.filter(t => t.assignedToEmployeeId === currentUser.id && t.status !== 'Completed').length
    : tasks.filter(t => t.status !== 'Completed').length;

  return (
    <nav 
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1 shadow-lg"
    >
      <div className="flex items-center justify-around h-14">
        {currentUser.role === 'Admin' ? (
          <>
            <button
              onClick={() => setActiveView('dashboard')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'dashboard' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Overview</span>
            </button>

            <button
              onClick={() => setActiveView('projects')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'projects' || activeView === 'project-detail' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Briefcase className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Projects</span>
            </button>

            <button
              onClick={() => setActiveView('tasks')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer relative ${
                activeView === 'tasks' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <CheckSquare className="w-5 h-5" />
                {myOpenTasksCount > 0 && (
                  <span className="absolute -top-1 -right-2 bg-red-600 text-white text-[9px] font-bold px-1 rounded-full min-w-3.5 text-center">
                    {myOpenTasksCount > 9 ? '9+' : myOpenTasksCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5">Tasks</span>
            </button>

            <button
              onClick={() => setActiveView('clients')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'clients' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Clients</span>
            </button>

            <button
              onClick={onOpenMobileMenu}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                isMobileMenuOpen || activeView === 'employees' || activeView === 'documents' || activeView === 'reports' || activeView === 'settings'
                  ? 'text-red-600 font-semibold' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Menu className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">More</span>
            </button>
          </>
        ) : currentUser.role === 'Employee' ? (
          <>
            <button
              onClick={() => setActiveView('employee-portal')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'employee-portal' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Workspace</span>
            </button>

            <button
              onClick={() => setActiveView('tasks')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer relative ${
                activeView === 'tasks' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <CheckSquare className="w-5 h-5" />
                {myOpenTasksCount > 0 && (
                  <span className="absolute -top-1 -right-2 bg-red-600 text-white text-[9px] font-bold px-1 rounded-full min-w-3.5 text-center">
                    {myOpenTasksCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5">My Tasks</span>
            </button>

            <button
              onClick={() => setActiveView('documents')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'documents' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Documents</span>
            </button>

            <button
              onClick={onOpenMobileMenu}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                isMobileMenuOpen ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <UserCheck className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Profile & Menu</span>
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => setActiveView('client-portal')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'client-portal' || activeView === 'project-detail' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Briefcase className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">My Projects</span>
            </button>

            <button
              onClick={() => setActiveView('documents')}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                activeView === 'documents' ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Documents</span>
            </button>

            <button
              onClick={onOpenMobileMenu}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-center transition-colors cursor-pointer ${
                isMobileMenuOpen ? 'text-red-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Menu className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">Help & Account</span>
            </button>
          </>
        )}
      </div>
    </nav>
  );
};
