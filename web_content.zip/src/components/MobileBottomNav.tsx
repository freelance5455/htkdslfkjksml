import React from 'react';
import { 
  Sparkles, 
  Mic2, 
  History, 
  Cloud, 
  Code2, 
  User 
} from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: 'studio' | 'voices' | 'history' | 'cloud' | 'api';
  onSelectTab: (tab: 'studio' | 'voices' | 'history' | 'cloud' | 'api') => void;
  historyCount: number;
  userAvatar?: string;
  onOpenProfile: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  onSelectTab,
  historyCount,
  userAvatar,
  onOpenProfile,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl border-t border-zinc-200 dark:border-zinc-800/80 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-1.5 transition-colors">
      <div className="max-w-md mx-auto flex items-center justify-around">
        
        {/* Studio Tab */}
        <button
          onClick={() => onSelectTab('studio')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all touch-press ${
            currentTab === 'studio'
              ? 'text-violet-600 dark:text-violet-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 font-medium hover:text-zinc-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${currentTab === 'studio' ? 'bg-violet-500/15' : ''}`}>
            <Sparkles className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Studio</span>
        </button>

        {/* Voices Tab */}
        <button
          onClick={() => onSelectTab('voices')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all touch-press ${
            currentTab === 'voices'
              ? 'text-violet-600 dark:text-violet-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 font-medium hover:text-zinc-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${currentTab === 'voices' ? 'bg-violet-500/15' : ''}`}>
            <Mic2 className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Voices</span>
        </button>

        {/* History Tab */}
        <button
          onClick={() => onSelectTab('history')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all relative touch-press ${
            currentTab === 'history'
              ? 'text-violet-600 dark:text-violet-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 font-medium hover:text-zinc-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${currentTab === 'history' ? 'bg-violet-500/15' : ''}`}>
            <History className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">History</span>
          {historyCount > 0 && (
            <span className="absolute top-1 right-2 w-4 h-4 bg-violet-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {historyCount > 9 ? '9+' : historyCount}
            </span>
          )}
        </button>

        {/* Cloud Tab */}
        <button
          onClick={() => onSelectTab('cloud')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all touch-press ${
            currentTab === 'cloud'
              ? 'text-violet-600 dark:text-violet-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 font-medium hover:text-zinc-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${currentTab === 'cloud' ? 'bg-violet-500/15' : ''}`}>
            <Cloud className="w-5 h-5 text-cyan-500" />
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Cloud</span>
        </button>

        {/* API Tab */}
        <button
          onClick={() => onSelectTab('api')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all touch-press ${
            currentTab === 'api'
              ? 'text-violet-600 dark:text-violet-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 font-medium hover:text-zinc-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-xl transition-all ${currentTab === 'api' ? 'bg-violet-500/15' : ''}`}>
            <Code2 className="w-5 h-5 text-emerald-500" />
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">API</span>
        </button>

      </div>
    </nav>
  );
};
