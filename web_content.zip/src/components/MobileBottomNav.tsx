import React from 'react';
import { Home, Film, Plus, Bell, User, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';

interface MobileBottomNavProps {
  activeTab: 'feed' | 'reels' | 'profile' | 'admin';
  setActiveTab: (tab: 'feed' | 'reels' | 'profile' | 'admin') => void;
  onOpenCreatePost: () => void;
  onOpenNotifications: () => void;
  onGoToMyProfile: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenCreatePost,
  onOpenNotifications,
  onGoToMyProfile,
}) => {
  const { user, isAdmin } = useAuth();
  const { unreadNotifsCount } = useSocial();

  return (
    <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 z-40 md:hidden pb-safe">
      <div className="flex items-center justify-around h-14 max-w-lg mx-auto px-2">
        
        {/* Feed */}
        <button
          onClick={() => setActiveTab('feed')}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
            activeTab === 'feed' ? 'text-[#1877F2]' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Feed</span>
        </button>

        {/* Reels */}
        <button
          onClick={() => setActiveTab('reels')}
          className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors relative ${
            activeTab === 'reels' ? 'text-[#1877F2]' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Film className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Reels</span>
          <span className="absolute top-1 right-5 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
        </button>

        {/* Create Center Button */}
        <div className="flex-1 flex justify-center">
          <button
            onClick={onOpenCreatePost}
            className="w-10 h-10 -mt-3 rounded-full bg-linear-to-tr from-[#1877F2] to-[#0D65D9] flex items-center justify-center text-white shadow-lg shadow-blue-500/30 hover:scale-105 active:scale-95 transition-transform cursor-pointer border-2 border-white"
            title="Create Post or Upload from Gallery"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* Notifications */}
        <button
          onClick={onOpenNotifications}
          className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer text-slate-500 hover:text-slate-700 relative"
        >
          <Bell className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5">Alerts</span>
          {unreadNotifsCount > 0 && (
            <span className="absolute top-1 right-5 bg-rose-500 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
              {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
            </span>
          )}
        </button>

        {/* Profile or Admin */}
        {isAdmin ? (
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
              activeTab === 'admin' ? 'text-amber-600' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <span className="text-[10px] font-semibold mt-0.5 text-amber-700">Admin</span>
          </button>
        ) : (
          <button
            onClick={onGoToMyProfile}
            className={`flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-colors ${
              activeTab === 'profile' ? 'text-[#1877F2]' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <img
              src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
              alt="Me"
              className={`w-5 h-5 rounded-full object-cover ring-1 ${activeTab === 'profile' ? 'ring-[#1877F2]' : 'ring-slate-300'}`}
            />
            <span className="text-[10px] font-semibold mt-0.5">Profile</span>
          </button>
        )}

      </div>
    </div>
  );
};
