import React from 'react';
import { BookOpen, Compass, Grid, Save, Store } from 'lucide-react';
import { NavTab } from './TopBar';

interface MobileBottomNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  hasActiveInteraction: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  hasActiveInteraction,
}) => {
  const items: { id: NavTab; label: string; Icon: React.FC<{ className?: string }> }[] = [
    { id: 'facility', label: 'Facility', Icon: Grid },
    { id: 'location', label: 'Location', Icon: Compass },
    { id: 'market', label: 'Market', Icon: Store },
    { id: 'journal', label: 'Journal', Icon: BookOpen },
    { id: 'save', label: 'Save', Icon: Save },
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#F7F5F0]/95 backdrop-blur-md border-t border-[#DFDBD0] pb-safe"
      aria-label="Mobile navigation"
    >
      <div className="grid grid-cols-5 h-14 items-center">
        {items.map(({ id, label, Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectTab(id)}
              className={`relative flex flex-col items-center justify-center min-h-[44px] w-full transition-colors cursor-pointer ${
                active ? 'text-[#1F4E3D] font-semibold' : 'text-[#5C584F]'
              }`}
            >
              <Icon className="w-5 h-5" aria-hidden="true" />
              <span className="text-[10px] mt-0.5 leading-none">{label}</span>
              {id === 'location' && hasActiveInteraction && (
                <span className="sr-only">Interaction active</span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
