import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, Home, Sparkles, ShieldAlert, Trophy } from 'lucide-react';
import { getHeroById } from '../data/heroesData';
import { getItemById } from '../data/itemsData';
import { getWorldById } from '../data/worldsData';
import {
  drawAnimeHero,
  drawBossEntity,
  drawEnemyEntity,
  drawHazards,
  drawParallaxWorld,
  drawWorldPlatformsAndProps,
  HeroAnimState,
  isPeriodicHazardActive,
} from '../game/animeRenderer';
import { computeEffectiveHeroStats } from '../game/saveManager';
import { soundEngine } from '../game/soundEngine';
import { SaveData } from '../types/game';
import { TouchControls } from './TouchControls';

const CANVAS_W = 960;
const CANVAS_H = 540;
const GRAVITY = 1520;

interface LiveEnemy {
  id: string;
  name: string;
  archetype: string;
  isElite: boolean;
  x: number;
  y: number;
  vx: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  attack: number;
  patrolMinX: number;
  patrolMaxX: number;
  facing: 1 | -1;
  attackCd: number;
  hurtTimer: number;
  slowTimer: number;
  stunTimer: number;
  animTime: number;
}

interface LiveBoss {
  active: boolean;
  defeated: boolean;
  x: number;
  y: number;
  vx: number;
  hp: number;
  maxHp: number;
  phase: number;
  facing: 1 | -1;
  actionTimer: number;
  hurtTimer: number;
  isCharging: boolean;
  pendingAttack: null | {
    type: 'pillars' | 'charge' | 'barrage';
    timer: number; // counts down to 0 then executes!
    zones: { x: number; y: number; w: number; h: number }[];
  };
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  fromPlayer: boolean;
  damage: number;
  pierce: boolean;
  life: number;
  slowOnHit?: boolean;
  stunOnHit?: boolean;
  pullOnHit?: boolean;
  hitIds: Set<string>;
}

interface SlashVfx {
  x: number;
  y: number;
  facing: 1 | -1;
  radius: number;
  color: string;
  stage: 1 | 2 | 3;
  life: number;
  maxLife: number;
}

interface PillarVfx {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  life: number;
  maxLife: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
}

interface FloatingNumber {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  isCrit?: boolean;
  life: number;
}

interface CoinPickup {
  x: number;
  y: number;
  vy: number;
  amount: number;
  healAmount?: number;
  life: number;
}

interface AfterimageGhost {
  x: number;
  y: number;
  facing: 1 | -1;
  color: string;
  life: number;
}

export interface StageCompletionSummary {
  worldId: number;
  coinsCollected: number;
  clearBonusCoins: number;
  xpEarned: number;
  enemiesKilled: number;
  maxCombo: number;
  secretFoundThisRun: boolean;
  unlockedItemIds: string[];
  stars: number;
}

interface CombatArenaProps {
  worldId: number;
  startFromCheckpoint?: boolean;
  save: SaveData;
  onSaveCheckpoint: (worldId: number, x: number, y: number) => void;
  onConsumePotion: () => boolean;
  onSecretDiscovered: (worldId: number, coins: number, itemId?: string) => void;
  onStageVictory: (summary: StageCompletionSummary) => { levelsGained: number };
  onExitToMenu: (earnedMidRunCoins: number, enemiesKilled: number, maxCombo: number) => void;
  onPlayNextWorld: (nextWorldId: number) => void;
}

export const CombatArena: React.FC<CombatArenaProps> = ({
  worldId,
  startFromCheckpoint = false,
  save,
  onSaveCheckpoint,
  onConsumePotion,
  onSecretDiscovered,
  onStageVictory,
  onExitToMenu,
  onPlayNextWorld,
}) => {
  const world = getWorldById(worldId);
  const hero = getHeroById(save.selectedHeroId);
  const effectiveStats = computeEffectiveHeroStats(save, hero.id);

  const equippedOutfit = getItemById(save.equippedOutfitId);
  const equippedPet = getItemById(save.equippedPetId);
  const equippedCosmetic = getItemById(save.equippedCosmeticId);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // React UI HUD State synced smoothly
  const [hudState, setHudState] = useState({
    hp: effectiveStats.maxHp,
    maxHp: effectiveStats.maxHp,
    bossActive: false,
    bossHp: world.boss.maxHp,
    bossMaxHp: world.boss.maxHp,
    bossPhase: 1,
    combo: 0,
    coinsRun: 0,
    dashCd: 0,
    skill1Cd: 0,
    skill2Cd: 0,
    bossIntroBanner: false,
    checkpointToast: false,
    secretToast: '',
  });

  const [isPaused, setIsPaused] = useState(false);
  const [isDefeated, setIsDefeated] = useState(false);
  const [victorySummary, setVictorySummary] = useState<
    (StageCompletionSummary & { levelsGained: number }) | null
  >(null);

  const dashMaxCd = hero.id === 'kaelen' ? 1.25 : 1.45;
  const skill1MaxCd = Number(
    (hero.skill1.cooldown * (1 - effectiveStats.cooldownReduction)).toFixed(2)
  );
  const skill2MaxCd = Number(
    (hero.skill2.cooldown * (1 - effectiveStats.cooldownReduction)).toFixed(2)
  );

  // Mutable Real-Time Engine State inside ref for zero-lag 60fps loop
  const engineRef = useRef({
    time: 0,
    paused: false,
    defeated: false,
    victoryTriggered: false,
    celebrationTimer: 0,
    shakeTimer: 0,

    // Inputs
    keysLeft: false,
    keysRight: false,
    touchMoveX: 0,
    attackHeld: false,

    // Player Physics & Combat
    px: startFromCheckpoint ? world.checkpointX : 110,
    py: startFromCheckpoint ? world.checkpointY : 430,
    vx: 0,
    vy: 0,
    facing: 1 as 1 | -1,
    onGround: true,
    coyoteTimer: 0,
    jumpsLeft: 2,
    lastSafeX: startFromCheckpoint ? world.checkpointX : 110,
    lastSafeY: startFromCheckpoint ? world.checkpointY : 430,

    hp: effectiveStats.maxHp,
    maxHp: effectiveStats.maxHp,
    animState: 'idle' as HeroAnimState,
    animTimer: 0,

    // Attack & Skills
    comboStage: 1 as 1 | 2 | 3,
    comboResetTimer: 0,
    attackTimer: 0,
    attackDuration: 0.24,
    skillAnimTimer: 0,
    dashTimer: 0,
    dashCd: 0,
    skill1Cd: 0,
    skill2Cd: 0,
    invulnTimer: 0,
    hurtTimer: 0,
    regenAcc: 0,
    petBoltTimer: 1.5,

    // Progression in current run
    comboCount: 0,
    comboDecayTimer: 0,
    maxComboRun: 0,
    coinsCollected: 0,
    enemiesKilled: 0,
    checkpointActivated: startFromCheckpoint,
    secretOpened: save.secretsFoundWorlds.includes(world.id),
    secretFoundThisRun: false,

    // Camera
    camX: startFromCheckpoint ? Math.max(0, world.checkpointX - 280) : 0,
    arenaLocked: false,
    bossIntroTimer: 0,

    // Entities
    enemies: [] as LiveEnemy[],
    boss: {
      active: false,
      defeated: false,
      x: world.length - 220,
      y: 430,
      vx: 0,
      hp: world.boss.maxHp,
      maxHp: world.boss.maxHp,
      phase: 1,
      facing: -1,
      actionTimer: 1.8,
      hurtTimer: 0,
      isCharging: false,
      pendingAttack: null,
    } as LiveBoss,
    projectiles: [] as Projectile[],
    slashes: [] as SlashVfx[],
    pillars: [] as PillarVfx[],
    particles: [] as Particle[],
    floatingNums: [] as FloatingNumber[],
    pickups: [] as CoinPickup[],
    ghosts: [] as AfterimageGhost[],
  });

  // Populate initial world enemies
  const initWorldEntities = useCallback(
    (fromCheckpoint: boolean) => {
      const eng = engineRef.current;
      const worldScale = 1 + (world.id - 1) * 0.36;
      eng.enemies = world.enemies
        .filter((e) => (!fromCheckpoint ? true : e.x > world.checkpointX + 60))
        .map((e) => {
          const baseHp = e.isElite ? 210 : 82;
          const baseAtk = e.isElite ? 24 : 14;
          const isHoverType =
            e.archetype.includes('drone') ||
            e.archetype.includes('wisp') ||
            e.archetype.includes('wraith') ||
            e.archetype.includes('gargoyle') ||
            e.archetype.includes('seraph');
          return {
            id: e.id,
            name: e.name,
            archetype: e.archetype,
            isElite: Boolean(e.isElite),
            x: e.x,
            y: isHoverType ? 406 : 430,
            vx: e.isElite ? 65 : 85,
            w: e.isElite ? 44 : 32,
            h: e.isElite ? 64 : 46,
            hp: Math.round(baseHp * worldScale),
            maxHp: Math.round(baseHp * worldScale),
            attack: Math.round(baseAtk * worldScale),
            patrolMinX: e.patrolMinX,
            patrolMaxX: e.patrolMaxX,
            facing: -1,
            attackCd: 1.1,
            hurtTimer: 0,
            slowTimer: 0,
            stunTimer: 0,
            animTime: Math.random() * 5,
          };
        });

      eng.boss = {
        active: false,
        defeated: false,
        x: world.length - 230,
        y: 430,
        vx: 0,
        hp: world.boss.maxHp,
        maxHp: world.boss.maxHp,
        phase: 1,
        facing: -1,
        actionTimer: 1.9,
        hurtTimer: 0,
        isCharging: false,
        pendingAttack: null,
      };
      eng.projectiles = [];
      eng.slashes = [];
      eng.pillars = [];
      eng.particles = [];
      eng.floatingNums = [];
      eng.pickups = [];
      eng.ghosts = [];
      eng.arenaLocked = false;
      eng.defeated = false;
      eng.victoryTriggered = false;
      eng.celebrationTimer = 0;
      eng.px = fromCheckpoint ? world.checkpointX : 110;
      eng.py = fromCheckpoint ? world.checkpointY : 430;
      eng.vx = 0;
      eng.vy = 0;
      eng.hp = effectiveStats.maxHp;
      eng.maxHp = effectiveStats.maxHp;
      eng.camX = fromCheckpoint ? Math.max(0, world.checkpointX - 280) : 0;
      setIsDefeated(false);
      soundEngine.playMusic(world.musicTrack);
    },
    [world, effectiveStats.maxHp]
  );

  useEffect(() => {
    initWorldEntities(startFromCheckpoint);
    return () => {
      // Music transitions back when exiting arena
    };
  }, [initWorldEntities, startFromCheckpoint]);

  // Helper particle spawner respecting Low/Medium/High/Maximum graphics settings
  const spawnParticles = useCallback(
    (x: number, y: number, color: string, count: number, speed = 150) => {
      const q = save.settings.graphicsQuality;
      const mult = q === 'low' ? 0.3 : q === 'medium' ? 0.65 : q === 'high' ? 1 : 1.35;
      const finalCount = Math.max(2, Math.round(count * mult));
      const eng = engineRef.current;
      if (eng.particles.length > 160) return;

      for (let i = 0; i < finalCount; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = (0.3 + Math.random() * 0.8) * speed;
        eng.particles.push({
          x,
          y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd - 35,
          size: 2 + Math.random() * 3.5,
          color,
          life: 0.35 + Math.random() * 0.3,
          maxLife: 0.65,
        });
      }
    },
    [save.settings.graphicsQuality]
  );

  // Deal damage to Enemy or Boss with Crit, Fury passive, Combo counter & Floating Text
  const dealDamageToTarget = useCallback(
    (
      target: { x: number; y: number; h?: number; hp: number; hurtTimer: number },
      rawMultiplier: number,
      targetDef = 0,
      options?: { slow?: boolean; stun?: boolean }
    ) => {
      const eng = engineRef.current;
      let atk = effectiveStats.attack;
      // Ignis Passive: Undying Ember (+up to 25% ATK below 50% HP)
      if (hero.id === 'ignis' && eng.hp < eng.maxHp * 0.5) {
        atk *= 1.25;
      }

      const isCrit = Math.random() < effectiveStats.critChance;
      const baseDmg = Math.max(6, atk * rawMultiplier - targetDef * 0.45);
      const finalDmg = Math.round(baseDmg * (isCrit ? 1.65 : 0.94 + Math.random() * 0.14));

      target.hp = Math.max(0, target.hp - finalDmg);
      target.hurtTimer = 0.14;

      if (options?.slow && 'slowTimer' in target) {
        (target as LiveEnemy).slowTimer = 3.2;
      }
      if (options?.stun && 'stunTimer' in target) {
        (target as LiveEnemy).stunTimer = 1.4;
      }

      eng.comboCount += 1;
      eng.comboDecayTimer = 3.2;
      if (eng.comboCount > eng.maxComboRun) {
        eng.maxComboRun = eng.comboCount;
      }

      soundEngine.playSfx(isCrit ? 'critHit' : 'hitEnemy');
      const topY = target.y - (target.h || 90) * 0.7;
      eng.floatingNums.push({
        x: target.x + (Math.random() - 0.5) * 24,
        y: topY,
        vy: -75,
        text: isCrit ? `✦ ${finalDmg}!` : `${finalDmg}`,
        color: isCrit ? '#fde047' : '#f8fafc',
        isCrit,
        life: 0.75,
      });
      spawnParticles(target.x, topY + 12, hero.palette.weaponGlow, isCrit ? 12 : 6, 170);
    },
    [effectiveStats, hero, spawnParticles]
  );

  // Action Triggers (Shared between Android Touch Controls & Keyboard!)
  const triggerJump = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    soundEngine.unlockAudio();

    const jumpPower = hero.id === 'lyra' ? 585 : 555;
    if (eng.onGround || eng.coyoteTimer > 0) {
      eng.vy = -jumpPower;
      eng.onGround = false;
      eng.coyoteTimer = 0;
      eng.jumpsLeft = 1;
      soundEngine.playSfx('jump');
      spawnParticles(eng.px, eng.py, '#cbd5e1', 6, 95);
    } else if (eng.jumpsLeft > 0) {
      eng.vy = -jumpPower * 0.93;
      eng.jumpsLeft = 0;
      soundEngine.playSfx('doubleJump');
      spawnParticles(eng.px, eng.py, hero.palette.weaponGlow, 10, 130);
    }
  }, [hero, spawnParticles]);

  const triggerDash = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    if (eng.dashCd > 0.05) return;
    soundEngine.unlockAudio();

    eng.dashTimer = hero.id === 'kaelen' ? 0.24 : 0.21;
    eng.dashCd = dashMaxCd;
    eng.invulnTimer = Math.max(eng.invulnTimer, 0.32);
    eng.vy = 0;
    soundEngine.playSfx('dash');
    spawnParticles(eng.px, eng.py - 26, hero.palette.weaponGlow, 10, 160);
  }, [dashMaxCd, hero, spawnParticles]);

  const performMeleeComboSwing = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    if (eng.attackTimer > 0.04 || eng.dashTimer > 0) return;
    soundEngine.unlockAudio();

    const stage = eng.comboStage;
    eng.attackDuration = hero.id === 'kaelen' || hero.id === 'akari' ? 0.21 : 0.25;
    eng.attackTimer = eng.attackDuration;
    eng.comboResetTimer = 1.1;

    // Slight forward combat lunge
    eng.vx = eng.facing * (stage === 3 ? 185 : 95);

    soundEngine.playSfx(stage === 1 ? 'slash1' : stage === 2 ? 'slash2' : 'slash3');

    const reach =
      hero.palette.weaponType === 'infinity_scythe' ||
      hero.palette.weaponType === 'phoenix_greatsword' ||
      hero.palette.weaponType === 'frost_halberd' ||
      hero.palette.weaponType === 'glaive'
        ? 92
        : 76;

    const finalReach = stage === 3 ? reach + 24 : reach;
    const mult = stage === 1 ? 1.0 : stage === 2 ? 1.2 : 1.6;

    // Add anime crescent slash visual
    eng.slashes.push({
      x: eng.px + eng.facing * (finalReach * 0.46),
      y: eng.py - 32,
      facing: eng.facing,
      radius: stage === 3 ? 52 : 38,
      color: hero.palette.weaponGlow,
      stage,
      life: 0.18,
      maxLife: 0.18,
    });

    // Hit Enemies in slash box
    const minX = eng.facing === 1 ? eng.px - 14 : eng.px - finalReach;
    const maxX = eng.facing === 1 ? eng.px + finalReach : eng.px + 14;

    for (const enemy of eng.enemies) {
      if (
        enemy.hp > 0 &&
        enemy.x + enemy.w * 0.5 >= minX &&
        enemy.x - enemy.w * 0.5 <= maxX &&
        Math.abs(enemy.y - eng.py) < 72
      ) {
        dealDamageToTarget(enemy, mult, enemy.isElite ? 8 : 3);
        enemy.x += eng.facing * (stage === 3 ? 22 : 11);
        enemy.vx = eng.facing * (stage === 3 ? 190 : 110);
      }
    }

    // Hit Boss if active
    if (eng.boss.active && !eng.boss.defeated) {
      if (
        eng.boss.x + 38 >= minX &&
        eng.boss.x - 38 <= maxX &&
        Math.abs(eng.boss.y - eng.py) < 118
      ) {
        dealDamageToTarget(eng.boss, mult, world.boss.defense);
      }
    }

    eng.comboStage = stage === 1 ? 2 : stage === 2 ? 3 : 1;
  }, [dealDamageToTarget, hero, world.boss.defense]);

  const triggerSkill1 = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    if (eng.skill1Cd > 0.05) return;
    soundEngine.unlockAudio();

    eng.skill1Cd = skill1MaxCd;
    eng.skillAnimTimer = 0.34;
    soundEngine.playSfx('skillCast');

    const dmgMult = hero.skill1.damageMultiplier * effectiveStats.specialBonusMultiplier;
    const eff = hero.skill1.effectType;

    if (eff === 'spirit_arrows') {
      // Lyra: 3 spread spirit bolts
      [-55, 0, 55].forEach((vyOff) => {
        eng.projectiles.push({
          x: eng.px + eng.facing * 24,
          y: eng.py - 34,
          vx: eng.facing * 540,
          vy: vyOff,
          radius: 10,
          color: '#34d399',
          fromPlayer: true,
          damage: dmgMult * 0.75,
          pierce: true,
          life: 1.2,
          hitIds: new Set(),
        });
      });
    } else {
      eng.projectiles.push({
        x: eng.px + eng.facing * 28,
        y: eng.py - 32,
        vx: eng.facing * (eff === 'void_singularity' ? 340 : 480),
        vy: 0,
        radius: eff === 'void_singularity' || eff === 'inferno_breaker' ? 24 : 18,
        color: hero.palette.weaponGlow,
        fromPlayer: true,
        damage: dmgMult,
        pierce: true,
        life: 1.25,
        slowOnHit: eff === 'permafrost_lance',
        stunOnHit: eff === 'overdrive_pulse',
        pullOnHit: eff === 'void_singularity',
        hitIds: new Set(),
      });
    }

    spawnParticles(eng.px + eng.facing * 20, eng.py - 32, hero.palette.weaponGlow, 14, 190);
  }, [effectiveStats.specialBonusMultiplier, hero, skill1MaxCd, spawnParticles]);

  const triggerSkill2Ultimate = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    if (eng.skill2Cd > 0.05) return;
    soundEngine.unlockAudio();

    eng.skill2Cd = skill2MaxCd;
    eng.skillAnimTimer = 0.48;
    eng.invulnTimer = Math.max(eng.invulnTimer, 0.55);
    eng.shakeTimer = 0.28;
    soundEngine.playSfx('ultimateCast');

    const dmgMult = hero.skill2.damageMultiplier * effectiveStats.specialBonusMultiplier;
    const eff = hero.skill2.effectType;

    // Healing component on Verdant Hurricane, Absolute Zero, Infinity Requiem
    if (eff === 'verdant_hurricane' || eff === 'absolute_zero' || eff === 'infinity_requiem') {
      const healPct = eff === 'infinity_requiem' ? 0.22 : eff === 'verdant_hurricane' ? 0.18 : 0.15;
      const healAmt = Math.round(eng.maxHp * healPct);
      eng.hp = Math.min(eng.maxHp, eng.hp + healAmt);
      eng.floatingNums.push({
        x: eng.px,
        y: eng.py - 64,
        vy: -60,
        text: `+${healAmt} HP`,
        color: '#34d399',
        life: 0.9,
      });
    }

    if (eff === 'eclipse_rush') {
      // Kaelen dashes forward cleaving everything
      const startX = eng.px;
      eng.px = Math.max(40, Math.min(world.length - 40, eng.px + eng.facing * 230));
      const minX = Math.min(startX, eng.px) - 30;
      const maxX = Math.max(startX, eng.px) + 30;
      for (let i = 0; i < 5; i++) {
        eng.pillars.push({
          x: minX + ((maxX - minX) * i) / 5,
          y: eng.py - 90,
          w: 26,
          h: 90,
          color: '#a855f7',
          life: 0.35,
          maxLife: 0.35,
        });
      }
      for (const e of eng.enemies) {
        if (e.hp > 0 && e.x >= minX && e.x <= maxX) {
          dealDamageToTarget(e, dmgMult, 0);
        }
      }
      if (eng.boss.active && !eng.boss.defeated && eng.boss.x >= minX && eng.boss.x <= maxX) {
        dealDamageToTarget(eng.boss, dmgMult, world.boss.defense * 0.5);
      }
    } else {
      // Wide-area Ultimate Pillars / Supernova Wave across screen!
      const pillarCount = eff === 'infinity_requiem' ? 7 : 5;
      for (let i = 0; i < pillarCount; i++) {
        const px =
          eff === 'verdant_hurricane' || eff === 'infinity_requiem'
            ? eng.px - 220 + i * (440 / (pillarCount - 1))
            : eng.px + eng.facing * (55 + i * 72);
        eng.pillars.push({
          x: px - 22,
          y: eng.py - 190,
          w: 44,
          h: 195,
          color: hero.palette.weaponGlow,
          life: 0.45,
          maxLife: 0.45,
        });
      }

      const rangeLeft =
        eff === 'verdant_hurricane' || eff === 'infinity_requiem'
          ? eng.px - 280
          : eng.facing === 1
          ? eng.px - 40
          : eng.px - 430;
      const rangeRight =
        eff === 'verdant_hurricane' || eff === 'infinity_requiem'
          ? eng.px + 280
          : eng.facing === 1
          ? eng.px + 430
          : eng.px + 40;

      for (const e of eng.enemies) {
        if (e.hp > 0 && e.x >= rangeLeft && e.x <= rangeRight) {
          dealDamageToTarget(e, dmgMult, 0, { slow: eff === 'absolute_zero' });
        }
      }
      if (
        eng.boss.active &&
        !eng.boss.defeated &&
        eng.boss.x >= rangeLeft - 45 &&
        eng.boss.x <= rangeRight + 45
      ) {
        dealDamageToTarget(eng.boss, dmgMult, world.boss.defense * 0.5);
      }
    }

    spawnParticles(eng.px, eng.py - 36, '#fde047', 24, 240);
  }, [
    dealDamageToTarget,
    effectiveStats.specialBonusMultiplier,
    hero,
    skill2MaxCd,
    spawnParticles,
    world.boss.defense,
    world.length,
  ]);

  const triggerPotion = useCallback(() => {
    const eng = engineRef.current;
    if (eng.paused || eng.defeated || eng.victoryTriggered) return;
    if (eng.hp >= eng.maxHp) return;
    if (onConsumePotion()) {
      const heal = Math.round(eng.maxHp * 0.45);
      eng.hp = Math.min(eng.maxHp, eng.hp + heal);
      soundEngine.playSfx('potion');
      eng.floatingNums.push({
        x: eng.px,
        y: eng.py - 60,
        vy: -65,
        text: `+${heal} HP`,
        color: '#f472b6',
        life: 0.9,
      });
      spawnParticles(eng.px, eng.py - 28, '#f472b6', 12, 130);
    }
  }, [onConsumePotion, spawnParticles]);

  // Keyboard Controls Listener (Desktop / Tablet Bluetooth Keyboard support)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      const key = e.key.toLowerCase();
      if (key === 'a' || e.key === 'ArrowLeft') eng.keysLeft = true;
      if (key === 'd' || e.key === 'ArrowRight') eng.keysRight = true;
      if (key === 'w' || e.key === 'ArrowUp' || e.key === ' ') {
        if (!e.repeat) {
          e.preventDefault();
          triggerJump();
        }
      }
      if (e.key === 'Shift' || key === 'l') {
        if (!e.repeat) triggerDash();
      }
      if (key === 'j' || key === 'z') {
        eng.attackHeld = true;
        if (!e.repeat) performMeleeComboSwing();
      }
      if (key === 'k' || key === 'x') {
        if (!e.repeat) triggerSkill1();
      }
      if (key === 'u' || key === 'c') {
        if (!e.repeat) triggerSkill2Ultimate();
      }
      if (key === 'h') {
        if (!e.repeat) triggerPotion();
      }
      if (e.key === 'Escape' || key === 'p') {
        if (!e.repeat && !eng.defeated && !eng.victoryTriggered) {
          eng.paused = !eng.paused;
          setIsPaused(eng.paused);
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      const key = e.key.toLowerCase();
      if (key === 'a' || e.key === 'ArrowLeft') eng.keysLeft = false;
      if (key === 'd' || e.key === 'ArrowRight') eng.keysRight = false;
      if (key === 'j' || key === 'z') eng.attackHeld = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [
    performMeleeComboSwing,
    triggerDash,
    triggerJump,
    triggerPotion,
    triggerSkill1,
    triggerSkill2Ultimate,
  ]);

  // =========================================================================
  // MAIN 60 FPS GAMEPLAY & RENDERING LOOP
  // =========================================================================
  useEffect(() => {
    let rafId = 0;
    let lastTs = performance.now();
    let hudSyncAcc = 0;

    const damagePlayer = (rawAtk: number) => {
      const eng = engineRef.current;
      if (eng.invulnTimer > 0 || eng.defeated || eng.victoryTriggered) return;
      const dmg = Math.max(4, Math.round(rawAtk - effectiveStats.defense * 0.42));
      eng.hp = Math.max(0, eng.hp - dmg);
      eng.invulnTimer = 0.72;
      eng.hurtTimer = 0.22;
      eng.shakeTimer = 0.16;
      soundEngine.playSfx('playerHurt');

      eng.floatingNums.push({
        x: eng.px,
        y: eng.py - 56,
        vy: -70,
        text: `-${dmg}`,
        color: '#fb7185',
        life: 0.8,
      });

      if (eng.hp <= 0) {
        eng.defeated = true;
        soundEngine.playSfx('defeat');
        setIsDefeated(true);
      }
    };

    const step = (ts: number) => {
      const dt = Math.min(0.045, (ts - lastTs) / 1000);
      lastTs = ts;
      const eng = engineRef.current;

      if (!eng.paused && !eng.defeated) {
        eng.time += dt;
        eng.animTimer += dt;

        // Cooldowns
        if (eng.dashCd > 0) eng.dashCd = Math.max(0, eng.dashCd - dt);
        if (eng.skill1Cd > 0) eng.skill1Cd = Math.max(0, eng.skill1Cd - dt);
        if (eng.skill2Cd > 0) eng.skill2Cd = Math.max(0, eng.skill2Cd - dt);
        if (eng.invulnTimer > 0) eng.invulnTimer = Math.max(0, eng.invulnTimer - dt);
        if (eng.hurtTimer > 0) eng.hurtTimer = Math.max(0, eng.hurtTimer - dt);
        if (eng.attackTimer > 0) eng.attackTimer = Math.max(0, eng.attackTimer - dt);
        if (eng.skillAnimTimer > 0) eng.skillAnimTimer = Math.max(0, eng.skillAnimTimer - dt);
        if (eng.shakeTimer > 0) eng.shakeTimer = Math.max(0, eng.shakeTimer - dt);
        if (eng.bossIntroTimer > 0) eng.bossIntroTimer = Math.max(0, eng.bossIntroTimer - dt);

        if (eng.comboResetTimer > 0) {
          eng.comboResetTimer -= dt;
          if (eng.comboResetTimer <= 0) eng.comboStage = 1;
        }
        if (eng.comboDecayTimer > 0) {
          eng.comboDecayTimer -= dt;
          if (eng.comboDecayTimer <= 0) eng.comboCount = 0;
        }

        // Auto-chain combo if holding Attack button!
        if (eng.attackHeld && eng.attackTimer <= 0 && !eng.victoryTriggered) {
          performMeleeComboSwing();
        }

        // Passive Regeneration (Lyra + Crystal Fairy Pet)
        const regenPerSec =
          (hero.id === 'lyra' ? 3 : 0) + (save.equippedPetId === 'pet_aegis_fairy' ? 4 : 0);
        if (regenPerSec > 0 && eng.hp < eng.maxHp && !eng.victoryTriggered) {
          eng.regenAcc += regenPerSec * dt;
          if (eng.regenAcc >= 2) {
            const add = Math.floor(eng.regenAcc);
            eng.regenAcc -= add;
            eng.hp = Math.min(eng.maxHp, eng.hp + add);
          }
        }

        // Companion Pet Auto-Bolt AI (Kitsune & Astral Wyrmling)
        if (
          (save.equippedPetId === 'pet_lumi_fox' || save.equippedPetId === 'pet_volt_drake') &&
          !eng.victoryTriggered
        ) {
          eng.petBoltTimer -= dt;
          if (eng.petBoltTimer <= 0) {
            eng.petBoltTimer = save.equippedPetId === 'pet_volt_drake' ? 2.1 : 2.5;
            // Find closest visible enemy or boss
            let targetX: number | null = null;
            let targetY = eng.py - 30;
            for (const e of eng.enemies) {
              if (e.hp > 0 && Math.abs(e.x - eng.px) < 380) {
                targetX = e.x;
                targetY = e.y - e.h * 0.5;
                break;
              }
            }
            if (targetX === null && eng.boss.active && !eng.boss.defeated) {
              targetX = eng.boss.x;
              targetY = eng.boss.y - 65;
            }
            if (targetX !== null) {
              const dx = targetX - eng.px;
              const dy = targetY - (eng.py - 46);
              const len = Math.max(1, Math.hypot(dx, dy));
              eng.projectiles.push({
                x: eng.px - eng.facing * 24,
                y: eng.py - 46,
                vx: (dx / len) * 440,
                vy: (dy / len) * 440,
                radius: 7,
                color: save.equippedPetId === 'pet_volt_drake' ? '#c084fc' : '#fbbf24',
                fromPlayer: true,
                damage: save.equippedPetId === 'pet_volt_drake' ? 0.85 : 0.6,
                pierce: false,
                life: 1.2,
                hitIds: new Set(),
              });
            }
          }
        }

        // Horizontal Movement & Dash Physics
        let inputDir = 0;
        if (eng.keysLeft) inputDir -= 1;
        if (eng.keysRight) inputDir += 1;
        if (Math.abs(eng.touchMoveX) > 0.05) inputDir = eng.touchMoveX;

        if (!eng.victoryTriggered) {
          if (eng.dashTimer > 0) {
            eng.dashTimer -= dt;
            const dashSpd = hero.id === 'kaelen' ? 760 : 700;
            eng.vx = eng.facing * dashSpd;
            eng.vy = 0;
            if (
              save.settings.graphicsQuality === 'high' ||
              save.settings.graphicsQuality === 'maximum'
            ) {
              eng.ghosts.push({
                x: eng.px,
                y: eng.py,
                facing: eng.facing,
                color: hero.palette.weaponGlow,
                life: 0.16,
              });
            }
          } else {
            if (Math.abs(inputDir) > 0.08) {
              eng.facing = inputDir > 0 ? 1 : -1;
            }
            if (eng.attackTimer <= 0.08) {
              eng.vx = inputDir * effectiveStats.moveSpeed;
            } else {
              eng.vx *= 0.88;
            }
            eng.vy += GRAVITY * dt;
          }
        } else {
          eng.vx = 0;
          eng.vy += GRAVITY * dt;
        }

        const prevY = eng.py;
        eng.px += eng.vx * dt;
        eng.py += eng.vy * dt;

        // World Boundaries (Lock left bound to Boss Arena once Boss starts!)
        const minWorldX = eng.arenaLocked ? world.bossArenaStartX + 24 : 24;
        const maxWorldX = world.length - 28;
        if (eng.px < minWorldX) eng.px = minWorldX;
        if (eng.px > maxWorldX) eng.px = maxWorldX;

        // Platform Landing Collisions
        let landed = false;
        if (eng.vy >= 0) {
          for (const plat of world.platforms) {
            if (eng.px + 13 >= plat.x && eng.px - 13 <= plat.x + plat.w) {
              if (prevY <= plat.y + 8 && eng.py >= plat.y) {
                eng.py = plat.y;
                eng.vy = 0;
                landed = true;
                eng.onGround = true;
                eng.coyoteTimer = 0.11;
                eng.jumpsLeft = 2;
                if (plat.style === 'ground') {
                  eng.lastSafeX = Math.max(plat.x + 36, Math.min(plat.x + plat.w - 36, eng.px));
                  eng.lastSafeY = plat.y;
                }
                break;
              }
            }
          }
        }
        if (!landed) {
          eng.onGround = false;
          if (eng.coyoteTimer > 0) eng.coyoteTimer -= dt;
        }

        // Safe Pit Recovery if player falls into gap
        if (eng.py > 565) {
          eng.px = eng.lastSafeX;
          eng.py = eng.lastSafeY - 10;
          eng.vy = 0;
          damagePlayer(18);
        }

        // Determine Hero Animation State (All 8 smooth states!)
        if (eng.victoryTriggered) {
          eng.animState = 'celebrate';
        } else if (eng.hurtTimer > 0) {
          eng.animState = 'hurt';
        } else if (eng.skillAnimTimer > 0) {
          eng.animState = 'skill';
        } else if (eng.dashTimer > 0) {
          eng.animState = 'dash';
        } else if (eng.attackTimer > 0) {
          eng.animState = 'attack';
        } else if (!eng.onGround) {
          eng.animState = 'jump';
        } else if (Math.abs(eng.vx) > 22) {
          eng.animState = 'run';
        } else {
          eng.animState = 'idle';
        }

        // Checkpoint Activation
        if (!eng.checkpointActivated && Math.abs(eng.px - world.checkpointX) < 52) {
          eng.checkpointActivated = true;
          eng.hp = Math.min(eng.maxHp, eng.hp + Math.round(eng.maxHp * 0.4));
          soundEngine.playSfx('checkpoint');
          onSaveCheckpoint(world.id, world.checkpointX, world.checkpointY);
          spawnParticles(world.checkpointX, world.checkpointY - 60, '#fbbf24', 18, 160);
          setHudState((prev) => ({ ...prev, checkpointToast: true }));
          setTimeout(() => {
            setHudState((prev) => ({ ...prev, checkpointToast: false }));
          }, 2600);
        }

        // Secret Treasure Chest Discovery
        if (
          !eng.secretOpened &&
          Math.abs(eng.px - world.secretChest.x) < 42 &&
          Math.abs(eng.py - world.secretChest.y) < 45
        ) {
          eng.secretOpened = true;
          eng.secretFoundThisRun = true;
          const bonusCoins = world.secretChest.rewardCoins;
          eng.coinsCollected += bonusCoins;
          soundEngine.playSfx('secretChest');
          onSecretDiscovered(world.id, bonusCoins, world.secretChest.rewardItemId);
          spawnParticles(world.secretChest.x, world.secretChest.y - 20, '#fde047', 24, 190);
          const relicItem = getItemById(world.secretChest.rewardItemId || null);
          setHudState((prev) => ({
            ...prev,
            secretToast: relicItem
              ? `Secret Relic Unlocked: ${relicItem.name} +${bonusCoins} Coins!`
              : `Secret Chest Found! +${bonusCoins} Coins!`,
          }));
          setTimeout(() => {
            setHudState((prev) => ({ ...prev, secretToast: '' }));
          }, 3600);
        }

        // Environmental Hazards Check
        for (const h of world.hazards) {
          if (!isPeriodicHazardActive(h, eng.time)) continue;
          const activeH = h.type === 'lava_geyser' ? 48 : h.h;
          if (
            eng.px + 10 > h.x &&
            eng.px - 10 < h.x + h.w &&
            eng.py > h.y + h.h - activeH &&
            eng.py - 46 < h.y + h.h
          ) {
            damagePlayer(h.damage);
          }
        }

        // Trigger Boss Encounter when entering Boss Arena!
        if (!eng.boss.active && !eng.boss.defeated && eng.px >= world.bossArenaStartX + 35) {
          eng.boss.active = true;
          eng.arenaLocked = true;
          eng.bossIntroTimer = 2.4;
          soundEngine.playSfx('bossWarning');
          soundEngine.playMusic('boss');
        }

        // Smooth Camera Tracking
        const targetCamX = eng.arenaLocked
          ? world.length - CANVAS_W
          : Math.max(0, Math.min(world.length - CANVAS_W, eng.px - CANVAS_W * 0.36));
        eng.camX += (targetCamX - eng.camX) * Math.min(1, dt * 8);

        // ===================================================================
        // UPDATE ENEMIES AI
        // ===================================================================
        for (const e of eng.enemies) {
          if (e.hp <= 0) continue;
          e.animTime += dt;
          if (e.hurtTimer > 0) e.hurtTimer -= dt;
          if (e.slowTimer > 0) e.slowTimer -= dt;
          if (e.stunTimer > 0) {
            e.stunTimer -= dt;
            continue;
          }

          const distToPlayer = eng.px - e.x;
          const absDist = Math.abs(distToPlayer);
          const speedMult = e.slowTimer > 0 ? 0.55 : 1;

          const isRanged =
            e.archetype.includes('drone') ||
            e.archetype.includes('wisp') ||
            e.archetype.includes('wraith') ||
            e.archetype.includes('seraph');

          if (absDist < 340 && !eng.victoryTriggered) {
            e.facing = distToPlayer >= 0 ? 1 : -1;
            if (isRanged) {
              if (absDist > 180) {
                e.x += e.facing * 75 * speedMult * dt;
              }
              e.attackCd -= dt * speedMult;
              if (e.attackCd <= 0) {
                e.attackCd = 2.1;
                eng.projectiles.push({
                  x: e.x + e.facing * 16,
                  y: e.y - e.h * 0.55,
                  vx: e.facing * 270,
                  vy: 0,
                  radius: 7,
                  color: '#fb7185',
                  fromPlayer: false,
                  damage: e.attack,
                  pierce: false,
                  life: 1.9,
                  hitIds: new Set(),
                });
              }
            } else {
              // Melee Aggro Pursuit & Strike
              if (absDist > 34) {
                const moveSpd = e.isElite ? 105 : 128;
                e.x += e.facing * moveSpd * speedMult * dt;
              } else {
                e.attackCd -= dt * speedMult;
                if (e.attackCd <= 0) {
                  e.attackCd = 1.15;
                  if (Math.abs(eng.py - e.y) < 58) {
                    damagePlayer(e.attack);
                  }
                }
              }
            }
          } else {
            // Calm Patrol Loop
            e.x += e.vx * speedMult * dt;
            if (e.x <= e.patrolMinX) {
              e.x = e.patrolMinX;
              e.vx = Math.abs(e.vx);
            } else if (e.x >= e.patrolMaxX) {
              e.x = e.patrolMaxX;
              e.vx = -Math.abs(e.vx);
            }
            e.facing = e.vx >= 0 ? 1 : -1;
          }

          e.x = Math.max(e.patrolMinX - 80, Math.min(e.patrolMaxX + 80, e.x));
        }

        // Remove freshly defeated enemies & drop Coins + occasional Healing Orb!
        for (let i = eng.enemies.length - 1; i >= 0; i--) {
          const e = eng.enemies[i];
          if (e.hp <= 0) {
            eng.enemiesKilled += 1;
            const coinDrop = Math.round(
              (e.isElite ? 48 : 16 + world.id * 5) * (hero.id === 'aetherion' ? 1.15 : 1)
            );
            eng.pickups.push({
              x: e.x,
              y: e.y - 18,
              vy: -190,
              amount: coinDrop,
              healAmount: e.isElite || Math.random() < 0.35 ? Math.round(eng.maxHp * 0.12) : 0,
              life: 10,
            });
            spawnParticles(e.x, e.y - 24, '#fbbf24', e.isElite ? 20 : 12, 180);
            eng.enemies.splice(i, 1);
          }
        }

        // ===================================================================
        // MULTI-PHASE TELEGRAPHED BOSS AI
        // ===================================================================
        const boss = eng.boss;
        if (boss.active && !boss.defeated) {
          if (boss.hurtTimer > 0) boss.hurtTimer -= dt;

          // Update Boss Phase (2 or 3 phases!)
          const hpPct = boss.hp / boss.maxHp;
          const nextPhase =
            world.boss.phases === 3
              ? hpPct < 0.3
                ? 3
                : hpPct < 0.65
                ? 2
                : 1
              : hpPct < 0.52
              ? 2
              : 1;
          if (nextPhase > boss.phase) {
            boss.phase = nextPhase;
            eng.shakeTimer = 0.3;
            soundEngine.playSfx('bossWarning');
            spawnParticles(boss.x, boss.y - 70, '#f43f5e', 26, 230);
          }

          if (boss.hp <= 0) {
            // BOSS VANQUISHED!
            boss.defeated = true;
            boss.pendingAttack = null;
            eng.victoryTriggered = true;
            eng.celebrationTimer = 1.9;
            eng.shakeTimer = 0.4;
            soundEngine.stopMusic();
            soundEngine.playSfx('victory');
            spawnParticles(boss.x, boss.y - 70, '#fde047', 40, 280);
            spawnParticles(boss.x, boss.y - 90, world.accentColor, 35, 250);
          } else if (boss.pendingAttack) {
            // Count down telegraphed attack warning before executing!
            boss.isCharging = true;
            boss.pendingAttack.timer -= dt;
            if (boss.pendingAttack.timer <= 0) {
              const atk = boss.pendingAttack;
              boss.pendingAttack = null;
              boss.isCharging = false;
              eng.shakeTimer = 0.22;

              if (atk.type === 'pillars') {
                for (const z of atk.zones) {
                  eng.pillars.push({
                    x: z.x,
                    y: z.y,
                    w: z.w,
                    h: z.h,
                    color: '#f43f5e',
                    life: 0.38,
                    maxLife: 0.38,
                  });
                  if (
                    eng.px + 12 > z.x &&
                    eng.px - 12 < z.x + z.w &&
                    eng.py > z.y &&
                    eng.py - 45 < z.y + z.h
                  ) {
                    damagePlayer(world.boss.attack * 1.25);
                  }
                }
              } else if (atk.type === 'charge') {
                const targetX =
                  boss.facing === 1
                    ? Math.min(world.length - 70, boss.x + 340)
                    : Math.max(world.bossArenaStartX + 70, boss.x - 340);
                const minC = Math.min(boss.x, targetX) - 35;
                const maxC = Math.max(boss.x, targetX) + 35;
                boss.x = targetX;
                if (eng.px >= minC && eng.px <= maxC && eng.py > 350) {
                  damagePlayer(world.boss.attack * 1.3);
                }
              } else if (atk.type === 'barrage') {
                const orbCount = boss.phase >= 2 ? 5 : 3;
                for (let k = 0; k < orbCount; k++) {
                  const vySpread = -140 + k * (240 / Math.max(1, orbCount - 1));
                  eng.projectiles.push({
                    x: boss.x + boss.facing * 32,
                    y: boss.y - 72,
                    vx: boss.facing * 310,
                    vy: vySpread,
                    radius: 11,
                    color: world.boss.glowColor,
                    fromPlayer: false,
                    damage: world.boss.attack,
                    pierce: false,
                    life: 2.3,
                    hitIds: new Set(),
                  });
                }
              }
            }
          } else {
            // Move steadily and queue next telegraphed boss attack
            boss.facing = eng.px >= boss.x ? 1 : -1;
            if (Math.abs(eng.px - boss.x) > 150) {
              boss.x += boss.facing * (70 + boss.phase * 18) * dt;
            }
            boss.actionTimer -= dt * (1 + (boss.phase - 1) * 0.25);
            if (boss.actionTimer <= 0) {
              boss.actionTimer = 2.05;
              const roll = Math.random();
              const warnDur = boss.phase >= 3 ? 0.85 : boss.phase === 2 ? 0.95 : 1.1;

              if (roll < 0.38) {
                // Ground Pillar Eruption Telegraph beneath hero + flanks
                const count = boss.phase >= 2 ? 3 : 2;
                const zones = [];
                for (let z = 0; z < count; z++) {
                  const zx = Math.max(
                    world.bossArenaStartX + 45,
                    Math.min(world.length - 105, eng.px - 28 + (z === 0 ? 0 : (z === 1 ? -135 : 135)))
                  );
                  zones.push({ x: zx, y: 250, w: 56, h: 180 });
                }
                boss.pendingAttack = { type: 'pillars', timer: warnDur, zones };
                soundEngine.playSfx('bossWarning');
              } else if (roll < 0.7) {
                // Dash Charge Lane Telegraph
                const laneX =
                  boss.facing === 1 ? boss.x : Math.max(world.bossArenaStartX + 50, boss.x - 350);
                boss.pendingAttack = {
                  type: 'charge',
                  timer: warnDur,
                  zones: [{ x: laneX, y: 360, w: 350, h: 70 }],
                };
                soundEngine.playSfx('bossWarning');
              } else {
                // Elemental Orb Barrage Telegraph
                boss.pendingAttack = {
                  type: 'barrage',
                  timer: warnDur * 0.8,
                  zones: [{ x: boss.x + boss.facing * 25 - 25, y: boss.y - 105, w: 50, h: 65 }],
                };
              }
            }
          }
        }

        // Victory Celebration Countdown -> Open Level Completion Modal
        if (eng.victoryTriggered && eng.celebrationTimer > 0) {
          eng.celebrationTimer -= dt;
          if (eng.celebrationTimer <= 0) {
            const mult = hero.id === 'aetherion' ? 1.15 : 1;
            const clearBonusCoins = Math.round(
              (world.clearRewardCoins + world.boss.rewardCoins) * mult
            );
            const xpEarned = Math.round((world.clearRewardXp + world.boss.rewardXp) * mult);
            const unlockedItems: string[] = [];
            if (world.boss.guaranteedDropItemId) {
              unlockedItems.push(world.boss.guaranteedDropItemId);
            }
            if (eng.secretFoundThisRun && world.secretChest.rewardItemId) {
              unlockedItems.push(world.secretChest.rewardItemId);
            }
            const stars =
              eng.hp >= eng.maxHp * 0.65 && eng.secretOpened
                ? 3
                : eng.hp >= eng.maxHp * 0.35
                ? 2
                : 1;

            const summary: StageCompletionSummary = {
              worldId: world.id,
              coinsCollected: eng.coinsCollected,
              clearBonusCoins,
              xpEarned,
              enemiesKilled: eng.enemiesKilled,
              maxCombo: eng.maxComboRun,
              secretFoundThisRun: eng.secretFoundThisRun,
              unlockedItemIds: unlockedItems,
              stars,
            };
            const { levelsGained } = onStageVictory(summary);
            setVictorySummary({ ...summary, levelsGained });
          }
        }

        // ===================================================================
        // PROJECTILES, PICKUPS & VFX UPDATES
        // ===================================================================
        for (let i = eng.projectiles.length - 1; i >= 0; i--) {
          const pr = eng.projectiles[i];
          pr.x += pr.vx * dt;
          pr.y += pr.vy * dt;
          pr.life -= dt;

          let remove = pr.life <= 0;
          if (pr.fromPlayer) {
            for (const e of eng.enemies) {
              if (
                e.hp > 0 &&
                !pr.hitIds.has(e.id) &&
                Math.abs(pr.x - e.x) < pr.radius + e.w * 0.5 &&
                pr.y > e.y - e.h - pr.radius &&
                pr.y < e.y + pr.radius
              ) {
                pr.hitIds.add(e.id);
                if (pr.pullOnHit) {
                  e.x += (pr.x - e.x) * 0.45;
                }
                dealDamageToTarget(e, pr.damage, 0, {
                  slow: pr.slowOnHit,
                  stun: pr.stunOnHit,
                });
                if (!pr.pierce) {
                  remove = true;
                  break;
                }
              }
            }
            if (
              !remove &&
              eng.boss.active &&
              !eng.boss.defeated &&
              !pr.hitIds.has('boss') &&
              Math.abs(pr.x - eng.boss.x) < pr.radius + 36 &&
              pr.y > eng.boss.y - 125 &&
              pr.y < eng.boss.y
            ) {
              pr.hitIds.add('boss');
              dealDamageToTarget(eng.boss, pr.damage, world.boss.defense * 0.6);
              if (!pr.pierce) remove = true;
            }
          } else {
            // Enemy / Boss Projectile hitting Hero
            if (
              Math.abs(pr.x - eng.px) < pr.radius + 13 &&
              pr.y > eng.py - 54 &&
              pr.y < eng.py - 4
            ) {
              damagePlayer(pr.damage);
              remove = true;
            }
          }

          if (remove) eng.projectiles.splice(i, 1);
        }

        // Coin & Heal Orb Pickups (Auto-magnet toward hero!)
        for (let i = eng.pickups.length - 1; i >= 0; i--) {
          const pk = eng.pickups[i];
          pk.life -= dt;
          pk.vy += 650 * dt;
          pk.y += pk.vy * dt;
          if (pk.y > 422) {
            pk.y = 422;
            pk.vy = 0;
          }
          const dx = eng.px - pk.x;
          const dy = eng.py - 26 - pk.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 140) {
            pk.x += (dx / Math.max(1, dist)) * 340 * dt;
            pk.y += (dy / Math.max(1, dist)) * 340 * dt;
          }
          if (dist < 28) {
            eng.coinsCollected += pk.amount;
            soundEngine.playSfx('coin');
            if (pk.healAmount && pk.healAmount > 0) {
              eng.hp = Math.min(eng.maxHp, eng.hp + pk.healAmount);
              eng.floatingNums.push({
                x: eng.px,
                y: eng.py - 60,
                vy: -55,
                text: `+${pk.healAmount} HP`,
                color: '#34d399',
                life: 0.75,
              });
            }
            eng.pickups.splice(i, 1);
            continue;
          }
          if (pk.life <= 0) eng.pickups.splice(i, 1);
        }

        // Decay VFX lists
        for (let i = eng.slashes.length - 1; i >= 0; i--) {
          eng.slashes[i].life -= dt;
          if (eng.slashes[i].life <= 0) eng.slashes.splice(i, 1);
        }
        for (let i = eng.pillars.length - 1; i >= 0; i--) {
          eng.pillars[i].life -= dt;
          if (eng.pillars[i].life <= 0) eng.pillars.splice(i, 1);
        }
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const pt = eng.particles[i];
          pt.x += pt.vx * dt;
          pt.y += pt.vy * dt;
          pt.life -= dt;
          if (pt.life <= 0) eng.particles.splice(i, 1);
        }
        for (let i = eng.floatingNums.length - 1; i >= 0; i--) {
          const fn = eng.floatingNums[i];
          fn.y += fn.vy * dt;
          fn.life -= dt;
          if (fn.life <= 0) eng.floatingNums.splice(i, 1);
        }
        for (let i = eng.ghosts.length - 1; i >= 0; i--) {
          eng.ghosts[i].life -= dt;
          if (eng.ghosts[i].life <= 0) eng.ghosts.splice(i, 1);
        }
      }

      // =====================================================================
      // RENDER TO CANVAS
      // =====================================================================
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (ctx) {
        ctx.save();
        if (
          eng.shakeTimer > 0 &&
          (save.settings.graphicsQuality === 'high' || save.settings.graphicsQuality === 'maximum')
        ) {
          ctx.translate((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8);
        }

        // 1. Parallax Sky & World Backdrop
        drawParallaxWorld(
          ctx,
          world,
          eng.camX,
          CANVAS_W,
          CANVAS_H,
          eng.time,
          save.settings.graphicsQuality
        );

        // Ambient Weather / Realm Particles (High & Maximum Graphics)
        if (
          save.settings.graphicsQuality === 'high' ||
          save.settings.graphicsQuality === 'maximum'
        ) {
          const count = save.settings.graphicsQuality === 'maximum' ? 22 : 12;
          ctx.save();
          ctx.fillStyle = world.accentColor;
          ctx.globalAlpha = 0.35;
          for (let i = 0; i < count; i++) {
            const ax = ((i * 97 + eng.time * (world.ambientType === 'neon_rain' ? -40 : 22)) % CANVAS_W + CANVAS_W) % CANVAS_W;
            const ay = ((i * 67 + eng.time * (world.ambientType === 'embers' ? -45 : 35)) % CANVAS_H + CANVAS_H) % CANVAS_H;
            if (world.ambientType === 'neon_rain') {
              ctx.fillRect(ax, ay, 1.5, 14);
            } else {
              ctx.beginPath();
              ctx.arc(ax, ay, 2, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          ctx.restore();
        }

        // 2. Platforms, Checkpoint Shrine, Secret Chest & Boss Gate
        drawWorldPlatformsAndProps(
          ctx,
          world,
          eng.camX,
          CANVAS_W,
          eng.time,
          eng.checkpointActivated,
          eng.secretOpened
        );

        // 3. Hazards
        drawHazards(ctx, world.hazards, eng.camX, CANVAS_W, eng.time);

        // 4. Boss Telegraphed Warning Zones (! DANGER !)
        if (eng.boss.active && eng.boss.pendingAttack) {
          const pulse = 0.25 + Math.abs(Math.sin(eng.time * 16)) * 0.3;
          for (const z of eng.boss.pendingAttack.zones) {
            const sx = z.x - eng.camX;
            ctx.save();
            ctx.fillStyle = `rgba(244, 63, 94, ${pulse})`;
            ctx.strokeStyle = '#fda4af';
            ctx.lineWidth = 2;
            ctx.fillRect(sx, z.y, z.w, z.h);
            ctx.strokeRect(sx, z.y, z.w, z.h);
            ctx.fillStyle = '#ffe4e6';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('! DANGER !', sx + z.w / 2, z.y + 18);
            ctx.restore();
          }
        }

        // 5. Dash Afterimages
        for (const gh of eng.ghosts) {
          ctx.save();
          ctx.globalAlpha = (gh.life / 0.16) * 0.35;
          ctx.fillStyle = gh.color;
          ctx.beginPath();
          ctx.ellipse(gh.x - eng.camX, gh.y - 30, 12, 26, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // 6. Pickups (Coins & Healing Orbs)
        for (const pk of eng.pickups) {
          const sx = pk.x - eng.camX;
          ctx.save();
          ctx.fillStyle = '#fbbf24';
          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(sx, pk.y, 7, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          if (pk.healAmount && pk.healAmount > 0) {
            ctx.fillStyle = '#34d399';
            ctx.beginPath();
            ctx.arc(sx + 10, pk.y - 4, 5, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }

        // 7. Enemies
        for (const e of eng.enemies) {
          if (e.x < eng.camX - 80 || e.x > eng.camX + CANVAS_W + 80) continue;
          drawEnemyEntity(ctx, e, eng.camX);
        }

        // 8. World Boss
        if (eng.boss.active && !eng.boss.defeated) {
          drawBossEntity(
            ctx,
            world.boss,
            eng.boss.x,
            eng.boss.y,
            eng.boss.facing,
            eng.boss.phase,
            eng.boss.hurtTimer,
            eng.time,
            eng.boss.isCharging,
            eng.camX
          );
        }

        // 9. Articulated 2D Anime Hero!
        const atkProg =
          eng.attackDuration > 0 ? 1 - Math.max(0, eng.attackTimer / eng.attackDuration) : 0;
        drawAnimeHero(ctx, {
          x: eng.px - eng.camX,
          y: eng.py,
          facing: eng.facing,
          animState: eng.animState,
          animTime: eng.animTimer,
          comboStage: eng.comboStage,
          attackProgress: atkProg,
          vx: eng.vx,
          vy: eng.vy,
          hero,
          outfit: equippedOutfit,
          pet: equippedPet,
          cosmetic: equippedCosmetic,
          invulnFlash: eng.invulnTimer > 0 && eng.hurtTimer > 0,
          graphics: save.settings.graphicsQuality,
        });

        // 10. Anime Crescent Sword Slashes
        for (const sl of eng.slashes) {
          const sx = sl.x - eng.camX;
          const alpha = sl.life / sl.maxLife;
          ctx.save();
          ctx.translate(sx, sl.y);
          ctx.scale(sl.facing, sl.stage === 2 ? -1 : 1);
          ctx.globalAlpha = alpha;
          ctx.strokeStyle = sl.color;
          ctx.lineWidth = sl.stage === 3 ? 10 : 7;
          ctx.beginPath();
          ctx.arc(0, 0, sl.radius, -Math.PI * 0.45, Math.PI * 0.45);
          ctx.stroke();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(2, 0, sl.radius - 2, -Math.PI * 0.38, Math.PI * 0.38);
          ctx.stroke();
          ctx.restore();
        }

        // 11. Ultimate / Boss Pillars
        for (const pl of eng.pillars) {
          const sx = pl.x - eng.camX;
          ctx.save();
          ctx.globalAlpha = (pl.life / pl.maxLife) * 0.85;
          const grad = ctx.createLinearGradient(sx, 0, sx + pl.w, 0);
          grad.addColorStop(0, 'transparent');
          grad.addColorStop(0.5, pl.color);
          grad.addColorStop(1, 'transparent');
          ctx.fillStyle = grad;
          ctx.fillRect(sx, pl.y, pl.w, pl.h);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(sx + pl.w * 0.38, pl.y, pl.w * 0.24, pl.h);
          ctx.restore();
        }

        // 12. Skill & Enemy Projectiles
        for (const pr of eng.projectiles) {
          const sx = pr.x - eng.camX;
          ctx.save();
          ctx.fillStyle = pr.color;
          if (save.settings.graphicsQuality !== 'low') {
            ctx.shadowColor = pr.color;
            ctx.shadowBlur = 12;
          }
          ctx.beginPath();
          ctx.arc(sx, pr.y, pr.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(sx, pr.y, pr.radius * 0.45, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // 13. Hit & Aura Particles
        for (const pt of eng.particles) {
          ctx.save();
          ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
          ctx.fillStyle = pt.color;
          ctx.beginPath();
          ctx.arc(pt.x - eng.camX, pt.y, pt.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // 14. Floating Damage & Heal Numbers
        for (const fn of eng.floatingNums) {
          ctx.save();
          ctx.globalAlpha = Math.min(1, fn.life * 1.4);
          ctx.font = fn.isCrit ? '800 17px sans-serif' : '700 14px sans-serif';
          ctx.textAlign = 'center';
          ctx.strokeStyle = '#090514';
          ctx.lineWidth = 3;
          ctx.strokeText(fn.text, fn.x - eng.camX, fn.y);
          ctx.fillStyle = fn.color;
          ctx.fillText(fn.text, fn.x - eng.camX, fn.y);
          ctx.restore();
        }

        ctx.restore();
      }

      // Sync React HUD ~15 times per second for crisp cooldowns & health bars
      hudSyncAcc += dt;
      if (hudSyncAcc >= 0.065) {
        hudSyncAcc = 0;
        setHudState((prev) => ({
          ...prev,
          hp: eng.hp,
          maxHp: eng.maxHp,
          bossActive: eng.boss.active && !eng.boss.defeated,
          bossHp: eng.boss.hp,
          bossMaxHp: eng.boss.maxHp,
          bossPhase: eng.boss.phase,
          combo: eng.comboCount,
          coinsRun: eng.coinsCollected,
          dashCd: eng.dashCd,
          skill1Cd: eng.skill1Cd,
          skill2Cd: eng.skill2Cd,
          bossIntroBanner: eng.bossIntroTimer > 0,
        }));
      }

      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [
    dealDamageToTarget,
    effectiveStats.defense,
    effectiveStats.moveSpeed,
    equippedCosmetic,
    equippedOutfit,
    equippedPet,
    hero,
    onSaveCheckpoint,
    onSecretDiscovered,
    onStageVictory,
    performMeleeComboSwing,
    save.equippedPetId,
    save.settings.graphicsQuality,
    spawnParticles,
    world,
  ]);

  const togglePause = () => {
    const eng = engineRef.current;
    if (eng.defeated || eng.victoryTriggered) return;
    eng.paused = !eng.paused;
    setIsPaused(eng.paused);
    soundEngine.playSfx('uiClick');
  };

  const handleExit = () => {
    const eng = engineRef.current;
    onExitToMenu(eng.coinsCollected, eng.enemiesKilled, eng.maxComboRun);
  };

  return (
    <div className="relative flex h-[100dvh] w-full flex-col items-center justify-center overflow-hidden bg-[#06030f] select-none">
      {/* GAME VIEWPORT CONTAINER */}
      <div className="relative flex h-full w-full max-w-[1280px] items-center justify-center">
        <canvas
          ref={canvasRef}
          width={CANVAS_W}
          height={CANVAS_H}
          className="h-full w-full object-contain shadow-[0_0_50px_rgba(0,0,0,0.9)]"
        />

        {/* TOP GAMEPLAY HUD: HERO PORTRAIT, HP BAR, LEVEL, COINS & PAUSE */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between p-2.5 sm:p-4">
          {/* Player Hero Status Card */}
          <div className="flex items-center gap-2.5 rounded-2xl border border-purple-400/35 bg-[#0d0820]/85 p-1.5 pr-4 shadow-lg backdrop-blur-md">
            <div className="relative h-11 w-11 sm:h-12 sm:w-12 overflow-hidden rounded-xl border-2 border-amber-400/80">
              <img
                src={hero.portrait}
                alt={hero.name}
                className="h-full w-full object-cover"
              />
              <span className="absolute right-0 bottom-0 rounded-tl-md bg-slate-950/90 px-1 text-[9px] font-extrabold text-amber-300">
                Lv.{save.heroLevels[hero.id] || 1}
              </span>
            </div>
            <div className="min-w-[130px] sm:min-w-[175px]">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="truncate text-slate-100">{hero.name}</span>
                <span className="ml-2 text-[11px] font-extrabold text-emerald-300">
                  {hudState.hp}/{hudState.maxHp}
                </span>
              </div>
              {/* Health Bar */}
              <div className="mt-1 h-2.5 w-full overflow-hidden rounded-full bg-slate-900 ring-1 ring-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 transition-all duration-150"
                  style={{
                    width: `${Math.max(0, Math.min(100, (hudState.hp / hudState.maxHp) * 100))}%`,
                  }}
                />
              </div>
              <div className="mt-1 flex items-center gap-3 text-[10px] font-semibold text-slate-300">
                <span className="text-amber-300">🪙 +{hudState.coinsRun}</span>
                <span className="text-purple-300">
                  World {world.id}: {world.name}
                </span>
              </div>
            </div>
          </div>

          {/* Combo Streak & Pause Button */}
          <div className="flex items-center gap-2.5">
            {hudState.combo >= 2 && (
              <div className="animate-bounce rounded-xl border border-amber-400/70 bg-gradient-to-r from-amber-600/90 to-purple-800/90 px-3 py-1 text-center shadow-lg">
                <div className="font-fantasy text-base sm:text-lg font-extrabold text-amber-200 leading-none">
                  {hudState.combo} HIT
                </div>
                <div className="text-[9px] font-bold tracking-widest text-amber-100 uppercase">
                  COMBO!
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={togglePause}
              className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-xl border border-purple-400/40 bg-[#120b29]/85 text-slate-100 shadow-lg backdrop-blur-md transition hover:border-amber-400 hover:text-amber-300 active:scale-90"
              title="Pause (Esc / P)"
            >
              <Pause className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* BOSS HEALTH BAR OVERLAY */}
        {hudState.bossActive && (
          <div className="pointer-events-none absolute top-16 sm:top-18 left-1/2 z-20 w-[86%] max-w-md -translate-x-1/2 rounded-2xl border border-rose-500/60 bg-[#14071e]/90 px-4 py-2 shadow-[0_0_30px_rgba(244,63,94,0.35)] backdrop-blur-md">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="font-fantasy tracking-wide text-rose-200">
                ☠ {world.boss.name} •{' '}
                <span className="text-amber-300">PHASE {hudState.bossPhase}</span>
              </span>
              <span className="text-rose-300">
                {hudState.bossHp} / {hudState.bossMaxHp}
              </span>
            </div>
            <div className="mt-1.5 h-3 w-full overflow-hidden rounded-full bg-slate-950 ring-1 ring-rose-400/40">
              <div
                className="h-full bg-gradient-to-r from-rose-600 via-amber-500 to-rose-400 transition-all duration-150"
                style={{
                  width: `${Math.max(0, (hudState.bossHp / hudState.bossMaxHp) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* CINEMATIC BOSS ENTRANCE BANNER */}
        {hudState.bossIntroBanner && (
          <div className="pointer-events-none absolute inset-x-0 top-1/3 z-30 flex flex-col items-center justify-center bg-gradient-to-r from-transparent via-rose-950/90 to-transparent py-4 text-center backdrop-blur-sm">
            <div className="flex items-center gap-2 text-xs font-extrabold tracking-[0.28em] text-amber-300 uppercase">
              <ShieldAlert className="h-4 w-4 text-rose-400" />
              Boss Encounter
              <ShieldAlert className="h-4 w-4 text-rose-400" />
            </div>
            <h2 className="font-fantasy mt-1 text-2xl sm:text-4xl font-extrabold text-white drop-shadow-[0_0_15px_rgba(244,63,94,0.8)]">
              {world.boss.name}
            </h2>
            <p className="text-xs sm:text-sm font-semibold text-rose-200">{world.boss.title}</p>
          </div>
        )}

        {/* CHECKPOINT & SECRET TOAST NOTIFICATIONS */}
        {hudState.checkpointToast && (
          <div className="pointer-events-none absolute top-24 left-1/2 z-30 -translate-x-1/2 rounded-full border border-amber-300/70 bg-amber-950/90 px-4 py-1.5 text-xs font-extrabold text-amber-200 shadow-lg">
            ✦ Checkpoint Activated! HP Restored & Progress Saved ✦
          </div>
        )}

        {hudState.secretToast && (
          <div className="pointer-events-none absolute top-28 left-1/2 z-30 -translate-x-1/2 rounded-full border border-amber-300 bg-gradient-to-r from-purple-950/95 to-amber-900/95 px-5 py-2 text-xs sm:text-sm font-extrabold text-amber-200 shadow-[0_0_25px_rgba(251,191,36,0.5)]">
            <Sparkles className="mr-1.5 inline h-4 w-4 text-amber-300" />
            {hudState.secretToast}
          </div>
        )}

        {/* ANDROID VIRTUAL JOYSTICK & TOUCH CONTROLS */}
        {save.settings.showTouchControls && !isPaused && !isDefeated && !victorySummary && (
          <TouchControls
            scale={save.settings.touchControlScale}
            dashCd={hudState.dashCd}
            dashMaxCd={dashMaxCd}
            skill1Cd={hudState.skill1Cd}
            skill1MaxCd={skill1MaxCd}
            skill1Name={hero.skill1.name}
            skill2Cd={hudState.skill2Cd}
            skill2MaxCd={skill2MaxCd}
            skill2Name={hero.skill2.name}
            potionsCount={save.potionsCount}
            onMoveChange={(mx) => {
              engineRef.current.touchMoveX = mx;
            }}
            onJumpPress={triggerJump}
            onDashPress={triggerDash}
            onAttackDown={() => {
              engineRef.current.attackHeld = true;
              performMeleeComboSwing();
            }}
            onAttackUp={() => {
              engineRef.current.attackHeld = false;
            }}
            onSkill1Press={triggerSkill1}
            onSkill2Press={triggerSkill2Ultimate}
            onPotionPress={triggerPotion}
          />
        )}

        {/* PAUSE MODAL */}
        {isPaused && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
            <div className="w-full max-w-sm rounded-3xl border border-purple-400/40 bg-gradient-to-b from-[#1a1036] to-[#0d081d] p-6 text-center shadow-2xl">
              <h3 className="font-fantasy text-2xl font-bold text-amber-300">Realm Paused</h3>
              <p className="mt-1 text-xs text-slate-300">
                {world.name} • {hero.name}
              </p>
              <div className="mt-5 flex flex-col gap-3">
                <button
                  type="button"
                  onClick={togglePause}
                  className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 py-3 text-sm font-extrabold text-slate-950 shadow-lg transition hover:brightness-110"
                >
                  <Play className="h-4 w-4" /> Resume Combat
                </button>
                <button
                  type="button"
                  onClick={() => {
                    engineRef.current.paused = false;
                    setIsPaused(false);
                    initWorldEntities(engineRef.current.checkpointActivated);
                  }}
                  className="flex items-center justify-center gap-2 rounded-xl border border-purple-400/40 bg-purple-950/60 py-2.5 text-sm font-bold text-purple-100 transition hover:border-amber-400"
                >
                  <RotateCcw className="h-4 w-4" />
                  {engineRef.current.checkpointActivated
                    ? 'Restart from Checkpoint'
                    : 'Restart Stage'}
                </button>
                <button
                  type="button"
                  onClick={handleExit}
                  className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900/80 py-2.5 text-sm font-bold text-slate-300 transition hover:text-white"
                >
                  <Home className="h-4 w-4" /> Save Coins & Exit to Sanctuary
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DEFEAT / CHECKPOINT RESPAWN MODAL */}
        {isDefeated && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md">
            <div className="w-full max-w-sm rounded-3xl border border-rose-500/50 bg-gradient-to-b from-[#230b24] to-[#0b0616] p-6 text-center shadow-2xl">
              <h3 className="font-fantasy text-2xl font-extrabold text-rose-300">
                Fallen in Shadow
              </h3>
              <p className="mt-2 text-xs text-slate-300">
                Your collected <span className="font-bold text-amber-300">+{hudState.coinsRun} Coins</span>{' '}
                are safely kept! Upgrade your skills or respawn immediately.
              </p>
              <div className="mt-5 flex flex-col gap-3">
                {engineRef.current.checkpointActivated && (
                  <button
                    type="button"
                    onClick={() => initWorldEntities(true)}
                    className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 py-3 text-sm font-extrabold text-slate-950 shadow-lg transition hover:brightness-110"
                  >
                    <RotateCcw className="h-4 w-4" /> Respawn at Checkpoint
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => initWorldEntities(false)}
                  className="flex items-center justify-center gap-2 rounded-xl border border-purple-400/50 bg-purple-900/70 py-2.5 text-sm font-bold text-white transition hover:border-amber-300"
                >
                  <RotateCcw className="h-4 w-4" /> Retry World from Beginning
                </button>
                <button
                  type="button"
                  onClick={handleExit}
                  className="flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900/80 py-2.5 text-sm font-bold text-slate-200"
                >
                  <Home className="h-4 w-4" /> Return to Sanctuary (Keep Coins)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* LEVEL COMPLETION VICTORY SCREEN */}
        {victorySummary && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md">
            <div className="w-full max-w-md rounded-3xl border-2 border-amber-400/75 bg-gradient-to-b from-[#1f1142] via-[#130b2c] to-[#090516] p-6 text-center shadow-[0_0_50px_rgba(251,191,36,0.35)]">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-amber-300 bg-amber-500/20 text-amber-300">
                <Trophy className="h-8 w-8" />
              </div>
              <div className="mt-2 text-xs font-extrabold tracking-[0.25em] text-amber-300 uppercase">
                Realm Liberated!
              </div>
              <h2 className="font-fantasy mt-1 text-2xl sm:text-3xl font-extrabold text-white">
                {world.name} Cleared
              </h2>

              {/* Star Rating */}
              <div className="mt-2 flex justify-center gap-2 text-2xl">
                {[1, 2, 3].map((s) => (
                  <span
                    key={s}
                    className={
                      s <= victorySummary.stars
                        ? 'text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]'
                        : 'text-slate-700'
                    }
                  >
                    ★
                  </span>
                ))}
              </div>

              {/* Rewards Breakdown */}
              <div className="mt-4 grid grid-cols-2 gap-2.5 rounded-2xl border border-purple-400/25 bg-slate-950/60 p-3.5 text-left text-xs">
                <div>
                  <span className="text-slate-400">Combat Coins</span>
                  <div className="text-sm font-extrabold text-amber-300">
                    +{victorySummary.coinsCollected} 🪙
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Boss & Clear Bonus</span>
                  <div className="text-sm font-extrabold text-amber-300">
                    +{victorySummary.clearBonusCoins} 🪙
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Experience Earned</span>
                  <div className="text-sm font-extrabold text-purple-300">
                    +{victorySummary.xpEarned} XP
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Best Combo</span>
                  <div className="text-sm font-extrabold text-cyan-300">
                    {victorySummary.maxCombo} Hits
                  </div>
                </div>
              </div>

              {victorySummary.levelsGained > 0 && (
                <div className="mt-3 rounded-xl border border-emerald-400/50 bg-emerald-950/70 px-3 py-2 text-xs font-extrabold text-emerald-200">
                  🌟 LEVEL UP! +{victorySummary.levelsGained} Skill Point(s) Earned!
                </div>
              )}

              {victorySummary.unlockedItemIds.length > 0 && (
                <div className="mt-3 rounded-xl border border-amber-400/50 bg-amber-950/50 px-3 py-2 text-xs font-bold text-amber-200">
                  🎁 Equipment Dropped:{' '}
                  {victorySummary.unlockedItemIds
                    .map((id) => getItemById(id)?.name)
                    .filter(Boolean)
                    .join(', ')}
                </div>
              )}

              <div className="mt-5 flex flex-col sm:flex-row gap-3">
                {world.id < 6 && (
                  <button
                    type="button"
                    onClick={() => onPlayNextWorld(world.id + 1)}
                    className="flex-1 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 py-3 text-sm font-extrabold text-slate-950 shadow-lg transition hover:brightness-110"
                  >
                    Enter World {world.id + 1} →
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onExitToMenu(0, 0, 0)}
                  className="flex-1 rounded-xl border border-purple-400/50 bg-purple-950/80 py-3 text-sm font-bold text-white transition hover:border-amber-300"
                >
                  Return to Sanctuary
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
