import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Check, Heart, Share2, Flame, Bell } from 'lucide-react';
import { PropheticPushMessage } from '../lib/propheticNotificationEngine';

export const PropheticWordToast: React.FC = () => {
  const [activeMessage, setActiveMessage] = useState<PropheticPushMessage | null>(null);
  const [hasReceivedWord, setHasReceivedWord] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    const handleEvent = (e: Event) => {
      const customEvent = e as CustomEvent<PropheticPushMessage>;
      if (customEvent.detail) {
        setActiveMessage(customEvent.detail);
        setHasReceivedWord(false);
      }
    };

    window.addEventListener('prophetic-push-received', handleEvent);
    return () => window.removeEventListener('prophetic-push-received', handleEvent);
  }, []);

  const handleAmenReceive = () => {
    setHasReceivedWord(true);
    // Also store in user's received prophecies
    try {
      if (activeMessage) {
        const stored = localStorage.getItem('juhnkrix_received_prophecies') || '[]';
        const list = JSON.parse(stored);
        list.unshift({ ...activeMessage, receivedAt: new Date().toISOString() });
        localStorage.setItem('juhnkrix_received_prophecies', JSON.stringify(list.slice(0, 30)));
      }
    } catch (e) {
      console.warn('Could not save received prophecy', e);
    }
    setTimeout(() => {
      setActiveMessage(null);
    }, 2500);
  };

  const handleCopyWord = () => {
    if (!activeMessage) return;
    const text = `🕊️ PROPHETIC WORD OF KNOWLEDGE\n${activeMessage.title}\n\n"${activeMessage.message}"\n\n📖 Scripture Anchor: ${activeMessage.scriptureAnchor}\n— Released by ${activeMessage.sender}\n(JUHNKRIX MUSIKA Sanctuary)`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {activeMessage && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -30, scale: 0.95 }}
          className="fixed top-6 right-4 sm:right-8 z-50 max-w-md w-full pointer-events-auto"
        >
          <div className="bg-gradient-to-br from-slate-900 via-amber-950/90 to-slate-950 border-2 border-amber-400/80 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-amber-500/20 backdrop-blur-xl space-y-4 relative overflow-hidden">
            {/* Top Glowing Beam */}
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-48 h-20 bg-amber-400/30 blur-2xl rounded-full pointer-events-none" />

            {/* Header Badge */}
            <div className="flex items-center justify-between border-b border-amber-500/30 pb-3">
              <div className="flex items-center space-x-2">
                <span className="p-1.5 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300">
                  <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
                </span>
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase text-amber-400 font-bold block">
                    Prophetic Push • Real-time Word
                  </span>
                  <span className="text-xs text-slate-300 font-serif font-bold">
                    {activeMessage.sender}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setActiveMessage(null)}
                className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Title & Category */}
            <div>
              <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-[10px] font-mono text-amber-300 mb-1.5">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>{activeMessage.category}</span>
              </div>
              <h4 className="text-base font-bold font-serif text-amber-100 leading-snug">
                {activeMessage.title}
              </h4>
            </div>

            {/* Message Body */}
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans bg-slate-950/60 p-3.5 rounded-2xl border border-amber-500/20">
              {activeMessage.message}
            </p>

            {/* Scripture Anchor */}
            <div className="text-[11px] font-serif italic text-amber-300/90 border-l-2 border-amber-500/50 pl-3 py-0.5">
              {activeMessage.scriptureAnchor}
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                onClick={handleCopyWord}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Share'}</span>
              </button>

              <button
                onClick={handleAmenReceive}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg cursor-pointer ${
                  hasReceivedWord
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:scale-102 text-slate-950 shadow-amber-500/20'
                }`}
              >
                {hasReceivedWord ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>Amen! Sealed in Faith</span>
                  </>
                ) : (
                  <>
                    <Heart className="w-4 h-4 fill-slate-950" />
                    <span>Amen! I Receive This Word</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
