import { Heart, MoreHorizontal, Play } from "lucide-react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { MediaItem } from "@/lib/media-types";
import { useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";
import { cn, formatBytes, formatDuration } from "@/lib/utils";

export function MediaPoster({
  item,
  thumb,
  className,
}: {
  item: MediaItem;
  thumb?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-md bg-secondary",
        item.kind === "audio" ? "aspect-square" : "aspect-video",
        className,
      )}
    >
      {thumb ? (
        <img src={thumb} alt="" className="size-full object-cover" />
      ) : (
        <div className="flex size-full items-center justify-center bg-[radial-gradient(circle_at_30%_20%,rgb(30_224_194_/_0.18),transparent_55%)]">
          <span className="font-display text-2xl font-semibold text-primary/80">
            {item.name.slice(0, 1).toUpperCase()}
          </span>
        </div>
      )}
      {item.duration > 0 ? (
        <span className="absolute bottom-1.5 right-1.5 rounded-sm bg-black/70 px-1.5 py-0.5 text-[10px] tabular-nums text-white">
          {formatDuration(item.duration)}
        </span>
      ) : null}
      {item.kind === "video" && item.position > 3 && item.duration > 0 ? (
        <span className="absolute inset-x-0 bottom-0 h-0.5 bg-black/40">
          <span
            className="block h-full bg-primary"
            style={{ width: `${Math.min(100, (item.position / item.duration) * 100)}%` }}
          />
        </span>
      ) : null}
    </div>
  );
}

export function MediaCard({
  item,
  queue,
  layout = "grid",
}: {
  item: MediaItem;
  queue: MediaItem[];
  layout?: "grid" | "list" | "rail";
}) {
  const thumb = useLibrary((s) => s.thumbs[item.id]);
  const toggleFavourite = useLibrary((s) => s.toggleFavourite);
  const open = usePlayer((s) => s.open);
  const navigate = useNavigate();

  const play = () => {
    open(item, queue);
    void navigate({ to: "/player/$id", params: { id: item.id } });
  };

  if (layout === "list") {
    return (
      <article className="flex items-center gap-3 rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]">
        <button
          type="button"
          onClick={play}
          className="relative w-28 shrink-0 overflow-hidden rounded-lg"
          aria-label={`Play ${item.name}`}
        >
          <MediaPoster item={item} thumb={thumb} />
        </button>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-medium">{item.name}</h3>
          <p className="mt-0.5 truncate text-xs text-muted">
            {item.folder} · {formatBytes(item.size)}
            {item.width && item.height ? ` · ${item.width}×${item.height}` : ""}
          </p>
          {!item.playable ? (
            <p className="mt-1 text-xs text-destructive">{item.unsupportedReason}</p>
          ) : null}
        </div>
        <ItemMenu item={item} />
        <Button size="icon" variant="ghost" onClick={() => toggleFavourite(item.id)} aria-label="Favourite">
          <Heart className={cn("size-4", item.favourite && "fill-primary text-primary")} />
        </Button>
        <Button size="icon" onClick={play} aria-label={`Play ${item.name}`}>
          <Play className="size-4 fill-current" />
        </Button>
      </article>
    );
  }

  return (
    <article className="group relative">
      <button type="button" onClick={play} className="block w-full text-left" aria-label={`Play ${item.name}`}>
        <MediaPoster item={item} thumb={thumb} className="rounded-lg" />
      </button>
      <div className="mt-2 flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-medium">{item.name}</h3>
          <p className="truncate text-xs text-muted">{item.folder}</p>
        </div>
        <ItemMenu item={item} />
      </div>
      {!item.linked && item.source === "local" ? (
        <Badge variant="muted" className="mt-1">
          Relink file
        </Badge>
      ) : null}
    </article>
  );
}

function ItemMenu({ item }: { item: MediaItem }) {
  const toggleFavourite = useLibrary((s) => s.toggleFavourite);
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="icon-sm" variant="ghost" aria-label={`More for ${item.name}`}>
          <MoreHorizontal />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem asChild>
          <Link to="/library" search={{ inspect: item.id }}>
            File information
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => toggleFavourite(item.id)}>
          {item.favourite ? "Remove favourite" : "Add to favourites"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/library" search={{ inspect: item.id, action: "rename" }}>
            Rename
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/library" search={{ inspect: item.id, action: "delete" }}>
            Delete
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function MediaRail({ title, items }: { title: string; items: MediaItem[] }) {
  if (!items.length) return null;
  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between">
        <h2 className="font-display text-lg font-semibold">{title}</h2>
      </div>
      <div className="rail-scroll -mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
        {items.map((item) => (
          <div key={item.id} className="w-40 shrink-0 sm:w-48">
            <MediaCard item={item} queue={items} layout="rail" />
          </div>
        ))}
      </div>
    </section>
  );
}
