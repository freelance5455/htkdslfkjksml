import React, { useMemo, useState } from 'react';
import { Gift } from 'lucide-react';
import { ClanDashboardState, ROLE_LABELS_RU } from '../shared/cocData';
import { computePlayerPeriodDeltas } from '../utils/clanAnalytics';
import { formatDateTimeRu } from '../utils/formatters';
import {
  SnapshotSeriesDef,
  SnapshotSeriesPoint,
  SnapshotTimeSeriesChart,
} from './ProgressCharts';

interface DonationsViewProps {
  state: ClanDashboardState;
  nowMs: number;
  onSelectPlayer: (tag: string) => void;
}

type DonSortKey = 'donations' | 'donationsReceived' | 'net' | 'growth';

export const DonationsView: React.FC<DonationsViewProps> = ({
  state,
  nowMs,
  onSelectPlayer,
}) => {
  const [period, setPeriod] = useState<'24h' | '7d' | '30d' | 'all'>('7d');
  const [sortBy, setSortBy] = useState<DonSortKey>('donations');

  const donationRows = useMemo(() => {
    const totalSent = state.players.reduce((s, p) => s + p.donations, 0);
    return state.players
      .map((p) => {
        const net = p.donations - p.donationsReceived;
        const ratio =
          p.donationsReceived > 0
            ? Number((p.donations / p.donationsReceived).toFixed(2))
            : p.donations > 0
            ? 99
            : 0;
        const sharePct = totalSent > 0 ? Number(((p.donations / totalSent) * 100).toFixed(1)) : 0;
        const deltas = computePlayerPeriodDeltas(state.snapshots, p.tag, nowMs);
        const match = deltas.find((d) => d.periodId === period);
        const growth = match && match.available ? match.deltas.donations : null;
        return {
          player: p,
          net,
          ratio,
          sharePct,
          growth,
        };
      })
      .sort((a, b) => {
        if (sortBy === 'donations') return b.player.donations - a.player.donations;
        if (sortBy === 'donationsReceived') {
          return b.player.donationsReceived - a.player.donationsReceived;
        }
        if (sortBy === 'net') return b.net - a.net;
        return (b.growth ?? -1) - (a.growth ?? -1);
      });
  }, [state.players, state.snapshots, nowMs, period, sortBy]);

  const totals = useMemo(() => {
    const sent = state.players.reduce((s, p) => s + p.donations, 0);
    const recv = state.players.reduce((s, p) => s + p.donationsReceived, 0);
    const donorsCount = state.players.filter((p) => p.donations > 0).length;
    const avgSent = state.players.length > 0 ? Math.round(sent / state.players.length) : 0;
    return { sent, recv, net: sent - recv, donorsCount, avgSent };
  }, [state.players]);

  const historySeriesPoints: SnapshotSeriesPoint[] = useMemo(() => {
    return state.snapshots.slice(-60).map((s) => ({
      id: s.id,
      timestamp: s.timestamp,
      values: {
        totalDonations: s.totalDonations,
        totalDonationsReceived: s.totalDonationsReceived,
      },
    }));
  }, [state.snapshots]);

  const seriesDefs: SnapshotSeriesDef[] = [
    { key: 'totalDonations', label: 'Отдано (сумма в клане)', color: '#10B981' },
    { key: 'totalDonationsReceived', label: 'Получено (сумма в клане)', color: '#38BDF8' },
  ];

  const recentDonationEvents = useMemo(
    () => state.clanEvents.filter((e) => e.type === 'donations_change').slice(0, 20),
    [state.clanEvents]
  );

  if (!state.clan || state.players.length === 0) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы анализировать пожертвования и историю донатов.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Пожертвования войск
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Отправленные, полученные войска, чистый баланс и прирост между снимками Supercell API
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start sm:self-auto">
          {(
            [
              { id: '24h', label: '24 часа' },
              { id: '7d', label: '7 дней' },
              { id: '30d', label: '30 дней' },
              { id: 'all', label: 'Всё время' },
            ] as const
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                period === p.id
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </section>

      {/* KPI Strip */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Отдано за сезон (клан)</div>
          <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-emerald-400">
            {totals.sent.toLocaleString('ru-RU')}
          </div>
          <div className="mt-0.5 font-mono text-[11px] text-slate-500 tabular-nums">
            В среднем {totals.avgSent.toLocaleString('ru-RU')} / игрок
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Получено за сезон (клан)</div>
          <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-sky-400">
            {totals.recv.toLocaleString('ru-RU')}
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Разница (отдано − получено)</div>
          <div
            className={`mt-1.5 font-mono text-2xl font-semibold tabular-nums ${
              totals.net >= 0 ? 'text-amber-400' : 'text-rose-400'
            }`}
          >
            {totals.net >= 0 ? `+${totals.net.toLocaleString('ru-RU')}` : totals.net.toLocaleString('ru-RU')}
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-4">
          <div className="text-xs text-slate-400">Активных донатеров</div>
          <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-slate-100">
            {totals.donorsCount} / {state.players.length}
          </div>
        </div>
      </section>

      {/* Chart + Recent Changes */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-8 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-100">
                История пожертвований по снимкам
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                Реальные значения сезонных счётчиков в каждом сохранённом снимке
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
              {seriesDefs.map((s) => (
                <span key={s.key} className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: s.color }} />
                  {s.label}
                </span>
              ))}
            </div>
          </div>
          <SnapshotTimeSeriesChart points={historySeriesPoints} series={seriesDefs} height={240} />
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-4 flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Gift className="h-4 w-4 text-emerald-400" />
              <h2 className="font-display text-base font-semibold text-slate-100">
                Недавние приросты
              </h2>
            </div>
            <span className="font-mono text-xs text-slate-400">{recentDonationEvents.length}</span>
          </div>

          <div className="mt-3 max-h-[250px] flex-1 divide-y divide-slate-800/70 overflow-y-auto pr-1">
            {recentDonationEvents.map((ev) => (
              <button
                key={ev.id}
                type="button"
                onClick={() => ev.playerTag && onSelectPlayer(ev.playerTag)}
                className="w-full py-2.5 text-left hover:bg-slate-800/30 rounded px-1.5 transition-colors"
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-100 truncate">{ev.playerName}</span>
                  <span className="font-mono font-semibold text-emerald-400 shrink-0">
                    {ev.deltaLabel}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center justify-between gap-2 text-[11px] text-slate-400">
                  <span className="truncate">{ev.description}</span>
                  <span className="font-mono text-slate-500 shrink-0">
                    {formatDateTimeRu(ev.timestamp)}
                  </span>
                </div>
              </button>
            ))}
            {recentDonationEvents.length === 0 && (
              <div className="py-10 text-center text-xs text-slate-500">
                Прирост пожертвований будет зафиксирован после следующего обновления клана.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Donors Leaderboard */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Рейтинг донатеров клана ({donationRows.length})
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Нажмите на игрока для перехода в подробный профиль
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
            {(
              [
                { id: 'donations', label: 'Отдано' },
                { id: 'donationsReceived', label: 'Получено' },
                { id: 'net', label: 'Баланс' },
                { id: 'growth', label: 'Прирост' },
              ] as const
            ).map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setSortBy(s.id)}
                className={`px-2.5 py-1 text-xs rounded whitespace-nowrap ${
                  sortBy === s.id
                    ? 'bg-slate-800 text-amber-400 font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                <th className="px-4 py-2.5">#</th>
                <th className="px-4 py-2.5">Игрок</th>
                <th className="px-3 py-2.5 text-right">TH</th>
                <th className="px-3 py-2.5 text-right">Отдано</th>
                <th className="px-3 py-2.5 text-right">Получено</th>
                <th className="px-3 py-2.5 text-right">Разница</th>
                <th className="px-3 py-2.5 text-right">Коэфф.</th>
                <th className="px-3 py-2.5 text-right">Прирост ({period})</th>
                <th className="px-4 py-2.5 text-right">Доля</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {donationRows.map((row, idx) => {
                const p = row.player;
                return (
                  <tr
                    key={p.tag}
                    onClick={() => onSelectPlayer(p.tag)}
                    className="cursor-pointer hover:bg-slate-800/35 transition-colors"
                  >
                    <td className="px-4 py-2.5 font-mono tabular-nums text-amber-400">#{idx + 1}</td>
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      <div className="font-medium text-slate-100">{p.name}</div>
                      <div className="font-mono text-[11px] text-slate-500">
                        {p.tag} · {ROLE_LABELS_RU[p.role]}
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                      {p.townHallLevel}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-emerald-400">
                      {p.donations.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                      {p.donationsReceived.toLocaleString('ru-RU')}
                    </td>
                    <td
                      className={`px-3 py-2.5 text-right font-mono font-semibold tabular-nums ${
                        row.net >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {row.net >= 0 ? `+${row.net.toLocaleString('ru-RU')}` : row.net.toLocaleString('ru-RU')}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {row.ratio === 99 ? '∞' : `${row.ratio.toFixed(2)}×`}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                      {row.growth !== null ? `+${row.growth.toLocaleString('ru-RU')}` : '—'}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-400">
                      {row.sharePct.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
