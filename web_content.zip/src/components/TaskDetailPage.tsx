/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, Check, X, Ban, CornerDownRight, ArrowRight, Clock } from 'lucide-react';
import { TaskStatus, ToDoTask } from '../types.ts';
import {
  formatDateToBengali,
  getTaskStatusOnDate,
  getTodayDateString,
  toBengaliNum,
  diffInDays,
  addDays,
  isDateScheduled,
} from '../utils/dateUtils.ts';
import { CalendarPlanning } from './CalendarPlanning.tsx';
import { EmptyState } from './EmptyState.tsx';

type DetailTab = 'done' | 'not_done' | 'wont_do' | 'postponed' | 'planning';

interface TaskDetailPageProps {
  task: ToDoTask;
  groupName: string;
  onUpdateReport: (dateStr: string, status: TaskStatus | null, postponedTo?: string) => void;
  onBack: () => void;
}

export const TaskDetailPage: React.FC<TaskDetailPageProps> = ({
  task,
  groupName,
  onUpdateReport,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<DetailTab>('done');
  const today = getTodayDateString();

  // If planning tab is selected, render CalendarPlanning
  if (activeTab === 'planning') {
    return (
      <CalendarPlanning
        task={task}
        onUpdateReport={onUpdateReport}
        onBack={() => setActiveTab('done')}
      />
    );
  }

  // Calculate dates for each of the 4 lists (sorted newest to oldest)
  // Let's gather all evaluated dates:
  // From task.createdAt (or earlier if reported) to today + 365 days
  const allRecordedDates = new Set<string>();

  // Add all explicit report dates
  if (task.reports) {
    Object.keys(task.reports).forEach((d) => allRecordedDates.add(d));
  }
  if (task.postponedDates) {
    Object.keys(task.postponedDates).forEach((d) => allRecordedDates.add(d));
  }

  // Add past scheduled dates (last 100 days rolling window) on or after task.createdAt for auto not_done
  for (let i = 1; i <= 100; i++) {
    const d = addDays(today, -i);
    if ((!task.createdAt || d >= task.createdAt) && isDateScheduled(task, d)) {
      allRecordedDates.add(d);
    }
  }

  // Also include today if reported or scheduled
  allRecordedDates.add(today);

  // Group dates by status
  const doneDates: string[] = [];
  const notDoneDates: string[] = [];
  const wontDoDates: string[] = [];
  const postponedList: Array<{ fromDate: string; toDate: string }> = [];

  Array.from(allRecordedDates).forEach((dateStr) => {
    const status = getTaskStatusOnDate(task, dateStr, today);
    if (status === 'done') {
      doneDates.push(dateStr);
    } else if (status === 'not_done') {
      notDoneDates.push(dateStr);
    } else if (status === 'wont_do') {
      wontDoDates.push(dateStr);
    } else if (status === 'postponed') {
      const target = task.postponedDates?.[dateStr] || '';
      postponedList.push({ fromDate: dateStr, toDate: target });
    }
  });

  // Sort newest to oldest
  doneDates.sort((a, b) => b.localeCompare(a));
  notDoneDates.sort((a, b) => b.localeCompare(a));
  wontDoDates.sort((a, b) => b.localeCompare(a));
  postponedList.sort((a, b) => b.fromDate.localeCompare(a.fromDate));

  const tabs: Array<{ id: DetailTab; label: string; count?: number; icon?: React.ReactNode }> = [
    {
      id: 'done',
      label: 'করেছি',
      count: doneDates.length,
      icon: <Check className="w-3.5 h-3.5 stroke-[2.5] text-emerald-600" />,
    },
    {
      id: 'not_done',
      label: 'করিনি',
      count: notDoneDates.length,
      icon: <X className="w-3.5 h-3.5 stroke-[2.5] text-rose-600" />,
    },
    {
      id: 'wont_do',
      label: 'করবো না',
      count: wontDoDates.length,
      icon: <Ban className="w-3.5 h-3.5 stroke-[2.5] text-amber-600" />,
    },
    {
      id: 'postponed',
      label: 'পরে করবো',
      count: postponedList.length,
      icon: <CornerDownRight className="w-3.5 h-3.5 stroke-[2.5] text-blue-600" />,
    },
    {
      id: 'planning',
      label: 'প্ল্যানিং',
      icon: <Calendar className="w-3.5 h-3.5 stroke-[2.5] text-purple-600" />,
    },
  ];

  return (
    <div className="pb-28 max-w-md mx-auto px-4 pt-3">
      {/* Header Info */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs mb-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
          <span>গ্রুপ: {groupName}</span>
          <span>•</span>
          <span>তৈরি: {formatDateToBengali(task.createdAt, false)}</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900 leading-snug">{task.name}</h2>
        {task.details && (
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">{task.details}</p>
        )}
      </div>

      {/* 5 Tab Navigation Buttons */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 rounded-2xl mb-4 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 shrink-0 transition-all ${
                isActive
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[11px] px-1.5 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-slate-100 text-slate-700' : 'bg-slate-300/60 text-slate-600'
                  }`}
                >
                  {toBengaliNum(tab.count)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content: Dates list (Newest to Oldest) */}
      <div className="space-y-2">
        {activeTab === 'done' && (
          <>
            {doneDates.length === 0 ? (
              <EmptyState
                message="এখনও কোনো তারিখ 'করেছি' হিসেবে নেই।"
                subMessage="প্ল্যানিং ক্যালেন্ডার থেকে যেকোনো তারিখে রিপোর্ট দিতে পারেন।"
              />
            ) : (
              doneDates.map((d) => (
                <div
                  key={d}
                  className="p-3 rounded-2xl bg-white border border-emerald-100 shadow-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                      <Check className="w-4 h-4 stroke-[3]" />
                    </span>
                    <span className="text-sm font-semibold text-slate-800">
                      {formatDateToBengali(d)}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                    করেছি
                  </span>
                </div>
              ))
            )}
          </>
        )}

        {activeTab === 'not_done' && (
          <>
            {notDoneDates.length === 0 ? (
              <EmptyState
                message="কোনো 'করিনি' তারিখ নেই।"
                subMessage="আপনি সব কাজ সময়ে সম্পন্ন করেছেন!"
              />
            ) : (
              notDoneDates.map((d) => (
                <div
                  key={d}
                  className="p-3 rounded-2xl bg-white border border-rose-100 shadow-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-xs">
                      <X className="w-4 h-4 stroke-[3]" />
                    </span>
                    <span className="text-sm font-semibold text-slate-800">
                      {formatDateToBengali(d)}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200">
                    করিনি
                  </span>
                </div>
              ))
            )}
          </>
        )}

        {activeTab === 'wont_do' && (
          <>
            {wontDoDates.length === 0 ? (
              <EmptyState
                message="কোনো 'করবো না' তারিখ নেই।"
                subMessage="এই কাজের জন্য কোনো দিন বাদ দেওয়া হয়নি।"
              />
            ) : (
              wontDoDates.map((d) => (
                <div
                  key={d}
                  className="p-3 rounded-2xl bg-white border border-amber-100 shadow-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs">
                      <Ban className="w-4 h-4 stroke-[2.5]" />
                    </span>
                    <span className="text-sm font-semibold text-slate-800">
                      {formatDateToBengali(d)}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                    করবো না
                  </span>
                </div>
              ))
            )}
          </>
        )}

        {activeTab === 'postponed' && (
          <>
            {postponedList.length === 0 ? (
              <EmptyState
                message="কোনো 'পরে করবো' তারিখ নেই।"
                subMessage="কোনো দিন পেছানো হয়নি।"
              />
            ) : (
              postponedList.map((item, idx) => (
                <div
                  key={`${item.fromDate}-${idx}`}
                  className="p-3 rounded-2xl bg-white border border-blue-100 shadow-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      <CornerDownRight className="w-4 h-4 stroke-[2.5]" />
                    </span>
                    <div className="text-sm font-semibold text-slate-800 flex items-center gap-1.5 flex-wrap">
                      <span>{formatDateToBengali(item.fromDate, false)}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-blue-500" />
                      <span className="text-blue-700 font-bold">
                        {item.toDate ? formatDateToBengali(item.toDate, false) : 'অনির্দিষ্ট'}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-lg border border-blue-200 shrink-0">
                    পরে করবো
                  </span>
                </div>
              ))
            )}
          </>
        )}
      </div>
    </div>
  );
};
