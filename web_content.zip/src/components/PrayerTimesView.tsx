import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  MapPin, 
  RefreshCw, 
  Compass, 
  Sunrise, 
  Sun, 
  SunMedium, 
  Sunset, 
  Moon, 
  MoonStar, 
  Sparkles, 
  ChevronDown, 
  Info, 
  Check, 
  Calendar,
  Volume2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { 
  calculatePrayerTimes, 
  PrayerTimesResult, 
  CalculationMethod, 
  CALCULATION_METHODS,
  formatRemainingTime,
  formatRemainingTimeArabicWords,
  PrayerId
} from '../utils/prayerTimesService';
import { requestCoordinates, getSavedCoordinates } from '../utils/solarTimeService';
import { POPULAR_CITIES, CityPreset } from '../utils/qiblaService';
import { triggerVibration } from '../utils/audioFeedback';

export const PrayerTimesView: React.FC = () => {
  const { 
    setActiveTab, 
    showToast, 
    settings, 
    userCoordinates, 
    refreshLocationForSolarTimes, 
    isDetectingLocation 
  } = useApp();
  
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [calculationMethod, setCalculationMethod] = useState<CalculationMethod>(() => {
    try {
      const saved = localStorage.getItem('hisn_prayer_method');
      if (saved && saved in CALCULATION_METHODS) return saved as CalculationMethod;
    } catch {}
    return 'Makkah';
  });

  const [coords, setCoords] = useState<{ lat: number; lng: number; city: string; isLive: boolean }>(() => {
    const saved = userCoordinates || getSavedCoordinates();
    if (saved) {
      return { lat: saved.latitude, lng: saved.longitude, city: saved.city || 'موقعك الجغرافي', isLive: true };
    }
    // Default to Makkah Al-Mukarramah
    return { lat: 21.4225, lng: 39.8262, city: 'مكة المكرمة، السعودية', isLive: false };
  });

  // Sync reactively whenever userCoordinates updates from online fetch or GPS
  useEffect(() => {
    if (userCoordinates) {
      setCoords({
        lat: userCoordinates.latitude,
        lng: userCoordinates.longitude,
        city: userCoordinates.city || 'موقعك الجغرافي',
        isLive: true,
      });
    }
  }, [userCoordinates]);

  const [showCityPicker, setShowCityPicker] = useState<boolean>(false);
  const [showMethodPicker, setShowMethodPicker] = useState<boolean>(false);

  // Live tick every second for real-time countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDate(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Compute prayer times
  const prayerResult: PrayerTimesResult = calculatePrayerTimes(
    currentDate,
    coords.lat,
    coords.lng,
    calculationMethod,
    coords.city
  );

  const handleRefreshLocation = async () => {
    triggerVibration(settings.vibration !== false, 'light');
    await refreshLocationForSolarTimes(false);
  };

  const handleSelectCity = (preset: CityPreset) => {
    triggerVibration(settings.vibration !== false, 'tap');
    setCoords({
      lat: preset.latitude,
      lng: preset.longitude,
      city: `${preset.name}، ${preset.country}`,
      isLive: false,
    });
    setShowCityPicker(false);
    showToast(`تم تغيير المدينة إلى: ${preset.name}`);
  };

  const handleSelectMethod = (method: CalculationMethod) => {
    triggerVibration(settings.vibration !== false, 'tap');
    setCalculationMethod(method);
    try {
      localStorage.setItem('hisn_prayer_method', method);
    } catch {}
    setShowMethodPicker(false);
    showToast(`طريقة الحساب: ${CALCULATION_METHODS[method].nameArabic}`);
  };

  const getPrayerIcon = (id: PrayerId, className: string = 'w-5 h-5') => {
    switch (id) {
      case 'fajr':
        return <Sunrise className={className} />;
      case 'sunrise':
        return <Sun className={className} />;
      case 'dhuhr':
        return <SunMedium className={className} />;
      case 'asr':
        return <Sunset className={className} />;
      case 'maghrib':
        return <Moon className={className} />;
      case 'isha':
      default:
        return <MoonStar className={className} />;
    }
  };

  const nextPrayer = prayerResult.nextPrayer;
  const remainingSecs = nextPrayer.remainingSeconds;

  return (
    <div className="space-y-4 pb-28 pt-1 text-right animate-in fade-in duration-300">
      {/* Top Header Card */}
      <div className="flex items-center justify-between gap-2 border-b border-emerald-800/40 pb-3">
        <div>
          <h1 className="text-xl font-extrabold text-[#e8f5ee] font-cairo flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-300" />
            <span>مواقيت الصلاة</span>
          </h1>
          <p className="text-xs text-[#84b8a0] font-tajawal mt-0.5">
            مواقيت دقيقة حسب موقعك الجغرافي مع عدّاد الصلاة القادمة
          </p>
        </div>

        {/* Action icons: refresh location & open Qibla */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleRefreshLocation}
            disabled={isDetectingLocation}
            className="p-2 rounded-xl bg-[#042017] hover:bg-[#073022] text-amber-300 border border-emerald-700/60 transition-colors cursor-pointer relative"
            title="تحديث الموقع الجغرافي عبر GPS"
            aria-label="تحديث الموقع الجغرافي"
          >
            <RefreshCw className={`w-4 h-4 ${isDetectingLocation ? 'animate-spin text-amber-400' : ''}`} />
          </button>

          <button
            onClick={() => setActiveTab('qibla')}
            className="p-2 rounded-xl bg-[#042017] hover:bg-[#073022] text-emerald-300 border border-emerald-700/60 transition-colors cursor-pointer"
            title="الانتقال إلى بوصلة القبلة"
            aria-label="بوصلة القبلة"
          >
            <Compass className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Location & Hijri Date Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-2xl bg-[#042017] border border-emerald-700/60 shadow-xs">
        {/* City selector dropdown trigger */}
        <button
          onClick={() => {
            triggerVibration(settings.vibration !== false, 'light');
            setShowCityPicker(!showCityPicker);
          }}
          className="flex items-center gap-1.5 text-xs font-bold text-amber-300 font-cairo hover:text-amber-200 cursor-pointer"
          title="اضغط لاختيار مدينة أخرى"
        >
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <span className="truncate max-w-[170px]">{coords.city}</span>
          <ChevronDown className={`w-3.5 h-3.5 text-amber-400/80 transition-transform ${showCityPicker ? 'rotate-180' : ''}`} />
          {coords.isLive && (
            <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
              GPS 📍
            </span>
          )}
        </button>

        {/* Hijri Calendar Date */}
        <div className="flex items-center gap-1.5 text-xs text-emerald-300 font-tajawal">
          <Calendar className="w-3.5 h-3.5 text-emerald-400" />
          <span>{prayerResult.dateHijriFormatted}</span>
        </div>
      </div>

      {/* City Picker Drawer */}
      {showCityPicker && (
        <div className="p-3 rounded-2xl bg-[#021811] border border-amber-500/40 space-y-2 animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center justify-between pb-1 border-b border-emerald-800/40">
            <span className="text-xs font-bold text-amber-300 font-cairo">
              اختر المدينة لتحديد مواقيت الصلاة:
            </span>
            <button
              onClick={handleRefreshLocation}
              className="text-[10px] font-bold text-emerald-300 hover:text-white flex items-center gap-1 cursor-pointer bg-emerald-800/40 px-2 py-0.5 rounded-lg border border-emerald-600/40"
            >
              <RefreshCw className="w-3 h-3" />
              <span>موقعي الحالي تلقائياً</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-48 overflow-y-auto pr-1">
            {POPULAR_CITIES.map((c) => {
              const isSelected = coords.city.includes(c.name);
              return (
                <button
                  key={c.name}
                  onClick={() => handleSelectCity(c)}
                  className={`p-2 rounded-xl text-right text-xs font-tajawal transition-all flex items-center justify-between cursor-pointer border ${
                    isSelected
                      ? 'bg-amber-500/25 border-amber-400 text-amber-200 font-bold'
                      : 'bg-[#042017] border-emerald-800/60 text-[#c8e6d8] hover:bg-[#073023]'
                  }`}
                >
                  <div className="truncate">
                    <span className="block font-bold">{c.name}</span>
                    <span className="text-[10px] text-[#84b8a0]">{c.country}</span>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* 1. HERO COUNTDOWN CARD (بطاقة الصلاة القادمة والعد التنازلي المباشر) */}
      {/* ======================================================================= */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-[#053d2b] via-[#03291d] to-[#021811] border border-amber-400/50 shadow-lg relative overflow-hidden text-right">
        {/* Glow ambient background effect */}
        <div className="absolute -top-12 -left-12 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-bold font-cairo shadow-2xs">
                <Sparkles className="w-3 h-3 text-amber-400 animate-spin [animation-duration:8s]" />
                <span>الصلاة القادمة</span>
              </span>
              <span className="text-xs text-emerald-300/80 font-tajawal">
                عند الأذان
              </span>
            </div>

            <h2 className="text-3xl font-black text-amber-300 font-cairo mt-2 flex items-baseline gap-2">
              <span>صلاة {nextPrayer.nameArabic}</span>
              <span className="text-sm font-semibold text-[#c8e6d8] font-mono">
                {nextPrayer.timeFormatted}
              </span>
            </h2>

            <p className="text-xs text-emerald-200/90 font-tajawal mt-1">
              متبقي: <strong className="text-amber-200">{formatRemainingTimeArabicWords(remainingSecs)}</strong>
            </p>
          </div>

          {/* Large dynamic icon */}
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/30 text-amber-300 border border-amber-400/40 flex items-center justify-center shrink-0 shadow-md">
            {getPrayerIcon(nextPrayer.id, 'w-8 h-8 text-amber-300 drop-shadow-[0_0_8px_rgba(253,230,138,0.5)]')}
          </div>
        </div>

        {/* Live Digital Countdown Clock Display */}
        <div className="mt-4 pt-3 border-t border-amber-500/25 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-200 font-cairo">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>العد التنازلي حتى الأذان:</span>
          </div>

          <div className="font-mono text-2xl font-black tracking-wider text-amber-300 bg-black/40 px-3.5 py-1 rounded-xl border border-amber-400/30 shadow-inner">
            {formatRemainingTime(remainingSecs)}
          </div>
        </div>
      </div>

      {/* ======================================================================= */}
      {/* 2. ALL PRAYER TIMES LIST (عرض أوقات الصلوات الخمس والشروق) */}
      {/* ======================================================================= */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-[#e8f5ee] font-cairo">
            مواقيت اليوم في {coords.city}
          </h3>
          <span className="text-[11px] text-[#84b8a0] font-tajawal">
            {CALCULATION_METHODS[calculationMethod].nameArabic}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-2">
          {prayerResult.prayers.map((prayer) => {
            const isNext = prayer.isNext;
            const isPassed = prayer.isPassed;

            return (
              <div
                key={prayer.id}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between ${
                  isNext
                    ? 'bg-gradient-to-r from-[#063f2d] via-[#043324] to-[#063f2d] border-amber-400 shadow-md ring-1 ring-amber-400/40'
                    : isPassed
                      ? 'bg-[#031d14]/70 border-emerald-900/40 text-emerald-300/70'
                      : 'bg-[#042017] border-emerald-800/60 hover:border-emerald-600/60 text-[#e8f5ee]'
                }`}
              >
                {/* Left: icon + name */}
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    isNext
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : isPassed
                        ? 'bg-emerald-950/40 border-emerald-800/40 text-emerald-400/60'
                        : 'bg-[#062c20] border-emerald-700/50 text-emerald-300'
                  }`}>
                    {getPrayerIcon(prayer.id, 'w-5 h-5')}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-extrabold font-cairo ${isNext ? 'text-amber-300' : 'text-[#e8f5ee]'}`}>
                        {prayer.nameArabic}
                      </span>
                      {isNext && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-400 text-[#0c2e20] font-bold font-cairo">
                          الصلاة القادمة
                        </span>
                      )}
                      {prayer.id === 'sunrise' && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-amber-950/60 text-amber-400/80 border border-amber-800/30">
                          شروق الشمس
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[#84b8a0] font-tajawal">
                      {isPassed ? 'مضى وقتها' : isNext ? 'متبقي ' + formatRemainingTimeArabicWords(remainingSecs) : 'في موعدها'}
                    </span>
                  </div>
                </div>

                {/* Right: formatted time */}
                <div className="text-left font-mono">
                  <div className={`text-base font-bold ${isNext ? 'text-amber-300 font-extrabold text-lg' : 'text-[#f0fbf5]'}`}>
                    {prayer.timeFormatted}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ======================================================================= */}
      {/* 3. CALCULATION METHOD SELECTOR BUTTON / MODAL */}
      {/* ======================================================================= */}
      <div className="pt-1">
        <button
          onClick={() => {
            triggerVibration(settings.vibration !== false, 'light');
            setShowMethodPicker(!showMethodPicker);
          }}
          className="w-full p-3 rounded-2xl bg-[#032017] border border-emerald-800/60 hover:border-emerald-600/70 transition-all text-right flex items-center justify-between cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-900/40 text-emerald-300 border border-emerald-700/40">
              <Info className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <span className="text-xs font-bold text-[#e8f5ee] font-cairo block">
                طريقة حساب المواقيت: {CALCULATION_METHODS[calculationMethod].nameArabic}
              </span>
              <span className="text-[10px] text-[#84b8a0] font-tajawal">
                انقر لتغيير الهيئة الحسابية المعتمدة
              </span>
            </div>
          </div>
          <ChevronDown className={`w-4 h-4 text-emerald-400 transition-transform ${showMethodPicker ? 'rotate-180' : ''}`} />
        </button>

        {showMethodPicker && (
          <div className="mt-2 p-3 rounded-2xl bg-[#021811] border border-emerald-700/60 space-y-1.5 animate-in fade-in duration-150">
            <span className="text-xs font-bold text-amber-300 font-cairo block mb-1">
              اختر الهيئة أو التقويم المعتمد:
            </span>
            {(Object.keys(CALCULATION_METHODS) as CalculationMethod[]).map((key) => {
              const m = CALCULATION_METHODS[key];
              const isSelected = calculationMethod === key;
              return (
                <button
                  key={key}
                  onClick={() => handleSelectMethod(key)}
                  className={`w-full p-2.5 rounded-xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-bold'
                      : 'bg-[#042017] border-emerald-800/60 text-[#c8e6d8] hover:bg-[#073023]'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold font-cairo">{m.nameArabic}</div>
                    <div className="text-[10px] text-[#84b8a0] font-mono">{m.name}</div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Direct Qibla & Athkar Links Banner */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        <button
          onClick={() => setActiveTab('qibla')}
          className="p-3 rounded-2xl bg-[#042017] border border-emerald-700/60 hover:border-amber-400/60 transition-all flex items-center gap-2 text-right cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#e8f5ee] font-cairo block group-hover:text-amber-200">
              بوصلة القبلة
            </span>
            <span className="text-[10px] text-[#84b8a0] font-tajawal">
              تحديد اتجاه الكعبة بدقة
            </span>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('morning_evening')}
          className="p-3 rounded-2xl bg-[#042017] border border-emerald-700/60 hover:border-emerald-500 transition-all flex items-center gap-2 text-right cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Sun className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#e8f5ee] font-cairo block group-hover:text-emerald-200">
              أذكار الصباح والمساء
            </span>
            <span className="text-[10px] text-[#84b8a0] font-tajawal">
              حصنك اليومي المتكامل
            </span>
          </div>
        </button>
      </div>
    </div>
  );
};
