import React, { useState } from 'react';

interface PlayerHeadProps {
  identifier: string; // name or displayName or uuid
  uuid?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  alt?: string;
}

const sizeMap = {
  sm: { px: 32, class: 'w-8 h-8' },
  md: { px: 48, class: 'w-12 h-12' },
  lg: { px: 64, class: 'w-16 h-16' },
  xl: { px: 128, class: 'w-32 h-32' },
};

export const PlayerHead: React.FC<PlayerHeadProps> = ({
  identifier,
  uuid,
  size = 'md',
  className = '',
  alt
}) => {
  const [sourceIndex, setSourceIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Clean identifier without prefixes if needed
  const cleanName = identifier.replace(/^[.*_]/, '');
  const pixelSize = sizeMap[size].px;

  // Ordered list of skin/head providers
  const sources = [
    // 1. Internal server skin endpoint (handles Geyser/Bedrock XUID & Java texture)
    `/api/skin/${encodeURIComponent(identifier)}`,
    // 2. mc-heads.net with clean name
    `https://mc-heads.net/avatar/${encodeURIComponent(cleanName || identifier)}/${pixelSize}`,
    // 3. Crafatar with UUID if available
    uuid && !uuid.startsWith('00000000-0000-0000') ? `https://crafatar.com/avatars/${uuid}?size=${pixelSize}&overlay` : null,
    // 4. Minotar helm
    `https://minotar.net/helm/${encodeURIComponent(cleanName || 'Steve')}/${pixelSize}.png`,
    // 5. Fallback Steve
    `https://mc-heads.net/avatar/Steve/${pixelSize}`
  ].filter(Boolean) as string[];

  const currentSrc = sources[Math.min(sourceIndex, sources.length - 1)];

  const handleError = () => {
    if (sourceIndex < sources.length - 1) {
      setSourceIndex(prev => prev + 1);
    } else {
      setIsLoading(false);
    }
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-lg overflow-hidden bg-zinc-800/80 border border-zinc-700/60 shadow-inner ${sizeMap[size].class} ${className}`}
    >
      {isLoading && (
        <div className="absolute inset-0 bg-zinc-800 animate-pulse" />
      )}
      <img
        src={currentSrc}
        alt={alt || `${identifier}'s Kopf`}
        className={`w-full h-full pixelated object-contain transition-opacity duration-200 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
        onLoad={() => setIsLoading(false)}
        onError={handleError}
        loading="lazy"
      />
    </div>
  );
};
