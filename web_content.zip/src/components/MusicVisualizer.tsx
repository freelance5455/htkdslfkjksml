import React, { useEffect, useRef } from 'react';

interface MusicVisualizerProps {
  isPlaying: boolean;
  barCount?: number;
  audioRef?: React.RefObject<HTMLAudioElement | null>;
}

export const MusicVisualizer: React.FC<MusicVisualizerProps> = ({ isPlaying, barCount = 24, audioRef }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const barWidth = width / barCount - 3;

      phase += 0.08;

      for (let i = 0; i < barCount; i++) {
        let barHeight = 6;
        if (isPlaying) {
          // Dynamic procedural wave simulating audio frequency response
          const sinValue = Math.sin(phase + i * 0.35) * 0.5 + 0.5;
          const cosValue = Math.cos(phase * 1.2 + i * 0.2) * 0.5 + 0.5;
          barHeight = Math.max(8, (sinValue * 0.6 + cosValue * 0.4) * (height - 12));
        }

        const x = i * (barWidth + 3);
        const y = height - barHeight;

        // Gradient bar styling
        const gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, '#0f172a');
        gradient.addColorStop(0.5, '#3b82f6');
        gradient.addColorStop(1, '#60a5fa');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(x, y, barWidth, barHeight, [4, 4, 0, 0]);
        } else {
          ctx.rect(x, y, barWidth, barHeight);
        }
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, barCount]);

  return (
    <div className="w-full flex items-center justify-center p-4">
      <canvas
        ref={canvasRef}
        width={320}
        height={80}
        className="w-full max-w-sm h-20 bg-slate-900/40 rounded-2xl backdrop-blur-md border border-white/10 shadow-inner"
      />
    </div>
  );
};
