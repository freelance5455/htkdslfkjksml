import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Send,
  MoreVertical,
  ShieldAlert,
  Ban,
  ChevronLeft,
  Check,
  CheckCheck,
  X,
  Users,
} from 'lucide-react';
import { ChatMessage, UserProfile } from '../types';
import { getAllUsers, subscribeMessages, sendChatMessage } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface MessagesScreenProps {
  onBack: () => void;
  onSelectCreator: (username: string) => void;
}

export const MessagesScreen: React.FC<MessagesScreenProps> = ({ onBack, onSelectCreator }) => {
  const { userProfile } = useAuth();
  const [conversations, setConversations] = useState<UserProfile[]>([]);
  const [activePartner, setActivePartner] = useState<UserProfile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState('');
  const [blockedUsers, setBlockedUsers] = useState<Set<string>>(new Set());
  const [showOptions, setShowOptions] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportSuccess, setReportSuccess] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const myId = userProfile?.id || 'guest-user';
  const partnerId = activePartner?.id || '';
  const conversationId = partnerId ? [myId, partnerId].sort().join('_') : '';

  useEffect(() => {
    async function load() {
      const users = await getAllUsers(20);
      const available = users.filter((u) => u.id !== userProfile?.id && u.username !== userProfile?.username);
      setConversations(available);
      if (available.length > 0 && !activePartner) {
        setActivePartner(available[0]);
      }
    }
    load();
  }, [userProfile?.id, userProfile?.username]);

  useEffect(() => {
    if (!conversationId) return;
    const unsubscribe = subscribeMessages(conversationId, (loaded) => {
      setMessages(loaded);
    });

    return () => unsubscribe();
  }, [conversationId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!text.trim() || !activePartner) return;
    const msgText = text.trim();
    setText('');

    // Optimistic message
    const tempMsg: ChatMessage = {
      id: `temp-${Date.now()}`,
      conversationId,
      senderId: myId,
      receiverId: partnerId,
      text: msgText,
      read: false,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempMsg]);

    try {
      await sendChatMessage(myId, partnerId, msgText);
    } catch {
      // ignore
    }
  };

  const handleToggleBlock = () => {
    if (!activePartner) return;
    setBlockedUsers((prev) => {
      const next = new Set(prev);
      if (next.has(activePartner.id)) {
        next.delete(activePartner.id);
      } else {
        next.add(activePartner.id);
      }
      return next;
    });
    setShowOptions(false);
  };

  const handleSendReport = () => {
    setReportSuccess(true);
    setTimeout(() => {
      setReportSuccess(false);
      setReportModalOpen(false);
    }, 1500);
  };

  const isCurrentBlocked = activePartner ? blockedUsers.has(activePartner.id) : false;

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen bg-[#050505] text-white flex flex-col justify-between pb-24 md:pb-8 animate-fade-in select-none">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#19191F] bg-[#050505]/90 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1 -ml-1 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F]"
          >
            <ChevronLeft size={22} />
          </button>
          {activePartner ? (
            <div
              onClick={() => onSelectCreator(activePartner.username)}
              className="flex items-center gap-2.5 cursor-pointer"
            >
              <div className="relative">
                <img
                  src={activePartner.photoURL}
                  alt={activePartner.displayName}
                  className="w-9 h-9 rounded-full object-cover border border-[#272730]"
                />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#20E060] border-2 border-[#050505]" />
              </div>
              <div className="text-left">
                <h3 className="text-xs font-bold text-white leading-tight">
                  {activePartner.displayName}
                </h3>
                <span className="text-[10px] text-[#A1A1AA]">@{activePartner.username}</span>
              </div>
            </div>
          ) : (
            <h1 className="text-lg font-bold text-white">Mensagens</h1>
          )}
        </div>

        {activePartner && (
          <div className="relative">
            <button
              onClick={() => setShowOptions((v) => !v)}
              className="p-1.5 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F]"
            >
              <MoreVertical size={18} />
            </button>

            {showOptions && (
              <div className="absolute right-0 top-8 z-40 w-44 bg-[#101014] border border-[#272730] rounded-2xl p-1.5 shadow-2xl">
                <button
                  onClick={handleToggleBlock}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-white hover:bg-[#19191F] flex items-center gap-2"
                >
                  <Ban size={14} className="text-[#FF3B30]" />
                  <span>{isCurrentBlocked ? 'Desbloquear' : 'Bloquear usuário'}</span>
                </button>
                <button
                  onClick={() => {
                    setShowOptions(false);
                    setReportModalOpen(true);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-[#FF3B30] hover:bg-[#19191F] flex items-center gap-2"
                >
                  <ShieldAlert size={14} />
                  <span>Denunciar conversa</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Conversations Switcher Bar */}
      <div className="flex items-center gap-3 overflow-x-auto no-scrollbar px-5 py-3 border-b border-[#19191F] bg-[#0a0a0f]">
        {conversations.map((c) => (
          <button
            key={c.id}
            onClick={() => setActivePartner(c)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all ${
              activePartner?.id === c.id
                ? 'bg-clipshare-gradient text-white shadow-md'
                : 'bg-[#101014] text-[#A1A1AA] hover:text-white border border-[#19191F]'
            }`}
          >
            <img src={c.photoURL} alt={c.username} className="w-5 h-5 rounded-full object-cover" />
            <span>@{c.username}</span>
          </button>
        ))}
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3.5">
        {isCurrentBlocked ? (
          <div className="py-12 text-center text-xs text-[#A1A1AA]">
            Você bloqueou este usuário. As mensagens estão ocultas.
          </div>
        ) : messages.length === 0 ? (
          <div className="py-12 text-center text-xs text-[#A1A1AA]">
            Inicie uma conversa privada com @{activePartner?.username}!
          </div>
        ) : (
          messages.map((m) => {
            const isMe = m.senderId === myId;
            return (
              <div
                key={m.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-4 py-2.5 rounded-2xl text-xs md:text-sm leading-relaxed ${
                    isMe
                      ? 'bg-clipshare-gradient text-white rounded-br-none shadow-md'
                      : 'bg-[#19191F] text-white/95 rounded-bl-none border border-[#272730]'
                  }`}
                >
                  <p>{m.text}</p>
                </div>
                <span className="text-[10px] text-[#A1A1AA] mt-1 px-1">
                  {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Message Input */}
      {!isCurrentBlocked ? (
        <div className="p-3 bg-[#050505] border-t border-[#19191F] flex items-center gap-2">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={`Conversar com @${activePartner?.username || 'criador'}...`}
            className="flex-1 bg-[#101014] border border-[#19191F] rounded-full px-4 py-3 text-xs md:text-sm text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#FF008C]"
          />
          <button
            onClick={handleSend}
            disabled={!text.trim()}
            className="w-11 h-11 rounded-full bg-clipshare-gradient glow-clipshare flex items-center justify-center text-white shrink-0 disabled:opacity-40 active:scale-95 transition-all cursor-pointer shadow-md"
          >
            <Send size={18} className="-ml-0.5" />
          </button>
        </div>
      ) : (
        <div className="p-4 text-center text-xs text-[#A1A1AA] border-t border-[#19191F]">
          Usuário bloqueado.
        </div>
      )}

      {/* Report Modal */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-[#101014] border border-[#272730] rounded-3xl p-6 shadow-2xl text-left">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldAlert size={18} className="text-[#FF3B30]" />
                Denunciar conversa
              </h3>
              <button onClick={() => setReportModalOpen(false)}>
                <X size={18} className="text-[#A1A1AA]" />
              </button>
            </div>

            {reportSuccess ? (
              <div className="py-6 text-center text-xs text-[#20E060] font-bold">
                ✓ Denúncia enviada para a moderação ClipShare. Obrigado por proteger nossa comunidade.
              </div>
            ) : (
              <div className="space-y-2 text-xs">
                <p className="text-[#A1A1AA] mb-2">Selecione o motivo da denúncia:</p>
                {['Spam ou mensagens repetitivas', 'Comportamento inadequado ou assédio', 'Conteúdo impróprio para menores', 'Outro motivo'].map(
                  (reason) => (
                    <button
                      key={reason}
                      onClick={handleSendReport}
                      className="w-full text-left p-3 rounded-xl bg-[#19191F] hover:bg-[#22222b] text-white transition-colors"
                    >
                      {reason}
                    </button>
                  )
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
