import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Folder,
  Plus,
  Search,
  MoreVertical,
  Settings,
  ArrowUpDown,
  Car,
  Calendar,
  X,
  Edit2,
  Trash2,
  Sparkles,
  FileArchive,
  Download,
} from 'lucide-react';
import { Carpeta } from '../types';
import {
  listarCarpetas,
  crearCarpeta,
  renombrarCarpeta,
  eliminarCarpeta,
  contarFotosPorCarpeta,
  formatearFecha,
  sembrarDatosDemo,
  descomprimirEImportarZip,
  exportarCarpetaIndividualZip,
} from '../db/storage';
import { NombreDialog, ConfirmarDialog } from './Dialogos';

interface InicioViewProps {
  onAbrirCarpeta: (carpetaId: string) => void;
  onIrAjustes: () => void;
}

export const InicioView: React.FC<InicioViewProps> = ({ onAbrirCarpeta, onIrAjustes }) => {
  const [carpetas, setCarpetas] = useState<Carpeta[]>([]);
  const [conteos, setConteos] = useState<Record<string, number>>({});
  const [cargando, setCargando] = useState(true);

  // Estados de búsqueda y orden
  const [busqueda, setBusqueda] = useState('');
  const [mostrarBuscador, setMostrarBuscador] = useState(false);
  const [orden, setOrden] = useState<'recientes' | 'nombre'>('recientes');
  const [mostrarMenuOrden, setMostrarMenuOrden] = useState(false);

  // Modales
  const [modalCrear, setModalCrear] = useState(false);
  const [carpetaARenombrar, setCarpetaARenombrar] = useState<Carpeta | null>(null);
  const [carpetaAEliminar, setCarpetaAEliminar] = useState<Carpeta | null>(null);
  const [menuAbiertoId, setMenuAbiertoId] = useState<string | null>(null);

  const cargarDatos = async () => {
    setCargando(true);
    try {
      const lista = await listarCarpetas();
      setCarpetas(lista);

      // Cargar conteos de fotos por carpeta
      const conteosMap: Record<string, number> = {};
      for (const c of lista) {
        conteosMap[c.id] = await contarFotosPorCarpeta(c.id);
      }
      setConteos(conteosMap);
    } catch (err) {
      console.error('Error al cargar carpetas:', err);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => {
    cargarDatos();
  }, []);

  const nombresExistentes = useMemo(() => carpetas.map((c) => c.nombre), [carpetas]);

  // Filtrado y orden
  const carpetasFiltradas = useMemo(() => {
    let resultado = [...carpetas];
    if (busqueda.trim()) {
      const q = busqueda.trim().toLowerCase();
      resultado = resultado.filter((c) => c.nombre.toLowerCase().includes(q));
    }
    if (orden === 'nombre') {
      resultado.sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', { sensitivity: 'base' }));
    } else {
      resultado.sort((a, b) => b.fechaModificacion - a.fechaModificacion);
    }
    return resultado;
  }, [carpetas, busqueda, orden]);

  const handleCrearCarpeta = async (nombre: string) => {
    try {
      await crearCarpeta(nombre);
      setModalCrear(false);
      await cargarDatos();
    } catch (err) {
      console.error('Error al crear carpeta:', err);
    }
  };

  const handleRenombrarCarpeta = async (nuevoNombre: string) => {
    if (!carpetaARenombrar) return;
    try {
      await renombrarCarpeta(carpetaARenombrar.id, nuevoNombre);
      setCarpetaARenombrar(null);
      await cargarDatos();
    } catch (err) {
      console.error('Error al renombrar carpeta:', err);
    }
  };

  const handleEliminarCarpeta = async () => {
    if (!carpetaAEliminar) return;
    try {
      await eliminarCarpeta(carpetaAEliminar.id);
      setCarpetaAEliminar(null);
      await cargarDatos();
    } catch (err) {
      console.error('Error al eliminar carpeta:', err);
    }
  };

  const handleCargarEjemplos = async () => {
    await sembrarDatosDemo();
    await cargarDatos();
  };

  const fileZipInputRef = useRef<HTMLInputElement>(null);
  const [descomprimiendo, setDescomprimiendo] = useState(false);
  const [mensajeImportacion, setMensajeImportacion] = useState<string | null>(null);

  const handleImportarZip = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    setDescomprimiendo(true);
    try {
      const resultado = await descomprimirEImportarZip(archivo);
      setMensajeImportacion(
        `¡ZIP descomprimido con éxito! Se importaron ${resultado.fotosImportadas} fotos en ${resultado.carpetasCreadas} carpetas.`
      );
      setTimeout(() => setMensajeImportacion(null), 5000);
      await cargarDatos();
    } catch (err) {
      console.error('Error al descomprimir ZIP:', err);
      alert('No se pudo descomprimir el archivo. Asegúrate de que sea un archivo .zip válido.');
    } finally {
      setDescomprimiendo(false);
      if (fileZipInputRef.current) fileZipInputRef.current.value = '';
    }
  };

  const handleExportarCarpetaZip = async (c: Carpeta) => {
    try {
      const { blob, nombreArchivo } = await exportarCarpetaIndividualZip(c.id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = nombreArchivo;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error al exportar carpeta en ZIP:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col pb-24 transition-colors">
      {/* Barra Superior estilo Material 3 / App Taller */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          {mostrarBuscador ? (
            <div className="flex-1 flex items-center gap-2">
              <Search size={18} className="text-amber-500 shrink-0" />
              <input
                type="text"
                autoFocus
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                placeholder="Buscar carpeta por placa o vehículo…"
                className="w-full bg-transparent text-sm font-medium outline-hidden text-slate-900 dark:text-slate-100 placeholder-slate-400"
              />
              <button
                onClick={() => {
                  setBusqueda('');
                  setMostrarBuscador(false);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-black">
                  <Car size={20} />
                </div>
                <div>
                  <h1 className="text-lg font-black tracking-tight text-slate-900 dark:text-white leading-tight">
                    Mis carpetas
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {carpetas.length} {carpetas.length === 1 ? 'vehículo registrado' : 'vehículos registrados'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setMostrarBuscador(true)}
                  aria-label="Buscar carpeta"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <Search size={20} />
                </button>

                {/* Menú Ordenar */}
                <div className="relative">
                  <button
                    onClick={() => setMostrarMenuOrden(!mostrarMenuOrden)}
                    aria-label="Ordenar carpetas"
                    className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1"
                  >
                    <ArrowUpDown size={20} />
                  </button>

                  {mostrarMenuOrden && (
                    <div
                      className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-40 animate-fadeIn"
                      onClick={() => setMostrarMenuOrden(false)}
                    >
                      <button
                        onClick={() => setOrden('recientes')}
                        className={`w-full text-left px-4 py-2.5 text-xs font-semibold flex items-center justify-between ${
                          orden === 'recientes'
                            ? 'text-amber-600 dark:text-amber-400 bg-amber-50/60 dark:bg-amber-950/20'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span>Más recientes</span>
                        {orden === 'recientes' && '✓'}
                      </button>
                      <button
                        onClick={() => setOrden('nombre')}
                        className={`w-full text-left px-4 py-2.5 text-xs font-semibold flex items-center justify-between ${
                          orden === 'nombre'
                            ? 'text-amber-600 dark:text-amber-400 bg-amber-50/60 dark:bg-amber-950/20'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span>Nombre A-Z</span>
                        {orden === 'nombre' && '✓'}
                      </button>
                    </div>
                  )}
                </div>

                {/* Descomprimir e importar archivo ZIP desde internet o Play Store */}
                <input
                  type="file"
                  ref={fileZipInputRef}
                  accept=".zip,application/zip,application/x-zip-compressed"
                  onChange={handleImportarZip}
                  className="hidden"
                />
                <button
                  onClick={() => fileZipInputRef.current?.click()}
                  disabled={descomprimiendo}
                  title="Descomprimir e importar archivo ZIP desde el teléfono o internet"
                  aria-label="Descomprimir archivo ZIP"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1"
                >
                  <FileArchive size={20} className={descomprimiendo ? 'animate-spin text-amber-500' : 'text-amber-500'} />
                </button>

                <button
                  onClick={onIrAjustes}
                  aria-label="Ajustes"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <Settings size={20} />
                </button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* Contenido Principal */}
      <main className="max-w-4xl mx-auto w-full px-4 pt-6">
        {mensajeImportacion && (
          <div className="mb-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-sm font-semibold flex items-center justify-between animate-fadeIn">
            <span>{mensajeImportacion}</span>
            <button onClick={() => setMensajeImportacion(null)} className="p-1 hover:opacity-80">
              <X size={16} />
            </button>
          </div>
        )}
        {cargando ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-3">
            <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm font-medium">Cargando carpetas del taller…</p>
          </div>
        ) : carpetas.length === 0 ? (
          /* Estado Vacío Requerimiento 4 */
          <div className="py-16 md:py-24 px-6 text-center max-w-sm mx-auto flex flex-col items-center space-y-5">
            <div className="w-24 h-24 rounded-3xl bg-amber-500/10 dark:bg-amber-500/15 text-amber-500 flex items-center justify-center shadow-inner">
              <Folder size={48} strokeWidth={1.5} />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Aún no hay carpetas</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Toca el botón <span className="font-semibold text-amber-600 dark:text-amber-400">+</span> para crear la
                primera carpeta para un vehículo o cliente.
              </p>
            </div>

            <div className="pt-2 flex flex-col w-full gap-2.5">
              <button
                onClick={() => setModalCrear(true)}
                className="w-full py-3 px-5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-md shadow-amber-600/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus size={18} />
                Crear primera carpeta
              </button>

              <button
                onClick={() => fileZipInputRef.current?.click()}
                disabled={descomprimiendo}
                className="w-full py-2.5 px-4 rounded-xl border border-dashed border-amber-500/60 dark:border-amber-500/40 text-xs font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-50/50 dark:hover:bg-amber-950/20 transition flex items-center justify-center gap-1.5"
              >
                <FileArchive size={14} className="text-amber-500" />
                {descomprimiendo ? 'Descomprimiendo ZIP…' : 'Descomprimir e importar archivo ZIP'}
              </button>

              <button
                onClick={handleCargarEjemplos}
                className="w-full py-2.5 px-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition flex items-center justify-center gap-1.5"
              >
                <Sparkles size={14} className="text-amber-500" />
                Cargar ejemplos de taller
              </button>
            </div>
          </div>
        ) : carpetasFiltradas.length === 0 ? (
          /* Búsqueda sin resultados */
          <div className="py-16 text-center text-slate-400 space-y-2">
            <p className="text-base font-semibold text-slate-700 dark:text-slate-300">
              No se encontraron carpetas con "{busqueda}"
            </p>
            <button
              onClick={() => setBusqueda('')}
              className="text-xs text-amber-600 dark:text-amber-400 font-semibold underline"
            >
              Borrar filtro de búsqueda
            </button>
          </div>
        ) : (
          /* Cuadrícula de carpetas Requerimiento 3 y 8 */
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
            {carpetasFiltradas.map((carpeta) => {
              const numFotos = conteos[carpeta.id] ?? 0;
              const menuAbierto = menuAbiertoId === carpeta.id;

              return (
                <div
                  key={carpeta.id}
                  onClick={() => onAbrirCarpeta(carpeta.id)}
                  className="group relative bg-white dark:bg-slate-900 rounded-2xl p-4 md:p-5 border border-slate-200/90 dark:border-slate-800/90 hover:border-amber-500/80 dark:hover:border-amber-500/80 shadow-xs hover:shadow-lg transition cursor-pointer flex flex-col justify-between overflow-hidden"
                >
                  {/* Decoración superior sutil */}
                  <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-500 to-amber-600 opacity-0 group-hover:opacity-100 transition" />

                  <div className="flex items-start justify-between gap-2">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 dark:bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-105 transition shrink-0">
                      <Folder size={26} strokeWidth={2} />
                    </div>

                    {/* Menú de opciones de carpeta */}
                    <div className="relative" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setMenuAbiertoId(menuAbierto ? null : carpeta.id)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                      >
                        <MoreVertical size={18} />
                      </button>

                      {menuAbierto && (
                        <div
                          className="absolute right-0 top-8 w-36 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1 z-20 animate-fadeIn"
                          onClick={() => setMenuAbiertoId(null)}
                        >
                          <button
                            onClick={() => handleExportarCarpetaZip(carpeta)}
                            className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                          >
                            <Download size={14} className="text-amber-500" />
                            Descargar ZIP
                          </button>
                          <button
                            onClick={() => setCarpetaARenombrar(carpeta)}
                            className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                          >
                            <Edit2 size={14} />
                            Renombrar
                          </button>
                          <button
                            onClick={() => setCarpetaAEliminar(carpeta)}
                            className="w-full text-left px-3.5 py-2 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 flex items-center gap-2"
                          >
                            <Trash2 size={14} />
                            Eliminar
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 space-y-1">
                    <h3 className="font-bold text-sm md:text-base text-slate-900 dark:text-white line-clamp-2 leading-tight group-hover:text-amber-600 dark:group-hover:text-amber-400 transition">
                      {carpeta.nombre}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-semibold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-md">
                        {numFotos} {numFotos === 1 ? 'foto' : 'fotos'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 dark:text-slate-500 pt-1">
                      <Calendar size={12} />
                      <span>{formatearFecha(carpeta.fechaModificacion)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Botón Flotante para Crear Carpeta Requerimiento 5 */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => setModalCrear(true)}
          aria-label="Nueva carpeta"
          className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white shadow-xl shadow-amber-600/40 flex items-center justify-center active:scale-95 transition-all cursor-pointer group"
        >
          <Plus size={28} className="group-hover:rotate-90 transition-transform duration-200" />
        </button>
      </div>

      {/* Diálogos de Gestión de Carpeta */}
      {modalCrear && (
        <NombreDialog
          titulo="Nueva Carpeta de Vehículo"
          existentes={nombresExistentes}
          placeholder="Ej. Placa ABC-123 (Toyota Hilux)"
          onAceptar={handleCrearCarpeta}
          onCancelar={() => setModalCrear(false)}
        />
      )}

      {carpetaARenombrar && (
        <NombreDialog
          titulo="Renombrar Carpeta"
          inicial={carpetaARenombrar.nombre}
          existentes={nombresExistentes}
          onAceptar={handleRenombrarCarpeta}
          onCancelar={() => setCarpetaARenombrar(null)}
        />
      )}

      {carpetaAEliminar && (
        <ConfirmarDialog
          titulo="Eliminar carpeta"
          mensaje={`Se borrará "${carpetaAEliminar.nombre}" definitivamente junto con todas sus fotos (${
            conteos[carpetaAEliminar.id] ?? 0
          } fotos). ¿Deseas continuar?`}
          textoOk="Sí, eliminar"
          textoCancelar="Cancelar"
          esPeligroso={true}
          onOk={handleEliminarCarpeta}
          onCancelar={() => setCarpetaAEliminar(null)}
        />
      )}
    </div>
  );
};
