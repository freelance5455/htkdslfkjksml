import React from 'react';
import { ArrowUpRight, ArrowDownRight, Clock, ShieldCheck, Zap, DollarSign } from 'lucide-react';
import { TradeOrder, Asset } from '../types/trading';

interface ActiveTradeModalProps {
  trade: TradeOrder;
  asset: Asset;
}

export const ActiveTradeModal: React.FC<ActiveTradeModalProps> = ({ trade, asset }) => {
  const isUp = trade.direction === 'UP';
  const isInTheMoney = isUp
    ? trade.currentPrice > trade.entryPrice
    : trade.currentPrice < trade.entryPrice;

  return (
    <div className="w-full bg-[#1b0813] border-2 border-red-500/80 rounded-2xl p-3.5 shadow-2xl animate-pulse-slow">
      <div className="flex items-center justify-between border-b border-[#361122] pb-2">
        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
              isUp
                ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/50'
                : 'bg-red-950 text-red-400 border border-red-700/50'
            }`}
          >
            {isUp ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black font-mono text-slate-100">{trade.pair}</span>
              <span className="text-[10px] font-bold text-red-400 uppercase font-mono">
                {trade.action}
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono">
              Stake: ${trade.stake} · Payout: {trade.payoutPercent}%
            </span>
          </div>
        </div>

        {/* Seconds remaining counter */}
        <div className="text-right">
          <div className="flex items-center gap-1 text-sm font-black font-mono text-red-500 tabular-nums">
            <Clock className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '3s' }} />
            <span>{trade.secondsRemaining}S LEFT</span>
          </div>
          <span
            className={`text-[10px] font-bold font-mono uppercase ${
              isInTheMoney ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {isInTheMoney ? '● IN THE MONEY' : '● OUT OF THE MONEY'}
          </span>
        </div>
      </div>

      {/* Entry Price vs Current Price */}
      <div className="grid grid-cols-3 gap-2 mt-3 text-center text-xs font-mono">
        <div className="bg-[#12040b] p-2 rounded-xl border border-[#2b0d1a]">
          <span className="text-[9px] text-zinc-400 uppercase font-sans">Entry Price</span>
          <div className="font-bold text-slate-200 mt-0.5 tabular-nums">
            {trade.entryPrice.toFixed(asset.decimals)}
          </div>
        </div>

        <div className="bg-[#12040b] p-2 rounded-xl border border-[#2b0d1a]">
          <span className="text-[9px] text-zinc-400 uppercase font-sans">Current Price</span>
          <div
            className={`font-black mt-0.5 tabular-nums ${
              isInTheMoney ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {trade.currentPrice.toFixed(asset.decimals)}
          </div>
        </div>

        <div className="bg-[#12040b] p-2 rounded-xl border border-[#2b0d1a]">
          <span className="text-[9px] text-zinc-400 uppercase font-sans">Est. Profit</span>
          <div
            className={`font-black mt-0.5 tabular-nums ${
              isInTheMoney ? 'text-emerald-400' : 'text-zinc-500'
            }`}
          >
            {isInTheMoney ? `+$${trade.potentialProfit.toFixed(2)}` : '$0.00'}
          </div>
        </div>
      </div>
    </div>
  );
};
