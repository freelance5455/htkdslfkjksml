import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  BookOpen,
  Feather,
  Wand2,
  User,
  Zap,
  Flame,
  PlusCircle,
  Copy,
  Check,
  RotateCcw,
  X,
} from 'lucide-react';
import { ChatMessage, ChatRoleType, ComplexityLevel, StoryAnalysisData } from '../types';

interface GhostwriterChatProps {
  storyContext: {
    storyTitle: string;
    genre: string;
    mood: string;
    currentStory: string;
    worldLore?: string;
    sensoryPalette?: any;
  };
  onAppendToStory: (textToAppend: string) => void;
  onClose?: () => void;
}

const CHAT_ROLES: {
  id: ChatRoleType;
  title: string;
  tagline: string;
  systemPrompt: string;
  badgeColor: string;
}[] = [
  {
    id: 'ghostwriter',
    title: 'Master Ghostwriter',
    tagline: 'Expands scenes, continues prose, crafts twists',
    systemPrompt:
      'You are a master fiction ghostwriter. Seamlessly match the tone, atmosphere, and imagery of the existing scene. When asked to continue, write evocative paragraphs ready to be inserted directly into the manuscript.',
    badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  },
  {
    id: 'lorekeeper',
    title: 'World Lorekeeper',
    tagline: 'Deepens factions, ancient relics & mythos',
    systemPrompt:
      'You are the worldbuilding architect and lorekeeper. Construct vivid historical chronicles, hidden societies, forbidden artifacts, and enigmatic ecology grounded in this setting.',
    badgeColor: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
  },
  {
    id: 'stylist',
    title: 'Prose Stylist',
    tagline: 'Polishes cadence, sensory metaphors & rhythm',
    systemPrompt:
      'You are an exacting prose stylist and literary line-editor. Elevate vocabulary, replace clichés with visceral sensory metaphors, and heighten emotional resonance.',
    badgeColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
  },
  {
    id: 'dramatist',
    title: 'Character Dramatist',
    tagline: 'Breathes life into motives, dilemma & dialogue',
    systemPrompt:
      'You are a dramatic character developer. Unpack the protagonist’s internal fractures, moral dilemmas, unspoken desires, and sharp, subtext-rich dialogue exchanges.',
    badgeColor: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
  },
];

const QUICK_PROMPTS = [
  'Continue the story with the next paragraph...',
  'Introduce a sudden sound or unexpected arrival...',
  'Reveal a hidden secret or dark history about this place...',
  'Deepen the sensory details of the immediate atmosphere...',
  'Give me 3 potential plot turns for the next chapter...',
];

export const GhostwriterChat: React.FC<GhostwriterChatProps> = ({
  storyContext,
  onAppendToStory,
  onClose,
}) => {
  const [selectedRole, setSelectedRole] = useState<ChatRoleType>('ghostwriter');
  const [complexity, setComplexity] = useState<ComplexityLevel>('general');
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [insertedId, setInsertedId] = useState<string | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      text: `Greetings, storyteller. I am your co-author for "${storyContext.storyTitle || 'this world'}". I can continue the prose, design lore factions, or sculpt dramatic twists. How shall we unfold the tale?`,
      timestamp: Date.now(),
      modelUsed: 'gemini-3.8-flash',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isSending) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: text,
      timestamp: Date.now(),
      complexity: complexity,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage('');
    setIsSending(true);

    try {
      const activeRoleConfig = CHAT_ROLES.find((r) => r.id === selectedRole);

      // Prepare conversation array
      const conversationHistory = [...messages, userMessage].map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: conversationHistory,
          complexity: complexity, // 'complex' -> gemini-4-argon, 'general' -> gemini-3.8-flash, 'fast' -> gemini-3.1-flash-lite
          roleInstruction: activeRoleConfig?.systemPrompt || '',
          storyContext: storyContext,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to get ghostwriter response');
      }

      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        text: data.message,
        timestamp: Date.now(),
        modelUsed: data.modelUsed,
        complexity: complexity,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        text: `The muse faltered momentarily (${err.message || 'Error communicating with AI'}). Please try again.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsSending(false);
    }
  };

  const handleInsert = (msg: ChatMessage) => {
    onAppendToStory(msg.text);
    setInsertedId(msg.id);
    setTimeout(() => setInsertedId(null), 2500);
  };

  const handleCopy = (msg: ChatMessage) => {
    navigator.clipboard.writeText(msg.text);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    if (confirm('Clear the ghostwriter conversation history?')) {
      setMessages([
        {
          id: `init-${Date.now()}`,
          role: 'assistant',
          text: `Thread reset. Ready to explore new scenes and prose together.`,
          timestamp: Date.now(),
          modelUsed: 'gemini-3.8-flash',
        },
      ]);
    }
  };

  const activeRole = CHAT_ROLES.find((r) => r.id === selectedRole) || CHAT_ROLES[0];

  return (
    <div className="flex flex-col h-full rounded-2xl border border-stone-800 bg-stone-900/80 backdrop-blur-md shadow-2xl overflow-hidden">
      {/* Drawer Header */}
      <div className="p-4 border-b border-stone-800 bg-stone-950/70 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-display text-sm font-semibold text-stone-100 flex items-center gap-1.5">
              Co-Author Ghostwriter
              <span className={`text-[10px] px-2 py-0.5 rounded-full border ${activeRole.badgeColor}`}>
                {activeRole.title}
              </span>
            </h3>
            <p className="text-[11px] text-stone-400">{activeRole.tagline}</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleClearHistory}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800/80 transition-colors"
            title="Reset conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800/80 transition-colors"
              title="Close drawer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Role & Model Selector Strip */}
      <div className="px-4 py-2.5 border-b border-stone-800/80 bg-stone-950/40 flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between text-xs">
        {/* Roles pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {CHAT_ROLES.map((role) => (
            <button
              key={role.id}
              onClick={() => setSelectedRole(role.id)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap transition-all ${
                selectedRole === role.id
                  ? 'bg-amber-500/20 text-amber-200 border border-amber-500/40 font-semibold'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              {role.title}
            </button>
          ))}
        </div>

        {/* Complexity Mode Chips (gemini-4-argon, gemini-3.8-flash, gemini-3.1-flash-lite) */}
        <div className="flex items-center gap-1 bg-stone-900/90 p-0.5 rounded-lg border border-stone-800 text-[10px] shrink-0">
          <button
            onClick={() => setComplexity('fast')}
            className={`px-2 py-0.5 rounded transition-colors flex items-center gap-0.5 ${
              complexity === 'fast'
                ? 'bg-stone-800 text-amber-300 font-semibold shadow'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Fast Mode: Uses gemini-3.1-flash-lite for instant brainstorming"
          >
            <Zap className="w-2.5 h-2.5" />
            <span>Fast (Lite)</span>
          </button>

          <button
            onClick={() => setComplexity('general')}
            className={`px-2 py-0.5 rounded transition-colors flex items-center gap-0.5 ${
              complexity === 'general'
                ? 'bg-stone-800 text-amber-300 font-semibold shadow'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="General Mode: Uses gemini-3.8-flash for balanced writing"
          >
            <Feather className="w-2.5 h-2.5" />
            <span>General (3.8)</span>
          </button>

          <button
            onClick={() => setComplexity('complex')}
            className={`px-2 py-0.5 rounded transition-colors flex items-center gap-0.5 ${
              complexity === 'complex'
                ? 'bg-stone-800 text-amber-300 font-semibold shadow'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Complex Mode: Uses gemini-4-argon for deep worldbuilding & complex prose"
          >
            <Flame className="w-2.5 h-2.5" />
            <span>Deep (Argon)</span>
          </button>
        </div>
      </div>

      {/* Messages Scrollable Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.role === 'user' ? 'items-end' : 'items-start'
            } space-y-1`}
          >
            <div
              className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-md ${
                msg.role === 'user'
                  ? 'bg-amber-600/20 border border-amber-500/40 text-stone-100 rounded-br-none'
                  : 'bg-stone-950/90 border border-stone-800 text-stone-200 font-serif-story text-base sm:text-lg rounded-bl-none'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>

              {/* Model Tag & Actions for Assistant */}
              {msg.role === 'assistant' && (
                <div className="mt-3 pt-2 border-t border-stone-800/80 flex items-center justify-between gap-2 text-[10px] font-sans">
                  <span className="text-stone-500 font-mono">
                    {msg.modelUsed || 'gemini'}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopy(msg)}
                      className="text-stone-400 hover:text-stone-200 flex items-center gap-1 transition-colors"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleInsert(msg)}
                      className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 flex items-center gap-1 transition-colors font-medium"
                      title="Append this text to the main story manuscript"
                    >
                      {insertedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-300">Inserted!</span>
                        </>
                      ) : (
                        <>
                          <PlusCircle className="w-3 h-3 text-amber-400" />
                          <span>Insert to Manuscript</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
            <span className="text-[10px] text-stone-500 px-1">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}

        {isSending && (
          <div className="flex items-start space-y-1">
            <div className="rounded-2xl rounded-bl-none p-3.5 bg-stone-950/90 border border-stone-800 text-xs text-stone-400 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
              <span className="font-sans text-stone-300 italic">Ghostwriter is drafting...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Carousel */}
      <div className="px-3 py-1.5 border-t border-stone-800/60 bg-stone-950/30 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-1.5">
        {QUICK_PROMPTS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(prompt)}
            disabled={isSending}
            className="px-2.5 py-1 rounded-full text-[11px] bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-800/80 transition-colors disabled:opacity-50 shrink-0"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Message Input Box */}
      <div className="p-3 border-t border-stone-800 bg-stone-950/80">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            disabled={isSending}
            placeholder={`Ask ${activeRole.title} to continue or advise...`}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isSending || !inputMessage.trim()}
            className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold shadow-md shadow-amber-500/20 transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
            title="Send prompt"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
