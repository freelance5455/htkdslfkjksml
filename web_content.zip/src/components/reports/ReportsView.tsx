import React, { useState, useMemo } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import { CategoryIcon } from '../common/CategoryIcon';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  PieChart as PieIcon,
  Calendar,
  Award,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
  Users,
  PiggyBank,
  Smartphone,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const {
    transactions,
    categories,
    selectedMonth,
    setSelectedMonth,
    language,
    t,
    setActiveModal,
    loadSampleData
  } = useKhata();

  // Parse Month
  const [yearStr, monthStr] = selectedMonth.split('-');
  const dateObj = new Date(parseInt(yearStr), parseInt(monthStr) - 1, 1);

  const prevMonth = () => {
    const d = new Date(dateObj);
    d.setMonth(d.getMonth() - 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  const nextMonth = () => {
    const d = new Date(dateObj);
    d.setMonth(d.getMonth() + 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  const monthLabel = formatIndianDate(`${selectedMonth}-01`, language).split(' ').slice(1).join(' ');

  // Current month transactions
  const monthTransactions = useMemo(() => {
    return transactions.filter(t => t.date.startsWith(selectedMonth));
  }, [transactions, selectedMonth]);

  const totalIncome = useMemo(() => {
    return monthTransactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  }, [monthTransactions]);

  const totalExpense = useMemo(() => {
    return monthTransactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  }, [monthTransactions]);

  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.round((netSavings / totalIncome) * 100)) : 0;

  // Category-wise Breakdown
  const categoryStats = useMemo(() => {
    const map: Record<string, number> = {};
    monthTransactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        map[t.categoryId] = (map[t.categoryId] || 0) + t.amount;
      });

    const list = Object.entries(map).map(([catId, amount]) => {
      const cat = categories.find(c => c.id === catId);
      const percent = totalExpense > 0 ? Math.round((amount / totalExpense) * 100) : 0;
      return {
        id: catId,
        cat,
        amount,
        percent
      };
    });

    // Sort descending by highest amount
    list.sort((a, b) => b.amount - a.amount);
    return list;
  }, [monthTransactions, totalExpense, categories]);

  // Weekly spending breakdown (Week 1: 1-7, Week 2: 8-14, Week 3: 15-21, Week 4+: 22-end)
  const weeklyStats = useMemo(() => {
    const weeks = [
      { label: language === 'hi' ? 'सप्ताह 1 (1-7)' : 'Week 1 (1-7)', amount: 0 },
      { label: language === 'hi' ? 'सप्ताह 2 (8-14)' : 'Week 2 (8-14)', amount: 0 },
      { label: language === 'hi' ? 'सप्ताह 3 (15-21)' : 'Week 3 (15-21)', amount: 0 },
      { label: language === 'hi' ? 'सप्ताह 4 (22+)' : 'Week 4 (22+)', amount: 0 }
    ];

    monthTransactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        const day = parseInt(t.date.split('-')[2]);
        if (day <= 7) weeks[0].amount += t.amount;
        else if (day <= 14) weeks[1].amount += t.amount;
        else if (day <= 21) weeks[2].amount += t.amount;
        else weeks[3].amount += t.amount;
      });

    const maxWeekly = Math.max(1, ...weeks.map(w => w.amount));
    return { weeks, maxWeekly };
  }, [monthTransactions, language]);

  return (
    <div className="space-y-4 pb-12">
      {/* Month Navigator Header */}
      <div className="flex items-center justify-between bg-white rounded-2xl p-3 shadow-xs border border-slate-200">
        <button
          onClick={prevMonth}
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-700" />
          <span className="text-base font-bold text-slate-900">{monthLabel}</span>
        </div>
        <button
          onClick={nextMonth}
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Income vs Expense Comparison KPI */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">{t.incomeVsExpense}</h3>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            {t.savingsRate}: {savingsRate}%
          </span>
        </div>

        {/* 2-bar visual comparison */}
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1 tabular-nums">
              <span className="flex items-center gap-1 text-emerald-700">
                <TrendingUp className="w-3.5 h-3.5" />
                {t.monthlyIncome}
              </span>
              <span className="font-bold text-emerald-800">{formatRupee(totalIncome)}</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-600 rounded-full transition-all duration-500"
                style={{
                  width: `${totalIncome + totalExpense > 0 ? (totalIncome / (totalIncome + totalExpense)) * 100 : 50}%`
                }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1 tabular-nums">
              <span className="flex items-center gap-1 text-rose-600">
                <TrendingDown className="w-3.5 h-3.5" />
                {t.monthlyExpense}
              </span>
              <span className="font-bold text-rose-800">{formatRupee(totalExpense)}</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-rose-500 rounded-full transition-all duration-500"
                style={{
                  width: `${totalIncome + totalExpense > 0 ? (totalExpense / (totalIncome + totalExpense)) * 100 : 50}%`
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Spending Trend Report */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900">{t.weeklySpendTrend}</h3>

        <div className="grid grid-cols-4 gap-2 pt-2 items-end h-36">
          {weeklyStats.weeks.map(w => {
            const heightPercent = Math.max(12, Math.round((w.amount / weeklyStats.maxWeekly) * 100));

            return (
              <div key={w.label} className="flex flex-col items-center h-full justify-end">
                <span className="text-[10px] font-bold text-slate-700 mb-1 tabular-nums">
                  {formatRupee(w.amount)}
                </span>
                <div className="w-full bg-slate-100 rounded-t-xl overflow-hidden flex items-end justify-center h-24">
                  <div
                    className="w-full bg-emerald-700 hover:bg-emerald-800 rounded-t-xl transition-all duration-500"
                    style={{ height: `${heightPercent}%` }}
                  />
                </div>
                <span className="text-[10px] font-semibold text-slate-400 mt-1.5 text-center leading-tight">
                  {w.label.split(' ')[0]}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Category-Wise Expense Breakdown & Ranking */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">{t.topSpendingCategories}</h3>
          <span className="text-xs text-slate-400">कुल खर्च: {formatRupee(totalExpense)}</span>
        </div>

        {categoryStats.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">
            इस महीने में कोई खर्च दर्ज नहीं है।
          </div>
        ) : (
          <div className="space-y-3">
            {categoryStats.slice(0, 6).map(item => (
              <div key={item.id} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
                      style={{
                        backgroundColor: item.cat ? `${item.cat.color}15` : '#e2e8f0',
                        color: item.cat ? item.cat.color : '#475569'
                      }}
                    >
                      <CategoryIcon name={item.cat?.icon || 'Tag'} className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-bold text-slate-800">
                      {language === 'hi' ? item.cat?.nameHi : item.cat?.nameEn}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 tabular-nums">
                    <span className="font-extrabold text-slate-900">{formatRupee(item.amount)}</span>
                    <span className="text-[11px] font-semibold text-slate-400 w-8 text-right">
                      {item.percent}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${item.percent}%`,
                      backgroundColor: item.cat?.color || '#15803d'
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Navigation Cards to Other Household Modules */}
      <div className="space-y-2 pt-2">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
          {language === 'hi' ? 'अतिरिक्त सुविधाएं (Additional Tools)' : 'Additional Tools'}
        </h4>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => setActiveModal('savings-modal')}
            className="p-3.5 bg-white border border-slate-200 rounded-2xl text-left hover:border-emerald-300 transition shadow-xs flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <PiggyBank className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.savingsGoalsTitle}</div>
              <div className="text-[10px] text-slate-400">बचत लक्ष्य ट्रैक करें</div>
            </div>
          </button>

          <button
            onClick={() => setActiveModal('family-modal')}
            className="p-3.5 bg-white border border-slate-200 rounded-2xl text-left hover:border-emerald-300 transition shadow-xs flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.familyAccountTitle}</div>
              <div className="text-[10px] text-slate-400">सदस्य-वार खर्च देखें</div>
            </div>
          </button>

          <button
            onClick={() => setActiveModal('backup')}
            className="p-3.5 bg-white border border-slate-200 rounded-2xl text-left hover:border-emerald-300 transition shadow-xs flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.backupRestoreTitle}</div>
              <div className="text-[10px] text-slate-400">Excel CSV / PDF</div>
            </div>
          </button>

          <button
            onClick={() => setActiveModal('android')}
            className="p-3.5 bg-white border border-slate-200 rounded-2xl text-left hover:border-emerald-300 transition shadow-xs flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.androidAppTitle}</div>
              <div className="text-[10px] text-slate-400">APK व PWA गाइड</div>
            </div>
          </button>
        </div>

        {/* Reload Demo Data button if needed */}
        <div className="pt-2 text-center">
          <button
            onClick={() => {
              if (window.confirm('क्या आप डेमो नमूना डेटा लोड करना चाहते हैं?')) {
                loadSampleData();
              }
            }}
            className="text-xs text-slate-400 hover:text-slate-600 inline-flex items-center gap-1 py-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>नमूना डेटा रीलोड करें (Reload Sample Data)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
