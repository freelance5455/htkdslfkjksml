// Financial & Inventory Reports View
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import {
  BarChart3,
  Download,
  Calendar,
  DollarSign,
  TrendingUp,
  Package,
  Layers,
  FileSpreadsheet,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { currentBranch } = useAuth();
  const settings = dbStore.getSettings();
  const sales = dbStore.getSales(currentBranch.id, 200);
  const inventory = dbStore.getInventory(currentBranch.id);

  const [reportType, setReportType] = useState<'sales' | 'inventory' | 'margin'>('sales');

  const totalRevenue = sales.reduce((sum, s) => sum + s.grandTotal, 0);
  const totalTax = sales.reduce((sum, s) => sum + s.taxTotal, 0);

  // COGS & Gross Margin
  let totalCOGS = 0;
  sales.forEach((s) => {
    s.items.forEach((item) => {
      totalCOGS += item.quantity * item.costPrice;
    });
  });
  const grossProfit = totalRevenue - totalTax - totalCOGS;

  const exportCSV = () => {
    let csv = '';
    if (reportType === 'sales') {
      csv = 'Receipt,Date,Cashier,Customer,PaymentMethod,Subtotal,Tax,GrandTotal\n';
      sales.forEach((s) => {
        csv += `${s.receiptNumber},${s.createdAt},"${s.cashierName}","${s.customerName || 'Walk-in'}",${s.paymentMethod},${s.subtotal},${s.taxTotal},${s.grandTotal}\n`;
      });
    } else {
      csv = 'Product,Barcode,SKU,Quantity,CostPrice,SellingPrice,TotalCostValuation,TotalRetailValuation\n';
      inventory.forEach((i) => {
        csv += `"${i.product.name}",${i.product.barcode},${i.product.sku},${i.quantity},${i.product.costPrice},${i.product.sellingPrice},${(i.quantity * i.product.costPrice).toFixed(2)},${(i.quantity * i.product.sellingPrice).toFixed(2)}\n`;
      });
    }

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `supermarket_${reportType}_report_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">Supermarket Financial & Inventory Reports</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile revenue, calculate true Gross Margins (COGS), and export audit CSV sheets.
          </p>
        </div>

        <button
          onClick={exportCSV}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm shadow-emerald-900/30 transition-colors"
        >
          <Download className="w-4 h-4" />
          Export CSV Spreadsheet
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Recorded Cumulative Sales</div>
          <div className="text-2xl font-bold text-slate-100 font-mono mt-2">
            {settings.currency} {totalRevenue.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">{sales.length} completed customer sales</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Total Cost of Goods Sold (COGS)</div>
          <div className="text-2xl font-bold text-amber-400 font-mono mt-2">
            {settings.currency} {totalCOGS.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Direct supplier cost of items sold</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Estimated Gross Margin</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono mt-2">
            {settings.currency} {grossProfit.toFixed(2)}
          </div>
          <div className="text-[11px] text-emerald-400/80 mt-1 font-semibold">
            {totalRevenue > 0 ? ((grossProfit / totalRevenue) * 100).toFixed(1) : 0}% Gross Margin
          </div>
        </div>
      </div>

      {/* Report Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800">
        <button
          onClick={() => setReportType('sales')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            reportType === 'sales'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          Sales Transactions Journal
        </button>
        <button
          onClick={() => setReportType('inventory')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            reportType === 'inventory'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Package className="w-4 h-4" />
          Inventory Valuation Ledger
        </button>
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          {reportType === 'sales' ? (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                  <th className="py-3 px-4">Receipt #</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Cashier</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4 text-center">Payment</th>
                  <th className="py-3 px-4 text-right">Subtotal</th>
                  <th className="py-3 px-4 text-right">VAT</th>
                  <th className="py-3 px-4 text-right">Grand Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {sales.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400">{s.receiptNumber}</td>
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                      {new Date(s.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4">{s.cashierName}</td>
                    <td className="py-3 px-4 text-slate-400">{s.customerName || 'Walk-in'}</td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                        {s.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400">
                      {settings.currency} {s.subtotal.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400">
                      {settings.currency} {s.taxTotal.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                      {settings.currency} {s.grandTotal.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                  <th className="py-3 px-4">Product</th>
                  <th className="py-3 px-4">Barcode</th>
                  <th className="py-3 px-4 text-right">Stock Qty</th>
                  <th className="py-3 px-4 text-right">Cost Price</th>
                  <th className="py-3 px-4 text-right">Selling Price</th>
                  <th className="py-3 px-4 text-right">Stock Cost Value</th>
                  <th className="py-3 px-4 text-right">Stock Retail Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {inventory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-200">{item.product.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{item.product.barcode}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                      {item.quantity} {item.product.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400">
                      {settings.currency} {item.product.costPrice.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-300">
                      {settings.currency} {item.product.sellingPrice.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-amber-400">
                      {settings.currency} {(item.quantity * item.product.costPrice).toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                      {settings.currency} {(item.quantity * item.product.sellingPrice).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
