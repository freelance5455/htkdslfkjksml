import React, { useState, useEffect, useMemo } from 'react';
import { 
  Tag, 
  Search, 
  Filter, 
  Edit3, 
  Save, 
  X, 
  Plus, 
  Trash2, 
  FileAudio, 
  Video, 
  Image as ImageIcon, 
  CheckCircle2, 
  Download, 
  HardDrive, 
  Sparkles, 
  RefreshCw, 
  Play, 
  Pause,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { tagManagementService } from '../lib/tagManagementService';
import { UploadedMediaItem } from '../types';

interface MetadataManagerProps {
  onShowToast?: (msg: string) => void;
}

export const MetadataManager: React.FC<MetadataManagerProps> = ({ onShowToast }) => {
  const [mediaItems, setMediaItems] = useState<UploadedMediaItem[]>(() => 
    tagManagementService.getAllMediaWithTags()
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'all' | 'audio' | 'video' | 'image'>('all');
  const [selectedTagFilter, setSelectedTagFilter] = useState<string>('all');
  
  // Inline tag editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTagsString, setEditingTagsString] = useState<string>('');
  
  // Quick Add tag modal/input per row
  const [quickAddTagInput, setQuickAddTagInput] = useState<{ [id: string]: string }>({});

  // Bulk tag selection
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [bulkTagInput, setBulkTagInput] = useState<string>('');
  const [showBulkModal, setShowBulkModal] = useState<boolean>(false);

  // Active audio preview
  const [activeAudioPlayingId, setActiveAudioPlayingId] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    const handleSync = () => {
      setMediaItems(tagManagementService.getAllMediaWithTags());
    };
    const unsubscribe = tagManagementService.subscribe(handleSync);
    return () => {
      unsubscribe();
      if (audioElement) {
        audioElement.pause();
      }
    };
  }, [audioElement]);

  // Unique tags list with count
  const uniqueTags = useMemo(() => {
    return tagManagementService.getAllUniqueTags();
  }, [mediaItems]);

  // Filtered Media
  const filteredItems = useMemo(() => {
    return mediaItems.filter(item => {
      // Type filter
      if (selectedTypeFilter !== 'all' && item.type !== selectedTypeFilter) {
        return false;
      }

      // Tag filter
      if (selectedTagFilter !== 'all') {
        const hasTag = (item.tags || []).some(t => t.toLowerCase() === selectedTagFilter.toLowerCase());
        if (!hasTag) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchArtist = (item.artistOrProphet || '').toLowerCase().includes(q);
        const matchDesc = item.description.toLowerCase().includes(q);
        const matchTags = (item.tags || []).some(t => t.toLowerCase().includes(q));
        return matchTitle || matchArtist || matchDesc || matchTags;
      }

      return true;
    });
  }, [mediaItems, selectedTypeFilter, selectedTagFilter, searchQuery]);

  // Start inline editing
  const handleStartEdit = (item: UploadedMediaItem) => {
    setEditingId(item.id);
    setEditingTagsString((item.tags || []).join(', '));
  };

  // Save inline editing atomically
  const handleSaveEdit = (itemId: string) => {
    const success = tagManagementService.updateMediaTags(itemId, editingTagsString);
    if (success) {
      setEditingId(null);
      setEditingTagsString('');
      if (onShowToast) onShowToast(`✓ Metadata tags updated atomically for file!`);
    } else {
      if (onShowToast) onShowToast(`❌ Failed to update metadata tags.`);
    }
  };

  // Cancel inline editing
  const handleCancelEdit = () => {
    setEditingId(null);
    setEditingTagsString('');
  };

  // Remove single tag badge
  const handleRemoveTag = (itemId: string, tag: string) => {
    tagManagementService.removeTagFromMedia(itemId, tag);
    if (onShowToast) onShowToast(`Removed tag #${tag}`);
  };

  // Add quick tag from preset
  const handleAddPresetTag = (itemId: string, presetTag: string) => {
    tagManagementService.addTagToMedia(itemId, presetTag);
    if (onShowToast) onShowToast(`Added #${presetTag} to file`);
  };

  // Quick custom tag addition
  const handleQuickAddCustomTag = (itemId: string) => {
    const customTag = (quickAddTagInput[itemId] || '').trim();
    if (!customTag) return;
    tagManagementService.addTagToMedia(itemId, customTag);
    setQuickAddTagInput(prev => ({ ...prev, [itemId]: '' }));
    if (onShowToast) onShowToast(`Added #${customTag} to file`);
  };

  // Toggle selection for bulk actions
  const handleToggleSelect = (id: string) => {
    setSelectedItemIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedItemIds.length === filteredItems.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(filteredItems.map(i => i.id));
    }
  };

  // Bulk tag application
  const handleApplyBulkTags = () => {
    if (!bulkTagInput.trim() || selectedItemIds.length === 0) return;
    const tagsToAdd = bulkTagInput.split(',').map(t => t.trim().toLowerCase().replace(/^#/, '')).filter(Boolean);
    
    selectedItemIds.forEach(id => {
      tagsToAdd.forEach(t => {
        tagManagementService.addTagToMedia(id, t);
      });
    });

    if (onShowToast) {
      onShowToast(`✓ Applied tags [${tagsToAdd.join(', ')}] across ${selectedItemIds.length} items!`);
    }
    setBulkTagInput('');
    setShowBulkModal(false);
    setSelectedItemIds([]);
  };

  // Toggle audio preview
  const handleToggleAudioPlay = (item: UploadedMediaItem) => {
    if (activeAudioPlayingId === item.id) {
      if (audioElement) {
        audioElement.pause();
      }
      setActiveAudioPlayingId(null);
    } else {
      if (audioElement) {
        audioElement.pause();
      }
      const audio = new Audio(item.url);
      audio.play().catch(e => console.warn('Preview play error:', e));
      audio.onended = () => setActiveAudioPlayingId(null);
      setAudioElement(audio);
      setActiveAudioPlayingId(item.id);
    }
  };

  // Export metadata table as CSV
  const handleExportCsv = () => {
    const headers = 'ID,Type,Title,Artist/Speaker,Date,Tags,IndexedDB URL,Likes,Downloads\n';
    const rows = filteredItems.map(item => {
      const cleanTitle = item.title.replace(/"/g, '""');
      const cleanArtist = item.artistOrProphet.replace(/"/g, '""');
      const tagsStr = (item.tags || []).join('; ');
      return `"${item.id}","${item.type}","${cleanTitle}","${cleanArtist}","${item.date}","${tagsStr}","${item.url}","${item.likes}","${item.downloads}"`;
    }).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_METADATA_TAGS_INDEX_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    if (onShowToast) onShowToast('✓ Metadata exported to CSV successfully!');
  };

  // Export metadata table as JSON
  const handleExportJson = () => {
    const dataStr = JSON.stringify(filteredItems, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_METADATA_ARCHIVE_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    if (onShowToast) onShowToast('✓ Metadata exported to JSON successfully!');
  };

  return (
    <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-amber-300">
            <Tag className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-bold font-serif text-amber-100">
              Unified Metadata & Tags Manager
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Search, inspect, and atomically edit tags across all Audio tracks, Video broadcasts, and Sanctuary images in the JUHNKRIX MUSIKA app.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold flex items-center space-x-1.5 transition-all shadow"
            title="Export Metadata Table as CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJson}
            className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold flex items-center space-x-1.5 transition-all shadow"
            title="Export Metadata Table as JSON"
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
          {selectedItemIds.length > 0 && (
            <button
              onClick={() => setShowBulkModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs flex items-center space-x-1.5 transition-all shadow-md"
            >
              <Layers className="w-3.5 h-3.5 text-slate-950" />
              <span>Bulk Tag ({selectedItemIds.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Search and Filters Toolbar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-950/70 p-4 rounded-2xl border border-amber-500/20">
        {/* Search Input */}
        <div className="md:col-span-2 relative">
          <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, speaker, description, or tag (#528hz, worship)..."
            className="w-full pl-9 pr-4 py-2 bg-slate-900 text-amber-100 placeholder-slate-500 text-xs rounded-xl border border-amber-500/30 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Media Type Filter */}
        <div>
          <select
            value={selectedTypeFilter}
            onChange={(e) => setSelectedTypeFilter(e.target.value as any)}
            className="w-full px-3 py-2 bg-slate-900 text-amber-200 text-xs rounded-xl border border-amber-500/30 focus:outline-none focus:border-amber-400 font-mono"
          >
            <option value="all">📁 All Media Types</option>
            <option value="audio">🎵 Audio Tracks Only</option>
            <option value="video">🎬 Videos Only</option>
            <option value="image">🖼️ Images Only</option>
          </select>
        </div>

        {/* Tag Preset Dropdown */}
        <div>
          <select
            value={selectedTagFilter}
            onChange={(e) => setSelectedTagFilter(e.target.value)}
            className="w-full px-3 py-2 bg-slate-900 text-amber-200 text-xs rounded-xl border border-amber-500/30 focus:outline-none focus:border-amber-400 font-mono"
          >
            <option value="all">🏷️ All Tags ({uniqueTags.length} Unique)</option>
            {uniqueTags.map(({ tag, count }) => (
              <option key={tag} value={tag}>#{tag} ({count})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Unique Tag Quick Filter Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider shrink-0">Tags:</span>
        <button
          onClick={() => setSelectedTagFilter('all')}
          className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all shrink-0 border ${
            selectedTagFilter === 'all'
              ? 'bg-amber-500 text-slate-950 border-amber-400'
              : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-amber-300'
          }`}
        >
          All
        </button>
        {uniqueTags.slice(0, 15).map(({ tag, count }) => (
          <button
            key={tag}
            onClick={() => setSelectedTagFilter(selectedTagFilter === tag ? 'all' : tag)}
            className={`px-2 py-0.5 rounded-lg text-[10px] font-mono transition-all shrink-0 border ${
              selectedTagFilter === tag
                ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow'
                : 'bg-slate-950 text-amber-300/80 border-amber-500/20 hover:border-amber-400'
            }`}
          >
            #{tag} <span className="opacity-60 text-[9px]">({count})</span>
          </button>
        ))}
      </div>

      {/* Main Searchable Table */}
      <div className="border border-amber-500/20 rounded-2xl overflow-hidden bg-slate-950/60 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-amber-500/30 text-[11px] font-mono text-amber-400 uppercase tracking-wider">
                <th className="p-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={filteredItems.length > 0 && selectedItemIds.length === filteredItems.length}
                    onChange={handleSelectAll}
                    className="accent-amber-500 rounded cursor-pointer"
                  />
                </th>
                <th className="p-3">Type</th>
                <th className="p-3">Media Title & Speaker</th>
                <th className="p-3">Searchable Tags</th>
                <th className="p-3">Quick Add</th>
                <th className="p-3">Vault Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-500/10">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500 italic">
                    No files found matching the criteria. Use the uploader or change filters.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isEditing = editingId === item.id;
                  const isSelected = selectedItemIds.includes(item.id);
                  const isPlayingAudio = activeAudioPlayingId === item.id;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-900/60 transition-colors ${
                        isSelected ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(item.id)}
                          className="accent-amber-500 rounded cursor-pointer"
                        />
                      </td>

                      {/* Type Badge & Audio Preview Play button */}
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20 shrink-0">
                            {item.type === 'audio' ? <FileAudio className="w-4 h-4" /> : item.type === 'video' ? <Video className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                          </div>
                          {item.type === 'audio' && (
                            <button
                              onClick={() => handleToggleAudioPlay(item)}
                              className={`p-1.5 rounded-lg border text-[10px] transition-all ${
                                isPlayingAudio
                                  ? 'bg-amber-500 text-slate-950 border-amber-400'
                                  : 'bg-slate-900 text-amber-300 border-amber-500/20 hover:border-amber-400'
                              }`}
                              title={isPlayingAudio ? 'Pause Audio Preview' : 'Play Audio Preview'}
                            >
                              {isPlayingAudio ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                            </button>
                          )}
                        </div>
                      </td>

                      {/* Title & Details */}
                      <td className="p-3 max-w-xs">
                        <p className="font-bold text-amber-100 truncate">{item.title}</p>
                        <p className="text-[10px] text-slate-400 truncate">{item.artistOrProphet}</p>
                        <p className="text-[9px] text-slate-500 font-mono">{item.date} • {item.likes} Likes • {item.downloads} DLs</p>
                      </td>

                      {/* Tags (Display or Inline Editor) */}
                      <td className="p-3 min-w-[240px]">
                        {isEditing ? (
                          <div className="space-y-2">
                            <input
                              type="text"
                              value={editingTagsString}
                              onChange={(e) => setEditingTagsString(e.target.value)}
                              placeholder="prophetic, worship, 528hz, healing"
                              className="w-full bg-slate-900 text-amber-200 border border-amber-500/40 rounded-lg px-2.5 py-1 text-xs font-mono focus:outline-none focus:border-amber-400"
                            />
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => handleSaveEdit(item.id)}
                                className="px-2.5 py-0.5 rounded-md bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] flex items-center space-x-1 shadow"
                              >
                                <Save className="w-2.5 h-2.5" />
                                <span>Save</span>
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-wrap gap-1.5 items-center">
                            {(item.tags && item.tags.length > 0 ? item.tags : ['prophetic', item.type]).map((tag, tIdx) => (
                              <span
                                key={tIdx}
                                className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 font-mono text-[10px] border border-amber-500/30 group"
                              >
                                <span>#{tag}</span>
                                <button
                                  onClick={() => handleRemoveTag(item.id, tag)}
                                  className="text-slate-400 hover:text-red-400 transition-colors ml-0.5"
                                  title={`Remove tag #${tag}`}
                                >
                                  <X className="w-2.5 h-2.5" />
                                </button>
                              </span>
                            ))}
                          </div>
                        )}
                      </td>

                      {/* Quick Add Tag Preset or Custom */}
                      <td className="p-3">
                        <div className="flex items-center space-x-1.5">
                          <input
                            type="text"
                            value={quickAddTagInput[item.id] || ''}
                            onChange={(e) => setQuickAddTagInput({ ...quickAddTagInput, [item.id]: e.target.value })}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleQuickAddCustomTag(item.id);
                              }
                            }}
                            placeholder="+ add tag"
                            className="w-24 bg-slate-900 text-amber-200 border border-amber-500/20 rounded-md px-2 py-1 text-[10px] font-mono focus:outline-none focus:border-amber-400"
                          />
                          <button
                            onClick={() => handleQuickAddCustomTag(item.id)}
                            className="p-1 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30"
                            title="Add tag"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        {/* Quick Presets */}
                        <div className="flex items-center space-x-1 pt-1">
                          {['prophetic', '528hz', 'worship'].map(preset => (
                            <button
                              key={preset}
                              onClick={() => handleAddPresetTag(item.id, preset)}
                              className="text-[8px] font-mono text-slate-400 hover:text-amber-300 hover:underline"
                            >
                              +{preset}
                            </button>
                          ))}
                        </div>
                      </td>

                      {/* Vault Status */}
                      <td className="p-3 text-[10px] font-mono">
                        <span className="inline-flex items-center space-x-1 text-emerald-400">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>IndexedDB Vault</span>
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right">
                        {!isEditing && (
                          <button
                            onClick={() => handleStartEdit(item)}
                            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold inline-flex items-center space-x-1 transition-all"
                            title="Edit Tags Inline"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit Tags</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 border-t border-amber-500/20 pt-4 font-mono">
        <div className="flex items-center space-x-3">
          <span>Showing <strong className="text-amber-300">{filteredItems.length}</strong> of {mediaItems.length} media files</span>
          <span>•</span>
          <span><strong className="text-amber-300">{uniqueTags.length}</strong> unique indexed tags</span>
        </div>
        <div className="flex items-center space-x-2 mt-2 sm:mt-0 text-emerald-400">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Atomic Synchronization Active Across All App Views</span>
        </div>
      </div>

      {/* Bulk Tag Modal */}
      {showBulkModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
              <h3 className="text-sm font-bold text-amber-200 flex items-center space-x-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>Bulk Apply Tags to {selectedItemIds.length} Selected Files</span>
              </h3>
              <button
                onClick={() => setShowBulkModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-amber-300 block font-semibold">
                Enter Tags to Append (Comma-Separated)
              </label>
              <input
                type="text"
                value={bulkTagInput}
                onChange={(e) => setBulkTagInput(e.target.value)}
                placeholder="prophetic, holy-fire, victory, 528hz"
                className="w-full bg-slate-950 text-amber-100 border border-amber-500/40 rounded-xl px-3.5 py-2 text-xs font-mono focus:outline-none focus:border-amber-400 font-bold"
              />
              <p className="text-[10px] text-slate-400">
                These tags will be appended atomically to all {selectedItemIds.length} selected files in the IndexedDB repository.
              </p>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowBulkModal(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyBulkTags}
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-xs font-extrabold shadow"
              >
                Apply to {selectedItemIds.length} Files
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
