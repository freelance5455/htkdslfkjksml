import React from 'react';
import { Car, RefreshCw, CheckCircle, ShieldCheck } from 'lucide-react';

interface SalidaViewProps {
  onReabrir: () => void;
}

export const SalidaView: React.FC<SalidaViewProps> = ({ onReabrir }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center select-none">
      <div className="w-full max-w-sm space-y-6 animate-fadeIn">
        <div className="w-24 h-24 mx-auto rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-center shadow-2xl relative">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center">
            <Car size={32} />
          </div>
          <div className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-emerald-500 text-slate-950">
            <CheckCircle size={16} />
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-black text-white tracking-tight">
            Aplicación Cerrada
          </h2>
          <p className="text-sm text-slate-400">
            Todos los registros de vehículos y fotos están guardados con seguridad en el almacenamiento local de tu dispositivo.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400 flex items-center justify-center gap-2">
          <ShieldCheck size={16} className="text-emerald-400 shrink-0" />
          <span>Datos protegidos y disponibles sin conexión</span>
        </div>

        <div className="pt-4">
          <button
            onClick={onReabrir}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <RefreshCw size={18} />
            Volver a abrir el taller
          </button>
        </div>
      </div>
    </div>
  );
};
