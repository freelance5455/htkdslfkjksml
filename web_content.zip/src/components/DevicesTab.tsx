/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNetwork } from '../context/NetworkContext';
import { NetworkDevice, DeviceType, PriorityTier } from '../types/network';
import { 
  Radar, 
  Search, 
  Smartphone, 
  Gamepad2, 
  Laptop, 
  Tv, 
  Cpu, 
  Network as NetIcon, 
  PauseCircle, 
  PlayCircle, 
  Sliders, 
  X, 
  ShieldAlert, 
  Check, 
  Wifi, 
  ArrowDown, 
  ArrowUp,
  Plus,
  Terminal,
  Signal
} from 'lucide-react';

export const DevicesTab: React.FC = () => {
  const { 
    devices, 
    scanForDevices, 
    isScanningDevices, 
    scanProgress, 
    toggleDevicePause, 
    updateDeviceLimits, 
    toggleDeviceGamingPriority,
    updateDevicePriority,
    updateDeviceDetails,
    addDevice,
    removeDevice,
    router
  } = useNetwork();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeDeviceForEdit, setActiveDeviceForEdit] = useState<NetworkDevice | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Filtered devices
  const filteredDevices = devices.filter(dev => {
    const matchesSearch = 
      dev.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (dev.customAlias && dev.customAlias.toLowerCase().includes(searchQuery.toLowerCase())) ||
      dev.ip.includes(searchQuery) ||
      dev.mac.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dev.vendor.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'all' || dev.type === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getDeviceIcon = (type: DeviceType) => {
    switch (type) {
      case 'console': return Gamepad2;
      case 'mobile': return Smartphone;
      case 'pc': return Laptop;
      case 'tv': return Tv;
      case 'iot': return Cpu;
      case 'network': return NetIcon;
    }
  };

  const categories = [
    { id: 'all', label: 'All', count: devices.length },
    { id: 'console', label: 'Gaming', count: devices.filter(d => d.type === 'console').length },
    { id: 'mobile', label: 'Mobile', count: devices.filter(d => d.type === 'mobile').length },
    { id: 'pc', label: 'PC/Mac', count: devices.filter(d => d.type === 'pc').length },
    { id: 'tv', label: 'Smart TV', count: devices.filter(d => d.type === 'tv').length },
    { id: 'iot', label: 'Smart Home', count: devices.filter(d => d.type === 'iot').length },
  ];

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Top Action & Subnet Scanner Bar */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800/80 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Connected Devices</span>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/20">
                {devices.filter(d => d.isOnline).length} Active
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Subnet 192.168.1.0/24 · Gateway {router.ip}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition"
              title="Add Custom Client"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                if (!isScanningDevices) scanForDevices();
              }}
              disabled={isScanningDevices}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-white shadow transition active:scale-95 ${
                isScanningDevices
                  ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                  : 'bg-cyan-600 hover:bg-cyan-500'
              }`}
            >
              <Radar className={`w-3.5 h-3.5 ${isScanningDevices ? 'animate-spin' : ''}`} />
              <span>{isScanningDevices ? `Scanning ${scanProgress}%` : 'Scan LAN'}</span>
            </button>
          </div>
        </div>

        {/* Scan Progress Bar */}
        {isScanningDevices && (
          <div className="mt-3">
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className="bg-cyan-500 h-full transition-all duration-300"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>Probing ARP, mDNS & SSDP tables...</span>
              <span>{scanProgress}%</span>
            </div>
          </div>
        )}

        {/* Search Bar */}
        <div className="mt-3 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, IP, MAC, or vendor..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-800 pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
          />
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-3">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                  : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800/60'
              }`}
            >
              <span>{cat.label}</span>
              <span className="text-[10px] font-mono text-slate-500">({cat.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Device List */}
      <div className="space-y-2.5">
        {filteredDevices.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800/60 text-slate-400">
            <p className="text-xs">No devices found matching your search.</p>
          </div>
        ) : (
          filteredDevices.map(dev => {
            const Icon = getDeviceIcon(dev.type);
            const totalSpeed = dev.currentDlMbps + dev.currentUlMbps;
            const hasCap = dev.downloadLimitMbps !== null || dev.uploadLimitMbps !== null;

            return (
              <div
                key={dev.id}
                className={`p-3 rounded-2xl border transition-all ${
                  dev.isPaused
                    ? 'bg-rose-950/20 border-rose-900/40 opacity-75'
                    : dev.isGamingPriority
                    ? 'bg-gradient-to-r from-slate-900 to-purple-950/30 border-purple-500/30 shadow-sm'
                    : 'bg-slate-900/80 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  {/* Left: Icon & Info */}
                  <div 
                    onClick={() => setActiveDeviceForEdit(dev)}
                    className="cursor-pointer flex items-start gap-3 min-w-0 flex-1"
                  >
                    <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      dev.isPaused
                        ? 'bg-rose-500/10 text-rose-400'
                        : dev.isGamingPriority
                        ? 'bg-purple-500/20 text-purple-300'
                        : 'bg-slate-800 text-slate-300'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white truncate">
                          {dev.customAlias || dev.name}
                        </span>

                        {dev.isGamingPriority && (
                          <span className="text-[9px] font-bold text-purple-300 bg-purple-500/20 border border-purple-500/30 px-1.5 py-0.2 rounded">
                            VIP GAMING
                          </span>
                        )}

                        {dev.isPaused && (
                          <span className="text-[9px] font-bold text-rose-400 bg-rose-500/20 px-1.5 py-0.2 rounded">
                            PAUSED
                          </span>
                        )}

                        {hasCap && !dev.isPaused && (
                          <span className="text-[9px] font-mono font-medium text-amber-300 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.2 rounded">
                            Cap: {dev.downloadLimitMbps || '∞'}M / {dev.uploadLimitMbps || '∞'}M
                          </span>
                        )}
                      </div>

                      {/* Technical Info Line */}
                      <div className="text-[11px] text-slate-400 font-mono mt-1 flex items-center gap-2 flex-wrap">
                        <span className="text-cyan-400">{dev.ip}</span>
                        <span>·</span>
                        <span className="text-slate-500">{dev.mac}</span>
                        <span>·</span>
                        <span>{dev.wifiBand}</span>
                      </div>

                      {/* Vendor name */}
                      <div className="text-[10px] text-slate-500 mt-0.5 truncate">
                        {dev.vendor} {dev.staticIpAssigned && '· Static IP'}
                      </div>
                    </div>
                  </div>

                  {/* Right: Real-time throughput & Quick Controls */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <div className="text-right">
                      <div className="text-xs font-bold text-cyan-300 font-mono">
                        {dev.isPaused ? (
                          <span className="text-rose-400">0.0 Mbps</span>
                        ) : (
                          `${totalSpeed.toFixed(1)} Mbps`
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        ↓ {dev.currentDlMbps} · ↑ {dev.currentUlMbps}
                      </div>
                    </div>

                    {/* Quick Action Buttons */}
                    <div className="flex items-center gap-1.5">
                      {/* Pause / Resume Button */}
                      <button
                        onClick={() => toggleDevicePause(dev.id)}
                        className={`p-1.5 rounded-lg transition ${
                          dev.isPaused
                            ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20'
                        }`}
                        title={dev.isPaused ? 'Resume Internet' : 'Pause Internet'}
                      >
                        {dev.isPaused ? (
                          <PlayCircle className="w-4 h-4" />
                        ) : (
                          <PauseCircle className="w-4 h-4" />
                        )}
                      </button>

                      {/* Limits / Config Button */}
                      <button
                        onClick={() => setActiveDeviceForEdit(dev)}
                        className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
                        title="Bandwidth Controls & Rules"
                      >
                        <Sliders className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Per-Client Bandwidth Control Modal */}
      {activeDeviceForEdit && (
        <DeviceEditModal
          device={activeDeviceForEdit}
          onClose={() => setActiveDeviceForEdit(null)}
          onSaveLimits={(dl, ul) => updateDeviceLimits(activeDeviceForEdit.id, dl, ul)}
          onTogglePause={() => toggleDevicePause(activeDeviceForEdit.id)}
          onToggleGaming={() => toggleDeviceGamingPriority(activeDeviceForEdit.id)}
          onUpdatePriority={(tier) => updateDevicePriority(activeDeviceForEdit.id, tier)}
          onUpdateDetails={(alias, staticIp) => updateDeviceDetails(activeDeviceForEdit.id, alias, staticIp)}
          onRemove={() => {
            removeDevice(activeDeviceForEdit.id);
            setActiveDeviceForEdit(null);
          }}
          routerModel={router.model}
        />
      )}

      {/* Add Custom Device Modal */}
      {isAddModalOpen && (
        <AddDeviceModal
          onClose={() => setIsAddModalOpen(false)}
          onAdd={(newDev) => {
            addDevice(newDev);
            setIsAddModalOpen(false);
          }}
        />
      )}
    </div>
  );
};

interface DeviceEditModalProps {
  device: NetworkDevice;
  onClose: () => void;
  onSaveLimits: (dl: number | null, ul: number | null) => void;
  onTogglePause: () => void;
  onToggleGaming: () => void;
  onUpdatePriority: (tier: PriorityTier) => void;
  onUpdateDetails: (alias: string, staticIp?: boolean) => void;
  onRemove: () => void;
  routerModel: string;
}

const DeviceEditModal: React.FC<DeviceEditModalProps> = ({
  device,
  onClose,
  onSaveLimits,
  onTogglePause,
  onToggleGaming,
  onUpdatePriority,
  onUpdateDetails,
  onRemove,
  routerModel,
}) => {
  const [alias, setAlias] = useState(device.customAlias || device.name);
  const [dlLimit, setDlLimit] = useState<number | null>(device.downloadLimitMbps);
  const [ulLimit, setUlLimit] = useState<number | null>(device.uploadLimitMbps);
  const [tier, setTier] = useState<PriorityTier>(device.priorityTier);
  const [staticIp, setStaticIp] = useState<boolean>(!!device.staticIpAssigned);
  const [showCliRule, setShowCliRule] = useState(false);

  const handlePreset = (dl: number | null, ul: number | null) => {
    setDlLimit(dl);
    setUlLimit(ul);
  };

  const handleSave = () => {
    onSaveLimits(dlLimit, ulLimit);
    onUpdatePriority(tier);
    onUpdateDetails(alias, staticIp);
    onClose();
  };

  // Generate real tc / OpenWrt command for this client
  const generatedTcRule = `# OpenWrt / Linux tc client rate-limit rule
uci set sqm.sqm_${device.id}=queue
uci set sqm.sqm_${device.id}.interface='br-lan'
uci set sqm.sqm_${device.id}.download='${dlLimit ? dlLimit * 1000 : 1000000}'
uci set sqm.sqm_${device.id}.upload='${ulLimit ? ulLimit * 1000 : 200000}'
uci set sqm.sqm_${device.id}.qdisc='cake'
uci set sqm.sqm_${device.id}.script='layer_cake.qos'
uci set sqm.sqm_${device.id}.enabled='1'
# Filter destination IP ${device.ip}
iptables -t mangle -A FORWARD -d ${device.ip} -j MARK --set-mark ${device.isGamingPriority ? '0x10' : '0x20'}
uci commit sqm`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-5 overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Bandwidth Control & Client Rules</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
              IP: {device.ip} · MAC: {device.mac}
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-4 space-y-4">
          {/* Device Alias input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Device Name / Alias
            </label>
            <input
              type="text"
              value={alias}
              onChange={e => setAlias(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Quick Presets */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Quick Bandwidth Preset
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => handlePreset(null, null)}
                className={`p-2 rounded-xl border text-left transition ${
                  dlLimit === null && ulLimit === null
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                    : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-white">Full Speed</div>
                <div className="text-[10px] text-slate-400">Unlimited pipe</div>
              </button>

              <button
                type="button"
                onClick={() => handlePreset(35, 10)}
                className={`p-2 rounded-xl border text-left transition ${
                  dlLimit === 35 && ulLimit === 10
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                    : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-white">4K Streaming</div>
                <div className="text-[10px] text-slate-400">35M Down / 10M Up</div>
              </button>

              <button
                type="button"
                onClick={() => handlePreset(15, 5)}
                className={`p-2 rounded-xl border text-left transition ${
                  dlLimit === 15 && ulLimit === 5
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                    : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-white">Office / Meeting</div>
                <div className="text-[10px] text-slate-400">15M Down / 5M Up</div>
              </button>

              <button
                type="button"
                onClick={() => handlePreset(5, 2)}
                className={`p-2 rounded-xl border text-left transition ${
                  dlLimit === 5 && ulLimit === 2
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300'
                    : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-semibold text-white">Throttle / Saver</div>
                <div className="text-[10px] text-slate-400">5M Down / 2M Up</div>
              </button>
            </div>
          </div>

          {/* Download Speed Limit Slider & Number */}
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                <ArrowDown className="w-3.5 h-3.5 text-cyan-400" />
                <span>Download Limit</span>
              </span>
              <span className="font-mono text-cyan-400 font-bold">
                {dlLimit !== null ? `${dlLimit} Mbps` : 'Unlimited'}
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="200"
              value={dlLimit ?? 200}
              onChange={e => {
                const val = Number(e.target.value);
                setDlLimit(val >= 200 ? null : val);
              }}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>1 Mbps</span>
              <span>100 Mbps</span>
              <span>Unlimited (200+)</span>
            </div>
          </div>

          {/* Upload Speed Limit Slider & Number */}
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                <ArrowUp className="w-3.5 h-3.5 text-purple-400" />
                <span>Upload Limit</span>
              </span>
              <span className="font-mono text-purple-400 font-bold">
                {ulLimit !== null ? `${ulLimit} Mbps` : 'Unlimited'}
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="100"
              value={ulLimit ?? 100}
              onChange={e => {
                const val = Number(e.target.value);
                setUlLimit(val >= 100 ? null : val);
              }}
              className="w-full accent-purple-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>1 Mbps</span>
              <span>50 Mbps</span>
              <span>Unlimited (100+)</span>
            </div>
          </div>

          {/* Priority Tier selection */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Traffic Priority Queue Tier
            </label>
            <div className="grid grid-cols-4 gap-1 text-[11px]">
              {(['critical', 'high', 'medium', 'low'] as PriorityTier[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTier(t)}
                  className={`py-1.5 rounded-lg border capitalize font-medium transition ${
                    tier === t
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Special Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            {/* VIP Gaming Priority toggle */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Gamepad2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>VIP Gaming Priority Lane</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  Tag packets with DSCP Expedited Forwarding
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleGaming}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  device.isGamingPriority
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {device.isGamingPriority ? 'VIP ACTIVE' : 'ENABLE'}
              </button>
            </div>

            {/* Pause Internet toggle */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <PauseCircle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Internet Access Block</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  Drop WAN packets at router gateway
                </div>
              </div>
              <button
                type="button"
                onClick={onTogglePause}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  device.isPaused
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {device.isPaused ? 'BLOCKED' : 'BLOCK'}
              </button>
            </div>

            {/* Static IP toggle */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-semibold text-white">DHCP Static IP Lease</div>
                <div className="text-[10px] text-slate-400 font-mono">Reserve {device.ip}</div>
              </div>
              <input
                type="checkbox"
                checked={staticIp}
                onChange={e => setStaticIp(e.target.checked)}
                className="w-4 h-4 accent-cyan-500"
              />
            </div>
          </div>

          {/* Generated Router Script preview */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => setShowCliRule(!showCliRule)}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{showCliRule ? 'Hide Router CLI Commands' : 'View Generated Router QoS Script'}</span>
            </button>

            {showCliRule && (
              <div className="mt-2 p-2.5 rounded-xl bg-black border border-slate-800 text-[10px] font-mono text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed">
                {generatedTcRule}
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800 gap-2">
          <button
            type="button"
            onClick={onRemove}
            className="px-3 py-2 rounded-xl text-rose-400 hover:bg-rose-500/10 text-xs transition"
          >
            Forget Device
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md transition"
            >
              Apply Limits
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface AddDeviceModalProps {
  onClose: () => void;
  onAdd: (device: Omit<NetworkDevice, 'id'>) => void;
}

const AddDeviceModal: React.FC<AddDeviceModalProps> = ({ onClose, onAdd }) => {
  const [name, setName] = useState('');
  const [ip, setIp] = useState('192.168.1.');
  const [mac, setMac] = useState('00:11:22:33:44:55');
  const [type, setType] = useState<DeviceType>('mobile');
  const [band, setBand] = useState<'2.4GHz' | '5GHz' | '6GHz' | 'Ethernet'>('5GHz');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !ip) return;

    onAdd({
      name,
      customAlias: name,
      vendor: 'Custom Discovered Client',
      ip,
      mac,
      type,
      isOnline: true,
      currentDlMbps: 1.5,
      currentUlMbps: 0.4,
      totalUsageMb: 0,
      downloadLimitMbps: null,
      uploadLimitMbps: null,
      isPaused: false,
      isGamingPriority: false,
      priorityTier: 'medium',
      wifiBand: band,
      rssiDbm: -50,
      hostname: name.toLowerCase().replace(/\s+/g, '-'),
      staticIpAssigned: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white">Add Device to Network</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="my-4 space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Device Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Living Room Nvidia Shield"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">IP Address</label>
            <input
              type="text"
              required
              value={ip}
              onChange={e => setIp(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">MAC Address</label>
            <input
              type="text"
              value={mac}
              onChange={e => setMac(e.target.value)}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Device Type</label>
              <select
                value={type}
                onChange={e => setType(e.target.value as DeviceType)}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-2 py-2 text-xs text-white"
              >
                <option value="console">Gaming Console</option>
                <option value="mobile">Mobile Phone</option>
                <option value="pc">PC / Mac</option>
                <option value="tv">Smart TV</option>
                <option value="iot">Smart Home (IoT)</option>
                <option value="network">Network Gear</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Band</label>
              <select
                value={band}
                onChange={e => setBand(e.target.value as any)}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-2 py-2 text-xs text-white"
              >
                <option value="5GHz">5GHz Wi-Fi</option>
                <option value="6GHz">6GHz (Wi-Fi 6E)</option>
                <option value="2.4GHz">2.4GHz Wi-Fi</option>
                <option value="Ethernet">Ethernet LAN</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition"
          >
            Add Client
          </button>
        </form>
      </div>
    </div>
  );
};
