import React from 'react';
import {
  Eye,
  Volume2,
  Monitor,
  Check,
  X,
  Sparkles,
  HelpCircle,
  FileSearch,
  Upload,
  Type
} from 'lucide-react';

interface ScreenReaderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerScreenCapture: () => void;
  onTriggerFileUpload: () => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: (val: boolean) => void;
  highContrast: boolean;
  onToggleHighContrast: (val: boolean) => void;
  speechRate: number;
  onChangeSpeechRate: (val: number) => void;
}

export const ScreenReaderModal: React.FC<ScreenReaderModalProps> = ({
  isOpen,
  onClose,
  onTriggerScreenCapture,
  onTriggerFileUpload,
  autoSpeak,
  onToggleAutoSpeak,
  highContrast,
  onToggleHighContrast,
  speechRate,
  onChangeSpeechRate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Screen Reader & Accessibility
                <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Vision + Speech
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                AI screen inspection, visual OCR transcription & speech audio controls
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-sm text-slate-200">
          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => {
                onClose();
                onTriggerScreenCapture();
              }}
              className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-950/50 to-slate-800 border border-emerald-500/30 hover:border-emerald-500 text-left transition flex items-start gap-3 cursor-pointer group shadow-lg"
            >
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-300 group-hover:scale-105 transition">
                <Monitor className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-white text-sm group-hover:text-emerald-300 transition">
                  Capture & Read Screen
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Takes live snapshot of your desktop or tab and reads text aloud
                </div>
              </div>
            </button>

            <button
              onClick={() => {
                onClose();
                onTriggerFileUpload();
              }}
              className="p-3.5 rounded-xl bg-gradient-to-br from-cyan-950/50 to-slate-800 border border-cyan-500/30 hover:border-cyan-500 text-left transition flex items-start gap-3 cursor-pointer group shadow-lg"
            >
              <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-300 group-hover:scale-105 transition">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-white text-sm group-hover:text-cyan-300 transition">
                  Upload Screenshot / Doc
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Inspect receipts, math, diagrams, PDF pages or photos
                </div>
              </div>
            </button>
          </div>

          {/* Accessibility Settings */}
          <div className="space-y-3 p-4 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Accessibility & Voice Preferences
            </h3>

            {/* Auto speak */}
            <div className="flex items-center justify-between py-2 border-b border-slate-700/40">
              <div className="flex items-center gap-2.5">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-sm font-medium text-white">Auto-Speak Replies (Voice)</div>
                  <div className="text-xs text-slate-400">AI automatically speaks answers aloud using Text-to-Speech</div>
                </div>
              </div>
              <button
                onClick={() => onToggleAutoSpeak(!autoSpeak)}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                  autoSpeak ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-white shadow-md" />
              </button>
            </div>

            {/* High Contrast */}
            <div className="flex items-center justify-between py-2 border-b border-slate-700/40">
              <div className="flex items-center gap-2.5">
                <Type className="w-4 h-4 text-yellow-400" />
                <div>
                  <div className="text-sm font-medium text-white">High Contrast & Large Font</div>
                  <div className="text-xs text-slate-400">Increases text readability and contrast for easier reading</div>
                </div>
              </div>
              <button
                onClick={() => onToggleHighContrast(!highContrast)}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                  highContrast ? 'bg-yellow-500 justify-end' : 'bg-slate-700 justify-start'
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-white shadow-md" />
              </button>
            </div>

            {/* Speech Rate */}
            <div className="py-2 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">Voice Speed (Speech Rate)</span>
                <span className="text-cyan-400 font-mono font-semibold">{speechRate}x</span>
              </div>
              <div className="flex items-center gap-2">
                {[0.8, 1.0, 1.2, 1.4].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => onChangeSpeechRate(rate)}
                    className={`flex-1 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                      speechRate === rate
                        ? 'bg-cyan-600 text-white shadow'
                        : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* How Screen Reader Works */}
          <div className="p-4 rounded-xl bg-slate-800/20 border border-slate-700/40 space-y-2 text-xs text-slate-300">
            <div className="font-semibold text-white flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-emerald-400" /> Kaise kaam karta hai Screen Reader?
            </div>
            <p className="leading-relaxed">
              1. <strong>Direct Capture</strong>: "Capture Screen" par click karne par browser aapse screen select karne ko kahega.
            </p>
            <p className="leading-relaxed">
              2. <strong>AI Vision OCR</strong>: AI screen ke har text, icons, buttons aur alerts ko instantly analyze karega.
            </p>
            <p className="leading-relaxed">
              3. <strong>Voice Guidance</strong>: AI aapko aawaz me bolkar sunayega ki screen par kya hai aur aapko kaunsa step lena hai.
            </p>
            <p className="leading-relaxed text-slate-400">
              *Note: Mobile par aap screenshot leke upload kar sakte hain ya camera se photo click kar sakte hain.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
