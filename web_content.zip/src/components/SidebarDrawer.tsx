import { useId, useState } from 'react';
import { Download, FolderDown, Plus, Trash2, X } from 'lucide-react';
import {
  clampVadSensitivity,
  getVadSensitivityLabel,
  MAX_VAD_SENSITIVITY,
  MIN_VAD_SENSITIVITY,
  vadSensitivityToRmsThreshold,
  vadThresholdToDb,
} from '../lib/voiceState';
import type {
  AIModelAdapterInfo,
  AssistantDomain,
  ConversationThread,
  ExplanationDepth,
  JarvisSettings,
  LanguagePreference,
} from '../lib/jarvisTypes';

interface SidebarDrawerProps {
  open: boolean;
  onClose: () => void;
  threads: ConversationThread[];
  activeThreadId: string;
  onSelectThread: (id: string) => void;
  onNewThread: () => void;
  onDeleteThread: (id: string) => void;
  onClearThreads?: () => void;
  settings: JarvisSettings;
  onUpdateSettings: (patch: Partial<JarvisSettings>) => void;
  models: AIModelAdapterInfo[];
  onExportProject?: () => void;
  onSaveProject?: () => void;
  exportStatus?: 'idle' | 'exporting' | 'saving';
}

const DOMAINS: Array<{ id: AssistantDomain; label: string }> = [
  { id: 'general', label: 'General' },
  { id: 'education', label: 'Education' },
  { id: 'coding', label: 'Coding' },
  { id: 'productivity', label: 'Productivity' },
  { id: 'planning', label: 'Planning' },
];

const DEPTHS: Array<{ id: ExplanationDepth; label: string }> = [
  { id: 'simple', label: 'Simple' },
  { id: 'balanced', label: 'Balanced' },
  { id: 'deep', label: 'Deep' },
];

const LANGUAGES: Array<{ id: LanguagePreference; label: string }> = [
  { id: 'auto', label: 'Auto (EN / HI / Hinglish)' },
  { id: 'english', label: 'English' },
  { id: 'hindi', label: 'Hindi (हिन्दी)' },
  { id: 'hinglish', label: 'Hinglish' },
];

export function SidebarDrawer({
  open,
  onClose,
  threads,
  activeThreadId,
  onSelectThread,
  onNewThread,
  onDeleteThread,
  onClearThreads,
  settings,
  onUpdateSettings,
  models,
  onExportProject,
  onSaveProject,
  exportStatus = 'idle',
}: SidebarDrawerProps) {
  const vadSliderId = useId();
  const [confirmClearThreads, setConfirmClearThreads] = useState(false);
  const activeModels = models.filter((m) => m.status === 'active');
  const hasConversationContent =
    threads.length > 1 || threads.some((t) => t.messages.length > 0);

  const renderContent = (idSuffix: 'desktop' | 'mobile') => {
    const sliderId = `${vadSliderId}-${idSuffix}`;
    return (
    <div className="flex h-full flex-col bg-[#080B11] text-slate-200">
      <div className="flex items-center justify-between border-b border-white/8 px-4 py-3.5">
        <span className="font-display text-sm font-semibold tracking-wide text-amber-300">
          Sessions & Brain
        </span>
        <button
          type="button"
          onClick={onClose}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-white lg:hidden"
          aria-label="Close sidebar"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="space-y-2 p-3">
        <button
          type="button"
          onClick={() => {
            onNewThread();
            onClose();
          }}
          className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-sky-400 whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          <span>New Conversation</span>
        </button>

        {(onExportProject || onSaveProject) && (
          <div className="grid grid-cols-2 gap-1.5">
            {onExportProject && (
              <button
                type="button"
                disabled={exportStatus !== 'idle'}
                onClick={() => onExportProject()}
                className="flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl border border-sky-400/30 bg-[#05070B] px-2.5 py-1.5 text-xs font-semibold text-sky-200 transition-colors hover:border-sky-400/60 hover:bg-sky-500/12 disabled:opacity-50 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5 shrink-0" />
                <span>{exportStatus === 'exporting' ? 'Exporting…' : 'Export Project'}</span>
              </button>
            )}
            {onSaveProject && (
              <button
                type="button"
                disabled={exportStatus !== 'idle'}
                onClick={() => onSaveProject()}
                className="flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl border border-amber-400/30 bg-[#05070B] px-2.5 py-1.5 text-xs font-semibold text-amber-200 transition-colors hover:border-amber-400/60 hover:bg-amber-500/12 disabled:opacity-50 whitespace-nowrap"
              >
                <FolderDown className="h-3.5 w-3.5 shrink-0" />
                <span>{exportStatus === 'saving' ? 'Saving…' : 'Save Project'}</span>
              </button>
            )}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-4">
        <div className="mb-2 flex items-center justify-between gap-2 px-1">
          <span className="text-xs font-medium text-slate-400">
            Conversation History
          </span>
          {onClearThreads && hasConversationContent && !confirmClearThreads && (
            <button
              type="button"
              onClick={() => setConfirmClearThreads(true)}
              className="rounded px-1.5 py-0.5 text-[11px] font-medium text-slate-400 hover:bg-white/5 hover:text-rose-300"
            >
              Clear all
            </button>
          )}
          {onClearThreads && confirmClearThreads && (
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  onClearThreads();
                  setConfirmClearThreads(false);
                }}
                className="rounded bg-rose-500 px-2 py-0.5 text-[11px] font-semibold text-white hover:bg-rose-400"
              >
                Confirm
              </button>
              <button
                type="button"
                onClick={() => setConfirmClearThreads(false)}
                className="rounded px-1.5 py-0.5 text-[11px] text-slate-400 hover:bg-white/5"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
        <div className="space-y-1">
          {threads.map((thread) => {
            const isActive = thread.id === activeThreadId;
            const canDelete = threads.length > 1 || thread.messages.length > 0;
            return (
              <div
                key={thread.id}
                className={`group flex items-center gap-1 rounded-xl transition-colors ${
                  isActive
                    ? 'bg-sky-500/12 text-white border border-sky-400/25'
                    : 'text-slate-400 hover:bg-white/4 hover:text-slate-200'
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    onSelectThread(thread.id);
                    onClose();
                  }}
                  className="min-h-[40px] flex-1 truncate px-3 py-2 text-left text-sm font-medium"
                >
                  {thread.title}
                </button>
                {canDelete && (
                  <button
                    type="button"
                    onClick={() => onDeleteThread(thread.id)}
                    aria-label={`Delete conversation ${thread.title}`}
                    className="mr-1 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-500 opacity-70 transition-colors hover:bg-white/8 hover:text-rose-400 group-hover:opacity-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-6 space-y-5 border-t border-white/8 pt-5">
          <div>
            <label
              htmlFor="jarvis-model-select"
              className="mb-1.5 block text-xs font-medium text-slate-400"
            >
              Gemini Speed Tier
            </label>
            <select
              id="jarvis-model-select"
              value={settings.modelId}
              onChange={(e) => onUpdateSettings({ modelId: e.target.value })}
              className="min-h-[42px] w-full rounded-xl border border-white/10 bg-[#05070B] px-3 py-2 text-sm text-slate-100"
            >
              {(activeModels.length > 0
                ? activeModels
                : [{ id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite' }]
              ).map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">
              Focus Domain
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {DOMAINS.map((d, idx) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => onUpdateSettings({ domain: d.id })}
                  className={`min-h-[38px] rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    DOMAINS.length % 2 === 1 && idx === DOMAINS.length - 1 ? 'col-span-2' : ''
                  } ${
                    settings.domain === d.id
                      ? 'bg-sky-500/20 text-sky-200 border border-sky-400/35'
                      : 'bg-[#05070B] text-slate-400 border border-white/6 hover:text-slate-200'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">
              Response Depth
            </span>
            <div className="grid grid-cols-3 gap-1 rounded-xl border border-white/6 bg-[#05070B] p-1">
              {DEPTHS.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => onUpdateSettings({ depth: d.id })}
                  className={`min-h-[34px] rounded-lg px-2 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                    settings.depth === d.id
                      ? 'bg-amber-500/20 text-amber-200'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label
              htmlFor="jarvis-lang-select"
              className="mb-1.5 block text-xs font-medium text-slate-400"
            >
              Language Preference
            </label>
            <select
              id="jarvis-lang-select"
              value={settings.languagePreference}
              onChange={(e) =>
                onUpdateSettings({
                  languagePreference: e.target.value as LanguagePreference,
                })
              }
              className="min-h-[42px] w-full rounded-xl border border-white/10 bg-[#05070B] px-3 py-2 text-sm text-slate-100"
            >
              {LANGUAGES.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.label}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-white/8 bg-[#05070B] px-3 py-2.5">
            <div>
              <div className="text-xs font-medium text-slate-200">
                Chat Memory Commands
              </div>
              <div className="text-[11px] text-slate-400">
                Save permanently only when you ask
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.autoExtractMemory}
              aria-label="Toggle saving permanent memories when asked in chat"
              onClick={() =>
                onUpdateSettings({ autoExtractMemory: !settings.autoExtractMemory })
              }
              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                settings.autoExtractMemory ? 'bg-amber-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.autoExtractMemory ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-white/8 bg-[#05070B] px-3 py-2.5">
            <div>
              <div className="text-xs font-medium text-slate-200">
                Auto-Speak Responses
              </div>
              <div className="text-[11px] text-slate-400">
                {settings.voiceMuted ? 'Voice output muted' : 'Speak every completed reply'}
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={!settings.voiceMuted}
              aria-label="Toggle automatic spoken AI replies"
              onClick={() =>
                onUpdateSettings({ voiceMuted: !settings.voiceMuted })
              }
              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                !settings.voiceMuted ? 'bg-sky-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  !settings.voiceMuted ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {(() => {
            const sensitivity = clampVadSensitivity(settings.vadSensitivity);
            const rmsThreshold = vadSensitivityToRmsThreshold(sensitivity);
            const dbThreshold = vadThresholdToDb(rmsThreshold);
            const modeLabel = getVadSensitivityLabel(sensitivity);
            return (
              <div className="rounded-xl border border-white/8 bg-[#05070B] px-3 py-3">
                <div className="flex items-center justify-between gap-2">
                  <label
                    htmlFor={sliderId}
                    className="text-xs font-medium text-slate-200"
                  >
                    Voice Sensitivity (VAD)
                  </label>
                  <span
                    data-testid="vad-sensitivity-readout"
                    className="font-mono text-[11px] font-medium text-sky-300 tabular-nums"
                  >
                    {sensitivity}% · {modeLabel}
                  </span>
                </div>
                <input
                  id={sliderId}
                  type="range"
                  min={MIN_VAD_SENSITIVITY}
                  max={MAX_VAD_SENSITIVITY}
                  step={5}
                  value={sensitivity}
                  onChange={(e) =>
                    onUpdateSettings({
                      vadSensitivity: clampVadSensitivity(Number(e.target.value)),
                    })
                  }
                  className="mt-2.5 h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-sky-400"
                />
                <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-400">
                  <span>Noisy room</span>
                  <span className="font-mono tabular-nums text-slate-500">
                    Gate {dbThreshold} dBFS
                  </span>
                  <span>Quiet room</span>
                </div>
                <p className="mt-1.5 text-[11px] leading-snug text-slate-400">
                  Lower sensitivity raises the threshold to filter background noise.
                </p>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
    );
  };

  return (
    <>
      <aside className="hidden w-[272px] shrink-0 border-r border-white/8 lg:block">
        {renderContent('desktop')}
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={onClose}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-[290px] max-w-[85vw] border-r border-white/10 shadow-2xl">
            {renderContent('mobile')}
          </aside>
        </div>
      )}
    </>
  );
}
