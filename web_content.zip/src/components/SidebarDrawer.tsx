import React from 'react';
import {
  LayoutDashboard,
  CalendarDays,
  Truck,
  Warehouse,
  Wallet,
  Undo2,
  LockKeyhole,
  BarChart3,
  CreditCard,
  TrendingUp,
  Package,
  Settings,
  X,
  ShieldCheck,
} from 'lucide-react';
import { ActiveTab } from './BottomNav';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: ActiveTab) => void;
  activeTab: ActiveTab;
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  activeTab,
}) => {
  const menuItems: Array<{ id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }> = [
    { id: 'dashboard', label: 'لوحة المتابعة الرئيسية', icon: LayoutDashboard },
    { id: 'visits', label: 'الزيارات وخط السير اليومي', icon: CalendarDays },
    { id: 'invoice', label: 'نقطة البيع وإصدار فاتورة', icon: Truck },
    { id: 'debt', label: 'الآجل والتحصيل (المديونيات والسداد)', icon: CreditCard },
    { id: 'inventory', label: 'حمولة السيارة والمخزن', icon: Warehouse },
    { id: 'treasury', label: 'الخزنة والمقبوضات والمصروفات', icon: Wallet },
    { id: 'returns', label: 'المرتجعات المتطورة', icon: Undo2 },
    { id: 'day-close', label: 'إغلاق اليوم البيعي وتأكيده', icon: LockKeyhole },
    { id: 'reports', label: 'التقارير اليومية والشاملة', icon: BarChart3 },
    { id: 'profit', label: 'حساب الأرباح وهوامش الربح', icon: TrendingUp },
    { id: 'products', label: 'دليل المنتجات والأسعار', icon: Package },
    { id: 'settings', label: 'الإعدادات والنسخ الاحتياطي', icon: Settings },
  ];

  return (
    <div
      className={`fixed inset-0 z-50 transition-opacity duration-300 ${
        isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
      }`}
    >
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-sm"
      />

      {/* Drawer Panel - RTL slides from right */}
      <aside
        className={`absolute top-0 right-0 h-full w-[85%] max-w-sm bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Profile Card Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 pt-[max(1rem,var(--sat))]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-lg">
                🚚
              </div>
              <div>
                <h2 className="text-white font-bold text-sm">مندوب المبيعات</h2>
                <p className="text-xs text-amber-400/90 font-mono">سيارة: VAN-9902</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-slate-700/50 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-800">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>نظام محلي مشفر 100% يعمل دون إنترنت (Offline Native)</span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto no-scrollbar p-3 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl text-xs font-bold transition active:scale-98 ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-amber-400'}`} />
                <span className="flex-1 text-right">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 text-center text-[10px] text-slate-500">
          Sales & Logistics Pro • الإصدار المتطور v2.0
        </div>
      </aside>
    </div>
  );
};
