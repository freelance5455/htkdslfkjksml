import React, { useState } from 'react';
import { Bluetooth, Shield, Cpu, Play, CheckCircle2, AlertTriangle, Layers, Radio } from 'lucide-react';
import { RemoteKey } from '../types/remote';

export const BluetoothHidLab: React.FC = () => {
  const [selectedKey, setSelectedKey] = useState<RemoteKey>('VOL_UP');
  const [reportLog, setReportLog] = useState<string[]>([
    'تم تسجيل HID App SDP Record بنجاح مع اسم "Universal Remote Pro"',
    'الهاتف جاهز للإقران مع التلفاز أو جهاز الاستقبال كلوحة مفاتيح / ريموت HID لاسلكي',
  ]);

  const hidMap: Record<RemoteKey, { usage: number; name: string; hex: string }> = {
    POWER: { usage: 0x0030, name: 'Power', hex: '0x0030' },
    VOL_UP: { usage: 0x00e9, name: 'Volume Increment', hex: '0x00E9' },
    VOL_DOWN: { usage: 0x00ea, name: 'Volume Decrement', hex: '0x00EA' },
    MUTE: { usage: 0x00e2, name: 'Mute', hex: '0x00E2' },
    CH_UP: { usage: 0x009c, name: 'Channel Increment', hex: '0x009C' },
    CH_DOWN: { usage: 0x009d, name: 'Channel Decrement', hex: '0x009D' },
    UP: { usage: 0x0042, name: 'Menu Up', hex: '0x0042' },
    DOWN: { usage: 0x0043, name: 'Menu Down', hex: '0x0043' },
    LEFT: { usage: 0x0044, name: 'Menu Left', hex: '0x0044' },
    RIGHT: { usage: 0x0045, name: 'Menu Right', hex: '0x0045' },
    OK: { usage: 0x0041, name: 'Menu Pick (OK)', hex: '0x0041' },
    BACK: { usage: 0x0224, name: 'AC Back', hex: '0x0224' },
    HOME: { usage: 0x0223, name: 'AC Home', hex: '0x0223' },
    MENU: { usage: 0x0040, name: 'Menu', hex: '0x0040' },
    PLAY: { usage: 0x00b0, name: 'Play', hex: '0x00B0' },
    PAUSE: { usage: 0x00b1, name: 'Pause', hex: '0x00B1' },
    STOP: { usage: 0x00b7, name: 'Stop', hex: '0x00B7' },
    REWIND: { usage: 0x00b4, name: 'Rewind', hex: '0x00B4' },
    FAST_FORWARD: { usage: 0x00b3, name: 'Fast Forward', hex: '0x00B3' },
  } as any;

  const currentInfo = hidMap[selectedKey] || { usage: 0x00e9, name: 'Volume Increment', hex: '0x00E9' };

  const sendHidKey = (key: RemoteKey) => {
    setSelectedKey(key);
    const info = hidMap[key];
    const time = new Date().toLocaleTimeString();
    const lsb = (info.usage & 0xff).toString(16).toUpperCase().padStart(2, '0');
    const msb = ((info.usage >> 8) & 0xff).toString(16).toUpperCase().padStart(2, '0');

    setReportLog((prev) => [
      `[${time}] بث HID Report ID=1 [0x${lsb}, 0x${msb}] -> مفتاح: ${info.name}`,
      `[${time}] تحرير الزر (Release Report) [0x00, 0x00]`,
      ...prev.slice(0, 20),
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500/10 via-blue-500/5 to-transparent border border-blue-500/20 rounded-2xl p-4 flex items-start gap-3">
        <div className="p-2.5 bg-blue-500/20 text-blue-400 rounded-xl mt-0.5">
          <Bluetooth className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-bold text-white text-base">وحدة البلوتوث (Bluetooth HID Device Profile)</h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            استخدام واجهة <code className="text-blue-400 font-mono">BluetoothHidDevice</code> الرسمية المتاحة في Android 9+ لتحويل هاتف الأندرويد نفسه إلى ريموت وماوس ولوحة مفاتيح HID يتعرف عليها التلفاز مباشرة دون الحاجة لأي تطبيق على الشاشة.
          </p>
        </div>
      </div>

      {/* Permissions Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <h4 className="font-bold text-white text-xs mb-3 flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>إدارة أذونات البلوتوث في أندرويد 12+ (API 31+)</span>
          </h4>
          <div className="space-y-2 text-xs">
            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <span className="font-mono text-cyan-400">BLUETOOTH_CONNECT</span>
              <span className="text-[11px] text-slate-400">الاتصال بأجهزة التلفاز المقترنة</span>
            </div>
            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <span className="font-mono text-cyan-400">BLUETOOTH_SCAN</span>
              <span className="text-[11px] text-slate-400">مسح أجهزة الشاشات القريبة (BLE)</span>
            </div>
            <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
              <span className="font-mono text-cyan-400">BLUETOOTH_ADVERTISE</span>
              <span className="text-[11px] text-slate-400">إعلان الهاتف كجهاز ريموت HID</span>
            </div>
          </div>
        </div>

        {/* HID Report Descriptor */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <h4 className="font-bold text-white text-xs mb-3 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-400" />
            <span>تقرير تعريف الـ HID (Report Descriptor)</span>
          </h4>
          <p className="text-[11px] text-slate-400 mb-2">
            Usage Page: <span className="font-mono text-cyan-300">Consumer Control (0x0C)</span>، Report ID: <span className="font-mono text-cyan-300">0x01</span> (16-bit Usage Code)
          </p>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400 leading-relaxed">
            0x05, 0x0C, // Usage Page (Consumer)<br/>
            0x09, 0x01, // Usage (Consumer Control)<br/>
            0xA1, 0x01, // Collection (Application)<br/>
            0x85, 0x01, //   Report ID (1)<br/>
            0x19, 0x00, 0x2A, 0xFF, 0x03, // Usages 0..1023<br/>
            0x75, 0x10, 0x95, 0x01, 0x81, 0x00, // 16-bit Input<br/>
            0xC0        // End Collection
          </div>
        </div>
      </div>

      {/* Interactive Key Simulation */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h4 className="font-bold text-white text-sm mb-3">تجربة بث حزم تقارير البلوتوث (HID Reports Stream)</h4>
        <div className="flex flex-wrap gap-2 mb-4">
          {Object.keys(hidMap).map((k) => (
            <button
              key={k}
              onClick={() => sendHidKey(k as RemoteKey)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                selectedKey === k
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
            >
              {k}
            </button>
          ))}
        </div>

        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <div>
            <span className="text-[11px] text-slate-500 block">الزر المحدد:</span>
            <span className="text-xs font-bold text-white">{currentInfo.name}</span>
          </div>
          <div>
            <span className="text-[11px] text-slate-500 block">رمز الاستخدام (Usage ID):</span>
            <span className="text-xs font-mono font-bold text-blue-400">{currentInfo.hex}</span>
          </div>
          <div>
            <span className="text-[11px] text-slate-500 block">حزمة التقرير (Bytes):</span>
            <span className="text-xs font-mono font-bold text-emerald-400">
              [0x{(currentInfo.usage & 0xff).toString(16).toUpperCase().padStart(2, '0')}, 0x{((currentInfo.usage >> 8) & 0xff).toString(16).toUpperCase().padStart(2, '0')}]
            </span>
          </div>
        </div>

        {/* Log */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 space-y-1 max-h-40 overflow-y-auto">
          {reportLog.map((log, i) => (
            <div key={i} className="text-blue-300/90">{log}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
