import { EyeOff } from "lucide-react";
import type { LiveEvent, Person, Role } from "@/lib/live/model";
import { formatCount } from "@/lib/live/model";

const ROLE_LABEL: Record<Role, string | null> = {
  mod: "Mod",
  sub: "Sub",
  fan: "Fan",
  viewer: null,
};

export function initials(nick: string) {
  const parts = nick.trim().split(/\s+/).slice(0, 2);
  const text = parts.map((part) => part[0] ?? "").join("");
  return (text || "?").toUpperCase();
}

export function Avatar({ person, size = "md" }: { person: Person; size?: "sm" | "md" | "lg" }) {
  const box = size === "lg" ? "h-14 w-14 text-lg" : size === "sm" ? "h-8 w-8 text-xs" : "h-10 w-10 text-sm";
  if (person.avatar) {
    return (
      <img
        src={person.avatar}
        alt=""
        referrerPolicy="no-referrer"
        className={`${box} shrink-0 rounded-full object-cover`}
      />
    );
  }
  const tone =
    person.role === "mod" ? "bg-signal text-bg" : person.role === "sub" ? "bg-hot text-bg" : "bg-raised text-fg";
  return (
    <span className={`${box} ${tone} inline-flex shrink-0 items-center justify-center rounded-full font-semibold`}>
      {initials(person.nick)}
    </span>
  );
}

export function RoleBadge({ role }: { role: Role }) {
  const label = ROLE_LABEL[role];
  if (!label) return null;
  const tone = role === "mod" ? "border-signal text-signal" : role === "sub" ? "border-hot text-hot" : "border-line text-muted";
  return <span className={`rounded-full border px-1.5 py-0.5 text-xs font-semibold ${tone}`}>{label}</span>;
}

export function ChatLine({
  event,
  onHide,
  scale = "md",
  place,
}: {
  event: LiveEvent;
  onHide?: (name: string) => void;
  scale?: "sm" | "md" | "lg";
  place?: string;
}) {
  if (!("user" in event)) return null;
  const textSize = scale === "sm" ? "text-sm" : scale === "lg" ? "text-xl" : "text-base";
  const accent =
    event.kind === "gift"
      ? "border-hot"
      : event.kind === "follow"
        ? "border-signal"
        : event.kind === "chat" && event.text.startsWith("!")
          ? "border-signal"
          : "border-transparent";
  let body = "";
  if (event.kind === "chat") body = event.text;
  else if (event.kind === "gift") body = `envió ${event.gift}${event.repeat > 1 ? ` ×${event.repeat}` : ""}`;
  else if (event.kind === "follow") body = "empezó a seguir";
  else if (event.kind === "share") body = "compartió el live";
  else if (event.kind === "join") body = "entró al live";
  else if (event.kind === "like") body = `envió ${formatCount(event.count)} likes`;
  else return null;

  return (
    <article className={`onda-rise group flex gap-3 border-l-2 ${accent} py-2 pl-3`}>
      <Avatar person={event.user} size={scale === "lg" ? "md" : "sm"} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className={`truncate font-semibold ${event.kind === "gift" ? "text-hot" : "text-fg"}`}>
            {event.user.nick}
          </span>
          <RoleBadge role={event.user.role} />
          {place ? <span className="shrink-0 text-xs text-muted">{place}</span> : null}
          <span className="truncate text-xs text-muted">@{event.user.name}</span>
          {onHide ? (
            <button
              type="button"
              onClick={() => onHide(event.user.name)}
              className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-md text-muted opacity-100 hover:bg-raised hover:text-fg lg:opacity-0 lg:group-hover:opacity-100"
              aria-label={`Ocultar a ${event.user.nick}`}
            >
              <EyeOff className="h-4 w-4" />
            </button>
          ) : null}
        </div>
        <p className={`${textSize} break-words text-pretty text-fg`}>{body}</p>
        {event.kind === "gift" ? (
          <p className="text-sm tabular-nums text-muted">{formatCount(event.diamonds * event.repeat)} monedas</p>
        ) : null}
      </div>
    </article>
  );
}

export function GoalMeter({
  label,
  value,
  goal,
  large = false,
}: {
  label: string;
  value: number;
  goal: number;
  large?: boolean;
}) {
  const safe = Math.max(1, goal);
  const pct = Math.max(0, Math.min(100, Math.round((value / safe) * 100)));
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <span className={large ? "font-display text-2xl text-fg" : "text-sm text-muted"}>{label}</span>
        <span className={`tabular-nums ${large ? "text-lg text-fg" : "text-sm text-fg"}`}>
          {formatCount(value)}
          <span className="text-muted"> / {formatCount(goal)}</span>
        </span>
      </div>
      <div className={`mt-2 overflow-hidden rounded-full bg-raised ${large ? "h-3" : "h-2"}`}>
        <div className="h-full rounded-full bg-signal" style={{ width: `${pct}%` }} />
      </div>
      {pct >= 100 ? <p className="mt-2 text-sm font-semibold text-signal">Meta cumplida</p> : null}
    </div>
  );
}

export function ToggleRow({
  on,
  label,
  onClick,
}: {
  on: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className="flex h-11 w-full items-center justify-between gap-3 rounded-md border border-line bg-bg px-3 text-left text-sm text-fg"
    >
      <span>{label}</span>
      <span className={`flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 ${on ? "bg-signal" : "bg-raised"}`}>
        <span className={`h-5 w-5 rounded-full ${on ? "translate-x-5 bg-bg" : "bg-muted"}`} />
      </span>
    </button>
  );
}
