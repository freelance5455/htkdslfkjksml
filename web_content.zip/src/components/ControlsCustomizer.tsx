import React, { useState, useRef } from 'react';
import { CustomControlsSettings, ControlButtonConfig } from '../types';
import {
  DEFAULT_CONTROLS_SETTINGS,
  LEFT_HANDED_CONTROLS_SETTINGS,
} from '../game/constants';
import {
  X,
  RotateCcw,
  Check,
  Move,
  Sliders,
  Crosshair,
  Shield,
  Zap,
  Flame,
  Radio,
  RefreshCw,
  Hammer,
} from 'lucide-react';

interface ControlsCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CustomControlsSettings;
  onSaveSettings: (newSettings: CustomControlsSettings) => void;
}

export const ControlsCustomizer: React.FC<ControlsCustomizerProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}) => {
  const [currentConfig, setCurrentConfig] = useState<CustomControlsSettings>(settings);
  const [selectedBtnKey, setSelectedBtnKey] = useState<string>('fire');
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);

  if (!isOpen) return null;

  const buttons = currentConfig.buttons;
  const selectedBtn = buttons[selectedBtnKey as keyof typeof buttons];

  const handlePointerDown = (key: string, e: React.PointerEvent) => {
    e.stopPropagation();
    setSelectedBtnKey(key);
    isDraggingRef.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (key: string, e: React.PointerEvent) => {
    if (!isDraggingRef.current || selectedBtnKey !== key || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    // Convert to percentage
    let xPct = Math.round((clientX / rect.width) * 100);
    let yPct = Math.round((clientY / rect.height) * 100);

    // Clamp within screen boundaries
    xPct = Math.max(5, Math.min(95, xPct));
    yPct = Math.max(10, Math.min(90, yPct));

    setCurrentConfig((prev) => ({
      ...prev,
      buttons: {
        ...prev.buttons,
        [key]: {
          ...prev.buttons[key as keyof typeof prev.buttons],
          xPercent: xPct,
          yPercent: yPct,
        },
      },
    }));
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDraggingRef.current = false;
  };

  const handleSizeChange = (newSize: number) => {
    if (!selectedBtnKey) return;
    setCurrentConfig((prev) => ({
      ...prev,
      buttons: {
        ...prev.buttons,
        [selectedBtnKey]: {
          ...prev.buttons[selectedBtnKey as keyof typeof prev.buttons],
          size: newSize,
        },
      },
    }));
  };

  const handleOpacityChange = (newOpacity: number) => {
    if (!selectedBtnKey) return;
    setCurrentConfig((prev) => ({
      ...prev,
      buttons: {
        ...prev.buttons,
        [selectedBtnKey]: {
          ...prev.buttons[selectedBtnKey as keyof typeof prev.buttons],
          opacity: newOpacity,
        },
      },
    }));
  };

  const handleApplyPreset = (type: 'default' | 'leftHanded' | 'large') => {
    if (type === 'default') {
      setCurrentConfig(JSON.parse(JSON.stringify(DEFAULT_CONTROLS_SETTINGS)));
    } else if (type === 'leftHanded') {
      setCurrentConfig(JSON.parse(JSON.stringify(LEFT_HANDED_CONTROLS_SETTINGS)));
    } else if (type === 'large') {
      const cloned = JSON.parse(JSON.stringify(DEFAULT_CONTROLS_SETTINGS)) as CustomControlsSettings;
      Object.keys(cloned.buttons).forEach((k) => {
        const btn = cloned.buttons[k as keyof typeof cloned.buttons];
        btn.size = Math.round(btn.size * 1.25);
      });
      setCurrentConfig(cloned);
    }
  };

  const handleSave = () => {
    onSaveSettings(currentConfig);
    onClose();
  };

  const renderIcon = (key: string) => {
    switch (key) {
      case 'joystick':
        return <Move className="w-7 h-7 text-white" />;
      case 'fire':
        return <Crosshair className="w-8 h-8 text-red-300" />;
      case 'reload':
        return <RefreshCw className="w-6 h-6 text-amber-300" />;
      case 'repair':
        return <Hammer className="w-6 h-6 text-blue-300" />;
      case 'switchWeapon':
        return <Radio className="w-6 h-6 text-cyan-300" />;
      case 'grenade':
        return <Flame className="w-6 h-6 text-emerald-300" />;
      case 'dash':
        return <Zap className="w-6 h-6 text-sky-300" />;
      case 'placeTurret':
        return <Shield className="w-6 h-6 text-purple-300" />;
      default:
        return <Crosshair className="w-6 h-6 text-white" />;
    }
  };

  return (
    <div
      id="controls-customizer-modal"
      className="fixed inset-0 z-50 flex flex-col bg-zinc-950 select-none overflow-hidden"
    >
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-6 py-2.5 bg-zinc-900 border-b border-zinc-800 z-20">
        <div className="flex items-center gap-3">
          <Sliders className="w-5 h-5 text-red-500" />
          <div>
            <h2 className="text-base font-bold font-display uppercase tracking-wider text-zinc-100">
              Tugmalarni Moslashtirish Paneli (HUD Editor)
            </h2>
            <p className="text-[11px] text-zinc-400">
              Tugmalarni ekranning istalgan joyiga suring, oʻlchami va shaffofligini oʻzgartiring
            </p>
          </div>
        </div>

        {/* Quick actions */}
        <div className="flex items-center gap-2">
          <button
            id="preset-default-btn"
            onClick={() => handleApplyPreset('default')}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition"
          >
            Standart
          </button>
          <button
            id="preset-left-btn"
            onClick={() => handleApplyPreset('leftHanded')}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition"
          >
            Chap Qoʻl
          </button>
          <button
            id="preset-large-btn"
            onClick={() => handleApplyPreset('large')}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition"
          >
            Katta Tugmalar
          </button>

          <button
            id="save-controls-btn"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-red-950/50 transition active:scale-95"
          >
            <Check className="w-4 h-4" />
            Saqlash
          </button>

          <button
            id="close-controls-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition ml-2"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Interactive Screen Area */}
      <div
        ref={containerRef}
        className="relative flex-1 w-full h-full bg-zinc-950/90 overflow-hidden cursor-crosshair border-b border-zinc-800"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, #1e293b 1px, transparent 1px), linear-gradient(to right, #18181b 1px, transparent 1px), linear-gradient(to bottom, #18181b 1px, transparent 1px)',
          backgroundSize: '30px 30px',
        }}
      >
        {/* Center Base Guideline */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center opacity-30">
          <div className="w-32 h-32 rounded-full border-2 border-dashed border-sky-400 flex items-center justify-center">
            <Shield className="w-8 h-8 text-sky-400" />
          </div>
          <span className="text-[11px] font-bold text-sky-300 uppercase mt-1 tracking-wider">
            Oʻyin Markazi (Baza)
          </span>
        </div>

        {/* Render Draggable Controls */}
        {(Object.entries(currentConfig.buttons) as [string, ControlButtonConfig][]).map(([key, btn]) => {
          const isSelected = selectedBtnKey === key;
          return (
            <div
              key={key}
              id={`editor-btn-${key}`}
              onPointerDown={(e) => handlePointerDown(key, e)}
              onPointerMove={(e) => handlePointerMove(key, e)}
              onPointerUp={handlePointerUp}
              style={{
                left: `${btn.xPercent}%`,
                top: `${btn.yPercent}%`,
                width: `${btn.size}px`,
                height: `${btn.size}px`,
                opacity: btn.opacity,
                transform: 'translate(-50%, -50%)',
              }}
              className={`absolute flex flex-col items-center justify-center rounded-full select-none cursor-move transition-shadow ${
                isSelected
                  ? 'border-2 border-yellow-400 bg-red-600/60 shadow-lg shadow-yellow-500/30 scale-105'
                  : 'border-2 border-zinc-500/60 bg-zinc-900/70 hover:border-zinc-400'
              }`}
            >
              {renderIcon(key)}
              <span className="text-[9px] font-bold text-zinc-200 mt-0.5 max-w-[80px] text-center truncate pointer-events-none px-1">
                {btn.nameUz}
              </span>

              {isSelected && (
                <div className="absolute -top-6 text-[10px] font-bold text-yellow-400 uppercase bg-zinc-950/80 px-2 py-0.5 rounded border border-yellow-400/50 whitespace-nowrap">
                  {btn.nameUz}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Inspector for the currently selected button */}
      {selectedBtn && (
        <div className="h-20 bg-zinc-900 px-6 py-2 flex items-center justify-between border-t border-zinc-800 z-20">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30">
              {renderIcon(selectedBtnKey)}
            </div>
            <div>
              <div className="text-sm font-bold text-zinc-100 uppercase tracking-wide">
                {selectedBtn.nameUz}
              </div>
              <div className="text-[11px] text-zinc-400">
                Koordinata: {selectedBtn.xPercent}% X, {selectedBtn.yPercent}% Y
              </div>
            </div>
          </div>

          {/* Size Slider */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-zinc-400">Oʻlchami:</span>
            <input
              id="button-size-slider"
              type="range"
              min={45}
              max={130}
              value={selectedBtn.size}
              onChange={(e) => handleSizeChange(Number(e.target.value))}
              className="w-32 accent-red-500"
            />
            <span className="text-xs font-mono text-zinc-300 w-8">{selectedBtn.size}px</span>
          </div>

          {/* Opacity Slider */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-zinc-400">Shaffoflik:</span>
            <input
              id="button-opacity-slider"
              type="range"
              min={30}
              max={100}
              value={Math.round(selectedBtn.opacity * 100)}
              onChange={(e) => handleOpacityChange(Number(e.target.value) / 100)}
              className="w-32 accent-red-500"
            />
            <span className="text-xs font-mono text-zinc-300 w-8">
              {Math.round(selectedBtn.opacity * 100)}%
            </span>
          </div>

          {/* Reset button position */}
          <button
            id="reset-single-btn"
            onClick={() => {
              const def = DEFAULT_CONTROLS_SETTINGS.buttons[selectedBtnKey as keyof typeof DEFAULT_CONTROLS_SETTINGS.buttons];
              if (def) {
                setCurrentConfig((prev) => ({
                  ...prev,
                  buttons: {
                    ...prev.buttons,
                    [selectedBtnKey]: { ...def },
                  },
                }));
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-zinc-400 hover:text-white rounded-lg bg-zinc-800 hover:bg-zinc-700 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Tugmani Tiklash
          </button>
        </div>
      )}
    </div>
  );
};
