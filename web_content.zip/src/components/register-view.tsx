import { useEffect, useRef, useState } from "react";
import { bitsFrom, formatDec, formatHex, shr2, windowRemain } from "@/lib/rax";
import { Eyebrow, Panel } from "@/components/desk";

const LANE = 12;
const CELL = 16;
const GAP = 3;
const LANE_WIDTH = LANE * CELL + (LANE - 1) * GAP;
const STEP = 2 * (CELL + GAP);

const FAMILY = [
  { name: "RAX", bits: 64, note: "Full accumulator. On Linux, functions return in it." },
  { name: "EAX", bits: 32, note: "Low 32. Today's Unix second still fits here." },
  { name: "AX", bits: 16, note: "Low 16 of EAX." },
  { name: "AH", bits: 8, note: "High byte of AX. Not the low byte." },
  { name: "AL", bits: 8, note: "Low byte of AX." },
];

function BitCell({
  bit,
  drop,
}: {
  bit: number;
  drop?: boolean;
}) {
  const tone = drop
    ? "border-brass text-brass"
    : bit
      ? "border-line text-fg"
      : "border-line text-muted";
  return (
    <span
      aria-hidden="true"
      className={`flex h-7 w-4 shrink-0 items-center justify-center border bg-bg font-mono text-xs tabular-nums ${tone}`}
    >
      {bit}
    </span>
  );
}

export function RegisterView({ now }: { now: number | null }) {
  const [working, setWorking] = useState<number | null>(null);
  const [follow, setFollow] = useState(true);
  const [sliding, setSliding] = useState(false);
  const [motion, setMotion] = useState(true);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (now !== null && follow) setWorking(now);
  }, [now, follow]);

  useEffect(() => {
    return () => {
      if (timer.current !== null) window.clearTimeout(timer.current);
    };
  }, []);

  function shift() {
    if (working === null || sliding) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setFollow(false);
    if (reduce) {
      setWorking(shr2(working));
      return;
    }
    setMotion(true);
    setSliding(true);
    timer.current = window.setTimeout(() => {
      setMotion(false);
      setWorking((value) => (value === null ? value : shr2(value)));
      setSliding(false);
      requestAnimationFrame(() => setMotion(true));
    }, 520);
  }

  function followClock() {
    if (timer.current !== null) window.clearTimeout(timer.current);
    setSliding(false);
    setFollow(true);
    if (now !== null) setWorking(now);
  }

  const bits = working === null ? bitsFrom(0, 32) : bitsFrom(working, 32);
  const laneBits = bits.slice(32 - LANE);
  const shifted = working === null ? null : shr2(working);
  const remain = now === null ? null : windowRemain(now);

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="flex flex-col gap-6 lg:col-span-3">
        <Panel>
          <div className="flex items-end justify-between gap-4">
            <Eyebrow>RAX · low 32</Eyebrow>
            <p className="font-mono text-xs text-muted tabular-nums">
              {follow ? "following clock" : "latched"}
            </p>
          </div>
          <p className="mt-3 font-mono text-3xl text-fg tabular-nums">
            {working === null ? "—" : formatDec(working)}
          </p>
          <p className="mt-1 font-mono text-sm text-muted tabular-nums">
            {working === null ? "—" : formatHex(working)}
          </p>

          <div className="mt-5 flex flex-col gap-1">
            {[0, 1, 2, 3].map((row) => {
              const start = row * 8;
              const high = 31 - start;
              const low = high - 7;
              return (
                <div key={row} className="flex items-center gap-3">
                  <span className="w-12 shrink-0 font-mono text-xs text-muted tabular-nums">
                    {high}–{low}
                  </span>
                  <div className="grid flex-1 grid-cols-8 gap-1">
                    {bits.slice(start, start + 8).map((bit, index) => {
                      const abs = start + index;
                      const drop = abs >= 30;
                      return (
                        <span
                          key={abs}
                          aria-hidden="true"
                          className={`flex h-9 items-center justify-center border font-mono text-sm tabular-nums ${
                            drop
                              ? "border-brass bg-bg text-brass"
                              : bit
                                ? "border-line bg-surface-2 text-fg"
                                : "border-line bg-bg text-muted"
                          }`}
                        >
                          {bit}
                        </span>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
          <p className="mt-3 text-sm text-muted">
            Brass cells are the two bits <span className="font-mono text-fg">shr</span> throws away.
            Losing them is what divides by four.
          </p>

          <div className="mt-5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={shift}
              disabled={working === null || sliding}
              className="inline-flex min-h-11 items-center bg-brass px-4 font-medium text-bg disabled:opacity-40"
            >
              shr rax, 2
            </button>
            <button
              type="button"
              onClick={followClock}
              className="inline-flex min-h-11 items-center border border-line bg-bg px-4 text-fg"
            >
              Follow clock
            </button>
          </div>
        </Panel>

        <Panel>
          <Eyebrow>Shifter · low 16</Eyebrow>
          <p className="mt-2 text-sm text-muted">
            Zeros enter from the left. The two low bits walk off the right.
          </p>
          <div className="mt-4 overflow-hidden" style={{ width: LANE_WIDTH }}>
            <div
              className={motion ? "flex transition-transform duration-500 ease-out" : "flex"}
              style={{
                gap: GAP,
                transform: `translateX(${sliding ? 0 : -STEP}px)`,
              }}
            >
              {[0, 0, ...laneBits].map((bit, index) => (
                <BitCell
                  key={`${working}-${index}`}
                  bit={bit}
                  drop={sliding && index >= laneBits.length}
                />
              ))}
            </div>
          </div>
          <dl className="mt-5 grid grid-cols-2 gap-4">
            <div>
              <dt className="text-sm text-muted">After one shift</dt>
              <dd className="font-mono text-lg text-fg tabular-nums">
                {shifted === null ? "—" : formatDec(shifted)}
              </dd>
            </div>
            <div>
              <dt className="text-sm text-muted">File</dt>
              <dd className="truncate font-mono text-lg text-fg">
                {shifted === null ? "—" : `${shifted}.json`}
              </dd>
            </div>
          </dl>
          <p className="mt-3 font-mono text-xs text-muted tabular-nums">
            {remain === null ? "—" : `Live id holds for ${remain}s`}
          </p>
        </Panel>
      </div>

      <aside className="flex flex-col gap-6 lg:col-span-2">
        <Panel>
          <Eyebrow>The register</Eyebrow>
          <h2 className="mt-2 text-xl font-semibold text-fg">RAX is the 64-bit accumulator.</h2>
          <p className="mt-3 text-sm text-muted">
            On x86-64 it is the wide form of the old AX register. EAX is its low 32 bits, AX the
            low 16, and AH / AL the two bytes of AX. Arithmetic, shifts, and — on Linux — function
            results all land here.
          </p>
          <ul className="mt-4 flex flex-col gap-3">
            {FAMILY.map((row) => (
              <li key={row.name}>
                <div className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-sm text-fg">{row.name}</span>
                  <span className="font-mono text-xs text-muted tabular-nums">{row.bits} bit</span>
                </div>
                <div className="mt-1 flex h-2 border border-line">
                  <span className="h-full bg-brass" style={{ width: `${(row.bits / 64) * 100}%` }} />
                </div>
                <p className="mt-1 text-xs text-muted">{row.note}</p>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel>
          <Eyebrow>shr rax, 2</Eyebrow>
          <pre className="mt-3 overflow-x-auto font-mono text-sm leading-6 text-fg">{`mov  timestamp, rax
shr  $2, rax
mov  rax, message_id`}</pre>
          <p className="mt-3 text-sm text-muted">
            A logical right shift by two drops the low pair and fills the top with zeros. For an
            unsigned value that is divide by four. 100 (binary 1100100) becomes 25 (binary 11001).
          </p>
          <p className="mt-3 text-sm text-muted">
            The inbox names each file with the Unix second shifted once. The desk does that divide
            directly, which is the same number the instruction prints.
          </p>
        </Panel>
      </aside>
    </div>
  );
}
