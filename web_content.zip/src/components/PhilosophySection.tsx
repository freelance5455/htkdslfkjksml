import React from "react";
import { ArrowRight, Leaf, HeartHandshake, ShieldCheck } from "lucide-react";
import { FloatingFoodFrame } from "./FloatingFoodFrame";
import { FloatingFrame } from "../types";

interface PhilosophySectionProps {
  onLearnMore?: () => void;
}

const PHILOSOPHY_FRAME: FloatingFrame = {
  id: "phil-frame-paneer",
  title: "Malabar Spices",
  alt: "Charred paneer steak with fresh herbs and cold-pressed oil",
  imageUrl: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=600&q=80",
  rotation: -1.8,
  motionType: "scale",
  duration: 11,
  delay: 0.4,
};

export const PhilosophySection: React.FC<PhilosophySectionProps> = ({ onLearnMore }) => {
  return (
    <section id="philosophy" className="py-24 sm:py-32 px-6 bg-[#FDFBF7] border-t border-b border-[#D8D0C2]/70 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Label */}
        <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82] mb-4">
          THE KAL O R E E Z IDEA
        </div>

        {/* 12-Column Asymmetric Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Headline Column */}
          <div className="lg:col-span-6 space-y-6">
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#17201C] leading-[1.05] tracking-tight">
              WHOLESOME,
              <br />
              <span className="italic font-light">WITHOUT THE PRETENCE.</span>
            </h2>

            <p className="text-base sm:text-lg text-[#17201C]/80 font-sans leading-relaxed">
              We believe eating well doesn&apos;t have to mean eating without pleasure.
            </p>

            <p className="text-sm sm:text-base text-[#17201C]/70 font-sans leading-relaxed">
              Kaloreez brings together fresh ingredients, familiar flavours and thoughtful preparation — creating food that feels balanced, satisfying and easy to return to.
            </p>

            {/* Core Pillars */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-6 border-t border-[#D8D0C2]/60">
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-[#17201C]">
                  <Leaf className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>Cold Oils</span>
                </div>
                <p className="text-xs text-[#17201C]/65 font-sans leading-normal">
                  Unrefined sesame, olive, and organic clarified butter.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-[#17201C]">
                  <HeartHandshake className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>Real Food</span>
                </div>
                <p className="text-xs text-[#17201C]/65 font-sans leading-normal">
                  Satisfying meals for daily dining, not austere diet rations.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-[#17201C]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>Transparent</span>
                </div>
                <p className="text-xs text-[#17201C]/65 font-sans leading-normal">
                  Honest calorie and macro listings where verified.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={onLearnMore}
                className="group inline-flex items-center gap-2 text-xs font-semibold tracking-[0.2em] uppercase text-[#17201C] hover:text-[#9BAF82] transition-colors cursor-pointer"
              >
                <span>OUR PHILOSOPHY</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Editorial Image & Floating Card */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] w-full bg-[#EAE4D7] rounded-sm overflow-hidden paper-frame border border-[#D8D0C2]">
              <img
                src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=1200&q=85"
                alt="Chefs preparing fresh wholesome ingredients in Kaloreez kitchen"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-4 left-5 text-white/90 font-serif italic text-sm">
                Thoughtful kitchen preparation · Visakhapatnam
              </div>
            </div>

            {/* Overlapping Floating Frame */}
            <div className="absolute -bottom-8 -left-6 sm:-left-10 z-10 w-40 sm:w-48 hidden sm:block">
              <FloatingFoodFrame frame={PHILOSOPHY_FRAME} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
