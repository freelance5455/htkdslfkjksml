import React, { useState } from 'react';
import { SaleTransaction, StoreSettings } from '../types';
import { 
  Receipt, 
  Search, 
  Download, 
  Calendar, 
  Eye, 
  RotateCcw, 
  TrendingUp, 
  DollarSign,
  Filter
} from 'lucide-react';

interface SalesHistoryViewProps {
  sales: SaleTransaction[];
  settings: StoreSettings;
  onOpenReceipt: (sale: SaleTransaction) => void;
  onRefund: (saleId: string) => void;
}

export const SalesHistoryView: React.FC<SalesHistoryViewProps> = ({
  sales,
  settings,
  onOpenReceipt,
  onRefund
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'today' | 'week' | 'month' | 'all'>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filter sales
  const filteredSales = sales.filter(s => {
    // Search
    const matchesSearch = 
      s.receiptNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.items.some(i => i.name.toLowerCase().includes(searchQuery.toLowerCase()) || i.code.toLowerCase().includes(searchQuery.toLowerCase()));

    // Payment method
    const matchesPayment = paymentFilter === 'all' || s.paymentMethod === paymentFilter;

    // Status
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;

    // Date
    const saleDate = new Date(s.timestamp);
    const now = new Date();
    let matchesDate = true;
    if (dateFilter === 'today') {
      matchesDate = saleDate.toDateString() === now.toDateString();
    } else if (dateFilter === 'week') {
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesDate = saleDate >= sevenDaysAgo;
    } else if (dateFilter === 'month') {
      matchesDate = saleDate.getMonth() === now.getMonth() && saleDate.getFullYear() === now.getFullYear();
    }

    return matchesSearch && matchesPayment && matchesStatus && matchesDate;
  });

  // Calculate totals from filtered
  const activeCompleted = filteredSales.filter(s => s.status === 'completed');
  const totalGross = activeCompleted.reduce((acc, s) => acc + s.total, 0);
  const totalRefunded = filteredSales.filter(s => s.status === 'refunded').reduce((acc, s) => acc + s.total, 0);

  // Export Sales Report to CSV
  const handleExportCSV = () => {
    const headers = ['ReceiptNumber', 'Timestamp', 'ItemsCount', 'Subtotal', 'Discount', 'Tax', 'Total', 'PaymentMethod', 'Status'];
    const rows = filteredSales.map(s => [
      `"${s.receiptNumber}"`,
      `"${s.timestamp}"`,
      s.items.reduce((acc, i) => acc + i.quantity, 0),
      s.subtotal,
      s.discount,
      s.tax,
      s.total,
      `"${s.paymentMethod}"`,
      `"${s.status}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sales-report-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Stats Banner */}
      <div className="glass-card rounded-3xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Receipt className="w-5 h-5 text-cyan-400" />
              <h2 className="text-xl font-black text-slate-100">Sales Register & Transactions</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Historical transactions, electronic receipts, refunds, and revenue reporting
            </p>
          </div>

          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export Sales CSV
          </button>
        </div>

        {/* Summary metric cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-400 block font-medium">Filtered Gross Sales</span>
            <span className="text-xl font-black text-emerald-400 mt-0.5 block">
              {settings.currency}{totalGross.toFixed(2)}
            </span>
          </div>

          <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-400 block font-medium">Completed Transactions</span>
            <span className="text-xl font-black text-cyan-400 mt-0.5 block">
              {activeCompleted.length} receipts
            </span>
          </div>

          <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-400 block font-medium">Refunded Total</span>
            <span className="text-xl font-black text-rose-400 mt-0.5 block">
              {settings.currency}{totalRefunded.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Filter controls */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
          {/* Search */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by receipt # or product item..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Date range filter */}
          <div className="sm:col-span-3">
            <select
              value={dateFilter}
              onChange={e => setDateFilter(e.target.value as 'today' | 'week' | 'month' | 'all')}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="week">Past 7 Days</option>
              <option value="month">This Month</option>
            </select>
          </div>

          {/* Payment method */}
          <div className="sm:col-span-2">
            <select
              value={paymentFilter}
              onChange={e => setPaymentFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Payments</option>
              <option value="cash">Cash</option>
              <option value="card">Card</option>
              <option value="ewallet">E-Wallet</option>
            </select>
          </div>

          {/* Status */}
          <div className="sm:col-span-2">
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Status</option>
              <option value="completed">Completed</option>
              <option value="refunded">Refunded</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-3">
        {filteredSales.length === 0 ? (
          <div className="glass-card rounded-3xl p-12 text-center space-y-3 text-slate-500">
            <Receipt className="w-12 h-12 mx-auto text-slate-600" />
            <p className="text-sm font-semibold">No transactions found</p>
            <p className="text-xs text-slate-500">Try changing your filters or record a sale in Sale Terminal.</p>
          </div>
        ) : (
          filteredSales.slice().reverse().map(sale => {
            const isRefunded = sale.status === 'refunded';
            return (
              <div
                key={sale.id}
                className="glass-card rounded-2xl p-4 transition hover:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Transaction details */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-slate-100">
                      {sale.receiptNumber}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                      isRefunded
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {sale.status}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-400 uppercase">
                      {sale.paymentMethod}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400">
                    <span>{new Date(sale.timestamp).toLocaleString()}</span>
                    <span className="mx-2">•</span>
                    <span>{sale.items.reduce((a, b) => a + b.quantity, 0)} total units ({sale.items.length} line items)</span>
                  </div>

                  {/* Item preview pill list */}
                  <div className="flex flex-wrap gap-1 mt-1">
                    {sale.items.slice(0, 3).map((item, idx) => (
                      <span key={idx} className="text-[10px] bg-slate-900 border border-slate-800 text-slate-300 px-2 py-0.5 rounded-md">
                        {item.quantity}x {item.name}
                      </span>
                    ))}
                    {sale.items.length > 3 && (
                      <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-500 px-2 py-0.5 rounded-md">
                        +{sale.items.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Amount & Actions */}
                <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 border-slate-800 pt-3 md:pt-0">
                  <div className="text-left md:text-right">
                    <span className={`text-lg font-black font-mono block ${isRefunded ? 'line-through text-slate-500' : 'text-cyan-400'}`}>
                      {settings.currency}{sale.total.toFixed(2)}
                    </span>
                    {sale.discount > 0 && (
                      <span className="text-[10px] text-emerald-400 block">
                        Saved: {settings.currency}{sale.discount.toFixed(2)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenReceipt(sale)}
                      className="px-3 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Receipt
                    </button>

                    {!isRefunded && (
                      <button
                        onClick={() => {
                          if (confirm(`Refund receipt ${sale.receiptNumber}? This will restore product stock into inventory.`)) {
                            onRefund(sale.id);
                          }
                        }}
                        title="Void / Refund Sale & Restore Inventory"
                        className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl border border-transparent hover:border-rose-500/20 transition cursor-pointer"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
