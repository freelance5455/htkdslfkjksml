import React, { useMemo, useState } from 'react';
import { fmtQty } from '../categoryTemplates';
import type { Sale, SaleItem, StoreData } from '../types';
import { fmtDateTime, fmtMoney, toDateKey } from '../utils';
import { Icon } from './Icon';
import { ConfirmModal, CustomDatePicker, CustomSelect, Modal } from './SharedUI';

const roundQty = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);

interface SalesHistoryViewProps {
  data: StoreData;
  t: Record<string, string>;
  onViewReceipt: (sale: Sale) => void;
  onEditSale: (oldSale: Sale, updatedSale: Sale) => void;
  onDeleteSale: (saleId: string) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

interface EditSaleForm {
  customerId: string;
  paymentMethod: string;
  discount: string;
  paidAmount: string;
  items: SaleItem[];
}

export const SalesHistoryView: React.FC<SalesHistoryViewProps> = ({
  data,
  t,
  onViewReceipt,
  onEditSale,
  onDeleteSale,
  notify,
}) => {
  const [deleteTarget, setDeleteTarget] = useState<Sale | null>(null);
  const [editTarget, setEditTarget] = useState<Sale | null>(null);
  const [editForm, setEditForm] = useState<EditSaleForm | null>(null);
  const [addProdId, setAddProdId] = useState('');

  const [search, setSearch] = useState('');
  const [payFilter, setPayFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const custMap = useMemo(() => Object.fromEntries(data.customers.map((c) => [c.id, c])), [data.customers]);

  const filteredSales = useMemo(() => {
    const q = search.trim().toLowerCase();
    return data.sales.filter((s) => {
      if (payFilter !== 'all' && s.paymentMethod !== payFilter) return false;
      if (statusFilter === 'paid' && s.dueAmount > 0) return false;
      if (statusFilter === 'due' && s.dueAmount <= 0) return false;
      const dk = toDateKey(s.date);
      if (fromDate && dk < fromDate) return false;
      if (toDate && dk > toDate) return false;
      if (q) {
        const custPhone = custMap[s.customerId]?.phone || '';
        const matchesText =
          (s.invoiceNo || '').toLowerCase().includes(q) ||
          (s.customerName || '').toLowerCase().includes(q) ||
          custPhone.toLowerCase().includes(q) ||
          s.items.some((it) => it.name.toLowerCase().includes(q));
        if (!matchesText) return false;
      }
      return true;
    });
  }, [data.sales, search, payFilter, statusFilter, fromDate, toDate, custMap]);

  const openEditModal = (sale: Sale) => {
    setEditTarget(sale);
    setEditForm({
      customerId: sale.customerId,
      paymentMethod: sale.paymentMethod,
      discount: String(sale.discount || 0),
      paidAmount: String(sale.paidAmount || 0),
      items: sale.items.map((i) => ({ ...i })),
    });
    setAddProdId(data.products[0]?.id || '');
  };

  const maxAllowedForItem = (productId: string) => {
    const inv = data.products.find((p) => p.id === productId)?.quantity || 0;
    const oldInSale = editTarget?.items.find((i) => i.productId === productId)?.qty || 0;
    return inv + oldInSale;
  };

  const updateEditItemQty = (productId: string, nextQty: number) => {
    const cleanQty = roundQty(nextQty);
    if (cleanQty <= 0) {
      setEditForm((prev) => (prev ? { ...prev, items: prev.items.filter((i) => i.productId !== productId) } : null));
      return;
    }
    const max = maxAllowedForItem(productId);
    if (cleanQty > max + 0.0001) {
      notify(t.cannotExceedStock, 'error');
      return;
    }
    setEditForm((prev) =>
      prev ? { ...prev, items: prev.items.map((i) => (i.productId === productId ? { ...i, qty: cleanQty } : i)) } : null
    );
  };

  const addProductToEdit = () => {
    const p = data.products.find((pr) => pr.id === addProdId);
    if (!p || !editForm) return;
    const max = maxAllowedForItem(p.id);
    const existing = editForm.items.find((i) => i.productId === p.id);
    const nextQty = roundQty((existing ? existing.qty : 0) + 1);
    if (nextQty > max + 0.0001) {
      notify(t.cannotExceedStock, 'error');
      return;
    }
    if (existing) {
      updateEditItemQty(p.id, nextQty);
    } else {
      setEditForm((prev) =>
        prev
          ? {
              ...prev,
              items: [
                ...prev.items,
                {
                  productId: p.id,
                  name: p.name,
                  model: p.model || '',
                  unit: p.unit || 'pcs',
                  purchasePrice: p.purchasePrice,
                  sellingPrice: p.sellingPrice,
                  qty: 1,
                },
              ],
            }
          : null
      );
    }
  };

  const editTotals = useMemo(() => {
    if (!editForm) return { subtotal: 0, discount: 0, grandTotal: 0, paid: 0, due: 0, change: 0, profit: 0 };
    const subtotal = editForm.items.reduce((s, i) => s + i.sellingPrice * i.qty, 0);
    const discount = Math.max(0, Math.min(subtotal, Number(editForm.discount || 0)));
    const grandTotal = Math.max(0, subtotal - discount);
    const rawPaid = Math.max(0, Number(editForm.paidAmount || 0));
    const due = Math.max(0, grandTotal - rawPaid);
    const change = Math.max(0, rawPaid - grandTotal);
    const cost = editForm.items.reduce((s, i) => s + i.purchasePrice * i.qty, 0);
    return { subtotal, discount, grandTotal, paid: Math.min(rawPaid, grandTotal), due, change, profit: grandTotal - cost };
  }, [editForm]);

  const handleSaveEditedSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm || !editTarget || editForm.items.length === 0) {
      notify(t.cartEmpty, 'error');
      return;
    }
    const cust = data.customers.find((c) => c.id === editForm.customerId) || data.customers[0];
    const updatedSale: Sale = {
      ...editTarget,
      customerId: cust.id,
      customerName: cust.name,
      paymentMethod: editForm.paymentMethod,
      items: editForm.items,
      subtotal: editTotals.subtotal,
      discount: editTotals.discount,
      grandTotal: editTotals.grandTotal,
      paidAmount: editTotals.paid,
      dueAmount: editTotals.due,
      changeReturn: editTotals.change,
      profit: editTotals.profit,
    };
    onEditSale(editTarget, updatedSale);
    setEditTarget(null);
    setEditForm(null);
  };

  const payFilterOptions = useMemo(
    () => [
      { value: 'all', label: `${t.paymentMethod}: ${t.all}` },
      ...['Cash', 'bKash', 'Nagad', 'Bank', 'Other'].map((m) => ({ value: m, label: t[m] || m })),
    ],
    [t]
  );

  const statusFilterOptions = useMemo(
    () => [
      { value: 'all', label: `${t.paymentStatus}: ${t.all}` },
      { value: 'paid', label: t.paidOnly },
      { value: 'due', label: t.dueOnly },
    ],
    [t]
  );

  const customerOptions = useMemo(() => data.customers.map((c) => ({ value: c.id, label: c.name })), [data.customers]);
  const paymentMethodOptions = useMemo(
    () => ['Cash', 'bKash', 'Nagad', 'Bank', 'Other'].map((m) => ({ value: m, label: t[m] || m })),
    [t]
  );
  const addProductOptions = useMemo(
    () =>
      data.products.map((p) => ({
        value: p.id,
        label: p.name,
        sublabel: `${fmtMoney(p.sellingPrice)} · ${t.inStock}: ${fmtQty(maxAllowedForItem(p.id), p.unit)}${p.barcode ? ` · ${p.barcode}` : ''}`,
      })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data.products, editTarget, t.inStock]
  );

  const filteredSummary = useMemo(() => {
    const total = filteredSales.reduce((s, x) => s + x.grandTotal, 0);
    const paid = filteredSales.reduce((s, x) => s + x.paidAmount, 0);
    const due = filteredSales.reduce((s, x) => s + x.dueAmount, 0);
    return { count: filteredSales.length, total, paid, due };
  }, [filteredSales]);

  return (
    <div className="space-y-4">
      <div className="surface-card p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="relative lg:col-span-2">
            <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.searchInvoices}
              className="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition min-h-[42px]"
            />
          </div>
          <CustomSelect value={payFilter} onChange={setPayFilter} options={payFilterOptions} />
          <CustomSelect value={statusFilter} onChange={setStatusFilter} options={statusFilterOptions} />
          <CustomDatePicker value={fromDate} onChange={setFromDate} placeholder={t.startDate} />
          <div className="flex gap-2">
            <CustomDatePicker value={toDate} onChange={setToDate} placeholder={t.endDate} className="flex-1" />
            {(search || payFilter !== 'all' || statusFilter !== 'all' || fromDate || toDate) && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setPayFilter('all');
                  setStatusFilter('all');
                  setFromDate('');
                  setToDate('');
                }}
                className="btn-secondary px-3 py-2 text-xs"
              >
                {t.resetFilters}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filtered Sales Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 tabular-nums">
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.totalOrders}</p>
          <p className="text-xl font-extrabold text-slate-900 mt-0.5">{filteredSummary.count}</p>
        </div>
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.totalSales}</p>
          <p className="text-xl font-extrabold text-blue-600 mt-0.5">{fmtMoney(filteredSummary.total)}</p>
        </div>
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.paid}</p>
          <p className="text-xl font-extrabold text-emerald-600 mt-0.5">{fmtMoney(filteredSummary.paid)}</p>
        </div>
        <div className="surface-card px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.due}</p>
          <p className={`text-xl font-extrabold mt-0.5 ${filteredSummary.due > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
            {fmtMoney(filteredSummary.due)}
          </p>
        </div>
      </div>

      <div className="surface-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left tabular-nums">
            <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 whitespace-nowrap">{t.invoiceNo}</th>
                <th className="px-4 py-3 whitespace-nowrap">{t.date}</th>
                <th className="px-4 py-3 whitespace-nowrap">{t.customer}</th>
                <th className="px-4 py-3 whitespace-nowrap">{t.paymentMethod}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.items}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.total}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.paid}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.due}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.profit}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-12 text-slate-400">
                    {t.noTransactionsYet}
                  </td>
                </tr>
              ) : (
                filteredSales.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-bold font-mono text-indigo-600 whitespace-nowrap">{s.invoiceNo}</td>
                    <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{fmtDateTime(s.date)}</td>
                    <td className="px-4 py-3 font-medium text-slate-800 whitespace-nowrap">{s.customerName}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{t[s.paymentMethod] || s.paymentMethod}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">{roundQty(s.items.reduce((a, b) => a + b.qty, 0))}</td>
                    <td className="px-4 py-3 text-right font-bold whitespace-nowrap">{fmtMoney(s.grandTotal)}</td>
                    <td className="px-4 py-3 text-right text-emerald-700 whitespace-nowrap">{fmtMoney(s.paidAmount)}</td>
                    <td className="px-4 py-3 text-right text-rose-600 font-semibold whitespace-nowrap">{s.dueAmount > 0 ? fmtMoney(s.dueAmount) : '-'}</td>
                    <td className="px-4 py-3 text-right text-emerald-600 font-semibold whitespace-nowrap">{fmtMoney(s.profit)}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="inline-flex gap-1">
                        <button
                          type="button"
                          onClick={() => onViewReceipt(s)}
                          className="btn-secondary px-2.5 py-1 text-xs text-blue-700"
                        >
                          {t.viewReceipt}
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal(s)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
                          title={t.editSale}
                        >
                          <Icon name="edit" className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTarget(s)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                          title={t.deleteSale}
                        >
                          <Icon name="trash" className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Sale Modal */}
      <Modal
        open={!!editTarget && !!editForm}
        onClose={() => {
          setEditTarget(null);
          setEditForm(null);
        }}
        title={`${t.editSale} — ${editTarget?.invoiceNo || ''}`}
        maxWidth="max-w-2xl"
      >
        {editForm && (
          <form noValidate onSubmit={handleSaveEditedSale} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.customer}</label>
                <CustomSelect
                  value={editForm.customerId}
                  onChange={(val) => setEditForm({ ...editForm, customerId: val })}
                  options={customerOptions}
                  searchable
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.paymentMethod}</label>
                <CustomSelect
                  value={editForm.paymentMethod}
                  onChange={(val) => setEditForm({ ...editForm, paymentMethod: val })}
                  options={paymentMethodOptions}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <CustomSelect
                value={addProdId}
                onChange={setAddProdId}
                options={addProductOptions}
                searchable
                className="flex-1"
              />
              <button type="button" onClick={addProductToEdit} className="btn-dark px-3.5 py-2 text-xs">
                + {t.addItemToSale}
              </button>
            </div>

            <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-52 overflow-y-auto custom-scrollbar">
              {editForm.items.map((it) => {
                const isFrac = ['kg', 'g', 'l', 'ml', 'meter'].includes((it.unit || '').toLowerCase());
                const step = isFrac ? 0.25 : 1;
                return (
                  <div key={it.productId} className="p-2.5 flex items-center justify-between gap-2 text-sm">
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-800 truncate">{it.name}</p>
                      <p className="text-xs text-slate-500 tabular-nums">
                        {fmtMoney(it.sellingPrice)} × {fmtQty(it.qty, it.unit)} = {fmtMoney(it.sellingPrice * it.qty)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => updateEditItemQty(it.productId, it.qty - step)}
                        className="w-7 h-7 rounded-lg border border-slate-200 font-bold"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        step="any"
                        min="0"
                        value={it.qty}
                        onChange={(e) => {
                          const v = parseFloat(e.target.value);
                          if (!Number.isNaN(v) && v >= 0) updateEditItemQty(it.productId, v);
                        }}
                        className="w-14 text-center rounded-lg border border-slate-200 py-0.5 text-xs font-bold tabular-nums"
                      />
                      <button
                        type="button"
                        onClick={() => updateEditItemQty(it.productId, it.qty + step)}
                        className="w-7 h-7 rounded-lg border border-slate-200 font-bold"
                      >
                        +
                      </button>
                      <button
                        type="button"
                        onClick={() => updateEditItemQty(it.productId, 0)}
                        className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg"
                      >
                        <Icon name="trash" className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-sm tabular-nums">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500">{t.subtotal}</label>
                <p className="font-bold text-slate-800 mt-1">{fmtMoney(editTotals.subtotal)}</p>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500">{t.discount}</label>
                <input
                  type="number"
                  min="0"
                  value={editForm.discount}
                  onChange={(e) => setEditForm({ ...editForm, discount: e.target.value })}
                  className="w-full mt-0.5 rounded-lg border border-slate-200 px-2 py-1 text-sm font-bold bg-white tabular-nums"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500">{t.grandTotal}</label>
                <p className="font-extrabold text-indigo-600 mt-1">{fmtMoney(editTotals.grandTotal)}</p>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500">{t.paidAmount}</label>
                <input
                  type="number"
                  min="0"
                  value={editForm.paidAmount}
                  onChange={(e) => setEditForm({ ...editForm, paidAmount: e.target.value })}
                  className="w-full mt-0.5 rounded-lg border border-slate-200 px-2 py-1 text-sm font-bold bg-white tabular-nums"
                />
              </div>
            </div>
            {editTotals.due > 0 && (
              <p className="text-xs font-bold text-rose-600 text-right tabular-nums">
                {t.dueAmount}: {fmtMoney(editTotals.due)}
              </p>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setEditTarget(null);
                  setEditForm(null);
                }}
                className="btn-secondary px-4 py-2 text-sm"
              >
                {t.cancel}
              </button>
              <button type="submit" className="btn-primary px-5 py-2 text-sm">
                {t.save}
              </button>
            </div>
          </form>
        )}
      </Modal>

      <ConfirmModal
        open={!!deleteTarget}
        title={t.deleteSaleConfirmTitle}
        message={t.deleteSaleConfirmMsg.replace('{invoice}', deleteTarget?.invoiceNo || '')}
        confirmLabel={t.deleteSale}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) onDeleteSale(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};
