import { Link, NavLink } from "react-router-dom";
import { Leaf, Plus, LogIn } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", label: "Board", end: true },
  { to: "/insights", label: "Insights" },
  { to: "/team", label: "City team" },
];

export default function SiteHeader() {
  const { user, isAuthenticated } = useAuth();

  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
            <Leaf className="h-4.5 w-4.5 text-primary-foreground" strokeWidth={2.2} />
          </span>
          <span className="leading-none">
            <span className="block font-display text-[15px] font-semibold tracking-tight">
              Clean City
            </span>
            <span className="block text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Coimbatore
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) =>
                cn(
                  "rounded-full px-3.5 py-2 text-sm transition-colors",
                  isActive
                    ? "bg-secondary text-foreground"
                    : "text-muted-foreground hover:text-foreground"
                )
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <Link
              to="/account"
              className="hidden h-9 w-9 items-center justify-center rounded-full border border-border bg-card text-xs font-semibold text-primary sm:flex"
              title={user?.full_name || user?.email}
            >
              {(user?.full_name || user?.email || "·").slice(0, 1).toUpperCase()}
            </Link>
          ) : (
            <Button asChild variant="ghost" size="sm" className="hidden rounded-full sm:inline-flex">
              <Link to="/login">
                <LogIn className="mr-1.5 h-4 w-4" />
                Log in
              </Link>
            </Button>
          )}
          <Button asChild size="sm" className="rounded-full">
            <Link to="/report">
              <Plus className="mr-1 h-4 w-4" />
              Report an issue
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}