import React, { useState } from "react";
import { Copy, Share2, Heart, Check, Volume2, BookOpen, Sparkles, SlidersHorizontal } from "lucide-react";
import { GeneratedPoetry, AppSettings } from "../types";
import { MODE_METADATA } from "../data/constants";

interface ResultCardProps {
  poetry: GeneratedPoetry;
  settings: AppSettings;
  onToggleFavorite: (id: string) => void;
  isFavorite: boolean;
}

export const ResultCard: React.FC<ResultCardProps> = ({
  poetry,
  settings,
  onToggleFavorite,
  isFavorite
}) => {
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [textScale, setTextScale] = useState<"normal" | "large" | "xlarge">("normal");

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(poetry.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      const textArea = document.createElement("textarea");
      textArea.value = poetry.content;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: "Hassan's MisraSaaz AI",
      text: `${poetry.content}\n\n— تخلیق کردہ: Hassan's MisraSaaz AI (حسنؔ کا مصرع ساز)`
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  const handleSpeak = () => {
    if (!("speechSynthesis" in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(poetry.content);
    const voices = window.speechSynthesis.getVoices();
    const urduVoice = voices.find(
      (v) => v.lang.startsWith("ur") || v.lang.startsWith("hi")
    );
    if (urduVoice) {
      utterance.voice = urduVoice;
    }
    utterance.rate = 0.85;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const meta = MODE_METADATA[poetry.mode];
  const fontClass = settings.selectedFont === "nastaliq" ? "font-urdu" : "font-urdu-sans";

  const sizeClass =
    textScale === "large"
      ? "text-2xl md:text-3xl leading-[2.6]"
      : textScale === "xlarge"
      ? "text-3xl md:text-4xl leading-[3]"
      : "text-xl md:text-2xl leading-[2.3]";

  // Helper to format markdown headers and bold sections neatly
  const renderFormattedContent = (content: string) => {
    const sections = content.split("\n\n");

    return sections.map((sec, idx) => {
      const trimmed = sec.trim();
      if (!trimmed) return null;

      // Divider
      if (trimmed === "---" || trimmed === "___" || trimmed === "***") {
        return (
          <div key={idx} className="my-4 flex items-center justify-center gap-3 opacity-40">
            <div className="h-[1px] w-16 bg-amber-400" />
            <span className="text-amber-400 text-xs">✦</span>
            <div className="h-[1px] w-16 bg-amber-400" />
          </div>
        );
      }

      // Heading 3 or 4
      if (trimmed.startsWith("###") || trimmed.startsWith("####") || trimmed.startsWith("##")) {
        const cleanHeading = trimmed.replace(/^[#]+\s*/, "").replace(/\*\*/g, "");
        return (
          <div key={idx} className="my-3 text-center">
            <span className="inline-block px-3 py-1 rounded-xl bg-emerald-950/80 border border-emerald-700/60 font-urdu-title text-base font-bold text-amber-300">
              {cleanHeading}
            </span>
          </div>
        );
      }

      // Bullet list items
      if (trimmed.includes("\n* ") || trimmed.includes("\n- ") || trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
        const lines = trimmed.split("\n");
        return (
          <div key={idx} className="my-2 text-right px-2 bg-stone-900/60 rounded-xl p-3 border border-stone-800 text-sm font-urdu-sans leading-relaxed text-stone-200">
            {lines.map((line, lIdx) => {
              const cleanLine = line.replace(/^[\*\-]\s+/, "");
              // Parse bold
              const parts = cleanLine.split(/(\*\*.*?\*\*)/g);
              return (
                <div key={lIdx} className="my-1 flex items-start gap-2">
                  <span className="text-amber-400 text-xs mt-1">✦</span>
                  <div>
                    {parts.map((part, pIdx) => {
                      if (part.startsWith("**") && part.endsWith("**")) {
                        return (
                          <strong key={pIdx} className="text-amber-300 font-bold">
                            {part.slice(2, -2)}
                          </strong>
                        );
                      }
                      return <span key={pIdx}>{part}</span>;
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        );
      }

      // Standard poetry verse or paragraph
      const lines = trimmed.split("\n");
      const isShortPoetry = lines.length <= 4 && !trimmed.includes(":");

      return (
        <div
          key={idx}
          className={`my-3 text-center ${
            isShortPoetry
              ? "p-3 rounded-2xl bg-gradient-to-b from-stone-900/90 to-emerald-950/40 border border-amber-500/30 shadow-md"
              : ""
          }`}
        >
          {lines.map((line, lIdx) => {
            const cleanLine = line.replace(/^\*\*(.*?)\*\*$/, "$1");
            return (
              <p
                key={lIdx}
                className={`${isShortPoetry ? sizeClass : "text-base md:text-lg"} ${fontClass} text-amber-100/95 my-1`}
              >
                {cleanLine}
              </p>
            );
          })}
        </div>
      );
    });
  };

  return (
    <div className="w-full my-6 rounded-3xl bg-gradient-to-b from-stone-900 via-stone-900 to-emerald-950/30 border-2 border-amber-500/40 p-4 md:p-6 shadow-2xl relative overflow-hidden">
      {/* Traditional Calligraphic Filigree Accents */}
      <div className="absolute top-2 right-3 text-amber-500/20 text-xs select-none pointer-events-none">
        ✦ ✧ ✦
      </div>
      <div className="absolute top-2 left-3 text-amber-500/20 text-xs select-none pointer-events-none">
        ✦ ✧ ✦
      </div>
      <div className="absolute bottom-2 right-3 text-amber-500/20 text-xs select-none pointer-events-none">
        ✦ ✧ ✦
      </div>
      <div className="absolute bottom-2 left-3 text-amber-500/20 text-xs select-none pointer-events-none">
        ✦ ✧ ✦
      </div>

      {/* Header Bar */}
      <div className="flex items-center justify-between border-b border-amber-500/20 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-emerald-950 border border-emerald-700/60 text-amber-400">
            <BookOpen className="w-4 h-4" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-urdu-title text-base font-bold text-amber-200">
                {meta?.titleUrdu || "تخلیق شدہ کلام"}
              </h4>
              <span className="text-[10px] font-urdu-sans px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {poetry.topic}
              </span>
            </div>
            <p className="text-[10px] font-ui text-stone-400">
              {new Date(poetry.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </p>
          </div>
        </div>

        {/* Action Controls: Size & Narration */}
        <div className="flex items-center gap-1.5">
          {/* Text Size Cycler */}
          <button
            onClick={() =>
              setTextScale(
                textScale === "normal"
                  ? "large"
                  : textScale === "large"
                  ? "xlarge"
                  : "normal"
              )
            }
            title="فونٹ سائز تبدیل کریں"
            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 text-xs font-ui"
          >
            {textScale === "normal" ? "A" : textScale === "large" ? "A+" : "A++"}
          </button>

          {/* Audio narration button */}
          <button
            onClick={handleSpeak}
            id="listen-recitation-button"
            title="سماعت فرمائیں (Audio Recitation)"
            className={`p-1.5 md:px-2.5 py-1.5 rounded-xl border transition-colors flex items-center gap-1 text-xs font-urdu-sans ${
              isSpeaking
                ? "bg-amber-500 text-stone-950 border-amber-400 animate-pulse"
                : "bg-stone-800/90 hover:bg-stone-700/90 border-stone-700 text-stone-300"
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">سماعت</span>
          </button>
        </div>
      </div>

      {/* Main Rendered Output */}
      <div className="py-2 px-2 md:px-4 bg-stone-950/70 rounded-2xl border border-stone-800/80 mb-5 shadow-inner">
        {renderFormattedContent(poetry.content)}
      </div>

      {/* Required Action Buttons: "Copy Sher", "Share as Text", "Favorite" */}
      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-stone-800/80">
        {/* 1. Copy Sher Button */}
        <button
          onClick={handleCopy}
          id={`copy-sher-button-${poetry.id}`}
          className={`py-2.5 px-2 rounded-xl font-urdu-sans font-semibold text-xs md:text-sm border transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
            copied
              ? "bg-emerald-600 text-white border-emerald-500 shadow-emerald-950/60"
              : "bg-stone-800/90 hover:bg-stone-700/90 text-amber-300 border-amber-500/30 hover:border-amber-400"
          }`}
        >
          {copied ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4 text-amber-400" />}
          <span>{copied ? "کاپی شد!" : "کاپی شعر"}</span>
        </button>

        {/* 2. Share as Text Button */}
        <button
          onClick={handleShare}
          id={`share-text-button-${poetry.id}`}
          className={`py-2.5 px-2 rounded-xl font-urdu-sans font-semibold text-xs md:text-sm border transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
            shared
              ? "bg-teal-600 text-white border-teal-500"
              : "bg-stone-800/90 hover:bg-stone-700/90 text-teal-300 border-teal-500/30 hover:border-teal-400"
          }`}
        >
          {shared ? <Check className="w-4 h-4 text-white" /> : <Share2 className="w-4 h-4 text-teal-400" />}
          <span>{shared ? "شیئر مکمل" : "شیئر کریں"}</span>
        </button>

        {/* 3. Favorite Button */}
        <button
          onClick={() => onToggleFavorite(poetry.id)}
          id={`favorite-button-${poetry.id}`}
          className={`py-2.5 px-2 rounded-xl font-urdu-sans font-semibold text-xs md:text-sm border transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 ${
            isFavorite
              ? "bg-rose-950/80 border-rose-500 text-rose-300 shadow-rose-950/40"
              : "bg-stone-800/90 hover:bg-stone-700/90 text-stone-300 border-stone-700 hover:text-rose-300"
          }`}
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isFavorite ? "fill-rose-500 text-rose-500" : "text-rose-400"
            }`}
          />
          <span>{isFavorite ? "پسندیدہ" : "پسند کریں"}</span>
        </button>
      </div>
    </div>
  );
};
