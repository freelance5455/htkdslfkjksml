import React, { useState, useEffect } from 'react';
import { WifiOff, Wifi, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface OfflineBannerProps {
  onRetrySync?: () => void;
}

export const OfflineBanner: React.FC<OfflineBannerProps> = ({ onRetrySync }) => {
  const isOnline = useOnlineStatus();
  const [wasOffline, setWasOffline] = useState(false);
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    if (!isOnline) {
      setWasOffline(true);
      setShowReconnected(false);
    } else if (wasOffline && isOnline) {
      setShowReconnected(true);
      const timer = setTimeout(() => {
        setShowReconnected(false);
        setWasOffline(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline]);

  if (!isOnline) {
    return (
      <div
        id="offline-banner"
        className="bg-amber-500/10 border-b border-amber-500/20 px-3.5 py-2 text-amber-900 transition-all"
      >
        <div className="max-w-md mx-auto flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-700 flex items-center justify-center shrink-0">
              <WifiOff className="w-3 h-3" />
            </div>
            <div className="truncate">
              <span className="font-bold text-amber-950">Offline Mode Active</span>
              <span className="hidden sm:inline text-amber-800 ml-1.5">
                • All saved notes, homework & notices are fully readable offline.
              </span>
            </div>
          </div>
          {onRetrySync && (
            <button
              onClick={onRetrySync}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 font-semibold shrink-0 text-[11px] transition"
              title="Check internet connection"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  if (showReconnected) {
    return (
      <div
        id="online-reconnected-banner"
        className="bg-emerald-500/10 border-b border-emerald-500/20 px-3.5 py-2 text-emerald-900 transition-all animate-fadeIn"
      >
        <div className="max-w-md mx-auto flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-700 flex items-center justify-center shrink-0">
              <Wifi className="w-3 h-3" />
            </div>
            <div>
              <span className="font-bold text-emerald-950">Back Online</span>
              <span className="text-emerald-800 ml-1.5">
                • Reconnected to school database.
              </span>
            </div>
          </div>
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
        </div>
      </div>
    );
  }

  return null;
};
