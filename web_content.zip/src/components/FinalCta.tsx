import { useState } from "react";
import { BadgeCheck, CheckCircle2, Download, LockKeyhole, Mail, ShieldCheck, Smartphone, WifiOff } from "lucide-react";
import Logo from "./Logo";

export default function FinalCta() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "error" | "done">("idle");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      setState("done");
    } else {
      setState("error");
    }
  };

  return (
    <section id="descargar" className="scroll-mt-28 mx-auto max-w-7xl px-4 pb-16 pt-4 sm:px-6 sm:pb-20">
      <div className="relative overflow-hidden rounded-3xl border border-electric/30 shadow-[0_40px_120px_-30px_rgba(47,123,255,0.45)]">
        <img
          src="/img/hero-art.jpg"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover object-[62%_center]"
        />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-r from-[#04061a]/95 via-[#04061a]/80 to-[#04061a]/10" />
        <div aria-hidden="true" className="noise absolute inset-0" />

        <div className="relative grid gap-8 p-6 sm:p-10 lg:grid-cols-2 lg:p-14">
          <div>
            <Logo compact />
            <h2 className="mt-5 font-display text-4xl font-bold leading-[1.05] text-white sm:text-6xl">
              Pulsa <span className="grad-text">Play</span>.<br />Nada más.
            </h2>
            <p className="mt-4 max-w-md text-base leading-relaxed text-slate-200">
              Recibe la APK firmada de <strong className="text-white">TV LO3 Ultimate Edition</strong> por correo,
              o descárgala directamente. Sin tarjeta, sin registro, sin letra pequeña.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-slate-200">
              {[
                { icon: Smartphone, t: "46 MB · Android 9+ · orientación 16:9 forzada" },
                { icon: LockKeyhole, t: "APK firmada SHA-256 · verificada por Play Protect" },
                { icon: WifiOff, t: "Modo offline para tu biblioteca local desde el primer minuto" },
                { icon: ShieldCheck, t: "Solo fuentes autorizadas — cero contenido pirata" },
              ].map(({ icon: Icon, t }) => (
                <li key={t} className="flex items-center gap-2.5"><Icon size={16} className="shrink-0 text-cyanx" />{t}</li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col justify-center">
            {state === "done" ? (
              <div className="rounded-2xl border border-emerald-400/30 bg-[#041f1b]/80 p-6 backdrop-blur-md">
                <CheckCircle2 size={40} className="text-emerald-400" />
                <h3 className="mt-3 font-display text-2xl font-bold text-white">¡Listo, {email.split("@")[0].slice(0, 24)}!</h3>
                <p className="mt-1.5 text-sm text-emerald-100/80">Acabamos de enviar el enlace de descarga a <strong>{email}</strong>. Revisa tu bandeja (y la carpeta de spam, por si acaso).</p>
                <a href="#inicio" className="grad-btn mt-5 flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-bold text-white"><Download size={17} /> O descarga ya la APK directa</a>
              </div>
            ) : (
              <form onSubmit={submit} className="rounded-2xl border border-white/15 bg-black/55 p-6 backdrop-blur-md">
                <label htmlFor="cta-email" className="text-[11px] font-bold uppercase tracking-[0.18em] text-cyan-200">Recibe tu APK ahora</label>
                <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                  <div className="relative flex-1">
                    <Mail size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      id="cta-email"
                      type="email"
                      value={email}
                      onChange={(e) => { setEmail(e.target.value); setState("idle"); }}
                      placeholder="tucorreo@ejemplo.com"
                      aria-invalid={state === "error"}
                      aria-describedby={state === "error" ? "cta-email-error" : undefined}
                      className={`h-14 w-full rounded-xl border bg-white/[0.06] pl-11 pr-4 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyanx/60 ${state === "error" ? "border-red-500/70" : "border-white/15"}`}
                    />
                  </div>
                  <button type="submit" className="grad-btn flex h-14 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-6 font-bold text-white">
                    <Download size={18} /> Enviar APK
                  </button>
                </div>
                {state === "error" && <p id="cta-email-error" role="alert" className="mt-2 text-xs font-medium text-red-400">Introduce un correo válido, por ejemplo: nombre@dominio.com</p>}
                <div className="mt-4 flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-slate-600">
                  <span className="h-px flex-1 bg-white/10" />o sin registro<span className="h-px flex-1 bg-white/10" />
                </div>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  <a href="#inicio" className="ghost-btn flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-bold text-white">
                    <Smartphone size={17} className="text-cyanx" /> APK directa · 46 MB
                  </a>
                  <a href="#inicio" className="ghost-btn flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-bold text-white">
                    <BadgeCheck size={17} className="text-emerald-400" /> Google Play
                  </a>
                </div>
                <p className="mt-4 text-[10px] leading-snug text-slate-500">Al descargar aceptas los <a href="#faq" className="underline hover:text-slate-300">Términos</a> y la <a href="#faq" className="underline hover:text-slate-300">Política de Privacidad</a>. TV LO3 no aloja ni retransmite contenido de terceros sin licencia; las listas M3U/Xtream importadas deben ser personales y autorizadas.</p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
