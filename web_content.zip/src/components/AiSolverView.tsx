import React, { useState } from 'react';
import { Sparkles, Send, ArrowRight, Check, Copy, ArrowUpRight, Zap, Lightbulb, RefreshCw } from 'lucide-react';
import { aiSolverService, AiSolveStep } from '../services/aiSolverService';
import { audioService } from '../services/audioService';
import { historyStorage } from '../services/historyStorage';
import confetti from 'canvas-confetti';

interface AiSolverViewProps {
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  onSendToCalculator: (expr: string) => void;
}

const QUICK_CHIPS = [
  '15% tip on $120 split 4 ways',
  '2x² + 5x - 3 = 0',
  '$10k at 8% interest 5yr',
  '18% GST on $450',
  'Speed of car: 120km in 1.5 hours',
  'Cost $45, sell $75: find margin',
];

export const AiSolverView: React.FC<AiSolverViewProps> = ({
  onShowToast,
  onSendToCalculator,
}) => {
  const [prompt, setPrompt] = useState<string>('15% tip on $120 split 4 ways');
  const [loading, setLoading] = useState<boolean>(false);
  const [solution, setSolution] = useState<AiSolveStep | null>({
    title: 'VIP Restaurant Bill & Gratuity Split',
    formula: 'Total = Bill × (1 + Tip%) ; Split = Total ÷ People',
    variables: [
      { name: 'Base Bill (B)', value: '$120.00' },
      { name: 'Tip (15%)', value: '$18.00' },
      { name: 'Total Bill', value: '$138.00' },
      { name: 'Split among 4 people', value: '$34.50 per person' },
    ],
    steps: [
      'Base Bill: $120.00',
      'Tip (15%): $18.00',
      'Total Bill: $138.00',
      'Split among 4 people: $34.50 per person',
    ],
    result: '$138.00 total ($34.50/each)',
    numericValue: 34.5,
    insight: 'Tipping 15% adds $18.00. Each person pays $34.50.',
    source: 'vip-local-engine',
  });
  const [copied, setCopied] = useState<boolean>(false);

  const handleSolve = async (overridePrompt?: string) => {
    const query = (overridePrompt ?? prompt).trim();
    if (!query) {
      onShowToast('Please enter a question or equation', 'error');
      return;
    }

    audioService.playOperatorClick();
    setLoading(true);

    try {
      const res = await aiSolverService.solve(query);
      setSolution(res);
      audioService.playEqualsChime();

      confetti({
        particleCount: 25,
        spread: 50,
        origin: { y: 0.4 },
        colors: ['#fbbf24', '#f59e0b', '#38bdf8'],
      });

      // Save to history
      historyStorage.add({
        type: 'ai',
        title: res.title,
        expression: query,
        result: res.result,
        details: res.steps.join(' | '),
        numericResult: res.numericValue,
      });

      onShowToast('VIP AI analysis complete!', 'success');
    } catch (err: any) {
      audioService.playErrorSound();
      onShowToast(err.message || 'Failed to solve query', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCopySolution = () => {
    if (!solution) return;
    audioService.playKeyClick();
    const text = [
      `VIP Solution: ${solution.title}`,
      `Formula: ${solution.formula}`,
      ...solution.steps.map((s) => `• ${s}`),
      `★ Result: ${solution.result}`,
    ].join('\n');

    if (navigator?.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      onShowToast('Full solution copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto p-3.5 space-y-3.5 overflow-y-auto">
      {/* Header Banner */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-[#17140b] via-[#10131d] to-[#0c0e16] border border-amber-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-amber-200 uppercase tracking-wider font-mono">
              VIP NATURAL FORMULA ENGINE
            </h3>
            <p className="text-[10px] text-zinc-400">
              Ask math, business, loan, or physics prompts
            </p>
          </div>
        </div>
        <span className="text-[9px] px-2 py-0.5 rounded-full font-mono font-bold bg-amber-400/15 text-amber-300 border border-amber-400/30">
          AI 3.8
        </span>
      </div>

      {/* Input Box */}
      <div className="relative">
        <textarea
          rows={2}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g. 15% tip on $120 split 4 ways or 2x² + 5x - 3 = 0"
          className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-zinc-800 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/20 font-mono resize-none transition"
        />
        <button
          onClick={() => handleSolve()}
          disabled={loading}
          className="w-full mt-2 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-black" />
              <span>Analyzing with VIP Engine...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5 text-black" />
              <span>⚡ Analyze & Solve</span>
            </>
          )}
        </button>
      </div>

      {/* Quick Chips */}
      <div>
        <p className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider mb-1.5">
          Quick VIP Formula Chips:
        </p>
        <div className="flex flex-wrap gap-1.5">
          {QUICK_CHIPS.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                setPrompt(chip);
                handleSolve(chip);
              }}
              className="px-2.5 py-1 rounded-lg bg-zinc-900/90 hover:bg-zinc-800 border border-amber-500/20 hover:border-amber-400/50 text-[11px] text-amber-200/90 font-mono transition active:scale-95"
            >
              [{chip}]
            </button>
          ))}
        </div>
      </div>

      {/* Solution Display Card */}
      {solution && (
        <div className="rounded-2xl bg-gradient-to-b from-[#111420] to-[#0a0c13] border border-amber-500/30 p-4 shadow-xl space-y-3">
          {/* Solution Header */}
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
            <div>
              <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider">
                VIP Breakdown & Solution
              </span>
              <h4 className="text-sm font-bold text-zinc-100">{solution.title}</h4>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopySolution}
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-amber-300 transition"
                title="Copy Solution"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              {solution.numericValue !== undefined && (
                <button
                  onClick={() => {
                    audioService.playKeyClick();
                    onSendToCalculator(solution.numericValue!.toString());
                    onShowToast(`Sent ${solution.numericValue} to Calculator!`, 'success');
                  }}
                  className="px-2 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-[10px] text-amber-300 font-mono font-medium flex items-center gap-1 transition"
                  title="Send to Calculator"
                >
                  <span>To Calc</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Formula Card */}
          <div className="p-2.5 rounded-xl bg-[#090b11] border border-amber-500/15 font-mono text-xs text-amber-300/90 flex items-center gap-2">
            <span className="text-[10px] text-zinc-500 uppercase">Formula:</span>
            <span className="font-semibold break-all">{solution.formula}</span>
          </div>

          {/* Variables Grid */}
          {solution.variables && solution.variables.length > 0 && (
            <div className="grid grid-cols-2 gap-1.5">
              {solution.variables.map((v, i) => (
                <div
                  key={i}
                  className="p-2 rounded-lg bg-[#0e1017] border border-zinc-800/80 text-[11px] font-mono"
                >
                  <span className="text-zinc-400 block text-[10px]">{v.name}</span>
                  <span className="text-amber-200 font-semibold">{v.value}</span>
                </div>
              ))}
            </div>
          )}

          {/* Steps */}
          <div className="space-y-1.5 pt-1">
            <p className="text-[10px] font-mono uppercase text-zinc-400 tracking-wider">
              Step-by-step resolution:
            </p>
            {solution.steps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2 text-xs font-mono text-zinc-300 bg-zinc-900/40 p-2 rounded-lg border border-zinc-800/40"
              >
                <span className="text-amber-400 font-bold shrink-0">•</span>
                <span>{step}</span>
              </div>
            ))}
          </div>

          {/* Golden Result Callout */}
          <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/15 via-amber-400/10 to-amber-500/15 border border-amber-400/40 shadow-inner flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase text-amber-300/80 block">
                Final Result
              </span>
              <span className="text-base sm:text-lg font-bold font-mono gold-gradient-text">
                ★ {solution.result}
              </span>
            </div>
          </div>

          {/* Insight / Takeaway */}
          {solution.insight && (
            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-[#090b10] border border-amber-500/15 text-[11px] text-zinc-400 font-sans">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <span>{solution.insight}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
