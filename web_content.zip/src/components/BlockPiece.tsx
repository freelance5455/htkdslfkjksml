import React from 'react';
import { BlockVisualEffect, CellColor } from '../types/game';
import { COLOR_MAP } from '../constants/shapes';

interface BlockCellProps {
  color: CellColor;
  size?: number; // size in px, defaults to responsive
  isGhost?: boolean;
  isClearing?: boolean;
  isDragging?: boolean;
  isBomb?: boolean;
  bombCountdown?: number;
  isTargeted?: boolean;
  visualStyle?: BlockVisualEffect;
  className?: string;
}

export const BlockCell: React.FC<BlockCellProps> = ({
  color,
  size,
  isGhost = false,
  isClearing = false,
  isDragging = false,
  isBomb = false,
  bombCountdown,
  isTargeted = false,
  visualStyle = 'crystalline',
  className = '',
}) => {
  const config = COLOR_MAP[color] || COLOR_MAP.cyan;

  if (isGhost) {
    return (
      <div
        style={size ? { width: `${size}px`, height: `${size}px` } : undefined}
        className={`w-full h-full rounded-md md:rounded-lg border-2 border-dashed ${config.border} bg-white/10 animate-pulse flex items-center justify-center ${className}`}
      >
        <div
          className="w-1/2 h-1/2 rounded-sm"
          style={{ backgroundColor: config.primary, opacity: 0.35 }}
        />
      </div>
    );
  }

  // --- 1. NEON STYLE ---
  if (visualStyle === 'neon') {
    return (
      <div
        style={size ? { width: `${size}px`, height: `${size}px` } : undefined}
        className={`relative w-full h-full rounded-md md:rounded-lg select-none transition-transform duration-75 overflow-hidden flex items-center justify-center ${
          isDragging ? 'scale-105 shadow-2xl' : ''
        } ${isClearing ? 'scale-110 brightness-150 animate-pulse' : ''} ${
          isTargeted ? 'ring-2 ring-rose-400 brightness-125' : ''
        } ${className}`}
      >
        {/* Neon outer glow & translucent body */}
        <div
          className="absolute inset-0 rounded-md md:rounded-lg border-2 border-white/80"
          style={{
            backgroundColor: `${config.primary}33`,
            boxShadow: `0 0 12px ${config.glow}, 0 0 22px ${config.glow}, inset 0 0 8px ${config.glow}`,
          }}
        />

        {/* White-hot center filament */}
        <div
          className="w-3/5 h-1.5 rounded-full bg-white/95 filter blur-[0.3px] shadow-[0_0_8px_#ffffff]"
        />

        {/* Corner Neon accents */}
        <div className="absolute top-0.5 left-0.5 w-1 h-1 rounded-full bg-white" />
        <div className="absolute bottom-0.5 right-0.5 w-1 h-1 rounded-full bg-white" />

        {/* Cosmic Bomb Core Overlay */}
        {isBomb && bombCountdown !== undefined && renderBombBadge(bombCountdown)}
      </div>
    );
  }

  // --- 2. METALLIC CHROME STYLE ---
  if (visualStyle === 'metallic') {
    return (
      <div
        style={size ? { width: `${size}px`, height: `${size}px` } : undefined}
        className={`relative w-full h-full rounded-md md:rounded-lg select-none transition-transform duration-75 overflow-hidden flex items-center justify-center ${
          isDragging ? 'scale-105 shadow-xl' : ''
        } ${isClearing ? 'scale-110 brightness-150 animate-pulse' : ''} ${
          isTargeted ? 'ring-2 ring-rose-400 brightness-125' : ''
        } ${className}`}
      >
        {/* Brushed chrome base with color tint */}
        <div
          className="absolute inset-0 rounded-md md:rounded-lg"
          style={{
            background: `linear-gradient(135deg, ${config.primary} 0%, #cbd5e1 30%, ${config.primary} 70%, #0f172a 100%)`,
            boxShadow: `inset 0 2px 3px rgba(255,255,255,0.9), inset 0 -2px 3px rgba(0,0,0,0.85), 0 3px 6px rgba(0,0,0,0.5)`,
          }}
        />

        {/* Diagonal metallic chrome sheen */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/50 to-transparent pointer-events-none opacity-80" />

        {/* Hard beveled chamfer border */}
        <div className="absolute inset-0 rounded-md md:rounded-lg border-t border-l border-white/80 border-b border-r border-black/80 pointer-events-none" />

        {/* Center metallic rivet/stud */}
        <div className="w-1.5 h-1.5 rounded-full bg-white/70 shadow-sm border border-black/40 pointer-events-none" />

        {/* Cosmic Bomb Core Overlay */}
        {isBomb && bombCountdown !== undefined && renderBombBadge(bombCountdown)}
      </div>
    );
  }

  // --- 3. OBSIDIAN GLASS STYLE ---
  if (visualStyle === 'obsidian') {
    return (
      <div
        style={size ? { width: `${size}px`, height: `${size}px` } : undefined}
        className={`relative w-full h-full rounded-md md:rounded-lg select-none transition-transform duration-75 overflow-hidden flex items-center justify-center ${
          isDragging ? 'scale-105 shadow-xl' : ''
        } ${isClearing ? 'scale-110 brightness-150 animate-pulse' : ''} ${
          isTargeted ? 'ring-2 ring-rose-400 brightness-125' : ''
        } ${className}`}
      >
        {/* Smoky obsidian dark glass */}
        <div
          className="absolute inset-0 rounded-md md:rounded-lg border"
          style={{
            background: `radial-gradient(circle at 35% 35%, #1e293b 0%, #090d16 65%, #020617 100%)`,
            borderColor: config.primary,
            boxShadow: `0 0 10px ${config.glow}, inset 0 1px 2px rgba(255,255,255,0.4), inset 0 0 12px rgba(0,0,0,0.9)`,
          }}
        />

        {/* Holographic color reflection rim */}
        <div
          className="absolute top-0 left-0 right-0 h-[30%] opacity-40 rounded-t-md"
          style={{
            background: `linear-gradient(to bottom, ${config.primary}, transparent)`,
          }}
        />

        {/* Internal micro stardust sparkles */}
        <div className="absolute top-1 left-1.5 w-1 h-1 rounded-full bg-white/80 shadow-[0_0_3px_#fff]" />
        <div className="absolute bottom-1.5 right-1.5 w-0.5 h-0.5 rounded-full bg-cyan-300" />
        <div className="absolute top-2 right-2 w-0.5 h-0.5 rounded-full bg-purple-300" />

        {/* Cosmic Bomb Core Overlay */}
        {isBomb && bombCountdown !== undefined && renderBombBadge(bombCountdown)}
      </div>
    );
  }

  // --- 4. DEFAULT: CRYSTALLINE GEM STYLE ---
  return (
    <div
      style={size ? { width: `${size}px`, height: `${size}px` } : undefined}
      className={`relative w-full h-full rounded-md md:rounded-lg select-none transition-transform duration-75 overflow-hidden flex items-center justify-center ${
        isDragging ? 'scale-105 shadow-xl' : ''
      } ${isClearing ? 'scale-110 brightness-150 animate-pulse' : ''} ${
        isTargeted ? 'ring-2 ring-rose-400 brightness-125' : ''
      } ${className}`}
    >
      {/* Base 3D jewel background */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${config.gradient} rounded-md md:rounded-lg`}
        style={{
          boxShadow: isDragging
            ? `0 0 16px ${config.glow}, inset 0 2px 3px rgba(255,255,255,0.6), inset 0 -2px 3px rgba(0,0,0,0.5)`
            : `0 2px 6px rgba(0,0,0,0.4), 0 0 8px ${config.glow}, inset 0 2px 2px rgba(255,255,255,0.55), inset 0 -2px 3px rgba(0,0,0,0.45)`,
        }}
      />

      {/* Top Bevel Highlight */}
      <div className="absolute top-0 left-0 right-0 h-[22%] bg-gradient-to-b from-white/45 to-transparent rounded-t-md pointer-events-none" />

      {/* Internal Jewel Facet / Glossy Center Reflection */}
      <div className="absolute inset-[15%] rounded-sm bg-gradient-to-tr from-black/15 via-white/10 to-white/30 border border-white/25 pointer-events-none" />

      {/* Top-left Sparkle Specular Spot */}
      <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/70 filter blur-[0.4px] pointer-events-none" />

      {/* Cosmic Bomb Core Overlay */}
      {isBomb && bombCountdown !== undefined && renderBombBadge(bombCountdown)}
    </div>
  );
};

function renderBombBadge(bombCountdown: number) {
  return (
    <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
      <div
        className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs font-mono-numbers shadow-lg border ${
          bombCountdown <= 3
            ? 'bg-rose-600/90 text-white border-rose-300 animate-ping'
            : bombCountdown <= 5
            ? 'bg-amber-600/90 text-white border-amber-300 animate-pulse'
            : 'bg-black/75 text-amber-300 border-white/30'
        }`}
      >
        {bombCountdown}
      </div>
    </div>
  );
}

interface ShapeMatrixProps {
  matrix: number[][];
  color: CellColor;
  cellSize?: number;
  isGhost?: boolean;
  visualStyle?: BlockVisualEffect;
  className?: string;
}

export const ShapeMatrix: React.FC<ShapeMatrixProps> = ({
  matrix,
  color,
  cellSize = 28,
  isGhost = false,
  visualStyle = 'crystalline',
  className = '',
}) => {
  const rows = matrix.length;
  const cols = matrix[0].length;

  return (
    <div
      className={`inline-grid gap-1 pointer-events-none select-none ${className}`}
      style={{
        gridTemplateColumns: `repeat(${cols}, ${cellSize}px)`,
        gridTemplateRows: `repeat(${rows}, ${cellSize}px)`,
      }}
    >
      {matrix.map((row, r) =>
        row.map((val, c) => (
          <div
            key={`${r}-${c}`}
            style={{ width: `${cellSize}px`, height: `${cellSize}px` }}
            className="flex items-center justify-center"
          >
            {val === 1 ? (
              <BlockCell color={color} size={cellSize} isGhost={isGhost} visualStyle={visualStyle} />
            ) : (
              <div className="w-full h-full" />
            )}
          </div>
        ))
      )}
    </div>
  );
};
