import React, { useState } from 'react';
import { 
  Users, Plus, Search, Phone, Mail, DollarSign, 
  CreditCard, ArrowDownRight, X, Check, FileText 
} from 'lucide-react';
import { Customer, StoreSettings } from '../../types';

interface Props {
  customers: Customer[];
  settings: StoreSettings;
  onAddCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => void;
  onRecordPayment: (customerId: string, amount: number, notes: string) => void;
}

export const CustomersManager: React.FC<Props> = ({
  customers,
  settings,
  onAddCustomer,
  onRecordPayment,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [activeCustomer, setActiveCustomer] = useState<Customer | null>(null);

  // Add form
  const [newCust, setNewCust] = useState({
    name: '',
    phone: '',
    email: '',
    balance: 0,
    notes: '',
  });

  // Pay form
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payNotes, setPayNotes] = useState('سداد نقدي للرصيد');

  const totalOutstandingDebt = customers.reduce((s, c) => s + Math.max(0, c.balance), 0);

  const filteredCustomers = customers.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    return !q || c.name.toLowerCase().includes(q) || c.phone.includes(q);
  });

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCust.name.trim() || !newCust.phone.trim()) {
      alert('الرجاء كتابة اسم العميل ورقم الهاتف');
      return;
    }
    onAddCustomer(newCust);
    setIsAddModalOpen(false);
    setNewCust({ name: '', phone: '', email: '', balance: 0, notes: '' });
  };

  const handleSettlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeCustomer && payAmount > 0) {
      onRecordPayment(activeCustomer.id, payAmount, payNotes);
      setIsPaymentModalOpen(false);
      setActiveCustomer(null);
      setPayAmount(0);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" />
              العملاء والحسابات الآجلة
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              متابعة مديونيات العملاء وسندات القبض وتسوية الحسابات
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl text-xs">
              <span className="text-slate-400 ml-1.5">إجمالي المديونيات المستحقة:</span>
              <strong className="font-mono font-bold text-amber-400 text-sm">
                {totalOutstandingDebt.toFixed(2)} {settings.currency}
              </strong>
            </div>

            <button
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة عميل جديد</span>
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالاسم أو رقم الهاتف..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Customers List */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {filteredCustomers.map((cust) => {
            const hasDebt = cust.balance > 0;

            return (
              <div
                key={cust.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-lg flex flex-col justify-between transition"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-bold text-white text-sm">{cust.name}</h4>
                      <p className="text-xs font-mono text-slate-400 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-500" />
                        {cust.phone}
                      </p>
                    </div>

                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full font-mono ${
                        hasDebt
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}
                    >
                      {hasDebt ? 'عليه مديونية' : 'خالص'}
                    </span>
                  </div>

                  {cust.notes && (
                    <p className="text-xs text-slate-400 bg-slate-950 p-2 rounded-lg border border-slate-800/80 my-2">
                      {cust.notes}
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block">الرصيد المستحق:</span>
                    <span
                      className={`text-base font-black font-mono ${
                        hasDebt ? 'text-amber-400' : 'text-slate-400'
                      }`}
                    >
                      {cust.balance.toFixed(2)}{' '}
                      <small className="text-[10px] font-normal">{settings.currency}</small>
                    </span>
                  </div>

                  {hasDebt && (
                    <button
                      onClick={() => {
                        setActiveCustomer(cust);
                        setPayAmount(cust.balance);
                        setIsPaymentModalOpen(true);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/15 hover:bg-emerald-600/25 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold transition"
                    >
                      <ArrowDownRight className="w-3.5 h-3.5" />
                      <span>سداد دين</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Customer Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
              <h3 className="font-bold text-base text-white">إضافة عميل جديد</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم العميل أو المؤسسة:
                </label>
                <input
                  type="text"
                  required
                  value={newCust.name}
                  onChange={(e) => setNewCust({ ...newCust, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  placeholder="مثال: فهد بن عبد العزيز"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  رقم الهاتف / الجوال:
                </label>
                <input
                  type="text"
                  required
                  value={newCust.phone}
                  onChange={(e) => setNewCust({ ...newCust, phone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                  placeholder="05xxxxxxxx"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  البريد الإلكتروني (اختياري):
                </label>
                <input
                  type="email"
                  value={newCust.email}
                  onChange={(e) => setNewCust({ ...newCust, email: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  رصيد سابق / مديونية افتتاحية:
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={newCust.balance}
                  onChange={(e) =>
                    setNewCust({ ...newCust, balance: parseFloat(e.target.value) || 0 })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">ملاحظات:</label>
                <input
                  type="text"
                  value={newCust.notes}
                  onChange={(e) => setNewCust({ ...newCust, notes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  placeholder="حد الائتمان أو شروط الدفع..."
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2 text-xs font-medium bg-slate-800 text-slate-400 rounded-xl hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md transition"
                >
                  حفظ العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Settle Debt Payment Modal */}
      {isPaymentModalOpen && activeCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <h3 className="font-bold text-base text-white mb-1">سند قبض وتخفيض مديونية</h3>
            <p className="text-xs text-slate-400 mb-3">{activeCustomer.name}</p>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 mb-4 text-xs">
              <div className="flex justify-between mb-1 text-slate-400">
                <span>الرصيد الحالي المستحق:</span>
                <span className="font-bold font-mono text-amber-400">
                  {activeCustomer.balance.toFixed(2)} {settings.currency}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>الرصيد المتبقي بعد السداد:</span>
                <span className="font-bold font-mono text-emerald-400">
                  {Math.max(0, activeCustomer.balance - payAmount).toFixed(2)} {settings.currency}
                </span>
              </div>
            </div>

            <form onSubmit={handleSettlePayment} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  المبلغ المسدد:
                </label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">بيان السداد:</label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="flex-1 py-2 text-xs font-medium bg-slate-800 text-slate-400 rounded-xl hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-md transition"
                >
                  تسجيل السداد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
