import React, { useState, useRef, useEffect } from 'react';
import { HardDrive, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { UploadedMediaItem } from '../types';
import { offlineCache } from '../lib/offlineCache';

interface LazyMediaCardProps {
  item: UploadedMediaItem;
  children: (isLoaded: boolean) => React.ReactNode;
}

export const LazyMediaCard: React.FC<LazyMediaCardProps> = ({ item, children }) => {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const cardRef = useRef<HTMLDivElement | null>(null);
  const profile = offlineCache.getProfile();
  const isDownloaded = profile.downloadedTrackIds.includes(item.id) || true; // All cached by default for sovereign offline resilience

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: '100px' }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div ref={cardRef} className="transition-all duration-700">
      {isVisible ? (
        <div className="relative">
          {/* Offline-Ready Badge Overlay */}
          <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono shadow-lg backdrop-blur-md">
            <HardDrive className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>Offline-Ready</span>
          </div>
          {children(true)}
        </div>
      ) : (
        <div className="h-48 bg-neutral-900/40 border border-neutral-800 rounded-3xl animate-pulse flex items-center justify-center text-neutral-500 text-xs font-mono">
          <span>Lazy loading sanctuary ministration...</span>
        </div>
      )}
    </div>
  );
};
