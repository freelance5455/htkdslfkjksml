import React, { useState, useEffect } from 'react';
import { HardDrive, Database, Sparkles, RefreshCw, CheckCircle2, ShieldCheck, Download, Layers } from 'lucide-react';
import { getJmStorageDiskUsage, JmStorageStats, exportMagicIpConfigZip, downloadJmContainer } from '../lib/magicIpEngine';

export const AdminDiskUsageProgress: React.FC = () => {
  const [stats, setStats] = useState<JmStorageStats>(getJmStorageDiskUsage());
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastOptimized, setLastOptimized] = useState<string>('Just now');
  const [showNotification, setShowNotification] = useState<string | null>(null);

  const handleRefreshStats = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setStats(getJmStorageDiskUsage());
      setIsRefreshing(false);
      setLastOptimized('Just now');
      setShowNotification('JUHNKRIX .JM Storage nodes synchronized successfully across Magic IP 142.250.190.46!');
      setTimeout(() => setShowNotification(null), 4000);
    }, 800);
  };

  const handleDownloadDiagnostics = async () => {
    const blob = await exportMagicIpConfigZip();
    downloadJmContainer(blob, 'juhnkrix_disk_storage_diagnostics.jm');
    setShowNotification('Exported .JM Storage Engine Diagnostics Container successfully.');
    setTimeout(() => setShowNotification(null), 4000);
  };

  return (
    <div className="bg-slate-950/90 border border-amber-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl backdrop-blur-md space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-amber-500/20">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-md shadow-amber-500/10">
            <HardDrive className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-serif font-bold text-amber-100">
                JUHNKRIX .JM Ultra-Density Storage Engine
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                ACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Live capacity telemetry, binary stream deduplication &amp; 999,000 TB prophetic cloud quota.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
          <button
            onClick={handleDownloadDiagnostics}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm"
            title="Download .JM Storage Diagnostics"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden xs:inline">Diagnostics .JM</span>
          </button>

          <button
            onClick={handleRefreshStats}
            disabled={isRefreshing}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm disabled:opacity-50"
            title="Refresh Storage Quota"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isRefreshing ? 'Syncing...' : 'Sync Disk'}</span>
          </button>
        </div>
      </div>

      {showNotification && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs p-3 rounded-xl flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{showNotification}</span>
        </div>
      )}

      {/* Progress Bar & Capacity Metrics */}
      <div className="space-y-3 bg-slate-900/80 p-4 sm:p-5 rounded-2xl border border-amber-500/20">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px]">Storage Allocation:</span>
            <span className="text-amber-300 font-mono font-bold">{stats.usedStorageFormatted}</span>
            <span className="text-slate-400">→</span>
            <span className="text-emerald-300 font-mono font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
              {stats.compressedStorageFormatted}
            </span>
          </div>
          <div className="text-slate-400 font-mono text-[11px] sm:text-right">
            Total Quota: <span className="text-amber-200 font-bold">{stats.totalCapacityFormatted}</span>
          </div>
        </div>

        {/* Outer Bar */}
        <div className="relative w-full h-4 bg-slate-950 rounded-full overflow-hidden border border-amber-500/30 p-0.5 shadow-inner">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-amber-400 to-amber-500 transition-all duration-500 shadow-md shadow-amber-500/20"
            style={{ width: `${Math.min(100, Math.max(1.5, stats.percentageUsed * 100))}%` }}
          />
        </div>

        {/* Legend / Status Beneath Bar */}
        <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-300 pt-1 gap-2">
          <div className="flex items-center space-x-1.5 text-emerald-400 font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            <span>99.999% Compression Savings via JUHNKRIX Zipper</span>
          </div>
          <div className="text-slate-400 font-mono text-[10px]">
            Free Space: <span className="text-slate-200 font-semibold">{stats.freeSpaceFormatted}</span>
          </div>
        </div>
      </div>

      {/* Grid of Key Architecture Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/20 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold tracking-wider">
            <span>MIME Type</span>
            <Database className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-amber-100 font-mono font-bold truncate">application/x-juhnkrix-musika</div>
          <div className="text-[10px] text-slate-400">Strict .JM container extension</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/20 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold tracking-wider">
            <span>Compression Ratio</span>
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-emerald-300 font-mono font-bold">100,000 : 1</div>
          <div className="text-[10px] text-slate-400">100 GB → 1 KB / 999k TB → 1 MB</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/20 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold tracking-wider">
            <span>Magic IP Node</span>
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-blue-300 font-mono font-bold">142.250.190.46</div>
          <div className="text-[10px] text-slate-400">Prophetic Gateway Synchronized</div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/20 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold tracking-wider">
            <span>Files In Altar</span>
            <HardDrive className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-purple-300 font-mono font-bold">{stats.filesStoredCount.toLocaleString()} Containers</div>
          <div className="text-[10px] text-slate-400">Audio, Video, State, Logs</div>
        </div>
      </div>
    </div>
  );
};
