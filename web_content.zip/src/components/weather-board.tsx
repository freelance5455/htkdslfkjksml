import { useEffect, useId, useRef, useState } from "react";
import { Droplets, LocateFixed, MapPin, Search, Wind } from "lucide-react";
import { CAPITALS, placeFromCoords, savePlace, searchPlaces, type Place } from "@/lib/places";
import { clockParts } from "@/lib/time";
import { describeSky, type Forecast } from "@/lib/weather";
import { getForecast } from "@/lib/get-forecast";

type Props = {
  place: Place;
  onPlace: (place: Place) => void;
  now: Date | null;
};

export function WeatherBoard({ place, onPlace, now }: Props) {
  const [forecast, setForecast] = useState<Forecast | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Place[]>([]);
  const [searching, setSearching] = useState(false);
  const [locating, setLocating] = useState(false);
  const [locateError, setLocateError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const panelRef = useRef<HTMLDivElement>(null);
  const listId = useId();

  useEffect(() => {
    const controller = new AbortController();
    setStatus("loading");
    getForecast({
      data: { latitude: place.latitude, longitude: place.longitude, timezone: place.timezone },
      signal: controller.signal,
    })
      .then((data) => {
        setForecast(data);
        setStatus("ready");
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setStatus("error");
      });
    return () => controller.abort();
  }, [place.latitude, place.longitude, attempt]);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setSearching(false);
      return;
    }
    const controller = new AbortController();
    setSearching(true);
    const timer = window.setTimeout(() => {
      searchPlaces(trimmed, controller.signal)
        .then((places) => {
          setResults(places);
          setSearching(false);
        })
        .catch((error: unknown) => {
          if (error instanceof DOMException && error.name === "AbortError") return;
          setResults([]);
          setSearching(false);
        });
    }, 280);
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [query]);

  useEffect(() => {
    if (!open) return;
    function onPointer(event: MouseEvent) {
      if (!panelRef.current?.contains(event.target as Node)) setOpen(false);
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("mousedown", onPointer);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onPointer);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  function choose(next: Place) {
    savePlace(next);
    onPlace(next);
    setOpen(false);
    setQuery("");
    setLocateError("");
  }

  function locate() {
    if (!navigator.geolocation) {
      setLocateError("Este navegador não informa a localização.");
      return;
    }
    setLocating(true);
    setLocateError("");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        placeFromCoords(position.coords.latitude, position.coords.longitude)
          .then((found) => {
            choose(found);
            setLocating(false);
          })
          .catch(() => {
            setLocating(false);
            setLocateError("Não achei o nome desse lugar.");
          });
      },
      () => {
        setLocating(false);
        setLocateError("Permissão de localização negada.");
      },
      { enableHighAccuracy: false, timeout: 8000 },
    );
  }

  const sky = forecast ? describeSky(forecast.current.sky) : null;
  const SkyIcon = sky?.icon;
  const there =
    forecast && now && forecast.timezone !== "America/Sao_Paulo" ? clockParts(now, forecast.timezone) : null;
  const suggestions = query.trim().length >= 2 ? results : CAPITALS.slice(0, 8);

  return (
    <section className="rounded-card border border-line bg-card p-5 shadow-card sm:p-7">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">Clima</p>
          <h2 className="mt-1 text-3xl leading-none text-ink">Onde você quer olhar</h2>
        </div>
        <div className="relative" ref={panelRef}>
          <button
            type="button"
            className="flex min-h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm font-medium text-ink"
            aria-expanded={open}
            aria-controls={listId}
            onClick={() => setOpen((value) => !value)}
          >
            <MapPin className="size-4 text-clay" aria-hidden="true" />
            {place.name}
            {place.admin ? <span className="text-muted">{place.admin}</span> : null}
          </button>
          {open ? (
            <div className="absolute right-0 z-20 mt-2 w-72 rounded-2xl border border-line bg-card p-3 shadow-card">
              <label className="flex items-center gap-2 rounded-xl border border-line bg-paper px-3">
                <Search className="size-4 text-muted" aria-hidden="true" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Buscar cidade"
                  className="h-11 w-full bg-transparent text-sm text-ink outline-none placeholder:text-muted"
                  autoFocus
                />
              </label>
              <button
                type="button"
                className="mt-2 flex min-h-11 w-full items-center gap-2 rounded-xl px-3 text-left text-sm font-medium text-forest hover:bg-paper"
                onClick={locate}
              >
                <LocateFixed className="size-4" aria-hidden="true" />
                {locating ? "Localizando…" : "Usar minha localização"}
              </button>
              {locateError ? <p className="px-3 pt-1 text-sm text-clay">{locateError}</p> : null}
              <ul id={listId} className="mt-2 max-h-64 overflow-auto" role="listbox">
                {searching ? <li className="px-3 py-2 text-sm text-muted">Buscando…</li> : null}
                {!searching && query.trim().length >= 2 && suggestions.length === 0 ? (
                  <li className="px-3 py-2 text-sm text-muted">Nenhuma cidade com esse nome.</li>
                ) : null}
                {suggestions.map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      className="flex min-h-11 w-full items-center justify-between rounded-xl px-3 text-left text-sm hover:bg-paper"
                      onClick={() => choose(item)}
                    >
                      <span className="font-medium text-ink">{item.name}</span>
                      <span className="text-muted">{item.admin}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </div>

      {status === "error" ? (
        <div className="mt-6 rounded-2xl bg-paper px-4 py-5">
          <p className="font-medium text-ink">O clima não respondeu agora.</p>
          <p className="mt-1 text-sm text-muted">
            A previsão às vezes demora ou pede uma pausa. A cidade continua salva.
          </p>
          <button
            type="button"
            className="mt-3 min-h-11 rounded-full bg-ink px-4 text-sm font-medium text-paper"
            onClick={() => setAttempt((value) => value + 1)}
          >
            Tentar de novo
          </button>
        </div>
      ) : null}

      {status === "loading" ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-5" aria-hidden="true">
          <div className="h-28 rounded-2xl bg-paper sm:col-span-2" />
          <div className="h-28 rounded-2xl bg-paper sm:col-span-3" />
        </div>
      ) : null}

      {status === "ready" && forecast && sky && SkyIcon ? (
        <>
          <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="flex size-16 items-center justify-center rounded-3xl bg-paper text-clay">
                <SkyIcon className="size-8" aria-hidden="true" />
              </span>
              <div>
                <p className="font-display text-6xl leading-none text-ink tabular-nums">
                  {forecast.current.temperature}°
                </p>
                <p className="mt-1 text-ink">{sky.label}</p>
              </div>
            </div>
            <ul className="flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted">
              <li>Sensação {forecast.current.apparent}°</li>
              <li className="inline-flex items-center gap-1">
                <Droplets className="size-4" aria-hidden="true" />
                {forecast.current.humidity}%
              </li>
              <li className="inline-flex items-center gap-1">
                <Wind className="size-4" aria-hidden="true" />
                {forecast.current.wind} km/h
              </li>
              {there ? (
                <li className="tabular-nums">
                  Lá são {there.hour}:{there.minute}
                </li>
              ) : null}
            </ul>
          </div>

          <ol className="mt-6 grid grid-cols-5 gap-2">
            {forecast.daily.map((day, index) => {
              const daySky = describeSky(day.sky);
              const DayIcon = daySky.icon;
              const label =
                index === 0
                  ? "Hoje"
                  : new Intl.DateTimeFormat("pt-BR", { weekday: "short" })
                      .format(new Date(`${day.date}T12:00:00`))
                      .replace(".", "");
              return (
                <li key={day.date} className="rounded-2xl bg-paper px-2 py-3 text-center">
                  <p className="text-xs font-medium text-muted capitalize">{label}</p>
                  <DayIcon className="mx-auto mt-2 size-5 text-forest" aria-hidden="true" />
                  <p className="mt-2 text-sm font-medium text-ink tabular-nums">{day.max}°</p>
                  <p className="text-xs text-muted tabular-nums">{day.min}°</p>
                  <p className="text-xs text-muted tabular-nums">{day.rainMm > 0 ? `${day.rainMm} mm` : "seco"}</p>
                </li>
              );
            })}
          </ol>
          <p className="mt-4 text-xs text-muted">Previsão de {forecast.source}. Chuva do dia em milímetros.</p>
        </>
      ) : null}
    </section>
  );
}
