import React from 'react';
import { NumeralSystem, Language } from '../types/calculator';
import { urduDigitsMap } from '../utils/math';

interface KeypadProps {
  onDigit: (digit: string) => void;
  onOperator: (op: '+' | '-' | '×' | '÷') => void;
  onDecimal: () => void;
  onPercent: () => void;
  onParenthesis: () => void;
  onToggleSign: () => void;
  onClear: () => void;
  onEquals: () => void;
  numeralSystem: NumeralSystem;
  language: Language;
  activeKey?: string | null;
}

export const Keypad: React.FC<KeypadProps> = ({
  onDigit,
  onOperator,
  onDecimal,
  onPercent,
  onParenthesis,
  onToggleSign,
  onClear,
  onEquals,
  numeralSystem,
  language,
  activeKey,
}) => {
  const isUrdu = language === 'ur';

  // Render a digit with both Western and Eastern characters
  const renderDigitLabel = (d: string) => {
    const urduDigit = urduDigitsMap[d] || d;
    if (numeralSystem === 'eastern') {
      return (
        <div className="flex flex-col items-center justify-center leading-none">
          <span className="text-2xl font-bold font-urdu">{urduDigit}</span>
          <span className="text-[10px] text-slate-400 font-mono mt-0.5">{d}</span>
        </div>
      );
    }
    return (
      <div className="flex flex-col items-center justify-center leading-none">
        <span className="text-2xl font-bold font-mono">{d}</span>
        <span className="text-[10px] text-slate-400 font-urdu mt-0.5">{urduDigit}</span>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-4 gap-2.5 sm:gap-3 w-full select-none">
      {/* Row 1: AC, ( ), %, ÷ */}
      <button
        type="button"
        onClick={onClear}
        className={`h-14 sm:h-16 rounded-2xl font-semibold text-rose-400 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-900/50 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-rose-500 ${
          activeKey === 'Escape' || activeKey === 'c' ? 'ring-2 ring-rose-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'تمام صاف کریں' : 'All Clear'}
      >
        <span className="text-lg font-bold">AC</span>
        <span className="text-[9px] text-rose-300/80 font-urdu">{isUrdu ? 'صاف' : 'Clear'}</span>
      </button>

      <button
        type="button"
        onClick={onParenthesis}
        className={`h-14 sm:h-16 rounded-2xl font-semibold text-slate-200 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '(' || activeKey === ')' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'قوسین / بریکٹ' : 'Parentheses'}
      >
        <span className="text-lg font-mono font-bold">( )</span>
        <span className="text-[9px] text-slate-400 font-urdu">{isUrdu ? 'قوسین' : 'Parens'}</span>
      </button>

      <button
        type="button"
        onClick={onPercent}
        className={`h-14 sm:h-16 rounded-2xl font-semibold text-slate-200 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '%' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'فیصد' : 'Percentage'}
      >
        <span className="text-xl font-bold font-mono">%</span>
        <span className="text-[9px] text-slate-400 font-urdu">{isUrdu ? 'فیصد' : 'Percent'}</span>
      </button>

      <button
        type="button"
        onClick={() => onOperator('÷')}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/50 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '/' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'تقسیم' : 'Divide'}
      >
        <span className="text-2xl font-bold font-mono">÷</span>
        <span className="text-[9px] text-amber-400/80 font-urdu">{isUrdu ? 'تقسیم' : 'Divide'}</span>
      </button>

      {/* Row 2: 7, 8, 9, × */}
      <button
        type="button"
        onClick={() => onDigit('7')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '7' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('7')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('8')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '8' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('8')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('9')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '9' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('9')}
      </button>

      <button
        type="button"
        onClick={() => onOperator('×')}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/50 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '*' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'ضرب' : 'Multiply'}
      >
        <span className="text-2xl font-bold font-mono">×</span>
        <span className="text-[9px] text-amber-400/80 font-urdu">{isUrdu ? 'ضرب' : 'Multiply'}</span>
      </button>

      {/* Row 3: 4, 5, 6, - */}
      <button
        type="button"
        onClick={() => onDigit('4')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '4' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('4')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('5')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '5' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('5')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('6')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '6' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('6')}
      </button>

      <button
        type="button"
        onClick={() => onOperator('-')}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/50 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '-' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'تفریق' : 'Subtract'}
      >
        <span className="text-2xl font-bold font-mono">−</span>
        <span className="text-[9px] text-amber-400/80 font-urdu">{isUrdu ? 'تفریق' : 'Subtract'}</span>
      </button>

      {/* Row 4: 1, 2, 3, + */}
      <button
        type="button"
        onClick={() => onDigit('1')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '1' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('1')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('2')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '2' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('2')}
      </button>

      <button
        type="button"
        onClick={() => onDigit('3')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '3' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('3')}
      </button>

      <button
        type="button"
        onClick={() => onOperator('+')}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/50 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '+' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'جمع' : 'Add'}
      >
        <span className="text-2xl font-bold font-mono">+</span>
        <span className="text-[9px] text-amber-400/80 font-urdu">{isUrdu ? 'جمع' : 'Add'}</span>
      </button>

      {/* Row 5: ±, 0, ., = */}
      <button
        type="button"
        onClick={onToggleSign}
        className="h-14 sm:h-16 rounded-2xl font-semibold text-slate-200 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500"
        aria-label={isUrdu ? 'مثبت یا منفی علامت' : 'Toggle positive or negative'}
      >
        <span className="text-xl font-bold font-mono">±</span>
        <span className="text-[9px] text-slate-400 font-urdu">{isUrdu ? 'علامت' : 'Sign'}</span>
      </button>

      <button
        type="button"
        onClick={() => onDigit('0')}
        className={`h-14 sm:h-16 rounded-2xl text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '0' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
      >
        {renderDigitLabel('0')}
      </button>

      <button
        type="button"
        onClick={onDecimal}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-slate-100 bg-slate-800/50 hover:bg-slate-700/60 border border-slate-700/40 shadow-sm active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-500 ${
          activeKey === '.' ? 'ring-2 ring-amber-400 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'اشاریہ' : 'Decimal point'}
      >
        <span className="text-2xl font-bold font-mono">.</span>
        <span className="text-[9px] text-slate-400 font-urdu">{isUrdu ? 'اشاریہ' : 'Point'}</span>
      </button>

      <button
        type="button"
        onClick={onEquals}
        className={`h-14 sm:h-16 rounded-2xl font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 shadow-md active:scale-95 transition-all flex flex-col items-center justify-center focus-visible:ring-2 focus-visible:ring-amber-300 ${
          activeKey === 'Enter' || activeKey === '=' ? 'ring-4 ring-amber-300/80 scale-95' : ''
        }`}
        aria-label={isUrdu ? 'برابر ہے' : 'Equals'}
      >
        <span className="text-3xl font-extrabold font-mono leading-none">=</span>
        <span className="text-[10px] text-slate-900/90 font-bold font-urdu mt-0.5">{isUrdu ? 'برابر' : 'Equals'}</span>
      </button>
    </div>
  );
};
