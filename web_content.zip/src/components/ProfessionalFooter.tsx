import React, { useState, useEffect, useRef } from 'react';
import { Facebook, Twitter, Instagram, Share2, Wallet, BookOpen, Keyboard, Check, Move, ZoomOut, ZoomIn, X, HeartHandshake, Link2, ExternalLink, MessageSquare, Phone, Video, Mic, Send, UserPlus, Maximize2, ShieldCheck, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Home, ArrowLeft, ArrowRight, Compass, Download, Copy, Sparkles, Globe } from 'lucide-react';
import { Track } from '../types';

interface ProfessionalFooterProps {
  currentTrack: Track;
  lowPowerMode: boolean;
  setLowPowerMode: (val: boolean) => void;
  onOpenTextMessages?: () => void;
  onOpenWhatsApp?: () => void;
  onOpenDownloads?: () => void;
  onOpenSignup?: () => void;
  onOpenAdmin?: () => void;
  onHome?: () => void;
  onPrevPage?: () => void;
  onNextPage?: () => void;
  onOpenNonWebbaseMode?: () => void;
}

export const ProfessionalFooter: React.FC<ProfessionalFooterProps> = ({ 
  currentTrack, 
  lowPowerMode, 
  setLowPowerMode, 
  onOpenTextMessages,
  onOpenWhatsApp,
  onOpenDownloads,
  onOpenSignup,
  onOpenAdmin,
  onHome,
  onPrevPage,
  onNextPage,
  onOpenNonWebbaseMode
}) => {
  const [showScripture, setShowScripture] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [integrationStatus, setIntegrationStatus] = useState<string | null>(null);
  const [referralToast, setReferralToast] = useState<string | null>(null);
  const footerScrollRef = useRef<HTMLDivElement>(null);

  const handleCopyReferralLink = async () => {
    try {
      const origin = typeof window !== 'undefined' ? window.location.origin : '';
      const refCode = Math.random().toString(36).substring(2, 8);
      const referralLink = `${origin}/?ref=juhnkrix_${refCode}`;
      await navigator.clipboard.writeText(referralLink);
      setReferralToast(`✓ JUHNKRIX MUSIKA Referral Link Copied!\n${referralLink}\nShare this link to invite brethren to the Prophetic Sanctuary.`);
      setTimeout(() => {
        setReferralToast(null);
      }, 4500);
    } catch (err) {
      const fallback = `/?ref=juhnkrix_musika_blessed`;
      setReferralToast(`✓ Referral Link: ${fallback}`);
      setTimeout(() => setReferralToast(null), 4500);
    }
  };

  const handleScrollUp = () => {
    window.scrollBy({ top: -450, behavior: 'smooth' });
    const mainEl = document.querySelector('main');
    if (mainEl) mainEl.scrollBy({ top: -450, behavior: 'smooth' });
  };

  const handleScrollDown = () => {
    window.scrollBy({ top: 450, behavior: 'smooth' });
    const mainEl = document.querySelector('main');
    if (mainEl) mainEl.scrollBy({ top: 450, behavior: 'smooth' });
  };

  const handleScrollLeft = () => {
    if (footerScrollRef.current) {
      footerScrollRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
    window.scrollBy({ left: -300, behavior: 'smooth' });
    const scrollContainers = document.querySelectorAll('.overflow-x-auto');
    scrollContainers.forEach(el => el.scrollBy({ left: -300, behavior: 'smooth' }));
  };

  const handleScrollRight = () => {
    if (footerScrollRef.current) {
      footerScrollRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
    window.scrollBy({ left: 300, behavior: 'smooth' });
    const scrollContainers = document.querySelectorAll('.overflow-x-auto');
    scrollContainers.forEach(el => el.scrollBy({ left: 300, behavior: 'smooth' }));
  };

  const checkMemberAndOpen = (action?: () => void) => {
    const isMember = localStorage.getItem('juhnkrix_registered_member') === 'true';
    if (isMember) {
      if (action) action();
    } else {
      alert("You are not a registered member of the JUHNKRIX MUSIKA, please click on the signups icon button below and get into the registration page to register as a member");
      if (onOpenSignup) onOpenSignup();
    }
  };

  
  const [userCountry, setUserCountry] = useState('Detecting...');
  const [localWallets, setLocalWallets] = useState<{id: string, name: string, initials: string, color: string, textColor: string, bgColor: string, deepLink: string}[]>([]);
  const [modalZoom, setModalZoom] = useState(1);
  
  // Social navigation state
  const [socialNavigation, setSocialNavigation] = useState<{name: string, url: string, color: string, icon: React.ReactNode} | null>(null);

  useEffect(() => {
    if (showSupportModal) {
      setModalZoom(1);
      fetch('https://ipapi.co/json/')
        .then(res => res.json())
        .then(data => {
          const country = data.country_name || 'Global';
          setUserCountry(country);
          if (country === 'Nigeria' || country === 'Ghana' || country === 'Kenya') {
            setLocalWallets([
              { id: 'opay', name: 'Opay Wallet', initials: 'OP', color: 'bg-emerald-500', textColor: 'text-emerald-300', bgColor: 'bg-emerald-950/40 border-emerald-500/30', deepLink: 'opay://' },
              { id: 'palmpay', name: 'PalmPay', initials: 'PP', color: 'bg-purple-500', textColor: 'text-purple-300', bgColor: 'bg-purple-950/40 border-purple-500/30', deepLink: 'palmpay://' },
              { id: 'moniepoint', name: 'Moniepoint', initials: 'MP', color: 'bg-blue-500', textColor: 'text-blue-300', bgColor: 'bg-blue-950/40 border-blue-500/30', deepLink: 'moniepoint://' }
            ]);
          } else if (country === 'United States' || country === 'United Kingdom' || country === 'Canada') {
            setLocalWallets([
              { id: 'cashapp', name: 'Cash App', initials: 'CA', color: 'bg-green-500 text-slate-900', textColor: 'text-green-300', bgColor: 'bg-green-950/40 border-green-500/30', deepLink: 'cashme://' },
              { id: 'paypal', name: 'PayPal', initials: 'PP', color: 'bg-blue-600', textColor: 'text-blue-300', bgColor: 'bg-blue-950/40 border-blue-500/30', deepLink: 'paypal://' },
              { id: 'venmo', name: 'Venmo', initials: 'V', color: 'bg-sky-500', textColor: 'text-sky-300', bgColor: 'bg-sky-950/40 border-sky-500/30', deepLink: 'venmo://' }
            ]);
          } else {
            setLocalWallets([
              { id: 'paypal', name: 'PayPal Global', initials: 'PP', color: 'bg-blue-600', textColor: 'text-blue-300', bgColor: 'bg-blue-950/40 border-blue-500/30', deepLink: 'paypal://' },
              { id: 'stripe', name: 'Card Payment', initials: 'CC', color: 'bg-indigo-500', textColor: 'text-indigo-300', bgColor: 'bg-indigo-950/40 border-indigo-500/30', deepLink: 'https://stripe.com' },
              { id: 'crypto', name: 'Crypto (USDT)', initials: 'USDT', color: 'bg-teal-500', textColor: 'text-teal-300', bgColor: 'bg-teal-950/40 border-teal-500/30', deepLink: 'bitcoin://' }
            ]);
          }
        })
        .catch(() => {
          setUserCountry('Global (Fallback)');
          setLocalWallets([
             { id: 'paypal', name: 'PayPal Global', initials: 'PP', color: 'bg-blue-600', textColor: 'text-blue-300', bgColor: 'bg-blue-950/40 border-blue-500/30', deepLink: 'paypal://' },
             { id: 'stripe', name: 'Card Payment', initials: 'CC', color: 'bg-indigo-500', textColor: 'text-indigo-300', bgColor: 'bg-indigo-950/40 border-indigo-500/30', deepLink: 'https://stripe.com' }
          ]);
        });
    }
  }, [showSupportModal]);

  useEffect(() => {
    if (showShareModal || showScripture || socialNavigation) {
      setModalZoom(1);
    }
  }, [showShareModal, showScripture, socialNavigation]);

  const handleShareTrack = () => {
    setShowShareModal(true);
  };

  const handleSocialClick = (name: string, url: string, color: string, icon: React.ReactNode) => {
    setSocialNavigation({ name, url, color, icon });
  };

  return (
    <>
      <div className="w-full bg-slate-900/90 border-t border-amber-500/20 py-2.5 px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
        {/* Left: Copyright */}
        <div className="text-[10px] text-slate-400 font-mono hidden md:flex items-center space-x-2">
          <span>&copy; {new Date().getFullYear()} JUHNKRIX MUSIKA.</span>
          <span className="text-amber-500/50">|</span>
          <a href="#" className="hover:text-amber-300 transition-colors">Privacy</a>
          <span className="text-amber-500/50">|</span>
          <a href="#" className="hover:text-amber-300 transition-colors">Terms</a>
        </div>
        
        {/* Middle: Social Icons & Footer Payment Integration Buttons */}
        <div className="flex flex-col items-center md:items-start space-y-2 mx-auto md:mx-0">
          <div className="flex items-center space-x-3">
            <button onClick={() => handleSocialClick('Facebook', 'https://facebook.com', 'text-blue-500', <Facebook className="w-12 h-12" />)} className="text-slate-400 hover:text-blue-400 transition-colors" title="Follow on Facebook">
              <Facebook className="w-4 h-4" />
            </button>
            <button onClick={() => handleSocialClick('TikTok', 'https://tiktok.com', 'text-slate-100', <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 2.22-1.15 4.38-2.91 5.67-1.6 1.18-3.69 1.52-5.59 1.05-1.9-.47-3.48-1.72-4.32-3.45-.85-1.74-.79-3.83.15-5.52.92-1.65 2.6-2.75 4.49-3.04 1.6-.25 3.23.01 4.63.78v4.14c-.66-.4-1.43-.6-2.2-.55-.77.05-1.52.4-2.06.96-.54.55-.83 1.3-.82 2.07.01.78.3 1.52.84 2.08.54.55 1.3.85 2.07.82.78-.02 1.5-.35 2.03-.91.53-.55.82-1.28.85-2.05.05-3.32.03-6.64.03-9.97z"/></svg>)} className="text-slate-400 hover:text-slate-100 transition-colors" title="Follow us on TikTok">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 2.22-1.15 4.38-2.91 5.67-1.6 1.18-3.69 1.52-5.59 1.05-1.9-.47-3.48-1.72-4.32-3.45-.85-1.74-.79-3.83.15-5.52.92-1.65 2.6-2.75 4.49-3.04 1.6-.25 3.23.01 4.63.78v4.14c-.66-.4-1.43-.6-2.2-.55-.77.05-1.52.4-2.06.96-.54.55-.83 1.3-.82 2.07.01.78.3 1.52.84 2.08.54.55 1.3.85 2.07.82.78-.02 1.5-.35 2.03-.91.53-.55.82-1.28.85-2.05.05-3.32.03-6.64.03-9.97z"/></svg>
            </button>
            <button onClick={() => handleSocialClick('Instagram', 'https://instagram.com', 'text-pink-500', <Instagram className="w-12 h-12" />)} className="text-slate-400 hover:text-pink-400 transition-colors" title="Follow on Instagram">
              <Instagram className="w-4 h-4" />
            </button>
            <button onClick={() => handleSocialClick('X (Twitter)', 'https://twitter.com', 'text-slate-200', <Twitter className="w-12 h-12" />)} className="text-slate-400 hover:text-white transition-colors" title="Follow on X">
              <Twitter className="w-4 h-4" />
            </button>
            <button onClick={() => handleSocialClick('Pinterest', 'https://pinterest.com', 'text-red-500', 
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 0a12 12 0 0 0-4.37 23.17c-.07-.65-.14-1.66.03-2.37.15-.62 1-4.22 1-4.22s-.26-.5-.26-1.25c0-1.17.68-2.04 1.53-2.04.72 0 1.07.54 1.07 1.19 0 .72-.46 1.8-.7 2.8-.2.84.42 1.52 1.25 1.52 1.5 0 2.65-1.58 2.65-3.87 0-2.02-1.45-3.43-3.53-3.43-2.4 0-3.8 1.8-3.8 3.65 0 .72.28 1.5.62 1.92.07.08.08.15.06.24l-.2 .8c-.03.1-.1.13-.19.09-.7-.33-1.15-1.37-1.15-2.2 0-1.78 1.3-3.42 3.73-3.42 1.97 0 3.5 1.4 3.5 3.28 0 1.95-1.23 3.53-2.93 3.53-.57 0-1.1-.3-1.28-.64l-.35 1.32c-.13.48-.47 1.08-.7 1.45A12 12 0 1 0 12 0z"/></svg>
            )} className="text-slate-400 hover:text-red-500 transition-colors" title="Follow on Pinterest">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 0a12 12 0 0 0-4.37 23.17c-.07-.65-.14-1.66.03-2.37.15-.62 1-4.22 1-4.22s-.26-.5-.26-1.25c0-1.17.68-2.04 1.53-2.04.72 0 1.07.54 1.07 1.19 0 .72-.46 1.8-.7 2.8-.2.84.42 1.52 1.25 1.52 1.5 0 2.65-1.58 2.65-3.87 0-2.02-1.45-3.43-3.53-3.43-2.4 0-3.8 1.8-3.8 3.65 0 .72.28 1.5.62 1.92.07.08.08.15.06.24l-.2 .8c-.03.1-.1.13-.19.09-.7-.33-1.15-1.37-1.15-2.2 0-1.78 1.3-3.42 3.73-3.42 1.97 0 3.5 1.4 3.5 3.28 0 1.95-1.23 3.53-2.93 3.53-.57 0-1.1-.3-1.28-.64l-.35 1.32c-.13.48-.47 1.08-.7 1.45A12 12 0 1 0 12 0z"/></svg>
            </button>

            {/* SHARE BUTTON NEXT TO PINTEREST */}
            <button
              onClick={handleShareTrack}
              className="text-slate-400 hover:text-amber-400 transition-colors p-1"
              title="Share Track / App Link"
            >
              {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-amber-400" />}
            </button>

            {/* WHATSAPP BUTTON NEXT TO PINTEREST & SHARE */}
            <button
              onClick={() => checkMemberAndOpen(() => window.open('https://wa.me/2347071918280', '_blank'))}
              className="text-slate-400 hover:text-green-400 transition-colors p-1"
              title="Chat on WhatsApp (+2347071918280)"
            >
              <svg className="w-4 h-4 text-emerald-400 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
            </button>

            {/* LOW POWER MODE TOGGLE NEXT TO WHATSAPP */}
            <button
              onClick={() => setLowPowerMode(!lowPowerMode)}
              className={`p-1 transition-all rounded-lg flex items-center space-x-1 ${
                lowPowerMode
                  ? 'text-amber-300 bg-amber-500/20 shadow-sm border border-amber-400/30'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
              title={lowPowerMode ? 'Low-Power Mode Active (Click for Ethereal Mode)' : 'Switch to Low-Power Mode (Battery Saving)'}
            >
              <span className="text-xs">⚡</span>
            </button>
          </div>
        </div>
        
        {/* Right: Navigation, Directional Scrolling & Core Ministry Action Buttons */}
        <div className="flex flex-wrap items-center justify-center lg:justify-end gap-1.5 sm:gap-2 w-full lg:w-auto">
          
          {/* PRIMARY SANCTUARY NAVIGATION & CORE APP ACTIONS */}
          <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-950/90 p-1 sm:p-1.5 rounded-2xl border border-amber-500/30 shadow-inner">
            {/* HOME ICON BUTTON */}
            <button
              onClick={onHome}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-[10px] sm:text-[11px] flex items-center space-x-1.5 shadow-md shadow-amber-500/20 transition-all hover:scale-105 shrink-0"
              title="Return to JUHNKRIX MUSIKA Worship Home Sanctuary"
            >
              <Home className="w-3.5 h-3.5 text-slate-950" />
              <span>HOME</span>
            </button>

            {/* NON-WEBBASE ICON BUTTON */}
            <button
              onClick={onOpenNonWebbaseMode}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-[10px] sm:text-[11px] flex items-center space-x-1.5 shadow-md shadow-emerald-500/20 transition-all hover:scale-105 shrink-0"
              title="Switch to Non-Webbase Native App Version (Decentralized Device Hardware Engine)"
            >
              <Globe className="w-3.5 h-3.5 text-slate-950 animate-spin-slow" />
              <span>NON-WEBBASE</span>
            </button>

            {/* PREVIOUS PAGE NAVIGATION BUTTON */}
            <button
              onClick={onPrevPage}
              className="px-2 sm:px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border border-amber-500/20 text-[10px] font-bold flex items-center space-x-1 transition-all shrink-0"
              title="Return Back to Previous Page"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">PREV</span>
            </button>

            {/* NEXT PAGE NAVIGATION BUTTON */}
            <button
              onClick={onNextPage}
              className="px-2 sm:px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border border-amber-500/20 text-[10px] font-bold flex items-center space-x-1 transition-all shrink-0"
              title="Go to Next Page"
            >
              <span className="hidden sm:inline">NEXT</span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>

          {/* DIRECTIONAL SCROLLING CLUSTER */}
          <div className="flex items-center space-x-1 bg-slate-950/90 p-1 rounded-2xl border border-amber-500/30 shadow-inner shrink-0">
            <span className="text-[9px] text-amber-400/70 font-mono px-1 font-bold hidden md:inline">SCROLL:</span>
            {/* SCROLL UP BUTTON */}
            <button
              onClick={handleScrollUp}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/40 transition-all"
              title="Scroll Up"
            >
              <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
            </button>

            {/* SCROLL DOWN BUTTON */}
            <button
              onClick={handleScrollDown}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/40 transition-all"
              title="Scroll Down"
            >
              <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
            </button>

            {/* SCROLL LEFT BUTTON */}
            <button
              onClick={handleScrollLeft}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/40 transition-all"
              title="Scroll Left"
            >
              <ChevronLeft className="w-3.5 h-3.5 text-amber-400" />
            </button>

            {/* SCROLL RIGHT BUTTON */}
            <button
              onClick={handleScrollRight}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/40 transition-all"
              title="Scroll Right"
            >
              <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>

          {/* SECONDARY UTILITY & MINISTRY ACTION BUTTONS */}
          <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
            <button
              className="p-1.5 sm:p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 border border-amber-500/20 transition-all relative group hidden sm:block shrink-0"
              title="Keyboard Shortcuts"
            >
              <Keyboard className="w-4 h-4 text-amber-400" />
              <div className="absolute bottom-full right-0 mb-3 hidden group-hover:block w-56 p-3 rounded-xl bg-slate-950 border border-amber-500/40 text-[10px] text-amber-200 shadow-xl z-50 pointer-events-none text-center font-mono">
                <p className="font-bold text-amber-300 mb-1 border-b border-amber-500/20 pb-1">Keyboard Shortcuts</p>
                <p className="mt-1">Space: Play / Pause</p>
                <p>Left / Right Arrows: Prev / Next</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Floating Referral Toast Notification */}
      {referralToast && (
        <div className="fixed bottom-24 left-1/2 transform -translate-x-1/2 z-[300] max-w-md w-[90%] bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 border-2 border-amber-400/80 rounded-2xl p-4 shadow-2xl shadow-amber-500/30 text-amber-100 flex items-start space-x-3 animate-fadeIn">
          <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 shrink-0">
            <Sparkles className="w-5 h-5 animate-spin-slow" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wide">Referral Link Copied</h4>
            <p className="text-xs text-amber-100/90 whitespace-pre-line mt-0.5 leading-relaxed font-mono">
              {referralToast}
            </p>
          </div>
          <button 
            onClick={() => setReferralToast(null)}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Scripture/Word Full Page Overlay */}
      {showScripture && currentTrack.scriptureRef && (
        <div className="fixed inset-0 z-[200] bg-slate-950 overflow-y-auto touch-pan-y touch-pinch-zoom animate-fadeIn">
          {/* Header & Zoom Controls */}
          <div className="sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-400 border border-amber-500/30">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-amber-100">Word & Inspiration</h3>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-900 p-1.5 rounded-full border border-slate-700">
              <button onClick={() => setModalZoom(z => Math.max(0.5, z - 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom Out"><ZoomOut className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <button onClick={() => setModalZoom(z => Math.min(2.5, z + 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom In"><ZoomIn className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <div className="w-px h-5 sm:h-6 bg-slate-700 mx-1"></div>
              <button onClick={() => setShowScripture(false)} className="p-1.5 sm:p-2 hover:text-rose-400 text-slate-400 transition-colors" title="Close"><X className="w-4 h-4 sm:w-5 sm:h-5" /></button>
            </div>
          </div>

          <div 
            className="w-full max-w-4xl mx-auto p-6 sm:p-10 transition-transform origin-top min-h-screen pb-32"
            style={{ transform: `scale(${modalZoom})` }}
          >
            <div className="text-center space-y-6 mb-12">
              <p className="text-sm sm:text-base text-slate-400 uppercase tracking-[0.2em] font-bold">Track Inspiration</p>
              <h2 className="text-2xl sm:text-4xl font-bold text-amber-300 font-serif leading-tight">
                {currentTrack.scriptureRef}
              </h2>
            </div>
            
            <div className="bg-slate-900 border border-amber-500/20 rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/5 rounded-full -translate-x-16 -translate-y-16 blur-2xl"></div>
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full translate-x-16 translate-y-16 blur-2xl"></div>
              
              <p className="text-lg sm:text-2xl text-slate-300 italic font-serif leading-relaxed text-center relative z-10">
                &ldquo;{currentTrack.description}&rdquo;
              </p>
            </div>

            <div className="pt-16 flex flex-col items-center space-y-3 opacity-60">
              <div className="flex items-center text-slate-500">
                <Move className="w-4 h-4 mr-2"/> <span className="text-[10px] sm:text-xs uppercase tracking-widest font-bold">Scroll & Zoom Enabled</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Share Social Modal - Now a Full Page Layout */}
      {showShareModal && (
        <div className="fixed inset-0 z-[200] bg-slate-950 overflow-y-auto touch-pan-y touch-pinch-zoom animate-fadeIn">
          {/* Header & Zoom Controls */}
          <div className="sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-400 border border-amber-500/30">
                <Share2 className="w-5 h-5" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-amber-100">Share This Track</h3>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-900 p-1.5 rounded-full border border-slate-700">
              <button onClick={() => setModalZoom(z => Math.max(0.5, z - 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom Out"><ZoomOut className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <button onClick={() => setModalZoom(z => Math.min(2.5, z + 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom In"><ZoomIn className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <div className="w-px h-5 sm:h-6 bg-slate-700 mx-1"></div>
              <button onClick={() => setShowShareModal(false)} className="p-1.5 sm:p-2 hover:text-rose-400 text-slate-400 transition-colors" title="Close"><X className="w-4 h-4 sm:w-5 sm:h-5" /></button>
            </div>
          </div>

          <div 
            className="w-full max-w-4xl mx-auto p-6 sm:p-10 transition-transform origin-top min-h-screen pb-32"
            style={{ transform: `scale(${modalZoom})` }}
          >
            <div className="text-center space-y-4 mb-10">
              <p className="text-sm sm:text-base text-slate-300">
                Select your preferred social media platform to share <br className="hidden sm:block"/>
                <strong className="text-white text-base sm:text-lg">"{currentTrack.title}"</strong>
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
              <button onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank')} className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-blue-500/50 rounded-2xl flex flex-col items-center justify-center space-y-3 text-blue-400 hover:text-blue-300 transition-all group">
                <Facebook className="w-8 h-8 sm:w-10 sm:h-10 group-hover:scale-110 transition-transform" />
                <span className="text-xs sm:text-sm font-bold text-slate-300">Facebook</span>
              </button>
              <button onClick={() => window.open(`https://www.tiktok.com/`, '_blank')} className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-500/50 rounded-2xl flex flex-col items-center justify-center space-y-3 text-slate-100 hover:text-white transition-all group">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="none" className="w-8 h-8 sm:w-10 sm:h-10 group-hover:scale-110 transition-transform"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 2.22-1.15 4.38-2.91 5.67-1.6 1.18-3.69 1.52-5.59 1.05-1.9-.47-3.48-1.72-4.32-3.45-.85-1.74-.79-3.83.15-5.52.92-1.65 2.6-2.75 4.49-3.04 1.6-.25 3.23.01 4.63.78v4.14c-.66-.4-1.43-.6-2.2-.55-.77.05-1.52.4-2.06.96-.54.55-.83 1.3-.82 2.07.01.78.3 1.52.84 2.08.54.55 1.3.85 2.07.82.78-.02 1.5-.35 2.03-.91.53-.55.82-1.28.85-2.05.05-3.32.03-6.64.03-9.97z"/></svg>
                <span className="text-xs sm:text-sm font-bold text-slate-300">TikTok</span>
              </button>
              <button onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(`Listen to ${currentTrack.title} on JUHNKRIX MUSIKA`)}`, '_blank')} className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-400 rounded-2xl flex flex-col items-center justify-center space-y-3 text-slate-300 hover:text-white transition-all group">
                <Twitter className="w-8 h-8 sm:w-10 sm:h-10 group-hover:scale-110 transition-transform" />
                <span className="text-xs sm:text-sm font-bold text-slate-300">X (Twitter)</span>
              </button>
              <button onClick={() => window.open(`https://instagram.com/`, '_blank')} className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-pink-500/50 rounded-2xl flex flex-col items-center justify-center space-y-3 text-pink-500 hover:text-pink-400 transition-all group">
                <Instagram className="w-8 h-8 sm:w-10 sm:h-10 group-hover:scale-110 transition-transform" />
                <span className="text-xs sm:text-sm font-bold text-slate-300">Instagram</span>
              </button>
              <button onClick={() => window.open(`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(window.location.href)}&description=${encodeURIComponent(`Listen to ${currentTrack.title}`)}`, '_blank')} className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-red-500/50 rounded-2xl flex flex-col items-center justify-center space-y-3 text-red-500 hover:text-red-400 transition-all group">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none" className="w-8 h-8 sm:w-10 sm:h-10 group-hover:scale-110 transition-transform"><path d="M12 0a12 12 0 0 0-4.37 23.17c-.07-.65-.14-1.66.03-2.37.15-.62 1-4.22 1-4.22s-.26-.5-.26-1.25c0-1.17.68-2.04 1.53-2.04.72 0 1.07.54 1.07 1.19 0 .72-.46 1.8-.7 2.8-.2.84.42 1.52 1.25 1.52 1.5 0 2.65-1.58 2.65-3.87 0-2.02-1.45-3.43-3.53-3.43-2.4 0-3.8 1.8-3.8 3.65 0 .72.28 1.5.62 1.92.07.08.08.15.06.24l-.2 .8c-.03.1-.1.13-.19.09-.7-.33-1.15-1.37-1.15-2.2 0-1.78 1.3-3.42 3.73-3.42 1.97 0 3.5 1.4 3.5 3.28 0 1.95-1.23 3.53-2.93 3.53-.57 0-1.1-.3-1.28-.64l-.35 1.32c-.13.48-.47 1.08-.7 1.45A12 12 0 1 0 12 0z"/></svg>
                <span className="text-xs sm:text-sm font-bold text-slate-300">Pinterest</span>
              </button>
            </div>

            <div className="pt-10 max-w-lg mx-auto">
              <button onClick={() => { 
                navigator.clipboard.writeText(`Listen to "${currentTrack.title}" on JUHNKRIX MUSIKA - ${window.location.href}`);
                setCopiedShare(true);
                setTimeout(() => setCopiedShare(false), 2000);
              }} className="w-full p-4 sm:p-5 bg-slate-900 border-2 border-amber-500/20 hover:border-amber-500/40 rounded-2xl flex items-center justify-center space-x-3 text-amber-300 text-sm sm:text-base font-bold transition-all shadow-lg hover:shadow-amber-500/10">
                {copiedShare ? <Check className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-400" /> : <Link2 className="w-5 h-5 sm:w-6 sm:h-6" />}
                <span>{copiedShare ? 'Copied to Clipboard!' : 'Copy Direct Link'}</span>
              </button>
            </div>
            <div className="pt-10 flex justify-center text-slate-500 opacity-60">
               <Move className="w-4 h-4 mr-2"/> <span className="text-[10px] sm:text-xs uppercase tracking-widest font-bold">Scroll & Zoom Enabled</span>
            </div>
          </div>
        </div>
      )}

      {/* Support & Banking Integration Modal - Now a Full Page Layout */}
      {showSupportModal && (
        <div className="fixed inset-0 z-[200] bg-slate-950 overflow-y-auto touch-pan-y touch-pinch-zoom animate-fadeIn">
          {/* Header & Zoom Controls */}
          <div className="sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-400 border border-amber-500/30">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-amber-100">Support The Ministry</h3>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-900 p-1.5 rounded-full border border-slate-700">
              <button onClick={() => setModalZoom(z => Math.max(0.5, z - 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom Out"><ZoomOut className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <button onClick={() => setModalZoom(z => Math.min(2.5, z + 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom In"><ZoomIn className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <div className="w-px h-5 sm:h-6 bg-slate-700 mx-1"></div>
              <button onClick={() => { setShowSupportModal(false); setIntegrationStatus(null); }} className="p-1.5 sm:p-2 hover:text-rose-400 text-slate-400 transition-colors" title="Close"><X className="w-4 h-4 sm:w-5 sm:h-5" /></button>
            </div>
          </div>
          
          <div 
            className="w-full max-w-4xl mx-auto p-6 sm:p-10 transition-transform origin-top min-h-screen pb-32"
            style={{ transform: `scale(${modalZoom})` }}
          >
            <div className="text-center space-y-6 mb-10 max-w-2xl mx-auto">
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                Our AI engines have automatically scanned your location <strong className="text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">({userCountry})</strong>. 
                <br className="hidden sm:block mt-2" />
                Select your local preferred app to securely integrate with the default <span className="font-bold text-amber-400">JUHNKRIX MUSIKA Opay & Fidelity Bank accounts</span> for your donation.
              </p>
            </div>
            
            {!integrationStatus ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 max-w-3xl mx-auto">
                {localWallets.map((wallet) => (
                  <button 
                    key={wallet.id} 
                    onClick={() => {
                      setIntegrationStatus(wallet.id);
                      setTimeout(() => {
                        window.location.href = wallet.deepLink || 'https://';
                      }, 1000);
                    }} 
                    className={`p-6 border rounded-2xl flex flex-col items-center justify-center space-y-4 transition-all group hover:shadow-xl hover:-translate-y-1 ${wallet.bgColor}`}
                  >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center font-bold text-lg group-hover:scale-110 transition-transform shadow-lg ${wallet.color}`}>{wallet.initials}</div>
                    <span className={`text-sm sm:text-base font-bold ${wallet.textColor}`}>{wallet.name}</span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-center space-y-6 max-w-2xl mx-auto animate-fadeIn shadow-2xl">
                <div className="w-16 h-16 rounded-full border-4 border-amber-400 border-t-transparent animate-spin mx-auto shadow-[0_0_15px_rgba(251,191,36,0.3)]" />
                <div className="space-y-3">
                  <h4 className="text-base sm:text-lg font-bold text-amber-400 font-mono">INTEGRATING {integrationStatus.toUpperCase()}...</h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
                    Establishing secure bridge from <span className="text-amber-200 font-bold">{localWallets.find(w => w.id === integrationStatus)?.name}</span> to Prophet Juhnkrix default accounts. 
                  </p>
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[10px] sm:text-xs font-mono text-slate-400 mt-4">
                    <span className="text-amber-500/60">Routing sequence:</span><br/>
                    Opay Primary <span className="text-amber-500/50">➔</span> Fidelity Fallback <span className="text-amber-500/50">➔</span> Moniepoint MFB Net.
                  </div>
                </div>
                <button onClick={() => setIntegrationStatus(null)} className="text-xs sm:text-sm text-amber-500/60 hover:text-amber-400 hover:underline pt-4 transition-colors">Cancel Integration</button>
              </div>
            )}

            <div className="pt-16 flex flex-col items-center space-y-3 opacity-60">
              <div className="text-[10px] sm:text-xs text-slate-400 uppercase tracking-[0.2em] font-bold">
                Secured by Juhnkrix AI Financial Engine
              </div>
              <div className="flex items-center text-slate-500">
                <Move className="w-4 h-4 mr-2"/> <span className="text-[10px] sm:text-xs uppercase tracking-widest font-bold">Scroll & Zoom Enabled</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Social Navigation Full Page Overlay */}
      {socialNavigation && (
        <div className="fixed inset-0 z-[200] bg-slate-950 overflow-y-auto touch-pan-y touch-pinch-zoom animate-fadeIn">
          {/* Header & Zoom Controls */}
          <div className="sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center border border-slate-700">
                <Share2 className="w-5 h-5 text-slate-300" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-slate-100">Ministry Network</h3>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-900 p-1.5 rounded-full border border-slate-700">
              <button onClick={() => setModalZoom(z => Math.max(0.5, z - 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom Out"><ZoomOut className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <button onClick={() => setModalZoom(z => Math.min(2.5, z + 0.1))} className="p-1.5 sm:p-2 hover:text-amber-400 text-slate-400 transition-colors" title="Zoom In"><ZoomIn className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <div className="w-px h-5 sm:h-6 bg-slate-700 mx-1"></div>
              <button onClick={() => setSocialNavigation(null)} className="p-1.5 sm:p-2 hover:text-rose-400 text-slate-400 transition-colors" title="Close"><X className="w-4 h-4 sm:w-5 sm:h-5" /></button>
            </div>
          </div>
          
          <div 
            className="w-full max-w-4xl mx-auto p-6 sm:p-10 transition-transform origin-top min-h-screen pb-32 flex flex-col items-center justify-center"
            style={{ transform: `scale(${modalZoom})` }}
          >
            <div className={`w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mb-8 shadow-2xl ${socialNavigation.color}`}>
              {socialNavigation.icon}
            </div>
            
            <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4 text-center">
              Join Us On <span className={socialNavigation.color}>{socialNavigation.name}</span>
            </h2>
            
            <p className="text-slate-400 text-center max-w-lg mb-10 text-sm sm:text-base leading-relaxed">
              Connect with Juhnkrix Musika and our ministry network on {socialNavigation.name} for daily inspiration, updates, and more.
            </p>
            
            <button 
              onClick={() => window.open(socialNavigation.url, '_blank')}
              className="flex items-center space-x-3 px-8 py-4 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-full transition-all group hover:scale-105 hover:shadow-xl"
            >
              <span className="text-white font-bold text-lg">Continue to {socialNavigation.name}</span>
              <ExternalLink className="w-5 h-5 text-slate-400 group-hover:text-white" />
            </button>
            
            <button 
              onClick={() => setSocialNavigation(null)}
              className="mt-6 text-slate-500 hover:text-slate-300 text-sm underline transition-colors"
            >
              Cancel Navigation
            </button>
          </div>
        </div>
      )}
    </>
  );
};
