import React, { useState } from 'react';
import {
  X,
  HardDrive,
  ShieldCheck,
  Download,
  Upload,
  Trash2,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { ChatSession, StorageStats } from '../types/index.ts';
import {
  exportAllDataAsJSON,
  importDataFromJSON,
  exportSessionAsMarkdown,
  downloadFile,
} from '../utils/storage.ts';

interface StorageModalProps {
  isOpen: boolean;
  onClose: () => void;
  storageStats: StorageStats;
  currentSession: ChatSession | null;
  onRefreshData: () => void;
  onClearAllData: () => void;
}

export const StorageModal: React.FC<StorageModalProps> = ({
  isOpen,
  onClose,
  storageStats,
  currentSession,
  onRefreshData,
  onClearAllData,
}) => {
  const [importMode, setImportMode] = useState<'merge' | 'overwrite'>('merge');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  if (!isOpen) return null;

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // Full backup JSON export
  const handleExportAllJSON = () => {
    const jsonStr = exportAllDataAsJSON();
    const dateStr = new Date().toISOString().slice(0, 10);
    downloadFile(jsonStr, `nexusai_backup_${dateStr}.json`, 'application/json');
    setStatusMessage({
      type: 'success',
      text: 'Semua riwayat percakapan dan pengaturan berhasil diekspor ke file JSON.',
    });
  };

  // Current session Markdown export
  const handleExportCurrentMarkdown = () => {
    if (!currentSession) return;
    const md = exportSessionAsMarkdown(currentSession);
    const safeTitle = currentSession.title.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
    downloadFile(md, `${safeTitle || 'percakapan'}.md`, 'text/markdown');
    setStatusMessage({
      type: 'success',
      text: `Percakapan "${currentSession.title}" berhasil diunduh sebagai Markdown.`,
    });
  };

  // Handle JSON Import
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = importDataFromJSON(content, importMode);
      if (res.success) {
        setStatusMessage({ type: 'success', text: res.message });
        onRefreshData();
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Manajemen Data &amp; Privasi Lokal</h2>
              <p className="text-xs text-slate-400">
                100% data tersimpan di peramban Anda — Tanpa server database pihak ketiga
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
          {/* Privacy Guarantee Banner */}
          <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-emerald-200 text-xs">Jaminan Privasi Penuh</div>
              <p className="text-emerald-300/80 text-[11px] leading-relaxed mt-0.5">
                Semua sesi percakapan, lampiran gambar, dan konfigurasi parameter Anda disimpan
                langsung di media <code>localStorage</code> peramban Anda. Tidak ada riwayat obrolan
                yang disimpan di server cloud.
              </p>
            </div>
          </div>

          {/* Feedback message banner if any */}
          {statusMessage && (
            <div
              className={`p-3 rounded-xl border flex items-center gap-2 text-xs ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                  : 'bg-rose-950/30 border-rose-800 text-rose-300'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* Storage Meter Stats */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-200">Kapasitas Memori Lokal Digunakan</span>
              <span className="font-mono text-slate-300 font-semibold">
                {formatBytes(storageStats.totalBytes)} / {formatBytes(storageStats.storageQuotaBytes)}
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-sky-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.max(2, storageStats.usagePercentage)}%` }}
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 text-center">
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-850">
                <div className="text-base font-bold text-white font-mono">
                  {storageStats.sessionCount}
                </div>
                <div className="text-[10px] text-slate-400">Total Obrolan Tersimpan</div>
              </div>
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-850">
                <div className="text-base font-bold text-white font-mono">
                  {storageStats.messageCount}
                </div>
                <div className="text-[10px] text-slate-400">Total Pesan Terekam</div>
              </div>
            </div>
          </div>

          {/* Backup & Export Section */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2.5">
            <div className="font-semibold text-slate-200 text-xs">Cadangkan &amp; Ekspor Data</div>
            <p className="text-[11px] text-slate-400">
              Simpan salinan cadangan dari seluruh obrolan dan preferensi Anda.
            </p>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleExportAllJSON}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium shadow-sm transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Cadangan Lengkap (.json)</span>
              </button>

              {currentSession && currentSession.messages.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportCurrentMarkdown}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Ekspor Chat Aktif (.md)</span>
                </button>
              )}
            </div>
          </div>

          {/* Import / Restore Section */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2.5">
            <div className="font-semibold text-slate-200 text-xs">Pulihkan dari File Cadangan</div>
            <p className="text-[11px] text-slate-400">
              Impor kembali file <code>.json</code> cadangan yang pernah Anda unduh sebelumnya.
            </p>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="importMode"
                  checked={importMode === 'merge'}
                  onChange={() => setImportMode('merge')}
                  className="accent-indigo-500"
                />
                <span>Gabungkan (Merge)</span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="importMode"
                  checked={importMode === 'overwrite'}
                  onChange={() => setImportMode('overwrite')}
                  className="accent-indigo-500"
                />
                <span>Timpa Bersih (Overwrite)</span>
              </label>
            </div>

            <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 font-medium transition cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-sky-400" />
              <span>Pilih File Cadangan JSON</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>
          </div>

          {/* Danger Zone: Wipe all data */}
          <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-900/40 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold text-rose-300 text-xs">Zona Hapus Permanen</div>
                <p className="text-[11px] text-rose-400/80">
                  Hapus semua riwayat percakapan dari media penyimpanan peramban ini.
                </p>
              </div>
            </div>

            {!showClearConfirm ? (
              <button
                type="button"
                onClick={() => setShowClearConfirm(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-800/80 text-rose-200 text-xs font-medium transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Kosongkan Semua Data Lokal</span>
              </button>
            ) : (
              <div className="p-3 rounded-lg bg-rose-950/90 border border-rose-700 space-y-2">
                <p className="text-xs text-rose-100 font-medium">
                  Apakah Anda yakin? Tindakan ini akan menghapus permanen seluruh percakapan dan tidak dapat dibatalkan kecuali Anda memiliki file cadangan.
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onClearAllData();
                      setShowClearConfirm(false);
                      setStatusMessage({
                        type: 'success',
                        text: 'Semua percakapan lokal telah berhasil dibersihkan.',
                      });
                    }}
                    className="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    Ya, Hapus Semua Sekarang
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowClearConfirm(false)}
                    className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-800 bg-slate-900 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-white font-medium transition cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
