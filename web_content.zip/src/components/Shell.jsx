import React,{useState} from "react";
import {LayoutDashboard,Film,Workflow,Radio,Users,Shield,Settings,UploadCloud,Rocket,Menu,X,Image as ImageIcon} from "lucide-react";
import {useApp} from "../context/AppContext";
import Dashboard from "./Dashboard";
import PipelineStudio from "./PipelineStudio";
import OwnerApproval from "./OwnerApproval";
import RKCommander from "./RKCommander";

const nav=[["Dashboard",LayoutDashboard],["Video Queue",Film],["Pipeline Studio",Workflow],["Live Output Showcase",Radio],["Social Accounts",Users],["Security",Shield],["Settings",Settings]];
export default function Shell(){
 const {wallpaper,setWallpaper,setMemory}=useApp(); const [page,setPage]=useState("Dashboard"); const [approval,setApproval]=useState(false); const [mobile,setMobile]=useState(false);
 function wallpaperUpload(e){const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>setWallpaper(r.result);r.readAsDataURL(f)}
 function critical(){setApproval(true)}
 return <div className="min-h-screen bg-[#07111f] bg-cover bg-center" style={wallpaper?{backgroundImage:`linear-gradient(rgba(7,17,31,.84),rgba(7,17,31,.94)),url(${wallpaper})`}:{}}>
  <div className="flex min-h-screen">
   <aside className={`${mobile?"fixed inset-y-0 left-0 z-40 w-72":"hidden lg:block w-64"} glass p-4`}>
    <div className="flex items-center justify-between mb-8"><div><div className="font-black">VLOGGER BHAU</div><div className="text-xs text-cyan-300">STUDIO</div></div>{mobile&&<button onClick={()=>setMobile(false)}><X/></button>}</div>
    <div className="space-y-1">{nav.map(([n,I])=><button key={n} onClick={()=>{setPage(n);setMobile(false)}} className={`w-full flex items-center gap-3 p-3 rounded-xl text-sm ${page===n?"bg-cyan-400/10 text-cyan-300":"text-slate-300 hover:bg-white/5"}`}><I size={18}/>{n}</button>)}</div>
    <div className="mt-8 p-4 rounded-2xl bg-black/20"><div className="text-xs text-slate-500">LOCAL ENGINE</div><div className="text-emerald-300 font-bold mt-1">● ONLINE</div><div className="text-[10px] text-slate-500 mt-2">No external inference dependency</div></div>
   </aside>
   <main className="flex-1 min-w-0">
    <header className="sticky top-0 z-30 glass px-4 lg:px-6 py-3 flex items-center gap-3"><button className="lg:hidden" onClick={()=>setMobile(true)}><Menu/></button><div className="flex-1"><div className="font-black">VLOGGER BHAU STUDIO</div><div className="text-[10px] text-slate-500">Proprietary Neural Production Runtime</div></div>
     <label className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 text-xs"><ImageIcon size={15}/>Wallpaper<input onChange={wallpaperUpload} type="file" accept="image/*" className="hidden"/></label>
     <button onClick={critical} className="rounded-xl bg-cyan-400 text-slate-950 font-black px-3 py-2 text-xs"><Rocket className="inline mr-1" size={15}/> START 730-DAY AUTO-PILOT</button>
    </header>
    <section className="p-4 lg:p-6">{page==="Dashboard"&&<Dashboard onInspect={()=>setPage("Live Output Showcase")}/>} {page==="Pipeline Studio"&&<PipelineStudio/>} {page==="Live Output Showcase"&&<Dashboard onInspect={()=>{}}/>} {["Video Queue","Social Accounts","Security","Settings"].includes(page)&&<div className="glass rounded-2xl p-8"><h2 className="text-2xl font-black">{page}</h2><p className="text-slate-400 mt-2">Module shell is active. Critical configuration changes require Owner Approval.</p><button onClick={critical} className="mt-5 rounded-xl bg-cyan-400 text-slate-950 font-bold px-4 py-3">Request Owner Approval</button></div>}</section>
   </main>
  </div>
  <RKCommander onCommand={c=>{if(c==="autopilot")critical();if(c==="outputs")setPage("Live Output Showcase")}}/>
  <OwnerApproval open={approval} onClose={()=>setApproval(false)} onApprove={()=>setMemory(m=>({...m,completed:Math.min(48180,m.completed+3)}))}/>
 </div>
}