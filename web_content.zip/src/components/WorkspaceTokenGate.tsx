import React from 'react';
import { SignInButton } from './SignInButton';

interface WorkspaceTokenGateProps {
  serviceName: string;
  onReconnect: () => void;
  isLoggingIn: boolean;
}

export const WorkspaceTokenGate: React.FC<WorkspaceTokenGateProps> = ({
  serviceName,
  onReconnect,
  isLoggingIn,
}) => {
  return (
    <div className="bg-white border border-orange-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h3 className="text-base font-semibold text-stone-900">
          Sesi Google Workspace Diperlukan untuk {serviceName}
        </h3>
        <p className="text-sm text-stone-600 mt-1 max-w-2xl">
          Demi keamanan, token akses Google Workspace hanya disimpan di memori sesi aktif. Klik tombol di samping untuk memperbarui otorisasi akses {serviceName}.
        </p>
      </div>
      <div className="shrink-0">
        <SignInButton
          onClick={onReconnect}
          disabled={isLoggingIn}
          label={isLoggingIn ? 'Menghubungkan...' : 'Sign in with Google'}
        />
      </div>
    </div>
  );
};
