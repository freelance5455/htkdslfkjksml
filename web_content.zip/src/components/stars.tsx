"use client";

type StarsProps = {
  value: number;
  onChange?: (value: number) => void;
  size?: "sm" | "md" | "lg";
  readOnly?: boolean;
  className?: string;
};

const SIZES: Record<NonNullable<StarsProps["size"]>, string> = {
  sm: "text-[13px]",
  md: "text-lg",
  lg: "text-2xl",
};

export function Stars({ value, onChange, size = "md", readOnly = false, className = "" }: StarsProps) {
  return (
    <div className={`flex items-center gap-0.5 ${className}`} role="group" aria-label="Valutazione">
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= value;
        const content = (
          <span
            className={`${SIZES[size]} leading-none transition-transform ${
              active ? "text-mv-gold drop-shadow-[0_0_6px_rgba(245,197,66,0.55)]" : "text-white/20"
            } ${readOnly ? "" : "group-hover/star:scale-110"}`}
          >
            ★
          </span>
        );

        if (readOnly || !onChange) {
          return (
            <span key={star} className="group/star inline-flex">
              {content}
            </span>
          );
        }

        return (
          <button
            key={star}
            type="button"
            aria-label={`Valuta ${star} stelle`}
            onClick={() => onChange(star === value ? 0 : star)}
            className="group/star inline-flex cursor-pointer p-0.5 transition hover:scale-110 active:scale-95"
          >
            {content}
          </button>
        );
      })}
    </div>
  );
}
