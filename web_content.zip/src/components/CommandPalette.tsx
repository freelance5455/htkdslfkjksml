import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  StickyNote,
  Plus,
  Sparkles,
  Shield,
  FileText,
  Network,
  BookOpen,
  User,
  SlidersHorizontal,
  Sun,
  Moon,
  Trash2,
  Camera,
  Layers,
  Stamp,
  Star,
  CheckSquare,
  Clock,
  Mic,
  FolderKanban,
  Download,
  Palette,
  ArrowRight,
  CornerDownLeft,
  X,
  Lightbulb,
  Settings as SettingsIcon,
  Check
} from "lucide-react";
import { Note, ActiveTab, ThemeAccent, SectionItem } from "../types";
import { ALL_FRAME_PRESETS, FramePreset } from "../utils/frames";
import { THEME_ACCENTS } from "../utils/theme";
import { normalizeTurkishText, matchNoteWithSearch } from "../utils/search";

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  notes: Note[];
  sections?: SectionItem[];
  onOpenNote: (note: Note) => void;
  onNewNote: () => void;
  onOpenDocumentHub: () => void;
  onOpenAIChat: () => void;
  onOpenSideGallery: () => void;
  onOpenTrash: () => void;
  onOpenMindMap: () => void;
  onOpenVault?: () => void;
  onOpenStudy: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenTips: () => void;
  onSelectCategory?: (category: string) => void;
  onSelectSection?: (section: string) => void;
  onToggleDarkMode?: () => void;
  onChangeThemeAccent?: (accent: ThemeAccent) => void;
  themeAccent?: ThemeAccent;
  onSelectFramePreset?: (frame: FramePreset) => void;
}

interface CommandItem {
  id: string;
  category: "Eylemler" | "Görünümler" | "Bölümler" | "Notlar" | "Çerçeveler" | "Ayarlar";
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  action: () => void;
  shortcut?: string;
  badge?: string;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  notes,
  sections = [],
  onOpenNote,
  onNewNote,
  onOpenDocumentHub,
  onOpenAIChat,
  onOpenSideGallery,
  onOpenTrash,
  onOpenMindMap,
  onOpenVault,
  onOpenStudy,
  onOpenProfile,
  onOpenSettings,
  onOpenTips,
  onSelectCategory,
  onSelectSection,
  onToggleDarkMode,
  onChangeThemeAccent,
  themeAccent = "teal",
  onSelectFramePreset,
}) => {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery("");
      setSelectedIndex(0);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Build command items list
  const baseCommands: CommandItem[] = [
    {
      id: "act-new-note",
      category: "Eylemler",
      title: "Yeni Not Oluştur",
      subtitle: "Zengin metin editöründe yeni not başlat",
      icon: <Plus className="w-4 h-4 text-teal-600 dark:text-teal-400" />,
      action: () => {
        onNewNote();
        onClose();
      },
      shortcut: "Ctrl+N",
    },
    {
      id: "act-ai-chat",
      category: "Eylemler",
      title: "NoteFlow Yapay Zeka Asistanı",
      subtitle: "Fikir geliştir, notları özetle veya araştırma yap",
      icon: <Sparkles className="w-4 h-4 text-amber-500" />,
      action: () => {
        onOpenAIChat();
        onClose();
      },
      shortcut: "AI",
      badge: "Gemini 2.5",
    },
    {
      id: "act-side-gallery",
      category: "Eylemler",
      title: "Öğeler & Çıkartma Kütüphanesi (Elements Library)",
      subtitle: "Goodnotes & Notability tarzı çıkartmalar, damgalar ve kement araçları",
      icon: <Stamp className="w-4 h-4 text-purple-600 dark:text-purple-400" />,
      action: () => {
        onOpenSideGallery();
        onClose();
      },
      badge: "Elements",
    },
    {
      id: "act-doc-hub",
      category: "Eylemler",
      title: "Evrensel Belge Merkezi (Word / PDF / Excel / MD)",
      subtitle: "Tüm dosya türlerinde içe aktar ve dışa aktar",
      icon: <FileText className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
      action: () => {
        onOpenDocumentHub();
        onClose();
      },
    },

    // VIEWS
    {
      id: "view-mindmap",
      category: "Görünümler",
      title: "Bilgi Haritası (Mind Map)",
      subtitle: "Kavramsal bağlantıları ve infografik akışları görselleştir",
      icon: <Network className="w-4 h-4 text-teal-600" />,
      action: () => {
        onOpenMindMap();
        onClose();
      },
      badge: "İnteraktif",
    },
    {
      id: "view-docs",
      category: "Görünümler",
      title: "Belge Merkezi Görünümü",
      subtitle: "Tüm belgeleri dosya türlerine göre yönet ve dönüştür",
      icon: <FileText className="w-4 h-4 text-blue-600" />,
      action: () => {
        onOpenDocumentHub();
        onClose();
      },
    },

    {
      id: "view-study",
      category: "Görünümler",
      title: "Çalışma Kartları & Quiz (Flashcards)",
      subtitle: "Aralıklı tekrar ile hızlı öğrenme ve test",
      icon: <BookOpen className="w-4 h-4 text-amber-600" />,
      action: () => {
        onOpenStudy();
        onClose();
      },
    },
    {
      id: "view-profile",
      category: "Görünümler",
      title: "Kullanıcı Profili & E-posta Senkronizasyonu",
      subtitle: "Senkronizasyon geçmişi ve paylaşım ayarları",
      icon: <User className="w-4 h-4 text-teal-600" />,
      action: () => {
        onOpenProfile();
        onClose();
      },
    },
    {
      id: "view-tips",
      category: "Görünümler",
      title: "Kullanım İpuçları & Kılavuz",
      subtitle: "Tüm özelliklerin ve kısayolların açıklamaları",
      icon: <Lightbulb className="w-4 h-4 text-amber-500" />,
      action: () => {
        onOpenTips();
        onClose();
      },
    },
    {
      id: "view-settings",
      category: "Görünümler",
      title: "Ayarlar & Veri Yönetimi",
      subtitle: "Yedekleme, tema ve genel tercihler",
      icon: <SettingsIcon className="w-4 h-4 text-slate-500" />,
      action: () => {
        onOpenSettings();
        onClose();
      },
    },
    {
      id: "view-trash",
      category: "Görünümler",
      title: "Çöp Kutusu",
      subtitle: "Silinen notları geri yükle veya kalıcı olarak temizle",
      icon: <Trash2 className="w-4 h-4 text-rose-500" />,
      action: () => {
        onOpenTrash();
        onClose();
      },
    },

    // SETTINGS / THEMES
    {
      id: "set-darkmode",
      category: "Ayarlar",
      title: "Karanlık / Aydınlık Mod Değiştir",
      subtitle: "Tema görünüm modunu tersine çevir",
      icon: <Sun className="w-4 h-4 text-amber-500" />,
      action: () => {
        if (onToggleDarkMode) onToggleDarkMode();
        onClose();
      },
    },
  ];

  // Section commands
  const sectionCommands: CommandItem[] = sections.map((sec) => ({
    id: `sec-${sec.id}`,
    category: "Bölümler",
    title: `Bölüm: ${sec.name}`,
    subtitle: `${sec.name} bölümündeki notları listele`,
    icon: <FolderKanban className="w-4 h-4 text-teal-600" />,
    action: () => {
      if (onSelectSection) onSelectSection(sec.name);
      onClose();
    },
    badge: "Bölüm",
  }));

  // Note search results with Turkish normalization
  const matchingNotes: CommandItem[] = notes
    .filter((n) => {
      if (!query.trim()) return false;
      return matchNoteWithSearch(n, query);
    })
    .slice(0, 6)
    .map((n) => ({
      id: `note-${n.id}`,
      category: "Notlar",
      title: n.title || "Başlıksız Not",
      subtitle: `${n.category} • ${(n.content || "").replace(/<[^>]*>?/gm, "").substring(0, 50)}...`,
      icon: <StickyNote className="w-4 h-4 text-teal-600 dark:text-teal-400" />,
      action: () => {
        onOpenNote(n);
        onClose();
      },
      badge: n.pinned ? "Sabitli" : undefined,
    }));

  // Frame search results with Turkish normalization
  const normalizedQuery = normalizeTurkishText(query);
  const matchingFrames: CommandItem[] = ALL_FRAME_PRESETS.filter((f) => {
    if (!normalizedQuery) return false;
    const corpus = normalizeTurkishText(`${f.name} ${f.badgeLabel} ${f.category}`);
    return corpus.includes(normalizedQuery);
  })
    .slice(0, 4)
    .map((f) => ({
      id: `frame-${f.id}`,
      category: "Çerçeveler",
      title: `Çerçeve: ${f.name}`,
      subtitle: `${f.badgeLabel} • Yeni çerçeveli not oluştur`,
      icon: <span className="text-sm">{f.iconSymbol}</span>,
      action: () => {
        if (onSelectFramePreset) {
          onSelectFramePreset(f);
        }
        onClose();
      },
      badge: f.category,
    }));

  // Filter commands by query
  const filteredCommands = query.trim()
    ? [
        ...matchingNotes,
        ...sectionCommands.filter((s) => normalizeTurkishText(s.title).includes(normalizedQuery)),
        ...matchingFrames,
        ...baseCommands.filter((c) => {
          const corpus = normalizeTurkishText(`${c.title} ${c.subtitle || ""}`);
          return corpus.includes(normalizedQuery);
        }),
      ]
    : [...baseCommands, ...sectionCommands.slice(0, 3)];

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % filteredCommands.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % filteredCommands.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        filteredCommands[selectedIndex].action();
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-900/60 dark:bg-black/70 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center px-4 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Bir not, komut, araç, bölüm veya çerçeve arayın... (↑↓ ok tuşları, Enter seç)"
            className="w-full bg-transparent text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Results List */}
        <div className="overflow-y-auto flex-1 p-2 space-y-1">
          {filteredCommands.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="font-semibold">Sonuç bulunamadı</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Farklı bir arama terimi deneyin.</p>
            </div>
          ) : (
            filteredCommands.map((cmd, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={cmd.id}
                  onClick={() => cmd.action()}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-2xl cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white"
                      : "text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected
                          ? "bg-white dark:bg-slate-700 shadow-xs"
                          : "bg-slate-100 dark:bg-slate-800"
                      }`}
                    >
                      {cmd.icon}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold truncate">{cmd.title}</span>
                        {cmd.badge && (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                            {cmd.badge}
                          </span>
                        )}
                      </div>
                      {cmd.subtitle && (
                        <p className="text-[11px] text-slate-400 truncate mt-0.2">{cmd.subtitle}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {cmd.shortcut && (
                      <kbd className="hidden sm:inline-block px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-[10px] font-mono text-slate-500 dark:text-slate-400 font-semibold">
                        {cmd.shortcut}
                      </kbd>
                    )}
                    {isSelected && (
                      <CornerDownLeft className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" />
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts hint */}
        <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-medium">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.2 bg-slate-200 dark:bg-slate-800 rounded text-[9px] font-mono">↑</kbd>
              <kbd className="px-1 py-0.2 bg-slate-200 dark:bg-slate-800 rounded text-[9px] font-mono">↓</kbd> Gezin
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.2 bg-slate-200 dark:bg-slate-800 rounded text-[9px] font-mono">↵</kbd> Seç
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.2 bg-slate-200 dark:bg-slate-800 rounded text-[9px] font-mono">esc</kbd> Kapat
            </span>
          </div>
          <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400">NoteFlow Spotlight</span>
        </div>
      </div>
    </div>
  );
};
