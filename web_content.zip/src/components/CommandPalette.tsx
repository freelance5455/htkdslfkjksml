import { useState } from "react";
import { useStore } from "../lib/store";
import { pathOf } from "../lib/fs";
import { Icon, Sheet } from "./ui";

export default function CommandPalette({
  open,
  onClose,
  onSettings,
  onWorkspace,
}: {
  open: boolean;
  onClose: () => void;
  onSettings: (section?: string) => void;
  onWorkspace: () => void;
}) {
  const { s, newSession, selectSession, openFile, set } = useStore();
  const [query, setQuery] = useState("");
  const commands = [
    {
      id: "new",
      label: "New session",
      desc: "Start a fresh conversation",
      icon: "plus",
      run: newSession,
    },
    {
      id: "folder",
      label: "Open workspace",
      desc: "Connect or import a folder",
      icon: "folder",
      run: onWorkspace,
    },
    {
      id: "providers",
      label: "Models & providers",
      desc: "Connect your own API key",
      icon: "key",
      run: () => onSettings("providers"),
    },
    {
      id: "changes",
      label: "Review changes",
      desc: "Inspect diffs and undo",
      icon: "changes",
      run: () => set({ view: "changes" }),
    },
    ...s.sessions.map((session) => ({
      id: session.id,
      label: session.title,
      desc: "Session",
      icon: "chat",
      run: () => selectSession(session.id),
    })),
    ...Object.values(s.fs.nodes)
      .filter(
        (node) => node.type === "file" && !node.binary && s.permissions.read,
      )
      .map((node) => ({
        id: node.id,
        label: node.name,
        desc: pathOf(s.fs, node.id),
        icon: "file",
        run: () => openFile(node.id),
      })),
  ]
    .filter((command) =>
      `${command.label} ${command.desc}`
        .toLowerCase()
        .includes(query.toLowerCase()),
    )
    .slice(0, 25);
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Quick switch"
      subtitle="Your sessions, files and commands"
    >
      <div className="px-4 pb-3">
        <label className="flex items-center gap-2 rounded-xl border border-line bg-surface2 px-3">
          <Icon name="search" className="h-4 w-4 text-muted" />
          <input
            autoFocus
            aria-label="Search files and commands"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && commands[0]) {
                commands[0].run();
                onClose();
                setQuery("");
              }
            }}
            placeholder="Go to a file, session or action..."
            className="h-12 min-w-0 flex-1 bg-transparent text-sm outline-none"
          />
        </label>
      </div>
      <div className="max-h-[50dvh] overflow-auto px-2 pb-3">
        {commands.map((command) => (
          <button
            key={command.id}
            onClick={() => {
              command.run();
              onClose();
              setQuery("");
            }}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-surface2"
          >
            <Icon name={command.icon} className="h-4 w-4 text-muted" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm">{command.label}</p>
              <p className="mt-0.5 truncate text-[11px] text-muted">
                {command.desc}
              </p>
            </div>
            <Icon name="arrowUpRight" className="h-3.5 w-3.5 text-muted" />
          </button>
        ))}
        {!commands.length && (
          <p className="py-10 text-center text-sm text-muted">
            Nothing found. Try a filename or an action.
          </p>
        )}
      </div>
    </Sheet>
  );
}
