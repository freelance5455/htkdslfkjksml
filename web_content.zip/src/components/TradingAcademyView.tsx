// JUHNKRIX MUSIKA - Trading Academy Component
// Provides educational video tutorials, safety guides, and risk minimization strategies for trading JMC on third-party exchanges.

import React, { useState } from 'react';
import { 
  Play, 
  BookOpen, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  ExternalLink, 
  Sparkles, 
  Lock, 
  Award,
  Video,
  FileText,
  CheckCircle,
  HelpCircle,
  Layers,
  ArrowRight
} from 'lucide-react';

interface TutorialLesson {
  id: string;
  title: string;
  duration: string;
  category: string;
  description: string;
  videoUrl: string;
  keyTakeaways: string[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

const TUTORIAL_LESSONS: TutorialLesson[] = [
  {
    id: 'lesson-1',
    title: 'Introduction to Self-Custodial JMC Trading & Safety Fundamentals',
    duration: '14:20',
    category: 'Security & Basics',
    description: 'Learn how JUHNKRIX MUSIKA’s sovereign wallet architecture protects your private keys while interacting with centralized and decentralized exchanges.',
    videoUrl: 'https://www.youtube.com/embed/sample_tutorial_jmc_1',
    keyTakeaways: [
      'Never share your 18-word BIP-39 mnemonic phrase with any exchange or support agent.',
      'Always verify official exchange URLs using the JM-GLOBAL-TRADE Safety Score engine.',
      'Understand the difference between centralized custodial exchanges and self-custodial DEXs.'
    ],
    difficulty: 'Beginner'
  },
  {
    id: 'lesson-2',
    title: 'Recognizing Phishing & Avoiding Fake Exchange URLs',
    duration: '18:05',
    category: 'Risk Mitigation',
    description: 'Master heuristic checks to identify spoofed domains, malicious SSL certificates, and unauthorized copycat trading platforms.',
    videoUrl: 'https://www.youtube.com/embed/sample_tutorial_jmc_2',
    keyTakeaways: [
      'Check the Safety Score threshold (always trade on platforms with 95%+ ratings).',
      'Bookmark official exchange links provided inside JM-GLOBAL-TRADE.',
      'Beware of unsolicited direct messages offering fake token air-drops or exchange listings.'
    ],
    difficulty: 'Beginner'
  },
  {
    id: 'lesson-3',
    title: 'Executing JMC Spot Trades with Limit & Stop-Loss Orders',
    duration: '22:45',
    category: 'Advanced Trading',
    description: 'Step-by-step masterclass on placing market, limit, and stop-loss orders on Binance, Coinbase Pro, Uniswap, and OKX without slippage.',
    videoUrl: 'https://www.youtube.com/embed/sample_tutorial_jmc_3',
    keyTakeaways: [
      'How to set limit orders to acquire JMC at desired discount pricing.',
      'Protecting capital with trailing stop-losses during high market volatility.',
      'Understanding liquidity depth charts and order book spreads.'
    ],
    difficulty: 'Intermediate'
  },
  {
    id: 'lesson-4',
    title: 'Cross-Chain Bridges & The 7-Day Optimistic Challenge Window',
    duration: '19:30',
    category: 'Bridge Security',
    description: 'Deep dive into decentralized cross-chain locking mechanisms, optimistic verification windows, and secure asset transfer.',
    videoUrl: 'https://www.youtube.com/embed/sample_tutorial_jmc_4',
    keyTakeaways: [
      'How lockTokens and unlockTokens function securely across networks.',
      'Why the 7-day challenge window ensures cryptographic tamper-proof security.',
      'Tracking cross-chain sync status inside the JM-WALLET dashboard.'
    ],
    difficulty: 'Advanced'
  }
];

export const TradingAcademyView: React.FC = () => {
  const [selectedLesson, setSelectedLesson] = useState<TutorialLesson>(TUTORIAL_LESSONS[0]);
  const [completedLessons, setCompletedLessons] = useState<Record<string, boolean>>({});
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [showQuizSubmitted, setShowQuizSubmitted] = useState<boolean>(false);

  const toggleLessonComplete = (id: string) => {
    setCompletedLessons(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 0;
    if (quizAnswers[1] === 'b') score += 50;
    if (quizAnswers[2] === 'a') score += 50;
    setQuizScore(score);
    setShowQuizSubmitted(true);
  };

  return (
    <div className="space-y-8 animate-fadeIn text-amber-100">
      {/* Academy Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/60 border-2 border-indigo-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/40">
              <Award className="w-4 h-4 text-indigo-400" />
              <span>JM-GLOBAL-TRADE TRADING ACADEMY</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black font-serif text-amber-100 tracking-tight">
              Master Safe JMC Trading & Risk Management
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              Welcome to the <strong>Trading Academy</strong>. Watch expert video tutorials, complete security checklists, and learn how to trade JMC securely across verified global exchanges while safeguarding your sovereign wallet.
            </p>
          </div>

          <div className="bg-slate-950/90 p-4 rounded-2xl border border-indigo-500/30 font-mono text-xs space-y-2 shrink-0">
            <div className="flex items-center justify-between space-x-4">
              <span className="text-slate-400">Academy Modules:</span>
              <strong className="text-indigo-400">{TUTORIAL_LESSONS.length} Masterclasses</strong>
            </div>
            <div className="flex items-center justify-between space-x-4">
              <span className="text-slate-400">Completed:</span>
              <strong className="text-emerald-400">{Object.values(completedLessons).filter(Boolean).length} / {TUTORIAL_LESSONS.length}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Main Video & Lesson Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Video Player & Lesson Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border-2 border-indigo-500/40 rounded-3xl overflow-hidden shadow-2xl">
            {/* Simulated Video Player */}
            <div className="aspect-video bg-slate-950 relative flex items-center justify-center group overflow-hidden border-b border-indigo-500/30">
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent z-10" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.15)_0,transparent_70%)] pointer-events-none" />
              
              <div className="relative z-20 text-center space-y-3 p-6 max-w-lg">
                <div className="w-16 h-16 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center mx-auto shadow-2xl shadow-indigo-600/50 cursor-pointer transition-transform hover:scale-110">
                  <Play className="w-8 h-8 fill-white ml-1" />
                </div>
                <h3 className="text-lg font-bold font-serif text-white">{selectedLesson.title}</h3>
                <span className="inline-block px-3 py-1 rounded-full text-xs font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  {selectedLesson.category} • {selectedLesson.duration}
                </span>
              </div>

              {/* Bottom Video Bar */}
              <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between text-xs font-mono text-slate-300 bg-slate-950/80 px-4 py-2.5 rounded-xl border border-slate-800">
                <span className="flex items-center space-x-2">
                  <Video className="w-4 h-4 text-indigo-400" />
                  <span>HD Secure Stream (Encrypted)</span>
                </span>
                <span>{selectedLesson.difficulty} Level</span>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-mono text-indigo-400 uppercase tracking-widest block mb-1">
                    Lesson Overview
                  </span>
                  <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
                    {selectedLesson.title}
                  </h2>
                </div>

                <button
                  onClick={() => toggleLessonComplete(selectedLesson.id)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold flex items-center space-x-2 shadow-lg cursor-pointer transition-all ${
                    completedLessons[selectedLesson.id]
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{completedLessons[selectedLesson.id] ? 'Lesson Completed ✓' : 'Mark as Completed'}</span>
                </button>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                {selectedLesson.description}
              </p>

              <div className="space-y-3 bg-slate-950 p-6 rounded-2xl border border-indigo-500/20">
                <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Key Takeaways & Safety Rules</span>
                </h4>
                <ul className="space-y-2">
                  {selectedLesson.keyTakeaways.map((takeaway, idx) => (
                    <li key={idx} className="flex items-start space-x-2 text-xs text-slate-300 leading-relaxed">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{takeaway}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Playlist / Lessons List */}
        <div className="space-y-6">
          <div className="bg-slate-900 border-2 border-indigo-500/30 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold font-serif text-amber-100 flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-indigo-400" />
              <span>Academy Curriculum</span>
            </h3>
            <p className="text-xs text-slate-400">
              Select a tutorial to begin learning safe JMC trading strategies.
            </p>

            <div className="space-y-3">
              {TUTORIAL_LESSONS.map((lesson) => {
                const isSelected = selectedLesson.id === lesson.id;
                const isComplete = completedLessons[lesson.id];

                return (
                  <div
                    key={lesson.id}
                    onClick={() => setSelectedLesson(lesson)}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-start space-x-3 ${
                      isSelected
                        ? 'bg-indigo-950/60 border-indigo-500 shadow-lg shadow-indigo-500/10'
                        : 'bg-slate-950/60 border-slate-800 hover:border-indigo-500/40'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 font-mono text-xs font-bold ${
                      isComplete ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-900 text-indigo-400 border border-slate-700'
                    }`}>
                      {isComplete ? '✓' : lesson.id.replace('lesson-', '')}
                    </div>

                    <div className="space-y-1 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-indigo-300 uppercase">{lesson.category}</span>
                        <span className="text-[10px] font-mono text-slate-400">{lesson.duration}</span>
                      </div>
                      <h4 className="text-xs font-bold text-amber-100 line-clamp-2">{lesson.title}</h4>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Safety Quiz Box */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold font-serif text-amber-100 flex items-center space-x-2">
              <HelpCircle className="w-5 h-5 text-amber-400" />
              <span>Trader Security Quiz</span>
            </h3>
            <p className="text-xs text-slate-300">
              Test your knowledge to ensure you are fully prepared for safe exchange trading.
            </p>

            <form onSubmit={handleQuizSubmit} className="space-y-4 text-xs font-mono">
              <div className="space-y-2">
                <label className="text-amber-200 font-bold block">1. What should you do before trading JMC on a new exchange?</label>
                <div className="space-y-1.5 pl-2">
                  <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                    <input type="radio" name="q1" value="a" onChange={e => setQuizAnswers(p => ({ ...p, 1: e.target.value }))} className="text-amber-500" />
                    <span>Share your 18-word seed phrase</span>
                  </label>
                  <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                    <input type="radio" name="q1" value="b" onChange={e => setQuizAnswers(p => ({ ...p, 1: e.target.value }))} className="text-amber-500" />
                    <span>Verify the Safety Score is 95%+ and license is active</span>
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-amber-200 font-bold block">2. Why use the 7-day optimistic bridge window?</label>
                <div className="space-y-1.5 pl-2">
                  <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                    <input type="radio" name="q2" value="a" onChange={e => setQuizAnswers(p => ({ ...p, 2: e.target.value }))} className="text-amber-500" />
                    <span>For tamper-proof cross-chain security</span>
                  </label>
                  <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                    <input type="radio" name="q2" value="b" onChange={e => setQuizAnswers(p => ({ ...p, 2: e.target.value }))} className="text-amber-500" />
                    <span>To speed up gas fees</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black uppercase tracking-wider shadow-lg cursor-pointer transition-transform hover:scale-102"
              >
                Submit Quiz Answers
              </button>

              {showQuizSubmitted && quizScore !== null && (
                <div className={`p-3 rounded-xl border text-center font-bold ${
                  quizScore === 100 ? 'bg-emerald-950 border-emerald-400 text-emerald-200' : 'bg-amber-950 border-amber-400 text-amber-200'
                }`}>
                  {quizScore === 100 ? '🎉 Perfect Score! 100% Security Mastery Verified.' : `Score: ${quizScore}% - Review lessons and try again.`}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
