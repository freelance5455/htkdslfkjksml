import React, { useState } from 'react';
import { X, Copy, Check, Smartphone, Terminal, FileCode2, ExternalLink } from 'lucide-react';

interface NativeAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NativeAppModal: React.FC<NativeAppModalProps> = ({ isOpen, onClose }) => {
  const [platform, setPlatform] = useState<'flutter' | 'react-native'>('flutter');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const flutterPubspec = `name: yt_music_app
description: "A YouTube Music player app with background audio and lock screen controls."
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  just_audio: ^0.9.36
  audio_service: ^0.18.12
  audio_session: ^0.1.18
  cached_network_image: ^3.3.1
  flutter_bloc: ^8.1.3
  cupertino_icons: ^1.0.8

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`;

  const flutterAudioHandler = `import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';

class AudioPlayerHandler extends BaseAudioHandler with SeekHandler {
  final _player = AudioPlayer();

  AudioPlayerHandler() {
    // Forward playback events to AudioService for background lockscreen controls
    _player.playbackEventStream.listen((PlaybackEvent event) {
      final playing = _player.playing;
      playbackState.add(playbackState.value.copyWith(
        controls: [
          MediaControl.skipToPrevious,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.skipToNext,
          MediaControl.stop,
        ],
        systemActions: const {
          MediaAction.seek,
          MediaAction.seekForward,
          MediaAction.seekBackward,
        },
        androidCompactActionIndices: const [0, 1, 2],
        processingState: const {
          ProcessingState.idle: AudioProcessingState.idle,
          ProcessingState.loading: AudioProcessingState.loading,
          ProcessingState.buffering: AudioProcessingState.buffering,
          ProcessingState.ready: AudioProcessingState.ready,
          ProcessingState.completed: AudioProcessingState.completed,
        }[_player.processingState]!,
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
        queueIndex: event.currentIndex,
      ));
    });
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> playMediaItem(MediaItem item) async {
    mediaItem.add(item);
    await _player.setUrl(item.extras!['url'] as String);
    play();
  }
}
`;

  const reactNativeService = `import TrackPlayer, { Event, Capability } from 'react-native-track-player';

module.exports = async function() {
  TrackPlayer.addEventListener(Event.RemotePlay, () => TrackPlayer.play());
  TrackPlayer.addEventListener(Event.RemotePause, () => TrackPlayer.pause());
  TrackPlayer.addEventListener(Event.RemoteNext, () => TrackPlayer.skipToNext());
  TrackPlayer.addEventListener(Event.RemotePrevious, () => TrackPlayer.skipToPrevious());
  TrackPlayer.addEventListener(Event.RemoteSeek, (event) => TrackPlayer.seekTo(event.position));
};
`;

  const reactNativeSetup = `import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import TrackPlayer, { Capability, State, usePlaybackState } from 'react-native-track-player';

export default function App() {
  const playbackState = usePlaybackState();

  useEffect(() => {
    async function setupPlayer() {
      await TrackPlayer.setupPlayer();
      await TrackPlayer.updateOptions({
        capabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
          Capability.SkipToPrevious,
          Capability.SeekTo,
        ],
        compactCapabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
        ],
        notificationCapabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
          Capability.SkipToPrevious,
        ],
      });

      await TrackPlayer.add({
        id: 'track1',
        url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
        title: 'Starfall Dreams',
        artist: 'Luna Eclipse',
        artwork: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600',
        duration: 194,
      });
    }
    setupPlayer();
  }, []);

  const togglePlay = async () => {
    const state = await TrackPlayer.getState();
    if (state === State.Playing) {
      await TrackPlayer.pause();
    } else {
      await TrackPlayer.play();
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>YT Music Mobile</Text>
      <TouchableOpacity onPress={togglePlay} style={styles.button}>
        <Text style={styles.btnText}>Play / Pause</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030303', justifyContent: 'center', alignItems: 'center' },
  title: { color: '#ffffff', fontSize: 24, fontWeight: 'bold' },
  button: { marginTop: 20, backgroundColor: '#ff0000', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 24 },
  btnText: { color: '#ffffff', fontWeight: 'bold' },
});
`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-3xl rounded-3xl bg-[#141414] border border-white/10 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-white">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Android & iOS Native App Blueprint</h2>
              <p className="text-xs text-neutral-400">
                Source code configured with native background audio service & lockscreen controls.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Selector Tabs */}
        <div className="flex items-center px-6 pt-4 gap-3 border-b border-white/5 pb-3">
          <button
            onClick={() => setPlatform('flutter')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              platform === 'flutter'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white'
            }`}
          >
            <span>Flutter (Dart)</span>
            <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">just_audio + audio_service</span>
          </button>

          <button
            onClick={() => setPlatform('react-native')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              platform === 'react-native'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white'
            }`}
          >
            <span>React Native (TS)</span>
            <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">react-native-track-player</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {platform === 'flutter' ? (
            <>
              {/* Flutter Quickstart Instructions */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300 mb-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>1. Setup Flutter Project</span>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-emerald-300 overflow-x-auto">
                  flutter create yt_music_app{"\n"}
                  cd yt_music_app{"\n"}
                  flutter pub add just_audio audio_service audio_session cached_network_image
                </pre>
              </div>

              {/* pubspec.yaml */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-blue-400" />
                    pubspec.yaml
                  </span>
                  <button
                    onClick={() => copyToClipboard(flutterPubspec, 'flutter-pub')}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer transition"
                  >
                    {copiedKey === 'flutter-pub' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'flutter-pub' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-neutral-300 overflow-x-auto max-h-48">
                  {flutterPubspec}
                </pre>
              </div>

              {/* audio_player_handler.dart */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-blue-400" />
                    lib/audio_player_handler.dart (Background Lockscreen Handler)
                  </span>
                  <button
                    onClick={() => copyToClipboard(flutterAudioHandler, 'flutter-handler')}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer transition"
                  >
                    {copiedKey === 'flutter-handler' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'flutter-handler' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-neutral-300 overflow-x-auto max-h-56">
                  {flutterAudioHandler}
                </pre>
              </div>
            </>
          ) : (
            <>
              {/* React Native Quickstart Instructions */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300 mb-2">
                  <Terminal className="w-4 h-4 text-cyan-400" />
                  <span>1. Initialize React Native Project</span>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-cyan-300 overflow-x-auto">
                  npx react-native init YTMusicApp --template react-native-template-typescript{"\n"}
                  cd YTMusicApp{"\n"}
                  npm install react-native-track-player
                </pre>
              </div>

              {/* service.js */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-cyan-400" />
                    service.js (Playback Background Service)
                  </span>
                  <button
                    onClick={() => copyToClipboard(reactNativeService, 'rn-service')}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer transition"
                  >
                    {copiedKey === 'rn-service' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'rn-service' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-neutral-300 overflow-x-auto max-h-40">
                  {reactNativeService}
                </pre>
              </div>

              {/* App.tsx */}
              <div className="bg-black/40 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-cyan-400" />
                    App.tsx (Player UI with Media Notifications)
                  </span>
                  <button
                    onClick={() => copyToClipboard(reactNativeSetup, 'rn-app')}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer transition"
                  >
                    {copiedKey === 'rn-app' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'rn-app' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="text-xs bg-black/80 p-3 rounded-xl font-mono text-neutral-300 overflow-x-auto max-h-56">
                  {reactNativeSetup}
                </pre>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-white/10 bg-neutral-900 flex items-center justify-between">
          <p className="text-xs text-neutral-400">
            Tip: You can also install this web app directly via the <strong className="text-white">Install App</strong> button!
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
