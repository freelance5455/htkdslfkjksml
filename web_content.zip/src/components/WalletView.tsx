import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  ShoppingCart,
  Plus,
  Send,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  ShieldCheck,
  Receipt,
  Search,
  Filter,
  X,
  Phone,
  Lock,
  ArrowRight,
  Sparkles,
  Layers,
  ChevronRight,
  Sprout,
  Target,
  PiggyBank,
  TrendingUp,
  Percent,
} from 'lucide-react';
import {
  Language,
  UserProfile,
  WalletTransaction,
  FarmInputItem,
} from '../types';
import { FARM_INPUT_ITEMS, INITIAL_WALLET_TRANSACTIONS } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface WalletViewProps {
  language: Language;
  user: UserProfile;
}

export default function WalletView({ language, user }: WalletViewProps) {
  const isSw = language === 'sw';

  // Wallet Balance State (defaults to Tsh 345,000)
  const [balance, setBalance] = useState<number>(345000);
  const [showBalance, setShowBalance] = useState<boolean>(true);
  const [transactions, setTransactions] = useState<WalletTransaction[]>(INITIAL_WALLET_TRANSACTIONS);
  const [activeTab, setActiveTab] = useState<'all' | 'growth' | 'buy'>('all');

  // Farm Growth Wallet (Mfuko wa Kukuza Shamba) State
  const [growthBalance, setGrowthBalance] = useState<number>(180000);
  const [growthTarget, setGrowthTarget] = useState<number>(250000);
  const [isAutoSaveActive, setIsAutoSaveActive] = useState<boolean>(true);
  const [autoSavePercent, setAutoSavePercent] = useState<number>(10);
  const [showGrowthModal, setShowGrowthModal] = useState<boolean>(false);
  const [growthAllocateAmount, setGrowthAllocateAmount] = useState<string>('30000');
  const [growthError, setGrowthError] = useState<string | null>(null);

  // Modal states
  const [showSendModal, setShowSendModal] = useState<boolean>(false);
  const [showBuyModal, setShowBuyModal] = useState<boolean>(false);
  const [showTopUpModal, setShowTopUpModal] = useState<boolean>(false);
  const [selectedInputItem, setSelectedInputItem] = useState<FarmInputItem | null>(null);
  const [inputQuantity, setInputQuantity] = useState<number>(1);
  const [successReceipt, setSuccessReceipt] = useState<{
    title: string;
    amount: number;
    reference: string;
    details: string;
  } | null>(null);

  // Send Money Form State
  const [sendRecipient, setSendRecipient] = useState('');
  const [sendAmount, setSendAmount] = useState('');
  const [sendNote, setSendNote] = useState('');
  const [sendMethod, setSendMethod] = useState<'wallet' | 'mpesa' | 'tigopesa' | 'airtel'>('wallet');
  const [securityPin, setSecurityPin] = useState('');
  const [sendError, setSendError] = useState<string | null>(null);

  // Top-Up Form State
  const [topUpAmount, setTopUpAmount] = useState('50000');
  const [topUpMethod, setTopUpMethod] = useState<'mpesa' | 'tigopesa' | 'airtel'>('mpesa');
  const [isProcessingTopUp, setIsProcessingTopUp] = useState(false);

  // Filter transactions
  const [filterType, setFilterType] = useState<'all' | 'sent' | 'received' | 'purchases'>('all');

  const filteredTransactions = transactions.filter((t) => {
    if (filterType === 'sent') return t.type === 'send';
    if (filterType === 'received') return t.type === 'receive' || t.type === 'top_up';
    if (filterType === 'purchases') return t.type === 'buy_input';
    return true;
  });

  // Handle Send Money Submit
  const handleSendMoney = (e: React.FormEvent) => {
    e.preventDefault();
    setSendError(null);

    const amountNum = Number(sendAmount);
    if (!amountNum || amountNum <= 0) {
      setSendError(isSw ? 'Weka kiasi sahihi cha pesa' : 'Enter a valid amount');
      return;
    }
    if (amountNum > balance) {
      setSendError(
        isSw
          ? 'Salio lako halitoshi kwa muamala huu.'
          : 'Insufficient wallet balance for this transfer.'
      );
      return;
    }
    if (securityPin.length < 4) {
      setSendError(isSw ? 'Weka PIN yako ya siri (tarakimu 4)' : 'Enter your 4-digit security PIN');
      return;
    }

    // Execute transfer
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: 'send',
      titleSw: sendNote ? `Malipo: ${sendNote}` : `Pesa Imetumwa kwa ${sendRecipient}`,
      titleEn: sendNote ? `Payment: ${sendNote}` : `Money Sent to ${sendRecipient}`,
      party: sendRecipient,
      amount: amountNum,
      timestamp: isSw ? 'Sasa hivi' : 'Just now',
      status: 'completed',
      method: sendMethod,
      reference: `ARD-${Math.floor(100000 + Math.random() * 900000)}`,
    };

    setBalance((prev) => prev - amountNum);
    setTransactions([newTx, ...transactions]);
    setShowSendModal(false);
    playSuccessChime();

    setSuccessReceipt({
      title: isSw ? 'Pesa Imetumwa Kikamilifu!' : 'Money Sent Successfully!',
      amount: amountNum,
      reference: newTx.reference,
      details: `${isSw ? 'Mpokeaji' : 'Recipient'}: ${sendRecipient} (${sendMethod.toUpperCase()})`,
    });

    // Reset fields
    setSendRecipient('');
    setSendAmount('');
    setSendNote('');
    setSecurityPin('');
  };

  // Handle Buy Farm Input Item
  const handleBuyInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInputItem) return;

    const totalCost = selectedInputItem.price * inputQuantity;
    if (totalCost > balance) {
      alert(
        isSw
          ? 'Salio halitoshi! Tafadhali weka pesa kwanza.'
          : 'Insufficient balance! Please top up your wallet first.'
      );
      return;
    }

    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: 'buy_input',
      titleSw: `Ununuzi: ${selectedInputItem.nameSw} (${inputQuantity})`,
      titleEn: `Purchased: ${selectedInputItem.nameEn} (${inputQuantity})`,
      party: selectedInputItem.supplier,
      amount: totalCost,
      timestamp: isSw ? 'Sasa hivi' : 'Just now',
      status: 'completed',
      method: 'wallet',
      reference: `INP-${Math.floor(100000 + Math.random() * 900000)}`,
    };

    setBalance((prev) => prev - totalCost);
    setTransactions([newTx, ...transactions]);
    setShowBuyModal(false);
    playSuccessChime();

    setSuccessReceipt({
      title: isSw ? 'Pembejeo Imelipiwa Kikamilifu!' : 'Input Purchased Successfully!',
      amount: totalCost,
      reference: newTx.reference,
      details: `${isSw ? 'Bidhaa' : 'Item'}: ${selectedInputItem.nameSw} (${inputQuantity} ${selectedInputItem.unitSw}). ${isSw ? 'Mkusanyie' : 'Supplier'}: ${selectedInputItem.supplier}.`,
    });
  };

  // Handle Top-Up Submit
  const handleTopUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = Number(topUpAmount);
    if (!amountNum || amountNum <= 0) return;

    setIsProcessingTopUp(true);

    setTimeout(() => {
      setIsProcessingTopUp(false);
      const newTx: WalletTransaction = {
        id: `tx-${Date.now()}`,
        type: 'top_up',
        titleSw: `Kuweka Pesa kutoka ${topUpMethod.toUpperCase()}`,
        titleEn: `Top-up via ${topUpMethod.toUpperCase()}`,
        party: `${topUpMethod.toUpperCase()} (${user.phone})`,
        amount: amountNum,
        timestamp: isSw ? 'Sasa hivi' : 'Just now',
        status: 'completed',
        method: topUpMethod,
        reference: `TOP-${Math.floor(100000 + Math.random() * 900000)}`,
      };

      setBalance((prev) => prev + amountNum);
      setTransactions([newTx, ...transactions]);
      setShowTopUpModal(false);
      playSuccessChime();

      setSuccessReceipt({
        title: isSw ? 'Pochi Imewekewa Pesa!' : 'Wallet Topped Up!',
        amount: amountNum,
        reference: newTx.reference,
        details: `${isSw ? 'Njia' : 'Method'}: ${topUpMethod.toUpperCase()} · ${user.phone}`,
      });
    }, 1200);
  };

  // Handle Farm Growth Wallet Allocation
  const handleAllocateToGrowth = (e: React.FormEvent) => {
    e.preventDefault();
    setGrowthError(null);
    const amountNum = Number(growthAllocateAmount);
    if (!amountNum || amountNum <= 0) {
      setGrowthError(isSw ? 'Weka kiasi sahihi' : 'Enter a valid amount');
      return;
    }
    if (amountNum > balance) {
      setGrowthError(
        isSw ? 'Salio halitoshi kwenye pochi kuu' : 'Insufficient balance in main wallet'
      );
      return;
    }

    setBalance((prev) => prev - amountNum);
    setGrowthBalance((prev) => prev + amountNum);

    const newTx: WalletTransaction = {
      id: `tx-growth-${Date.now()}`,
      type: 'send',
      titleSw: 'Tenga Pesa: Mfuko wa Kukuza Shamba',
      titleEn: 'Allocation: Farm Growth Vault',
      party: isSw ? 'Mfuko wa Pembejeo Masika 2026' : 'Masika Season 2026 Input Stash',
      amount: amountNum,
      timestamp: isSw ? 'Hivi sasa' : 'Just now',
      status: 'completed',
      method: 'wallet',
      reference: `GRW-${Math.floor(100000 + Math.random() * 900000)}`,
    };

    setTransactions([newTx, ...transactions]);
    setShowGrowthModal(false);
    playSuccessChime();

    setSuccessReceipt({
      title: isSw ? 'Umetenga Pesa Kukuza Shamba!' : 'Allocated to Farm Growth Stash!',
      amount: amountNum,
      reference: newTx.reference,
      details: isSw
        ? `Salio Jipya la Mfuko: Tsh ${(growthBalance + amountNum).toLocaleString()} / ${growthTarget.toLocaleString()}`
        : `New Growth Vault Balance: Tsh ${(growthBalance + amountNum).toLocaleString()} / ${growthTarget.toLocaleString()}`,
    });
  };

  return (
    <div id="wallet-main-view" className="space-y-4 pb-8 text-[var(--ink)]">
      {/* Wallet Header */}
      <div className="pt-2 flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Pochi ya Mkulima' : 'Farmer Wallet'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-0.5">
            {isSw
              ? 'Nunua pembejeo, tuma pesa, au pokea mapato ya mazao'
              : 'Buy inputs, transfer funds, and receive harvest payouts'}
          </p>
        </div>
        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>{isSw ? 'Salama' : 'Protected'}</span>
        </span>
      </div>

      {/* Main Agrarian Gradient Wallet Card */}
      <div
        className="rounded-3xl p-5 text-[#F7F4E9] shadow-xl relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #1A3528 0%, #264A38 50%, #4D3C1F 100%)',
          border: '1px solid rgba(200, 155, 60, 0.3)',
        }}
      >
        {/* Subtle agricultural background watermarks */}
        <div className="absolute right-2 -bottom-6 opacity-10 pointer-events-none font-display text-8xl font-bold">
          ARDHI
        </div>

        <div className="relative z-10 flex items-start justify-between mb-4">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-amber-200 font-semibold flex items-center gap-2">
              <span>{isSw ? 'Salio Linalopatikana' : 'Available Balance'}</span>
              <button
                type="button"
                onClick={() => setShowBalance(!showBalance)}
                className="opacity-75 hover:opacity-100 transition-opacity"
              >
                {showBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="font-display text-3xl sm:text-4xl font-bold mt-1 tracking-tight text-white">
              {showBalance ? `Tsh ${balance.toLocaleString()}` : '••••••••'}
            </div>

            <div className="text-xs text-amber-100/75 mt-0.5">
              {showBalance ? `≈ $${(balance / 2568).toFixed(2)} USD` : '••••'}
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-amber-200/80 font-mono block">
              ID: ARD-{user.phone.slice(-6)}
            </span>
            <span className="text-[10px] text-emerald-200/90 font-semibold bg-black/25 px-2 py-0.5 rounded-full mt-1 inline-block">
              {user.name.split(' ')[0]} ({user.region})
            </span>
          </div>
        </div>

        {/* Action Buttons: Send Money, Buy Inputs, Top Up */}
        <div className="relative z-10 grid grid-cols-3 gap-2 pt-2 border-t border-white/15">
          {/* Send Money */}
          <button
            id="wallet-send-money-btn"
            onClick={() => {
              playKeyTap();
              setShowSendModal(true);
            }}
            className="py-2.5 px-2 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-xs font-semibold flex flex-col items-center gap-1 transition-all active:scale-95 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-amber-400 text-[#1A3528] flex items-center justify-center font-bold">
              <Send className="w-4 h-4" />
            </div>
            <span>{isSw ? 'Tuma Pesa' : 'Send Money'}</span>
          </button>

          {/* Buy Farm Inputs */}
          <button
            id="wallet-buy-inputs-btn"
            onClick={() => {
              playKeyTap();
              setActiveTab('buy');
            }}
            className="py-2.5 px-2 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-xs font-semibold flex flex-col items-center gap-1 transition-all active:scale-95 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-400 text-[#1A3528] flex items-center justify-center font-bold">
              <ShoppingCart className="w-4 h-4" />
            </div>
            <span>{isSw ? 'Nunua Pembejeo' : 'Buy Inputs'}</span>
          </button>

          {/* Top Up / Deposit */}
          <button
            id="wallet-topup-btn"
            onClick={() => {
              playKeyTap();
              setShowTopUpModal(true);
            }}
            className="py-2.5 px-2 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-xs font-semibold flex flex-col items-center gap-1 transition-all active:scale-95 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-sky-300 text-[#1A3528] flex items-center justify-center font-bold">
              <Plus className="w-4 h-4" />
            </div>
            <span>{isSw ? 'Weka Pesa' : 'Top Up'}</span>
          </button>
        </div>
      </div>

      {/* FARM GROWTH VAULT SUMMARY BANNER */}
      <div
        id="farm-growth-vault-card"
        className="rounded-3xl p-4 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-3"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-[#F7F4E9] flex items-center justify-center font-bold">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-display font-bold text-sm text-[var(--ink)]">
                  {isSw ? 'Mfuko wa Kukuza Shamba' : 'Farm Growth Wallet'}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-bold">
                  {Math.round((growthBalance / growthTarget) * 100)}% {isSw ? 'Lengo' : 'Goal'}
                </span>
              </div>
              <p className="text-[11px] text-[var(--ink-soft)]">
                {isSw
                  ? 'Akiba maalum ya mbegu bora, mbolea, na umwagiliaji kwa msimu ujao'
                  : 'Dedicated savings for next season inputs, seeds & irrigation'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              playKeyTap();
              setShowGrowthModal(true);
            }}
            className="px-3 py-1.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-bold flex items-center gap-1 hover:opacity-95 cursor-pointer shadow-sm active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isSw ? 'Tenga Salio' : 'Allocate'}</span>
          </button>
        </div>

        {/* Progress Bar & Target Display */}
        <div className="space-y-1.5 bg-[var(--bg)] p-3 rounded-2xl border border-[var(--line)]">
          <div className="flex items-baseline justify-between text-xs">
            <span className="text-[var(--ink-soft)]">
              {isSw ? 'Kiasi Kilichotengwa Shambani:' : 'Stashed Balance:'}
            </span>
            <div className="font-display font-bold text-sm text-emerald-700 dark:text-emerald-300">
              Tsh {growthBalance.toLocaleString()}{' '}
              <span className="text-xs text-[var(--ink-soft)] font-normal">
                / {growthTarget.toLocaleString()} Tsh
              </span>
            </div>
          </div>

          {/* Bar */}
          <div className="w-full h-2.5 rounded-full bg-[var(--line)] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-amber-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (growthBalance / growthTarget) * 100)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] text-[var(--ink-soft)] pt-1">
            <span>🌱 {isSw ? 'Lengo la Msimu wa Masika 2026' : 'Target: Masika 2026 Season'}</span>
            <span className="font-semibold text-emerald-700 dark:text-emerald-300">
              {isSw ? 'Punguzo la 5% kwenye Pembejeo' : '5% Bonus Input Discount Active'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Tab Switcher (3-Way) */}
      <div className="flex bg-[var(--paper)] p-1 rounded-2xl border border-[var(--line)]">
        <button
          id="wallet-tab-all"
          onClick={() => {
            playKeyTap();
            setActiveTab('all');
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'all'
              ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          {isSw ? 'Muhtasari & Historia' : 'Overview & Ledger'}
        </button>
        <button
          id="wallet-tab-growth"
          onClick={() => {
            playKeyTap();
            setActiveTab('growth');
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'growth'
              ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Sprout className="w-3.5 h-3.5" />
          <span>{isSw ? 'Kukuza Shamba' : 'Growth Vault'}</span>
        </button>
        <button
          id="wallet-tab-buy"
          onClick={() => {
            playKeyTap();
            setActiveTab('buy');
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'buy'
              ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>{isSw ? 'Duka la Pembejeo' : 'Inputs Store'}</span>
        </button>
      </div>

      {/* SECTION: FARM GROWTH VAULT (MFUKO WA KUKUZA SHAMBA) */}
      {activeTab === 'growth' && (
        <div className="space-y-4">
          {/* Target Milestone Details */}
          <div className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                  <Target className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-[var(--ink)]">
                    {isSw ? 'Lengo la Msimu wa Masika 2026' : 'Masika Season 2026 Target'}
                  </h4>
                  <p className="text-[10px] text-[var(--ink-soft)]">
                    {isSw ? 'Kukusanya gharama zote za pembejeo mapema' : 'Pre-funding all necessary certified inputs'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold font-display px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                {Math.round((growthBalance / growthTarget) * 100)}% {isSw ? 'Tayari' : 'Funded'}
              </span>
            </div>

            {/* Checklist of planned items */}
            <div className="space-y-2 pt-1">
              {[
                {
                  nameSw: 'Mbegu Chotara ya Mahindi SC627 (2kg)',
                  nameEn: 'Hybrid Maize Seed SC627 (2kg)',
                  cost: 22500,
                  funded: true,
                  icon: '🌽',
                },
                {
                  nameSw: 'Mbolea ya YaraBela Sulfan / CAN (50kg)',
                  nameEn: 'Top-Dressing Fertilizer CAN (50kg)',
                  cost: 78000,
                  funded: true,
                  icon: '🌿',
                },
                {
                  nameSw: 'Mirija ya Matone (Drip Irrigation Kit)',
                  nameEn: 'Gravity Drip Irrigation Tube Kit',
                  cost: 95000,
                  funded: growthBalance >= 180000,
                  icon: '💧',
                },
                {
                  nameSw: 'Kiuadudu cha Kibiolojia (Bio-Inoculant)',
                  nameEn: 'Rhizobium Bio-Inoculant Biofix',
                  cost: 15000,
                  funded: growthBalance >= 200000,
                  icon: '🦠',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{item.icon}</span>
                    <div>
                      <div className="font-semibold text-[var(--ink)]">
                        {isSw ? item.nameSw : item.nameEn}
                      </div>
                      <div className="text-[10px] text-[var(--ink-soft)] font-display">
                        Tsh {item.cost.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      item.funded
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                        : 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {item.funded
                      ? (isSw ? 'Imelipiwa' : 'Covered')
                      : (isSw ? 'Inasubiri' : 'Pending')}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                playKeyTap();
                setShowGrowthModal(true);
              }}
              className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer hover:opacity-95"
            >
              <Plus className="w-4 h-4" />
              <span>{isSw ? 'Tenga Pesa Kwenye Mfuko Huu' : 'Stash Money to This Goal'}</span>
            </button>
          </div>

          {/* Auto-Save Reinvestment Card */}
          <div className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-sm flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold">
                <PiggyBank className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-xs text-[var(--ink)]">
                  {isSw ? 'Hifadhi Kiotomatiki Mauzo (Auto-Save)' : 'Auto-Reinvest Harvest Sales'}
                </div>
                <div className="text-[10px] text-[var(--ink-soft)]">
                  {isSw
                    ? 'Weka 10% ya kila malipo unayopokea kwenye pochi hii'
                    : 'Automatically divert 10% of crop sales into Farm Growth'}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                playKeyTap();
                setIsAutoSaveActive(!isAutoSaveActive);
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer flex-shrink-0 ${
                isAutoSaveActive ? 'bg-emerald-600' : 'bg-[var(--line)]'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${
                  isAutoSaveActive ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Perks & Rewards */}
          <div className="p-4 rounded-3xl bg-gradient-to-br from-[var(--paper)] to-amber-50/50 dark:to-amber-950/20 border border-amber-200/50 dark:border-amber-900/30 space-y-2">
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-bold text-xs">
              <Sparkles className="w-4 h-4" />
              <span>{isSw ? 'Faida za Mfuko wa Kukuza Shamba' : 'Farm Growth Wallet Perks'}</span>
            </div>
            <ul className="text-xs text-[var(--ink-soft)] space-y-1 pl-4 list-disc">
              <li>
                <strong>{isSw ? 'Punguzo la 5%' : '5% Direct Discount'}</strong>:{' '}
                {isSw
                  ? 'Kila unaponunua pembejeo zilizoidhinishwa kupitia mfuko huu'
                  : 'On all certified seeds & fertilizers bought through this vault'}
              </li>
              <li>
                <strong>{isSw ? 'Nafasi ya Range Rover & Dubai' : 'Range Rover & Dubai Raffle'}</strong>:{' '}
                {isSw
                  ? 'Kila Tsh 50,000 unayotenga inakupa tiketi 2 za ziada za bahati nasibu!'
                  : 'Every Tsh 50,000 stashed awards +2 extra tickets into the grand prize!'}
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* SECTION A: BUY FARM INPUTS CATALOG */}
      {activeTab === 'buy' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
              {isSw ? 'Pembejeo Zilizoidhinishwa' : 'Certified Farm Inputs & Supplies'}
            </h3>
            <span className="text-[11px] text-[var(--forest)] font-medium">
              {FARM_INPUT_ITEMS.length} {isSw ? 'bidhaa' : 'items'}
            </span>
          </div>

          <div className="space-y-2.5">
            {FARM_INPUT_ITEMS.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm flex flex-col gap-2 hover:border-[var(--forest)] transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center text-2xl flex-shrink-0">
                    {item.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="font-bold text-xs text-[var(--ink)] leading-snug">
                        {isSw ? item.nameSw : item.nameEn}
                      </h4>
                      <span className="font-display font-bold text-sm text-[var(--forest)] flex-shrink-0">
                        Tsh {item.price.toLocaleString()}
                      </span>
                    </div>

                    <div className="text-[10px] text-[var(--ink-soft)] mt-0.5">
                      {isSw ? item.unitSw : item.unitEn} · {item.supplier}
                    </div>

                    <p className="text-[11px] text-[var(--ink-soft)] mt-1 line-clamp-2">
                      {isSw ? item.descriptionSw : item.descriptionEn}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-[var(--line)] flex items-center justify-between">
                  <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                    {isSw ? 'Ipo Dukani' : 'In Stock'}
                  </span>

                  <button
                    id={`buy-input-item-btn-${item.id}`}
                    onClick={() => {
                      playKeyTap();
                      setSelectedInputItem(item);
                      setInputQuantity(1);
                      setShowBuyModal(true);
                    }}
                    className="py-1.5 px-4 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] text-xs font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Nunua kwa Pochi' : 'Buy with Wallet'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION B: TRANSACTIONS HISTORY & OVERVIEW */}
      {activeTab === 'all' && (
        <div className="space-y-3">
          {/* Quick Input Shortcut Strip */}
          <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center text-lg">
                🌱
              </div>
              <div className="text-xs">
                <div className="font-bold text-[var(--ink)]">
                  {isSw ? 'Unahitaji Mbegu au Mbolea?' : 'Need Seeds or Fertilizer?'}
                </div>
                <div className="text-[10px] text-[var(--ink-soft)]">
                  {isSw ? 'Lipia moja kwa moja kwa salio la pochi' : 'Pay instantly from your harvest wallet'}
                </div>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('buy')}
              className="text-xs font-semibold text-[var(--forest)] hover:underline flex items-center gap-0.5"
            >
              <span>{isSw ? 'Tazama' : 'Browse'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center justify-between pt-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
              {isSw ? 'Miamala ya Pochi' : 'Wallet Transactions'}
            </h3>
            <div className="flex gap-1 text-[10px]">
              {(['all', 'sent', 'received', 'purchases'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setFilterType(mode)}
                  className={`px-2 py-0.5 rounded-full border transition-all ${
                    filterType === mode
                      ? 'bg-[var(--forest)] text-white border-[var(--forest)] font-semibold'
                      : 'bg-[var(--paper)] text-[var(--ink-soft)] border-[var(--line)]'
                  }`}
                >
                  {mode === 'all' && (isSw ? 'Yote' : 'All')}
                  {mode === 'sent' && (isSw ? 'Zilizotumwa' : 'Sent')}
                  {mode === 'received' && (isSw ? 'Zilizopokelewa' : 'Received')}
                  {mode === 'purchases' && (isSw ? 'Pembejeo' : 'Inputs')}
                </button>
              ))}
            </div>
          </div>

          {/* Transactions List */}
          <div className="space-y-2 bg-[var(--paper)] p-3 rounded-2xl border border-[var(--line)] divide-y divide-[var(--line)]">
            {filteredTransactions.length === 0 ? (
              <div className="text-center py-6 text-xs text-[var(--ink-soft)]">
                {isSw ? 'Hakuna miamala katika kundi hili' : 'No transactions found'}
              </div>
            ) : (
              filteredTransactions.map((tx) => {
                const isIncoming = tx.type === 'receive' || tx.type === 'top_up';
                return (
                  <div key={tx.id} className="pt-2.5 first:pt-0 pb-2.5 last:pb-0 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          isIncoming
                            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            : tx.type === 'buy_input'
                            ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                            : 'bg-red-500/15 text-red-700 dark:text-red-300'
                        }`}
                      >
                        {isIncoming ? (
                          <ArrowDownLeft className="w-4 h-4" />
                        ) : tx.type === 'buy_input' ? (
                          <ShoppingCart className="w-4 h-4" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-xs text-[var(--ink)]">
                          {isSw ? tx.titleSw : tx.titleEn}
                        </div>
                        <div className="text-[10px] text-[var(--ink-soft)]">
                          {tx.party} · {tx.timestamp}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div
                        className={`font-display font-bold text-xs ${
                          isIncoming ? 'text-emerald-600 dark:text-emerald-400' : 'text-[var(--ink)]'
                        }`}
                      >
                        {isIncoming ? '+' : '-'}Tsh {tx.amount.toLocaleString()}
                      </div>
                      <span className="text-[9px] font-mono text-[var(--ink-soft)] opacity-70">
                        {tx.reference}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: SEND MONEY */}
      <AnimatePresence>
        {showSendModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-5 border border-[var(--line)] shadow-2xl relative my-6"
            >
              <button
                onClick={() => setShowSendModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-[var(--forest)] text-white flex items-center justify-center">
                  <Send className="w-4 h-4" />
                </div>
                <h3 className="font-display text-lg font-bold text-[var(--ink)]">
                  {isSw ? 'Tuma Pesa' : 'Send Money'}
                </h3>
              </div>

              <div className="p-2.5 rounded-xl bg-[var(--bg)] text-xs text-[var(--ink-soft)] mb-3 flex justify-between items-center">
                <span>{isSw ? 'Salio Linalopatikana:' : 'Wallet Balance:'}</span>
                <span className="font-bold text-[var(--forest)] font-display text-sm">
                  Tsh {balance.toLocaleString()}
                </span>
              </div>

              <form onSubmit={handleSendMoney} className="space-y-3">
                {/* Method selector */}
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Njia ya Kutuma' : 'Delivery Method'}
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {[
                      { id: 'wallet', name: 'Ardhi' },
                      { id: 'mpesa', name: 'M-Pesa' },
                      { id: 'tigopesa', name: 'Tigo' },
                      { id: 'airtel', name: 'Airtel' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setSendMethod(m.id as any)}
                        className={`py-1.5 text-[11px] font-bold rounded-lg border transition-all ${
                          sendMethod === m.id
                            ? 'bg-[var(--forest)] text-white border-[var(--forest)]'
                            : 'bg-[var(--bg)] text-[var(--ink)] border-[var(--line)]'
                        }`}
                      >
                        {m.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Recipient Input */}
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Namba ya Simu au Jina la Mkulima' : 'Recipient Phone or Farmer Name'}
                  </label>
                  <div className="flex items-center rounded-xl bg-[var(--bg)] border border-[var(--line)] px-3 py-2">
                    <Phone className="w-3.5 h-3.5 text-[var(--ink-soft)] mr-2 flex-shrink-0" />
                    <input
                      type="text"
                      required
                      value={sendRecipient}
                      onChange={(e) => setSendRecipient(e.target.value)}
                      placeholder={isSw ? 'Mfano: 0754 888 111 au Rashid' : 'e.g. 0754 888 111'}
                      className="w-full bg-transparent text-xs font-medium text-[var(--ink)] outline-none"
                    />
                  </div>
                </div>

                {/* Amount Input */}
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Kiasi (Tsh)' : 'Amount (Tsh)'}
                  </label>
                  <input
                    type="number"
                    required
                    value={sendAmount}
                    onChange={(e) => setSendAmount(e.target.value)}
                    placeholder="25000"
                    className="w-full px-3 py-2 text-sm font-bold font-display rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                  />
                  {/* Quick amount chips */}
                  <div className="flex gap-1.5 mt-1.5">
                    {['10000', '25000', '50000', '100000'].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setSendAmount(amt)}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[var(--bg)] hover:bg-[var(--line)] text-[var(--ink)] font-semibold border border-[var(--line)]"
                      >
                        +{Number(amt) / 1000}k
                      </button>
                    ))}
                  </div>
                </div>

                {/* Note / Purpose */}
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Kumbukumbu / Sababu (Hiari)' : 'Note / Reference (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={sendNote}
                    onChange={(e) => setSendNote(e.target.value)}
                    placeholder={isSw ? 'Mfano: Malipo ya vibarua wa palizi' : 'e.g. Fertilizer fee'}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                  />
                </div>

                {/* Security PIN */}
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-[var(--forest)]" />
                    <span>{isSw ? 'Weka PIN yako ya Siri (1234)' : 'Enter 4-Digit PIN (1234)'}</span>
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={securityPin}
                    onChange={(e) => setSecurityPin(e.target.value)}
                    placeholder="****"
                    className="w-full text-center font-display text-lg tracking-widest py-2 rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none focus:border-[var(--forest)]"
                  />
                </div>

                {sendError && (
                  <div className="p-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{sendError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSw ? 'Thibitisha na Utume Pesa' : 'Confirm & Transfer'}</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: BUY INPUT ITEM CHECKOUT */}
      <AnimatePresence>
        {showBuyModal && selectedInputItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-5 border border-[var(--line)] shadow-2xl relative"
            >
              <button
                onClick={() => setShowBuyModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2.5 mb-3">
                <div className="text-2xl p-2 rounded-xl bg-[var(--gold-soft)]">
                  {selectedInputItem.icon}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-[var(--ink)]">
                    {isSw ? selectedInputItem.nameSw : selectedInputItem.nameEn}
                  </h3>
                  <div className="text-[10px] text-[var(--ink-soft)]">
                    {selectedInputItem.supplier}
                  </div>
                </div>
              </div>

              <form onSubmit={handleBuyInputSubmit} className="space-y-3">
                <div className="p-3 rounded-xl bg-[var(--bg)] text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-[var(--ink-soft)]">{isSw ? 'Bei kwa Kipimo:' : 'Unit Price:'}</span>
                    <span className="font-bold text-[var(--ink)]">Tsh {selectedInputItem.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[var(--ink-soft)]">{isSw ? 'Idadi ya Vipimo:' : 'Quantity:'}</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setInputQuantity(Math.max(1, inputQuantity - 1))}
                        className="w-6 h-6 rounded-md bg-[var(--line)] text-xs font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold w-4 text-center">{inputQuantity}</span>
                      <button
                        type="button"
                        onClick={() => setInputQuantity(inputQuantity + 1)}
                        className="w-6 h-6 rounded-md bg-[var(--line)] text-xs font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-[var(--line)] flex justify-between font-bold text-sm">
                    <span>{isSw ? 'Jumla ya Malipo:' : 'Total Payable:'}</span>
                    <span className="text-[var(--forest)] font-display">
                      Tsh {(selectedInputItem.price * inputQuantity).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-[var(--ink-soft)] flex items-center justify-between px-1">
                  <span>{isSw ? 'Salio Linalobaki:' : 'Remaining Balance:'}</span>
                  <span className="font-semibold text-[var(--ink)]">
                    Tsh {Math.max(0, balance - selectedInputItem.price * inputQuantity).toLocaleString()}
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={selectedInputItem.price * inputQuantity > balance}
                  className="w-full py-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-md disabled:opacity-50 transition-all cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>{isSw ? 'Lipia Pembejeo Hii Sasa' : 'Authorize Payment'}</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 3: TOP UP WALLET */}
      <AnimatePresence>
        {showTopUpModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-5 border border-[var(--line)] shadow-2xl relative"
            >
              <button
                onClick={() => setShowTopUpModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <h3 className="font-display text-lg font-bold text-[var(--ink)] mb-1">
                {isSw ? 'Weka Pesa kwenye Pochi' : 'Top Up Ardhi Wallet'}
              </h3>
              <p className="text-xs text-[var(--ink-soft)] mb-3">
                {isSw
                  ? 'Pokea ujumbe wa USSD kwenye simu yako ili kuidhinisha malipo kutoka akaunti yako ya mtandao.'
                  : 'You will receive a mobile money USSD prompt on your phone to authorize transfer.'}
              </p>

              <form onSubmit={handleTopUpSubmit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Chagua Mtandao' : 'Select Network'}
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: 'mpesa', name: 'M-Pesa' },
                      { id: 'tigopesa', name: 'Tigo Pesa' },
                      { id: 'airtel', name: 'Airtel Money' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setTopUpMethod(m.id as any)}
                        className={`py-2 text-[11px] font-bold rounded-xl border transition-all ${
                          topUpMethod === m.id
                            ? 'bg-[var(--forest)] text-white border-[var(--forest)]'
                            : 'bg-[var(--bg)] text-[var(--ink)] border-[var(--line)]'
                        }`}
                      >
                        {m.name}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Kiasi cha Kuweka (Tsh)' : 'Top-Up Amount (Tsh)'}
                  </label>
                  <input
                    type="number"
                    required
                    value={topUpAmount}
                    onChange={(e) => setTopUpAmount(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold font-display rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                  />
                  <div className="flex gap-1.5 mt-1.5">
                    {['30000', '50000', '100000', '200000'].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setTopUpAmount(amt)}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[var(--bg)] hover:bg-[var(--line)] text-[var(--ink)] font-semibold border border-[var(--line)]"
                      >
                        +{Number(amt) / 1000}k
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-[var(--bg)] text-xs text-[var(--ink-soft)]">
                  {isSw ? 'Namba ya simu itakayokatwa:' : 'Deducted phone number:'}{' '}
                  <strong className="text-[var(--ink)]">{user.phone}</strong>
                </div>

                <button
                  type="submit"
                  disabled={isProcessingTopUp}
                  className="w-full py-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>
                    {isProcessingTopUp
                      ? (isSw ? 'Inatuma ombi la USSD...' : 'Sending USSD prompt...')
                      : (isSw ? 'Weka Pesa Sasa' : 'Initiate Deposit')}
                  </span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 4: ALLOCATE TO FARM GROWTH WALLET */}
      <AnimatePresence>
        {showGrowthModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-5 border border-[var(--line)] shadow-2xl relative my-6"
            >
              <button
                onClick={() => {
                  setShowGrowthModal(false);
                  setGrowthError(null);
                }}
                className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                  <Sprout className="w-4 h-4" />
                </div>
                <h3 className="font-display text-lg font-bold text-[var(--ink)]">
                  {isSw ? 'Tenga Salio la Shamba' : 'Allocate to Farm Vault'}
                </h3>
              </div>

              <p className="text-xs text-[var(--ink-soft)] mb-3">
                {isSw
                  ? 'Hamisha pesa kutoka pochi yako kuu kwenda Mfuko wa Kukuza Shamba ili kununua pembejeo za msimu wa Masika.'
                  : 'Transfer funds from your main wallet into your dedicated Farm Growth Vault to fund upcoming seasonal inputs.'}
              </p>

              {growthError && (
                <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs flex items-center gap-2 mb-3">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{growthError}</span>
                </div>
              )}

              <form onSubmit={handleAllocateToGrowth} className="space-y-3">
                <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-1.5 text-xs">
                  <div className="flex justify-between text-[var(--ink-soft)]">
                    <span>{isSw ? 'Pochi Kuu Inayopatikana:' : 'Main Available Balance:'}</span>
                    <strong className="text-[var(--forest)] font-display">Tsh {balance.toLocaleString()}</strong>
                  </div>
                  <div className="flex justify-between text-[var(--ink-soft)]">
                    <span>{isSw ? 'Salio la Mfuko wa Shamba:' : 'Current Growth Stash:'}</span>
                    <strong className="text-emerald-600 font-display">Tsh {growthBalance.toLocaleString()}</strong>
                  </div>
                  <div className="flex justify-between text-[var(--ink-soft)]">
                    <span>{isSw ? 'Lengo la Msimu:' : 'Season Target Goal:'}</span>
                    <strong className="text-amber-600 font-display">Tsh {growthTarget.toLocaleString()}</strong>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Kiasi cha Kutenga (Tsh)' : 'Allocation Amount (Tsh)'}
                  </label>
                  <input
                    type="number"
                    required
                    value={growthAllocateAmount}
                    onChange={(e) => setGrowthAllocateAmount(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold font-display rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                    placeholder="mf. 30000"
                  />
                  <div className="flex gap-1.5 mt-1.5">
                    {['20000', '30000', '50000', '70000'].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setGrowthAllocateAmount(amt)}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[var(--bg)] hover:bg-[var(--line)] text-[var(--ink)] font-semibold border border-[var(--line)]"
                      >
                        +{Number(amt) / 1000}k
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-800 dark:text-emerald-300">
                  🌱 {isSw ? 'Pesa hii inahifadhiwa maalum kwa mbegu & mbolea tu.' : 'Locked safely for seasonal seeds & fertilizer purchases.'}
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <Sprout className="w-4 h-4" />
                  <span>{isSw ? 'Idhinisha Kutenga Salio' : 'Confirm Allocation'}</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 5: SUCCESS RECEIPT */}
      <AnimatePresence>
        {successReceipt && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-6 border border-[var(--line)] shadow-2xl relative text-center"
            >
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <h3 className="font-display text-xl font-bold text-[var(--ink)]">
                {successReceipt.title}
              </h3>

              <div className="font-display text-2xl font-bold text-[var(--forest)] my-2">
                Tsh {successReceipt.amount.toLocaleString()}
              </div>

              <p className="text-xs text-[var(--ink-soft)] leading-relaxed mb-4">
                {successReceipt.details}
              </p>

              <div className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink-soft)] font-mono mb-4">
                Ref: {successReceipt.reference}
              </div>

              <button
                onClick={() => setSuccessReceipt(null)}
                className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-bold shadow-md cursor-pointer"
              >
                {isSw ? 'Imekamilika' : 'Done'}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
