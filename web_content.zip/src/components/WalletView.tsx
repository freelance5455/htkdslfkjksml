import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { exportFileToDeviceFolder } from '../lib/fileExportHelper';
import { 
  Wallet, 
  DollarSign, 
  Zap, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck, 
  RefreshCw, 
  Download, 
  ExternalLink, 
  CreditCard, 
  Building2, 
  CheckCircle2, 
  History, 
  AlertCircle, 
  Sparkles, 
  Filter, 
  ChevronRight, 
  Lock, 
  Copy, 
  Check,
  FileText,
  Fingerprint,
  Scan,
  TrendingUp,
  FileCheck,
  Table,
  Link2,
  BellRing
} from 'lucide-react';
import { imsiEngine, ImsiWalletBalances, ImsiLedgerTransaction } from '../lib/imsiEngine';
import { financialMessenger, WithdrawalRequest } from '../lib/financialMessenger';
import { CryptoTickerBar } from './CryptoTickerBar';
import { PortfolioDashboard } from './PortfolioDashboard';
import { GlobalCurrencyExchangeWidget } from './GlobalCurrencyExchangeWidget';
import { MiningStatusDashboard } from './MiningStatusDashboard';
import { GlobalPaymentGateway } from './GlobalPaymentGateway';
import { MobileBankIntegration } from './MobileBankIntegration';
import { TelecomNetworkIntegration } from './TelecomNetworkIntegration';
import { MiningHardwareDashboard } from './MiningHardwareDashboard';
import { DetailedTransactionLogTable } from './DetailedTransactionLogTable';
import { WalletGrowthChart } from './WalletGrowthChart';
import { BiometricAuthModal } from './BiometricAuthModal';
import { WalletConnectPanel } from './WalletConnectPanel';
import { PriceAlertManager } from './PriceAlertManager';
import { CrossChainSyncMonitor } from './CrossChainSyncMonitor';
import { JuhnkrixEnginesMachineStudio } from './JuhnkrixEnginesMachineStudio';
import { generateSignedPdfLedger } from '../lib/pdfLedgerGenerator';
import { exportAccountingCsv } from '../lib/csvLedgerExporter';
import { BiometricAuthResult } from '../lib/webAuthnBiometric';
import { CurrencyToggle } from './CurrencyToggle';
import { QRPaymentGenerator } from './QRPaymentGenerator';
import { AssetWatchlistAlertSystem } from './AssetWatchlistAlertSystem';
import { MiningEfficiencyDashboard } from './MiningEfficiencyDashboard';
import { MiningRigHealthWidget } from './MiningRigHealthWidget';
import { GlobalAssetAllocationChart } from './GlobalAssetAllocationChart';
import { AutoPayoutConfigModule } from './AutoPayoutConfigModule';
import { NetworkLatencyMonitor } from './NetworkLatencyMonitor';
import { BtcWalletDisplay } from './BtcWalletDisplay';
import { AssetSyncDashboard } from './AssetSyncDashboard';
import { MiningPerformanceChart } from './MiningPerformanceChart';
import { SmartContractAuditModule } from './SmartContractAuditModule';
import { OfflineBibleReader } from './OfflineBibleReader';
import { GlobalPrayerHeatmap } from './GlobalPrayerHeatmap';
import { ShareBreakthroughModal, BreakthroughSharePayload } from './ShareBreakthroughModal';
import { currencyConverter, DisplayCurrency, CURRENCY_REGISTRY } from '../lib/currencyConverter';
import { MiningRoiCalculator } from './MiningRoiCalculator';
import { AutoAlertManager } from './AutoAlertManager';
import { PayoutMethodManager } from './PayoutMethodManager';
import { SeedSowingHistoryView } from './SeedSowingHistoryView';
import { OwnerEarningsMasterDashboard } from './OwnerEarningsMasterDashboard';

interface WalletViewProps {
  onOpenConverto?: () => void;
  onOpenImsiData?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ onOpenConverto, onOpenImsiData }) => {
  const [wallet, setWallet] = useState<ImsiWalletBalances>(() => imsiEngine.getWalletBalances());
  const [ledger, setLedger] = useState<ImsiLedgerTransaction[]>(() => imsiEngine.getLedger());
  const [displayCurrency, setDisplayCurrency] = useState<DisplayCurrency>(() => currencyConverter.getCurrency());
  const [filterType, setFilterType] = useState<'ALL' | 'CASH' | 'BITCOIN' | 'SMS_CHARGE' | 'CONVERTO'>('ALL');
  const [showWithdrawModal, setShowWithdrawModal] = useState<boolean>(false);
  const [showBiometricModal, setShowBiometricModal] = useState<boolean>(false);
  const [breakthroughSharePayload, setBreakthroughSharePayload] = useState<BreakthroughSharePayload | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [isExportingCsv, setIsExportingCsv] = useState<boolean>(false);
  const [withdrawType, setWithdrawType] = useState<'bank_account' | 'crypto_wallet'>('bank_account');
  const [withdrawAmountNgn, setWithdrawAmountNgn] = useState<string>('1000');
  const [withdrawBtcSats, setWithdrawBtcSats] = useState<string>('500');
  const [selectedBank, setSelectedBank] = useState<string>('Opay Mobile Bank - 7071918280 (JUHNKRIX STEPHEN)');
  const [customBankDetails, setCustomBankDetails] = useState<string>('');
  const [selectedCryptoDest, setSelectedCryptoDest] = useState<string>('Bitcoin Altar Vault (bc1qjuhnkrixaltarvaultbitcoin999777888)');
  const [customCryptoAddress, setCustomCryptoAddress] = useState<string>('');
  const [withdrawNote, setWithdrawNote] = useState<string>('Prophetic Ministry Operations');
  const [withdrawLoading, setWithdrawLoading] = useState<boolean>(false);
  const [withdrawSuccessMsg, setWithdrawSuccessMsg] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 4000);
  };

  useEffect(() => {
    const unsubImsi = imsiEngine.subscribe(() => {
      setWallet(imsiEngine.getWalletBalances());
      setLedger(imsiEngine.getLedger());
    });
    const unsubCurrency = currencyConverter.subscribe((curr) => {
      setDisplayCurrency(curr);
    });
    return () => {
      unsubImsi();
      unsubCurrency();
    };
  }, []);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    showToast(`✓ Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedText(null), 2500);
  };

  // Download Cryptographically Signed PDF Ledger
  const handleDownloadPdfLedger = async () => {
    try {
      setIsGeneratingPdf(true);
      showToast('📄 Compiling & cryptographically signing financial ledger PDF...');
      
      const { blob, fileName, sha256Hash } = await generateSignedPdfLedger({
        wallet,
        ledger,
        ownerName: 'PROPHET JUHNKRIX SYNVAGORD',
        phoneNumber: '07071918280',
        subdomain: 'juhnkrixmusika.pages.dev'
      });

      // Trigger device storage folder export with File System Access API
      await exportFileToDeviceFolder(fileName, blob, 'application/pdf');

      showToast(`✓ Signed PDF Ledger saved to device folder! (SHA-256: ${sha256Hash.substring(0, 12)}...)`);
    } catch (err: any) {
      showToast(`❌ Error generating signed PDF: ${err.message || 'Unknown error'}`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Export Complete Financial Ledger as Formatted CSV
  const handleExportCsvLedger = () => {
    try {
      setIsExportingCsv(true);
      const res = exportAccountingCsv({
        wallet,
        ledger,
        ownerName: 'PROPHET JUHNKRIX SYNVAGORD',
        companyName: 'JUHNKRIX MUSIKA SOVEREIGN TREASURY',
        subdomain: 'juhnkrixmusika.pages.dev',
        phone: '07071918280'
      });
      showToast(`✓ Exported ${res.rowCount} ledger rows to ${res.fileName} (CSV format)!`);
    } catch (err: any) {
      showToast(`❌ Error exporting CSV: ${err.message || 'Failed'}`);
    } finally {
      setIsExportingCsv(false);
    }
  };

  // Step 1: User requests withdrawal -> Opens WebAuthn Biometric Security Check
  const handleInitiateWithdrawal = () => {
    if (withdrawType === 'bank_account') {
      const amt = Number(withdrawAmountNgn);
      if (isNaN(amt) || amt <= 0) {
        showToast('⚠️ Please enter a valid NGN withdrawal amount.');
        return;
      }
      if (amt > wallet.cashNgn) {
        showToast(`⚠️ Insufficient cash balance. Available: ₦${wallet.cashNgn.toLocaleString()}`);
        return;
      }
    } else {
      const sats = Number(withdrawBtcSats);
      if (isNaN(sats) || sats <= 0) {
        showToast('⚠️ Please enter a valid Bitcoin Satoshi amount.');
        return;
      }
      if (sats > wallet.bitcoinSats) {
        showToast(`⚠️ Insufficient Bitcoin balance. Available: ${wallet.bitcoinSats.toLocaleString()} Sats`);
        return;
      }
    }

    setShowBiometricModal(true);
  };

  // Step 2: Biometric passed -> Execute withdrawal on chain / mobile bank
  const handleBiometricSuccess = async (bioResult: BiometricAuthResult) => {
    setShowBiometricModal(false);
    setWithdrawLoading(true);
    setWithdrawSuccessMsg(null);

    try {
      const destination = withdrawType === 'bank_account'
        ? (customBankDetails.trim() || selectedBank)
        : (customCryptoAddress.trim() || selectedCryptoDest);

      const request: WithdrawalRequest = {
        destinationType: withdrawType,
        amountNgn: withdrawType === 'bank_account' ? Number(withdrawAmountNgn) : undefined,
        btcSats: withdrawType === 'crypto_wallet' ? Number(withdrawBtcSats) : undefined,
        accountOrAddress: destination,
        bankName: withdrawType === 'bank_account' ? selectedBank : undefined,
        note: `${withdrawNote} [WebAuthn: ${bioResult.authToken.substring(0, 24)}]`
      };

      const res = await financialMessenger.executeWithdrawal(request);
      setWithdrawSuccessMsg(res.message);
      showToast(`✓ Biometrically Authorized! Dispatched ${withdrawType === 'bank_account' ? `₦${withdrawAmountNgn}` : `${withdrawBtcSats} Sats`} successfully.`);
      setTimeout(() => {
        setShowWithdrawModal(false);
        setWithdrawSuccessMsg(null);
      }, 3500);
    } catch (err: any) {
      showToast(`❌ Withdrawal error: ${err.message || 'Failed to process withdrawal'}`);
    } finally {
      setWithdrawLoading(false);
    }
  };

  const filteredLedger = ledger.filter(tx => {
    if (filterType === 'ALL') return true;
    if (filterType === 'CASH') return tx.convertedCashNgn > 0;
    if (filterType === 'BITCOIN') return tx.convertedBtcSats > 0;
    if (filterType === 'SMS_CHARGE') return tx.id.includes('imsi');
    if (filterType === 'CONVERTO') return tx.id.includes('converto');
    return true;
  });

  const getWithdrawAmountFormatted = () => {
    if (withdrawType === 'bank_account') {
      return `₦${Number(withdrawAmountNgn).toLocaleString()} NGN`;
    }
    return `${Number(withdrawBtcSats).toLocaleString()} Satoshis (BTC)`;
  };

  const getWithdrawDestinationFormatted = () => {
    if (withdrawType === 'bank_account') {
      return customBankDetails.trim() || selectedBank;
    }
    return customCryptoAddress.trim() || selectedCryptoDest;
  };

  return (
    <div className="space-y-8 animate-fadeIn text-slate-100 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border-2 border-amber-400 text-amber-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* FEATURE 1: REAL-TIME CRYPTO & CONVERTO TICKER BAR */}
      <CryptoTickerBar />

      {/* Header Banner */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
              <Wallet className="w-4 h-4 text-amber-400" />
              <span>JUHNKRIX MUSIKA APP WALLET & REVENUE VAULT</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-amber-100">
              Prophetic Treasury & Digital Asset Balances
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl">
              Real-time synchronization of ₦5 IMSI telecommunications carrier deductions, CONVERTO airtime-to-cash, data-to-bitcoin tokenization, and multi-bank settlement accounts.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* FEATURE: GLOBAL CURRENCY DISPLAY TOGGLE */}
            <CurrencyToggle />

            <button
              onClick={() => setShowWithdrawModal(true)}
              className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-105"
            >
              <Fingerprint className="w-4 h-4 text-slate-950" />
              <span>WITHDRAW FUNDS (WEBAUTHN)</span>
            </button>

            {/* DOWNLOAD SIGNED PDF LEDGER BUTTON */}
            <button
              onClick={handleDownloadPdfLedger}
              disabled={isGeneratingPdf}
              className="px-4 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center space-x-2 shadow-xl shadow-amber-500/10 transition-all hover:scale-105"
            >
              {isGeneratingPdf ? (
                <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              ) : (
                <FileCheck className="w-4 h-4 text-amber-400" />
              )}
              <span>SIGNED PDF</span>
            </button>

            {/* EXPORT CSV ACCOUNTING LEDGER BUTTON */}
            <button
              onClick={handleExportCsvLedger}
              disabled={isExportingCsv}
              className="px-4 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center space-x-2 shadow-xl shadow-emerald-500/10 transition-all hover:scale-105"
            >
              <Table className="w-4 h-4 text-emerald-400" />
              <span>EXPORT CSV</span>
            </button>

            {onOpenConverto && (
              <button
                onClick={onOpenConverto}
                className="px-4 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-extrabold text-xs flex items-center space-x-2 shadow-xl shadow-amber-500/20 hover:scale-105 transition-all"
              >
                <Zap className="w-4 h-4 text-slate-950" />
                <span>CONVERTO</span>
              </button>
            )}

            {onOpenImsiData && (
              <button
                onClick={onOpenImsiData}
                className="px-4 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center space-x-2 transition-all"
              >
                <History className="w-4 h-4 text-amber-400" />
                <span>IMSI DATA</span>
              </button>
            )}
          </div>
        </div>

        {/* Primary Balances Grid with Framer-Motion Entrance Animations */}
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.15 }
            }
          }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8"
        >
          {/* Cash Balance Card */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 25 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: 'easeOut' } }
            }}
            className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 relative overflow-hidden shadow-xl space-y-4 hover:border-amber-400 transition-all hover:scale-101"
          >
            <div className="flex justify-between items-center">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center space-x-1.5">
                <DollarSign className="w-4 h-4 text-amber-400" />
                <span>Cash Money Balance ({displayCurrency})</span>
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 text-[10px] font-bold">
                Instant Settlement
              </span>
            </div>

            <div>
              <div className="text-3xl sm:text-4xl font-black text-amber-100 tracking-tight">
                {currencyConverter.formatFromNgn(wallet.cashNgn, displayCurrency)}
              </div>
              <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                <span>Base: <strong>₦{wallet.cashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })} NGN</strong></span>
                {displayCurrency !== 'USD' && (
                  <span className="text-amber-300 font-bold">
                    • ${(wallet.cashNgn / 1550).toFixed(2)} USD
                  </span>
                )}
                {displayCurrency !== 'BTC' && (
                  <span className="text-cyan-300 font-mono text-[11px]">
                    • ₿{((wallet.cashNgn / 1550) / 96420).toFixed(6)} BTC
                  </span>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
              <span>Settlement Account:</span>
              <span className="font-bold text-amber-200">Opay (7071918280)</span>
            </div>
          </motion.div>

          {/* Bitcoin Balance Card */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 25 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: 'easeOut' } }
            }}
            className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 relative overflow-hidden shadow-xl space-y-4 hover:border-amber-400 transition-all hover:scale-101"
          >
            <div className="flex justify-between items-center">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Bitcoin & Crypto Vault ({displayCurrency})</span>
              </span>
              <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-400/30 text-[10px] font-bold">
                On-Chain Vault
              </span>
            </div>

            <div>
              <div className="text-3xl sm:text-4xl font-black text-amber-100 tracking-tight">
                {displayCurrency === 'BTC'
                  ? `${(wallet.bitcoinSats / 100000000).toFixed(6)} ₿`
                  : currencyConverter.formatFromSats(wallet.bitcoinSats, displayCurrency)}
              </div>
              <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                <span>Holdings: <strong className="text-amber-300 font-mono">{wallet.bitcoinSats.toLocaleString()} Sats</strong></span>
                <span className="font-mono text-amber-300">({wallet.bitcoinFormatted})</span>
                {displayCurrency !== 'USD' && (
                  <span className="text-emerald-400 font-bold">
                    • ${((wallet.bitcoinSats / 100000000) * 96420).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                  </span>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
              <span>Vault Address:</span>
              <span className="font-mono text-[10px] text-amber-300 truncate max-w-[160px]">bc1qjuhnkrixaltar...</span>
            </div>
          </motion.div>

          {/* Telecom Carrier Revenue Card */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 25 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: 'easeOut' } }
            }}
            className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 relative overflow-hidden shadow-xl space-y-4 md:col-span-2 lg:col-span-1 hover:border-amber-400 transition-all hover:scale-101"
          >
            <div className="flex justify-between items-center">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Building2 className="w-4 h-4 text-amber-400" />
                <span>Carrier SIM Info</span>
              </span>
              <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-400 border border-blue-400/30 text-[10px] font-bold">
                IMSI 62130-777
              </span>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Bound Number:</span>
                <span className="font-bold text-amber-200">07071918280</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Fixed Magic IP:</span>
                <span className="font-mono font-bold text-amber-300">142.250.190.46</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Domain URL:</span>
                <span className="font-bold text-amber-200">juhnkrixmusika.pages.dev</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Carrier Tariff:</span>
                <span className="font-bold text-emerald-400">₦5.00 / SMS / 2.5 MB</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* NEW FEATURE: AUTO-DETECTED BTC WALLET QR CODE (juhnkrix@gmail.com) */}
      <BtcWalletDisplay />

      {/* NEW FEATURE: ASSET SYNC DASHBOARD */}
      <AssetSyncDashboard />

      {/* NEW FEATURE: MINING PERFORMANCE D3 CHART */}
      <MiningPerformanceChart />

      {/* FEATURE 1: D3.JS REAL-TIME CROSS-CHAIN PORTFOLIO DASHBOARD */}
      <PortfolioDashboard 
        wallet={wallet} 
        ledger={ledger} 
        onShowToast={showToast}
        onOpenConverto={onOpenConverto}
        onOpenWithdrawal={() => setShowWithdrawModal(true)}
      />

      {/* FEATURE: D3.JS GLOBAL ASSET ALLOCATION PIE CHART & LIQUIDITY MATRIX */}
      <GlobalAssetAllocationChart
        wallet={wallet}
        onShowToast={showToast}
      />

      {/* FEATURE: GLOBAL MULTI-RAIL PAYMENT & TITHING GATEWAY */}
      <GlobalPaymentGateway
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: DYNAMIC MULTI-RAIL QR PAYMENT & DONATION GENERATOR */}
      <QRPaymentGenerator
        wallet={wallet}
        onShowToast={showToast}
      />

      {/* FEATURE: MOBILE BANKING API & WEB3 BRIDGE INTERFACE */}
      <MobileBankIntegration
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: AUTO-PAYOUT CONFIGURATION & AUTOMATED BANK SETTLEMENT */}
      <AutoPayoutConfigModule
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: TELECOM NETWORK INTEGRATION & UNUSED DATA CONVERTER */}
      <TelecomNetworkIntegration
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: MINING HARDWARE DASHBOARD & THERMAL EFFICIENCY OPTIMIZER */}
      <MiningHardwareDashboard
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: D3.JS MINING EFFICIENCY, HASH RATE, ELECTRICITY & NET MARGIN DASHBOARD */}
      <MiningEfficiencyDashboard
        wallet={wallet}
        onShowToast={showToast}
        onOpenBiometricAuth={() => setShowBiometricModal(true)}
      />

      {/* FEATURE: MINING RIG HEALTH & REAL-TIME REMOTE NODE RESET ENGINE */}
      <MiningRigHealthWidget
        wallet={wallet}
        onShowToast={showToast}
      />

      {/* FEATURE: ASSET SYNC DASHBOARD */}
      <AssetSyncDashboard />

      {/* FEATURE: MINING ROI CALCULATOR COMPONENT */}
      <MiningRoiCalculator
        displayCurrency={displayCurrency}
        onShowToast={showToast}
      />

      {/* FEATURE: AUTO-ALERT MANAGER FOR PORTFOLIO GROWTH / DROP (10% 24H) */}
      <AutoAlertManager
        currentTotalUsd={(wallet.cashNgn / 1550) + (wallet.bitcoinSats * 0.00000095 * 95000)}
        onShowToast={showToast}
      />

      {/* FEATURE: PAYOUT METHOD MANAGER UI FOR FAST SECURE WITHDRAWALS */}
      <PayoutMethodManager
        onSelectMethod={(m) => {
          if (m.type === 'bank') {
            setSelectedBank(`${m.title} - ${m.detail} (${m.holderName})`);
            setWithdrawType('bank_account');
          } else {
            setSelectedCryptoDest(`${m.title} (${m.detail})`);
            setWithdrawType('crypto_wallet');
          }
          showToast(`✓ Applied payout destination: ${m.title}`);
        }}
        onShowToast={showToast}
      />

      {/* FEATURE 2: GLOBAL FIAT & CRYPTOCURRENCY EXCHANGE WIDGET */}
      <GlobalCurrencyExchangeWidget
        wallet={wallet}
        onShowToast={showToast}
        onOpenWithdrawal={() => setShowWithdrawModal(true)}
      />

      {/* FEATURE: SMART CONTRACT AUDIT & CROSS-CHAIN DEFI PROTOCOL TRUST SCORE */}
      <SmartContractAuditModule onShowToast={showToast} />

      {/* FEATURE: D3.JS GLOBAL PRAYER PARTICIPATION & TIMEZONE HEATMAP */}
      <GlobalPrayerHeatmap onShowToast={showToast} />

      {/* FEATURE: LIGHTWEIGHT OFFLINE BIBLE READER & PROPHETIC REVELATION VAULT */}
      <OfflineBibleReader 
        onShowToast={showToast}
        onOpenBreakthroughModal={(p) => setBreakthroughSharePayload(p)}
      />

      {/* FEATURE: NETWORK SPEED TEST & GLOBAL BANKING LATENCY MONITOR */}
      <NetworkLatencyMonitor onShowToast={showToast} />

      {/* FEATURE: CROSS-CHAIN BLOCKCHAIN NODE SYNC STATUS */}
      <CrossChainSyncMonitor onShowToast={showToast} />

      {/* FEATURE: WALLETCONNECT MULTI-CHAIN WEB3 INTEGRATION */}
      <WalletConnectPanel onShowToast={showToast} />

      {/* FEATURE: ASSET WATCHLIST & PRICE TARGET ALERT ENGINE */}
      <AssetWatchlistAlertSystem onShowToast={showToast} />

      {/* FEATURE: REAL-TIME PRICE MONITORING SYSTEM & PUSH NOTIFICATIONS */}
      <PriceAlertManager onShowToast={showToast} />

      {/* FEATURE: JUHNKRIX MUSIKA SOVEREIGN UNIFIED ENGINES & HARDWARE MATRIX */}
      <JuhnkrixEnginesMachineStudio 
        onShowToast={showToast} 
        onOpenWithdrawal={() => setShowWithdrawModal(true)} 
      />

      {/* FEATURE: D3.JS 30-DAY WALLET BALANCE GROWTH CHART */}
      <WalletGrowthChart wallet={wallet} ledger={ledger} />

      {/* FEATURE 4: DETAILED CRYPTO & CASH HISTORICAL TRANSACTION LOG TABLE */}
      <DetailedTransactionLogTable
        ledger={ledger}
        wallet={wallet}
        onShowToast={showToast}
      />

      {/* SHARE MY BREAKTHROUGH & TESTIMONY IMAGE CARD GENERATOR MODAL */}
      {breakthroughSharePayload && (
        <ShareBreakthroughModal
          payload={breakthroughSharePayload}
          onClose={() => setBreakthroughSharePayload(null)}
          onShowToast={showToast}
        />
      )}

      {/* Interactive Withdrawal Modal */}
      {showWithdrawModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 border-2 border-amber-500/60 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl text-slate-100">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-4">
              <div className="space-y-1">
                <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
                  <ArrowUpRight className="w-5 h-5 text-emerald-400" />
                  <span>Withdraw Treasury Funds</span>
                </h3>
                <p className="text-xs text-slate-400">Transfer cash money to bank account or Bitcoin to crypto vault.</p>
              </div>
              <button
                onClick={() => setShowWithdrawModal(false)}
                className="text-slate-400 hover:text-amber-200 text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            {withdrawSuccessMsg ? (
              <div className="p-5 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h4 className="text-base font-extrabold text-emerald-200">Withdrawal Dispatched!</h4>
                <p className="text-xs text-emerald-300">{withdrawSuccessMsg}</p>
              </div>
            ) : (
              <div className="space-y-5">
                {/* Method Selector */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setWithdrawType('bank_account')}
                    className={`p-3.5 rounded-2xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                      withdrawType === 'bank_account'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/20'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Building2 className="w-4 h-4 text-amber-400" />
                    <span>Mobile Bank (₦ NGN)</span>
                  </button>

                  <button
                    onClick={() => setWithdrawType('crypto_wallet')}
                    className={`p-3.5 rounded-2xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                      withdrawType === 'crypto_wallet'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/20'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>Bitcoin Altar Vault</span>
                  </button>
                </div>

                {/* Bank Account Fields */}
                {withdrawType === 'bank_account' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Amount to Withdraw (₦ NGN):
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={withdrawAmountNgn}
                          onChange={(e) => setWithdrawAmountNgn(e.target.value)}
                          className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-4 py-2.5 text-sm text-amber-200 font-bold focus:outline-none focus:border-amber-400"
                        />
                        <span className="absolute right-3 top-2.5 text-xs text-slate-500 font-bold">NGN</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                        <span>Available: ₦{wallet.cashNgn.toLocaleString()}</span>
                        <button
                          onClick={() => setWithdrawAmountNgn(wallet.cashNgn.toString())}
                          className="text-amber-400 font-bold hover:underline"
                        >
                          Max All
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Destination Bank Account:
                      </label>
                      <select
                        value={selectedBank}
                        onChange={(e) => setSelectedBank(e.target.value)}
                        className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                      >
                        <option value="Opay Mobile Bank - 7071918280 (JUHNKRIX STEPHEN)">Opay Mobile Bank - 7071918280 (JUHNKRIX STEPHEN)</option>
                        <option value="Opay Mobile Bank - 7055737988 (JUHNKRIX STEPHEN)">Opay Mobile Bank - 7055737988 (JUHNKRIX STEPHEN)</option>
                        <option value="Fidelity Bank - 6555712574 (JUHNKRIX STEPHEN)">Fidelity Bank - 6555712574 (JUHNKRIX STEPHEN)</option>
                        <option value="Moniepoint MFB - 7071918280 (JUHNKRIX STEPHEN)">Moniepoint MFB - 7071918280 (JUHNKRIX STEPHEN)</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Amount to Transfer (Satoshis):
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={withdrawBtcSats}
                          onChange={(e) => setWithdrawBtcSats(e.target.value)}
                          className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-4 py-2.5 text-sm text-amber-200 font-bold focus:outline-none focus:border-amber-400"
                        />
                        <span className="absolute right-3 top-2.5 text-xs text-slate-500 font-bold">SATS</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                        <span>Available: {wallet.bitcoinSats.toLocaleString()} Sats</span>
                        <button
                          onClick={() => setWithdrawBtcSats(wallet.bitcoinSats.toString())}
                          className="text-amber-400 font-bold hover:underline"
                        >
                          Max All
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Destination Crypto Vault:
                      </label>
                      <select
                        value={selectedCryptoDest}
                        onChange={(e) => setSelectedCryptoDest(e.target.value)}
                        className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                      >
                        <option value="Bitcoin Altar Vault (bc1qjuhnkrixaltarvaultbitcoin999777888)">Bitcoin Altar Vault (bc1qjuhnkrixaltarvaultbitcoin999777888)</option>
                        <option value="MetaMask / Web3 Wallet (0xJUHNKRIX...9a8f)">MetaMask / Web3 Wallet (0xJUHNKRIX...9a8f)</option>
                        <option value="Trust Wallet (bc1qjuhnkrix...7721)">Trust Wallet (bc1qjuhnkrix...7721)</option>
                        <option value="MiniPay Opera Stablecoin (minipay.juhnkrix@gmail.com)">MiniPay Opera Stablecoin (minipay.juhnkrix@gmail.com)</option>
                      </select>
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Purpose / Ministry Memo:
                  </label>
                  <input
                    type="text"
                    value={withdrawNote}
                    onChange={(e) => setWithdrawNote(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                    placeholder="e.g. Prophetic broadcast operational support"
                  />
                </div>

                <div className="pt-2">
                  <button
                    disabled={withdrawLoading}
                    onClick={handleInitiateWithdrawal}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-102"
                  >
                    {withdrawLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                        <span>PROCESSING WITHDRAWAL...</span>
                      </>
                    ) : (
                      <>
                        <Fingerprint className="w-4 h-4 text-slate-950" />
                        <span>AUTHORIZE WITH WEBAUTHN BIOMETRIC</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* OWNER-ONLY MASTER EARNINGS DASHBOARD */}
      <OwnerEarningsMasterDashboard />

      {/* SEED SOWING & FLUTTERWAVE PAYOUT HISTORY TIMELINE */}
      <SeedSowingHistoryView onTriggerFlutterwavePayout={() => setShowWithdrawModal(true)} />

      {/* WEBAUTHN BIOMETRIC AUTHENTICATION MODAL */}
      <BiometricAuthModal
        isOpen={showBiometricModal}
        onClose={() => setShowBiometricModal(false)}
        onSuccess={handleBiometricSuccess}
        amountText={getWithdrawAmountFormatted()}
        destinationText={getWithdrawDestinationFormatted()}
      />
    </div>
  );
};


