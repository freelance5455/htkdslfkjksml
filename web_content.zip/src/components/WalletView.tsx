import { useState } from 'react';
import { PaymentRecord, Student } from '../types';
import {
  Wallet,
  TrendingUp,
  Clock,
  DollarSign,
  Plus,
  Trash2,
  Receipt
} from 'lucide-react';

interface WalletViewProps {
  payments: PaymentRecord[];
  students: Student[];
  onOpenNewPayment: () => void;
  onDeletePayment: (paymentId: string) => void;
}

export const WalletView = ({
  payments,
  students,
  onOpenNewPayment,
  onDeletePayment,
}: WalletViewProps) => {
  const [currencyFilter, setCurrencyFilter] = useState<'all' | 'TL' | 'USD'>('all');

  const totalEarnedTL = payments
    .filter((p) => p.currency === 'TL')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalEarnedUSD = payments
    .filter((p) => p.currency === 'USD')
    .reduce((sum, p) => sum + p.amount, 0);

  let pendingTL = 0;
  let pendingUSD = 0;

  students.forEach((s) => {
    if (s.status === 'active' && s.lessonsInCurrentCycle > 0) {
      const due = s.hourlyRate * s.lessonsInCurrentCycle;
      if (s.currency === 'USD') {
        pendingUSD += due;
      } else {
        pendingTL += due;
      }
    }
  });

  const filteredPayments = payments
    .filter((p) => (currencyFilter === 'all' ? true : p.currency === currencyFilter))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-5">
      {/* Top Cards: Balance Summaries for TL and USD */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total TL Earned */}
        <div className="bg-gradient-to-br from-emerald-950 via-[#0d2818] to-zinc-950 text-white rounded-2xl p-5 shadow-xl border border-emerald-500/30 relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 opacity-10">
            <Wallet className="w-28 h-28" />
          </div>
          <div className="flex items-center justify-between text-xs text-emerald-400 font-semibold mb-2">
            <span>Toplam Tahsil Edilen (₺)</span>
            <span className="p-1.5 rounded-lg bg-emerald-900/60 text-emerald-300 border border-emerald-500/30">
              <TrendingUp className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-3xl font-extrabold font-mono tracking-tight text-emerald-300">
            {totalEarnedTL.toLocaleString('tr-TR')} ₺
          </div>
          <p className="text-[11px] text-emerald-400/70 mt-1">
            Zeynep'in Türk Lirası cüzdan bakiyesi
          </p>
        </div>

        {/* Total USD Earned */}
        <div className="bg-gradient-to-br from-sky-950 via-[#0c2340] to-zinc-950 text-white rounded-2xl p-5 shadow-xl border border-sky-500/30 relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 opacity-10">
            <DollarSign className="w-28 h-28" />
          </div>
          <div className="flex items-center justify-between text-xs text-sky-400 font-semibold mb-2">
            <span>Toplam Tahsil Edilen ($)</span>
            <span className="p-1.5 rounded-lg bg-sky-900/60 text-sky-300 border border-sky-500/30">
              <TrendingUp className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-3xl font-extrabold font-mono tracking-tight text-sky-300">
            ${totalEarnedUSD.toLocaleString('tr-TR')}
          </div>
          <p className="text-[11px] text-sky-400/70 mt-1">
            Yabancı öğrenci döviz kazancı
          </p>
        </div>

        {/* Pending Uncollected TL */}
        <div className="bg-[#121214] rounded-2xl p-5 shadow-xl border border-zinc-800">
          <div className="flex items-center justify-between text-xs text-stone-400 font-semibold mb-2">
            <span>Ders Başı Biriken (TL)</span>
            <span className="p-1.5 rounded-lg bg-amber-950 text-amber-400 border border-amber-500/30">
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {pendingTL.toLocaleString('tr-TR')} ₺
          </div>
          <p className="text-[11px] text-stone-400 mt-1">
            Henüz döngüsü dolmamış/bekleyen dersler
          </p>
        </div>

        {/* Pending Uncollected USD */}
        <div className="bg-[#121214] rounded-2xl p-5 shadow-xl border border-zinc-800">
          <div className="flex items-center justify-between text-xs text-stone-400 font-semibold mb-2">
            <span>Ders Başı Biriken ($)</span>
            <span className="p-1.5 rounded-lg bg-amber-950 text-amber-400 border border-amber-500/30">
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            ${pendingUSD.toLocaleString('tr-TR')}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">
            Tahsil edilecek döviz tutarı
          </p>
        </div>
      </div>

      {/* Ledger Header & Actions */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#121214] p-4 rounded-2xl border border-zinc-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-zinc-900 text-stone-300 border border-zinc-800">
            <Receipt className="w-5 h-5 text-rose-400" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">
              Cüzdan Tahsilat Geçmişi
            </h3>
            <p className="text-xs text-stone-400">
              Öğrencilerden alınan tüm ödemelerin makbuz dökümü
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Currency Filter */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setCurrencyFilter('all')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                currencyFilter === 'all' ? 'bg-zinc-800 shadow-xs font-bold text-white' : 'text-stone-400'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setCurrencyFilter('TL')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                currencyFilter === 'TL' ? 'bg-emerald-950 font-bold text-emerald-300 border border-emerald-800/40' : 'text-stone-400'
              }`}
            >
              ₺ (TL)
            </button>
            <button
              onClick={() => setCurrencyFilter('USD')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                currencyFilter === 'USD' ? 'bg-sky-950 font-bold text-sky-300 border border-sky-800/40' : 'text-stone-400'
              }`}
            >
              $ (USD)
            </button>
          </div>

          <button
            onClick={onOpenNewPayment}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-950/40 cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>+ Ödeme Kaydet</span>
          </button>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-[#121214] rounded-2xl border border-zinc-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-900/90 border-b border-zinc-800 text-[11px] font-bold text-stone-400 uppercase tracking-wider">
                <th className="py-3 px-4">Tarih</th>
                <th className="py-3 px-4">Öğrenci</th>
                <th className="py-3 px-4">Açıklama / Paket</th>
                <th className="py-3 px-4">Ödeme Yöntemi</th>
                <th className="py-3 px-4">Tutar</th>
                <th className="py-3 px-4 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80 text-xs text-stone-300">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-stone-500">
                    Henüz kayıtlı bir ödeme bulunmuyor.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((payment) => {
                  const dateStr = new Date(payment.date).toLocaleDateString('tr-TR', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <tr key={payment.id} className="hover:bg-zinc-850/60 transition-colors">
                      <td className="py-3.5 px-4 font-mono text-stone-400 whitespace-nowrap">
                        {dateStr}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white">
                        {payment.studentName}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-stone-200">
                          {payment.cycleDescription}
                        </div>
                        {payment.note && (
                          <div className="text-[11px] text-stone-400 italic mt-0.5">
                            {payment.note}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] bg-zinc-800 text-stone-300 font-medium border border-zinc-700">
                          {payment.paymentMethod}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-bold font-mono text-sm whitespace-nowrap">
                        <span
                          className={
                            payment.currency === 'USD' ? 'text-sky-400' : 'text-emerald-400'
                          }
                        >
                          +{payment.amount.toLocaleString('tr-TR')}{' '}
                          {payment.currency === 'USD' ? '$' : '₺'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            if (window.confirm(`${payment.studentName} için bu ödeme kaydını silmek istediğinize emin misiniz?`)) {
                              onDeletePayment(payment.id);
                            }
                          }}
                          className="p-1 text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-all cursor-pointer"
                          title="Ödeme kaydını sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
