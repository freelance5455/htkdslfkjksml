import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';

export const WalletView: React.FC = () => {
  const {
    coins,
    diamonds,
    uid,
    upiId,
    ledger,
    addCoins,
    openOtpModal,
    showToast,
  } = useApp();

  // Deposit Form State
  const [selectedAmt, setSelectedAmt] = useState<number>(50);
  const [convertTarget, setConvertTarget] = useState<'coins' | 'diamonds'>('diamonds');
  const [utrNumber, setUtrNumber] = useState('');
  const [depositFileName, setDepositFileName] = useState('');
  const [depositSuccessToast, setDepositSuccessToast] = useState(false);
  const [depositToastMessage, setDepositToastMessage] = useState('');

  // Referral Copy State
  const [copiedReferral, setCopiedReferral] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Withdraw Form State
  const [payoutMethod, setPayoutMethod] = useState<'upi' | 'bank'>('upi');
  const [withdrawUpi, setWithdrawUpi] = useState(upiId);
  const [withdrawUpiConfirm, setWithdrawUpiConfirm] = useState(upiId);
  const [bankName, setBankName] = useState('VIKRAM SENAPATI');
  const [bankAcc, setBankAcc] = useState('918239048123');
  const [bankIfsc, setBankIfsc] = useState('BKID0000102');
  const [withdrawAmount, setWithdrawAmount] = useState<number>(500);

  const copyUpiId = () => {
    navigator.clipboard.writeText('paytm-tournament@boi');
    setCopiedUpi(true);
    showToast('Official UPI ID paytm-tournament@boi copied!');
    setTimeout(() => setCopiedUpi(false), 2200);
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText('IGNITE-V7-8492');
    setCopiedReferral(true);
    showToast('Squad Invite Code IGNITE-V7-8492 copied!');
    setTimeout(() => setCopiedReferral(false), 2200);
  };

  const copyInviteLink = () => {
    const link = 'https://igniteff.gg/invite/IGNITE-V7-8492';
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    showToast('Invite link copied to clipboard!');
    setTimeout(() => setCopiedLink(false), 2200);
  };

  const handleCustomAmt = () => {
    const custom = prompt('Enter custom deposit amount in ₹ INR:', '150');
    if (custom && !isNaN(Number(custom)) && Number(custom) > 0) {
      const val = Math.floor(Number(custom));
      setSelectedAmt(val);
    }
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!utrNumber || utrNumber.length !== 12) {
      showToast('Please enter a valid 12-digit UTR Transaction ID.', 'error');
      return;
    }

    addCoins(selectedAmt, convertTarget);
    const itemType = convertTarget === 'coins' ? `${selectedAmt} Game Coins 🪙` : `${selectedAmt} Diamonds 💎`;
    setDepositToastMessage(
      `UTR #${utrNumber} verified for ₹${selectedAmt}. Credited ${itemType} to UID: ${uid}.`
    );
    setDepositSuccessToast(true);
    setUtrNumber('');
    setDepositFileName('');
  };

  const handleWithdrawAction = () => {
    if (withdrawAmount < 50) {
      showToast('Minimum withdrawal is ₹50.', 'error');
      return;
    }

    if (payoutMethod === 'upi') {
      if (!withdrawUpi || !withdrawUpiConfirm || withdrawUpi !== withdrawUpiConfirm) {
        showToast('Please ensure UPI ID and confirmation match.', 'error');
        return;
      }
      openOtpModal(withdrawAmount, `UPI (${withdrawUpi})`);
    } else {
      if (!bankName || !bankAcc || !bankIfsc) {
        showToast('Please fill all bank details.', 'error');
        return;
      }
      openOtpModal(withdrawAmount, `Bank IMPS (...${bankAcc.slice(-4)})`);
    }
  };

  return (
    <div className="flex flex-col w-full">
      <div className="w-full px-4 sm:px-6 lg:px-10 py-6 flex flex-col gap-8 relative overflow-hidden">
        {/* Ambient glowing tactical orbs */}
        <div className="absolute -top-32 left-1/4 w-96 h-96 bg-primary-container/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-80 h-80 bg-tertiary/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header Telemetry Strip */}
        <div className="w-full flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00dbe9] animate-pulse"></span>
              <span className="font-label-sm text-label-sm uppercase text-[#00dbe9] tracking-widest font-bold">
                TRANSACTION GATEWAY // PROTOCOL v4.2
              </span>
              <span className="text-surface-variant">•</span>
              <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                SECURE ENCRYPTED UPI VPA
              </span>
            </div>
            <h1 className="font-headline-lg text-2xl sm:text-4xl uppercase text-on-surface tracking-tight font-bold">
              IGNITE <span className="text-primary-container">TREASURY</span> &amp; DEPOSITS
            </h1>
            <p className="font-body-sm text-body-sm text-on-surface-variant max-w-xl">
              Direct instant wallet synchronization for tournament entries and diamond top-ups. Zero gateway commission, automated 12-digit UTR validation ledger.
            </p>
          </div>

          {/* Quick Conversion Monospace Ticker */}
          <div className="bg-[#191c22] px-4 py-2 rounded shadow-sm flex items-center gap-4">
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                BASE RATIO
              </span>
              <span className="font-headline-sm text-headline-sm text-secondary font-bold">₹1.00 = 1🪙</span>
            </div>
            <div className="w-px h-8 bg-surface-variant"></div>
            <div className="flex flex-col">
              <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                DIAMOND SYNC
              </span>
              <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">₹1.00 = 1💎</span>
            </div>
            <div className="w-px h-8 bg-surface-variant"></div>
            <div className="flex flex-col items-end">
              <span className="font-label-sm text-label-sm uppercase text-primary font-semibold">
                INSTANT UTR
              </span>
              <span className="font-label-md text-label-md text-on-surface font-bold">&lt; 90 SEC</span>
            </div>
          </div>
        </div>

        {/* 12-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full items-start">
          {/* LEFT COLUMN: UPI Scan Matrix & Refer & Earn (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* PROMINENT UPI QR CARD */}
            <div className="bg-[#191c22] rounded-xl p-4 sm:p-6 shadow-xl relative overflow-hidden flex flex-col items-center">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-container via-secondary to-tertiary"></div>
              <div className="w-full flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ff5e00] text-xl">qr_code_scanner</span>
                  <span className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface font-bold">
                    OFFICIAL UPI SCANNER
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-surface-container font-label-sm text-label-sm text-[#00dbe9] uppercase flex items-center gap-1 font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00dbe9] animate-ping"></span> Live boi vpa
                </span>
              </div>

              {/* QR Display Container */}
              <div className="relative bg-[#0b0e14] p-3 rounded-lg shadow-2xl flex flex-col items-center max-w-xs w-full group">
                {/* Corner Tactical Reticles */}
                <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-primary-container pointer-events-none"></div>
                <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-primary-container pointer-events-none"></div>
                <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-primary-container pointer-events-none"></div>
                <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-primary-container pointer-events-none"></div>

                <div className="w-full bg-[#32353c] rounded overflow-hidden flex items-center justify-center p-1">
                  <img
                    alt="UPI Bank of India QR Code"
                    className="w-full h-auto object-contain max-h-[380px] rounded"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuDuIkIHW19m9NhGZpybM9HDiqr6VT4lIhRX6QgxCn8Uo6GzIdXTHSIUrAZYCYB1B_GOEpZwugbymmIV9AUxQFONx5xjglHWP9T1ADDy5YFSYCyEYTcCfCdAm6pKAs7VtR_qBtCemcLPBQmzcttpmcvKQE7AspIs5XoLi912-PSTMQW4ew7cN1BTv6-CwyyxHy6XbpF67eH0b79864pwRTanxHbh3ynxgrshdRQzx-1XzPU1HZyBdZ44IQBn4lk5-INPQpw"
                  />
                </div>
                <div className="w-full mt-2 pt-1 flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm uppercase">
                  <span>SCAN ANY VALID APP</span>
                  <span className="text-secondary font-bold">BOI RECOGNIZED</span>
                </div>
              </div>

              {/* Scan Caption */}
              <p className="font-body-sm text-body-sm text-center text-on-surface-variant mt-4">
                Scan with any UPI App: <strong className="text-on-surface font-semibold">Paytm</strong>,{' '}
                <strong className="text-on-surface font-semibold">PhonePe</strong>,{' '}
                <strong className="text-on-surface font-semibold">Google Pay</strong>,{' '}
                <strong className="text-on-surface font-semibold">BHIM</strong>, or Bank Apps.
              </p>

              {/* 1-Click Copy UPI ID Field */}
              <div className="w-full mt-4 bg-surface-container p-2 rounded-lg flex items-center justify-between gap-2">
                <div className="flex flex-col truncate pl-1">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                    IGNITE Official UPI ID
                  </span>
                  <span className="font-headline-sm text-headline-sm text-primary tracking-wide truncate font-bold">
                    paytm-tournament@boi
                  </span>
                </div>
                <button
                  onClick={copyUpiId}
                  className="px-4 py-2 rounded bg-surface-container-high hover:bg-primary-container text-on-surface hover:text-on-primary-container font-label-md text-label-md uppercase transition-all flex items-center gap-1.5 shrink-0 shadow-sm font-bold cursor-pointer"
                  title="Copy UPI Address"
                >
                  <span className="material-symbols-outlined text-base">
                    {copiedUpi ? 'check' : 'content_copy'}
                  </span>
                  <span>{copiedUpi ? 'COPIED!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Conversion Rates Box */}
            <div className="bg-[#191c22] rounded-xl p-4 shadow-md flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary text-lg">currency_exchange</span>
                <span className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface font-bold">
                  CONVERSION TIER RULES
                </span>
              </div>
              <div className="grid grid-cols-1 gap-1.5 font-body-sm text-body-sm">
                <div className="flex items-center justify-between p-2 rounded bg-surface-container">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded bg-secondary"></span>
                    <span className="text-on-surface font-semibold">₹1 INR</span>
                  </div>
                  <span className="text-secondary font-bold font-label-md text-label-md">1 Game Coin 🪙</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded bg-surface-container">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded bg-[#00dbe9]"></span>
                    <span className="text-on-surface font-semibold">₹50 INR</span>
                  </div>
                  <span className="text-on-surface font-label-sm text-label-sm">
                    50 Coins <span className="text-on-surface-variant">(Squad Match)</span>{' '}
                    <strong className="text-[#00dbe9]">OR 50 FF Diamonds 💎</strong>
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 rounded bg-surface-container">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded bg-primary-container"></span>
                    <span className="text-on-surface font-semibold">₹100 INR</span>
                  </div>
                  <span className="text-primary-container font-bold font-label-md text-label-md">
                    100 Coins + 10 BONUS COINS <span className="text-xs">🔥</span>
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 px-1 text-on-surface-variant font-label-sm text-label-sm">
                <span className="material-symbols-outlined text-sm text-[#00dbe9]">shield</span>
                <span>Diamonds sent directly to player in-game Free Fire UID via official partner pipeline.</span>
              </div>
            </div>

            {/* REFER & EARN SQUAD BOOST CARD */}
            <div className="bg-[#191c22] rounded-xl p-4 sm:p-6 shadow-xl relative overflow-hidden flex flex-col gap-4 border border-primary-container/20">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary via-primary-container to-tertiary"></div>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded bg-primary-container/20 flex items-center justify-center text-primary shrink-0">
                    <span className="material-symbols-outlined text-2xl">group_add</span>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
                      <span className="font-label-sm text-label-sm uppercase text-secondary tracking-widest font-bold">
                        SQUAD REWARD BOOST
                      </span>
                    </div>
                    <h3 className="font-headline-sm text-headline-sm uppercase text-on-surface tracking-tight leading-tight font-bold">
                      REFER &amp; EARN <span className="text-primary-container">₹10</span> INSTANT CASH
                    </h3>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-primary-container/20 text-primary font-label-sm text-label-sm font-bold uppercase shrink-0">
                  +10 🪙 BONUS
                </span>
              </div>

              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Share your invite code with fellow Free Fire players. Get ₹10 in withdrawable cash + 10 Game Coins when they join their first ₹50 tournament!
              </p>

              <div className="bg-[#0b0e14] p-3 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-2 border border-surface-variant/50">
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                    Your Squad Invite Code
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="font-headline-sm text-headline-sm text-secondary font-bold tracking-wider">
                      IGNITE-V7-8492
                    </span>
                    <span className="font-label-sm text-xs text-[#00dbe9] uppercase font-bold">ACTIVE</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={copyReferralCode}
                  className="w-full sm:w-auto px-4 py-2 rounded bg-primary-container hover:bg-secondary-container text-on-primary-container font-label-md text-label-md uppercase transition-all flex items-center justify-center gap-1.5 shadow-md shrink-0 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base">
                    {copiedReferral ? 'check' : 'content_copy'}
                  </span>
                  <span>{copiedReferral ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href="https://api.whatsapp.com/send?text=Join%20my%20squad%20on%20IGNITE%20FF!%20Use%20code%20IGNITE-V7-8492%20for%20Free%20Tournament%20Entry%20coins:%20https://igniteff.gg/invite/IGNITE-V7-8492"
                  target="_blank"
                  rel="noreferrer"
                  className="py-2 px-2 rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md uppercase flex items-center justify-center gap-1.5 transition-colors border border-surface-variant/40 font-bold"
                >
                  <span className="material-symbols-outlined text-base text-[#00dbe9]">share</span>
                  <span>WhatsApp Share</span>
                </a>
                <button
                  type="button"
                  onClick={copyInviteLink}
                  className="py-2 px-2 rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md uppercase flex items-center justify-center gap-1.5 transition-colors border border-surface-variant/40 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base text-secondary">link</span>
                  <span>{copiedLink ? 'Link Copied' : 'Copy Link'}</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="bg-surface-container p-2 rounded flex flex-col items-center text-center">
                  <span className="font-label-sm text-xs text-on-surface-variant uppercase font-semibold">
                    Referred
                  </span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">14</span>
                  <span className="font-label-sm text-xs text-[#00dbe9]">Athletes</span>
                </div>
                <div className="bg-surface-container p-2 rounded flex flex-col items-center text-center">
                  <span className="font-label-sm text-xs text-on-surface-variant uppercase font-semibold">
                    Earned Cash
                  </span>
                  <span className="font-headline-sm text-headline-sm text-secondary font-bold">₹140</span>
                  <span className="font-label-sm text-xs text-secondary-fixed-dim">Withdrawable</span>
                </div>
                <div className="bg-surface-container p-2 rounded flex flex-col items-center text-center">
                  <span className="font-label-sm text-xs text-on-surface-variant uppercase font-semibold">
                    Pending
                  </span>
                  <span className="font-headline-sm text-headline-sm text-primary font-bold">2</span>
                  <span className="font-label-sm text-xs text-on-surface-variant">In-Match</span>
                </div>
              </div>
            </div>
          </div>

          {/* MIDDLE COLUMN: Direct Coin Deposit Verification Form (4 Cols) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-[#191c22] rounded-xl p-4 sm:p-6 shadow-xl flex flex-col gap-4 relative">
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm uppercase text-primary-container font-bold">
                    Step 2: Submit Details
                  </span>
                  <h2 className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                    Verify &amp; Add Coins
                  </h2>
                </div>
                <span className="material-symbols-outlined text-on-surface-variant">bolt</span>
              </div>

              <form onSubmit={handleDepositSubmit} className="flex flex-col gap-4">
                {/* 1. Select Amount */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-sm text-label-sm uppercase text-on-surface-variant flex justify-between font-semibold">
                    <span>1. Select Amount / Match Tier</span>
                    <span className="text-secondary font-bold">₹{selectedAmt} SELECTED</span>
                  </label>

                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { amt: 30, sub: 'Solo Match' },
                      { amt: 50, sub: 'Squad Match' },
                      { amt: 100, sub: '+10 Bonus' },
                      { amt: 200, sub: '2x Squad' },
                      { amt: 500, sub: '+60 Bonus' },
                    ].map((tier) => (
                      <button
                        key={tier.amt}
                        type="button"
                        onClick={() => setSelectedAmt(tier.amt)}
                        className={`py-2.5 px-1 rounded font-label-md text-label-md flex flex-col items-center transition-all cursor-pointer ${
                          selectedAmt === tier.amt
                            ? 'bg-[#ff5e00] text-[#531900] font-bold shadow-md'
                            : 'bg-surface-container hover:bg-surface-container-high text-on-surface'
                        }`}
                      >
                        <span className="font-bold">₹{tier.amt}</span>
                        {tier.sub && (
                          <span
                            className={`font-label-sm text-xs ${
                              selectedAmt === tier.amt ? 'text-[#531900]' : 'text-secondary'
                            }`}
                          >
                            {tier.sub}
                          </span>
                        )}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={handleCustomAmt}
                      className="py-2.5 px-1 rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md flex flex-col items-center justify-center transition-all cursor-pointer"
                    >
                      <span className="text-on-surface-variant font-label-sm text-xs uppercase font-semibold">
                        CUSTOM
                      </span>
                      <span className="text-primary font-bold">₹ Other</span>
                    </button>
                  </div>
                </div>

                {/* 2. Convert Target */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                    2. Convert Payment Into
                  </label>
                  <div className="grid grid-cols-2 p-1 bg-[#0b0e14] rounded-lg">
                    <button
                      type="button"
                      onClick={() => setConvertTarget('coins')}
                      className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded font-label-md text-label-md transition-all font-bold cursor-pointer ${
                        convertTarget === 'coins'
                          ? 'bg-[#ff5e00] text-[#531900] shadow-sm'
                          : 'text-on-surface-variant hover:text-on-surface'
                      }`}
                    >
                      <span className="text-base">🪙</span>
                      <span>Game Coins</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setConvertTarget('diamonds')}
                      className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded font-label-md text-label-md transition-all font-bold cursor-pointer ${
                        convertTarget === 'diamonds'
                          ? 'bg-[#00dbe9] text-[#00363a] shadow-sm'
                          : 'text-on-surface-variant hover:text-on-surface'
                      }`}
                    >
                      <span className="text-base">💎</span>
                      <span>FF Diamonds</span>
                    </button>
                  </div>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] px-1 font-semibold">
                    {convertTarget === 'coins'
                      ? `Receives: ${
                          selectedAmt + (selectedAmt >= 500 ? 60 : selectedAmt >= 100 ? 10 : 0)
                        } Game Coins (₹${selectedAmt} Base + Bonus)`
                      : `Receives: ${selectedAmt} Free Fire In-Game Diamonds (Synced to UID: ${uid})`}
                  </span>
                </div>

                {/* 3. UTR Input */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-sm text-label-sm uppercase text-on-surface-variant flex justify-between font-semibold">
                    <span>3. UTR / Ref Number</span>
                    <span className="text-[#00dbe9]">Exact 12 Digits</span>
                  </label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-lg">
                      tag
                    </span>
                    <input
                      type="text"
                      maxLength={12}
                      value={utrNumber}
                      onChange={(e) => setUtrNumber(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 419204918231"
                      required
                      className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md pl-10 pr-4 py-2.5 rounded outline-none placeholder:text-surface-variant focus:bg-surface-container transition-all"
                    />
                  </div>
                  <span className="font-body-sm text-xs text-on-surface-variant">
                    Check your UPI payment receipt (GooglePay / PhonePe / Paytm) for the 12-digit UTR.
                  </span>
                </div>

                {/* 4. Payment Screenshot */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-sm text-label-sm uppercase text-on-surface-variant flex justify-between font-semibold">
                    <span>4. Payment Screenshot</span>
                    <span className="text-on-surface-variant text-xs">JPG / PNG / WebP</span>
                  </label>
                  <label className="bg-[#0b0e14] rounded-lg p-4 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-surface-container transition-all group border border-dashed border-surface-variant">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setDepositFileName(e.target.files[0].name);
                          showToast(`Selected receipt: ${e.target.files[0].name}`);
                        }
                      }}
                    />
                    <span className="material-symbols-outlined text-3xl text-on-surface-variant group-hover:text-primary transition-colors">
                      {depositFileName ? 'check_circle' : 'cloud_upload'}
                    </span>
                    <span className="font-label-md text-label-md text-on-surface mt-1 group-hover:text-primary transition-colors font-bold">
                      {depositFileName ? `Selected: ${depositFileName}` : 'Tap to upload transfer receipt'}
                    </span>
                    <span className="font-label-sm text-label-sm text-on-surface-variant mt-0.5">
                      Drag &amp; drop or browse device gallery
                    </span>
                  </label>
                </div>

                {/* 5. Submit CTA */}
                <button
                  type="submit"
                  className="w-full mt-1 py-3 px-6 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline-sm text-headline-sm uppercase rounded transition-all flex items-center justify-center gap-2 shadow-xl active:scale-[0.99] font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-xl">verified</span>
                  <span>Verify &amp; Add Coins Instantly</span>
                </button>

                <div className="flex items-center justify-center gap-1.5 text-center text-on-surface-variant font-label-sm text-label-sm uppercase font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00dbe9]"></span>
                  <span>Automated Bot Arbiter Active // Response Time: 30-90s</span>
                </div>
              </form>

              {/* Toast Dialog on Success */}
              {depositSuccessToast && (
                <div className="absolute inset-0 bg-[#0b0e14]/95 backdrop-blur rounded-xl p-6 flex flex-col items-center justify-center text-center gap-4 z-20">
                  <div className="w-16 h-16 rounded-full bg-[#ff5e00] flex items-center justify-center text-[#531900] animate-bounce">
                    <span className="material-symbols-outlined text-3xl">check_circle</span>
                  </div>
                  <div className="flex flex-col">
                    <h3 className="font-headline-md text-headline-md uppercase text-on-surface font-bold">
                      Payment Queued!
                    </h3>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                      {depositToastMessage}
                    </p>
                  </div>
                  <button
                    onClick={() => setDepositSuccessToast(false)}
                    className="px-6 py-2 bg-surface-container font-label-md text-label-md text-on-surface uppercase rounded hover:bg-surface-container-high transition-colors font-bold cursor-pointer"
                  >
                    Dismiss &amp; Track
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN: Live Balance HUD & Withdraw & Ledger (3 Cols) */}
          <div className="lg:col-span-3 flex flex-col gap-6">
            {/* LIVE BALANCE CARD */}
            <div className="bg-[#191c22] rounded-xl p-4 sm:p-6 shadow-xl flex flex-col gap-4 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-bold">
                  ACTIVE VAULT
                </span>
                <span className="px-2 py-0.5 rounded bg-surface-container font-label-sm text-label-sm text-[#00dbe9] font-bold">
                  SYNCED
                </span>
              </div>

              {/* Game Coins */}
              <div className="flex flex-col bg-surface-container p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                    Available Game Coins
                  </span>
                  <span className="text-xl">🪙</span>
                </div>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="font-headline-lg text-3xl text-secondary font-bold">
                    {coins}
                  </span>
                  <span className="font-label-md text-label-md text-on-surface-variant">COINS</span>
                </div>
                <span className="font-label-sm text-label-sm text-secondary-fixed-dim mt-0.5">
                  (Cash Value: ₹{coins}.00 INR)
                </span>
              </div>

              {/* Diamonds */}
              <div className="flex flex-col bg-surface-container p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                    In-Game Free Fire
                  </span>
                  <span className="text-xl">💎</span>
                </div>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="font-headline-lg text-3xl text-[#00dbe9] font-bold">
                    {diamonds}
                  </span>
                  <span className="font-label-md text-label-md text-tertiary-fixed">DIAMONDS</span>
                </div>
                <span className="font-label-sm text-label-sm text-on-surface-variant mt-0.5">
                  Direct Sync to UID: {uid}
                </span>
              </div>

              {/* WITHDRAW MONEY SECTION */}
              <div className="flex flex-col gap-2 pt-2 border-t-2 border-surface-variant" id="dedicated-withdraw-section">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-secondary text-base">payments</span>
                    <span className="font-label-md text-label-md uppercase tracking-wider text-on-surface font-bold">
                      Withdraw Money
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-surface-container font-label-sm text-label-sm text-[#00dbe9] flex items-center gap-1 font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00dbe9] animate-ping"></span> INSTANT GATEWAY
                  </span>
                </div>

                {/* Method selector */}
                <div className="grid grid-cols-2 p-1 bg-[#0b0e14] rounded-lg">
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('upi')}
                    className={`py-1.5 px-2 rounded font-label-sm text-label-sm uppercase font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                      payoutMethod === 'upi'
                        ? 'bg-[#ff5e00] text-[#531900]'
                        : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    <span className="material-symbols-outlined text-sm">qr_code</span> UPI Instant
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('bank')}
                    className={`py-1.5 px-2 rounded font-label-sm text-label-sm uppercase font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                      payoutMethod === 'bank'
                        ? 'bg-[#ff5e00] text-[#531900]'
                        : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    <span className="material-symbols-outlined text-sm">account_balance</span> Bank (IMPS)
                  </button>
                </div>

                {/* Form fields */}
                {payoutMethod === 'upi' ? (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex flex-col gap-0.5">
                      <label className="font-label-sm text-label-sm uppercase text-on-surface-variant flex justify-between font-semibold">
                        <span>UPI ID / VPA</span>
                        <span className="text-[#00dbe9] text-xs font-bold">Auto-Validated</span>
                      </label>
                      <div className="relative">
                        <span className="material-symbols-outlined absolute left-2 top-1/2 -translate-y-1/2 text-on-surface-variant text-base">
                          alternate_email
                        </span>
                        <input
                          type="text"
                          value={withdrawUpi}
                          onChange={(e) => setWithdrawUpi(e.target.value)}
                          placeholder="username@okhdfcbank"
                          className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md pl-8 pr-16 py-1.5 rounded outline-none placeholder:text-surface-variant focus:bg-surface-container"
                        />
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded bg-[#00a3ad]/30 text-[#00dbe9] font-label-sm text-xs font-bold">
                          ACTIVE
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                        Confirm UPI ID
                      </label>
                      <input
                        type="text"
                        value={withdrawUpiConfirm}
                        onChange={(e) => setWithdrawUpiConfirm(e.target.value)}
                        placeholder="Re-enter UPI ID to verify"
                        className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md px-3 py-1.5 rounded outline-none placeholder:text-surface-variant focus:bg-surface-container"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex flex-col gap-0.5">
                      <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                        Account Holder Name
                      </label>
                      <input
                        type="text"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="Name as per bank records"
                        className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md px-3 py-1.5 rounded outline-none placeholder:text-surface-variant focus:bg-surface-container"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col gap-0.5">
                        <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                          Account Number
                        </label>
                        <input
                          type="password"
                          value={bankAcc}
                          onChange={(e) => setBankAcc(e.target.value)}
                          placeholder="918239048123"
                          className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md px-3 py-1.5 rounded outline-none placeholder:text-surface-variant focus:bg-surface-container"
                        />
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <label className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                          IFSC Code
                        </label>
                        <input
                          type="text"
                          value={bankIfsc}
                          onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                          placeholder="BKID0000102"
                          className="w-full bg-[#0b0e14] text-on-surface font-label-md text-label-md px-3 py-1.5 rounded outline-none uppercase placeholder:text-surface-variant focus:bg-surface-container"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Amount Selector */}
                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm uppercase text-on-surface-variant flex justify-between font-semibold">
                    <span>Withdrawal Amount (₹)</span>
                    <span className="text-secondary font-bold">Balance: ₹8,940</span>
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {[100, 200, 500].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setWithdrawAmount(amt)}
                        className={`py-1 px-1 rounded font-label-sm text-label-sm text-center transition-colors cursor-pointer font-bold ${
                          withdrawAmount === amt
                            ? 'bg-[#ff5e00] text-[#531900] shadow-sm'
                            : 'bg-surface-container hover:bg-surface-container-high text-on-surface'
                        }`}
                      >
                        ₹{amt}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setWithdrawAmount(8940)}
                      className={`py-1 px-1 rounded font-label-sm text-label-sm text-center transition-colors cursor-pointer font-bold ${
                        withdrawAmount === 8940
                          ? 'bg-[#ff5e00] text-[#531900] shadow-sm'
                          : 'bg-surface-container hover:bg-surface-container-high text-[#00dbe9]'
                      }`}
                    >
                      MAX
                    </button>
                  </div>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                    className="w-full bg-[#0b0e14] text-secondary font-headline-sm text-headline-sm px-3 py-1 rounded outline-none text-right font-bold"
                  />
                </div>

                {/* Payout Summary */}
                <div className="bg-[#0b0e14] p-2 rounded font-label-sm text-xs flex flex-col gap-1">
                  <div className="flex justify-between text-on-surface-variant">
                    <span>Withdrawable Balance</span>
                    <span className="text-on-surface font-bold">₹8,940</span>
                  </div>
                  <div className="flex justify-between text-on-surface-variant">
                    <span>TDS Deduction (&lt;₹10k)</span>
                    <span className="text-[#00dbe9]">0% (₹0.00)</span>
                  </div>
                  <div className="flex justify-between text-on-surface-variant">
                    <span>Platform Processing Fee</span>
                    <span className="text-[#00dbe9]">₹0.00 (Free)</span>
                  </div>
                  <div className="w-full h-px bg-surface-variant"></div>
                  <div className="flex justify-between text-on-surface font-bold text-sm">
                    <span>Net Transferable</span>
                    <span className="text-primary font-bold">₹{Number(withdrawAmount).toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-on-surface-variant font-label-sm text-xs">
                  <span className="material-symbols-outlined text-xs text-[#00dbe9]">lock_clock</span>
                  <span>Payouts processed in 5-15 mins with instant UTR tracking.</span>
                </div>

                <button
                  type="button"
                  onClick={handleWithdrawAction}
                  className="w-full py-2.5 px-4 rounded bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline-sm text-headline-sm uppercase transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-[0.99] font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base">lock</span>
                  <span>REQUEST WITHDRAWAL</span>
                </button>

                {/* Recent Withdrawals Live Feed */}
                <div className="flex flex-col gap-1 pt-1">
                  <div className="flex justify-between items-center">
                    <span className="font-label-sm text-xs uppercase text-on-surface-variant font-semibold">
                      Recent Withdrawals
                    </span>
                    <span className="text-xs text-[#00dbe9] font-label-sm font-bold">LIVE FEED</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between p-1 bg-surface-container rounded text-xs">
                      <div className="flex items-center gap-1 truncate">
                        <span className="material-symbols-outlined text-sm text-[#00dbe9]">check_circle</span>
                        <span className="text-on-surface truncate">₹500 → user@apl</span>
                      </div>
                      <span className="text-[#00dbe9] font-bold shrink-0">COMPLETED</span>
                    </div>
                    <div className="flex items-center justify-between p-1 bg-surface-container rounded text-xs">
                      <div className="flex items-center gap-1 truncate">
                        <span className="material-symbols-outlined text-sm text-[#00dbe9]">check_circle</span>
                        <span className="text-on-surface truncate">₹1,200 → A/C ...4091</span>
                      </div>
                      <span className="text-[#00dbe9] font-bold shrink-0">COMPLETED</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tournament Earning Ratio Visualizer */}
              <div className="p-2 bg-[#0b0e14] rounded-lg flex flex-col gap-1">
                <div className="flex justify-between font-label-sm text-label-sm text-on-surface-variant">
                  <span>TOURNAMENT EARNING RATIO</span>
                  <span className="text-[#00dbe9] font-bold">78.4% PROFIT</span>
                </div>
                <div className="w-full h-2 rounded bg-surface-container overflow-hidden flex">
                  <div className="bg-secondary h-full" style={{ width: '65%' }}></div>
                  <div className="bg-[#00dbe9] h-full" style={{ width: '35%' }}></div>
                </div>
                <div className="flex justify-between font-label-sm text-label-sm text-on-surface-variant pt-0.5">
                  <span>Match Wins: ₹840</span>
                  <span>Fees: ₹260</span>
                </div>
              </div>
            </div>

            {/* LEDGER ACTIVITY CARD */}
            <div className="bg-[#191c22] rounded-xl p-4 shadow-md flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-base">receipt_long</span>
                  <span className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface font-bold">
                    LEDGER ACTIVITY
                  </span>
                </div>
                <span className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">
                  LAST 7 DAYS
                </span>
              </div>

              <div className="flex flex-col gap-1.5">
                {ledger.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 bg-surface-container rounded hover:bg-surface-container-high transition-colors"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div
                        className={`w-8 h-8 rounded bg-[#0b0e14] flex items-center justify-center shrink-0 ${
                          item.isPositive ? 'text-[#00dbe9]' : 'text-error'
                        }`}
                      >
                        <span className="material-symbols-outlined text-base">
                          {item.type === 'deposit'
                            ? 'arrow_downward'
                            : item.type === 'bounty'
                            ? 'military_tech'
                            : item.type === 'entry'
                            ? 'sports_esports'
                            : 'payments'}
                        </span>
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="font-label-md text-label-md text-on-surface truncate font-bold">
                          {item.title}
                        </span>
                        <span className="font-label-sm text-label-sm text-on-surface-variant truncate">
                          {item.subtitle}
                        </span>
                      </div>
                    </div>
                    <span
                      className={`font-label-md text-label-md font-bold shrink-0 ${
                        item.isPositive ? 'text-[#00dbe9]' : 'text-error'
                      }`}
                    >
                      {item.isPositive ? `+${item.amount} 🪙` : `-${item.amount} 🪙`}
                    </span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => showToast('Vault audit ledger synchronised with corporate bank records.', 'info')}
                className="w-full text-center py-1 font-label-sm text-label-sm uppercase text-primary hover:text-on-surface transition-colors mt-1 font-bold cursor-pointer"
              >
                View Complete Vault Audit History →
              </button>
            </div>
          </div>
        </div>

        {/* TACTICAL COMPLIANCE & SAFETY STRIP */}
        <div className="w-full bg-[#191c22] rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-md">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded bg-surface-container flex items-center justify-center text-[#00dbe9] shrink-0">
              <span className="material-symbols-outlined text-2xl">verified_user</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-md text-label-md text-on-surface uppercase font-bold">
                Instant Bank Reconciliation
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Payments are matched directly against our BOI Corporate UPI API. Fake UTR submissions trigger an automatic 48-hour tournament ban.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex items-center gap-1.5 text-on-surface-variant font-label-sm text-label-sm font-semibold">
              <span className="material-symbols-outlined text-primary text-base">support_agent</span>
              <span>Payment stuck? WhatsApp Arbiter: +91 98200 XXXXX</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
