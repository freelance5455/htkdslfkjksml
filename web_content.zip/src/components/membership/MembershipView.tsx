import React, { useState } from 'react';
import { 
  Sparkles, 
  Check, 
  ShieldCheck, 
  Clock, 
  Zap, 
  Award,
  AlertCircle,
  Receipt,
  Lock,
  ArrowRight,
  CreditCard
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { MembershipTier } from '../../types';
import { UpiPaymentModal } from '../vip/UpiPaymentModal';
import { VipPaymentHistoryModal } from '../vip/VipPaymentHistoryModal';

export const MembershipView: React.FC = () => {
  const { 
    currentUser, 
    membershipPlans, 
    upgradeMembership, 
    vipPayments,
    language, 
    t 
  } = useApp();

  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [selectedPlanForUpi, setSelectedPlanForUpi] = useState<{
    id: MembershipTier;
    name: string;
    amountRupees: number;
    dailyEarningsRupees?: number;
    taskRewardRupees?: number;
  } | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const activeTier = currentUser?.membershipTier || 'basic';
  const currentPlan = membershipPlans.find(p => p.id === activeTier) || membershipPlans[0];

  const handlePlanAction = (plan: typeof membershipPlans[0]) => {
    setMessage(null);
    if (plan.id === 'basic') {
      const res = upgradeMembership('basic');
      if (res.success) setMessage({ text: res.message, isError: false });
      return;
    }

    // Open Professional UPI payment modal for all VIP plans
    setSelectedPlanForUpi({
      id: plan.id,
      name: plan.name,
      amountRupees: plan.price,
      dailyEarningsRupees: plan.dailyEarningRupees,
    });
  };

  const getTierIcon = (tierId: MembershipTier) => {
    switch (tierId) {
      case 'basic':
        return <Award className="w-6 h-6 text-slate-400" />;
      case 'vip1':
        return <Zap className="w-6 h-6 text-blue-500" />;
      case 'vip2':
        return <Sparkles className="w-6 h-6 text-amber-500" />;
      case 'vip3':
        return <Sparkles className="w-6 h-6 text-purple-400 animate-pulse" />;
      case 'vip4':
        return <Sparkles className="w-6 h-6 text-emerald-400 animate-bounce" />;
      default:
        return <ShieldCheck className="w-6 h-6 text-slate-400" />;
    }
  };

  const getUserPendingPayment = (tierId: MembershipTier) => {
    if (!currentUser) return null;
    return vipPayments.find(p => 
      p.status === 'pending' && 
      p.vipTier === tierId &&
      (p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase())
    );
  };

  const userPaymentsCount = currentUser 
    ? vipPayments.filter(p => p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase()).length
    : 0;

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-300">
      
      {/* Title & History button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 max-w-5xl mx-auto">
        <div className="space-y-1.5 text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>VIP Earnings Acceleration & UPI Purchase</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {t('membershipTitle')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed max-w-xl">
            Upgrade your account to unlock guaranteed high-yield tasks, instant cashouts, and priority rewards via direct UPI payment.
          </p>
        </div>

        <div>
          <button
            type="button"
            onClick={() => setIsHistoryOpen(true)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all"
          >
            <Receipt className="w-4 h-4 text-emerald-500" />
            <span>My Purchases</span>
            {userPaymentsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-emerald-500 text-white font-bold text-[10px] flex items-center justify-center">
                {userPaymentsCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Current Plan Status Card */}
      {currentUser && (
        <div className="max-w-5xl mx-auto p-4 sm:p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {t('currentPlan')}
              </span>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>{language === 'bn' ? currentPlan.nameBn : currentPlan.name}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  {currentPlan.rewardMultiplier}x Multiplier
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {currentUser.membershipExpiresAt ? (
                  <span>
                    {t('expiresOn')}: {new Date(currentUser.membershipExpiresAt).toLocaleDateString()}
                  </span>
                ) : (
                  <span>{t('lifetime')}</span>
                )}
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right shrink-0">
            <span className="text-xs text-slate-400 block">{t('dailyTaskCap')}</span>
            <span className="text-xl font-bold text-emerald-400">
              {currentPlan.dailyTaskLimit} tasks / day
            </span>
          </div>
        </div>
      )}

      {message && (
        <div className={`max-w-5xl mx-auto p-4 rounded-2xl border text-xs font-semibold flex items-center gap-3 ${
          message.isError
            ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300'
            : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300'
        }`}>
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{message.text}</span>
        </div>
      )}

      {/* Plans Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
        {membershipPlans.filter(p => p.id !== 'basic').map((plan) => {
          const isCurrent = plan.id === activeTier;
          const planName = language === 'bn' ? plan.nameBn : plan.name;
          const features = language === 'bn' ? plan.featuresBn : plan.features;
          const pendingPayment = getUserPendingPayment(plan.id);

          return (
            <div
              key={plan.id}
              className={`rounded-3xl p-5 border relative flex flex-col justify-between transition-all ${
                isCurrent
                  ? 'bg-emerald-50/20 dark:bg-emerald-950/20 border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                  : pendingPayment
                  ? 'bg-amber-50/20 dark:bg-amber-950/20 border-amber-400 shadow-md ring-2 ring-amber-400/20'
                  : plan.isPopular
                  ? 'bg-gradient-to-b from-amber-500/5 to-transparent dark:from-amber-950/20 border-amber-400 dark:border-amber-600 shadow-xl'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs'
              }`}
            >
              {plan.isPopular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold text-[10px] uppercase tracking-wider shadow-sm">
                  Most Popular
                </span>
              )}

              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800">
                    {getTierIcon(plan.id)}
                  </div>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${plan.badgeColor}`}>
                    {plan.rewardMultiplier}x Multiplier
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
                    {planName}
                  </h3>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                      ₹{plan.price}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      / 30 Days
                    </span>
                  </div>
                  {plan.dailyEarningRupees && (
                    <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5">
                      Earn up to ₹{plan.dailyEarningRupees}/day
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Clock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Daily Tasks: {plan.dailyTaskLimit} Tasks</span>
                  </div>

                  {features.map((feat, fIndex) => (
                    <div key={fIndex} className="flex items-start gap-1.5 text-[11px] text-slate-600 dark:text-slate-300">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-5">
                {isCurrent ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-center font-bold text-xs border border-emerald-300 dark:border-emerald-800">
                    ✓ Plan Currently Active
                  </div>
                ) : pendingPayment ? (
                  <button
                    type="button"
                    onClick={() => setIsHistoryOpen(true)}
                    className="w-full py-2.5 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-center font-bold text-xs border border-amber-300 dark:border-amber-800 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Pending Approval</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handlePlanAction(plan)}
                    className="w-full py-3 rounded-xl bg-slate-900 dark:bg-slate-100 hover:bg-emerald-600 text-white dark:text-slate-900 hover:text-white font-black text-xs shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Buy VIP Plan (₹{plan.price})</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Professional UPI Payment Modal */}
      <UpiPaymentModal
        isOpen={!!selectedPlanForUpi}
        onClose={() => setSelectedPlanForUpi(null)}
        vipPlan={selectedPlanForUpi}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Payment History Modal */}
      <VipPaymentHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onBuyPlan={() => {
          setIsHistoryOpen(false);
          const firstPlan = membershipPlans.find(p => p.id === 'vip1');
          if (firstPlan) handlePlanAction(firstPlan);
        }}
      />

    </div>
  );
};
