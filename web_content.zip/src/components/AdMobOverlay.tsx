import React from 'react';
import { ActiveAdState } from '../utils/admob';

interface AdMobOverlayProps {
  adState: ActiveAdState | null;
  onToast?: (msg: string, type: 'success' | 'error' | 'info' | 'magic') => void;
}

// Disconnected fake ad overlay: Real Google Mobile Ads (App Open, Interstitial,
// Rewarded, Rewarded Interstitial) are presented natively by Google Mobile Ads SDK.
export const AdMobOverlay: React.FC<AdMobOverlayProps> = () => {
  return null;
};
