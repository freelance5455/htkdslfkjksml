import React from 'react';
import { X, Plus, FileCode } from 'lucide-react';
import { ProjectFile } from '../types';

interface EditorTabsProps {
  files: ProjectFile[];
  activeFileId: string;
  onSelectTab: (fileId: string) => void;
  onCloseTab: (fileId: string) => void;
  onNewTab: () => void;
}

export const EditorTabs: React.FC<EditorTabsProps> = ({
  files,
  activeFileId,
  onSelectTab,
  onCloseTab,
  onNewTab,
}) => {
  const getExtColor = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'html': return 'text-amber-400';
      case 'css': return 'text-sky-400';
      case 'js': return 'text-yellow-400';
      case 'ts': return 'text-blue-400';
      case 'py': return 'text-emerald-400';
      case 'json': return 'text-purple-400';
      default: return 'text-cyan-400';
    }
  };

  return (
    <div className="h-10 bg-[#070a14] border-b border-slate-800 flex items-center overflow-x-auto select-none px-2 gap-1 shrink-0">
      <div className="flex items-center gap-1 overflow-x-auto flex-1 py-1">
        {files.map(file => {
          const isActive = file.id === activeFileId;
          const extColor = getExtColor(file.name);

          return (
            <div
              key={file.id}
              onClick={() => onSelectTab(file.id)}
              className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs font-mono cursor-pointer border-t-2 transition-all shrink-0 ${
                isActive
                  ? 'bg-[#0f172a] text-slate-100 border-cyan-400 font-semibold shadow-xs'
                  : 'bg-transparent text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40'
              }`}
            >
              <FileCode className={`w-3.5 h-3.5 ${extColor}`} />
              <span className="truncate max-w-[130px]">{file.name}</span>
              {files.length > 1 && (
                <button
                  onClick={e => {
                    e.stopPropagation();
                    onCloseTab(file.id);
                  }}
                  aria-label={`Close ${file.name}`}
                  className="opacity-0 group-hover:opacity-100 hover:text-rose-400 p-0.5 rounded transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}

        <button
          onClick={onNewTab}
          aria-label="Create new file tab"
          className="p-1.5 rounded-md text-slate-500 hover:text-cyan-300 hover:bg-slate-800 transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
