import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Pause, Play, RotateCcw, SkipBack, SkipForward, Volume2, VolumeX, AlertTriangle, Film } from "lucide-react";
import type { Project, QuestionScene } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { preloadImages, decodeAudioBlob, ensureFontsLoaded } from "@/lib/media";
import { buildTimeline, sceneAt, phaseAt, formatClock } from "@/lib/timeline";
import { renderFrame, toArabicDigits } from "@/lib/render";
import { cn } from "@/utils/cn";

export function usePreviewImages(project: Project) {
  const { mediaUrls } = useStudio();
  const [images, setImages] = useState<Map<string, HTMLImageElement>>(new Map());
  const idsKey = JSON.stringify([
    project.design.background.imageId,
    project.design.brand.logoId,
    ...project.questions.map((question) => question.imageId),
  ]);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      await ensureFontsLoaded([project.design.typography.font]);
      const loaded = await preloadImages(project, mediaUrls);
      if (!cancelled) setImages(loaded);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey, mediaUrls, project.design.typography.font]);
  return images;
}

const STAGE_ORDER = ["question", "options", "thinking", "reveal"] as const;
export type PreviewStage = (typeof STAGE_ORDER)[number];

function stageLocal(scene: QuestionScene, stage: PreviewStage): number {
  const { optionsStart, thinkingStart, revealStart, revealDuration } = scene.timings;
  switch (stage) {
    case "question":
      return Math.max(0.15, optionsStart * 0.35);
    case "options":
      return optionsStart + Math.max(0.2, (thinkingStart - optionsStart) * 0.55);
    case "thinking":
      return thinkingStart + Math.max(0.2, (revealStart - thinkingStart) * 0.5);
    case "reveal":
    default:
      return revealStart + Math.min(0.55, Math.max(0.2, revealDuration * 0.45));
  }
}

function canvasSize(project: Project): { width: number; height: number } {
  const max = 960;
  const scale = Math.min(1, max / Math.max(project.exportSettings.width, project.exportSettings.height));
  return {
    width: Math.max(320, Math.round(project.exportSettings.width * scale)),
    height: Math.max(320, Math.round(project.exportSettings.height * scale)),
  };
}

export function SceneCanvas({
  questionIndex = 0,
  stage = "thinking",
  className,
  handles,
  dragTarget,
  onDrag,
  onWarn,
}: {
  questionIndex?: number;
  stage?: PreviewStage;
  className?: string;
  handles?: boolean;
  dragTarget?: "content" | "timer" | null;
  onDrag?: (x: number, y: number) => void;
  onWarn?: (message: string) => void;
}) {
  const { project } = useStudio();
  const images = usePreviewImages(project);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const timeline = useMemo(() => buildTimeline(project), [project]);
  const scene = timeline.scenes[Math.min(questionIndex, Math.max(0, timeline.scenes.length - 1))];
  const projectRef = useRef(project);
  projectRef.current = project;

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !scene) return;
    const size = canvasSize(projectRef.current);
    if (canvas.width !== size.width || canvas.height !== size.height) {
      canvas.width = size.width;
      canvas.height = size.height;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const local = stageLocal(scene, stage);
    renderFrame(ctx, projectRef.current, scene, { images }, scene.timings.start + local, size.width, size.height);
  }, [scene, stage, images]);

  useEffect(() => {
    draw();
  }, [draw, project]);

  useEffect(() => {
    const observer = new ResizeObserver(() => draw());
    if (wrapRef.current) observer.observe(wrapRef.current);
    return () => observer.disconnect();
  }, [draw]);

  const draggingRef = useRef(false);
  const updateDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragTarget || !onDrag) return;
    const rect = wrapRef.current?.getBoundingClientRect();
    if (!rect) return;
    const rawX = ((event.clientX - rect.left) / rect.width) * 100;
    const rawY = ((event.clientY - rect.top) / rect.height) * 100;
    const x = Math.max(6, Math.min(94, rawX));
    const y = Math.max(8, Math.min(92, rawY));
    if (x !== rawX || y !== rawY) onWarn?.("تم تثبيت العنصر داخل المنطقة الآمنة؛ لا يُسمح بخروجه عن حدود الفيديو.");
    onDrag(Math.round(x * 10) / 10, Math.round(y * 10) / 10);
  };

  return (
    <div
      ref={wrapRef}
      className={cn("relative mx-auto w-full overflow-hidden rounded-2xl border border-white/10 bg-black shadow-[0_30px_80px_-40px_rgba(0,0,0,0.95)]", className)}
      style={{ aspectRatio: `${project.exportSettings.width} / ${project.exportSettings.height}`, touchAction: dragTarget ? "none" : "auto" }}
      onPointerDown={(event) => {
        if (!dragTarget) return;
        draggingRef.current = true;
        event.currentTarget.setPointerCapture(event.pointerId);
        updateDrag(event);
      }}
      onPointerMove={(event) => {
        if (!dragTarget || !draggingRef.current) return;
        updateDrag(event);
      }}
      onPointerUp={() => {
        draggingRef.current = false;
      }}
      onPointerCancel={() => {
        draggingRef.current = false;
      }}
    >
      <canvas ref={canvasRef} className="h-full w-full object-contain" aria-label="معاينة مشهد الفيديو" />
      {handles ? (
        <>
          <div
            className={cn(
              "pointer-events-none absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1 rounded-full border px-2 py-1 text-[9px] font-semibold shadow-lg",
              dragTarget === "content" ? "border-[#d9b65a] bg-[#d9b65a] text-[#181205]" : "border-[#d9b65a]/40 bg-black/70 text-[#f0dfb4]",
            )}
            style={{ left: `${project.design.content.x}%`, top: `${project.design.content.y}%` }}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-current" /> المحتوى
          </div>
          {project.design.timer.visible ? (
            <div
              className={cn(
                "pointer-events-none absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1 rounded-full border px-2 py-1 text-[9px] font-semibold shadow-lg",
                dragTarget === "timer" ? "border-[#57dc96] bg-[#57dc96] text-[#04150c]" : "border-[#57dc96]/35 bg-black/70 text-[#9ef0c1]",
              )}
              style={{ left: `${project.design.timer.x}%`, top: `${project.design.timer.y}%` }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-current" /> المؤقت
            </div>
          ) : null}
        </>
      ) : null}
      {dragTarget ? (
        <div className="pointer-events-none absolute inset-x-0 top-2 flex justify-center">
          <span className="rounded-full border border-white/10 bg-black/70 px-2.5 py-1 text-[9px] text-[#d8d8de] backdrop-blur">
            اسحب بإصبعك لتحريك {dragTarget === "content" ? "المحتوى" : "المؤقت"} داخل الإطار
          </span>
        </div>
      ) : null}
    </div>
  );
}

function stopNodes(nodes: AudioNode[], sources: AudioScheduledSourceNode[]) {
  for (const source of sources) {
    try {
      source.stop();
    } catch {
      /* ignore */
    }
  }
  for (const node of nodes) {
    try {
      node.disconnect();
    } catch {
      /* ignore */
    }
  }
}

export function PlayerPreview({ className }: { className?: string }) {
  const { project, mediaUrls, toast } = useStudio();
  const images = usePreviewImages(project);
  const timeline = useMemo(() => buildTimeline(project), [project]);
  const [position, setPosition] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(85);
  const [muted, setMuted] = useState(false);
  const [decoding, setDecoding] = useState(false);
  const [audioWarning, setAudioWarning] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const positionRef = useRef(0);
  const projectRef = useRef(project);
  const timelineRef = useRef(timeline);
  const imagesRef = useRef(images);
  projectRef.current = project;
  timelineRef.current = timeline;
  imagesRef.current = images;

  const ctxRef = useRef<AudioContext | null>(null);
  const masterRef = useRef<GainNode | null>(null);
  const sourcesRef = useRef<AudioScheduledSourceNode[]>([]);
  const nodesRef = useRef<AudioNode[]>([]);
  const clockStartRef = useRef(0);
  const rafRef = useRef(0);
  const buffersRef = useRef<Record<string, AudioBuffer>>({});
  const lastUiUpdate = useRef(0);
  const previousSignature = useRef("");

  const audioIds = useMemo(() => {
    const ids = new Set<string>();
    for (const scene of timeline.scenes) for (const clip of scene.audio) ids.add(clip.mediaId);
    if (project.timing.backgroundMusicId) ids.add(project.timing.backgroundMusicId);
    return [...ids];
  }, [timeline, project.timing.backgroundMusicId]);
  const audioKey = audioIds.join("|");

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      const missing = audioIds.filter((id) => !buffersRef.current[id] && mediaUrls[id]);
      if (missing.length === 0) return;
      setDecoding(true);
      const failed: string[] = [];
      for (const id of missing) {
        try {
          const response = await fetch(mediaUrls[id]);
          const blob = await response.blob();
          buffersRef.current[id] = await decodeAudioBlob(blob);
        } catch {
          failed.push(project.media[id]?.name ?? id);
        }
      }
      if (!cancelled) {
        setDecoding(false);
        if (failed.length) setAudioWarning(`تعذّر تجهيز معاينة: ${failed.slice(0, 2).join("، ")}. سيستمر العرض بصريًا دون هذا الصوت.`);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioKey, mediaUrls]);

  const drawAt = useCallback((time: number) => {
    const canvas = canvasRef.current;
    const projectNow = projectRef.current;
    const timelineNow = timelineRef.current;
    const at = sceneAt(timelineNow, time);
    if (!canvas || !at) return;
    const size = canvasSize(projectNow);
    if (canvas.width !== size.width || canvas.height !== size.height) {
      canvas.width = size.width;
      canvas.height = size.height;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    renderFrame(ctx, projectNow, at.scene, { images: imagesRef.current }, time, size.width, size.height);
  }, []);

  useEffect(() => {
    drawAt(positionRef.current);
  }, [drawAt, images, project]);

  const stopPlaybackNodes = useCallback(() => {
    stopNodes(nodesRef.current, sourcesRef.current);
    sourcesRef.current = [];
    nodesRef.current = [];
    if (masterRef.current) {
      try {
        masterRef.current.disconnect();
      } catch {
        /* ignore */
      }
      masterRef.current = null;
    }
  }, []);

  const ensureCtx = useCallback(() => {
    if (!ctxRef.current) {
      const Context = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Context) throw new Error("متصفحك لا يدعم معاينة الصوت (Web Audio).");
      ctxRef.current = new Context();
    }
    return ctxRef.current;
  }, []);

  const startFrom = useCallback(
    async (from: number, resume = false) => {
      const timelineNow = timelineRef.current;
      const projectNow = projectRef.current;
      const safeFrom = Math.max(0, Math.min(timelineNow.totalDuration - 0.01, from));
      let ctx: AudioContext;
      try {
        ctx = ensureCtx();
        if (resume) await ctx.resume();
      } catch (error) {
        toast(error instanceof Error ? error.message : "تعذّر تشغيل الصوت.", "error");
        return;
      }
      stopPlaybackNodes();
      const master = ctx.createGain();
      master.gain.value = muted ? 0 : volume / 100;
      master.connect(ctx.destination);
      masterRef.current = master;
      const base = ctx.currentTime + 0.08;
      clockStartRef.current = base - safeFrom;
      positionRef.current = safeFrom;
      setPosition(safeFrom);
      for (const scene of timelineNow.scenes) {
        for (const clip of scene.audio) {
          const buffer = buffersRef.current[clip.mediaId];
          if (!buffer) continue;
          const absoluteStart = scene.timings.start + clip.start;
          if (absoluteStart + buffer.duration < safeFrom) continue;
          const source = ctx.createBufferSource();
          source.buffer = buffer;
          const gain = ctx.createGain();
          gain.gain.value = clip.volume * Math.max(0, Math.min(1, projectNow.timing.voiceVolume / 100));
          source.connect(gain);
          gain.connect(master);
          const when = base + Math.max(0, absoluteStart - safeFrom);
          const offset = Math.max(0, safeFrom - absoluteStart);
          try {
            source.start(when, offset);
          } catch {
            continue;
          }
          sourcesRef.current.push(source);
          nodesRef.current.push(gain);
        }
      }
      if (projectNow.timing.backgroundMusicId) {
        const music = buffersRef.current[projectNow.timing.backgroundMusicId];
        if (music && projectNow.timing.musicVolume > 0) {
          const source = ctx.createBufferSource();
          source.buffer = music;
          source.loop = true;
          const gain = ctx.createGain();
          gain.gain.value = (projectNow.timing.musicVolume / 100) * 0.6;
          source.connect(gain);
          gain.connect(master);
          try {
            source.start(base, safeFrom % music.duration);
          } catch {
            /* ignore */
          }
          sourcesRef.current.push(source);
          nodesRef.current.push(gain);
        }
      }
      if (projectNow.timing.sfxEnabled && projectNow.timing.sfxVolume > 0) {
        const gainValue = (projectNow.timing.sfxVolume / 100) * 0.3;
        for (const scene of timelineNow.scenes) {
          const at = scene.timings.start + scene.timings.revealStart;
          if (at < safeFrom) continue;
          [659.25, 830.61, 987.77].forEach((frequency, index) => {
            const when = base + Math.max(0, at - safeFrom) + index * 0.1;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = "sine";
            osc.frequency.value = frequency;
            gain.gain.setValueAtTime(0.0001, when);
            gain.gain.linearRampToValueAtTime(gainValue, when + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.0001, when + 0.4);
            osc.connect(gain);
            gain.connect(master);
            osc.start(when);
            osc.stop(when + 0.42);
            sourcesRef.current.push(osc);
            nodesRef.current.push(gain);
          });
        }
      }
      setPlaying(true);
    },
    [ensureCtx, muted, stopPlaybackNodes, toast, volume],
  );

  const pause = useCallback(() => {
    const ctx = ctxRef.current;
    const elapsed = ctx ? Math.max(0, ctx.currentTime - clockStartRef.current) : positionRef.current;
    const bounded = Math.min(elapsed, timelineRef.current.totalDuration);
    positionRef.current = bounded;
    setPosition(bounded);
    stopPlaybackNodes();
    setPlaying(false);
  }, [stopPlaybackNodes]);

  useEffect(() => {
    if (!playing) return;
    const tick = () => {
      const ctx = ctxRef.current;
      if (!ctx) return;
      const current = Math.min(timelineRef.current.totalDuration, Math.max(0, ctx.currentTime - clockStartRef.current));
      positionRef.current = current;
      drawAt(current);
      const now = performance.now();
      if (now - lastUiUpdate.current > 100) {
        lastUiUpdate.current = now;
        setPosition(current);
      }
      if (current >= timelineRef.current.totalDuration - 0.02) {
        stopPlaybackNodes();
        setPlaying(false);
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [playing, drawAt, stopPlaybackNodes]);

  useEffect(() => {
    if (masterRef.current) masterRef.current.gain.value = muted ? 0 : volume / 100;
  }, [muted, volume]);

  useEffect(() => {
    const signature = timeline.scenes
      .map((scene) => `${scene.questionId}:${scene.timings.duration.toFixed(3)}:${scene.audio.map((clip) => clip.mediaId).join(",")}`)
      .join("|");
    if (previousSignature.current && previousSignature.current !== signature) {
      positionRef.current = 0;
      setPosition(0);
      if (playing) {
        stopPlaybackNodes();
        setPlaying(false);
      }
    }
    previousSignature.current = signature;
  }, [timeline, playing, stopPlaybackNodes]);

  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      stopPlaybackNodes();
      if (ctxRef.current) void ctxRef.current.close();
    };
  }, [stopPlaybackNodes]);

  const seek = (value: number) => {
    const bounded = Math.max(0, Math.min(timeline.totalDuration, value));
    setPosition(bounded);
    positionRef.current = bounded;
    drawAt(bounded);
    if (playing) void startFrom(bounded, true);
  };

  const jumpScene = (direction: -1 | 1) => {
    const at = sceneAt(timeline, position);
    if (!at) return;
    const targetIndex = Math.max(0, Math.min(timeline.scenes.length - 1, at.scene.index + direction));
    const target = timeline.scenes[targetIndex];
    seek(target.timings.start + 0.01);
  };

  const at = sceneAt(timeline, position);
  const phase = at ? phaseAt(at.scene, at.local) : null;
  const currentScene = at?.scene;
  const progress = timeline.totalDuration ? (position / timeline.totalDuration) * 100 : 0;

  return (
    <div className={cn("panel overflow-hidden", className)}>
      <div className="grid gap-0 lg:grid-cols-[1fr_290px]">
        <div className="relative flex items-center justify-center bg-[#050506] p-3 sm:p-5">
          <div className="relative w-full max-w-[380px]">
            <div
              className="relative overflow-hidden rounded-2xl border border-white/10 bg-black shadow-[0_40px_100px_-40px_rgba(0,0,0,1)]"
              style={{ aspectRatio: `${project.exportSettings.width} / ${project.exportSettings.height}`, maxHeight: "62dvh" }}
            >
              <canvas ref={canvasRef} className="h-full w-full object-contain" aria-label="الفيديو في المعاينة" />
              <button
                type="button"
                onClick={() => (playing ? pause() : void startFrom(position, true))}
                className="absolute inset-0 z-10 flex items-center justify-center focus:outline-none"
                aria-label={playing ? "إيقاف المعاينة" : "تشغيل المعاينة"}
              >
                {!playing ? (
                  <span className="flex h-14 w-14 items-center justify-center rounded-full border border-white/25 bg-black/55 text-white backdrop-blur transition hover:bg-[#d9b65a] hover:text-[#161205]">
                    <Play size={22} className="-mr-1" />
                  </span>
                ) : null}
              </button>
              <div className="pointer-events-none absolute inset-x-3 bottom-3 z-20 flex items-center justify-between gap-2">
                <span className="rounded-full border border-white/15 bg-black/65 px-2.5 py-1 text-[10px] text-white backdrop-blur">
                  {currentScene ? `سؤال ${toArabicDigits(currentScene.index + 1)} من ${toArabicDigits(timeline.scenes.length)}` : "لا توجد أسئلة"}
                </span>
                {phase ? <span className="rounded-full border border-[#d9b65a]/25 bg-black/65 px-2.5 py-1 text-[10px] text-[#f0dfb4] backdrop-blur">{phase.label}</span> : null}
              </div>
              {decoding ? (
                <div className="absolute right-3 top-3 z-20 flex items-center gap-1.5 rounded-full border border-white/10 bg-black/70 px-2 py-1 text-[9px] text-[#d8d8de] backdrop-blur">
                  <span className="h-2.5 w-2.5 animate-spin rounded-full border border-current border-t-transparent" /> تجهيز الصوت
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4 border-t border-white/[0.07] p-4 lg:border-r lg:border-t-0">
          <div>
            <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-[#73737c]">وضع المعاينة</p>
            <p className="mt-1 font-display text-[16px] font-bold text-white">مشهد مطابق للتصدير</p>
            <p className="mt-1 text-[11px] leading-5 text-[#85858f]">نفس الخط الزمني ونفس محرك الرسم المستخدم في ملف MP4.</p>
          </div>

          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-2.5">
            <div className="flex items-center justify-between text-[10px] text-[#8e8e98]">
              <span>{formatClock(position)}</span>
              <span>{formatClock(timeline.totalDuration)}</span>
            </div>
            <div className="relative mt-1.5">
              <div className="absolute inset-x-0 top-1/2 flex h-1.5 -translate-y-1/2 overflow-hidden rounded-full bg-white/10">
                {timeline.scenes.map((scene, index) => (
                  <span
                    key={scene.questionId}
                    style={{ width: `${(scene.timings.duration / Math.max(0.01, timeline.totalDuration)) * 100}%` }}
                    className={index % 2 === 0 ? "h-full bg-[#4a4434]" : "h-full bg-[#35353c]"}
                  />
                ))}
              </div>
              <div className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 overflow-hidden rounded-full">
                <span className="block h-full bg-[#d9b65a]" style={{ width: `${progress}%` }} />
              </div>
              <input
                type="range"
                min={0}
                max={Math.max(0.1, timeline.totalDuration)}
                step={0.05}
                value={position}
                onChange={(event) => seek(Number(event.target.value))}
                className="relative z-10 w-full cursor-pointer opacity-0"
                style={{ height: 18 }}
                aria-label="الموضع الزمني في الفيديو"
              />
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5">
            <button type="button" onClick={() => seek(0)} className="rounded-lg p-2 text-[#9c9ca6] transition hover:bg-white/5 hover:text-white" aria-label="إعادة من البداية">
              <RotateCcw size={16} />
            </button>
            <button type="button" onClick={() => jumpScene(-1)} disabled={!currentScene || currentScene.index === 0} className="rounded-lg p-2 text-[#c9c9d1] transition hover:bg-white/5 disabled:opacity-30" aria-label="السؤال السابق">
              <SkipForward size={18} />
            </button>
            <button
              type="button"
              onClick={() => (playing ? pause() : void startFrom(position, true))}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-b from-[#eedaa2] to-[#d9b65a] text-[#171307] shadow-lg transition active:scale-95"
              aria-label={playing ? "إيقاف" : "تشغيل"}
            >
              {playing ? <Pause size={18} /> : <Play size={18} className="-mr-0.5" />}
            </button>
            <button type="button" onClick={() => jumpScene(1)} disabled={!currentScene || currentScene.index >= timeline.scenes.length - 1} className="rounded-lg p-2 text-[#c9c9d1] transition hover:bg-white/5 disabled:opacity-30" aria-label="السؤال التالي">
              <SkipBack size={18} />
            </button>
            <button type="button" onClick={() => setMuted((value) => !value)} className="rounded-lg p-2 text-[#9c9ca6] transition hover:bg-white/5 hover:text-white" aria-label={muted ? "إلغاء كتم الصوت" : "كتم الصوت"}>
              {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#777781]">الصوت</span>
            <input type="range" min={0} max={100} value={muted ? 0 : volume} onChange={(event) => setVolume(Number(event.target.value))} className="range w-full" style={{ "--fill": `${muted ? 0 : volume}%` } as React.CSSProperties} aria-label="مستوى صوت المعاينة" />
            <span className="w-7 text-left text-[10px] tabular-nums text-[#9c9ca6]" dir="ltr">{muted ? 0 : volume}%</span>
          </div>

          <div className="mt-auto space-y-2">
            <div className="flex items-center gap-2 rounded-lg border border-white/[0.07] bg-white/[0.02] px-2.5 py-2 text-[10px] text-[#8f8f99]">
              <Film size={13} className="text-[#b5a06c]" />
              {project.exportSettings.width}×{project.exportSettings.height} · {project.exportSettings.fps} إطار/ث
            </div>
            {audioWarning ? (
              <div className="flex items-start gap-1.5 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-2.5 py-2 text-[10px] leading-5 text-amber-200">
                <AlertTriangle size={12} className="mt-0.5 shrink-0" /> {audioWarning}
              </div>
            ) : null}
            {!timeline.hasAudio ? (
              <div className="flex items-start gap-1.5 rounded-lg border border-white/10 bg-white/[0.03] px-2.5 py-2 text-[10px] leading-5 text-[#a5a5af]">
                <AlertTriangle size={12} className="mt-0.5 shrink-0" /> لا توجد ملفات صوت مرتبطة؛ المعاينة تعمل بالوقت الصامت، ويمكنك إضافة الصوت من صفحة الصوت والتوقيت.
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
