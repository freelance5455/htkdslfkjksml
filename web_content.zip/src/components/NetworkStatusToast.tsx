import React, { useState, useEffect } from 'react';
import { WifiOff, Wifi, Sparkles, X, CheckCircle2, Music, Server } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { checkIsOwnerAuthenticated } from '../lib/ownerSecurity';
import { ipManager } from '../lib/ipManager';
import { nativeSocketEngine, SocketConnectionState } from '../lib/magicIpEngine';

interface NetworkStatusToastProps {
  onNavigateToWorship?: () => void;
}

export const NetworkStatusToast: React.FC<NetworkStatusToastProps> = ({
  onNavigateToWorship
}) => {
  const [isOffline, setIsOffline] = useState<boolean>(typeof navigator !== 'undefined' ? !navigator.onLine : false);
  const [showToast, setShowToast] = useState<boolean>(typeof navigator !== 'undefined' ? !navigator.onLine : false);
  const [justCameOnline, setJustCameOnline] = useState<boolean>(false);
  const [reconciledInfo, setReconciledInfo] = useState<{ prayerRequestsSynced: number; miningEventsSynced: number } | null>(null);
  const [downloadedCount, setDownloadedCount] = useState<number>(() => {
    try {
      return offlineCache?.getDownloadedTracks?.()?.length || 3;
    } catch {
      return 3;
    }
  });

  const isOwner = checkIsOwnerAuthenticated();
  const currentIp = ipManager.getIp();
  const [socketState, setSocketState] = useState<SocketConnectionState>(nativeSocketEngine.getState());

  useEffect(() => {
    const unsubSocket = nativeSocketEngine.subscribe((state) => {
      setSocketState(state);
    });

    const unsubIp = ipManager.subscribe(() => {
      // re-render on ip change
    });

    const handleOnline = () => {
      setIsOffline(false);
      setJustCameOnline(true);
      setShowToast(true);

      const timer = setTimeout(() => {
        setJustCameOnline(false);
        setReconciledInfo(null);
        setShowToast(false);
      }, 4000);

      return () => clearTimeout(timer);
    };

    const handleOffline = () => {
      setIsOffline(true);
      setJustCameOnline(false);
      setReconciledInfo(null);
      setShowToast(true);
      try {
        setDownloadedCount(offlineCache?.getDownloadedTracks?.()?.length || 3);
      } catch (e) {
        // fallback
      }
    };

    const handleReconciled = (e: any) => {
      if (e.detail && e.detail.success) {
        setReconciledInfo({
          prayerRequestsSynced: e.detail.prayerRequestsSynced,
          miningEventsSynced: e.detail.miningEventsSynced
        });
        setIsOffline(false);
        setJustCameOnline(true);
        setShowToast(true);

        const timer = setTimeout(() => {
          setJustCameOnline(false);
          setReconciledInfo(null);
          setShowToast(false);
        }, 5500);

        return () => clearTimeout(timer);
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('juhnkrix-offline-reconciled', handleReconciled as EventListener);

    const unsubscribe = offlineCache?.subscribe?.(() => {
      try {
        setDownloadedCount(offlineCache?.getDownloadedTracks?.()?.length || 3);
      } catch (e) {
        // fallback
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('juhnkrix-offline-reconciled', handleReconciled as EventListener);
      if (typeof unsubscribe === 'function') unsubscribe();
      if (typeof unsubSocket === 'function') unsubSocket();
      if (typeof unsubIp === 'function') unsubIp();
    };
  }, []);

  // Also show toast or indicator if owner is logged in to display Connected to IP: [current_ip]
  const shouldShowOwnerIpBanner = isOwner && !isOffline;

  if (!showToast && !shouldShowOwnerIpBanner) return null;

  return (
    <div
      id="network-offline-toast"
      className="fixed bottom-28 sm:bottom-24 right-4 sm:right-6 z-40 max-w-md w-[calc(100vw-2rem)] sm:w-auto transition-all duration-500 ease-out animate-slideUp"
    >
      {isOffline ? (
        <div className="bg-slate-950/95 border border-amber-500/40 rounded-2xl p-4 shadow-2xl backdrop-blur-xl space-y-3 relative text-left">
          <button
            onClick={() => setShowToast(false)}
            className="absolute top-3 right-3 p-1 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-900 transition-colors"
            aria-label="Dismiss offline notification"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-start space-x-3 pr-6">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 shrink-0 shadow-md">
              <WifiOff className="w-5 h-5 text-amber-400 animate-pulse" />
            </div>

            <div className="space-y-1 min-w-0">
              <div className="flex items-center space-x-2">
                <h4 className="text-xs font-bold font-serif text-amber-100 uppercase tracking-wider">
                  Offline Mode Active
                </h4>
                <span className="px-2 py-0.2 rounded-full text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  Cached Sanctuary
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Device is currently offline. Your cached worship songs, devotionals, and synthesized 528Hz soaking audio are ready for offline listening.
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between gap-2">
            <div className="flex items-center space-x-1.5 text-[11px] font-mono text-emerald-400">
              <Music className="w-3.5 h-3.5" />
              <span>{downloadedCount} Cached Tracks Ready</span>
            </div>

            <div className="flex items-center space-x-2">
              {onNavigateToWorship && (
                <button
                  onClick={() => {
                    onNavigateToWorship();
                    setShowToast(false);
                  }}
                  className="px-3 py-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1 transition-all shadow-md"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Listen Offline</span>
                </button>
              )}
              <button
                onClick={() => setShowToast(false)}
                className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      ) : shouldShowOwnerIpBanner && !showToast ? (
        <div className="bg-slate-950/95 border border-indigo-500/40 rounded-2xl p-3 shadow-2xl backdrop-blur-xl flex items-center justify-between gap-3 text-left animate-fadeIn">
          <div className="flex items-center space-x-2.5">
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shrink-0">
              <Server className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider font-mono">
                Owner Socket Active
              </div>
              <div className="text-xs font-mono font-bold text-slate-100">
                Connected to IP: {currentIp} <span className="text-[10px] text-emerald-400 font-normal">({socketState.status})</span>
              </div>
            </div>
          </div>
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></div>
        </div>
      ) : justCameOnline ? (
        <div className="bg-slate-950/95 border border-emerald-500/40 rounded-2xl p-3.5 shadow-2xl backdrop-blur-xl flex items-center justify-between gap-3 text-left animate-fadeIn">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shrink-0">
              <Wifi className="w-4 h-4 text-emerald-400 animate-pulse" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-emerald-300 flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cloudflare Offline-First Reconciled</span>
              </h5>
              <p className="text-[11px] text-slate-300">
                {reconciledInfo
                  ? `Synced ${reconciledInfo.prayerRequestsSynced} prayer requests & ${reconciledInfo.miningEventsSynced} mining records to Cloudflare storage.`
                  : 'Live sanctuary broadcasts and prophetic updates reconnected.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowToast(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-emerald-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : null}
    </div>
  );
};
