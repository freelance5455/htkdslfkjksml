import { ArrowUpLeft, Star, Volume2 } from 'lucide-react';
import { BAND_META } from '../data/constants';
import type { VocabEntry } from '../types';

interface WordRowProps {
  word: VocabEntry;
  isFavorite: boolean;
  isMistake: boolean;
  isMastered: boolean;
  onOpenDetail: (id: number) => void;
  onSpeak: (text: string) => void;
  onToggleFavorite: (id: number) => void;
  onPrefetchWord?: (word: VocabEntry) => void;
}

export function WordRow({
  word,
  isFavorite,
  isMistake,
  isMastered,
  onOpenDetail,
  onSpeak,
  onToggleFavorite,
  onPrefetchWord,
}: WordRowProps) {
  const meta = BAND_META[word.band];

  return (
    <div
      onMouseEnter={() => onPrefetchWord?.(word)}
      onFocus={() => onPrefetchWord?.(word)}
      className="tmn-card-hover flex items-center justify-between gap-3 rounded-2xl px-4 py-3.5"
    >
      <button
        type="button"
        onClick={() => onOpenDetail(word.id)}
        className="flex min-w-0 flex-1 items-center gap-3.5 rounded-xl text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
      >
        <span
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl font-en text-xs font-extrabold text-white shadow-2xs ${meta.bgClass}`}
          aria-label={`المستوى ${word.band}`}
        >
          {word.band}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-2">
            <span
              className="font-en text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-50"
              dir="ltr"
            >
              {word.en}
            </span>
            <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">
              ·
            </span>
            <span className="truncate text-sm font-medium text-slate-600 dark:text-slate-300">
              {word.ar}
            </span>
          </div>
          {(isMastered || isMistake) && (
            <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              {isMastered && (
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">متقنة</span>
              )}
              {isMastered && isMistake && <span aria-hidden="true">·</span>}
              {isMistake && (
                <span className="font-semibold text-amber-600 dark:text-amber-400">
                  في بنك الأخطاء
                </span>
              )}
            </div>
          )}
        </div>
      </button>

      <div className="flex shrink-0 items-center gap-1.5">
        <button
          type="button"
          onClick={() => onSpeak(word.en)}
          aria-label={`نطق كلمة ${word.en}`}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-50/90 text-slate-700 transition-colors hover:border-indigo-400/50 hover:bg-indigo-50/70 hover:text-indigo-600 dark:border-slate-700/60 dark:bg-slate-800/60 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Volume2 className="h-4 w-4" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => onToggleFavorite(word.id)}
          aria-label={isFavorite ? `إزالة ${word.en} من المفضلة` : `إضافة ${word.en} إلى المفضلة`}
          className={`flex h-10 w-10 items-center justify-center rounded-xl border transition-colors ${
            isFavorite
              ? 'border-amber-300 bg-amber-50 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-400'
              : 'border-slate-200/80 bg-slate-50/90 text-slate-500 hover:bg-slate-100 dark:border-slate-700/60 dark:bg-slate-800/60 dark:text-slate-400 dark:hover:bg-slate-800'
          }`}
        >
          <Star className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => onOpenDetail(word.id)}
          aria-label={`تفاصيل كلمة ${word.en}`}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-50/90 text-slate-600 transition-colors hover:border-indigo-400/50 hover:bg-indigo-50/70 hover:text-indigo-600 dark:border-slate-700/60 dark:bg-slate-800/60 dark:text-slate-300 dark:hover:bg-slate-800"
        >
          <ArrowUpLeft className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
