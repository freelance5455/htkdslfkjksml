import React, { useState } from 'react';
import { Calculator, MessageCircle, Sparkles, Plus, Check } from 'lucide-react';
import { DJ_SERVICES } from '../data/djData';

interface QuoteCalculatorProps {
  onApplyToBooking: (serviceId: string, estimatedTotal: number, details: string) => void;
}

export const QuoteCalculator: React.FC<QuoteCalculatorProps> = ({ onApplyToBooking }) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>('party');
  const [extraHours, setExtraHours] = useState<number>(0);
  const [soundOption, setSoundOption] = useState<'dj_only' | 'small_sound' | 'full_sound'>('dj_only');
  const [locationArea, setLocationArea] = useState<string>('Bwaise / Kawempe');

  const selectedService = DJ_SERVICES.find((s) => s.id === selectedServiceId) || DJ_SERVICES[0];

  const soundAddons: Record<string, { label: string; price: number; desc: string }> = {
    dj_only: { label: 'DJ Services Only', price: 0, desc: 'Venue already has sound system' },
    small_sound: { label: 'DJ + 2 Active JBL Tops', price: 100000, desc: 'Perfect for up to 100 guests' },
    full_sound: { label: 'DJ + Full Sound (Tops + Bass Bins + Mics)', price: 250000, desc: 'Concert & Wedding grade sound' },
  };

  const extraHourRate = 30000; // 30k UGX per extra hour
  const soundCost = soundAddons[soundOption].price;
  const totalUgx = selectedService.priceUgx + extraHours * extraHourRate + soundCost;

  const handleWhatsAppBooking = () => {
    const summary = `Hello DJ EVAN PRO UG! Here is my customized quote from your website:
- Service: ${selectedService.name} (UGX ${selectedService.displayPrice})
- Sound Setup: ${soundAddons[soundOption].label} (+UGX ${(soundCost / 1000).toFixed(0)}k)
- Extra Hours: ${extraHours} hrs (+UGX ${(extraHours * extraHourRate / 1000).toFixed(0)}k)
- Preferred Location: ${locationArea}
- Estimated Total: UGX ${(totalUgx / 1000).toFixed(0)},000/=

Is your date available for this booking?`;

    const url = `https://wa.me/256742094651?text=${encodeURIComponent(summary)}`;
    window.open(url, '_blank');
  };

  return (
    <section className="py-12 px-4 max-w-4xl mx-auto">
      <div className="bg-gradient-to-br from-[#120a24] via-[#0d0718] to-[#080511] border-2 border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Decorative corner light */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-purple-900/40">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-widest mb-1">
              <Calculator className="w-3.5 h-3.5" />
              Instant Event Estimator
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white uppercase">
              Calculate Your Custom Package
            </h3>
            <p className="text-xs text-slate-400">
              Customize event type, sound gear, and extra hours for transparent pricing in Kampala &amp; Wakiso.
            </p>
          </div>

          <div className="text-right bg-purple-950/60 border border-purple-700/50 p-3 rounded-xl min-w-[180px]">
            <span className="text-[11px] font-mono text-purple-300 block uppercase">
              Estimated Total:
            </span>
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
              UGX {(totalUgx / 1000).toFixed(0)}k
              <span className="text-xs text-slate-400 font-sans font-normal ml-1">/=</span>
            </div>
          </div>
        </div>

        {/* Configuration grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
          {/* Step 1: Event Type */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              1. Select Event Type
            </label>
            <select
              value={selectedServiceId}
              onChange={(e) => setSelectedServiceId(e.target.value)}
              className="w-full bg-slate-900 border border-purple-800/60 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              {DJ_SERVICES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.displayPrice})
                </option>
              ))}
            </select>
            <span className="text-[11px] text-purple-300 block">
              Base: UGX {selectedService.displayPrice} • {selectedService.duration}
            </span>
          </div>

          {/* Step 2: Sound System */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              2. Sound Equipment
            </label>
            <select
              value={soundOption}
              onChange={(e) => setSoundOption(e.target.value as any)}
              className="w-full bg-slate-900 border border-purple-800/60 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="dj_only">DJ Gear Only (+0k)</option>
              <option value="small_sound">+ 2 Active JBL Tops (+100k)</option>
              <option value="full_sound">+ Concert Tops &amp; Bass Bins (+250k)</option>
            </select>
            <span className="text-[11px] text-slate-400 block">
              {soundAddons[soundOption].desc}
            </span>
          </div>

          {/* Step 3: Extra Hours */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              3. Extra Overtime Hours
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setExtraHours(Math.max(0, extraHours - 1))}
                className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-700 text-white font-bold hover:bg-purple-800"
              >
                -
              </button>
              <div className="flex-1 text-center font-mono font-bold text-white bg-slate-900 py-2 rounded-xl border border-purple-900/60">
                {extraHours} {extraHours === 1 ? 'hr' : 'hrs'}
              </div>
              <button
                type="button"
                onClick={() => setExtraHours(extraHours + 1)}
                className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-700 text-white font-bold hover:bg-purple-800"
              >
                +
              </button>
            </div>
            <span className="text-[11px] text-slate-400 block">
              +UGX 30k/hr for late night extensions
            </span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-purple-900/40">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Zero booking commission • Direct payment to DJ Evan Pro</span>
          </div>

          <button
            onClick={handleWhatsAppBooking}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-500 hover:brightness-110 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 active:scale-95 transition-all"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Lock Quote on WhatsApp (UGX {(totalUgx / 1000).toFixed(0)}k)</span>
          </button>
        </div>
      </div>
    </section>
  );
};
