export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <rect x="16" y="16" width="16" height="16" fill="currentColor" transform="rotate(45 24 24)" />
      <rect x="18" y="6" width="12" height="36" fill="currentColor" />
      <rect x="6" y="18" width="36" height="12" fill="currentColor" />
    </svg>
  );
}
