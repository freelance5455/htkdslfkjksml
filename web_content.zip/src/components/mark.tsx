export function ShelfMark({ className = "size-10" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <rect x="6" y="10" width="8" height="28" rx="1.5" fill="currentColor" opacity="0.92" />
      <rect x="16" y="8" width="7" height="30" rx="1.5" fill="currentColor" opacity="0.72" />
      <rect x="25" y="12" width="9" height="26" rx="1.5" fill="currentColor" opacity="0.84" />
      <rect x="36" y="9" width="6" height="29" rx="1.5" fill="currentColor" opacity="0.6" />
      <rect x="4" y="38" width="40" height="3" rx="1" fill="currentColor" />
    </svg>
  );
}

export function SealLock({ className = "size-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <rect x="12" y="22" width="24" height="18" rx="3" fill="none" stroke="currentColor" strokeWidth="2" />
      <path
        d="M17 22v-6a7 7 0 0 1 14 0v6"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <circle cx="24" cy="31" r="2.2" fill="currentColor" />
    </svg>
  );
}
