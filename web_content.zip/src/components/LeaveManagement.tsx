import React, { useState, useMemo } from 'react';
import {
  CalendarDays,
  Plus,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Layers,
  History,
  Trash2,
  Download,
  Settings2,
} from 'lucide-react';
import { AppSettings, LeaveRecord, LeaveType } from '../types';
import { translations } from '../utils/translations';
import { calculateLeaveBalances } from '../utils/calculations';
import { StorageService } from '../utils/storage';

interface LeaveManagementProps {
  records: LeaveRecord[];
  onUpdateRecords: (records: LeaveRecord[]) => void;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
}

export const LeaveManagement: React.FC<LeaveManagementProps> = ({
  records,
  onUpdateRecords,
  settings,
  onUpdateSettings,
}) => {
  const t = translations[settings.language];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [filterType, setFilterType] = useState<string>('');

  // Form State
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [leaveType, setLeaveType] = useState<LeaveType>('CL');
  const [numberOfDays, setNumberOfDays] = useState<number | ''>(1);
  const [reason, setReason] = useState('');
  const [remarks, setRemarks] = useState('');

  // Config State
  const [tempClLimit, setTempClLimit] = useState(settings.clAnnualLimit);
  const [tempSlLimit, setTempSlLimit] = useState(settings.slAnnualLimit);
  const [tempCplExpiry, setTempCplExpiry] = useState(settings.cplExpiryDays);
  const [tempStartMonth, setTempStartMonth] = useState(settings.leaveYearStartMonth);

  // Compute live leave summary using the FIFO lots calculation engine
  const summary = useMemo(() => {
    return calculateLeaveBalances(records, {
      clLimit: settings.clAnnualLimit,
      slLimit: settings.slAnnualLimit,
      cplExpiryDays: settings.cplExpiryDays,
      leaveYearStartMonth: settings.leaveYearStartMonth,
      leaveYearStartDay: settings.leaveYearStartDay,
      asOfDate: new Date(),
    });
  }, [records, settings]);

  // Active records
  const activeRecords = useMemo(() => {
    return records
      .filter((r) => !r.isDeleted)
      .filter((r) => (filterType === '' ? true : r.leaveType === filterType))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [records, filterType]);

  // Add leave entry
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const days = Number(numberOfDays);
    if (!reason.trim()) {
      alert('Please enter reason for leave / duty');
      return;
    }
    if (days <= 0) {
      alert('Days must be greater than zero');
      return;
    }

    // Balance checks
    if (leaveType === 'CL' && days > summary.clRemaining) {
      if (!window.confirm(`Warning: Requested ${days} CL days exceeds current remaining CL balance (${summary.clRemaining}). Proceed anyway?`)) {
        return;
      }
    }
    if (leaveType === 'SL' && days > summary.slRemaining) {
      if (!window.confirm(`Warning: Requested ${days} SL days exceeds current remaining SL balance (${summary.slRemaining}). Proceed anyway?`)) {
        return;
      }
    }
    if (leaveType === 'CPL Used' && days > summary.cplAvailable) {
      if (!window.confirm(`Warning: Requested ${days} CPL days exceeds currently valid unexpired CPL balance (${summary.cplAvailable}). Proceed anyway?`)) {
        return;
      }
    }

    const newRec: LeaveRecord = {
      id: `leave_${Date.now()}`,
      date,
      leaveType,
      numberOfDays: days,
      reason: reason.trim(),
      remarks: remarks.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updated = [newRec, ...records];
    onUpdateRecords(updated);
    StorageService.saveLeaves(updated);
    StorageService.addAuditLog('CREATE', 'Leaves', `Added ${days} days of ${leaveType} on ${date}`, null, newRec);

    setIsModalOpen(false);
    setReason('');
    setRemarks('');
  };

  // Delete leave entry
  const handleDelete = (rec: LeaveRecord) => {
    if (window.confirm(t.confirmDelete)) {
      const updated = records.map((r) => (r.id === rec.id ? { ...r, isDeleted: true } : r));
      onUpdateRecords(updated);
      StorageService.saveLeaves(updated);
      StorageService.moveToRecycleBin('Leaves', rec.id, `${rec.leaveType}: ${rec.numberOfDays} days (${rec.date})`, rec);
    }
  };

  // Save Config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...settings,
      clAnnualLimit: Number(tempClLimit) || 10,
      slAnnualLimit: Number(tempSlLimit) || 8,
      cplExpiryDays: Number(tempCplExpiry) || 40,
      leaveYearStartMonth: Number(tempStartMonth) || 7,
    };
    onUpdateSettings(updated);
    StorageService.saveSettings(updated);
    setIsConfigModalOpen(false);
  };

  // Export CSV
  const handleExportCSV = () => {
    const rows = activeRecords.map((r) => ({
      Date: r.date,
      'Leave Type': r.leaveType,
      Days: r.numberOfDays,
      Reason: r.reason,
      Remarks: r.remarks || '',
    }));
    StorageService.exportToCsv('Leave_Records_Export', rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 rounded-lg">
            <CalendarDays className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {t.leaveManagement}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Annual CL/SL Quotas & FIFO Compensatory Leave (CPL) Expiry Engine
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsConfigModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Settings2 className="w-4 h-4 text-slate-500" />
            <span>Leave Rules</span>
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addLeave}</span>
          </button>
        </div>
      </div>

      {/* Leave Year Banner */}
      <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 p-3 rounded-xl flex items-center justify-between text-xs text-blue-900 dark:text-blue-200">
        <div className="flex items-center gap-2 font-medium">
          <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
          <span>
            {t.leaveYearNotice} • Starting Month:{' '}
            <strong className="font-bold underline">
              {new Date(2026, settings.leaveYearStartMonth - 1, 1).toLocaleString('default', { month: 'long' })}
            </strong>
          </span>
        </div>
        <span className="text-[11px] text-blue-600 dark:text-blue-400">
          CPL Expiry: {settings.cplExpiryDays} Days
        </span>
      </div>

      {/* KPI Balances Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Casual Leave (CL) Card */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Casual Leave (CL)
            </span>
            <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
              Quota: {summary.clOpening} Days
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[10px] text-slate-400 block">{t.clOpening}</span>
              <span className="text-lg font-bold text-slate-900 dark:text-white">
                {summary.clOpening}
              </span>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[10px] text-slate-400 block">{t.clUsed}</span>
              <span className="text-lg font-bold text-rose-600 dark:text-rose-400">
                {summary.clUsed}
              </span>
            </div>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg border border-emerald-200 dark:border-emerald-800/60">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-400 block">
                {t.clRemaining}
              </span>
              <span className="text-lg font-bold text-emerald-600 dark:text-emerald-300">
                {summary.clRemaining}
              </span>
            </div>
          </div>
        </div>

        {/* Sick Leave (SL) Card */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Sick Leave (SL)
            </span>
            <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
              Quota: {summary.slOpening} Days
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[10px] text-slate-400 block">{t.slOpening}</span>
              <span className="text-lg font-bold text-slate-900 dark:text-white">
                {summary.slOpening}
              </span>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[10px] text-slate-400 block">{t.slUsed}</span>
              <span className="text-lg font-bold text-rose-600 dark:text-rose-400">
                {summary.slUsed}
              </span>
            </div>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg border border-emerald-200 dark:border-emerald-800/60">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-400 block">
                {t.slRemaining}
              </span>
              <span className="text-lg font-bold text-emerald-600 dark:text-emerald-300">
                {summary.slRemaining}
              </span>
            </div>
          </div>
        </div>

        {/* Compensatory Leave (CPL) Card */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              CPL (FIFO Allocation)
            </span>
            <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
              {settings.cplExpiryDays}-Day Expiry
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 text-center">
            <div className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[9px] text-slate-400 block">Earned</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">
                {summary.cplEarned}
              </span>
            </div>
            <div className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[9px] text-slate-400 block">Used</span>
              <span className="text-base font-bold text-rose-500">
                {summary.cplUsed}
              </span>
            </div>
            <div className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <span className="text-[9px] text-slate-400 block">Expired</span>
              <span className="text-base font-bold text-slate-400 line-through">
                {summary.cplExpired}
              </span>
            </div>
            <div className="p-1.5 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg border border-emerald-200 dark:border-emerald-800/60">
              <span className="text-[9px] text-emerald-700 dark:text-emerald-400 block font-semibold">
                Available
              </span>
              <span className="text-base font-bold text-emerald-600 dark:text-emerald-300">
                {summary.cplAvailable}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* CPL Lots FIFO Inspector */}
      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-purple-500" />
            {t.cplLotAllocation} (FIFO: Oldest Valid Lots Consumed First)
          </h3>
          <span className="text-[11px] text-slate-400">
            {summary.cplLots.length} lot(s) recorded
          </span>
        </div>

        {summary.cplLots.length === 0 ? (
          <p className="text-xs text-slate-400 py-3 text-center">No CPL earning lots recorded yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {summary.cplLots.map((lot, idx) => (
              <div
                key={lot.id}
                className={`p-3 rounded-lg border text-xs space-y-1.5 transition ${
                  lot.isExpired
                    ? 'bg-slate-100/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-400 opacity-70'
                    : lot.isFullyConsumed
                    ? 'bg-slate-100/50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800 text-slate-400'
                    : 'bg-white dark:bg-slate-900 border-purple-200 dark:border-purple-900/60 shadow-xs'
                }`}
              >
                <div className="flex justify-between items-center font-bold">
                  <span className="text-slate-800 dark:text-slate-200">
                    Lot #{idx + 1} • {lot.earnDate}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] ${
                      lot.isExpired
                        ? 'bg-red-100 dark:bg-red-950 text-red-600'
                        : lot.isFullyConsumed
                        ? 'bg-slate-200 dark:bg-slate-800 text-slate-600'
                        : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 font-semibold'
                    }`}
                  >
                    {lot.isExpired ? 'Expired' : lot.isFullyConsumed ? 'Consumed' : 'Active'}
                  </span>
                </div>

                <div className="flex justify-between text-slate-500">
                  <span>Days Earned:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{lot.daysEarned}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>FIFO Allocated / Used:</span>
                  <span className="font-semibold text-rose-500">{lot.daysUsed}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Expiry Date:</span>
                  <span className="font-medium text-slate-700 dark:text-slate-300">{lot.expiryDate}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-slate-100 dark:border-slate-800 pt-1">
                  <span>Currently Available:</span>
                  <span className={lot.daysRemaining > 0 ? 'text-emerald-600' : 'text-slate-400'}>
                    {lot.daysRemaining} days
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Filter and Leave History Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs space-y-2">
        <div className="p-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Leave History & Records
          </h3>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
          >
            <option value="">All Leave Types</option>
            <option value="CL">CL (Casual Leave)</option>
            <option value="SL">SL (Sick Leave)</option>
            <option value="CPL Earn">CPL Earn</option>
            <option value="CPL Used">CPL Used</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Leave Type</th>
                <th className="px-4 py-3">Number of Days</th>
                <th className="px-4 py-3">Reason / Shift</th>
                <th className="px-4 py-3">Remarks</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                    No leave entries found.
                  </td>
                </tr>
              ) : (
                activeRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                      {r.date}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                          r.leaveType === 'CL'
                            ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                            : r.leaveType === 'SL'
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                            : r.leaveType === 'CPL Earn'
                            ? 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300'
                            : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                        }`}
                      >
                        {r.leaveType}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                      {r.numberOfDays} {r.numberOfDays === 1 ? 'day' : 'days'}
                    </td>
                    <td className="px-4 py-3 text-slate-700 dark:text-slate-300 max-w-sm">
                      {r.reason}
                    </td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                      {r.remarks || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => handleDelete(r)}
                        className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                        title="Delete"
                        aria-label={`Delete leave record on ${r.date}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Leave Record Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-blue-600" />
                {t.addLeave}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Leave Type *
                  </label>
                  <select
                    value={leaveType}
                    onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="CL">Casual Leave (CL)</option>
                    <option value="SL">Sick Leave (SL)</option>
                    <option value="CPL Earn">CPL Earn (Overtime/Duty)</option>
                    <option value="CPL Used">CPL Used (Compensatory)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Number of Days *
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  required
                  value={numberOfDays}
                  onChange={(e) => setNumberOfDays(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Reason / Emergency Shift Description *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. Sunday plant overhaul duty or family event"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Remarks / Approval Reference
                </label>
                <input
                  type="text"
                  placeholder="Approved by GM / gate pass ref"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Leave Rules & Year Config Modal */}
      {isConfigModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-blue-600" />
                Configure Leave Limits & Year
              </h3>
              <button
                type="button"
                onClick={() => setIsConfigModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveConfig} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Annual CL Limit (Days)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={tempClLimit}
                    onChange={(e) => setTempClLimit(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-bold"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Default: 10</p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Annual SL Limit (Days)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={tempSlLimit}
                    onChange={(e) => setTempSlLimit(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-bold"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Default: 8</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    CPL Expiry (Days)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={tempCplExpiry}
                    onChange={(e) => setTempCplExpiry(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-bold"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Default: 40</p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Leave Year Starting Month
                  </label>
                  <select
                    value={tempStartMonth}
                    onChange={(e) => setTempStartMonth(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-semibold"
                  >
                    <option value={1}>January</option>
                    <option value={4}>April</option>
                    <option value={7}>July (Default)</option>
                    <option value={10}>October</option>
                  </select>
                  <p className="text-[10px] text-slate-400 mt-1">Standard: 1 July – 30 June</p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsConfigModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition"
                >
                  Save Rules
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
