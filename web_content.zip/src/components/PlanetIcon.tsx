import type { PlanetKey } from '../utils/ageCalculations';

interface PlanetIconProps {
  planet: PlanetKey;
  className?: string;
}

export function PlanetIcon({ planet, className = 'w-7 h-7' }: PlanetIconProps) {
  switch (planet) {
    case 'mercury':
      return (
        <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="mercury-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#E2E8F0" />
              <stop offset="65%" stopColor="#94A3B8" />
              <stop offset="100%" stopColor="#475569" />
            </radialGradient>
          </defs>
          <circle cx="16" cy="16" r="11" fill="url(#mercury-g)" />
          <circle cx="12.5" cy="13" r="1.6" fill="#64748B" opacity="0.55" />
          <circle cx="19.5" cy="18.5" r="2.1" fill="#475569" opacity="0.5" />
        </svg>
      );
    case 'venus':
      return (
        <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="venus-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FEF3C7" />
              <stop offset="60%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#92400E" />
            </radialGradient>
          </defs>
          <circle cx="16" cy="16" r="11" fill="url(#venus-g)" />
          <path d="M7.5 14.5 Q16 12 24.5 14.5" stroke="#FEF3C7" strokeWidth="1.2" strokeOpacity="0.4" fill="none" />
          <path d="M8.5 19 Q16 17.2 23.5 19" stroke="#FDE68A" strokeWidth="1" strokeOpacity="0.35" fill="none" />
        </svg>
      );
    case 'mars':
      return (
        <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="mars-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FCA5A5" />
              <stop offset="55%" stopColor="#DC2626" />
              <stop offset="100%" stopColor="#7F1D1D" />
            </radialGradient>
          </defs>
          <circle cx="16" cy="16" r="11" fill="url(#mars-g)" />
          <ellipse cx="16" cy="6.6" rx="3.4" ry="1.2" fill="#F8FAFC" opacity="0.7" />
          <circle cx="19" cy="17" r="2.3" fill="#991B1B" opacity="0.45" />
        </svg>
      );
    case 'jupiter':
      return (
        <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="jupiter-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FDE68A" />
              <stop offset="60%" stopColor="#D97706" />
              <stop offset="100%" stopColor="#78350F" />
            </radialGradient>
            <clipPath id="jupiter-clip">
              <circle cx="16" cy="16" r="11.5" />
            </clipPath>
          </defs>
          <circle cx="16" cy="16" r="11.5" fill="url(#jupiter-g)" />
          <g clipPath="url(#jupiter-clip)">
            <rect x="4" y="10.5" width="24" height="2.4" fill="#FEF3C7" opacity="0.38" />
            <rect x="4" y="15.5" width="24" height="2.6" fill="#92400E" opacity="0.45" />
            <rect x="4" y="20.5" width="24" height="1.8" fill="#FDE68A" opacity="0.32" />
            <ellipse cx="20" cy="18.5" rx="2.5" ry="1.5" fill="#DC2626" opacity="0.65" />
          </g>
        </svg>
      );
    case 'saturn':
      return (
        <svg viewBox="0 0 36 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="saturn-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FEF3C7" />
              <stop offset="65%" stopColor="#D4A359" />
              <stop offset="100%" stopColor="#785828" />
            </radialGradient>
          </defs>
          <ellipse
            cx="18"
            cy="16"
            rx="15"
            ry="4.3"
            transform="rotate(-18 18 16)"
            fill="none"
            stroke="#FDE68A"
            strokeWidth="2.2"
            strokeOpacity="0.55"
          />
          <circle cx="18" cy="16" r="8.8" fill="url(#saturn-g)" />
          <path
            d="M4.6 20.4 A15 4.3 -18 0 0 31.4 11.6"
            fill="none"
            stroke="#FEF3C7"
            strokeWidth="2.2"
            strokeOpacity="0.82"
          />
        </svg>
      );
    case 'uranus':
      return (
        <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
          <defs>
            <radialGradient id="uranus-g" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#CFFAFE" />
              <stop offset="60%" stopColor="#22D3EE" />
              <stop offset="100%" stopColor="#0E7490" />
            </radialGradient>
          </defs>
          <circle cx="16" cy="16" r="10.5" fill="url(#uranus-g)" />
          <ellipse
            cx="16"
            cy="16"
            rx="4"
            ry="13.5"
            transform="rotate(24 16 16)"
            fill="none"
            stroke="#A5F3FC"
            strokeWidth="1.2"
            strokeOpacity="0.65"
          />
        </svg>
      );
  }
}
