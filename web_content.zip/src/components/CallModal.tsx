import React, { useState, useEffect, useRef } from 'react';
import {
  Phone, PhoneOff, Video, VideoOff, Mic, MicOff, Volume2,
  RefreshCw, Shield, Check, X, User as UserIcon
} from 'lucide-react';
import type { User } from '../types/index.ts';
import { wsClient } from '../services/api.ts';
import { soundService } from '../services/soundService.ts';
import { BlueTick } from './BlueTick.tsx';

export interface ActiveCallState {
  callId: string;
  isCaller: boolean;
  isVideo: boolean;
  remoteUser: {
    id: string;
    username: string;
    fullName: string;
    avatarUrl: string;
    verifiedBlueTick?: boolean;
  };
  status: 'calling' | 'incoming' | 'connected' | 'ended';
}

interface CallModalProps {
  callState: ActiveCallState;
  currentUser: User;
  onEndCall: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  callState,
  currentUser,
  onEndCall,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(callState.isVideo);
  const [callDuration, setCallDuration] = useState(0);
  const [connectionStatus, setConnectionStatus] = useState<string>('Connecting secure channel...');
  const [hasMediaPermission, setHasMediaPermission] = useState<boolean | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const timerRef = useRef<any>(null);

  // Initialize WebRTC
  useEffect(() => {
    let isMounted = true;

    async function setupMediaAndPeer() {
      try {
        let stream: MediaStream | null = null;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: callState.isVideo ? { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' } : false,
          });
          localStreamRef.current = stream;
          setHasMediaPermission(true);

          if (localVideoRef.current && callState.isVideo) {
            localVideoRef.current.srcObject = stream;
          }
        } catch (mediaErr) {
          console.warn('Microphone/Camera permission restricted, using simulated WebRTC audio channel:', mediaErr);
          setHasMediaPermission(false);
        }

        // WebRTC PeerConnection with Google Public STUN
        const pc = new RTCPeerConnection({
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
          ],
        });
        peerConnectionRef.current = pc;

        if (stream) {
          stream.getTracks().forEach(track => {
            pc.addTrack(track, stream!);
          });
        }

        pc.ontrack = (event) => {
          if (remoteVideoRef.current && event.streams[0]) {
            remoteVideoRef.current.srcObject = event.streams[0];
          }
        };

        pc.onicecandidate = (event) => {
          if (event.candidate) {
            wsClient.send({
              type: 'call:signal',
              callId: callState.callId,
              targetUserId: callState.remoteUser.id,
              senderId: currentUser.id,
              signal: { candidate: event.candidate },
            });
          }
        };

        // If caller, create SDP offer
        if (callState.isCaller && callState.status === 'connected') {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          wsClient.send({
            type: 'call:signal',
            callId: callState.callId,
            targetUserId: callState.remoteUser.id,
            senderId: currentUser.id,
            signal: { sdp: pc.localDescription },
          });
        }
      } catch (err) {
        console.error('WebRTC initialization error:', err);
      }
    }

    if (callState.status === 'connected') {
      setupMediaAndPeer();
      soundService.stopRingtone();
      soundService.playConnectedSound();
      setConnectionStatus('Secure Voice Encrypted');

      // Start duration counter
      timerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }

    // Listen for WebRTC signals from remote peer
    const unsubSignal = wsClient.on('call:signal', async (data) => {
      if (data.callId === callState.callId && peerConnectionRef.current) {
        const pc = peerConnectionRef.current;
        try {
          if (data.signal?.sdp) {
            await pc.setRemoteDescription(new RTCSessionDescription(data.signal.sdp));
            if (data.signal.sdp.type === 'offer') {
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              wsClient.send({
                type: 'call:signal',
                callId: callState.callId,
                targetUserId: callState.remoteUser.id,
                senderId: currentUser.id,
                signal: { sdp: pc.localDescription },
              });
            }
          } else if (data.signal?.candidate) {
            await pc.addIceCandidate(new RTCIceCandidate(data.signal.candidate));
          }
        } catch (sigErr) {
          console.error('Error handling WebRTC signal:', sigErr);
        }
      }
    });

    return () => {
      isMounted = false;
      clearInterval(timerRef.current);
      unsubSignal();
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(t => t.stop());
      }
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
      }
    };
  }, [callState.status, callState.callId, callState.isCaller]);

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach(t => {
        t.enabled = isMuted;
      });
    }
    setIsMuted(!isMuted);
  };

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach(t => {
        t.enabled = !isVideoEnabled;
      });
    }
    setIsVideoEnabled(!isVideoEnabled);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md h-[550px] max-h-[90vh] rounded-3xl bg-[#090d16] border border-cyan-500/40 shadow-[0_0_50px_rgba(0,210,255,0.25)] flex flex-col justify-between overflow-hidden text-slate-100">
        {/* Background glow and subtle arena styling */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-cyan-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-700/15 rounded-full blur-3xl pointer-events-none" />

        {/* Video Containers (If active Video Call) */}
        {callState.isVideo && callState.status === 'connected' && (
          <div className="absolute inset-0 bg-black z-0">
            {/* Remote Video Stream */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            {/* Local Video Stream Preview */}
            <div className="absolute top-4 right-4 w-28 h-36 rounded-2xl bg-slate-900 border-2 border-cyan-400 overflow-hidden shadow-2xl z-20">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover -scale-x-100"
              />
            </div>
          </div>
        )}

        {/* Top Call Info Header */}
        <div className="relative z-10 p-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-cyan-300">
              {callState.isVideo ? 'Video Arena' : 'Clan Voice Channel'}
            </span>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-slate-300">
              {callState.status === 'connected' ? formatTime(callDuration) : 'Calling...'}
            </span>
          </div>
        </div>

        {/* Center Gamer Identity Card (When in voice mode or calling/ringing) */}
        {(!callState.isVideo || callState.status !== 'connected') && (
          <div className="relative z-10 flex flex-col items-center justify-center text-center px-6 my-auto">
            {/* Pulsing Avatar Halo */}
            <div className="relative mb-6">
              <div className="absolute -inset-4 rounded-full bg-cyan-500/20 blur-xl animate-pulse" />
              <img
                src={callState.remoteUser.avatarUrl}
                alt={callState.remoteUser.fullName}
                className="relative w-32 h-32 rounded-3xl bg-slate-900 border-2 border-cyan-400/80 object-cover shadow-[0_0_25px_rgba(0,210,255,0.4)]"
              />
              {callState.status === 'connected' && (
                <div className="absolute -bottom-2 -right-2 p-1.5 rounded-xl bg-cyan-950 border border-cyan-400 text-cyan-300">
                  <Volume2 size={16} className="animate-pulse" />
                </div>
              )}
            </div>

            <div className="flex items-center justify-center gap-2 font-black text-xl text-white font-display">
              <span>{callState.remoteUser.fullName}</span>
              {callState.remoteUser.verifiedBlueTick && <BlueTick size="md" />}
            </div>
            <div className="text-xs text-cyan-400 font-mono mt-1">
              @{callState.remoteUser.username}
            </div>

            <div className="mt-3 text-xs font-medium text-slate-400">
              {callState.status === 'calling' && 'Calling gamer in arena...'}
              {callState.status === 'incoming' && 'Incoming Call...'}
              {callState.status === 'connected' && connectionStatus}
              {callState.status === 'ended' && 'Call Terminated'}
            </div>

            {/* Audio Waveform Effect during active Voice call */}
            {callState.status === 'connected' && (
              <div className="flex items-center gap-1.5 mt-6 h-8">
                {[40, 75, 55, 90, 60, 85, 45, 95, 70, 50, 80, 40].map((h, i) => (
                  <span
                    key={i}
                    style={{ height: `${h}%` }}
                    className="w-1 bg-gradient-to-t from-cyan-500 to-blue-400 rounded-full animate-pulse"
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Bottom Call Action Buttons */}
        <div className="relative z-10 p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-center gap-5">
          {callState.status === 'connected' && (
            <>
              {/* Mute Mic */}
              <button
                onClick={toggleMute}
                className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
                  isMuted ? 'bg-red-950 text-red-300 border border-red-500/40' : 'bg-slate-800/80 text-white hover:bg-slate-700'
                }`}
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <MicOff size={22} /> : <Mic size={22} />}
              </button>

              {/* Video Camera Toggle */}
              {callState.isVideo && (
                <button
                  onClick={toggleVideo}
                  className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
                    !isVideoEnabled ? 'bg-red-950 text-red-300 border border-red-500/40' : 'bg-slate-800/80 text-white hover:bg-slate-700'
                  }`}
                  title={isVideoEnabled ? 'Stop Video' : 'Start Video'}
                >
                  {isVideoEnabled ? <Video size={22} /> : <VideoOff size={22} />}
                </button>
              )}
            </>
          )}

          {/* End Call / Decline Button */}
          <button
            onClick={onEndCall}
            className="w-16 h-16 rounded-3xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-all cursor-pointer"
            title="End Call"
          >
            <PhoneOff size={28} />
          </button>
        </div>
      </div>
    </div>
  );
};
