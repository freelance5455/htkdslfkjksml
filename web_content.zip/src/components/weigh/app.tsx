import { useEffect, useState } from "react";
import { Menu, Scale, X } from "lucide-react";
import { Toaster } from "sonner";
import { MODES } from "@/lib/weigh/defaults";
import { useWeigh } from "@/lib/weigh/store";
import type { Mode, TabId } from "@/lib/weigh/types";
import { ArchiveView } from "@/components/weigh/archive";
import { DealView } from "@/components/weigh/deal";
import { GoodsView } from "@/components/weigh/goods";
import { ReportsView } from "@/components/weigh/reports";
import { SlipModal, type SaleSlip, type WorkerSlip } from "@/components/weigh/slip";
import { StockView } from "@/components/weigh/stock";
import { WorkersView } from "@/components/weigh/workers";

const TABS: { id: TabId; label: string }[] = [
  { id: "visitor", label: "الزائر" },
  { id: "dealer", label: "المتعامل" },
  { id: "special", label: "خاص" },
  { id: "sales", label: "المبيعات" },
  { id: "archive", label: "السجل" },
  { id: "stock", label: "المخزن" },
  { id: "goods", label: "السلع" },
  { id: "workers", label: "العمال" },
  { id: "reports", label: "النسخ والتقارير" },
];

function isMode(tab: TabId): tab is Mode {
  return (MODES as readonly string[]).includes(tab);
}

/** Pull a one-time copy from the old single-file version if this device still has it. */
function adoptLegacy() {
  const state = useWeigh.getState();
  if (state.history.length || state.workers.length || state.pays.length || state.updatedAt > 0) return;
  try {
    const read = (key: string) => {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : undefined;
    };
    const payload = {
      commodities: read("dz_commodities"),
      history: read("dz_history"),
      workerPays: read("dz_worker_pays"),
      workerRoster: read("dz_worker_roster"),
    };
    if (!payload.commodities && !payload.history && !payload.workerPays && !payload.workerRoster) return;
    useWeigh.getState().importPayload(payload);
  } catch {
    /* ignore a broken legacy copy */
  }
}

export function WeighApp() {
  const [tab, setTab] = useState<TabId>("visitor");
  const [menu, setMenu] = useState(false);
  const [ready, setReady] = useState(false);
  const [slip, setSlip] = useState<SaleSlip | WorkerSlip | null>(null);
  const updatedAt = useWeigh((s) => s.updatedAt);
  const count = useWeigh((s) => s.history.length);
  const active = TABS.find((t) => t.id === tab) ?? TABS[0];

  useEffect(() => {
    let alive = true;
    const unsub = useWeigh.persist.onFinishHydration(() => {
      if (!alive) return;
      adoptLegacy();
      useWeigh.getState().setHydrated();
      setReady(true);
    });
    void useWeigh.persist.rehydrate();
    return () => {
      alive = false;
      unsub();
    };
  }, []);

  function go(id: TabId) {
    setTab(id);
    setMenu(false);
  }

  const savedLabel = updatedAt
    ? `محفوظ · ${count} عملية`
    : "الحفظ تلقائي على هذا الجهاز";

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-line bg-bg/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-3 py-2">
          <div className="flex min-w-0 items-center gap-2">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-fg">
              <Scale className="size-5" />
            </span>
            <div className="min-w-0">
              <div className="truncate text-sm font-bold text-primary">نظام الوزن والبيع</div>
              <div className="truncate text-xs text-muted">{ready ? savedLabel : "جاري فتح السجل…"}</div>
            </div>
          </div>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full bg-surface-2 text-fg"
            aria-expanded={menu}
            aria-label={menu ? "إغلاق القائمة" : "القائمة"}
            onClick={() => setMenu((v) => !v)}
          >
            {menu ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {menu ? (
          <nav className="mx-auto flex max-w-3xl flex-wrap gap-2 px-3 pb-3" aria-label="أقسام التطبيق">
            {TABS.map((item) => {
              const on = item.id === tab;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(item.id)}
                  className={
                    on
                      ? "h-11 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg"
                      : "h-11 rounded-full bg-surface-2 px-4 text-sm font-semibold text-fg"
                  }
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        ) : (
          <div className="mx-auto max-w-3xl px-3 pb-2 text-xs text-muted">{active.label}</div>
        )}
      </header>

      <main className="mx-auto max-w-3xl px-3 py-4">
        {!ready ? (
          <p className="py-16 text-center text-sm text-muted">جاري فتح السجل المحفوظ…</p>
        ) : isMode(tab) ? (
          <DealView key={tab} mode={tab} onPrint={setSlip} />
        ) : tab === "archive" ? (
          <ArchiveView onPrint={setSlip} />
        ) : tab === "stock" ? (
          <StockView />
        ) : tab === "goods" ? (
          <GoodsView />
        ) : tab === "workers" ? (
          <WorkersView onPrint={setSlip} />
        ) : (
          <ReportsView />
        )}
      </main>

      {slip ? <SlipModal slip={slip} onClose={() => setSlip(null)} /> : null}
      <Toaster position="top-center" theme="dark" dir="rtl" />
    </div>
  );
}
