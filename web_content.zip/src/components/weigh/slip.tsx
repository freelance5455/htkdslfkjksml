import { Printer, X } from "lucide-react";
import type { ReactNode } from "react";
import { MODE_META } from "@/lib/weigh/defaults";
import { money, qtyLabel } from "@/lib/weigh/logic";
import type { Mode, SavedItem, WorkerPay } from "@/lib/weigh/types";
import { btnClass } from "@/components/weigh/ui";

export type SaleSlip = {
  kind: "sale";
  bonNum: number;
  name: string;
  datetime: string;
  isCredit: boolean;
  mode: Mode;
  items: SavedItem[];
  grand: number;
  shop: string;
};

export type WorkerSlip = {
  kind: "worker";
  pay: WorkerPay;
  shop: string;
};

function SheetFrame({
  children,
  onClose,
}: {
  children: ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 overflow-auto bg-bg/80 p-4">
      <div className="mx-auto max-w-3xl">
        <div className="mb-3 flex gap-2">
          <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => window.print()}>
            <Printer className="size-4" />
            طباعة
          </button>
          <button type="button" className={`${btnClass} bg-surface-2 text-fg`} onClick={onClose}>
            <X className="size-4" />
            إغلاق
          </button>
        </div>
        <article id="print-sheet" className="rounded-xl bg-paper p-5 text-ink">
          {children}
        </article>
      </div>
    </div>
  );
}

export function SlipModal({ slip, onClose }: { slip: SaleSlip | WorkerSlip; onClose: () => void }) {
  if (slip.kind === "worker") return <WorkerSheet slip={slip} onClose={onClose} />;
  const pay = slip.isCredit ? "بالدين" : "نقدي";
  const num = String(slip.bonNum).slice(-6);
  return (
    <SheetFrame onClose={onClose}>
      <p className="text-center text-sm font-semibold">{slip.shop || "نظام الوزن والبيع"}</p>
      <h1 className="my-3 text-center text-xl font-bold">سند تسليم رقم {num}</h1>
      <table className="w-full border-collapse text-sm">
        <tbody>
          <tr>
            <td className="border border-ink/30 p-2">
              <strong>مسلم إلى</strong>
              <div>{slip.name}</div>
            </td>
            <td className="border border-ink/30 p-2">
              <strong>التاريخ</strong>
              <div>{slip.datetime}</div>
            </td>
            <td className="border border-ink/30 p-2">
              <strong>النوع</strong>
              <div>
                {MODE_META[slip.mode].label} · {pay}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table className="mt-3 w-full border-collapse text-sm">
        <thead>
          <tr>
            <th className="border border-ink/30 p-2 text-start">التعيين</th>
            <th className="border border-ink/30 p-2">الكمية</th>
            <th className="border border-ink/30 p-2">السعر</th>
            <th className="border border-ink/30 p-2">المجموع</th>
          </tr>
        </thead>
        <tbody>
          {slip.items.map((it, i) => (
            <tr key={`${it.id}-${i}`}>
              <td className="border border-ink/30 p-2 text-start">
                {it.emoji} {it.name}
              </td>
              <td className="border border-ink/30 p-2 text-center">{qtyLabel(it)}</td>
              <td className="border border-ink/30 p-2 text-center">{money(it.pricePerKg)}</td>
              <td className="border border-ink/30 p-2 text-center">{money(it.total)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-4 text-lg font-bold">
        المجموع الكلي: {money(slip.grand)} دج · {pay}
      </p>
      <div className="mt-10 flex justify-between text-sm">
        <div className="w-2/5 border-t border-ink pt-2 text-center">إمضاء المستلم</div>
        <div className="w-2/5 border-t border-ink pt-2 text-center">إمضاء المسؤول</div>
      </div>
    </SheetFrame>
  );
}

function WorkerSheet({ slip, onClose }: { slip: WorkerSlip; onClose: () => void }) {
  const x = slip.pay;
  return (
    <SheetFrame onClose={onClose}>
      <p className="text-center text-sm font-semibold">{slip.shop || "نظام الوزن والبيع"}</p>
      <h1 className="my-3 text-center text-xl font-bold">وصل تسليم — محاسبة عامل</h1>
      <table className="w-full border-collapse text-sm">
        <tbody>
          {(
            [
              ["اسم العامل", x.name],
              ["من", x.start || "—"],
              ["إلى", x.end || "—"],
              ["أيام العمل", String(x.days)],
              ["الغياب", String(x.absent)],
              ["أنصاف الأيام", String(x.half)],
              ["الأيام الفعلية", x.effective.toFixed(2)],
              ["أجر اليوم", `${money(x.wage)} دج`],
              ["قبل الخصم", `${money(x.gross)} دج`],
              ["المصروف", `${money(x.expense)} دج`],
              ["المحمول", `${money(x.mobile)} دج`],
              ["الصافي", `${money(x.net)} دج`],
              ["الدفع", x.paid ? `تم الدفع${x.paidAt ? ` — ${x.paidAt}` : ""}` : "غير مدفوع"],
            ] as const
          ).map(([k, v]) => (
            <tr key={k}>
              <td className="border border-ink/30 p-2 font-semibold">{k}</td>
              <td className="border border-ink/30 p-2">{v}</td>
            </tr>
          ))}
          {x.expenses.map((e, i) => (
            <tr key={`${e.date}-${i}`}>
              <td className="border border-ink/30 p-2 ps-6">
                {e.date} {e.note ? `· ${e.note}` : ""}
              </td>
              <td className="border border-ink/30 p-2">{money(e.amount)} دج</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-10 flex justify-between text-sm">
        <div className="w-2/5 border-t border-ink pt-2 text-center">إمضاء العامل</div>
        <div className="w-2/5 border-t border-ink pt-2 text-center">إمضاء المسؤول</div>
      </div>
    </SheetFrame>
  );
}
