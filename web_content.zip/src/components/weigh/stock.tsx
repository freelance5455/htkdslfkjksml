import { useMemo, useState, type ReactNode } from "react";
import { calcStock, money, weekRange, ymd, type StockRow } from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import type { Mode, Period, StockView } from "@/lib/weigh/types";
import { Card, Field, inputClass } from "@/components/weigh/ui";

const VIEW_LABEL: Record<StockView, string> = { buy: "المشتريات", sale: "المبيعات", net: "صافي المخزون" };

export function StockView() {
  const history = useWeigh((s) => s.history);
  const today = ymd();
  const [view, setView] = useState<StockView>("buy");
  const [period, setPeriod] = useState<Period>("today");
  const [day, setDay] = useState(today);
  const [month, setMonth] = useState(today.slice(0, 7));

  const title = useMemo(() => {
    const ym = month || day.slice(0, 7);
    const dom = Number((day || today).slice(8, 10)) || 1;
    const wk = weekRange(ym, dom);
    const periodLabel =
      period === "today"
        ? `يومي — ${day || today}`
        : period === "week"
          ? `أسبوعي ${ym} من ${wk.start} إلى ${wk.end}`
          : period === "month"
            ? `شهري — ${ym}`
            : "الإجمالي";
    return `${periodLabel} · ${VIEW_LABEL[view]}`;
  }, [view, period, day, month, today]);

  const buyModes: Mode[] = ["visitor", "dealer", "special"];

  let body: ReactNode;
  if (view === "net") {
    const buys = calcStock(history, period, buyModes, day, month);
    const sales = calcStock(history, period, ["sales"], day, month);
    const names = new Set([...buys.map((b) => b.name), ...sales.map((s) => s.name)]);
    const list = [...names]
      .map((name) => {
        const b = buys.find((x) => x.name === name);
        const s = sales.find((x) => x.name === name);
        return {
          name,
          emoji: b?.emoji || s?.emoji || "",
          buy: b?.weight || 0,
          sale: s?.weight || 0,
          net: (b?.weight || 0) - (s?.weight || 0),
        };
      })
      .sort((a, b) => b.net - a.net);
    body = list.length ? (
      <div className="space-y-2">
        {list.map((n) => (
          <div key={n.name} className="rounded-xl border border-line bg-bg/40 p-3">
            <div className="flex items-center justify-between gap-2">
              <strong>
                {n.emoji} {n.name}
              </strong>
              <strong className={n.net >= 0 ? "text-primary" : "text-danger"}>صافي {n.net.toFixed(2)} كغ</strong>
            </div>
            <p className="mt-1 text-sm text-muted">
              شراء {n.buy.toFixed(2)} كغ · بيع {n.sale.toFixed(2)} كغ
            </p>
          </div>
        ))}
      </div>
    ) : (
      <Empty count={history.length} />
    );
  } else {
    const modes: Mode[] = view === "sale" ? ["sales"] : buyModes;
    const stock = calcStock(history, period, modes, day, month);
    const sumW = stock.reduce((a, s) => a + s.weight, 0);
    const sumC = stock.reduce((a, s) => a + s.cost, 0);
    body = stock.length ? (
      <div>
        <div className="mb-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 font-bold">
          <span>الإجمالي</span>
          <span>
            {sumW.toFixed(2)} كغ · {money(sumC)} دج
          </span>
        </div>
        <div className="space-y-2">
          {stock.map((s) => (
            <StockCard key={s.name} row={s} />
          ))}
        </div>
      </div>
    ) : (
      <Empty count={history.length} />
    );
  }

  return (
    <Card title="المخزن">
      <div className="mb-3 grid gap-3 sm:grid-cols-2">
        <Field label="العرض">
          <select className={inputClass} value={view} onChange={(e) => setView(e.target.value as StockView)}>
            <option value="buy">المشتريات</option>
            <option value="sale">المبيعات</option>
            <option value="net">صافي المخزون</option>
          </select>
        </Field>
        <Field label="الفترة">
          <select className={inputClass} value={period} onChange={(e) => setPeriod(e.target.value as Period)}>
            <option value="today">اليوم</option>
            <option value="week">أسبوعي</option>
            <option value="month">شهري</option>
            <option value="all">الإجمالي</option>
          </select>
        </Field>
        <Field label="اليوم">
          <input
            type="date"
            className={inputClass}
            value={day}
            onChange={(e) => {
              setDay(e.target.value);
              if (e.target.value) setMonth(e.target.value.slice(0, 7));
            }}
          />
        </Field>
        <Field label="الشهر">
          <input type="month" className={inputClass} value={month} onChange={(e) => setMonth(e.target.value)} />
        </Field>
      </div>
      <p className="mb-2 text-xs text-muted">الأسبوعي يقسّم الشهر كل 7 أيام: 1–7 ثم 8–14 ثم 15–21.</p>
      <p className="mb-3 font-bold text-primary">{title}</p>
      {body}
    </Card>
  );
}

function StockCard({ row }: { row: StockRow }) {
  return (
    <div className="rounded-xl border border-line bg-bg/40 p-3">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <strong className="text-primary">
          {row.emoji} {row.name}
        </strong>
        <span>
          {row.weight.toFixed(2)} كغ · {money(row.cost)} دج
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-muted">
              <th className="p-1 text-start font-medium">السعر</th>
              <th className="p-1 text-start font-medium">الكمية</th>
              <th className="p-1 text-start font-medium">المبلغ</th>
            </tr>
          </thead>
          <tbody>
            {row.byPrice.map((p) => (
              <tr key={p.price} className="border-t border-line">
                <td className="p-1">{money(p.price, 0)}</td>
                <td className="p-1">
                  {p.weight.toFixed(2)} كغ{p.qty ? ` / ${p.qty} ق` : ""}
                </td>
                <td className="p-1">{money(p.cost)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Empty({ count }: { count: number }) {
  return (
    <p className="py-6 text-center text-sm text-muted">
      لا بيانات لهذه الفترة.
      <br />
      العمليات المحفوظة: {count}. جرّب «الإجمالي».
    </p>
  );
}
