import { useRef, useState } from "react";
import { toast } from "sonner";
import { buildReportHtml, buildReportText, downloadText, periodBounds, ymd } from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import { btnClass, Card, Field, inputClass } from "@/components/weigh/ui";

type Kind = "day" | "week" | "month" | "all";

export function ReportsView() {
  const history = useWeigh((s) => s.history);
  const pays = useWeigh((s) => s.pays);
  const report = useWeigh((s) => s.report);
  const setReport = useWeigh((s) => s.setReport);
  const exportPayload = useWeigh((s) => s.exportPayload);
  const importPayload = useWeigh((s) => s.importPayload);
  const updatedAt = useWeigh((s) => s.updatedAt);
  const fileRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState("");

  async function send(kind: Kind) {
    const html = buildReportHtml(history, kind, report.shop, pays);
    const text = buildReportText(history, kind);
    const label = periodBounds(kind).label;
    downloadText(`تقرير-${kind}-${ymd()}.html`, html);
    const to = report.email.trim();
    if (report.ejPublic && report.ejService && report.ejTemplate && to) {
      try {
        const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            service_id: report.ejService,
            template_id: report.ejTemplate,
            user_id: report.ejPublic,
            template_params: {
              to_email: to,
              cc_email: report.email2,
              subject: `تقرير ${label}`,
              message: text,
              html_message: html,
            },
          }),
        });
        if (!res.ok) throw new Error(await res.text());
        setStatus(`أُرسل التقرير إلى ${to} ونُزّل الملف`);
        toast.success("تم إرسال التقرير");
        return;
      } catch (e) {
        const msg = e instanceof Error ? e.message : "فشل الإرسال";
        setStatus(`تعذر البريد (${msg}). نُزّل الملف.`);
      }
    }
    if (to) {
      const subject = encodeURIComponent(`تقرير ${label}`);
      const body = encodeURIComponent(`${text}\n\nأرفق ملف HTML الذي نُزّل على الجهاز.`);
      const cc = report.email2 ? `&cc=${encodeURIComponent(report.email2)}` : "";
      window.location.href = `mailto:${encodeURIComponent(to)}?subject=${subject}&body=${body}${cc}`;
      setStatus("نُزّل الملف وفُتح البريد إن كان متاحاً");
    } else {
      setStatus("نُزّل ملف التقرير على الجهاز");
      toast.success("نُزّل التقرير");
    }
  }

  return (
    <div>
      <Card title="الحفظ على هذا الجهاز">
        <p className="text-sm text-muted">
          كل معاملة وسلعة وعامل تُحفظ تلقائياً هنا وتبقى بعد إغلاق الصفحة.
          {updatedAt ? ` آخر حفظ: ${new Date(updatedAt).toLocaleString("ar-DZ-u-nu-latn")}.` : ""}
        </p>
        <p className="mt-2 text-sm text-muted">للانتقال إلى هاتف آخر أو أخذ نسخة، صدّر الملف ثم استورده هناك.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            className={`${btnClass} bg-primary text-primary-fg`}
            onClick={() => {
              downloadText(`نسخة-احتياطية-${ymd()}.json`, exportPayload(), "application/json");
              toast.success("تم تنزيل النسخة الاحتياطية");
            }}
          >
            تصدير نسخة احتياطية
          </button>
          <button type="button" className={`${btnClass} bg-surface-2 text-fg`} onClick={() => fileRef.current?.click()}>
            استيراد نسخة
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(ev) => {
              const file = ev.target.files?.[0];
              ev.target.value = "";
              if (!file) return;
              const reader = new FileReader();
              reader.onload = () => {
                try {
                  const data = JSON.parse(String(reader.result));
                  if (!window.confirm("استيراد النسخة واستبدال البيانات الحالية على هذا الجهاز؟")) return;
                  const res = importPayload(data);
                  if (!res.ok) {
                    toast.error(res.error);
                    return;
                  }
                  toast.success(`تم الاستيراد · ${res.count} عملية`);
                } catch {
                  toast.error("الملف غير صالح");
                }
              };
              reader.readAsText(file);
            }}
          />
        </div>
      </Card>

      <Card title="التقارير">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="اسم المحل (يظهر في السند)">
            <input className={inputClass} value={report.shop} placeholder="اسم المحل" onChange={(e) => setReport({ shop: e.target.value })} />
          </Field>
          <Field label="بريد الاستلام">
            <input type="email" className={inputClass} value={report.email} placeholder="name@example.com" onChange={(e) => setReport({ email: e.target.value })} />
          </Field>
          <Field label="بريد إضافي" className="sm:col-span-2">
            <input type="email" className={inputClass} value={report.email2} placeholder="اختياري" onChange={(e) => setReport({ email2: e.target.value })} />
          </Field>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button type="button" className={`${btnClass} bg-accent text-accent-fg`} onClick={() => void send("day")}>
            تقرير يومي
          </button>
          <button type="button" className={`${btnClass} bg-accent text-accent-fg`} onClick={() => void send("week")}>
            تقرير أسبوعي
          </button>
          <button type="button" className={`${btnClass} bg-accent text-accent-fg`} onClick={() => void send("month")}>
            تقرير شهري
          </button>
          <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => void send("all")}>
            تقرير شامل
          </button>
        </div>
        <p className="mt-2 text-xs text-muted">يُنزَّل ملف التقرير دائماً. إن ضبطت بريداً يُفتح تطبيق البريد مع الملخص.</p>
        {status ? <p className="mt-2 text-sm text-primary">{status}</p> : null}
      </Card>

      <Card title="إرسال مباشر (EmailJS)">
        <p className="mb-3 text-xs text-muted">اختياري. من emailjs.com انسخ المفاتيح إن أردت الإرسال دون فتح تطبيق البريد.</p>
        <div className="grid gap-3">
          <Field label="Public Key">
            <input className={inputClass} value={report.ejPublic} onChange={(e) => setReport({ ejPublic: e.target.value })} />
          </Field>
          <Field label="Service ID">
            <input className={inputClass} value={report.ejService} onChange={(e) => setReport({ ejService: e.target.value })} />
          </Field>
          <Field label="Template ID">
            <input className={inputClass} value={report.ejTemplate} onChange={(e) => setReport({ ejTemplate: e.target.value })} />
          </Field>
        </div>
      </Card>
    </div>
  );
}
