import { useState } from "react";
import { toast } from "sonner";
import { money, num } from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import { btnClass, Card, Field, inputClass } from "@/components/weigh/ui";

export function GoodsView() {
  const commodities = useWeigh((s) => s.commodities);
  const saveCommodity = useWeigh((s) => s.saveCommodity);
  const toggleByCount = useWeigh((s) => s.toggleByCount);
  const deleteCommodity = useWeigh((s) => s.deleteCommodity);
  const [editId, setEditId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState("");
  const [pv, setPv] = useState("");
  const [pd, setPd] = useState("");
  const [ps, setPs] = useState("");
  const [byCount, setByCount] = useState(false);

  function reset() {
    setEditId(null);
    setName("");
    setEmoji("");
    setPv("");
    setPd("");
    setPs("");
    setByCount(false);
  }

  function onSave() {
    if (!name.trim()) {
      toast.error("أدخل الاسم");
      return;
    }
    saveCommodity(
      {
        name: name.trim(),
        emoji: emoji.trim() || "📦",
        priceVisitor: num(pv),
        priceDealer: num(pd),
        priceSale: num(ps),
        byCount,
      },
      editId ?? undefined,
    );
    toast.success(editId ? "تم تعديل السلعة" : "تم حفظ السلعة");
    reset();
  }

  return (
    <div>
      <Card title="إدارة السلع">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="الاسم">
            <input className={inputClass} value={name} placeholder="اسم السلعة" onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="رمز">
            <input className={inputClass} value={emoji} placeholder="رمز قصير" onChange={(e) => setEmoji(e.target.value)} />
          </Field>
          <Field label="سعر زائر">
            <input inputMode="decimal" className={inputClass} value={pv} placeholder="0" onChange={(e) => setPv(e.target.value)} />
          </Field>
          <Field label="سعر متعامل">
            <input inputMode="decimal" className={inputClass} value={pd} placeholder="0" onChange={(e) => setPd(e.target.value)} />
          </Field>
          <Field label="سعر بيع">
            <input inputMode="decimal" className={inputClass} value={ps} placeholder="0" onChange={(e) => setPs(e.target.value)} />
          </Field>
          <Field label="طريقة التسعير">
            <select className={inputClass} value={byCount ? "1" : "0"} onChange={(e) => setByCount(e.target.value === "1")}>
              <option value="0">بالوزن (كغ)</option>
              <option value="1">بالقطعة (عدد)</option>
            </select>
          </Field>
        </div>
        <p className="mt-2 text-xs text-muted">بالقطعة: الثمن من العدد، والوزن يبقى لإنقاصه من قوس الميزان.</p>
        <div className="mt-3 flex gap-2">
          <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={onSave}>
            {editId ? "حفظ التعديل" : "حفظ السلعة"}
          </button>
          {editId ? (
            <button type="button" className={`${btnClass} bg-surface-2 text-fg`} onClick={reset}>
              إلغاء
            </button>
          ) : null}
        </div>
      </Card>
      <div className="space-y-2">
        {commodities.map((c) => (
          <article key={c.id} className="rounded-2xl border border-line bg-surface p-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-bold">
                  {c.emoji} {c.name}
                </div>
                <p className="mt-1 text-sm text-muted">
                  زائر {money(c.priceVisitor, 0)} · متعامل {money(c.priceDealer, 0)} · بيع {money(c.priceSale, 0)}
                </p>
              </div>
              <button
                type="button"
                className={`${btnClass} ${c.byCount ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg"}`}
                onClick={() => toggleByCount(c.id)}
              >
                {c.byCount ? "بالقطعة" : "بالوزن"}
              </button>
            </div>
            <div className="mt-2 flex gap-2">
              <button
                type="button"
                className={`${btnClass} bg-surface-2 text-fg`}
                onClick={() => {
                  setEditId(c.id);
                  setName(c.name);
                  setEmoji(c.emoji);
                  setPv(String(c.priceVisitor));
                  setPd(String(c.priceDealer));
                  setPs(String(c.priceSale));
                  setByCount(c.byCount);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              >
                تعديل
              </button>
              <button
                type="button"
                className={`${btnClass} bg-danger text-danger-fg`}
                onClick={() => {
                  if (!window.confirm("حذف السلعة؟")) return;
                  deleteCommodity(c.id);
                  if (editId === c.id) reset();
                }}
              >
                حذف
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
