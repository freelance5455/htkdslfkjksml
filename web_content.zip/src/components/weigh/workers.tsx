import { useMemo, useState } from "react";
import { toast } from "sonner";
import { formatNow, money, num, uid, workerMath, ymd } from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import type { Expense, WorkerPay } from "@/lib/weigh/types";
import type { WorkerSlip } from "@/components/weigh/slip";
import { btnClass, Card, Field, inputClass } from "@/components/weigh/ui";

export function WorkersView({ onPrint }: { onPrint: (slip: WorkerSlip) => void }) {
  const workers = useWeigh((s) => s.workers);
  const pays = useWeigh((s) => s.pays);
  const shop = useWeigh((s) => s.report.shop);
  const addWorker = useWeigh((s) => s.addWorker);
  const deleteWorker = useWeigh((s) => s.deleteWorker);
  const savePay = useWeigh((s) => s.savePay);
  const markPaid = useWeigh((s) => s.markPaid);
  const deletePay = useWeigh((s) => s.deletePay);

  const today = ymd();
  const [rName, setRName] = useState("");
  const [rWage, setRWage] = useState("");
  const [rStart, setRStart] = useState(today);

  const [editId, setEditId] = useState<number | null>(null);
  const [pick, setPick] = useState("");
  const [name, setName] = useState("");
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(today);
  const [daysRaw, setDaysRaw] = useState("");
  const [absent, setAbsent] = useState("");
  const [half, setHalf] = useState("");
  const [wage, setWage] = useState("");
  const [mobile, setMobile] = useState("");
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [expDate, setExpDate] = useState(today);
  const [expAmount, setExpAmount] = useState("");
  const [expNote, setExpNote] = useState("");
  const [q, setQ] = useState("");
  const [paidFilter, setPaidFilter] = useState<"all" | "0" | "1">("all");

  const math = useMemo(
    () =>
      workerMath({
        start,
        end,
        daysRaw,
        absent: num(absent),
        half: num(half),
        wage: num(wage),
        mobile: num(mobile),
        expenses,
      }),
    [start, end, daysRaw, absent, half, wage, mobile, expenses],
  );

  const ledger = pays.filter((p) => {
    if (q && !p.name.toLowerCase().includes(q.trim().toLowerCase())) return false;
    if (paidFilter === "1" && !p.paid) return false;
    if (paidFilter === "0" && p.paid) return false;
    return true;
  });

  function clearForm() {
    setEditId(null);
    setPick("");
    setName("");
    setStart(today);
    setEnd(today);
    setDaysRaw("");
    setAbsent("");
    setHalf("");
    setWage("");
    setMobile("");
    setExpenses([]);
    setExpAmount("");
    setExpNote("");
    setExpDate(today);
  }

  function loadWorker(id: string) {
    setPick(id);
    const w = workers.find((x) => String(x.id) === id);
    if (!w) return;
    setName(w.name);
    if (w.start) setStart(w.start);
    if (w.wage) setWage(String(w.wage));
  }

  function buildPay(): WorkerPay | null {
    if (!name.trim()) {
      toast.error("أدخل اسم العامل أو اختره من القائمة");
      return null;
    }
    if (num(wage) <= 0) {
      toast.error("أدخل أجر اليوم");
      return null;
    }
    const prev = editId ? pays.find((p) => p.id === editId) : undefined;
    return {
      id: editId ?? uid(),
      name: name.trim(),
      start,
      end,
      days: math.days,
      absent: num(absent),
      half: num(half),
      wage: num(wage),
      expense: math.expense,
      expenses: expenses.map((e) => ({ ...e })),
      mobile: num(mobile),
      effective: math.effective,
      gross: math.gross,
      net: math.net,
      paid: prev?.paid ?? false,
      paidAt: prev?.paidAt,
      datetime: prev?.datetime || formatNow(),
      dateKey: prev?.dateKey || today,
    };
  }

  return (
    <div>
      <Card title="قائمة العمال">
        <p className="mb-3 text-sm text-muted">أضف العمال مرة واحدة، ثم احسب لكل واحد. القائمة تُحفظ تلقائياً.</p>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="اسم العامل">
            <input className={inputClass} value={rName} placeholder="الاسم" onChange={(e) => setRName(e.target.value)} />
          </Field>
          <Field label="أجر اليوم الافتراضي">
            <input inputMode="decimal" className={inputClass} value={rWage} placeholder="0" onChange={(e) => setRWage(e.target.value)} />
          </Field>
          <Field label="تاريخ بدء العمل">
            <input type="date" className={inputClass} value={rStart} onChange={(e) => setRStart(e.target.value)} />
          </Field>
        </div>
        <button
          type="button"
          className={`${btnClass} mt-3 bg-primary text-primary-fg`}
          onClick={() => {
            const res = addWorker({ name: rName, wage: num(rWage), start: rStart || today });
            if (!res.ok) {
              toast.error(res.error);
              return;
            }
            setRName("");
            setRWage("");
            toast.success("أُضيف العامل");
          }}
        >
          إضافة عامل
        </button>
        <div className="mt-3 space-y-2">
          {workers.length === 0 ? <p className="text-sm text-muted">لا عمال بعد</p> : null}
          {workers.map((w) => (
            <div key={w.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line px-3 py-2">
              <div>
                <div className="font-semibold">{w.name}</div>
                <div className="text-xs text-muted">
                  {money(w.wage, 0)} دج/يوم · من {w.start || "—"}
                </div>
              </div>
              <div className="flex gap-2">
                <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => loadWorker(String(w.id))}>
                  محاسبة
                </button>
                <button
                  type="button"
                  aria-label={`حذف ${w.name}`}
                  className={`${btnClass} bg-danger text-danger-fg`}
                  onClick={() => {
                    if (!window.confirm("حذف العامل من القائمة؟ السجلات السابقة تبقى.")) return;
                    deleteWorker(w.id);
                  }}
                >
                  ×
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="محاسبة عامل">
        <p className="mb-3 text-sm text-muted">أيام العمل − الغياب + أنصاف الأيام × أجر اليوم − المصروف − المحمول = الصافي</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="اختر العامل">
            <select className={inputClass} value={pick} onChange={(e) => loadWorker(e.target.value)}>
              <option value="">— اختر عاملاً —</option>
              {workers.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="اسم العامل">
            <input id="worker-name" className={inputClass} value={name} placeholder="الاسم" onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="تاريخ البدء">
            <input type="date" className={inputClass} value={start} onChange={(e) => setStart(e.target.value)} />
          </Field>
          <Field label="يوم المحاسبة">
            <input type="date" className={inputClass} value={end} onChange={(e) => setEnd(e.target.value)} />
          </Field>
          <Field label="أيام العمل (فارغ = تلقائي)">
            <input inputMode="decimal" className={inputClass} value={daysRaw} placeholder={String(math.autoDays || 0)} onChange={(e) => setDaysRaw(e.target.value)} />
          </Field>
          <Field label="أيام الغياب">
            <input inputMode="decimal" className={inputClass} value={absent} placeholder="0" onChange={(e) => setAbsent(e.target.value)} />
          </Field>
          <Field label="أنصاف يوم">
            <input inputMode="decimal" className={inputClass} value={half} placeholder="0" onChange={(e) => setHalf(e.target.value)} />
          </Field>
          <Field label="أجر اليوم (دج)">
            <input inputMode="decimal" className={inputClass} value={wage} placeholder="0" onChange={(e) => setWage(e.target.value)} />
          </Field>
          <Field label="المحمول (دج)">
            <input inputMode="decimal" className={inputClass} value={mobile} placeholder="0" onChange={(e) => setMobile(e.target.value)} />
          </Field>
        </div>
        <div className="mt-3 rounded-xl border border-line bg-bg/40 p-3">
          <strong className="text-accent">المصروف</strong>
          <div className="mt-2 grid gap-2 sm:grid-cols-3">
            <Field label="التاريخ">
              <input type="date" className={inputClass} value={expDate} onChange={(e) => setExpDate(e.target.value)} />
            </Field>
            <Field label="المبلغ">
              <input inputMode="decimal" className={inputClass} value={expAmount} placeholder="0" onChange={(e) => setExpAmount(e.target.value)} />
            </Field>
            <Field label="ملاحظة">
              <input className={inputClass} value={expNote} placeholder="اختياري" onChange={(e) => setExpNote(e.target.value)} />
            </Field>
          </div>
          <button
            type="button"
            className={`${btnClass} mt-2 bg-accent text-accent-fg`}
            onClick={() => {
              if (num(expAmount) <= 0) {
                toast.error("أدخل مبلغ المصروف");
                return;
              }
              setExpenses((list) => [...list, { id: uid(), date: expDate || today, amount: num(expAmount), note: expNote.trim() }]);
              setExpAmount("");
              setExpNote("");
            }}
          >
            إضافة مصروف
          </button>
          <ul className="mt-2 space-y-1 text-sm">
            {expenses.length === 0 ? <li className="text-muted">لا مصاريف</li> : null}
            {expenses.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-2">
                <span>
                  {e.date} — {money(e.amount)} دج {e.note ? `· ${e.note}` : ""}
                </span>
                <button type="button" className="text-danger" onClick={() => setExpenses((list) => list.filter((x) => x.id !== e.id))}>
                  ×
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-2 font-bold">مجموع المصروف: {money(math.expense)} دج</p>
        </div>
        <div className="mt-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 font-bold">
          <span>أيام فعلية {math.effective.toFixed(2)}</span>
          <span className={math.net < 0 ? "text-danger" : "text-accent"}>{money(math.net)} دج</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            className={`${btnClass} bg-primary text-primary-fg`}
            onClick={() => {
              const pay = buildPay();
              if (!pay) return;
              savePay(pay);
              toast.success(`تم حفظ محاسبة ${pay.name}`);
              clearForm();
            }}
          >
            حفظ في السجل
          </button>
          <button
            type="button"
            className={`${btnClass} bg-accent text-accent-fg`}
            onClick={() => {
              const pay = buildPay();
              if (!pay) return;
              savePay(pay);
              onPrint({ kind: "worker", pay, shop });
              clearForm();
            }}
          >
            حفظ + وصل
          </button>
          <button type="button" className={`${btnClass} bg-surface-2 text-fg`} onClick={clearForm}>
            مسح النموذج
          </button>
        </div>
      </Card>

      <Card title="سجل محاسبة العمال">
        <div className="mb-3 grid gap-3 sm:grid-cols-2">
          <Field label="بحث بالاسم">
            <input className={inputClass} value={q} placeholder="اسم العامل" onChange={(e) => setQ(e.target.value)} />
          </Field>
          <Field label="الحالة">
            <select className={inputClass} value={paidFilter} onChange={(e) => setPaidFilter(e.target.value as "all" | "0" | "1")}>
              <option value="all">الكل</option>
              <option value="0">غير مدفوع</option>
              <option value="1">تم الدفع</option>
            </select>
          </Field>
        </div>
        {ledger.length === 0 ? <p className="py-4 text-center text-sm text-muted">لا سجلات بعد</p> : null}
        <div className="space-y-2">
          {ledger.map((x) => (
            <article key={x.id} className="rounded-xl border border-line p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <strong className="text-primary">{x.name}</strong>
                <span className={x.paid ? "text-xs text-primary" : "text-xs text-accent"}>{x.paid ? "تم الدفع" : "غير مدفوع"}</span>
              </div>
              <p className="mt-1 text-sm text-muted">
                من {x.start || "—"} إلى {x.end || "—"} · أيام {x.days} · غياب {x.absent} · نصف {x.half}
                <br />
                صافي <strong className="text-accent">{money(x.net)} دج</strong>
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => markPaid(x.id, !x.paid)}>
                  {x.paid ? "إلغاء الدفع" : "تم الدفع"}
                </button>
                <button type="button" className={`${btnClass} bg-accent text-accent-fg`} onClick={() => onPrint({ kind: "worker", pay: x, shop })}>
                  وصل
                </button>
                <button
                  type="button"
                  className={`${btnClass} bg-surface-2 text-fg`}
                  onClick={() => {
                    setEditId(x.id);
                    setName(x.name);
                    setStart(x.start);
                    setEnd(x.end);
                    setDaysRaw(String(x.days));
                    setAbsent(x.absent ? String(x.absent) : "");
                    setHalf(x.half ? String(x.half) : "");
                    setWage(String(x.wage));
                    setMobile(x.mobile ? String(x.mobile) : "");
                    setExpenses(x.expenses.map((e) => ({ ...e })));
                    const w = workers.find((wr) => wr.name === x.name);
                    setPick(w ? String(w.id) : "");
                    document.getElementById("worker-name")?.scrollIntoView({ behavior: "smooth", block: "center" });
                  }}
                >
                  تعديل
                </button>
                <button
                  type="button"
                  className={`${btnClass} bg-danger text-danger-fg`}
                  onClick={() => {
                    if (!window.confirm("حذف هذا السجل؟")) return;
                    deletePay(x.id);
                  }}
                >
                  حذف
                </button>
              </div>
            </article>
          ))}
        </div>
      </Card>
    </div>
  );
}
