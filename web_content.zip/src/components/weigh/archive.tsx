import { useMemo, useState } from "react";
import { Printer, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { MODE_META, MODES } from "@/lib/weigh/defaults";
import { money, qtyLabel, ymd } from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import type { Mode } from "@/lib/weigh/types";
import type { SaleSlip } from "@/components/weigh/slip";
import { Card, Field, inputClass } from "@/components/weigh/ui";

export function ArchiveView({ onPrint }: { onPrint: (slip: SaleSlip) => void }) {
  const history = useWeigh((s) => s.history);
  const shop = useWeigh((s) => s.report.shop);
  const deleteTx = useWeigh((s) => s.deleteTx);
  const [name, setName] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [type, setType] = useState<"all" | Mode>("all");

  const rows = useMemo(() => {
    const q = name.trim().toLowerCase();
    return history
      .filter((tx) => {
        if (type !== "all" && tx.mode !== type) return false;
        if (q && !tx.name.toLowerCase().includes(q)) return false;
        if (from && tx.dateKey && tx.dateKey < from) return false;
        if (to && tx.dateKey && tx.dateKey > to) return false;
        return true;
      })
      .sort((a, b) => b.id - a.id);
  }, [history, name, from, to, type]);

  const sum = rows.reduce((a, tx) => a + tx.grandTotal, 0);

  return (
    <div>
      <Card title="سجل العمليات">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="بحث بالاسم">
            <input className={inputClass} value={name} placeholder="اسم..." onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="النوع">
            <select className={inputClass} value={type} onChange={(e) => setType(e.target.value as "all" | Mode)}>
              <option value="all">الكل</option>
              {MODES.map((m) => (
                <option key={m} value={m}>
                  {MODE_META[m].label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="من تاريخ">
            <input type="date" className={inputClass} value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label="إلى تاريخ">
            <input type="date" className={inputClass} value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
        </div>
        <p className="mt-3 text-sm text-muted">
          {rows.length} عملية · {money(sum)} دج
        </p>
      </Card>
      {rows.length === 0 ? (
        <Card>
          <p className="py-6 text-center text-sm text-muted">لا نتائج. العمليات المحفوظة تبقى على هذا الجهاز.</p>
        </Card>
      ) : null}
      {rows.map((tx) => (
        <Card key={tx.id}>
          <div className="mb-2 flex flex-wrap items-start justify-between gap-2">
            <div>
              <div className="font-bold">{tx.name || "—"}</div>
              <div className="mt-1 flex flex-wrap gap-2 text-xs">
                <span className="rounded-full bg-primary/15 px-2 py-1 text-primary">{MODE_META[tx.mode].label}</span>
                <span className={tx.isCredit ? "rounded-full bg-accent/20 px-2 py-1 text-accent" : "rounded-full bg-primary/10 px-2 py-1 text-primary"}>
                  {tx.isCredit ? "بالدين" : "نقدي"}
                </span>
              </div>
            </div>
            <div className="text-xs text-muted">{tx.datetime || tx.dateKey}</div>
          </div>
          <ul className="space-y-1 text-sm">
            {tx.items.map((it, i) => (
              <li key={`${it.id}-${i}`} className="flex justify-between gap-3 border-b border-line/70 py-1">
                <span>
                  {it.emoji} {it.name}
                  <span className="text-muted"> · {qtyLabel(it)}</span>
                </span>
                <span className="font-semibold text-accent">{money(it.total)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex items-center justify-between gap-2">
            <strong>{money(tx.grandTotal)} دج</strong>
            <div className="flex gap-2">
              <button
                type="button"
                aria-label="طباعة السند"
                className="flex size-11 items-center justify-center rounded-xl bg-accent text-accent-fg"
                onClick={() =>
                  onPrint({
                    kind: "sale",
                    bonNum: tx.id,
                    name: tx.name,
                    datetime: tx.datetime,
                    isCredit: tx.isCredit,
                    mode: tx.mode,
                    items: tx.items,
                    grand: tx.grandTotal,
                    shop,
                  })
                }
              >
                <Printer className="size-4" />
              </button>
              <button
                type="button"
                aria-label="حذف العملية"
                className="flex size-11 items-center justify-center rounded-xl bg-danger text-danger-fg"
                onClick={() => {
                  if (!window.confirm("حذف العملية؟ لا يمكن التراجع.")) return;
                  deleteTx(tx.id);
                  toast.success("حُذفت العملية");
                }}
              >
                <Trash2 className="size-4" />
              </button>
            </div>
          </div>
        </Card>
      ))}
      <p className="px-1 text-center text-xs text-muted">اليوم {ymd()}</p>
    </div>
  );
}
