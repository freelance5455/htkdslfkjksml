import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { Plus, Printer, Save, ShoppingCart, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { MODE_META } from "@/lib/weigh/defaults";
import {
  formatNow,
  keptItems,
  lineTotal,
  money,
  sideWeight,
  stageGross,
  toSaved,
  totalGross,
  uid,
} from "@/lib/weigh/logic";
import { useWeigh } from "@/lib/weigh/store";
import type { Mode } from "@/lib/weigh/types";
import type { SaleSlip } from "@/components/weigh/slip";
import { btnClass, Card, Field, inputClass, Modal } from "@/components/weigh/ui";
import { cn } from "@/lib/cn";

export function DealView({ mode, onPrint }: { mode: Mode; onPrint: (slip: SaleSlip) => void }) {
  const session = useWeigh((s) => s.sessions[mode].find((x) => x.id === s.activeId[mode]) ?? s.sessions[mode][0]);
  const sessions = useWeigh((s) => s.sessions[mode]);
  const commodities = useWeigh((s) => s.commodities);
  const shop = useWeigh((s) => s.report.shop);
  const updateSession = useWeigh((s) => s.updateSession);
  const patchStage = useWeigh((s) => s.patchStage);
  const addStage = useWeigh((s) => s.addStage);
  const removeStage = useWeigh((s) => s.removeStage);
  const addSides = useWeigh((s) => s.addSides);
  const removeSide = useWeigh((s) => s.removeSide);
  const addItem = useWeigh((s) => s.addItem);
  const updateItem = useWeigh((s) => s.updateItem);
  const removeItem = useWeigh((s) => s.removeItem);
  const clearList = useWeigh((s) => s.clearList);
  const newSession = useWeigh((s) => s.newSession);
  const switchSession = useWeigh((s) => s.switchSession);
  const closeSession = useWeigh((s) => s.closeSession);
  const saveTx = useWeigh((s) => s.saveTx);

  const [clock, setClock] = useState(formatNow);
  const [goodsOpen, setGoodsOpen] = useState(false);
  const [sideStage, setSideStage] = useState<number | null>(null);
  const [picked, setPicked] = useState<number[]>([]);
  const armFocus = useRef(false);
  const meta = MODE_META[mode];

  useEffect(() => {
    const t = setInterval(() => setClock(formatNow()), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!armFocus.current || !session) return;
    armFocus.current = false;
    const el = document.getElementById(`w-${mode}-${session.stages.length - 1}`);
    el?.focus();
  }, [session, mode]);

  if (!session) return null;

  const grand = session.items.reduce((a, it) => a + lineTotal(it), 0);
  const gross = totalGross(session.stages);

  function focusSibling(el: HTMLElement) {
    const root = el.closest("[data-fields]");
    if (!root) return;
    const inputs = [...root.querySelectorAll<HTMLElement>("input, select")];
    const i = inputs.indexOf(el);
    const next = inputs[i + 1];
    if (next) {
      next.focus();
      if (next instanceof HTMLInputElement) next.select();
    }
  }

  function onEnter(e: KeyboardEvent<HTMLInputElement | HTMLSelectElement>) {
    if (e.key !== "Enter") return;
    e.preventDefault();
    focusSibling(e.currentTarget);
  }

  function buildSlip(): SaleSlip | null {
    const name = session.name.trim();
    if (!name) {
      toast.error("أدخل الاسم");
      return null;
    }
    const items = keptItems(session.items).map(toSaved);
    if (!items.length) {
      toast.error("أضف سلعة بوزن أو عدد");
      return null;
    }
    return {
      kind: "sale",
      bonNum: uid(),
      name,
      datetime: clock,
      isCredit: session.isCredit,
      mode,
      items,
      grand: items.reduce((a, it) => a + it.total, 0),
      shop,
    };
  }

  function onSave() {
    const res = saveTx(mode);
    if (!res.ok) {
      toast.error(res.error);
      return;
    }
    toast.success("تم حفظ المعاملة");
    onPrint({
      kind: "sale",
      bonNum: res.tx.id,
      name: res.tx.name,
      datetime: res.tx.datetime,
      isCredit: res.tx.isCredit,
      mode: res.tx.mode,
      items: res.tx.items,
      grand: res.tx.grandTotal,
      shop,
    });
  }

  const stageBox = sideStage != null ? session.stages[sideStage] : null;

  return (
    <div>
      <Card
        title={meta.title}
        action={
          <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => newSession(mode)}>
            <Plus className="size-4" />
            معاملة جديدة
          </button>
        }
      >
        <p className="mb-3 text-xs text-muted">{meta.price} · تُحفظ المسودة تلقائياً</p>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {sessions.map((s, i) => {
            const active = s.id === session.id;
            return (
              <div
                key={s.id}
                className={cn(
                  "flex h-10 shrink-0 items-center rounded-full border pe-1 ps-3",
                  active ? "border-primary bg-primary/15" : "border-line bg-surface-2",
                )}
              >
                <button type="button" className="max-w-40 truncate text-sm font-medium" onClick={() => switchSession(mode, s.id)}>
                  {s.name || `معاملة ${i + 1}`}
                </button>
                {sessions.length > 1 ? (
                  <button
                    type="button"
                    aria-label="إغلاق المعاملة"
                    className="flex size-8 items-center justify-center text-danger"
                    onClick={() => closeSession(mode, s.id)}
                  >
                    ×
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
      </Card>

      <Card title="البيانات والأوزان">
        <div className="grid gap-3 sm:grid-cols-3" data-fields>
          <Field label="الاسم">
            <input
              id="tx-name"
              className={inputClass}
              value={session.name}
              placeholder="اسم الزبون"
              onChange={(e) => updateSession(mode, { name: e.target.value })}
              onKeyDown={onEnter}
            />
          </Field>
          <Field label="نوع الدفع">
            <select
              className={inputClass}
              value={session.isCredit ? "1" : "0"}
              onChange={(e) => updateSession(mode, { isCredit: e.target.value === "1" })}
            >
              <option value="0">نقدي</option>
              <option value="1">بالدين</option>
            </select>
          </Field>
          <Field label="التاريخ والوقت">
            <input className={inputClass} readOnly value={clock} />
          </Field>
        </div>
        <p className="mt-3 text-xs text-muted">الفرق بين وزنين هو قوس السلعة. السلع الجانبية تُنقص من القوس ويُكتب وزنها في القائمة.</p>
        <div className="mt-3 space-y-3">
          {session.stages.map((st, i) => {
            if (i === 0) {
              return (
                <div key={i} className="rounded-xl border border-line bg-bg/50 p-3">
                  <Field label="الوزن 1 (كغ)">
                    <input
                      id={`w-${mode}-0`}
                      inputMode="decimal"
                      className={inputClass}
                      placeholder="وزن الميزان"
                      value={st.value}
                      onChange={(e) => patchStage(mode, 0, { value: e.target.value })}
                      onFocus={(e) => e.target.select()}
                      onKeyDown={(e) => {
                        if (e.key !== "Enter") return;
                        e.preventDefault();
                        const n = document.getElementById(`w-${mode}-1`) as HTMLInputElement | null;
                        n?.focus();
                        n?.select();
                      }}
                    />
                  </Field>
                </div>
              );
            }
            const g = stageGross(session.stages, i);
            const ss = st.sides.reduce((a, side) => a + sideWeight(session.items, side.id), 0);
            const net = Math.max(0, g - ss);
            return (
              <div key={i} className="rounded-xl border border-line bg-bg/50 p-3">
                <div className="flex items-end gap-2">
                  <Field label={`الوزن ${i + 1} — قوس ${i}−${i + 1}`} className="flex-1">
                    <input
                      id={`w-${mode}-${i}`}
                      inputMode="decimal"
                      className={inputClass}
                      placeholder="وزن"
                      value={st.value}
                      onChange={(e) => patchStage(mode, i, { value: e.target.value })}
                      onFocus={(e) => e.target.select()}
                      onKeyDown={(e) => {
                        if (e.key !== "Enter") return;
                        e.preventDefault();
                        const n = document.getElementById(`w-${mode}-${i + 1}`) as HTMLInputElement | null;
                        if (n) {
                          n.focus();
                          n.select();
                        }
                      }}
                    />
                  </Field>
                  {i >= 2 ? (
                    <button type="button" aria-label="حذف الوزن" className={`${btnClass} bg-danger text-danger-fg`} onClick={() => removeStage(mode, i)}>
                      <Trash2 className="size-4" />
                    </button>
                  ) : null}
                </div>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-primary/40 bg-primary/10 px-3 py-2">
                    <div className="text-xs text-muted">صافي القوس</div>
                    <div className="text-lg font-bold text-primary">{money(g)} كغ</div>
                  </div>
                  <Field label="السلعة المستهدفة">
                    <select className={inputClass} value={st.targetId} onChange={(e) => patchStage(mode, i, { targetId: e.target.value })}>
                      <option value="">— بدون —</option>
                      {commodities.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.emoji} {c.name}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
                <div className="mt-3 rounded-xl bg-surface-2 p-3">
                  <div className="mb-2 text-sm font-semibold text-accent">سلع جانبية</div>
                  {st.sides.length === 0 ? <p className="text-sm text-muted">لا توجد</p> : null}
                  <ul className="space-y-2">
                    {st.sides.map((side) => {
                      const c = commodities.find((x) => x.id === side.id);
                      return (
                        <li key={side.id} className="flex items-center justify-between gap-2 text-sm">
                          <span>
                            {c ? `${c.emoji} ${c.name}` : side.id}
                            <span className="text-muted"> · {money(sideWeight(session.items, side.id))} كغ</span>
                          </span>
                          <button type="button" aria-label="إزالة سلعة جانبية" className="text-danger" onClick={() => removeSide(mode, i, side.id)}>
                            ×
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                  <button
                    type="button"
                    className={`${btnClass} mt-2 bg-accent text-accent-fg`}
                    onClick={() => {
                      setPicked([]);
                      setSideStage(i);
                    }}
                  >
                    <ShoppingCart className="size-4" />
                    إضافة سلع جانبية
                  </button>
                  <div className="mt-2 flex justify-between text-sm">
                    <span>جانبية: {money(ss)} كغ</span>
                    <span className="font-bold text-primary">للمستهدفة: {money(net)} كغ</span>
                  </div>
                </div>
                {i === session.stages.length - 1 ? (
                  <button
                    type="button"
                    className={`${btnClass} mt-3 w-full bg-accent text-accent-fg`}
                    onClick={() => {
                      armFocus.current = true;
                      addStage(mode);
                    }}
                  >
                    <Plus className="size-4" />
                    إضافة الوزن التالي
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-sm text-muted">
          إجمالي الأقواس: <strong className="text-primary">{money(gross)} كغ</strong>
        </p>
      </Card>

      <Card title="السلع">
        <button type="button" className={`${btnClass} bg-primary text-primary-fg`} onClick={() => setGoodsOpen(true)}>
          <ShoppingCart className="size-4" />
          فتح قائمة السلع
        </button>
        <div className="mt-3 space-y-2" data-fields>
          {session.items.length === 0 ? <p className="py-4 text-center text-sm text-muted">لم تُضف سلع بعد</p> : null}
          {session.items.map((it) => (
            <div key={it.id} className="rounded-xl border border-line bg-bg/40 p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <div className="font-semibold">
                  {it.emoji} {it.name}
                  {it.byCount ? <span className="ms-2 text-xs font-normal text-muted">بالقطعة</span> : null}
                  {it.fromStage ? <span className="ms-2 text-xs font-normal text-primary">من القوس</span> : null}
                </div>
                <button type="button" aria-label={`حذف ${it.name}`} className="text-danger" onClick={() => removeItem(mode, it.id)}>
                  <Trash2 className="size-4" />
                </button>
              </div>
              <div className={cn("grid gap-2", it.byCount ? "sm:grid-cols-3" : "sm:grid-cols-2")}>
                <Field label="الوزن (كغ)">
                  <input
                    inputMode="decimal"
                    className={inputClass}
                    placeholder="0"
                    value={it.weight}
                    onChange={(e) => updateItem(mode, it.id, "weight", e.target.value)}
                    onFocus={(e) => e.target.select()}
                    onKeyDown={onEnter}
                  />
                </Field>
                {it.byCount ? (
                  <Field label="العدد">
                    <input
                      inputMode="decimal"
                      className={inputClass}
                      placeholder="0"
                      value={it.quantity}
                      onChange={(e) => updateItem(mode, it.id, "quantity", e.target.value)}
                      onFocus={(e) => e.target.select()}
                      onKeyDown={onEnter}
                    />
                  </Field>
                ) : null}
                <Field label="السعر (دج)">
                  <input
                    inputMode="decimal"
                    className={inputClass}
                    placeholder={String(it.priceDefault || "سعر")}
                    value={it.pricePerKg}
                    onChange={(e) => updateItem(mode, it.id, "pricePerKg", e.target.value)}
                    onFocus={(e) => e.target.select()}
                    onKeyDown={onEnter}
                  />
                </Field>
              </div>
              <p className="mt-2 text-end text-sm font-bold text-accent">{money(lineTotal(it))} دج</p>
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-between rounded-xl bg-primary/15 px-4 py-3 text-lg font-bold">
          <span>المجموع</span>
          <span className="text-accent">{money(grand)} دج</span>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button type="button" className={`${btnClass} col-span-2 h-12 bg-primary text-base text-primary-fg`} onClick={onSave}>
            <Save className="size-4" />
            حفظ المعاملة
          </button>
          <button
            type="button"
            className={`${btnClass} bg-accent text-accent-fg`}
            onClick={() => {
              const slip = buildSlip();
              if (slip) onPrint(slip);
            }}
          >
            <Printer className="size-4" />
            سند تسليم
          </button>
          <button
            type="button"
            className={`${btnClass} bg-danger text-danger-fg`}
            onClick={() => {
              if (session.items.length && !window.confirm("مسح القائمة والأوزان؟")) return;
              clearList(mode);
            }}
          >
            <Trash2 className="size-4" />
            مسح
          </button>
        </div>
      </Card>

      {goodsOpen ? (
        <Modal title={`اختيار السلع — ${meta.label}`} onClose={() => setGoodsOpen(false)}>
          <p className="mb-3 text-sm text-muted">اضغط لإضافة السلعة إلى القائمة. يمكنك اختيار أكثر من واحدة.</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {commodities.map((c) => {
              const inList = session.items.some((it) => it.id === c.id);
              const price = mode === "visitor" ? c.priceVisitor : mode === "sales" ? c.priceSale : c.priceDealer;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => addItem(mode, c.id)}
                  className={cn(
                    "min-h-20 rounded-xl border px-1 py-2 text-center",
                    inList ? "border-primary bg-primary/15" : "border-line bg-bg",
                  )}
                >
                  <div className="text-xl">{c.emoji || "•"}</div>
                  <div className="mt-1 text-xs font-semibold">{c.name}</div>
                  <div className="text-xs text-accent">
                    {money(price, 0)} {c.byCount ? "دج/ق" : "دج/كغ"}
                  </div>
                </button>
              );
            })}
          </div>
        </Modal>
      ) : null}

      {sideStage != null && stageBox ? (
        <Modal title={`سلع جانبية — قوس ${sideStage}−${sideStage + 1}`} onClose={() => setSideStage(null)}>
          <p className="mb-3 text-sm text-muted">حدد السلع ثم أضفها. وزنها يُنقص من القوس.</p>
          <div className="grid grid-cols-3 gap-2">
            {commodities.map((c) => {
              const taken = stageBox.sides.some((s) => s.id === c.id) || String(stageBox.targetId) === String(c.id);
              const on = picked.includes(c.id);
              return (
                <button
                  key={c.id}
                  type="button"
                  disabled={taken}
                  onClick={() => setPicked((p) => (p.includes(c.id) ? p.filter((x) => x !== c.id) : [...p, c.id]))}
                  className={cn(
                    "min-h-20 rounded-xl border px-1 py-2 text-center disabled:opacity-40",
                    on ? "border-primary bg-primary/20" : "border-line bg-bg",
                  )}
                >
                  <div className="text-xl">{c.emoji || "•"}</div>
                  <div className="mt-1 text-xs font-semibold">{c.name}</div>
                  <div className="text-xs text-muted">{taken ? (String(stageBox.targetId) === String(c.id) ? "مستهدفة" : "موجودة") : on ? "محددة" : "تحديد"}</div>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            className={`${btnClass} mt-4 w-full bg-primary text-primary-fg`}
            onClick={() => {
              if (!picked.length) {
                toast.error("حدد سلعة واحدة أو أكثر");
                return;
              }
              addSides(mode, sideStage, picked);
              setSideStage(null);
            }}
          >
            إضافة المحددة
          </button>
        </Modal>
      ) : null}
    </div>
  );
}
