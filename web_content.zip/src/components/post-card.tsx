import { useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { addComment, deleteComment, deletePost, listComments, setReaction } from "@/lib/cutegirls/api";
import {
  REACTIONS,
  STICKERS,
  ago,
  youtubeVideoId,
  type CommentView,
  type PostView,
} from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { Avatar, KindPill, MarkIcon, RolePill, fieldClass } from "./bits";

export function PostCard({
  post,
  variant,
  mine,
  onRemoved,
}: {
  post: PostView;
  variant: "feed" | "reel" | "subliminal";
  mine: boolean;
  onRemoved: (id: string) => void;
}) {
  const bump = useSalon((s) => s.bump);
  const [reactions, setReactions] = useState(post.reactions);
  const [myReaction, setMine] = useState(post.myReaction);
  const [open, setOpen] = useState(false);
  const [comments, setComments] = useState<CommentView[] | null>(null);
  const [count, setCount] = useState(post.commentCount);
  const [body, setBody] = useState("");
  const [sticker, setSticker] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const video = post.link ? youtubeVideoId(post.link) : null;

  useEffect(() => {
    setReactions(post.reactions);
    setMine(post.myReaction);
    setCount(post.commentCount);
  }, [post]);

  async function react(kind: string) {
    setError(null);
    const result = await setReaction({ data: { postId: post.id, kind } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setReactions(result.reactions);
    setMine(result.myReaction);
  }

  async function loadComments() {
    const next = !open;
    setOpen(next);
    if (!next || comments) return;
    const result = await listComments({ data: { postId: post.id } });
    if (result.ok) setComments(result.comments);
  }

  async function sendComment(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await addComment({ data: { postId: post.id, body, sticker } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setBody("");
      setSticker(null);
      const fresh = await listComments({ data: { postId: post.id } });
      if (fresh.ok) {
        setComments(fresh.comments);
        setCount(fresh.comments.length);
      }
    } finally {
      setBusy(false);
    }
  }

  async function removeComment(id: string) {
    const result = await deleteComment({ data: { id } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setComments((list) => (list ? list.filter((item) => item.id !== id) : list));
    setCount((n) => Math.max(0, n - 1));
  }

  async function removePost() {
    const result = await deletePost({ data: { id: post.id } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onRemoved(post.id);
    bump();
  }

  return (
    <article className="rounded-3xl bg-paper p-4 shadow-card sm:p-5">
      <header className="flex items-start gap-3">
        <Link to="/u/$username" params={{ username: post.username }} className="shrink-0">
          <Avatar src={post.avatar} name={post.username} />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Link to="/u/$username" params={{ username: post.username }} className="truncate font-medium">
              {post.username}
            </Link>
            <RolePill role={post.role} />
            <span className="text-xs tabular-nums text-mute">{ago(post.createdAt)}</span>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <KindPill kind={post.kind} />
            {post.groupSlug && post.groupName ? (
              <Link to="/groups/$slug" params={{ slug: post.groupSlug }} className="text-xs text-mute">
                {post.groupName}
              </Link>
            ) : null}
          </div>
        </div>
        {mine ? (
          <button type="button" className="grid size-11 shrink-0 place-items-center rounded-full text-mute hover:bg-ivory hover:text-rose" onClick={() => void removePost()} aria-label="حذف المنشور">
            <Trash2 className="size-4" />
          </button>
        ) : null}
      </header>
      {post.title ? <h3 className="mt-4 font-display text-2xl leading-snug">{post.title}</h3> : null}
      {post.body ? <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-ink">{post.body}</p> : null}
      {post.media ? (
        <img
          src={post.media}
          alt=""
          className={`mt-4 w-full rounded-2xl object-cover ${variant === "reel" ? "aspect-[4/5]" : "max-h-80"}`}
        />
      ) : null}
      {video ? (
        <iframe
          className="mt-4 aspect-video w-full rounded-2xl"
          src={`https://www.youtube-nocookie.com/embed/${video}`}
          title={post.title || "سيبلمنال"}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ) : post.link ? (
        <a href={post.link} target="_blank" rel="noreferrer" className="mt-3 block truncate text-sm text-rose" dir="ltr">
          {post.link}
        </a>
      ) : null}
      <div className="mt-4 grid grid-cols-6 gap-1">
        {REACTIONS.map((item) => {
          const active = myReaction === item.id;
          const n = reactions[item.id] ?? 0;
          return (
            <button
              key={item.id}
              type="button"
              aria-pressed={active}
              aria-label={item.label}
              onClick={() => void react(item.id)}
              className={`flex min-h-11 flex-col items-center justify-center rounded-2xl text-xs ${
                active ? "bg-rose text-paper" : "bg-ivory text-ink"
              }`}
            >
              <MarkIcon name={item.id} className="size-4" />
              <span className="tabular-nums">{n > 0 ? n : item.label}</span>
            </button>
          );
        })}
      </div>
      <button type="button" className="mt-3 min-h-11 text-sm text-mute" onClick={() => void loadComments()}>
        {open ? "إخفاء التعليقات" : `تعليقات ${count}`}
      </button>
      {open ? (
        <div className="mt-2 space-y-3 border-t border-ink/10 pt-3">
          {(comments ?? []).map((comment) => (
            <div key={comment.id} className="flex gap-2">
              <Avatar src={comment.avatar} name={comment.username} className="size-8 text-xs" />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <Link to="/u/$username" params={{ username: comment.username }} className="text-sm font-medium">
                    {comment.username}
                  </Link>
                  <span className="text-xs text-mute">{ago(comment.createdAt)}</span>
                  {comment.mine ? (
                    <button type="button" className="text-xs text-mute" onClick={() => void removeComment(comment.id)}>
                      حذف
                    </button>
                  ) : null}
                </div>
                {comment.sticker ? (
                  <span className="mt-1 inline-flex items-center gap-1 rounded-2xl bg-rose/10 px-2 py-1 text-xs text-rose">
                    <MarkIcon name={comment.sticker} />
                    {STICKERS.find((item) => item.id === comment.sticker)?.label}
                  </span>
                ) : null}
                {comment.body ? <p className="text-sm leading-6">{comment.body}</p> : null}
              </div>
            </div>
          ))}
          <form onSubmit={sendComment} className="space-y-2">
            <div className="grid grid-cols-4 gap-1.5">
              {STICKERS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={sticker === item.id}
                  onClick={() => setSticker((cur) => (cur === item.id ? null : item.id))}
                  className={`flex min-h-11 flex-col items-center justify-center rounded-2xl text-xs ${
                    sticker === item.id ? "bg-rose text-paper" : "bg-ivory"
                  }`}
                >
                  <MarkIcon name={item.id} />
                  {item.label}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                className={`${fieldClass} h-12 flex-1`}
                placeholder="تعليق أو ملصق"
                value={body}
                onChange={(e) => setBody(e.target.value)}
              />
              <button className="min-h-12 shrink-0 rounded-full bg-rose px-4 text-sm text-paper disabled:opacity-50" disabled={busy} type="submit">
                إرسال
              </button>
            </div>
          </form>
        </div>
      ) : null}
      {error ? <p className="mt-2 text-sm text-rose">{error}</p> : null}
    </article>
  );
}
