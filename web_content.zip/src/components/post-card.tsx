import { CommentThread } from "@/components/comment-thread";
import { ErrorBoundary } from "@/components/error-boundary";
import { MediaViewer } from "@/components/media-viewer";
import { SubscribeButton } from "@/components/subscribe-button";
import { Badge } from "@/components/ui/badge";
import { VideoPlayer } from "@/components/video-player";
import { cn } from "@/lib/utils";
import type { CommunityPost } from "@/lib/youtube/types";
import { Link } from "@tanstack/react-router";
import { Heart, MessageCircle, Play } from "lucide-react";
import { memo, useState } from "react";

function kindLabel(kind: CommunityPost["kind"]) {
  if (kind === "image") return "Image";
  if (kind === "poll") return "Poll";
  if (kind === "video") return "Video";
  if (kind === "quiz") return "Quiz";
  return "Post";
}

function PostCardInner({ post }: { post: CommunityPost }) {
  const [openImage, setOpenImage] = useState<string | null>(null);
  const [openVideo, setOpenVideo] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const long = post.text.length > 280;
  const body = !expanded && long ? `${post.text.slice(0, 280).trim()}…` : post.text;

  const channel = {
    id: post.channelId,
    title: post.channelTitle,
    handle: post.channelHandle,
    description: "",
    thumbnail: post.channelThumbnail,
    subscriberCount: 0,
    subscriberText: "",
    videoCount: 0,
    videoText: "",
    verified: false,
    hasPostsTab: true,
  };

  return (
    <article className="card-item overflow-hidden rounded-2xl border border-border bg-card p-4 sm:p-5">
      <header className="flex items-start gap-3">
        <Link
          to="/channel/$channelId"
          params={{ channelId: post.channelId }}
          className="shrink-0"
        >
          {post.channelThumbnail ? (
            <img
              src={post.channelThumbnail}
              alt=""
              loading="lazy"
              decoding="async"
              className="size-11 rounded-full object-cover"
            />
          ) : (
            <span className="flex size-11 items-center justify-center rounded-full bg-muted text-sm font-medium">
              {post.channelTitle.slice(0, 1)}
            </span>
          )}
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex min-w-0 items-center gap-2">
            <Link
              to="/channel/$channelId"
              params={{ channelId: post.channelId }}
              className="truncate text-sm font-semibold text-foreground"
            >
              {post.channelTitle}
            </Link>
            <Badge>{kindLabel(post.kind)}</Badge>
          </div>
          <p className="truncate text-xs text-muted-foreground">
            {post.channelHandle ? `${post.channelHandle} · ` : ""}
            {post.publishedText}
          </p>
        </div>
        {post.channelId ? (
          <div className="shrink-0">
            <SubscribeButton channel={channel} />
          </div>
        ) : null}
      </header>

      {body ? (
        <p className="mt-3 whitespace-pre-wrap break-words text-pretty text-sm leading-relaxed text-foreground">
          {body}
          {long ? (
            <button
              type="button"
              className="ml-1 font-medium text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
              onClick={() => setExpanded((v) => !v)}
            >
              {expanded ? "Show less" : "Show more"}
            </button>
          ) : null}
        </p>
      ) : null}

      {post.images.length === 1 && post.images[0] ? (
        <button
          type="button"
          className="mt-3 block w-full overflow-hidden rounded-xl bg-muted"
          onClick={() => setOpenImage(post.images[0]!.url)}
        >
          <img
            src={post.images[0].url}
            alt=""
            loading="lazy"
            decoding="async"
            className="max-h-[28rem] w-full object-cover"
          />
        </button>
      ) : null}

      {post.images.length > 1 ? (
        <div
          className={cn(
            "mt-3 grid gap-1 overflow-hidden rounded-xl",
            post.images.length === 2 ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-3",
          )}
        >
          {post.images.slice(0, 6).map((img, i) => (
            <button
              key={`${img.url}-${i}`}
              type="button"
              className="relative aspect-square overflow-hidden bg-muted"
              onClick={() => setOpenImage(img.url)}
            >
              <img src={img.url} alt="" loading="lazy" decoding="async" className="size-full object-cover" />
              {i === 5 && post.images.length > 6 ? (
                <span className="absolute inset-0 flex items-center justify-center bg-background/70 text-sm font-medium">
                  +{post.images.length - 6}
                </span>
              ) : null}
            </button>
          ))}
        </div>
      ) : null}

      {post.poll ? (
        <ul className="mt-3 space-y-2">
          {post.poll.choices.map((choice) => (
            <li key={choice.text}>
              {choice.imageUrl ? (
                <button
                  type="button"
                  className="w-full overflow-hidden rounded-xl border border-border bg-secondary text-left"
                  onClick={() => setOpenImage(choice.imageUrl!)}
                >
                  <img
                    src={choice.imageUrl}
                    alt=""
                    loading="lazy"
                    decoding="async"
                    className="h-28 w-full object-cover"
                  />
                  <span className="block px-3 py-2.5 text-sm break-words">{choice.text}</span>
                </button>
              ) : (
                <div className="rounded-xl border border-border bg-secondary px-3 py-2.5 text-sm break-words">
                  {choice.text}
                </div>
              )}
            </li>
          ))}
          {post.poll.totalVotesText ? (
            <li className="px-1 text-xs text-muted-foreground">{post.poll.totalVotesText}</li>
          ) : null}
        </ul>
      ) : null}

      {post.video ? (
        <button
          type="button"
          onClick={() => setOpenVideo(true)}
          className="relative mt-3 block w-full overflow-hidden rounded-xl bg-muted text-left"
        >
          <img
            src={post.video.thumbnail}
            alt=""
            loading="lazy"
            decoding="async"
            className="aspect-video w-full object-cover"
          />
          <span className="absolute inset-0 flex items-center justify-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-background/80 text-foreground">
              <Play className="size-5 fill-current" />
            </span>
          </span>
          {post.video.lengthText ? (
            <span className="absolute bottom-2 right-2 rounded-md bg-background/80 px-1.5 py-0.5 text-[11px] font-medium tabular-nums">
              {post.video.lengthText}
            </span>
          ) : null}
          <span className="block px-3 py-2 text-sm font-medium break-words">{post.video.title}</span>
        </button>
      ) : null}

      <footer className="mt-4 flex items-center justify-between gap-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5 tabular-nums">
            <Heart className="size-3.5" />
            {post.likeText || "0"}
          </span>
          <span className="inline-flex items-center gap-1.5 tabular-nums">
            <MessageCircle className="size-3.5" />
            {post.replyText || post.replyCount || "0"}
          </span>
        </div>
      </footer>

      <ErrorBoundary fallbackTitle="Comments failed to load">
        <CommentThread post={post} />
      </ErrorBoundary>

      {openImage ? <MediaViewer src={openImage} onClose={() => setOpenImage(null)} /> : null}
      {openVideo && post.video ? (
        <VideoPlayer
          videoId={post.video.id}
          title={post.video.title}
          onClose={() => setOpenVideo(false)}
        />
      ) : null}
    </article>
  );
}

export const PostCard = memo(PostCardInner);

export function PostCardSkeleton() {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 sm:p-5">
      <div className="flex gap-3">
        <div className="size-11 animate-pulse rounded-full bg-muted" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-40 animate-pulse rounded bg-muted" />
          <div className="h-3 w-24 animate-pulse rounded bg-muted" />
        </div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="h-3 w-full animate-pulse rounded bg-muted" />
        <div className="h-3 w-4/5 animate-pulse rounded bg-muted" />
      </div>
      <div className="mt-3 h-48 animate-pulse rounded-xl bg-muted" />
    </div>
  );
}
