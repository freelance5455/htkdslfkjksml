import React from 'react';
import { MessageSquareQuote, Mic } from 'lucide-react';

interface VocalSuggestionsProps {
  onSelectSuggestion?: (text: string) => void;
  active: boolean;
}

const suggestions = [
  'YouTube kholo',
  'Zip file download karo',
  '5 minute ka timer lagao',
  'Gana bajao (Chill Lo-Fi)',
  'Google pe search karo space news',
  'Yeh note kar lo: Meeting at 5pm',
  'Roast my procrastination',
  'Vibe badlo to Midnight Emerald',
];

export const VocalSuggestions: React.FC<VocalSuggestionsProps> = ({ active }) => {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-2 flex flex-col items-center gap-2 select-none z-20">
      <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 font-medium">
        <Mic className="w-3.5 h-3.5 text-pink-400" />
        <span>Voice Commands you can speak (Hindi / English / Hinglish):</span>
      </div>

      <div className="flex items-center justify-center flex-wrap gap-2">
        {suggestions.map((item, idx) => (
          <div
            key={idx}
            className={`px-3 py-1.5 rounded-full text-xs backdrop-blur-md transition-all border ${
              active
                ? 'bg-white/5 border-white/10 text-zinc-300 hover:text-white hover:border-pink-500/40 hover:bg-pink-500/10 cursor-default'
                : 'bg-white/5 border-white/5 text-zinc-400 opacity-80'
            }`}
          >
            "{item}"
          </div>
        ))}
      </div>
    </div>
  );
};
