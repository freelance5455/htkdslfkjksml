import { useCallback, useEffect, useState } from "react";
import { IconFullscreen, IconFullscreenExit } from "./Icons";

type FullscreenDoc = Document & {
  webkitFullscreenElement?: Element | null;
  webkitExitFullscreen?: () => Promise<void> | void;
};

type FullscreenEl = HTMLElement & {
  webkitRequestFullscreen?: () => Promise<void> | void;
};

function isDocFullscreen(): boolean {
  if (typeof document === "undefined") return false;
  const doc = document as FullscreenDoc;
  return Boolean(doc.fullscreenElement ?? doc.webkitFullscreenElement);
}

export function FullscreenButton({ className }: { className?: string }) {
  const [active, setActive] = useState<boolean>(isDocFullscreen);

  useEffect(() => {
    const sync = () => setActive(isDocFullscreen());
    document.addEventListener("fullscreenchange", sync);
    document.addEventListener("webkitfullscreenchange", sync);
    return () => {
      document.removeEventListener("fullscreenchange", sync);
      document.removeEventListener("webkitfullscreenchange", sync);
    };
  }, []);

  const toggle = useCallback(async () => {
    const doc = document as FullscreenDoc;
    const el = document.documentElement as FullscreenEl;
    try {
      if (isDocFullscreen()) {
        if (doc.exitFullscreen) {
          await doc.exitFullscreen();
        } else if (doc.webkitExitFullscreen) {
          await doc.webkitExitFullscreen();
        }
      } else if (el.requestFullscreen) {
        await el.requestFullscreen({ navigationUI: "hide" }).catch(() => el.requestFullscreen());
      } else if (el.webkitRequestFullscreen) {
        await el.webkitRequestFullscreen();
      }
    } catch {
      /* ignore if browser blocks fullscreen */
    }
  }, []);

  const label = active ? "خروج از حالت تمام‌صفحه" : "تمام‌صفحه";

  return (
    <button
      type="button"
      onClick={() => void toggle()}
      aria-label={label}
      title={label}
      className={className}
    >
      {active ? <IconFullscreenExit size={19} /> : <IconFullscreen size={19} />}
    </button>
  );
}
