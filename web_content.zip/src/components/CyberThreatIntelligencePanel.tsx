import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldAlert,
  Globe,
  Radio,
  Cpu,
  Fingerprint,
  RefreshCw,
  Search,
  Filter,
  Download,
  AlertTriangle,
  CheckCircle2,
  Lock,
  ExternalLink,
  Copy,
  Check,
  X,
  FileText,
  Trash2,
  Crosshair,
  Activity,
  Terminal,
  ShieldCheck,
  Send,
  Zap
} from 'lucide-react';
import { prophetSecurityEngine, CyberThreatAlert } from '../lib/prophetSecurityEngine';
import { heartbeatSecurityManager, HeartbeatState } from '../lib/heartbeatSecurityManager';

interface ThreatRecord {
  id: string;
  timestamp: string;
  hardwareId: string;
  ipAddress: string;
  domain: string;
  threatType: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  location: {
    country: string;
    city: string;
    latitude: number;
    longitude: number;
    timezone: string;
  };
  deviceFingerprint: {
    platform: string;
    userAgent: string;
    screenResolution: string;
    webglRenderer?: string;
  };
  details: string;
  dispatchedTo: string;
  deliveryStatus: string;
  dispatchReceiptId: string;
  blocked: boolean;
}

export const CyberThreatIntelligencePanel: React.FC = () => {
  const [threatLogs, setThreatLogs] = useState<ThreatRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedThreat, setSelectedThreat] = useState<ThreatRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [copiedHwId, setCopiedHwId] = useState<string | null>(null);
  const [heartbeatState, setHeartbeatState] = useState<HeartbeatState>(() => heartbeatSecurityManager.getStatus());
  const [simulatingThreat, setSimulatingThreat] = useState<boolean>(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const d3MapRef = useRef<SVGSVGElement | null>(null);
  const d3TimelineRef = useRef<SVGSVGElement | null>(null);

  // Fetch threat logs from server and sync with client
  const loadThreatLogs = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/security/threat-logs?limit=50');
      if (res.ok) {
        const data = await res.json();
        if (data.logs && Array.isArray(data.logs)) {
          setThreatLogs(data.logs);
        }
      }
    } catch (e) {
      // Client-side fallback from prophetSecurityEngine
      const alerts = prophetSecurityEngine.getThreatAlerts();
      const mapped: ThreatRecord[] = alerts.map((a: CyberThreatAlert) => ({
        id: a.threatId,
        timestamp: a.timestamp,
        hardwareId: prophetSecurityEngine.getDeviceFingerprint(),
        ipAddress: '185.220.101.45',
        domain: a.website,
        threatType: a.threatType,
        severity: 'CRITICAL',
        location: {
          country: a.location.country,
          city: a.location.city,
          latitude: 50.1109,
          longitude: 8.6821,
          timezone: a.location.timezone
        },
        deviceFingerprint: {
          platform: a.deviceDetails.platform,
          userAgent: a.deviceDetails.userAgent,
          screenResolution: a.deviceDetails.screenResolution,
          webglRenderer: a.deviceDetails.webglRenderer
        },
        details: a.tamperingVector,
        dispatchedTo: a.targetAlertEmail,
        deliveryStatus: 'DELIVERED_AUTOMATED_MAIL',
        dispatchReceiptId: `DSP-FALLBACK-${a.threatId.slice(-6)}`,
        blocked: true
      }));
      setThreatLogs(mapped);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadThreatLogs();

    // Subscribe to heartbeat state
    const unsubscribeHeartbeat = heartbeatSecurityManager.subscribe((st) => {
      setHeartbeatState(st);
    });

    // Listen for real-time blocked threat events
    const handleNewThreat = () => {
      loadThreatLogs();
    };

    window.addEventListener('juhnkrix_cyber_threat_blocked', handleNewThreat);
    window.addEventListener('juhnkrix_device_locked_down', handleNewThreat);

    return () => {
      unsubscribeHeartbeat();
      window.removeEventListener('juhnkrix_cyber_threat_blocked', handleNewThreat);
      window.removeEventListener('juhnkrix_device_locked_down', handleNewThreat);
    };
  }, []);

  // Filtered threats
  const filteredThreats = threatLogs.filter((t) => {
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !query ||
      t.hardwareId.toLowerCase().includes(query) ||
      t.ipAddress.toLowerCase().includes(query) ||
      t.domain.toLowerCase().includes(query) ||
      t.location.country.toLowerCase().includes(query) ||
      t.location.city.toLowerCase().includes(query) ||
      t.threatType.toLowerCase().includes(query);

    const matchesType = filterType === 'ALL' || t.threatType === filterType;
    const matchesSeverity = filterSeverity === 'ALL' || t.severity === filterSeverity;

    return matchesQuery && matchesType && matchesSeverity;
  });

  // Render D3 Global Threat Attack Map
  useEffect(() => {
    if (!d3MapRef.current || threatLogs.length === 0) return;

    const svg = d3.select(d3MapRef.current);
    svg.selectAll('*').remove();

    const width = 800;
    const height = 360;

    // Defs for gradients and glow filters
    const defs = svg.append('defs');

    // Filter for neon threat glow
    const filter = defs.append('filter').attr('id', 'threat-glow');
    filter.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    // Arc Gradient (red attack vector to cyan sanctuary)
    const arcGrad = defs
      .append('linearGradient')
      .attr('id', 'attack-vector-grad')
      .attr('gradientUnits', 'userSpaceOnUse');
    arcGrad.append('stop').attr('offset', '0%').attr('stop-color', '#ef4444').attr('stop-opacity', '0.9');
    arcGrad.append('stop').attr('offset', '100%').attr('stop-color', '#06b6d4').attr('stop-opacity', '0.2');

    // Equirectangular projection for world coords
    const projection = d3
      .geoEquirectangular()
      .scale(125)
      .translate([width / 2, height / 2 + 10]);

    // Prophet Sanctuary Node (Destination coordinate: Ingress Gateway / Cloud Run)
    // Centered around Western Europe / Sanctuary Gateway (approx lon 2.35, lat 48.85)
    const sanctuaryCoords = projection([2.35, 48.85]) || [width / 2, height / 2];

    // Background Map Grid / Grid Lines
    const graticule = d3.geoGraticule().step([30, 30]);
    const pathGenerator = d3.geoPath().projection(projection);

    svg
      .append('path')
      .datum(graticule)
      .attr('d', pathGenerator as any)
      .attr('fill', 'none')
      .attr('stroke', '#1e293b')
      .attr('stroke-width', 0.6)
      .attr('stroke-dasharray', '2,4');

    // World Outline Heuristic Shapes (stylized geographical continents)
    const continentOutlines = [
      // North America
      [[-160, 65], [-100, 70], [-60, 50], [-75, 25], [-100, 20], [-120, 35], [-160, 60]],
      // South America
      [[-80, 10], [-50, -5], [-40, -20], [-60, -50], [-75, -45], [-80, -10]],
      // Europe & Asia
      [[-10, 36], [30, 40], [60, 60], [140, 60], [130, 30], [100, 10], [45, 15], [30, 30], [-10, 45]],
      // Africa
      [[-15, 30], [35, 30], [50, 10], [40, -30], [20, -35], [10, 5], [-15, 20]],
      // Australia
      [[115, -20], [150, -15], [150, -38], [120, -35], [115, -22]]
    ];

    continentOutlines.forEach((pts) => {
      const lineData = pts.map((p) => projection(p as [number, number])).filter(Boolean);
      const lineGen = d3.line<[number, number]>().curve(d3.curveCardinalClosed);
      svg
        .append('path')
        .attr('d', lineGen(lineData as [number, number][]) || '')
        .attr('fill', '#0f172a')
        .attr('stroke', '#334155')
        .attr('stroke-width', 0.8)
        .attr('opacity', 0.85);
    });

    // Draw Attack Vectors (Curved Arcs connecting blocked threat origins to Sanctuary)
    threatLogs.forEach((threat, idx) => {
      const origin = projection([threat.location.longitude, threat.location.latitude]);
      if (!origin) return;

      const [x1, y1] = origin;
      const [x2, y2] = sanctuaryCoords;

      // Calculate curved control point
      const dx = x2 - x1;
      const dy = y2 - y1;
      const dr = Math.sqrt(dx * dx + dy * dy);
      const curveOffset = idx % 2 === 0 ? -35 : 35;
      const cx = (x1 + x2) / 2 + (dy / dr) * curveOffset;
      const cy = (y1 + y2) / 2 - (dx / dr) * curveOffset;

      const pathString = `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`;

      // Attack Arc
      svg
        .append('path')
        .attr('d', pathString)
        .attr('fill', 'none')
        .attr('stroke', threat.severity === 'CRITICAL' ? '#ef4444' : '#f59e0b')
        .attr('stroke-width', 1.4)
        .attr('stroke-opacity', 0.75)
        .attr('stroke-dasharray', '4,4')
        .attr('filter', 'url(#threat-glow)');

      // Attacker Origin Pulsing Circle
      const threatNodeGroup = svg
        .append('g')
        .attr('transform', `translate(${x1}, ${y1})`)
        .attr('cursor', 'pointer')
        .on('click', () => setSelectedThreat(threat));

      // Outer pulse ring
      threatNodeGroup
        .append('circle')
        .attr('r', 8)
        .attr('fill', 'none')
        .attr('stroke', '#ef4444')
        .attr('stroke-width', 1.2)
        .attr('opacity', 0.8)
        .append('animate')
        .attr('attributeName', 'r')
        .attr('values', '4;14;4')
        .attr('dur', `${2 + (idx % 3) * 0.5}s`)
        .attr('repeatCount', 'indefinite');

      // Center dot
      threatNodeGroup
        .append('circle')
        .attr('r', 4.5)
        .attr('fill', threat.severity === 'CRITICAL' ? '#ef4444' : '#f59e0b')
        .attr('stroke', '#020617')
        .attr('stroke-width', 1.5);

      // Label on hover/node
      threatNodeGroup
        .append('text')
        .text(`${threat.location.city} (${threat.ipAddress})`)
        .attr('x', 9)
        .attr('y', 3)
        .attr('font-size', '9px')
        .attr('font-family', 'ui-monospace, monospace')
        .attr('font-weight', '700')
        .attr('fill', '#fca5a5')
        .attr('opacity', 0.85);
    });

    // Prophet Sanctuary Node (Destination)
    const sanctuaryGroup = svg
      .append('g')
      .attr('transform', `translate(${sanctuaryCoords[0]}, ${sanctuaryCoords[1]})`);

    sanctuaryGroup
      .append('circle')
      .attr('r', 16)
      .attr('fill', 'rgba(6, 182, 212, 0.15)')
      .attr('stroke', '#06b6d4')
      .attr('stroke-width', 1.5)
      .append('animate')
      .attr('attributeName', 'r')
      .attr('values', '10;22;10')
      .attr('dur', '2s')
      .attr('repeatCount', 'indefinite');

    sanctuaryGroup
      .append('circle')
      .attr('r', 6)
      .attr('fill', '#10b981')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 2);

    sanctuaryGroup
      .append('text')
      .text('SANCTUARY GATEWAY (142.250.190.46)')
      .attr('x', 14)
      .attr('y', 4)
      .attr('font-size', '10px')
      .attr('font-family', 'ui-monospace, monospace')
      .attr('font-weight', '800')
      .attr('fill', '#38bdf8');
  }, [threatLogs]);

  // Render D3 Threat Activity Histogram over Time
  useEffect(() => {
    if (!d3TimelineRef.current || threatLogs.length === 0) return;

    const svg = d3.select(d3TimelineRef.current);
    svg.selectAll('*').remove();

    const width = 800;
    const height = 120;
    const margin = { top: 15, right: 20, bottom: 25, left: 35 };

    // Group threats by 30-minute intervals or recent bins
    const threatTypes: string[] = Array.from(new Set(threatLogs.map((t) => String(t.threatType))));
    const countsByType: { type: string; count: number }[] = threatTypes.map((type) => {
      const count = threatLogs.filter((t) => t.threatType === type).length;
      return { type, count };
    });

    const x = d3
      .scaleBand<string>()
      .domain(countsByType.map((d) => d.type))
      .range([margin.left, width - margin.right])
      .padding(0.35);

    const maxCount = d3.max(countsByType, (d) => d.count) || 1;
    const y = d3
      .scaleLinear()
      .domain([0, maxCount + 1])
      .range([height - margin.bottom, margin.top]);

    // X axis
    svg
      .append('g')
      .attr('transform', `translate(0, ${height - margin.bottom})`)
      .call(
        d3
          .axisBottom(x)
          .tickFormat((d) => d.replace(/_/g, ' ').slice(0, 14))
      )
      .selectAll('text')
      .attr('font-size', '9px')
      .attr('font-family', 'ui-monospace, monospace')
      .attr('fill', '#94a3b8');

    // Y axis
    svg
      .append('g')
      .attr('transform', `translate(${margin.left}, 0)`)
      .call(d3.axisLeft(y).ticks(3))
      .selectAll('text')
      .attr('font-size', '9px')
      .attr('font-family', 'ui-monospace, monospace')
      .attr('fill', '#94a3b8');

    // Bars
    svg
      .selectAll('.bar')
      .data(countsByType)
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('x', (d) => x(d.type) ?? 0)
      .attr('y', (d) => y(d.count))
      .attr('width', x.bandwidth())
      .attr('height', (d) => height - margin.bottom - y(d.count))
      .attr('rx', 4)
      .attr('fill', (d, i) => (i % 2 === 0 ? '#ef4444' : '#f59e0b'))
      .attr('opacity', 0.85);

    // Value Labels
    svg
      .selectAll('.label')
      .data(countsByType)
      .enter()
      .append('text')
      .text((d) => `${d.count} blocked`)
      .attr('x', (d) => (x(d.type) ?? 0) + x.bandwidth() / 2)
      .attr('y', (d) => y(d.count) - 4)
      .attr('text-anchor', 'middle')
      .attr('font-size', '9px')
      .attr('font-family', 'ui-monospace, monospace')
      .attr('font-weight', '700')
      .attr('fill', '#f8fafc');
  }, [threatLogs]);

  // Test Tamper Simulation
  const handleRunSimulation = async (simType: 'unauthorized_domain' | 'hardware_mismatch' | 'binary_tamper') => {
    setSimulatingThreat(true);
    setActionNotice('Injecting simulated rogue heartbeat payload to test automated lockdown and email alert delivery...');
    try {
      await heartbeatSecurityManager.simulateTamperTest(simType);
      await loadThreatLogs();
      setActionNotice('✓ Simulated attack blocked! Threat report automatically dispatched to juhnkrix.musika@gmail.com.');
    } catch (err: any) {
      setActionNotice(`Simulation notice: ${err?.message}`);
    } finally {
      setSimulatingThreat(false);
      setTimeout(() => setActionNotice(null), 6000);
    }
  };

  // Export Threat Log Data
  const exportThreatDossier = (format: 'json' | 'csv') => {
    if (format === 'json') {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(threatLogs, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `JUHNKRIX_CYBER_THREAT_DOSSIER_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } else {
      const headers = ['ID', 'Timestamp', 'HardwareID', 'IP', 'Domain', 'ThreatType', 'Severity', 'Country', 'City', 'DispatchedTo', 'ReceiptID'];
      const rows = threatLogs.map((t) => [
        t.id,
        `"${t.timestamp}"`,
        `"${t.hardwareId}"`,
        t.ipAddress,
        `"${t.domain}"`,
        t.threatType,
        t.severity,
        `"${t.location.country}"`,
        `"${t.location.city}"`,
        t.dispatchedTo,
        t.dispatchReceiptId
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `JUHNKRIX_CYBER_THREAT_LOGS_${Date.now()}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
    setActionNotice(`✓ Threat intelligence dossier exported successfully (${format.toUpperCase()}).`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  // Copy Hardware ID
  const copyHwId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedHwId(id);
    setTimeout(() => setCopiedHwId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards & High-Level Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Blocked */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-rose-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Blocked Threats</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 font-mono">{threatLogs.length}</div>
          <div className="text-[11px] text-slate-400 font-mono mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
            100% Intercept Rate
          </div>
        </div>

        {/* Encrypted Heartbeat Status */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Heartbeat Security</span>
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          </div>
          <div className="text-lg font-bold text-cyan-300 font-mono">
            {heartbeatState.status === 'HEALTHY' ? 'Pinging (25s)' : heartbeatState.status}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Latency: {heartbeatState.lastPingDurationMs}ms • Pings: {heartbeatState.successfulPings}
          </div>
        </div>

        {/* Automated Dispatch Target */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Auto Threat Report</span>
            <Send className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xs font-bold text-amber-300 font-mono truncate">
            juhnkrix.musika@gmail.com
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            Instant Email Pipeline Active
          </div>
        </div>

        {/* Bound Hardware Fingerprint */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/40 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 font-mono text-xs mb-1">
            <span>Active Physical Node</span>
            <Fingerprint className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xs font-bold text-emerald-300 font-mono truncate select-all">
            {heartbeatState.activeHardwareId}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">
            Physical 1-to-1 Altar Bound
          </div>
        </div>
      </div>

      {actionNotice && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 rounded-xl bg-slate-900 border border-cyan-500/50 text-xs font-mono text-cyan-200 flex items-center justify-between gap-3 shadow-md"
        >
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400 animate-pulse flex-shrink-0" />
            <span>{actionNotice}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionNotice(null)}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}

      {/* D3 Geographic Threat Vector & Timeline Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* D3 Map Vector Canvas */}
        <div className="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-cyan-400" />
                Global Threat Interception Matrix (D3 Geo Arcs)
              </h3>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                Real-time attack vector trajectories converging into Sanctuary Gateway Node
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-rose-500/20 text-rose-300 border border-rose-500/40">
                Pulsing: Blocked Attackers
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                Center: Sanctuary Node
              </span>
            </div>
          </div>

          <div className="w-full overflow-hidden rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center p-2 relative">
            <svg
              ref={d3MapRef}
              viewBox="0 0 800 360"
              className="w-full h-auto max-h-[380px] drop-shadow-md select-none"
            />
          </div>
        </div>

        {/* D3 Histogram & Threat Classification Breakdown */}
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4">
          <div>
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-amber-400" />
                Attack Vector Classification
              </h3>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                Distribution of blocked threats by vector
              </p>
            </div>

            <div className="w-full overflow-hidden rounded-xl bg-slate-950 border border-slate-800 p-2 my-3">
              <svg
                ref={d3TimelineRef}
                viewBox="0 0 800 120"
                className="w-full h-auto select-none"
              />
            </div>
          </div>

          {/* Quick Simulation Testing Sandbox */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-rose-500/30 space-y-2.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-rose-300 font-bold flex items-center gap-1.5">
                <Crosshair className="w-3.5 h-3.5 text-rose-400" />
                Test Threat Simulation Engine
              </span>
              <span className="text-[10px] text-slate-400">Prophet Sandbox</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Simulates illegal clone or spoofing to verify instant lockdown and automated report delivery:
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                type="button"
                disabled={simulatingThreat}
                onClick={() => handleRunSimulation('unauthorized_domain')}
                className="px-2.5 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-200 text-[11px] font-bold cursor-pointer transition-all"
              >
                Rogue Domain
              </button>
              <button
                type="button"
                disabled={simulatingThreat}
                onClick={() => handleRunSimulation('hardware_mismatch')}
                className="px-2.5 py-1.5 rounded-lg bg-amber-950/60 hover:bg-amber-900 border border-amber-500/40 text-amber-200 text-[11px] font-bold cursor-pointer transition-all"
              >
                Farm HW Spoof
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Blocked Malicious Access Attempts Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
        {/* Table Controls */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-rose-400" />
              Blocked Malicious Access Attempts Audit Log
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Specific device hardware IDs, IP addresses, geolocations, and automated reports
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search HW ID, IP, Country..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-400 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none"
              />
            </div>

            {/* Filter */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
            >
              <option value="ALL">All Threat Types</option>
              <option value="UNAUTHORIZED_DOMAIN">Unauthorized Domain</option>
              <option value="HARDWARE_ID_MISMATCH">Hardware Mismatch</option>
              <option value="TAMPERED_CHECKSUM">Tampered Checksum</option>
              <option value="PIRATED_CLONE">Pirated Clone</option>
              <option value="UNAUTHORIZED_ADMIN_SIGNATURE">Unauthorized Signature</option>
            </select>

            {/* Export Buttons */}
            <button
              type="button"
              onClick={() => exportThreatDossier('csv')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium cursor-pointer transition-all border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>CSV</span>
            </button>
            <button
              type="button"
              onClick={() => exportThreatDossier('json')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium cursor-pointer transition-all border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>JSON</span>
            </button>
            <button
              type="button"
              onClick={loadThreatLogs}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer border border-slate-700"
              title="Refresh Threat Logs"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/40">
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Device Hardware ID</th>
                <th className="py-3 px-3">IP Address</th>
                <th className="py-3 px-3">Origin / Domain</th>
                <th className="py-3 px-3">Geolocation & Timestamp</th>
                <th className="py-3 px-3">Threat Vector</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredThreats.length > 0 ? (
                filteredThreats.map((threat) => (
                  <tr key={threat.id} className="hover:bg-slate-800/40 transition-colors">
                    {/* Status */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-500/20 text-rose-300 border border-rose-500/40">
                        <Lock className="w-2.5 h-2.5" /> BLOCKED
                      </span>
                    </td>

                    {/* Hardware ID with copy */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-white font-bold select-all">{threat.hardwareId}</span>
                        <button
                          type="button"
                          onClick={() => copyHwId(threat.hardwareId)}
                          className="text-slate-500 hover:text-cyan-400 cursor-pointer"
                          title="Copy Hardware ID"
                        >
                          {copiedHwId === threat.hardwareId ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-500 block truncate max-w-[200px]">
                        {threat.deviceFingerprint.platform}
                      </span>
                    </td>

                    {/* IP Address */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="text-cyan-300 font-bold select-all">{threat.ipAddress}</span>
                    </td>

                    {/* Domain */}
                    <td className="py-3 px-3 text-slate-300 max-w-xs truncate">
                      <span className="text-rose-300/90 font-medium">{threat.domain}</span>
                    </td>

                    {/* Geolocation & Timestamp */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="text-white font-medium">
                        {threat.location.city}, {threat.location.country}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(threat.timestamp).toLocaleString()}
                      </div>
                    </td>

                    {/* Threat Vector */}
                    <td className="py-3 px-3">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {threat.threatType.replace(/_/g, ' ')}
                      </span>
                      <p className="text-[10px] text-slate-400 truncate max-w-xs mt-0.5">
                        {threat.details}
                      </p>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedThreat(threat)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 border border-slate-700 text-[11px] font-bold cursor-pointer transition-all"
                      >
                        Inspect Dossier
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 font-mono text-xs">
                    {searchQuery || filterType !== 'ALL'
                      ? 'No blocked threat entries match the search filter.'
                      : 'No malicious access attempts recorded. Sanctuary perimeter intact.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Threat Inspection Dossier Modal */}
      <AnimatePresence>
        {selectedThreat && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border-2 border-rose-500/60 rounded-3xl p-6 shadow-2xl text-slate-100 font-sans"
            >
              {/* Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-400 flex items-center justify-center text-rose-400 shadow-md">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      Blocked Threat Intelligence Dossier
                    </h2>
                    <p className="text-xs text-rose-300 font-mono">
                      Incident ID: {selectedThreat.id} • Status: PERMANENTLY BLOCKED
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedThreat(null)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Automated Dispatch Receipt Banner */}
              <div className="my-4 p-3.5 rounded-2xl bg-amber-950/50 border border-amber-500/40 text-xs font-mono space-y-1">
                <div className="flex items-center justify-between text-amber-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-amber-400" />
                    Automated Threat Report Delivery Confirmed
                  </span>
                  <span>Receipt: {selectedThreat.dispatchReceiptId}</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Target Recipient: <strong className="text-white">{selectedThreat.dispatchedTo}</strong> • Transmitted automatically upon heartbeat violation.
                </p>
              </div>

              {/* Threat Technical Details */}
              <div className="space-y-3 text-xs font-mono">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Device Hardware ID:</span>
                    <span className="text-white font-bold select-all">{selectedThreat.hardwareId}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Source IP Address:</span>
                    <span className="text-cyan-300 font-bold select-all">{selectedThreat.ipAddress}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Attempted Domain / Host:</span>
                    <span className="text-rose-300 font-bold">{selectedThreat.domain}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block mb-1">Geolocation:</span>
                    <span className="text-emerald-300">
                      {selectedThreat.location.city}, {selectedThreat.location.country} ({selectedThreat.location.timezone})
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-slate-400 block">Threat Classification & Vector:</span>
                  <span className="text-amber-400 font-bold block">{selectedThreat.threatType}</span>
                  <p className="text-slate-300 text-[11px] leading-relaxed pt-1">
                    {selectedThreat.details}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-[11px]">
                  <span className="text-slate-400 block font-bold">Hardware & Browser Fingerprint:</span>
                  <div className="text-slate-300">Platform: {selectedThreat.deviceFingerprint.platform}</div>
                  <div className="text-slate-300">Resolution: {selectedThreat.deviceFingerprint.screenResolution}</div>
                  {selectedThreat.deviceFingerprint.webglRenderer && (
                    <div className="text-slate-300">GPU: {selectedThreat.deviceFingerprint.webglRenderer}</div>
                  )}
                  <div className="text-slate-400 break-all select-all pt-1 border-t border-slate-800">
                    UserAgent: {selectedThreat.deviceFingerprint.userAgent}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">
                  Node isolated by Sovereign prophetSecurityEngine.
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedThreat(null)}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer transition-all"
                >
                  Close Dossier
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
