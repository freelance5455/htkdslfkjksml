import React from 'react';
import { ArrowLeft, Bookmark, Share2, Bell, Bot, Sun, Moon, User as UserIcon, UserPlus, LogIn } from 'lucide-react';
import { User } from 'firebase/auth';

interface MaterialTopBarProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  savedCount?: number;
  onOpenSaved?: () => void;
  onOpenAlerts?: () => void;
  alertsCount?: number;
  onShareApp?: () => void;
  currentUser?: User | null;
  onOpenAuth?: (tab?: 'signin' | 'register') => void;
  onOpenProfile?: () => void;
  onOpenAiAssistant?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export const MaterialTopBar: React.FC<MaterialTopBarProps> = ({
  title,
  subtitle,
  showBack = false,
  onBack,
  savedCount = 0,
  onOpenSaved,
  onOpenAlerts,
  alertsCount = 0,
  onShareApp,
  currentUser,
  onOpenAuth,
  onOpenProfile,
  onOpenAiAssistant,
  theme = 'dark',
  onToggleTheme
}) => {
  return (
    <div className={`sticky top-0 z-30 backdrop-blur-md border-b shadow-sm transition-all ${
      theme === 'light'
        ? 'bg-white/95 border-slate-200 text-slate-900'
        : 'bg-slate-900/95 border-slate-800/80 text-white'
    }`}>
      {/* Decorative India Tricolor Sub-bar */}
      <div className="h-0.5 w-full flex">
        <div className="h-full flex-1 bg-amber-500" />
        <div className="h-full flex-1 bg-white" />
        <div className="h-full flex-1 bg-emerald-500" />
      </div>

      <div className="px-3 sm:px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-2.5 min-w-0">
          {showBack && (
            <button
              id="btn-topbar-back"
              onClick={onBack}
              className={`p-1.5 -ml-1 rounded-full transition-colors active:scale-95 ${
                theme === 'light'
                  ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="Return to Home"
              aria-label="Back to Home"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div className="relative shrink-0">
            <img
              src="/india-job-hub-logo.png"
              alt="India Job Hub Logo"
              width={56}
              height={56}
              className={`w-[56px] h-[56px] min-w-[56px] min-h-[56px] rounded-xl object-contain shadow-sm cursor-pointer transition-transform active:scale-95 ${
                theme === 'light'
                  ? 'bg-white p-1 border border-slate-200/90 shadow-slate-200/60'
                  : 'bg-slate-900/90 p-1 border border-slate-700/80 shadow-slate-950/80 ring-1 ring-white/10'
              }`}
              referrerPolicy="no-referrer"
              onClick={onBack}
            />
          </div>

          <div className="truncate min-w-0">
            <h1 className={`text-base sm:text-lg font-bold tracking-tight truncate flex items-center gap-1.5 ${
              theme === 'light' ? 'text-slate-900' : 'text-white'
            }`}>
              <span>India Job Hub</span>
            </h1>
            {subtitle && (
              <p className={`text-[11px] truncate leading-none mt-0.5 ${
                theme === 'light' ? 'text-slate-500' : 'text-slate-400'
              }`}>
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center space-x-1 sm:space-x-1.5 shrink-0">
          {/* AI Assistant Quick Trigger */}
          {onOpenAiAssistant && (
            <button
              id="btn-topbar-ai"
              onClick={onOpenAiAssistant}
              className="relative p-2 rounded-full text-indigo-400 hover:bg-indigo-500/10 transition-colors"
              title="AI Job Assistant"
              aria-label="AI Job Assistant"
            >
              <Bot className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
            </button>
          )}

          {/* Theme Toggle (Requirement 13) */}
          {onToggleTheme && (
            <button
              id="btn-topbar-theme-toggle"
              onClick={onToggleTheme}
              className={`p-2 rounded-full transition-colors ${
                theme === 'light'
                  ? 'text-amber-600 hover:bg-slate-100'
                  : 'text-amber-400 hover:bg-slate-800'
              }`}
              title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          )}

          {/* Personalized Job Alerts */}
          {onOpenAlerts && (
            <button
              id="btn-topbar-alerts"
              onClick={onOpenAlerts}
              className={`relative p-2 rounded-full transition-colors ${
                theme === 'light'
                  ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="Personalized Job Alerts"
              aria-label="Job Alerts"
            >
              <Bell className="w-4 h-4 text-indigo-400" />
              {alertsCount > 0 && (
                <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-indigo-600 text-white text-[9px] font-bold flex items-center justify-center animate-pulse">
                  {alertsCount}
                </span>
              )}
            </button>
          )}

          {/* Saved Jobs */}
          {onOpenSaved && (
            <button
              id="btn-topbar-saved"
              onClick={onOpenSaved}
              className={`relative p-2 rounded-full transition-colors ${
                theme === 'light'
                  ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="Saved Jobs"
              aria-label="Saved Jobs"
            >
              <Bookmark className="w-4 h-4" />
              {savedCount > 0 && (
                <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-amber-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </button>
          )}

          {/* App Share */}
          {onShareApp && (
            <button
              id="btn-topbar-share"
              onClick={onShareApp}
              className={`p-2 rounded-full transition-colors ${
                theme === 'light'
                  ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="Share App"
              aria-label="Share App"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}

          {/* User Account / Profile button (Requirement 5) */}
          {currentUser ? (
            <button
              id="btn-topbar-user-profile"
              onClick={onOpenProfile}
              className="p-1 rounded-full hover:ring-2 hover:ring-indigo-500 transition-all ml-1"
              title={`Logged in as ${currentUser.displayName || currentUser.email}`}
            >
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || 'User'}
                  className="w-7 h-7 rounded-full object-cover border border-indigo-500/50"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center border border-indigo-400/50">
                  {(currentUser.displayName || currentUser.email || 'U').charAt(0).toUpperCase()}
                </div>
              )}
            </button>
          ) : (
            <div className="flex items-center gap-1 ml-1">
              {onOpenProfile && (
                <button
                  id="btn-topbar-user-profile-guest"
                  onClick={onOpenProfile}
                  className={`p-1.5 rounded-full transition-colors ${
                    theme === 'light'
                      ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title="Guest Account / Profile"
                  aria-label="Account / Profile"
                >
                  <UserIcon className="w-4 h-4" />
                </button>
              )}
              <button
                id="btn-topbar-user-register"
                onClick={() => onOpenAuth?.('register')}
                className="flex items-center gap-1 px-2 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition-all shadow-sm active:scale-95"
                title="Register with Email OTP"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Register</span>
              </button>
              <button
                id="btn-topbar-user-login"
                onClick={() => onOpenAuth?.('signin')}
                className="flex items-center gap-1 px-2 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold transition-all shadow-sm active:scale-95"
                title="Sign In with existing account"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
