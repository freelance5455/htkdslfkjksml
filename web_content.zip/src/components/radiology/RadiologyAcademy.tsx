import React, { useState } from 'react';
import { RADIOLOGY_LESSONS } from '../../data/radiologyCurriculum';
import { RadiologyLesson, Language, HunterRank } from '../../types';
import { soundManager } from '../../utils/audio';
import { 
  Zap, 
  Layers, 
  Magnet, 
  Activity, 
  ShieldAlert, 
  ShieldCheck, 
  Radio, 
  CheckCircle, 
  HelpCircle, 
  Award, 
  Clock, 
  AlertTriangle,
  BookOpen,
  Volume2
} from 'lucide-react';
import { speakText } from '../../utils/speech';

interface Props {
  language: Language;
  soundEnabled: boolean;
  completedLessonIds: string[];
  userRank: HunterRank;
  onCompleteLesson: (lessonId: string, xpReward: number) => void;
}

export const RadiologyAcademy: React.FC<Props> = ({
  language,
  soundEnabled,
  completedLessonIds,
  userRank,
  onCompleteLesson
}) => {
  const [selectedLesson, setSelectedLesson] = useState<RadiologyLesson>(RADIOLOGY_LESSONS[0]);
  const [selectedQuizAnswer, setSelectedQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [quizFeedback, setQuizFeedback] = useState<{ isCorrect: boolean; explanation: string } | null>(null);

  const isCompleted = completedLessonIds.includes(selectedLesson.id);

  const handleSelectLesson = (lesson: RadiologyLesson) => {
    setSelectedLesson(lesson);
    setSelectedQuizAnswer(null);
    setQuizSubmitted(false);
    setQuizFeedback(null);
    soundManager.playTick(soundEnabled);
  };

  const handleQuizSubmit = () => {
    if (selectedQuizAnswer === null || !selectedLesson.scenarioQuiz) return;
    const isCorrect = selectedQuizAnswer === selectedLesson.scenarioQuiz.correctIndex;
    setQuizSubmitted(true);
    setQuizFeedback({
      isCorrect,
      explanation: language === 'ar' ? selectedLesson.scenarioQuiz.explanationAr : selectedLesson.scenarioQuiz.explanationFr
    });

    if (isCorrect) {
      soundManager.playSuccess(soundEnabled);
      if (!isCompleted) {
        onCompleteLesson(selectedLesson.id, selectedLesson.xpReward);
      }
    } else {
      soundManager.playError(soundEnabled);
    }
  };

  const handleSpeakInstruction = () => {
    if (selectedLesson.technicalParams?.patientInstructionAr) {
      speakText(selectedLesson.technicalParams.patientInstructionAr, 'ar');
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Academy Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-rose-950 p-5 rounded-2xl border border-purple-500/40 shadow-neon-purple text-right">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-100 flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-400" />
              <span>أكاديمية تقنيات الأشعة والتصوير الطبي (Radiologie MIM)</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              منهاج معتمد لطلبة الشبه طبي في الجزائر: فيزياء الأشعة، تشغيل الأجهزة، الحماية من الإشعاع، والإسقاطات الشعاعية.
            </p>
          </div>

          {/* Academic Badge */}
          <div className="bg-purple-900/60 border border-purple-400/50 px-3.5 py-1.5 rounded-xl text-xs font-bold text-purple-200">
            برنامج المعاهد الوطنية للباراميديكال (INFSPM DZ)
          </div>
        </div>

        {/* Prominent Medical Educational Disclaimer */}
        <div className="mt-4 flex items-start gap-2 bg-rose-950/40 border border-rose-500/40 rounded-xl p-3 text-[11px] text-rose-200 leading-relaxed">
          <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
          <span>
            <strong>تنويه تعليمي هام: </strong> 
            هذا المحتوى مقدم حصرياً لأغراض التعليم الطبي لطلبة الباراميديكال والمناورين في التصوير الطبي. لا يُعتبر هذا التطبيق مرجعاً لتشخيص الحالات المرضية الحقيقية أو إعطاء استشارات علاجية.
          </span>
        </div>
      </div>

      {/* Main Grid: Lessons Selector on Left/Top + Active Lesson Display */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Lesson Navigation List */}
        <div className="lg:col-span-4 flex flex-col gap-2.5">
          <h3 className="text-xs font-bold text-purple-400 uppercase tracking-wider px-1">
            وحدات التدريب الشعاعي ({RADIOLOGY_LESSONS.length})
          </h3>

          <div className="flex flex-col gap-2">
            {RADIOLOGY_LESSONS.map((lesson) => {
              const isCurrent = selectedLesson.id === lesson.id;
              const done = completedLessonIds.includes(lesson.id);

              return (
                <button
                  key={lesson.id}
                  onClick={() => handleSelectLesson(lesson)}
                  className={`w-full text-right p-3.5 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                    isCurrent
                      ? 'bg-purple-950/80 border-purple-400 shadow-neon-purple'
                      : 'bg-slate-950/70 border-purple-900/40 hover:bg-slate-900 text-slate-300'
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-purple-300 font-tech">
                        {lesson.category.toUpperCase()}
                      </span>
                      {done && (
                        <span className="flex items-center gap-0.5 text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800">
                          <CheckCircle className="w-3 h-3" /> تم الإنجاز
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-bold text-slate-100 leading-snug">
                      {language === 'ar' ? lesson.titleAr : lesson.titleFr}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {lesson.readingMinutes} د
                      </span>
                      <span className="text-yellow-400 font-bold font-mono">
                        +{lesson.xpReward} XP
                      </span>
                    </p>
                  </div>

                  <div className={`p-2 rounded-lg ${isCurrent ? 'bg-purple-600 text-white' : 'bg-slate-900 text-purple-400'}`}>
                    <BookOpen className="w-4 h-4" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Lesson Details */}
        <div className="lg:col-span-8 flex flex-col gap-5 bg-slate-950/80 p-5 rounded-2xl border border-purple-900/40 text-right">
          {/* Lesson Header */}
          <div className="border-b border-purple-900/40 pb-4">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="px-3 py-1 bg-purple-900/60 border border-purple-500/50 text-purple-200 text-xs font-bold rounded-lg font-mono">
                {selectedLesson.category.toUpperCase()}
              </span>

              <div className="flex items-center gap-2">
                <span className="text-xs text-yellow-400 font-bold bg-yellow-950/60 border border-yellow-700/50 px-2.5 py-1 rounded-lg">
                  مكافأة الدرس: +{selectedLesson.xpReward} XP
                </span>
                {isCompleted && (
                  <span className="text-xs text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-700/50 px-2.5 py-1 rounded-lg flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> مكتمل
                  </span>
                )}
              </div>
            </div>

            <h2 className="text-lg md:text-xl font-black text-slate-100">
              {language === 'ar' ? selectedLesson.titleAr : selectedLesson.titleFr}
            </h2>
            <p className="text-xs text-purple-300 font-mono mt-0.5">
              FR: {selectedLesson.titleFr} | EN: {selectedLesson.titleEn}
            </p>
            <p className="text-xs text-slate-300 leading-relaxed mt-2.5 bg-black/40 p-3 rounded-xl border border-purple-900/30">
              {language === 'ar' ? selectedLesson.summaryAr : selectedLesson.summaryFr}
            </p>
          </div>

          {/* Sections of the Lesson */}
          <div className="flex flex-col gap-4">
            {selectedLesson.sections.map((sec, idx) => (
              <div key={idx} className="bg-slate-900/60 p-4 rounded-xl border border-purple-900/30">
                <h3 className="text-sm md:text-base font-extrabold text-purple-300 mb-2">
                  {language === 'ar' ? sec.titleAr : sec.titleFr}
                </h3>
                <p className="text-xs md:text-sm text-slate-200 leading-relaxed mb-3">
                  {language === 'ar' ? sec.contentAr : sec.contentFr}
                </p>

                {/* Key Points */}
                <div className="bg-black/50 p-3 rounded-lg border border-purple-900/40">
                  <span className="text-[11px] font-bold text-purple-400 block mb-1.5">
                    النقاط التقنية المحورية:
                  </span>
                  <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                    {sec.keyPoints.map((kp, kIdx) => (
                      <li key={kIdx} className="leading-relaxed">{kp}</li>
                    ))}
                  </ul>
                </div>

                {/* Warning if exists */}
                {sec.warning && (
                  <div className="mt-3 p-2.5 bg-amber-950/40 border border-amber-500/50 rounded-lg text-[11px] text-amber-200 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                    <span>{sec.warning}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Technical Protocol & Patient Communication Box */}
          {selectedLesson.technicalParams && (
            <div className="bg-gradient-to-r from-purple-950/60 to-slate-900/60 p-4 rounded-xl border border-purple-500/30">
              <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-purple-400" />
                <span>بروتوكول الفحص وتوجيه المريض بالدارجة والفرنسية</span>
              </h4>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs mb-3 font-mono">
                {selectedLesson.technicalParams.kv && (
                  <div className="bg-black/60 p-2 rounded-lg border border-purple-900/40">
                    <span className="text-slate-400 block text-[10px]">الجهد (kV):</span>
                    <span className="text-purple-300 font-bold">{selectedLesson.technicalParams.kv}</span>
                  </div>
                )}
                {selectedLesson.technicalParams.mas && (
                  <div className="bg-black/60 p-2 rounded-lg border border-purple-900/40">
                    <span className="text-slate-400 block text-[10px]">الشحنة (mAs):</span>
                    <span className="text-purple-300 font-bold">{selectedLesson.technicalParams.mas}</span>
                  </div>
                )}
                {selectedLesson.technicalParams.distance && (
                  <div className="bg-black/60 p-2 rounded-lg border border-purple-900/40">
                    <span className="text-slate-400 block text-[10px]">المسافة البؤرية:</span>
                    <span className="text-purple-300 font-bold">{selectedLesson.technicalParams.distance}</span>
                  </div>
                )}
                {selectedLesson.technicalParams.grid !== undefined && (
                  <div className="bg-black/60 p-2 rounded-lg border border-purple-900/40">
                    <span className="text-slate-400 block text-[10px]">شبكة بوكي:</span>
                    <span className="text-emerald-400 font-bold">
                      {selectedLesson.technicalParams.grid ? 'مستعملة (Grille +)' : 'بدون شبكة'}
                    </span>
                  </div>
                )}
              </div>

              {selectedLesson.technicalParams.patientInstructionAr && (
                <div className="bg-black/70 p-3 rounded-lg border border-purple-800/40 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-amber-300 block mb-0.5">
                      عبارة التوجيه للمريض (إعطاء الأمر):
                    </span>
                    <p className="text-xs text-slate-100 font-semibold">
                      « {selectedLesson.technicalParams.patientInstructionAr} »
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                      🇫🇷 {selectedLesson.technicalParams.patientInstructionFr}
                    </p>
                  </div>
                  <button
                    onClick={handleSpeakInstruction}
                    title="نطق التعليمات صوتياً"
                    className="p-2 text-purple-300 hover:text-white bg-purple-900/50 hover:bg-purple-800 rounded-lg transition-colors border border-purple-500/30 flex-shrink-0"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Interactive Scenario Quiz */}
          {selectedLesson.scenarioQuiz && (
            <div className="bg-slate-900/90 p-4 rounded-xl border border-purple-600/50 shadow-neon-purple mt-2">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-black text-purple-300">
                  <Award className="w-4 h-4 text-yellow-400" />
                  <span>تحدي سيناريو الدرس (Quiz Pratique)</span>
                </span>
                <span className="text-[11px] text-yellow-400 font-bold font-mono">
                  +{selectedLesson.xpReward} XP
                </span>
              </div>

              <p className="text-xs md:text-sm text-slate-100 font-bold leading-relaxed mb-3">
                {language === 'ar' ? selectedLesson.scenarioQuiz.questionAr : selectedLesson.scenarioQuiz.questionFr}
              </p>

              <div className="space-y-2 mb-3">
                {selectedLesson.scenarioQuiz.optionsAr.map((opt, oIdx) => {
                  const isSelected = selectedQuizAnswer === oIdx;
                  return (
                    <button
                      key={oIdx}
                      onClick={() => {
                        if (!quizSubmitted) {
                          setSelectedQuizAnswer(oIdx);
                          soundManager.playTick(soundEnabled);
                        }
                      }}
                      disabled={quizSubmitted}
                      className={`w-full text-right p-3 rounded-xl border text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-purple-600/30 border-purple-400 text-white'
                          : 'bg-black/40 border-purple-900/30 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full border border-purple-400/50 flex items-center justify-center text-[10px] font-mono">
                          {oIdx + 1}
                        </span>
                        <span>{language === 'ar' ? opt : selectedLesson.scenarioQuiz!.optionsFr[oIdx]}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {!quizSubmitted ? (
                <button
                  onClick={handleQuizSubmit}
                  disabled={selectedQuizAnswer === null}
                  className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg active:scale-95 disabled:opacity-50"
                >
                  تأكيد الإجابة وحصد نقاط الخبرة
                </button>
              ) : (
                <div className={`p-3 rounded-xl border text-xs leading-relaxed ${
                  quizFeedback?.isCorrect
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200'
                    : 'bg-rose-950/60 border-rose-500 text-rose-200'
                }`}>
                  <div className="font-bold mb-1 flex items-center gap-1.5">
                    {quizFeedback?.isCorrect ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                        <span>إجابة صحيحة خارقة! كسبت {selectedLesson.xpReward} XP</span>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-4 h-4 text-rose-400" />
                        <span>إجابة خاطئة! راجع الشرح العلمي أدناه:</span>
                      </>
                    )}
                  </div>
                  <p>{quizFeedback?.explanation}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
