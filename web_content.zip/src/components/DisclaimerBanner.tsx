import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { ShieldAlert, X } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  const { language } = useApp();
  const t = translations[language];
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-zinc-950/95 border-b border-[#D4AF37]/30 text-amber-100/90 text-xs py-2 px-4 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <p className="leading-relaxed">
            <strong className="font-semibold text-amber-300">
              {language === 'ar' ? 'تنبيه تنظيمي وطبي:' : 'Medical Advisory:'}
            </strong>{' '}
            {t.disclaimerBar}
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-zinc-500 hover:text-amber-300 p-0.5 rounded transition-colors shrink-0"
          title={language === 'ar' ? 'إخفاء التنبيه' : 'Dismiss notice'}
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
