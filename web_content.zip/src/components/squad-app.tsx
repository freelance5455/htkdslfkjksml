"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ActivityItem, EntryDTO, MemberStats, SquadSnapshot } from "@/lib/types";
import { formatAvg, SAGA_ORDER, timeAgo } from "@/lib/palette";
import { Stars } from "@/components/stars";
import { MovieModal, PosterCard, type FriendMark } from "@/components/movie-card";
import { Countdown } from "@/components/countdown";
import { PosterImage } from "@/components/poster";
import { apiFetch, clearToken } from "@/lib/client-session";

type Tab = "catalogo" | "squadra" | "attivita";
type StatusFilter = "all" | "watched" | "watchlist" | "unseen" | "favorites";
type SortKey = "order" | "year-desc" | "rating" | "title";

type Patch = {
  status?: "watched" | "watchlist";
  rating?: number | null;
  review?: string | null;
  favorite?: boolean;
};

type Props = {
  snapshot: SquadSnapshot;
  me: MemberStats;
  activity: ActivityItem[];
};

const STATUS_LABELS: Record<StatusFilter, string> = {
  all: "Tutti",
  watched: "Visti",
  watchlist: "Watchlist",
  unseen: "Da vedere",
  favorites: "Preferiti",
};

const SORT_LABELS: Record<SortKey, string> = {
  order: "Ordine saga",
  "year-desc": "Più recenti",
  rating: "Mio voto",
  title: "Titolo A-Z",
};

const TABS: Array<[Tab, string]> = [
  ["catalogo", "Catalogo"],
  ["squadra", "Squadra"],
  ["attivita", "Attività"],
];

export function SquadApp({ snapshot, me, activity }: Props) {
  const router = useRouter();
  const movies = snapshot.movies;

  const serverMine = useMemo(
    () => snapshot.entries.filter((entry) => entry.memberId === me.id),
    [snapshot.entries, me.id],
  );
  const serverSignature = serverMine.map((entry) => `${entry.movieId}:${entry.updatedAt}`).join("|");

  const [myEntries, setMyEntries] = useState<Record<number, EntryDTO>>(() =>
    Object.fromEntries(serverMine.map((entry) => [entry.movieId, entry])),
  );
  const signatureRef = useRef(serverSignature);

  useEffect(() => {
    if (signatureRef.current !== serverSignature) {
      signatureRef.current = serverSignature;
      setMyEntries(Object.fromEntries(serverMine.map((entry) => [entry.movieId, entry])));
    }
  }, [serverSignature, serverMine]);

  const [tab, setTab] = useState<Tab>("catalogo");
  const [query, setQuery] = useState("");
  const [saga, setSaga] = useState<string>("ALL");
  const [phase, setPhase] = useState<number>(0);
  const [status, setStatus] = useState<StatusFilter>("all");
  const [sort, setSort] = useState<SortKey>("order");
  const [openMovieId, setOpenMovieId] = useState<number | null>(null);
  const [pendingIds, setPendingIds] = useState<number[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(timer);
  }, [toast]);

  const markPending = useCallback((movieId: number, on: boolean) => {
    setPendingIds((prev) => (on ? [...prev, movieId] : prev.filter((id) => id !== movieId)));
  }, []);

  const saveEntry = useCallback(
    async (movieId: number, patch: Patch) => {
      markPending(movieId, true);
      try {
        const response = await apiFetch("/api/entries", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ movieId, ...patch }),
        });
        if (response.status === 401) {
          router.push("/");
          return;
        }
        const data = (await response.json()) as { entry?: EntryDTO; error?: string };
        if (!response.ok || !data.entry) throw new Error(data.error ?? "Errore nel salvataggio");
        setMyEntries((prev) => ({ ...prev, [movieId]: data.entry as EntryDTO }));
        router.refresh();
        window.dispatchEvent(new Event("marvel:refresh"));
      } catch (error) {
        setToast(error instanceof Error ? error.message : "Errore nel salvataggio");
      } finally {
        markPending(movieId, false);
      }
    },
    [markPending, router],
  );

  const removeEntry = useCallback(
    async (movieId: number) => {
      markPending(movieId, true);
      try {
        const response = await apiFetch(`/api/entries?movieId=${movieId}`, { method: "DELETE" });
        if (response.status === 401) {
          router.push("/");
          return;
        }
        if (!response.ok) throw new Error("Errore nella rimozione");
        setMyEntries((prev) => {
          const next = { ...prev };
          delete next[movieId];
          return next;
        });
        setToast("Film rimosso dal tuo profilo");
        router.refresh();
        window.dispatchEvent(new Event("marvel:refresh"));
      } catch (error) {
        setToast(error instanceof Error ? error.message : "Errore nella rimozione");
      } finally {
        markPending(movieId, false);
      }
    },
    [markPending, router],
  );

  const toggleWatchlist = useCallback(
    (movieId: number) => {
      const entry = myEntries[movieId];
      if (entry?.status === "watchlist") {
        const hasContent = (entry.rating ?? 0) > 0 || (entry.review ?? "").trim().length > 0 || entry.favorite;
        if (hasContent) void saveEntry(movieId, { status: "watched" });
        else void removeEntry(movieId);
        return;
      }
      void saveEntry(movieId, { status: "watchlist" });
    },
    [myEntries, removeEntry, saveEntry],
  );

  const friendsByMovie = useMemo(() => {
    const map = new Map<number, FriendMark[]>();
    for (const entry of snapshot.entries) {
      if (entry.memberId === me.id) continue;
      const member = snapshot.members.find((m) => m.id === entry.memberId);
      if (!member) continue;
      const list = map.get(entry.movieId) ?? [];
      list.push({ member, entry });
      map.set(entry.movieId, list);
    }
    return map;
  }, [snapshot.entries, snapshot.members, me.id]);

  const myStats = useMemo(() => {
    const list = Object.values(myEntries);
    const watched = list.filter((entry) => entry.status === "watched");
    const rated = watched.filter((entry) => (entry.rating ?? 0) > 0);
    const avg = rated.length > 0 ? rated.reduce((sum, entry) => sum + (entry.rating ?? 0), 0) / rated.length : null;
    const total = movies.length;
    const mcu = movies.filter((movie) => movie.saga === "MCU");
    const phases = [1, 2, 3, 4, 5, 6].map((phaseNumber) => {
      const phaseMovies = mcu.filter((movie) => movie.phase === phaseNumber);
      const done = phaseMovies.filter((movie) => myEntries[movie.id]?.status === "watched").length;
      return { phase: phaseNumber, done, total: phaseMovies.length };
    });
    const minutes = watched.reduce((sum, entry) => {
      const movie = movies.find((item) => item.id === entry.movieId);
      return sum + (movie?.runtime ?? 0);
    }, 0);
    return {
      watched: watched.length,
      watchlist: list.filter((entry) => entry.status === "watchlist").length,
      favorites: list.filter((entry) => entry.favorite).length,
      reviews: list.filter((entry) => (entry.review ?? "").trim().length > 0).length,
      hours: Math.round(minutes / 60),
      avg,
      total,
      percent: total > 0 ? Math.round((watched.length / total) * 100) : 0,
      phases,
    };
  }, [myEntries, movies]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = movies.filter((movie) => {
      if (saga !== "ALL" && movie.saga !== saga) return false;
      if (phase > 0 && movie.phase !== phase) return false;
      const entry = myEntries[movie.id];
      if (status === "watched" && entry?.status !== "watched") return false;
      if (status === "watchlist" && entry?.status !== "watchlist") return false;
      if (status === "unseen" && entry) return false;
      if (status === "favorites" && !entry?.favorite) return false;
      if (needle && !`${movie.title} ${movie.year}`.toLowerCase().includes(needle)) return false;
      return true;
    });

    const sorted = [...list];
    if (sort === "year-desc") sorted.sort((a, b) => b.year - a.year);
    else if (sort === "title") sorted.sort((a, b) => a.title.localeCompare(b.title, "it"));
    else if (sort === "rating") sorted.sort((a, b) => (myEntries[b.id]?.rating ?? 0) - (myEntries[a.id]?.rating ?? 0));
    else sorted.sort((a, b) => a.sortIndex - b.sortIndex);
    return sorted;
  }, [movies, myEntries, query, saga, phase, status, sort]);

  const leaderboard = useMemo(() => {
    const totalMovies = movies.length || 1;
    return [...snapshot.members]
      .map((member) => ({
        ...member,
        percent: Math.round((member.watched / totalMovies) * 100),
        isMe: member.id === me.id,
      }))
      .sort((a, b) => b.watched - a.watched || (b.avgRating ?? 0) - (a.avgRating ?? 0));
  }, [snapshot.members, movies.length, me.id]);

  const openMovie = openMovieId !== null ? movies.find((movie) => movie.id === openMovieId) ?? null : null;
  const nextUp = useMemo(
    () => movies.find((movie) => movie.saga === "MCU" && !myEntries[movie.id]) ?? null,
    [movies, myEntries],
  );

  async function copyCode(code: string, label: string) {
    try {
      await navigator.clipboard.writeText(code);
      setToast(`${label} copiato: ${code}`);
    } catch {
      setToast(`Copia manuale: ${code}`);
    }
  }

  async function logout() {
    await fetch("/api/session", { method: "DELETE" }).catch(() => undefined);
    clearToken();
    router.push("/");
    router.refresh();
  }

  const activeTabIndex = TABS.findIndex(([key]) => key === tab);

  return (
    <div className="min-h-screen pb-16">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-mv-ink/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-3 py-2.5 sm:px-4">
          <Link href="/squad" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-mv-red font-display text-base text-white shadow-[0_6px_18px_-6px_rgba(230,36,41,0.9)]">
              M
            </span>
            <span className="font-display text-base leading-none tracking-wide text-white">
              Marvel<span className="text-mv-red">Squad</span>
            </span>
          </Link>

          <button
            type="button"
            onClick={() => copyCode(snapshot.squad.code, "Codice squadra")}
            title="Copia il codice per invitare gli amici"
            className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1 transition hover:border-mv-gold/50 hover:bg-mv-gold/10"
          >
            <span className="hidden max-w-[110px] truncate text-[11px] font-bold text-white/70 sm:block">
              {snapshot.squad.name}
            </span>
            <span className="font-mono text-[10px] font-bold tracking-widest text-mv-gold">{snapshot.squad.code}</span>
            <span className="text-[10px] text-white/30">⧉</span>
          </button>

          <div className="ml-auto flex items-center gap-1.5">
            <div className="hidden items-center gap-1 sm:flex">
              {snapshot.members.map((member) => (
                <Link
                  key={member.id}
                  href={`/amici/${member.id}`}
                  title={`${member.name} · ${member.watched} film visti`}
                  className="grid h-7 w-7 place-items-center rounded-full border text-xs transition hover:scale-110"
                  style={{
                    borderColor: member.id === me.id ? member.color : "rgba(255,255,255,0.14)",
                    backgroundColor: `${member.color}22`,
                  }}
                >
                  {member.avatar}
                </Link>
              ))}
            </div>
            <button
              type="button"
              onClick={logout}
              className="cursor-pointer rounded-lg border border-white/12 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white/55 transition hover:border-mv-red/60 hover:text-mv-red"
            >
              Esci
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-3 sm:px-4">
        {/* Countdown compatto */}
        <div className="animate-fade mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-2xl border border-mv-red/25 bg-gradient-to-r from-mv-red/15 via-mv-panel/80 to-mv-panel/40 px-3 py-2">
          <span className="text-sm">⏳</span>
          <p className="text-[11px] font-bold uppercase tracking-widest text-white/70">
            Doomsday <span className="text-white/35">· 18.12.2026</span>
          </p>
          <Countdown compact />
          {nextUp ? (
            <p className="ml-auto hidden text-[10px] text-white/40 sm:block">
              Prossimo da vedere: <span className="text-white/70">{nextUp.title}</span>
            </p>
          ) : null}
        </div>

        {/* Profilo + progressi */}
        <section className="animate-rise mt-3 grid gap-3 lg:grid-cols-[1.35fr_1fr]">
          <div className="comic-panel relative overflow-hidden rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-xl"
                style={{ backgroundColor: `${me.color}26`, color: me.color }}
              >
                {me.avatar}
              </span>
              <div className="min-w-0">
                <p className="font-display text-lg leading-none text-white">{me.name}</p>
                <p className="font-mono text-[9px] tracking-widest text-white/30">{me.code}</p>
              </div>
              <div className="ml-auto text-right">
                <p className="font-display text-2xl leading-none text-mv-gold">{myStats.percent}%</p>
                <p className="text-[9px] uppercase tracking-widest text-white/35">collezione</p>
              </div>
            </div>

            <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-mv-red to-mv-gold transition-all duration-700 ease-out"
                style={{ width: `${Math.max(myStats.percent, 1.5)}%` }}
              />
            </div>

            <div className="mt-3 grid grid-cols-4 gap-1.5">
              {[
                ["Visti", `${myStats.watched}`],
                ["Watchlist", `${myStats.watchlist}`],
                ["Media", formatAvg(myStats.avg)],
                ["Ore", `${myStats.hours}`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-white/8 bg-white/[0.03] px-1.5 py-1.5 text-center">
                  <p className="font-display text-base leading-none text-white">{value}</p>
                  <p className="text-[8px] font-bold uppercase tracking-widest text-white/35">{label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="comic-panel rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Avanzamento per fase</p>
              <p className="text-[10px] text-white/30">
                {myStats.phases.reduce((sum, item) => sum + item.done, 0)}/
                {myStats.phases.reduce((sum, item) => sum + item.total, 0)} MCU
              </p>
            </div>
            <div className="mt-2 grid grid-cols-6 gap-1.5">
              {myStats.phases.map((item) => {
                const percent = item.total > 0 ? (item.done / item.total) * 100 : 0;
                return (
                  <div key={item.phase} className="text-center">
                    <div className="relative mx-auto flex h-14 w-full items-end overflow-hidden rounded-md border border-white/8 bg-white/[0.03]">
                      <div
                        className="w-full rounded-b-md bg-gradient-to-t from-mv-red to-mv-gold/80 transition-all duration-700 ease-out"
                        style={{ height: `${Math.max(percent, 4)}%` }}
                      />
                    </div>
                    <p className="mt-1 text-[9px] font-bold text-white/45">F{item.phase}</p>
                    <p className="text-[8px] text-white/25">
                      {item.done}/{item.total}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Tabs */}
        <nav className="animate-fade relative mt-3 flex rounded-xl border border-white/10 bg-black/40 p-1">
          <span
            className="absolute inset-y-1 rounded-lg bg-mv-red shadow-[0_8px_20px_-10px_rgba(230,36,41,0.9)] transition-all duration-300 ease-out"
            style={{ width: `calc((100% - 8px) / 3)`, left: `calc(4px + (100% - 8px) / 3 * ${activeTabIndex})` }}
          />
          {TABS.map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`relative z-10 flex-1 cursor-pointer rounded-lg px-2 py-1.5 text-[11px] font-black uppercase tracking-widest transition-colors duration-200 ${
                tab === key ? "text-white" : "text-white/45 hover:text-white/80"
              }`}
            >
              {label}
              {key === "catalogo" ? <span className="ml-1 text-[9px] opacity-60">{filtered.length}</span> : null}
              {key === "squadra" ? <span className="ml-1 text-[9px] opacity-60">{snapshot.members.length}</span> : null}
            </button>
          ))}
        </nav>

        {tab === "catalogo" && myStats.watched + myStats.watchlist === 0 ? (
          <div className="animate-rise mt-3 flex items-start gap-2.5 rounded-xl border border-mv-gold/30 bg-mv-gold/8 px-3 py-2.5">
            <span className="text-base">👋</span>
            <p className="text-[11px] leading-relaxed text-white/70">
              <span className="font-bold text-mv-gold">Benvenuto!</span> Tocca la copertina di un film per aprirlo:
              puoi segnarlo come <span className="font-semibold text-white">visto</span>, metterlo nella{" "}
              <span className="font-semibold text-white">watchlist</span>, dargli un voto da 1 a 5 stelle e scrivere una
              recensione. Le stelle sotto ogni copertina sono la tua valutazione rapida.
            </p>
          </div>
        ) : null}

        {tab === "catalogo" ? (
          <section key="catalogo" className="animate-fade mt-3">
            <div className="comic-panel rounded-2xl p-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[160px] flex-1">
                  <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-white/30">
                    🔍
                  </span>
                  <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Cerca un film..."
                    className="w-full rounded-lg border border-white/10 bg-black/40 py-1.5 pl-8 pr-3 text-xs text-white placeholder:text-white/30 transition focus:border-mv-red/60 focus:outline-none"
                  />
                </div>
                <select
                  value={sort}
                  onChange={(event) => setSort(event.target.value as SortKey)}
                  className="cursor-pointer rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-[11px] font-semibold text-white/70 focus:border-mv-red/60 focus:outline-none"
                >
                  {(Object.keys(SORT_LABELS) as SortKey[]).map((key) => (
                    <option key={key} value={key} className="bg-mv-panel">
                      {SORT_LABELS[key]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="no-scrollbar mt-2 flex items-center gap-1.5 overflow-x-auto pb-0.5">
                {(["all", ...SAGA_ORDER] as string[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setSaga(key);
                      setPhase(0);
                    }}
                    className={`shrink-0 cursor-pointer rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide transition ${
                      saga === key ? "bg-white text-black" : "border border-white/10 text-white/50 hover:text-white"
                    }`}
                  >
                    {key === "all" ? "Tutte" : key}
                  </button>
                ))}
                <span className="mx-0.5 h-3.5 w-px shrink-0 bg-white/10" />
                {(Object.keys(STATUS_LABELS) as StatusFilter[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setStatus(key)}
                    className={`shrink-0 cursor-pointer rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide transition ${
                      status === key ? "bg-mv-red text-white" : "border border-white/10 text-white/50 hover:text-white"
                    }`}
                  >
                    {STATUS_LABELS[key]}
                  </button>
                ))}
                {saga === "MCU" ? (
                  <>
                    <span className="mx-0.5 h-3.5 w-px shrink-0 bg-white/10" />
                    <button
                      type="button"
                      onClick={() => setPhase(0)}
                      className={`shrink-0 cursor-pointer rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide transition ${
                        phase === 0 ? "bg-mv-gold text-black" : "border border-white/10 text-white/50 hover:text-white"
                      }`}
                    >
                      Fasi
                    </button>
                    {[1, 2, 3, 4, 5, 6].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setPhase(value)}
                        className={`shrink-0 cursor-pointer rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide transition ${
                          phase === value ? "bg-mv-gold text-black" : "border border-white/10 text-white/50 hover:text-white"
                        }`}
                      >
                        F{value}
                      </button>
                    ))}
                  </>
                ) : null}
              </div>
            </div>

            {filtered.length === 0 ? (
              <p className="mt-10 text-center text-sm text-white/40">
                Nessun film con questi filtri. Prova a cambiare qualcosa 👀
              </p>
            ) : (
              <div className="mt-3 grid grid-cols-2 gap-x-2.5 gap-y-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                {filtered.map((movie, index) => (
                  <PosterCard
                    key={movie.id}
                    movie={movie}
                    index={index}
                    myEntry={myEntries[movie.id]}
                    friends={friendsByMovie.get(movie.id) ?? []}
                    pending={pendingIds.includes(movie.id)}
                    onOpen={() => setOpenMovieId(movie.id)}
                    onRate={(rating) => saveEntry(movie.id, { rating })}
                    onToggleWatchlist={() => toggleWatchlist(movie.id)}
                    onToggleFavorite={() => saveEntry(movie.id, { favorite: !myEntries[movie.id]?.favorite })}
                  />
                ))}
              </div>
            )}
          </section>
        ) : null}

        {tab === "squadra" ? (
          <section key="squadra" className="animate-fade mt-3 grid gap-3 lg:grid-cols-[1.15fr_1fr]">
            <div className="comic-panel rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl text-white">Classifica</h2>
                <span className="text-[10px] uppercase tracking-widest text-white/30">film visti</span>
              </div>
              <div className="mt-3 space-y-2">
                {leaderboard.map((member, index) => (
                  <div
                    key={member.id}
                    className={`animate-rise flex items-center gap-2.5 rounded-xl border p-2.5 ${
                      member.isMe ? "border-mv-red/40 bg-mv-red/10" : "border-white/8 bg-white/[0.02]"
                    }`}
                    style={{ animationDelay: `${index * 45}ms` }}
                  >
                    <span className="w-5 text-center font-display text-base text-white/40">
                      {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : index + 1}
                    </span>
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-base"
                      style={{ backgroundColor: `${member.color}26`, color: member.color }}
                    >
                      {member.avatar}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <Link
                          href={`/amici/${member.id}`}
                          className="truncate text-xs font-bold text-white hover:text-mv-gold"
                        >
                          {member.name} {member.isMe ? <span className="text-[9px] text-mv-red">(tu)</span> : null}
                        </Link>
                        <span className="shrink-0 text-[11px] font-bold text-white/60">{member.watched}</span>
                      </div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/8">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{ width: `${Math.max(member.percent, 1)}%`, backgroundColor: member.color }}
                        />
                      </div>
                      <div className="mt-0.5 flex flex-wrap gap-2 text-[9px] text-white/35">
                        <span>★ {formatAvg(member.avgRating)}</span>
                        <span>🔖 {member.watchlist}</span>
                        <span>♥ {member.favorites}</span>
                        <span>✍️ {member.reviews}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <div className="comic-panel rounded-2xl p-4">
                <h2 className="font-display text-xl text-white">Invita gli amici</h2>
                <p className="mt-1 text-[11px] leading-relaxed text-white/50">
                  Chi inserisce questo codice entra nella tua squadra e vede tutto.
                </p>
                <button
                  type="button"
                  onClick={() => copyCode(snapshot.squad.code, "Codice squadra")}
                  className="mt-2.5 flex w-full cursor-pointer items-center justify-between gap-3 rounded-xl border border-dashed border-mv-gold/40 bg-mv-gold/5 px-3 py-2.5 transition hover:bg-mv-gold/10 active:scale-[0.99]"
                >
                  <span className="font-mono text-lg font-black tracking-[0.3em] text-mv-gold">
                    {snapshot.squad.code}
                  </span>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-mv-gold/70">Copia</span>
                </button>
              </div>

              <div className="comic-panel rounded-2xl p-4">
                <h2 className="font-display text-xl text-white">La squadra</h2>
                <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
                  {snapshot.members.map((member) => (
                    <Link
                      key={member.id}
                      href={`/amici/${member.id}`}
                      className="flex items-center gap-2.5 rounded-xl border border-white/8 bg-white/[0.02] p-2 transition hover:border-white/25 hover:bg-white/[0.05]"
                    >
                      <span
                        className="grid h-9 w-9 place-items-center rounded-full text-base"
                        style={{ backgroundColor: `${member.color}26`, color: member.color }}
                      >
                        {member.avatar}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-[11px] font-bold text-white">
                          {member.name} {member.id === me.id ? <span className="text-[9px] text-mv-red">(tu)</span> : null}
                        </p>
                        <p className="text-[9px] text-white/40">
                          {member.watched} visti · ★ {formatAvg(member.avgRating)}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </section>
        ) : null}

        {tab === "attivita" ? (
          <section key="attivita" className="animate-fade mt-3 grid gap-3 lg:grid-cols-[1.4fr_1fr]">
            <div className="comic-panel rounded-2xl p-4">
              <h2 className="font-display text-xl text-white">Attività recente</h2>
              <div className="mt-2.5 space-y-1.5">
                {activity.length === 0 ? (
                  <p className="text-xs text-white/40">Ancora nessuna attività. Inizia a segnare i film!</p>
                ) : (
                  activity.map((item, index) => (
                    <div
                      key={item.id}
                      className="animate-rise flex items-start gap-2.5 rounded-xl border border-white/8 bg-white/[0.02] p-2.5"
                      style={{ animationDelay: `${Math.min(index, 12) * 35}ms` }}
                    >
                      <span
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm"
                        style={{ backgroundColor: `${item.memberColor}26`, color: item.memberColor }}
                      >
                        {item.memberAvatar}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[11px] leading-relaxed text-white/75">
                          <span className="font-bold text-white">{item.memberName}</span>{" "}
                          {item.status === "watchlist" ? (
                            <>
                              ha aggiunto <span className="font-semibold text-mv-gold">{item.movieTitle}</span> alla
                              watchlist
                            </>
                          ) : (
                            <>
                              ha valutato <span className="font-semibold text-white">{item.movieTitle}</span>{" "}
                              <span className="text-mv-gold">{"★".repeat(item.rating ?? 0)}</span>
                            </>
                          )}
                        </p>
                        {item.review ? (
                          <p className="mt-0.5 text-[11px] italic leading-relaxed text-white/45">“{item.review}”</p>
                        ) : null}
                        <p className="mt-0.5 text-[9px] uppercase tracking-widest text-white/25">
                          {timeAgo(item.updatedAt)} · {item.movieYear}
                        </p>
                      </div>
                      <PosterImage
                        src={item.moviePoster}
                        palette={item.moviePalette}
                        alt={item.movieTitle}
                        className="hidden h-11 w-8 shrink-0 rounded sm:block"
                        width={100}
                        emojiClassName="text-xs"
                      />
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-3">
              <div className="comic-panel rounded-2xl p-4">
                <h2 className="font-display text-xl text-white">Preferiti</h2>
                <div className="mt-2 space-y-1.5">
                  {Object.values(myEntries).filter((entry) => entry.favorite).length === 0 ? (
                    <p className="text-[11px] text-white/40">Nessun preferito. Tocca ♥ su un film che ami.</p>
                  ) : (
                    Object.values(myEntries)
                      .filter((entry) => entry.favorite)
                      .map((entry) => {
                        const movie = movies.find((item) => item.id === entry.movieId);
                        if (!movie) return null;
                        return (
                          <button
                            key={entry.movieId}
                            type="button"
                            onClick={() => setOpenMovieId(movie.id)}
                            className="flex w-full cursor-pointer items-center gap-2.5 rounded-xl border border-white/8 bg-white/[0.02] p-1.5 text-left transition hover:border-mv-red/40"
                          >
                            <PosterImage
                              src={movie.posterUrl}
                              palette={movie.palette}
                              alt={movie.title}
                              className="h-11 w-8 shrink-0 rounded"
                              width={100}
                              emojiClassName="text-xs"
                            />
                            <div className="min-w-0">
                              <p className="truncate text-[11px] font-bold text-white">{movie.title}</p>
                              <Stars value={entry.rating ?? 0} size="sm" readOnly />
                            </div>
                          </button>
                        );
                      })
                  )}
                </div>
              </div>

              <div className="comic-panel rounded-2xl p-4">
                <h2 className="font-display text-xl text-white">Le tue recensioni</h2>
                <div className="mt-2 space-y-1.5">
                  {Object.values(myEntries).filter((entry) => (entry.review ?? "").trim().length > 0).length === 0 ? (
                    <p className="text-[11px] text-white/40">Scrivi una recensione dal dettaglio di un film.</p>
                  ) : (
                    Object.values(myEntries)
                      .filter((entry) => (entry.review ?? "").trim().length > 0)
                      .slice(0, 6)
                      .map((entry) => {
                        const movie = movies.find((item) => item.id === entry.movieId);
                        if (!movie) return null;
                        return (
                          <div key={entry.movieId} className="rounded-xl border border-white/8 bg-white/[0.02] p-2.5">
                            <div className="flex items-center justify-between gap-2">
                              <p className="truncate text-[11px] font-bold text-white">{movie.title}</p>
                              <Stars value={entry.rating ?? 0} size="sm" readOnly />
                            </div>
                            <p className="mt-0.5 text-[11px] italic text-white/50">“{entry.review}”</p>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </div>
          </section>
        ) : null}
      </main>

      {openMovie ? (
        <MovieModal
          movie={openMovie}
          myEntry={myEntries[openMovie.id]}
          friends={friendsByMovie.get(openMovie.id) ?? []}
          pending={pendingIds.includes(openMovie.id)}
          onClose={() => setOpenMovieId(null)}
          onSave={(patch) => saveEntry(openMovie.id, patch)}
          onRemove={() => removeEntry(openMovie.id)}
        />
      ) : null}

      {toast ? (
        <div className="animate-toast fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-white/15 bg-mv-panel-2 px-4 py-2.5 text-xs font-semibold text-white shadow-2xl">
          {toast}
        </div>
      ) : null}
    </div>
  );
}
