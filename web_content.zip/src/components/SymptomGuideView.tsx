import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  Check,
  X,
  AlertTriangle,
  ShieldAlert,
  Clock,
  RotateCcw,
  HeartPulse,
  Stethoscope,
  Activity,
  ArrowLeft,
  AlertCircle,
  HelpCircle,
  FileCheck2,
  Languages,
  ChevronRight,
} from 'lucide-react';
import {
  SymptomItem,
  SymptomCategory,
  SymptomAnalysisResult,
  UrgencyLevel,
  PreferredLanguage,
} from '../types';
import {
  COMMON_SYMPTOMS,
  SYMPTOM_CATEGORIES_TRANSLATIONS,
  URGENCY_LEVEL_TRANSLATIONS,
  SYMPTOM_GUIDE_UI_TRANSLATIONS,
} from '../data/symptomGuideData';
import { analyzeSymptoms } from '../services/symptomGuideService';
import { useAuth } from '../context/AuthContext';
import { ReadAloudButton } from './ReadAloudButton';

const CATEGORIES: ('All' | SymptomCategory)[] = [
  'All',
  'General & Constitutional',
  'Respiratory & Throat',
  'Head & Neurological',
  'Digestive & Abdominal',
  'Chest & Cardiovascular',
  'Musculoskeletal',
  'Skin & Allergies',
];

interface SymptomGuideViewProps {
  language?: PreferredLanguage;
  onLanguageChange?: (lang: PreferredLanguage) => void;
  onBack?: () => void;
}

export const SymptomGuideView: React.FC<SymptomGuideViewProps> = ({
  language: propLanguage,
  onLanguageChange,
}) => {
  const { user, updateHealthProfile } = useAuth();

  // Determine current active language from prop, auth context, or localStorage
  const getInitialLanguage = (): PreferredLanguage => {
    if (propLanguage) return propLanguage;
    const saved = localStorage.getItem('preferred_language') as PreferredLanguage;
    if (saved === 'English' || saved === 'Hindi' || saved === 'Marathi') {
      return saved;
    }
    if (user?.healthProfile?.preferredLanguage) {
      return user.healthProfile.preferredLanguage;
    }
    return 'English';
  };

  const [currentLanguage, setCurrentLanguage] = useState<PreferredLanguage>(getInitialLanguage);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | SymptomCategory>('All');
  const [analysisResult, setAnalysisResult] = useState<SymptomAnalysisResult | null>(null);

  // Synchronize when propLanguage or user.healthProfile.preferredLanguage changes externally
  useEffect(() => {
    if (propLanguage && propLanguage !== currentLanguage) {
      setCurrentLanguage(propLanguage);
    } else if (
      !propLanguage &&
      user?.healthProfile?.preferredLanguage &&
      user.healthProfile.preferredLanguage !== currentLanguage
    ) {
      setCurrentLanguage(user.healthProfile.preferredLanguage);
    }
  }, [propLanguage, user?.healthProfile?.preferredLanguage]);

  // Handle switching language in Symptom Guide
  const handleLanguageSwitch = (newLang: PreferredLanguage) => {
    setCurrentLanguage(newLang);
    localStorage.setItem('preferred_language', newLang);
    if (updateHealthProfile) {
      updateHealthProfile({ preferredLanguage: newLang });
    }
    if (onLanguageChange) {
      onLanguageChange(newLang);
    }

    // If analysis result is already displayed, dynamically refresh it in the new language
    if (analysisResult) {
      const refreshed = analyzeSymptoms(analysisResult.selectedSymptoms, newLang);
      setAnalysisResult(refreshed);
    }
  };

  const t = SYMPTOM_GUIDE_UI_TRANSLATIONS[currentLanguage] || SYMPTOM_GUIDE_UI_TRANSLATIONS.English;

  // Multi-lingual search and category filtering
  const filteredSymptoms = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return COMMON_SYMPTOMS.filter((s) => {
      const matchesSearch =
        q === '' ||
        s.name.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        (s.nameTranslations?.English && s.nameTranslations.English.toLowerCase().includes(q)) ||
        (s.nameTranslations?.Hindi && s.nameTranslations.Hindi.toLowerCase().includes(q)) ||
        (s.nameTranslations?.Marathi && s.nameTranslations.Marathi.toLowerCase().includes(q)) ||
        (s.descriptionTranslations?.English && s.descriptionTranslations.English.toLowerCase().includes(q)) ||
        (s.descriptionTranslations?.Hindi && s.descriptionTranslations.Hindi.toLowerCase().includes(q)) ||
        (s.descriptionTranslations?.Marathi && s.descriptionTranslations.Marathi.toLowerCase().includes(q));

      const matchesCat = selectedCategory === 'All' || s.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [searchQuery, selectedCategory]);

  const selectedSymptomsList = useMemo(() => {
    return COMMON_SYMPTOMS.filter((s) => selectedIds.includes(s.id));
  }, [selectedIds]);

  const toggleSymptom = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const removeSymptom = (id: string) => {
    setSelectedIds((prev) => prev.filter((item) => item !== id));
  };

  const clearAllSymptoms = () => {
    setSelectedIds([]);
    setAnalysisResult(null);
  };

  const handleAnalyze = () => {
    if (selectedSymptomsList.length === 0) return;
    const result = analyzeSymptoms(selectedSymptomsList, currentLanguage);
    setAnalysisResult(result);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEditSymptoms = () => {
    setAnalysisResult(null);
  };

  const getUrgencyBadgeStyle = (level: UrgencyLevel) => {
    switch (level) {
      case 'Urgent medical attention':
        return {
          bg: 'bg-rose-50 border-rose-200 text-rose-800',
          badge: 'bg-rose-600 text-white',
          icon: ShieldAlert,
          iconColor: 'text-rose-600',
          containerBg: 'from-rose-500/10 via-rose-50 to-white border-rose-300',
        };
      case 'Medical consultation recommended':
        return {
          bg: 'bg-amber-50 border-amber-200 text-amber-800',
          badge: 'bg-amber-600 text-white',
          icon: AlertTriangle,
          iconColor: 'text-amber-600',
          containerBg: 'from-amber-500/10 via-amber-50 to-white border-amber-300',
        };
      case 'Low urgency':
      default:
        return {
          bg: 'bg-emerald-50 border-emerald-200 text-emerald-800',
          badge: 'bg-emerald-600 text-white',
          icon: FileCheck2,
          iconColor: 'text-emerald-600',
          containerBg: 'from-emerald-500/10 via-emerald-50 to-white border-emerald-300',
        };
    }
  };

  const getSymptomDisplayName = (sym: SymptomItem): string => {
    return sym.nameTranslations?.[currentLanguage] || sym.name;
  };

  const getSymptomDisplayDescription = (sym: SymptomItem): string => {
    return sym.descriptionTranslations?.[currentLanguage] || sym.description;
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      {/* ======================================================== */}
      {/* LANGUAGE SELECTOR BAR (SYNCHRONIZED APP-WIDE)           */}
      {/* ======================================================== */}
      <div
        id="symptom-guide-language-bar"
        className="flex items-center justify-between bg-white border border-slate-200/90 rounded-2xl p-2 px-3 shadow-2xs"
      >
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
          <Languages className="w-4 h-4 text-teal-600 shrink-0" />
          <span>{t.languageLabel}:</span>
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          {(['English', 'Hindi', 'Marathi'] as PreferredLanguage[]).map((lang) => {
            const isSelected = currentLanguage === lang;
            const label = lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिंदी' : 'मराठी';
            return (
              <button
                key={lang}
                id={`symptom-guide-lang-${lang.toLowerCase()}`}
                type="button"
                onClick={() => handleLanguageSwitch(lang)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-teal-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* If Analysis Result is active, show the localized analysis result screen */}
      {analysisResult ? (
        <div className="space-y-4" id="symptom-analysis-result">
          {/* Top action bar: Edit symptoms / Read Aloud / Start new check */}
          <div className="flex items-center justify-between bg-white border border-slate-200/90 rounded-2xl p-3 shadow-2xs gap-2">
            <button
              onClick={handleEditSymptoms}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-teal-700 transition-colors py-1 px-2.5 rounded-lg hover:bg-slate-100 cursor-pointer shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5 stroke-[2.5]" />
              {t.editSymptoms} ({analysisResult.selectedSymptoms.length})
            </button>
            <div className="flex items-center gap-2">
              <ReadAloudButton
                id="symptom-analysis-read-aloud"
                text={(() => {
                  const localizedUrgencyName =
                    URGENCY_LEVEL_TRANSLATIONS[analysisResult.urgencyLevel]?.[currentLanguage] ||
                    analysisResult.urgencyLevel;
                  const parts: string[] = [];
                  parts.push(`${t.triageLevelLabel}: ${localizedUrgencyName}. ${analysisResult.urgencyReason}`);
                  if (analysisResult.redFlags && analysisResult.redFlags.length > 0) {
                    parts.push(`${t.redFlagsTitle}: ${analysisResult.redFlags.join('. ')}`);
                  }
                  if (analysisResult.possibleConditions && analysisResult.possibleConditions.length > 0) {
                    const condList = analysisResult.possibleConditions
                      .map((c) => `${c.nameTranslations?.[currentLanguage] || c.name}: ${c.descriptionTranslations?.[currentLanguage] || c.description}`)
                      .join('. ');
                    parts.push(`${t.possibleCausesTitle}: ${condList}`);
                  }
                  if (analysisResult.generalSelfCare && analysisResult.generalSelfCare.length > 0) {
                    parts.push(`${t.selfCareTitle}: ${analysisResult.generalSelfCare.join('. ')}`);
                  }
                  if (analysisResult.whenToSeeDoctor) {
                    parts.push(`${t.whenToSeeDoctorTitle}: ${analysisResult.whenToSeeDoctor}`);
                  }
                  if (t.medicalDisclaimer) {
                    parts.push(`${t.medicalDisclaimer}`);
                  }
                  return parts.join('. ');
                })()}
                language={currentLanguage}
                variant="pill"
              />
              <button
                onClick={clearAllSymptoms}
                className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-800 py-1 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                {t.newCheck}
              </button>
            </div>
          </div>

          {/* Selected Symptoms Summary Chips */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-teal-600" />
                {t.evaluatedSymptomsTitle}
              </span>
              <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                {analysisResult.selectedSymptoms.length} {t.selectedCount}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              {analysisResult.selectedSymptoms.map((sym) => (
                <span
                  key={sym.id}
                  className="inline-flex items-center gap-1 text-xs font-medium text-slate-700 bg-slate-100 border border-slate-200/80 px-2.5 py-1 rounded-lg"
                >
                  {getSymptomDisplayName(sym)}
                </span>
              ))}
            </div>
          </div>

          {/* Section B: Urgency Level */}
          {(() => {
            const urgencyStyling = getUrgencyBadgeStyle(analysisResult.urgencyLevel);
            const UrgencyIcon = urgencyStyling.icon;
            const localizedUrgencyName =
              URGENCY_LEVEL_TRANSLATIONS[analysisResult.urgencyLevel]?.[currentLanguage] ||
              analysisResult.urgencyLevel;

            return (
              <div
                className={`p-4 rounded-2xl border bg-gradient-to-b ${urgencyStyling.containerBg} shadow-2xs space-y-2`}
              >
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-xl bg-white shadow-2xs ${urgencyStyling.iconColor}`}>
                    <UrgencyIcon className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">
                      {t.triageLevelLabel}
                    </div>
                    <div className="text-base font-extrabold text-slate-900 leading-tight">
                      {localizedUrgencyName}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
                  {analysisResult.urgencyReason}
                </p>
              </div>
            );
          })()}

          {/* Section C: Red Flags (Emergency Warnings) */}
          {analysisResult.redFlags && analysisResult.redFlags.length > 0 && (
            <div className="bg-white border border-rose-200/80 rounded-2xl p-4 shadow-2xs space-y-2.5">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-3.5 h-3.5 stroke-[2.5]" />
                </div>
                <h3 className="text-xs font-extrabold text-slate-900 tracking-tight uppercase">
                  {t.redFlagsTitle}
                </h3>
              </div>
              <p className="text-[11px] text-slate-500 leading-normal">
                {t.redFlagsSubtitle}
              </p>
              <ul className="space-y-1.5 pt-0.5">
                {analysisResult.redFlags.map((flag, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-slate-800 leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0 mt-1.5" />
                    <span>{flag}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Section A: Possible Causes / Conditions */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs space-y-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                  <Stethoscope className="w-3.5 h-3.5 stroke-[2.5]" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  {t.possibleCausesTitle}
                </h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                {t.possibleCausesSubtitle}
              </p>
            </div>

            {analysisResult.possibleConditions.length > 0 ? (
              <div className="space-y-2.5 pt-1">
                {analysisResult.possibleConditions.map((cond) => (
                  <div
                    key={cond.id}
                    className="p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-slate-900 leading-snug">
                        {cond.nameTranslations?.[currentLanguage] || cond.name}
                      </h4>
                      <span className="text-[10px] font-semibold text-teal-700 bg-teal-50 border border-teal-200/70 px-2 py-0.5 rounded-md shrink-0">
                        {cond.matchingSymptoms.length} {t.matchingCountTag}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {cond.descriptionTranslations?.[currentLanguage] || cond.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-1 pt-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        {t.matchedTag}
                      </span>
                      {cond.matchingSymptoms.map((m, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] font-medium text-slate-700 bg-white border border-slate-200 px-1.5 py-0.5 rounded"
                        >
                          {m}
                        </span>
                      ))}
                    </div>

                    {/* Authoritative Source Reference */}
                    <div className="pt-2 border-t border-slate-200/60 flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] font-bold text-slate-500">
                        {t.verifiedSourcesTag}
                      </span>
                      {cond.sources.map((src, i) => (
                        <span
                          key={i}
                          className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-700 bg-blue-50 border border-blue-200/70 px-1.5 py-0.5 rounded"
                          title={src.title}
                        >
                          {src.organization}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-1">
                <p className="text-xs text-slate-600 font-medium">
                  {t.noConditionsFound}
                </p>
                <p className="text-[11px] text-slate-500">
                  {t.consultDoctorNote}
                </p>
              </div>
            )}
          </div>

          {/* Section D: General Self-Care Information */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs space-y-2.5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <HeartPulse className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                {t.selfCareTitle}
              </h3>
            </div>
            <p className="text-[11px] text-slate-500">
              {t.selfCareSubtitle}
            </p>
            <ul className="space-y-2 pt-1">
              {analysisResult.generalSelfCare.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-slate-700 leading-relaxed">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0 mt-1.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <div className="p-2.5 bg-amber-50/70 border border-amber-200/60 rounded-xl text-[11px] text-amber-800 font-medium">
              {t.selfCareWarning}
            </div>
          </div>

          {/* Section E: When to See a Doctor */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs space-y-2.5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                <Clock className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                {t.whenToSeeDoctorTitle}
              </h3>
            </div>
            <ul className="space-y-2 pt-1">
              {analysisResult.whenToSeeDoctor.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-slate-700 leading-relaxed">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section F: Authoritative Sources Display */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs space-y-2.5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <FileCheck2 className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <h3 className="text-xs font-bold text-slate-900 tracking-tight uppercase">
                {t.authoritativeRefsTitle}
              </h3>
            </div>
            <p className="text-[11px] text-slate-500">
              {t.authoritativeRefsSubtitle}
            </p>
            <div className="space-y-1.5 pt-1">
              {analysisResult.sources.map((src, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/80 flex items-start justify-between gap-2 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-800 flex items-center gap-1.5">
                      <span className="text-[10px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded font-extrabold border border-indigo-200/60">
                        {src.organization}
                      </span>
                      {src.title}
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      {src.guidelineTopic}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section G: Mandatory Disclaimer */}
          <div className="p-4 bg-slate-100 border border-slate-200/90 rounded-2xl space-y-2 text-center">
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-slate-700 uppercase tracking-wide">
              <AlertCircle className="w-4 h-4 text-slate-600" />
              {t.disclaimerTitle}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {analysisResult.disclaimer}
            </p>
          </div>
        </div>
      ) : (
        /* SYMPTOM SELECTION SCREEN */
        <div className="space-y-4" id="symptom-selection-view">
          {/* Header Card with Purpose */}
          <div className="bg-gradient-to-r from-teal-500/10 via-teal-50 to-white border border-teal-200/80 rounded-2xl p-4 shadow-2xs space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-teal-100 text-teal-800">
                <Activity className="w-4 h-4 stroke-[2.2]" />
              </div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                {t.headerTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {t.headerSubtitle}
            </p>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="symptom-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-white border border-slate-200/90 rounded-2xl pl-10 pr-10 py-3 text-xs text-slate-900 placeholder:text-slate-400 shadow-2xs focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Selected Symptoms Chips Area */}
          {selectedIds.length > 0 ? (
            <div className="bg-white border border-teal-200/80 rounded-2xl p-3.5 shadow-2xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-teal-900 tracking-tight">
                  {t.selectedSymptomsTitle} ({selectedIds.length})
                </span>
                <button
                  onClick={clearAllSymptoms}
                  className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 transition-colors cursor-pointer"
                >
                  {t.clearAll}
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {selectedSymptomsList.map((sym) => (
                  <span
                    key={sym.id}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-800 bg-teal-50 border border-teal-200 px-2.5 py-1 rounded-xl shadow-2xs"
                  >
                    <span>{getSymptomDisplayName(sym)}</span>
                    <button
                      onClick={() => removeSymptom(sym.id)}
                      className="text-teal-600 hover:text-teal-900 p-0.5 rounded-full hover:bg-teal-100 cursor-pointer"
                      title={`Remove ${getSymptomDisplayName(sym)}`}
                    >
                      <X className="w-3 h-3 stroke-[2.5]" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          ) : (
            /* Required Empty State: “Select symptoms to get an educational guide.” */
            <div
              className="p-5 bg-white border border-dashed border-slate-200 rounded-2xl text-center space-y-1.5 shadow-2xs"
              id="symptom-empty-state"
            >
              <div className="w-9 h-9 rounded-2xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto mb-1">
                <HelpCircle className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">
                {t.emptyTitle}
              </p>
              <p className="text-[11px] text-slate-400">
                {t.emptySubtitle}
              </p>
            </div>
          )}

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {CATEGORIES.map((cat) => {
              const localizedCat =
                SYMPTOM_CATEGORIES_TRANSLATIONS[cat]?.[currentLanguage] || cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white border border-slate-200/80 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {localizedCat}
                </button>
              );
            })}
          </div>

          {/* Common Symptoms List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-xs font-bold text-slate-800 tracking-tight">
                {t.availableSymptomsTitle} ({filteredSymptoms.length})
              </span>
              <span className="text-[11px] text-slate-400">
                {t.tapToSelect}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {filteredSymptoms.map((sym) => {
                const isSelected = selectedIds.includes(sym.id);
                return (
                  <button
                    key={sym.id}
                    id={`symptom-item-${sym.id}`}
                    onClick={() => toggleSymptom(sym.id)}
                    className={`p-3 rounded-2xl border text-left transition-all flex items-start justify-between gap-2.5 cursor-pointer ${
                      isSelected
                        ? 'bg-teal-50/90 border-teal-400 ring-2 ring-teal-500/20 shadow-2xs'
                        : 'bg-white border-slate-200/90 hover:border-slate-300 shadow-2xs active:scale-[0.99]'
                    }`}
                  >
                    <div className="space-y-0.5 min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-xs font-bold ${
                            isSelected ? 'text-teal-950' : 'text-slate-900'
                          }`}
                        >
                          {getSymptomDisplayName(sym)}
                        </span>
                        {sym.isRedFlagTrigger && (
                          <span className="text-[9px] font-extrabold uppercase bg-rose-50 text-rose-700 border border-rose-200 px-1 py-0.2 rounded">
                            {t.keySignBadge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-tight">
                        {getSymptomDisplayDescription(sym)}
                      </p>
                    </div>

                    <div
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 transition-colors mt-0.5 ${
                        isSelected
                          ? 'bg-teal-600 border-teal-600 text-white'
                          : 'border-slate-300 bg-white text-transparent'
                      }`}
                    >
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  </button>
                );
              })}
            </div>

            {filteredSymptoms.length === 0 && (
              <div className="p-6 bg-white border border-slate-200 rounded-2xl text-center space-y-2">
                <p className="text-xs text-slate-500">
                  {t.noMatchingSearch} "{searchQuery}"
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                  }}
                  className="text-xs font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
                >
                  {t.resetSearch}
                </button>
              </div>
            )}
          </div>

          {/* Floating / Sticky Bottom Action Bar for Analysis */}
          <div className="pt-2 sticky bottom-2 z-20">
            <button
              id="continue-to-analysis-btn"
              disabled={selectedIds.length === 0}
              onClick={handleAnalyze}
              className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer ${
                selectedIds.length > 0
                  ? 'bg-teal-700 hover:bg-teal-800 text-white active:scale-[0.99]'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>{t.continueToAnalysis}</span>
              {selectedIds.length > 0 && (
                <span className="bg-teal-800/80 text-white text-[11px] px-2 py-0.5 rounded-full font-bold">
                  {selectedIds.length}
                </span>
              )}
              <ChevronRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
