import React, { useState, useEffect } from 'react';
import { ShieldCheck, ShieldAlert, Mic, Camera, MapPin, Zap, Check } from 'lucide-react';
import { deviceService } from '../services/deviceService';

interface PermissionsBannerProps {
  onPermissionGranted?: () => void;
}

export const PermissionsBanner: React.FC<PermissionsBannerProps> = ({ onPermissionGranted }) => {
  const [hasRequested, setHasRequested] = useState(false);
  const [permissionsStatus, setPermissionsStatus] = useState<{
    mic: boolean;
    camera: boolean;
    gps: boolean;
  } | null>(null);
  const [isAsking, setIsAsking] = useState(false);

  const handleRequest = async () => {
    setIsAsking(true);
    try {
      const res = await deviceService.requestAllPermissions();
      setPermissionsStatus(res);
      setHasRequested(true);
      if (res.mic) {
        onPermissionGranted?.();
      }
    } catch (e) {
      console.warn("Ruxsat so'rashda xato:", e);
    } finally {
      setIsAsking(false);
    }
  };

  // Agar barcha ruxsatlar berilgan bo'lsa, ixcham ko'rinish
  if (hasRequested && permissionsStatus?.mic && permissionsStatus?.camera) {
    return (
      <div className="bg-emerald-950/40 border-b border-emerald-500/30 px-4 py-1.5 flex items-center justify-between text-[11px] text-emerald-300">
        <div className="flex items-center gap-1.5 font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Barcha qurilma ruxsatlari faollashtirildi (Mikrofon, Kamera, GPS)</span>
        </div>
        <span className="font-mono text-emerald-400 text-[10px]">100% FAOL</span>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-cyan-950/80 via-slate-950/90 to-cyan-950/80 border-b border-cyan-500/30 px-3 sm:px-4 py-2 sm:py-2.5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
      <div className="flex items-center gap-2 text-slate-200">
        <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0 animate-pulse" />
        <div>
          <span className="font-semibold text-cyan-300">Telefonni 100% boshqarish uchun:</span>{' '}
          <span className="text-slate-400">
            Mikrofon, Kamera va GPS datchiklariga ruxsat bering, Sir.
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={handleRequest}
          disabled={isAsking}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs transition-all shadow-[0_0_12px_rgba(6,182,212,0.4)] disabled:opacity-50 cursor-pointer"
        >
          <Zap className="w-3.5 h-3.5 fill-current" />
          <span>{isAsking ? "Ruxsat so'ralmoqda..." : "Ruxsatlarni Yoqish"}</span>
        </button>
      </div>
    </div>
  );
};
