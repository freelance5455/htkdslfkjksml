import React from 'react';
import { Home, MapPin, Users, Compass, Bookmark, ShieldCheck } from 'lucide-react';

export type NavDestination = 'home' | 'drilldown' | 'community' | 'nearme' | 'saved' | 'admin';

interface MaterialNavBarProps {
  currentTab: NavDestination;
  onSelectTab: (tab: NavDestination) => void;
  savedCount?: number;
  isAdmin?: boolean;
  theme?: 'dark' | 'light';
}

export const MaterialNavBar: React.FC<MaterialNavBarProps> = ({
  currentTab,
  onSelectTab,
  savedCount = 0,
  isAdmin = false,
  theme = 'dark'
}) => {
  const items = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'drilldown', label: 'States', icon: MapPin },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'nearme', label: 'Near Me', icon: Compass },
    { id: 'saved', label: 'Saved', icon: Bookmark, badge: savedCount },
    ...(isAdmin ? [{ id: 'admin', label: 'Admin', icon: ShieldCheck }] : [])
  ];

  return (
    <nav
      className={`sticky bottom-0 z-30 backdrop-blur-md border-t px-2 py-1.5 flex items-center justify-around select-none transition-colors ${
        theme === 'light'
          ? 'bg-white/95 border-slate-200 text-slate-800 shadow-sm'
          : 'bg-slate-900/95 border-slate-800/80 text-white shadow-2xl'
      }`}
      aria-label="Bottom Navigation"
    >
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = currentTab === item.id;

        return (
          <button
            key={item.id}
            id={`nav-tab-${item.id}`}
            onClick={() => onSelectTab(item.id as NavDestination)}
            className="flex flex-col items-center justify-center flex-1 py-1 px-1 transition-all group"
          >
            {/* Active Pill Container */}
            <div
              className={`relative px-4 py-1 rounded-full flex items-center justify-center transition-all ${
                isActive
                  ? theme === 'light'
                    ? 'bg-indigo-50 text-indigo-600 ring-1 ring-indigo-200'
                    : 'bg-indigo-600/30 text-indigo-400 ring-1 ring-indigo-500/50'
                  : theme === 'light'
                  ? 'text-slate-500 group-hover:text-slate-800'
                  : 'text-slate-400 group-hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              {item.badge !== undefined && item.badge > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[15px] h-3.5 px-1 bg-amber-500 text-slate-950 font-bold text-[9px] rounded-full flex items-center justify-center leading-none">
                  {item.badge}
                </span>
              )}
            </div>

            <span
              className={`text-[10px] tracking-tight mt-1 font-medium transition-colors ${
                isActive
                  ? theme === 'light'
                    ? 'text-indigo-600 font-bold'
                    : 'text-indigo-300 font-bold'
                  : theme === 'light'
                  ? 'text-slate-500'
                  : 'text-slate-400'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
