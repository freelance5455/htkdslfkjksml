import React, { useEffect, useState } from 'react';
import {
  Check,
  Code2,
  Crown,
  Hammer,
  Layers,
  Lock,
  Save,
  Smartphone,
  Upload,
} from 'lucide-react';
import {
  ApiError,
  apiRequest,
  appendIconAssetsToFormData,
  ICON_PRESETS,
  processIconUploadAssets,
  resolveProjectIconSrc,
} from '../lib/api';
import type { ApkConfig, MembershipInfo, ProjectDetail, ProjectSummary } from '../types/studio';
import { SyntaxCodeBlock } from './SyntaxCodeBlock';

interface ApkSettingsViewProps {
  projects: ProjectSummary[];
  selectedProject: ProjectDetail | null;
  membership: MembershipInfo;
  onSelectProject: (id: string) => void;
  onRefreshSelected: (id: string) => Promise<void>;
  onStartBuild: (projectId: string) => void;
  onRequireUpgrade: (message: string) => void;
}

const PACKAGE_REGEX = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;

export const ApkSettingsView: React.FC<ApkSettingsViewProps> = ({
  projects,
  selectedProject,
  membership,
  onSelectProject,
  onRefreshSelected,
  onStartBuild,
  onRequireUpgrade,
}) => {
  const [config, setConfig] = useState<ApkConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploadingIcon, setUploadingIcon] = useState(false);
  const [launcherShape, setLauncherShape] = useState<'squircle' | 'circle' | 'rounded'>('squircle');
  const [iconMetaNote, setIconMetaNote] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [showAndroidCode, setShowAndroidCode] = useState(false);
  const [codeTab, setCodeTab] = useState<'kotlin' | 'manifest' | 'gradle' | 'docker'>('kotlin');
  const [androidCode, setAndroidCode] = useState<{
    mainKt: string;
    manifest: string;
    gradle: string;
    dockerfile: string;
  } | null>(null);

  useEffect(() => {
    if (selectedProject) {
      setConfig({
        adaptiveIconEnabled: true,
        adaptiveBgColor: '#0B1020',
        offlineEnabled: true,
        ...selectedProject.config,
      });
      setFeedback(null);
      setIconMetaNote(null);
      setAndroidCode(null);
    } else {
      setConfig(null);
    }
  }, [selectedProject?.id, selectedProject?.updated_at]);

  const packageValid = config ? PACKAGE_REGEX.test(config.packageName.trim()) : true;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !config) return;
    setSaving(true);
    setFeedback(null);
    try {
      await apiRequest(`/api/projects/${selectedProject.id}/config`, {
        method: 'PUT',
        body: JSON.stringify(config),
      });
      await onRefreshSelected(selectedProject.id);
      setFeedback({ type: 'ok', text: 'APK ve WebView ayarları kaydedildi.' });
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        onRequireUpgrade(err.message);
        return;
      }
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Ayarlar kaydedilemedi.',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleIconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFile = e.target.files?.[0];
    if (!rawFile || !selectedProject || !config) return;
    setUploadingIcon(true);
    setFeedback(null);
    try {
      const assets = await processIconUploadAssets(rawFile);
      const form = new FormData();
      appendIconAssetsToFormData(form, assets);
      form.append('adaptiveIconEnabled', String(config.adaptiveIconEnabled ?? true));
      form.append('adaptiveBgColor', config.adaptiveBgColor || '#0B1020');

      const res = await apiRequest<{
        config: ApkConfig;
        validation?: {
          isSquare: boolean;
          dimensions?: { width: number; height: number } | null;
          generatedDensities?: string[];
        };
      }>(`/api/projects/${selectedProject.id}/icon`, { method: 'POST', body: form });

      setConfig(res.config);
      await onRefreshSelected(selectedProject.id);

      const squareInfo = assets.wasSquare
        ? `Kare doğrulandı (${assets.sourceWidth}×${assets.sourceHeight})`
        : `Orijinal ${assets.sourceWidth}×${assets.sourceHeight} oranından 512×512 kareye ortalandı`;
      setIconMetaNote(
        `${squareInfo} · mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi + Adaptive Foreground üretildi.`
      );
      setFeedback({
        type: 'ok',
        text: 'Özel uygulama ikonu ve tüm Android mipmap çözünürlükleri kaydedildi.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'İkon yüklenemedi.',
      });
    } finally {
      setUploadingIcon(false);
      e.target.value = '';
    }
  };

  const handleInspectAndroidCode = async () => {
    if (!selectedProject) return;
    setShowAndroidCode(true);
    try {
      const res = await apiRequest<{
        mainKt: string;
        manifest: string;
        gradle: string;
        dockerfile: string;
      }>(`/api/projects/${selectedProject.id}/android-preview`);
      setAndroidCode(res);
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Android kod önizlemesi yüklenemedi.',
      });
    }
  };

  if (!selectedProject || !config) {
    return (
      <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-12 text-center text-sm text-slate-600 dark:text-[#94A3B8]">
        APK ayarlarını düzenlemek için önce bir proje seçin veya oluşturun.
      </div>
    );
  }

  const iconSrc = resolveProjectIconSrc(
    selectedProject.id,
    config.iconPreset,
    config.customIconPath,
    selectedProject.updated_at
  );

  const shapeClass =
    launcherShape === 'circle'
      ? 'rounded-full'
      : launcherShape === 'squircle'
      ? 'rounded-[22px]'
      : 'rounded-xl';

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            APK & WebView Ayarları
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            AndroidManifest.xml, Kotlin WebView, Adaptive Icon, Splash ekranı ve offline önbellek
            yapılandırması.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {projects.length > 0 && (
            <select
              value={selectedProject.id}
              onChange={(e) => onSelectProject(e.target.value)}
              className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          )}
          <button
            type="button"
            onClick={() => void handleInspectAndroidCode()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl bg-white dark:bg-[#151D2E] hover:bg-slate-50 dark:hover:bg-white/[0.06] border border-slate-200 dark:border-white/[0.08] text-slate-800 dark:text-[#F8FAFC] whitespace-nowrap"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Kotlin / Gradle Kodunu İncele</span>
          </button>
          <button
            type="button"
            onClick={() => onStartBuild(selectedProject.id)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white whitespace-nowrap"
          >
            <Hammer className="w-3.5 h-3.5" />
            <span>APK Derle</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-700 dark:text-[#22C55E]'
              : 'bg-red-500/10 border-red-500/25 text-red-600 dark:text-[#EF4444]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Core Identity & System Bars */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Temel Uygulama Kimliği
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Uygulama Adı
                </label>
                <input
                  type="text"
                  required
                  value={config.appName}
                  onChange={(e) => setConfig({ ...config, appName: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Paket Adı (Application ID)
                </label>
                <input
                  type="text"
                  required
                  value={config.packageName}
                  onChange={(e) => setConfig({ ...config, packageName: e.target.value })}
                  className={`w-full bg-slate-50 dark:bg-[#0B1020] border rounded-xl px-3.5 py-2 text-sm font-mono text-slate-900 dark:text-[#F8FAFC] focus:outline-none ${
                    packageValid
                      ? 'border-slate-200 dark:border-white/[0.1] focus:border-[#6366F1]'
                      : 'border-[#EF4444]'
                  }`}
                />
                {!packageValid && (
                  <p className="mt-1 text-[11px] text-[#EF4444]">
                    Geçersiz Android paket adı (ör. com.firma.uygulama)
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Sürüm Adı (Version Name)
                </label>
                <input
                  type="text"
                  required
                  value={config.versionName}
                  onChange={(e) => setConfig({ ...config, versionName: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm font-mono text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Sürüm Kodu (Version Code)
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={config.versionCode}
                  onChange={(e) =>
                    setConfig({ ...config, versionCode: Math.max(1, Number(e.target.value) || 1) })
                  }
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
            </div>
          </div>

          {/* Display, Orientation & Permissions */}
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-5">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Ekran, Çubuklar ve WebView İzinleri
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Ekran Yönü
                </label>
                <select
                  value={config.orientation}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      orientation: e.target.value as ApkConfig['orientation'],
                    })
                  }
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm text-slate-900 dark:text-[#F8FAFC]"
                >
                  <option value="unspecified">Otomatik (Sensör)</option>
                  <option value="portrait">Dikey (Portrait)</option>
                  <option value="landscape">Yatay (Landscape)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Açılış Animasyonu
                </label>
                <select
                  value={config.launchAnimation}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      launchAnimation: e.target.value as ApkConfig['launchAnimation'],
                    })
                  }
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm text-slate-900 dark:text-[#F8FAFC]"
                >
                  <option value="fade">Yumuşak Geçiş (Fade)</option>
                  <option value="slide">Yatay Kayma (Slide)</option>
                  <option value="scale">Ölçekli Açılış (Scale)</option>
                  <option value="none">Animasyon Yok</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Durum Çubuğu Rengi
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.statusBarColor}
                    onChange={(e) => setConfig({ ...config, statusBarColor: e.target.value })}
                    className="w-10 h-9 rounded-lg bg-transparent border border-slate-200 dark:border-white/[0.1] cursor-pointer"
                  />
                  <input
                    type="text"
                    value={config.statusBarColor}
                    onChange={(e) => setConfig({ ...config, statusBarColor: e.target.value })}
                    className="flex-1 bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Navigasyon Çubuğu Rengi
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.navigationBarColor}
                    onChange={(e) => setConfig({ ...config, navigationBarColor: e.target.value })}
                    className="w-10 h-9 rounded-lg bg-transparent border border-slate-200 dark:border-white/[0.1] cursor-pointer"
                  />
                  <input
                    type="text"
                    value={config.navigationBarColor}
                    onChange={(e) => setConfig({ ...config, navigationBarColor: e.target.value })}
                    className="flex-1 bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                <span className="text-xs text-slate-800 dark:text-[#CBD5E1]">Tam Ekran Modu</span>
                <input
                  type="checkbox"
                  checked={config.fullscreen}
                  onChange={(e) => setConfig({ ...config, fullscreen: e.target.checked })}
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                <span className="text-xs text-slate-800 dark:text-[#CBD5E1]">
                  Durum Çubuğu Görünür
                </span>
                <input
                  type="checkbox"
                  checked={config.statusBarVisible}
                  onChange={(e) => setConfig({ ...config, statusBarVisible: e.target.checked })}
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                <span className="text-xs text-slate-800 dark:text-[#CBD5E1]">
                  Navigasyon Çubuğu Görünür
                </span>
                <input
                  type="checkbox"
                  checked={config.navigationBarVisible}
                  onChange={(e) =>
                    setConfig({ ...config, navigationBarVisible: e.target.checked })
                  }
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                <span className="text-xs text-slate-800 dark:text-[#CBD5E1]">
                  İnternet Erişimi İzni
                </span>
                <input
                  type="checkbox"
                  checked={config.internetPermission}
                  onChange={(e) =>
                    setConfig({ ...config, internetPermission: e.target.checked })
                  }
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <label className="sm:col-span-2 flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] cursor-pointer">
                <div>
                  <span className="text-xs font-medium text-slate-900 dark:text-[#F8FAFC]">
                    Offline Çalışma & Yerel Varlık Önbelleği
                  </span>
                  <p className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                    HTML/CSS/JS varlıkları APK içinde WebViewAssetLoader ile internet olmadan da
                    çalışır
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={config.offlineEnabled ?? true}
                  onChange={(e) => setConfig({ ...config, offlineEnabled: e.target.checked })}
                  className="accent-[#6366F1] w-4 h-4 shrink-0"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Right: Adaptive Icon Studio & Splash Screen */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#6366F1]" />
                <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  Android İkon & Adaptive Studio
                </h2>
              </div>
              <label className="inline-flex items-center gap-1.5 text-xs font-medium text-[#3B82F6] hover:underline cursor-pointer whitespace-nowrap">
                <Upload className="w-3.5 h-3.5" />
                <span>{uploadingIcon ? 'İşleniyor...' : 'PNG / JPG Yükle'}</span>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg,.webp,.svg"
                  onChange={handleIconUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Launcher Preview Card with Shape Switcher */}
            <div className="rounded-xl bg-slate-100 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-slate-600 dark:text-[#94A3B8]">
                  Launcher Önizlemesi
                </span>
                <div className="inline-flex p-0.5 rounded-lg bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] text-[11px]">
                  {(
                    [
                      { id: 'circle', label: 'Yuvarlak' },
                      { id: 'squircle', label: 'Squircle' },
                      { id: 'rounded', label: 'Kare' },
                    ] as const
                  ).map((sh) => (
                    <button
                      key={sh.id}
                      type="button"
                      onClick={() => setLauncherShape(sh.id)}
                      className={`px-2 py-0.5 rounded-md transition-colors ${
                        launcherShape === sh.id
                          ? 'bg-[#6366F1] text-white'
                          : 'text-slate-500 dark:text-[#94A3B8]'
                      }`}
                    >
                      {sh.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div
                  className={`w-16 h-16 ${shapeClass} overflow-hidden border border-slate-300 dark:border-white/[0.14] flex items-center justify-center shrink-0`}
                  style={{
                    backgroundColor:
                      config.adaptiveIconEnabled !== false
                        ? config.adaptiveBgColor || '#0B1020'
                        : '#0B1020',
                  }}
                >
                  <img
                    src={iconSrc}
                    alt={config.appName}
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover ${
                      config.adaptiveIconEnabled !== false ? 'p-1.5 rounded-full' : ''
                    }`}
                  />
                </div>
                <div className="min-w-0 text-xs">
                  <div className="font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                    {config.appName}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                    mdpi · hdpi · xhdpi · xxhdpi · xxxhdpi
                  </div>
                  {iconMetaNote && (
                    <div className="mt-1 text-[11px] text-[#22C55E] leading-snug">
                      {iconMetaNote}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Adaptive Icon Controls */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] space-y-3">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="inline-flex items-center gap-2 text-xs font-medium text-slate-800 dark:text-[#F8FAFC]">
                  <Layers className="w-3.5 h-3.5 text-[#6366F1]" />
                  <span>Android Adaptive Icon (API 26+)</span>
                </span>
                <input
                  type="checkbox"
                  checked={config.adaptiveIconEnabled ?? true}
                  onChange={(e) =>
                    setConfig({ ...config, adaptiveIconEnabled: e.target.checked })
                  }
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              {(config.adaptiveIconEnabled ?? true) && (
                <div>
                  <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                    Adaptive Arka Plan Rengi (ic_launcher_background)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={config.adaptiveBgColor || '#0B1020'}
                      onChange={(e) => setConfig({ ...config, adaptiveBgColor: e.target.value })}
                      className="w-9 h-8 rounded-lg bg-transparent border border-slate-200 dark:border-white/[0.1] cursor-pointer"
                    />
                    <input
                      type="text"
                      value={config.adaptiveBgColor || '#0B1020'}
                      onChange={(e) => setConfig({ ...config, adaptiveBgColor: e.target.value })}
                      className="flex-1 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Preset Icons */}
            <div className="grid grid-cols-3 gap-2.5">
              {ICON_PRESETS.map((preset) => {
                const locked = preset.premiumOnly && !membership.limits.premiumIcons;
                const active = config.iconPreset === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => {
                      if (locked) {
                        onRequireUpgrade(`"${preset.name}" ikonu Premium üyelik gerektirir.`);
                        return;
                      }
                      setConfig({ ...config, iconPreset: preset.id, customIconPath: null });
                    }}
                    className={`rounded-xl border p-2 text-left transition-colors ${
                      active
                        ? 'border-[#6366F1] bg-[#6366F1]/10'
                        : 'border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0B1020] hover:border-slate-300 dark:hover:border-white/[0.2]'
                    }`}
                  >
                    <img
                      src={preset.src}
                      alt={preset.name}
                      referrerPolicy="no-referrer"
                      className="w-full aspect-square object-cover rounded-lg mb-1.5"
                    />
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[11px] font-medium text-slate-900 dark:text-[#F8FAFC] truncate">
                        {preset.name}
                      </span>
                      {locked ? (
                        <Lock className="w-3 h-3 text-[#EAB308] shrink-0" />
                      ) : active ? (
                        <Check className="w-3 h-3 text-[#6366F1] shrink-0" />
                      ) : preset.premiumOnly ? (
                        <Crown className="w-3 h-3 text-[#EAB308] shrink-0" />
                      ) : null}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Splash Screen */}
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Splash Screen (Açılış Ekranı)
              </h2>
              <input
                type="checkbox"
                checked={config.splashEnabled}
                onChange={(e) => setConfig({ ...config, splashEnabled: e.target.checked })}
                className="accent-[#6366F1] w-4 h-4"
              />
            </div>

            {config.splashEnabled && (
              <div className="space-y-3 pt-1">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                    Splash Başlığı
                  </label>
                  <input
                    type="text"
                    value={config.splashTitle}
                    onChange={(e) => setConfig({ ...config, splashTitle: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm text-slate-900 dark:text-[#F8FAFC]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                      Arka Plan Rengi
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={config.splashBgColor}
                        onChange={(e) => setConfig({ ...config, splashBgColor: e.target.value })}
                        className="w-9 h-9 rounded-lg bg-transparent border border-slate-200 dark:border-white/[0.1]"
                      />
                      <input
                        type="text"
                        value={config.splashBgColor}
                        onChange={(e) => setConfig({ ...config, splashBgColor: e.target.value })}
                        className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-2.5 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                      Süre (ms)
                    </label>
                    <input
                      type="number"
                      min={400}
                      max={5000}
                      step={100}
                      value={config.splashDurationMs}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          splashDurationMs: Math.max(400, Number(e.target.value) || 1200),
                        })
                      }
                      className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC]"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={saving || !packageValid}
            className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white text-sm font-semibold transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Kaydediliyor...' : 'APK Ayarlarını Kaydet'}</span>
          </button>
        </div>
      </form>

      {/* Android Code Inspector Modal */}
      {showAndroidCode && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-4xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-2xl overflow-hidden max-h-[88vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Üretilen Gerçek Android WebView Kaynak Kodları
              </h3>
              <button
                type="button"
                onClick={() => setShowAndroidCode(false)}
                className="text-xs text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
              >
                Kapat
              </button>
            </div>
            <div className="px-6 py-3 border-b border-slate-200 dark:border-white/[0.08] flex flex-wrap gap-2 bg-slate-50 dark:bg-[#111827]">
              {(
                [
                  { id: 'kotlin', label: 'MainActivity.kt' },
                  { id: 'manifest', label: 'AndroidManifest.xml' },
                  { id: 'gradle', label: 'app/build.gradle.kts' },
                  { id: 'docker', label: 'Dockerfile' },
                ] as const
              ).map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setCodeTab(t.id)}
                  className={`px-3 py-1.5 text-xs font-mono rounded-lg ${
                    codeTab === t.id
                      ? 'bg-[#6366F1] text-white'
                      : 'bg-white dark:bg-[#0B1020] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <div className="flex-1 overflow-auto py-3 bg-white dark:bg-[#0B1020]">
              {androidCode ? (
                <SyntaxCodeBlock
                  code={
                    codeTab === 'kotlin'
                      ? androidCode.mainKt
                      : codeTab === 'manifest'
                      ? androidCode.manifest
                      : codeTab === 'gradle'
                      ? androidCode.gradle
                      : androidCode.dockerfile
                  }
                  filePath={
                    codeTab === 'kotlin'
                      ? 'MainActivity.kt'
                      : codeTab === 'manifest'
                      ? 'AndroidManifest.xml'
                      : codeTab === 'gradle'
                      ? 'build.gradle.kts'
                      : 'Dockerfile'
                  }
                />
              ) : (
                <div className="p-6 text-xs text-slate-500 dark:text-[#94A3B8]">
                  Kaynak dosyalar oluşturuluyor...
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
