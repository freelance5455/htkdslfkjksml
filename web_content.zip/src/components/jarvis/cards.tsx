import type { ReactNode } from "react";
import { Activity, Cpu, Shield, Timer } from "lucide-react";
import type { ChatMessage } from "@/lib/jarvis/types";
import { cn } from "@/lib/utils";

function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg bg-surface px-4 py-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]",
        className,
      )}
    >
      <span className="hud-corner tl" />
      <span className="hud-corner tr" />
      <span className="hud-corner bl" />
      <span className="hud-corner br" />
      {children}
    </div>
  );
}

function formatClock(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function TimerCard({ remaining, total }: { remaining: number; total: number }) {
  const pct = total > 0 ? Math.max(0, Math.min(1, remaining / total)) : 0;
  return (
    <Panel>
      <div className="flex items-center gap-3">
        <Timer className="size-5 text-primary" strokeWidth={1.75} />
        <div className="min-w-0 flex-1">
          <p className="font-mono text-xs tracking-widest text-muted uppercase">Timer</p>
          <p className="font-mono text-2xl tabular-nums leading-tight text-fg">{formatClock(remaining)}</p>
        </div>
      </div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-primary/15">
        <div
          className="h-full bg-primary transition-[width] duration-300 ease-linear"
          style={{ width: `${pct * 100}%` }}
        />
      </div>
    </Panel>
  );
}

const SYSTEMS = [
  { label: "Power core", value: "NOMINAL" },
  { label: "Optics", value: "NOMINAL" },
  { label: "Comms mesh", value: "NOMINAL" },
  { label: "Voice print", value: "ARMED" },
  { label: "Wake word", value: "HEY JARVIS" },
];

export function DiagnosticsCard() {
  return (
    <Panel>
      <div className="mb-3 flex items-center gap-2">
        <Activity className="size-4 text-primary" strokeWidth={1.75} />
        <p className="font-mono text-xs tracking-widest text-muted uppercase">Systems check</p>
      </div>
      <ul className="space-y-1.5">
        {SYSTEMS.map((row) => (
          <li key={row.label} className="flex items-baseline justify-between gap-3 font-mono text-sm">
            <span className="text-muted">{row.label}</span>
            <span className="text-primary tabular-nums">{row.value}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

const SUIT = [
  { label: "Hull", value: "GOLD-TITANIUM" },
  { label: "Integrity", value: "100%" },
  { label: "Repulsors", value: "98%" },
  { label: "Flight", value: "IDLE" },
];

export function SuitCard() {
  return (
    <Panel>
      <div className="mb-3 flex items-center gap-2">
        <Shield className="size-4 text-gold" strokeWidth={1.75} />
        <p className="font-mono text-xs tracking-widest text-muted uppercase">Armor telemetry</p>
      </div>
      <ul className="space-y-1.5">
        {SUIT.map((row) => (
          <li key={row.label} className="flex items-baseline justify-between gap-3 font-mono text-sm">
            <span className="text-muted">{row.label}</span>
            <span className="text-fg tabular-nums">{row.value}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

export function MessageBubble({ message }: { message: ChatMessage }) {
  const mine = message.role === "user";
  return (
    <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-sm rounded-lg px-3.5 py-2.5 text-sm leading-snug sm:max-w-md",
          mine
            ? "rounded-br-xs bg-primary/15 text-fg"
            : "rounded-bl-xs bg-surface text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_18%,transparent)]",
        )}
      >
        {!mine ? (
          <p className="mb-1 flex items-center gap-1.5 font-mono text-xs tracking-widest text-primary uppercase">
            <Cpu className="size-3" strokeWidth={2} />
            Jarvis
          </p>
        ) : null}
        <p>{message.content}</p>
      </div>
    </div>
  );
}
