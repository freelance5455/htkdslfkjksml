import { cn } from "@/lib/utils";
import type { JarvisPhase } from "@/lib/jarvis/types";

type Props = {
  phase: JarvisPhase;
  compact?: boolean;
  onPress: () => void;
  caption: string;
};

const TICKS = Array.from({ length: 60 }, (_, i) => {
  const a = (i / 60) * Math.PI * 2;
  const inner = i % 5 === 0 ? 86 : 90;
  const outer = 94;
  const round = (n: number) => n.toFixed(2);
  return {
    major: i % 5 === 0,
    x1: round(100 + Math.cos(a) * inner),
    y1: round(100 + Math.sin(a) * inner),
    x2: round(100 + Math.cos(a) * outer),
    y2: round(100 + Math.sin(a) * outer),
  };
});

export function JarvisOrb({ phase, compact, onPress, caption }: Props) {
  const listening = phase === "listening";
  const speaking = phase === "speaking";
  const thinking = phase === "thinking";

  return (
    <div className="flex flex-col items-center gap-3">
      <button
        type="button"
        onClick={onPress}
        aria-label={caption}
        className={cn(
          "relative grid place-items-center rounded-full transition-[width,height,transform] duration-300 ease-out",
          compact ? "orb-size-compact" : "orb-size",
        )}
      >
        {listening ? (
          <>
            <span className="ripple absolute inset-0 rounded-full border border-primary/50" />
            <span className="ripple-delayed ripple absolute inset-0 rounded-full border border-primary/30" />
          </>
        ) : null}

        <svg
          viewBox="0 0 200 200"
          className={cn("size-full", listening ? "orb-listen" : speaking ? "orb-speak" : "")}
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="core" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="var(--color-fg)" />
              <stop offset="35%" stopColor="var(--color-primary)" />
              <stop offset="70%" stopColor="var(--color-primary-dim)" />
              <stop offset="100%" stopColor="var(--color-bg)" />
            </radialGradient>
            <radialGradient id="gold" cx="50%" cy="42%" r="55%">
              <stop offset="0%" stopColor="var(--color-fg)" />
              <stop offset="45%" stopColor="var(--color-gold)" />
              <stop offset="100%" stopColor="var(--color-bg)" />
            </radialGradient>
          </defs>

          <circle
            cx="100"
            cy="100"
            r="96"
            fill="none"
            stroke="currentColor"
            className="text-primary/25"
            strokeWidth="1"
          />

          <g
            className={thinking ? "orb-spin-fast origin-center" : "orb-spin origin-center"}
            style={{ transformBox: "fill-box", transformOrigin: "center" }}
          >
            {TICKS.map((tick, i) => (
              <line
                key={i}
                x1={tick.x1}
                y1={tick.y1}
                x2={tick.x2}
                y2={tick.y2}
                stroke="currentColor"
                className={tick.major ? "text-primary/80" : "text-primary/35"}
                strokeWidth={tick.major ? 1.4 : 0.8}
              />
            ))}
          </g>

          <circle
            cx="100"
            cy="100"
            r="78"
            fill="none"
            stroke="currentColor"
            className="text-primary/40"
            strokeWidth="1"
            strokeDasharray="4 6"
          />

          <g className="orb-spin-rev origin-center" style={{ transformBox: "fill-box", transformOrigin: "center" }}>
            <circle
              cx="100"
              cy="100"
              r="68"
              fill="none"
              stroke="currentColor"
              className="text-primary/70"
              strokeWidth="1.5"
              strokeDasharray="28 120"
              strokeLinecap="round"
            />
            <circle
              cx="100"
              cy="100"
              r="62"
              fill="none"
              stroke="currentColor"
              className="text-primary/30"
              strokeWidth="6"
              strokeDasharray="2 14"
            />
          </g>

          {thinking ? (
            <circle
              cx="100"
              cy="100"
              r="54"
              fill="none"
              stroke="currentColor"
              className="text-primary orb-think"
              strokeWidth="2"
              strokeDasharray="40 160"
              strokeLinecap="round"
            />
          ) : (
            <circle
              cx="100"
              cy="100"
              r="54"
              fill="none"
              stroke="currentColor"
              className="text-primary/50"
              strokeWidth="1"
            />
          )}

          <circle cx="100" cy="100" r="36" fill="url(#gold)" opacity="0.92" />
          <circle cx="100" cy="100" r="26" fill="var(--color-bg)" />
          <circle cx="100" cy="100" r="20" fill="url(#core)" className={speaking || listening ? "orb-pulse" : ""} />
          <circle cx="100" cy="100" r="8" fill="var(--color-fg)" opacity="0.9" />

          <line x1="100" y1="42" x2="100" y2="52" stroke="currentColor" className="text-primary/70" strokeWidth="1.2" />
          <line x1="100" y1="148" x2="100" y2="158" stroke="currentColor" className="text-primary/70" strokeWidth="1.2" />
          <line x1="42" y1="100" x2="52" y2="100" stroke="currentColor" className="text-primary/70" strokeWidth="1.2" />
          <line x1="148" y1="100" x2="158" y2="100" stroke="currentColor" className="text-primary/70" strokeWidth="1.2" />
        </svg>
      </button>
      <p className="font-mono text-xs tracking-widest text-primary uppercase">{caption}</p>
    </div>
  );
}
