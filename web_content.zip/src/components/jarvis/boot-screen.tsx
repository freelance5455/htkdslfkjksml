import { useEffect, useState } from "react";

const LINES = [
  "INITIALIZING J.A.R.V.I.S.",
  "COGNITIVE MESH ………… ONLINE",
  "VOICE PRINT ……………… ARMED",
  "WAKE WORD ……………… HEY JARVIS",
  "ALL SYSTEMS ………… NOMINAL",
];

type Props = { onDone: () => void };

export function BootScreen({ onDone }: Props) {
  const [visible, setVisible] = useState(0);

  useEffect(() => {
    const timers: number[] = [];
    LINES.forEach((_, i) => {
      timers.push(window.setTimeout(() => setVisible(i + 1), 180 + i * 280));
    });
    timers.push(window.setTimeout(onDone, 180 + LINES.length * 280 + 420));
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-8 bg-bg px-6">
      <div className="relative grid size-28 place-items-center">
        <span className="absolute inset-0 rounded-full border border-primary/40" />
        <span className="absolute inset-2 rounded-full border border-primary/25 orb-spin" />
        <span className="size-10 rounded-full bg-primary/80 orb-pulse" />
      </div>
      <ol className="w-full max-w-sm font-mono text-sm tracking-wide text-primary">
        {LINES.map((line, i) => (
          <li
            key={line}
            className="boot-line py-1"
            style={{ animationDelay: `${i * 80}ms`, opacity: i < visible ? 1 : 0 }}
          >
            {line}
          </li>
        ))}
      </ol>
    </div>
  );
}
