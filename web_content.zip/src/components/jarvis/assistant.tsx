import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Keyboard, Mic, MicOff, Power, Settings2, Volume2, VolumeX, X } from "lucide-react";
import { askJarvis } from "@/lib/jarvis/ask";
import { parseLocalCommand } from "@/lib/jarvis/commands";
import { speakJarvis } from "@/lib/jarvis/speak";
import { newId, useJarvisStore } from "@/lib/jarvis/store";
import { SUGGESTIONS, type JarvisPhase } from "@/lib/jarvis/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { BootScreen } from "./boot-screen";
import { DiagnosticsCard, MessageBubble, SuitCard, TimerCard } from "./cards";
import { JarvisOrb } from "./orb";
import { speakBrowser, stopBrowserSpeech, useJarvisSpeech } from "./use-speech";

function greetingFor(date: Date) {
  const h = date.getHours();
  if (h < 12) return "Good morning, sir.";
  if (h < 18) return "Good afternoon, sir.";
  return "Good evening, sir.";
}

function phaseCaption(phase: JarvisPhase, wakeOn: boolean, micOn: boolean) {
  if (phase === "listening") return "Listening";
  if (phase === "thinking") return "Processing";
  if (phase === "speaking") return "Speaking";
  if (micOn && wakeOn) return "Say Hey Jarvis";
  if (micOn) return "Tap to speak";
  return "Standby";
}

export function Assistant() {
  const messages = useJarvisStore((s) => s.messages);
  const voiceOn = useJarvisStore((s) => s.voiceOn);
  const wakeOn = useJarvisStore((s) => s.wakeOn);
  const addMessage = useJarvisStore((s) => s.addMessage);
  const clearMessages = useJarvisStore((s) => s.clearMessages);
  const setVoiceOn = useJarvisStore((s) => s.setVoiceOn);
  const setWakeOn = useJarvisStore((s) => s.setWakeOn);

  const [booting, setBooting] = useState(true);
  const [phase, setPhase] = useState<JarvisPhase>("idle");
  const [draft, setDraft] = useState("");
  const [partial, setPartial] = useState("");
  const [now, setNow] = useState(() => new Date());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [timer, setTimer] = useState<{ remaining: number; total: number } | null>(null);
  const [micArmed, setMicArmed] = useState(false);
  const [banner, setBanner] = useState<string | null>(null);

  const listRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const genRef = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortSpeakRef = useRef<(() => void) | null>(null);

  const paused = phase === "speaking" || phase === "thinking";

  const onPartial = useCallback((text: string) => setPartial(text), []);

  const handleCommandRef = useRef<(text: string) => void>(() => {});

  const onWake = useCallback(() => {
    stopPlayback();
    setPhase("listening");
    setPartial("");
    setBanner(null);
  }, []);

  const speech = useJarvisSpeech({
    enabled: wakeOn && micArmed,
    paused,
    onCommand: (text) => handleCommandRef.current(text),
    onWake,
    onPartial,
  });

  function stopPlayback() {
    stopBrowserSpeech();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }
    abortSpeakRef.current?.();
    abortSpeakRef.current = null;
  }

  const speak = useCallback(async (text: string, gen: number) => {
    if (!voiceOn) return;
    if (gen !== genRef.current) return;
    setPhase("speaking");
    try {
      const tts = await speakJarvis({ data: { text } });
      if (gen !== genRef.current) return;
      if (tts.ok) {
        await new Promise<void>((resolve) => {
          abortSpeakRef.current = resolve;
          const audio = new Audio(tts.audio);
          audioRef.current = audio;
          audio.onended = () => resolve();
          audio.onerror = () => resolve();
          audio.play().catch(() => resolve());
        });
        return;
      }
      await speakBrowser(text);
    } catch {
      if (gen !== genRef.current) return;
      await speakBrowser(text);
    } finally {
      abortSpeakRef.current = null;
      if (audioRef.current) audioRef.current = null;
    }
  }, [voiceOn]);

  const handleCommand = useCallback(
    async (raw: string) => {
      const text = raw.replace(/\s+/g, " ").trim();
      if (!text) return;
      const gen = ++genRef.current;
      setPartial("");
      setComposerOpen(false);
      setDraft("");
      setBanner(null);
      stopPlayback();

      addMessage({ id: newId(), role: "user", content: text });
      setPhase("thinking");

      const local = parseLocalCommand(text, new Date());
      const stillMine = () => gen === genRef.current;

      try {
        if (local?.type === "clear") {
          clearMessages();
          setTimer(null);
          const reply = "Conversation cleared, sir.";
          if (!stillMine()) return;
          addMessage({ id: newId(), role: "assistant", content: reply });
          await speak(reply, gen);
          if (stillMine()) setPhase("idle");
          return;
        }
        if (local?.type === "mute") {
          setVoiceOn(!local.muted);
          if (!stillMine()) return;
          addMessage({ id: newId(), role: "assistant", content: local.text });
          if (!local.muted) await speak(local.text, gen);
          if (stillMine()) setPhase("idle");
          return;
        }
        if (local?.type === "wake") {
          setWakeOn(local.enabled);
          if (!stillMine()) return;
          addMessage({ id: newId(), role: "assistant", content: local.text });
          await speak(local.text, gen);
          if (stillMine()) setPhase("idle");
          return;
        }
        if (local?.type === "timer") {
          if (local.seconds === 0) setTimer(null);
          else setTimer({ remaining: local.seconds, total: local.seconds });
          if (!stillMine()) return;
          addMessage({
            id: newId(),
            role: "assistant",
            content: local.text,
            kind: "timer",
            seconds: local.seconds,
          });
          await speak(local.text, gen);
          if (stillMine()) setPhase("idle");
          return;
        }
        if (local) {
          if (!stillMine()) return;
          addMessage({
            id: newId(),
            role: "assistant",
            content: local.text,
            kind: local.type === "diagnostics" || local.type === "suit" || local.type === "time" ? local.type : "text",
          });
          await speak(local.text, gen);
          if (stillMine()) setPhase("idle");
          return;
        }

        const history = useJarvisStore
          .getState()
          .messages.filter((m) => m.role === "user" || m.role === "assistant")
          .slice(-8)
          .map((m) => ({ role: m.role, content: m.content }));

        const result = await askJarvis({
          data: {
            prompt: text,
            history: history.slice(0, -1),
            localTime: new Date().toString(),
          },
        });

        if (!stillMine()) return;
        const reply = result.ok ? result.text : result.error;
        addMessage({ id: newId(), role: "assistant", content: reply });
        await speak(reply, gen);
        if (stillMine()) setPhase("idle");
      } catch {
        if (!stillMine()) return;
        const fail = "Something went sideways in the mesh, sir. Try again.";
        addMessage({ id: newId(), role: "assistant", content: fail });
        setPhase("idle");
      }
    },
    [addMessage, clearMessages, setVoiceOn, setWakeOn, speak],
  );

  useEffect(() => {
    handleCommandRef.current = handleCommand;
  }, [handleCommand]);

  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const timerActive = timer !== null;
  useEffect(() => {
    if (!timerActive) return;
    const t = window.setInterval(() => {
      setTimer((cur) => {
        if (!cur) return null;
        if (cur.remaining <= 1) {
          window.setTimeout(() => {
            const msg = "Sir, your timer has elapsed.";
            addMessage({ id: newId(), role: "assistant", content: msg, kind: "timer" });
            const gen = ++genRef.current;
            void speak(msg, gen);
          }, 0);
          return null;
        }
        return { ...cur, remaining: cur.remaining - 1 };
      });
    }, 1000);
    return () => window.clearInterval(t);
  }, [timerActive, addMessage, speak]);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages.length, partial, timer]);

  useEffect(() => {
    try {
      if (sessionStorage.getItem("jarvis-booted") === "1") setBooting(false);
    } catch {
      /* ignore */
    }
  }, []);

  const finishBoot = useCallback(() => {
    setBooting(false);
    try {
      sessionStorage.setItem("jarvis-booted", "1");
    } catch {
      /* ignore */
    }
  }, []);

  const clock = useMemo(
    () =>
      new Intl.DateTimeFormat(undefined, {
        hour: "numeric",
        minute: "2-digit",
      }).format(now),
    [now],
  );

  const greeting = useMemo(() => greetingFor(now), [now]);
  const compact = messages.length > 0 || Boolean(timer);
  const caption = phaseCaption(phase, wakeOn, micArmed && speech.mode !== "off");

  function onOrbPress() {
    stopPlayback();
    setBanner(null);
    if (phase === "listening") {
      speech.disarm();
      if (wakeOn && micArmed) speech.armStandby();
      setPhase("idle");
      setPartial("");
      return;
    }
    if (!speech.supported) {
      setComposerOpen(true);
      setBanner("Voice engine unavailable here, sir. Type a command.");
      window.setTimeout(() => inputRef.current?.focus(), 50);
      return;
    }
    const ok = speech.listenForCommand();
    if (ok) {
      setMicArmed(true);
      setPhase("listening");
      setPartial("");
    } else {
      setComposerOpen(true);
    }
  }

  function enableVoiceSystems() {
    const ok = speech.armStandby();
    if (ok) {
      setMicArmed(true);
      setWakeOn(true);
      setBanner(null);
    }
  }

  const last = messages[messages.length - 1];

  return (
    <div className="hud-grid relative flex min-h-dvh flex-col overflow-hidden">
      <div className="scanlines pointer-events-none absolute inset-0 z-10" />
      {booting ? <BootScreen onDone={finishBoot} /> : null}

      <header className="relative z-20 flex items-center justify-between gap-3 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2">
        <div>
          <p className="font-mono text-xs tracking-widest text-primary uppercase">J.A.R.V.I.S.</p>
          <p className="font-mono text-xs tracking-widest text-muted">MK.I  //  OS</p>
        </div>
        <p className="font-mono text-sm tabular-nums text-fg">{clock}</p>
        <div className="flex items-center gap-1">
          <span
            className={cn(
              "mr-1 font-mono text-xs tracking-widest uppercase",
              phase === "listening" ? "text-primary" : "text-muted",
            )}
          >
            {phase === "idle" ? "STBY" : phase === "listening" ? "LIVE" : phase === "thinking" ? "CPU" : "VOX"}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="size-11 text-muted hover:text-fg"
            aria-label="Settings"
            onClick={() => setSettingsOpen((v) => !v)}
          >
            {settingsOpen ? <X className="size-5" /> : <Settings2 className="size-5" />}
          </Button>
        </div>
      </header>

      {settingsOpen ? (
        <div className="relative z-20 mx-4 mb-2 rounded-lg bg-surface p-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]">
          <div className="flex flex-col gap-2">
            <SettingsRow
              icon={voiceOn ? Volume2 : VolumeX}
              label="Voice replies"
              on={voiceOn}
              onToggle={() => setVoiceOn(!voiceOn)}
            />
            <SettingsRow
              icon={wakeOn ? Mic : MicOff}
              label={'Wake word "Hey Jarvis"'}
              on={wakeOn}
              onToggle={() => {
                const next = !wakeOn;
                setWakeOn(next);
                if (next && micArmed) speech.armStandby();
                if (!next && speech.mode === "standby") speech.disarm();
              }}
            />
            <Button
              variant="outline"
              size="sm"
              className="mt-1 w-full"
              onClick={() => {
                clearMessages();
                setTimer(null);
                setSettingsOpen(false);
              }}
            >
              Clear conversation
            </Button>
          </div>
        </div>
      ) : null}

      <div ref={listRef} className="relative z-20 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-2">
        {compact ? (
          <>
            {messages.map((m) => (
              <div key={m.id} className="flex flex-col gap-2">
                <MessageBubble message={m} />
                {m.kind === "diagnostics" && m.role === "assistant" ? <DiagnosticsCard /> : null}
                {m.kind === "suit" && m.role === "assistant" ? <SuitCard /> : null}
              </div>
            ))}
            {timer ? <TimerCard remaining={timer.remaining} total={timer.total} /> : null}
            {phase === "listening" && partial ? (
              <p className="font-mono text-sm text-primary/80">{partial}</p>
            ) : null}
            {phase === "thinking" ? (
              <p className="shimmer font-mono text-sm tracking-widest uppercase">Working</p>
            ) : null}
          </>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center">
            <p className="mb-1 text-center text-2xl font-semibold tracking-tight text-fg sm:text-3xl">{greeting}</p>
            <p className="mb-6 max-w-xs text-center text-sm text-muted">
              J.A.R.V.I.S. at your service. Say Hey Jarvis, tap the core, or type a command.
            </p>
          </div>
        )}
      </div>

      <div className="relative z-20 flex flex-col items-center gap-4 px-4 pb-2 pt-1">
        <JarvisOrb
          phase={phase === "boot" ? "idle" : phase}
          compact={compact}
          onPress={onOrbPress}
          caption={caption}
        />

        {speech.error ? <p className="max-w-sm text-center text-sm text-danger">{speech.error}</p> : null}
        {banner ? <p className="max-w-sm text-center text-sm text-muted">{banner}</p> : null}

        {!micArmed && speech.supported ? (
          <Button variant="outline" onClick={enableVoiceSystems} className="rounded-full px-5">
            <Power className="size-4" />
            Enable voice systems
          </Button>
        ) : null}

        <div className="chip-row flex w-full max-w-lg gap-2 overflow-x-auto pb-1">
          {SUGGESTIONS.map((s) => (
            <Button
              key={s}
              variant="hud"
              size="chip"
              className="shrink-0"
              onClick={() => void handleCommand(s)}
              disabled={phase === "thinking"}
            >
              {s}
            </Button>
          ))}
        </div>
      </div>

      <form
        className="relative z-20 mx-auto flex w-full max-w-lg items-center gap-2 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-2"
        onSubmit={(e) => {
          e.preventDefault();
          const value = draft.trim();
          if (value) void handleCommand(value);
        }}
      >
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="size-11 shrink-0 text-muted"
          aria-label={composerOpen ? "Hide keyboard" : "Show keyboard"}
          onClick={() => {
            setComposerOpen((v) => !v);
            window.setTimeout(() => inputRef.current?.focus(), 40);
          }}
        >
          <Keyboard className="size-5" />
        </Button>
        <div
          className={cn(
            "flex min-h-11 flex-1 items-center rounded-xl bg-surface px-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)] transition-[opacity] duration-150",
            composerOpen || draft ? "opacity-100" : "opacity-90",
          )}
        >
          <input
            ref={inputRef}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Type a command"
            aria-label="Command"
            className="h-11 w-full bg-transparent text-base text-fg outline-none placeholder:text-muted"
            suppressHydrationWarning
          />
        </div>
        <Button
          type="button"
          variant={phase === "listening" ? "default" : "hud"}
          size="icon"
          className="size-12 shrink-0 rounded-full"
          aria-label="Talk"
          onClick={onOrbPress}
        >
          <Mic className="size-5" />
        </Button>
      </form>

      <p className="sr-only" aria-live="polite">
        {last?.role === "assistant" ? last.content : partial}
      </p>
    </div>
  );
}

function SettingsRow({
  icon: Icon,
  label,
  on,
  onToggle,
}: {
  icon: typeof Volume2;
  label: string;
  on: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="flex h-11 items-center justify-between gap-3 rounded-md px-2 text-left hover:bg-primary/10"
    >
      <span className="flex items-center gap-2 text-sm text-fg">
        <Icon className="size-4 text-primary" strokeWidth={1.75} />
        {label}
      </span>
      <span
        className={cn(
          "relative h-6 w-11 rounded-full transition-colors duration-150",
          on ? "bg-primary" : "bg-primary/20",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-5 rounded-full bg-bg transition-transform duration-150",
            on ? "translate-x-5" : "translate-x-0.5",
          )}
        />
      </span>
    </button>
  );
}
