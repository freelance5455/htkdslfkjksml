import { useCallback, useEffect, useRef, useState } from "react";

type SpeechRecognitionLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: SpeechRecEvent) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

type SpeechRecEvent = {
  resultIndex: number;
  results: ArrayLike<{
    isFinal: boolean;
    0: { transcript: string };
  }>;
};

type RecCtor = new () => SpeechRecognitionLike;

function getCtor(): RecCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: RecCtor;
    webkitSpeechRecognition?: RecCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export const WAKE_RE =
  /\b(?:hey|hi|ok|okay|yo)\s+(?:jarvis|jarvice|jarviss|jar vis|jarvys)\b/i;

export function stripWakeWord(transcript: string) {
  return transcript.replace(WAKE_RE, " ").replace(/\s+/g, " ").trim();
}

export function hasWakeWord(transcript: string) {
  return WAKE_RE.test(transcript);
}

type Mode = "off" | "standby" | "command";

type Options = {
  enabled: boolean;
  onCommand: (text: string) => void;
  onWake: () => void;
  onPartial: (text: string) => void;
  paused: boolean;
};

export function useJarvisSpeech({ enabled, onCommand, onWake, onPartial, paused }: Options) {
  const [supported, setSupported] = useState(false);
  const [permission, setPermission] = useState<"unknown" | "granted" | "denied">("unknown");
  const [mode, setMode] = useState<Mode>("off");
  const [error, setError] = useState<string | null>(null);

  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const modeRef = useRef<Mode>("off");
  const wantRef = useRef(false);
  const pausedRef = useRef(paused);
  const enabledRef = useRef(enabled);
  const callbacks = useRef({ onCommand, onWake, onPartial });

  useEffect(() => {
    callbacks.current = { onCommand, onWake, onPartial };
  }, [onCommand, onWake, onPartial]);

  useEffect(() => {
    pausedRef.current = paused;
  }, [paused]);

  useEffect(() => {
    enabledRef.current = enabled;
  }, [enabled]);

  useEffect(() => {
    setSupported(Boolean(getCtor()));
  }, []);

  const setModeBoth = useCallback((next: Mode) => {
    modeRef.current = next;
    setMode(next);
  }, []);

  const stopRec = useCallback(() => {
    wantRef.current = false;
    const rec = recRef.current;
    if (!rec) return;
    try {
      rec.onend = null;
      rec.abort();
    } catch {
      /* ignore */
    }
    recRef.current = null;
  }, []);

  const startRec = useCallback(
    (nextMode: Mode) => {
      const Ctor = getCtor();
      if (!Ctor) {
        setError("Voice engine unavailable in this browser, sir.");
        return false;
      }
      stopRec();
      wantRef.current = true;
      const rec = new Ctor();
      rec.continuous = nextMode === "standby";
      rec.interimResults = true;
      rec.lang = "en-US";

      rec.onstart = () => {
        setPermission("granted");
        setError(null);
      };

      rec.onerror = (ev) => {
        if (ev.error === "not-allowed") {
          setPermission("denied");
          setError("Microphone access denied. Typed commands still work, sir.");
          wantRef.current = false;
          setModeBoth("off");
          return;
        }
        if (ev.error === "no-speech") return;
        if (ev.error === "aborted") return;
        setError(ev.error);
      };

      rec.onresult = (ev) => {
        if (pausedRef.current) return;
        let interim = "";
        let finalText = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const piece = ev.results[i];
          if (!piece) continue;
          const t = piece[0]?.transcript ?? "";
          if (piece.isFinal) finalText += t;
          else interim += t;
        }
        const heard = (finalText || interim).trim();
        if (!heard) return;

        if (modeRef.current === "standby") {
          callbacks.current.onPartial(heard);
          if (hasWakeWord(heard) && finalText) {
            const rest = stripWakeWord(finalText);
            callbacks.current.onWake();
            if (rest.length > 1) {
              callbacks.current.onCommand(rest);
              setModeBoth("standby");
            } else {
              setModeBoth("command");
            }
          }
          return;
        }

        if (modeRef.current === "command") {
          callbacks.current.onPartial(heard);
          if (finalText.trim()) {
            const rest = stripWakeWord(finalText) || finalText.trim();
            callbacks.current.onCommand(rest);
            setModeBoth(enabledRef.current ? "standby" : "off");
          }
        }
      };

      rec.onend = () => {
        if (!wantRef.current) return;
        if (modeRef.current === "off") return;
        const resume = () => {
          const wantMode = modeRef.current;
          if (wantMode === "off" || !wantRef.current) return;
          const shouldBeContinuous = wantMode === "standby";
          if (rec.continuous === shouldBeContinuous) {
            try {
              rec.start();
            } catch {
              window.setTimeout(() => {
                try {
                  rec.start();
                } catch {
                  /* ignore */
                }
              }, 300);
            }
            return;
          }
          startRec(wantMode);
        };
        if (pausedRef.current) {
          window.setTimeout(() => {
            if (!wantRef.current || pausedRef.current || modeRef.current === "off") return;
            resume();
          }, 280);
          return;
        }
        resume();
      };

      recRef.current = rec;
      setModeBoth(nextMode);
      try {
        rec.start();
        return true;
      } catch {
        setError("Could not start the microphone, sir.");
        return false;
      }
    },
    [setModeBoth, stopRec],
  );

  const armStandby = useCallback(() => {
    if (!enabledRef.current) return false;
    return startRec("standby");
  }, [startRec]);

  const listenForCommand = useCallback(() => {
    return startRec("command");
  }, [startRec]);

  const disarm = useCallback(() => {
    stopRec();
    setModeBoth("off");
  }, [stopRec, setModeBoth]);

  useEffect(() => {
    return () => stopRec();
  }, [stopRec]);

  useEffect(() => {
    if (!enabled && modeRef.current === "standby") {
      disarm();
    }
  }, [enabled, disarm]);

  return {
    supported,
    permission,
    mode,
    error,
    armStandby,
    listenForCommand,
    disarm,
  };
}

export function speakBrowser(text: string): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      resolve();
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const pick =
      voices.find((v) => /en-GB/i.test(v.lang) && /male|daniel|george|malcolm|arthur|rishi/i.test(v.name)) ||
      voices.find((v) => /en-GB/i.test(v.lang)) ||
      voices.find((v) => /en-US/i.test(v.lang) && /male|david|alex|daniel/i.test(v.name)) ||
      voices[0];
    if (pick) utter.voice = pick;
    utter.rate = 1.02;
    utter.pitch = 0.92;
    utter.onend = () => resolve();
    utter.onerror = () => resolve();
    window.speechSynthesis.speak(utter);
  });
}

export function stopBrowserSpeech() {
  if (typeof window === "undefined") return;
  window.speechSynthesis?.cancel();
}
