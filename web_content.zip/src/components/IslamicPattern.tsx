import React from 'react';

interface Props {
  className?: string;
  size?: number;
}

export const IslamicPattern: React.FC<Props> = ({ className = 'text-amber-500/30', size = 64 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* 8-pointed Islamic Star Rub el Hizb with layered geometry */}
      <rect x="25" y="25" width="50" height="50" stroke="currentColor" strokeWidth="2" transform="rotate(0 50 50)" />
      <rect x="25" y="25" width="50" height="50" stroke="currentColor" strokeWidth="2" transform="rotate(45 50 50)" />
      <circle cx="50" cy="50" r="15" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="50" cy="50" r="4" fill="currentColor" />
      <circle cx="50" cy="18" r="2.5" fill="currentColor" />
      <circle cx="50" cy="82" r="2.5" fill="currentColor" />
      <circle cx="18" cy="50" r="2.5" fill="currentColor" />
      <circle cx="82" cy="50" r="2.5" fill="currentColor" />
      <path d="M50 35 L50 65 M35 50 L65 50" stroke="currentColor" strokeWidth="1" opacity="0.6" />
    </svg>
  );
};

export const IslamicCrescent: React.FC<Props> = ({ className = 'text-amber-400', size = 48 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M26 8C16.059 8 8 16.059 8 26C8 35.941 16.059 44 26 44C32.185 44 37.643 40.871 40.89 36.104C39.317 36.685 37.604 37 35.812 37C25.969 37 18 29.031 18 19.188C18 14.617 19.722 10.45 22.562 7.288C23.684 7.426 24.827 8 26 8Z"
        fill="currentColor"
      />
      <polygon
        points="37,13 39.5,18 45,18.5 41,22.5 42,28 37,25 32,28 33,22.5 29,18.5 34.5,18"
        fill="currentColor"
      />
    </svg>
  );
};

export const IslamicArchBorder: React.FC<{ className?: string }> = ({ className = 'text-amber-600/30' }) => {
  return (
    <div className={`w-full flex items-center justify-center gap-2.5 my-3 ${className}`}>
      <span className="h-[1px] flex-1 bg-gradient-to-l from-current to-transparent opacity-40"></span>
      <span className="text-sm font-serif opacity-80 select-none">۞</span>
      <span className="h-[1px] flex-1 bg-gradient-to-r from-current to-transparent opacity-40"></span>
    </div>
  );
};

