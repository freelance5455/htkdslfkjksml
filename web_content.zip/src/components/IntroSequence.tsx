import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../audio/SoundEngine';
import { GameEngine } from '../game/core/GameEngine';
import { ShieldAlert, Crosshair, Sparkles, Skull, UserCheck, Flame } from 'lucide-react';

interface IntroSequenceProps {
  onComplete: () => void;
  engine?: GameEngine | null;
}

type IntroPhase =
  | 'dark_intro'     // 0 - 1.5s: Dark screen & ambient rumble
  | 'running_zombie' // 1.5s - 4.1s: Small zombie runs across slowly (2.6s)
  | 'title_logo'     // 4.1s - 6.3s: Game title & studio branding (2.2s)
  | 'creator'        // 6.3s - 8.5s: Creator credit: Kyle Reece Willoughby (2.2s)
  | 'calibration'    // 8.5s - 10.0s: Short calibration screen (~1.5s)
  | 'loading';       // 10.0s+: Asynchronous loading of base systems

export const IntroSequence: React.FC<IntroSequenceProps> = ({ onComplete, engine }) => {
  const [phase, setPhase] = useState<IntroPhase>('dark_intro');
  const [zombieX, setZombieX] = useState(-15);
  const [zombieBob, setZombieBob] = useState(0);
  const [fireGlow, setFireGlow] = useState(false);
  const [loadingStage, setLoadingStage] = useState('INITIALIZING...');
  const [loadingProgress, setLoadingProgress] = useState(10);

  const animFrameRef = useRef<number | null>(null);

  // STEP 1 & 2: Dark screen & Ambient rumble (1.5 seconds)
  useEffect(() => {
    sound.init();

    const darkTimer = setTimeout(() => {
      setPhase('running_zombie');
      startSlowZombieRun();
    }, 1500);

    return () => {
      clearTimeout(darkTimer);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  // STEP 3: Slow zombie runs across screen (Duration: 2.6 seconds)
  const startSlowZombieRun = () => {
    const duration = 2600; // 2.6 seconds (Requirement 26: 2-3s crossing)
    const startTime = performance.now();

    const animate = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);

      // Smooth easing: starts smoothly, steady running middle, exits smoothly
      const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

      // Traverses from -15% off-screen to 115% off-screen
      const posX = -15 + eased * 130;
      setZombieX(posX);

      // Running step cadence bobbing
      const bob = Math.sin(t * Math.PI * 14) * 6;
      setZombieBob(bob);

      if (t < 1) {
        animFrameRef.current = requestAnimationFrame(animate);
      } else {
        // STEP 4: Game Title appears
        setPhase('title_logo');
        sound.playIntroStinger();
        setTimeout(() => setFireGlow(true), 400);

        // Advance to Creator Screen after 2.2s
        setTimeout(() => {
          setPhase('creator');
        }, 2200);
      }
    };

    animFrameRef.current = requestAnimationFrame(animate);
  };

  // STEP 5: Creator Screen transition
  useEffect(() => {
    if (phase === 'creator') {
      // Creator screen lasts 2.2 seconds
      const timer = setTimeout(() => {
        // STEP 6: Short calibration screen (~1.4 seconds)
        setPhase('calibration');
        sound.playRoundStart();
      }, 2200);

      return () => clearTimeout(timer);
    }

    if (phase === 'calibration') {
      // Calibration transition lasts ~1.4 seconds
      const timer = setTimeout(() => {
        // STEP 7 & 8: Enter actual loading screen
        setPhase('loading');
        executeAssetLoading();
      }, 1400);

      return () => clearTimeout(timer);
    }
  }, [phase]);

  // STEP 8: Actual Loading Screen with Asynchronous Phased Progress
  const executeAssetLoading = () => {
    sound.startCinematicMusic();

    if (engine) {
      engine.initAssetsAsync((stage, pct) => {
        setLoadingStage(stage);
        setLoadingProgress(pct);
      }).then(() => {
        setTimeout(() => {
          onComplete();
        }, 400);
      });
    } else {
      const stages = [
        { label: 'INITIALIZING...', pct: 15 },
        { label: 'LOADING ENVIRONMENT...', pct: 35 },
        { label: 'LOADING CHARACTERS...', pct: 55 },
        { label: 'LOADING WEAPONS...', pct: 75 },
        { label: 'LOADING ZOMBIE SYSTEM...', pct: 90 },
        { label: 'OPTIMIZING...', pct: 98 },
        { label: 'READY', pct: 100 },
      ];

      let idx = 0;
      const interval = setInterval(() => {
        if (idx < stages.length) {
          setLoadingStage(stages[idx].label);
          setLoadingProgress(stages[idx].pct);
          idx++;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 450);
        }
      }, 480);
    }
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black select-none overflow-hidden font-sans">
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_bottom,transparent_50%,rgba(0,0,0,0.8)_51%)] [background-size:100%_4px] pointer-events-none" />

      {/* STEP 1 & 2: DARK SCREEN INTRO (0 - 1.5s) */}
      {phase === 'dark_intro' && (
        <div className="flex flex-col items-center justify-center text-center animate-pulse">
          <div className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping mb-3" />
          <span className="font-mono-tech text-xs tracking-[0.4em] text-zinc-600 uppercase">
            INITIALIZING BLACKOUT PROTOCOL...
          </span>
        </div>
      )}

      {/* STEP 3: SMALL ZOMBIE RUNS ACROSS SCREEN SLOWLY (2.6 SECONDS) */}
      {phase === 'running_zombie' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center">
          <div
            className="absolute bottom-1/2 flex items-center gap-2 will-change-transform drop-shadow-[0_0_14px_rgba(239,68,68,0.7)]"
            style={{
              left: `${zombieX}%`,
              transform: `translateY(${zombieBob}px)`,
            }}
          >
            <div className="relative flex flex-col items-center">
              <div className="w-9 h-9 rounded-lg bg-zinc-900 border border-red-500/80 flex items-center justify-center shadow-lg relative">
                <Skull className="w-6 h-6 text-red-500" />
                <div className="absolute top-2 left-2 w-1.5 h-1.5 rounded-full bg-red-400 shadow-[0_0_6px_#ef4444]" />
                <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-red-400 shadow-[0_0_6px_#ef4444]" />
              </div>

              <div className="w-5 h-6 bg-zinc-800 rounded-sm mt-0.5" />
              <div className="flex gap-1 -mt-1">
                <div className="w-2 h-4 bg-zinc-700 rounded-sm transform -rotate-12" />
                <div className="w-2 h-4 bg-zinc-700 rounded-sm transform rotate-12" />
              </div>
            </div>

            <div className="w-8 h-1 bg-gradient-to-r from-red-600/40 to-transparent rounded-full blur-xs" />
          </div>

          <span className="absolute bottom-1/3 font-mono-tech text-xs tracking-[0.35em] text-zinc-600 uppercase animate-pulse">
            OUTBREAK DETECTED...
          </span>
        </div>
      )}

      {/* STEP 4: GAME TITLE - BLACKOUT: DEAD RISING */}
      {phase === 'title_logo' && (
        <div className="flex flex-col items-center justify-center text-center px-4 animate-fade-in">
          <div className="relative mb-5">
            <div
              className={`w-28 h-28 rounded-3xl bg-gradient-to-br from-red-600 to-red-950 flex items-center justify-center border-2 border-red-500 shadow-2xl transition-all duration-700 ${
                fireGlow ? 'shadow-red-600/80 scale-105 border-red-400' : 'shadow-red-950/40 scale-95'
              }`}
            >
              <ShieldAlert className="w-16 h-16 text-white animate-pulse" />
            </div>

            <div
              className={`absolute -inset-4 bg-red-600/30 blur-2xl rounded-full -z-10 transition-opacity duration-700 ${
                fireGlow ? 'opacity-100' : 'opacity-0'
              }`}
            />
          </div>

          <div className="tracking-[0.45em] text-red-500 font-mono-tech text-sm uppercase mb-2">
            BLACKOUT ZOMBIE STUDIOS
          </div>

          <h1 className="text-6xl sm:text-8xl font-teko tracking-wider text-white font-extrabold uppercase drop-shadow-2xl leading-none">
            BLACKOUT: <span className="text-red-600">DEAD RISING</span>
          </h1>

          <div className="flex items-center gap-2 mt-3">
            <div className="h-0.5 w-16 bg-red-600" />
            <Sparkles className="w-4 h-4 text-red-400" />
            <div className="h-0.5 w-16 bg-red-600" />
          </div>

          <div className="text-zinc-500 font-mono-tech text-xs tracking-widest mt-4 uppercase">
            POLISHED 3D SURVIVAL FPS ENGINE // 10 THEATERS
          </div>
        </div>
      )}

      {/* STEP 5: CREATOR CREDIT SCREEN (KYLE REECE WILLOUGHBY) */}
      {phase === 'creator' && (
        <div className="flex flex-col items-center justify-center text-center px-6 animate-fade-in relative max-w-2xl">
          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-2xl bg-zinc-900/90 border border-zinc-700/80 flex items-center justify-center shadow-2xl relative overflow-hidden">
              <UserCheck className="w-10 h-10 text-red-500" />
              <div className="absolute inset-0 bg-gradient-to-tr from-red-600/10 via-transparent to-white/5" />
            </div>
            <div className="absolute -inset-3 bg-red-600/20 blur-xl rounded-full -z-10" />
          </div>

          <span className="font-mono-tech text-xs sm:text-sm tracking-[0.4em] text-zinc-400 uppercase mb-3">
            GAME CREATED BY
          </span>

          <h2 className="text-5xl sm:text-7xl md:text-8xl font-teko uppercase font-extrabold text-white tracking-wider leading-none drop-shadow-2xl">
            KYLE REECE WILLOUGHBY
          </h2>

          <div className="h-0.5 w-24 bg-gradient-to-r from-transparent via-red-600 to-transparent mt-4" />

          <div className="text-zinc-600 font-mono-tech text-[11px] tracking-widest mt-4 uppercase flex items-center gap-2">
            <Flame className="w-3.5 h-3.5 text-red-500" />
            ORIGINAL DESIGN & DEVELOPMENT
          </div>
        </div>
      )}

      {/* STEP 6: SHORT CALIBRATION SCREEN (~1.4 SECONDS) */}
      {phase === 'calibration' && (
        <div className="flex flex-col items-center justify-center text-center px-6 animate-fade-in">
          <div className="relative w-16 h-16 rounded-full border-2 border-red-500/80 flex items-center justify-center mb-5 shadow-[0_0_18px_rgba(239,68,68,0.4)]">
            <Crosshair className="w-8 h-8 text-red-500 animate-spin" />
            <div className="absolute inset-0 border-t-2 border-white rounded-full animate-spin" style={{ animationDuration: '0.8s' }} />
          </div>

          <span className="font-mono-tech text-xs sm:text-sm text-red-400 tracking-[0.3em] uppercase font-bold">
            CALIBRATING WEAPONS & COMBAT THEATER...
          </span>

          <div className="flex items-center gap-1.5 mt-3">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
            <span className="font-mono-tech text-[10px] text-zinc-500 uppercase tracking-widest">
              SYSTEM CHECK OPTIMAL
            </span>
          </div>
        </div>
      )}

      {/* STEP 7 & 8: ACTUAL ASYNCHRONOUS LOADING SCREEN */}
      {phase === 'loading' && (
        <div className="relative w-full h-full flex flex-col items-center justify-between p-8 sm:p-12 bg-gradient-to-b from-zinc-950 via-zinc-900 to-black animate-fade-in">
          <div className="w-full flex justify-between items-center z-10">
            <div className="flex items-center gap-2 text-red-500 font-mono-tech text-xs tracking-widest uppercase">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              BLACKOUT PROTOCOL // LEVEL 5
            </div>
            <div className="text-zinc-500 font-mono-tech text-xs">
              INITIALIZING THEATER ASSETS
            </div>
          </div>

          <div className="flex flex-col items-center text-center max-w-xl z-10">
            <div className="w-16 h-16 rounded-2xl bg-red-950/80 border border-red-700/80 flex items-center justify-center mb-4 shadow-xl shadow-red-900/40">
              <Crosshair className="w-9 h-9 text-red-400" />
            </div>

            <h1 className="text-6xl sm:text-8xl font-teko uppercase font-extrabold text-white tracking-wide leading-none drop-shadow-2xl">
              BLACKOUT: <span className="text-red-600">DEAD RISING</span>
            </h1>

            <p className="text-zinc-400 text-sm font-mono-tech tracking-wider mt-2 mb-6">
              TACTICAL ZOMBIE COMBAT // REPAIR BARRICADES // SURVIVE 100+ WAVES
            </p>

            <div className="p-3.5 rounded-xl bg-zinc-950/80 border border-zinc-800 text-zinc-300 font-mono-tech text-xs max-w-md shadow-lg">
              <span className="text-amber-400 font-bold block mb-1">TACTICAL INTEL:</span>
              Aiming down sights (ADS) tightens bullet spread. Tap Slide while sprinting to evade zombie attacks.
            </div>
          </div>

          <div className="w-full max-w-md flex flex-col items-center z-10">
            <div className="w-full h-3 bg-zinc-950 border border-zinc-800 rounded-full overflow-hidden p-0.5 mb-2.5 shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-red-500 rounded-full transition-all duration-150 shadow-lg shadow-red-500/50"
                style={{ width: `${loadingProgress}%` }}
              />
            </div>

            <div className="w-full flex justify-between font-mono-tech text-xs text-zinc-400">
              <span className="text-amber-300 font-bold tracking-wider">{loadingStage}</span>
              <span className="text-red-400 font-bold">{loadingProgress}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
