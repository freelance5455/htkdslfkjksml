import React, { useState } from 'react';
import { AlertOctagon, X, Check } from 'lucide-react';
import { Player } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface FoulModalProps {
  isOpen: boolean;
  onClose: () => void;
  activePlayer: Player;
  otherPlayers: Player[];
  onCommitFoul: (points: number, reason: string, awardToOpponentId?: number) => void;
}

const COMMON_FOULS = [
  { reason: 'عدم برخورد با توپ هدف (Miss)', defaultPoints: 4 },
  { reason: 'افتادن توپ سفید در پاکت (In-Off / پاکت سفید)', defaultPoints: 4 },
  { reason: 'برخورد ابتدا با توپ نادرست', defaultPoints: 4 },
  { reason: 'خطا روی توپ آبی', defaultPoints: 5 },
  { reason: 'خطا روی توپ صورتی', defaultPoints: 6 },
  { reason: 'خطا روی توپ مشکی', defaultPoints: 7 },
  { reason: 'ضربه دوگانه / هل دادن توپ (Push Stroke)', defaultPoints: 4 },
  { reason: 'خروج توپ از میز (Ball off table)', defaultPoints: 4 },
];

export const FoulModal: React.FC<FoulModalProps> = ({
  isOpen,
  onClose,
  activePlayer,
  otherPlayers,
  onCommitFoul,
}) => {
  const [selectedPoints, setSelectedPoints] = useState<number>(4);
  const [selectedReason, setSelectedReason] = useState<string>('عدم برخورد با توپ هدف (Miss)');
  const [targetOpponentId, setTargetOpponentId] = useState<number>(
    otherPlayers.length > 0 ? otherPlayers[0].id : -1
  );
  const [awardToOpponent, setAwardToOpponent] = useState<boolean>(true);

  if (!isOpen) return null;

  const handleConfirm = () => {
    onCommitFoul(
      selectedPoints,
      selectedReason,
      awardToOpponent && targetOpponentId !== -1 ? targetOpponentId : undefined
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700/80 p-5 shadow-2xl text-slate-100"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl border border-rose-500/30">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">ثبت خطا (Foul)</h2>
              <p className="text-xs text-slate-400">بازیکن متخلف: {activePlayer.name}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Penalty Points Selection */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            جریمه خطا (امتیاز):
          </label>
          <div className="grid grid-cols-4 gap-2">
            {[4, 5, 6, 7].map((pts) => (
              <button
                key={pts}
                type="button"
                onClick={() => setSelectedPoints(pts)}
                className={`py-2.5 rounded-xl font-black text-sm transition-all border ${
                  selectedPoints === pts
                    ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/30'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                {toPersianDigits(pts)} امتیاز
              </button>
            ))}
          </div>
        </div>

        {/* Common foul types */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">نوع خطا:</label>
          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {COMMON_FOULS.map((item) => (
              <button
                key={item.reason}
                type="button"
                onClick={() => {
                  setSelectedReason(item.reason);
                  setSelectedPoints(item.defaultPoints);
                }}
                className={`w-full text-right px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors border ${
                  selectedReason === item.reason
                    ? 'bg-slate-800 border-rose-500/60 text-rose-300 font-semibold'
                    : 'bg-slate-950/40 border-slate-800/80 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <span>{item.reason}</span>
                <span className="text-[11px] text-slate-400">{toPersianDigits(item.defaultPoints)} امتیازی</span>
              </button>
            ))}
          </div>
        </div>

        {/* Destination of penalty: Official snooker gives points to opponent */}
        <div className="mb-5 bg-slate-950/60 border border-slate-800 p-3 rounded-2xl space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300 font-medium">نحوه اعمال جریمه:</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setAwardToOpponent(true)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                  awardToOpponent
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                افزودن به حریف (رسمی)
              </button>
              <button
                type="button"
                onClick={() => setAwardToOpponent(false)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                  !awardToOpponent
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                کسر از بازیکن
              </button>
            </div>
          </div>

          {awardToOpponent && otherPlayers.length > 1 && (
            <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
              <span className="text-slate-400">افزودن امتیاز به:</span>
              <select
                value={targetOpponentId}
                onChange={(e) => setTargetOpponentId(Number(e.target.value))}
                className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-slate-200 text-xs focus:outline-none"
              >
                {otherPlayers.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleConfirm}
            className="flex-1 py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>ثبت خطا و پایان نوبت</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition-colors cursor-pointer"
          >
            انصراف
          </button>
        </div>
      </div>
    </div>
  );
};
