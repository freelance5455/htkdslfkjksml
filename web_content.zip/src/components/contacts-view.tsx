import { Avatar } from "@/components/avatar";
import { ScreenHeader } from "@/components/phone-shell";
import { formatPhone } from "@/lib/emergency";
import { useAppStore } from "@/lib/store";
import type { LisaPolicy } from "@/lib/types";
import { Plus, Search, Star } from "lucide-react";

const POLICY_LABEL: Record<LisaPolicy, string> = {
  always_myself: "Always you",
  lisa_may: "Lisa may handle",
  never_lisa: "Never Lisa",
};

export function ContactsView() {
  const contacts = useAppStore((s) => s.contacts);
  const search = useAppStore((s) => s.search);
  const setSearch = useAppStore((s) => s.setSearch);
  const setOverlay = useAppStore((s) => s.setOverlay);

  const q = search.trim().toLowerCase();
  const filtered = contacts.filter((c) => {
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      c.number.includes(q) ||
      (c.company ?? "").toLowerCase().includes(q)
    );
  });
  const favs = filtered.filter((c) => c.favorite);
  const rest = filtered.filter((c) => !c.favorite);

  return (
    <div>
      <ScreenHeader
        title="Contacts"
        subtitle={`${contacts.length} on this device`}
        action={
          <button
            type="button"
            aria-label="Add contact"
            onClick={() => setOverlay({ kind: "new-contact" })}
            className="grid size-11 place-items-center rounded-full bg-muted text-accent"
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <div className="px-5 pb-3">
        <label className="flex h-11 items-center gap-2 rounded-md bg-muted px-3">
          <Search className="size-4 text-subtle" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name or number"
            className="h-full w-full bg-transparent text-sm outline-none placeholder:text-subtle"
          />
        </label>
      </div>
      {filtered.length === 0 ? (
        <p className="px-5 text-sm text-muted-foreground">No contacts match.</p>
      ) : (
        <>
          {favs.length > 0 ? (
            <section className="mb-2">
              <h2 className="flex items-center gap-1.5 px-5 pb-2 text-xs tracking-wide text-subtle uppercase">
                <Star className="size-3" /> Favorites
              </h2>
              {favs.map((c) => (
                <ContactRow
                  key={c.id}
                  name={c.name}
                  number={c.number}
                  meta={POLICY_LABEL[c.policy]}
                  onClick={() => setOverlay({ kind: "contact", contactId: c.id })}
                />
              ))}
            </section>
          ) : null}
          <section>
            {favs.length > 0 ? (
              <h2 className="px-5 pb-2 text-xs tracking-wide text-subtle uppercase">All</h2>
            ) : null}
            {rest.map((c) => (
              <ContactRow
                key={c.id}
                name={c.name}
                number={c.number}
                meta={`${c.company ? `${c.company} · ` : ""}${POLICY_LABEL[c.policy]}`}
                onClick={() => setOverlay({ kind: "contact", contactId: c.id })}
              />
            ))}
          </section>
        </>
      )}
    </div>
  );
}

function ContactRow({
  name,
  number,
  meta,
  onClick,
}: {
  name: string;
  number: string;
  meta: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60"
    >
      <Avatar name={name} />
      <div className="min-w-0">
        <p className="truncate font-medium">{name}</p>
        <p className="text-xs text-muted-foreground">
          {formatPhone(number)} · {meta}
        </p>
      </div>
    </button>
  );
}
