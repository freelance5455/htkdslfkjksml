import React from 'react';
import { Shield, Sparkles, Mic, Volume2, Cpu, Activity, Battery, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface HologramDisplayProps {
  status: 'ready' | 'listening' | 'thinking' | 'speaking';
  userName: string;
  rmsVolume: number;
  batteryLevel?: number;
  latencyMs?: number;
  onMicClick?: () => void;
  isListening?: boolean;
}

export const HologramDisplay: React.FC<HologramDisplayProps> = ({
  status,
  userName,
  rmsVolume,
  batteryLevel = 100,
  latencyMs = 24,
  onMicClick,
  isListening = false,
}) => {
  const getStatusLabel = () => {
    switch (status) {
      case 'listening':
        return { text: 'LISTENING TO BOSS...', color: 'text-fuchsia-400', dot: 'bg-fuchsia-400' };
      case 'thinking':
        return { text: 'JARVIS QUANTUM PROCESSING...', color: 'text-amber-400', dot: 'bg-amber-400' };
      case 'speaking':
        return { text: 'TRANSMITTING VOCAL RESPONSE...', color: 'text-cyan-300', dot: 'bg-cyan-400' };
      default:
        return { text: 'SYSTEM OPERATIONAL · STANDBY', color: 'text-emerald-400', dot: 'bg-emerald-400' };
    }
  };

  const statusInfo = getStatusLabel();

  // Waveform bars based on rmsVolume or animation
  const bars = [0.4, 0.7, 1.0, 0.6, 0.85, 0.5, 0.9, 0.65, 0.4];

  return (
    <div className="relative w-full rounded-3xl bg-gradient-to-b from-slate-950 via-[#0a1224] to-[#060b17] border border-cyan-500/20 p-5 md:p-6 shadow-2xl shadow-cyan-950/40 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute inset-0 hologram-vignette pointer-events-none" />

      {/* Top Telemetry Bar */}
      <div className="relative z-10 flex items-center justify-between border-b border-cyan-900/40 pb-3 text-xs font-mono-tech text-slate-400">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${statusInfo.dot} opacity-75`} />
            <span className={`relative inline-flex rounded-full h-2 w-2 ${statusInfo.dot}`} />
          </span>
          <span className={`font-semibold tracking-wider ${statusInfo.color}`}>{statusInfo.text}</span>
        </div>

        <div className="hidden sm:flex items-center gap-4 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 text-cyan-400/90">
            <Cpu className="w-3.5 h-3.5" />
            <span>CORE: GEMINI 2.5</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-400/90">
            <Activity className="w-3.5 h-3.5" />
            <span>PING: {latencyMs}ms</span>
          </div>
          <div className="flex items-center gap-1.5 text-amber-400/90">
            <Battery className="w-3.5 h-3.5" />
            <span>{batteryLevel}%</span>
          </div>
        </div>
      </div>

      {/* Holographic Center Stage */}
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-center gap-6 py-4 md:py-6">
        {/* Hologram Avatar Orb */}
        <div className="relative flex items-center justify-center">
          {/* Outer rotating cyber ring */}
          <div className="absolute w-52 h-52 md:w-60 md:h-60 rounded-full border border-dashed border-cyan-400/30 animate-spin-slow pointer-events-none" />
          
          {/* Middle counter-rotating ring with gradient notches */}
          <div className="absolute w-44 h-44 md:w-52 md:h-52 rounded-full border border-fuchsia-500/40 animate-spin-reverse pointer-events-none" />
          
          {/* Inner pulse aura */}
          <motion.div
            animate={{
              scale: isListening || status === 'speaking' || status === 'thinking' ? [1, 1.07, 1] : [1, 1.02, 1],
              opacity: isListening ? [0.6, 1, 0.6] : [0.4, 0.7, 0.4],
            }}
            transition={{ repeat: Infinity, duration: isListening ? 1.2 : 2.5 }}
            className="absolute w-40 h-40 md:w-48 md:h-48 rounded-full bg-cyan-500/10 blur-xl pointer-events-none"
          />

          {/* Hologram Avatar Image Container */}
          <div className="relative w-36 h-36 md:w-44 md:h-44 rounded-full p-1 bg-gradient-to-tr from-cyan-500 via-slate-900 to-fuchsia-500 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full rounded-full overflow-hidden bg-[#070e1c] relative scanlines border border-cyan-400/50">
              <img
                src="/assets/hologram_art.png"
                alt="Rubel Boss AI Hologram"
                className="w-full h-full object-cover object-center filter contrast-110 brightness-105"
                onError={(e) => {
                  // Fallback if image path has issue
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              {/* Cyan holographic tint overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/15 via-transparent to-fuchsia-500/20 mix-blend-screen pointer-events-none" />

              {/* Holographic scanlines grid */}
              <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_60%,rgba(0,229,255,0.25)_100%)] pointer-events-none" />
            </div>

            {/* Pedestal Tag */}
            <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 bg-slate-950/90 border border-cyan-400/80 px-3 py-0.5 rounded-full text-[10px] font-mono-tech tracking-wider text-cyan-300 shadow-md flex items-center gap-1.5 whitespace-nowrap">
              <Zap className="w-3 h-3 text-cyan-400" />
              <span>JARVIS RB-01</span>
            </div>
          </div>
        </div>

        {/* Identity & Audio Reactive HUD */}
        <div className="flex flex-col items-center md:items-start text-center md:text-left max-w-sm">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono-tech mb-2">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI QUANTUM MATRIX</span>
          </div>

          <h2 className="text-2xl md:text-3xl font-orbitron font-extrabold tracking-wider bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
            RUBEL BOSS AI
          </h2>

          <div className="flex items-center gap-1.5 text-fuchsia-400 text-xs font-semibold tracking-wide mt-1">
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>CREATED BY RUBEL BOSS · BOSS: {userName}</span>
          </div>

          <p className="text-slate-400 text-xs mt-2 line-clamp-2">
            Voice Recognition · Speech Synthesis · Screen & Camera Vision AI · Notes · Device Telemetry
          </p>

          {/* Audio Waveform Equalizer Display */}
          <div className="mt-4 flex items-center gap-3 bg-slate-950/70 border border-slate-800 rounded-xl px-3.5 py-2 w-full justify-between">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-mono-tech">
              {isListening ? (
                <Mic className="w-4 h-4 text-fuchsia-400 animate-pulse" />
              ) : status === 'speaking' ? (
                <Volume2 className="w-4 h-4 text-cyan-400 animate-bounce" />
              ) : (
                <Activity className="w-4 h-4 text-emerald-400" />
              )}
              <span className="text-[11px] text-slate-300">
                {isListening ? 'VOICE SPECTRUM' : status === 'speaking' ? 'TTS AUDIO' : 'TELEMETRY HUD'}
              </span>
            </div>

            {/* Dynamic frequency equalizer bars */}
            <div className="flex items-end gap-1 h-5 px-1">
              {bars.map((bar, idx) => {
                const heightMult = isListening
                  ? Math.max(0.2, (rmsVolume * 2 + bar) * 0.7)
                  : status === 'speaking'
                  ? Math.max(0.2, bar)
                  : 0.2;
                return (
                  <motion.div
                    key={idx}
                    animate={{
                      height: `${Math.min(22, Math.max(4, heightMult * 22))}px`,
                    }}
                    transition={{ duration: 0.1 }}
                    className={`w-1 rounded-sm ${
                      idx % 2 === 0 ? 'bg-cyan-400' : 'bg-fuchsia-400'
                    }`}
                  />
                );
              })}
            </div>

            {onMicClick && (
              <button
                onClick={onMicClick}
                className={`text-[11px] px-2.5 py-1 rounded-lg font-mono-tech transition-all flex items-center gap-1 ${
                  isListening
                    ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/40'
                    : 'bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40'
                }`}
              >
                <Mic className="w-3 h-3" />
                <span>{isListening ? 'STOP' : 'VOICE'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
