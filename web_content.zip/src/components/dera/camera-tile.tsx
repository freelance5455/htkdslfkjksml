import { useEffect, useRef, useState } from "react";
import { registerCanvas, unregisterCanvas } from "@/lib/dera/engine";
import { hasLive, liveElement, onLiveChange, parkLive } from "@/lib/dera/media";
import { useSafety } from "@/lib/dera/store";
import { KIND_LABEL, NIGHT_VISION, shedOnBattery, SOURCE_LABEL, type CamId } from "@/lib/dera/types";
import { cn } from "@/lib/cn";

export function CameraTile({
  id,
  expanded = false,
  onOpen,
}: {
  id: CamId;
  expanded?: boolean;
  onOpen?: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const camera = useSafety((state) => state.cameras[id]);
  const reading = useSafety((state) => state.threats[id]);
  const forced = useSafety((state) => state.forced[id]);
  const leading = useSafety((state) => state.leading);
  const powerCut = useSafety((state) => state.powerCut);
  const remote = useSafety((state) => state.remoteFrames[id]);
  const selected = useSafety((state) => state.inspector === id);
  const [live, setLive] = useState(() => hasLive(id));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    registerCanvas(id, canvas);
    return () => unregisterCanvas(id, canvas);
  }, [id]);

  useEffect(() => onLiveChange(() => setLive(hasLive(id))), [id]);

  useEffect(() => {
    const host = hostRef.current;
    const overlay = overlayRef.current;
    if (!host || !overlay) return;
    const draw = () => {
      const width = Math.max(1, Math.round(host.clientWidth));
      const height = Math.max(1, Math.round(host.clientHeight));
      overlay.width = width;
      overlay.height = height;
      const ctx = overlay.getContext("2d");
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);
      const box = reading.box;
      if (!box || reading.kind === "clear") return;
      const x = box.x * width;
      const y = box.y * height;
      const w = box.w * width;
      const h = box.h * height;
      ctx.strokeStyle = "#c43838";
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 1, y + 1, Math.max(0, w - 2), Math.max(0, h - 2));
      const label = `${KIND_LABEL[reading.kind]} ${Math.round(reading.confidence * 100)}%`;
      ctx.font = "14px IBM Plex Sans Arabic, sans-serif";
      const pad = 6;
      const textW = ctx.measureText(label).width + pad * 2;
      const textH = 20;
      const labelY = y > textH + 2 ? y - textH : y;
      ctx.fillStyle = "#c43838";
      ctx.fillRect(x, labelY, textW, textH);
      ctx.fillStyle = "#fff6f4";
      ctx.fillText(label, x + pad, labelY + 14);
    };
    draw();
    const observer = new ResizeObserver(draw);
    observer.observe(host);
    return () => observer.disconnect();
  }, [reading.box, reading.confidence, reading.kind]);

  useEffect(() => {
    const host = hostRef.current;
    if (!host || !live) return;
    const video = liveElement(id);
    if (!video) return;
    video.className = "absolute inset-0 z-[1] h-full w-full object-cover";
    video.muted = true;
    video.playsInline = true;
    host.appendChild(video);
    void video.play().catch(() => {});
    return () => parkLive(id);
  }, [id, live]);

  const alert = reading.level === "critical";
  const watch = reading.level === "watch";
  const night = NIGHT_VISION[id];
  const detail =
    camera.source === "rtsp"
      ? camera.rtspUrl || "بدون عنوان"
      : camera.source === "bluetooth"
        ? camera.btName || "غير مقترن"
        : camera.source === "usb"
          ? camera.usbLabel || "غير متصل"
          : live
            ? "كاميرا الجهاز"
            : "محاكاة الدورية";

  const frame = (
        <>
          <canvas ref={canvasRef} className={cn("feed absolute inset-0 h-full w-full object-cover", !leading && "opacity-0")} />
          {!leading && remote ? (
            <img src={remote} alt="" className="feed absolute inset-0 h-full w-full object-cover" />
          ) : null}
          {!leading && !remote ? (
            <span className="absolute inset-0 flex items-center justify-center text-sm text-subtle">لا توجد إشارة</span>
          ) : null}
          <span className="feed-mask absolute inset-0" />
          <span className="absolute start-2 top-2 flex items-center gap-1 font-mono text-sm text-fg" dir="ltr">
            <span className={cn("size-1.5 rounded-full", alert ? "bg-alarm" : "bg-ok")} />
            {alert ? "REC" : "LIVE"}
          </span>
          {alert ? (
            <span className="absolute bottom-2 start-2 rounded-sm bg-alarm px-2 py-1 text-sm font-medium text-alarm-fg">
              إنذار حرج · {KIND_LABEL[reading.kind]} · {Math.round(reading.confidence * 100)}٪
            </span>
          ) : null}
          {watch ? (
            <span className="absolute bottom-2 start-2 rounded-sm bg-elevated px-2 py-1 text-sm text-fg">
              تحقق من الاستمرار
            </span>
          ) : null}
          {powerCut ? (
            <span className="absolute top-2 end-2 rounded-sm bg-bg/80 px-2 py-1 text-sm text-fg">
              {night ? "أشعة تحت الحمراء" : "ظلام بلا رؤية ليلية"}
            </span>
          ) : null}
          {forced !== "clear" ? (
            <span className="absolute bottom-2 end-2 rounded-sm bg-bg/80 px-2 py-1 text-sm text-fg">تدريب</span>
          ) : null}
          {shedOnBattery(id, powerCut) ? (
            <span className="absolute inset-0 flex items-center justify-center bg-bg/80 px-3 text-center text-sm text-fg">
              مفصولة لتوفير طاقة البطارية
            </span>
          ) : null}
          <canvas
            ref={overlayRef}
            data-testid={`box-${id}`}
            className="pointer-events-none absolute inset-0 z-10 h-full w-full"
          />
        </>
      );

      return (
        <article
      data-testid={`cam-${id}`}
      data-kind={reading.kind}
      data-level={reading.level}
      data-flame={reading.flame}
      data-smoke={reading.smoke}
      data-box={reading.box ? `${reading.box.x},${reading.box.y},${reading.box.w},${reading.box.h}` : ""}
      data-scenario={forced}
      className={cn(
        "flex min-w-0 flex-col gap-2 rounded-xl border border-border bg-surface p-2",
        expanded && "min-h-0 flex-1 border-0 bg-transparent p-0",
        alert && "is-alert",
        watch && "is-watch",
        selected && !expanded && "outline outline-1 outline-fg",
      )}
    >
      {!expanded ? (
        <header className="flex items-start justify-between gap-2 px-1">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-medium">{camera.zone}</h2>
            <p className="truncate text-sm text-muted">{camera.name}</p>
          </div>
          <span className="shrink-0 rounded-sm bg-elevated px-2 py-1 text-sm text-muted">
            {SOURCE_LABEL[camera.source]}
          </span>
        </header>
      ) : null}
      {onOpen ? (
        <button
          type="button"
          className="press w-full text-start"
          onClick={onOpen}
          aria-label={`تكبير ${camera.zone}`}
        >
          <div ref={hostRef} className="relative h-36 overflow-hidden rounded-lg bg-bg">
            {frame}
          </div>
        </button>
      ) : (
        <div
          ref={hostRef}
          className={cn("relative overflow-hidden rounded-lg bg-bg", expanded ? "min-h-0 flex-1" : "aspect-video")}
        >
          {frame}
        </div>
      )}
      {!expanded ? (
        <p className="truncate px-1 font-mono text-sm text-subtle" dir="ltr">
          {detail}
        </p>
      ) : null}
    </article>
  );
}
