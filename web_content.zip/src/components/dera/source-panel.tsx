import { useEffect, useState } from "react";
import { Bluetooth, Usb, Wifi, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { attachLive, detachLive, listVideoInputs } from "@/lib/dera/media";
import { useSafety } from "@/lib/dera/store";
import { KIND_LABEL, type Scenario } from "@/lib/dera/types";

const BT_DEVICES = [
  { id: "bt-hall", name: "Cam-BT صالة الطعام", ok: true },
  { id: "bt-store", name: "Cam-BT المخزن الخلفي", ok: true },
  { id: "bt-sensor", name: "مستشعر دخان لاسلكي", ok: false },
];

export function SourcePanel({ embedded = false }: { embedded?: boolean }) {
  const inspector = useSafety((state) => state.inspector);
  const camera = useSafety((state) => (inspector ? state.cameras[inspector] : null));
  const setInspector = useSafety((state) => state.setInspector);
  const patchCamera = useSafety((state) => state.patchCamera);
  const setDrill = useSafety((state) => state.setDrill);
  const [rtsp, setRtsp] = useState("");
  const [message, setMessage] = useState("");
  const [usb, setUsb] = useState<MediaDeviceInfo[]>([]);
  const [scanning, setScanning] = useState(false);
  const [found, setFound] = useState(false);
  const [pairing, setPairing] = useState<string | null>(null);

  useEffect(() => {
    setRtsp(camera?.rtspUrl ?? "");
    setMessage("");
    setFound(false);
    setScanning(false);
  }, [camera?.id, camera?.rtspUrl]);

  useEffect(() => {
    if (!inspector || embedded) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setInspector(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [inspector, setInspector, embedded]);

  if (!inspector || !camera) return null;

  async function connectUsb(device: MediaDeviceInfo) {
    setMessage("");
    try {
      await attachLive(inspector!, {
        audio: false,
        video: device.deviceId ? { deviceId: { exact: device.deviceId } } : true,
      });
      patchCamera(inspector!, {
        source: "usb",
        usbLabel: device.label || "كاميرا USB",
      });
      useSafety.getState().noteLinkFlap(inspector!);
      setMessage("تم وصل البث من منفذ الجهاز.");
    } catch {
      useSafety.getState().noteLinkFlap(inspector!);
      setMessage("تعذّر فتح كاميرا USB في هذه الجلسة.");
    }
  }

  async function connectPhone() {
    setMessage("");
    try {
      try {
        await attachLive(inspector!, {
          audio: false,
          video: { facingMode: { ideal: "environment" } },
        });
      } catch {
        await attachLive(inspector!, { audio: false, video: true });
      }
      patchCamera(inspector!, { source: "phone", usbLabel: "كاميرا الجهاز" });
      useSafety.getState().noteLinkFlap(inspector!);
      setMessage("بث الجوال يعمل، والتحليل يقرأ إطاره مباشرة.");
    } catch {
      useSafety.getState().noteLinkFlap(inspector!);
      setMessage("المتصفح منع الكاميرا. تبقى قناة المحاكاة.");
    }
  }

  function saveRtsp() {
    const url = rtsp.trim();
    if (!/^rtsp:\/\/\S+$/i.test(url)) {
      setMessage("العنوان يجب أن يبدأ بـ rtsp://");
      return;
    }
    detachLive(inspector!);
    patchCamera(inspector!, { source: "rtsp", rtspUrl: url });
    useSafety.getState().noteLinkFlap(inspector!);
    setMessage("حُفظ العنوان. المتصفح لا يفك RTSP، لذا تُعرض قناة الموقع التجريبية المرتبطة به.");
  }

  function scanBt() {
    setScanning(true);
    setFound(false);
    window.setTimeout(() => {
      setScanning(false);
      setFound(true);
    }, 900);
  }

  function pair(device: (typeof BT_DEVICES)[number]) {
    if (!device.ok) {
      setMessage("هذا الجهاز مستشعر وليس كاميرا فيديو.");
      return;
    }
    setPairing(device.id);
    window.setTimeout(() => {
      detachLive(inspector!);
      patchCamera(inspector!, { source: "bluetooth", btName: device.name });
      setPairing(null);
      setMessage("تم الإقران التجريبي. البث المعروض مشهد الكاميرا المرتبطة.");
    }, 800);
  }

  function drill(kind: Scenario) {
    setDrill(inspector!, kind);
  }

  const form = (
    <div>
      {embedded ? <p className="mb-3 text-sm text-muted">{camera.zone} · مصدر الفيديو</p> : null}
      <section className="mb-4 flex flex-col gap-2">
        <h3 className="flex items-center gap-2 text-sm font-medium">
          <Wifi className="size-4" aria-hidden="true" />
          واي فاي / RTSP
        </h3>
        <label className="text-sm text-muted" htmlFor="rtsp-url">
          عنوان البث
        </label>
        <input
          id="rtsp-url"
          dir="ltr"
          value={rtsp}
          onChange={(event) => setRtsp(event.target.value)}
          className="h-11 w-full rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg"
          placeholder="rtsp://192.168.1.21/live"
        />
        <Button onClick={saveRtsp}>حفظ عنوان RTSP</Button>
      </section>

      <section className="mb-4 flex flex-col gap-2">
        <h3 className="flex items-center gap-2 text-sm font-medium">
          <Usb className="size-4" aria-hidden="true" />
          كاميرا USB
        </h3>
        <Button
          onClick={() => {
            void listVideoInputs()
              .then((devices) => {
                setUsb(devices);
                if (devices.length === 0) setMessage("لا توجد كاميرا USB ظاهرة للمتصفح.");
              })
              .catch(() => setMessage("تعذّر قراءة أجهزة USB."));
          }}
        >
          البحث عن أجهزة USB
        </Button>
        {usb.map((device, index) => (
          <Button key={device.deviceId || index} onClick={() => void connectUsb(device)}>
            {device.label || `كاميرا ${index + 1}`}
          </Button>
        ))}
        <Button variant="primary" onClick={() => void connectPhone()}>
          بث كاميرا هذا الجهاز
        </Button>
      </section>

      <section className="mb-4 flex flex-col gap-2">
        <h3 className="flex items-center gap-2 text-sm font-medium">
          <Bluetooth className="size-4" aria-hidden="true" />
          اكتشاف بلوتوث
        </h3>
        <p className="text-sm text-pretty text-muted">
          البحث إقران تجريبي داخل المعاينة، لا يفتح راديو البلوتوث الحقيقي في المتصفح.
        </p>
        <Button onClick={scanBt}>{scanning ? "جارٍ البحث…" : "بحث عن أجهزة قريبة"}</Button>
        {found
          ? BT_DEVICES.map((device) => (
              <Button key={device.id} onClick={() => pair(device)} disabled={pairing === device.id}>
                {pairing === device.id ? "جارٍ الإقران…" : device.name}
              </Button>
            ))
          : null}
      </section>

      <section className="flex flex-col gap-2">
        <h3 className="text-sm font-medium">تدريب الكشف على هذه القناة</h3>
        <div className="grid grid-cols-2 gap-2">
          <Button data-testid="drill-flame" variant="alarm" onClick={() => drill("flame")}>
            {KIND_LABEL.flame}
          </Button>
          <Button data-testid="drill-smoke" onClick={() => drill("smoke")}>
            {KIND_LABEL.smoke}
          </Button>
          <Button data-testid="drill-smoking" onClick={() => drill("smoking")}>
            {KIND_LABEL.smoking}
          </Button>
          <Button data-testid="drill-clear" onClick={() => drill("clear")}>
            مشهد آمن
          </Button>
        </div>
      </section>
      {message ? <p className="mt-3 text-sm text-pretty text-muted">{message}</p> : null}
    </div>
  );

  if (embedded) return form;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end bg-bg/70 lg:items-center lg:justify-center"
      onClick={() => setInspector(null)}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="source-title"
        className="max-h-[85dvh] w-full overflow-auto rounded-t-xl border border-border bg-surface p-4 lg:max-w-lg lg:rounded-xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id="source-title" className="text-lg font-medium">
              {camera.zone}
            </h2>
            <p className="text-sm text-muted">مصدر الفيديو ومحرك الاتصال</p>
          </div>
          <Button variant="ghost" aria-label="إغلاق" onClick={() => setInspector(null)}>
            <X className="size-5" />
          </Button>
        </div>
        {form}
      </div>
    </div>
  );
}
