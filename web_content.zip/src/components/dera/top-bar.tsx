import { useEffect, useState } from "react";
import { Shield } from "lucide-react";
import { isAdmin, isEmergency, useSafety } from "@/lib/dera/store";
import { CAM_IDS } from "@/lib/dera/types";
import { cn } from "@/lib/cn";

export function TopBar() {
  const mode = useSafety((state) => state.mode);
  const away = useSafety((state) => state.away);
  const admin = useSafety(isAdmin);
  const emergency = useSafety(isEmergency);
  const threats = useSafety((state) => state.threats);
  const active = CAM_IDS.filter((id) => threats[id].level === "critical").length;
  const watching = CAM_IDS.filter((id) => threats[id].level === "watch").length;
  const [clock, setClock] = useState("");

  useEffect(() => {
    const tick = () =>
      setClock(
        new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      );
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <header className="flex items-center gap-3 border-b border-border px-3 py-3">
      <Shield className="size-5 shrink-0" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">درع الأمان · مجمع النخيل</p>
        <p className="truncate text-sm text-muted">
          {admin ? "مدير النظام" : "مستعرض فقط"}
          {" · "}
          {mode === "hub" ? "المركز المحلي" : "المراقبة البعيدة"}
        </p>
      </div>
      <p className="font-mono text-sm tabular-nums text-muted" dir="ltr">
        {clock}
      </p>
      <span
        className={cn(
          "hidden rounded-sm px-2 py-1 text-sm sm:inline",
          emergency ? "bg-elevated text-fg" : "bg-elevated text-ok",
        )}
      >
        {emergency
          ? "تحليل محلي"
          : active > 0
            ? `إنذار حرج في ${active}`
            : watching > 0
              ? "تحقق زمني"
              : away
                ? "وضع الغياب"
                : "هادئ"}
      </span>
    </header>
  );
}
