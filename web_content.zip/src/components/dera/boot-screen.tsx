import type { ReactNode } from "react";
import { Radio, Shield, Smartphone } from "lucide-react";
import { primeAudio } from "@/lib/dera/alarm";
import { useSafety } from "@/lib/dera/store";
import type { AppMode } from "@/lib/dera/types";

function choose(mode: AppMode) {
  primeAudio();
  useSafety.getState().openSeat(mode);
}

export function BootScreen({ ready }: { ready: boolean }) {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col justify-center gap-8 px-4 py-10">
      <div className="flex items-center gap-4">
        <span className="flex size-14 items-center justify-center rounded-lg border border-border bg-surface text-fg">
          <Shield className="size-7" strokeWidth={1.5} aria-hidden="true" />
        </span>
        <div>
          <p className="text-sm text-muted">سلامة المتاجر والصالات والمنازل</p>
          <h1 className="text-3xl font-medium tracking-tight text-balance">درع الأمان</h1>
        </div>
      </div>
      <p className="max-w-2xl text-pretty text-muted">
        ست قنوات على شاشة واحدة. المحلل المحلي يقرأ اللهب والدخان وجمرة التدخين من الصورة نفسها،
        ويبقى يعمل إذا انقطع الاتصال. عند توفر الشبكة يمكن تأكيد الحدث سحابياً بلقطة واحدة.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <ModeCard
          ready={ready}
          title="المركز المحلي"
          body="لجهاز الموقع أو الجهاز اللوحي. شبكة ٢×٣، ومصادر RTSP وUSB وبلوتوث، وإنذار في المكان."
          icon={<Radio className="size-5" aria-hidden="true" />}
          onClick={() => choose("hub")}
          testId="boot-hub"
        />
        <ModeCard
          ready={ready}
          title="المراقبة البعيدة"
          body="لهاتفك. متابعة اللقطات، تنبيه حرج، وتأكيد الأحداث حتى لو كان المركز في نافذة أخرى."
          icon={<Smartphone className="size-5" aria-hidden="true" />}
          onClick={() => choose("viewer")}
          testId="boot-viewer"
        />
      </div>
    </main>
  );
}

function ModeCard({
  title,
  body,
  icon,
  onClick,
  ready,
  testId,
}: {
  title: string;
  body: string;
  icon: ReactNode;
  onClick: () => void;
  ready: boolean;
  testId: string;
}) {
  return (
    <button
      type="button"
      data-testid={testId}
      disabled={!ready}
      onClick={onClick}
      className="press flex flex-col gap-4 rounded-xl border border-border bg-surface p-4 text-start disabled:opacity-60"
    >
      <span className="flex size-10 items-center justify-center rounded-sm bg-elevated text-fg">{icon}</span>
      <span>
        <span className="block text-lg font-medium">{title}</span>
        <span className="mt-1 block text-sm text-pretty text-muted">{body}</span>
      </span>
    </button>
  );
}
