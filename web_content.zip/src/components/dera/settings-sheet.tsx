import { useEffect, useState } from "react";
import { Bell, BellOff } from "lucide-react";
import { BackBar } from "@/components/dera/back-bar";
import { SourcePanel } from "@/components/dera/source-panel";
import { Button } from "@/components/ui/button";
import { primeAudio, setAlarm } from "@/lib/dera/alarm";
import { stopEngine } from "@/lib/dera/engine";
import { requestAlerts } from "@/lib/dera/notify";
import { isAdmin, isEmergency, useSafety } from "@/lib/dera/store";
import { CAM_IDS, type LinkMode } from "@/lib/dera/types";
import { cn } from "@/lib/cn";

const LINKS: { id: LinkMode; label: string }[] = [
  { id: "auto", label: "تلقائي" },
  { id: "online", label: "متصل" },
  { id: "emergency", label: "طوارئ" },
];

export function SettingsSheet({ onClose }: { onClose: () => void }) {
  const mode = useSafety((state) => state.mode);
  const setMode = useSafety((state) => state.setMode);
  const link = useSafety((state) => state.linkOverride);
  const setLink = useSafety((state) => state.setLink);
  const muted = useSafety((state) => state.muted);
  const setMuted = useSafety((state) => state.setMuted);
  const autoDrill = useSafety((state) => state.autoDrill);
  const setAutoDrill = useSafety((state) => state.setAutoDrill);
  const autoCloud = useSafety((state) => state.autoCloud);
  const setAutoCloud = useSafety((state) => state.setAutoCloud);
  const away = useSafety((state) => state.away);
  const setAway = useSafety((state) => state.setAway);
  const powerCut = useSafety((state) => state.powerCut);
  const setPowerCut = useSafety((state) => state.setPowerCut);
  const predictive = useSafety((state) => state.predictive);
  const setPredictive = useSafety((state) => state.setPredictive);
  const powerCutAt = useSafety((state) => state.powerCutAt);
  const contacts = useSafety((state) => state.contacts);
  const addContact = useSafety((state) => state.addContact);
  const removeContact = useSafety((state) => state.removeContact);
  const admin = useSafety(isAdmin);
  const emergency = useSafety(isEmergency);
  const cameras = useSafety((state) => state.cameras);
  const inspector = useSafety((state) => state.inspector);
  const setInspector = useSafety((state) => state.setInspector);
  const [alertNote, setAlertNote] = useState("");
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!powerCut) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [powerCut]);

  const batteryMs = powerCut && powerCutAt ? Math.max(0, 45 * 60 * 1000 - (now - powerCutAt)) : 0;
  const batteryMin = Math.ceil(batteryMs / 60000);

  if (admin && inspector) {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <BackBar title={cameras[inspector].zone} onBack={() => setInspector(null)} />
        <div className="min-h-0 flex-1 overflow-auto p-4">
          <SourcePanel embedded />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <BackBar title="الإعدادات" onBack={onClose} />
      <div className="min-h-0 flex-1 overflow-auto p-4">

        {admin ? (
          <div className="flex flex-col gap-4">
            <div role="radiogroup" aria-label="حالة الاتصال" className="flex rounded-md border border-border p-1">
              {LINKS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="radio"
                  aria-checked={link === item.id}
                  onClick={() => setLink(item.id)}
                  className={cn(
                    "press min-h-11 flex-1 rounded-sm px-3 text-sm",
                    link === item.id ? "bg-fg text-bg" : "text-muted",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <p className="text-sm text-muted">
              {emergency ? "وضع الطوارئ: التحليل محلي ولا يُرسل شيء للسحابة." : "الاتصال يسمح بالتأكيد السحابي."}
            </p>
            <div className="grid grid-cols-2 gap-2">
              <Button variant={away ? "primary" : "quiet"} aria-pressed={away} onClick={() => setAway(!away)}>
                وضع الغياب
              </Button>
              <Button
                variant={powerCut ? "primary" : "quiet"}
                aria-pressed={powerCut}
                onClick={() => setPowerCut(!powerCut)}
              >
                انقطاع الكهرباء
              </Button>
              <Button
                variant={autoDrill ? "primary" : "quiet"}
                aria-pressed={autoDrill}
                onClick={() => setAutoDrill(!autoDrill)}
              >
                تدريب تلقائي
              </Button>
              <Button
                variant={autoCloud ? "primary" : "quiet"}
                aria-pressed={autoCloud}
                onClick={() => setAutoCloud(!autoCloud)}
              >
                تأكيد تلقائي
              </Button>
              <Button
                aria-pressed={muted}
                onClick={() => {
                  primeAudio();
                  setMuted(!muted);
                  if (!muted) setAlarm("off");
                }}
              >
                {muted ? <BellOff className="size-4" /> : <Bell className="size-4" />}
                {muted ? "الإنذار صامت" : "كتم الإنذار"}
              </Button>
              <Button
                onClick={() => {
                  primeAudio();
                  setMode(mode === "hub" ? "viewer" : "hub");
                }}
              >
                {mode === "hub" ? "المراقبة البعيدة" : "المركز المحلي"}
              </Button>
            <Button
                variant={predictive ? "primary" : "quiet"}
                aria-pressed={predictive}
                onClick={() => setPredictive(!predictive)}
              >
                تنبؤ وقائي
              </Button>
            </div>
            {powerCut ? (
              <p className="text-sm text-pretty text-muted">
                انقطع التيار. النظام على البطارية الاحتياطية، متبقي {batteryMin} دقيقة. فُصلت كاميرا الممر والصالة.
                لا توجد قراءة بلوتوث من بطارية حقيقية؛ هذا عدّاد تشغيلي.
              </p>
            ) : null}
            <section className="flex flex-col gap-2">
              <h3 className="text-sm font-medium">دائرة الطوارئ</h3>
              <p className="text-sm text-pretty text-muted">
                إذا لم يُقرأ الإنذار خلال ٣٠ ثانية تُجهَّز رسالة لهذه الجهات. المتصفح لا يرسل SMS.
              </p>
              <input
                value={contactName}
                onChange={(event) => setContactName(event.target.value)}
                placeholder="الاسم"
                className="h-11 rounded-md border border-border bg-bg px-3 text-sm"
              />
              <input
                value={contactPhone}
                onChange={(event) => setContactPhone(event.target.value)}
                placeholder="الجوال"
                dir="ltr"
                className="h-11 rounded-md border border-border bg-bg px-3 text-sm"
              />
              <Button
                onClick={() => {
                  addContact(contactName, contactPhone);
                  setContactName("");
                  setContactPhone("");
                }}
              >
                إضافة جهة
              </Button>
              {contacts.map((item) => (
                <div key={item.id} className="flex items-center justify-between gap-2 text-sm">
                  <span>
                    {item.name} · <span dir="ltr">{item.phone}</span>
                  </span>
                  <Button variant="ghost" onClick={() => removeContact(item.id)}>
                    حذف
                  </Button>
                </div>
              ))}
            </section>
            <section className="flex flex-col gap-2">
              <h3 className="text-sm font-medium">مصدر كل كاميرا</h3>
              <div className="grid grid-cols-2 gap-2">
                {CAM_IDS.map((id) => (
                  <Button
                    key={id}
                    variant={inspector === id ? "primary" : "quiet"}
                    aria-pressed={inspector === id}
                    onClick={() => setInspector(inspector === id ? null : id)}
                  >
                    {cameras[id].name}
                  </Button>
                ))}
              </div>
              <SourcePanel embedded />
            </section>
            <Button
              variant="alarm"
              onClick={() => {
                stopEngine();
                setMode(null);
              }}
            >
              إنهاء النظام
            </Button>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-pretty text-muted">
              هذه جلسة مستعرض. يمكن مشاهدة البث وتفعيل الإشعار، دون كتم الإنذار أو تعديل الإعدادات أو إيقاف النظام.
            </p>
            <Button
              variant="primary"
              onClick={() => {
                void requestAlerts().then((result) => {
                  setAlertNote(
                    result === "granted"
                      ? "سيصل إشعار الجهاز عند وقوع حدث والشاشة في الخلفية."
                      : result === "unsupported"
                        ? "هذا المتصفح لا يعرض إشعارات. التنبيه داخل الشاشة يعمل."
                        : "رُفض الإذن. التنبيه داخل الشاشة يبقى فعالاً.",
                  );
                });
              }}
            >
              تفعيل إشعار الشاشة
            </Button>
            {alertNote ? <p className="text-sm text-muted">{alertNote}</p> : null}
          </div>
        )}
      </div>
    </div>
  );
}
