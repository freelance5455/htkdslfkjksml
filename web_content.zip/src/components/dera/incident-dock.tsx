import { useState } from "react";
import { Button } from "@/components/ui/button";
import { IntercomBar } from "@/components/dera/intercom-bar";
import { runCloud } from "@/lib/dera/cloud-client";
import { buildPasswordZip } from "@/lib/dera/zip-report";
import { isAdmin, isEmergency, useSafety } from "@/lib/dera/store";
import { KIND_LABEL } from "@/lib/dera/types";
import type { CloudVerdict, Incident } from "@/lib/dera/types";

function isVerdict(cloud: Incident["cloud"]): cloud is CloudVerdict {
  return Boolean(cloud && "kind" in cloud);
}

export function IncidentDock() {
  const incidents = useSafety((state) => state.incidents);
  const cameras = useSafety((state) => state.cameras);
  const cloudBusy = useSafety((state) => state.cloudBusy);
  const cloudLeft = useSafety((state) => state.cloudLeft);
  const emergency = useSafety(isEmergency);
  const mode = useSafety((state) => state.mode);
  const leading = useSafety((state) => state.leading);
  const admin = useSafety(isAdmin);
  const transients = useSafety((state) => state.transients);
  const reports = useSafety((state) => state.reports);
  const maintenance = useSafety((state) => state.maintenance);
  const health = useSafety((state) => state.health);
  const flaps = useSafety((state) => state.flaps);
  const nextReportAt = useSafety((state) => state.nextReportAt);
  const away = useSafety((state) => state.away);
  const forecasts = useSafety((state) => state.forecasts);
  const circleLog = useSafety((state) => state.circleLog);
  const ackIncident = useSafety((state) => state.ackIncident);
  const setDrill = useSafety((state) => state.setDrill);
  const stopDrills = useSafety((state) => state.stopDrills);
  const [password, setPassword] = useState("");
  const [exportNote, setExportNote] = useState("");
  const latest = incidents[0];

  return (
    <aside className="flex max-h-80 min-h-0 flex-col overflow-auto border-t border-border bg-bg lg:max-h-none lg:w-80 lg:shrink-0 lg:border-s lg:border-t-0">
      <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-3">
        <h2 className="text-sm font-medium">سجل الأحداث</h2>
        <span className="font-mono text-sm tabular-nums text-muted" dir="ltr">
          {cloudLeft} تأكيد
        </span>
      </div>
      <p className="sr-only" role="status" aria-live="assertive">
        {latest ? `${KIND_LABEL[latest.kind]} في ${cameras[latest.camId].zone}` : "لا تنبيهات"}
      </p>
      <div className="flex flex-wrap gap-2 border-b border-border p-3">
        {admin && (mode === "hub" || leading) ? (
          <>
            <Button data-testid="quick-flame" variant="alarm" onClick={() => setDrill("c2", "flame")}>
              اشتعال المطبخ
            </Button>
            <Button data-testid="quick-smoke" onClick={() => setDrill("c5", "smoke")}>
              دخان الصالة
            </Button>
            <Button data-testid="quick-smoking" onClick={() => setDrill("c1", "smoking")}>
              تدخين المدخل
            </Button>
            <Button onClick={stopDrills}>إيقاف التدريب</Button>
          </>
        ) : (
          <p className="text-sm text-muted">التدريب يُشغَّل من المركز المحلي.</p>
        )}
      </div>
      <div className="flex flex-col gap-3 p-3">
        {incidents.length === 0 ? (
          <p className="text-sm text-pretty text-muted">
            لا أحداث بعد. التدريب يحقن الخطر في البكسلات، والإنذار لا يُطلق إلا إذا رصده المحلل.
          </p>
        ) : (
          incidents.map((incident) => {
            const verdict = isVerdict(incident.cloud) ? incident.cloud : null;
            const error = incident.cloud && "error" in incident.cloud ? incident.cloud.error : null;
            return (
              <article key={incident.id} className="flex gap-3 rounded-lg border border-border bg-surface p-2">
                {incident.snapshot ? (
                  <img
                    src={incident.snapshot}
                    alt=""
                    className="h-16 w-24 shrink-0 rounded-sm object-cover"
                  />
                ) : (
                  <div className="h-16 w-24 shrink-0 rounded-sm bg-bg" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">
                    {KIND_LABEL[incident.kind]} · {cameras[incident.camId].zone}
                  </p>
                  <p className="font-mono text-sm tabular-nums text-muted" dir="ltr">
                    {new Date(incident.at).toLocaleTimeString("ar", {
                      hour: "2-digit",
                      minute: "2-digit",
                      second: "2-digit",
                    })}
                    {" · "}
                    {Math.round(incident.confidence * 100)}٪
                    {" · "}
                    {incident.origin === "drill" ? "تدريب" : "رصد"}
                  </p>
                  {verdict ? (
                    <p className="text-sm text-pretty text-muted">
                      سحابة: {KIND_LABEL[verdict.kind]}
                      {verdict.note ? ` — ${verdict.note}` : ""}
                    </p>
                  ) : null}
                  {error ? <p className="text-sm text-pretty text-muted">{error}</p> : null}
                  {!incident.acked ? (
                    <Button className="mt-2" onClick={() => ackIncident(incident.id)}>
                      قرأت التنبيه
                    </Button>
                  ) : (
                    <p className="mt-2 text-sm text-muted">قُرئ. لن يُصعَّد إلى دائرة الطوارئ.</p>
                  )}
                  {!incident.cloud && admin ? (
                    <Button
                      className="mt-2"
                      variant="primary"
                      disabled={cloudBusy || emergency || cloudLeft <= 0}
                      onClick={() => void runCloud(incident.id)}
                    >
                      {emergency ? "محلي فقط" : "تأكيد سحابي"}
                    </Button>
                  ) : null}
                </div>
              </article>
            );
          })
        )}
      </div>
      {latest ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">تصدير تقرير الحادث</h3>
          <p className="mt-1 text-sm text-pretty text-muted">
            يجمع اللقطة والوقت ونوع الرصد في ملف مضغوط بكلمة مرور. لا يوجد فيديو مستمر محفوظ في المتصفح.
          </p>
          <label className="mt-2 block text-sm text-muted" htmlFor="export-pass">
            كلمة المرور
          </label>
          <input
            id="export-pass"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="mt-1 h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          />
          <Button
            className="mt-2"
            onClick={() => {
              if (password.trim().length < 4) {
                setExportNote("كلمة المرور أربعة أحرف على الأقل.");
                return;
              }
              const camera = cameras[latest.camId];
              const report = [
                "تقرير حادث — درع الأمان",
                `الوقت: ${new Date(latest.at).toLocaleString("ar")}`,
                `القناة: ${camera.name} — ${camera.zone}`,
                `النوع: ${KIND_LABEL[latest.kind]}`,
                `الثقة: ${Math.round(latest.confidence * 100)}٪`,
                `المصدر: ${latest.origin === "drill" ? "تدريب" : "رصد"}`,
                "المرفق صورة الإطار لحظة التصعيد، لا تسجيل فيديو كامل.",
              ].join("\n");
              const entries = [{ name: "report.txt", data: new TextEncoder().encode(report) }];
              if (latest.snapshot.startsWith("data:image")) {
                const raw = atob(latest.snapshot.split(",")[1] ?? "");
                const bytes = new Uint8Array(raw.length);
                for (let i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i);
                entries.push({ name: "snapshot.jpg", data: bytes });
              }
              const blob = buildPasswordZip(entries, password.trim());
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = "dera-incident.zip";
              link.click();
              URL.revokeObjectURL(url);
              setExportNote("نزل الملف. افتحه بكلمة المرور نفسها.");
            }}
          >
            تصدير تقرير الحادث
          </Button>
          {exportNote ? <p className="mt-2 text-sm text-muted">{exportNote}</p> : null}
          <div className="mt-3">
            <IntercomBar />
          </div>
        </div>
      ) : null}
      {forecasts.length > 0 ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">تنبيه وقائي</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {forecasts.map((item) => (
              <li key={item.id} className="text-sm text-pretty text-fg">
                {item.text}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {circleLog.length > 0 ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">دائرة الطوارئ</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {circleLog.map((item) => (
              <li key={item.id} className="text-sm text-pretty text-muted">
                {item.text}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      <div className="border-t border-border px-3 py-3 text-sm">
        <h3 className="font-medium">صحة المركز</h3>
        <p className="mt-1 font-mono tabular-nums text-muted" dir="ltr">
          {health.heapMb === null ? "الذاكرة: غير ظاهرة في هذا المتصفح" : `RAM ${health.heapMb}/${health.heapLimitMb} MB`}
          {" · "}
          {health.frameMs} ms
        </p>
        <p className="text-muted">
          {health.frameMs > 40 ? "حمل المعالجة مرتفع." : "استقرار المعالجة طبيعي."}
          {away && nextReportAt > 0
            ? ` تقرير الاطمئنان التالي ${new Date(nextReportAt).toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" })}.`
            : ""}
        </p>
        <p className="text-muted">
          انقطاعات الرابط:{" "}
          {Object.entries(flaps)
            .filter(([, count]) => count > 0)
            .map(([id, count]) => `${cameras[id as keyof typeof cameras].name} ${count}`)
            .join(" · ") || "لا يوجد"}
        </p>
      </div>
      {reports.length > 0 ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">تقارير الغياب</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {reports.map((report) => (
              <li key={report.id} className="text-sm text-pretty text-muted">
                {report.text}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {maintenance.length > 0 ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">سجل الصيانة</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {maintenance.map((note) => (
              <li key={note.id} className="text-sm text-pretty text-fg">
                {note.text}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {transients.length > 0 ? (
        <div className="border-t border-border px-3 py-3">
          <h3 className="text-sm font-medium">أحداث عابرة دون إزعاج</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {transients.map((item) => (
              <li key={item.id} className="text-sm text-muted">
                {KIND_LABEL[item.kind]} · {cameras[item.camId].zone} · {Math.round(item.heldMs / 100) / 10} ث
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </aside>
  );
}
