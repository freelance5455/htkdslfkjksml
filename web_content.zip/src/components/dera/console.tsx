import { useEffect, useState, type ReactNode } from "react";
import { Cctv, Settings, Smartphone } from "lucide-react";
import { BackBar } from "@/components/dera/back-bar";
import { CameraTile } from "@/components/dera/camera-tile";
import { IncidentDock } from "@/components/dera/incident-dock";
import { IntercomBar } from "@/components/dera/intercom-bar";
import { SettingsSheet } from "@/components/dera/settings-sheet";
import { TopBar } from "@/components/dera/top-bar";
import { setAlarm } from "@/lib/dera/alarm";
import { startEngine, stopEngine } from "@/lib/dera/engine";
import { attachLive, hasLive, resumeLive } from "@/lib/dera/media";
import { subscribeRelay } from "@/lib/dera/relay";
import { isAdmin, isEmergency, useSafety } from "@/lib/dera/store";
import { CAM_IDS } from "@/lib/dera/types";
import { cn } from "@/lib/cn";

const SITE_IDS = CAM_IDS.filter((id) => id !== "c6");
type Screen = "home" | "phone" | "cameras" | "settings";

export function Console() {
  const mode = useSafety((state) => state.mode);
  const emergency = useSafety(isEmergency);
  const threats = useSafety((state) => state.threats);
  const [screen, setScreen] = useState<Screen>("home");
  const [phoneNote, setPhoneNote] = useState("");
  const critical = CAM_IDS.filter((id) => threats[id].level === "critical").length;

  useEffect(() => {
    if (mode === "hub") startEngine();
  }, [mode]);

  useEffect(() => () => stopEngine(), []);

  useEffect(() => {
    const sync = () => useSafety.getState().setBrowserOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  useEffect(() => {
    return subscribeRelay((message) => {
      const state = useSafety.getState();
      if (message.type === "incident") state.addIncident(message.incident);
      if (message.type === "frame" && !state.leading) {
        state.setRemoteFrame(
          message.id,
          message.jpg,
          message.kind,
          message.confidence,
          message.level,
          message.box,
        );
      }
    });
  }, []);

  useEffect(() => {
    return useSafety.subscribe((state) => {
      if (state.leading) return;
      const any = CAM_IDS.some((id) => state.threats[id].level === "critical");
      setAlarm(!any || state.muted || state.mode === null ? "off" : "pulse");
    });
  }, []);

  function openPhone() {
    setScreen("phone");
    if (hasLive("c6")) {
      resumeLive("c6");
      setPhoneNote("");
      return;
    }
    setPhoneNote("جارٍ فتح كاميرا الجهاز…");
    const started = attachLive("c6", {
      audio: false,
      video: { facingMode: { ideal: "environment" } },
    });
    void started
      .catch(() => attachLive("c6", { audio: false, video: true }))
      .then(() => {
        const state = useSafety.getState();
        if (isAdmin(state)) state.patchCamera("c6", { source: "phone", usbLabel: "كاميرا الجهاز" });
        setPhoneNote("");
      })
      .catch(() => {
        setPhoneNote("المتصفح منع الكاميرا. تظهر صورة الدورية حتى يُسمح بالكاميرا من إعدادات الموقع.");
      });
  }

  return (
    <main className="flex h-dvh flex-col overflow-hidden">
      <TopBar />
      {screen === "home" ? (
        <section className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-3 px-4 py-6">
          <h2 className="text-sm text-muted">القائمة الرئيسية</h2>
          <MenuButton
            testId="menu-phone"
            icon={<Smartphone className="size-7" aria-hidden="true" />}
            title="كاميرا الجوال"
            body="بث كاميرا هذا الجهاز في صفحة كاملة."
            onClick={openPhone}
          />
          <MenuButton
            testId="menu-cameras"
            icon={<Cctv className="size-7" aria-hidden="true" />}
            title="كاميرات الموقع"
            body="خمس قنوات مرتبة، مع سجل الأحداث."
            onClick={() => setScreen("cameras")}
          />
          <MenuButton
            testId="menu-settings"
            icon={<Settings className="size-7" aria-hidden="true" />}
            title="الإعدادات"
            body="الاتصال، الغياب، المصادر، والإنذار."
            onClick={() => setScreen("settings")}
          />
          <p className={cn("text-sm", critical > 0 ? "text-alarm" : "text-muted")}>
            {critical > 0 ? `إنذار حرج في ${critical} قنوات` : emergency ? "تحليل محلي — طوارئ" : "اللوحة هادئة"}
          </p>
        </section>
      ) : null}

      {screen === "phone" ? (
        <section className="flex min-h-0 flex-1 flex-col">
          <BackBar title="كاميرا الجوال" onBack={() => setScreen("home")} />
          {phoneNote ? <p className="px-3 py-2 text-sm text-pretty text-muted">{phoneNote}</p> : null}
          <div className="flex min-h-0 flex-1 flex-col gap-3 p-3">
            <CameraTile id="c6" expanded />
            <IntercomBar />
          </div>
        </section>
      ) : (
        <div className="pointer-events-none fixed top-0 -z-10 size-px overflow-hidden opacity-0" aria-hidden="true">
          <CameraTile id="c6" />
        </div>
      )}

      {screen === "cameras" ? (
        <section className="flex min-h-0 flex-1 flex-col lg:flex-row">
          <div className="flex min-h-0 flex-1 flex-col">
            <BackBar title="كاميرات الموقع" onBack={() => setScreen("home")} />
            <div className="grid min-h-0 flex-1 content-start grid-cols-1 gap-3 overflow-auto p-3 sm:grid-cols-2">
              {SITE_IDS.map((id) => (
                <CameraTile key={id} id={id} />
              ))}
            </div>
          </div>
          <IncidentDock />
        </section>
      ) : (
        <div className="pointer-events-none fixed top-0 -z-10 size-px overflow-hidden opacity-0" aria-hidden="true">
          {SITE_IDS.map((id) => (
            <CameraTile key={id} id={id} />
          ))}
        </div>
      )}

      {screen === "settings" ? <SettingsSheet onClose={() => setScreen("home")} /> : null}
    </main>
  );
}

function MenuButton({
  testId,
  icon,
  title,
  body,
  onClick,
}: {
  testId: string;
  icon: ReactNode;
  title: string;
  body: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      data-testid={testId}
      onClick={onClick}
      className="press flex min-h-24 items-center gap-4 rounded-xl border border-border bg-surface p-4 text-start"
    >
      <span className="flex size-14 shrink-0 items-center justify-center rounded-lg bg-elevated text-fg">{icon}</span>
      <span className="min-w-0">
        <span className="block text-lg font-medium">{title}</span>
        <span className="mt-1 block text-sm text-pretty text-muted">{body}</span>
      </span>
    </button>
  );
}
