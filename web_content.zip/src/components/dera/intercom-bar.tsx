import { useState } from "react";
import { Button } from "@/components/ui/button";
import { micLevel, startListen, startTalk } from "@/lib/dera/intercom";

export function IntercomBar() {
  const [mode, setMode] = useState<"off" | "talk" | "listen">("off");
  const [note, setNote] = useState("");
  const [level, setLevel] = useState(0);
  const [stop, setStop] = useState<(() => void) | null>(null);

  function halt() {
    stop?.();
    setStop(null);
    setMode("off");
    setLevel(0);
  }

  async function talk() {
    halt();
    try {
      const end = await startTalk();
      setStop(() => end);
      setMode("talk");
      setNote("يُبث صوتك عبر سماعة هذا الجهاز، وهو مكبر المركز إن كان اللابتوب في الموقع.");
    } catch {
      setNote("المتصفح منع الميكروفون.");
    }
  }

  async function listen() {
    halt();
    try {
      const end = await startListen();
      setStop(() => end);
      setMode("listen");
      setNote("الاستماع يقيس ميكروفون المركز دون إعادته للسماعة، حتى لا يحدث صدى.");
      const timer = window.setInterval(() => setLevel(micLevel()), 150);
      const prev = end;
      setStop(() => () => {
        window.clearInterval(timer);
        prev();
      });
    } catch {
      setNote("المتصفح منع الميكروفون.");
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        <Button variant={mode === "talk" ? "primary" : "quiet"} onClick={() => void (mode === "talk" ? halt() : talk())}>
          {mode === "talk" ? "إيقاف الحديث" : "تحدث للموقع"}
        </Button>
        <Button variant={mode === "listen" ? "primary" : "quiet"} onClick={() => void (mode === "listen" ? halt() : listen())}>
          {mode === "listen" ? "إيقاف الاستماع" : "استماع للمكان"}
        </Button>
      </div>
      {mode === "listen" ? (
        <div className="h-2 overflow-hidden rounded-full bg-elevated" aria-hidden="true">
          <div className="h-full bg-fg" style={{ width: `${Math.round(level * 100)}%` }} />
        </div>
      ) : null}
      {note ? <p className="text-sm text-pretty text-muted">{note}</p> : null}
    </div>
  );
}
