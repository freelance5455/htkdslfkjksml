import { ChevronRight } from "lucide-react";

export function BackBar({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-2 border-b border-border px-2 py-1">
      <button
        type="button"
        onClick={onBack}
        className="press inline-flex min-h-11 items-center gap-1 rounded-md px-2 text-sm"
      >
        <ChevronRight className="size-5" aria-hidden="true" />
        رجوع
      </button>
      <h2 className="min-w-0 truncate text-sm font-medium">{title}</h2>
    </div>
  );
}
