import React, { useRef, useState } from 'react';
import { UploadCloud, FileCode2, CheckCircle2, Sparkles, Layers, ShieldCheck, ArrowRight } from 'lucide-react';
import { SAMPLE_PACKAGES, SamplePackDef } from '../utils/samplePackages';

interface UploadStageProps {
  onFileSelected: (file: File | Blob, fileName: string) => void;
  selectedFile: { file: File | Blob; fileName: string; size: number } | null;
  onStartAnalysis: () => void;
  isLoadingSample: boolean;
  onLoadSample: (sample: SamplePackDef) => Promise<void>;
}

export const UploadStage: React.FC<UploadStageProps> = ({
  onFileSelected,
  selectedFile,
  onStartAnalysis,
  isLoadingSample,
  onLoadSample
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleTouchAreaClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      const file = files[0];
      onFileSelected(file, file.name);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      onFileSelected(file, file.name);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto py-2">
      {/* Hidden Native File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".apk,.xapk,.zip,application/vnd.android.package-archive"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Screen Title & Subtext */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium mb-3">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>Android Package Resource Analyzer &amp; Patcher</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Inspect &amp; Modify Game Assets
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-md mx-auto">
          Deep-scan APK and XAPK packages to locate and modify in-game currency values like coins, gems, and diamonds.
        </p>
      </div>

      {/* Dedicated Touch Area */}
      <div
        role="button"
        tabIndex={0}
        onClick={handleTouchAreaClick}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleTouchAreaClick();
          }
        }}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`w-full group cursor-pointer transition-all duration-300 relative rounded-2xl border-2 border-dashed p-8 sm:p-10 flex flex-col items-center justify-center text-center select-none shadow-xl ${
          isDragging
            ? 'border-emerald-400 bg-emerald-950/30 scale-[1.01] shadow-emerald-500/20'
            : selectedFile
            ? 'border-emerald-500/60 bg-slate-900/90 shadow-slate-900/50 hover:border-emerald-400'
            : 'border-slate-700 hover:border-emerald-500/70 bg-slate-900/50 hover:bg-slate-900/80'
        }`}
      >
        {/* Subtle decorative glow */}
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 via-transparent to-teal-500/5 rounded-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          <div
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110 shadow-lg ${
              selectedFile
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-emerald-500/20'
                : 'bg-slate-800 text-slate-300 border border-slate-700 group-hover:text-emerald-400 group-hover:border-emerald-500/40'
            }`}
          >
            {selectedFile ? (
              <FileCode2 className="w-8 h-8 sm:w-10 sm:h-10 text-emerald-400" />
            ) : (
              <UploadCloud className="w-8 h-8 sm:w-10 sm:h-10" />
            )}
          </div>

          {/* EXACT REQUIRED TEXT */}
          <p className="text-base sm:text-lg font-bold text-white group-hover:text-emerald-300 transition-colors max-w-sm">
            Upload the APK or XAPK file to be analyzed here.
          </p>

          <p className="text-xs text-slate-400 mt-2 max-w-xs">
            Tap to browse your device files or drag and drop your Android package here. Supports .apk and .xapk archives.
          </p>

          <div className="flex items-center gap-3 mt-4 text-[11px] font-medium text-slate-400">
            <span className="px-2.5 py-1 rounded bg-slate-800/80 border border-slate-700/60 font-mono text-emerald-400">
              .APK
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-800/80 border border-slate-700/60 font-mono text-teal-400">
              .XAPK
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-800/80 border border-slate-700/60 font-mono text-slate-300">
              Split-APKs / OBB
            </span>
          </div>
        </div>
      </div>

      {/* Selected File Card Indicator */}
      {selectedFile && (
        <div className="w-full mt-4 p-4 rounded-xl bg-slate-900 border border-emerald-500/30 flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0 text-emerald-400">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-xs">
                  {selectedFile.fileName}
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex-shrink-0">
                  {selectedFile.fileName.endsWith('.xapk') ? 'XAPK' : 'APK'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Size: {formatFileSize(selectedFile.size)} • Ready for full analysis
              </p>
            </div>
          </div>

          <button
            onClick={handleTouchAreaClick}
            className="text-xs text-slate-400 hover:text-white underline underline-offset-2 flex-shrink-0 ml-3"
          >
            Change File
          </button>
        </div>
      )}

      {/* EXACT REQUIRED BUTTON: "Start Full Analysis of the Selected File." */}
      {selectedFile && (
        <div className="w-full mt-5">
          <button
            onClick={onStartAnalysis}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:via-teal-400 hover:to-emerald-500 text-slate-950 font-bold text-base shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transform active:scale-[0.99] transition-all flex items-center justify-center gap-2 group cursor-pointer"
          >
            <span>Start Full Analysis of the Selected File.</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      )}

      {/* Sample Packages Selector for Immediate Browser Testing */}
      <div className="w-full mt-8 pt-6 border-t border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            Or test with a pre-configured sample package:
          </span>
          <span className="text-[11px] text-slate-400">1-click test</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {SAMPLE_PACKAGES.map((sample) => (
            <button
              key={sample.id}
              disabled={isLoadingSample}
              onClick={() => onLoadSample(sample)}
              className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-800/90 border border-slate-800 hover:border-emerald-500/40 text-left transition group relative overflow-hidden cursor-pointer"
            >
              <div className="flex items-start gap-2.5">
                <span className="text-2xl group-hover:scale-110 transition-transform">
                  {sample.icon}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white truncate group-hover:text-emerald-300">
                      {sample.name.split('_')[0]}
                    </span>
                    <span className="text-[9px] font-mono px-1 rounded bg-slate-800 text-slate-400">
                      {sample.type.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    {sample.description}
                  </p>
                  <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400 font-mono">
                    <span className="text-emerald-400">Coins, Gems, Diamonds</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Security & Feature Badges */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Client-Side In-Memory Decompression
        </span>
        <span className="flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          Android APK v1 &amp; v2 Digital Re-signing
        </span>
      </div>
    </div>
  );
};
