import React, { useState } from 'react';
import {
  Search,
  ArrowUpDown,
  Filter,
  CheckSquare,
  Square,
  Play,
  Heart,
  MoreVertical,
  Plus,
  Trash2,
  FolderPlus,
  ListPlus,
  PlaySquare,
  Edit,
  X,
} from 'lucide-react';
import { Song, SortField, LibraryFilter } from '../types';
import { ArtworkImage } from './ArtworkImage';

interface LibraryScreenProps {
  songs: Song[];
  searchQuery: string;
  onSearchChange: (q: string) => void;
  sortField: SortField;
  onSortFieldChange: (field: SortField) => void;
  sortAscending: boolean;
  onToggleSortOrder: () => void;
  filter: LibraryFilter;
  onFilterChange: (filter: LibraryFilter) => void;
  onPlaySong: (song: Song, contextList: Song[]) => void;
  onPlayNext: (song: Song) => void;
  onAddToQueue: (song: Song) => void;
  onToggleFavorite: (song: Song) => void;
  onAddToPlaylist: (song: Song) => void;
  onEditMetadata: (song: Song) => void;
  onDeleteSong: (song: Song) => void;
  onDeleteMultipleSongs: (songIds: string[]) => void;
  onAddMultipleToPlaylist: (songIds: string[]) => void;
  onAddSongsClick: () => void;
}

export const LibraryScreen: React.FC<LibraryScreenProps> = ({
  songs,
  searchQuery,
  onSearchChange,
  sortField,
  onSortFieldChange,
  sortAscending,
  onToggleSortOrder,
  filter,
  onFilterChange,
  onPlaySong,
  onPlayNext,
  onAddToQueue,
  onToggleFavorite,
  onAddToPlaylist,
  onEditMetadata,
  onDeleteSong,
  onDeleteMultipleSongs,
  onAddMultipleToPlaylist,
  onAddSongsClick,
}) => {
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activeMenuSongId, setActiveMenuSongId] = useState<string | null>(null);

  // Filter songs
  let filtered = songs.filter((s) => {
    if (filter === 'favorites' && !s.isFavorite) return false;
    if (filter === 'recent') {
      const oneWeekAgo = Date.now() - 7 * 24 * 3600 * 1000;
      if (s.dateAdded < oneWeekAgo) return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      s.title.toLowerCase().includes(q) ||
      s.artist.toLowerCase().includes(q) ||
      s.album.toLowerCase().includes(q) ||
      s.genre.toLowerCase().includes(q)
    );
  });

  // Sort songs
  filtered.sort((a, b) => {
    let cmp = 0;
    switch (sortField) {
      case 'title':
        cmp = a.title.localeCompare(b.title);
        break;
      case 'artist':
        cmp = a.artist.localeCompare(b.artist);
        break;
      case 'album':
        cmp = a.album.localeCompare(b.album);
        break;
      case 'dateAdded':
        cmp = a.dateAdded - b.dateAdded;
        break;
      case 'playCount':
        cmp = a.playCount - b.playCount;
        break;
    }
    return sortAscending ? cmp : -cmp;
  });

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const selectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((s) => s.id)));
    }
  };

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4 pb-28 pt-2">
      {/* Header with Title & Add Songs button */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100">
            Music Library
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {filtered.length} {filtered.length === 1 ? 'track' : 'tracks'} in collection
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsMultiSelect(!isMultiSelect);
              setSelectedIds(new Set());
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isMultiSelect
                ? 'bg-emerald-950 text-emerald-400 border-emerald-500'
                : 'text-slate-300 border-slate-700 hover:bg-slate-800'
            }`}
          >
            {isMultiSelect ? 'Done' : 'Select'}
          </button>

          <button
            onClick={onAddSongsClick}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs transition-all shadow-sm"
          >
            <Plus size={16} />
            <span>Add Songs</span>
          </button>
        </div>
      </div>

      {/* Multi-select Action Bar */}
      {isMultiSelect && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-100 animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <button
              onClick={selectAll}
              className="text-xs font-semibold hover:underline"
            >
              {selectedIds.size === filtered.length ? 'Deselect All' : 'Select All'}
            </button>
            <span className="text-xs text-emerald-300">
              ({selectedIds.size} selected)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              disabled={selectedIds.size === 0}
              onClick={() => {
                onAddMultipleToPlaylist(Array.from(selectedIds));
                setIsMultiSelect(false);
                setSelectedIds(new Set());
              }}
              className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-xs font-medium text-slate-950 transition-colors"
            >
              Add to Playlist
            </button>
            <button
              disabled={selectedIds.size === 0}
              onClick={() => {
                onDeleteMultipleSongs(Array.from(selectedIds));
                setIsMultiSelect(false);
                setSelectedIds(new Set());
              }}
              className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-xs font-medium text-white transition-colors"
            >
              Remove
            </button>
          </div>
        </div>
      )}

      {/* Search Input */}
      <div className="relative">
        <Search
          size={18}
          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search by title, artist, or album..."
          className="w-full bg-[#12181F] text-slate-100 placeholder-slate-500 text-sm rounded-xl pl-10 pr-9 py-2.5 border border-slate-800 focus:outline-none focus:border-emerald-500/60 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Filter Tabs & Sort Controls */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {(['all', 'favorites', 'recent'] as LibraryFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => onFilterChange(f)}
              className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-colors ${
                filter === f
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-[#12181F] text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {f === 'all' ? 'All Songs' : f}
            </button>
          ))}
        </div>

        {/* Sort Select */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <select
            value={sortField}
            onChange={(e) => onSortFieldChange(e.target.value as SortField)}
            className="bg-[#12181F] text-slate-300 text-xs font-medium rounded-lg px-2.5 py-1 border border-slate-800 focus:outline-none focus:border-emerald-500/50 cursor-pointer"
          >
            <option value="title">Title</option>
            <option value="artist">Artist</option>
            <option value="album">Album</option>
            <option value="dateAdded">Date Added</option>
            <option value="playCount">Play Count</option>
          </select>

          <button
            onClick={onToggleSortOrder}
            className="p-1 rounded-lg bg-[#12181F] text-slate-400 hover:text-slate-200 border border-slate-800 transition-colors"
            title={sortAscending ? 'Ascending' : 'Descending'}
          >
            <ArrowUpDown size={14} className={sortAscending ? '' : 'rotate-180'} />
          </button>
        </div>
      </div>

      {/* Songs List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 px-4 bg-[#12181F]/40 rounded-2xl border border-slate-800/60">
          <p className="text-sm font-semibold text-slate-300">No tracks found</p>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            {searchQuery
              ? `No results matching "${searchQuery}". Try a different keyword.`
              : 'Add your favorite songs to start listening offline.'}
          </p>
          <button
            onClick={onAddSongsClick}
            className="mt-4 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs inline-flex items-center gap-1.5 transition-all"
          >
            <Plus size={16} />
            <span>Add Songs Now</span>
          </button>
        </div>
      ) : (
        <div className="space-y-1.5">
          {filtered.map((song) => {
            const isSelected = selectedIds.has(song.id);
            const isMenuOpen = activeMenuSongId === song.id;

            return (
              <div
                key={song.id}
                onClick={() => {
                  if (isMultiSelect) {
                    toggleSelect(song.id);
                  } else {
                    onPlaySong(song, filtered);
                  }
                }}
                className={`relative flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500/50'
                    : 'bg-[#12181F] hover:bg-[#1A232C] border-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Multi-select checkbox */}
                  {isMultiSelect && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelect(song.id);
                      }}
                      className="text-emerald-400 flex-shrink-0"
                    >
                      {isSelected ? (
                        <CheckSquare size={18} className="fill-emerald-500 text-slate-950" />
                      ) : (
                        <Square size={18} className="text-slate-600" />
                      )}
                    </button>
                  )}

                  <ArtworkImage
                    artworkUrl={song.artworkUrl}
                    alt={song.title}
                    className="w-11 h-11 rounded-lg"
                    iconSize={20}
                  />

                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-100 truncate">
                      {song.title}
                    </p>
                    <p className="text-xs text-slate-400 truncate">
                      {song.artist} {song.album && `• ${song.album}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 flex-shrink-0">
                  <span className="text-xs text-slate-500 font-mono hidden sm:inline mr-2">
                    {formatDuration(song.duration)}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(song);
                    }}
                    className="p-1.5 text-slate-400 hover:text-emerald-400 transition-colors"
                    title="Favorite"
                  >
                    <Heart
                      size={18}
                      className={
                        song.isFavorite ? 'fill-emerald-500 text-emerald-500' : ''
                      }
                    />
                  </button>

                  {/* Kebab More Menu */}
                  <div className="relative">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenuSongId(isMenuOpen ? null : song.id);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
                      title="More options"
                    >
                      <MoreVertical size={18} />
                    </button>

                    {isMenuOpen && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="absolute right-0 top-8 z-40 w-44 bg-[#1A232C] border border-slate-700 rounded-xl shadow-2xl py-1 text-xs text-slate-200 divide-y divide-slate-800/80 animate-in fade-in zoom-in-95 duration-150"
                      >
                        <div className="py-1">
                          <button
                            onClick={() => {
                              onPlayNext(song);
                              setActiveMenuSongId(null);
                            }}
                            className="flex items-center gap-2.5 w-full px-3 py-2 text-left hover:bg-slate-700/50"
                          >
                            <PlaySquare size={15} className="text-emerald-400" />
                            <span>Play Next</span>
                          </button>
                          <button
                            onClick={() => {
                              onAddToQueue(song);
                              setActiveMenuSongId(null);
                            }}
                            className="flex items-center gap-2.5 w-full px-3 py-2 text-left hover:bg-slate-700/50"
                          >
                            <ListPlus size={15} className="text-emerald-400" />
                            <span>Add to Queue</span>
                          </button>
                          <button
                            onClick={() => {
                              onAddToPlaylist(song);
                              setActiveMenuSongId(null);
                            }}
                            className="flex items-center gap-2.5 w-full px-3 py-2 text-left hover:bg-slate-700/50"
                          >
                            <FolderPlus size={15} className="text-emerald-400" />
                            <span>Add to Playlist...</span>
                          </button>
                        </div>

                        <div className="py-1">
                          <button
                            onClick={() => {
                              onEditMetadata(song);
                              setActiveMenuSongId(null);
                            }}
                            className="flex items-center gap-2.5 w-full px-3 py-2 text-left hover:bg-slate-700/50"
                          >
                            <Edit size={15} className="text-slate-400" />
                            <span>Edit Metadata...</span>
                          </button>
                        </div>

                        <div className="py-1">
                          <button
                            onClick={() => {
                              onDeleteSong(song);
                              setActiveMenuSongId(null);
                            }}
                            className="flex items-center gap-2.5 w-full px-3 py-2 text-left text-rose-400 hover:bg-rose-950/40"
                          >
                            <Trash2 size={15} />
                            <span>Remove from Library</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
