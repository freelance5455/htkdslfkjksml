import React, { useState, useEffect } from 'react';
import { Track } from '../types';
import { FEATURED_TRACKS, ASSETS } from '../data/spiritualData';
import { Play, Pause, Sparkles, Heart, Search, Radio, Disc, Flame, Share2, Download, Trash2, Smile } from 'lucide-react';
import { DailyProphecyBento } from './DailyProphecyBento';
import { VerseOfTheDayBanner } from './VerseOfTheDayBanner';
import { PropheticWordCard } from './PropheticWordCard';
import { PraiseWallComponent } from './PraiseWallComponent';
import { offlineCache } from '../lib/offlineCache';

interface MusicPraiseViewProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onSelectTrack: (track: Track) => void;
  onTogglePlay: () => void;
  onOpenSoakingRoom: () => void;
}

export const MusicPraiseView: React.FC<MusicPraiseViewProps> = ({
  currentTrack,
  isPlaying,
  onSelectTrack,
  onTogglePlay,
  onOpenSoakingRoom,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMood, setSelectedMood] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [favorites, setFavorites] = useState<string[]>(['track-1', 'track-3']);
  const [downloadedIds, setDownloadedIds] = useState<string[]>(offlineCache.getDownloadedTracks());
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);
  const [fullOffline, setFullOffline] = useState(offlineCache.isFullOfflineExperienceEnabled());

  useEffect(() => {
    const unsub = offlineCache.subscribe(() => {
      setDownloadedIds(offlineCache.getDownloadedTracks());
      setFullOffline(offlineCache.isFullOfflineExperienceEnabled());
    });
    return unsub;
  }, []);

  const handleToggleFullOffline = () => {
    const newState = offlineCache.toggleFullOfflineExperience();
    setFullOffline(newState);
  };

  const handleShareTrack = async (track: Track, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `Listen to "${track.title}" by ${track.artist} on JUHNKRIX MUSIKA - Prophetic Gospel & Soaking.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: track.title,
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Share canceled', err);
      }
    } else {
      navigator.clipboard.writeText(`${shareText} (${window.location.href})`);
      setCopiedShareId(track.id);
      setTimeout(() => setCopiedShareId(null), 2500);
    }
  };

  const categories = [
    'All',
    'Soaking Meditation',
    'Anointed Worship',
    'High Praise',
    'Prophetic Chants',
    'Deliverance & Power',
    '📥 Offline Downloads',
  ];

  const moods = ['All', 'Uplifting', 'Repentance', 'Victory', 'Soaking'];

  const filteredTracks = FEATURED_TRACKS.filter((track) => {
    const isDownloadedTab = selectedCategory === '📥 Offline Downloads';
    const matchesCategory = isDownloadedTab ? downloadedIds.includes(track.id) : (selectedCategory === 'All' || track.category === selectedCategory);
    
    let matchesMood = true;
    if (selectedMood === 'Uplifting') {
      matchesMood = track.category === 'High Praise' || track.category === 'Anointed Worship';
    } else if (selectedMood === 'Repentance') {
      matchesMood = track.category === 'Deliverance & Power' || track.category === 'Prophetic Chants';
    } else if (selectedMood === 'Victory') {
      matchesMood = track.category === 'High Praise' || track.category === 'Deliverance & Power';
    } else if (selectedMood === 'Soaking') {
      matchesMood = track.category === 'Soaking Meditation';
    }

    const matchesSearch =
      track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.artist.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesMood && matchesSearch;
  });

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleDownload = (trackId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    offlineCache.toggleDownloadTrack(trackId);
    setDownloadedIds(offlineCache.getDownloadedTracks());
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Verse of the Day Persistent Banner */}
      <VerseOfTheDayBanner />

      {/* Daily Prophetic Rhema Word Component */}
      <PropheticWordCard />

      {/* Bento Grid Top Highlight Section */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Main Hero Bento Tile (Spans 3 cols on desktop) */}
        <div className="lg:col-span-3 relative rounded-3xl overflow-hidden border border-amber-500/30 shadow-2xl bg-slate-900 group flex flex-col justify-between min-h-[320px]">
          <div className="absolute inset-0 z-0">
            <img
              src={ASSETS.heroBanner}
              alt="Divine Worship Hero"
              className="w-full h-full object-cover object-center opacity-35 group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/20" />
          </div>

          <div className="relative z-10 p-6 sm:p-8 lg:p-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-400/30 backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>EXCLUSIVELY ON JUHNKRIX MUSIKA</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold font-serif text-amber-100 tracking-tight leading-tight">
              Anointed Worship & Soaking Audio Atmosphere
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
              Experience divine transformation through psalms, prophetic chants, and 528Hz soaking frequencies composed by Prophet JUHNKRIX SYNVAGORD to usher believers into heavenly stillness.
            </p>
          </div>

          <div className="relative z-10 p-6 sm:p-8 pt-0 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectTrack(FEATURED_TRACKS[0])}
              className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-bold flex items-center space-x-2 shadow-xl shadow-amber-500/20 hover:scale-105 transition-all"
            >
              <Play className="w-4 h-4 fill-slate-950 text-slate-950" />
              <span>Play Featured Worship Track</span>
            </button>

            <button
              onClick={onOpenSoakingRoom}
              className="px-5 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-amber-200 border border-amber-500/30 text-xs font-semibold flex items-center space-x-2 transition-all hover:border-amber-400 backdrop-blur-md"
            >
              <Disc className="w-4 h-4 text-amber-400" />
              <span>528Hz Soaking Room</span>
            </button>
          </div>
        </div>

        {/* Side Bento Tile: Prophet's Prophetic Soaking Feature */}
        <div className="lg:col-span-1 rounded-3xl border border-amber-500/20 bg-slate-900/80 backdrop-blur-md p-6 flex flex-col justify-between relative overflow-hidden shadow-xl group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="space-y-3 relative z-10">
            <div className="inline-flex items-center space-x-1.5 text-[10px] uppercase tracking-wider font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
              <Radio className="w-3 h-3 text-amber-400 animate-pulse" />
              <span>Divine Atmosphere</span>
            </div>

            <h3 className="text-lg font-bold font-serif text-amber-100 leading-snug">
              Deep Soaking Chamber
            </h3>

            <p className="text-xs text-slate-400 leading-relaxed">
              Step into continuous spiritual immersion with prophetic frequency tuning and high-worship soundscapes.
            </p>
          </div>

          <div className="pt-4 relative z-10 space-y-3">
            <div className="p-3 rounded-2xl bg-slate-950/60 border border-amber-500/15 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-amber-200">528 Hz Healing</p>
                <p className="text-[10px] text-slate-400">Restoration Frequency</p>
              </div>
              <button
                onClick={onOpenSoakingRoom}
                className="p-2.5 rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors shadow-md shadow-amber-500/20"
              >
                <Sparkles className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Prophetic Affirmation Bento Component */}
      <DailyProphecyBento />

      {/* Full Offline Experience Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/70 border-2 border-amber-500/40 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 text-amber-100">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/40 shadow-inner shrink-0 text-xl">
            📡
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold font-serif text-amber-200">Full Offline Experience Mode</h3>
            <p className="text-xs text-slate-300">
              Proactively caches the 5 most popular worship tracks locally into IndexedDB & CacheStorage for instant offline playback without any internet connection.
            </p>
          </div>
        </div>
        <button
          onClick={handleToggleFullOffline}
          className={`px-5 py-3 rounded-2xl text-xs font-mono font-black uppercase tracking-wider transition-all shadow-lg cursor-pointer flex items-center space-x-2 shrink-0 ${
            fullOffline
              ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30 ring-2 ring-emerald-400'
              : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/30'
          }`}
        >
          <span>{fullOffline ? '✓ Full Offline Mode Active (Top 5 Cached)' : 'Enable Full Offline Experience'}</span>
        </button>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          {/* Category Chips */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-300 ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'bg-slate-900/80 text-slate-300 hover:text-amber-200 hover:bg-slate-800 border border-amber-500/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64 flex-shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search worship, praise..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/90 border border-amber-500/20 rounded-xl pl-10 pr-4 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>
        </div>

        {/* Mood Selection Filter Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pt-2 pb-1 scrollbar-none">
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs font-bold shrink-0">
            <Smile className="w-3.5 h-3.5 text-amber-400" />
            <span>Spiritual Mood:</span>
          </div>
          {moods.map((mood) => (
            <button
              key={mood}
              onClick={() => setSelectedMood(mood)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-300 ${
                selectedMood === mood
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-400/20'
                  : 'bg-slate-900/60 text-slate-300 hover:text-amber-200 border border-amber-500/20'
              }`}
            >
              {mood}
            </button>
          ))}
        </div>
      </div>

      {/* Track List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-amber-200 font-serif flex items-center space-x-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <span>Anointed Playlists & Praise Tracks ({filteredTracks.length})</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTracks.map((track) => {
            const isCurrent = currentTrack?.id === track.id;
            const isFav = favorites.includes(track.id);
            const isDown = downloadedIds.includes(track.id) || offlineCache.isDownloaded(track.id);
            const isTop3 = offlineCache.isTopWorshipTrack(track.id);

            return (
              <div
                key={track.id}
                onClick={() => {
                  if (isCurrent) {
                    onTogglePlay();
                  } else {
                    onSelectTrack(track);
                  }
                }}
                className={`group p-4 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                  isCurrent
                    ? 'bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 border-amber-400/50 shadow-xl shadow-amber-500/10'
                    : 'bg-slate-900/60 hover:bg-slate-900/90 border-amber-500/10 hover:border-amber-500/30'
                }`}
              >
                <div>
                  <div className="flex items-center space-x-3">
                    <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 border border-amber-500/20">
                      <img
                        src={track.albumArt}
                        alt={track.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div
                        className={`absolute inset-0 bg-slate-950/50 flex items-center justify-center transition-opacity ${
                          isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                        }`}
                      >
                        {isCurrent && isPlaying ? (
                          <Pause className="w-6 h-6 text-amber-300" />
                        ) : (
                          <Play className="w-6 h-6 text-amber-300 fill-amber-300 ml-0.5" />
                        )}
                      </div>
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-400/20">
                          {track.category}
                        </span>
                        {track.isAnointedFeatured && (
                          <span className="text-[9px] font-semibold text-amber-400 uppercase tracking-widest flex items-center">
                            <Radio className="w-2.5 h-2.5 mr-0.5" /> Prophet Choice
                          </span>
                        )}
                        {isTop3 && (
                          <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-400/30 px-1.5 py-0.5 rounded uppercase tracking-wider flex items-center gap-1" title="Top 3 Worship Track - Explicitly Pre-cached for Offline Playback">
                            <Sparkles className="w-2.5 h-2.5 text-emerald-400" /> Offline Ready
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-bold text-amber-100 truncate mt-1 group-hover:text-amber-300 transition-colors font-serif">
                        {track.title}
                      </h4>
                      <p className="text-xs text-amber-300/70 truncate">{track.artist}</p>
                    </div>

                    <div className="flex items-center space-x-1">
                      <button
                        onClick={(e) => handleToggleDownload(track.id, e)}
                        className={`p-2 rounded-xl transition-colors ${
                          isDown ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-500 hover:text-amber-300'
                        }`}
                        title={isDown ? 'Downloaded for Offline (Click to Delete)' : 'Save for Offline Access'}
                      >
                        {isDown ? <Trash2 className="w-4 h-4 text-emerald-400" /> : <Download className="w-4 h-4" />}
                      </button>

                      <button
                        onClick={(e) => handleShareTrack(track, e)}
                        className="p-2 rounded-xl text-slate-400 hover:text-amber-300 transition-colors"
                        title="Share Track"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={(e) => toggleFavorite(track.id, e)}
                        className={`p-2 rounded-xl transition-colors ${
                          isFav ? 'text-rose-400 bg-rose-500/10' : 'text-slate-500 hover:text-amber-300'
                        }`}
                        title="Favorite Track"
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-400' : ''}`} />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-3 line-clamp-2 leading-relaxed">
                    {track.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-amber-500/10 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="truncate max-w-[180px] italic text-amber-200/80">
                    {track.scriptureRef}
                  </span>
                  <span className="font-mono text-slate-500">
                    {Math.floor(track.duration / 60)}:
                    {(track.duration % 60 < 10 ? '0' : '') + (track.duration % 60)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Community Praise Wall */}
      <PraiseWallComponent />
    </div>
  );
};
