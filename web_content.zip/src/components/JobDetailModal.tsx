import React, { useState, useEffect } from 'react';
import { JobPosting } from '../types/job';
import { useTheme } from '../context/ThemeContext';
import {
  X,
  MapPin,
  Calendar,
  Award,
  IndianRupee,
  Users,
  ExternalLink,
  Bookmark,
  Share2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ShieldCheck,
  Check,
  Copy,
  Briefcase,
  FileCheck,
  Heart,
  Eye,
  Clock
} from 'lucide-react';
import { JobShareModal } from './JobShareModal';
import { incrementJobViewCount, incrementJobApplicationCount } from '../lib/firebase';

interface JobDetailModalProps {
  job: JobPosting | null;
  isOpen: boolean;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: (jobId: string) => void;
  onReportJob?: (job: JobPosting) => void;
  isLiked?: boolean;
  onToggleLike?: (jobId: string) => void;
}

export const JobDetailModal: React.FC<JobDetailModalProps> = ({
  job,
  isOpen,
  onClose,
  isSaved,
  onToggleSave,
  onReportJob,
  isLiked = false,
  onToggleLike
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const [copiedLink, setCopiedLink] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Track view count when job detail modal opens
  useEffect(() => {
    if (isOpen && job?.id) {
      incrementJobViewCount(job.id).catch(() => {});
    }
  }, [isOpen, job?.id]);

  if (!isOpen || !job) return null;

  const handleCopyLink = () => {
    const deepLink = `${window.location.origin}${window.location.pathname}?job=${job.id}`;
    navigator.clipboard.writeText(deepLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleApplyClick = () => {
    incrementJobApplicationCount(job.id).catch(() => {});
    window.open(job.officialApplicationLink, '_blank', 'noopener,noreferrer');
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const deadlineDate = job.closingDate || job.lastDate || job.expiryDate;
  const deadline = new Date(deadlineDate || '');
  const diffDays = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  const isExpired = job.status === 'EXPIRED' || (!isNaN(deadline.getTime()) && diffDays < 0);
  const isClosingSoon = !isExpired && !isNaN(deadline.getTime()) && diffDays >= 0 && diffDays <= 7;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4 overflow-y-auto">
        <div
          id="job-detail-sheet"
          className={`w-full max-w-2xl border-t sm:border rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in slide-in-from-bottom-6 duration-200 ${
            isDark
              ? 'bg-slate-900 border-slate-800 text-slate-100'
              : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          {/* Header */}
          <div
            className={`p-4 sm:p-5 border-b flex items-start justify-between gap-3 sticky top-0 z-10 backdrop-blur-md ${
              isDark
                ? 'bg-slate-900/95 border-slate-800'
                : 'bg-white/95 border-slate-200'
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-10 h-10 rounded-2xl border flex items-center justify-center text-xl shrink-0 shadow-inner ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white'
                    : 'bg-slate-100 border-slate-200 text-slate-900'
                }`}
              >
                {job.orgLogo || (job.sector === 'Government' ? '🏛️' : '💼')}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold rounded uppercase border ${
                      job.sector === 'Government'
                        ? isDark
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : isDark
                        ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}
                  >
                    {job.sector} Sector
                  </span>

                  {isExpired ? (
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded border flex items-center gap-1 ${
                        isDark
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}
                    >
                      <Clock className="w-3 h-3 text-rose-500" />
                      EXPIRED
                    </span>
                  ) : isClosingSoon ? (
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded border flex items-center gap-1 animate-pulse ${
                        isDark
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-amber-50 text-amber-700 border-amber-300'
                      }`}
                    >
                      CLOSING SOON ({diffDays}d)
                    </span>
                  ) : job.status === 'VERIFIED' ? (
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded border flex items-center gap-1 ${
                        isDark
                          ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                          : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                      }`}
                    >
                      <ShieldCheck className="w-3 h-3 text-indigo-500" />
                      VERIFIED VACANCY
                    </span>
                  ) : (
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded border flex items-center gap-1 ${
                        isDark
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      <FileCheck className="w-3 h-3 text-emerald-500" />
                      OFFICIAL NOTIFICATION
                    </span>
                  )}
                </div>
                <p className={`text-xs truncate mt-0.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                  {job.organization}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {/* Like Button */}
              {onToggleLike && (
                <button
                  id="btn-detail-like"
                  onClick={() => onToggleLike(job.id)}
                  className={`p-2 rounded-xl border flex items-center gap-1 text-xs transition-colors ${
                    isLiked
                      ? isDark
                        ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                        : 'bg-rose-50 border-rose-300 text-rose-600'
                      : isDark
                      ? 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-rose-300'
                      : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-rose-600'
                  }`}
                  title="Like Job"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                  <span className="text-[11px] font-bold">{job.likesCount || 0}</span>
                </button>
              )}

              {/* Report Button */}
              {onReportJob && (
                <button
                  onClick={() => onReportJob(job)}
                  className={`p-2 rounded-xl border transition-colors ${
                    isDark
                      ? 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-rose-400'
                      : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-rose-600'
                  }`}
                  title="Report Incorrect / Fake Job"
                >
                  <AlertTriangle className="w-4 h-4" />
                </button>
              )}

              {/* Bookmark Button */}
              <button
                id="btn-detail-bookmark"
                onClick={() => onToggleSave(job.id)}
                className={`p-2 rounded-xl border transition-colors flex items-center gap-1 ${
                  isSaved
                    ? isDark
                      ? 'bg-amber-500/20 border-amber-500/40 text-amber-400'
                      : 'bg-amber-50 border-amber-300 text-amber-600'
                    : isDark
                    ? 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
                title="Bookmark"
              >
                <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                <span className="text-[11px] font-bold">{job.savesCount || 0}</span>
              </button>

              {/* Share Button */}
              <button
                id="btn-detail-share"
                onClick={() => setIsShareModalOpen(true)}
                className={`p-2 rounded-xl border transition-colors flex items-center gap-1 ${
                  isDark
                    ? 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
                title="Share via WhatsApp, Telegram, Facebook, etc."
              >
                <Share2 className="w-4 h-4" />
                <span className="text-[11px] font-bold">{job.sharesCount || 0}</span>
              </button>

              <button
                id="btn-detail-close"
                onClick={onClose}
                className={`p-2 rounded-xl border transition-colors ${
                  isDark
                    ? 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-white'
                    : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-900'
                }`}
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Scrollable Body */}
          <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
            {/* Authentic Verification Banner */}
            <div
              className={`p-3 rounded-xl flex items-start gap-2.5 text-xs border ${
                isDark
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">AUTHENTIC RECRUITMENT:</span> Cross-verified with official government gazettes & authorized commission portals. Last verified: {job.lastVerifiedDate || 'Recently'}.
              </div>
            </div>

            {/* Title & Notification Code */}
            <div>
              <h1
                className={`text-lg sm:text-xl font-bold leading-snug ${
                  isDark ? 'text-white' : 'text-slate-900'
                }`}
              >
                {job.title}
              </h1>
              <div
                className={`flex items-center gap-3 mt-1.5 text-xs flex-wrap ${
                  isDark ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                <span className={isDark ? 'font-semibold text-slate-300' : 'font-semibold text-slate-700'}>
                  Advt No: {job.advtNumber}
                </span>
                <span>•</span>
                <span>Posted: {job.postDate}</span>
                {job.viewsCount !== undefined && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      <span>{job.viewsCount} Views</span>
                    </span>
                  </>
                )}
                {job.applicationsCount !== undefined && (
                  <>
                    <span>•</span>
                    <span className="text-emerald-500 font-semibold">
                      {job.applicationsCount} Applications Tracked
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div
                className={`p-3 rounded-2xl border ${
                  isDark ? 'bg-slate-800/60 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className={`flex items-center gap-1.5 text-xs mb-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  <Users className="w-4 h-4 text-indigo-500" />
                  <span>Vacancies</span>
                </div>
                <div className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {job.vacancies.toLocaleString('en-IN')} Posts
                </div>
              </div>

              <div
                className={`p-3 rounded-2xl border ${
                  isDark ? 'bg-slate-800/60 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className={`flex items-center gap-1.5 text-xs mb-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  <IndianRupee className="w-4 h-4 text-emerald-500" />
                  <span>Salary / Pay</span>
                </div>
                <div className={`text-sm font-bold truncate ${isDark ? 'text-white' : 'text-slate-900'}`} title={job.salary}>
                  {job.salary}
                </div>
              </div>

              <div
                className={`p-3 rounded-2xl border ${
                  isDark ? 'bg-slate-800/60 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className={`flex items-center gap-1.5 text-xs mb-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  <Calendar className="w-4 h-4 text-rose-500" />
                  <span>Deadline</span>
                </div>
                <div className={`text-sm font-bold truncate ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {job.closingDate || job.lastDate}
                </div>
              </div>

              <div
                className={`p-3 rounded-2xl border ${
                  isDark ? 'bg-slate-800/60 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className={`flex items-center gap-1.5 text-xs mb-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  <MapPin className="w-4 h-4 text-amber-500" />
                  <span>Location</span>
                </div>
                <div className={`text-sm font-bold truncate ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {job.district}, {job.state}
                </div>
              </div>
            </div>

            {/* Eligibility & Qualifications */}
            <div
              className={`p-4 rounded-2xl border space-y-3 ${
                isDark ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                <Award className="w-4 h-4" /> Eligibility & Criteria
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <span className={`block mb-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                    Required Qualification:
                  </span>
                  <span className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {job.qualification}
                  </span>
                </div>
                <div>
                  <span className={`block mb-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                    Age Criteria:
                  </span>
                  <span className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {job.ageLimit}
                  </span>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                <Briefcase className="w-4 h-4" /> Job Summary & Role
              </h2>
              <p
                className={`text-xs leading-relaxed whitespace-pre-line p-3.5 rounded-2xl border ${
                  isDark
                    ? 'bg-slate-800/20 border-slate-800 text-slate-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                {job.description}
              </p>
            </div>

            {/* Key Important Dates */}
            {job.importantDates && job.importantDates.length > 0 && (
              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5 mb-2">
                  <Calendar className="w-4 h-4" /> Schedule of Events
                </h2>
                <ul className="space-y-1.5 text-xs">
                  {job.importantDates.map((d, idx) => (
                    <li
                      key={idx}
                      className={`flex items-center justify-between border-b pb-1 last:border-none ${
                        isDark ? 'border-slate-800/60' : 'border-slate-200'
                      }`}
                    >
                      <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>{d.label}:</span>
                      <span className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>{d.date}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Selection Process */}
            {job.selectionProcess && job.selectionProcess.length > 0 && (
              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-500 flex items-center gap-1.5 mb-2">
                  <CheckCircle2 className="w-4 h-4" /> Selection Procedure
                </h2>
                <ul className="space-y-1.5 text-xs">
                  {job.selectionProcess.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-500 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Application Fee */}
            <div
              className={`p-3.5 rounded-2xl border text-xs ${
                isDark ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <span className={`font-bold ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Application Fee: </span>
              <span className={isDark ? 'text-slate-200' : 'text-slate-800'}>{job.applicationFee}</span>
            </div>

            {/* Official Source & Gazette Verification */}
            <div
              className={`p-3.5 rounded-2xl border text-xs space-y-1 ${
                isDark ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <span className={`font-bold ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Official Notification Source:
              </span>
              <p
                className={`font-mono text-[11px] break-all p-2 rounded-lg mt-1 border ${
                  isDark
                    ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                {job.officialSource}
              </p>
            </div>
          </div>

          {/* Footer Actions */}
          <div
            className={`p-4 border-t flex items-center gap-3 ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <button
              id="btn-copy-apply-link"
              onClick={handleCopyLink}
              className={`flex-1 py-3 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 border transition-colors ${
                isDark
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
              }`}
            >
              {copiedLink ? (
                <>
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span>Link Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Link</span>
                </>
              )}
            </button>

            <button
              id="btn-open-official-portal"
              onClick={handleApplyClick}
              className="flex-[2] py-3 px-5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98]"
            >
              <span>Apply on Official Portal</span>
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Share Modal */}
      <JobShareModal
        job={job}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </>
  );
};
