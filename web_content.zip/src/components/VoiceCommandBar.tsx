import React, { useState } from 'react';
import { Mic, MicOff, Send, Sparkles, Volume2, VolumeX } from 'lucide-react';

interface VoiceCommandBarProps {
  isListening: boolean;
  isSpeaking: boolean;
  voiceFeedbackEnabled: boolean;
  liveTranscript: string;
  onToggleListening: () => void;
  onSubmitCommand: (text: string) => void;
  onToggleVoiceFeedback: () => void;
}

export const VoiceCommandBar: React.FC<VoiceCommandBarProps> = ({
  isListening,
  isSpeaking,
  voiceFeedbackEnabled,
  liveTranscript,
  onToggleListening,
  onSubmitCommand,
  onToggleVoiceFeedback,
}) => {
  const [inputText, setInputText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSubmitCommand(inputText.trim());
    setInputText('');
  };

  const handleQuickPrompt = (prompt: string) => {
    onSubmitCommand(prompt);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 p-3 sm:p-4 bg-gray-950/90 backdrop-blur-xl border-t border-cyan-500/30 shadow-[0_-10px_30px_rgba(3,7,18,0.8)]">
      <div className="max-w-4xl mx-auto space-y-2.5">
        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px] font-mono-code">
          <span className="text-slate-500 shrink-0 uppercase tracking-widest pl-1">
            Prompt Jarvis:
          </span>
          <button
            onClick={() => handleQuickPrompt('Schedule team debrief at 4 PM')}
            className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-800 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition shrink-0"
          >
            "Schedule meeting at 4 PM"
          </button>
          <button
            onClick={() => handleQuickPrompt('Remind me to call Pepper in 10 minutes')}
            className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-800 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition shrink-0"
          >
            "Remind me in 10 mins"
          </button>
          <button
            onClick={() => handleQuickPrompt('Call Happy Hogan')}
            className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-800 hover:border-emerald-400 text-slate-300 hover:text-emerald-300 transition shrink-0"
          >
            "Call Happy Hogan"
          </button>
          <button
            onClick={() => handleQuickPrompt('Turn on flashlight')}
            className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-800 hover:border-amber-400 text-slate-300 hover:text-amber-300 transition shrink-0"
          >
            "Turn on flashlight"
          </button>
          <button
            onClick={() => handleQuickPrompt('Open WhatsApp')}
            className="px-2.5 py-1 rounded-full bg-gray-900 border border-gray-800 hover:border-green-400 text-slate-300 hover:text-green-300 transition shrink-0"
          >
            "Open WhatsApp"
          </button>
        </div>

        {/* Live Audio / Transcript HUD */}
        {(isListening || liveTranscript) && (
          <div className="flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs font-mono-code text-cyan-300 animate-pulse">
            <div className="flex items-center gap-2 truncate">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="truncate">
                {liveTranscript ? `"${liveTranscript}"` : 'Listening for "Jarvis" or command...'}
              </span>
            </div>
            <span className="text-[10px] text-cyan-400/80 uppercase tracking-widest shrink-0 ml-2">
              SPEECH RECOGNITION ACTIVE
            </span>
          </div>
        )}

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          {/* Voice Mic Button */}
          <button
            type="button"
            onClick={onToggleListening}
            aria-label={isListening ? 'Stop listening' : 'Start voice recognition'}
            className={`relative p-3 rounded-2xl font-bold transition-all shadow-lg shrink-0 flex items-center justify-center ${
              isListening
                ? 'bg-red-600 text-white shadow-red-600/50 animate-pulse scale-105'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-gray-950 shadow-cyan-500/30 hover:scale-105'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Text Input */}
          <div className="relative flex-1">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={isListening ? 'Listening to voice...' : 'Say "Jarvis" or type a command...'}
              className="w-full bg-gray-900 border border-gray-800 focus:border-cyan-400 rounded-2xl px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none transition shadow-inner"
            />
          </div>

          {/* Voice Response Toggle */}
          <button
            type="button"
            onClick={onToggleVoiceFeedback}
            aria-label={voiceFeedbackEnabled ? 'Disable voice synthesis' : 'Enable voice synthesis'}
            className={`p-3 rounded-2xl border transition shrink-0 ${
              voiceFeedbackEnabled
                ? 'bg-gray-900 border-cyan-500/40 text-cyan-400'
                : 'bg-gray-900 border-gray-800 text-slate-500'
            }`}
          >
            {voiceFeedbackEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!inputText.trim()}
            aria-label="Send command"
            className="p-3 rounded-2xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:hover:bg-cyan-600 text-gray-950 transition shrink-0 shadow-md shadow-cyan-600/30"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
