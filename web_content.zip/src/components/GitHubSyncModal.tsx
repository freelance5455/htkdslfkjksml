import React, { useState, useEffect } from 'react';
import { FileItem, Project } from '../types';
import { importFromGitHub, pushToGitHub } from '../utils/github';
import { 
  GitBranch, 
  UploadCloud, 
  DownloadCloud, 
  Key, 
  FolderGit2, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  ExternalLink, 
  X, 
  Eye, 
  EyeOff,
  Github
} from 'lucide-react';

interface GitHubSyncModalProps {
  isOpen: boolean;
  initialMode?: 'push' | 'import';
  currentProject: Project;
  onClose: () => void;
  onImportSuccess: (project: { name: string; files: FileItem[] }) => void;
}

export const GitHubSyncModal: React.FC<GitHubSyncModalProps> = ({
  isOpen,
  initialMode = 'push',
  currentProject,
  onClose,
  onImportSuccess,
}) => {
  const [mode, setMode] = useState<'push' | 'import'>(initialMode);
  const [token, setToken] = useState(() => localStorage.getItem('devarena_github_token') || '');
  const [showToken, setShowToken] = useState(false);
  const [rememberToken, setRememberToken] = useState(true);

  // Push state
  const [pushRepo, setPushRepo] = useState(() => localStorage.getItem('devarena_github_push_repo') || '');
  const [pushBranch, setPushBranch] = useState('main');
  const [commitMessage, setCommitMessage] = useState(`Update ${currentProject.name} from NEXORA Studio`);

  // Import state
  const [importRepo, setImportRepo] = useState('');
  const [importBranch, setImportBranch] = useState('');

  // Status state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successResult, setSuccessResult] = useState<{ message: string; url?: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setError(null);
      setSuccessResult(null);
      setCommitMessage(`Update ${currentProject.name} from NEXORA Studio`);
    }
  }, [isOpen, initialMode, currentProject.name]);

  if (!isOpen) return null;

  const saveTokenPreference = (pat: string) => {
    if (rememberToken && pat.trim()) {
      localStorage.setItem('devarena_github_token', pat.trim());
    } else if (!rememberToken) {
      localStorage.removeItem('devarena_github_token');
    }
  };

  const handlePush = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessResult(null);

    if (!token.trim()) {
      setError('Please provide a GitHub Personal Access Token with repo scope.');
      return;
    }
    if (!pushRepo.trim()) {
      setError('Please specify a repository in "owner/repo" format (e.g. amaan/my-website).');
      return;
    }

    setLoading(true);
    saveTokenPreference(token);
    localStorage.setItem('devarena_github_push_repo', pushRepo.trim());

    try {
      const result = await pushToGitHub({
        token: token.trim(),
        repoInput: pushRepo.trim(),
        files: currentProject.files,
        commitMessage: commitMessage.trim() || 'Update from NEXORA Studio',
        branch: pushBranch.trim() || 'main',
      });

      setSuccessResult({
        message: `Successfully pushed ${currentProject.files.filter((f) => !f.isFolder).length} files to branch "${result.branch}"!`,
        url: result.commitUrl,
      });
    } catch (err: any) {
      setError(err?.message || 'Failed to push to GitHub.');
    } finally {
      setLoading(false);
    }
  };

  const handleImport = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessResult(null);

    if (!importRepo.trim()) {
      setError('Please specify a GitHub repository name or URL to import from.');
      return;
    }

    setLoading(true);
    saveTokenPreference(token);

    try {
      const result = await importFromGitHub(importRepo.trim(), token.trim(), importBranch.trim());
      if (result.files.length === 0) {
        throw new Error('No compatible files found in this repository.');
      }

      onImportSuccess({
        name: result.projectName,
        files: result.files,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to import repository.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#181920] border border-[#2e3142] rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden text-slate-200 animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="h-14 px-5 border-b border-[#2e3142] bg-[#121318] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242634] flex items-center justify-center text-white">
              <Github className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <span>GitHub Repository Sync</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Sync project code seamlessly with your GitHub account
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="p-3 bg-[#14151b] border-b border-[#242634] flex items-center justify-center">
          <div className="grid grid-cols-2 gap-1 w-full max-w-xs bg-[#0d0e13] p-1 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                setMode('push');
                setError(null);
                setSuccessResult(null);
              }}
              className={`py-1.5 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                mode === 'push'
                  ? 'bg-[#359efe] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Push to GitHub</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('import');
                setError(null);
                setSuccessResult(null);
              }}
              className={`py-1.5 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                mode === 'import'
                  ? 'bg-[#359efe] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <DownloadCloud className="w-3.5 h-3.5" />
              <span>Import from GitHub</span>
            </button>
          </div>
        </div>

        {/* Body Container */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Notifications */}
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{error}</span>
            </div>
          )}

          {successResult && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-medium">{successResult.message}</span>
              </div>
              {successResult.url && (
                <a
                  href={successResult.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center space-x-1 font-semibold text-[#359efe] hover:underline pt-1"
                >
                  <span>View Commit on GitHub</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          )}

          {/* Common Personal Access Token Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                <Key className="w-3.5 h-3.5 text-[#359efe]" />
                <span>Personal Access Token (PAT)</span>
              </label>
              <a
                href="https://github.com/settings/tokens/new?scopes=repo&description=NEXORA%20Studio%20Sync"
                target="_blank"
                rel="noreferrer"
                className="text-[10px] text-[#359efe] hover:underline flex items-center space-x-1"
              >
                <span>Generate token</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>

            <div className="relative">
              <input
                type={showToken ? 'text' : 'password'}
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder={mode === 'push' ? 'ghp_xxxxxxxxxxxxxxxxxxxx (Requires repo scope)' : 'Optional for public repos, required for private'}
                className="w-full px-3 py-2 pr-10 text-xs font-mono rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
              >
                {showToken ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="flex items-center space-x-2 pt-0.5">
              <input
                type="checkbox"
                id="rememberPat"
                checked={rememberToken}
                onChange={(e) => setRememberToken(e.target.checked)}
                className="rounded accent-[#359efe] cursor-pointer"
              />
              <label htmlFor="rememberPat" className="text-[11px] text-slate-400 cursor-pointer">
                Remember token in local browser storage
              </label>
            </div>
          </div>

          {/* MODE: PUSH */}
          {mode === 'push' && (
            <form onSubmit={handlePush} className="space-y-4 pt-2">
              <div className="p-3 rounded-xl border border-slate-800 bg-[#121318] text-xs space-y-1">
                <div className="text-[11px] text-slate-400">Current Active Workspace:</div>
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <FolderGit2 className="w-3.5 h-3.5 text-[#359efe]" />
                  <span>{currentProject.name}</span>
                  <span className="text-slate-400 font-normal">
                    ({currentProject.files.filter((f) => !f.isFolder).length} files)
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Target Repository (owner/repo)
                </label>
                <input
                  type="text"
                  required
                  value={pushRepo}
                  onChange={(e) => setPushRepo(e.target.value)}
                  placeholder="e.g. amaan/my-project or https://github.com/amaan/my-project"
                  className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Branch
                  </label>
                  <div className="relative">
                    <GitBranch className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={pushBranch}
                      onChange={(e) => setPushBranch(e.target.value)}
                      placeholder="main"
                      className="w-full pl-8 pr-2 py-2 text-xs font-mono rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
                    />
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Commit Message
                  </label>
                  <input
                    type="text"
                    required
                    value={commitMessage}
                    onChange={(e) => setCommitMessage(e.target.value)}
                    placeholder="Commit message..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white flex items-center space-x-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Pushing files...</span>
                    </>
                  ) : (
                    <>
                      <UploadCloud className="w-3.5 h-3.5" />
                      <span>Push to GitHub</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* MODE: IMPORT */}
          {mode === 'import' && (
            <form onSubmit={handleImport} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  GitHub Repository (URL or owner/repo)
                </label>
                <input
                  type="text"
                  required
                  value={importRepo}
                  onChange={(e) => setImportRepo(e.target.value)}
                  placeholder="e.g. facebook/react or https://github.com/amaan/portfolio"
                  className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Public repositories do not require a token. Private repositories require a token above.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Branch (optional)
                </label>
                <div className="relative">
                  <GitBranch className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    value={importBranch}
                    onChange={(e) => setImportBranch(e.target.value)}
                    placeholder="Leave empty for repository default branch"
                    className="w-full pl-8 pr-3 py-2 text-xs font-mono rounded-xl border border-slate-700 bg-[#101117] text-white focus:outline-none focus:border-[#359efe]"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white flex items-center space-x-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Importing files...</span>
                    </>
                  ) : (
                    <>
                      <DownloadCloud className="w-3.5 h-3.5" />
                      <span>Import from GitHub</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
