import { useState } from 'react';
import {
  Users,
  Compass,
  FileSpreadsheet,
  FolderLock,
  Send,
  Plus,
  Search,
  CheckCircle,
  FileText,
  Printer,
  Sparkles,
  Phone,
  Mail,
  Shield,
  Trash2,
  Edit,
  Eye,
  UserCheck,
  TrendingUp,
  X,
  CreditCard
} from 'lucide-react';
import { AgencyClient, Devis, DevisItem, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';
import { calculateDevisTotals, generateDevisNumber } from '../../utils/devis';

interface AgencyDashboardProps {
  clients: AgencyClient[];
  devisList: Devis[];
  language: Language;
  currency: Currency;
  onSendBroadcast: (title: string, message: string) => void;
  onCloseAgencyMode: () => void;
}

export function AgencyDashboard({
  clients: initialClients,
  devisList: initialDevisList,
  language,
  currency,
  onSendBroadcast,
  onCloseAgencyMode,
}: AgencyDashboardProps) {
  const [activeTab, setActiveTab] = useState<'kpi' | 'clients' | 'devis' | 'docs' | 'broadcast'>('kpi');
  const [clients, setClients] = useState<AgencyClient[]>(initialClients);
  const [devisList, setDevisList] = useState<Devis[]>(initialDevisList);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDevis, setSelectedDevis] = useState<Devis | null>(initialDevisList[0]);

  // New Client Modal State
  const [showAddClientModal, setShowAddClientModal] = useState(false);
  const [newClient, setNewClient] = useState({
    fullName: '',
    phone: '',
    email: '',
    passportNumber: '',
    city: 'الجزائر العاصمة',
    notes: '',
    vip: false,
  });

  // New Devis Modal State
  const [showAddDevisModal, setShowAddDevisModal] = useState(false);
  const [newDevisData, setNewDevisData] = useState<{
    clientName: string;
    clientPhone: string;
    clientEmail: string;
    destination: string;
    travelDates: string;
    items: DevisItem[];
    agencyFeeDZD: number;
    taxRatePercent: number;
    notes: string;
  }>({
    clientName: 'أحمد بن علي',
    clientPhone: '+213 550 88 99 00',
    clientEmail: 'ahmed.benali@email.dz',
    destination: 'إسطنبول (رحلة 7 أيام فاخرة)',
    travelDates: '12 - 19 ديسمبر 2026',
    items: [
      { id: '1', description: 'تذاكر طيران الخطوط التركية ALG-IST-ALG', category: 'flight', unitPriceDZD: 68500, quantity: 2 },
      { id: '2', description: 'إقامة 7 ليالٍ Swissôtel The Bosphorus مع الإفطار', category: 'hotel', unitPriceDZD: 38000, quantity: 7 },
      { id: '3', description: 'استقبال وتوديع بمطار إسطنبول VIP Transfer', category: 'transfer', unitPriceDZD: 16000, quantity: 2 },
      { id: '4', description: 'تأمين سفر دولي أليانز Allianz لشخصين', category: 'insurance', unitPriceDZD: 4500, quantity: 2 },
    ],
    agencyFeeDZD: 15000,
    taxRatePercent: 9,
    notes: 'يشمل العرض خدمة الكونسيرج 24/7 والمساعدة بمطار هواري بومدين.',
  });

  // Broadcast Notification State
  const [broadcastTitle, setBroadcastTitle] = useState('وثيقة رحلتك أصبحت جاهزة للتحميل');
  const [broadcastMessage, setBroadcastMessage] = useState('يرجى الدخول إلى محفظة TAKI-GO لتحميل تذاكر الطيران وقسيمة الفندق.');
  const [broadcastTarget, setBroadcastTarget] = useState<'all' | 'vip' | 'single'>('all');
  const [broadcastSent, setBroadcastSent] = useState(false);

  const t = translations[language];

  // Client search filter
  const filteredClients = clients.filter(c =>
    c.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const created: AgencyClient = {
      id: `cli-${Date.now()}`,
      fullName: newClient.fullName,
      phone: newClient.phone,
      email: newClient.email,
      passportNumber: newClient.passportNumber,
      city: newClient.city,
      totalTrips: 0,
      vip: newClient.vip,
      notes: newClient.notes,
      registeredDate: 'اليوم',
    };
    setClients([created, ...clients]);
    setShowAddClientModal(false);
    setNewClient({
      fullName: '',
      phone: '',
      email: '',
      passportNumber: '',
      city: 'الجزائر العاصمة',
      notes: '',
      vip: false,
    });
  };

  const handleCreateDevisSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totals = calculateDevisTotals(newDevisData.items, newDevisData.agencyFeeDZD, newDevisData.taxRatePercent);
    const createdDevis: Devis = {
      id: `dev-${Date.now()}`,
      devisNumber: generateDevisNumber(devisList.length + 43),
      clientName: newDevisData.clientName,
      clientPhone: newDevisData.clientPhone,
      clientEmail: newDevisData.clientEmail,
      destination: newDevisData.destination,
      travelDates: newDevisData.travelDates,
      items: newDevisData.items,
      subtotalDZD: totals.subtotalDZD,
      agencyFeeDZD: totals.agencyFeeDZD,
      taxRatePercent: newDevisData.taxRatePercent,
      totalDZD: totals.totalDZD,
      status: 'sent',
      createdAt: 'اليوم',
      validUntil: 'بعد 15 يوماً',
      notes: newDevisData.notes,
      agencyNotes: 'عرض مسعر عبر منصة Tourism By Taki Backoffice',
    };
    setDevisList([createdDevis, ...devisList]);
    setSelectedDevis(createdDevis);
    setShowAddDevisModal(false);
  };

  const handleSendBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;
    onSendBroadcast(broadcastTitle, broadcastMessage);
    setBroadcastSent(true);
    setTimeout(() => {
      setBroadcastSent(false);
      setBroadcastTitle('');
      setBroadcastMessage('');
    }, 2500);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Top Banner with Agency Identity & Exit to Client View */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-[#0c1a40] via-[#091535] to-[#060c22] border border-cyan-500/30 text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-[0_0_20px_rgba(0,240,255,0.4)]">
            <div className="w-full h-full bg-[#070b1e] rounded-2xl flex items-center justify-center font-black text-cyan-400">
              TB
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-black text-white">
                {t.agencyDashboardTitle}
              </h1>
              <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded-full font-bold">
                ADMIN CONSOLE
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              {t.agencySubtitle}
            </p>
          </div>
        </div>

        <button
          onClick={onCloseAgencyMode}
          className="self-start md:self-auto px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-xs text-cyan-300 font-semibold transition-colors"
        >
          {language === 'ar' ? '← العودة لواجهة العميل' : '← Back to Client View'}
        </button>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'kpi', label: language === 'ar' ? 'المؤشرات العامة' : 'KPIs', icon: <TrendingUp className="w-3.5 h-3.5" /> },
          { id: 'clients', label: t.tabClients, icon: <Users className="w-3.5 h-3.5" /> },
          { id: 'devis', label: t.tabDevis, icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
          { id: 'docs', label: t.tabDocs, icon: <FolderLock className="w-3.5 h-3.5" /> },
          { id: 'broadcast', label: t.tabBroadcast, icon: <Send className="w-3.5 h-3.5" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-2xl flex items-center gap-1.5 whitespace-nowrap text-xs font-bold transition-all border ${
              activeTab === tab.id
                ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 1. KPI OVERVIEW */}
      {activeTab === 'kpi' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="glass-panel p-4 rounded-3xl border border-cyan-500/20">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">{t.kpiClients}</span>
              <p className="text-2xl font-black text-white font-mono">{clients.length}</p>
              <span className="text-[10px] text-emerald-400 font-semibold">+3 عملاء هذا الأسبوع</span>
            </div>

            <div className="glass-panel p-4 rounded-3xl border border-cyan-500/20">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">{t.kpiActiveTrips}</span>
              <p className="text-2xl font-black text-cyan-400 font-mono">18</p>
              <span className="text-[10px] text-slate-400 font-semibold">إسطنبول، دبي، مكة</span>
            </div>

            <div className="glass-panel p-4 rounded-3xl border border-cyan-500/20">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">{t.kpiPendingVisas}</span>
              <p className="text-2xl font-black text-amber-400 font-mono">12</p>
              <span className="text-[10px] text-amber-300 font-semibold">شنغن & تركيا قيد المعالجة</span>
            </div>

            <div className="glass-panel p-4 rounded-3xl border border-cyan-500/20 overflow-hidden">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1 truncate">{t.kpiRevenue}</span>
              <p className="text-lg sm:text-xl font-black text-emerald-400 font-mono truncate">
                {formatPrice(3450000, currency, language)}
              </p>
              <span className="text-[10px] text-emerald-400 font-semibold block truncate">نوفمبر 2026</span>
            </div>
          </div>

          {/* Quick Actions Bar */}
          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={() => {
                setActiveTab('devis');
                setShowAddDevisModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110"
            >
              <Plus className="w-4 h-4" />
              <span>{t.newDevisBtn}</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('clients');
                setShowAddClientModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-cyan-300 font-bold text-xs flex items-center gap-1.5"
            >
              <Users className="w-4 h-4" />
              <span>{t.addNewClientBtn}</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. CLIENT MANAGEMENT */}
      {activeTab === 'clients' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="flex-1 flex items-center gap-2 bg-[#060c20] p-2.5 rounded-2xl border border-slate-800">
              <Search className="w-4 h-4 text-cyan-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={language === 'ar' ? 'بحث بالاسم، رقم الهاتف، أو المدينة...' : 'Search clients...'}
                className="w-full bg-transparent text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>

            <button
              onClick={() => setShowAddClientModal(true)}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shrink-0 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addNewClientBtn}</span>
            </button>
          </div>

          {/* Client Table / Cards */}
          <div className="space-y-2.5">
            {filteredClients.map(client => (
              <div
                key={client.id}
                className="glass-panel p-4 rounded-3xl border border-slate-800 hover:border-cyan-400/30 transition-all text-white flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center text-sm font-mono shrink-0">
                    {client.fullName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold text-white">{client.fullName}</p>
                      {client.vip && (
                        <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.2 rounded-full font-bold">
                          VIP
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {client.phone} · {client.email}
                    </p>
                    <p className="text-[10px] text-cyan-400 font-mono mt-0.5">
                      جواز السفر: {client.passportNumber} · {client.city}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/${client.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30"
                    title="WhatsApp"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                  <button
                    onClick={() => {
                      setNewDevisData({
                        ...newDevisData,
                        clientName: client.fullName,
                        clientPhone: client.phone,
                        clientEmail: client.email,
                      });
                      setActiveTab('devis');
                      setShowAddDevisModal(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-blue-600/30 border border-cyan-400/40 text-cyan-300 text-xs font-semibold hover:bg-blue-600/40"
                  >
                    + Devis
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. DEVIS GENERATOR & VIEWER */}
      {activeTab === 'devis' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white">
              {language === 'ar' ? 'عروض الأسعار المعتمدة (Devis & Quotes):' : 'Tourism By Taki Quotations:'}
            </h2>
            <button
              onClick={() => setShowAddDevisModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs flex items-center gap-1 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{t.newDevisBtn}</span>
            </button>
          </div>

          {/* Devis List selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {devisList.map(dev => (
              <button
                key={dev.id}
                onClick={() => setSelectedDevis(dev)}
                className={`px-3.5 py-2 rounded-2xl text-xs font-mono font-bold whitespace-nowrap transition-all border ${
                  selectedDevis?.id === dev.id
                    ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span>{dev.devisNumber}</span>
                <span className="text-[10px] text-cyan-400 font-sans block">{dev.clientName}</span>
              </button>
            ))}
          </div>

          {/* Official Printable DEVIS Document View */}
          {selectedDevis && (
            <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-400/40 text-white space-y-5">
              {/* Devis Official Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-xl font-black text-white tracking-wider">
                    DEVIS – TOURISME BY TAKI
                  </h3>
                  <p className="text-xs text-cyan-400 font-mono mt-0.5">
                    RÉFÉRENCE OFFICIELLE : {selectedDevis.devisNumber}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Agence Agréée de Tourisme et de Voyages · Alger, Algérie
                  </p>
                </div>

                <div className="text-left rtl:text-right">
                  <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase font-mono ${
                    selectedDevis.status === 'approved' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                  }`}>
                    {selectedDevis.status}
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1">تاريخ الإنشاء: {selectedDevis.createdAt}</p>
                </div>
              </div>

              {/* Client Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-[#060c20] p-4 rounded-2xl border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block mb-0.5">العميل المستفيد:</span>
                  <p className="font-bold text-white text-sm">{selectedDevis.clientName}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{selectedDevis.clientPhone} · {selectedDevis.clientEmail}</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block mb-0.5">الوجهة وبرنامج الرحلة:</span>
                  <p className="font-bold text-cyan-300">{selectedDevis.destination}</p>
                  <p className="text-[11px] text-slate-400">{selectedDevis.travelDates}</p>
                </div>
              </div>

              {/* Items Breakdown Table */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-200">تفاصيل الخدمات والبنود:</p>
                <div className="divide-y divide-slate-800 border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/60">
                  {selectedDevis.items.map(item => (
                    <div key={item.id} className="p-3 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-medium text-white">{item.description}</p>
                        <p className="text-[10px] text-slate-400 capitalize">{item.category} × {item.quantity}</p>
                      </div>
                      <p className="font-mono font-bold text-slate-200">
                        {formatPrice(item.unitPriceDZD * item.quantity, currency, language)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Totals */}
              <div className="bg-[#060c20] p-4 rounded-2xl border border-cyan-500/30 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>المجموع الفرعي (Subtotal):</span>
                  <span className="font-mono">{formatPrice(selectedDevis.subtotalDZD, currency, language)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>أتعاب ورسوم الوكالة:</span>
                  <span className="font-mono">{formatPrice(selectedDevis.agencyFeeDZD, currency, language)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>الضريبة على القيمة المضافة TVA ({selectedDevis.taxRatePercent}%):</span>
                  <span className="font-mono">
                    {formatPrice(Math.round((selectedDevis.subtotalDZD + selectedDevis.agencyFeeDZD) * (selectedDevis.taxRatePercent / 100)), currency, language)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-800 text-sm font-bold text-white">
                  <span>المبلغ الصافي المستحق (TOTAL):</span>
                  <span className="text-base text-cyan-400 font-mono font-black">
                    {formatPrice(selectedDevis.totalDZD, currency, language)}
                  </span>
                </div>
              </div>

              {/* Action Buttons: Print / Share */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="flex-1 h-11 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 transition-colors"
                >
                  <Printer className="w-4 h-4 text-cyan-400" />
                  <span>{language === 'ar' ? 'طباعة / حفظ PDF' : 'Print / Export PDF'}</span>
                </button>
                <a
                  href={`https://wa.me/?text=DEVIS Tourism By Taki ${selectedDevis.devisNumber} Total: ${selectedDevis.totalDZD} DZD`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 h-11 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:brightness-110"
                >
                  <Send className="w-4 h-4" />
                  <span>{language === 'ar' ? 'مشاركة Devis مع العميل' : 'Share with Client'}</span>
                </a>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. DOCUMENTS VAULT */}
      {activeTab === 'docs' && (
        <div className="space-y-4">
          <p className="text-xs text-slate-300">
            {language === 'ar' ? 'إدارة الوثائق والملفات الرسمية المرفوعة للعملاء (GED Tourism By Taki)' : 'Client Travel Documents Vault'}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              { title: 'جوازات السفر الممسوحة ضوئياً', count: '4 ملفات نشطة', icon: <FileText className="w-5 h-5 text-cyan-400" /> },
              { title: 'ملفات وتأشيرات شنغن وتركيا', count: '6 ملفات مصدقة', icon: <Shield className="w-5 h-5 text-emerald-400" /> },
              { title: 'تذاكر الطيران وبطاقات الصعود', count: '8 تذاكر إلكترونية', icon: <CreditCard className="w-5 h-5 text-blue-400" /> },
              { title: 'قسائم الفنادق والتأمين الدولي', count: '5 قسائم نشطة', icon: <FileSpreadsheet className="w-5 h-5 text-amber-400" /> },
            ].map((docGroup, idx) => (
              <div key={idx} className="glass-panel p-4 rounded-3xl border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                    {docGroup.icon}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white">{docGroup.title}</p>
                    <p className="text-[11px] text-cyan-400 font-mono">{docGroup.count}</p>
                  </div>
                </div>
                <button className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 text-xs hover:bg-slate-700">
                  عرض
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. BROADCAST NOTIFICATIONS */}
      {activeTab === 'broadcast' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 text-white space-y-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Send className="w-4 h-4 text-cyan-400" />
              <span>{language === 'ar' ? 'إرسال إشعار فوري للعملاء' : 'Push Notification Broadcaster'}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'ar' ? 'إرسال تنبيهات لحظية تظهر مباشرة في تطبيق TAKI-GO لدى المسافرين' : 'Send instant push alerts to traveler mobile apps'}
            </p>
          </div>

          {broadcastSent && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>{language === 'ar' ? 'تم بث الإشعار بنجاح إلى جميع العملاء المستهدفين!' : 'Notification Broadcasted Successfully!'}</span>
            </div>
          )}

          <form onSubmit={handleSendBroadcastSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                {language === 'ar' ? 'الفئة المستهدفة:' : 'Target Audience:'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'all', label: language === 'ar' ? 'جميع العملاء' : 'All Clients' },
                  { id: 'vip', label: language === 'ar' ? 'عملاء VIP فقط' : 'VIP Only' },
                  { id: 'single', label: language === 'ar' ? 'أحمد بن علي' : 'Ahmed Benali' },
                ].map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setBroadcastTarget(item.id as any)}
                    className={`py-2 px-2.5 rounded-xl text-xs font-medium border text-center transition-colors ${
                      broadcastTarget === item.id
                        ? 'bg-blue-600/30 border-cyan-400 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1">
                {language === 'ar' ? 'عنوان الإشعار:' : 'Notification Title:'}
              </label>
              <input
                type="text"
                required
                value={broadcastTitle}
                onChange={e => setBroadcastTitle(e.target.value)}
                placeholder="مثال: وثيقة رحلتك أصبحت جاهزة للتحميل"
                className="w-full h-11 bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl px-3 text-xs text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1">
                {language === 'ar' ? 'نص الرسالة:' : 'Message Content:'}
              </label>
              <textarea
                required
                rows={3}
                value={broadcastMessage}
                onChange={e => setBroadcastMessage(e.target.value)}
                placeholder="اكتب التنبيه هنا..."
                className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl p-3 text-xs text-white outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>{language === 'ar' ? 'إرسال الإشعار الآن' : 'Broadcast Now'}</span>
            </button>
          </form>
        </div>
      )}

      {/* Add Client Modal */}
      {showAddClientModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-elevated rounded-3xl p-6 max-w-md w-full border border-cyan-400/40 text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">{t.addNewClientBtn}</h3>
              <button
                onClick={() => setShowAddClientModal(false)}
                className="w-8 h-8 rounded-full bg-slate-900 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddClientSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">الاسم الكامل</label>
                <input
                  type="text"
                  required
                  value={newClient.fullName}
                  onChange={e => setNewClient({ ...newClient, fullName: e.target.value })}
                  placeholder="محمد بن عبد الله"
                  className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">رقم الهاتف</label>
                  <input
                    type="tel"
                    required
                    value={newClient.phone}
                    onChange={e => setNewClient({ ...newClient, phone: e.target.value })}
                    placeholder="+213 555..."
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">جواز السفر</label>
                  <input
                    type="text"
                    value={newClient.passportNumber}
                    onChange={e => setNewClient({ ...newClient, passportNumber: e.target.value })}
                    placeholder="23DZ..."
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none uppercase font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={newClient.email}
                  onChange={e => setNewClient({ ...newClient, email: e.target.value })}
                  placeholder="client@gmail.com"
                  className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="vip-check"
                  checked={newClient.vip}
                  onChange={e => setNewClient({ ...newClient, vip: e.target.checked })}
                  className="rounded border-slate-700 bg-slate-900 text-cyan-400"
                />
                <label htmlFor="vip-check" className="text-slate-300 cursor-pointer">
                  تصنيف العميل كعميل VIP مميز
                </label>
              </div>

              <button
                type="submit"
                className="w-full h-11 mt-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold"
              >
                إضافة العميل وتوثيق الملف
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Devis Modal */}
      {showAddDevisModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-elevated rounded-3xl p-6 max-w-lg w-full border border-cyan-400/40 text-white space-y-4 max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">{t.newDevisBtn}</h3>
              <button
                onClick={() => setShowAddDevisModal(false)}
                className="w-8 h-8 rounded-full bg-slate-900 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDevisSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">اسم العميل</label>
                  <input
                    type="text"
                    required
                    value={newDevisData.clientName}
                    onChange={e => setNewDevisData({ ...newDevisData, clientName: e.target.value })}
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">رقم الهاتف</label>
                  <input
                    type="tel"
                    value={newDevisData.clientPhone}
                    onChange={e => setNewDevisData({ ...newDevisData, clientPhone: e.target.value })}
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">الوجهة والبرنامج</label>
                <input
                  type="text"
                  required
                  value={newDevisData.destination}
                  onChange={e => setNewDevisData({ ...newDevisData, destination: e.target.value })}
                  className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">رسوم الوكالة (DZD)</label>
                  <input
                    type="number"
                    value={newDevisData.agencyFeeDZD}
                    onChange={e => setNewDevisData({ ...newDevisData, agencyFeeDZD: Number(e.target.value) })}
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">نسبة الضريبة TVA %</label>
                  <input
                    type="number"
                    value={newDevisData.taxRatePercent}
                    onChange={e => setNewDevisData({ ...newDevisData, taxRatePercent: Number(e.target.value) })}
                    className="w-full h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-white outline-none font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full h-11 mt-3 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold"
              >
                إصدار Devis الرسمي وتحديث العروض
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
