import React, { useState } from 'react';
import { Assignment, Submission, FileItem, Project, UserSession } from '../types';
import { 
  GraduationCap, 
  Plus, 
  Code, 
  ExternalLink, 
  CheckCircle, 
  Copy, 
  Check, 
  Send, 
  Eye, 
  Trash2, 
  FileCode, 
  Image as ImageIcon,
  Sparkles,
  BookOpen,
  ArrowRight
} from 'lucide-react';

interface AssignmentsViewProps {
  session: UserSession | null;
  assignments: Assignment[];
  submissions: Submission[];
  activeProjectFiles: FileItem[];
  teacherProjects: Project[];
  onCreateAssignment: (assignment: Assignment) => void;
  onSubmitAssignment: (submission: Submission) => void;
  onOpenAssignmentInEditor: (assignment: Assignment) => void;
  onDeleteSubmission: (id: string) => void;
  onDeleteAssignment: (id: string) => void;
}

export const AssignmentsView: React.FC<AssignmentsViewProps> = ({
  session,
  assignments,
  submissions,
  activeProjectFiles,
  teacherProjects,
  onCreateAssignment,
  onSubmitAssignment,
  onOpenAssignmentInEditor,
  onDeleteSubmission,
  onDeleteAssignment,
}) => {
  const isTeacher = session?.role === 'teacher';
  const isStudent = session?.role === 'student';

  const [copiedKey, setCopiedKey] = useState(false);
  const [activeTab, setActiveTab] = useState<'assignments' | 'submissions'>('assignments');

  // Create Assignment Modal / Form
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [tech, setTech] = useState<'html' | 'html-css' | 'html-css-js'>('html-css');
  const [selectedTemplateProject, setSelectedTemplateProject] = useState<string>('');
  const [attachmentUrl, setAttachmentUrl] = useState('');

  // Submission Inspection Modal
  const [inspectSubmission, setInspectSubmission] = useState<Submission | null>(null);
  const [inspectMode, setInspectMode] = useState<'preview' | 'code'>('preview');

  // Student submission feedback
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);

  const copyClassKey = () => {
    if (session?.classKey) {
      navigator.clipboard.writeText(session.classKey);
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !desc.trim()) return;

    let initialTemplateFiles: FileItem[] | undefined;
    if (selectedTemplateProject) {
      const proj = teacherProjects.find((p) => p.id === selectedTemplateProject);
      if (proj) initialTemplateFiles = proj.files;
    }

    const newAssignment: Assignment = {
      id: `assign_${Date.now()}`,
      classKey: session?.classKey || 'CLASS-101',
      teacherId: session?.uid || 'teacher_1',
      teacherName: session?.name || 'amaan',
      title: title.trim(),
      description: desc.trim(),
      requiredTech: tech,
      attachments: attachmentUrl.trim()
        ? [
            {
              id: `att_${Date.now()}`,
              title: 'Assignment Spec / Reference',
              type: 'image',
              urlOrContent: attachmentUrl.trim(),
            },
          ]
        : undefined,
      initialTemplateFiles,
      createdAt: new Date().toISOString(),
    };

    onCreateAssignment(newAssignment);
    setShowCreateModal(false);
    setTitle('');
    setDesc('');
    setAttachmentUrl('');
  };

  const handleStudentSubmit = (assignmentId: string) => {
    if (!session) return;

    const submission: Submission = {
      id: `sub_${Date.now()}`,
      assignmentId,
      studentName: session.name,
      classKey: session.classKey || 'CLASS-101',
      files: activeProjectFiles,
      submittedAt: new Date().toISOString(),
      status: 'submitted',
    };

    onSubmitAssignment(submission);
    setSubmitSuccess(assignmentId);
    setTimeout(() => setSubmitSuccess(null), 3000);
  };

  // Filter assignments by class key
  const relevantAssignments = assignments.filter((a) => {
    if (!session?.classKey) return true;
    return a.classKey === session.classKey;
  });

  // Filter submissions by class key
  const relevantSubmissions = submissions.filter((s) => {
    if (!session?.classKey) return true;
    return s.classKey === session.classKey;
  });

  return (
    <div className="h-full w-full overflow-y-auto p-4 sm:p-6 theme-bg-main theme-text-main select-none font-sans">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Top Classroom Banner */}
        <div className="p-4 sm:p-6 rounded-2xl border theme-border theme-bg-surface flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#359efe]/10 border border-[#359efe]/30 flex items-center justify-center text-[#359efe] shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-bold text-slate-100 flex items-center space-x-2">
                <span>Classroom & Assignments</span>
                <span className="text-xs px-2 py-0.5 rounded font-mono font-medium bg-[#359efe]/20 text-[#359efe] border border-[#359efe]/30">
                  {isTeacher ? 'Teacher Mode' : isStudent ? 'Student Mode' : 'Guest Mode'}
                </span>
              </h1>
              <p className="text-xs theme-text-muted mt-0.5">
                {isTeacher
                  ? 'Create class assignments, provide starter templates, and review student code.'
                  : 'Complete classroom tasks, test live code in editor, and submit to your teacher.'}
              </p>
            </div>
          </div>

          {/* Class Key Badge & Actions */}
          <div className="flex items-center space-x-2 shrink-0">
            {session?.classKey && (
              <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border theme-border theme-bg-main font-mono text-xs">
                <span className="theme-text-muted text-[10px]">KEY:</span>
                <span className="font-bold text-[#359efe]">{session.classKey}</span>
                <button
                  onClick={copyClassKey}
                  className="p-1 theme-text-muted hover:theme-text-main cursor-pointer"
                  title="Copy Class Key"
                >
                  {copiedKey ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            )}

            {isTeacher && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white shadow-md cursor-pointer transition-all active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Task</span>
              </button>
            )}
          </div>
        </div>

        {/* Teacher Navigation Tabs */}
        {isTeacher && (
          <div className="flex items-center space-x-2 border-b theme-border pb-2 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('assignments')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'assignments'
                  ? 'bg-[#359efe] text-white'
                  : 'theme-text-muted hover:theme-text-main'
              }`}
            >
              Assignments ({relevantAssignments.length})
            </button>
            <button
              onClick={() => setActiveTab('submissions')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'submissions'
                  ? 'bg-[#359efe] text-white'
                  : 'theme-text-muted hover:theme-text-main'
              }`}
            >
              Student Submissions ({relevantSubmissions.length})
            </button>
          </div>
        )}

        {/* ASSIGNMENTS LIST */}
        {(activeTab === 'assignments' || !isTeacher) && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold uppercase tracking-wider theme-text-muted">
                Active Assignments
              </h2>
              <span className="text-xs theme-text-muted font-mono">
                {relevantAssignments.length} Available
              </span>
            </div>

            {relevantAssignments.length === 0 ? (
              <div className="p-8 text-center rounded-2xl border theme-border theme-bg-surface theme-text-muted text-xs">
                No assignments found for Class Key: {session?.classKey || 'None'}.
              </div>
            ) : (
              relevantAssignments.map((assign) => {
                const userSub = submissions.find(
                  (s) => s.assignmentId === assign.id && s.studentName === session?.name
                );

                return (
                  <div
                    key={assign.id}
                    className="p-5 rounded-2xl border theme-border theme-bg-surface space-y-4 shadow-md transition-all hover:border-[#359efe]/40"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-semibold px-2 py-0.5 rounded font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase">
                            {assign.requiredTech}
                          </span>
                          <span className="text-[11px] theme-text-muted">
                            Teacher: <strong className="text-slate-300">{assign.teacherName}</strong>
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-white mt-1.5">{assign.title}</h3>
                        <p className="text-xs theme-text-muted leading-relaxed mt-1">
                          {assign.description}
                        </p>
                      </div>

                      {isTeacher && (
                        <button
                          onClick={() => onDeleteAssignment(assign.id)}
                          className="p-1.5 theme-text-muted hover:text-red-400 rounded transition-colors self-start cursor-pointer"
                          title="Delete Assignment"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Attachment preview if any */}
                    {assign.attachments && assign.attachments.length > 0 && (
                      <div className="pt-2">
                        <div className="text-[11px] font-semibold theme-text-muted mb-1.5 flex items-center space-x-1">
                          <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Reference Spec / Layout:</span>
                        </div>
                        <div className="max-w-xs rounded-xl overflow-hidden border theme-border bg-black/40">
                          <img
                            src={assign.attachments[0].urlOrContent}
                            alt="Reference"
                            className="w-full h-36 object-cover"
                          />
                        </div>
                      </div>
                    )}

                    {/* Actions Row */}
                    <div className="pt-2 border-t theme-border flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center space-x-2">
                        {/* Open & Code in Editor */}
                        <button
                          onClick={() => onOpenAssignmentInEditor(assign)}
                          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold theme-bg-main hover:theme-bg-surface-hover border theme-border theme-text-main transition-colors cursor-pointer"
                        >
                          <Code className="w-3.5 h-3.5 text-[#359efe]" />
                          <span>Open & Code in Editor</span>
                        </button>

                        {/* Submit to teacher (for students) */}
                        {isStudent && (
                          <button
                            onClick={() => handleStudentSubmit(assign.id)}
                            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all cursor-pointer shadow-xs active:scale-95"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Submit to Teacher</span>
                          </button>
                        )}
                      </div>

                      {/* Status indicator */}
                      {submitSuccess === assign.id && (
                        <span className="text-xs text-emerald-400 font-medium flex items-center space-x-1 animate-pulse">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Submitted! Aapke active editor ke files Sir ke paas chale gaye.</span>
                        </span>
                      )}

                      {userSub && submitSuccess !== assign.id && (
                        <div className="text-[11px] text-slate-300 flex items-center space-x-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          <span>Submitted on {new Date(userSub.submittedAt).toLocaleTimeString()}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* SUBMISSIONS LIST (TEACHER VIEW) */}
        {isTeacher && activeTab === 'submissions' && (
          <div className="space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider theme-text-muted">
              Student Submissions ({relevantSubmissions.length})
            </h2>

            {relevantSubmissions.length === 0 ? (
              <div className="p-8 text-center rounded-2xl border theme-border theme-bg-surface theme-text-muted text-xs">
                No submissions received yet from students.
              </div>
            ) : (
              relevantSubmissions.map((sub) => {
                const assign = assignments.find((a) => a.id === sub.assignmentId);

                return (
                  <div
                    key={sub.id}
                    className="p-4 rounded-xl border theme-border theme-bg-surface flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-sm text-white">{sub.studentName}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400">
                          {sub.classKey}
                        </span>
                      </div>
                      <div className="text-xs theme-text-muted mt-1">
                        Assignment: <strong className="text-slate-200">{assign?.title || 'Unknown'}</strong>
                      </div>
                      <div className="text-[10px] theme-text-muted font-mono mt-0.5">
                        {sub.files.length} files submitted · {new Date(sub.submittedAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 shrink-0">
                      <button
                        onClick={() => {
                          setInspectSubmission(sub);
                          setInspectMode('preview');
                        }}
                        className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white transition-colors cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect & Grade</span>
                      </button>

                      <button
                        onClick={() => onDeleteSubmission(sub.id)}
                        className="p-1.5 theme-text-muted hover:text-red-400 rounded transition-colors cursor-pointer"
                        title="Delete Submission"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>

      {/* CREATE ASSIGNMENT MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#1a1b24] border border-[#2e3142] rounded-2xl shadow-2xl w-full max-w-md p-6 text-slate-200">
            <h3 className="text-base font-bold text-white mb-4 flex items-center space-x-2">
              <Plus className="w-4 h-4 text-[#359efe]" />
              <span>Create New Assignment Task</span>
            </h3>

            <form onSubmit={handleCreateAssignment} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Assignment Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Build a Responsive Calculator or Portfolio"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-700 bg-[#121318] text-white focus:outline-none focus:border-[#359efe]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Task Description & Requirements
                </label>
                <textarea
                  required
                  rows={3}
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Provide instructions on what HTML elements, CSS styles, or JS interactions to build..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-700 bg-[#121318] text-white focus:outline-none focus:border-[#359efe]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Required Tech
                  </label>
                  <select
                    value={tech}
                    onChange={(e: any) => setTech(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-slate-700 bg-[#121318] text-white focus:outline-none focus:border-[#359efe]"
                  >
                    <option value="html">HTML Only</option>
                    <option value="html-css">HTML & CSS</option>
                    <option value="html-css-js">HTML, CSS & JS</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Starter Project
                  </label>
                  <select
                    value={selectedTemplateProject}
                    onChange={(e) => setSelectedTemplateProject(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-slate-700 bg-[#121318] text-white focus:outline-none focus:border-[#359efe]"
                  >
                    <option value="">Default Starter</option>
                    {teacherProjects.map((tp) => (
                      <option key={tp.id} value={tp.id}>
                        {tp.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Reference Layout / Spec Image URL (optional)
                </label>
                <input
                  type="url"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-700 bg-[#121318] text-white focus:outline-none focus:border-[#359efe]"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#359efe] hover:bg-[#2563eb] text-white cursor-pointer"
                >
                  Publish Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* INSPECT SUBMISSION MODAL */}
      {inspectSubmission && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#181920] border border-[#2f3244] rounded-2xl shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden text-slate-200">
            {/* Modal Header */}
            <div className="h-12 px-4 border-b border-[#2f3244] flex items-center justify-between shrink-0 bg-[#13141a]">
              <div className="flex items-center space-x-3">
                <span className="font-bold text-sm text-white">
                  Submission from {inspectSubmission.studentName}
                </span>
                <div className="flex items-center space-x-1 bg-[#1c1d26] p-0.5 rounded-lg border border-slate-700">
                  <button
                    onClick={() => setInspectMode('preview')}
                    className={`px-3 py-1 rounded text-xs font-bold cursor-pointer transition-colors ${
                      inspectMode === 'preview' ? 'bg-[#359efe] text-white' : 'text-slate-400'
                    }`}
                  >
                    Live Preview
                  </button>
                  <button
                    onClick={() => setInspectMode('code')}
                    className={`px-3 py-1 rounded text-xs font-bold cursor-pointer transition-colors ${
                      inspectMode === 'code' ? 'bg-[#359efe] text-white' : 'text-slate-400'
                    }`}
                  >
                    Code Files
                  </button>
                </div>
              </div>

              <button
                onClick={() => setInspectSubmission(null)}
                className="px-3 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white cursor-pointer"
              >
                Close
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-grow w-full h-[calc(100%-3rem)] overflow-hidden">
              {inspectMode === 'preview' ? (
                <div className="w-full h-full p-3 bg-[#0d0e12]">
                  <iframe
                    srcDoc={
                      inspectSubmission.files.find((f) => f.name.endsWith('.html'))?.content ||
                      '<p>No HTML</p>'
                    }
                    title="Student Preview"
                    sandbox="allow-scripts"
                    className="w-full h-full bg-white rounded-xl shadow-lg border-none"
                  />
                </div>
              ) : (
                <div className="w-full h-full overflow-y-auto p-4 space-y-4">
                  {inspectSubmission.files.map((file) => (
                    <div
                      key={file.id}
                      className="rounded-xl border border-slate-700 overflow-hidden bg-[#121318]"
                    >
                      <div className="h-8 px-3 bg-[#1c1d26] border-b border-slate-700 flex items-center justify-between text-xs font-mono">
                        <span className="text-cyan-400 font-bold">{file.name}</span>
                        <span className="text-[10px] text-slate-500 uppercase">{file.language}</span>
                      </div>
                      <pre className="p-3 text-xs font-mono text-slate-300 overflow-x-auto whitespace-pre">
                        {file.content}
                      </pre>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
