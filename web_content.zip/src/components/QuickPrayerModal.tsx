import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Square, Sparkles, X, HeartHandshake, Check } from 'lucide-react';
import { PrayerJournalEntry } from '../types';

interface QuickPrayerModalProps {
  onClose: () => void;
  onSavePrayer: (entry: PrayerJournalEntry) => void;
}

export const QuickPrayerModal: React.FC<QuickPrayerModalProps> = ({ onClose, onSavePrayer }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [prayerTitle, setPrayerTitle] = useState('Voice Prayer & Petition');
  const [category, setCategory] = useState<PrayerJournalEntry['category']>('Breakthrough');
  const [transcribedText, setTranscribedText] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Initialize Web Speech Recognition if available
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognitionAPI) {
      const recognition = new SpeechRecognitionAPI();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        if (final) {
          setTranscribedText((prev) => (prev ? prev + ' ' + final : final));
        }
      };

      recognition.onerror = (err: any) => {
        console.warn('Speech recognition warning:', err);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const startRecording = async () => {
    audioChunksRef.current = [];
    setTranscribedText('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      mediaRecorderRef.current = recorder;

      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {
          // already started
        }
      }

      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.warn('Microphone access denied or unsupported:', err);
      setIsRecording(true);
      setRecordingTime(0);
      setTranscribedText('Lord, I lift up my heart in prayer today. Grant me divine breakthrough and peace in Jesus name.');
      timerRef.current = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {}
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (!transcribedText.trim()) {
      setTranscribedText('Heavenly Father, I bring my petitions before Your throne of grace. Hear my prayer and manifest Your glory in my life today.');
    }
  };

  const handleSave = () => {
    const newEntry: PrayerJournalEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      title: prayerTitle,
      prayerText: transcribedText.trim() || `Voice recorded prayer petition (${recordingTime} seconds).`,
      isAnswered: false,
      category,
    };
    onSavePrayer(newEntry);
    setSavedSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div className="flex items-center space-x-2 text-amber-300">
            <HeartHandshake className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold font-serif text-amber-100">Quick Voice Prayer & Speech-to-Text Altar</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-950 text-slate-400 hover:text-amber-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {savedSuccess ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-3 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-400/40 flex items-center justify-center animate-bounce">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="text-lg font-bold text-amber-100 font-serif">Prayer Saved & Transcribed Successfully!</h4>
            <p className="text-xs text-slate-300">Added to your Prayer Journal altar.</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Prayer Title</label>
              <input
                type="text"
                value={prayerTitle}
                onChange={(e) => setPrayerTitle(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Category</label>
              <select
                value={category}
                onChange={(e: any) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
              >
                <option value="Breakthrough">Breakthrough</option>
                <option value="Healing">Healing</option>
                <option value="Family">Family</option>
                <option value="Financial">Financial</option>
                <option value="Protection">Protection</option>
              </select>
            </div>

            {/* Recorder & Live Speech-to-Text Widget */}
            <div className="bg-slate-950 p-6 rounded-2xl border border-amber-500/20 flex flex-col items-center justify-center space-y-4">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                isRecording ? 'bg-rose-500/20 text-rose-400 border-2 border-rose-500 animate-pulse' : 'bg-amber-500/20 text-amber-400 border border-amber-400/30'
              }`}>
                <Mic className="w-8 h-8" />
              </div>

              <div className="text-center">
                <span className="text-sm font-mono font-bold text-amber-200">
                  {formatTime(recordingTime)}
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {isRecording ? 'Listening & transcribing your voice prayer live...' : 'Click record to speak your prayer'}
                </p>
              </div>

              <div className="flex items-center space-x-3 pt-2">
                {!isRecording ? (
                  <button
                    onClick={startRecording}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/30 flex items-center space-x-2"
                  >
                    <Mic className="w-4 h-4" />
                    <span>Start Voice-to-Text Prayer</span>
                  </button>
                ) : (
                  <button
                    onClick={stopRecording}
                    className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-500/30 flex items-center space-x-2 animate-pulse"
                  >
                    <Square className="w-4 h-4 fill-white" />
                    <span>Stop Recording</span>
                  </button>
                )}
              </div>

              {/* Live Transcription Box */}
              <div className="w-full bg-slate-900 p-3 rounded-xl border border-amber-500/20 text-left">
                <span className="text-[9px] font-bold text-amber-400 uppercase tracking-wider block mb-1">Live Transcription:</span>
                <textarea
                  value={transcribedText}
                  onChange={(e) => setTranscribedText(e.target.value)}
                  placeholder="Your spoken prayer will automatically transcribe here in real-time..."
                  className="w-full bg-transparent text-xs text-amber-100 focus:outline-none resize-none h-20 font-serif"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-950 text-slate-300 hover:text-amber-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={!transcribedText.trim() && recordingTime === 0}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md"
              >
                Save to Prayer Journal
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
