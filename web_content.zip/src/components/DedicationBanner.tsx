import React from 'react';
import { useApp } from '../context/AppContext';
import { AppLogo } from './AppLogo';

export const DedicationBanner: React.FC = () => {
  const { setShowAboutModal } = useApp();

  return (
    <button
      onClick={() => setShowAboutModal(true)}
      className="w-full text-right relative overflow-hidden bg-[#f4f9f6]/90 dark:bg-[#031d15]/80 hover:bg-[#ebf5ef] dark:hover:bg-[#04261c] border border-emerald-600/20 dark:border-emerald-700/40 rounded-xl py-1.5 px-3 flex items-center justify-between gap-2.5 transition-all cursor-pointer group shadow-2xs select-none"
      aria-label="عن التطبيق والصدقة الجارية"
    >
      <div className="flex items-center gap-2 min-w-0">
        <AppLogo size={20} withGlow={false} className="shrink-0 opacity-85" />
        <p className="text-xs font-medium text-[#1a4734] dark:text-[#a7d7c0] font-cairo truncate">
          <span>صدقة جارية عن الحاجة هدى</span>
          <span className="text-[10px] font-normal text-[#5c8a74] dark:text-[#729e8a] mr-1.5 font-tajawal">
            · نسأل الله القبول
          </span>
        </p>
      </div>

      <div className="flex items-center gap-1 text-[10px] font-medium text-emerald-700/80 dark:text-emerald-400/80 group-hover:text-emerald-600 dark:group-hover:text-emerald-300 transition-colors shrink-0 font-tajawal">
        <span>عن العمل</span>
        <span className="text-[9px]">←</span>
      </div>
    </button>
  );
};
