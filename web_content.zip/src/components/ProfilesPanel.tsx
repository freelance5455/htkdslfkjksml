import { useState } from "react";
import { useApp } from "@/lib/store";
import { Btn, Card } from "./UI";

export default function ProfilesPanel() {
  const {
    profiles,
    saveProfile,
    applyProfile,
    deleteProfile,
    updateProfile,
    settings,
    exportData,
    importData,
  } = useApp();

  const [name, setName] = useState("");
  const [raw, setRaw] = useState("");
  const [msg, setMsg] = useState("");

  const copy = async () => {
    const data = exportData();
    try {
      await navigator.clipboard.writeText(data);
      setMsg("Configuração copiada para a área de transferência.");
    } catch {
      setRaw(data);
      setMsg("Copie o texto abaixo manualmente.");
    }
  };

  const download = () => {
    const blob = new Blob([exportData()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "gg-touch-freefire.json";
    a.click();
    URL.revokeObjectURL(url);
    setMsg("Arquivo JSON gerado.");
  };

  const doImport = () => {
    const ok = importData(raw);
    setMsg(ok ? "Configuração importada com sucesso!" : "JSON inválido — confira o conteúdo.");
  };

  return (
    <div className="space-y-4">
      <Card
        title="Meus perfis"
        icon="🗂️"
        desc="Cada perfil guarda uma combinação de sensibilidade, touch e layout de botões."
      >
        <div className="mb-3 flex gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nome do perfil (ex: Mira Sniper)"
            className="flex-1 rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-slate-100 outline-none placeholder:text-slate-600 focus:border-lime-400/60"
          />
          <Btn
            variant="primary"
            onClick={() => {
              saveProfile(name);
              setName("");
              setMsg("Perfil salvo com as configurações atuais.");
            }}
          >
            Salvar
          </Btn>
        </div>

        <div className="space-y-2">
          {profiles.map((p) => (
            <div
              key={p.id}
              className="flex items-center justify-between gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2.5"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="truncate text-[13px] font-semibold text-slate-100">{p.name}</span>
                  {p.builtin && (
                    <span className="rounded-full bg-cyan-400/15 px-2 py-0.5 text-[10px] font-bold text-cyan-300">
                      PADRÃO
                    </span>
                  )}
                </div>
                <div className="mt-0.5 font-mono text-[10px] text-slate-500">
                  H {p.settings.sensHorizontal}% · V {p.settings.sensVertical}% · suav {p.settings.smoothing} ·
                  curva {p.settings.curve.toFixed(2)}
                </div>
              </div>
              <div className="flex shrink-0 gap-1.5">
                <Btn onClick={() => applyProfile(p.id)}>Aplicar</Btn>
                {!p.builtin && (
                  <>
                    <Btn
                      onClick={() => {
                        updateProfile(p.id, settings);
                        setMsg(`Perfil “${p.name}” atualizado.`);
                      }}
                    >
                      Salvar atual
                    </Btn>
                    <Btn variant="danger" onClick={() => deleteProfile(p.id)}>
                      ✕
                    </Btn>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Backup e compartilhamento" icon="💾" desc="Exporte seus ajustes para outro celular.">
        <div className="flex flex-wrap gap-2">
          <Btn variant="primary" onClick={copy}>
            Copiar JSON
          </Btn>
          <Btn onClick={download}>Baixar arquivo</Btn>
          <Btn onClick={() => setRaw(exportData())}>Ver JSON</Btn>
        </div>
        <textarea
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          placeholder="Cole aqui o JSON de configuração para importar..."
          className="mt-3 h-28 w-full resize-none rounded-2xl border border-white/10 bg-black/40 p-3 font-mono text-[11px] text-slate-200 outline-none focus:border-lime-400/60"
        />
        <div className="mt-2 flex items-center gap-2">
          <Btn onClick={doImport}>Importar</Btn>
          {msg && <span className="text-[11px] text-lime-300">{msg}</span>}
        </div>
      </Card>
    </div>
  );
}
