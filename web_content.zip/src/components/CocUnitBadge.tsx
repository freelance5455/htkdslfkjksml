import React from 'react';
import {
  Castle,
  Crown,
  Flame,
  Hammer,
  PawPrint,
  Shield,
  Sparkles,
  Sword,
  Wand2,
  Wrench,
} from 'lucide-react';
import {
  DATA_SOURCE_LABELS_RU,
  DataSourceType,
  UpgradeDetailType,
  UpgradeEvent,
  VillageId,
} from '../shared/cocData';

export type UpgradePeriodId = 'today' | 'yesterday' | '7d' | '30d' | 'all';

export const UPGRADE_PERIOD_OPTIONS: Array<{ id: UpgradePeriodId; label: string }> = [
  { id: 'today', label: 'Сегодня' },
  { id: 'yesterday', label: 'Вчера' },
  { id: '7d', label: 'Последние 7 дней' },
  { id: '30d', label: 'Последние 30 дней' },
  { id: 'all', label: 'За всё время' },
];

export const REAL_UPGRADE_TYPES = new Set<UpgradeDetailType>([
  'townhall',
  'hero',
  'equipment',
  'troop',
  'spell',
  'siege',
  'pet',
  'building',
]);

export function resolveUpgradeDetailType(ev: UpgradeEvent): UpgradeDetailType {
  if (ev.detailType) return ev.detailType;
  if (ev.category === 'townhall') return 'townhall';
  if (ev.category === 'heroes') return 'hero';
  if (ev.category === 'lab') return 'troop';
  return 'building';
}

export function isActualUpgradeEvent(ev: UpgradeEvent): boolean {
  if (ev.village === 'clanCapital' && (ev.itemId === 'capital_hall' || ev.itemId.startsWith('capital_district:'))) {
    return true;
  }
  return REAL_UPGRADE_TYPES.has(resolveUpgradeDetailType(ev));
}

export function resolveUpgradeVillage(ev: Pick<UpgradeEvent, 'village'>): VillageId {
  if (ev.village === 'builderBase') return 'builderBase';
  if (ev.village === 'clanCapital') return 'clanCapital';
  return 'home';
}

export function getVillageShortTitle(village: VillageId): string {
  if (village === 'builderBase') return 'BUILDER BASE';
  if (village === 'clanCapital') return 'CLAN CAPITAL';
  return 'HOME VILLAGE';
}

export function getVillageRuTitle(village: VillageId): string {
  if (village === 'builderBase') return 'Деревня строителя';
  if (village === 'clanCapital') return 'Столица клана';
  return 'Родная деревня';
}

export function getDataSourceLabel(source?: DataSourceType): string {
  if (!source) return 'Supercell API';
  return DATA_SOURCE_LABELS_RU[source] ?? source;
}

export function formatCountdownRu(
  estimatedFinishesAt: string | undefined,
  nowMs: number
): { label: string; expired: boolean } | null {
  if (!estimatedFinishesAt) return null;
  const targetMs = new Date(estimatedFinishesAt).getTime();
  if (Number.isNaN(targetMs)) return null;
  const diffSec = Math.floor((targetMs - nowMs) / 1000);
  if (diffSec <= 0) {
    return { label: 'Таймер по экспорту истёк (требуется проверка)', expired: true };
  }
  const days = Math.floor(diffSec / 86400);
  const hours = Math.floor((diffSec % 86400) / 3600);
  const mins = Math.floor((diffSec % 3600) / 60);
  const secs = diffSec % 60;
  if (days > 0) return { label: `Осталось: ${days} д ${hours} ч ${mins} м`, expired: false };
  if (hours > 0) return { label: `Осталось: ${hours} ч ${mins} м`, expired: false };
  return { label: `Осталось: ${mins} м ${secs} с`, expired: false };
}

export function matchesUpgradePeriod(
  isoTimestamp: string,
  period: UpgradePeriodId,
  nowMs: number
): boolean {
  if (period === 'all') return true;
  const ts = new Date(isoTimestamp).getTime();
  if (Number.isNaN(ts)) return false;

  const now = new Date(nowMs);
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;

  if (period === 'today') return ts >= startOfToday;
  if (period === 'yesterday') return ts >= startOfYesterday && ts < startOfToday;
  if (period === '7d') return ts >= nowMs - 7 * 24 * 60 * 60 * 1000;
  if (period === '30d') return ts >= nowMs - 30 * 24 * 60 * 60 * 1000;
  return true;
}

export function getUpgradeCategoryShortLabel(type: UpgradeDetailType): string {
  switch (type) {
    case 'hero':
      return 'Герой';
    case 'equipment':
      return 'Оборудование';
    case 'troop':
      return 'Войско';
    case 'spell':
      return 'Заклинание';
    case 'siege':
      return 'Осадная машина';
    case 'pet':
      return 'Питомец';
    case 'townhall':
      return 'Ратуша / Дом';
    case 'building':
      return 'Здание / Защита';
    case 'capital':
      return 'Столица клана';
    default:
      return 'Улучшение';
  }
}

export const CocUnitBadge: React.FC<{
  detailType: UpgradeDetailType;
  apiName?: string;
  isSuperTroop?: boolean;
  size?: 'sm' | 'md' | 'lg';
}> = ({ detailType, apiName = '', isSuperTroop = false, size = 'md' }) => {
  const lower = apiName.toLowerCase();
  const boxCls =
    size === 'lg'
      ? 'h-12 w-12 rounded-lg'
      : size === 'sm'
      ? 'h-8 w-8 rounded-md'
      : 'h-10 w-10 rounded-lg';
  const iconCls = size === 'lg' ? 'h-6 w-6' : size === 'sm' ? 'h-4 w-4' : 'h-5 w-5';

  if (detailType === 'townhall') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-amber-500/40 bg-amber-500/15 text-amber-400 shrink-0`}
        title="Ратуша"
      >
        <Castle className={iconCls} />
      </div>
    );
  }

  if (detailType === 'hero') {
    const colorCls = lower.includes('queen')
      ? 'border-fuchsia-500/40 bg-fuchsia-500/15 text-fuchsia-300'
      : lower.includes('warden')
      ? 'border-sky-500/40 bg-sky-500/15 text-sky-300'
      : lower.includes('champion')
      ? 'border-cyan-500/40 bg-cyan-500/15 text-cyan-300'
      : lower.includes('minion')
      ? 'border-violet-500/40 bg-violet-500/15 text-violet-300'
      : lower.includes('battle')
      ? 'border-slate-400/40 bg-slate-500/15 text-slate-200'
      : 'border-amber-500/40 bg-amber-500/15 text-amber-300';

    return (
      <div className={`${boxCls} flex items-center justify-center border ${colorCls} shrink-0`} title="Герой">
        <Crown className={iconCls} />
      </div>
    );
  }

  if (detailType === 'equipment') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-orange-500/40 bg-orange-500/15 text-orange-300 shrink-0`}
        title="Оборудование героя"
      >
        <Shield className={iconCls} />
      </div>
    );
  }

  if (detailType === 'spell') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-violet-500/40 bg-violet-500/15 text-violet-300 shrink-0`}
        title="Заклинание"
      >
        <Wand2 className={iconCls} />
      </div>
    );
  }

  if (detailType === 'pet') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-emerald-500/40 bg-emerald-500/15 text-emerald-300 shrink-0`}
        title="Питомец"
      >
        <PawPrint className={iconCls} />
      </div>
    );
  }

  if (detailType === 'siege') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-rose-500/40 bg-rose-500/15 text-rose-300 shrink-0`}
        title="Осадная машина"
      >
        <Hammer className={iconCls} />
      </div>
    );
  }

  if (detailType === 'building') {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-slate-600/50 bg-slate-700/25 text-slate-300 shrink-0`}
        title="Постройка"
      >
        <Wrench className={iconCls} />
      </div>
    );
  }

  if (isSuperTroop) {
    return (
      <div
        className={`${boxCls} flex items-center justify-center border border-amber-500/40 bg-amber-500/15 text-amber-300 shrink-0`}
        title="Супервойско"
      >
        <Flame className={iconCls} />
      </div>
    );
  }

  return (
    <div
      className={`${boxCls} flex items-center justify-center border border-sky-500/40 bg-sky-500/15 text-sky-300 shrink-0`}
      title="Войско"
    >
      {lower.includes('dragon') || lower.includes('pekka') ? (
        <Sparkles className={iconCls} />
      ) : (
        <Sword className={iconCls} />
      )}
    </div>
  );
};
