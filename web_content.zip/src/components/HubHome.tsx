import React, { useState } from 'react';
import { ChevronRight, Shield, Settings, Trophy, Users, Sparkles } from 'lucide-react';
import { TRANSLATIONS } from '../i18n/translations';
import { Club, Language } from '../types/game';
import { ClubCrest } from './ClubCrest';

export type ScreenTab = 'home' | 'kickoff' | 'career' | 'ultimate' | 'editor';

interface HubHomeProps {
  clubs: Club[];
  favoriteClub: Club;
  language: Language;
  coins: number;
  onSelectFavorite: (clubId: string) => void;
  onNavigate: (tab: ScreenTab) => void;
  onOpenSettings: () => void;
}

export const HubHome: React.FC<HubHomeProps> = ({
  clubs,
  favoriteClub,
  language,
  coins,
  onSelectFavorite,
  onNavigate,
  onOpenSettings,
}) => {
  const t = TRANSLATIONS[language];
  const [pickingFav, setPickingFav] = useState(false);

  return (
    <div className="relative z-10 h-full overflow-y-auto flex flex-col justify-between px-4 sm:px-8 py-6 max-w-6xl mx-auto">
      {/* Main Hero & Mode Grid */}
      <div className="my-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left: Hero Lockup + Favorite Club Spotlight */}
        <div className="lg:col-span-6 bg-white/92 dark:bg-[#0B1120]/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl">
          <div className="text-xs font-semibold tracking-wider uppercase text-amber-600 dark:text-amber-400">
            {t.heroKicker}
          </div>

          <h1 className="mt-2 font-display font-extrabold text-4xl sm:text-5xl leading-[1.02] tracking-tight text-slate-900 dark:text-white text-balance">
            {t.heroHeadline}
          </h1>

          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
            {t.heroSub}
          </p>

          {/* Favorite Club Card */}
          <div className="mt-6 flex items-center justify-between gap-4 p-4 rounded-xl bg-slate-100/90 dark:bg-[#111A2E] border border-slate-200 dark:border-slate-700/70">
            <div className="flex items-center gap-4 min-w-0">
              <ClubCrest club={favoriteClub} size={52} />
              <div className="min-w-0">
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {t.favoriteClub} · {favoriteClub.stadium}
                </div>
                <div className="font-display font-bold text-2xl text-slate-900 dark:text-white truncate">
                  {favoriteClub.name}
                </div>
                <div className="font-mono-num text-xs font-semibold text-amber-600 dark:text-amber-400 mt-0.5">
                  OVR {favoriteClub.ovr} · ATT {favoriteClub.att} · MID {favoriteClub.mid} · DEF {favoriteClub.def}
                </div>
              </div>
            </div>
            <button
              onClick={() => setPickingFav(!pickingFav)}
              className="shrink-0 px-3 py-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-600 transition-colors"
            >
              {t.changeFavorite}
            </button>
          </div>

          {pickingFav && (
            <div className="mt-3 grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-40 overflow-y-auto p-2 bg-slate-100 dark:bg-slate-900/90 rounded-xl border border-slate-200 dark:border-slate-800">
              {clubs.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    onSelectFavorite(c.id);
                    setPickingFav(false);
                  }}
                  className={`flex items-center gap-2 p-2 rounded-lg text-left text-xs font-semibold transition-colors ${
                    c.id === favoriteClub.id
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-700'
                  }`}
                >
                  <ClubCrest club={c} size={22} />
                  <span className="truncate">{c.abbr}</span>
                </button>
              ))}
            </div>
          )}

          {/* Primary CTA */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('kickoff')}
              className="flex-1 min-w-[200px] py-3.5 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-xl tracking-wide uppercase flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.98]"
            >
              <span>{t.playQuickMatch}</span>
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenSettings}
              className="py-3.5 px-4 rounded-xl bg-slate-200/80 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-semibold text-sm flex items-center gap-2 border border-slate-300 dark:border-slate-700 transition-colors"
            >
              <Settings className="w-4 h-4 text-amber-500 dark:text-amber-400" />
              <span>{t.navSettings}</span>
            </button>
          </div>
        </div>

        {/* Right: 4 Mode Shortcuts */}
        <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => onNavigate('kickoff')}
            className="group text-left bg-white/92 dark:bg-[#0B1120]/88 hover:border-amber-400/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl transition-all hover:-translate-y-0.5"
          >
            <div className="w-10 h-10 rounded-lg bg-amber-400/15 flex items-center justify-center text-amber-500 dark:text-amber-400 mb-3">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-slate-900 dark:text-white group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
              {t.navKickOff}
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
              {clubs.length} {t.allLeagues} · {t.weatherDay} / {t.weatherNight} / {t.weatherRain}
            </p>
          </button>

          <button
            onClick={() => onNavigate('career')}
            className="group text-left bg-white/92 dark:bg-[#0B1120]/88 hover:border-amber-400/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl transition-all hover:-translate-y-0.5"
          >
            <div className="w-10 h-10 rounded-lg bg-sky-500/15 flex items-center justify-center text-sky-600 dark:text-sky-400 mb-3">
              <Trophy className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-slate-900 dark:text-white group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
              {t.openCareer}
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
              {t.standings} · {t.fixtures} · {t.training}
            </p>
          </button>

          <button
            onClick={() => onNavigate('ultimate')}
            className="group text-left bg-white/92 dark:bg-[#0B1120]/88 hover:border-amber-400/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl transition-all hover:-translate-y-0.5"
          >
            <div className="w-10 h-10 rounded-lg bg-indigo-500/15 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-3">
              <Users className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-slate-900 dark:text-white group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
              {t.openUltimate}
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 font-mono-num">
              {coins.toLocaleString()} {t.coins} · {t.futPacks}
            </p>
          </button>

          <button
            onClick={() => onNavigate('editor')}
            className="group text-left bg-white/92 dark:bg-[#0B1120]/88 hover:border-amber-400/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl transition-all hover:-translate-y-0.5"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-3">
              <Shield className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-slate-900 dark:text-white group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
              {t.openEditor}
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
              {t.brasileirao} · {t.europe} · {t.squadEditor}
            </p>
          </button>
        </div>
      </div>

      {/* Bottom Controls Hint Strip */}
      <div className="mt-4 text-center">
        <span className="inline-block px-4 py-1.5 rounded-lg bg-white/85 dark:bg-[#0B1120]/85 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
          {t.controlsDesktop}
        </span>
      </div>
    </div>
  );
};
