import React, { useEffect, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Flashlight,
  Pause,
  Smartphone,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { BodycamSettings, GameHudState, LightingMood, OpticalMode } from '../game/types';

interface BodycamOverlayProps {
  hud: GameHudState;
  settings: BodycamSettings;
  mobileControlsEnabled: boolean;
  onToggleMobileControls: () => void;
  onUpdateSettings: (next: Partial<BodycamSettings>) => void;
  onPause: () => void;
  onLockPointer: () => void;
}

function formatClock(elapsedSec: number): string {
  const base = new Date(2026, 10, 23, 18, 43, 55 + Math.floor(elapsedSec));
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${base.getFullYear()}-${pad(base.getMonth() + 1)}-${pad(base.getDate())} ${pad(base.getHours())}:${pad(base.getMinutes())}:${pad(base.getSeconds())} -0800`;
}

export const BodycamOverlay: React.FC<BodycamOverlayProps> = ({
  hud,
  settings,
  mobileControlsEnabled,
  onToggleMobileControls,
  onUpdateSettings,
  onPause,
  onLockPointer,
}) => {
  const [dockCollapsed, setDockCollapsed] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth < 768 : false,
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'KeyH') {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const isPlaying = hud.phase === 'playing';
  const opticalOptions: { id: OpticalMode; label: string }[] = [
    { id: 'standard', label: 'Standard' },
    { id: 'lowlight', label: 'Low-Light' },
    { id: 'ir_night', label: 'IR Night' },
  ];

  const moodOptions: { id: LightingMood; label: string }[] = [
    { id: 'flare_night', label: 'Night Flare' },
    { id: 'dawn_mist', label: 'Dawn Mist' },
    { id: 'blackout', label: 'Blackout' },
  ];

  return (
    <div className="pointer-events-none fixed inset-0 z-10 flex flex-col justify-between p-3 sm:p-6">
      {/* Subtle Bodycam Corner Brackets */}
      <div className="pointer-events-none fixed inset-3 sm:inset-6">
        <div className="absolute top-0 left-0 h-4 w-4 sm:h-5 sm:w-5 border-t border-l border-zinc-200/35" />
        <div className="absolute top-0 right-0 h-4 w-4 sm:h-5 sm:w-5 border-t border-r border-zinc-200/35" />
        <div className="absolute bottom-0 left-0 h-4 w-4 sm:h-5 sm:w-5 border-b border-l border-zinc-200/35" />
        <div className="absolute bottom-0 right-0 h-4 w-4 sm:h-5 sm:w-5 border-b border-r border-zinc-200/35" />
      </div>

      {/* Top OSD Bar (Static clean typography, zero pills, zero pulsing dots) */}
      <div className="flex items-start justify-between gap-4 px-1 pt-1">
        <div className="font-mono-tech text-[10px] sm:text-xs leading-relaxed tracking-wider text-zinc-100/90 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
          <div className="flex items-center gap-2 font-semibold text-zinc-50">
            <span className="inline-block h-2 w-2 bg-red-600" aria-hidden="true" />
            <span>REC · AXON-TAC CAM-04</span>
          </div>
          <div className="hidden sm:block text-zinc-300/85">{formatClock(hud.elapsedSeconds)}</div>
          <div className="text-zinc-400">
            {hud.currentZone} · {hud.flashlightOn ? `LUMEN ${hud.flashlightBattery}%` : 'LIGHT OFF'}
          </div>
        </div>

        {/* Top-Right Mission & Vitals Telemetry (unboxed tabular monospace) */}
        <div className="font-mono-tech flex items-start gap-2.5 text-right text-[10px] sm:text-xs leading-relaxed tracking-wider text-zinc-100/90 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
          <div>
            <div className="font-semibold text-amber-400">
              {hud.extractionReady
                ? 'Extract North Pillbox'
                : `Field Radios ${hud.drivesCollected} / ${hud.totalDrives}`}
            </div>
            <div className="text-zinc-300/90">
              Hostiles {hud.hostilesNeutralized} / {hud.totalHostiles} · Armor {hud.health}%
            </div>
            <div className="text-zinc-300/90">
              {hud.isReloading
                ? 'Reloading...'
                : `9x19mm ${hud.ammo} / ${hud.reserveAmmo}`}
            </div>
          </div>

          {isPlaying && (
            <button
              type="button"
              onClick={onPause}
              aria-label="Pause Deployment"
              className="pointer-events-auto flex h-9 w-9 sm:hidden items-center justify-center rounded border border-zinc-700/80 bg-zinc-950/85 text-zinc-200"
            >
              <Pause className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Center Reticle, Hit Marker & Interaction Prompt (only while playing) */}
      {isPlaying && (
        <div className="pointer-events-none fixed inset-0 flex items-center justify-center">
          {/* Minimalist tactical center dot (hidden during ADS so red-dot optic takes over) */}
          {!hud.isAiming && (
            <div className="h-1.5 w-1.5 rounded-full bg-zinc-100/65 shadow-[0_0_4px_rgba(0,0,0,0.9)]" />
          )}

          {/* Crisp Hit Marker */}
          {hud.hitMarkerTimer > 0 && (
            <div className="relative h-6 w-6">
              <span className="absolute top-0 left-1/2 h-2 w-0.5 -translate-x-1/2 rotate-45 bg-amber-400" />
              <span className="absolute bottom-0 left-1/2 h-2 w-0.5 -translate-x-1/2 rotate-45 bg-amber-400" />
              <span className="absolute top-1/2 left-0 h-0.5 w-2 -translate-y-1/2 rotate-45 bg-amber-400" />
              <span className="absolute top-1/2 right-0 h-0.5 w-2 -translate-y-1/2 rotate-45 bg-amber-400" />
            </div>
          )}

          {/* Transient Status Banner */}
          {hud.statusBanner && (
            <div className="font-mono-tech absolute top-24 max-w-[90vw] truncate border border-zinc-700/70 bg-zinc-950/85 px-4 py-1.5 text-[11px] sm:text-xs font-medium tracking-wider text-amber-300">
              {hud.statusBanner}
            </div>
          )}

          {/* Contextual Interact Prompt (desktop view) */}
          {hud.nearbyPrompt && !mobileControlsEnabled && (
            <div className="font-mono-tech absolute bottom-32 border border-cyan-500/50 bg-zinc-950/90 px-4 py-2 text-xs font-medium tracking-wide text-cyan-300">
              {hud.nearbyPrompt}
            </div>
          )}

          {/* Subtle Mouse-Look Hint when pointer not locked on desktop */}
          {!hud.pointerLocked && !mobileControlsEnabled && (
            <button
              type="button"
              onClick={onLockPointer}
              className="pointer-events-auto font-mono-tech absolute top-16 border border-zinc-700/80 bg-zinc-950/85 px-3 py-1 text-[11px] text-zinc-300 transition-colors hover:border-amber-500/70 hover:text-zinc-50"
            >
              Click viewport to lock aim · Drag also supported · WASD Move · F Light · R Reload
            </button>
          )}
        </div>
      )}

      {/* Collapsible Bottom Optical & Lighting Dock (Zero Viewport Occlusion) */}
      <div className="pointer-events-none flex flex-col items-center">
        <button
          type="button"
          onClick={() => setDockCollapsed((v) => !v)}
          className="pointer-events-auto font-mono-tech mb-1 flex items-center gap-1.5 rounded-t border border-b-0 border-zinc-700/70 bg-zinc-950/90 px-3 py-1 text-[11px] tracking-wider text-zinc-300 transition-colors hover:text-white"
        >
          {dockCollapsed ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          <span>{dockCollapsed ? 'Optics & Controls (H)' : 'Hide Controls (H)'}</span>
        </button>

        {!dockCollapsed && (
          <div className="pointer-events-auto flex w-full max-w-[960px] flex-wrap items-center justify-between gap-2.5 rounded border border-zinc-700/70 bg-zinc-950/92 px-3.5 py-2 text-xs text-zinc-200 shadow-2xl">
            {/* Optical Mode Selector */}
            <div className="flex items-center gap-1 rounded bg-zinc-900 p-0.5 border border-zinc-800">
              {opticalOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onUpdateSettings({ opticalMode: opt.id })}
                  className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    settings.opticalMode === opt.id
                      ? 'bg-amber-500 text-zinc-950 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-100'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Atmospheric Lighting Mood Selector */}
            <div className="flex items-center gap-1 rounded bg-zinc-900 p-0.5 border border-zinc-800">
              {moodOptions.map((mood) => (
                <button
                  key={mood.id}
                  type="button"
                  onClick={() => onUpdateSettings({ lightingMood: mood.id })}
                  className={`whitespace-nowrap shrink-0 rounded px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    settings.lightingMood === mood.id
                      ? 'bg-zinc-100 text-zinc-950 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-100'
                  }`}
                >
                  {mood.label}
                </button>
              ))}
            </div>

            {/* Live Bodycam Optical Sliders */}
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                <span className="whitespace-nowrap">Fisheye</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.distortion}
                  onChange={(e) => onUpdateSettings({ distortion: parseFloat(e.target.value) })}
                  className="tac-slider w-14"
                />
              </label>

              <label className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                <span className="whitespace-nowrap">Grain</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.grain}
                  onChange={(e) => onUpdateSettings({ grain: parseFloat(e.target.value) })}
                  className="tac-slider w-14"
                />
              </label>

              <label className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                <span className="whitespace-nowrap">Exposure</span>
                <input
                  type="range"
                  min={0.7}
                  max={1.8}
                  step={0.05}
                  value={settings.exposure}
                  onChange={(e) => onUpdateSettings({ exposure: parseFloat(e.target.value) })}
                  className="tac-slider w-14"
                />
              </label>
            </div>

            {/* Utility Action Buttons */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={onToggleMobileControls}
                title="Toggle Mobile Touch Controls"
                className={`flex h-8 items-center gap-1.5 rounded border px-2 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                  mobileControlsEnabled
                    ? 'border-cyan-500/70 bg-cyan-500/15 text-cyan-300'
                    : 'border-zinc-700 bg-zinc-900 text-zinc-400 hover:text-zinc-100'
                }`}
              >
                <Smartphone className="h-3.5 w-3.5" />
                <span>Touch</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ flashlightOn: !hud.flashlightOn })}
                title="Toggle Tactical Flashlight (F)"
                className={`flex h-8 w-8 items-center justify-center rounded border transition-colors ${
                  hud.flashlightOn
                    ? 'border-amber-500/60 bg-amber-500/15 text-amber-400'
                    : 'border-zinc-700 bg-zinc-900 text-zinc-400 hover:text-zinc-100'
                }`}
              >
                <Flashlight className="h-3.5 w-3.5" />
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ audioEnabled: !settings.audioEnabled })}
                title="Toggle Audio"
                className="flex h-8 w-8 items-center justify-center rounded border border-zinc-700 bg-zinc-900 text-zinc-300 transition-colors hover:text-white"
              >
                {settings.audioEnabled ? (
                  <Volume2 className="h-3.5 w-3.5" />
                ) : (
                  <VolumeX className="h-3.5 w-3.5 text-zinc-500" />
                )}
              </button>

              {isPlaying && (
                <button
                  type="button"
                  onClick={onPause}
                  title="Pause (P)"
                  className="flex h-8 w-8 items-center justify-center rounded border border-zinc-700 bg-zinc-900 text-zinc-300 transition-colors hover:text-white"
                >
                  <Pause className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
