import React, { useState } from 'react';
import { Playlist, Track } from '../types/audio';
import { ListMusic, Plus, Play, Trash2, Music, Sparkles } from 'lucide-react';

interface Props {
  playlists: Playlist[];
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  onCreatePlaylist: (name: string, description?: string) => void;
  onDeletePlaylist: (id: string) => void;
  onRemoveTrackFromPlaylist: (playlistId: string, trackId: string) => void;
}

export const PlaylistsView: React.FC<Props> = ({
  playlists,
  tracks,
  currentTrack,
  isPlaying,
  onPlayTrack,
  onCreatePlaylist,
  onDeletePlaylist,
  onRemoveTrackFromPlaylist,
}) => {
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(
    playlists[0]?.id || null
  );
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const activePlaylist = playlists.find((p) => p.id === selectedPlaylistId) || playlists[0];
  const playlistTracks = activePlaylist
    ? activePlaylist.trackIds
        .map((id) => tracks.find((t) => t.id === id))
        .filter((t): t is Track => !!t)
    : [];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    onCreatePlaylist(newName.trim(), newDesc.trim() || undefined);
    setNewName('');
    setNewDesc('');
    setShowCreateModal(false);
  };

  const handlePlayAll = () => {
    if (playlistTracks.length > 0) {
      onPlayTrack(playlistTracks[0]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with create playlist button */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <ListMusic className="w-5 h-5 text-indigo-400" />
            <span>Listas de Reproducción</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Crea colecciones personalizadas de audio organizadas a tu gusto
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm shadow-indigo-600/20"
        >
          <Plus className="w-4 h-4" />
          <span>Nueva Lista</span>
        </button>
      </div>

      {/* Playlist Horizontal Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {playlists.map((pl) => {
          const isSelected = activePlaylist?.id === pl.id;
          return (
            <button
              key={pl.id}
              onClick={() => setSelectedPlaylistId(pl.id)}
              className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl whitespace-nowrap transition border ${
                isSelected
                  ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-sm'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <ListMusic className="w-3.5 h-3.5" />
              <span>{pl.name}</span>
              <span className="text-[10px] text-slate-500 font-mono">
                ({pl.trackIds.length})
              </span>
            </button>
          );
        })}
      </div>

      {/* Active Playlist Detail */}
      {activePlaylist ? (
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950/30 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white">{activePlaylist.name}</h3>
              {activePlaylist.description && (
                <p className="text-xs text-slate-400 mt-0.5">{activePlaylist.description}</p>
              )}
              <div className="flex items-center gap-3 text-xs text-slate-500 mt-2">
                <span>{playlistTracks.length} canciones</span>
                <span aria-hidden="true">·</span>
                <span>
                  {Math.round(
                    playlistTracks.reduce((acc, t) => acc + t.duration, 0) / 60
                  )}{' '}
                  minutos en total
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {playlistTracks.length > 0 && (
                <button
                  onClick={handlePlayAll}
                  className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-600/20"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Reproducir Todo</span>
                </button>
              )}

              {/* Only allow deleting non-default playlists */}
              {activePlaylist.id !== 'favorites' && activePlaylist.id !== 'relax' && (
                <button
                  onClick={() => onDeletePlaylist(activePlaylist.id)}
                  className="p-2 text-slate-400 hover:text-red-400 bg-slate-800 hover:bg-slate-700 rounded-xl transition"
                  title="Eliminar lista"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Track List inside playlist */}
          {playlistTracks.length === 0 ? (
            <div className="p-8 text-center bg-slate-900/30 border border-dashed border-slate-800 rounded-2xl">
              <Music className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs font-medium text-slate-400">Esta lista está vacía</p>
              <p className="text-[11px] text-slate-500 mt-1">
                Ve a tu biblioteca y haz clic en el botón '+' de cualquier canción para agregarla aquí.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {playlistTracks.map((track, idx) => {
                const isCurrent = currentTrack?.id === track.id;
                return (
                  <div
                    key={`${track.id}-${idx}`}
                    className={`flex items-center justify-between p-3 rounded-xl border transition ${
                      isCurrent
                        ? 'bg-indigo-950/30 border-indigo-500/50'
                        : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-800/60'
                    }`}
                  >
                    <div
                      onClick={() => onPlayTrack(track)}
                      className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                    >
                      <span className="text-xs font-mono text-slate-500 w-5 text-center">
                        {idx + 1}
                      </span>
                      <div className="w-9 h-9 rounded-lg overflow-hidden shrink-0 bg-slate-800">
                        <img
                          src={track.coverUrl || '/icon.svg'}
                          alt={track.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <p
                          className={`text-xs font-semibold truncate ${
                            isCurrent ? 'text-indigo-400' : 'text-slate-200'
                          }`}
                        >
                          {track.title}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate">{track.artist}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 ml-3">
                      <span className="text-[10px] font-mono uppercase text-slate-400 px-1.5 py-0.5 bg-slate-800 rounded">
                        {track.format}
                      </span>
                      <button
                        onClick={() => onRemoveTrackFromPlaylist(activePlaylist.id, track.id)}
                        className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg transition"
                        title="Quitar de la lista"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : null}

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl">
            <h3 className="text-sm font-semibold text-white mb-4">Nueva Lista de Reproducción</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Nombre</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Sesión Acústica 2026"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 block mb-1">Descripción (opcional)</label>
                <input
                  type="text"
                  placeholder="Ej: Sonidos cálidos y relajantes"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm"
                >
                  Crear Lista
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
