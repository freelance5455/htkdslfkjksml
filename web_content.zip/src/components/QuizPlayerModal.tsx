import React, { useMemo, useState } from 'react';
import { Award, CheckCircle2, Clock, HelpCircle, RotateCcw, X, XCircle } from 'lucide-react';
import { LanguageCode, Quiz, QuizAttempt } from '../types/edutoon';
import { Logo } from './Logo';

interface QuizPlayerModalProps {
  quiz: Quiz;
  subjectName: string;
  language: LanguageCode;
  previousAttempt?: QuizAttempt;
  onSubmitQuiz: (score: number) => Promise<void>;
  onClose: () => void;
}

export const QuizPlayerModal: React.FC<QuizPlayerModalProps> = ({
  quiz,
  subjectName,
  language,
  previousAttempt,
  onSubmitQuiz,
  onClose,
}) => {
  const isHi = language === 'hi';
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const answeredCount = Object.keys(answers).length;
  const totalQuestions = quiz.questions.length;

  const computedScore = useMemo(() => {
    return quiz.questions.reduce((acc, q, idx) => {
      return acc + (answers[idx] === q.correctIndex ? 1 : 0);
    }, 0);
  }, [answers, quiz.questions]);

  const percentage = totalQuestions > 0 ? Math.round((computedScore / totalQuestions) * 100) : 0;

  const handleFinish = async () => {
    setSubmitting(true);
    try {
      await onSubmitQuiz(computedScore);
      setSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRetry = () => {
    setAnswers({});
    setSubmitted(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-3xl bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header with Official Logo */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3 min-w-0">
            <Logo size="xs" />
            <div className="min-w-0">
              <p className="text-xs text-slate-500 truncate">
                {subjectName} · {isHi ? `कक्षा ${quiz.classLevel}` : `Class ${quiz.classLevel}`} ·{' '}
                {isHi ? `अध्याय ${quiz.chapterNumber}` : `Chapter ${quiz.chapterNumber}`}
              </p>
              <h2 className="font-display text-sm sm:text-base font-bold text-slate-900 truncate">
                {quiz.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close quiz"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-200/70 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2 p-4 rounded-2xl bg-sky-50 border border-sky-200">
            <div>
              <p className="text-sm font-semibold text-slate-900">{quiz.description}</p>
              <p className="text-xs text-slate-600 mt-0.5 flex items-center gap-3">
                <span className="inline-flex items-center gap-1">
                  <HelpCircle className="h-3.5 w-3.5 text-sky-700" />
                  <span className="font-mono-num">{totalQuestions} Questions</span>
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5 text-sky-700" />
                  <span className="font-mono-num">{quiz.timeLimitMinutes} min</span>
                </span>
              </p>
            </div>
            {previousAttempt && !submitted && (
              <span className="text-xs font-semibold text-sky-800 bg-white px-3 py-1.5 rounded-xl border border-sky-200 font-mono-num">
                Best: {previousAttempt.score}/{previousAttempt.totalQuestions} ({previousAttempt.percentage}%)
              </span>
            )}
          </div>

          {submitted && (
            <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Award className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                    {isHi ? 'क्विज़ परिणाम सहेजा गया' : 'Quiz Score Saved'}
                  </p>
                  <p className="font-display text-xl font-bold text-slate-900 font-mono-num">
                    {computedScore} / {totalQuestions} ({percentage}%)
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleRetry}
                className="min-h-[42px] px-4 rounded-xl border border-emerald-300 bg-white text-emerald-800 text-xs sm:text-sm font-semibold inline-flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{isHi ? 'फिर से प्रयास करें' : 'Retake Quiz'}</span>
              </button>
            </div>
          )}

          <div className="space-y-4">
            {quiz.questions.map((q, qIdx) => {
              const chosen = answers[qIdx];
              return (
                <div
                  key={q.id || qIdx}
                  className="p-4 sm:p-5 rounded-2xl border border-slate-200 bg-white space-y-3"
                >
                  <p className="text-sm sm:text-base font-bold text-slate-900">
                    <span className="font-mono-num text-sky-700 mr-2">Q{qIdx + 1}.</span>
                    {q.prompt}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = chosen === optIdx;
                      const isCorrect = optIdx === q.correctIndex;
                      let optionStyle =
                        'border-slate-200 bg-slate-50 text-slate-800 hover:border-sky-400 hover:bg-sky-50/50';
                      if (submitted) {
                        if (isCorrect) {
                          optionStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold';
                        } else if (isSelected && !isCorrect) {
                          optionStyle = 'border-red-400 bg-red-50 text-red-900';
                        } else {
                          optionStyle = 'border-slate-200 bg-white text-slate-500';
                        }
                      } else if (isSelected) {
                        optionStyle = 'border-sky-600 bg-sky-50 text-sky-900 font-semibold';
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          disabled={submitted}
                          onClick={() => setAnswers((prev) => ({ ...prev, [qIdx]: optIdx }))}
                          className={`min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left text-xs sm:text-sm flex items-center justify-between gap-2 transition-colors ${
                            submitted ? 'cursor-default' : 'cursor-pointer'
                          } ${optionStyle}`}
                        >
                          <span>
                            <span className="font-mono-num font-bold mr-1.5">
                              {String.fromCharCode(65 + optIdx)}.
                            </span>
                            {opt}
                          </span>
                          {submitted && isCorrect && (
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                          )}
                          {submitted && isSelected && !isCorrect && (
                            <XCircle className="h-4 w-4 text-red-600 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                  {submitted && q.explanation && (
                    <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <span className="font-semibold text-slate-800">Explanation: </span>
                      {q.explanation}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 sm:px-6 py-3.5 border-t border-slate-200 bg-white flex items-center justify-between gap-3">
          <span className="text-xs font-semibold text-slate-600 font-mono-num">
            {answeredCount}/{totalQuestions} {isHi ? 'उत्तर चुने गए' : 'answered'}
          </span>
          {!submitted ? (
            <button
              type="button"
              disabled={submitting || answeredCount === 0}
              onClick={handleFinish}
              className="min-h-[44px] px-5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white text-sm font-semibold cursor-pointer"
            >
              {submitting ? 'Saving Score...' : isHi ? 'क्विज़ सबमिट करें' : 'Submit Quiz'}
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold cursor-pointer"
            >
              {isHi ? 'बंद करें' : 'Done'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
