import splash from '../assets/splash.jpg';

export default function Splash({ fading }: { fading: boolean }) {
  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-end text-center transition-opacity duration-700 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ backgroundImage: `url(${splash})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundColor: '#052e22' }}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
      <div className="relative pb-16 px-6">
        <h1 className="text-4xl font-extrabold text-amber-300 drop-shadow-lg" style={{ fontFamily: '"Amiri","Noto Naskh Arabic",serif' }}>
          الأحاديث الصحيحة
        </h1>
        <p className="mt-2 text-amber-100/90 text-lg">عن النبي ﷺ وأهل بيته الأطهار (ع)</p>
        <div className="mt-6 mx-auto h-1.5 w-40 rounded-full bg-white/20 overflow-hidden">
          <div className="h-full w-1/2 rounded-full bg-amber-300 animate-[slide_1.3s_ease-in-out_infinite]" />
        </div>
        <p className="mt-3 text-xs text-white/70">يعمل بدون إنترنت</p>
      </div>
    </div>
  );
}
