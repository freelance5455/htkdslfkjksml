import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Sparkles,
  Download,
  Image as ImageIcon,
  RotateCcw,
  Maximize2,
  Trash2,
  Wand2,
  Sliders,
  Type,
  Smile,
  Eye,
  Check,
  Brain,
  Palette,
  Undo2
} from 'lucide-react';

interface ImageEditorProps {
  onOpenSetupGuide: () => void;
}

interface StickerItem {
  id: string;
  emoji: string;
  label: string;
  x: number; // percentage
  y: number; // percentage
  size: number;
}

const PRESET_FILTERS = [
  { id: 'normal', name: 'Asal (Normal)', filter: 'none', icon: '📷' },
  {
    id: 'cyberpunk',
    name: 'Neon Ungu HANN',
    filter: 'hue-rotate(240deg) saturate(1.8) contrast(1.2)',
    icon: '🟣',
  },
  {
    id: 'anime',
    name: 'Gaya Anime Pop',
    filter: 'saturate(2.2) contrast(1.3) brightness(1.05)',
    icon: '🎨',
  },
  {
    id: 'night_city',
    name: 'Cyberpunk 2077',
    filter: 'contrast(1.4) hue-rotate(180deg) saturate(1.6)',
    icon: '🌆',
  },
  {
    id: 'golden',
    name: 'Golden Sunset',
    filter: 'sepia(0.5) saturate(1.8) hue-rotate(-20deg) brightness(1.1)',
    icon: '🌅',
  },
  {
    id: 'noir',
    name: 'Dark Noir',
    filter: 'grayscale(1) contrast(1.6) brightness(0.9)',
    icon: '🖤',
  },
  {
    id: 'soft_glow',
    name: 'Soft Dreamy',
    filter: 'brightness(1.15) contrast(0.95) saturate(1.3)',
    icon: '✨',
  },
  {
    id: 'vintage',
    name: 'Retro Vintage',
    filter: 'sepia(0.7) contrast(1.1) brightness(0.95)',
    icon: '📼',
  },
];

const STICKER_PRESETS = [
  { emoji: '🐱', label: 'Kucing Comel' },
  { emoji: '🕶️', label: 'Cermin Mata Hitam' },
  { emoji: '🤠', label: 'Topi Koboi' },
  { emoji: '👑', label: 'Mahkota' },
  { emoji: '🔥', label: 'Api Padu' },
  { emoji: '✨', label: 'Kilauan Bintang' },
  { emoji: '💜', label: 'Hati Ungu' },
  { emoji: '🌸', label: 'Bunga Sakura' },
  { emoji: '🎧', label: 'Headphone' },
  { emoji: '⭐', label: 'Bintang Emas' },
];

const ASPECT_RATIOS = [
  { id: 'free', label: 'Asal', ratio: 0 },
  { id: '1:1', label: '1:1 (Segiempat)', ratio: 1 },
  { id: '4:3', label: '4:3 (Foto)', ratio: 4 / 3 },
  { id: '16:9', label: '16:9 (Skrin Lebar)', ratio: 16 / 9 },
  { id: '9:16', label: '9:16 (Telefon/Story)', ratio: 9 / 16 },
];

export const ImageEditor: React.FC<ImageEditorProps> = () => {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'filter' | 'adjust' | 'stickers' | 'text'>('filter');

  // Adjustments state
  const [selectedFilter, setSelectedFilter] = useState('normal');
  const [hueRotate, setHueRotate] = useState(0); // 0 to 360 (Tukar warna baju / persekitaran)
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);

  // Overlay text
  const [overlayText, setOverlayText] = useState('');
  const [textColor, setTextColor] = useState('#c084fc'); // purple accent
  const [textSize, setTextSize] = useState(28);

  // Stickers state
  const [stickers, setStickers] = useState<StickerItem[]>([]);
  const [activeStickerId, setActiveStickerId] = useState<string | null>(null);

  // Aspect ratio
  const [aspectRatio, setAspectRatio] = useState('free');

  // AI Vision analysis (Free multimodal)
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Canvas result
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewContainerRef = useRef<HTMLDivElement>(null);

  // Load uploaded image
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Limit max dimensions to 1280px for performance
        const maxDim = 1280;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          setSourceImage(dataUrl);
          setGeneratedImage(null);
          setAiAnalysis(null);
          resetControls();
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const resetControls = () => {
    setSelectedFilter('normal');
    setHueRotate(0);
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setOverlayText('');
    setStickers([]);
  };

  // Render composite to canvas and generate output image
  const renderComposite = () => {
    if (!sourceImage) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let targetW = img.width;
      let targetH = img.height;

      // Handle aspect ratio crop if requested
      const selectedRatioObj = ASPECT_RATIOS.find((r) => r.id === aspectRatio);
      if (selectedRatioObj && selectedRatioObj.ratio > 0) {
        const targetRatio = selectedRatioObj.ratio;
        const currentRatio = targetW / targetH;
        if (currentRatio > targetRatio) {
          targetW = Math.round(targetH * targetRatio);
        } else {
          targetH = Math.round(targetW / targetRatio);
        }
      }

      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Apply CSS-like filters on canvas context
      const filterObj = PRESET_FILTERS.find((f) => f.id === selectedFilter);
      let filterString = '';

      if (filterObj && filterObj.filter !== 'none') {
        filterString += `${filterObj.filter} `;
      }
      if (hueRotate !== 0) {
        filterString += `hue-rotate(${hueRotate}deg) `;
      }
      if (brightness !== 100) {
        filterString += `brightness(${brightness / 100}) `;
      }
      if (contrast !== 100) {
        filterString += `contrast(${contrast / 100}) `;
      }
      if (saturation !== 100) {
        filterString += `saturate(${saturation / 100}) `;
      }

      ctx.filter = filterString.trim() || 'none';

      // Draw image centered
      const offsetX = (img.width - targetW) / 2;
      const offsetY = (img.height - targetH) / 2;
      ctx.drawImage(img, offsetX, offsetY, targetW, targetH, 0, 0, targetW, targetH);

      // Reset filter for stickers and text overlays
      ctx.filter = 'none';

      // Draw Stickers
      stickers.forEach((sticker) => {
        const xPos = (sticker.x / 100) * targetW;
        const yPos = (sticker.y / 100) * targetH;
        const fontSize = (sticker.size / 100) * (targetW * 0.18);

        ctx.font = `${Math.round(fontSize)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(sticker.emoji, xPos, yPos);
      });

      // Draw Overlay Text if present
      if (overlayText.trim()) {
        const textFontSize = Math.round((textSize / 100) * (targetW * 0.08));
        ctx.font = `bold ${textFontSize}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';

        const textX = targetW / 2;
        const textY = targetH - targetH * 0.08;

        // Draw shadow glow
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 12;
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#000000';
        ctx.strokeText(overlayText.trim(), textX, textY);

        ctx.fillStyle = textColor;
        ctx.fillText(overlayText.trim(), textX, textY);
      }

      const resultDataUrl = canvas.toDataURL('image/png', 0.95);
      setGeneratedImage(resultDataUrl);
    };
    img.src = sourceImage;
  };

  // Re-render composite whenever edits change
  useEffect(() => {
    if (sourceImage) {
      const timer = setTimeout(() => {
        renderComposite();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [
    sourceImage,
    selectedFilter,
    hueRotate,
    brightness,
    contrast,
    saturation,
    overlayText,
    textColor,
    textSize,
    stickers,
    aspectRatio,
  ]);

  // Add Sticker to Canvas
  const handleAddSticker = (emoji: string, label: string) => {
    if (!sourceImage) return;
    const newSticker: StickerItem = {
      id: `sticker-${Date.now()}`,
      emoji,
      label,
      x: 50 + (Math.random() * 20 - 10),
      y: 50 + (Math.random() * 20 - 10),
      size: 50,
    };
    setStickers((prev) => [...prev, newSticker]);
    setActiveStickerId(newSticker.id);
  };

  const removeSticker = (id: string) => {
    setStickers((prev) => prev.filter((s) => s.id !== id));
    if (activeStickerId === id) setActiveStickerId(null);
  };

  // Free AI Vision Analysis with Gemini 3.1 Flash Lite
  const handleAnalyzeImage = async () => {
    if (!sourceImage) return;

    setIsAnalyzing(true);
    setAiAnalysis(null);

    try {
      const response = await fetch('/api/image/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: sourceImage,
          prompt:
            'Tengok gambar ni dan ulas dalam loghat utara santai HANN AI. Habaq mai apa yang menarik pasai gambar ni, cadangkan warna atau gaya yang sesuai nak edit, dan bagi lawak santai sikit!',
        }),
      });

      const data = await response.json();
      if (data.success && data.reply) {
        setAiAnalysis(data.reply);
      } else {
        setAiAnalysis('Maaf hang, tak dapat nak ulas gambar ni tadi.');
      }
    } catch (err: any) {
      console.error('Vision analysis error:', err);
      setAiAnalysis('Ada masalah teknikal semasa menghubungi enjin analisis HANN AI.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Download image
  const handleDownload = () => {
    const imgToSave = generatedImage || sourceImage;
    if (!imgToSave) return;
    const link = document.createElement('a');
    link.href = imgToSave;
    link.download = `hann-ai-studio-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Set edited image as new source
  const handleReuseAsSource = () => {
    if (!generatedImage) return;
    setSourceImage(generatedImage);
    setGeneratedImage(null);
    resetControls();
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  const handleReset = () => {
    setSourceImage(null);
    setGeneratedImage(null);
    setAiAnalysis(null);
    resetControls();
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 overscroll-contain">
      <div className="max-w-4xl mx-auto space-y-4 pb-12">
        {/* Banner Header */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/70 via-[#15072b] to-purple-900/50 border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-[0_0_25px_rgba(168,85,247,0.2)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-violet-500 flex items-center justify-center shadow-md shadow-purple-600/30 shrink-0">
              <Wand2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  HANN AI Image Studio
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                  100% Percuma & Aktif
                </span>
              </div>
              <p className="text-xs text-purple-200/80">
                Tukar warna baju/suasana, tambah background neon, pelekat comel & dapatkan ulasan AI loghat utara!
              </p>
            </div>
          </div>

          {sourceImage && (
            <button
              onClick={handleAnalyzeImage}
              disabled={isAnalyzing}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-xs font-bold text-white shadow-md shadow-purple-900/40 transition-all hover:scale-[1.02] shrink-0"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>HANN AI Sedang Imbas...</span>
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 text-purple-200" />
                  <span>🧠 HANN AI Ulas Gambar</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* AI Vision Commentary Box */}
        {aiAnalysis && (
          <div className="p-4 rounded-2xl bg-[#180938] border border-purple-500/40 shadow-lg space-y-2 animate-fade-in text-slate-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-fuchsia-400" />
                <span className="text-xs font-bold text-purple-200">
                  Ulasan Pintar HANN AI (Loghat Utara):
                </span>
              </div>
              <button
                onClick={() => setAiAnalysis(null)}
                className="text-xs text-purple-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            <p className="text-xs sm:text-sm text-purple-100/90 leading-relaxed italic bg-black/40 p-3 rounded-xl border border-purple-900/50">
              "{aiAnalysis}"
            </p>
          </div>
        )}

        {/* Reuse Notification */}
        {copiedNotification && (
          <div className="p-3 rounded-xl bg-purple-900/60 border border-purple-500/40 text-purple-200 text-xs flex items-center gap-2 animate-fade-in">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Gambar hasil suntingan telah ditetapkan sebagai gambar baru untuk sambung edit!</span>
          </div>
        )}

        {/* Main Editor Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Canvas & Preview (7 cols) */}
          <div className="lg:col-span-7 space-y-3">
            <div className="p-4 rounded-2xl bg-[#120728]/90 border border-purple-900/50 backdrop-blur-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-200 tracking-wide flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-fuchsia-400" />
                  Pratonton Studio (Sentuh / Klik Gambar)
                </span>
                {sourceImage && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setLightboxImage(generatedImage || sourceImage)}
                      className="p-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 text-xs transition-colors"
                      title="Lihat Skrin Penuh"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleReset}
                      className="flex items-center gap-1 text-[11px] font-medium text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Kosongkan</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Upload Dropzone or Live Canvas */}
              {!sourceImage ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="group relative border-2 border-dashed border-purple-700/40 hover:border-purple-400 rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer bg-purple-950/20 hover:bg-purple-950/40 transition-all min-h-[260px]"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <div className="w-16 h-16 rounded-2xl bg-purple-900/40 group-hover:bg-purple-800/60 border border-purple-500/30 flex items-center justify-center text-purple-300 group-hover:text-white transition-all shadow-md group-hover:scale-110 mb-3">
                    <Upload className="w-8 h-8" />
                  </div>
                  <h4 className="font-bold text-sm sm:text-base text-purple-100 group-hover:text-purple-300 transition-colors">
                    Sentuh atau Klik untuk Pilih Gambar
                  </h4>
                  <p className="text-xs text-purple-300/70 mt-1 max-w-xs leading-relaxed">
                    Pilih gambar dari galeri telefon, kamera atau komputer anda.
                  </p>
                  <span className="mt-3 text-[10px] font-medium px-3 py-1 rounded-full bg-purple-900/50 text-purple-300 border border-purple-700/30">
                    Sokong Kamera & Galeri Telefon Android
                  </span>
                </div>
              ) : (
                <div
                  ref={previewContainerRef}
                  className="relative rounded-xl overflow-hidden border border-purple-600/40 bg-black/80 flex items-center justify-center min-h-[300px] max-h-[460px] select-none"
                >
                  {/* Live Rendered Output */}
                  <img
                    src={generatedImage || sourceImage}
                    alt="Pratonton Suntingan"
                    className="max-h-[460px] w-auto object-contain rounded-xl shadow-2xl"
                  />

                  {/* Quick Change button */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-2.5 py-1.5 rounded-lg bg-black/80 hover:bg-black text-white text-xs font-semibold backdrop-blur-md border border-purple-500/40 shadow-lg"
                    >
                      Tukar Gambar
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons: Download & Iterate */}
              {sourceImage && (
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <button
                    onClick={handleDownload}
                    className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-950 transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <Download className="w-4 h-4" />
                    <span>Simpan / Muat Turun Gambar</span>
                  </button>
                  <button
                    onClick={handleReuseAsSource}
                    className="flex items-center gap-1.5 py-3 px-3.5 rounded-xl bg-purple-900/50 hover:bg-purple-800 text-purple-200 hover:text-white text-xs font-semibold border border-purple-600/40 transition-colors"
                    title="Gunakan hasil ini sebagai gambar asas untuk suntingan seterusnya"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Sunting Lagi</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Controls & Tools Panel (5 cols) */}
          <div className="lg:col-span-5 space-y-3">
            <div className="p-4 rounded-2xl bg-[#120728]/90 border border-purple-900/50 backdrop-blur-sm space-y-4">
              {/* Tool Navigation Tabs */}
              <div className="flex items-center rounded-xl bg-[#0a0316] p-1 border border-purple-900/40">
                <button
                  onClick={() => setActiveTab('filter')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'filter'
                      ? 'bg-purple-700 text-white shadow'
                      : 'text-purple-300/70 hover:text-purple-200'
                  }`}
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>Gaya</span>
                </button>
                <button
                  onClick={() => setActiveTab('adjust')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'adjust'
                      ? 'bg-purple-700 text-white shadow'
                      : 'text-purple-300/70 hover:text-purple-200'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Warna</span>
                </button>
                <button
                  onClick={() => setActiveTab('stickers')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'stickers'
                      ? 'bg-purple-700 text-white shadow'
                      : 'text-purple-300/70 hover:text-purple-200'
                  }`}
                >
                  <Smile className="w-3.5 h-3.5" />
                  <span>Pelekat</span>
                </button>
                <button
                  onClick={() => setActiveTab('text')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'text'
                      ? 'bg-purple-700 text-white shadow'
                      : 'text-purple-300/70 hover:text-purple-200'
                  }`}
                >
                  <Type className="w-3.5 h-3.5" />
                  <span>Teks</span>
                </button>
              </div>

              {/* TAB 1: FILTERS & THEMES */}
              {activeTab === 'filter' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-200">
                      Pilih Gaya Visual / Penapis:
                    </span>
                    <button
                      onClick={() => setSelectedFilter('normal')}
                      className="text-[11px] text-purple-400 hover:text-white"
                    >
                      Reset Gaya
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {PRESET_FILTERS.map((f) => (
                      <button
                        key={f.id}
                        onClick={() => setSelectedFilter(f.id)}
                        className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center gap-2 ${
                          selectedFilter === f.id
                            ? 'bg-purple-600/40 border-purple-400 text-white shadow-md shadow-purple-900/40 font-bold'
                            : 'bg-purple-950/30 border-purple-900/40 text-purple-300 hover:bg-purple-900/40'
                        }`}
                      >
                        <span className="text-base shrink-0">{f.icon}</span>
                        <span className="truncate">{f.name}</span>
                      </button>
                    ))}
                  </div>

                  {/* Aspect Ratio Cropping */}
                  <div className="pt-2 border-t border-purple-900/40 space-y-2">
                    <span className="text-xs font-bold text-purple-200 block">
                      Nisbah Aspek (Aspect Ratio):
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {ASPECT_RATIOS.map((r) => (
                        <button
                          key={r.id}
                          onClick={() => setAspectRatio(r.id)}
                          className={`p-1.5 rounded-lg border text-xs text-center transition-all ${
                            aspectRatio === r.id
                              ? 'bg-purple-600/30 border-purple-400 text-white font-bold'
                              : 'bg-purple-950/20 border-purple-900/40 text-purple-300/70 hover:bg-purple-900/30'
                          }`}
                        >
                          {r.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: COLOR & SHIRT TONE ADJUSTMENTS */}
              {activeTab === 'adjust' && (
                <div className="space-y-4 text-xs">
                  {/* Hue Rotate (Tukar Warna Baju / Suasana) */}
                  <div className="space-y-1.5 p-3 rounded-xl bg-purple-950/30 border border-purple-800/30">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-purple-200">
                        🔄 Tukar Ton Warna & Baju (Hue):
                      </span>
                      <span className="font-mono text-purple-400">{hueRotate}°</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="360"
                      value={hueRotate}
                      onChange={(e) => setHueRotate(Number(e.target.value))}
                      className="w-full accent-fuchsia-500 cursor-pointer"
                    />
                    <p className="text-[10px] text-purple-300/60 leading-tight">
                      Alih slider ni untuk ubah warna baju atau latar secara langsung (contoh: hijau ke ungu neon).
                    </p>
                  </div>

                  {/* Brightness */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Kecerahan (Brightness):</span>
                      <span className="font-mono text-purple-400">{brightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="150"
                      value={brightness}
                      onChange={(e) => setBrightness(Number(e.target.value))}
                      className="w-full accent-purple-500 cursor-pointer"
                    />
                  </div>

                  {/* Contrast */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Kontras (Contrast):</span>
                      <span className="font-mono text-purple-400">{contrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="180"
                      value={contrast}
                      onChange={(e) => setContrast(Number(e.target.value))}
                      className="w-full accent-purple-500 cursor-pointer"
                    />
                  </div>

                  {/* Saturation */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Ketepuan Warna (Saturation):</span>
                      <span className="font-mono text-purple-400">{saturation}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="220"
                      value={saturation}
                      onChange={(e) => setSaturation(Number(e.target.value))}
                      className="w-full accent-purple-500 cursor-pointer"
                    />
                  </div>

                  <button
                    onClick={() => {
                      setHueRotate(0);
                      setBrightness(100);
                      setContrast(100);
                      setSaturation(100);
                    }}
                    className="w-full py-2 rounded-xl bg-purple-900/30 hover:bg-purple-900/50 text-purple-300 text-xs font-semibold border border-purple-800/40"
                  >
                    Reset Semua Pelaras
                  </button>
                </div>
              )}

              {/* TAB 3: STICKERS & OBJECTS */}
              {activeTab === 'stickers' && (
                <div className="space-y-3">
                  <span className="text-xs font-bold text-purple-200 block">
                    Tambah Objek & Pelekat (Klik untuk Tampal):
                  </span>
                  <div className="grid grid-cols-5 gap-2">
                    {STICKER_PRESETS.map((s, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleAddSticker(s.emoji, s.label)}
                        className="p-3 rounded-xl bg-purple-950/40 hover:bg-purple-900/60 border border-purple-800/40 hover:border-purple-500/60 text-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 shadow"
                        title={s.label}
                      >
                        {s.emoji}
                      </button>
                    ))}
                  </div>

                  {/* Active Stickers list */}
                  {stickers.length > 0 && (
                    <div className="pt-2 border-t border-purple-900/40 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-purple-200">
                          Pelekat yang Ditambah ({stickers.length}):
                        </span>
                        <button
                          onClick={() => setStickers([])}
                          className="text-[11px] text-red-400 hover:text-red-300"
                        >
                          Padam Semua
                        </button>
                      </div>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {stickers.map((st) => (
                          <div
                            key={st.id}
                            className="p-2 rounded-xl bg-black/40 border border-purple-900/50 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{st.emoji}</span>
                              <span className="text-purple-200 font-medium">{st.label}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                                  // move right/down
                                  setStickers((prev) =>
                                    prev.map((item) =>
                                      item.id === st.id
                                        ? { ...item, x: (item.x + 10) % 90, y: (item.y + 10) % 90 }
                                        : item
                                    )
                                  );
                                }}
                                className="px-2 py-0.5 rounded bg-purple-900/40 hover:bg-purple-800 text-[10px] text-purple-300 font-medium"
                              >
                                Alih
                              </button>
                              <button
                                onClick={() => removeSticker(st.id)}
                                className="text-red-400 hover:text-red-300 p-1"
                              >
                                ✕
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: OVERLAY TEXT & CAPTIONS */}
              {activeTab === 'text' && (
                <div className="space-y-3 text-xs">
                  <span className="text-xs font-bold text-purple-200 block">
                    Tambah Kapsyen Teks:
                  </span>
                  <input
                    type="text"
                    value={overlayText}
                    onChange={(e) => setOverlayText(e.target.value)}
                    placeholder="Contoh: Padu bak hang! 🔥"
                    className="w-full px-3 py-2.5 rounded-xl bg-[#0a0316] border border-purple-700/40 focus:border-purple-400 text-white placeholder-purple-300/40 outline-none"
                  />

                  {overlayText && (
                    <>
                      <div className="space-y-1.5">
                        <span className="text-purple-300 block">Pilih Warna Teks:</span>
                        <div className="flex items-center gap-2">
                          {[
                            { color: '#c084fc', name: 'Ungu Neon' },
                            { color: '#ffffff', name: 'Putih' },
                            { color: '#facc15', name: 'Emas Kuning' },
                            { color: '#38bdf8', name: 'Biru Cerah' },
                            { color: '#4ade80', name: 'Hijau Padu' },
                          ].map((c) => (
                            <button
                              key={c.color}
                              onClick={() => setTextColor(c.color)}
                              className={`w-7 h-7 rounded-full border-2 transition-all ${
                                textColor === c.color ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                              }`}
                              style={{ backgroundColor: c.color }}
                              title={c.name}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-purple-300">Saiz Teks:</span>
                          <span className="font-mono text-purple-400">{textSize}</span>
                        </div>
                        <input
                          type="range"
                          min="16"
                          max="60"
                          value={textSize}
                          onChange={(e) => setTextSize(Number(e.target.value))}
                          className="w-full accent-purple-500 cursor-pointer"
                        />
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Fullscreen Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4 backdrop-blur-md animate-fade-in"
          onClick={() => setLightboxImage(null)}
        >
          <button
            onClick={() => setLightboxImage(null)}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            ✕
          </button>
          <img
            src={lightboxImage}
            alt="Paparan Penuh"
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-xl shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
