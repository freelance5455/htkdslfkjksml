import React, { useState } from 'react';
import { 
  ClipboardList, 
  Search, 
  Sparkles, 
  Coins, 
  Clock, 
  CheckCircle2, 
  Star, 
  Flame, 
  ArrowRight, 
  Check, 
  X, 
  Award,
  ChevronRight,
  ShieldCheck,
  Building2,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  MEGA_SURVEYS_DATA, 
  SURVEY_CATEGORIES, 
  TOTAL_SURVEYS_CATALOG_COUNT, 
  SurveyItem, 
  SurveyQuestion 
} from '../../services/surveysLibrary';

export const MegaSurveyHubView: React.FC = () => {
  const { currentUser, adjustUserCoins, language } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeSurvey, setActiveSurvey] = useState<SurveyItem | null>(null);

  // Survey answering state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [claimedSurveys, setClaimedSurveys] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_claimed_surveys');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const filteredSurveys = MEGA_SURVEYS_DATA.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.titleBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sponsorName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleStartSurvey = (survey: SurveyItem) => {
    setActiveSurvey(survey);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setIsCompleted(false);
  };

  const handleSelectAnswer = (questionId: string, answer: any) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleNextQuestion = () => {
    if (!activeSurvey) return;
    if (currentQuestionIndex < activeSurvey.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // Finished all questions
      setIsCompleted(true);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      // Award coins
      if (currentUser && !claimedSurveys.includes(activeSurvey.id)) {
        adjustUserCoins(
          currentUser.id,
          activeSurvey.rewardCoins, 
          `Survey Completed: ${activeSurvey.title}`
        );
        const updated = [...claimedSurveys, activeSurvey.id];
        setClaimedSurveys(updated);
        try {
          localStorage.setItem('taskearn_claimed_surveys', JSON.stringify(updated));
        } catch {
          // ignore
        }
      }
    }
  };

  const currentQ: SurveyQuestion | undefined = activeSurvey?.questions[currentQuestionIndex];
  const isLastQuestion = activeSurvey ? currentQuestionIndex === activeSurvey.questions.length - 1 : false;
  const hasAnsweredCurrent = currentQ ? answers[currentQ.id] !== undefined : false;

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-400" />
                100,000+ Surveys Pool
              </span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black">
                {language === 'bn' ? 'তাত্ক্ষণিক কয়েন' : 'Instant Coins'}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-indigo-400" />
              <span>{language === 'bn' ? '১০০,০০০+ সার্ভে ও অপিনিয়ন হাব' : '100,000+ Survey & Opinions Hub'}</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'bn'
                ? 'সহজ প্রশ্নের উত্তর দিন ও তাৎক্ষণিক ২০০ থেকে ৫০০ কয়েন ক্লেইম করুন।'
                : 'Share your genuine opinions and collect guaranteed 200 - 500 Coins per survey.'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2 rounded-xl border border-indigo-500/20 self-start sm:self-auto">
            <Coins className="w-4 h-4 text-amber-400 animate-bounce" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-medium">Average Reward</span>
              <span className="text-xs font-black text-amber-300">250 - 450 Coins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {SURVEY_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-indigo-600 text-white border border-indigo-400 shadow-md shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={language === 'bn' ? 'সার্ভে খুঁজুন (যেমন: AI, Banking, Shopping)...' : 'Search 100,000+ surveys...'}
          className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
        />
      </div>

      {/* Survey Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredSurveys.map((survey) => {
          const isClaimed = claimedSurveys.includes(survey.id);
          const title = language === 'bn' ? survey.titleBn : survey.title;

          return (
            <div
              key={survey.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 shadow-md ${
                isClaimed 
                  ? 'bg-slate-900/40 border-slate-800 opacity-80' 
                  : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800 hover:border-indigo-500/40'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[9px] uppercase font-black px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    {survey.category}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-amber-400 font-bold">
                    <Star className="w-3 h-3 fill-current" />
                    <span>{survey.rating}</span>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-white line-clamp-2">
                  {title}
                </h3>

                <div className="flex items-center gap-3 text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>~{survey.estimatedMinutes} mins</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-slate-500" />
                    <span className="truncate max-w-[110px]">{survey.sponsorName}</span>
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-black text-amber-400 block">
                    +{survey.rewardCoins} Coins
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold block">
                    ₹{survey.rewardRupees.toFixed(2)}
                  </span>
                </div>

                {isClaimed ? (
                  <button
                    disabled
                    className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'সংগৃহীত' : 'Completed'}</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleStartSurvey(survey)}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer active:scale-95 transition-all shadow-md shadow-indigo-600/30"
                  >
                    <span>{language === 'bn' ? 'সার্ভে শুরু করুন' : 'Start Survey'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Survey Taker Modal */}
      {activeSurvey && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-5 sm:p-6 space-y-4 shadow-2xl relative animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 px-2 py-0.5 rounded-md bg-indigo-500/10 border border-indigo-500/20">
                  {activeSurvey.category} • +{activeSurvey.rewardCoins} Coins
                </span>
                <h3 className="text-base font-black text-white mt-1">
                  {language === 'bn' ? activeSurvey.titleBn : activeSurvey.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveSurvey(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            {!isCompleted ? (
              <div className="space-y-4">
                {/* Progress bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold">
                    <span>
                      {language === 'bn' ? 'প্রশ্ন' : 'Question'} {currentQuestionIndex + 1} / {activeSurvey.questions.length}
                    </span>
                    <span>
                      {Math.round(((currentQuestionIndex + 1) / activeSurvey.questions.length) * 100)}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
                      style={{ width: `${((currentQuestionIndex + 1) / activeSurvey.questions.length) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Current Question */}
                {currentQ && (
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                    <h4 className="text-sm font-bold text-slate-100">
                      {language === 'bn' ? currentQ.questionBn : currentQ.question}
                    </h4>

                    {/* Single choice options */}
                    {currentQ.type === 'single' && currentQ.options && (
                      <div className="space-y-2 pt-1">
                        {currentQ.options.map((opt, idx) => {
                          const optLabel = language === 'bn' && currentQ.optionsBn ? currentQ.optionsBn[idx] : opt;
                          const isSelected = answers[currentQ.id] === opt;
                          return (
                            <button
                              key={idx}
                              onClick={() => handleSelectAnswer(currentQ.id, opt)}
                              className={`w-full text-left p-3 rounded-xl border text-xs font-semibold transition-all flex items-center justify-between cursor-pointer ${
                                isSelected
                                  ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-sm'
                                  : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:bg-slate-800'
                              }`}
                            >
                              <span>{optLabel}</span>
                              <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ml-2 ${
                                isSelected ? 'border-indigo-400 bg-indigo-500 text-white' : 'border-slate-600'
                              }`}>
                                {isSelected && <Check className="w-2.5 h-2.5" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Rating 1 to 5 */}
                    {currentQ.type === 'rating' && (
                      <div className="flex items-center justify-center gap-2 py-3">
                        {[1, 2, 3, 4, 5].map((star) => {
                          const isSelected = (answers[currentQ.id] || 0) >= star;
                          return (
                            <button
                              key={star}
                              onClick={() => handleSelectAnswer(currentQ.id, star)}
                              className="p-2 transition-transform hover:scale-125 cursor-pointer"
                            >
                              <Star className={`w-8 h-8 ${isSelected ? 'text-amber-400 fill-current' : 'text-slate-600'}`} />
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* Footer Controls */}
                <div className="pt-2 flex items-center justify-end">
                  <button
                    disabled={!hasAnsweredCurrent}
                    onClick={handleNextQuestion}
                    className={`px-5 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 transition-all cursor-pointer ${
                      hasAnsweredCurrent
                        ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <span>{isLastQuestion ? (language === 'bn' ? 'সার্ভে জমা দিন ও কয়েন নিন' : 'Submit & Claim Reward') : (language === 'bn' ? 'পরবর্তী প্রশ্ন' : 'Next Question')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              /* Success / Claimed View */
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-3xl shadow-xl shadow-emerald-500/20">
                  🎉
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-black text-white">
                    {language === 'bn' ? 'সার্ভে সফলভাবে সম্পন্ন হয়েছে!' : 'Survey Completed Successfully!'}
                  </h3>
                  <p className="text-xs text-slate-300">
                    {language === 'bn'
                      ? `অভিনন্দন! আপনার ওয়ালেটে +${activeSurvey.rewardCoins} কয়েন যোগ হয়েছে।`
                      : `Congratulations! +${activeSurvey.rewardCoins} Coins have been added to your balance.`}
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950 border border-emerald-500/30 max-w-xs mx-auto flex items-center justify-center gap-3">
                  <Coins className="w-6 h-6 text-amber-400 animate-bounce" />
                  <div className="text-left">
                    <span className="text-[10px] text-slate-400 block font-bold">Reward Credited</span>
                    <span className="text-sm font-black text-amber-300">+{activeSurvey.rewardCoins} Coins (₹{activeSurvey.rewardRupees.toFixed(2)})</span>
                  </div>
                </div>

                <button
                  onClick={() => setActiveSurvey(null)}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs cursor-pointer shadow-lg shadow-emerald-600/30"
                >
                  {language === 'bn' ? 'পরবর্তী সার্ভে দেখুন' : 'Explore More Surveys'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
