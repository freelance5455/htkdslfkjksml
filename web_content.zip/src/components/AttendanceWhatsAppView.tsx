import React, { useState } from 'react';
import { ClassInfo, Language, Student } from '../types';
import { translations, getAbsentWhatsappMessage, formatWhatsappUrl } from '../utils/translations';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  MessageCircle,
  Send,
  AlertCircle,
  Copy,
  ExternalLink,
  Users,
  Check
} from 'lucide-react';

interface AttendanceWhatsAppViewProps {
  students: Student[];
  classes: ClassInfo[];
  lang: Language;
  onUpdateAttendance: (studentId: string, date: string, status: 'present' | 'absent' | 'leave') => void;
  onMarkWhatsappSent: (studentId: string, date: string) => void;
}

export const AttendanceWhatsAppView: React.FC<AttendanceWhatsAppViewProps> = ({
  students,
  classes,
  lang,
  onUpdateAttendance,
  onMarkWhatsappSent,
}) => {
  const t = translations[lang];

  // Default to today
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [previewModalStudent, setPreviewModalStudent] = useState<Student | null>(null);
  const [copiedMessage, setCopiedMessage] = useState(false);

  const selectedClass = classes.find((c) => c.id === selectedClassId);
  const classStudents = students.filter((s) => s.classId === selectedClassId && !s.isGraduated);

  const getStudentStatusForDate = (student: Student, date: string) => {
    const record = student.attendanceHistory?.find((r) => r.date === date);
    return record ? record.status : 'present';
  };

  const isWhatsappSentForDate = (student: Student, date: string) => {
    const record = student.attendanceHistory?.find((r) => r.date === date);
    return !!record?.notifiedWhatsApp;
  };

  const handleStatusChange = (student: Student, newStatus: 'present' | 'absent' | 'leave') => {
    onUpdateAttendance(student.id, selectedDate, newStatus);
    // If student is marked absent, automatically prompt the WhatsApp alert preview
    if (newStatus === 'absent') {
      setPreviewModalStudent(student);
    }
  };

  const generateMessageForStudent = (student: Student) => {
    const className = selectedClass
      ? lang === 'ps'
        ? selectedClass.namePs
        : lang === 'ur'
        ? selectedClass.nameUr
        : selectedClass.nameEn
      : 'Class';

    return getAbsentWhatsappMessage(
      lang,
      student.name,
      student.fatherName,
      className,
      selectedDate
    );
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 2000);
  };

  const absentStudents = classStudents.filter(
    (s) => getStudentStatusForDate(s, selectedDate) === 'absent'
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Instant Parent WhatsApp Absence Alerts</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t.navAttendance}
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {lang === 'ps'
              ? 'هره ورځ د ټولګي حاضري ثبت کړئ. که زده کوونکی غیر حاضر و، په هماغه شیبه د هغه پلار ته په واټس‌اپ رسمي خبرتیا واستوئ.'
              : lang === 'ur'
              ? 'روزانہ کی بنیاد پر حاضری لگائیں۔ غیر حاضر ہونے کی صورت میں طالب علم کے والد کو فوری طور پر واٹس ایپ الرٹ ارسال کریں۔'
              : 'Record daily attendance. When a student is absent, instantly notify the father via WhatsApp with a pre-formatted message.'}
          </p>
        </div>

        {/* Date and Class Selector Controls */}
        <div className="bg-slate-800/80 p-4 rounded-2xl border border-emerald-500/30 flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              {t.selectDate}
            </label>
            <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-2 rounded-xl border border-slate-700 text-xs">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-transparent text-white outline-none font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              {t.classEnrolled}
            </label>
            <select
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="bg-slate-900 text-white border border-slate-700 text-xs px-3 py-2 rounded-xl font-bold outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nameEn} ({c.startTime} - {c.endTime})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Class Overview Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block uppercase">
              {lang === 'ps' ? 'په ټولګي کې ټول زده کوونکي' : lang === 'ur' ? 'کلاس میں کل طلباء' : 'Enrolled Students'}
            </span>
            <span className="text-2xl font-black text-slate-900">{classStudents.length}</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block uppercase">
              {lang === 'ps' ? 'نن حاضر زده کوونکي' : lang === 'ur' ? 'آج حاضر طلباء' : 'Present Today'}
            </span>
            <span className="text-2xl font-black text-emerald-600">
              {classStudents.filter((s) => getStudentStatusForDate(s, selectedDate) === 'present').length}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 block uppercase">
              {lang === 'ps' ? 'غیر حاضر (واټس‌اپ اړین)' : lang === 'ur' ? 'غیر حاضر (واٹس ایپ درکار)' : 'Absent (Requires Alert)'}
            </span>
            <span className="text-2xl font-black text-rose-600">
              {absentStudents.length}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Attendance Roster Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <h3 className="text-base font-extrabold text-slate-900">
              {selectedClass ? (lang === 'ps' ? selectedClass.namePs : lang === 'ur' ? selectedClass.nameUr : selectedClass.nameEn) : 'Class'} - {selectedDate}
            </h3>
            <p className="text-xs text-slate-500">
              {selectedClass?.startTime} - {selectedClass?.endTime} | {selectedClass?.instructorName}
            </p>
          </div>

          {absentStudents.length > 0 && (
            <div className="bg-rose-50 text-rose-800 border border-rose-200 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <span>
                {absentStudents.length} {lang === 'ps' ? 'زده کوونکي غیر حاضر دي' : lang === 'ur' ? 'طلباء غیر حاضر ہیں' : 'students are absent today'}
              </span>
            </div>
          )}
        </div>

        <div className="divide-y divide-slate-100 overflow-x-auto">
          {classStudents.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No students enrolled in this class yet.
            </div>
          ) : (
            classStudents.map((student) => {
              const currentStatus = getStudentStatusForDate(student, selectedDate);
              const isAbsent = currentStatus === 'absent';
              const isNotified = isWhatsappSentForDate(student, selectedDate);

              return (
                <div
                  key={student.id}
                  className={`p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors ${
                    isAbsent ? 'bg-rose-50/40' : 'hover:bg-slate-50/60'
                  }`}
                >
                  {/* Student Photo & Details */}
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={student.photoUrl}
                      alt={student.name}
                      className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-200 bg-slate-100 shrink-0"
                    />
                    <div>
                      <h4 className="text-sm font-extrabold text-slate-900 truncate">
                        {student.name}
                      </h4>
                      <p className="text-xs text-slate-500 truncate">
                        <span className="text-slate-400">{t.fatherName}:</span> {student.fatherName}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-600">
                        <span>
                          {t.daysAttended}: <strong>{student.monthlyAttendancePresentDays} / {student.monthlyTotalWorkingDays}</strong>
                        </span>
                        <span className="text-slate-300">•</span>
                        <span className="text-emerald-700 font-semibold">{student.whatsappNumber}</span>
                      </div>
                    </div>
                  </div>

                  {/* Attendance Controls */}
                  <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
                    <div className="inline-flex bg-slate-100 p-1 rounded-xl">
                      <button
                        onClick={() => handleStatusChange(student, 'present')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                          currentStatus === 'present'
                            ? 'bg-emerald-600 text-white shadow'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.present}</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(student, 'absent')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                          currentStatus === 'absent'
                            ? 'bg-rose-600 text-white shadow animate-pulse'
                            : 'text-slate-600 hover:text-rose-700'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>{t.absent}</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(student, 'leave')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                          currentStatus === 'leave'
                            ? 'bg-amber-500 text-white shadow'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>{t.leave}</span>
                      </button>
                    </div>

                    {/* Instant WhatsApp Action when Absent */}
                    {isAbsent && (
                      <button
                        onClick={() => setPreviewModalStudent(student)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition shadow-md flex items-center gap-1.5 ${
                          isNotified
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white animate-bounce'
                        }`}
                        title="Send instant WhatsApp message to father"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>{isNotified ? t.whatsappSent : t.sendWhatsappAlert}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* WhatsApp Absence Alert Preview Modal */}
      {previewModalStudent && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-emerald-600" />
                {t.instantAlertHeading}
              </h3>
              <button
                onClick={() => setPreviewModalStudent(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="bg-emerald-50 border border-emerald-200/80 p-3 rounded-2xl flex items-center gap-3">
              <img
                src={previewModalStudent.photoUrl}
                alt={previewModalStudent.name}
                className="w-12 h-12 rounded-xl object-cover ring-2 ring-emerald-500 shrink-0"
              />
              <div className="text-xs">
                <div className="font-extrabold text-slate-900 text-sm">
                  {previewModalStudent.name}
                </div>
                <div className="text-slate-600">
                  {t.fatherName}: <strong>{previewModalStudent.fatherName}</strong>
                </div>
                <div className="text-emerald-800 font-semibold mt-0.5">
                  WhatsApp: {previewModalStudent.whatsappNumber}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.whatsappDirectNotice}
              </label>
              <div className="bg-slate-900 text-emerald-300 p-4 rounded-2xl text-xs font-mono whitespace-pre-wrap leading-relaxed border border-slate-800 max-h-48 overflow-y-auto">
                {generateMessageForStudent(previewModalStudent)}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t">
              <button
                onClick={() => handleCopy(generateMessageForStudent(previewModalStudent))}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
              >
                {copiedMessage ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copiedMessage ? 'Copied!' : t.copyMessage}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewModalStudent(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  {t.cancel}
                </button>

                <a
                  href={formatWhatsappUrl(
                    previewModalStudent.whatsappNumber,
                    generateMessageForStudent(previewModalStudent)
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    onMarkWhatsappSent(previewModalStudent.id, selectedDate);
                    setPreviewModalStudent(null);
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-700/30 transition"
                >
                  <Send className="w-4 h-4" />
                  <span>{t.openWhatsApp}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
