import React, { useState, useEffect, useRef } from 'react';
import { RotateCw, RefreshCw, Smartphone, Maximize2, Minimize2, Wifi, Battery, Volume2 } from 'lucide-react';

interface DeviceSimulatorProps {
  previewUrl: string;
  appName: string;
  orientation: 'portrait' | 'landscape' | 'sensor';
  fullscreen: boolean;
}

export const DeviceSimulator: React.FC<DeviceSimulatorProps> = ({
  previewUrl,
  appName,
  orientation,
  fullscreen,
}) => {
  const [currentOrientation, setCurrentOrientation] = useState<'portrait' | 'landscape'>(
    orientation === 'landscape' ? 'landscape' : 'portrait'
  );
  const [iframeKey, setIframeKey] = useState(0);
  const [currentTime, setCurrentTime] = useState('');
  const [isImmersive, setIsImmersive] = useState(fullscreen);

  useEffect(() => {
    setIsImmersive(fullscreen);
  }, [fullscreen]);

  useEffect(() => {
    if (orientation === 'landscape') {
      setCurrentOrientation('landscape');
    } else if (orientation === 'portrait') {
      setCurrentOrientation('portrait');
    }
  }, [orientation]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
          hour12: false,
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 30000);
    return () => clearInterval(timer);
  }, []);

  const toggleOrientation = () => {
    setCurrentOrientation((prev) => (prev === 'portrait' ? 'landscape' : 'portrait'));
  };

  const reloadIframe = () => {
    setIframeKey((prev) => prev + 1);
  };

  const isPortrait = currentOrientation === 'portrait';

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-slate-900/40 border border-slate-800 rounded-2xl w-full">
      {/* Simulator Control Toolbar */}
      <div className="w-full flex items-center justify-between pb-3 mb-4 border-b border-slate-800 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white truncate max-w-[140px]">{appName || 'Android App'}</span>
          <span className="text-slate-600">·</span>
          <span className="font-mono text-[11px] text-slate-500">
            {isPortrait ? '390 × 780' : '780 × 390'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={toggleOrientation}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"
            title="Rotate Device Orientation"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px] capitalize">{currentOrientation}</span>
          </button>
          <button
            onClick={reloadIframe}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Reload App WebView"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsImmersive((prev) => !prev)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title={isImmersive ? 'Exit Fullscreen' : 'Enter Immersive Mode'}
          >
            {isImmersive ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Android Device Mockup Frame */}
      <div
        className={`relative transition-all duration-300 ease-out bg-slate-950 border-[6px] border-slate-800 rounded-[38px] shadow-2xl shadow-black/80 flex flex-col overflow-hidden ${
          isPortrait ? 'w-[360px] h-[680px]' : 'w-[680px] h-[360px]'
        }`}
      >
        {/* Status Bar (hidden in immersive mode) */}
        {!isImmersive && (
          <div className="h-7 bg-slate-950 px-5 flex items-center justify-between text-[11px] font-mono text-slate-300 shrink-0 select-none z-10 border-b border-slate-900">
            <span>{currentTime || '10:00'}</span>

            {/* Camera Punch Hole */}
            <div className="w-3.5 h-3.5 bg-black rounded-full border border-slate-800 shrink-0" />

            <div className="flex items-center gap-1.5 text-slate-400">
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Live WebView Iframe Content */}
        <div className="relative flex-1 bg-black overflow-hidden">
          {previewUrl ? (
            <iframe
              key={iframeKey}
              src={previewUrl}
              title="Android App Preview"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              className="w-full h-full border-0 select-none"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-slate-500">
              <Smartphone className="w-10 h-10 mb-2 opacity-40 text-emerald-400" />
              <p className="text-xs">No web assets loaded yet.</p>
              <p className="text-[11px] mt-1 text-slate-600">
                Upload a ZIP, paste HTML, or choose a Quick Demo to preview.
              </p>
            </div>
          )}
        </div>

        {/* Bottom Android Navigation Bar (gesture bar or 3-button) */}
        {!isImmersive && (
          <div className="h-4 bg-slate-950 flex items-center justify-center shrink-0 z-10">
            <div className="w-28 h-1 bg-slate-700 rounded-full" />
          </div>
        )}
      </div>

      <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
        <span className="font-mono">file:///android_asset/www/index.html</span>
        <span>·</span>
        <span className="text-emerald-500">Sandbox Active</span>
      </div>
    </div>
  );
};
