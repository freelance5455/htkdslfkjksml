import React, { useState } from 'react';
import { ClassInfo, Language, Student } from '../types';
import { translations } from '../utils/translations';
import {
  DollarSign,
  CheckCircle2,
  XCircle,
  Printer,
  Search,
  Filter,
  Check,
  Calendar,
  CreditCard,
  FileText
} from 'lucide-react';

interface FeeTrackerViewProps {
  students: Student[];
  classes: ClassInfo[];
  lang: Language;
  onToggleFeeStatus: (studentId: string) => void;
}

export const FeeTrackerView: React.FC<FeeTrackerViewProps> = ({
  students,
  classes,
  lang,
  onToggleFeeStatus,
}) => {
  const t = translations[lang];

  const [filterClass, setFilterClass] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'unpaid'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [receiptStudent, setReceiptStudent] = useState<Student | null>(null);

  const classMap = new Map<string, ClassInfo>();
  classes.forEach((c) => classMap.set(c.id, c));

  const filteredStudents = students.filter((s) => {
    if (s.isGraduated) return false; // active students only
    const matchClass = filterClass === 'all' || s.classId === filterClass;
    const matchStatus = filterStatus === 'all' || s.feeStatus === filterStatus;
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.fatherName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchClass && matchStatus && matchSearch;
  });

  const activeStudents = students.filter((s) => !s.isGraduated);
  const totalTargetFee = activeStudents.reduce((acc, s) => acc + s.feeAmount, 0);
  const totalCollectedFee = activeStudents
    .filter((s) => s.feeStatus === 'paid')
    .reduce((acc, s) => acc + s.feeAmount, 0);
  const totalPendingFee = totalTargetFee - totalCollectedFee;
  const collectionRate = totalTargetFee > 0 ? Math.round((totalCollectedFee / totalTargetFee) * 100) : 0;

  const handlePrintReceipt = (student: Student) => {
    setReceiptStudent(student);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase block">
              {lang === 'ps' ? 'مجموعي هدف (فیسونه)' : lang === 'ur' ? 'کل متوقع فیس' : 'Monthly Fee Target'}
            </span>
            <span className="text-xl font-black text-slate-900">
              PKR {totalTargetFee.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {activeStudents.length} {lang === 'ps' ? 'زده کوونکي' : lang === 'ur' ? 'طلباء' : 'Students'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase block">
              {t.feesCollected}
            </span>
            <span className="text-xl font-black text-emerald-600">
              PKR {totalCollectedFee.toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
              ✅ {activeStudents.filter((s) => s.feeStatus === 'paid').length} {t.paid}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase block">
              {t.feesPending}
            </span>
            <span className="text-xl font-black text-rose-600">
              PKR {totalPendingFee.toLocaleString()}
            </span>
            <span className="text-[10px] text-rose-600 font-bold block mt-0.5">
              ❌ {activeStudents.filter((s) => s.feeStatus === 'unpaid').length} {t.unpaid}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <XCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase block">
              {lang === 'ps' ? 'د راټولېدو سلنه' : lang === 'ur' ? 'وصولی کی شرح' : 'Collection Rate'}
            </span>
            <span className="text-xl font-black text-blue-600">
              {collectionRate}%
            </span>
            <div className="w-24 bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${collectionRate}%` }}
              />
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <CreditCard className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-xs px-3 py-2 rounded-xl font-bold outline-none"
          >
            <option value="all">{t.allClasses}</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nameEn} (PKR {c.monthlyFeePkr})
              </option>
            ))}
          </select>

          <div className="inline-flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filterStatus === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterStatus('paid')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filterStatus === 'paid' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600'
              }`}
            >
              {t.paidMark}
            </button>
            <button
              onClick={() => setFilterStatus('unpaid')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filterStatus === 'unpaid' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-600'
              }`}
            >
              {t.unpaidMark}
            </button>
          </div>
        </div>
      </div>

      {/* Fees Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-extrabold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Student / Father</th>
                <th className="px-4 py-3.5">Class / Schedule</th>
                <th className="px-4 py-3.5">Monthly Fee</th>
                <th className="px-4 py-3.5 text-center">Status (✅ / ❌)</th>
                <th className="px-4 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400">
                    No student records found matching this fee filter.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student) => {
                  const studentClass = classMap.get(student.classId);
                  const isPaid = student.feeStatus === 'paid';

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition">
                      {/* Name & Photo */}
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={student.photoUrl}
                            alt={student.name}
                            className="w-10 h-10 rounded-xl object-cover bg-slate-100 ring-1 ring-slate-200 shrink-0"
                          />
                          <div>
                            <span className="font-extrabold text-slate-900 block">
                              {student.name}
                            </span>
                            <span className="text-slate-500 text-[11px]">
                              {t.fatherName}: {student.fatherName}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Class */}
                      <td className="px-4 py-3.5">
                        <span className="font-bold text-slate-800 block">
                          {studentClass?.nameEn || 'Class'}
                        </span>
                        <span className="text-slate-400 text-[10px]">
                          {studentClass?.startTime} - {studentClass?.endTime}
                        </span>
                      </td>

                      {/* Fee Amount */}
                      <td className="px-4 py-3.5 font-black text-slate-900 text-sm">
                        PKR {student.feeAmount.toLocaleString()}
                      </td>

                      {/* Status Badge & Toggle */}
                      <td className="px-4 py-3.5 text-center">
                        <button
                          onClick={() => onToggleFeeStatus(student.id)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black shadow-sm transition hover:scale-105 ${
                            isPaid
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-rose-100 text-rose-800 border border-rose-300'
                          }`}
                          title="Click to toggle status"
                        >
                          {isPaid ? (
                            <>
                              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                              <span>{t.paidMark}</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-4 h-4 text-rose-600" />
                              <span>{t.unpaidMark}</span>
                            </>
                          )}
                        </button>
                      </td>

                      {/* Print Slip */}
                      <td className="px-4 py-3.5 text-right">
                        <button
                          onClick={() => handlePrintReceipt(student)}
                          className="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-xl text-xs transition shadow-sm"
                        >
                          <Printer className="w-3.5 h-3.5 text-slate-600" />
                          <span>{t.printSlip}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Printable Receipt Modal (Hidden on normal screen, triggers window.print()) */}
      {receiptStudent && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 printable-receipt">
            <div className="text-center border-b pb-4">
              <h2 className="text-xl font-black text-emerald-800 tracking-wide uppercase">
                Rahbar English Center
              </h2>
              <p className="text-xs text-slate-600 font-medium">Trat, Pishin, Balochistan | Tel: +92 312 3456789</p>
              <div className="mt-2 inline-block bg-slate-900 text-white text-[10px] uppercase font-bold tracking-widest px-3 py-0.5 rounded-full">
                Official Fee Receipt Slip
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">Receipt No:</span>
                <span className="font-bold text-slate-900">REC-2026-{receiptStudent.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">{t.studentName}:</span>
                <span className="font-bold text-slate-900">{receiptStudent.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">{t.fatherName}:</span>
                <span className="font-bold text-slate-900">{receiptStudent.fatherName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">{t.classEnrolled}:</span>
                <span className="font-bold text-slate-900">
                  {classMap.get(receiptStudent.classId)?.nameEn || 'Class'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">Fee Amount:</span>
                <span className="font-extrabold text-slate-900 text-sm">PKR {receiptStudent.feeAmount}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-slate-200">
                <span className="text-slate-500 font-medium">Payment Status:</span>
                <span className={`font-black ${receiptStudent.feeStatus === 'paid' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {receiptStudent.feeStatus === 'paid' ? 'PAID ✅' : 'UNPAID ❌'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Date:</span>
                <span className="font-bold text-slate-900">{new Date().toLocaleDateString()}</span>
              </div>
            </div>

            <div className="pt-6 flex justify-between items-end border-t border-slate-200 text-[10px] text-slate-400">
              <div className="text-center">
                <div className="w-24 border-b border-slate-400 mb-1" />
                <span>Student / Guardian</span>
              </div>
              <div className="text-center">
                <div className="w-24 border-b border-slate-400 mb-1" />
                <span>Cashier / Principal</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t no-print">
              <button
                onClick={() => setReceiptStudent(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Slip</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
