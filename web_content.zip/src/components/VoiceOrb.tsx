import React, { useId } from 'react';
import { AssistantState, VoiceGender } from '../types';

interface VoiceOrbProps {
  state: AssistantState;
  micVolume: number; // 0 to 1
  speakerVolume: number; // 0 to 1
  isCallActive: boolean;
  onCircleClick: () => void;
  characterGender: VoiceGender;
  liveTranscriptionText?: string;
  isMuted?: boolean;
}

export const VoiceOrb: React.FC<VoiceOrbProps> = ({
  state,
  micVolume,
  speakerVolume,
  isCallActive,
  onCircleClick,
  characterGender,
  liveTranscriptionText,
  isMuted,
}) => {
  const isSpeaking = state === 'speaking';
  const isListening = state === 'listening';
  const isProcessing = state === 'thinking';
  const isInterrupted = state === 'interrupted';

  // Active audio volume from real stream (mic while listening, speaker while speaking)
  const activeVolume = isSpeaking
    ? Math.min(1, speakerVolume * 1.3)
    : isListening && !isMuted
    ? Math.min(1, micVolume * 1.4)
    : 0;

  // Dynamic transforms based on actual audio amplitude
  const coreScale = 1 + activeVolume * 0.18;
  const ring1Scale = 1 + activeVolume * 0.35;
  const ring2Scale = 1 + activeVolume * 0.55;
  const ring3Scale = 1 + activeVolume * 0.75;
  const ring4Scale = 1 + activeVolume * 0.95;

  // 32-segment live audio spectrum bars
  const totalSpectrumBars = 32;
  const spectrumBars = Array.from({ length: totalSpectrumBars }, (_, i) => {
    // Generate curved spectrum height from center outward
    const normalizedPos = Math.abs(i - totalSpectrumBars / 2) / (totalSpectrumBars / 2);
    const weight = Math.cos(normalizedPos * Math.PI * 0.5);
    const jitter = ((i * 7) % 5) * 0.12;
    const baseHeight = 4;
    const dynamicHeight = activeVolume > 0.03
      ? baseHeight + activeVolume * 36 * (weight + jitter)
      : isCallActive && isSpeaking
      ? 14 * weight
      : isCallActive
      ? 5
      : 3;
    return Math.max(3, Math.min(42, dynamicHeight));
  });

  // State label and colors
  let statusBadgeText = 'AI Core Ready';
  let statusBadgeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-950/40';
  let primaryGlow = 'rgba(16, 185, 129, 0.45)';
  let cyanGlow = 'rgba(6, 182, 212, 0.4)';

  if (!isCallActive) {
    statusBadgeText = 'Tap Start Call to Connect';
    statusBadgeColor = 'text-emerald-400/80 border-emerald-500/20 bg-slate-900/60';
    primaryGlow = 'rgba(16, 185, 129, 0.25)';
    cyanGlow = 'rgba(6, 182, 212, 0.2)';
  } else if (isSpeaking) {
    statusBadgeText = 'Blame is Speaking';
    statusBadgeColor = 'text-cyan-300 border-cyan-400/40 bg-cyan-950/60 animate-pulse';
    primaryGlow = 'rgba(6, 182, 212, 0.6)';
    cyanGlow = 'rgba(16, 185, 129, 0.5)';
  } else if (isListening) {
    statusBadgeText = isMuted
      ? 'Microphone Muted'
      : activeVolume > 0.05
      ? 'Receiving Your Voice'
      : 'Listening to You...';
    statusBadgeColor = 'text-emerald-300 border-emerald-400/40 bg-emerald-950/60';
    primaryGlow = 'rgba(16, 185, 129, 0.65)';
    cyanGlow = 'rgba(52, 211, 153, 0.45)';
  } else if (isProcessing) {
    statusBadgeText = 'Processing Request...';
    statusBadgeColor = 'text-teal-300 border-teal-400/40 bg-teal-950/60';
    primaryGlow = 'rgba(20, 184, 166, 0.6)';
    cyanGlow = 'rgba(6, 182, 212, 0.5)';
  } else if (isInterrupted) {
    statusBadgeText = 'Interrupted';
    statusBadgeColor = 'text-amber-400 border-amber-500/40 bg-amber-950/60';
    primaryGlow = 'rgba(245, 158, 11, 0.5)';
  }

  const gradientId1 = useId();
  const gradientId2 = useId();

  return (
    <div className="flex flex-col items-center justify-center w-full px-4 py-2 select-none">
      {/* Listening / Status Pill */}
      <div
        className={`inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-semibold border backdrop-blur-md shadow-xs transition-all duration-300 ${statusBadgeColor} mb-2`}
      >
        <span className="relative flex h-2 w-2">
          {isCallActive && (
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          )}
          <span
            className={`relative inline-flex rounded-full h-2 w-2 ${
              !isCallActive
                ? 'bg-emerald-500/70'
                : isSpeaking
                ? 'bg-cyan-400'
                : 'bg-emerald-400'
            }`}
          />
        </span>
        <span className="tracking-wider uppercase text-[10px] font-mono font-bold">
          {statusBadgeText}
        </span>
      </div>

      {/* Prominent Large Speech Text ("Bada bada likha hai") */}
      {liveTranscriptionText ? (
        <div className="w-full max-w-sm px-4 py-3 mb-3 rounded-2xl bg-slate-900/90 border border-emerald-500/30 shadow-xl backdrop-blur-md text-center transition-all animate-in fade-in">
          <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400/80 block mb-1">
            {isSpeaking ? 'BLAME IS SAYING' : 'YOU SAID'}
          </span>
          <p
            className={`text-base sm:text-lg font-extrabold tracking-tight leading-snug ${
              isSpeaking ? 'text-cyan-200' : 'text-emerald-300'
            }`}
          >
            "{liveTranscriptionText}"
          </p>
        </div>
      ) : (
        <div className="h-8 mb-2 flex items-center justify-center text-xs text-slate-400 font-medium font-mono">
          {isCallActive
            ? isSpeaking
              ? 'Transmitting speech...'
              : 'Speak naturally in any language'
            : 'AI Voice Core Standby'}
        </div>
      )}

      {/* NEXT-GENERATION AI VOICE CORE INTERFACE */}
      <div className="relative flex items-center justify-center w-72 h-72 sm:w-80 sm:h-80 my-1">
        {/* Ambient Dark Emerald Void Aura */}
        <div
          className="absolute rounded-full transition-all duration-300 pointer-events-none filter blur-2xl"
          style={{
            width: '280px',
            height: '280px',
            background: `radial-gradient(circle, ${primaryGlow} 0%, ${cyanGlow} 40%, rgba(2, 44, 34, 0.2) 70%, transparent 100%)`,
            transform: `scale(${ring3Scale})`,
            opacity: isCallActive ? 0.85 : 0.45,
          }}
        />

        {/* Outer Ring 4: Holographic Cyan/Emerald Perimeter Orbit */}
        <div
          className="absolute rounded-full border border-cyan-500/20 pointer-events-none transition-transform duration-200 ease-out"
          style={{
            width: '286px',
            height: '286px',
            transform: `scale(${ring4Scale}) rotate(${isCallActive ? '45deg' : '0deg'})`,
          }}
        >
          {/* Micro Orbit Node */}
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#06b6d4]" />
        </div>

        {/* Outer Ring 3: Concentric Holographic Dashed Ring */}
        <div
          className="absolute rounded-full border border-dashed border-emerald-400/40 pointer-events-none transition-transform duration-200 ease-out animate-[spin_30s_linear_infinite]"
          style={{
            width: '256px',
            height: '256px',
            transform: `scale(${ring3Scale})`,
            boxShadow: `0 0 15px -3px ${primaryGlow}`,
          }}
        />

        {/* Outer Ring 2: Subtle Neon Pulse Ring */}
        <div
          className="absolute rounded-full border border-emerald-400/50 pointer-events-none transition-transform duration-150 ease-out"
          style={{
            width: '224px',
            height: '224px',
            transform: `scale(${ring2Scale})`,
            boxShadow: `inset 0 0 12px ${primaryGlow}, 0 0 12px ${primaryGlow}`,
          }}
        />

        {/* Outer Ring 1: Scanning / Radar Ring */}
        <div
          className={`absolute rounded-full border border-cyan-400/60 pointer-events-none transition-transform duration-100 ease-out ${
            isProcessing ? 'animate-spin' : ''
          }`}
          style={{
            width: '194px',
            height: '194px',
            transform: `scale(${ring1Scale})`,
          }}
        />

        {/* Central Dimensional AI Energy Core */}
        <button
          onClick={onCircleClick}
          aria-label={isSpeaking ? 'Interrupt Blame' : 'AI Voice Core'}
          className="group relative z-10 w-44 h-44 sm:w-48 sm:h-48 rounded-full flex flex-col items-center justify-center cursor-pointer transition-transform duration-150 active:scale-95 focus:outline-hidden"
          style={{
            transform: `scale(${coreScale})`,
          }}
        >
          {/* Outer Glass Bezel */}
          <div className="absolute inset-0 rounded-full p-[3px] bg-gradient-to-tr from-emerald-500 via-cyan-400 to-emerald-600 shadow-[0_0_30px_rgba(16,185,129,0.35)]">
            <div className="w-full h-full rounded-full bg-black/90 backdrop-blur-md relative overflow-hidden flex flex-col items-center justify-center">
              
              {/* Internal Holographic Grid Texture */}
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage:
                    'radial-gradient(circle at center, rgba(16, 185, 129, 0.4) 1px, transparent 1px)',
                  backgroundSize: '16px 16px',
                }}
              />

              {/* Glowing Inner Core Sphere */}
              <div
                className="absolute w-28 h-28 rounded-full transition-all duration-300 filter blur-xs"
                style={{
                  background: isSpeaking
                    ? 'radial-gradient(circle, #06b6d4 0%, #047857 50%, transparent 75%)'
                    : isListening
                    ? 'radial-gradient(circle, #10b981 0%, #064e3b 60%, transparent 80%)'
                    : 'radial-gradient(circle, #059669 0%, #022c22 65%, transparent 85%)',
                  opacity: isCallActive ? 0.75 + activeVolume * 0.25 : 0.45,
                  transform: `scale(${1 + activeVolume * 0.25})`,
                }}
              />

              {/* Glass Reflection Arc */}
              <div className="absolute top-2 left-6 w-24 h-12 bg-gradient-to-b from-white/30 via-white/5 to-transparent rounded-full transform -rotate-25 filter blur-xs pointer-events-none" />

              {/* Central Sci-Fi Brand & Voice Type */}
              <div className="relative z-20 flex flex-col items-center text-center px-2">
                <span className="text-[10px] font-mono tracking-widest text-emerald-400 font-bold uppercase drop-shadow-[0_0_8px_#10b981]">
                  AI CORE
                </span>
                <span className="text-xl sm:text-2xl font-black tracking-widest text-white drop-shadow-[0_2px_12px_rgba(0,255,136,0.6)] font-mono">
                  BLAME
                </span>
                <span className="text-[11px] font-semibold text-emerald-300/90 tracking-wide mt-0.5">
                  {characterGender === 'female' ? 'Female Voice' : 'Male Voice'}
                </span>
              </div>

              {/* Scanning Ray effect when processing */}
              {isProcessing && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent animate-[spin_2s_linear_infinite] pointer-events-none" />
              )}
            </div>
          </div>
        </button>
      </div>

      {/* 32-Bar Real-Time Live Audio Waveform Spectrum */}
      <div className="flex items-center justify-center gap-[3px] h-10 px-5 py-1.5 rounded-full bg-slate-900/80 border border-emerald-500/30 shadow-lg backdrop-blur-md mt-2 max-w-xs mx-auto">
        {spectrumBars.map((barHeight, idx) => {
          const isMid = idx >= 10 && idx <= 22;
          return (
            <span
              key={idx}
              className={`w-[3px] rounded-full transition-all duration-75 ${
                isSpeaking
                  ? 'bg-gradient-to-t from-cyan-500 to-teal-300 shadow-[0_0_6px_#06b6d4]'
                  : isListening
                  ? 'bg-gradient-to-t from-emerald-600 to-emerald-300 shadow-[0_0_6px_#10b981]'
                  : 'bg-emerald-900/60'
              }`}
              style={{
                height: `${barHeight}px`,
                opacity: isCallActive ? (activeVolume > 0.02 ? 0.95 : 0.4) : 0.25,
              }}
            />
          );
        })}
      </div>
    </div>
  );
};
