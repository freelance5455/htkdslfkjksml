import { useState, useMemo } from 'react';
import {
  Sparkles,
  X,
  TrendingUp,
  Award,
  DollarSign,
  Ship,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Scale,
  Percent,
} from 'lucide-react';
import { Language } from '../types';
import { playSuccessSound, playKeyTap } from '../utils/audio';

interface AIProfitAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSelectCountry?: (country: string) => void;
}

interface CropOption {
  id: string;
  nameSw: string;
  nameEn: string;
  icon: string;
  defaultTons: number;
  localPricePerKgTsh: number;
  // Per country export FOB/CIF prices in USD per Metric Ton (1000 kg)
  pricesUsdPerMt: {
    china?: number;
    eu?: number;
    us?: number;
    india?: number;
    uae?: number;
  };
  // Specific quality & treaty remarks
  notesSw: string;
  notesEn: string;
}

const CROPS_DATA: CropOption[] = [
  {
    id: 'sesame',
    nameSw: 'Ufuta Mweupe (Sesame Seed 99%)',
    nameEn: 'White Sesame Seeds (99% Purity)',
    icon: '🌱',
    defaultTons: 25,
    localPricePerKgTsh: 3400,
    pricesUsdPerMt: {
      china: 2150, // Huge buyer
      eu: 2280,
      us: 2200,
      india: 1950,
      uae: 2050,
    },
    notesSw: 'China ina makubaliano ya Zero-Tariff 98% kwa ufuta wa Tanzania bila kodi ya forodha. Bandari ya Qingdao inashughulikia tani 60,000+ kila mwezi.',
    notesEn: 'China grants 98% Zero-Tariff preferential protocol for Tanzanian sesame. Qingdao port handles over 60,000 MT monthly with rapid GACC customs clearance.',
  },
  {
    id: 'avocado',
    nameSw: 'Parachichi Hass (Hass Avocado Grade 1)',
    nameEn: 'Hass Avocado (Grade 1 Export)',
    icon: '🥑',
    defaultTons: 22,
    localPricePerKgTsh: 2800,
    pricesUsdPerMt: {
      china: 2850,
      eu: 3450, // EU has highest organic premium
      us: 3100,
      uae: 2600,
    },
    notesSw: 'Ulaya (EU) inatoa faida kubwa zaidi kwa Parachichi zilizothibitishwa na GlobalGAP kupitia bandari ya Rotterdam. China imefungua itifaki mpya ya SPS.',
    notesEn: 'EU offers the highest net margin for GlobalGAP certified Hass avocados via Rotterdam reefer lines. China protocol is now open with direct phytosanitary clearance.',
  },
  {
    id: 'coffee',
    nameSw: 'Kahawa Arabica / Peaberry (Specialty SCA 86+)',
    nameEn: 'Arabica Specialty Coffee (SCA 86+)',
    icon: '☕',
    defaultTons: 19,
    localPricePerKgTsh: 8500,
    pricesUsdPerMt: {
      china: 6800,
      eu: 7800,
      us: 8400, // US specialty roasters pay top dollar
      uae: 7100,
    },
    notesSw: 'Marekani (US) na Ulaya ndio wanunuzi wakuu wa kahawa ya daraja la juu (Specialty). Chini ya mpango wa AGOA nchini Marekani hakuna kodi ya forodha.',
    notesEn: 'The US market pays premium prices for SCA 86+ Peaberry under the AGOA duty-free framework. EU requires EUDR deforestation-free polygon mapping.',
  },
  {
    id: 'cashew',
    nameSw: 'Korosho Zilizobanguliwa (Kernel W240 / W320)',
    nameEn: 'Processed Cashew Kernels (W240 / W320)',
    icon: '🥜',
    defaultTons: 20,
    localPricePerKgTsh: 16000,
    pricesUsdPerMt: {
      china: 8100,
      eu: 8900,
      us: 9200,
      india: 7400,
      uae: 8200,
    },
    notesSw: 'Marekani na Ulaya zinatoa bei nzuri zaidi kwa korosho nyeupe zilizobanguliwa (W240/W320). Hakikisha unyevu uko chini ya 5% na cheti cha ISO 22000.',
    notesEn: 'US and EU offer exceptional premiums for white kernels (W240/W320). Vacuum packing with nitrogen flushing and ISO 22000 mandatory.',
  },
  {
    id: 'soybean',
    nameSw: 'Soya ya Njano (Soybean Non-GMO)',
    nameEn: 'Non-GMO Yellow Soybeans',
    icon: '🌾',
    defaultTons: 50,
    localPricePerKgTsh: 1450,
    pricesUsdPerMt: {
      china: 760, // Enormous volume demand
      eu: 810,
      india: 680,
    },
    notesSw: 'China ndiye mnunuzi namba moja duniani wa soya. Ushuru ni 0% chini ya mikataba ya Tanzania na China, ujazo wa FCL 25-50 MT.',
    notesEn: 'China is the largest global consumer of Tanzanian Non-GMO soybeans with fast sea corridor access to Tianjin and Dalian.',
  },
  {
    id: 'cassava',
    nameSw: 'Mihogo Mkaushwa / Chenga (Dry Cassava Chips)',
    nameEn: 'Dried Cassava Chips / Starch Grade',
    icon: '🥔',
    defaultTons: 50,
    localPricePerKgTsh: 750,
    pricesUsdPerMt: {
      china: 390,
      eu: 410,
      uae: 360,
    },
    notesSw: 'China inanunua mamia ya maelfu ya tani za mihogo mikavu kwa ajili ya wanga na bio-ethanol. Ushuru ni 0% kupitia bandari ya Nanning.',
    notesEn: 'China imports extensive tonnage of Tanzanian dry cassava chips for starch production with zero import tariffs at Nanning and Guangzhou.',
  },
  {
    id: 'pigeonpea',
    nameSw: 'Mbaazi Safi (Toor Dal / Pigeon Peas)',
    nameEn: 'Polished Pigeon Peas (Toor Dal)',
    icon: '🫘',
    defaultTons: 40,
    localPricePerKgTsh: 1950,
    pricesUsdPerMt: {
      india: 1280, // Prime destination
      uae: 1210,
      china: 1150,
    },
    notesSw: 'India ndilo soko kuu la mbaazi duniani chini ya makubaliano ya G2G kati ya Tanzania na India bila vizuizi vya ushuru.',
    notesEn: 'India is the premier global hub for Tanzanian pigeon peas under the bilateral G2G quota memorandum of understanding.',
  },
  {
    id: 'chili',
    nameSw: 'Pilipili Kavu (African Bird\'s Eye Chili)',
    nameEn: 'Dried Bird\'s Eye Chili (SHU 100k+)',
    icon: '🌶️',
    defaultTons: 10,
    localPricePerKgTsh: 9500,
    pricesUsdPerMt: {
      china: 4800,
      eu: 5600,
      us: 5900,
      uae: 5100,
    },
    notesSw: 'Ulaya na Marekani zinanunua pilipili yenye kiwango cha juu cha joto (SHU 100,000+) kwa bei ya juu sana. Hakikisha hakuna aflatoxin.',
    notesEn: 'EU and US pharmaceutical & hot sauce makers buy high Scoville chili with 0% duty. Strict aflatoxin tests required.',
  },
];

// Fixed exchange rate for calculation: 1 USD = 2,620 TZS
const USD_TO_TZS = 2620;

export default function AIProfitAdvisorModal({
  isOpen,
  onClose,
  language,
  onSelectCountry,
}: AIProfitAdvisorModalProps) {
  const isSw = language === 'sw';

  const [selectedCropId, setSelectedCropId] = useState<string>('sesame');
  const [metricTons, setMetricTons] = useState<number>(25);
  const [hasCalculated, setHasCalculated] = useState<boolean>(true);

  const activeCrop = useMemo(() => {
    return CROPS_DATA.find((c) => c.id === selectedCropId) || CROPS_DATA[0];
  }, [selectedCropId]);

  // Comprehensive Net Profit Evaluation across all destination countries
  const analysisResults = useMemo(() => {
    const tons = Math.max(1, metricTons);
    const kg = tons * 1000;
    const containers = Math.ceil(tons / 25); // Standard 25 MT per 40ft container

    // Baseline Local Tanzania Sales (e.g., selling directly at farmgate/local market in Dar/AMCOS)
    const localGrossTsh = kg * activeCrop.localPricePerKgTsh;
    const localTransportTsh = tons * 45000; // inland transit to regional center
    const localNetTsh = localGrossTsh - localTransportTsh;
    const localNetUsd = localNetTsh / USD_TO_TZS;

    const destinations = [
      {
        id: 'china',
        nameSw: 'China 🇨🇳',
        nameEn: 'China 🇨🇳',
        priceUsdPerMt: activeCrop.pricesUsdPerMt.china || 0,
        seaFreightPerContUsd: 1850,
        inspectionPhytoUsd: 350,
        tariffRatePct: 0, // 0% tariff under Bilateral 98% Treaty
        tariffSavedUsd: (activeCrop.pricesUsdPerMt.china || 0) * tons * 0.12, // saved 12% standard duty
        transitDays: 22,
        protocolSw: 'Itifaki ya Zero-Tariff 98% ya Tanzania-China (GACC)',
        protocolEn: 'Tanzania-China 98% Zero-Tariff GACC Protocol',
      },
      {
        id: 'eu',
        nameSw: 'Ulaya (EU) 🇪🇺',
        nameEn: 'European Union 🇪🇺',
        priceUsdPerMt: activeCrop.pricesUsdPerMt.eu || 0,
        seaFreightPerContUsd: 2650,
        inspectionPhytoUsd: 550, // stricter EU MRL & EUDR tests
        tariffRatePct: 0, // EBA 0%
        tariffSavedUsd: (activeCrop.pricesUsdPerMt.eu || 0) * tons * 0.09,
        transitDays: 26,
        protocolSw: 'Mpango wa EU EBA (Everything But Arms) 0% Ushuru',
        protocolEn: 'EU EBA (Everything But Arms) 0% Duty Free Quota',
      },
      {
        id: 'us',
        nameSw: 'Marekani (USA) 🇺🇸',
        nameEn: 'United States 🇺🇸',
        priceUsdPerMt: activeCrop.pricesUsdPerMt.us || 0,
        seaFreightPerContUsd: 3400,
        inspectionPhytoUsd: 480,
        tariffRatePct: 0, // AGOA 0%
        tariffSavedUsd: (activeCrop.pricesUsdPerMt.us || 0) * tons * 0.11,
        transitDays: 31,
        protocolSw: 'Mpango wa AGOA (Uuzaji Bila Ushuru Marekani)',
        protocolEn: 'AGOA Duty-Free Preference Scheme',
      },
      {
        id: 'india',
        nameSw: 'India 🇮🇳',
        nameEn: 'India 🇮🇳',
        priceUsdPerMt: activeCrop.pricesUsdPerMt.india || 0,
        seaFreightPerContUsd: 1100,
        inspectionPhytoUsd: 300,
        tariffRatePct: 0,
        tariffSavedUsd: (activeCrop.pricesUsdPerMt.india || 0) * tons * 0.1,
        transitDays: 12,
        protocolSw: 'Makubaliano Maalum ya Kibiashara Tanzania-India (G2G)',
        protocolEn: 'Bilateral G2G Quota Agreement',
      },
      {
        id: 'uae',
        nameSw: 'Falme za Kiarabu (UAE) 🇦🇪',
        nameEn: 'United Arab Emirates 🇦🇪',
        priceUsdPerMt: activeCrop.pricesUsdPerMt.uae || 0,
        seaFreightPerContUsd: 1350,
        inspectionPhytoUsd: 320,
        tariffRatePct: 0,
        tariffSavedUsd: (activeCrop.pricesUsdPerMt.uae || 0) * tons * 0.05,
        transitDays: 14,
        protocolSw: 'Ushirikiano wa Kiuchumi Tanzania-GCC',
        protocolEn: 'Tanzania-GCC Trade Corridor',
      },
    ].filter((d) => d.priceUsdPerMt > 0);

    const calculatedDestinations = destinations.map((d) => {
      const grossRevenueUsd = d.priceUsdPerMt * tons;
      const freightCostUsd = d.seaFreightPerContUsd * containers;
      const totalCostUsd = freightCostUsd + d.inspectionPhytoUsd;
      const netProfitUsd = grossRevenueUsd - totalCostUsd;
      const netProfitTsh = netProfitUsd * USD_TO_TZS;

      // Profit advantage compared to local sales
      const profitDeltaTsh = netProfitTsh - localNetTsh;
      const profitDeltaPct = localNetTsh > 0 ? (profitDeltaTsh / localNetTsh) * 100 : 0;

      return {
        ...d,
        grossRevenueUsd,
        grossRevenueTsh: grossRevenueUsd * USD_TO_TZS,
        freightCostUsd,
        totalCostUsd,
        netProfitUsd,
        netProfitTsh,
        profitDeltaTsh,
        profitDeltaPct,
        containers,
      };
    });

    // Sort by Highest Net Profit
    calculatedDestinations.sort((a, b) => b.netProfitUsd - a.netProfitUsd);

    const winner = calculatedDestinations[0];

    return {
      localNetTsh,
      localNetUsd,
      destinations: calculatedDestinations,
      winner,
      tons,
      containers,
    };
  }, [activeCrop, metricTons]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div
        id="profit-advisor-modal"
        className="w-full max-w-4xl bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950 text-white rounded-3xl border border-emerald-500/40 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-slate-950/60 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950">
              <Sparkles className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-400 text-slate-950">
                  {isSw ? 'Ushauri wa Faida Kubwa' : 'Best Profit Recommender'}
                </span>
                <span className="text-xs text-emerald-400 font-mono">AI Trade Algorithm</span>
              </div>
              <h2 className="text-base sm:text-lg font-display font-extrabold text-white mt-0.5">
                {isSw
                  ? 'Ni Taifa Lipi Mkulima Akiuza Atapata Faida Kubwa Zaidi?'
                  : 'Which Country Delivers the Highest Net Profit for Your Crop?'}
              </h2>
            </div>
          </div>

          <button
            id="close-profit-advisor-btn"
            onClick={() => {
              playKeyTap();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-grow custom-scrollbar">
          {/* Controls Bar: Crop Selection & Tonnage Input */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Crop Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <span>🌾</span>
                <span>{isSw ? 'Chagua Zao Lako la Kilimo:' : 'Select Your Harvested Crop:'}</span>
              </label>
              <select
                id="profit-crop-select"
                value={selectedCropId}
                onChange={(e) => {
                  playKeyTap();
                  setSelectedCropId(e.target.value);
                  const found = CROPS_DATA.find((c) => c.id === e.target.value);
                  if (found) setMetricTons(found.defaultTons);
                }}
                className="w-full bg-slate-900 border border-white/20 rounded-xl px-3 py-2.5 text-sm font-semibold text-white focus:outline-none focus:ring-2 focus:ring-emerald-400 cursor-pointer"
              >
                {CROPS_DATA.map((crop) => (
                  <option key={crop.id} value={crop.id} className="bg-slate-900 text-white">
                    {crop.icon} {isSw ? crop.nameSw : crop.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Metric Tons Quantity Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Scale className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isSw ? 'Ujazo wa Tani (Metric Tons - MT):' : 'Volume in Metric Tons (MT):'}</span>
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  {metricTons} MT = {(metricTons * 1000).toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  id="profit-tons-input"
                  type="range"
                  min="5"
                  max="150"
                  step="5"
                  value={metricTons}
                  onChange={(e) => setMetricTons(Number(e.target.value))}
                  className="w-full accent-emerald-400 cursor-pointer"
                />
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={metricTons}
                  onChange={(e) => setMetricTons(Number(e.target.value) || 1)}
                  className="w-20 bg-slate-900 border border-white/20 rounded-xl px-2.5 py-1 text-sm font-mono font-bold text-center text-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                />
              </div>
              <div className="flex items-center gap-2 mt-2">
                {[10, 25, 50, 100].map((quick) => (
                  <button
                    key={quick}
                    onClick={() => {
                      playKeyTap();
                      setMetricTons(quick);
                    }}
                    className={`px-2.5 py-0.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                      metricTons === quick
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-white/10 text-slate-300 hover:bg-white/20'
                    }`}
                  >
                    {quick} MT {quick === 25 ? '(1 Kontena)' : ''}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* AI ADVISORY VERDICT BANNER (THE WINNER) */}
          {analysisResults.winner && (
            <div
              id="profit-verdict-card"
              className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-teal-500/20 border-2 border-amber-400/50 shadow-xl relative overflow-hidden"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-400 text-slate-950 flex items-center gap-1 shadow-md">
                      <Award className="w-3.5 h-3.5" />
                      <span>{isSw ? 'TAIFA LILILOSHINDA FAIDA' : 'TOP PROFIT DESTINATION'}</span>
                    </span>
                    <span className="text-xs text-amber-300 font-semibold flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>
                        +{analysisResults.winner.profitDeltaPct.toFixed(0)}%{' '}
                        {isSw ? 'Zaidi ya Soko la Ndani' : 'vs Domestic Market'}
                      </span>
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-display font-black text-white">
                    {analysisResults.winner.nameSw}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl">
                    {isSw
                      ? `Kama utauza tani ${analysisResults.tons} za ${activeCrop.nameSw} nchini ${analysisResults.winner.nameSw}, utapata faida halisi ya takriban Tsh ${Math.round(analysisResults.winner.netProfitTsh).toLocaleString()} ($${Math.round(analysisResults.winner.netProfitUsd).toLocaleString()}). Hii ni ongezeko la Tsh ${Math.round(analysisResults.winner.profitDeltaTsh).toLocaleString()} kulinganisha na kuuza ndani ya nchi!`
                      : `Selling ${analysisResults.tons} MT of ${activeCrop.nameEn} to ${analysisResults.winner.nameEn} yields a projected net profit of Tsh ${Math.round(analysisResults.winner.netProfitTsh).toLocaleString()} ($${Math.round(analysisResults.winner.netProfitUsd).toLocaleString()}), generating an extra Tsh ${Math.round(analysisResults.winner.profitDeltaTsh).toLocaleString()} over domestic farmgate sales.`}
                  </p>
                </div>

                {/* Net Profit Metric Callout */}
                <div className="p-3 sm:p-4 rounded-2xl bg-slate-950/80 border border-amber-400/40 text-right flex-shrink-0 min-w-[200px]">
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">
                    {isSw ? 'Faida Halisi (Net Profit)' : 'Projected Net Profit'}
                  </span>
                  <span className="font-display text-xl sm:text-2xl font-black text-amber-400 block">
                    Tsh {(Math.round(analysisResults.winner.netProfitTsh / 1000000) * 1).toFixed(1)}M
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-bold block">
                    ${Math.round(analysisResults.winner.netProfitUsd).toLocaleString()} USD
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-1">
                    {analysisResults.containers}x 40ft {isSw ? 'Kontena za Bahari' : 'FCL Containers'}
                  </span>
                </div>
              </div>

              {/* Protocol Badge */}
              <div className="mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
                <span className="flex items-center gap-1 text-emerald-300 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>{isSw ? analysisResults.winner.protocolSw : analysisResults.winner.protocolEn}</span>
                </span>
                <span className="text-slate-400 text-[11px]">
                  {isSw ? 'Muda wa meli baharini:' : 'Sea transit time:'}{' '}
                  <strong className="text-white">{analysisResults.winner.transitDays} {isSw ? 'Siku' : 'Days'}</strong>
                </span>
              </div>
            </div>
          )}

          {/* SIDE-BY-SIDE RANKING COMPARISON TABLE */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-display font-bold text-white flex items-center gap-2">
                <Scale className="w-4 h-4 text-emerald-400" />
                <span>
                  {isSw
                    ? 'Ulinganisho wa Faida kwa Kila Soko la Kimataifa'
                    : 'Destination-by-Destination Profit Comparison'}
                </span>
              </h4>
              <span className="text-xs text-slate-400 font-mono">
                1 USD = 2,620 TZS
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              {analysisResults.destinations.map((dest, idx) => {
                const isTop = idx === 0;
                return (
                  <div
                    key={dest.id}
                    id={`profit-rank-row-${dest.id}`}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isTop
                        ? 'bg-amber-950/40 border-amber-400/50 shadow-md ring-1 ring-amber-400/40'
                        : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {/* Left: Country & Pricing */}
                    <div className="flex items-start sm:items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                          isTop
                            ? 'bg-amber-400 text-slate-950'
                            : 'bg-white/10 text-slate-300'
                        }`}
                      >
                        #{idx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-display font-bold text-white text-sm">
                            {isSw ? dest.nameSw : dest.nameEn}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            FOB ${dest.priceUsdPerMt.toLocaleString()} / MT
                          </span>
                          {dest.tariffRatePct === 0 && (
                            <span className="text-[10px] font-medium text-amber-300">
                              (0% Tariff)
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-3">
                          <span className="flex items-center gap-1">
                            <Ship className="w-3 h-3 text-blue-400" />
                            <span>{dest.transitDays} {isSw ? 'Siku Baharini' : 'Days Sea'}</span>
                          </span>
                          <span>
                            {isSw ? 'Gharama ya Meli:' : 'Freight:'} ${dest.freightCostUsd.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right: Net Profit in TSH & USD */}
                    <div className="flex items-center justify-between sm:justify-end gap-4 text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-white/10">
                      <div>
                        <span className="text-[10px] text-slate-400 block">
                          {isSw ? 'Faida Halisi' : 'Net Profit'}
                        </span>
                        <span
                          className={`font-display text-sm sm:text-base font-extrabold ${
                            isTop ? 'text-amber-400' : 'text-emerald-300'
                          }`}
                        >
                          Tsh {Math.round(dest.netProfitTsh).toLocaleString()}
                        </span>
                        <span className="text-[11px] font-mono text-slate-300 block">
                          ${Math.round(dest.netProfitUsd).toLocaleString()} USD
                        </span>
                      </div>

                      {onSelectCountry && (
                        <button
                          onClick={() => {
                            playKeyTap();
                            onSelectCountry(dest.id);
                            onClose();
                          }}
                          className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer flex-shrink-0"
                        >
                          <span>{isSw ? 'Ona Soko' : 'View'}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Baseline Local Sales Row */}
              <div className="p-3 rounded-2xl bg-white/5 border border-dashed border-white/20 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="text-base">🇹🇿</span>
                  <div>
                    <span className="font-semibold text-slate-300">
                      {isSw ? 'Kuuza Soko la Ndani / AMCOS (Baseline)' : 'Domestic Farmgate / AMCOS Sale (Baseline)'}
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Tsh {activeCrop.localPricePerKgTsh.toLocaleString()} / kg
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-slate-300 block">
                    Tsh {Math.round(analysisResults.localNetTsh).toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    ${Math.round(analysisResults.localNetUsd).toLocaleString()} USD
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* ACTIONABLE AI EXPORT GUIDANCE & PROTOCOLS */}
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs space-y-2">
            <h5 className="font-display font-bold text-emerald-300 flex items-center gap-1.5 text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{isSw ? 'Mwongozo wa Kufikia Faida Hii Kubwa:' : 'Action Plan to Maximize Export Profits:'}</span>
            </h5>
            <p className="text-slate-200 leading-relaxed">
              {isSw ? activeCrop.notesSw : activeCrop.notesEn}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 text-[11px] text-slate-300">
              <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/10">
                <strong className="text-amber-300 block mb-0.5">
                  1. {isSw ? 'Kusanya Kupitia AMCOS' : 'AMCOS Aggregation'}
                </strong>
                <span>
                  {isSw
                    ? 'Kama unavuna chini ya tani 20, ungana na AMCOS yako ili kujaza kontena zima la futi 40 (FCL) kupunguza gharama.'
                    : 'If producing <20 MT, aggregate with your local AMCOS cooperative to ship full container loads (FCL) and cut freight.'}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/10">
                <strong className="text-emerald-300 block mb-0.5">
                  2. {isSw ? 'Cheti cha Afya (TPHPA/TBS)' : 'Phytosanitary Cert'}
                </strong>
                <span>
                  {isSw
                    ? 'Pata cheti cha ukaguzi wa wadudu na aflatoxin kutoka Mamlaka ya Afya ya Mimea (TPHPA) kabla ya kupakia bandarini.'
                    : 'Secure phytosanitary and aflatoxin certificates from TPHPA before booking ocean vessel slots at Dar/Mtwara.'}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/10">
                <strong className="text-blue-300 block mb-0.5">
                  3. {isSw ? 'Barua ya Ununuzi (LOI)' : 'Verified Buyer LOI'}
                </strong>
                <span>
                  {isSw
                    ? 'Saini Mkataba wa Ununuzi (Sales Contract / LC) na wanunuzi walioidhinishwa kwenye jukwaa letu kabla ya meli kung\'oa nanga.'
                    : 'Lock in sales contracts and Irrevocable Letters of Credit (LC) with verified buyers before vessel departure.'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/10 bg-slate-950/60 flex items-center justify-between flex-shrink-0">
          <span className="text-[11px] text-slate-400">
            {isSw
              ? 'Takwimu zinasasishwa kila wiki kutoka TMX, GACC China, na Eurostat.'
              : 'Weekly benchmarked data from TMX, GACC China, and Eurostat.'}
          </span>
          <button
            onClick={() => {
              playKeyTap();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs transition-colors cursor-pointer"
          >
            {isSw ? 'Funga Mwongozo' : 'Done & Return'}
          </button>
        </div>
      </div>
    </div>
  );
}
