import React, { useState, useEffect } from 'react';
import { Flame, Cpu, Thermometer, Sparkles, ShieldCheck, Zap, RefreshCw, CheckCircle2 } from 'lucide-react';

interface MiningEfficiencyTipsProps {
  hashrateVelocity: number;
  onOptimizeThermal?: () => void;
}

export const MiningEfficiencyTips: React.FC<MiningEfficiencyTipsProps> = ({
  hashrateVelocity,
  onOptimizeThermal
}) => {
  const [deviceTemp, setDeviceTemp] = useState<number>(34.5); // Normal operating temp in Celsius
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [optimizedMessage, setOptimizedMessage] = useState<string | null>(null);

  // Simulate slight temperature fluctuations based on mining activity
  useEffect(() => {
    const interval = setInterval(() => {
      setDeviceTemp(prev => {
        const delta = (Math.random() * 0.6 - 0.3);
        const nextTemp = prev + delta;
        return parseFloat(Math.max(31.0, Math.min(44.0, nextTemp)).toFixed(1));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleRunThermalOptimization = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      setIsOptimizing(false);
      setDeviceTemp(32.1);
      setOptimizedMessage('⚡ Prophetic Thermal Blessing Applied! Device heat optimized, 100,000 H/s speed running at peak efficiency with zero battery drain.');
      if (onOptimizeThermal) onOptimizeThermal();
      setTimeout(() => setOptimizedMessage(null), 5000);
    }, 1500);
  };

  // Dynamic Prophetic Wisdom Tips based on temperature
  const getPropheticWisdomTip = () => {
    if (deviceTemp > 40) {
      return {
        title: '🔥 High Thermal Alert - Prophetic Cool-Down',
        advice: 'Device temperature is elevated. Invoke the 528Hz Soaking Frequency protocol and throttle power to 10% to protect processor longevity while sustaining 100,000 H/s mining velocity.',
        badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40'
      };
    } else if (deviceTemp > 36) {
      return {
        title: '⚡ Optimal Thermal Balance - Altar Flow',
        advice: 'Device is running at warm efficiency. Maintain the 10% power throttle limit to ensure seamless mining without hardware strain.',
        badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40'
      };
    } else {
      return {
        title: '🌿 Pristine Sanctuary Temperature - Peak Performance',
        advice: 'Device temperature is cool and optimized. 100,000 HashRate/sec is operating at maximum efficiency with end-to-end cryptographic encryption.',
        badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
      };
    }
  };

  const currentTip = getPropheticWisdomTip();

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/40 border-2 border-amber-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden space-y-5">
      <div className="absolute top-0 right-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/30 border border-amber-300">
            <Thermometer className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-extrabold text-amber-100 font-serif">
                Mining Efficiency & Prophetic Wisdom Tips
              </h3>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${currentTip.badgeColor}`}>
                {deviceTemp}°C Temp
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Real-time thermal monitoring & CPU heat optimization for 100,000 HashRate/sec
            </p>
          </div>
        </div>

        <button
          onClick={handleRunThermalOptimization}
          disabled={isOptimizing}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 transition-all hover:scale-105 flex items-center space-x-2 border border-amber-300 disabled:opacity-50"
        >
          {isOptimizing ? (
            <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
          ) : (
            <Sparkles className="w-4 h-4 text-slate-950" />
          )}
          <span>{isOptimizing ? 'Optimizing Thermal Conduction...' : 'Optimize Device Heat'}</span>
        </button>
      </div>

      {optimizedMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs font-bold flex items-center space-x-2 animate-pulse">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{optimizedMessage}</span>
        </div>
      )}

      {/* Prophetic Wisdom Card */}
      <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 space-y-2 relative z-10">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-amber-300 flex items-center space-x-1.5 font-serif">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{currentTip.title}</span>
          </span>
          <span className="text-slate-400 font-mono">Hashrate: {hashrateVelocity.toLocaleString()} H/s</span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          {currentTip.advice}
        </p>
      </div>

      {/* Efficiency Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 relative z-10">
        <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Processor Power Limit</div>
          <div className="text-lg font-black text-amber-300 font-mono mt-1">10% Safe Mode</div>
          <div className="text-[10px] text-emerald-400 mt-0.5">Zero background battery drain</div>
        </div>
        <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Encryption Standard</div>
          <div className="text-lg font-black text-emerald-300 font-mono mt-1">AES-256 E2EE</div>
          <div className="text-[10px] text-emerald-400 mt-0.5">100% Secure Blockchain Tx</div>
        </div>
        <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Consensus Protocol</div>
          <div className="text-lg font-black text-blue-300 font-mono mt-1">50/50 Share Rule</div>
          <div className="text-[10px] text-blue-400 mt-0.5">50% User | 50% Treasury</div>
        </div>
      </div>
    </div>
  );
};
