import React, { useState, useEffect } from "react";
import { ArrowRight, BookOpen, X, Clock, Image as ImageIcon, Upload, RotateCcw, Check, Sparkles, Tag } from "lucide-react";
import { JOURNAL_ARTICLES } from "../data/journalData";
import { JournalArticle } from "../types";

const JOURNAL_STORAGE_KEY = "kaloreez_journal_image_overrides_v1";

export const JournalSection: React.FC = () => {
  const [activeArticle, setActiveArticle] = useState<JournalArticle | null>(null);
  const [editingArticle, setEditingArticle] = useState<JournalArticle | null>(null);
  const [customImageUrl, setCustomImageUrl] = useState("");
  const [filterTag, setFilterTag] = useState<string>("All");

  // Load custom image overrides from localStorage
  const [imageOverrides, setImageOverrides] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem(JOURNAL_STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const saveOverride = (articleId: string, url: string) => {
    const updated = { ...imageOverrides, [articleId]: url };
    setImageOverrides(updated);
    try {
      localStorage.setItem(JOURNAL_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const resetOverride = (articleId: string) => {
    const updated = { ...imageOverrides };
    delete updated[articleId];
    setImageOverrides(updated);
    try {
      localStorage.setItem(JOURNAL_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const getArticleImage = (article: JournalArticle) => {
    return imageOverrides[article.id] || article.imageUrl;
  };

  // Handle local file upload (drag & drop or file picker)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingArticle) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          saveOverride(editingArticle.id, result);
          setCustomImageUrl("");
          setEditingArticle(null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredArticles = JOURNAL_ARTICLES.filter((article) => {
    if (filterTag === "All") return true;
    if (filterTag === "Placeholders") return article.isPlaceholder;
    if (filterTag === "Kitchen Photos") return !article.isPlaceholder;
    return article.tag.toLowerCase().includes(filterTag.toLowerCase());
  });

  return (
    <section id="journal" className="py-24 sm:py-32 px-4 sm:px-6 bg-[#F4F0E7] relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-[#D8D0C2]/60 pb-8">
          <div>
            <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82] mb-3 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" />
              THE CULINARY JOURNAL & ARCHIVE
            </div>
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#17201C] leading-[1.05] tracking-tight">
              NOTES FROM THE
              <br />
              <span className="italic font-light">KITCHEN & TABLE.</span>
            </h2>
          </div>

          <div className="space-y-3 max-w-md">
            <p className="text-xs sm:text-sm text-[#17201C]/70 font-sans leading-relaxed">
              Curated photographic dispatches documenting our coastal heritage storefront, ambient dining hall, chef's skillet signatures, and morning baker bowls in Visakhapatnam.
            </p>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              {["All", "Kitchen Photos", "Placeholders"].map((tag) => (
                <button
                  key={tag}
                  onClick={() => setFilterTag(tag)}
                  className={`px-3 py-1 rounded-full text-[10px] font-sans uppercase tracking-wider transition-all cursor-pointer ${
                    filterTag === tag
                      ? "bg-[#17201C] text-[#F4F0E7] shadow-2xs font-semibold"
                      : "bg-[#FDFBF7] text-[#17201C]/70 border border-[#D8D0C2] hover:border-[#17201C]"
                  }`}
                >
                  {tag === "Kitchen Photos" ? "Verified Dispatches" : tag === "Placeholders" ? "Placeholder Images" : "All Notes"}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredArticles.map((article) => {
            const currentImg = getArticleImage(article);
            const isCustom = !!imageOverrides[article.id];

            return (
              <article
                key={article.id}
                className="group flex flex-col justify-between bg-[#FDFBF7] rounded-sm border border-[#D8D0C2]/80 overflow-hidden paper-frame hover:border-[#17201C] transition-all"
              >
                <div>
                  {/* Visual Image Container with Badges */}
                  <div className="relative aspect-[16/10] bg-[#EAE4D7] overflow-hidden">
                    <img
                      src={currentImg}
                      alt={article.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-103"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20 pointer-events-none" />

                    {/* Top Tag & Status Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                      <span className="px-2.5 py-1 rounded-full bg-[#FDFBF7]/90 backdrop-blur-xs text-[9px] font-bold uppercase tracking-wider text-[#17201C] shadow-2xs">
                        {article.tag}
                      </span>

                      {article.isPlaceholder && !isCustom ? (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/85 backdrop-blur-xs text-[9px] font-semibold uppercase tracking-wider text-white shadow-2xs">
                          Placeholder
                        </span>
                      ) : isCustom ? (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-700/85 backdrop-blur-xs text-[9px] font-semibold uppercase tracking-wider text-white shadow-2xs">
                          Custom Upload
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-[#17201C]/80 backdrop-blur-xs text-[9px] font-semibold uppercase tracking-wider text-[#9BAF82] shadow-2xs">
                          Verified Photo
                        </span>
                      )}
                    </div>

                    {/* Image Action Overlay Button */}
                    <div className="absolute bottom-3 right-3 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingArticle(article);
                          setCustomImageUrl(imageOverrides[article.id] || "");
                        }}
                        className="px-2.5 py-1 rounded-full bg-black/75 hover:bg-black text-white text-[10px] font-sans tracking-wider uppercase flex items-center gap-1 backdrop-blur-xs shadow-xs"
                      >
                        <ImageIcon className="w-3 h-3 text-[#9BAF82]" />
                        <span>Replace</span>
                      </button>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 sm:p-6">
                    <div className="flex items-center gap-2 text-[11px] text-[#17201C]/50 mb-2 font-mono">
                      <span>{article.date}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1 font-sans">
                        <Clock className="w-3 h-3 text-[#9BAF82]" />
                        {article.readTime}
                      </span>
                    </div>

                    <h3
                      onClick={() => setActiveArticle(article)}
                      className="font-serif text-xl sm:text-2xl text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-snug mb-2 cursor-pointer"
                    >
                      {article.title}
                    </h3>

                    <p className="text-xs text-[#17201C]/75 font-sans leading-relaxed line-clamp-3 mb-3">
                      {article.excerpt}
                    </p>
                  </div>
                </div>

                {/* Card Footer Action */}
                <div className="p-5 sm:p-6 pt-0 border-t border-[#D8D0C2]/40 mt-auto flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-[#17201C]">
                  <button
                    type="button"
                    onClick={() => setActiveArticle(article)}
                    className="group-hover:text-[#9BAF82] transition-colors inline-flex items-center gap-1.5 cursor-pointer py-1"
                  >
                    <span>Read Full Story</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </button>

                  {isCustom && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        resetOverride(article.id);
                      }}
                      title="Reset to default photo"
                      className="text-[10px] text-[#17201C]/40 hover:text-red-600 underline font-mono"
                    >
                      Reset Photo
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Article Detail Full Reading Modal */}
      {activeArticle && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div
            onClick={() => setActiveArticle(null)}
            className="fixed inset-0 bg-[#17201C]/70 backdrop-blur-xs"
          />

          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame z-10 my-auto shadow-2xl p-6 sm:p-8">
            <button
              onClick={() => setActiveArticle(null)}
              aria-label="Close story"
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/90 border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] uppercase tracking-widest text-[#9BAF82] font-semibold">
                {activeArticle.tag}
              </span>
              <span className="text-[10px] text-[#17201C]/40">·</span>
              <span className="text-[10px] uppercase tracking-wider text-[#17201C]/60 font-mono">
                {activeArticle.date}
              </span>
            </div>

            <h3 className="font-serif text-3xl sm:text-4xl text-[#17201C] leading-tight mb-2">
              {activeArticle.title}
            </h3>

            <div className="font-serif italic text-base text-[#17201C]/75 mb-6 border-b border-[#D8D0C2]/60 pb-4">
              {activeArticle.subtitle}
            </div>

            {/* Featured Photo in Modal with Replace Button */}
            <div className="relative aspect-[16/9] rounded-xs overflow-hidden mb-6 bg-[#EAE4D7] group">
              <img
                src={getArticleImage(activeArticle)}
                alt={activeArticle.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => {
                  setEditingArticle(activeArticle);
                  setCustomImageUrl(imageOverrides[activeArticle.id] || "");
                }}
                className="absolute bottom-3 right-3 px-3 py-1.5 rounded-full bg-black/80 hover:bg-black text-white text-xs font-sans tracking-wider uppercase flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Replace / Upload Image</span>
              </button>
            </div>

            <div className="space-y-4 text-sm text-[#17201C]/85 font-sans leading-relaxed">
              <p className="font-medium text-base text-[#17201C] leading-relaxed">
                {activeArticle.excerpt}
              </p>
              <p className="leading-relaxed">{activeArticle.content}</p>
            </div>

            <div className="mt-8 pt-4 border-t border-[#D8D0C2]/60 flex items-center justify-between text-xs text-[#17201C]/60">
              <span className="font-mono">Kaloreez Culinary Dispatch #{activeArticle.id}</span>
              <button
                onClick={() => setActiveArticle(null)}
                className="font-semibold text-[#17201C] uppercase tracking-wider hover:text-[#9BAF82] cursor-pointer"
              >
                Close Story ×
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Replacement / Upload Modal */}
      {editingArticle && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div
            onClick={() => setEditingArticle(null)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
          />

          <div className="relative w-full max-w-lg bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame z-10 my-auto shadow-2xl p-6 sm:p-7">
            <div className="flex items-center justify-between mb-4 border-b border-[#D8D0C2] pb-3">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#9BAF82] font-semibold">
                  Update Dispatch Image
                </span>
                <h4 className="font-serif text-xl text-[#17201C]">{editingArticle.title}</h4>
              </div>
              <button
                onClick={() => setEditingArticle(null)}
                className="w-8 h-8 rounded-full bg-[#EAE4D7] flex items-center justify-center text-[#17201C]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-sans">
              <div>
                <label className="block font-semibold mb-1.5 text-[#17201C]">
                  Option 1: Upload Image File directly
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="w-full text-xs text-[#17201C]/70 file:mr-3 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-[#17201C] file:text-[#F4F0E7] hover:file:bg-[#9BAF82] hover:file:text-[#17201C] cursor-pointer"
                />
                <span className="text-[10px] text-[#17201C]/50 mt-1 block">
                  Select your uploaded photo from your phone or device. Saved locally in your browser.
                </span>
              </div>

              <div className="relative flex items-center py-1">
                <div className="flex-grow border-t border-[#D8D0C2]" />
                <span className="px-2 text-[10px] uppercase tracking-wider text-[#17201C]/50 bg-[#FDFBF7]">
                  OR
                </span>
                <div className="flex-grow border-t border-[#D8D0C2]" />
              </div>

              <div>
                <label className="block font-semibold mb-1.5 text-[#17201C]">
                  Option 2: Image URL
                </label>
                <input
                  type="url"
                  placeholder="https://... image link"
                  value={customImageUrl}
                  onChange={(e) => setCustomImageUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-xs border border-[#D8D0C2] bg-white text-[#17201C] focus:outline-none focus:border-[#9BAF82]"
                />
              </div>

              {/* Preview */}
              {customImageUrl && (
                <div className="mt-3">
                  <span className="block font-semibold mb-1 text-[11px]">Preview:</span>
                  <div className="relative aspect-[16/10] rounded-xs overflow-hidden bg-black/5">
                    <img
                      src={customImageUrl}
                      alt="Preview"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#D8D0C2]">
                {imageOverrides[editingArticle.id] && (
                  <button
                    type="button"
                    onClick={() => {
                      resetOverride(editingArticle.id);
                      setEditingArticle(null);
                    }}
                    className="px-4 py-2 rounded-full border border-red-300 text-red-600 hover:bg-red-50 text-xs font-semibold mr-auto"
                  >
                    Reset to Default
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setEditingArticle(null)}
                  className="px-4 py-2 rounded-full border border-[#D8D0C2] text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!customImageUrl}
                  onClick={() => {
                    if (customImageUrl) {
                      saveOverride(editingArticle.id, customImageUrl);
                      setEditingArticle(null);
                    }
                  }}
                  className="px-5 py-2 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-semibold hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors disabled:opacity-40"
                >
                  Save Photo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
