import React, { useState, useRef, useEffect } from "react";
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RefreshCw,
  Sliders,
} from "lucide-react";

interface GlobalMediaPlayerProps {
  mediaUrl: string;
  mediaType: "audio" | "video";
  title?: string;
  posterUrl?: string;
  onEnded?: () => void;
  className?: string;
}

export const GlobalMediaPlayer: React.FC<GlobalMediaPlayerProps> = ({
  mediaUrl,
  mediaType,
  title,
  posterUrl,
  onEnded,
  className = "",
}) => {
  const mediaRef = useRef<HTMLVideoElement & HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [rotation, setRotation] = useState(0); // 0, 90, 180, 270
  const [aspectRatio, setAspectRatio] = useState<"contain" | "cover">("contain");

  useEffect(() => {
    const el = mediaRef.current;
    if (!el) return;

    const onTimeUpdate = () => setCurrentTime(el.currentTime);
    const onLoadedMetadata = () => {
      setDuration(el.duration || 0);
    };
    const handleEnded = () => {
      setIsPlaying(false);
      if (onEnded) onEnded();
    };

    el.addEventListener("timeupdate", onTimeUpdate);
    el.addEventListener("loadedmetadata", onLoadedMetadata);
    el.addEventListener("ended", handleEnded);

    return () => {
      el.removeEventListener("timeupdate", onTimeUpdate);
      el.removeEventListener("loadedmetadata", onLoadedMetadata);
      el.removeEventListener("ended", handleEnded);
    };
  }, [mediaUrl, onEnded]);

  const togglePlay = () => {
    const el = mediaRef.current;
    if (!el) return;
    if (isPlaying) {
      el.pause();
      setIsPlaying(false);
    } else {
      el.play()
        .then(() => setIsPlaying(true))
        .catch((e) => console.warn("Playback prevented:", e));
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (mediaRef.current) {
      mediaRef.current.currentTime = time;
    }
  };

  const skipSeconds = (seconds: number) => {
    if (mediaRef.current) {
      mediaRef.current.currentTime = Math.max(0, Math.min(duration, mediaRef.current.currentTime + seconds));
    }
  };

  const toggleMute = () => {
    if (!mediaRef.current) return;
    mediaRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (mediaRef.current) {
      mediaRef.current.volume = val;
      mediaRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const rotateVideo = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const toggleAspectRatio = () => {
    setAspectRatio((prev) => (prev === "contain" ? "cover" : "contain"));
  };

  const formatTime = (timeInSec: number) => {
    if (isNaN(timeInSec)) return "00:00";
    const minutes = Math.floor(timeInSec / 60);
    const seconds = Math.floor(timeInSec % 60);
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  };

  return (
    <div
      ref={containerRef}
      id="global-media-player-container"
      className={`bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl ${className}`}
    >
      {/* Video Canvas or Audio Display Header */}
      {mediaType === "video" ? (
        <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
          <video
            ref={mediaRef}
            src={mediaUrl}
            poster={posterUrl}
            playsInline
            className={`w-full h-full transition-transform duration-300 object-${aspectRatio}`}
            style={{ transform: `rotate(${rotation}deg)` }}
            onClick={togglePlay}
          />
          {/* Central play overlay when paused */}
          {!isPlaying && (
            <button
              onClick={togglePlay}
              className="absolute w-14 h-14 rounded-full bg-blue-600/90 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-600/30 backdrop-blur-sm transition-transform active:scale-95"
            >
              <Play className="w-6 h-6 ml-1" />
            </button>
          )}

          {/* Video Controls Bar Header */}
          <div className="absolute top-2 right-2 flex items-center space-x-1.5 bg-black/60 backdrop-blur-md px-2 py-1 rounded-xl">
            <button
              onClick={rotateVideo}
              title="Rotate 90°"
              className="p-1 text-slate-300 hover:text-white"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={toggleAspectRatio}
              title="Aspect ratio (contain / cover)"
              className="p-1 text-slate-300 hover:text-white text-[11px] font-mono uppercase"
            >
              {aspectRatio}
            </button>
            <button
              onClick={toggleFullscreen}
              title="Fullscreen"
              className="p-1 text-slate-300 hover:text-white"
            >
              {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      ) : (
        /* Audio Player Top Display */
        <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 flex items-center space-x-3.5 border-b border-slate-800/80">
          {posterUrl ? (
            <img src={posterUrl} alt="Cover" className="w-12 h-12 rounded-xl object-cover border border-slate-700" />
          ) : (
            <div className="w-12 h-12 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Sliders className="w-6 h-6" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold text-white truncate">{title || "Audio Output"}</h4>
            <p className="text-xs text-slate-400 mt-0.5 font-mono">
              {formatTime(currentTime)} / {formatTime(duration)}
            </p>
          </div>
          <audio ref={mediaRef} src={mediaUrl} />
        </div>
      )}

      {/* Media Controls Bar (Seek, Skip, Play, Volume) */}
      <div className="p-3.5 space-y-3 bg-slate-900/95">
        {/* Seek progress bar */}
        <div className="space-y-1">
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Primary Controls Row */}
        <div className="flex items-center justify-between">
          {/* 10s Backward, Play/Pause, 10s Forward */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => skipSeconds(-10)}
              title="Rewind 10 seconds"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-md shadow-blue-500/20 active:scale-95 transition-all"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </button>

            <button
              onClick={() => skipSeconds(10)}
              title="Fast forward 10 seconds"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors active:scale-95"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>

          {/* Volume Slider & Toggle */}
          <div className="flex items-center space-x-2">
            <button
              onClick={toggleMute}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-16 sm:w-20 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
