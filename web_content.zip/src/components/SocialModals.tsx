import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeftRight,
  Check,
  Coins,
  Play,
  Plus,
  UserCheck,
  UserMinus,
  Users,
  X,
} from 'lucide-react';
import { AvatarConfig, CatalogItem, FriendProfile, WorldConfig, WorldId } from '../types/game';
import { MiniAvatarIcon } from './GameThumbnail';

export const PartyMabarModal: React.FC<{
  open: boolean;
  playerName: string;
  playerAvatar: AvatarConfig;
  allPlayers: FriendProfile[];
  partyMemberIds: string[];
  worlds: WorldConfig[];
  onClose: () => void;
  onAddPartyMember: (id: string) => void;
  onRemovePartyMember: (id: string) => void;
  onFillTenParty: () => void;
  onClearParty: () => void;
  onStartMabar: (worldId: WorldId) => void;
}> = ({
  open,
  playerName,
  playerAvatar,
  allPlayers,
  partyMemberIds,
  worlds,
  onClose,
  onAddPartyMember,
  onRemovePartyMember,
  onFillTenParty,
  onClearParty,
  onStartMabar,
}) => {
  const [selectedWorldId, setSelectedWorldId] = useState<WorldId>(worlds[0]?.id || 'obby-ez');

  if (!open) return null;

  const partyMembers = allPlayers.filter((p) => partyMemberIds.includes(p.id));
  const totalInParty = 1 + partyMembers.length; // Host + invited members
  const availablePlayers = allPlayers.filter((p) => !partyMemberIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(740px,96vw)] max-h-[90vh] flex flex-col rounded-2xl bg-zinc-950 border border-white/15 overflow-hidden shadow-2xl"
      >
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
          <div>
            <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5" />
              Party Mabar ({totalInParty}/12 Pemain)
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Ajak teman atau pemain lain hingga 10–12 orang lalu masuk ke map bersama!
            </p>
          </div>
          <button type="button" onClick={onClose} className="text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto p-5 space-y-5">
          {/* Quick Status & Fill 10+ Helper */}
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-xl bg-zinc-900 border border-white/10">
            <div className="text-xs text-zinc-200">
              {totalInParty >= 10 ? (
                <span className="font-bold text-emerald-400">
                  Party Mabar Siap! ({totalInParty} pemain siap masuk ke map bersama)
                </span>
              ) : (
                <span>
                  Anggota saat ini: <strong className="text-white">{totalInParty}</strong> · Undang{' '}
                  <strong className="text-white">{10 - totalInParty}</strong> pemain lagi untuk squad 10 orang.
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onFillTenParty}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-black text-xs font-bold cursor-pointer whitespace-nowrap"
              >
                + Isi Party 10+ Orang
              </button>
              {partyMembers.length > 0 && (
                <button
                  type="button"
                  onClick={onClearParty}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold cursor-pointer"
                >
                  Kosongkan
                </button>
              )}
            </div>
          </div>

          {/* Current Party Roster */}
          <div>
            <div className="text-xs font-bold text-zinc-300 mb-2">Anggota Party ({totalInParty}/12)</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-white text-black border border-white">
                <MiniAvatarIcon avatar={playerAvatar} size={32} />
                <div className="min-w-0">
                  <div className="text-xs font-bold truncate">{playerName}</div>
                  <div className="text-[10px] font-semibold opacity-75">Ketua Party</div>
                </div>
              </div>

              {partyMembers.map((pm) => (
                <div
                  key={pm.id}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-zinc-900 border border-white/15"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <MiniAvatarIcon avatar={pm.avatar} size={30} />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{pm.name}</div>
                      <div className="text-[10px] text-zinc-400 truncate">{pm.online ? 'Siap Mabar' : 'Diundang'}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemovePartyMember(pm.id)}
                    aria-label={`Keluarkan ${pm.name}`}
                    className="p-1 text-zinc-400 hover:text-rose-400 cursor-pointer shrink-0"
                  >
                    <UserMinus className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Invite Players */}
          <div>
            <div className="text-xs font-bold text-zinc-300 mb-2">
              Undang Pemain Lain ({availablePlayers.length} tersedia)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {availablePlayers.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-zinc-900/70 border border-white/10"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <MiniAvatarIcon avatar={p.avatar} size={32} />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{p.name}</div>
                      <div className="text-[11px] text-zinc-400 truncate">
                        {p.username} · {p.online ? 'Online' : 'Offline'}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={totalInParty >= 12}
                    onClick={() => onAddPartyMember(p.id)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-white hover:text-black disabled:opacity-40 text-xs font-bold text-white cursor-pointer shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Undang
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Select Map for Mabar */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">Pilih Map untuk Mabar Bareng</label>
            <select
              value={selectedWorldId}
              onChange={(e) => setSelectedWorldId(e.target.value as WorldId)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
            >
              {worlds.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} — oleh {w.creator}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="px-5 py-4 border-t border-white/10 flex items-center justify-end gap-2.5 bg-zinc-950">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-xs font-semibold text-zinc-300 hover:text-white cursor-pointer"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={() => onStartMabar(selectedWorldId)}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            Mabar Bareng ({totalInParty} Pemain)
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export const TradeModal: React.FC<{
  open: boolean;
  targetPlayer: FriendProfile | null;
  allPlayers: FriendProfile[];
  catalogItems: CatalogItem[];
  ownedIds: string[];
  playerSlapbux: number;
  onSelectTarget: (p: FriendProfile) => void;
  onExecuteTrade: (payload: {
    partner: FriendProfile;
    giveItemIds: string[];
    receiveItemIds: string[];
    giveSlapbux: number;
  }) => { ok: boolean; message: string };
  onClose: () => void;
}> = ({
  open,
  targetPlayer,
  allPlayers,
  catalogItems,
  ownedIds,
  playerSlapbux,
  onSelectTarget,
  onExecuteTrade,
  onClose,
}) => {
  const [mySelectedIds, setMySelectedIds] = useState<string[]>([]);
  const [theirSelectedIds, setTheirSelectedIds] = useState<string[]>([]);
  const [offerSlapbux, setOfferSlapbux] = useState('0');
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);

  const partner = targetPlayer ?? allPlayers[0] ?? null;

  const myTradables = useMemo(
    () =>
      catalogItems.filter(
        (it) =>
          ownedIds.includes(it.id) &&
          it.id !== 'cat-bundle-noob' &&
          (it.category === 'accessory' ||
            it.category === 'hat' ||
            it.category === 'hair' ||
            it.category === 'shoes' ||
            it.category === 'ugc' ||
            it.category === 'shirt' ||
            it.category === 'pants')
      ),
    [catalogItems, ownedIds]
  );

  const theirTradables = useMemo(() => {
    if (!partner) return [];
    const ids = partner.ownedAccessoryIds || [];
    return catalogItems.filter((it) => ids.includes(it.id) && !ownedIds.includes(it.id));
  }, [partner, catalogItems, ownedIds]);

  if (!open || !partner) return null;

  const toggleMy = (id: string) => {
    setFeedback(null);
    setMySelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleTheir = (id: string) => {
    setFeedback(null);
    setTheirSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const handleConfirm = () => {
    const sb = Math.max(0, Math.round(Number(offerSlapbux) || 0));
    if (sb > playerSlapbux) {
      setFeedback({ ok: false, message: 'Saldo Slapbux tidak mencukupi untuk penawaran ini.' });
      return;
    }
    if (mySelectedIds.length === 0 && sb === 0) {
      setFeedback({ ok: false, message: 'Pilih minimal 1 aksesoris kamu atau tawarkan Slapbux.' });
      return;
    }
    if (theirSelectedIds.length === 0) {
      setFeedback({ ok: false, message: 'Pilih minimal 1 aksesoris milik partner untuk ditukar.' });
      return;
    }

    const res = onExecuteTrade({
      partner,
      giveItemIds: mySelectedIds,
      receiveItemIds: theirSelectedIds,
      giveSlapbux: sb,
    });
    setFeedback(res);
    if (res.ok) {
      setMySelectedIds([]);
      setTheirSelectedIds([]);
      setOfferSlapbux('0');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-[min(760px,96vw)] max-h-[90vh] flex flex-col rounded-2xl bg-zinc-950 border border-white/15 overflow-hidden shadow-2xl"
      >
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between gap-3">
          <div>
            <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5" />
              Trade Aksesoris Antar Pemain
            </h3>
            <p className="text-xs text-zinc-400">
              Pilih item aksesoris milikmu dan item milik pemain lain untuk bertukar.
            </p>
          </div>
          <button type="button" onClick={onClose} className="text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto p-5 space-y-4">
          {/* Partner selector */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-zinc-400">Partner Trade:</span>
            <select
              value={partner.id}
              onChange={(e) => {
                const found = allPlayers.find((p) => p.id === e.target.value);
                if (found) {
                  onSelectTarget(found);
                  setTheirSelectedIds([]);
                  setFeedback(null);
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-white/15 text-xs font-bold text-white focus:outline-none focus:border-white"
            >
              {allPlayers.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.username})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* My Items */}
            <div className="rounded-2xl bg-zinc-900/70 border border-white/10 p-4 space-y-3">
              <div className="text-xs font-bold text-white">
                Penawaran Kamu ({mySelectedIds.length} dipilih)
              </div>
              {myTradables.length === 0 ? (
                <div className="text-xs text-zinc-400 py-6 text-center">
                  Beli topi, rambut, sepatu, atau aksesoris di Avatar Shop terlebih dahulu.
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                  {myTradables.map((it) => {
                    const active = mySelectedIds.includes(it.id);
                    return (
                      <button
                        key={it.id}
                        type="button"
                        onClick={() => toggleMy(it.id)}
                        className={`p-2 rounded-xl border text-left cursor-pointer transition-colors ${
                          active
                            ? 'bg-white text-black border-white'
                            : 'bg-zinc-950 text-white border-white/10 hover:border-white/40'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black">{it.letter}</span>
                          {active && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div className="text-[11px] font-bold truncate mt-1">{it.name}</div>
                        <div className="text-[10px] opacity-70 font-mono-num">
                          {it.price.toLocaleString('id-ID')} SB
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">
                  Tambah Slapbux (Saldo: {playerSlapbux.toLocaleString('id-ID')})
                </label>
                <div className="relative">
                  <Coins className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min={0}
                    max={playerSlapbux}
                    value={offerSlapbux}
                    onChange={(e) => setOfferSlapbux(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-zinc-950 border border-white/15 text-xs text-white font-mono-num focus:outline-none focus:border-white"
                  />
                </div>
              </div>
            </div>

            {/* Partner Items */}
            <div className="rounded-2xl bg-zinc-900/70 border border-white/10 p-4 space-y-3">
              <div className="flex items-center gap-2">
                <MiniAvatarIcon avatar={partner.avatar} size={24} />
                <span className="text-xs font-bold text-white">
                  Aksesoris {partner.name} ({theirSelectedIds.length} dipilih)
                </span>
              </div>
              {theirTradables.length === 0 ? (
                <div className="text-xs text-zinc-400 py-6 text-center">
                  Semua aksesoris {partner.name} sudah kamu miliki! Coba pilih partner lain.
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto">
                  {theirTradables.map((it) => {
                    const active = theirSelectedIds.includes(it.id);
                    return (
                      <button
                        key={it.id}
                        type="button"
                        onClick={() => toggleTheir(it.id)}
                        className={`p-2 rounded-xl border text-left cursor-pointer transition-colors ${
                          active
                            ? 'bg-emerald-400 text-black border-emerald-300'
                            : 'bg-zinc-950 text-white border-white/10 hover:border-white/40'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black">{it.letter}</span>
                          {active && <Check className="w-3.5 h-3.5" />}
                        </div>
                        <div className="text-[11px] font-bold truncate mt-1">{it.name}</div>
                        <div className="text-[10px] opacity-70 font-mono-num">
                          {it.price.toLocaleString('id-ID')} SB
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {feedback && (
            <div
              className={`px-4 py-2.5 rounded-xl text-xs font-semibold border ${
                feedback.ok
                  ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-200'
                  : 'bg-rose-500/15 border-rose-400/40 text-rose-200'
              }`}
            >
              {feedback.message}
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t border-white/10 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-xs font-semibold text-zinc-300 hover:text-white cursor-pointer"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            Kirim & Konfirmasi Trade
          </button>
        </div>
      </motion.div>
    </div>
  );
};
