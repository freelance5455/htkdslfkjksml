import React, { useState } from 'react';
import { X, Plus, Trash2, Check, RotateCcw, BookOpen } from 'lucide-react';
import { PronunciationRule } from '../types/tts';
import { DEFAULT_PRONUNCIATION_RULES } from '../utils/pronunciation';

interface PronunciationModalProps {
  isOpen: boolean;
  onClose: () => void;
  rules: PronunciationRule[];
  onChangeRules: (rules: PronunciationRule[]) => void;
}

export const PronunciationModal: React.FC<PronunciationModalProps> = ({
  isOpen,
  onClose,
  rules,
  onChangeRules,
}) => {
  const [newOriginal, setNewOriginal] = useState('');
  const [newTeluguPhonetic, setNewTeluguPhonetic] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOriginal.trim() || !newTeluguPhonetic.trim()) return;

    const newRule: PronunciationRule = {
      id: `rule-${Date.now()}`,
      original: newOriginal.trim(),
      replacement: newTeluguPhonetic.trim(),
      teluguPhonetic: newTeluguPhonetic.trim(),
      enabled: true,
      active: true,
      caseSensitive: false,
      notes: notes.trim() || undefined,
    };

    onChangeRules([...rules, newRule]);
    setNewOriginal('');
    setNewTeluguPhonetic('');
    setNotes('');
  };

  const handleToggleActive = (id: string) => {
    onChangeRules(
      rules.map((r) => (r.id === id ? { ...r, active: !r.active } : r))
    );
  };

  const handleDeleteRule = (id: string) => {
    onChangeRules(rules.filter((r) => r.id !== id));
  };

  const handleResetDefaults = () => {
    onChangeRules(DEFAULT_PRONUNCIATION_RULES);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-2xl bg-[#101522] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <span className="font-telugu font-bold text-base">అ-ఆ</span>
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                ఉచ్చారణ నిఘంటువు (Custom Pronunciation Rules)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                ఇంగ్లీష్ లేదా విదేశీ పదాలను స్వచ్ఛమైన తెలుగు శబ్దాలతో పలకడానికి నియమాలను చేర్చండి
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add New Rule Form */}
        <form onSubmit={handleAddRule} className="p-4 bg-slate-900/40 border-b border-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                అసలు పదం (Original Word)
              </label>
              <input
                type="text"
                placeholder="e.g. AI or Podcast"
                value={newOriginal}
                onChange={(e) => setNewOriginal(e.target.value)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                తెలుగు ఉచ్చారణ (Telugu Phonetic)
              </label>
              <input
                type="text"
                placeholder="e.g. ఏ ఐ or పాడ్‌కాస్ట్"
                value={newTeluguPhonetic}
                onChange={(e) => setNewTeluguPhonetic(e.target.value)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 font-telugu placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <input
              type="text"
              placeholder="వివరణ / Notes (ఐచ్ఛికం)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-2/3 bg-[#0a0d14] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />

            <button
              type="submit"
              disabled={!newOriginal.trim() || !newTeluguPhonetic.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 disabled:opacity-40 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>రూల్ జోడించు (Add)</span>
            </button>
          </div>
        </form>

        {/* Rules Table / List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1 scrollbar-thin">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800/80">
            <span>క్రియాశీల నియమాలు ({rules.length})</span>
            <button
              type="button"
              onClick={handleResetDefaults}
              className="flex items-center gap-1 text-slate-400 hover:text-cyan-400 text-xs transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>డిఫాల్ట్ నియమాలకు రీసెట్ చేయండి</span>
            </button>
          </div>

          {rules.map((rule) => (
            <div
              key={rule.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs gap-3"
            >
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={rule.active}
                  onChange={() => handleToggleActive(rule.id)}
                  className="rounded border-slate-700 text-cyan-500 focus:ring-cyan-500 bg-slate-800 cursor-pointer"
                />
                <div>
                  <span className="font-mono font-bold text-slate-200">{rule.original}</span>
                  <span className="mx-2 text-slate-500">➔</span>
                  <span className="font-telugu font-bold text-cyan-300">{rule.teluguPhonetic}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {rule.notes && (
                  <span className="text-[11px] text-slate-500 hidden sm:inline">{rule.notes}</span>
                )}
                <button
                  type="button"
                  onClick={() => handleDeleteRule(rule.id)}
                  className="p-1 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
