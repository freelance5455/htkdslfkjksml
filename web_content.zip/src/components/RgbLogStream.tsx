import React, { useState, useEffect } from 'react';
import { Terminal, Zap, Shield, Radio, ChevronDown, ChevronUp, Trash2, Cpu } from 'lucide-react';
import { RgbLogItem } from '../types';

interface RgbLogStreamProps {
  logs?: RgbLogItem[];
}

export const RgbLogStream: React.FC<RgbLogStreamProps> = ({ logs: customLogs }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [logs, setLogs] = useState<RgbLogItem[]>([
    { id: '1', time: '11:06:12', type: 'INFO', message: 'ViralPulse Core v2.4 initialized in Cyber RGB Engine.' },
    { id: '2', time: '11:06:18', type: 'ALGO', message: 'YouTube Shorts algorithm weight indexed: Hook (45%), Audio (30%), Loop (25%).' },
    { id: '3', time: '11:06:24', type: 'AUDIO', message: 'Audio radar flagged 5 breakout tracks with velocity > 25K uses/hr.' },
    { id: '4', time: '11:06:30', type: 'PREDICT', message: 'Bhavishya Predictor: AI Tools & Desi ASMR formats surging.' },
  ]);

  // Append background live RGB logs every few seconds to keep it lively
  useEffect(() => {
    const logInterval = setInterval(() => {
      const now = new Date().toLocaleTimeString();
      const mockEvents = [
        { type: 'AUDIO' as const, message: 'Detected new audio spike: "Sajna Phonk Mix" +4,200 uses in last 10m.' },
        { type: 'ALGO' as const, message: 'Audited CTR threshold: Videos with question hooks beating benchmark by 38%.' },
        { type: 'PREDICT' as const, message: 'Future Wave alert: Weekend search surge predicted for "Gaming Setup Hacks".' },
        { type: 'VIRAL' as const, message: 'Retention analysis: 0:01-0:03 drop-off reduced by 62% using pattern-interrupt fx.' },
        { type: 'INFO' as const, message: 'Agent telemetry synced with YouTube trending radar cache.' },
      ];
      const randomEvent = mockEvents[Math.floor(Math.random() * mockEvents.length)];
      setLogs(prev => [
        ...prev.slice(-12),
        { id: String(Date.now()), time: now, type: randomEvent.type, message: randomEvent.message }
      ]);
    }, 9000);

    return () => clearInterval(logInterval);
  }, []);

  const badgeColor = (type: string) => {
    switch (type) {
      case 'AUDIO':
        return 'text-pink-400 bg-pink-950/60 border-pink-700/50';
      case 'PREDICT':
        return 'text-amber-400 bg-amber-950/60 border-amber-700/50';
      case 'ALGO':
        return 'text-cyan-400 bg-cyan-950/60 border-cyan-700/50';
      case 'VIRAL':
        return 'text-emerald-400 bg-emerald-950/60 border-emerald-700/50';
      default:
        return 'text-zinc-400 bg-zinc-900 border-zinc-700';
    }
  };

  return (
    <div className="relative rounded-2xl p-[1.5px] rgb-gradient-border shadow-lg shadow-cyan-500/10 mb-4 transition-all">
      <div className="rounded-[15px] bg-zinc-950/95 p-3 backdrop-blur-xl overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            </div>
            <div className="flex items-center gap-1.5 ml-2">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs font-mono font-bold tracking-wider text-cyan-300">
                RGB_TELEMETRY_LOGS.SYS
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-800/40">
              <Radio className="w-2.5 h-2.5 animate-spin" /> LIVE RADAR
            </span>
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 rounded-md hover:bg-white/10 text-zinc-400 hover:text-white"
            >
              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        {isExpanded && (
          <div className="font-mono text-[11px] space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {logs.map(log => (
              <div key={log.id} className="flex items-start gap-2 leading-relaxed">
                <span className="text-zinc-500 shrink-0 select-none">[{log.time}]</span>
                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border shrink-0 ${badgeColor(log.type)}`}>
                  {log.type}
                </span>
                <span className="text-zinc-300 break-words flex-1">
                  {log.message}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
