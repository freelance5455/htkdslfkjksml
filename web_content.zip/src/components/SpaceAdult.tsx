import React, { useState } from 'react';
import {
  Heart,
  Search,
  Sparkles,
  Zap,
  Eye,
  ShieldAlert,
  Compass,
  Archive,
  Smile,
  HeartHandshake,
  Star,
  Play,
  Clock,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { RegulationTool, ToolCategory } from '../types/index.ts';

interface SpaceAdultProps {
  tools: RegulationTool[];
  onOpenTool: (tool: RegulationTool, version: 'short' | 'full') => void;
  favorites: string[];
  onToggleFavorite: (toolId: string) => void;
}

export const SpaceAdult: React.FC<SpaceAdultProps> = ({
  tools,
  onOpenTool,
  favorites,
  onToggleFavorite,
}) => {
  const { t } = useTranslation();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: t('adultSpace.categories.all') },
    { id: 'crisis', label: t('adultSpace.categories.crisis') },
    { id: 'grounding', label: t('adultSpace.categories.grounding') },
    { id: 'breathing', label: t('adultSpace.categories.breathing') },
    { id: 'somatic', label: t('adultSpace.categories.somatic') },
    { id: 'hypnosis', label: t('adultSpace.categories.hypnosis') },
    { id: 'compassion', label: t('adultSpace.categories.compassion') },
  ];

  const filteredTools = tools.filter((tool) => {
    if (tool.space !== 'adult') return false;
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      tool.titleKey.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.shortDescriptionKey.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getToolIcon = (name: string) => {
    switch (name) {
      case 'Eye':
        return <Eye className="w-5 h-5 text-amber-500" />;
      case 'Heart':
        return <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-purple-500" />;
      case 'AlertTriangle':
        return <Zap className="w-5 h-5 text-orange-500" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-5 h-5 text-indigo-500" />;
      case 'Compass':
        return <Compass className="w-5 h-5 text-teal-500" />;
      case 'Archive':
        return <Archive className="w-5 h-5 text-cyan-500" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-5 h-5 text-rose-500" />;
      case 'Smile':
        return <Smile className="w-5 h-5 text-emerald-500" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-yellow-500" />;
      default:
        return <Heart className="w-5 h-5 text-rose-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Philosophy Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-100/60 via-amber-50/50 to-teal-50/60 dark:from-slate-800 dark:via-slate-800 dark:to-slate-900 border border-rose-100 dark:border-slate-700 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t('adultSpace.title')}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
            {t('adultSpace.subtitle')}. Approches validées : Compassion-Focused Therapy, IFS simplifié, EFT, cohérence cardiaque et stimulation bilatérale.
          </p>
        </div>

        {/* Quick Search */}
        <div className="relative w-full md:w-72 shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('adultSpace.filterPlaceholder')}
            className="w-full text-xs pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-400 shadow-2xs"
          />
        </div>
      </div>

      {/* Categories chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shadow-2xs ${
              activeCategory === cat.id
                ? 'bg-rose-500 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTools.map((tool) => {
          const isFav = favorites.includes(tool.id);
          return (
            <div
              key={tool.id}
              className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group hover:border-rose-200 dark:hover:border-slate-700"
            >
              <div>
                {/* Card Top: Icon, Tag & Favorite Star */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center border border-slate-100 dark:border-slate-700 shadow-2xs group-hover:scale-105 transition-transform">
                    {getToolIcon(tool.iconName)}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {tool.emergencyRelevant && (
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-900">
                        Urgence
                      </span>
                    )}
                    <button
                      onClick={() => onToggleFavorite(tool.id)}
                      className={`p-1.5 rounded-lg transition-colors ${
                        isFav
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-slate-300 dark:text-slate-600 hover:text-amber-400'
                      }`}
                      title={isFav ? 'Retirer des favoris' : 'Ajouter aux favoris'}
                    >
                      <Star className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Title & Description */}
                <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base leading-snug mb-1 group-hover:text-rose-600 transition-colors">
                  {tool.titleKey}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                  {tool.shortDescriptionKey}
                </p>
              </div>

              {/* Action Buttons: Short & Full */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <button
                  onClick={() => onOpenTool(tool, 'short')}
                  className="flex-1 py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/30 dark:hover:bg-rose-900/40 text-rose-700 dark:text-rose-300 text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-2xs"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Court ({tool.durationShortMin} min)</span>
                </button>

                <button
                  onClick={() => onOpenTool(tool, 'full')}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-2xs"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Complet ({tool.durationFullMin} min)</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
