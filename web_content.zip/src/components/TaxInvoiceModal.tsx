import React from 'react';
import { X, Printer, Share2, Download, QrCode } from 'lucide-react';
import { Voucher, Company, Ledger } from '../types/tally';
import { formatCurrency, formatINR, formatDateDisplay, numberToWordsINR } from '../utils/tallyEngine';
import { triggerHaptic } from '../utils/haptics';

interface TaxInvoiceModalProps {
  voucher: Voucher;
  company: Company;
  partyLedger?: Ledger;
  onClose: () => void;
}

export const TaxInvoiceModal: React.FC<TaxInvoiceModalProps> = ({
  voucher,
  company,
  partyLedger,
  onClose,
}) => {
  const isInvoice = voucher.voucherType === 'sales' || voucher.voucherType === 'purchase';

  const handlePrint = () => {
    triggerHaptic('light');
    window.print();
  };

  const handleShareWhatsApp = () => {
    triggerHaptic('light');
    const msg = `*TAX INVOICE*\n*${company.name}*\nInvoice No: ${voucher.voucherNumber}\nDate: ${formatDateDisplay(voucher.date)}\nBilled To: ${voucher.partyLedgerName || 'Customer'}\nTotal Amount: ${formatCurrency(voucher.totalAmount)}\nThank you for your business!`;
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4">
      <div className="w-full max-w-xl bg-white text-slate-900 rounded-t-3xl sm:rounded-2xl border border-slate-300 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Top Control Bar */}
        <div className="bg-emerald-950 text-white px-4 py-2.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              Tax Invoice Preview
            </span>
            <span className="text-emerald-400">·</span>
            <span className="text-xs font-mono">{voucher.voucherNumber}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-xs font-medium transition-colors touch-press"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">WhatsApp</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-white px-2.5 py-1 rounded-lg text-xs font-medium transition-colors touch-press"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-300 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Sheet */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-white space-y-4 text-xs font-sans text-slate-800">
          {/* Invoice Header */}
          <div className="text-center pb-2 border-b-2 border-slate-800">
            <h1 className="text-lg font-black tracking-tight uppercase text-slate-950">
              TAX INVOICE
            </h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">
              (Issued under Section 31 of CGST Act, 2017)
            </p>
          </div>

          {/* Supplier & Invoice Meta Split */}
          <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-300">
            <div>
              <h2 className="font-bold text-sm text-slate-900">{company.name}</h2>
              <p className="text-[11px] text-slate-600 mt-0.5">{company.address}</p>
              <p className="text-[11px] text-slate-600">
                {company.city}, {company.state} - {company.pincode}
              </p>
              <p className="text-[11px] font-mono mt-1 font-semibold text-slate-900">
                GSTIN: {company.gstin}
              </p>
              <p className="text-[11px] text-slate-600">Phone: {company.phone}</p>
            </div>

            <div className="text-right font-mono text-[11px] space-y-1">
              <div>
                <span className="text-slate-500 font-sans">Invoice No:</span>{' '}
                <strong className="text-slate-900 text-xs">{voucher.voucherNumber}</strong>
              </div>
              <div>
                <span className="text-slate-500 font-sans">Invoice Date:</span>{' '}
                <strong>{formatDateDisplay(voucher.date)}</strong>
              </div>
              {voucher.referenceNo && (
                <div>
                  <span className="text-slate-500 font-sans">Buyer's Ref:</span>{' '}
                  <strong>{voucher.referenceNo}</strong>
                </div>
              )}
              <div>
                <span className="text-slate-500 font-sans">State of Supply:</span>{' '}
                <strong>{company.state} (Code 27)</strong>
              </div>
            </div>
          </div>

          {/* Buyer Details */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1">
              Billed To (Recipient / Buyer)
            </div>
            <div className="font-bold text-xs text-slate-900">
              {voucher.partyLedgerName || 'Cash Sale / Customer'}
            </div>
            {partyLedger?.address && (
              <div className="text-[11px] text-slate-600 mt-0.5">{partyLedger.address}</div>
            )}
            <div className="text-[11px] font-mono mt-1 text-slate-700 flex flex-wrap gap-x-4">
              {partyLedger?.gstin && <span>GSTIN: {partyLedger.gstin}</span>}
              {partyLedger?.phone && <span>Ph: {partyLedger.phone}</span>}
            </div>
          </div>

          {/* Line Items Table */}
          {isInvoice && voucher.items && voucher.items.length > 0 ? (
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <table className="w-full text-[11px] text-left">
                <thead className="bg-slate-100 border-b border-slate-300 text-[10px] font-bold uppercase text-slate-700">
                  <tr>
                    <th className="p-2 w-8 text-center">#</th>
                    <th className="p-2">Description of Goods</th>
                    <th className="p-2 w-14 text-center">HSN</th>
                    <th className="p-2 w-12 text-center">Qty</th>
                    <th className="p-2 w-16 text-right">Rate</th>
                    <th className="p-2 w-20 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {voucher.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="p-2 text-center text-slate-500">{idx + 1}</td>
                      <td className="p-2 font-sans font-medium text-slate-900">
                        {item.itemName}
                      </td>
                      <td className="p-2 text-center text-slate-500">{item.hsnCode || '8471'}</td>
                      <td className="p-2 text-center font-bold">
                        {item.qty} {item.unit}
                      </td>
                      <td className="p-2 text-right">{formatINR(item.rate)}</td>
                      <td className="p-2 text-right font-bold text-slate-900">
                        {formatINR(item.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            /* For Financial Vouchers (Payment/Receipt) */
            <div className="border border-slate-200 rounded-lg p-3 space-y-1.5 font-mono text-xs">
              <div className="font-bold text-slate-900 uppercase">Accounting Details</div>
              {voucher.rows?.map((r, i) => (
                <div key={i} className="flex justify-between py-1 border-b border-slate-100">
                  <span>
                    {r.type}: {r.ledgerName}
                  </span>
                  <span className="font-bold">{formatCurrency(r.amount)}</span>
                </div>
              ))}
            </div>
          )}

          {/* Tax Breakdown & Total */}
          <div className="flex justify-end">
            <div className="w-64 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Taxable Value:</span>
                <span>{formatCurrency(voucher.taxableAmount || voucher.totalAmount)}</span>
              </div>

              {voucher.cgstAmount > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>CGST (Central Tax 9%):</span>
                  <span>{formatCurrency(voucher.cgstAmount)}</span>
                </div>
              )}

              {voucher.sgstAmount > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>SGST (State Tax 9%):</span>
                  <span>{formatCurrency(voucher.sgstAmount)}</span>
                </div>
              )}

              {voucher.igstAmount > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>IGST (Integrated Tax 18%):</span>
                  <span>{formatCurrency(voucher.igstAmount)}</span>
                </div>
              )}

              {voucher.roundOff !== 0 && (
                <div className="flex justify-between text-slate-500 text-[10px]">
                  <span>Round Off:</span>
                  <span>{voucher.roundOff}</span>
                </div>
              )}

              <div className="pt-2 border-t-2 border-slate-800 flex justify-between font-bold text-sm text-slate-950">
                <span>Total Invoice Value:</span>
                <span>{formatCurrency(voucher.totalAmount)}</span>
              </div>
            </div>
          </div>

          {/* Amount in words */}
          <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <span className="text-[10px] text-slate-400 uppercase font-bold block font-sans">
              Invoice Amount in Words:
            </span>
            <span className="font-semibold text-slate-900">
              {numberToWordsINR(voucher.totalAmount)}
            </span>
          </div>

          {/* Narration */}
          {voucher.narration && (
            <div className="text-[11px] text-slate-600 italic">
              <strong>Narration / Remarks:</strong> {voucher.narration}
            </div>
          )}

          {/* Footer: Bank details & Signature */}
          <div className="pt-4 border-t border-slate-300 grid grid-cols-2 gap-4 text-[10px]">
            <div>
              <div className="font-bold text-slate-900 uppercase">Bank Payment Details:</div>
              <p>Bank: HDFC Bank Current A/c</p>
              <p>A/c No: 50200088912345</p>
              <p>IFSC Code: HDFC0001042</p>
              <p>Branch: MIDC Andheri East, Mumbai</p>
            </div>

            <div className="text-right flex flex-col justify-between">
              <div>
                <span className="font-bold text-slate-900 uppercase">
                  For {company.name}
                </span>
              </div>
              <div className="pt-8">
                <span className="border-t border-slate-400 pt-1 text-slate-600 block">
                  Authorized Signatory
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
