import React, { useEffect, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { WithdrawalRequest } from '../types';
import { reviewWithdrawalFn, walletErrorMessage } from '../wallet';

const STATUS_LABEL: Record<string, string> = {
  pending: 'قيد المراجعة',
  approved: 'موافق عليه، بانتظار التحويل',
  paid: 'تم التحويل',
  rejected: 'مرفوض',
  cancelled: 'ملغي من المستخدم'
};

export const AdminWithdrawals: React.FC<{ showToast: (m: string) => void }> = ({ showToast }) => {
  const [list, setList] = useState<WithdrawalRequest[]>([]);
  const [filter, setFilter] = useState<'open' | 'all'>('open');
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'withdrawals'),
      (snap) => {
        const l = snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
        l.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setList(l);
      },
      (e) => console.error('Withdrawals listener error:', e)
    );
    return () => unsub();
  }, []);

  const act = async (w: WithdrawalRequest, decision: 'approve' | 'reject' | 'paid') => {
    setBusyId(w.id);
    try {
      await reviewWithdrawalFn(w.id, decision, notes[w.id]);
      showToast(decision === 'paid' ? 'تم تسجيل التحويل' : decision === 'approve' ? 'تمت الموافقة' : 'تم الرفض وإرجاع المبلغ للمستخدم');
    } catch (err) {
      showToast(walletErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const shown = list.filter((w) => (filter === 'all' ? true : w.status === 'pending' || w.status === 'approved'));

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-3" dir="rtl">
      <div className="flex gap-2 text-xs">
        {(['open', 'all'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer ${filter === f ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'}`}
          >
            {f === 'open' ? 'المفتوحة' : 'الكل'}
          </button>
        ))}
      </div>
      {shown.length === 0 && <p className="text-xs text-slate-500">لا توجد طلبات.</p>}
      {shown.map((w) => (
        <div key={w.id} className="p-3 rounded-2xl bg-white border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-black text-slate-900">{w.userDisplayName || w.userId}</span>
            <span className="text-[10px] font-bold text-slate-600">{STATUS_LABEL[w.status] || w.status}</span>
          </div>
          <div className="text-slate-700">
            المطلوب تحويله: <strong>{w.amountEGP} ج.م</strong> ({w.amountEarnings.toLocaleString('en-US')} من الأرباح)
          </div>
          <div className="text-slate-700">
            فودافون كاش: <strong className="font-mono" dir="ltr">{w.phone}</strong>
          </div>
          <div className="text-[10px] text-slate-500">{w.userEmail} · {new Date(w.createdAt).toLocaleString('ar-EG')}</div>
          {(w.status === 'pending' || w.status === 'approved') && (
            <>
              <input
                value={notes[w.id] || ''}
                onChange={(e) => setNotes((p) => ({ ...p, [w.id]: e.target.value }))}
                placeholder="ملاحظة (إلزامية عند الرفض)"
                className="w-full px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs"
              />
              <div className="flex gap-2">
                {w.status === 'pending' && (
                  <button disabled={busyId === w.id} onClick={() => act(w, 'approve')} className="px-3 py-1.5 rounded-xl bg-sky-600 text-white font-bold disabled:opacity-50 cursor-pointer">
                    موافقة
                  </button>
                )}
                {w.status === 'approved' && (
                  <button disabled={busyId === w.id} onClick={() => act(w, 'paid')} className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold disabled:opacity-50 cursor-pointer">
                    تم التحويل
                  </button>
                )}
                <button disabled={busyId === w.id} onClick={() => act(w, 'reject')} className="px-3 py-1.5 rounded-xl bg-red-600 text-white font-bold disabled:opacity-50 cursor-pointer">
                  رفض
                </button>
              </div>
            </>
          )}
          {w.status === 'rejected' && w.adminNote && <div className="text-[10px] text-red-600">سبب الرفض: {w.adminNote}</div>}
        </div>
      ))}
    </div>
  );
};
