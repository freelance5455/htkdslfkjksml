import React, { useState, useMemo } from 'react';
import { Track, SortField, SortDirection } from '../types/audio';
import {
  Folder,
  FolderOpen,
  Music,
  ArrowUpDown,
  Upload,
  FolderPlus,
  Heart,
  Play,
  Pause,
  ListPlus,
  Clock,
  HardDrive,
  ChevronRight,
  Disc3,
  Search
} from 'lucide-react';

interface Props {
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  onTogglePlay: () => void;
  onToggleFavorite: (trackId: string) => void;
  onImportFiles: (files: FileList) => void;
  onOpenPlaylistModal: (track: Track) => void;
}

export const LibraryView: React.FC<Props> = ({
  tracks,
  currentTrack,
  isPlaying,
  onPlayTrack,
  onTogglePlay,
  onToggleFavorite,
  onImportFiles,
  onOpenPlaylistModal,
}) => {
  const [viewMode, setViewMode] = useState<'alpha' | 'folders'>('alpha');
  const [sortField, setSortField] = useState<SortField>('title');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);

  // Group tracks by folder path
  const folderTree = useMemo(() => {
    const folders: Record<string, Track[]> = {};
    tracks.forEach((track) => {
      const folder = track.folderPath || 'Raíz / Sin Carpeta';
      if (!folders[folder]) folders[folder] = [];
      folders[folder].push(track);
    });
    return folders;
  }, [tracks]);

  // Sort tracks for alphabetical view
  const sortedTracks = useMemo(() => {
    const list = [...tracks];
    list.sort((a, b) => {
      let valA: string | number = '';
      let valB: string | number = '';

      if (sortField === 'title') {
        valA = a.title.toLowerCase();
        valB = b.title.toLowerCase();
      } else if (sortField === 'artist') {
        valA = a.artist.toLowerCase();
        valB = b.artist.toLowerCase();
      } else if (sortField === 'album') {
        valA = a.album.toLowerCase();
        valB = b.album.toLowerCase();
      } else if (sortField === 'duration') {
        valA = a.duration;
        valB = b.duration;
      } else if (sortField === 'dateAdded') {
        valA = a.dateAdded;
        valB = b.dateAdded;
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    return list;
  }, [tracks, sortField, sortDirection]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Toolbar: View switcher, Import buttons, Sort menu */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        {/* Toggle between Alphabetical and Folders */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => {
              setViewMode('alpha');
              setSelectedFolder(null);
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-lg transition ${
              viewMode === 'alpha'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Orden Alfabético</span>
          </button>
          <button
            onClick={() => setViewMode('folders')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-lg transition ${
              viewMode === 'folders'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5" />
            <span>Por Carpetas</span>
          </button>
        </div>

        {/* Action: Import audio files and folders */}
        <div className="flex items-center gap-2">
          {/* File input */}
          <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl cursor-pointer transition">
            <Upload className="w-3.5 h-3.5 text-indigo-400" />
            <span>Importar Archivos</span>
            <input
              type="file"
              multiple
              accept="audio/*,.mp3,.ogg,.wav,.flac,.m4a,.aac"
              onChange={(e) => e.target.files && onImportFiles(e.target.files)}
              className="hidden"
            />
          </label>

          {/* Folder input */}
          <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl cursor-pointer transition">
            <FolderPlus className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Importar Carpeta</span>
            <span className="sm:hidden">Carpeta</span>
            <input
              type="file"
              multiple
              // @ts-expect-error webkitdirectory is standard for folder pickers in Chromium/Safari
              webkitdirectory=""
              onChange={(e) => e.target.files && onImportFiles(e.target.files)}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* VIEW MODE 1: ALPHABETICAL ORDER */}
      {viewMode === 'alpha' && (
        <div className="space-y-4">
          {/* Sort bar buttons */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className="text-slate-500 mr-1 flex items-center gap-1">
              <ArrowUpDown className="w-3 h-3" />
              Ordenar por:
            </span>
            {[
              { field: 'title' as SortField, label: 'Título' },
              { field: 'artist' as SortField, label: 'Artista' },
              { field: 'album' as SortField, label: 'Álbum' },
              { field: 'duration' as SortField, label: 'Duración' },
              { field: 'dateAdded' as SortField, label: 'Fecha' },
            ].map(({ field, label }) => {
              const isActive = sortField === field;
              return (
                <button
                  key={field}
                  onClick={() => toggleSort(field)}
                  className={`px-2.5 py-1 rounded-lg border text-xs transition flex items-center gap-1 ${
                    isActive
                      ? 'bg-slate-800 border-indigo-500/80 text-indigo-300 font-medium'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{label}</span>
                  {isActive && <span>{sortDirection === 'asc' ? '▲' : '▼'}</span>}
                </button>
              );
            })}
            <span className="text-[11px] text-slate-500 ml-auto tabular-nums">
              {tracks.length} canciones
            </span>
          </div>

          {/* Track list */}
          <div className="space-y-1.5">
            {sortedTracks.map((track) => {
              const isCurrent = currentTrack?.id === track.id;
              return (
                <div
                  key={track.id}
                  className={`group flex items-center justify-between p-3 rounded-xl border transition ${
                    isCurrent
                      ? 'bg-indigo-950/30 border-indigo-500/50'
                      : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700/80'
                  }`}
                >
                  {/* Left: Thumbnail & Track info */}
                  <div
                    onClick={() => onPlayTrack(track)}
                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="relative w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-slate-800 border border-slate-700/50">
                      <img
                        src={track.coverUrl || '/icon.svg'}
                        alt={track.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        {isCurrent && isPlaying ? (
                          <Pause className="w-5 h-5 text-white" />
                        ) : (
                          <Play className="w-5 h-5 text-white ml-0.5" />
                        )}
                      </div>
                      {isCurrent && (
                        <div className="absolute bottom-1 right-1 w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <p
                        className={`text-sm font-semibold truncate ${
                          isCurrent ? 'text-indigo-400' : 'text-slate-200'
                        }`}
                      >
                        {track.title}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 truncate">
                        <span className="truncate">{track.artist}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate text-slate-500">{track.album}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Format tag, Duration, Favorite & Playlist trigger */}
                  <div className="flex items-center gap-3 shrink-0 ml-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 px-1.5 py-0.5 bg-slate-800 rounded">
                      {track.format}
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-400 hidden sm:inline">
                      {formatDuration(track.duration)}
                    </span>

                    <button
                      onClick={() => onToggleFavorite(track.id)}
                      className={`p-2 rounded-lg transition ${
                        track.isFavorite
                          ? 'text-pink-500 hover:text-pink-400'
                          : 'text-slate-500 hover:text-slate-300'
                      }`}
                      title={track.isFavorite ? 'Quitar de favoritos' : 'Añadir a favoritos'}
                    >
                      <Heart className={`w-4 h-4 ${track.isFavorite ? 'fill-current' : ''}`} />
                    </button>

                    <button
                      onClick={() => onOpenPlaylistModal(track)}
                      className="p-2 text-slate-500 hover:text-slate-300 rounded-lg transition"
                      title="Añadir a lista de reproducción"
                    >
                      <ListPlus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW MODE 2: FOLDER HIERARCHY */}
      {viewMode === 'folders' && (
        <div className="space-y-4">
          {/* Breadcrumb if in folder */}
          {selectedFolder ? (
            <div className="flex items-center gap-2 pb-2">
              <button
                onClick={() => setSelectedFolder(null)}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
              >
                <span>Todas las Carpetas</span>
              </button>
              <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
              <span className="text-xs font-semibold text-slate-200 truncate">{selectedFolder}</span>
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              Explora y reproduce tus archivos agrupados por estructura de carpetas de almacenamiento.
            </p>
          )}

          {selectedFolder ? (
            // Tracks inside selected folder
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-slate-900 border border-slate-800 rounded-xl mb-3">
                <div className="flex items-center gap-2 text-xs text-slate-300 font-medium">
                  <FolderOpen className="w-4 h-4 text-indigo-400" />
                  <span>{selectedFolder}</span>
                  <span className="text-slate-500">
                    ({folderTree[selectedFolder]?.length || 0} canciones)
                  </span>
                </div>
                <button
                  onClick={() => {
                    const first = folderTree[selectedFolder]?.[0];
                    if (first) onPlayTrack(first);
                  }}
                  className="px-3 py-1 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Reproducir Carpeta</span>
                </button>
              </div>

              {folderTree[selectedFolder]?.map((track) => {
                const isCurrent = currentTrack?.id === track.id;
                return (
                  <div
                    key={track.id}
                    onClick={() => onPlayTrack(track)}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition ${
                      isCurrent
                        ? 'bg-indigo-950/30 border-indigo-500/50'
                        : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Music className={`w-4 h-4 shrink-0 ${isCurrent ? 'text-indigo-400' : 'text-slate-500'}`} />
                      <div className="min-w-0">
                        <p className={`text-xs font-semibold truncate ${isCurrent ? 'text-indigo-400' : 'text-slate-200'}`}>
                          {track.title}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate">{track.artist}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[10px] font-mono uppercase text-slate-400 px-1.5 py-0.5 bg-slate-800 rounded">
                        {track.format}
                      </span>
                      <span className="text-xs font-mono tabular-nums text-slate-400">
                        {formatDuration(track.duration)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            // Grid of folders
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.entries(folderTree).map(([folderPath, trackList]) => (
                <div
                  key={folderPath}
                  onClick={() => setSelectedFolder(folderPath)}
                  className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-850 cursor-pointer transition flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0 group-hover:bg-indigo-500/20 transition-colors">
                      <Folder className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-200 truncate group-hover:text-white">
                        {folderPath}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {trackList.length} {trackList.length === 1 ? 'canción' : 'canciones'}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-slate-400 shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
