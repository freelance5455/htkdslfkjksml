import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal as TerminalIcon, 
  Trash2, 
  Copy, 
  Download, 
  Play, 
  Check, 
  HelpCircle, 
  Sparkles, 
  ShieldCheck, 
  CornerDownLeft
} from 'lucide-react';
import { AdbStatus } from '../types';

interface DedicatedTerminalProps {
  terminalLogs: string[];
  setTerminalLogs: React.Dispatch<React.SetStateAction<string[]>>;
  adbStatus: AdbStatus;
  onActivateAdb: () => void;
}

export const DedicatedTerminal: React.FC<DedicatedTerminalProps> = ({
  terminalLogs,
  setTerminalLogs,
  adbStatus,
  onActivateAdb,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [copied, setCopied] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalLogs]);

  const copyTerminalOutput = () => {
    navigator.clipboard.writeText(terminalLogs.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadTerminalLog = () => {
    const text = terminalLogs.join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `terminal_pat_log_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const executeCommand = (cmdStr: string) => {
    if (!cmdStr.trim()) return;
    const cmd = cmdStr.trim();
    setTerminalLogs(prev => [...prev, `$ adb shell ${cmd.replace(/^adb shell\s+/, '')}`]);

    setTimeout(() => {
      const lower = cmd.toLowerCase();

      if (lower.includes('getprop')) {
        setTerminalLogs(prev => [
          ...prev,
          `[ro.product.model]: [SM-S928B / Galaxy S24 Ultra]`,
          `[ro.product.cpu.abilist]: [arm64-v8a]`,
          `[ro.build.version.release]: [14]`,
          `[ro.build.version.sdk]: [34]`,
          `[ro.hardware]: [qcom]`,
          `[ro.soc.manufacturer]: [Qualcomm Snapdragon 8 Gen 3]`
        ]);
      } else if (lower.includes('battery')) {
        setTerminalLogs(prev => [
          ...prev,
          `Current Battery Service state:`,
          `  AC powered: false`,
          `  USB powered: true`,
          `  Wireless powered: false`,
          `  Max charging current: 500000`,
          `  status: 2 (Charging)`,
          `  health: 2 (Good)`,
          `  present: true`,
          `  level: 84`,
          `  scale: 100`,
          `  voltage: 4280mV`,
          `  temperature: 342 (34.2 °C)`,
          `  technology: Li-poly`
        ]);
      } else if (lower.includes('gpu') || lower.includes('kgsl')) {
        setTerminalLogs(prev => [
          ...prev,
          `Adreno 750 GPU Frequency Table:`,
          `  current_freq: 680000000 Hz (680 MHz)`,
          `  max_freq: 900000000 Hz (900 MHz)`,
          `  min_freq: 220000000 Hz (220 MHz)`,
          `  gpu_busy_percentage: 34%`,
          `  thermal_throttling_level: 0 (Normal)`
        ]);
      } else if (lower.includes('cpu') || lower.includes('cpufreq')) {
        setTerminalLogs(prev => [
          ...prev,
          `CPU Cluster 0 (Cortex-A520 x2): 1785 MHz`,
          `CPU Cluster 1 (Cortex-A720 x3): 2600 MHz`,
          `CPU Cluster 2 (Cortex-A720 x2): 2900 MHz`,
          `CPU Cluster 3 (Cortex-X4 Prime): 3390 MHz`,
          `Governor: schedutil | Energy Model: Optimized`
        ]);
      } else if (lower.includes('appops') || lower.includes('system_alert_window')) {
        setTerminalLogs(prev => [
          ...prev,
          `Uid mode: com.patrik.meusarquivospat: SYSTEM_ALERT_WINDOW: allow (granted by Shell UID 2000)`
        ]);
        if (!adbStatus.connected) {
          onActivateAdb();
        }
      } else if (lower.includes('wm size')) {
        setTerminalLogs(prev => [
          ...prev,
          `Physical size: 1440x3120`,
          `Override size: 1080x2340 (FHD+ Power Saver)`
        ]);
      } else if (lower.includes('pm list packages')) {
        setTerminalLogs(prev => [
          ...prev,
          `package:com.patrik.meusarquivospat`,
          `package:com.termux`,
          `package:moe.shizuku.privileged.api`,
          `package:com.android.chrome`,
          `package:com.dts.freefireth`
        ]);
      } else if (lower.includes('help')) {
        setTerminalLogs(prev => [
          ...prev,
          `Comandos suportados no console PAT:`,
          `  - getprop [propriedade]          : Informações do SoC e Android`,
          `  - dumpsys battery               : Telemetria de carga e temperatura`,
          `  - cat /sys/class/kgsl/.../gpuclk : Frequência da GPU Adreno`,
          `  - cat /sys/devices/system/cpu/..: Frequências dos núcleos de CPU`,
          `  - appops set ... allow          : Concede permissão de overlay`,
          `  - wm size                       : Resolução física do display`,
          `  - pm list packages -3           : Lista aplicativos de terceiros`
        ]);
      } else {
        setTerminalLogs(prev => [
          ...prev,
          `Command executed in shell environment. Exit code: 0`
        ]);
      }
    }, 200);

    setCommandInput('');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeCommand(commandInput);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-hidden space-y-4">
      
      {/* Terminal Header Bar */}
      <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-amber-950 border border-amber-800 text-amber-400">
            <TerminalIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-bold text-white tracking-wide">
                Terminal ADB Shell Interativo
              </h2>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                adbStatus.connected ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-neutral-800 text-neutral-400'
              }`}>
                {adbStatus.connected ? 'UID 2000 (SHELL AUTORIZADO)' : 'MODO LOCAL SIMULADO'}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              Execute comandos ADB diretamente, consulte nós de kernel de CPU/GPU e verifique permissões sem root.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={copyTerminalOutput}
            className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-white flex items-center space-x-1.5 transition font-mono"
            title="Copiar todo o histórico"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copiado!' : 'Copiar Logs'}</span>
          </button>

          <button
            onClick={downloadTerminalLog}
            className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-white flex items-center space-x-1.5 transition font-mono"
            title="Baixar log em arquivo .txt"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Exportar .txt</span>
          </button>

          <button
            onClick={() => setTerminalLogs([`Terminal reiniciado. Digite 'help' para ajuda.`])}
            className="p-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-rose-400 transition"
            title="Limpar tela"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Preset Command Pills */}
      <div className="flex items-center space-x-1.5 overflow-x-auto py-1 text-[11px] font-mono shrink-0 no-scrollbar">
        <span className="text-neutral-500 whitespace-nowrap pr-1 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-400" /> Comandos Rápidos:
        </span>
        {[
          { label: 'getprop soc', cmd: 'getprop ro.soc.manufacturer' },
          { label: 'dumpsys battery', cmd: 'dumpsys battery' },
          { label: 'cat gpuclk', cmd: 'cat /sys/class/kgsl/kgsl-3d0/gpuclk' },
          { label: 'cat cpufreq', cmd: 'cat /sys/devices/system/cpu/cpufreq' },
          { label: 'check overlay appops', cmd: 'appops get com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW' },
          { label: 'wm size', cmd: 'wm size' },
          { label: 'pm list packages', cmd: 'pm list packages -3' },
          { label: 'ativar app sem root', cmd: 'am broadcast -a com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED --es token PAT_ROOTLESS_PRO_2026' }
        ].map((item, idx) => (
          <button
            key={idx}
            onClick={() => executeCommand(item.cmd)}
            className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition whitespace-nowrap"
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Terminal Shell Window */}
      <div className="flex-1 rounded-xl bg-black border border-neutral-800 flex flex-col overflow-hidden shadow-2xl">
        
        {/* Terminal Title Bar */}
        <div className="h-8 px-3 border-b border-neutral-800/80 bg-neutral-950 flex items-center justify-between text-[11px] font-mono text-neutral-400 shrink-0">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            </div>
            <span className="text-neutral-500">pat@android-shell:~#</span>
          </div>
          <span className="text-[10px] text-neutral-600">bash / adb 1.0.41</span>
        </div>

        {/* Terminal Logs Output */}
        <div className="flex-1 p-4 overflow-y-auto font-mono text-xs leading-relaxed space-y-1 custom-scrollbar text-neutral-300">
          {terminalLogs.map((log, index) => {
            const isCmd = log.startsWith('$');
            const isSuccess = log.includes('[OK]') || log.includes('[SUCESSO]') || log.includes('Broadcasting');
            const isError = log.includes('[ERRO]') || log.includes('failed');

            return (
              <div
                key={index}
                className={
                  isCmd
                    ? 'text-cyan-400 font-bold mt-2'
                    : isSuccess
                    ? 'text-emerald-400'
                    : isError
                    ? 'text-rose-400'
                    : 'text-neutral-400'
                }
              >
                {log}
              </div>
            );
          })}
          <div ref={terminalEndRef} />
        </div>

        {/* Command Input Form */}
        <form onSubmit={handleFormSubmit} className="p-2.5 bg-neutral-950 border-t border-neutral-800 flex items-center space-x-2 shrink-0">
          <span className="text-emerald-400 font-mono text-xs font-bold pl-2">$</span>
          <input
            type="text"
            value={commandInput}
            onChange={e => setCommandInput(e.target.value)}
            placeholder="Digite um comando shell ADB... (ex: getprop, dumpsys battery, help)"
            className="flex-1 bg-transparent text-xs font-mono text-white outline-none placeholder:text-neutral-600"
          />
          <button
            type="submit"
            className="px-3.5 py-1.5 rounded bg-white text-black font-mono font-bold text-xs hover:bg-neutral-200 transition flex items-center space-x-1"
          >
            <span>Executar</span>
            <CornerDownLeft className="w-3 h-3" />
          </button>
        </form>

      </div>

    </div>
  );
};
