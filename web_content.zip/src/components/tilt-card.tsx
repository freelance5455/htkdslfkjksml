"use client";

import Link from "next/link";
import type { MouseEvent, ReactNode } from "react";

/**
 * A link card with a subtle 3D tilt and a cursor-following gold glow.
 * The tilt is driven by CSS custom properties (--rx, --ry, --mx, --my, --gx, --gy)
 * that the inner visuals (e.g. parallax images) also read.
 */
export function TiltCard({
  href,
  ariaLabel,
  className = "",
  children,
}: {
  href: string;
  ariaLabel: string;
  className?: string;
  children: ReactNode;
}) {
  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    el.style.setProperty("--mx", (x - 0.5).toFixed(3));
    el.style.setProperty("--my", (y - 0.5).toFixed(3));
    el.style.setProperty("--rx", `${((0.5 - y) * 7).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${((x - 0.5) * 7).toFixed(2)}deg`);
    el.style.setProperty("--gx", `${(x * 100).toFixed(1)}%`);
    el.style.setProperty("--gy", `${(y * 100).toFixed(1)}%`);
  };

  const handleLeave = (e: MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    ["--mx", "--my", "--rx", "--ry"].forEach((p) => el.style.setProperty(p, p.startsWith("--r") ? "0deg" : "0"));
  };

  return (
    <Link
      href={href}
      aria-label={ariaLabel}
      className={`block h-full rounded-[2rem] outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-4 focus-visible:ring-offset-ivory ${className}`}
    >
      <div className="h-full [perspective:1200px]" onMouseMove={handleMove} onMouseLeave={handleLeave}>
        <div className="group/tilt relative h-full rounded-[2rem] transition-transform duration-300 ease-out [transform-style:preserve-3d] [transform:rotateX(var(--rx,0deg))_rotateY(var(--ry,0deg))]">
          {children}
          <div
            className="pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover/tilt:opacity-100"
            style={{
              background:
                "radial-gradient(500px circle at var(--gx,50%) var(--gy,50%), rgba(230,212,173,0.22), transparent 45%)",
            }}
            aria-hidden="true"
          />
        </div>
      </div>
    </Link>
  );
}
