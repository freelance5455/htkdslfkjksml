import React from 'react';
import { DailyStreakData, STREAK_REWARDS } from '../types';
import { X, Flame, Coins, Check, Lock, Sparkles, Trophy } from 'lucide-react';

interface DailyStreakModalProps {
  streakData: DailyStreakData;
  canClaim: boolean;
  dayIndexToClaim: number;
  onClaim: () => void;
  onClose: () => void;
}

export const DailyStreakModal: React.FC<DailyStreakModalProps> = ({
  streakData,
  canClaim,
  dayIndexToClaim,
  onClaim,
  onClose,
}) => {
  const currentReward = STREAK_REWARDS[dayIndexToClaim] || STREAK_REWARDS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="relative flex w-full max-w-sm flex-col max-h-[92vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl overflow-y-auto no-scrollbar">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Flame className="h-5 w-5 text-orange-400 fill-orange-400 animate-bounce" />
            <h2 className="text-lg font-black text-white">DAILY STREAK</h2>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Streak Highlight Banner */}
        <div className="my-4 flex flex-col items-center rounded-2xl bg-gradient-to-b from-orange-500/20 via-slate-950/80 to-slate-950/80 p-4 border border-orange-500/30 text-center shadow-[0_0_25px_rgba(249,115,22,0.15)]">
          <div className="relative mb-2 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-lg shadow-orange-500/30">
            <Flame className="h-8 w-8 fill-white" />
          </div>

          <h3 className="text-xl font-black text-white flex items-center gap-1.5">
            <span>{streakData.currentStreak} DAY STREAK!</span>
          </h3>
          <p className="mt-1 text-xs text-slate-400 max-w-[240px]">
            {canClaim
              ? "You've returned! Claim your streak bonus now."
              : "Come back tomorrow to keep your streak blazing!"}
          </p>
        </div>

        {/* 7-Day Rewards Ladder */}
        <div className="grid grid-cols-4 gap-2 mb-2">
          {STREAK_REWARDS.slice(0, 6).map((item, idx) => {
            const isClaimed = idx < dayIndexToClaim || (!canClaim && idx === dayIndexToClaim);
            const isToday = idx === dayIndexToClaim;
            const isFuture = idx > dayIndexToClaim;

            return (
              <div
                key={item.day}
                className={`relative flex flex-col items-center justify-between rounded-2xl p-2.5 border transition-all ${
                  isToday && canClaim
                    ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.35)] scale-105 z-10'
                    : isClaimed
                    ? 'bg-emerald-950/30 border-emerald-500/40 opacity-90'
                    : 'bg-slate-950/60 border-slate-800/80 opacity-70'
                }`}
              >
                <span className="text-[10px] font-bold uppercase text-slate-400">
                  {item.label}
                </span>

                <div className="my-1.5 flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80">
                  {isClaimed ? (
                    <Check className="h-4 w-4 text-emerald-400" />
                  ) : isToday && canClaim ? (
                    <Sparkles className="h-4 w-4 text-amber-300 animate-spin" />
                  ) : (
                    <Coins className="h-4 w-4 text-amber-400 fill-amber-400/20" />
                  )}
                </div>

                <span
                  className={`text-xs font-mono font-black tabular-nums ${
                    isToday && canClaim ? 'text-amber-300' : isClaimed ? 'text-emerald-400' : 'text-slate-300'
                  }`}
                >
                  +{item.coins}
                </span>
              </div>
            );
          })}

          {/* Day 7: Double-width Mega Jackpot Card */}
          {STREAK_REWARDS.slice(6, 7).map((item) => {
            const isClaimed = 6 < dayIndexToClaim || (!canClaim && 6 === dayIndexToClaim);
            const isToday = 6 === dayIndexToClaim;

            return (
              <div
                key={item.day}
                className={`col-span-2 relative flex items-center justify-between rounded-2xl p-3 border transition-all ${
                  isToday && canClaim
                    ? 'bg-gradient-to-r from-amber-500/30 to-yellow-500/30 border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.4)] scale-102'
                    : isClaimed
                    ? 'bg-emerald-950/30 border-emerald-500/40 opacity-90'
                    : 'bg-gradient-to-r from-slate-950 to-indigo-950/40 border-indigo-500/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40">
                    <Trophy className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">
                      DAY 7 JACKPOT
                    </span>
                    <span className="text-xs font-bold text-white">Mega Chest</span>
                  </div>
                </div>

                <div className="flex flex-col items-end">
                  <span className="font-mono text-sm font-black text-amber-300 tabular-nums">
                    +{item.coins}
                  </span>
                  {isClaimed && (
                    <span className="text-[9px] font-bold text-emerald-400 flex items-center gap-0.5">
                      <Check className="h-3 w-3" /> Claimed
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Claim or Status CTA */}
        <div className="mt-3 flex flex-col gap-2">
          {canClaim ? (
            <button
              onClick={onClaim}
              className="flex h-13 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-sm shadow-[0_4px_25px_rgba(245,158,11,0.4)] active:scale-95 transition-all hover:brightness-110"
            >
              <Coins className="h-4 w-4" />
              <span>CLAIM REWARD (+{currentReward.coins} COINS)</span>
            </button>
          ) : (
            <div className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-slate-800/80 text-emerald-400 font-bold text-xs border border-emerald-500/30">
              <Check className="h-4 w-4" />
              <span>Claimed Today! Next reward unlocks at midnight</span>
            </div>
          )}

          <p className="text-[10px] text-slate-500 text-center">
            Total Days Logged: <span className="font-bold text-slate-400">{streakData.totalDaysLogged} days</span>
          </p>
        </div>
      </div>
    </div>
  );
};
