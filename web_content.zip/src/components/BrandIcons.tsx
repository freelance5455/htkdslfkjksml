import React from 'react';

interface BrandIconProps {
  brandKey: string;
  className?: string;
  size?: number;
}

export const BrandIcon: React.FC<BrandIconProps> = ({ brandKey, className = "w-10 h-10", size = 40 }) => {
  switch (brandKey.toLowerCase()) {
    case 'netflix':
      return (
        <svg viewBox="0 0 111 111" width={size} height={size} className={className} fill="none">
          <path d="M28 15V96H44V42L68 96H84V15H68V69L44 15H28Z" fill="#E50914" />
          <path d="M44 42L68 96H84V15H68L44 69V15H28V96H44V42Z" fill="url(#netflix-grad)" opacity="0.3" />
          <defs>
            <linearGradient id="netflix-grad" x1="28" y1="15" x2="84" y2="96" gradientUnits="userSpaceOnUse">
              <stop stopColor="#000000" stopOpacity="0.8" />
              <stop offset="1" stopColor="#E50914" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      );

    case 'youtube':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <rect x="15" y="28" width="90" height="64" rx="20" fill="#FF0000" />
          <polygon points="52,44 78,60 52,76" fill="#FFFFFF" />
        </svg>
      );

    case 'appletv':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          {/* Apple logo mark */}
          <path d="M60 22C62.5 18 66 15 70 15C70.5 19 68.5 23 65.5 26C62.5 29 59 30 58.5 29.5C58 26 60 22 60 22ZM74 54C74 44 82 39 82.5 38.5C78 32 71 31.5 68.5 31.5C62.5 31 57 35 54 35C51 35 46.5 31.5 41.5 31.5C33 31.5 25 38 25 50.5C25 63 36 88 44 88C48 88 50 85 55 85C60 85 62 88 66.5 88C74.5 88 80 75 83 70C74.5 65.5 74 56.5 74 54Z" fill="#FFFFFF" />
          <text x="88" y="75" fill="#FFFFFF" fontSize="26" fontWeight="bold" fontFamily="sans-serif">tv</text>
        </svg>
      );

    case 'primevideo':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <text x="20" y="58" fill="#FFFFFF" fontSize="30" fontWeight="800" fontFamily="sans-serif" fontStyle="italic">prime</text>
          {/* Amazon smile arrow */}
          <path d="M22 75C42 88 78 88 98 73C99 72 100 74 99 75C80 94 40 94 20 78C19 77 20 74 22 75Z" fill="#00A8E1" />
          <polygon points="94,68 102,73 98,82" fill="#00A8E1" />
        </svg>
      );

    case 'disneyplus':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          {/* Disney arch */}
          <path d="M20 75C35 30 85 28 100 70" stroke="#00D6FF" strokeWidth="6" strokeLinecap="round" />
          <text x="32" y="76" fill="#FFFFFF" fontSize="32" fontWeight="bold" fontFamily="serif">D+</text>
        </svg>
      );

    case 'plex':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <polygon points="35,25 65,60 35,95" fill="#E5A00D" />
          <polygon points="60,25 90,60 60,95" fill="#FFFFFF" opacity="0.9" />
        </svg>
      );

    case 'spotify':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <circle cx="60" cy="60" r="42" fill="#1DB954" />
          <path d="M40 48C56 43 78 46 86 51" stroke="#000000" strokeWidth="6" strokeLinecap="round" />
          <path d="M43 60C56 56 73 58 81 63" stroke="#000000" strokeWidth="5" strokeLinecap="round" />
          <path d="M46 72C56 69 68 70 75 74" stroke="#000000" strokeWidth="4.5" strokeLinecap="round" />
        </svg>
      );

    case 'twitch':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <polygon points="25,20 95,20 95,70 75,90 55,90 45,100 45,90 25,90" fill="#9146FF" />
          <polygon points="32,28 88,28 88,66 72,82 54,82 46,90 46,82 32,82" fill="#FFFFFF" />
          <rect x="50" y="44" width="7" height="18" fill="#9146FF" />
          <rect x="67" y="44" width="7" height="18" fill="#9146FF" />
        </svg>
      );

    case 'smarttube':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <rect x="20" y="28" width="80" height="64" rx="18" fill="#2BA640" />
          <polygon points="52,46 76,60 52,74" fill="#FFFFFF" />
          <circle cx="86" cy="38" r="6" fill="#FFFFFF" />
        </svg>
      );

    case 'kodi':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <rect x="30" y="30" width="60" height="60" rx="14" fill="#17B2E7" transform="rotate(45 60 60)" />
          <text x="44" y="68" fill="#FFFFFF" fontSize="24" fontWeight="900" fontFamily="sans-serif">K</text>
        </svg>
      );

    case 'stremio':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <circle cx="60" cy="60" r="42" fill="#7C3AED" />
          <polygon points="48,42 78,60 48,78" fill="#FFFFFF" />
          <circle cx="80" cy="40" r="5" fill="#38BDF8" />
        </svg>
      );

    case 'retroarch':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <path d="M25 45L40 75H52L56 68H64L68 75H80L95 45H75L68 55H52L45 45H25Z" fill="#F59E0B" />
          <circle cx="45" cy="58" r="4" fill="#FFFFFF" />
          <circle cx="75" cy="58" r="4" fill="#FFFFFF" />
        </svg>
      );

    case 'settings':
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <circle cx="60" cy="60" r="22" stroke="#FFFFFF" strokeWidth="8" />
          <path d="M60 20V32M60 88V100M20 60H32M88 60H100M32 32L40 40M80 80L88 88M88 32L80 40M40 80L32 88" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" />
        </svg>
      );

    default:
      return (
        <svg viewBox="0 0 120 120" width={size} height={size} className={className} fill="none">
          <rect x="25" y="25" width="70" height="70" rx="16" fill="rgba(255,255,255,0.2)" />
          <polygon points="50,42 76,60 50,78" fill="#FFFFFF" />
        </svg>
      );
  }
};
