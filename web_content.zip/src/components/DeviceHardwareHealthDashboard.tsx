import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Cpu,
  Battery,
  HardDrive,
  Activity,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Zap,
  Thermometer,
  ZapOff,
  CheckCircle2,
  Server
} from 'lucide-react';
import { deviceRegistryEngine, RegisteredDeviceRecord } from '../lib/deviceRegistryEngine';

export const DeviceHardwareHealthDashboard: React.FC = () => {
  const [devices, setDevices] = useState<RegisteredDeviceRecord[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [cpuTemp, setCpuTemp] = useState<number>(38.4);
  const [batteryHealth, setBatteryHealth] = useState<number>(98.5);
  const [storageWear, setStorageWear] = useState<number>(0.04);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    const list = deviceRegistryEngine.getAllRegisteredDevices();
    setDevices(list);
    if (list.length > 0) {
      setSelectedDeviceId(list[0].deviceId);
    }
  }, []);

  // Simulate live telemetry fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuTemp(prev => parseFloat((37 + Math.random() * 3.5).toFixed(1)));
      setBatteryHealth(prev => parseFloat((98 + Math.random() * 0.8).toFixed(1)));
      setStorageWear(prev => parseFloat((0.03 + Math.random() * 0.02).toFixed(3)));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleRefreshMetrics = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      setNotice('✓ Hardware health metrics successfully synchronized across 50,000,000 peer nodes.');
      setTimeout(() => setNotice(null), 4000);
    }, 800);
  };

  const activeDevice = devices.find(d => d.deviceId === selectedDeviceId) || devices[0];

  return (
    <div className="space-y-6 text-slate-100 font-sans">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/80 border-2 border-cyan-500/40 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 shadow-xl shadow-cyan-500/20">
            <Activity className="w-8 h-8 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                PROPHET OVERSIGHT • HARDWARE TELEMETRY
              </span>
              <span className="text-[10px] font-mono text-emerald-300 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Live Node Diagnostics
              </span>
            </div>
            <h2 className="text-xl font-black text-white tracking-tight mt-1">
              DEVICE HARDWARE HEALTH DASHBOARD
            </h2>
            <p className="text-xs text-slate-300 font-mono mt-0.5">
              Real-time CPU thermal throttling, battery cycle health & storage wear-leveling metrics across global mesh nodes.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={selectedDeviceId}
            onChange={(e) => setSelectedDeviceId(e.target.value)}
            className="bg-slate-950 border border-cyan-500/40 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyan-400 shadow"
          >
            {devices.map(d => (
              <option key={d.deviceId} value={d.deviceId}>
                {d.deviceName} ({d.registeredUser.fullName})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={handleRefreshMetrics}
            disabled={isRefreshing}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow cursor-pointer transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Refresh Telemetry</span>
          </button>
        </div>
      </div>

      {notice && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-xs font-mono text-cyan-200 flex items-center gap-2 shadow"
        >
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{notice}</span>
        </motion.div>
      )}

      {/* 3 Core Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: CPU Temperature */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-amber-500/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40">
              THERMAL MONITOR
            </span>
            <Thermometer className="w-5 h-5 text-amber-400 animate-pulse" />
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-mono">Live CPU Core Temperature</span>
            <div className="text-3xl font-black text-white font-mono flex items-baseline gap-2">
              <span>{cpuTemp}°C</span>
              <span className="text-xs font-normal text-emerald-400">Normal / Safe</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-slate-800 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">Thermal Throttling:</span>
              <strong className="text-emerald-400">Disabled (Optimal)</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Concurrency Load:</span>
              <strong className="text-cyan-300">{activeDevice?.hardwareConcurrency || 8} Cores Active</strong>
            </div>
          </div>
        </div>

        {/* Card 2: Battery Cycle Health */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-emerald-500/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              POWER SYSTEM
            </span>
            <Battery className="w-5 h-5 text-emerald-400" />
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-mono">Battery Cycle Health</span>
            <div className="text-3xl font-black text-white font-mono flex items-baseline gap-2">
              <span>{batteryHealth}%</span>
              <span className="text-xs font-normal text-emerald-400">Grade A+</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-slate-800 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">Charge Cycles:</span>
              <strong className="text-white">142 Cycles</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Fast Charge Status:</span>
              <strong className="text-emerald-400">Active (45W PD)</strong>
            </div>
          </div>
        </div>

        {/* Card 3: Storage Wear-Leveling */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              NAND FLASH
            </span>
            <HardDrive className="w-5 h-5 text-cyan-400" />
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-mono">Storage Wear-Leveling</span>
            <div className="text-3xl font-black text-white font-mono flex items-baseline gap-2">
              <span>{storageWear}%</span>
              <span className="text-xs font-normal text-cyan-300">Pristine</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-slate-800 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">SMART Status:</span>
              <strong className="text-emerald-400">PASSED (0 Errors)</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">RAM Allocation:</span>
              <strong className="text-white">{activeDevice?.deviceMemoryGb || '16 GB'}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Device Deep Telemetry Summary */}
      {activeDevice && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Server className="w-4 h-4 text-amber-400" />
              Active Hardware Telemetry: {activeDevice.deviceName}
            </h3>
            <span className="px-2.5 py-0.5 rounded bg-slate-800 text-amber-300 border border-amber-500/30 text-[10px]">
              {activeDevice.approvalStatus}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-slate-300">
            <div>
              <span className="text-slate-500 block text-[10px]">Serial Number:</span>
              <strong className="text-cyan-300 truncate block">{activeDevice.serialNumber}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Hardware IMEI:</span>
              <strong className="text-emerald-300">{activeDevice.imei}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Operating System:</span>
              <strong className="text-white truncate block">{activeDevice.osVersion}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Decentralized Node IP:</span>
              <strong className="text-amber-300 truncate block">{activeDevice.decentralizedNodeIp}</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
