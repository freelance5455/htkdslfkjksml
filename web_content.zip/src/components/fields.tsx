import { formatRial, parseAmount } from "@/lib/accounting/format";
import {
  JALALI_MONTHS,
  JALALI_WEEKDAYS,
  gregorianToJalali,
  isoToJalali,
  isoToJalaliTuple,
  jalaliMonthDays,
  jalaliToIso,
  parseJalaliInput,
  toEnDigits,
  toFaDigits,
} from "@/lib/accounting/jalali";
import { Input } from "@/components/ui";
import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";

export function MoneyText({ value, className }: { value: unknown; className?: string }) {
  const n = Number(value) || 0;
  return (
    <span className={cn("tabular", n < 0 ? "text-danger" : "", className)} dir="ltr">
      {formatRial(n)}
    </span>
  );
}

export function AmountInput({
  value,
  onChange,
  className,
}: {
  value: number;
  onChange: (n: number) => void;
  className?: string;
}) {
  const [raw, setRaw] = useState(value ? formatRial(value, false) : "");
  return (
    <Input
      dir="ltr"
      inputMode="numeric"
      className={className}
      value={raw}
      onChange={(e) => {
        const next = toEnDigits(e.target.value);
        setRaw(next);
        onChange(parseAmount(next));
      }}
      onBlur={() => setRaw(value ? formatRial(value, false) : "")}
    />
  );
}

export function JalaliDateField({ value, onChange }: { value: string; onChange: (iso: string) => void }) {
  const [open, setOpen] = useState(false);
  const [jy, jm] = isoToJalaliTuple(value || new Date().toISOString());
  const [cursor, setCursor] = useState<[number, number]>([jy, jm]);
  const days = jalaliMonthDays(cursor[0], cursor[1]);
  const firstIso = jalaliToIso(cursor[0], cursor[1], 1);
  const first = new Date(`${firstIso}T12:00:00`);
  const wd = (first.getDay() + 1) % 7;
  const cells = [...Array(wd).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const selected = isoToJalaliTuple(value);

  return (
    <div className="relative">
      <Input
        value={value ? isoToJalali(value) : ""}
        onChange={(e) => {
          const iso = parseJalaliInput(e.target.value);
          if (iso) onChange(iso);
        }}
        onFocus={() => setOpen(true)}
        placeholder="۱۴۰۵/۰۷/۰۴"
      />
      {open && (
        <div className="absolute z-20 mt-1 w-72 rounded-lg border border-line bg-card p-3 shadow-lg">
          <div className="mb-2 flex items-center justify-between text-sm">
            <button
              type="button"
              onClick={() => setCursor(([y, m]) => (m === 1 ? [y - 1, 12] : [y, m - 1]))}
            >
              ‹
            </button>
            <span>
              {JALALI_MONTHS[cursor[1] - 1]} {toFaDigits(cursor[0])}
            </span>
            <button
              type="button"
              onClick={() => setCursor(([y, m]) => (m === 12 ? [y + 1, 1] : [y, m + 1]))}
            >
              ›
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-muted">
            {JALALI_WEEKDAYS.map((d) => (
              <div key={d}>{d}</div>
            ))}
            {cells.map((d, i) =>
              d ? (
                <button
                  key={i}
                  type="button"
                  className={cn(
                    "h-8 rounded-md text-sm",
                    selected[0] === cursor[0] && selected[1] === cursor[1] && selected[2] === d
                      ? "bg-navy text-paper"
                      : "hover:bg-paper-2",
                  )}
                  onClick={() => {
                    onChange(jalaliToIso(cursor[0], cursor[1], d));
                    setOpen(false);
                  }}
                >
                  {toFaDigits(d)}
                </button>
              ) : (
                <div key={i} />
              ),
            )}
          </div>
          <button type="button" className="mt-2 text-xs text-muted" onClick={() => setOpen(false)}>
            بستن
          </button>
        </div>
      )}
    </div>
  );
}

type Opt = { id: string; label: string; sub?: string };

export function SearchSelect({
  options,
  value,
  onChange,
  placeholder,
  onCreate,
  createLabel,
}: {
  options: Opt[];
  value: string;
  onChange: (id: string) => void;
  placeholder: string;
  onCreate?: () => void;
  createLabel?: string;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.id === value);
  const filtered = useMemo(() => {
    const s = q.trim();
    if (!s) return options.slice(0, 12);
    return options.filter((o) => `${o.label} ${o.sub ?? ""}`.includes(s)).slice(0, 12);
  }, [options, q]);
  return (
    <div className="relative">
      <Input
        value={open ? q : selected ? `${selected.label}${selected.sub ? " — " + selected.sub : ""}` : ""}
        placeholder={placeholder}
        onFocus={() => {
          setOpen(true);
          setQ("");
        }}
        onChange={(e) => setQ(e.target.value)}
      />
      {open && (
        <div className="absolute z-20 mt-1 max-h-56 w-full overflow-y-auto rounded-md border border-line bg-card shadow-lg">
          {onCreate && (
            <button
              type="button"
              className="block w-full px-3 py-2 text-right text-sm text-gold"
              onClick={() => {
                setOpen(false);
                onCreate();
              }}
            >
              {createLabel ?? "+ مورد جدید"}
            </button>
          )}
          {filtered.map((o) => (
            <button
              key={o.id}
              type="button"
              className="block w-full px-3 py-2 text-right text-sm hover:bg-paper-2"
              onClick={() => {
                onChange(o.id);
                setOpen(false);
              }}
            >
              {o.label}
              {o.sub && <span className="mr-2 text-xs text-muted">{o.sub}</span>}
            </button>
          ))}
          {!filtered.length && <p className="px-3 py-2 text-sm text-muted">موردی نیست</p>}
        </div>
      )}
    </div>
  );
}

export function useTodayIso() {
  return gregorianToJalali(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate());
}
