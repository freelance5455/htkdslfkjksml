import React, { useState } from 'react';
import { 
  Users, 
  Bookmark, 
  Film, 
  Smartphone, 
  Database, 
  ShieldAlert, 
  Sparkles, 
  Filter,
  Image,
  Video,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { StoryTray } from './StoryTray';
import { CreatePostBox } from './CreatePostBox';
import { PostCard } from './PostCard';

interface FeedViewProps {
  onOpenCreatePost: () => void;
  onOpenCreateReel: () => void;
  onOpenApkGuide: () => void;
  onOpenFirebaseSettings: () => void;
  onOpenProfile: (userId: string) => void;
  onNavigateToTab: (tab: 'feed' | 'reels' | 'profile' | 'admin') => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onOpenCreatePost,
  onOpenCreateReel,
  onOpenApkGuide,
  onOpenFirebaseSettings,
  onOpenProfile,
  onNavigateToTab,
}) => {
  const { user, isAdmin, allUsers } = useAuth();
  const { posts } = useSocial();

  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video' | 'saved'>('all');

  const filteredPosts = posts.filter(p => {
    if (mediaFilter === 'image') return p.mediaType === 'image';
    if (mediaFilter === 'video') return p.mediaType === 'video';
    if (mediaFilter === 'saved') return p.isSaved;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 grid grid-cols-1 lg:grid-cols-12 gap-5 pb-20 md:pb-12">
      
      {/* Left Sidebar (Desktop only) */}
      <aside className="hidden lg:block lg:col-span-3 space-y-3 sticky top-18 h-fit">
        {/* User Card */}
        <div 
          onClick={() => user?.id && onOpenProfile(user.id)}
          className="p-3 bg-white rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3 cursor-pointer hover:bg-slate-50 transition-colors"
        >
          <img
            src={user?.photoURL}
            alt={user?.displayName}
            className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-300"
          />
          <div className="truncate">
            <p className="font-bold text-sm text-slate-900 truncate">{user?.displayName}</p>
            <p className="text-xs text-slate-500 truncate">@{user?.username}</p>
          </div>
        </div>

        {/* Shortcuts Navigation List */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-2 space-y-0.5 text-xs font-semibold text-slate-700">
          <button
            onClick={() => onNavigateToTab('reels')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer text-slate-800"
          >
            <Film className="w-5 h-5 text-rose-500" />
            <span>Shorts & Reels</span>
          </button>

          <button
            onClick={() => setMediaFilter('saved')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
              mediaFilter === 'saved' ? 'bg-blue-50 text-[#1877F2]' : 'hover:bg-slate-100 text-slate-800'
            }`}
          >
            <Bookmark className="w-5 h-5 text-purple-500" />
            <span>Saved Posts</span>
          </button>

          <button
            onClick={onOpenApkGuide}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-emerald-50 text-emerald-800 transition-colors cursor-pointer"
          >
            <Smartphone className="w-5 h-5 text-emerald-600" />
            <span>Android APK Packager</span>
          </button>

          <button
            onClick={onOpenFirebaseSettings}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-orange-50 text-orange-800 transition-colors cursor-pointer"
          >
            <Database className="w-5 h-5 text-orange-500" />
            <span>Firebase Diagnostics</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => onNavigateToTab('admin')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-amber-50 text-amber-900 transition-colors cursor-pointer"
            >
              <ShieldAlert className="w-5 h-5 text-amber-600" />
              <span>Owner Dashboard</span>
            </button>
          )}
        </div>

        {/* Community Creators list */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-3">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
            Community Creators
          </span>
          <div className="space-y-1.5">
            {allUsers.slice(0, 4).map(u => (
              <div
                key={u.id}
                onClick={() => onOpenProfile(u.id)}
                className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <div className="relative">
                    <img src={u.photoURL} alt={u.displayName} className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200" />
                    <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-500 ring-1 ring-white"></span>
                  </div>
                  <span className="text-xs font-semibold text-slate-800 truncate">{u.displayName}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Feed Column */}
      <main className="col-span-1 lg:col-span-6 max-w-xl mx-auto w-full">
        
        {/* Stories Tray */}
        <StoryTray />

        {/* Composer Box */}
        <CreatePostBox
          onOpenCreatePost={onOpenCreatePost}
          onOpenCreateReel={onOpenCreateReel}
        />

        {/* Filter Bar */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            <button
              onClick={() => setMediaFilter('all')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                mediaFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              All Feeds
            </button>
            <button
              onClick={() => setMediaFilter('image')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 ${
                mediaFilter === 'image' ? 'bg-[#1877F2] text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Image className="w-3.5 h-3.5" />
              <span>Photos</span>
            </button>
            <button
              onClick={() => setMediaFilter('video')}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 ${
                mediaFilter === 'video' ? 'bg-rose-500 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Videos</span>
            </button>
          </div>

          <span className="text-xs text-slate-400 font-medium">
            {filteredPosts.length} posts
          </span>
        </div>

        {/* Posts Stream */}
        {filteredPosts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500">
            <p className="text-sm font-semibold mb-2">No posts matching this filter.</p>
            <button
              onClick={() => setMediaFilter('all')}
              className="text-xs font-bold text-[#1877F2] hover:underline"
            >
              Show all posts
            </button>
          </div>
        ) : (
          filteredPosts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              onOpenProfile={onOpenProfile}
            />
          ))
        )}

      </main>

      {/* Right Sidebar (Desktop only) */}
      <aside className="hidden lg:block lg:col-span-3 space-y-4 sticky top-18 h-fit">
        
        {/* Android Package Callout Card */}
        <div className="bg-linear-to-br from-emerald-500 to-teal-700 text-white p-4 rounded-2xl shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <Smartphone className="w-5 h-5 text-emerald-200" />
            <h4 className="font-bold text-sm">Download as Android APK</h4>
          </div>
          <p className="text-xs text-emerald-100 leading-relaxed mb-3">
            Package FaceLook into a native Android APK for free with PWABuilder or Google Bubblewrap CLI.
          </p>
          <button
            onClick={onOpenApkGuide}
            className="w-full py-2 bg-white text-emerald-800 font-bold text-xs rounded-xl hover:bg-emerald-50 transition-colors cursor-pointer shadow-xs"
          >
            Open Free Packaging Guide
          </button>
        </div>

        {/* Firebase Live Health */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-xs text-slate-900">Firebase Backend</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed mb-2.5">
            Cloud Firestore database is synchronizing posts, reels, and profiles in real-time.
          </p>
          <button
            onClick={onOpenFirebaseSettings}
            className="text-xs font-semibold text-orange-600 hover:text-orange-700 flex items-center gap-1"
          >
            <span>View configuration guide</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        {/* Footer info */}
        <div className="px-2 text-[11px] text-slate-400 space-y-1">
          <p>FaceLook Mobile Social Network • 2026</p>
          <p>Built with React, Tailwind CSS & Firebase</p>
        </div>

      </aside>

    </div>
  );
};
