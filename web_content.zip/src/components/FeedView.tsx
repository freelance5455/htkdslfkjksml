import React from 'react';
import { useApp } from '../context/AppContext';
import { ConfessionCard } from './ConfessionCard';
import { PollsView } from './PollsView';
import { CategoryType } from '../types';
import { 
  Flame, 
  Clock, 
  GraduationCap, 
  Bookmark, 
  Sparkles, 
  Plus, 
  Filter, 
  Search, 
  Globe 
} from 'lucide-react';

const CATEGORY_ITEMS: { id: 'all' | CategoryType; label: string; icon: string }[] = [
  { id: 'all', label: 'All Whispers', icon: '✨' },
  { id: 'secret', label: 'Secrets', icon: '🤫' },
  { id: 'love', label: 'Love', icon: '💘' },
  { id: 'funny', label: 'Funny', icon: '😂' },
  { id: 'stress', label: 'Study Stress', icon: '📚' },
  { id: 'hottake', label: 'Hot Takes', icon: '🔥' },
  { id: 'campus', label: 'Campus Life', icon: '🏛️' },
];

export const FeedView: React.FC = () => {
  const { 
    confessions, 
    feedFilter, 
    setFeedFilter, 
    categoryFilter, 
    setCategoryFilter, 
    searchQuery, 
    user, 
    setIsCreateOpen 
  } = useApp();

  // Filter confessions
  let filtered = confessions.filter(c => !c.isHidden);

  // Search filter
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(c => 
      c.content.toLowerCase().includes(q) || 
      c.collegeName.toLowerCase().includes(q) ||
      c.authorAvatarName.toLowerCase().includes(q)
    );
  }

  // Category filter
  if (categoryFilter !== 'all') {
    filtered = filtered.filter(c => c.category === categoryFilter);
  }

  // Feed type filter
  if (feedFilter === 'trending') {
    filtered = [...filtered].sort((a, b) => (b.likes * 2 + b.commentsCount * 3) - (a.likes * 2 + a.commentsCount * 3));
  } else if (feedFilter === 'recent') {
    filtered = [...filtered].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } else if (feedFilter === 'my-college') {
    filtered = filtered.filter(c => c.collegeCode === user.collegeCode || !c.isCampusOnly);
  } else if (feedFilter === 'bookmarked') {
    filtered = filtered.filter(c => user.savedPostIds.includes(c.id));
  }

  return (
    <div className="space-y-4 pb-20">
      
      {/* Daily Theme Campus Callout Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-950/40 via-purple-950/40 to-slate-900 border border-cyan-500/30 p-4 shadow-lg flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Campus Theme: Funny Friday</span>
          </div>
          <h2 className="font-display font-black text-sm sm:text-base text-slate-100">
            "What's the funniest blunder you saw in the campus mess or lecture?"
          </h2>
          <p className="text-[11px] text-slate-400">
            Post anonymously with disguise avatars. Real names never appear.
          </p>
        </div>
        <button
          onClick={() => setIsCreateOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shrink-0 transition-all shadow-md shadow-cyan-500/20 hidden xs:flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Whisper</span>
        </button>
      </div>

      {/* Feed Filter Tabs (Segmented Button Control) */}
      <div className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-xl overflow-x-auto scrollbar-none">
        <button
          onClick={() => setFeedFilter('trending')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
            feedFilter === 'trending' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Trending</span>
        </button>

        <button
          onClick={() => setFeedFilter('recent')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
            feedFilter === 'recent' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Latest</span>
        </button>

        <button
          onClick={() => setFeedFilter('my-college')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
            feedFilter === 'my-college' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5" />
          <span>My Campus ({user.collegeCode})</span>
        </button>

        <button
          onClick={() => setFeedFilter('bookmarked')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
            feedFilter === 'bookmarked' ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved</span>
        </button>
      </div>

      {/* Horizontal Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {CATEGORY_ITEMS.map(cat => (
          <button
            key={cat.id}
            onClick={() => setCategoryFilter(cat.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium whitespace-nowrap transition-all shrink-0 ${
              categoryFilter === cat.id 
                ? 'bg-slate-800 border-cyan-500/70 text-cyan-300 font-semibold shadow-sm' 
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Confession Cards Feed Stream */}
      {filtered.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-slate-400 space-y-3">
          <span className="text-3xl block">🤫</span>
          <p className="text-sm font-semibold text-slate-200">
            No campus gossip yet in this feed.
          </p>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            Be the first student to drop an anonymous gossip or confession!
          </p>
          <button
            onClick={() => setIsCreateOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white text-xs font-bold shadow-md transition-all inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Drop Campus Gossip 🚀</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((confession, index) => (
            <React.Fragment key={confession.id}>
              <ConfessionCard confession={confession} />
              
              {/* Inject interactive campus dilemma poll after every 3 confessions for maximum viral engagement! */}
              {index === 1 && (
                <div className="my-2 p-1 border-y border-dashed border-cyan-500/20">
                  <PollsView />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      )}

    </div>
  );
};
