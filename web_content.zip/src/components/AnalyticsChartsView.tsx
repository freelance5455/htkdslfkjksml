import React, { useMemo, useState } from 'react';
import { ClanDashboardState } from '../shared/cocData';
import { getStatusTextColor, PLAYER_PALETTE } from '../utils/formatters';
import {
  MultiLineProgressChart,
  SeriesConfig,
  VelocityBarChart,
} from './ProgressCharts';

interface AnalyticsChartsViewProps {
  state: ClanDashboardState;
  onSelectPlayer: (tag: string) => void;
}

export const AnalyticsChartsView: React.FC<AnalyticsChartsViewProps> = ({
  state,
  onSelectPlayer,
}) => {
  const [selectedTags, setSelectedTags] = useState<string[]>(() =>
    state.players.slice(0, 4).map((p) => p.tag)
  );
  const [rangeDays, setRangeDays] = useState<14 | 30>(30);

  const togglePlayer = (tag: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tag)) {
        return prev.length > 1 ? prev.filter((t) => t !== tag) : prev;
      }
      if (prev.length >= 6) {
        return [...prev.slice(1), tag];
      }
      return [...prev, tag];
    });
  };

  const selectThGroup = (th: number) => {
    const tags = state.players
      .filter((p) => p.townHallLevel === th)
      .slice(0, 6)
      .map((p) => p.tag);
    if (tags.length > 0) setSelectedTags(tags);
  };

  const slicedHistory = useMemo(
    () => state.history.slice(-rangeDays),
    [state.history, rangeDays]
  );

  const playerSeries: SeriesConfig[] = useMemo(() => {
    return selectedTags
      .map((tag, idx) => {
        const p = state.players.find((pl) => pl.tag === tag);
        if (!p) return null;
        return {
          key: p.tag,
          label: `${p.name} (TH${p.townHallLevel})`,
          color: PLAYER_PALETTE[idx % PLAYER_PALETTE.length],
          getValue: (pt) => pt.byPlayer[p.tag],
        } as SeriesConfig;
      })
      .filter((x): x is SeriesConfig => x !== null);
  }, [selectedTags, state.players]);

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-3 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Графики прогресса и темп клана
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Сравнение траектории развития до 6 игроков одновременно, дневной объём апгрейдов и баланс баз
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start">
          {([14, 30] as const).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setRangeDays(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                rangeDays === d
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              За {d} дней
            </button>
          ))}
        </div>
      </section>

      {/* Multi-Player Comparison Chart */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Сравнение прогресса игроков ({selectedTags.length}/6 выбрано)
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Быстрый выбор целой группы Ратуши или отдельных участников
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {state.thGroups.map((g) => (
              <button
                key={g.townHallLevel}
                type="button"
                onClick={() => selectThGroup(g.townHallLevel)}
                className="rounded border border-slate-700 bg-[#0B0F17] px-2.5 py-1 text-xs text-slate-300 hover:border-amber-500/60 hover:text-amber-400 transition-colors"
              >
                Вся группа TH{g.townHallLevel}
              </button>
            ))}
          </div>
        </div>

        {/* Player toggle buttons */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {state.players.map((p) => {
            const idx = selectedTags.indexOf(p.tag);
            const active = idx !== -1;
            const color = active ? PLAYER_PALETTE[idx % PLAYER_PALETTE.length] : undefined;
            return (
              <button
                key={p.tag}
                type="button"
                onClick={() => togglePlayer(p.tag)}
                className={`inline-flex items-center gap-2 rounded-md border px-2.5 py-1 text-xs transition-colors ${
                  active
                    ? 'border-slate-600 bg-slate-800/90 text-slate-100 font-medium'
                    : 'border-slate-800 bg-[#0B0F17] text-slate-400 hover:text-slate-200'
                }`}
              >
                {active && (
                  <span
                    className="h-2 w-2 rounded-xs"
                    style={{ backgroundColor: color }}
                  />
                )}
                <span>{p.name}</span>
                <span className="font-mono text-[11px] text-slate-500">TH{p.townHallLevel}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-5">
          <MultiLineProgressChart history={slicedHistory} series={playerSeries} height={300} />
        </div>
      </section>

      {/* Daily Velocity Stacked Bar Chart */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-3.5">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Ежедневная интенсивность улучшений в клане
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Количество завершённых апгрейдов по дням с разбивкой по категориям
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#F59E0B]" /> Оборона
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#10B981]" /> Герои
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#38BDF8]" /> Лаборатория
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#A78BFA]" /> Стены
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#FB7185]" /> Ловушки
            </span>
          </div>
        </div>

        <div className="mt-4">
          <VelocityBarChart history={slicedHistory} height={240} />
        </div>
      </section>

      {/* Full Clan Balance Breakdown Matrix */}
      <section className="rounded-lg border border-slate-800 bg-[#121824]">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Баланс прокачки: Оборона против Героев и Лаборатории
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Позволяет быстро выявить дисбаланс («раш») по каждому игроку клана
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400">
                <th className="px-5 py-2.5">Игрок</th>
                <th className="px-3 py-2.5 text-right">Ратуша</th>
                <th className="px-3 py-2.5 text-right">Оборона</th>
                <th className="px-3 py-2.5 text-right">Герои</th>
                <th className="px-3 py-2.5 text-right">Лаборатория</th>
                <th className="px-3 py-2.5 text-right">Ловушки</th>
                <th className="px-3 py-2.5 text-right">Стены</th>
                <th className="px-5 py-2.5 text-right">Вердикт</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {[...state.players]
                .sort((a, b) => b.progress.overallPct - a.progress.overallPct)
                .map((p) => (
                  <tr
                    key={p.tag}
                    onClick={() => onSelectPlayer(p.tag)}
                    className="cursor-pointer transition-colors hover:bg-slate-800/35"
                  >
                    <td className="px-5 py-2.5 font-medium text-slate-100">
                      {p.name}
                      <span className="ml-2 font-mono text-[11px] text-slate-500">{p.tag}</span>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                      TH{p.townHallLevel}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {p.progress.defensesPct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                      {p.progress.heroesPct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                      {p.progress.labPct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {p.progress.trapsPct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {p.progress.wallsPct.toFixed(1)}%
                    </td>
                    <td className={`px-5 py-2.5 text-right text-xs font-medium ${getStatusTextColor(p.progress.statusLabel)}`}>
                      {p.progress.statusLabel}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
