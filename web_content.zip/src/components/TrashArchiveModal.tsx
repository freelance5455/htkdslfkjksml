import React, { useEffect, useState } from 'react';
import { Archive, MessageSquare, RefreshCw, Trash2, X } from 'lucide-react';
import { api } from '../services/api.ts';
import type { ConversationItem } from '../types.ts';

interface TrashArchiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRestored: () => void;
}

export const TrashArchiveModal: React.FC<TrashArchiveModalProps> = ({
  isOpen,
  onClose,
  onRestored,
}) => {
  const [activeTab, setActiveTab] = useState<'TRASH' | 'ARCHIVE'>('TRASH');
  const [trashItems, setTrashItems] = useState<ConversationItem[]>([]);
  const [archivedItems, setArchivedItems] = useState<ConversationItem[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const [trashRes, archiveRes] = await Promise.all([
        api.getConversations({ isTrashOnly: true }),
        api.getConversations({ includeArchived: true }),
      ]);
      setTrashItems(trashRes.conversations || []);
      setArchivedItems((archiveRes.conversations || []).filter((c) => c.isArchived && !c.isTrash));
    } catch (err) {
      console.error('Failed to load trash or archive:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      void fetchItems();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRestore = async (id: string) => {
    try {
      await api.restoreConversation(id);
      await fetchItems();
      onRestored();
    } catch (err) {
      console.error('Failed to restore conversation:', err);
    }
  };

  const handlePermanentDelete = async (id: string) => {
    if (!window.confirm('Permanently delete this conversation and all associated messages? This cannot be undone.')) {
      return;
    }
    try {
      await api.deleteConversation(id, true);
      await fetchItems();
      onRestored();
    } catch (err) {
      console.error('Failed to permanently delete conversation:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-200 text-slate-700">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 font-mono tracking-tight uppercase">
                CHAT ARCHIVE &amp; TRASH MANAGER
              </h2>
              <p className="text-xs text-slate-500">
                Restore soft-deleted chats or safely clean historical sessions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="px-5 pt-3 border-b border-slate-200 flex gap-2">
          <button
            onClick={() => setActiveTab('TRASH')}
            className={`px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'TRASH'
                ? 'border-rose-600 text-rose-700 bg-rose-50/50'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Trash ({trashItems.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('ARCHIVE')}
            className={`px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'ARCHIVE'
                ? 'border-sky-600 text-sky-700 bg-sky-50/50'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Archived ({archivedItems.length})</span>
          </button>
        </div>

        {/* List of items */}
        <div className="flex-1 overflow-y-auto p-5">
          {loading ? (
            <div className="py-12 text-center text-xs font-mono text-slate-400 animate-pulse">
              Loading items...
            </div>
          ) : activeTab === 'TRASH' ? (
            trashItems.length === 0 ? (
              <div className="py-12 text-center text-xs font-mono text-slate-400">
                Trash is empty. All active chats are healthy.
              </div>
            ) : (
              <div className="space-y-2">
                {trashItems.map((c) => (
                  <div
                    key={c.id}
                    className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs hover:border-slate-300"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-bold text-slate-800">{c.title}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                          {c.topic || 'General'}
                        </span>
                      </div>
                      {c.lastMessageSnippet && (
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                          {c.lastMessageSnippet}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleRestore(c.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-bold border border-sky-200 flex items-center gap-1 transition-all"
                        title="Restore conversation to active sidebar"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Restore
                      </button>
                      <button
                        onClick={() => handlePermanentDelete(c.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold border border-rose-200 flex items-center gap-1 transition-all"
                        title="Permanently remove conversation"
                      >
                        <Trash2 className="w-3 h-3" />
                        Purge
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : archivedItems.length === 0 ? (
            <div className="py-12 text-center text-xs font-mono text-slate-400">
              No archived conversations.
            </div>
          ) : (
            <div className="space-y-2">
              {archivedItems.map((c) => (
                <div
                  key={c.id}
                  className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs hover:border-slate-300"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-bold text-slate-800">{c.title}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                        {c.topic || 'General'}
                      </span>
                    </div>
                    <div className="mt-1 text-[11px] font-mono text-slate-400">
                      {c.messageCount || 0} messages • Archived
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleRestore(c.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-bold border border-sky-200 flex items-center gap-1 transition-all"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Unarchive
                    </button>
                    <button
                      onClick={() => api.updateConversation(c.id, { isTrash: true }).then(fetchItems)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                      title="Move to trash"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
