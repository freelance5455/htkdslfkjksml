import { useState } from 'react';
import { Globe, Bot, ShieldCheck, Crown, ChevronRight, ChevronLeft, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface OnboardingScreenProps {
  language: Language;
  onComplete: () => void;
}

export function OnboardingScreen({ language, onComplete }: OnboardingScreenProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const t = translations[language];
  const isRTL = language === 'ar';

  const slides = [
    {
      title: t.onboarding1Title,
      desc: t.onboarding1Desc,
      icon: <Globe className="w-16 h-16 text-cyan-400" />,
      tag: '01 / Global Destinations',
      accentColor: 'from-blue-600/30 to-cyan-500/20',
    },
    {
      title: t.onboarding2Title,
      desc: t.onboarding2Desc,
      icon: <Bot className="w-16 h-16 text-blue-400" />,
      tag: '02 / Smart Travel AI',
      accentColor: 'from-cyan-600/30 to-indigo-500/20',
    },
    {
      title: t.onboarding3Title,
      desc: t.onboarding3Desc,
      icon: <ShieldCheck className="w-16 h-16 text-emerald-400" />,
      tag: '03 / Offline Wallet & Guardian',
      accentColor: 'from-emerald-600/30 to-cyan-500/20',
    },
    {
      title: t.onboarding4Title,
      desc: t.onboarding4Desc,
      icon: <Crown className="w-16 h-16 text-amber-400" />,
      tag: '04 / Tourism By Taki VIP',
      accentColor: 'from-amber-600/30 to-blue-500/20',
    },
  ];

  const handleNext = () => {
    if (currentStep < slides.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const slide = slides[currentStep];

  return (
    <div className="fixed inset-0 z-40 flex flex-col justify-between p-6 bg-[#050814] text-white">
      {/* Top Bar: Skip Button */}
      <div className="flex items-center justify-between pt-4">
        <span className="text-xs font-mono tracking-widest text-cyan-400/80">
          TAKI-GO
        </span>
        <button
          onClick={onComplete}
          className="text-xs font-medium text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors"
        >
          {t.btnSkip}
        </button>
      </div>

      {/* Main Slide Card */}
      <div className="my-auto flex flex-col items-center text-center max-w-sm mx-auto w-full">
        {/* Glow Icon Container */}
        <div className={`w-32 h-32 rounded-3xl bg-gradient-to-br ${slide.accentColor} border border-cyan-500/20 flex items-center justify-center p-4 mb-8 shadow-[0_0_40px_rgba(0,102,255,0.25)] relative group`}>
          <div className="absolute inset-0 rounded-3xl bg-radial from-cyan-400/10 to-transparent pointer-events-none" />
          {slide.icon}
        </div>

        {/* Tag */}
        <span className="text-[11px] font-mono text-cyan-400 tracking-wider uppercase mb-3">
          {slide.tag}
        </span>

        {/* Title */}
        <h2 className="text-2xl md:text-3xl font-extrabold text-white mb-4 tracking-tight">
          {slide.title}
        </h2>

        {/* Description */}
        <p className="text-sm text-slate-300 leading-relaxed max-w-xs font-normal">
          {slide.desc}
        </p>
      </div>

      {/* Bottom Controls */}
      <div className="pb-6 flex flex-col gap-6 max-w-sm mx-auto w-full">
        {/* Step Indicator Dots */}
        <div className="flex items-center justify-center gap-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentStep ? 'w-8 bg-cyan-400 shadow-[0_0_10px_#00f0ff]' : 'w-2 bg-slate-700'
              }`}
              aria-label={`Slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center gap-3">
          {currentStep > 0 && (
            <button
              onClick={handlePrev}
              className="h-12 w-12 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 flex items-center justify-center hover:bg-slate-800 transition-colors shrink-0"
              aria-label="Previous Slide"
            >
              {isRTL ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
            </button>
          )}

          <button
            onClick={handleNext}
            className="flex-1 h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all"
          >
            <span>{currentStep === slides.length - 1 ? t.btnStart : t.btnNext}</span>
            {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}
