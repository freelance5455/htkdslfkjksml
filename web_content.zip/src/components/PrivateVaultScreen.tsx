import React, { useState, useEffect, useRef } from 'react';
import {
  Image as ImageIcon,
  Film,
  FileText,
  Trash2,
  Plus,
  Play,
  RotateCcw,
} from 'lucide-react';
import {
  VaultPhoto,
  VaultVideo,
  VaultNote,
  RecycleItem,
  getLocalPhotos,
  saveLocalPhotos,
  getLocalVideos,
  saveLocalVideos,
  getLocalNotes,
  saveLocalNotes,
  getRecycleBin,
  saveRecycleBin,
  saveVideoBlob,
  getVideoBlob,
  deleteVideoBlob,
  getBackupState,
  saveBackupState,
  getUserSession,
  getMasterPin,
  blobToDataUrl,
} from '../lib/storage';
import { backupToSupabase } from '../lib/supabase';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { Toast } from './Toast';

interface PrivateVaultScreenProps {
  onBack: () => void;
}

// Original Share Icon SVG (Standard connected nodes)
const OriginalShareIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="18" cy="5" r="3" />
    <circle cx="6" cy="12" r="3" />
    <circle cx="18" cy="19" r="3" />
    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
  </svg>
);

// Convert data URL or blob to real File and share via Web Share API (NEVER directly downloads)
async function shareMediaFileDirectly(item: { name: string; url: string; type: 'photo' | 'video' }): Promise<void> {
  try {
    let blob: Blob;
    if (item.url.startsWith('data:') || item.url.startsWith('blob:')) {
      const res = await fetch(item.url);
      blob = await res.blob();
    } else {
      const res = await fetch(item.url);
      blob = await res.blob();
    }
    const mime = item.type === 'video' ? 'video/mp4' : 'image/jpeg';
    const ext = item.type === 'video' ? 'mp4' : 'jpg';
    const fileName = item.name || `media_${Date.now()}.${ext}`;
    const file = new File([blob], fileName, { type: blob.type || mime });

    if (navigator.share) {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: fileName,
        });
        return;
      } else {
        await navigator.share({
          files: [file],
          title: fileName,
        });
        return;
      }
    }
  } catch (err: any) {
    if (err.name !== 'AbortError') {
      console.warn('Share file notice:', err);
    }
  }
}

// Helper to generate a crisp image thumbnail from a video Blob
function generateThumbnailFromBlob(file: Blob): Promise<string> {
  return new Promise((resolve) => {
    try {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;
      const blobUrl = URL.createObjectURL(file);
      video.src = blobUrl;

      video.onloadeddata = () => {
        video.currentTime = Math.min(0.2, (video.duration || 1) / 2);
      };

      video.onseeked = () => {
        try {
          const canvas = document.createElement('canvas');
          const width = 320;
          const height = video.videoHeight ? Math.round((video.videoHeight / video.videoWidth) * width) : 320;
          canvas.width = width;
          canvas.height = height || 320;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const thumbUrl = canvas.toDataURL('image/jpeg', 0.85);
            URL.revokeObjectURL(blobUrl);
            resolve(thumbUrl);
            return;
          }
        } catch (e) {
          console.warn('Canvas thumbnail error:', e);
        }
        URL.revokeObjectURL(blobUrl);
        resolve('');
      };

      video.onerror = () => {
        URL.revokeObjectURL(blobUrl);
        resolve('');
      };

      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
        resolve('');
      }, 4000);
    } catch {
      resolve('');
    }
  });
}

// Component to render video thumbnail image outside before opening (just like photos)
const VideoCardThumbnail: React.FC<{ video: VaultVideo }> = ({ video }) => {
  const [thumbSrc, setThumbSrc] = useState<string | null>(video.thumbnail || null);

  useEffect(() => {
    if (video.thumbnail) {
      setThumbSrc(video.thumbnail);
      return;
    }
    let isCancelled = false;
    const fetchAndGenerate = async () => {
      let blob: Blob | null = null;
      if (video.id) {
        blob = await getVideoBlob(video.id);
      }
      if (blob && !isCancelled) {
        const generated = await generateThumbnailFromBlob(blob);
        if (generated && !isCancelled) {
          setThumbSrc(generated);
        }
      }
    };
    fetchAndGenerate();
    return () => {
      isCancelled = true;
    };
  }, [video.id, video.thumbnail]);

  if (thumbSrc) {
    return (
      <img
        src={thumbSrc}
        alt={video.name}
        className="w-full h-full object-cover pointer-events-none"
      />
    );
  }

  return (
    <video
      src={`${video.url}#t=0.2`}
      preload="metadata"
      muted
      playsInline
      className="w-full h-full object-cover pointer-events-none"
    />
  );
};

export const PrivateVaultScreen: React.FC<PrivateVaultScreenProps> = ({ onBack }) => {
  const [currentBox, setCurrentBox] = useState<'main' | 'photos' | 'videos' | 'notes' | 'recycle'>('main');
  const [photos, setPhotos] = useState<VaultPhoto[]>([]);
  const [videos, setVideos] = useState<VaultVideo[]>([]);
  const [notes, setNotes] = useState<VaultNote[]>([]);
  const [recycleBin, setRecycleBin] = useState<RecycleItem[]>([]);

  // 2-second toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Note editor states
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [isEditingNote, setIsEditingNote] = useState(false);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);

  // Fullscreen Photo Viewer
  const [activePhoto, setActivePhoto] = useState<VaultPhoto | null>(null);
  const [photoZoom, setPhotoZoom] = useState<number>(1);
  const [photoPan, setPhotoPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDraggingPhoto, setIsDraggingPhoto] = useState<boolean>(false);
  const initialDistanceRef = useRef<number>(0);
  const initialZoomRef = useRef<number>(1);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const panStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastTapTimeRef = useRef<number>(0);

  // Fullscreen Video Player
  const [activeVideo, setActiveVideo] = useState<VaultVideo | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [isLoadingVideo, setIsLoadingVideo] = useState(false);

  // File Inputs
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Delete Modal state: exactly 2 buttons Cancel and Delete
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    type: 'photo' | 'video' | 'note' | 'recycle';
    item: any;
    title?: string;
    isPermanent?: boolean;
  }>({
    isOpen: false,
    type: 'photo',
    item: null,
    isPermanent: false,
  });

  const longPressTimerRef = useRef<any>(null);
  const isLongPressTriggeredRef = useRef<boolean>(false);

  // Load initial data
  useEffect(() => {
    setPhotos(getLocalPhotos());
    setVideos(getLocalVideos());
    setNotes(getLocalNotes());
    setRecycleBin(getRecycleBin());
  }, []);

  // Sync refs for quiet auto-save if app is backgrounded while editing note
  const noteTitleRef = useRef(noteTitle);
  noteTitleRef.current = noteTitle;
  const noteContentRef = useRef(noteContent);
  noteContentRef.current = noteContent;
  const isEditingNoteRef = useRef(isEditingNote);
  isEditingNoteRef.current = isEditingNote;
  const activeNoteIdRef = useRef(activeNoteId);
  activeNoteIdRef.current = activeNoteId;
  const notesRef = useRef(notes);
  notesRef.current = notes;

  useEffect(() => {
    return () => {
      // Quietly save draft note on sudden background / screen lock
      if (isEditingNoteRef.current) {
        const title = noteTitleRef.current.trim();
        const content = noteContentRef.current.trim();
        if (title || content) {
          const curNotes = notesRef.current;
          let updated: VaultNote[];
          if (activeNoteIdRef.current) {
            updated = curNotes.map((n) =>
              n.id === activeNoteIdRef.current
                ? {
                    ...n,
                    title: title || (content ? content.slice(0, 30) : 'Untitled Note'),
                    content,
                    date: new Date().toLocaleDateString(),
                  }
                : n
            );
          } else {
            const newNote: VaultNote = {
              id: `n-${Date.now()}`,
              title: title || (content ? content.slice(0, 30) : 'Untitled Note'),
              content,
              date: new Date().toLocaleDateString(),
            };
            updated = [newNote, ...curNotes];
          }
          saveLocalNotes(updated);
        }
      }
    };
  }, []);

  // Clear picking file flag on window focus
  useEffect(() => {
    const handleFocus = () => {
      setTimeout(() => {
        (window as any).__isPickingFile = false;
      }, 500);
    };
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, []);

  const openPhotoPicker = () => {
    (window as any).__isPickingFile = true;
    photoInputRef.current?.click();
  };

  const openVideoPicker = () => {
    (window as any).__isPickingFile = true;
    videoInputRef.current?.click();
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  // Real Auto Backup to Supabase when Auto Backup is enabled (within 80 MB limit)
  const syncBackupSilently = async (newPhotos = photos, newVideos = videos, newNotes = notes) => {
    const backupState = getBackupState();
    const session = getUserSession();
    const email = session.email || localStorage.getItem('current_user_email');
    if (backupState.autoBackup && email) {
      try {
        const videosWithPayload = await Promise.all(
          newVideos.map(async (item) => {
            try {
              const blob = await getVideoBlob(item.id);
              if (blob) {
                const dataUrl = await blobToDataUrl(blob);
                return { ...item, url: dataUrl };
              }
            } catch {}
            return item;
          })
        );

        const res = await backupToSupabase(email, {
          photos: newPhotos,
          videos: videosWithPayload,
          notes: newNotes,
          recycleBin: getRecycleBin(),
          calc_password: getMasterPin(),
        });
        if (res.success && res.timestamp) {
          saveBackupState({
            ...backupState,
            lastBackupDate: res.timestamp,
          });
        }
      } catch (err) {
        console.warn('Auto backup background sync notice:', err);
      }
    }
  };

  // Long press trigger for 2-button popup in lists
  const startLongPress = (type: 'photo' | 'video' | 'note', item: any, title?: string) => {
    isLongPressTriggeredRef.current = false;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      isLongPressTriggeredRef.current = true;
      if (window.navigator?.vibrate) {
        try {
          window.navigator.vibrate(40);
        } catch {}
      }
      setDeleteModal({
        isOpen: true,
        type,
        item,
        title: title || item.name || item.title || 'Item',
        isPermanent: false,
      });
    }, 450);
  };

  const startRecycleLongPress = (item: RecycleItem) => {
    isLongPressTriggeredRef.current = false;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      isLongPressTriggeredRef.current = true;
      if (window.navigator?.vibrate) {
        try {
          window.navigator.vibrate(40);
        } catch {}
      }
      setDeleteModal({
        isOpen: true,
        type: 'recycle',
        item,
        title: item.type === 'photo' || item.type === 'video' ? item.data?.name : item.data?.title,
        isPermanent: true,
      });
    }, 450);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // Delete item from box -> moves to Recycle Bin (Cloud safe)
  const confirmDelete = () => {
    if (!deleteModal.item) return;

    if (deleteModal.type === 'photo') {
      const item: VaultPhoto = deleteModal.item;
      const updated = photos.filter((p) => p.id !== item.id);
      setPhotos(updated);
      saveLocalPhotos(updated);
      const newRecycle: RecycleItem[] = [
        { id: `rec-${Date.now()}`, type: 'photo', deletedAt: Date.now(), data: item },
        ...recycleBin,
      ];
      setRecycleBin(newRecycle);
      saveRecycleBin(newRecycle);
      syncBackupSilently(updated, videos, notes);
      showToast('Photo moved to Recycle Bin (stays safe in Cloud)');
    } else if (deleteModal.type === 'video') {
      const item: VaultVideo = deleteModal.item;
      const updated = videos.filter((v) => v.id !== item.id);
      setVideos(updated);
      saveLocalVideos(updated);
      const newRecycle: RecycleItem[] = [
        { id: `rec-${Date.now()}`, type: 'video', deletedAt: Date.now(), data: item },
        ...recycleBin,
      ];
      setRecycleBin(newRecycle);
      saveRecycleBin(newRecycle);
      syncBackupSilently(photos, updated, notes);
      showToast('Video moved to Recycle Bin (stays safe in Cloud)');
    } else if (deleteModal.type === 'note') {
      const item: VaultNote = deleteModal.item;
      const updated = notes.filter((n) => n.id !== item.id);
      setNotes(updated);
      saveLocalNotes(updated);
      const newRecycle: RecycleItem[] = [
        { id: `rec-${Date.now()}`, type: 'note', deletedAt: Date.now(), data: item },
        ...recycleBin,
      ];
      setRecycleBin(newRecycle);
      saveRecycleBin(newRecycle);
      syncBackupSilently(photos, videos, updated);
      showToast('Note moved to Recycle Bin (stays safe in Cloud)');
    } else if (deleteModal.type === 'recycle') {
      const item: RecycleItem = deleteModal.item;
      if (item.type === 'video' && item.data?.id) {
        deleteVideoBlob(item.data.id);
      }
      const updated = recycleBin.filter((r) => r.id !== item.id);
      setRecycleBin(updated);
      saveRecycleBin(updated);
      showToast('Permanently deleted');
    }

    setDeleteModal({ isOpen: false, type: 'photo', item: null, isPermanent: false });
  };

  // Restore from Recycle Bin
  const restoreItem = (item: RecycleItem) => {
    const updatedRecycle = recycleBin.filter((r) => r.id !== item.id);
    setRecycleBin(updatedRecycle);
    saveRecycleBin(updatedRecycle);

    if (item.type === 'photo') {
      const updated = [item.data, ...photos];
      setPhotos(updated);
      saveLocalPhotos(updated);
      syncBackupSilently(updated, videos, notes);
      showToast('Photo restored to gallery');
    } else if (item.type === 'video') {
      const updated = [item.data, ...videos];
      setVideos(updated);
      saveLocalVideos(updated);
      syncBackupSilently(photos, updated, notes);
      showToast('Video restored to vault');
    } else if (item.type === 'note') {
      const updated = [item.data, ...notes];
      setNotes(updated);
      saveLocalNotes(updated);
      syncBackupSilently(photos, videos, updated);
      showToast('Note restored');
    }
  };

  // Photo viewer
  const openPhotoViewer = (photo: VaultPhoto) => {
    setPhotoZoom(1);
    setPhotoPan({ x: 0, y: 0 });
    setActivePhoto(photo);
  };

  const closePhotoViewer = () => {
    setPhotoZoom(1);
    setPhotoPan({ x: 0, y: 0 });
    setActivePhoto(null);
  };

  // Touch handlers for photo zoom and pan
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDraggingPhoto(true);
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      initialDistanceRef.current = dist;
      initialZoomRef.current = photoZoom;
    } else if (e.touches.length === 1) {
      const now = Date.now();
      if (now - lastTapTimeRef.current < 300) {
        // Double tap toggle
        if (photoZoom > 1.2) {
          setPhotoZoom(1);
          setPhotoPan({ x: 0, y: 0 });
        } else {
          setPhotoZoom(2.5);
          setPhotoPan({ x: 0, y: 0 });
        }
        lastTapTimeRef.current = 0;
        return;
      }
      lastTapTimeRef.current = now;
      dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      panStartRef.current = { ...photoPan };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialDistanceRef.current > 0) {
      e.preventDefault();
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / initialDistanceRef.current;
      const nextZoom = Math.min(4.5, Math.max(1, Number((initialZoomRef.current * factor).toFixed(2))));
      setPhotoZoom(nextZoom);
      if (nextZoom <= 1.05) {
        setPhotoPan({ x: 0, y: 0 });
      }
    } else if (e.touches.length === 1 && photoZoom > 1.05) {
      // Panning when zoomed in - allows reaching every corner
      const deltaX = e.touches[0].clientX - dragStartRef.current.x;
      const deltaY = e.touches[0].clientY - dragStartRef.current.y;
      const maxPanX = (window.innerWidth * (photoZoom - 1)) / 1.7;
      const maxPanY = (window.innerHeight * (photoZoom - 1)) / 1.7;
      const targetX = panStartRef.current.x + deltaX;
      const targetY = panStartRef.current.y + deltaY;
      setPhotoPan({
        x: Math.max(-maxPanX, Math.min(maxPanX, targetX)),
        y: Math.max(-maxPanY, Math.min(maxPanY, targetY)),
      });
    }
  };

  const handleTouchEnd = () => {
    setIsDraggingPhoto(false);
    initialDistanceRef.current = 0;
    if (photoZoom <= 1.05) {
      setPhotoZoom(1);
      setPhotoPan({ x: 0, y: 0 });
    }
  };

  // Video Player
  const openVideoPlayer = async (video: VaultVideo) => {
    setActiveVideo(video);
    setIsLoadingVideo(true);
    try {
      const blob = await getVideoBlob(video.id);
      if (blob) {
        setActiveVideoUrl(URL.createObjectURL(blob));
      } else if (video.url) {
        setActiveVideoUrl(video.url);
      } else {
        setActiveVideoUrl(null);
      }
    } catch {
      setActiveVideoUrl(video.url || null);
    } finally {
      setIsLoadingVideo(false);
    }
  };

  const closeVideoPlayer = () => {
    setActiveVideo(null);
    setActiveVideoUrl(null);
    setIsLoadingVideo(false);
  };

  // Upload Photo
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    showToast('Uploading photo...');
    const fileList = Array.from(files);
    const newItems: VaultPhoto[] = [];

    for (const file of fileList) {
      try {
        const dataUrl = await new Promise<string>((res) => {
          const reader = new FileReader();
          reader.onload = () => res(reader.result as string);
          reader.readAsDataURL(file);
        });
        newItems.push({
          id: `p-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: file.name || `Photo_${Date.now()}.jpg`,
          url: dataUrl,
          date: new Date().toLocaleDateString(),
          size: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
          bytes: file.size,
        });
      } catch (err) {
        console.error('Photo read error:', err);
      }
    }

    if (newItems.length > 0) {
      const updated = [...newItems, ...photos];
      setPhotos(updated);
      saveLocalPhotos(updated);
      syncBackupSilently(updated, videos, notes);
      showToast(`${newItems.length} photo(s) locked`);
    }

    if (photoInputRef.current) photoInputRef.current.value = '';
  };

  // Upload Video - captures real first frame thumbnail immediately
  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    showToast('Uploading video...');
    const videoId = `v-${Date.now()}`;
    await saveVideoBlob(videoId, file);
    const objectUrl = URL.createObjectURL(file);

    // Generate thumbnail image immediately so video shows outside just like photo!
    const thumbnail = await generateThumbnailFromBlob(file);

    const newVideo: VaultVideo = {
      id: videoId,
      name: file.name || `Video_${Date.now()}.mp4`,
      url: objectUrl,
      thumbnail: thumbnail || undefined,
      date: new Date().toLocaleDateString(),
      size: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
      bytes: file.size,
    };

    const updated = [newVideo, ...videos];
    setVideos(updated);
    saveLocalVideos(updated);
    syncBackupSilently(photos, updated, notes);
    showToast('Video locked in vault');

    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  // Notes Auto-Save quietly (NO popups)
  const saveNoteQuietly = () => {
    const title = noteTitle.trim();
    const content = noteContent.trim();
    if (title || content) {
      if (activeNoteId) {
        const updated = notes.map((n) =>
          n.id === activeNoteId
            ? {
                ...n,
                title: title || (content ? content.slice(0, 30) : 'Untitled Note'),
                content,
                date: new Date().toLocaleDateString(),
              }
            : n
        );
        setNotes(updated);
        saveLocalNotes(updated);
        syncBackupSilently(photos, videos, updated);
      } else {
        const newNote: VaultNote = {
          id: `n-${Date.now()}`,
          title: title || (content ? content.slice(0, 30) : 'Untitled Note'),
          content,
          date: new Date().toLocaleDateString(),
        };
        const updated = [newNote, ...notes];
        setNotes(updated);
        saveLocalNotes(updated);
        syncBackupSilently(photos, videos, updated);
      }
    }
    setNoteTitle('');
    setNoteContent('');
    setActiveNoteId(null);
    setIsEditingNote(false);
  };

  return (
    <div className="w-full h-full max-w-xl mx-auto flex flex-col justify-between px-3 sm:px-6 py-3 sm:py-4 select-none bg-[#0c1422] text-white overflow-hidden relative">
      {/* 2-second Toast */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

      {/* Hidden File Inputs */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => {
          (window as any).__isPickingFile = false;
          handlePhotoUpload(e);
        }}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          (window as any).__isPickingFile = false;
          handleVideoUpload(e);
        }}
      />

      {/* 1. Main Vault Hub */}
      {currentBox === 'main' && (
        <>
          <div className="flex items-center justify-end pb-3 pt-1">
            <button
              onClick={onBack}
              className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-5 py-2 rounded-xl text-sm transition shadow-md cursor-pointer"
            >
              Back
            </button>
          </div>

          <div className="flex-1 flex flex-col justify-start space-y-4">
            <div className="bg-[#152033] border border-[#24354f] rounded-2xl py-3 px-4 text-center shadow-lg">
              <div className="text-[#f43f5e] font-bold text-lg tracking-wide leading-snug">
                This App Developed
              </div>
              <div className="text-[#f43f5e] font-bold text-lg tracking-wide leading-snug mt-0.5">
                By Saleem Zakhme
              </div>
            </div>

            <div className="bg-[#152033] border border-[#24354f] rounded-2xl py-2.5 px-4 text-center shadow-lg">
              <div className="text-[#22c55e] font-bold text-lg tracking-wide">
                Your Private Lock
              </div>
            </div>

            {/* 4 Storage Boxes Grid */}
            <div className="grid grid-cols-2 gap-3.5 pt-1">
              {/* Photos Box */}
              <div
                onClick={() => setCurrentBox('photos')}
                className="bg-[#152033] border border-[#24354f] rounded-3xl p-4 flex flex-col items-center justify-center gap-2.5 aspect-square shadow-xl cursor-pointer hover:bg-[#1a283e] active:scale-95 transition group"
              >
                <div className="w-14 h-14 rounded-full bg-[#f59e0b] flex items-center justify-center shadow-md group-hover:scale-105 transition">
                  <div className="w-9 h-9 rounded-lg bg-white/90 flex items-center justify-center text-blue-600 shadow-inner">
                    <ImageIcon className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
                <div className="text-center">
                  <span className="text-white font-bold text-sm tracking-wide block">Photos</span>
                  <span className="text-[11px] text-slate-400 font-normal">{photos.length} items</span>
                </div>
              </div>

              {/* Videos Box */}
              <div
                onClick={() => setCurrentBox('videos')}
                className="bg-[#152033] border border-[#24354f] rounded-3xl p-4 flex flex-col items-center justify-center gap-2.5 aspect-square shadow-xl cursor-pointer hover:bg-[#1a283e] active:scale-95 transition group"
              >
                <div className="w-14 h-14 rounded-full bg-[#38bdf8] flex items-center justify-center shadow-md group-hover:scale-105 transition">
                  <div className="w-9 h-9 rounded-lg bg-[#0c1422] flex items-center justify-center text-[#38bdf8]">
                    <Film className="w-5 h-5 text-[#38bdf8]" />
                  </div>
                </div>
                <div className="text-center">
                  <span className="text-white font-bold text-sm tracking-wide block">Videos</span>
                  <span className="text-[11px] text-slate-400 font-normal">{videos.length} items</span>
                </div>
              </div>

              {/* Notes Box */}
              <div
                onClick={() => setCurrentBox('notes')}
                className="bg-[#152033] border border-[#24354f] rounded-3xl p-4 flex flex-col items-center justify-center gap-2.5 aspect-square shadow-xl cursor-pointer hover:bg-[#1a283e] active:scale-95 transition group"
              >
                <div className="w-14 h-14 rounded-full bg-[#22c55e] flex items-center justify-center shadow-md group-hover:scale-105 transition">
                  <div className="w-9 h-9 rounded-lg bg-white/90 flex items-center justify-center text-[#22c55e]">
                    <FileText className="w-5 h-5 text-[#22c55e]" />
                  </div>
                </div>
                <div className="text-center">
                  <span className="text-white font-bold text-sm tracking-wide block">Notes</span>
                  <span className="text-[11px] text-slate-400 font-normal">{notes.length} notes</span>
                </div>
              </div>

              {/* Recycle Bin Box */}
              <div
                onClick={() => setCurrentBox('recycle')}
                className="bg-[#152033] border border-[#24354f] rounded-3xl p-4 flex flex-col items-center justify-center gap-2.5 aspect-square shadow-xl cursor-pointer hover:bg-[#1a283e] active:scale-95 transition group"
              >
                <div className="w-14 h-14 rounded-full bg-[#a855f7] flex items-center justify-center shadow-md group-hover:scale-105 transition">
                  <div className="w-9 h-9 rounded-lg bg-white/90 flex items-center justify-center text-[#a855f7]">
                    <Trash2 className="w-5 h-5 text-[#a855f7]" />
                  </div>
                </div>
                <div className="text-center">
                  <span className="text-white font-bold text-sm tracking-wide block">Recycle bin</span>
                  <span className="text-[11px] text-slate-400 font-normal">{recycleBin.length} deleted</span>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* 2. Photos Box */}
      {currentBox === 'photos' && (
        <div className="flex-1 flex flex-col justify-between overflow-hidden relative">
          <div className="flex items-center justify-between pb-3 border-b border-[#24354f] shrink-0">
            <h2 className="font-bold text-base text-amber-400 flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-amber-400" />
              <span>Photos ({photos.length})</span>
            </h2>
            <button
              onClick={() => setCurrentBox('main')}
              className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
            >
              Back
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-2.5">
            {photos.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-2 py-12">
                <div className="w-14 h-14 rounded-full bg-[#152033] border border-[#24354f] flex items-center justify-center text-slate-500 mb-2">
                  <ImageIcon className="w-7 h-7 text-amber-500/60" />
                </div>
                <p className="text-sm font-semibold text-slate-300">No photos locked yet</p>
                <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                  Click the green (+) button below to select and lock photos.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5 pb-20">
                {photos.map((photo) => (
                  <div
                    key={photo.id}
                    onTouchStart={() => startLongPress('photo', photo)}
                    onTouchEnd={cancelLongPress}
                    onTouchMove={cancelLongPress}
                    onMouseDown={() => startLongPress('photo', photo)}
                    onMouseUp={cancelLongPress}
                    onMouseLeave={cancelLongPress}
                    onContextMenu={(e) => e.preventDefault()}
                    onClick={() => {
                      if (isLongPressTriggeredRef.current) {
                        isLongPressTriggeredRef.current = false;
                        return;
                      }
                      openPhotoViewer(photo);
                    }}
                    className="relative group aspect-square rounded-2xl overflow-hidden bg-[#152033] border border-[#23354d] hover:border-slate-500 shadow-md transition cursor-pointer select-none active:scale-[0.97]"
                  >
                    <img
                      src={photo.url}
                      alt={photo.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300 pointer-events-none"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-1.5 flex items-center justify-between">
                      <span className="text-[10px] text-slate-300 truncate font-medium">
                        {photo.name}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Plus Add Button */}
          <button
            onClick={openPhotoPicker}
            className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#22c55e] hover:bg-[#16a34a] active:scale-90 text-white shadow-2xl flex items-center justify-center transition shadow-green-500/40 cursor-pointer"
            title="Lock photo from gallery"
          >
            <Plus className="w-8 h-8 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* 3. Videos Box */}
      {currentBox === 'videos' && (
        <div className="flex-1 flex flex-col justify-between overflow-hidden relative">
          <div className="flex items-center justify-between pb-3 border-b border-[#24354f] shrink-0">
            <h2 className="font-bold text-base text-cyan-400 flex items-center gap-2">
              <Film className="w-5 h-5 text-cyan-400" />
              <span>Videos ({videos.length})</span>
            </h2>
            <button
              onClick={() => setCurrentBox('main')}
              className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
            >
              Back
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-2.5">
            {videos.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-2 py-12">
                <div className="w-14 h-14 rounded-full bg-[#152033] border border-[#24354f] flex items-center justify-center text-slate-500 mb-2">
                  <Film className="w-7 h-7 text-cyan-500/60" />
                </div>
                <p className="text-sm font-semibold text-slate-300">No videos locked yet</p>
                <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                  Click the green (+) button below to select and lock videos.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5 pb-20">
                {videos.map((video) => (
                  <div
                    key={video.id}
                    onTouchStart={() => startLongPress('video', video)}
                    onTouchEnd={cancelLongPress}
                    onTouchMove={cancelLongPress}
                    onMouseDown={() => startLongPress('video', video)}
                    onMouseUp={cancelLongPress}
                    onMouseLeave={cancelLongPress}
                    onContextMenu={(e) => e.preventDefault()}
                    onClick={() => {
                      if (isLongPressTriggeredRef.current) {
                        isLongPressTriggeredRef.current = false;
                        return;
                      }
                      openVideoPlayer(video);
                    }}
                    className="aspect-square rounded-2xl overflow-hidden bg-[#152033] border border-[#23354d] hover:border-slate-500 shadow-md transition cursor-pointer select-none active:scale-[0.97] relative group"
                  >
                    {/* Real Video Frame Thumbnail */}
                    <VideoCardThumbnail video={video} />
                    {/* Compact Play Badge Center */}
                    <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-black/60 backdrop-blur-xs border border-white/20 text-cyan-400 flex items-center justify-center shadow-lg group-hover:scale-110 transition pointer-events-none">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </div>
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-1.5 flex items-center justify-between">
                      <span className="text-[10px] text-slate-200 truncate font-medium">
                        {video.name}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Plus Add Button */}
          <button
            onClick={openVideoPicker}
            className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#22c55e] hover:bg-[#16a34a] active:scale-90 text-white shadow-2xl flex items-center justify-center transition shadow-green-500/40 cursor-pointer"
            title="Lock video from device"
          >
            <Plus className="w-8 h-8 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* 4. Notes Box */}
      {currentBox === 'notes' && (
        <div className="flex-1 flex flex-col justify-between overflow-hidden relative">
          {isEditingNote ? (
            <div className="flex-1 flex flex-col justify-between overflow-hidden h-full animate-in fade-in duration-150 relative">
              {/* Top Bar */}
              <div className="flex items-center justify-between pb-3 shrink-0">
                <h1 className="text-2xl font-bold text-white tracking-tight">Notes</h1>
                <button
                  onClick={saveNoteQuietly}
                  className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-5 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
                >
                  Back
                </button>
              </div>

              {/* Note Editor Body - Standard native text selection with no custom blue buttons */}
              <div className="flex-1 bg-[#131e2e] border border-[#24354f] rounded-2xl p-4 sm:p-5 flex flex-col min-h-0 shadow-2xl overflow-hidden mb-1">
                <input
                  type="text"
                  placeholder="Title"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full bg-transparent text-xl sm:text-2xl font-semibold text-white placeholder-slate-400 outline-none pb-3 border-b border-[#24354f]/60"
                  autoFocus
                />
                <textarea
                  placeholder="Write your private note here..."
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="w-full flex-1 bg-transparent text-base sm:text-lg text-slate-100 placeholder-slate-400 outline-none resize-none pt-4 leading-relaxed font-sans overflow-y-auto cursor-text select-text"
                  style={{ WebkitUserSelect: 'text', userSelect: 'text' }}
                />
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col justify-between overflow-hidden h-full">
              <div className="flex items-center justify-between pb-3 border-b border-[#24354f] shrink-0">
                <h1 className="text-2xl font-bold text-white tracking-tight">
                  Notes ({notes.length})
                </h1>
                <button
                  onClick={() => setCurrentBox('main')}
                  className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-5 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
                >
                  Back
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-2.5">
                {notes.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-2 py-12">
                    <div className="w-14 h-14 rounded-full bg-[#152033] border border-[#24354f] flex items-center justify-center text-slate-500 mb-2">
                      <FileText className="w-7 h-7 text-emerald-500/60" />
                    </div>
                    <p className="text-sm font-semibold text-slate-300">No secret notes yet</p>
                    <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                      Click the green (+) button below to create a private note.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2.5 pb-20">
                    {notes.map((note) => (
                      <div
                        key={note.id}
                        onTouchStart={() => startLongPress('note', note)}
                        onTouchEnd={cancelLongPress}
                        onTouchMove={cancelLongPress}
                        onMouseDown={() => startLongPress('note', note)}
                        onMouseUp={cancelLongPress}
                        onMouseLeave={cancelLongPress}
                        onContextMenu={(e) => e.preventDefault()}
                        onClick={() => {
                          if (isLongPressTriggeredRef.current) {
                            isLongPressTriggeredRef.current = false;
                            return;
                          }
                          setActiveNoteId(note.id);
                          setNoteTitle(note.title);
                          setNoteContent(note.content);
                          setIsEditingNote(true);
                        }}
                        className="bg-[#152033] hover:bg-[#1a283e] cursor-pointer border border-[#23354d] hover:border-slate-500 rounded-2xl p-3 flex flex-col justify-between shadow transition select-none active:scale-[0.97] min-h-[110px]"
                      >
                        <div className="min-w-0">
                          <h4 className="text-sm font-bold text-white truncate">{note.title}</h4>
                          <p className="text-xs text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                            {note.content}
                          </p>
                        </div>
                        <span className="text-[10px] text-slate-500 mt-2 block">{note.date}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Plus Add Button */}
              <button
                onClick={() => {
                  setActiveNoteId(null);
                  setNoteTitle('');
                  setNoteContent('');
                  setIsEditingNote(true);
                }}
                className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-[#22c55e] hover:bg-[#16a34a] active:scale-90 text-white shadow-2xl flex items-center justify-center transition shadow-green-500/40 cursor-pointer"
                title="Write secret note"
              >
                <Plus className="w-8 h-8 stroke-[2.5]" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* 5. Recycle Bin */}
      {currentBox === 'recycle' && (
        <div className="flex-1 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-[#24354f] shrink-0">
            <h2 className="font-bold text-base text-purple-400 flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-purple-400" />
              <span>Recycle Bin ({recycleBin.length})</span>
            </h2>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentBox('main')}
                className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
              >
                Back
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto py-2.5 space-y-2.5">
            {recycleBin.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 space-y-2 py-12">
                <Trash2 className="w-12 h-12 text-slate-600" />
                <p className="text-sm">Recycle bin is empty.</p>
                <p className="text-xs text-slate-500">
                  Photos, videos, and notes deleted from boxes stay here safely.
                </p>
              </div>
            ) : (
              recycleBin.map((item) => (
                <div
                  key={item.id}
                  onTouchStart={() => startRecycleLongPress(item)}
                  onTouchEnd={cancelLongPress}
                  onTouchMove={cancelLongPress}
                  onMouseDown={() => startRecycleLongPress(item)}
                  onMouseUp={cancelLongPress}
                  onMouseLeave={cancelLongPress}
                  onContextMenu={(e) => e.preventDefault()}
                  className="bg-[#152033] border border-[#23354d] rounded-2xl p-3 flex items-center justify-between gap-3 shadow select-none"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#0c1422] flex items-center justify-center shrink-0 overflow-hidden border border-[#24354f]">
                    {item.type === 'photo' && (
                      <img src={item.data.url} alt="Deleted" className="w-full h-full object-cover" />
                    )}
                    {item.type === 'video' && <Film className="w-6 h-6 text-cyan-400" />}
                    {item.type === 'note' && <FileText className="w-6 h-6 text-emerald-400" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">
                      {item.type === 'photo' && item.data?.name}
                      {item.type === 'video' && item.data?.name}
                      {item.type === 'note' && item.data?.title}
                    </p>
                    <p className="text-[10px] text-slate-400 capitalize">
                      {item.type} • Deleted {new Date(item.deletedAt).toLocaleDateString()}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => restoreItem(item)}
                      className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 active:scale-95 text-white rounded-xl transition flex items-center gap-1 text-xs font-medium cursor-pointer"
                      title="Restore back to vault"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Restore</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Fullscreen Photo Viewer */}
      {activePhoto && (
        <div
          className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-0 select-none animate-in fade-in duration-150 overflow-hidden"
          onClick={closePhotoViewer}
        >
          {/* Top Bar: Title on left, and on RIGHT: Share button to the LEFT of Back button */}
          <div
            className="absolute top-0 left-0 right-0 z-30 flex justify-between items-center text-white px-4 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="text-xs sm:text-sm font-semibold truncate max-w-xs text-amber-300 drop-shadow">
              {activePhoto.name}
            </span>

            {/* Back button ke LEFT side me Share button */}
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() =>
                  shareMediaFileDirectly({
                    name: activePhoto.name,
                    url: activePhoto.url,
                    type: 'photo',
                  })
                }
                className="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 active:scale-90 text-white flex items-center justify-center shadow-lg transition cursor-pointer"
                title="Share photo file directly"
              >
                <OriginalShareIcon className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={closePhotoViewer}
                className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-lg cursor-pointer"
              >
                Back
              </button>
            </div>
          </div>

          {/* Fullscreen, perfectly balanced, no corners cut, pan to every corner */}
          <div
            className="w-full h-full flex items-center justify-center overflow-hidden relative select-none touch-none bg-black cursor-grab active:cursor-grabbing"
            onClick={(e) => e.stopPropagation()}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <img
              src={activePhoto.url}
              alt={activePhoto.name}
              style={{
                transform: `translate3d(${photoPan.x}px, ${photoPan.y}px, 0) scale(${photoZoom})`,
                transition: isDraggingPhoto ? 'none' : 'transform 0.18s cubic-bezier(0.2, 0.9, 0.3, 1)',
                willChange: 'transform',
                transformOrigin: 'center center',
              }}
              className="w-full h-full object-contain pointer-events-none select-none max-w-full max-h-full"
              draggable={false}
            />
          </div>
        </div>
      )}

      {/* Fullscreen Video Player */}
      {activeVideo && (
        <div
          className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-0 select-none animate-in fade-in duration-150 overflow-hidden"
          onClick={closeVideoPlayer}
        >
          {/* Top Bar: Title on left, and on RIGHT: Share button to the LEFT of Back button */}
          <div
            className="absolute top-0 left-0 right-0 z-30 flex justify-between items-center text-white px-4 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="text-xs sm:text-sm font-semibold truncate max-w-xs text-cyan-400 drop-shadow">
              {activeVideo.name}
            </span>

            {/* Back button ke LEFT side me Share button */}
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() =>
                  shareMediaFileDirectly({
                    name: activeVideo.name,
                    url: activeVideoUrl || activeVideo.url,
                    type: 'video',
                  })
                }
                className="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 active:scale-90 text-white flex items-center justify-center shadow-lg transition cursor-pointer"
                title="Share video file directly"
              >
                <OriginalShareIcon className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={closeVideoPlayer}
                className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-lg cursor-pointer shrink-0"
              >
                Back
              </button>
            </div>
          </div>

          {/* Fullscreen Video Viewport (No cut corners) */}
          <div
            className="w-full h-full flex items-center justify-center bg-black p-0"
            onClick={(e) => e.stopPropagation()}
          >
            {isLoadingVideo ? (
              <div className="flex flex-col items-center gap-3 text-slate-300">
                <div className="w-10 h-10 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                <span className="text-xs font-medium">Video loading...</span>
              </div>
            ) : activeVideoUrl ? (
              <video
                key={activeVideoUrl}
                src={activeVideoUrl}
                controls
                controlsList="nodownload noplaybackrate nofullscreen"
                disablePictureInPicture
                playsInline
                preload="metadata"
                className="w-full h-full object-contain max-w-full max-h-full bg-black"
              />
            ) : (
              <div className="text-center text-slate-400 space-y-2">
                <p className="text-sm">Could not load video.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal: Exactly 2 buttons Cancel and Delete */}
      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        title={deleteModal.title}
        isPermanent={deleteModal.isPermanent}
        onCancel={() =>
          setDeleteModal({ isOpen: false, type: 'photo', item: null, isPermanent: false })
        }
        onConfirm={confirmDelete}
      />
    </div>
  );
};
