import { Camera, ChevronRight, Clock3, ScanFace, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScoreRing } from "@/components/score-ring";
import { confidenceLabel, formatPsl, TIER_META, TIER_ORDER } from "@/lib/psl";
import { useAppStore } from "@/lib/store";

export function HomeScreen() {
  const history = useAppStore((s) => s.history);
  const go = useAppStore((s) => s.go);
  const latest = history[0];

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6">
      <p className="text-2xs uppercase tracking-hero text-subtle">PSL Score</p>
      <h1 className="mt-1 font-display text-3xl font-bold tracking-tight">LUME</h1>
      <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted">
        Chụp selfie, nhận rank và điểm PSL từ thang chính thức — GigaChad đến Sub3.
      </p>

      {latest ? (
        <button
          type="button"
          onClick={() => go("history")}
          className="tap mt-8 w-full rounded-2xl bg-surface p-5 text-left"
        >
          <div className="flex items-center justify-between">
            <p className="text-2xs uppercase tracking-label text-subtle">Lần quét gần nhất</p>
            <ChevronRight className="size-4 text-subtle" />
          </div>
          <div className="mt-4 flex items-center gap-4">
            <ScoreRing value={latest.psl} size="sm" />
            <div className="min-w-0">
              <p className="font-display text-xl font-semibold">{latest.rank}</p>
              <p className="mt-1 text-sm text-muted">
                PSL {formatPsl(latest.psl)} · {TIER_META[latest.tier].rarity}
              </p>
            </div>
          </div>
        </button>
      ) : (
        <div className="mt-8 rounded-2xl bg-surface p-5">
          <div className="grid size-12 place-items-center rounded-lg bg-surface-2 text-accent">
            <ScanFace className="size-6" strokeWidth={1.6} />
          </div>
          <h2 className="mt-4 font-display text-lg font-semibold">Chưa có điểm</h2>
          <p className="mt-1 text-sm text-muted">
            Một ảnh chính diện là đủ để lấy rank và điểm PSL.
          </p>
        </div>
      )}

      <Button size="xl" className="mt-6 w-full" onClick={() => go("scan")}>
        <Camera className="size-5" />
        Quét khuôn mặt
      </Button>

      <section className="mt-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-2xs uppercase tracking-label text-subtle">Thang PSL</h2>
          <button type="button" className="tap text-sm text-accent" onClick={() => go("scale")}>
            Xem đủ
          </button>
        </div>
        <ol className="divide-y divide-border overflow-hidden rounded-2xl bg-surface">
          {TIER_ORDER.slice(0, 4).map((id) => {
            const t = TIER_META[id];
            return (
              <li key={id} className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-fg">{t.rank}</span>
                <span className="text-sm tabular-nums text-muted">
                  {formatPsl(t.pslMin)}–{formatPsl(t.pslMax)}
                </span>
              </li>
            );
          })}
        </ol>
      </section>
    </div>
  );
}

export function HistoryScreen() {
  const history = useAppStore((s) => s.history);
  const removeHistory = useAppStore((s) => s.removeHistory);
  const go = useAppStore((s) => s.go);

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6">
      <p className="text-2xs uppercase tracking-hero text-subtle">Lịch sử</p>
      <h1 className="mt-1 font-display text-3xl font-bold">Các lần quét</h1>
      <p className="mt-2 text-sm text-muted">Lưu trên thiết bị này. Ảnh gốc không được giữ trên server.</p>

      {history.length === 0 ? (
        <div className="mt-10 rounded-2xl bg-surface p-6 text-center">
          <Clock3 className="mx-auto size-8 text-subtle" />
          <p className="mt-3 font-display font-semibold">Chưa có lịch sử</p>
          <p className="mt-1 text-sm text-muted">Quét lần đầu để thấy rank và điểm PSL ở đây.</p>
          <Button className="mt-5" onClick={() => go("scan")}>
            Quét ngay
          </Button>
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {history.map((item) => (
            <li key={item.id} className="flex gap-3 rounded-2xl bg-surface p-3">
              <button
                type="button"
                className="tap flex min-w-0 flex-1 gap-3 text-left"
                onClick={() => useAppStore.getState().openHistory(item)}
              >
                <img
                  src={item.thumbnail}
                  alt=""
                  className="size-16 shrink-0 rounded-lg object-cover bg-surface-2"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-display font-semibold leading-tight">{item.rank}</p>
                  <p className="mt-1 text-sm tabular-nums text-muted">
                    PSL {formatPsl(item.psl)} · {confidenceLabel(item.confidence)}
                  </p>
                  <p className="mt-1 text-2xs text-subtle">
                    {new Date(item.createdAt).toLocaleString("vi-VN", {
                      day: "2-digit",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </button>
              <button
                type="button"
                className="tap grid size-10 place-items-center rounded-lg text-subtle"
                onClick={() => removeHistory(item.id)}
                aria-label="Xóa"
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function ScaleScreen() {
  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-4 pt-6">
      <p className="text-2xs uppercase tracking-hero text-subtle">Thang đo</p>
      <h1 className="mt-1 font-display text-3xl font-bold">PSL Scale</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Bốn trục: Harmony, Dimorphism, Angularity, Miscellaneous. Rank dưới đây khớp công cụ PSL
        Score trên moggedupapp.com.
      </p>
      <ol className="mt-6 space-y-3">
        {TIER_ORDER.map((id) => {
          const t = TIER_META[id];
          return (
            <li key={id} className="rounded-2xl bg-surface p-4">
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="font-display text-lg font-semibold">{t.rank}</h2>
                <p className="text-sm tabular-nums text-accent">
                  {formatPsl(t.pslMin)}–{formatPsl(t.pslMax)}
                </p>
              </div>
              <p className="mt-1 text-2xs uppercase tracking-wider text-subtle">{t.rarity}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{t.blurb}</p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
