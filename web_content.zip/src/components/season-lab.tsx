import { useState } from "react";
import { formatHours, formatLat, monthName, seasonStats } from "@/lib/astro";
import { useVespera } from "@/lib/store";

const MONTH_START = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];

function monthOf(day: number): string {
  let idx = 0;
  for (let i = 0; i < 12; i++) if (day >= MONTH_START[i]) idx = i;
  return monthName(idx + 1);
}

export function SeasonLab() {
  const lat = useVespera((s) => s.lat);
  const setLat = useVespera((s) => s.setLat);
  const [day, setDay] = useState(172);
  const stats = seasonStats(lat, day);
  const toward = lat >= 0 ? stats.dec > 2 : stats.dec < -2;
  const away = lat >= 0 ? stats.dec < -2 : stats.dec > 2;
  const lean = stats.dec;

  let verdict = "Near an equinox. Day and night are close, everywhere.";
  if (stats.dayHours > 23) verdict = "The Sun doesn't set. Midnight sun — you are inside the polar day.";
  else if (stats.dayHours < 1) verdict = "The Sun doesn't rise. Polar night.";
  else if (toward) verdict = "Your hemisphere leans toward the Sun. Longer days, a high noon, summer weather.";
  else if (away) verdict = "Your hemisphere leans away. Short days, a low noon Sun, winter weather.";

  return (
    <figure className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
      <figcaption className="text-xs uppercase tracking-widest text-gold">One tilt, two seasons</figcaption>
      <div className="mt-4 grid items-center gap-6 md:grid-cols-[220px_1fr]">
        <svg viewBox="0 0 220 160" className="w-full" role="img" aria-label="Earth tilt relative to the Sun">
          <g stroke="#e2b15a" strokeOpacity="0.55">
            <line x1="8" y1="80" x2="48" y2="80" />
            <line x1="8" y1="68" x2="36" y2="68" />
            <line x1="8" y1="92" x2="36" y2="92" />
          </g>
          <text x="8" y="28" fill="#e2b15a" fontSize="11">
            Sun
          </text>
          <g transform={`rotate(${-lean} 130 80)`}>
            <circle cx="130" cy="80" r="36" fill="#1a3a52" stroke="#efe7d6" strokeOpacity="0.4" />
            <line x1="130" y1="28" x2="130" y2="132" stroke="#e2b15a" />
            <circle cx="130" cy="36" r="3" fill="#e2b15a" />
            <text x="138" y="32" fill="#efe7d6" fontSize="11">
              N
            </text>
            <text x="138" y="136" fill="#a7b0bd" fontSize="11">
              S
            </text>
            <line x1="96" y1="80" x2="164" y2="80" stroke="#7d8b9c" strokeDasharray="3 3" />
          </g>
        </svg>
        <div>
          <p className="font-display text-3xl text-fg">
            {monthOf(day)} · day {day}
          </p>
          <p className="mt-2 text-sm text-fg">{verdict}</p>
          <dl className="mt-4 grid grid-cols-3 gap-3">
            <div>
              <dt className="text-xs uppercase tracking-widest text-faint">Noon sun</dt>
              <dd className="mt-1 font-display text-2xl tabular-nums text-fg">{stats.noonAlt.toFixed(0)}°</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-widest text-faint">Daylight</dt>
              <dd className="mt-1 font-display text-2xl tabular-nums text-fg">{formatHours(stats.dayHours)}</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-widest text-faint">Sun declination</dt>
              <dd className="mt-1 font-display text-2xl tabular-nums text-fg">
                {stats.dec >= 0 ? "+" : "−"}
                {Math.abs(stats.dec).toFixed(0)}°
              </dd>
            </div>
          </dl>
          <label className="mt-4 block text-sm text-muted">
            <span className="flex justify-between">
              Day of the year <span className="text-fg">{monthOf(day)}</span>
            </span>
            <input className="mt-2 w-full" type="range" min={1} max={365} value={day} onChange={(e) => setDay(Number(e.target.value))} />
          </label>
          <label className="mt-3 block text-sm text-muted">
            <span className="flex justify-between">
              Your latitude <span className="text-fg tabular-nums">{formatLat(lat)}</span>
            </span>
            <input className="mt-2 w-full" type="range" min={-60} max={70} value={lat} onChange={(e) => setLat(Number(e.target.value))} />
          </label>
          <p className="mt-3 text-xs text-faint">Schematic, not to scale. The axis keeps pointing the same way in space — only our place in the orbit changes.</p>
        </div>
      </div>
    </figure>
  );
}
