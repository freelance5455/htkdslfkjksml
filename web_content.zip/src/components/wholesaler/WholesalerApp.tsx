import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Calculator,
  Layers,
  ShoppingBag,
  TrendingUp,
  DollarSign,
  ArrowRight,
  Package,
  CheckCircle2,
  AlertTriangle,
  FileText
} from 'lucide-react';

export const WholesalerApp: React.FC = () => {
  const {
    t,
    wholesaleInventory,
    updateWholesaleStock,
    addWholesalePurchase,
    products,
    orders,
    setInvoiceModalOrderId
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'purchase' | 'inventory' | 'sales' | 'calculator'>('dashboard');

  // Screen 28: Interactive Wholesale Profit Calculator State
  const [calcPurchasePrice, setCalcPurchasePrice] = useState<number>(8800); // ₹/1000
  const [calcTransportCost, setCalcTransportCost] = useState<number>(1200); // ₹/1000 or total
  const [calcLoadingUnloading, setCalcLoadingUnloading] = useState<number>(350); // ₹/1000 labour
  const [calcOtherExpense, setCalcOtherExpense] = useState<number>(200); // ₹/1000 wastage/overhead
  const [calcSellingPrice, setCalcSellingPrice] = useState<number>(11200); // ₹/1000 customer rate
  const [calcQuantityThousand, setCalcQuantityThousand] = useState<number>(5); // 5,000 bricks

  // Dynamic Mathematical Calculations for Screen 28
  const costPerThousand = calcPurchasePrice + calcTransportCost + calcLoadingUnloading + calcOtherExpense;
  const totalCost = costPerThousand * calcQuantityThousand;
  const totalRevenue = calcSellingPrice * calcQuantityThousand;
  const grossProfit = totalRevenue - totalCost;
  const profitPerThousand = calcSellingPrice - costPerThousand;
  const profitMarginPercent = totalRevenue > 0 ? ((grossProfit / totalRevenue) * 100).toFixed(1) : '0';

  // Purchase Bricks state (Screen 25)
  const [selectedKilnProduct, setSelectedKilnProduct] = useState<string>(products[0]?.id || '');
  const [purchaseQty, setPurchaseQty] = useState<number>(10);
  const [purchaseSuccess, setPurchaseSuccess] = useState<boolean>(false);

  // Wholesale Dashboard calculations (Screen 24)
  const totalInventoryStock = wholesaleInventory.reduce((s, i) => s + i.currentStockThousand, 0);
  const totalInventoryValue = wholesaleInventory.reduce((s, i) => s + i.currentStockThousand * i.sellingPricePerThousand, 0);
  const totalPurchasesThousand = wholesaleInventory.reduce((s, i) => s + i.purchasedThousand, 0);
  const totalSoldThousand = wholesaleInventory.reduce((s, i) => s + i.soldThousand, 0);

  const handlePlaceWholesaleOrder = () => {
    const prod = products.find((p) => p.id === selectedKilnProduct);
    if (!prod) return;

    addWholesalePurchase(prod.id, purchaseQty, prod.pricePerThousand);
    setPurchaseSuccess(true);
    setTimeout(() => {
      setPurchaseSuccess(false);
      setActiveTab('inventory');
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Sub Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#131822] border border-[#242f40] p-2 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
            <Store className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">
              Ghosh Imarati Bhandar & Building Materials
            </h2>
            <span className="text-[10px] text-slate-400 font-medium">
              NH-12 Yard Hub • Authorized Wholesale Stockist
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'dashboard' as const, label: 'Bhandar Dashboard' },
            { id: 'calculator' as const, label: '📊 Profit Calculator' },
            { id: 'inventory' as const, label: 'Yard Stock' },
            { id: 'purchase' as const, label: 'Purchase from Bhattas' },
            { id: 'sales' as const, label: 'Retail Sales' }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`wh-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2432]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* =========================================================================
          SCREEN 28: PROFIT CALCULATOR (Crucial prompt spec)
      ========================================================================= */}
      {activeTab === 'calculator' && (
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-gradient-to-br from-[#162030] to-[#111722] border border-[#273850] rounded-2xl p-6 shadow-xl">
            <div className="pb-4 border-b border-[#24334a] mb-6">
              <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                Screen 28 • Wholesale Imarati Bhandar Unit Economics
              </span>
              <h2 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
                <Calculator className="w-6 h-6 text-blue-400" />
                <span>Wholesale Brick Margin & Profit Calculator</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Real-time formula: [Selling Price - (Bhatta Cost + Freight + Labor + Wastage)] × Quantity
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Inputs Panel */}
              <div className="space-y-4 text-xs">
                <h3 className="font-bold text-slate-200 text-sm border-b border-[#222f42] pb-2">
                  Cost Inputs & Overhead
                </h3>

                <div>
                  <div className="flex justify-between text-slate-300 font-semibold mb-1">
                    <span>{t('calcPurchasePrice')}</span>
                    <span className="text-white font-mono">₹{calcPurchasePrice.toLocaleString()}</span>
                  </div>
                  <input
                    id="calc-input-purchase"
                    type="number"
                    value={calcPurchasePrice}
                    onChange={(e) => setCalcPurchasePrice(Number(e.target.value))}
                    className="w-full bg-[#0d1219] border border-[#223145] rounded-xl px-3 py-2 text-white font-mono text-sm outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 font-semibold mb-1">
                    <span>{t('calcTransportCost')} (₹/1000)</span>
                    <span className="text-white font-mono">₹{calcTransportCost.toLocaleString()}</span>
                  </div>
                  <input
                    id="calc-input-transport"
                    type="number"
                    value={calcTransportCost}
                    onChange={(e) => setCalcTransportCost(Number(e.target.value))}
                    className="w-full bg-[#0d1219] border border-[#223145] rounded-xl px-3 py-2 text-white font-mono text-sm outline-none focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      {t('calcLoadingUnloading')}
                    </label>
                    <input
                      id="calc-input-labor"
                      type="number"
                      value={calcLoadingUnloading}
                      onChange={(e) => setCalcLoadingUnloading(Number(e.target.value))}
                      className="w-full bg-[#0d1219] border border-[#223145] rounded-xl px-3 py-2 text-white font-mono text-sm outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      {t('calcOtherExpenses')}
                    </label>
                    <input
                      id="calc-input-wastage"
                      type="number"
                      value={calcOtherExpense}
                      onChange={(e) => setCalcOtherExpense(Number(e.target.value))}
                      className="w-full bg-[#0d1219] border border-[#223145] rounded-xl px-3 py-2 text-white font-mono text-sm outline-none"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-[#223043]">
                  <div className="flex justify-between text-slate-300 font-semibold mb-1">
                    <span>{t('calcSellingPrice')}</span>
                    <span className="text-emerald-400 font-mono font-bold">
                      ₹{calcSellingPrice.toLocaleString()}
                    </span>
                  </div>
                  <input
                    id="calc-input-selling"
                    type="number"
                    value={calcSellingPrice}
                    onChange={(e) => setCalcSellingPrice(Number(e.target.value))}
                    className="w-full bg-[#0d1219] border border-[#223145] rounded-xl px-3 py-2 text-white font-mono text-sm outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 font-semibold mb-1">
                    <span>{t('calcQuantity')}</span>
                    <span className="text-amber-400 font-mono font-bold">
                      {calcQuantityThousand}k ({calcQuantityThousand * 1000} bricks)
                    </span>
                  </div>
                  <input
                    id="calc-input-qty"
                    type="range"
                    min={1}
                    max={50}
                    step={1}
                    value={calcQuantityThousand}
                    onChange={(e) => setCalcQuantityThousand(Number(e.target.value))}
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Outputs Panel (Screen 28 Outputs: Total cost, Gross profit, Profit per 1k, Profit margin %) */}
              <div className="bg-[#0e131b] border border-[#243449] rounded-2xl p-5 flex flex-col justify-between space-y-4">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Calculated Margin Breakdown
                  </span>

                  <div className="mt-4 space-y-3">
                    <div className="p-3 bg-[#151d29] border border-[#223144] rounded-xl flex items-center justify-between">
                      <span className="text-xs text-slate-400">Total Landed Cost:</span>
                      <span className="text-sm font-bold text-white font-mono">
                        ₹{totalCost.toLocaleString()}
                      </span>
                    </div>

                    <div className="p-3 bg-[#151d29] border border-[#223144] rounded-xl flex items-center justify-between">
                      <span className="text-xs text-slate-400">Total Customer Billed:</span>
                      <span className="text-sm font-bold text-white font-mono">
                        ₹{totalRevenue.toLocaleString()}
                      </span>
                    </div>

                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
                      <span className="text-xs font-bold text-emerald-400 uppercase">
                        {t('grossProfit')}
                      </span>
                      <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">
                        ₹{grossProfit.toLocaleString()}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-[#151d29] border border-[#223144] rounded-xl text-center">
                        <span className="text-[10px] text-slate-400 uppercase font-semibold">
                          {t('profitPerThousand')}
                        </span>
                        <div className="text-base font-bold text-white font-mono mt-0.5">
                          ₹{profitPerThousand.toLocaleString()}
                        </div>
                      </div>

                      <div className="p-3 bg-[#151d29] border border-[#223144] rounded-xl text-center">
                        <span className="text-[10px] text-slate-400 uppercase font-semibold">
                          {t('profitMargin')}
                        </span>
                        <div className="text-base font-bold text-amber-400 font-mono mt-0.5">
                          {profitMarginPercent}%
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#202d3e] text-[11px] text-slate-400 leading-tight">
                  💡 Tip: Purchasing 10k+ quantities directly from kiln reduces transport rate by ~15%, boosting gross margin to &gt;18%.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 24: WHOLESALE DASHBOARD
      ========================================================================= */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Dashboard cards (Screen 24: Inventory, Purchase, Sales, Orders, Profit, Outstanding payments) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Yard Inventory</span>
              <div className="text-xl font-black text-white mt-1">{totalInventoryStock}k</div>
              <span className="text-[10px] text-slate-400">Total bricks in yard</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Inventory Value</span>
              <div className="text-xl font-black text-emerald-400 mt-1">
                ₹{(totalInventoryValue / 100000).toFixed(1)}L
              </div>
              <span className="text-[10px] text-emerald-400">Current asset value</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Monthly Purchase</span>
              <div className="text-xl font-black text-white mt-1">{totalPurchasesThousand}k</div>
              <span className="text-[10px] text-slate-400">From 4 Kilns</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Monthly Sales</span>
              <div className="text-xl font-black text-blue-400 mt-1">{totalSoldThousand}k</div>
              <span className="text-[10px] text-blue-400">Builders & retail</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Gross Margin</span>
              <div className="text-xl font-black text-amber-400 mt-1">16.8%</div>
              <span className="text-[10px] text-amber-400">+2.1% this month</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Outstanding Due</span>
              <div className="text-xl font-black text-rose-400 mt-1">₹68,400</div>
              <span className="text-[10px] text-rose-400">From 3 contractors</span>
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold text-[10px] uppercase">
                  Margin Tool
                </span>
                <h3 className="text-base font-bold text-white mt-1.5">
                  Launch Interactive Wholesale Profit Calculator
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Accurately compute total landed cost per thousand, labour, freight, and profit margin before quoting builders.
                </p>
              </div>
              <button
                id="open-profit-calc-btn"
                onClick={() => setActiveTab('calculator')}
                className="mt-4 py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Calculator className="w-4 h-4" />
                <span>Open Calculator</span>
              </button>
            </div>

            <div className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl flex flex-col justify-between">
              <div>
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px] uppercase">
                  Procurement
                </span>
                <h3 className="text-base font-bold text-white mt-1.5">
                  Direct Kiln Purchase & Spot Comparison
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Procure 10k-50k wholesale brick consignments from verified Bengal & Bihar kiln bhattas at bulk distributor rates.
                </p>
              </div>
              <button
                id="open-procurement-btn"
                onClick={() => setActiveTab('purchase')}
                className="mt-4 py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Browse Kiln Batches</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 26: WHOLESALE INVENTORY
      ========================================================================= */}
      {activeTab === 'inventory' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                Screen 26 • Bhandar Yard Ledger
              </span>
              <h2 className="text-xl font-bold text-white">{t('wholesaleInventory')}</h2>
            </div>
            <span className="text-xs text-slate-400">Live stock value: ₹{(totalInventoryValue / 100000).toFixed(2)} Lakh</span>
          </div>

          <div className="bg-[#141a24] border border-[#253243] rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#10141d] border-b border-[#212b3a] text-slate-400 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3.5">Product</th>
                    <th className="p-3.5">Opening Stock</th>
                    <th className="p-3.5">Purchased</th>
                    <th className="p-3.5">Sold</th>
                    <th className="p-3.5">Current Stock</th>
                    <th className="p-3.5">Buy Price (₹/1k)</th>
                    <th className="p-3.5">Sell Price (₹/1k)</th>
                    <th className="p-3.5">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1f2837]">
                  {wholesaleInventory.map((item) => (
                    <tr key={item.id} className="hover:bg-[#18202d] transition-colors">
                      <td className="p-3.5">
                        <div className="font-bold text-white">{item.name}</div>
                        <div className="text-[10px] text-slate-400">{item.category}</div>
                      </td>
                      <td className="p-3.5 font-mono">{item.openingStockThousand}k</td>
                      <td className="p-3.5 font-mono text-emerald-400">+{item.purchasedThousand}k</td>
                      <td className="p-3.5 font-mono text-amber-400">-{item.soldThousand}k</td>
                      <td className="p-3.5 font-mono font-bold text-white text-sm">
                        {item.currentStockThousand}k
                      </td>
                      <td className="p-3.5 font-mono">₹{item.purchasePricePerThousand.toLocaleString()}</td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        ₹{item.sellingPricePerThousand.toLocaleString()}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-1">
                          <button
                            id={`inv-minus-${item.id}`}
                            onClick={() => updateWholesaleStock(item.id, Math.max(0, item.currentStockThousand - 2))}
                            className="px-2 py-1 bg-[#1e2736] hover:bg-[#283549] text-white rounded text-xs"
                          >
                            -2k
                          </button>
                          <button
                            id={`inv-plus-${item.id}`}
                            onClick={() => updateWholesaleStock(item.id, item.currentStockThousand + 5)}
                            className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold"
                          >
                            +5k
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 25: PURCHASE FROM BHATTAS
      ========================================================================= */}
      {activeTab === 'purchase' && (
        <div className="max-w-3xl mx-auto bg-[#151b25] border border-[#263345] rounded-2xl p-6 space-y-5">
          <div className="pb-3 border-b border-[#243142]">
            <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
              Screen 25 • Kiln Direct Procurement
            </span>
            <h2 className="text-xl font-bold text-white mt-0.5">{t('purchaseFromMfg')}</h2>
            <p className="text-xs text-slate-400">
              Procure direct wholesale batches at manufacturer gate rates
            </p>
          </div>

          {purchaseSuccess && (
            <div className="p-3 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Purchase order placed! Stock added to Bhandar Yard.</span>
            </div>
          )}

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Select Kiln Manufacturer & Batch
              </label>
              <select
                id="select-kiln-product"
                value={selectedKilnProduct}
                onChange={(e) => setSelectedKilnProduct(e.target.value)}
                className="w-full bg-[#10141e] border border-[#273549] rounded-xl px-3.5 py-2.5 text-white outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — {p.manufacturerName} (₹{p.pricePerThousand}/1k)
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Quantity (Thousands of Bricks)
                </label>
                <input
                  id="wholesale-purchase-qty"
                  type="number"
                  min={2}
                  max={100}
                  value={purchaseQty}
                  onChange={(e) => setPurchaseQty(Number(e.target.value))}
                  className="w-full bg-[#10141e] border border-[#273549] rounded-xl px-3.5 py-2.5 text-white font-bold outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Consignment Transport Fee
                </label>
                <div className="w-full bg-[#10141e] border border-[#273549] rounded-xl px-3.5 py-2.5 text-slate-300">
                  ₹4,200 (10-Wheeler Assigned)
                </div>
              </div>
            </div>

            <button
              id="confirm-bhandar-purchase-btn"
              onClick={handlePlaceWholesaleOrder}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-600/20"
            >
              <span>Place Purchase Order to Bhatta</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 27: WHOLESALE SALES
      ========================================================================= */}
      {activeTab === 'sales' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
              Screen 27 • Retail & B2B Sales Ledger
            </span>
            <h2 className="text-xl font-bold text-white">Wholesale Dispatches & Retail Customers</h2>
          </div>

          <div className="space-y-3 text-xs">
            {orders.map((ord) => (
              <div
                key={ord.id}
                className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">{ord.id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                      {ord.orderStatus}
                    </span>
                  </div>
                  <p className="text-slate-200 mt-1 font-semibold">
                    Customer: {ord.customerName} ({ord.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks)
                  </p>
                  <p className="text-slate-400 text-[11px] truncate max-w-md">
                    Site: {ord.deliveryAddress}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400">Billed Total</span>
                    <div className="font-bold text-white text-sm">
                      ₹{ord.totalAmount.toLocaleString()}
                    </div>
                  </div>
                  <button
                    onClick={() => setInvoiceModalOrderId(ord.id)}
                    className="px-3 py-1.5 bg-[#1f2937] hover:bg-[#283547] text-slate-200 font-medium rounded-lg"
                  >
                    Invoice
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
