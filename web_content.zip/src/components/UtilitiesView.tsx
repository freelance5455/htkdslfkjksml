import React, { useEffect, useRef, useState } from 'react';
import {
  Battery,
  BatteryCharging,
  Calculator as CalcIcon,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  CloudSun,
  Copy,
  Delete,
  ExternalLink,
  Flashlight,
  Globe,
  Hourglass,
  MapPin,
  Navigation,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Search,
  StickyNote,
  Timer,
  Trash2,
  Vibrate,
} from 'lucide-react';
import type { NoteItem, ShortcutItem, UtilityPanelId, WeatherData } from '../types';
import { loadNotes, loadShortcuts, saveNotes, saveShortcuts } from '../services/storage';

interface UtilitiesViewProps {
  activeUtility: UtilityPanelId;
  onSelectUtility: (id: UtilityPanelId) => void;
  lowPowerActive?: boolean;
}

const UTILITY_TABS: Array<{ id: UtilityPanelId; label: string; icon: React.ReactNode }> = [
  { id: 'clock', label: 'Clock & Date', icon: <Clock className="h-4 w-4" /> },
  { id: 'weather', label: 'Weather', icon: <CloudSun className="h-4 w-4" /> },
  { id: 'timer', label: 'Timer', icon: <Hourglass className="h-4 w-4" /> },
  { id: 'stopwatch', label: 'Stopwatch', icon: <Timer className="h-4 w-4" /> },
  { id: 'calculator', label: 'Calculator', icon: <CalcIcon className="h-4 w-4" /> },
  { id: 'notes', label: 'Notes', icon: <StickyNote className="h-4 w-4" /> },
  { id: 'shortcuts', label: 'Shortcuts', icon: <Globe className="h-4 w-4" /> },
  { id: 'device', label: 'Device', icon: <Battery className="h-4 w-4" /> },
  { id: 'camera', label: 'Camera', icon: <Camera className="h-4 w-4" /> },
];

// Safe arithmetic evaluator (no eval / Function)
function evaluateExpression(expr: string): string {
  const sanitized = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').trim();
  if (!sanitized) return '0';
  if (!/^[0-9+\-*/.%()\s]+$/.test(sanitized)) {
    throw new Error('Invalid characters');
  }

  const tokens: string[] = [];
  let i = 0;
  while (i < sanitized.length) {
    const ch = sanitized[i];
    if (ch === ' ') {
      i++;
      continue;
    }
    if (/[0-9.]/.test(ch)) {
      let num = '';
      while (i < sanitized.length && /[0-9.]/.test(sanitized[i])) {
        num += sanitized[i++];
      }
      if ((num.match(/\./g) ?? []).length > 1) throw new Error('Invalid number');
      tokens.push(num);
      continue;
    }
    if ('+-*/%()'.includes(ch)) {
      // Handle unary minus
      if (
        ch === '-' &&
        (tokens.length === 0 || '+-*/%('.includes(tokens[tokens.length - 1]))
      ) {
        let num = '-';
        i++;
        while (i < sanitized.length && /[0-9.]/.test(sanitized[i])) {
          num += sanitized[i++];
        }
        if (num === '-') {
          tokens.push('0');
          tokens.push('-');
        } else {
          tokens.push(num);
        }
        continue;
      }
      tokens.push(ch);
      i++;
      continue;
    }
    throw new Error('Invalid token');
  }

  const output: Array<number | string> = [];
  const ops: string[] = [];
  const prec: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2 };

  for (const tok of tokens) {
    if (!Number.isNaN(Number(tok)) && tok !== '') {
      output.push(Number(tok));
    } else if (tok === '(') {
      ops.push(tok);
    } else if (tok === ')') {
      while (ops.length > 0 && ops[ops.length - 1] !== '(') {
        output.push(ops.pop()!);
      }
      if (ops.pop() !== '(') throw new Error('Mismatched parentheses');
    } else {
      while (
        ops.length > 0 &&
        ops[ops.length - 1] !== '(' &&
        (prec[ops[ops.length - 1]] ?? 0) >= (prec[tok] ?? 0)
      ) {
        output.push(ops.pop()!);
      }
      ops.push(tok);
    }
  }
  while (ops.length > 0) {
    const op = ops.pop()!;
    if (op === '(') throw new Error('Mismatched parentheses');
    output.push(op);
  }

  const stack: number[] = [];
  for (const item of output) {
    if (typeof item === 'number') {
      stack.push(item);
    } else {
      const b = stack.pop();
      const a = stack.pop();
      if (a === undefined || b === undefined) throw new Error('Invalid expression');
      if (item === '+') stack.push(a + b);
      else if (item === '-') stack.push(a - b);
      else if (item === '*') stack.push(a * b);
      else if (item === '/') {
        if (b === 0) throw new Error('Cannot divide by zero');
        stack.push(a / b);
      } else if (item === '%') {
        if (b === 0) throw new Error('Cannot divide by zero');
        stack.push(a % b);
      }
    }
  }
  if (stack.length !== 1 || !Number.isFinite(stack[0])) {
    throw new Error('Invalid expression');
  }
  const rounded = Math.round(stack[0] * 1e10) / 1e10;
  return String(rounded);
}

function playAlarmTone() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    [0, 0.25, 0.5].forEach((offset) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now + offset);
      gain.gain.setValueAtTime(0.18, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.2);
    });
  } catch {
    // Ignore audio context errors
  }
}

export const UtilitiesView: React.FC<UtilitiesViewProps> = ({
  activeUtility,
  onSelectUtility,
  lowPowerActive = false,
}) => {
  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* Horizontal scrollable utility picker */}
      <div className="border-b border-sky-400/15 bg-[#060d1e]/90 px-3 py-2.5 overflow-x-auto custom-scrollbar">
        <div className="flex items-center gap-1.5 min-w-max">
          {UTILITY_TABS.map((tab) => {
            const active = activeUtility === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectUtility(tab.id)}
                className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                  active
                    ? 'bg-cyan-500/20 border border-cyan-400/45 text-cyan-200'
                    : 'border border-transparent bg-[#0a1428] text-slate-300 hover:border-sky-400/20 hover:text-slate-100'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active utility panel */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
        <div className="mx-auto max-w-2xl">
          {activeUtility === 'clock' && (
            <ClockCalendarPanel lowPowerActive={lowPowerActive} />
          )}
          {activeUtility === 'weather' && (
            <WeatherPanel lowPowerActive={lowPowerActive} />
          )}
          {activeUtility === 'timer' && <TimerPanel />}
          {activeUtility === 'stopwatch' && <StopwatchPanel />}
          {activeUtility === 'calculator' && <CalculatorPanel />}
          {activeUtility === 'notes' && <NotesPanel />}
          {activeUtility === 'shortcuts' && <ShortcutsPanel />}
          {activeUtility === 'device' && <DevicePanel />}
          {activeUtility === 'camera' && <CameraPanel />}
        </div>
      </div>
    </div>
  );
};

/* ---------------- 1. Clock & Calendar ---------------- */
const ClockCalendarPanel: React.FC<{ lowPowerActive?: boolean }> = ({
  lowPowerActive = false,
}) => {
  const [now, setNow] = useState(() => new Date());
  const [viewDate, setViewDate] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  useEffect(() => {
    setNow(new Date());
    if (lowPowerActive) return;
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, [lowPowerActive]);

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstDayOffset = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = viewDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const today = new Date();
  const isCurrentMonth =
    today.getFullYear() === year && today.getMonth() === month;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-5 text-center">
        <p className="text-xs font-medium text-sky-300/80">{timeZone}</p>
        <div className="mt-2 font-mono text-4xl sm:text-5xl font-semibold tracking-tight text-cyan-200 tabular-nums">
          {now.toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            ...(lowPowerActive ? {} : { second: '2-digit' }),
            hour12: true,
          })}
        </div>
        <p className="mt-2 text-sm text-slate-300">
          {now.toLocaleDateString('en-IN', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
          })}
        </p>
        {lowPowerActive && (
          <p className="mt-2 text-xs text-amber-300/90">
            1-second clock polling paused in Low Power Mode
          </p>
        )}
      </div>

      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-base font-semibold text-slate-100">{monthName}</h3>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setViewDate(new Date(year, month - 1, 1))}
              aria-label="Previous month"
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-sky-400/15 bg-[#0c1a33] text-slate-300 hover:text-cyan-200"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewDate(new Date(year, month + 1, 1))}
              aria-label="Next month"
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-sky-400/15 bg-[#0c1a33] text-slate-300 hover:text-cyan-200"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center text-xs text-slate-400 mb-1.5">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="py-1 font-medium">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1 text-center font-mono text-sm tabular-nums">
          {Array.from({ length: firstDayOffset }).map((_, i) => (
            <div key={`empty-${i}`} className="h-10" />
          ))}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const dayNum = idx + 1;
            const isToday = isCurrentMonth && dayNum === today.getDate();
            return (
              <div
                key={dayNum}
                className={`flex h-10 items-center justify-center rounded-xl ${
                  isToday
                    ? 'bg-cyan-500 text-[#040812] font-bold'
                    : 'text-slate-200 hover:bg-sky-500/10'
                }`}
              >
                {dayNum}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/* ---------------- 2. Weather ---------------- */
const WeatherPanel: React.FC<{ lowPowerActive?: boolean }> = ({
  lowPowerActive = false,
}) => {
  const [cityInput, setCityInput] = useState('New Delhi');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCityWeather = async (city: string) => {
    const trimmed = city.trim();
    if (!trimmed) return;
    setLoading(true);
    setError(null);
    try {
      const resp = await fetch(`/api/weather?city=${encodeURIComponent(trimmed)}`);
      const data = await resp.json();
      if (!resp.ok) {
        setError(data.error ?? 'Could not load weather.');
      } else {
        setWeather(data as WeatherData);
      }
    } catch {
      setError('Network error while fetching weather.');
    } finally {
      setLoading(false);
    }
  };

  const fetchMyLocationWeather = () => {
    if (!('geolocation' in navigator)) {
      setError('Geolocation is not supported on this browser.');
      return;
    }
    setLoading(true);
    setError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const resp = await fetch(
            `/api/weather?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}`,
          );
          const data = await resp.json();
          if (!resp.ok) {
            setError(data.error ?? 'Could not fetch local weather.');
          } else {
            setWeather(data as WeatherData);
          }
        } catch {
          setError('Network error while fetching local weather.');
        } finally {
          setLoading(false);
        }
      },
      (geoErr) => {
        setLoading(false);
        setError(
          geoErr.code === geoErr.PERMISSION_DENIED
            ? 'Location permission was denied. You can still search any city below.'
            : 'Unable to determine your GPS location right now.',
        );
      },
      { enableHighAccuracy: false, timeout: 8000 },
    );
  };

  useEffect(() => {
    if (lowPowerActive) return;
    void fetchCityWeather('New Delhi');
  }, [lowPowerActive]);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void fetchCityWeather(cityInput);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={cityInput}
            onChange={(e) => setCityInput(e.target.value)}
            placeholder="Enter city (e.g. Mumbai, Delhi, Bengaluru)"
            className="min-h-[44px] flex-1 rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="min-h-[44px] rounded-xl bg-cyan-500 px-4 text-sm font-semibold text-[#040812] hover:bg-cyan-400 disabled:opacity-50"
          >
            <Search className="h-4 w-4" />
          </button>
        </form>

        <button
          type="button"
          onClick={fetchMyLocationWeather}
          disabled={loading}
          className="inline-flex w-full min-h-[44px] items-center justify-center gap-2 rounded-xl border border-sky-400/25 bg-[#0c1a33] px-4 text-xs font-medium text-sky-200 hover:bg-[#112447] disabled:opacity-50"
        >
          <Navigation className="h-4 w-4 text-cyan-300" />
          <span>Use My Current Location (asks permission)</span>
        </button>

        {error && (
          <p className="rounded-xl border border-rose-400/30 bg-rose-950/35 px-3 py-2.5 text-xs text-rose-200">
            {error}
          </p>
        )}
      </div>

      {loading && (
        <div className="rounded-2xl border border-sky-400/15 bg-[#091326] p-6 text-center text-sm text-sky-200">
          Fetching live weather data…
        </div>
      )}

      {weather && !loading && (
        <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-5 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-semibold text-slate-100">
                {weather.locationName}
              </h3>
              <p className="text-xs text-slate-400">
                {weather.country ? `${weather.country} · ` : ''}
                {weather.condition}
              </p>
            </div>
            <div className="font-mono text-4xl font-semibold text-cyan-200 tabular-nums">
              {weather.temperatureC}°C
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-[#050c1a] p-3">
              <div className="text-[11px] text-slate-400">Feels Like</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-100 tabular-nums">
                {weather.apparentTempC}°C
              </div>
            </div>
            <div className="rounded-xl bg-[#050c1a] p-3">
              <div className="text-[11px] text-slate-400">Humidity</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-100 tabular-nums">
                {weather.humidity}%
              </div>
            </div>
            <div className="rounded-xl bg-[#050c1a] p-3">
              <div className="text-[11px] text-slate-400">Wind</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-100 tabular-nums">
                {weather.windKmh} km/h
              </div>
            </div>
          </div>

          {weather.daily.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-sky-400/15">
              <p className="text-xs font-medium text-slate-400">3-Day Forecast</p>
              {weather.daily.map((day) => (
                <div
                  key={day.date}
                  className="flex items-center justify-between text-xs py-1.5"
                >
                  <span className="text-slate-200 font-medium">
                    {new Date(`${day.date}T12:00:00`).toLocaleDateString('en-IN', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'short',
                    })}
                  </span>
                  <span className="text-slate-400">{day.condition}</span>
                  <span className="font-mono text-sky-200 tabular-nums">
                    {day.tempMin}° / {day.tempMax}°C
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

/* ---------------- 3. Timer ---------------- */
const TimerPanel: React.FC = () => {
  const [minutesInput, setMinutesInput] = useState(1);
  const [secondsInput, setSecondsInput] = useState(0);
  const [remainingMs, setRemainingMs] = useState(60_000);
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    if (!running) return;
    const interval = window.setInterval(() => {
      setRemainingMs((prev) => {
        if (prev <= 1000) {
          setRunning(false);
          setFinished(true);
          playAlarmTone();
          if (typeof navigator.vibrate === 'function') {
            navigator.vibrate([200, 100, 200]);
          }
          return 0;
        }
        return prev - 1000;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [running]);

  const applyPreset = (mins: number, secs = 0) => {
    setRunning(false);
    setFinished(false);
    setMinutesInput(mins);
    setSecondsInput(secs);
    setRemainingMs((mins * 60 + secs) * 1000);
  };

  const totalSecs = Math.ceil(remainingMs / 1000);
  const displayMin = String(Math.floor(totalSecs / 60)).padStart(2, '0');
  const displaySec = String(totalSecs % 60).padStart(2, '0');

  return (
    <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-5 space-y-5">
      <div className="text-center">
        <div
          className={`font-mono text-5xl font-semibold tabular-nums ${
            finished ? 'text-amber-300' : 'text-cyan-200'
          }`}
        >
          {displayMin}:{displaySec}
        </div>
        {finished && (
          <p className="mt-2 text-xs font-medium text-amber-300">
            Timer finished!
          </p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { label: '1 min', m: 1 },
          { label: '5 min', m: 5 },
          { label: '10 min', m: 10 },
        ].map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => applyPreset(p.m)}
            className="min-h-[44px] rounded-xl border border-sky-400/20 bg-[#0c1a33] text-xs font-medium text-sky-200 hover:border-cyan-400/40"
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <label className="block text-xs text-slate-400">
          Minutes
          <input
            type="number"
            min={0}
            max={180}
            value={minutesInput}
            onChange={(e) => {
              const v = Math.max(0, Math.min(180, Number(e.target.value) || 0));
              applyPreset(v, secondsInput);
            }}
            className="mt-1 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3 font-mono text-sm text-slate-100"
          />
        </label>
        <label className="block text-xs text-slate-400">
          Seconds
          <input
            type="number"
            min={0}
            max={59}
            value={secondsInput}
            onChange={(e) => {
              const v = Math.max(0, Math.min(59, Number(e.target.value) || 0));
              applyPreset(minutesInput, v);
            }}
            className="mt-1 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3 font-mono text-sm text-slate-100"
          />
        </label>
      </div>

      <div className="flex gap-2.5">
        <button
          type="button"
          onClick={() => {
            if (remainingMs === 0) applyPreset(minutesInput, secondsInput);
            setFinished(false);
            setRunning((r) => !r);
          }}
          className="flex-1 min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500 text-sm font-semibold text-[#040812] hover:bg-cyan-400"
        >
          {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          <span>{running ? 'Pause' : 'Start'}</span>
        </button>
        <button
          type="button"
          onClick={() => applyPreset(minutesInput, secondsInput)}
          className="min-h-[48px] min-w-[48px] inline-flex items-center justify-center gap-2 rounded-xl border border-sky-400/25 bg-[#0c1a33] px-4 text-sm font-medium text-slate-200 hover:bg-[#122546]"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
};

/* ---------------- 4. Stopwatch ---------------- */
const StopwatchPanel: React.FC = () => {
  const [elapsedMs, setElapsedMs] = useState(0);
  const [running, setRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const lastStartRef = useRef<number>(0);

  useEffect(() => {
    if (!running) return;
    lastStartRef.current = performance.now() - elapsedMs;
    let rafId = 0;
    const tick = () => {
      setElapsedMs(performance.now() - lastStartRef.current);
      rafId = window.requestAnimationFrame(tick);
    };
    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [running]);

  const formatSw = (ms: number) => {
    const totalCs = Math.floor(ms / 10);
    const cs = String(totalCs % 100).padStart(2, '0');
    const totalS = Math.floor(totalCs / 100);
    const s = String(totalS % 60).padStart(2, '0');
    const m = String(Math.floor(totalS / 60)).padStart(2, '0');
    return `${m}:${s}.${cs}`;
  };

  return (
    <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-5 space-y-5">
      <div className="text-center font-mono text-5xl font-semibold text-cyan-200 tabular-nums">
        {formatSw(elapsedMs)}
      </div>

      <div className="flex gap-2.5">
        <button
          type="button"
          onClick={() => setRunning((r) => !r)}
          className="flex-1 min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500 text-sm font-semibold text-[#040812] hover:bg-cyan-400"
        >
          {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          <span>{running ? 'Pause' : 'Start'}</span>
        </button>
        <button
          type="button"
          disabled={!running}
          onClick={() => setLaps((prev) => [elapsedMs, ...prev])}
          className="min-h-[48px] rounded-xl border border-sky-400/25 bg-[#0c1a33] px-4 text-sm font-medium text-sky-200 disabled:opacity-40"
        >
          Lap
        </button>
        <button
          type="button"
          onClick={() => {
            setRunning(false);
            setElapsedMs(0);
            setLaps([]);
          }}
          className="min-h-[48px] min-w-[48px] inline-flex items-center justify-center rounded-xl border border-sky-400/25 bg-[#0c1a33] text-slate-200"
          aria-label="Reset stopwatch"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>

      {laps.length > 0 && (
        <div className="max-h-52 overflow-y-auto custom-scrollbar divide-y divide-sky-400/10 border-t border-sky-400/15 pt-2">
          {laps.map((lapMs, idx) => (
            <div
              key={`${lapMs}-${idx}`}
              className="flex items-center justify-between py-2 text-xs font-mono tabular-nums"
            >
              <span className="text-slate-400">Lap {laps.length - idx}</span>
              <span className="text-cyan-200">{formatSw(lapMs)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ---------------- 5. Calculator ---------------- */
const CalculatorPanel: React.FC = () => {
  const [expr, setExpr] = useState('');
  const [result, setResult] = useState('0');
  const [error, setError] = useState<string | null>(null);

  const press = (val: string) => {
    setError(null);
    if (val === 'C') {
      setExpr('');
      setResult('0');
      return;
    }
    if (val === 'DEL') {
      setExpr((prev) => prev.slice(0, -1));
      return;
    }
    if (val === '=') {
      if (!expr.trim()) return;
      try {
        const res = evaluateExpression(expr);
        setResult(res);
        setExpr(res);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Invalid expression');
      }
      return;
    }
    setExpr((prev) => prev + val);
  };

  const buttons = [
    ['C', '(', ')', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '−'],
    ['1', '2', '3', '+'],
    ['0', '.', '%', '='],
  ];

  return (
    <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
      <div className="rounded-xl bg-[#040914] p-4 text-right border border-sky-400/15">
        <div className="min-h-[22px] font-mono text-sm text-slate-400 break-all">
          {expr || '0'}
        </div>
        <div className="mt-1 font-mono text-3xl font-semibold text-cyan-200 tabular-nums break-all">
          {error ? <span className="text-sm text-rose-300">{error}</span> : result}
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={() => press('DEL')}
          className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-sky-400/20 bg-[#0c1a33] px-3.5 text-xs font-medium text-slate-200 hover:bg-[#13284d]"
        >
          <Delete className="h-4 w-4" />
          <span>Backspace</span>
        </button>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {buttons.flat().map((btn) => {
          const isEquals = btn === '=';
          const isOp = ['÷', '×', '−', '+', '%', '(', ')'].includes(btn);
          const isClear = btn === 'C';
          return (
            <button
              key={btn}
              type="button"
              onClick={() => press(btn)}
              className={`min-h-[52px] rounded-xl font-mono text-lg font-semibold transition-colors active:scale-[0.97] ${
                isEquals
                  ? 'bg-cyan-500 text-[#040812] hover:bg-cyan-400'
                  : isClear
                    ? 'bg-rose-500/20 border border-rose-400/30 text-rose-200 hover:bg-rose-500/30'
                    : isOp
                      ? 'bg-sky-500/15 border border-sky-400/25 text-cyan-200 hover:bg-sky-500/25'
                      : 'bg-[#0d182f] border border-sky-400/10 text-slate-100 hover:bg-[#132240]'
              }`}
            >
              {btn}
            </button>
          );
        })}
      </div>
    </div>
  );
};

/* ---------------- 6. Notes ---------------- */
const NotesPanel: React.FC = () => {
  const [notes, setNotes] = useState<NoteItem[]>(() => loadNotes());
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [savedNotice, setSavedNotice] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const persist = (next: NoteItem[]) => {
    setNotes(next);
    saveNotes(next);
  };

  const deriveTitle = (rawTitle: string, rawBody: string): string => {
    if (rawTitle.trim()) return rawTitle.trim().slice(0, 64);
    const firstLine = rawBody.trim().split('\n')[0]?.trim() ?? '';
    if (!firstLine) return 'Quick Note';
    return firstLine.length > 36 ? `${firstLine.slice(0, 36)}…` : firstLine;
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !body.trim()) return;
    const now = Date.now();
    const resolvedTitle = deriveTitle(title, body);
    const resolvedBody = body.trim();

    if (editingId) {
      persist(
        notes.map((n) =>
          n.id === editingId
            ? { ...n, title: resolvedTitle, body: resolvedBody, updatedAt: now }
            : n,
        ),
      );
      setEditingId(null);
    } else {
      persist([
        {
          id: `note-${now}`,
          title: resolvedTitle,
          body: resolvedBody,
          updatedAt: now,
        },
        ...notes,
      ]);
    }
    setTitle('');
    setBody('');
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 1800);
  };

  const handleCopy = async (note: NoteItem) => {
    const content = note.body ? `${note.title}\n${note.body}` : note.title;
    try {
      await navigator.clipboard.writeText(content);
      setCopiedId(note.id);
      window.setTimeout(() => setCopiedId((prev) => (prev === note.id ? null : prev)), 1600);
    } catch {
      // Ignore clipboard failure
    }
  };

  const visibleNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(filter.toLowerCase()) ||
      n.body.toLowerCase().includes(filter.toLowerCase()),
  );

  return (
    <div className="space-y-4">
      <form
        onSubmit={handleSave}
        className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3"
      >
        <div className="flex items-center justify-between gap-2 text-xs text-slate-400">
          <span>Saved locally on device · Works offline</span>
          <span className="font-mono tabular-nums text-cyan-300/90">
            {notes.length} {notes.length === 1 ? 'note' : 'notes'}
          </span>
        </div>

        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title (optional for quick thoughts)"
          className="w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
        />
        <textarea
          rows={3}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Capture a quick thought, reminder, or idea offline…"
          className="w-full rounded-xl border border-sky-400/20 bg-[#050b18] p-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
        />
        <div className="flex items-center gap-2">
          <button
            type="submit"
            disabled={!title.trim() && !body.trim()}
            className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 text-sm font-semibold text-[#040812] hover:bg-cyan-400 disabled:opacity-45"
          >
            {savedNotice ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            <span>
              {savedNotice ? 'Saved Locally' : editingId ? 'Update Note' : 'Save Note'}
            </span>
          </button>
          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setTitle('');
                setBody('');
              }}
              className="min-h-[44px] rounded-xl border border-sky-400/20 px-4 text-sm text-slate-300"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      {notes.length > 0 && (
        <input
          type="search"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Search saved notes…"
          className="w-full min-h-[44px] rounded-xl border border-sky-400/15 bg-[#091326] px-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
        />
      )}

      {visibleNotes.length === 0 ? (
        <div className="rounded-2xl border border-sky-400/15 bg-[#091326] p-6 text-center text-sm text-slate-400">
          {notes.length === 0
            ? 'No notes saved yet. Capture a quick thought above.'
            : 'No saved notes match your search.'}
        </div>
      ) : (
        <div className="space-y-2.5">
          {visibleNotes.map((note) => (
            <div
              key={note.id}
              className="rounded-2xl border border-sky-400/15 bg-[#091326] p-4"
            >
              <div className="flex items-start justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(note.id);
                    setTitle(note.title);
                    setBody(note.body);
                  }}
                  className="text-left flex-1 min-h-[44px]"
                >
                  <h4 className="font-medium text-sm text-cyan-200">{note.title}</h4>
                  {note.body && (
                    <p className="mt-1 text-xs text-slate-300 whitespace-pre-wrap">
                      {note.body}
                    </p>
                  )}
                  <p className="mt-2 text-[11px] text-slate-500 font-mono">
                    {new Date(note.updatedAt).toLocaleString()}
                  </p>
                </button>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    aria-label={`Copy ${note.title}`}
                    onClick={() => void handleCopy(note)}
                    className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-400 hover:bg-sky-500/15 hover:text-cyan-200"
                  >
                    {copiedId === note.id ? (
                      <Check className="h-4 w-4 text-cyan-300" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete ${note.title}`}
                    onClick={() => {
                      if (editingId === note.id) {
                        setEditingId(null);
                        setTitle('');
                        setBody('');
                      }
                      persist(notes.filter((n) => n.id !== note.id));
                    }}
                    className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-400 hover:bg-rose-950/50 hover:text-rose-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ---------------- 7. Quick Website Shortcuts ---------------- */
const ShortcutsPanel: React.FC = () => {
  const [shortcuts, setShortcuts] = useState<ShortcutItem[]>(() => loadShortcuts());
  const [label, setLabel] = useState('');
  const [url, setUrl] = useState('');
  const [urlError, setUrlError] = useState<string | null>(null);

  const addShortcut = (e: React.FormEvent) => {
    e.preventDefault();
    setUrlError(null);
    const cleanLabel = label.trim();
    let cleanUrl = url.trim();
    if (!cleanLabel || !cleanUrl) {
      setUrlError('Enter both a name and a website URL.');
      return;
    }
    if (!/^https?:\/\//i.test(cleanUrl)) {
      cleanUrl = `https://${cleanUrl}`;
    }
    try {
      const parsed = new URL(cleanUrl);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        throw new Error('Invalid protocol');
      }
      const next = [
        ...shortcuts,
        { id: `sc-${Date.now()}`, label: cleanLabel.slice(0, 24), url: parsed.toString() },
      ];
      setShortcuts(next);
      saveShortcuts(next);
      setLabel('');
      setUrl('');
    } catch {
      setUrlError('Please enter a valid http:// or https:// URL.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        {shortcuts.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between rounded-2xl border border-sky-400/20 bg-[#091326] pr-1.5"
          >
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 min-h-[52px] flex items-center gap-2 px-3.5 text-sm font-medium text-sky-100 hover:text-cyan-200 truncate"
            >
              <ExternalLink className="h-4 w-4 shrink-0 text-cyan-300" />
              <span className="truncate">{item.label}</span>
            </a>
            <button
              type="button"
              aria-label={`Remove ${item.label}`}
              onClick={() => {
                const next = shortcuts.filter((s) => s.id !== item.id);
                setShortcuts(next);
                saveShortcuts(next);
              }}
              className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:text-rose-300"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      <form
        onSubmit={addShortcut}
        className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3"
      >
        <h3 className="text-sm font-semibold text-slate-100">Add Custom Shortcut</h3>
        <div className="grid sm:grid-cols-2 gap-2.5">
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Name (e.g. GitHub)"
            className="min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 placeholder:text-slate-500"
          />
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="URL (e.g. https://github.com)"
            className="min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 placeholder:text-slate-500"
          />
        </div>
        {urlError && <p className="text-xs text-rose-300">{urlError}</p>}
        <button
          type="submit"
          className="w-full min-h-[44px] rounded-xl bg-cyan-500 px-4 text-sm font-semibold text-[#040812] hover:bg-cyan-400"
        >
          Add Shortcut
        </button>
      </form>
    </div>
  );
};

/* ---------------- 8. Device Capabilities (Battery, Vibration, Torch, Location) ---------------- */
const DevicePanel: React.FC = () => {
  const [batteryInfo, setBatteryInfo] = useState<{
    supported: boolean;
    level?: number;
    charging?: boolean;
  }>({ supported: false });
  const [vibrateStatus, setVibrateStatus] = useState<string | null>(null);
  const [torchOn, setTorchOn] = useState(false);
  const [torchStatus, setTorchStatus] = useState<string | null>(null);
  const torchStreamRef = useRef<MediaStream | null>(null);

  const [coords, setCoords] = useState<{
    lat: number;
    lon: number;
    accuracy: number;
  } | null>(null);
  const [locationStatus, setLocationStatus] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<{
        level: number;
        charging: boolean;
        addEventListener?: (name: string, fn: () => void) => void;
        removeEventListener?: (name: string, fn: () => void) => void;
      }>;
    };

    if (typeof nav.getBattery === 'function') {
      nav
        .getBattery()
        .then((bat) => {
          if (!active) return;
          const sync = () => {
            if (!active) return;
            setBatteryInfo({
              supported: true,
              level: Math.round(bat.level * 100),
              charging: bat.charging,
            });
          };
          sync();
          bat.addEventListener?.('levelchange', sync);
          bat.addEventListener?.('chargingchange', sync);
        })
        .catch(() => {
          if (active) setBatteryInfo({ supported: false });
        });
    }

    return () => {
      active = false;
      torchStreamRef.current?.getTracks().forEach((t) => t.stop());
      torchStreamRef.current = null;
    };
  }, []);

  const triggerVibration = () => {
    if (typeof navigator.vibrate !== 'function') {
      setVibrateStatus('Vibration API is not supported on this browser/device.');
      return;
    }
    const ok = navigator.vibrate([90, 50, 90]);
    setVibrateStatus(
      ok
        ? 'Vibration pulse triggered.'
        : 'Vibration request was blocked or unsupported on this device.',
    );
  };

  const toggleFlashlight = async () => {
    setTorchStatus(null);
    if (torchOn && torchStreamRef.current) {
      torchStreamRef.current.getTracks().forEach((t) => t.stop());
      torchStreamRef.current = null;
      setTorchOn(false);
      setTorchStatus('Flashlight turned off.');
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      setTorchStatus('Camera/Flashlight API is unavailable in this browser.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      const track = stream.getVideoTracks()[0];
      const capabilities =
        typeof track?.getCapabilities === 'function'
          ? (track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean })
          : undefined;

      if (!track || !capabilities?.torch) {
        stream.getTracks().forEach((t) => t.stop());
        setTorchStatus(
          'Flashlight (torch) control is not supported by this browser or camera hardware.',
        );
        return;
      }

      await track.applyConstraints({
        advanced: [{ torch: true } as MediaTrackConstraintSet],
      });
      torchStreamRef.current = stream;
      setTorchOn(true);
      setTorchStatus('Flashlight is ON.');
    } catch {
      setTorchStatus(
        'Camera permission is required for flashlight control, or hardware access was denied.',
      );
    }
  };

  const requestLocation = () => {
    if (!('geolocation' in navigator)) {
      setLocationStatus('Geolocation is not supported on this browser.');
      return;
    }
    setLocationStatus('Requesting location permission…');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          lat: Number(pos.coords.latitude.toFixed(5)),
          lon: Number(pos.coords.longitude.toFixed(5)),
          accuracy: Math.round(pos.coords.accuracy),
        });
        setLocationStatus(null);
      },
      (err) => {
        setLocationStatus(
          err.code === err.PERMISSION_DENIED
            ? 'Location permission denied.'
            : 'Could not read GPS coordinates.',
        );
      },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  return (
    <div className="space-y-3">
      {/* Battery */}
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {batteryInfo.charging ? (
            <BatteryCharging className="h-5 w-5 text-cyan-300" />
          ) : (
            <Battery className="h-5 w-5 text-sky-300" />
          )}
          <div>
            <h3 className="text-sm font-semibold text-slate-100">Battery Status</h3>
            <p className="text-xs text-slate-400">
              {batteryInfo.supported
                ? batteryInfo.charging
                  ? 'Charging'
                  : 'On battery'
                : 'Battery Status API not supported on this browser'}
            </p>
          </div>
        </div>
        <div className="font-mono text-xl font-semibold text-cyan-200 tabular-nums">
          {batteryInfo.supported ? `${batteryInfo.level}%` : 'N/A'}
        </div>
      </div>

      {/* Vibration */}
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-2.5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Vibrate className="h-5 w-5 text-sky-300" />
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Haptic Vibration</h3>
              <p className="text-xs text-slate-400">Test device vibration motor</p>
            </div>
          </div>
          <button
            type="button"
            onClick={triggerVibration}
            className="min-h-[44px] rounded-xl bg-sky-500/20 border border-sky-400/35 px-4 text-xs font-semibold text-cyan-200 hover:bg-sky-500/30"
          >
            Vibrate
          </button>
        </div>
        {vibrateStatus && <p className="text-xs text-slate-300">{vibrateStatus}</p>}
      </div>

      {/* Flashlight */}
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-2.5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Flashlight className={`h-5 w-5 ${torchOn ? 'text-amber-300' : 'text-sky-300'}`} />
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Flashlight (Torch)</h3>
              <p className="text-xs text-slate-400">
                Requires camera permission & supported Android hardware
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={toggleFlashlight}
            className={`min-h-[44px] rounded-xl px-4 text-xs font-semibold transition-colors ${
              torchOn
                ? 'bg-amber-400 text-[#040812]'
                : 'bg-sky-500/20 border border-sky-400/35 text-cyan-200 hover:bg-sky-500/30'
            }`}
          >
            {torchOn ? 'Turn Off' : 'Turn On'}
          </button>
        </div>
        {torchStatus && <p className="text-xs text-slate-300">{torchStatus}</p>}
      </div>

      {/* Location */}
      <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <MapPin className="h-5 w-5 text-sky-300" />
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Location</h3>
              <p className="text-xs text-slate-400">Only accessed after you tap below</p>
            </div>
          </div>
          <button
            type="button"
            onClick={requestLocation}
            className="min-h-[44px] rounded-xl bg-sky-500/20 border border-sky-400/35 px-4 text-xs font-semibold text-cyan-200 hover:bg-sky-500/30"
          >
            Get GPS
          </button>
        </div>
        {coords && (
          <div className="flex items-center justify-between rounded-xl bg-[#050c1a] px-3.5 py-2.5 text-xs font-mono tabular-nums text-cyan-200">
            <span>
              {coords.lat}, {coords.lon} (±{coords.accuracy}m)
            </span>
            <button
              type="button"
              onClick={() => setCoords(null)}
              className="text-slate-400 hover:text-slate-200 font-sans"
            >
              Clear
            </button>
          </div>
        )}
        {locationStatus && <p className="text-xs text-slate-300">{locationStatus}</p>}
      </div>
    </div>
  );
};

/* ---------------- 9. Camera Viewfinder ---------------- */
const CameraPanel: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [active, setActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [error, setError] = useState<string | null>(null);

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setActive(false);
  };

  const startCamera = async (mode: 'environment' | 'user') => {
    setError(null);
    stopCamera();
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Camera access is not supported in this browser.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setActive(true);
    } catch {
      setError('Camera permission denied or no camera available.');
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  return (
    <div className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
      <div className="overflow-hidden rounded-xl bg-[#040914] border border-sky-400/15 aspect-video flex items-center justify-center">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`h-full w-full object-cover ${active ? 'block' : 'hidden'}`}
        />
        {!active && (
          <div className="p-6 text-center text-xs text-slate-400">
            Camera preview is off. Tap Start Camera below to grant permission and open viewfinder.
          </div>
        )}
      </div>

      {error && (
        <p className="rounded-xl border border-rose-400/30 bg-rose-950/35 px-3 py-2 text-xs text-rose-200">
          {error}
        </p>
      )}

      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => (active ? stopCamera() : void startCamera(facingMode))}
          className="flex-1 min-h-[44px] rounded-xl bg-cyan-500 px-4 text-sm font-semibold text-[#040812] hover:bg-cyan-400"
        >
          {active ? 'Stop Camera' : 'Start Camera'}
        </button>
        <button
          type="button"
          onClick={() => {
            const next = facingMode === 'environment' ? 'user' : 'environment';
            setFacingMode(next);
            if (active) void startCamera(next);
          }}
          className="min-h-[44px] rounded-xl border border-sky-400/25 bg-[#0c1a33] px-4 text-xs font-medium text-sky-200"
        >
          Flip ({facingMode === 'environment' ? 'Back' : 'Front'})
        </button>
      </div>
    </div>
  );
};
