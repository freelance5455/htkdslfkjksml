import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  BellRing, 
  Plus, 
  Trash2, 
  Check, 
  AlertTriangle, 
  TrendingUp, 
  Sparkles, 
  Radio, 
  X, 
  Zap,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { 
  priceMonitorService, 
  PriceAlertRule, 
  LiveMarketRates, 
  AlertMetricType 
} from '../lib/priceMonitorService';

interface PriceAlertManagerProps {
  onShowToast?: (msg: string) => void;
}

export const PriceAlertManager: React.FC<PriceAlertManagerProps> = ({ onShowToast }) => {
  const [rates, setRates] = useState<LiveMarketRates>(() => priceMonitorService.getRates());
  const [rules, setRules] = useState<PriceAlertRule[]>(() => priceMonitorService.getRules());
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [pushPermitted, setPushPermitted] = useState<boolean>(
    typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted'
  );

  // New Rule Form Inputs
  const [newMetricType, setNewMetricType] = useState<AlertMetricType>('BTC_USD_PRICE');
  const [newTitle, setNewTitle] = useState<string>('Bitcoin Surge Alert');
  const [newTargetValue, setNewTargetValue] = useState<string>('98000');
  const [newCondition, setNewCondition] = useState<'GREATER_EQUAL' | 'LESS_EQUAL'>('GREATER_EQUAL');

  useEffect(() => {
    const unsub = priceMonitorService.subscribe((r, rls) => {
      setRates(r);
      setRules(rls);
    });
    return () => unsub();
  }, []);

  const handleRequestPushPermission = async () => {
    const granted = await priceMonitorService.requestPushNotificationPermission();
    setPushPermitted(granted);
    if (granted) {
      onShowToast?.('✓ Browser Push Notifications enabled for Price Alerts!');
    } else {
      onShowToast?.('⚠️ Push notifications denied or not supported.');
    }
  };

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(newTargetValue);
    if (isNaN(val) || val <= 0) {
      onShowToast?.('⚠️ Please enter a valid target threshold value.');
      return;
    }

    let unit = '$ USD';
    if (newMetricType === 'DATA_TO_BITCOIN') unit = 'Sats/MB';
    if (newMetricType === 'AIRTIME_TO_CASH') unit = '₦/Unit';

    priceMonitorService.addRule({
      metricType: newMetricType,
      title: newTitle.trim() || 'Custom Price Alert',
      targetValue: val,
      condition: newCondition,
      unit,
      enabled: true
    });

    setShowAddModal(false);
    onShowToast?.(`✓ Added price monitoring alert: ${newTitle}`);
  };

  const handleToggle = (id: string) => {
    priceMonitorService.toggleRule(id);
    onShowToast?.('✓ Updated alert rule status');
  };

  const handleDelete = (id: string) => {
    priceMonitorService.deleteRule(id);
    onShowToast?.('✓ Removed alert rule');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.15 }}
      className="bg-slate-950 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <BellRing className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>REAL-TIME PRICE MONITORING & PUSH NOTIFICATIONS</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center space-x-2">
            <span>Data-to-Bitcoin & Airtime-to-Cash Alert Engine</span>
          </h3>
          <p className="text-xs text-slate-400 max-w-xl">
            Get instant browser push notifications and acoustic chimes when conversion rates cross your designated target thresholds.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!pushPermitted && (
            <button
              onClick={handleRequestPushPermission}
              className="px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span>Enable Push Notifications</span>
            </button>
          )}

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 transition-all hover:scale-105"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>ADD ALERT THRESHOLD</span>
          </button>
        </div>
      </div>

      {/* Live Monitored Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 relative z-10">
        <div className="bg-slate-900/90 border border-amber-500/20 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Bitcoin Benchmark</div>
            <div className="text-xl font-black text-amber-300">${rates.btcUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
            BTC
          </div>
        </div>

        <div className="bg-slate-900/90 border border-amber-500/20 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Data-to-Bitcoin (1 MB)</div>
            <div className="text-xl font-black text-emerald-400">100,000,000 <span className="text-xs">Sats</span></div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
            1.0 BTC
          </div>
        </div>

        <div className="bg-slate-900/90 border border-amber-500/20 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Airtime-to-Cash (₦1.00)</div>
            <div className="text-xl font-black text-amber-100">₦{rates.airtimeToCashNgnPerUnit.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-xs">
            $1 USD
          </div>
        </div>
      </div>

      {/* Rules List */}
      <div className="space-y-2 relative z-10">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
          Configured Alert Rules ({rules.length})
        </span>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {rules.map(rule => (
            <div 
              key={rule.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                rule.enabled 
                  ? 'bg-slate-900/80 border-amber-500/40 shadow-md' 
                  : 'bg-slate-950/60 border-slate-800 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs font-extrabold text-slate-200 line-clamp-1">{rule.title}</div>
                  <div className="text-[11px] font-mono text-amber-300 mt-0.5">
                    Target: {rule.condition === 'GREATER_EQUAL' ? '≥' : '≤'} {rule.targetValue.toLocaleString()} {rule.unit}
                  </div>
                </div>

                <button
                  onClick={() => handleToggle(rule.id)}
                  className={`w-9 h-5 rounded-full p-0.5 transition-all shrink-0 ${
                    rule.enabled ? 'bg-amber-500' : 'bg-slate-800'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-slate-950 transition-all ${
                    rule.enabled ? 'translate-x-4' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[10px] text-slate-400">
                <span>{rule.lastTriggered ? `Last Triggered: ${rule.lastTriggered}` : 'Monitoring Active'}</span>
                <button
                  onClick={() => handleDelete(rule.id)}
                  className="text-rose-400 hover:text-rose-300 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ADD THRESHOLD MODAL */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-lg font-black text-amber-100 flex items-center space-x-2">
                  <BellRing className="w-5 h-5 text-amber-400" />
                  <span>New Price Target Alert</span>
                </h4>
                <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-200">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddRule} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Metric to Monitor:</label>
                  <select
                    value={newMetricType}
                    onChange={(e) => {
                      const m = e.target.value as AlertMetricType;
                      setNewMetricType(m);
                      if (m === 'BTC_USD_PRICE') {
                        setNewTitle('Bitcoin Target Alert');
                        setNewTargetValue('98000');
                      } else if (m === 'DATA_TO_BITCOIN') {
                        setNewTitle('Data-to-Bitcoin Spike');
                        setNewTargetValue('100000000');
                      } else {
                        setNewTitle('Airtime-to-Cash Parity Alert');
                        setNewTargetValue('1560');
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 font-bold focus:border-amber-400 focus:outline-none"
                  >
                    <option value="BTC_USD_PRICE">Bitcoin Benchmark ($ USD)</option>
                    <option value="DATA_TO_BITCOIN">Data-to-Bitcoin Rate (Sats/MB)</option>
                    <option value="AIRTIME_TO_CASH">Airtime-to-Cash Rate (₦/Airtime)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Alert Title / Label:</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 focus:border-amber-400 focus:outline-none"
                    placeholder="e.g. Bitcoin Above $98k"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Condition:</label>
                    <select
                      value={newCondition}
                      onChange={(e) => setNewCondition(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 font-bold focus:border-amber-400 focus:outline-none"
                    >
                      <option value="GREATER_EQUAL">≥ Greater than or equal</option>
                      <option value="LESS_EQUAL">≤ Less than or equal</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Target Threshold:</label>
                    <input
                      type="number"
                      value={newTargetValue}
                      onChange={(e) => setNewTargetValue(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 font-mono focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 transition-all"
                >
                  <Check className="w-4 h-4 text-slate-950" />
                  <span>ACTIVATE PRICE ALERT</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
