import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShoppingCart,
  Trash2,
  Tag,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  BookOpen,
  ArrowLeft
} from 'lucide-react';

export const CartView: React.FC = () => {
  const {
    cart,
    removeFromCart,
    clearCart,
    cartSubtotal,
    cartDiscount,
    cartTotal,
    appliedCoupon,
    couponError,
    applyCoupon,
    removeCoupon,
    setActiveTab,
    setCheckoutOpen,
    setSelectedEbook
  } = useApp();

  const [couponInput, setCouponInput] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponInput.trim()) {
      applyCoupon(couponInput);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShoppingCart className="w-10 h-10" />
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-[#0B192C]">
          Your Shopping Cart is Empty
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-md mx-auto">
          Explore our top exam preparation books for Railway, Assam Police, ADRE, and SSC exams to begin your preparation journey.
        </p>
        <button
          onClick={() => setActiveTab('home')}
          className="mt-6 inline-flex items-center gap-2 bg-[#0B192C] text-amber-400 hover:bg-slate-800 font-bold text-sm px-6 py-3 rounded-xl shadow-md transition-all hover:scale-105"
        >
          <BookOpen className="w-4 h-4" />
          <span>Browse Top Exam Books</span>
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#0B192C] flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-amber-500" />
            Shopping Cart ({cart.length} {cart.length === 1 ? 'Ebook' : 'Ebooks'})
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Instant digital access & offline downloads unlocked upon purchase
          </p>
        </div>

        <button
          onClick={clearCart}
          className="text-xs font-semibold text-red-600 hover:text-red-800 flex items-center gap-1 hover:underline"
        >
          <Trash2 className="w-3.5 h-3.5" /> Clear Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Cart Items List */}
        <div className="lg:col-span-8 space-y-3">
          {cart.map((item) => {
            const ebook = item.ebook;
            return (
              <div
                key={ebook.id}
                className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs hover:border-amber-400 transition-colors"
              >
                {/* Book Thumbnail + Info */}
                <div className="flex items-center gap-3.5 flex-1 min-w-0">
                  <div
                    onClick={() => setSelectedEbook(ebook)}
                    className={`w-14 h-20 rounded-md bg-gradient-to-tr ${ebook.coverGradient} text-white p-1.5 flex flex-col justify-between shrink-0 shadow-sm cursor-pointer hover:scale-105 transition-transform`}
                  >
                    <span className="text-[7px] font-black uppercase text-amber-300 truncate">
                      {ebook.targetExam}
                    </span>
                    <span className="text-[8px] font-extrabold line-clamp-2">
                      {ebook.title}
                    </span>
                    <span className="text-[7px] bg-black/40 px-1 rounded text-center">
                      {ebook.format}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                      {ebook.targetExam}
                    </span>
                    <h3
                      onClick={() => setSelectedEbook(ebook)}
                      className="text-sm font-bold text-slate-900 hover:text-blue-900 cursor-pointer line-clamp-1 mt-1"
                    >
                      {ebook.title}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                      {ebook.publisher} • {ebook.language} • {ebook.pageCount} Pages
                    </p>
                    <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                      Digital Ebook (Quantity: 1)
                    </p>
                  </div>
                </div>

                {/* Pricing & Remove */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                  <div className="text-right">
                    {ebook.isFree ? (
                      <span className="text-base font-extrabold text-emerald-600">FREE</span>
                    ) : (
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-base sm:text-lg font-black text-[#0B192C]">
                          ₹{ebook.price}
                        </span>
                        <span className="text-xs text-slate-400 line-through">
                          ₹{ebook.originalPrice}
                        </span>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => removeFromCart(ebook.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}

          <div className="pt-2">
            <button
              onClick={() => setActiveTab('home')}
              className="text-xs font-bold text-slate-700 hover:text-[#0B192C] flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" /> Continue Shopping for More Books
            </button>
          </div>
        </div>

        {/* Right: Coupon & Pricing Summary */}
        <div className="lg:col-span-4 space-y-4">
          {/* Coupon Box */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-bold text-[#0B192C] uppercase tracking-wider mb-2">
              <Tag className="w-4 h-4 text-amber-500" /> Apply Discount Coupon
            </div>

            {appliedCoupon ? (
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-xs text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{appliedCoupon.code} Applied</span>
                  </div>
                  <p className="text-[11px] text-emerald-700 mt-0.5">
                    {appliedCoupon.description}
                  </p>
                </div>
                <button
                  onClick={removeCoupon}
                  className="text-xs font-bold text-red-600 hover:underline"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    placeholder="Enter Coupon (e.g. NEXA20)"
                    className="flex-1 uppercase bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:border-amber-500"
                  />
                  <button
                    type="submit"
                    className="bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold text-xs px-4 py-2 rounded-xl transition-colors"
                  >
                    Apply
                  </button>
                </div>

                {couponError && (
                  <p className="text-xs text-red-600 font-medium">{couponError}</p>
                )}

                {/* Suggested Coupons chips */}
                <div className="pt-2">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block mb-1.5">
                    Available Student Coupons:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {['NEXA20', 'ASSAM100', 'FIRSTEXAM'].map((code) => (
                      <button
                        key={code}
                        type="button"
                        onClick={() => {
                          setCouponInput(code);
                          applyCoupon(code);
                        }}
                        className="text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200 hover:bg-amber-100 px-2 py-0.5 rounded transition-colors"
                      >
                        {code}
                      </button>
                    ))}
                  </div>
                </div>
              </form>
            )}
          </div>

          {/* Price Breakdown Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider pb-2 border-b border-slate-100">
              Order Price Summary
            </h3>

            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Total Items MRP</span>
                <span className="font-semibold text-slate-800">₹{cartSubtotal}</span>
              </div>

              {cartDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Coupon Discount</span>
                  <span>- ₹{cartDiscount}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Platform Delivery Fee</span>
                <span className="text-emerald-600 font-semibold">FREE (Digital)</span>
              </div>

              <div className="flex justify-between">
                <span>GST (Goods & Services Tax)</span>
                <span className="text-slate-500">Inclusive</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex items-baseline justify-between">
              <div>
                <span className="text-sm font-black text-[#0B192C]">Total Payable</span>
                <p className="text-[10px] text-slate-400">All taxes included</p>
              </div>
              <span className="text-2xl font-black text-[#0B192C]">
                ₹{cartTotal}
              </span>
            </div>

            <button
              onClick={() => setCheckoutOpen(true)}
              className="w-full mt-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 group"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="pt-2 text-center flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Safe & Secure Indian Payment Gateway</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
