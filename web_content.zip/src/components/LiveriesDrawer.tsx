import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Gift,
  Check,
  AlertCircle,
  CheckCircle2,
  Plane as PlaneIcon,
  Layers,
  Lock
} from 'lucide-react';
import {
  AVAILABLE_LIVERIES,
  Livery,
  Plane,
  redeemPromoCode,
  GameState
} from '../game/flightLogic';
import { sound } from '../game/sound';

interface LiveriesDrawerProps {
  planes: Plane[];
  selectedPlaneId: string | null;
  unlockedLiveryIds: string[];
  redeemedCodes: string[];
  onSelectPlane: (planeId: string) => void;
  onEquipLivery: (planeId: string, liveryId: string) => void;
  onEquipLiveryAll: (liveryId: string) => void;
  onRedeemSuccess: (liveryId: string, bonusCash?: number, message?: string) => void;
  onClose: () => void;
}

export const LiveriesDrawer: React.FC<LiveriesDrawerProps> = ({
  planes,
  selectedPlaneId,
  unlockedLiveryIds,
  redeemedCodes,
  onSelectPlane,
  onEquipLivery,
  onEquipLiveryAll,
  onRedeemSuccess,
  onClose
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [redeemStatus, setRedeemStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  // Currently focused plane to equip to
  const activePlane = planes.find(p => p.id === selectedPlaneId) || planes[0];

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = promoInput.trim();
    if (!cleanCode) return;

    // Use validation logic
    const dummyState: GameState = {
      airlineName: '',
      userId: null,
      userEmail: null,
      userAvatar: null,
      cash: 0,
      totalEarned: 0,
      totalFuelCost: 0,
      totalPassengersCarried: 0,
      totalDistanceFlownKm: 0,
      fuelMarketIndex: 1.0,
      unlockedCityIds: [],
      airportLevels: {},
      speedLevel: 1,
      moneyMakerLevel: 1,
      fleetCount: planes.length,
      capacityLevel: 1,
      planes,
      lastSavedTimestamp: 0,
      soundEnabled: true,
      autoPilot: true,
      selectedPlaneId,
      selectedCityId: null,
      unlockedLiveryIds,
      redeemedCodes,
      routeStats: {},
      activeEvent: null
    };

    const result = redeemPromoCode(cleanCode, dummyState);

    if (result.success && result.liveryId) {
      sound.playCelebration();
      setRedeemStatus({
        type: 'success',
        message: result.message
      });
      onRedeemSuccess(result.liveryId, result.bonusCash, result.message);
      // Automatically equip newly unlocked livery to current plane for instant feedback
      if (activePlane) {
        onEquipLivery(activePlane.id, result.liveryId);
      }
      setPromoInput('');
    } else {
      sound.playClick();
      setRedeemStatus({
        type: 'error',
        message: result.message
      });
    }
  };

  return (
    <div
      className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#0a0b10] border-l border-[#27272a] shadow-2xl flex flex-col text-white animate-in slide-in-from-right duration-200"
      data-testid="liveries-drawer"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-[#27272a]">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-red-400" />
            <h2 className="font-mono text-base font-bold tracking-tight">FLIGHT LIVERY HANGAR</h2>
          </div>
          <p className="text-xs text-[#71717a] font-mono mt-0.5">
            Aircraft Skins & Redeem Codes · {unlockedLiveryIds.length}/{AVAILABLE_LIVERIES.length} Unlocked
          </p>
        </div>
        <button
          onClick={onClose}
          aria-label="Close Livery Panel"
          className="p-1.5 text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-lg transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-5">
        {/* Promo Code Redemption Box (NO codes displayed per user instruction) */}
        <div className="p-4 rounded-xl bg-[#12131b] border border-[#27272a] shadow-inner space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift size={16} className="text-red-400" />
              <h3 className="font-mono text-xs font-bold text-white tracking-wide">
                REDEEM LIVERY CODE
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/70 border border-red-800/60 text-red-300 font-semibold">
              EXCLUSIVE REWARDS
            </span>
          </div>

          <p className="text-xs text-[#a1a1aa] leading-relaxed">
            Enter secret promotional codes to unlock rare seasonal liveries and expand your hangar collection.
          </p>

          <form onSubmit={handleRedeem} className="space-y-2.5">
            <div className="flex gap-2">
              <input
                type="text"
                value={promoInput}
                onChange={e => setPromoInput(e.target.value)}
                placeholder="Enter secret code..."
                aria-label="Promo code input"
                className="flex-1 bg-[#181924] border border-[#3f3f46] focus:border-red-400 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-[#71717a] focus:outline-none transition-colors"
              />
              <button
                type="submit"
                aria-label="Submit promo code"
                className="px-4 py-2 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-mono text-xs font-bold rounded-lg transition-all shadow-md cursor-pointer whitespace-nowrap"
              >
                Redeem
              </button>
            </div>
          </form>

          {/* Feedback banner */}
          {redeemStatus.type && (
            <div
              className={`p-3 rounded-lg border text-xs font-mono flex items-start gap-2.5 animate-in fade-in duration-150 ${
                redeemStatus.type === 'success'
                  ? 'bg-emerald-950/60 border-emerald-600/70 text-emerald-200'
                  : 'bg-red-950/60 border-red-800/70 text-red-200'
              }`}
            >
              {redeemStatus.type === 'success' ? (
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
              )}
              <span className="leading-snug">{redeemStatus.message}</span>
            </div>
          )}
        </div>

        {/* Selected Aircraft Target Switcher */}
        {planes.length > 0 && (
          <div className="p-3 bg-[#0e0f16] rounded-xl border border-[#27272a] flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <PlaneIcon size={14} className="text-[#a1a1aa]" />
              <span className="text-[#71717a]">Target Aircraft:</span>
              <span className="text-white font-bold">{activePlane?.name}</span>
            </div>

            {planes.length > 1 && (
              <select
                value={activePlane?.id}
                onChange={e => onSelectPlane(e.target.value)}
                className="bg-[#181924] border border-[#27272a] rounded px-2 py-1 text-xs text-white font-mono focus:border-white focus:outline-none"
              >
                {planes.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            )}
          </div>
        )}

        {/* Livery Catalog - Unlocked skins and mystery locked skins */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-mono text-xs font-bold text-[#a1a1aa] tracking-wider uppercase">
              HANGAR LIVERIES ({AVAILABLE_LIVERIES.length})
            </h3>
          </div>

          <div className="space-y-3">
            {AVAILABLE_LIVERIES.map(livery => {
              const isUnlocked = unlockedLiveryIds.includes(livery.id);
              const isEquippedOnActive = activePlane?.liveryId === livery.id || (!activePlane?.liveryId && livery.id === 'default');

              return (
                <div
                  key={livery.id}
                  className={`p-4 rounded-xl border transition-all ${
                    isEquippedOnActive
                      ? 'bg-[#151624] border-white ring-1 ring-white/50'
                      : isUnlocked
                      ? 'bg-[#101119] border-[#27272a] hover:border-[#3f3f46]'
                      : 'bg-[#0d0e14] border-[#1f2029] opacity-80'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    {/* Livery Plane Preview Thumbnail */}
                    <div
                      className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 border relative overflow-hidden ${
                        isUnlocked && livery.isHoliday
                          ? 'bg-gradient-to-br from-red-950/80 to-[#120606] border-red-700/60'
                          : isUnlocked
                          ? 'bg-[#181924] border-[#27272a]'
                          : 'bg-[#101016] border-[#1e1f29]'
                      }`}
                    >
                      {isUnlocked && livery.image ? (
                        <img
                          src={livery.image}
                          alt={livery.name}
                          className="w-12 h-12 object-contain drop-shadow-md"
                        />
                      ) : isUnlocked ? (
                        <svg width="32" height="32" viewBox="0 0 24 24" className="drop-shadow-md">
                          <path
                            d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"
                            fill={livery.fuselageColor}
                            stroke={livery.accentColor}
                            strokeWidth="1"
                          />
                        </svg>
                      ) : (
                        <Lock size={20} className="text-[#52525b]" />
                      )}
                    </div>

                    {/* Livery Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-mono text-sm font-bold text-white tracking-tight">
                          {isUnlocked ? livery.name : 'Mystery Aircraft Livery'}
                        </h4>
                        <span
                          className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                            isUnlocked && livery.isHoliday
                              ? 'bg-red-950/80 border-red-700 text-red-200'
                              : isUnlocked
                              ? 'bg-[#18181b] border-[#3f3f46] text-[#a1a1aa]'
                              : 'bg-[#14141c] border-[#27272a] text-[#71717a]'
                          }`}
                        >
                          {isUnlocked ? livery.badge : 'LOCKED'}
                        </span>
                      </div>

                      <p className="text-xs text-[#a1a1aa] mt-1 leading-relaxed">
                        {isUnlocked
                          ? livery.description
                          : 'Exclusive special livery locked behind a secret promotional code.'}
                      </p>

                      <div className="mt-2 text-[11px] font-mono text-[#71717a]">
                        {isUnlocked ? (
                          <span className="text-emerald-400 font-semibold flex items-center gap-1">
                            <Check size={11} /> Unlocked in Hangar
                          </span>
                        ) : (
                          <span className="text-amber-400 font-medium">
                            🔒 Redeem secret promo code to unlock
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-3 pt-3 border-t border-[#1f2029] flex items-center justify-between gap-2">
                    {isUnlocked ? (
                      <div className="flex items-center gap-2 w-full">
                        <button
                          onClick={() => {
                            if (activePlane) {
                              onEquipLivery(activePlane.id, livery.id);
                              sound.playClick();
                            }
                          }}
                          disabled={isEquippedOnActive}
                          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-mono font-semibold transition-all cursor-pointer ${
                            isEquippedOnActive
                              ? 'bg-white/10 text-white border border-white/30 cursor-default'
                              : 'bg-white text-black hover:bg-[#e4e4e7]'
                          }`}
                        >
                          {isEquippedOnActive ? '✓ Equipped on ' + activePlane?.name : 'Equip to ' + activePlane?.name}
                        </button>

                        {planes.length > 1 && (
                          <button
                            onClick={() => {
                              onEquipLiveryAll(livery.id);
                              sound.playUpgrade();
                            }}
                            title="Equip this livery to every plane in your fleet"
                            className="py-1.5 px-3 rounded-lg text-xs font-mono text-[#a1a1aa] hover:text-white bg-[#181924] hover:bg-[#222433] border border-[#27272a] transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Layers size={12} />
                            <span>All Fleet</span>
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-between w-full">
                        <span className="text-xs font-mono text-[#71717a]">Secret Livery</span>
                        <span className="text-[11px] font-mono text-[#52525b]">Redeem code above</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
