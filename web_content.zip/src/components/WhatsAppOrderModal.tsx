import React, { useState } from 'react';
import { X, Send, MessageCircle, ShoppingBag, Truck, CheckCircle2, Copy, Check, ExternalLink } from 'lucide-react';
import { Product, CartItem, DeliveryAddress } from '../types/ecommerce';
import { WHATSAPP_SUPPORT_NUMBER, WHATSAPP_DISPLAY_NUMBER, DEFAULT_ADDRESSES } from '../data/mockData';

interface WhatsAppOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  product?: Product | null;
  selectedColor?: string;
  selectedSize?: string;
  quantity?: number;
  cartItems?: CartItem[];
  defaultAddress?: DeliveryAddress;
}

export const WhatsAppOrderModal: React.FC<WhatsAppOrderModalProps> = ({
  isOpen,
  onClose,
  product,
  selectedColor,
  selectedSize,
  quantity = 1,
  cartItems,
  defaultAddress = DEFAULT_ADDRESSES[0]
}) => {
  const [copied, setCopied] = useState(false);
  const [customerName, setCustomerName] = useState(defaultAddress.name || 'Kasun Perera');
  const [customerPhone, setCustomerPhone] = useState(defaultAddress.phone || '+94 77 123 4567');
  const [customerAddress, setCustomerAddress] = useState(`${defaultAddress.addressLine}, ${defaultAddress.city}`);
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery (COD)');
  const [activeTab, setActiveTab] = useState<'order' | 'support'>('order');
  const [supportQuery, setSupportQuery] = useState('Hello SEWORA MART! I would like to inquire about item delivery times to Colombo.');

  if (!isOpen) return null;

  // Build the WhatsApp formatted message
  let messageText = '';

  if (activeTab === 'order') {
    if (product) {
      const itemTotal = product.price * quantity;
      messageText = `*SEWORA MART - Direct WhatsApp Order Request*\n\n` +
        `🛍️ *Product:* ${product.title}\n` +
        `🎨 *Variant:* ${selectedColor || 'Default'} | Size: ${selectedSize || 'Standard'}\n` +
        `🔢 *Quantity:* ${quantity}\n` +
        `💵 *Price:* Rs. ${itemTotal.toLocaleString()} (Unit: Rs. ${product.price.toLocaleString()})\n\n` +
        `📍 *Customer Details:*\n` +
        `• Name: ${customerName}\n` +
        `• Phone: ${customerPhone}\n` +
        `• Delivery Address: ${customerAddress}\n` +
        `• Payment: ${paymentMethod}\n\n` +
        `Please confirm availability and dispatch schedule. Thank you!`;
    } else if (cartItems && cartItems.length > 0) {
      const selected = cartItems.filter(i => i.selected);
      const itemsList = (selected.length > 0 ? selected : cartItems)
        .map(i => `• ${i.quantity}x ${i.product.title} (${i.selectedColor || ''} ${i.selectedSize || ''}) - Rs. ${(i.product.price * i.quantity).toLocaleString()}`)
        .join('\n');
      const total = (selected.length > 0 ? selected : cartItems).reduce((sum, it) => sum + (it.product.price * it.quantity), 0);

      messageText = `*SEWORA MART - Cart WhatsApp Order Request*\n\n` +
        `🛒 *Order Items:*\n${itemsList}\n\n` +
        `💰 *Estimated Total:* Rs. ${total.toLocaleString()} (+ Delivery)\n\n` +
        `📍 *Customer Details:*\n` +
        `• Name: ${customerName}\n` +
        `• Phone: ${customerPhone}\n` +
        `• Address: ${customerAddress}\n` +
        `• Payment: ${paymentMethod}\n\n` +
        `Please verify stock and confirm order!`;
    } else {
      messageText = `*Hello SEWORA MART Support!*\n\nI want to place an order via WhatsApp. Please share your latest catalog and daily deals.`;
    }
  } else {
    messageText = `*SEWORA MART Customer Support Inquiry*\n\n` +
      `Hello team, I need assistance with:\n` +
      `"${supportQuery}"\n\n` +
      `Customer: ${customerName} (${customerPhone})`;
  }

  const encodedUrl = `https://wa.me/${WHATSAPP_SUPPORT_NUMBER.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(messageText)}`;

  const handleOpenWhatsApp = () => {
    window.open(encodedUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-[#25D366] text-white p-4 rounded-t-3xl flex items-center justify-between sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white text-[#25D366] flex items-center justify-center shadow-xs">
              <MessageCircle className="w-6 h-6 fill-[#25D366]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-sm text-white">SEWORA MART WhatsApp Support</h3>
                <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
              </div>
              <p className="text-[11px] text-emerald-100 font-mono">{WHATSAPP_DISPLAY_NUMBER} · Online 24/7</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-black/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Mode Switcher */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl text-xs font-bold text-slate-700">
            <button
              onClick={() => setActiveTab('order')}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'order' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Instant WhatsApp Order</span>
            </button>
            <button
              onClick={() => setActiveTab('support')}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'support' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Customer Help & FAQs</span>
            </button>
          </div>

          {activeTab === 'order' ? (
            <>
              {/* Order Item Preview */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-center justify-between text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Selected Item(s)</div>
                  <div className="font-bold text-slate-900 line-clamp-1">
                    {product ? product.title : `${cartItems?.length || 1} Cart Items`}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {product ? `Qty: ${quantity} · ${selectedColor || ''} ${selectedSize || ''}` : 'Ready for verification'}
                  </div>
                </div>
                <span className="text-sm font-extrabold text-[#FF6600] tabular-nums">
                  Rs. {product ? (product.price * quantity).toLocaleString() : 'Calculated'}
                </span>
              </div>

              {/* Delivery Details */}
              <div className="space-y-2 text-xs">
                <div className="font-bold text-slate-800">Your Delivery Details</div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Your Name</label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">Contact Phone</label>
                    <input
                      type="text"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Street Address & City</label>
                  <input
                    type="text"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800"
                  >
                    <option value="Cash on Delivery (COD)">Cash on Delivery (Doorstep payment)</option>
                    <option value="Bank Transfer / Deposit">Bank Transfer / Online Deposit</option>
                    <option value="Mobile Wallet (eZ Cash / FriMi)">Mobile Wallet (eZ Cash / FriMi)</option>
                  </select>
                </div>
              </div>
            </>
          ) : (
            /* Quick Support Question Chips */
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-800">Choose a common inquiry:</div>
              <div className="space-y-1.5">
                {[
                  'Can I get islandwide cash on delivery for fresh groceries?',
                  'I want to track my order package. Please update status.',
                  'Are all electronics and gadgets covered by local seller warranty?',
                  'How do I claim bulk discount on Basmati Rice and Tea?'
                ].map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSupportQuery(q)}
                    className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all ${
                      supportQuery === q
                        ? 'border-[#25D366] bg-emerald-50 text-slate-900 font-semibold'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    💬 {q}
                  </button>
                ))}
              </div>

              <div>
                <label className="text-[10px] text-slate-500 block mb-1">Custom Message</label>
                <textarea
                  rows={2}
                  value={supportQuery}
                  onChange={(e) => setSupportQuery(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800"
                />
              </div>
            </div>
          )}

          {/* WhatsApp Message Preview Bubble */}
          <div>
            <div className="flex items-center justify-between mb-1.5 text-[11px] font-bold text-slate-600">
              <span>WhatsApp Message Preview:</span>
              <button
                onClick={handleCopy}
                className="text-[#25D366] font-semibold flex items-center gap-1 hover:underline"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            </div>
            <div className="bg-[#E7FFDB] text-slate-900 border border-emerald-200/80 p-3 rounded-2xl rounded-tr-none text-xs font-sans whitespace-pre-wrap leading-relaxed shadow-2xs font-mono text-[11px]">
              {messageText}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="space-y-2 pt-1">
            <button
              onClick={handleOpenWhatsApp}
              className="w-full bg-[#25D366] hover:bg-emerald-600 active:scale-98 text-white font-extrabold text-sm py-3.5 rounded-2xl shadow-lg hover:shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>Send & Order via WhatsApp</span>
              <ExternalLink className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="w-full text-slate-500 text-xs font-semibold py-2 hover:text-slate-800 transition-colors"
            >
              Continue Browsing Sewora Mart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
