import React from 'react';
import { X } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              HOW TO PLAY
            </h2>
            <p className="text-xs text-slate-400">
              Rules of engagement and special puzzle mechanics
            </p>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 text-slate-300 text-xs sm:text-sm">
          {/* Rule 1 */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-xs flex items-center justify-center font-mono">1</span>
              Connect Same-Color Pairs
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Touch or click any glowing colored endpoint, then drag your path to its matching partner. When both ends connect, the circuit completes with a harmonic chime!
            </p>
          </div>

          {/* Rule 2 */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 text-xs flex items-center justify-center font-mono">2</span>
              Horizontal & Vertical Only (No Crossing)
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Connections move along adjacent orthogonal grid cells. Diagonal steps are not permitted. Different color paths cannot overlap or cut through one another.
            </p>
          </div>

          {/* Rule 3 */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <h3 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 text-xs flex items-center justify-center font-mono">3</span>
              Combos & Remaining Moves
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Connecting paths in rapid succession builds your Combo Multiplier for huge score surges! Completing a level with leftover moves grants star bonuses and gold coins.
            </p>
          </div>

          {/* Special Mechanics */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
            <h3 className="font-bold text-white text-sm mb-2.5">
              Special Grid Tiles (Worlds 3–5)
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-start gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-base">💣</span>
                <div>
                  <div className="font-bold text-white">Bomb</div>
                  <div className="text-[10px] text-slate-400">Detonates when neighboring lines close, giving bonus points!</div>
                </div>
              </div>

              <div className="flex items-start gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-amber-400 font-mono font-bold text-sm">2X</span>
                <div>
                  <div className="font-bold text-white">Multiplier</div>
                  <div className="text-[10px] text-slate-400">Route your path through this tile to double connection points.</div>
                </div>
              </div>

              <div className="flex items-start gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-purple-400 text-base">🌀</span>
                <div>
                  <div className="font-bold text-white">Portal</div>
                  <div className="text-[10px] text-slate-400">Step in to warp across the board to the linked portal!</div>
                </div>
              </div>

              <div className="flex items-start gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-cyan-300 text-base">❄️</span>
                <div>
                  <div className="font-bold text-white">Ice Tile</div>
                  <div className="text-[10px] text-slate-400">Encased frozen cell that thaws when adjacent lines connect.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
