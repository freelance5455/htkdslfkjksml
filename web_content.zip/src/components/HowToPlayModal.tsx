import React from 'react';
import { X, CheckCircle, AlertTriangle } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="absolute inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl text-left space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center space-x-2">
            <span>📖</span>
            <span>How to Play & Survive</span>
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3.5 text-xs sm:text-sm text-slate-300">
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60 flex items-start space-x-3">
            <span className="text-2xl shrink-0">💎</span>
            <div>
              <strong className="text-cyan-300 block text-sm">1. Collect 3 Crystals to Unlock Portal</strong>
              The central portal is locked! You must explore the other three maze corners to collect all <strong>3 Crystals</strong> (Sapphire, Emerald, Ruby). Once collected, the central portal unlocks and you can step inside to escape and win!
            </div>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60 flex items-start space-x-3">
            <span className="text-2xl shrink-0">🐔</span>
            <div>
              <strong className="text-amber-300 block text-sm">2. Grounded Chickens & Relentless Chase</strong>
              Chickens stay strictly on the ground—they cannot fly, jump over walls, or pass through walls. Once a chicken sees you, it keeps chasing through corridors until you hide in a bush or get caught!
            </div>
          </div>

          <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/40 flex items-start space-x-3">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-emerald-300 block text-sm">3. The Guaranteed Safe Route</strong>
              Every procedural maze has <strong>exactly one continuous route</strong> to the portal that is 100% free of chickens! Explore carefully to discover it.
            </div>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60 flex items-start space-x-3">
            <span className="text-2xl shrink-0">🌿</span>
            <div>
              <strong className="text-yellow-300 block text-sm">4. Real vs. Fake Hiding Bushes</strong>
              Bushes are placed randomly every run and look identical!
              <ul className="mt-1 list-disc list-inside space-y-0.5 text-slate-300">
                <li><strong>Real Bushes:</strong> Turn you semi-transparent and completely immune to chickens. Chasing chickens stop and lose your trail.</li>
                <li><strong>Fake Bushes:</strong> Look identical but provide NO protection! You remain visible and can be chased and caught normally.</li>
              </ul>
            </div>
          </div>

          <div className="bg-amber-950/40 p-3 rounded-xl border border-amber-800/40 flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-amber-300 block text-sm">5. Ladders Across the Maze</strong>
              Ladders are placed randomly throughout valid maze locations across the maze (marked with 🪜). Stand next to one to deploy it. It takes <strong>5 seconds</strong> to secure, during which chickens continue moving!
            </div>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
            <strong className="text-white block text-sm mb-1">🎮 Controls</strong>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong>Desktop:</strong> WASD or Arrow Keys to move, or click any reachable corridor to pathfind.</li>
              <li><strong>Mobile/Touch:</strong> Tap a reachable destination to move.</li>
              <li><strong>Action Buttons:</strong> Use on-screen buttons for Ladder climbing and Hiding exit.</li>
            </ul>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm tracking-wide transition"
        >
          GOT IT, LET'S PLAY!
        </button>
      </div>
    </div>
  );
};
