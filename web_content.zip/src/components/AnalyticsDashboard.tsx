import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { TrendingUp, BarChart3, Clock, Flame, ShieldCheck, RefreshCw, Radio } from 'lucide-react';

interface StreamingDataPoint {
  hour: string;
  streams: number;
  worshipIntensity: number;
}

interface TrackPopularity {
  title: string;
  streams: number;
  revenueNgn: number;
}

export const AnalyticsDashboard: React.FC = () => {
  const chartRef = useRef<HTMLDivElement>(null);
  const popularityChartRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [liveKvStatus, setLiveKvStatus] = useState<string>("Connected to JUHNKRIX_FINANCIAL_LEDGER");

  const hourlyData: StreamingDataPoint[] = [
    { hour: '00:00', streams: 120, worshipIntensity: 40 },
    { hour: '03:00', streams: 85, worshipIntensity: 25 },
    { hour: '06:00', streams: 450, worshipIntensity: 85 },
    { hour: '09:00', streams: 890, worshipIntensity: 95 },
    { hour: '12:00', streams: 1240, worshipIntensity: 100 },
    { hour: '15:00', streams: 980, worshipIntensity: 88 },
    { hour: '18:00', streams: 1450, worshipIntensity: 96 },
    { hour: '21:00', streams: 1100, worshipIntensity: 90 },
  ];

  const trackPopularityData: TrackPopularity[] = [
    { title: 'Prophetic Impartation Anthem', streams: 4820, revenueNgn: 12050 },
    { title: 'Heavenly Atmosphere (Selah)', streams: 3910, revenueNgn: 9775 },
    { title: 'Midnight Intercession Soaking', streams: 3450, revenueNgn: 8625 },
    { title: 'Divine Healing Stream 777', streams: 2900, revenueNgn: 7250 },
    { title: 'Glory Cloud Descending', streams: 2450, revenueNgn: 6125 },
  ];

  useEffect(() => {
    renderPeakWorshipChart();
    renderTrackPopularityChart();

    const handleResize = () => {
      renderPeakWorshipChart();
      renderTrackPopularityChart();
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const renderPeakWorshipChart = () => {
    if (!chartRef.current) return;
    d3.select(chartRef.current).selectAll("*").remove();

    const margin = { top: 20, right: 20, bottom: 30, left: 45 };
    const width = chartRef.current.clientWidth - margin.left - margin.right;
    const height = 240 - margin.top - margin.bottom;

    const svg = d3
      .select(chartRef.current)
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    const x = d3.scalePoint()
      .domain(hourlyData.map(d => d.hour))
      .range([0, width])
      .padding(0.5);

    const y = d3.scaleLinear()
      .domain([0, d3.max(hourlyData, d => d.streams) || 1500])
      .range([height, 0]);

    // Area generator
    const area = d3.area<StreamingDataPoint>()
      .x(d => x(d.hour) || 0)
      .y0(height)
      .y1(d => y(d.streams))
      .curve(d3.curveMonotoneX);

    // Gradient
    const gradient = svg.append("defs")
      .append("linearGradient")
      .attr("id", "worship-gradient")
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "0%")
      .attr("y2", "100%");

    gradient.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#fbbf24")
      .attr("stop-opacity", 0.6);

    gradient.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#fbbf24")
      .attr("stop-opacity", 0.0);

    svg.append("path")
      .datum(hourlyData)
      .attr("fill", "url(#worship-gradient)")
      .attr("d", area);

    // Line generator
    const valueline = d3.line<StreamingDataPoint>()
      .x(d => x(d.hour) || 0)
      .y(d => y(d.streams))
      .curve(d3.curveMonotoneX);

    svg.append("path")
      .datum(hourlyData)
      .attr("fill", "none")
      .attr("stroke", "#f59e0b")
      .attr("stroke-width", 3)
      .attr("d", valueline);

    // X axis
    svg.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll("text")
      .attr("fill", "#94a3b8")
      .attr("font-size", "10px");

    // Y axis
    svg.append("g")
      .call(d3.axisLeft(y).ticks(4))
      .selectAll("text")
      .attr("fill", "#94a3b8")
      .attr("font-size", "10px");
  };

  const renderTrackPopularityChart = () => {
    if (!popularityChartRef.current) return;
    d3.select(popularityChartRef.current).selectAll("*").remove();

    const margin = { top: 10, right: 20, bottom: 40, left: 120 };
    const width = popularityChartRef.current.clientWidth - margin.left - margin.right;
    const height = 240 - margin.top - margin.bottom;

    const svg = d3
      .select(popularityChartRef.current)
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    const y = d3.scaleBand()
      .range([0, height])
      .domain(trackPopularityData.map(d => d.title))
      .padding(0.3);

    const x = d3.scaleLinear()
      .range([0, width])
      .domain([0, d3.max(trackPopularityData, d => d.streams) || 5000]);

    svg.selectAll(".bar")
      .data(trackPopularityData)
      .enter()
      .append("rect")
      .attr("y", d => y(d.title) || 0)
      .attr("height", y.bandwidth())
      .attr("x", 0)
      .attr("width", d => x(d.streams))
      .attr("fill", "url(#bar-gradient)")
      .attr("rx", 6);

    // Gradient for bars
    const barGrad = svg.append("defs")
      .append("linearGradient")
      .attr("id", "bar-gradient")
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "100%")
      .attr("y2", "0%");

    barGrad.append("stop").attr("offset", "0%").attr("stop-color", "#d97706");
    barGrad.append("stop").attr("offset", "100%").attr("stop-color", "#fbbf24");

    // Axes
    svg.append("g")
      .call(d3.axisLeft(y))
      .selectAll("text")
      .attr("fill", "#e2e8f0")
      .attr("font-size", "10px")
      .attr("font-weight", "bold");

    svg.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(4))
      .selectAll("text")
      .attr("fill", "#94a3b8")
      .attr("font-size", "10px");
  };

  const handleRefreshKv = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setLiveKvStatus("KV Sync Live: Fetched fresh stream telemetry from Cloudflare edge");
      renderPeakWorshipChart();
      renderTrackPopularityChart();
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-amber-950/80 p-5 rounded-3xl border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-amber-100 flex items-center gap-2">
              Cloudflare KV Analytics Dashboard <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              {liveKvStatus}
            </p>
          </div>
        </div>

        <button
          onClick={handleRefreshKv}
          disabled={loading}
          className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center space-x-2 transition-all shadow-lg shadow-amber-500/20 active:scale-95 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Sync KV Ledger</span>
        </button>
      </div>

      {/* D3 Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Peak Worship Times Chart */}
        <div className="bg-slate-900/90 p-5 rounded-3xl border border-amber-500/20 shadow-xl backdrop-blur-xl">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-extrabold text-amber-200 flex items-center space-x-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Peak Worship Times (24h Stream Activity)</span>
            </h4>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono border border-amber-500/30">
              D3.js Area Graph
            </span>
          </div>
          <div ref={chartRef} className="w-full h-[245px]"></div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between font-mono">
            <span>Peak Hour: 12:00 PM (1,240 streams)</span>
            <span className="text-emerald-400 font-bold">● High Anointing Flow</span>
          </div>
        </div>

        {/* Track Popularity Chart */}
        <div className="bg-slate-900/90 p-5 rounded-3xl border border-amber-500/20 shadow-xl backdrop-blur-xl">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-extrabold text-amber-200 flex items-center space-x-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Top Anointed Tracks (Stream Count & Revenue)</span>
            </h4>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono border border-amber-500/30">
              D3.js Bar Graph
            </span>
          </div>
          <div ref={popularityChartRef} className="w-full h-[245px]"></div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between font-mono">
            <span>#1 Anthem: Prophetic Impartation (4,820 Streams)</span>
            <span className="text-amber-400 font-bold">₦12,050 Payout</span>
          </div>
        </div>
      </div>
    </div>
  );
};
