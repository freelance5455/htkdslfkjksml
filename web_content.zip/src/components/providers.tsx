import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";

export function AppProviders({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 60_000,
            gcTime: 10 * 60_000,
            retry: 1,
            refetchOnWindowFocus: false,
            refetchOnReconnect: false,
            throwOnError: false,
          },
          mutations: {
            throwOnError: false,
            retry: 0,
          },
        },
      }),
  );

  useEffect(() => {
    const onError = (event: ErrorEvent) => {
      event.preventDefault();
    };
    const onReject = (event: PromiseRejectionEvent) => {
      event.preventDefault();
    };
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onReject);
    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onReject);
    };
  }, []);

  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}
