"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { CheckCircle2, Info, X, XCircle } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { api, ApiError } from "@/lib/api-client";
import { LOCALE_COOKIE, LOCALE_META, type Locale } from "@/lib/constants";
import { dictionaries } from "@/lib/i18n/dictionaries";
import type { CategoryDTO, CurrentUser, SiteData, SiteSettings } from "@/lib/types";
import { cn, errorKey, loc, telLink, waLink } from "@/lib/utils";

/* ---------------------------- i18n ---------------------------- */

type Vars = Record<string, string | number>;

interface I18nValue {
  locale: Locale;
  dir: "ltr" | "rtl";
  t: (key: string, vars?: Vars) => string;
  /** Translates an API error code (or ApiError) into a user-facing message. */
  te: (err: unknown) => string;
  setLocale: (locale: Locale) => void;
}

const I18nContext = createContext<I18nValue | null>(null);

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside <Providers>");
  return ctx;
}

function translate(locale: Locale, key: string, vars?: Vars): string {
  let text = dictionaries[locale][key] ?? dictionaries.en[key] ?? key;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) text = text.split(`{${k}}`).join(String(v));
  }
  return text;
}

function I18nProvider({ initialLocale, children }: { initialLocale: Locale; children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = LOCALE_META[locale].dir;
  }, [locale]);

  const setLocale = useCallback((next: Locale) => {
    document.cookie = `${LOCALE_COOKIE}=${next}; path=/; max-age=31536000; samesite=lax`;
    setLocaleState(next);
  }, []);

  const value = useMemo<I18nValue>(
    () => ({
      locale,
      dir: LOCALE_META[locale].dir,
      t: (key, vars) => translate(locale, key, vars),
      te: (err) => {
        const code = err instanceof ApiError ? err.code : typeof err === "string" ? err : null;
        const key = errorKey(code);
        const msg = translate(locale, key);
        return msg === key ? translate(locale, "err.generic") : msg;
      },
      setLocale,
    }),
    [locale, setLocale],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

/* ---------------------------- Website content ---------------------------- */

interface SiteValue {
  settings: SiteSettings;
  categories: CategoryDTO[];
  categoryName: (slug: string) => string;
  /** Opens WhatsApp with the ShifaCare number, optionally with a pre-filled message. */
  whatsapp: (text?: string) => string;
  /** tel: link for the call button. */
  callLink: string;
  /** Default text used by the floating WhatsApp button, in the active language. */
  defaultMessage: string;
  refreshSite: () => Promise<void>;
}

const SiteContext = createContext<SiteValue | null>(null);

export function useSite(): SiteValue {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error("useSite must be used inside <Providers>");
  return ctx;
}

function SiteProvider({ initial, children }: { initial: SiteData; children: ReactNode }) {
  const { locale } = useI18n();
  const [data, setData] = useState<SiteData>(initial);

  const refreshSite = useCallback(async () => {
    const next = await api<SiteData>("/api/site");
    setData(next);
  }, []);

  const value = useMemo<SiteValue>(() => {
    const number = data.settings.contact.whatsappNumber;
    return {
      settings: data.settings,
      categories: data.categories,
      categoryName: (slug: string) => {
        const c = data.categories.find((x) => x.slug === slug);
        return c ? loc(c.name, locale) : slug;
      },
      whatsapp: (text?: string) => waLink(text, number),
      callLink: telLink(data.settings.contact.phoneIntl),
      defaultMessage: loc(data.settings.defaultWhatsappMessage, locale),
      refreshSite,
    };
  }, [data, locale, refreshSite]);

  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}

/* ---------------------------- Toasts ---------------------------- */

type ToastTone = "success" | "error" | "info";
interface ToastItem {
  id: number;
  tone: ToastTone;
  message: string;
}
interface ToastValue {
  success: (message: string) => void;
  error: (message: string) => void;
  info: (message: string) => void;
}

const ToastContext = createContext<ToastValue | null>(null);

export function useToast(): ToastValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <Providers>");
  return ctx;
}

const TOAST_TONE: Record<ToastTone, { icon: typeof Info; cls: string }> = {
  success: { icon: CheckCircle2, cls: "bg-emerald-50 text-emerald-800 ring-emerald-200" },
  error: { icon: XCircle, cls: "bg-rose-50 text-rose-800 ring-rose-200" },
  info: { icon: Info, cls: "bg-sky-50 text-sky-800 ring-sky-200" },
};

function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const dismiss = useCallback((id: number) => setItems((prev) => prev.filter((i) => i.id !== id)), []);

  const push = useCallback(
    (tone: ToastTone, message: string) => {
      const id = Date.now() + Math.random();
      setItems((prev) => [...prev.slice(-3), { id, tone, message }]);
      window.setTimeout(() => dismiss(id), 4500);
    },
    [dismiss],
  );

  const value = useMemo<ToastValue>(
    () => ({
      success: (m) => push("success", m),
      error: (m) => push("error", m),
      info: (m) => push("info", m),
    }),
    [push],
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed inset-x-0 top-4 z-[100] flex flex-col items-center gap-2 px-4">
        {items.map((item) => {
          const { icon: Icon, cls } = TOAST_TONE[item.tone];
          return (
            <div
              key={item.id}
              role="status"
              className={cn(
                "animate-toast-in pointer-events-auto flex w-full max-w-md items-start gap-3 rounded-2xl px-4 py-3 text-sm font-medium shadow-xl ring-1",
                cls,
              )}
            >
              <Icon className="mt-0.5 h-5 w-5 shrink-0" />
              <p className="flex-1 leading-snug">{item.message}</p>
              <button type="button" onClick={() => dismiss(item.id)} aria-label="Close" className="opacity-60 hover:opacity-100">
                <X className="h-4 w-4" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

/* ---------------------------- Auth ---------------------------- */

export interface ProfessionalSummary {
  id: string;
  verificationStatus: string;
  profession: string;
}

interface AuthValue {
  user: CurrentUser | null;
  professional: ProfessionalSummary | null;
  loading: boolean;
  refresh: () => Promise<void>;
  setSession: (user: CurrentUser | null, professional: ProfessionalSummary | null) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthValue | null>(null);

export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <Providers>");
  return ctx;
}

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [professional, setProfessional] = useState<ProfessionalSummary | null>(null);
  const [loading, setLoading] = useState(true);

  const setSession = useCallback((u: CurrentUser | null, p: ProfessionalSummary | null) => {
    setUser(u);
    setProfessional(p);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const res = await api<{ user: CurrentUser | null; professional: ProfessionalSummary | null }>("/api/auth/me");
      setUser(res.user);
      setProfessional(res.professional);
    } catch {
      setUser(null);
      setProfessional(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const logout = useCallback(async () => {
    await api("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
    setProfessional(null);
    window.location.assign("/");
  }, []);

  const value = useMemo<AuthValue>(
    () => ({ user, professional, loading, refresh, setSession, logout }),
    [user, professional, loading, refresh, setSession, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/* ---------------------------- Root ---------------------------- */

export function Providers({
  initialLocale,
  initialSite,
  children,
}: {
  initialLocale: Locale;
  initialSite: SiteData;
  children: ReactNode;
}) {
  return (
    <I18nProvider initialLocale={initialLocale}>
      <SiteProvider initial={initialSite}>
        <ToastProvider>
          <AuthProvider>
            <AppShell>{children}</AppShell>
          </AuthProvider>
        </ToastProvider>
      </SiteProvider>
    </I18nProvider>
  );
}
