import React from 'react';

interface AudioWaveformProps {
  volume: number; // 0 to 1
  isActive: boolean;
  colorScheme?: 'emerald' | 'rose' | 'indigo';
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  volume,
  isActive,
  colorScheme = 'emerald',
}) => {
  // 16 bars with mirrored or organic height
  const barHeights = [
    0.25, 0.45, 0.7, 0.9, 0.6, 0.85, 1.0, 0.75, 0.8, 1.0, 0.85, 0.65, 0.9, 0.7, 0.45, 0.25,
  ];

  const getColorClass = () => {
    switch (colorScheme) {
      case 'rose':
        return 'bg-gradient-to-t from-rose-500 to-pink-400';
      case 'indigo':
        return 'bg-gradient-to-t from-indigo-500 to-purple-400';
      case 'emerald':
      default:
        return 'bg-gradient-to-t from-emerald-500 to-teal-400';
    }
  };

  return (
    <div className="flex items-center justify-center gap-1 h-8 px-4 py-1 rounded-full bg-slate-50 border border-slate-200/80 shadow-2xs">
      {barHeights.map((factor, idx) => {
        const height = isActive
          ? Math.max(4, Math.min(26, 4 + volume * 24 * factor + (idx % 3) * 2))
          : 4;

        return (
          <span
            key={idx}
            className={`w-1 rounded-full transition-all duration-75 ${
              isActive ? getColorClass() : 'bg-slate-300'
            }`}
            style={{
              height: `${height}px`,
              opacity: isActive ? 0.9 : 0.4,
            }}
          />
        );
      })}
    </div>
  );
};
