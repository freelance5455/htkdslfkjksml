/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { VoiceModeState } from '../types/assistant';
import { voiceService } from '../services/voiceService';

interface AudioWaveformProps {
  voiceState: VoiceModeState;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({ voiceState }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    const numBars = 48;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const audioLevel = voiceService.getLiveAudioLevel();
      const isActive = voiceState === 'LISTENING' || voiceState === 'SPEAKING';
      const time = Date.now() * 0.005;

      const barWidth = 3;
      const spacing = 5;
      const totalWidth = numBars * spacing;
      const startX = (width - totalWidth) / 2;
      const centerY = height / 2;

      // Glow effect
      ctx.shadowBlur = isActive ? 12 : 6;
      ctx.shadowColor = '#06b6d4';

      for (let i = 0; i < numBars; i++) {
        // Distance from center factor (bell curve taper)
        const distFromCenter = Math.abs(i - numBars / 2) / (numBars / 2);
        const taper = Math.max(0, 1 - Math.pow(distFromCenter, 1.4));

        let barHeight = 2;
        if (isActive) {
          // Dynamic frequency simulation with audioLevel modulation
          const wave1 = Math.sin(time * 3 + i * 0.35);
          const wave2 = Math.cos(time * 2 - i * 0.2);
          const dynamicFactor = (wave1 * 0.5 + wave2 * 0.5 + 1) * audioLevel;
          barHeight = 3 + taper * 32 * dynamicFactor;
        } else {
          // Subtle breathing resting state
          const wave = Math.sin(time + i * 0.2);
          barHeight = 2 + taper * 6 * (wave * 0.5 + 0.5);
        }

        const x = startX + i * spacing;
        const topY = centerY - barHeight / 2;

        // Gradient from cyan to bright blue
        const gradient = ctx.createLinearGradient(0, topY, 0, topY + barHeight);
        gradient.addColorStop(0, '#38bdf8');
        gradient.addColorStop(0.5, '#67e8f9');
        gradient.addColorStop(1, '#0284c7');

        ctx.fillStyle = gradient;
        ctx.fillRect(x, topY, barWidth, Math.max(2, barHeight));
      }

      // Thin horizontal center guideline
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.25)';
      ctx.lineWidth = 1;
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.moveTo(startX - 20, centerY);
      ctx.lineTo(startX + totalWidth + 20, centerY);
      ctx.stroke();

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [voiceState]);

  return (
    <div className="w-full flex justify-center items-center my-1 pointer-events-none">
      <canvas
        ref={canvasRef}
        width={360}
        height={50}
        className="w-72 sm:w-80 h-10 max-w-full"
      />
    </div>
  );
};
