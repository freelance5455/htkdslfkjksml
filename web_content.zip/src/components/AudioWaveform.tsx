import React from 'react';
import { AssistantState } from '../types/jarvis';

interface AudioWaveformProps {
  state: AssistantState;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({ state }) => {
  const isAudioActive = state === 'listening' || state === 'speaking';
  const barCount = 19;

  return (
    <div className="flex items-center justify-center gap-1 h-10 px-4 py-1">
      {Array.from({ length: barCount }).map((_, i) => {
        // Compute rhythmic visual heights
        const delay = (i * 0.08) % 1.2;
        const baseHeight = isAudioActive
          ? Math.sin((i / barCount) * Math.PI) * 24 + 8
          : 4;

        return (
          <div
            key={i}
            className={`w-1 rounded-full transition-all duration-200 ${
              state === 'listening'
                ? 'bg-cyan-400 shadow-[0_0_8px_rgba(0,240,255,0.6)]'
                : state === 'speaking'
                ? 'bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.6)]'
                : state === 'thinking'
                ? 'bg-blue-600/50'
                : 'bg-slate-700/40'
            }`}
            style={{
              height: isAudioActive ? `${baseHeight}px` : '4px',
              animation: isAudioActive
                ? `sound-bar 0.9s ease-in-out infinite alternate ${delay}s`
                : 'none',
            }}
          />
        );
      })}
    </div>
  );
};
