import React, { useState } from 'react';
import { Bookmark, Trash2, FileText, BookOpen, HelpCircle, ArrowRight, Sparkles } from 'lucide-react';
import { SavedItem, Language } from '../types';

interface SavedContentProps {
  language: Language;
  savedItems: SavedItem[];
  onRemoveItem: (id: string) => void;
  onOpenItem?: (item: SavedItem) => void;
}

export default function SavedContent({ language, savedItems, onRemoveItem, onOpenItem }: SavedContentProps) {
  const [filterType, setFilterType] = useState<string>('all');

  const filteredItems = savedItems.filter(item => filterType === 'all' || item.type === filterType);

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 max-w-5xl mx-auto w-full pb-24 md:pb-10">
      
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500 rounded-2xl shadow-lg shadow-amber-500/20 text-slate-950">
            <Bookmark className="w-6 h-6 fill-current" />
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-black font-display">
              {language === 'bn' ? 'সংরক্ষিত বিষয়বস্তু (Saved Content)' : 'My Bookmarks & Saved Content'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'bn' ? 'আপনার সেভ করা লেসন, নোটস, ফ্ল্যাশকার্ড ও গুরুত্বপূর্ণ প্রশ্ন' : 'Review your bookmarked lessons, notes, and practice flashcards'}
            </p>
          </div>
        </div>

        <span className="bg-slate-800 border border-slate-700 font-extrabold text-xs px-3 py-1.5 rounded-xl text-amber-400">
          {savedItems.length} {language === 'bn' ? 'টি আইটেম' : 'Items'}
        </span>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'all', label: language === 'bn' ? 'সবগুলো' : 'All' },
          { id: 'note', label: language === 'bn' ? 'নোটস' : 'Notes' },
          { id: 'lesson', label: language === 'bn' ? 'ক্লাস লেসন' : 'Lessons' },
          { id: 'flashcard', label: language === 'bn' ? 'ফ্ল্যাশকার্ড' : 'Flashcards' },
          { id: 'question', label: language === 'bn' ? 'প্রশ্নসমূহ' : 'Questions' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === tab.id
                ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Items List */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Bookmark className="w-10 h-10 mx-auto text-slate-300" />
          <div className="text-sm font-bold text-slate-600">
            {language === 'bn' ? 'কোনো সেভ করা আইটেম পাওয়া যায়নি।' : 'No saved content found.'}
          </div>
          <p className="text-xs">
            {language === 'bn' ? 'ক্লাসরুম বা নোট বুকমার্গে বুকমার্ক আইকন ক্লিক করে সেভ করুন।' : 'Bookmark lessons or notes while studying to review them anytime here.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <div key={item.id} className="bg-white border border-slate-200/90 hover:border-amber-400 transition-all rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="font-extrabold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {item.type} • {item.subject}
                  </span>
                  <span className="text-slate-400 font-bold">{item.dateSaved}</span>
                </div>

                <h3 className="text-sm font-black text-slate-900 leading-snug">
                  {item.title}
                </h3>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  {language === 'bn' ? 'মুছে ফেলুন' : 'Remove'}
                </button>

                {onOpenItem && (
                  <button
                    onClick={() => onOpenItem(item)}
                    className="text-xs font-extrabold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    {language === 'bn' ? 'খুলুন' : 'View'} <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
