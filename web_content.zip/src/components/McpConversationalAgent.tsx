"use client";

import React, { useState } from "react";
import {
  CoinTechnicalAnalysis,
  OHLCVCandle,
  formatPriceNumber,
} from "../services/technicalEngine";
import {
  McpChatMessage,
  McpProposedOrderCard,
  PRESET_MCP_HEBREW_COMMANDS,
  parseNaturalLanguageDayTradeCommand,
} from "../services/mcpTradingService";
import {
  Bot,
  Send,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Sparkles,
  Terminal,
  AlertOctagon,
  TrendingUp,
  TrendingDown,
} from "lucide-react";

interface McpConversationalAgentProps {
  coins: CoinTechnicalAnalysis[];
  candles: OHLCVCandle[];
  virtualBalanceUsdt: number;
  dailyCircuitBreakerPct: number;
  onApproveMarketTrade: (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    entryPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => Promise<void>;
  onApproveCircuitBreaker: (maxLossPct: number) => void;
  onNavigateToBacktest: () => void;
}

export function McpConversationalAgent({
  coins,
  candles,
  virtualBalanceUsdt,
  dailyCircuitBreakerPct,
  onApproveMarketTrade,
  onApproveCircuitBreaker,
  onNavigateToBacktest,
}: McpConversationalAgentProps) {
  const safeCoins = Array.isArray(coins) ? coins : [];
  const btcPrice =
    safeCoins.find((c) => c.symbol === "BTCUSDT")?.currentPrice || 94280;

  const [inputCmd, setInputCmd] = useState<string>("");
  const [messages, setMessages] = useState<McpChatMessage[]>(() => {
    const initialParsed = parseNaturalLanguageDayTradeCommand(
      "קנה 0.5 BTC מרקט עם Stop-Loss ב-1.5% ו-Take-Profit ב-3%",
      safeCoins,
      candles,
      virtualBalanceUsdt
    );
    return [
      {
        id: "WELCOME-MCP-1",
        sender: "MCP_AI_AGENT",
        textHe:
          "שלום! אני סוכן המסחר היומי שלך בפרוטוקול MCP (Model Context Protocol), המחובר ל-Claude / ChatGPT / NVIDIA NIM ולמנוע הביצוע בזמן אמת. הקלד פקודת מסחר יומית בעברית או בחר פקודה מהירה. שום עסקה לא תבוצע ללא לחיצת אישור מפורשת שלך (״אתה מחליט, אתה מאשר, ה-AI מבצע״).",
        timestamp: Date.now() - 60000,
      },
      {
        id: "DEMO-PROPOSAL-1",
        sender: "MCP_AI_AGENT",
        textHe: initialParsed.replyTextHe,
        timestamp: Date.now() - 30000,
        proposalCard: {
          ...initialParsed.proposalCard,
          estimatedEntryPrice: btcPrice,
        },
      },
    ];
  });

  const handleSubmitCommand = (cmdText: string) => {
    const trimmed = (cmdText || "").trim();
    if (!trimmed) return;

    const userMsg: McpChatMessage = {
      id: `USER-${Date.now()}`,
      sender: "USER",
      textHe: trimmed,
      timestamp: Date.now(),
    };

    const parsed = parseNaturalLanguageDayTradeCommand(
      trimmed,
      safeCoins,
      candles,
      virtualBalanceUsdt
    );

    const agentMsg: McpChatMessage = {
      id: `AGENT-${Date.now() + 1}`,
      sender: "MCP_AI_AGENT",
      textHe: parsed.replyTextHe,
      timestamp: Date.now() + 1,
      proposalCard: parsed.proposalCard,
    };

    setMessages((prev) => [...prev, userMsg, agentMsg]);
    setInputCmd("");
  };

  const handleDecisionOnProposal = async (
    messageId: string,
    proposal: McpProposedOrderCard,
    decision: "APPROVE" | "REJECT"
  ) => {
    if (decision === "REJECT") {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId && m.proposalCard
            ? {
                ...m,
                proposalCard: {
                  ...m.proposalCard,
                  status: "REJECTED_BY_USER",
                },
              }
            : m
        )
      );
      return;
    }

    // User explicitly clicked [בצע / Execute]
    if (proposal.actionType === "SET_DAILY_CIRCUIT_BREAKER") {
      onApproveCircuitBreaker(proposal.circuitBreakerPct || 2.5);
    } else if (proposal.actionType === "RUN_INTRADAY_BACKTEST") {
      await onApproveMarketTrade({
        symbol: proposal.symbol,
        side: proposal.side,
        entryPrice: proposal.estimatedEntryPrice,
        sizeUsdt: proposal.sizeUsdt,
        leverage: proposal.leverage,
        stopLoss: proposal.stopLossPrice,
        takeProfit: proposal.takeProfitPrice,
      });
      onNavigateToBacktest();
    } else {
      await onApproveMarketTrade({
        symbol: proposal.symbol,
        side: proposal.side,
        entryPrice: proposal.estimatedEntryPrice,
        sizeUsdt: proposal.sizeUsdt,
        leverage: proposal.leverage,
        stopLoss: proposal.stopLossPrice,
        takeProfit: proposal.takeProfitPrice,
      });
    }

    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId && m.proposalCard
          ? {
              ...m,
              proposalCard: {
                ...m.proposalCard,
                status: "APPROVED_EXECUTED",
              },
            }
          : m
      )
    );
  };

  return (
    <div dir="rtl" className="space-y-5">
      {/* Top MCP Protocol & Safety Governance Banner */}
      <div className="rounded-xl border border-[#00E676]/40 bg-gradient-to-l from-[#11161F] via-[#181F2C] to-[#11161F] p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#00E676]/15 text-[#00E676]">
              <Bot className="h-7 w-7" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-extrabold text-[#F1F5F9] sm:text-xl">
                  סוכן AI למסחר יומי בצ&apos;אט (MCP Protocol Day Trading Agent)
                </h2>
                <span className="rounded-full bg-[#00E676]/20 px-2.5 py-0.5 font-mono text-xs font-bold text-[#00E676]">
                  אתה מחליט • אתה מאשר • ה-AI מבצע
                </span>
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">
                גשר MCP ישיר לפקודות שפה טבעית בעברית: סקאלפינג 1m/5m, הגדרת
                Stop-Loss / Trailing Stop, מנגנון הגנת הפסד יומי ו-Backtest.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-lg border border-[#222B3A] bg-[#0B0E14] px-4 py-2.5 text-xs">
            <AlertOctagon className="h-4 w-4 text-[#F59E0B]" />
            <div>
              <span className="block text-[10px] text-[#94A3B8]">
                מנגנון הגנת הפסד יומי מרבי (Circuit Breaker)
              </span>
              <strong className="font-mono text-sm text-[#00E676]">
                פעיל: תקרת הפסד יומי {dailyCircuitBreakerPct}% ($
                {((virtualBalanceUsdt * dailyCircuitBreakerPct) / 100).toFixed(0)}
                )
              </strong>
            </div>
          </div>
        </div>

        {/* 6 Preset Natural Language Hebrew Day Trading Commands */}
        <div className="mt-4 border-t border-[#222B3A] pt-3">
          <span className="mb-2 block text-xs font-bold text-[#94A3B8]">
            פקודות מסחר יומי מהירות בלחיצה אחת (Natural Language MCP Prompts):
          </span>
          <div className="flex flex-wrap gap-2">
            {PRESET_MCP_HEBREW_COMMANDS.map((cmd, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSubmitCommand(cmd)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-1.5 text-right text-xs font-semibold text-[#E2E8F0] transition hover:border-[#00E676] hover:bg-[#00E676]/10 hover:text-white"
              >
                <Terminal className="h-3.5 w-3.5 text-[#00E676]" />
                <span>&quot;{cmd}&quot;</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chat Stream & Strict 1-Click Approval Cards */}
      <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
        <div className="max-h-[540px] space-y-4 overflow-y-auto pl-1">
          {messages.map((msg) => {
            const isUser = msg.sender === "USER";
            const card = msg.proposalCard;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  isUser ? "items-start" : "items-stretch"
                }`}
              >
                <div
                  className={`max-w-3xl rounded-xl p-4 text-xs leading-relaxed ${
                    isUser
                      ? "border border-[#3B82F6]/50 bg-[#3B82F6]/15 text-[#F1F5F9]"
                      : "border border-[#222B3A] bg-[#0B0E14] text-[#E2E8F0]"
                  }`}
                >
                  <div className="mb-1 flex items-center justify-between gap-4">
                    <span className="font-bold text-[#00E676]">
                      {isUser
                        ? "👤 פקודת סוחר (אתה)"
                        : "🤖 סוכן MCP Day Trading AI"}
                    </span>
                    <span className="font-mono text-[10px] text-[#64748B]">
                      {new Date(msg.timestamp).toLocaleTimeString("he-IL", {
                        hour12: false,
                      })}
                    </span>
                  </div>
                  <p className="text-sm">{msg.textHe}</p>

                  {/* Proposed Order Card Requiring Explicit [בצע / Execute] or [דחה / Reject] */}
                  {card && (
                    <div className="mt-4 rounded-xl border border-[#3B82F6]/50 bg-[#11161F] p-4 shadow-inner">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222B3A] pb-2.5">
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="h-5 w-5 text-[#00E676]" />
                          <span className="text-sm font-extrabold text-[#F1F5F9]">
                            {card.summaryTitleHe}
                          </span>
                        </div>
                        <span className="rounded bg-[#3B82F6]/20 px-2 py-0.5 font-mono text-[10px] font-bold text-[#3B82F6]">
                          {card.mcpToolName}
                        </span>
                      </div>

                      <p className="mt-2.5 text-xs text-[#94A3B8]">
                        {card.aiExplanationHe}
                      </p>

                      {/* Structured Order Metrics */}
                      <div className="mt-3 grid grid-cols-2 gap-2.5 rounded-lg bg-[#0B0E14] p-3 font-mono text-xs sm:grid-cols-6">
                        <div>
                          <span className="block font-sans text-[10px] text-[#64748B]">
                            נכס (Symbol)
                          </span>
                          <strong className="text-[#F1F5F9]">
                            {card.symbol}
                          </strong>
                        </div>
                        <div>
                          <span className="block font-sans text-[10px] text-[#64748B]">
                            כיוון (Side)
                          </span>
                          <strong
                            className={
                              card.side === "LONG"
                                ? "text-[#00E676]"
                                : "text-[#FF3B69]"
                            }
                          >
                            {card.side === "LONG" ? "LONG (לונג)" : "SHORT (שורט)"}
                          </strong>
                        </div>
                        <div>
                          <span className="block font-sans text-[10px] text-[#64748B]">
                            בטחונות ומינוף
                          </span>
                          <strong className="text-[#F1F5F9]">
                            ${card.sizeUsdt} ({card.leverage}x)
                          </strong>
                        </div>
                        <div>
                          <span className="block font-sans text-[10px] text-[#64748B]">
                            כניסה משוערת
                          </span>
                          <strong className="text-[#F1F5F9]">
                            ${formatPriceNumber(card.estimatedEntryPrice)}
                          </strong>
                        </div>
                        <div>
                          <span className="block font-sans text-[10px] text-[#FF3B69]">
                            Stop-Loss (SL)
                          </span>
                          <strong className="text-[#FF3B69]">
                            {card.stopLossPrice > 0
                              ? `$${formatPriceNumber(card.stopLossPrice)}`
                              : `${card.circuitBreakerPct || 2.5}% יומי`}
                          </strong>
                        </div>
                        <div>
                          <span className="block font-sans text-[10px] text-[#00E676]">
                            סיכון מהתיק (Risk)
                          </span>
                          <strong className="text-[#00E676]">
                            {card.accountRiskPct}% מהתיק
                          </strong>
                        </div>
                      </div>

                      {/* Approval Action Buttons */}
                      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#222B3A] pt-3">
                        <span className="text-[11px] font-semibold text-[#94A3B8]">
                          🔒 אישור חובה: שום פקודה לא נשלחת ללא לחיצתך המפורשת
                        </span>

                        {card.status === "PENDING_USER_APPROVAL" ? (
                          <div className="flex items-center gap-2.5">
                            <button
                              type="button"
                              onClick={() =>
                                handleDecisionOnProposal(
                                  msg.id,
                                  card,
                                  "APPROVE"
                                )
                              }
                              className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E676] px-5 py-2 text-xs font-extrabold text-[#0B0E14] shadow transition hover:brightness-110"
                            >
                              <CheckCircle2 className="h-4 w-4" />
                              <span>[בצע / Execute]</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleDecisionOnProposal(msg.id, card, "REJECT")
                              }
                              className="inline-flex items-center gap-1.5 rounded-lg border border-[#FF3B69] bg-[#FF3B69]/15 px-4 py-2 text-xs font-bold text-[#FF3B69] transition hover:bg-[#FF3B69] hover:text-white"
                            >
                              <XCircle className="h-4 w-4" />
                              <span>[דחה / Reject]</span>
                            </button>
                          </div>
                        ) : card.status === "APPROVED_EXECUTED" ? (
                          <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E676]/20 px-3.5 py-1.5 text-xs font-extrabold text-[#00E676]">
                            <CheckCircle2 className="h-4 w-4" />
                            אושר ובוצע בהצלחה בתיק הדמו!
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#FF3B69]/20 px-3.5 py-1.5 text-xs font-extrabold text-[#FF3B69]">
                            <XCircle className="h-4 w-4" />
                            הפקודה נדחתה על ידך (לא בוצעה)
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Natural Language Command Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmitCommand(inputCmd);
          }}
          className="mt-4 flex items-center gap-2 border-t border-[#222B3A] pt-4"
        >
          <input
            type="text"
            value={inputCmd}
            onChange={(e) => setInputCmd(e.target.value)}
            placeholder='הקלד פקודת מסחר יומית בעברית (למשל: "קנה 0.5 BTC מרקט עם Stop-Loss ב-1.5% ו-Take-Profit ב-3%")...'
            className="flex-1 rounded-xl border border-[#222B3A] bg-[#0B0E14] px-4 py-3 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#00E676] focus:outline-none"
          />
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-xl bg-[#00E676] px-5 py-3 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
          >
            <Send className="h-4 w-4" />
            <span>נתח והכן כרטיס אישור</span>
          </button>
        </form>
      </div>
    </div>
  );
}
