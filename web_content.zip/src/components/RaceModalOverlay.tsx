import React from 'react';
import { Trophy, Play, RotateCcw, ArrowRight, Home, Video } from 'lucide-react';
import { AUTOMATED_LEVELS, GamePhase, LiveTelemetry } from '../types/game';

interface RaceModalOverlayProps {
  gamePhase: GamePhase;
  countdownText: string | null;
  levelIndex: number;
  telemetry: LiveTelemetry;
  raceResult: {
    winnerName: string;
    playerRank: number;
    finishTimeMs: number;
  } | null;
  autoAdvanceSeconds: number | null;
  onResume: () => void;
  onRestartLevel: () => void;
  onNextLevel: () => void;
  onReturnToTitle: () => void;
  onWatchReplay?: () => void;
}

function formatMs(ms: number | null): string {
  if (ms === null || ms <= 0) return '--:--.-';
  const totalSec = ms / 1000;
  const mins = Math.floor(totalSec / 60);
  const secs = Math.floor(totalSec % 60);
  const tenths = Math.floor((totalSec * 10) % 10);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${tenths}`;
}

export const RaceModalOverlay: React.FC<RaceModalOverlayProps> = ({
  gamePhase,
  countdownText,
  levelIndex,
  telemetry,
  raceResult,
  autoAdvanceSeconds,
  onResume,
  onRestartLevel,
  onNextLevel,
  onReturnToTitle,
  onWatchReplay,
}) => {
  const currentLevel = AUTOMATED_LEVELS[levelIndex] || AUTOMATED_LEVELS[0];
  const nextLevel = AUTOMATED_LEVELS[(levelIndex + 1) % AUTOMATED_LEVELS.length];

  // 1. 3-2-1-GO Countdown Banner
  if (gamePhase === 'countdown' && countdownText) {
    return (
      <div className="fixed inset-0 z-30 pointer-events-none flex items-center justify-center">
        <div className="px-12 py-6 rounded-2xl bg-[#090d16]/90 border border-amber-400/40 shadow-2xl text-center">
          <div className="text-xs font-semibold tracking-widest text-slate-400 uppercase mb-1">
            {currentLevel.name}
          </div>
          <div className="font-display text-6xl sm:text-7xl font-bold text-amber-400 tracking-wider font-mono-tabular">
            {countdownText}
          </div>
        </div>
      </div>
    );
  }

  // 2. Pause Modal
  if (gamePhase === 'paused') {
    return (
      <div className="fixed inset-0 z-30 bg-black/65 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl bg-[#090d16] border border-white/15 p-6 shadow-2xl space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div>
              <h2 className="font-display text-xl font-bold text-white">RACE PAUSED</h2>
              <p className="text-xs text-slate-400">{currentLevel.name}</p>
            </div>
            <span className="font-mono-tabular text-xs text-amber-400">
              LAP {telemetry.lap}/{telemetry.totalLaps}
            </span>
          </div>

          {/* Live Standings Snapshot */}
          <div className="space-y-1.5 max-h-44 overflow-y-auto">
            <div className="text-xs font-semibold text-slate-400">Current Grid Standings</div>
            {telemetry.standings.map((s, idx) => (
              <div
                key={s.id}
                className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono-tabular font-bold text-amber-400 w-4">
                    {idx + 1}.
                  </span>
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: s.paintHex }}
                  />
                  <span className="text-white font-medium">{s.name}</span>
                </div>
                <span className="font-mono-tabular text-slate-400">
                  Lap {s.lap} · {s.speedKmh} km/h
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
            <button
              onClick={onResume}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Resume</span>
            </button>
            <button
              onClick={onRestartLevel}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Restart</span>
            </button>
            <button
              onClick={onReturnToTitle}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Showroom</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Victory / Level Complete Modal with Automated Next Level Progression
  if (gamePhase === 'victory' && raceResult) {
    const isPodium = raceResult.playerRank <= 3;
    return (
      <div className="fixed inset-0 z-30 bg-black/70 flex items-center justify-center p-4">
        <div className="w-full max-w-lg rounded-2xl bg-[#090d16] border border-white/15 p-6 shadow-2xl space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs text-amber-400 font-semibold">
                  {currentLevel.name} COMPLETE
                </div>
                <h2 className="font-display text-2xl font-bold text-white">
                  {raceResult.playerRank === 1
                    ? '1ST PLACE VICTORY!'
                    : isPodium
                    ? `PODIUM FINISH — P${raceResult.playerRank}`
                    : `RACE FINISHED — P${raceResult.playerRank}`}
                </h2>
              </div>
            </div>

            <div className="text-right font-mono-tabular">
              <div className="text-[11px] text-slate-400">TOTAL TIME</div>
              <div className="text-base font-bold text-white">
                {formatMs(raceResult.finishTimeMs)}
              </div>
            </div>
          </div>

          {/* Final Standings Table */}
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            <div className="flex justify-between text-[11px] text-slate-400 px-2">
              <span>DRIVER</span>
              <span>STATUS / PACE</span>
            </div>
            {telemetry.standings.map((s, idx) => (
              <div
                key={s.id}
                className={`flex items-center justify-between px-3 py-2 rounded-lg border text-xs ${
                  s.id === 'local-p1'
                    ? 'bg-amber-500/15 border-amber-400/40 text-white'
                    : 'bg-slate-900 border-white/10 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-mono-tabular font-bold text-amber-400 w-5">
                    P{idx + 1}
                  </span>
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: s.paintHex }}
                  />
                  <span className="font-semibold">{s.name}</span>
                </div>
                <span className="font-mono-tabular text-xs text-slate-400">
                  {s.finished && s.finishTimeMs ? formatMs(s.finishTimeMs) : `Lap ${s.lap}`}
                </span>
              </div>
            ))}
          </div>

          {/* Automated Next Level Notice */}
          {autoAdvanceSeconds !== null && (
            <div className="px-3.5 py-2 rounded-xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-between text-xs text-emerald-200">
              <span>
                Advancing automatically to <strong>{nextLevel.name}</strong>
              </span>
              <span className="font-mono-tabular font-bold text-emerald-400">
                {autoAdvanceSeconds}s
              </span>
            </div>
          )}

          <div className="space-y-2 pt-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {onWatchReplay && (
                <button
                  onClick={onWatchReplay}
                  className="px-4 py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-400/40 font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-sm"
                  title="Watch the last 30 seconds of race telemetry in cinematic cameras"
                >
                  <Video className="w-4 h-4 text-cyan-400" />
                  <span>Cinematic Replay (30s)</span>
                </button>
              )}

              <button
                onClick={onNextLevel}
                className={`px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                  !onWatchReplay ? 'sm:col-span-2' : ''
                }`}
              >
                <span>NEXT: {nextLevel.name}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onRestartLevel}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Replay Level</span>
              </button>
              <button
                onClick={onReturnToTitle}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <Home className="w-4 h-4" />
                <span>Showroom</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
