import { useRef, useState } from "react";
import { AudioLines, FileAudio, Loader2, Replace, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useStudio } from "@/lib/studio/store";
import { createSampleScene, ingestAudioFile } from "@/lib/studio/pipeline";
import { formatBytes, formatDuration } from "@/lib/utils";
import { formatMegabytes, MAX_AUDIO_BYTES } from "@/lib/studio/limits";
import { StudioError } from "@/lib/studio/errors";
import { Waveform } from "./waveform";
import { TransferBar } from "./transfer-bar";

const ACCEPT = "audio/mpeg,audio/mp3,audio/wav,audio/x-wav,audio/mp4,audio/aac,audio/ogg,audio/flac,audio/x-m4a,.mp3,.wav,.m4a,.aac,.ogg,.flac";

export function AudioUploader() {
  const original = useStudio((s) => s.original);
  const peaks = useStudio((s) => s.peaks);
  const busy = useStudio((s) => s.busy);
  const analysisStatus = useStudio((s) => s.analysisStatus);
  const generationStatus = useStudio((s) => s.generationStatus);
  const resetProject = useStudio((s) => s.resetProject);
  const transfer = useStudio((s) => s.transfer);
  const inputRef = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);

  async function takeFile(file: File | undefined) {
    if (!file) return;
    try {
      await ingestAudioFile(file);
      toast.success("Story audio ready");
    } catch (err) {
      toast.error(err instanceof StudioError ? err.message : "The uploaded audio could not be processed.");
    }
  }

  async function onSample() {
    try {
      const blob = await createSampleScene();
      await ingestAudioFile(blob, "sample-scene.wav");
      toast.success("Sample scene loaded — analyze it next");
    } catch (err) {
      toast.error(err instanceof StudioError ? err.message : "Could not create the sample scene.");
    }
  }

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent">
          <Upload className="size-4" />
        </span>
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Upload story audio</h2>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            One recording with narration and multiple characters. Maximum size is 50 MB and 30 minutes.
          </p>
        </div>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT}
        className="sr-only"
        onChange={(e) => {
          void takeFile(e.target.files?.[0]);
          e.currentTarget.value = "";
        }}
      />

      {!original && transfer ? (
        <div className="mt-5">
          <TransferBar progress={transfer} />
        </div>
      ) : !original ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragEnter={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            void takeFile(e.dataTransfer.files?.[0]);
          }}
          className={`mt-5 flex min-h-44 w-full flex-col items-center justify-center rounded-lg bg-secondary px-4 py-10 text-center transition-[box-shadow,background-color] duration-200 ${
            drag ? "shadow-border-hover" : "shadow-border"
          }`}
        >
          <AudioLines className="size-8 text-accent" />
          <p className="mt-3 text-sm font-medium">Drop a story recording here</p>
          <p className="mt-1 text-xs text-muted-foreground">
            MP3, WAV, M4A, AAC, OGG, FLAC · up to {formatMegabytes(MAX_AUDIO_BYTES)} and 30 minutes
          </p>
        </button>
      ) : (
        <div className="mt-5 rounded-lg bg-secondary p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex min-w-0 items-start gap-3">
              <FileAudio className="mt-0.5 size-4 shrink-0 text-accent" />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{original.name}</p>
                <p className="mt-0.5 font-mono text-xs text-muted-foreground tabular-nums">
                  {formatBytes(original.size)} · {formatDuration(original.duration)}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" size="sm" disabled={busy} onClick={() => inputRef.current?.click()}>
                <Replace className="size-3.5" />
                Replace
              </Button>
              <Button type="button" variant="outline" size="sm" disabled={busy} onClick={resetProject}>
                <Trash2 className="size-3.5" />
                Remove
              </Button>
            </div>
          </div>
          <div className="mt-4">
            <Waveform peaks={peaks} />
          </div>
          <audio className="mt-4 w-full" controls src={original.objectUrl} preload="metadata" />
        </div>
      )}

      {transfer && original && transfer.label.startsWith("Reading") ? (
        <div className="mt-4">
          <TransferBar progress={transfer} />
        </div>
      ) : null}

      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-muted-foreground">
          Audio is sent only to the analysis API website you entered, for this session, and is not kept on this studio after processing.
        </p>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={busy || analysisStatus !== "valid" || generationStatus !== "valid"}
          onClick={() => void onSample()}
        >
          {busy ? <Loader2 className="size-3.5 animate-spin" /> : null}
          Create sample scene
        </Button>
      </div>
    </section>
  );
}
