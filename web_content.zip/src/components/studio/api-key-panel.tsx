import type { ReactNode } from "react";
import { AlertTriangle, Check, Eye, EyeOff, KeyRound, Loader2, Mic, Sparkles, Unplug, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStudio, type KeyStatus } from "@/lib/studio/store";
import { verifyAnalysisKey, verifyGenerationKey } from "@/lib/studio/pipeline";
import { maskApiKey } from "@/lib/utils";
import { familyLabel } from "@/lib/studio/providers/ids";

function analysisResult(status: KeyStatus) {
  if (status === "valid") {
    return { title: "✓ API is Valid and Useful", body: "This API authenticated and can analyze multi-speaker audio.", tone: "success" as const };
  }
  if (status === "invalid") {
    return { title: "✕ Audio Analysis API Key is Invalid", body: "The analysis API key could not be authenticated.", tone: "error" as const };
  }
  if (status === "quota") {
    return { title: "⚠ Analysis API quota is unavailable.", body: "The key was accepted, but analysis quota or credits are currently unavailable.", tone: "warning" as const };
  }
  if (status === "model_error") {
    return {
      title: "⚠ This API is valid, but not useful for audio analysis.",
      body: "Authentication worked, but this website cannot currently analyze uploaded multi-speaker audio.",
      tone: "warning" as const,
    };
  }
  if (status === "network_error") {
    return { title: "⚠ Unable to connect to the selected AI provider.", body: "Check the API website URL and your internet connection, then try again.", tone: "warning" as const };
  }
  if (status === "server_error") {
    return { title: "⚠ The selected AI provider is temporarily unavailable.", body: "Please try again in a moment.", tone: "warning" as const };
  }
  return null;
}

function generationResult(status: KeyStatus) {
  if (status === "valid") {
    return { title: "✓ API is Valid and Useful", body: "This API authenticated and can generate character voices.", tone: "success" as const };
  }
  if (status === "invalid") {
    return { title: "✕ Audio Generation API Key is Invalid", body: "The generation API key could not be authenticated.", tone: "error" as const };
  }
  if (status === "quota") {
    return { title: "⚠ Audio Generation API quota is unavailable.", body: "The key was accepted, but generation quota or credits are currently unavailable.", tone: "warning" as const };
  }
  if (status === "model_error") {
    return {
      title: "⚠ This API is valid, but not useful for voice generation.",
      body: "Authentication worked, but this website cannot currently generate distinct character voices.",
      tone: "warning" as const,
    };
  }
  if (status === "network_error") {
    return { title: "⚠ Unable to connect to the selected AI provider.", body: "Check the API website URL and your internet connection, then try again.", tone: "warning" as const };
  }
  if (status === "server_error") {
    return { title: "⚠ The selected AI provider is temporarily unavailable.", body: "Please try again in a moment.", tone: "warning" as const };
  }
  return null;
}

const TONE = {
  success: "border-success/30 bg-success/10 text-success",
  error: "border-destructive/30 bg-destructive/10 text-destructive",
  warning: "border-accent/30 bg-accent/10 text-accent",
};

export function ApiKeyPanel() {
  const analysisUrl = useStudio((s) => s.analysisUrl);
  const analysisKey = useStudio((s) => s.analysisKey);
  const analysisShowKey = useStudio((s) => s.analysisShowKey);
  const analysisStatus = useStudio((s) => s.analysisStatus);
  const analysisModel = useStudio((s) => s.analysisModel);
  const analysisFamily = useStudio((s) => s.analysisFamily);
  const generationUrl = useStudio((s) => s.generationUrl);
  const generationKey = useStudio((s) => s.generationKey);
  const generationShowKey = useStudio((s) => s.generationShowKey);
  const generationStatus = useStudio((s) => s.generationStatus);
  const generationModel = useStudio((s) => s.generationModel);
  const generationFamily = useStudio((s) => s.generationFamily);
  const workflowUnlocked = useStudio((s) => s.workflowUnlocked);
  const setAnalysisUrl = useStudio((s) => s.setAnalysisUrl);
  const setAnalysisKey = useStudio((s) => s.setAnalysisKey);
  const setAnalysisShowKey = useStudio((s) => s.setAnalysisShowKey);
  const clearAnalysisKey = useStudio((s) => s.clearAnalysisKey);
  const setGenerationUrl = useStudio((s) => s.setGenerationUrl);
  const setGenerationKey = useStudio((s) => s.setGenerationKey);
  const setGenerationShowKey = useStudio((s) => s.setGenerationShowKey);
  const clearGenerationKey = useStudio((s) => s.clearGenerationKey);
  const unlockWorkflow = useStudio((s) => s.unlockWorkflow);

  const canContinue = analysisStatus === "valid" && generationStatus === "valid";
  const aResult = analysisResult(analysisStatus);
  const gResult = generationResult(generationStatus);

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent">
          <KeyRound className="size-4" />
        </span>
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Connect two APIs</h2>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Paste any HTTPS API website and its key. Nothing is hard-coded. The studio validates the key for real, then checks whether that API is actually useful for analysis or voice generation.
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <KeySlot
          icon={<Mic className="size-3.5" />}
          title="Audio Analysis API"
          description="Any website API that can understand audio or transcribe speech, then reason about speakers and story."
          urlId="analysis-url"
          url={analysisUrl}
          onUrl={setAnalysisUrl}
          urlPlaceholder="https://api.example.com/v1"
          inputId="analysis-key"
          value={analysisKey}
          onChange={setAnalysisKey}
          show={analysisShowKey}
          onShow={setAnalysisShowKey}
          onClear={clearAnalysisKey}
          placeholder="Enter API key for audio analysis"
          buttonLabel="Validate Analysis API"
          testing={analysisStatus === "testing"}
          onValidate={() => void verifyAnalysisKey()}
          result={aResult}
          model={analysisModel}
          family={analysisFamily ? familyLabel(analysisFamily) : null}
        />
        <KeySlot
          icon={<Sparkles className="size-3.5" />}
          title="Audio Generation API"
          description="Any website API that can generate distinct, expressive character voices."
          urlId="generation-url"
          url={generationUrl}
          onUrl={setGenerationUrl}
          urlPlaceholder="https://api.example.com/v1"
          inputId="generation-key"
          value={generationKey}
          onChange={setGenerationKey}
          show={generationShowKey}
          onShow={setGenerationShowKey}
          onClear={clearGenerationKey}
          placeholder="Enter API key for voice generation"
          buttonLabel="Validate Generation API"
          testing={generationStatus === "testing"}
          onValidate={() => void verifyGenerationKey()}
          result={gResult}
          model={generationModel}
          family={generationFamily ? familyLabel(generationFamily) : null}
        />
      </div>

      <p className="mt-4 text-xs leading-5 text-muted-foreground">
        Keys stay in this browser session only, are never put in URLs, and are never written into this app’s source. Each key is sent only to the website you pasted for that slot.
      </p>

      <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-end">
        <Button type="button" size="lg" className="w-full sm:w-auto" disabled={!canContinue} onClick={unlockWorkflow}>
          Continue
        </Button>
      </div>
      {workflowUnlocked ? (
        <p className="mt-2 text-right text-xs text-success">Studio unlocked. Upload a multi-speaker recording below.</p>
      ) : (
        <p className="mt-2 text-right text-xs text-muted-foreground">Continue is enabled only after both APIs validate as valid and useful.</p>
      )}
    </section>
  );
}

function KeySlot({
  icon,
  title,
  description,
  urlId,
  url,
  onUrl,
  urlPlaceholder,
  inputId,
  value,
  onChange,
  show,
  onShow,
  onClear,
  placeholder,
  buttonLabel,
  testing,
  onValidate,
  result,
  model,
  family,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  urlId: string;
  url: string;
  onUrl: (value: string) => void;
  urlPlaceholder: string;
  inputId: string;
  value: string;
  onChange: (value: string) => void;
  show: boolean;
  onShow: (value: boolean) => void;
  onClear: () => void;
  placeholder: string;
  buttonLabel: string;
  testing: boolean;
  onValidate: () => void;
  result: { title: string; body: string; tone: "success" | "error" | "warning" } | null;
  model: string | null;
  family: string | null;
}) {
  const canValidate = value.trim().length > 0 && url.trim().length > 0 && !testing;
  return (
    <div className="flex flex-col gap-3 rounded-lg bg-secondary/70 p-4">
      <div className="flex items-center gap-2">
        <span className="flex size-7 items-center justify-center rounded-md bg-card text-accent">{icon}</span>
        <h3 className="font-medium">{title}</h3>
      </div>
      <p className="text-xs leading-5 text-muted-foreground">{description}</p>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={urlId}>API website</Label>
        <Input
          id={urlId}
          type="url"
          inputMode="url"
          autoComplete="off"
          spellCheck={false}
          placeholder={urlPlaceholder}
          value={url}
          onChange={(e) => onUrl(e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={inputId}>API key</Label>
        <div className="relative">
          <Input
            id={inputId}
            type={show ? "text" : "password"}
            autoComplete="off"
            spellCheck={false}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="pr-20"
            suppressHydrationWarning
          />
          <div className="absolute inset-y-0 right-1 flex items-center gap-0.5">
            <button
              type="button"
              className="rounded-md p-2 text-muted-foreground hover:text-foreground"
              onClick={() => onShow(!show)}
              aria-label={show ? "Hide API key" : "Show API key"}
            >
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
            <button
              type="button"
              className="rounded-md p-2 text-muted-foreground hover:text-foreground"
              onClick={onClear}
              disabled={!value}
              aria-label="Clear API key"
            >
              <Unplug className="size-4" />
            </button>
          </div>
        </div>
      </div>
      <Button type="button" disabled={!canValidate} onClick={onValidate}>
        {testing ? (
          <>
            <Loader2 className="size-4 animate-spin" />
            Validating...
          </>
        ) : (
          buttonLabel
        )}
      </Button>
      {result ? (
        <div className={`rounded-md border px-3 py-2 text-sm ${TONE[result.tone]}`}>
          <p className="flex items-start gap-2 font-medium">
            {result.tone === "success" ? <Check className="mt-0.5 size-4 shrink-0" /> : result.tone === "error" ? <X className="mt-0.5 size-4 shrink-0" /> : <AlertTriangle className="mt-0.5 size-4 shrink-0" />}
            {result.title}
          </p>
          <p className="mt-1 text-xs opacity-90">{result.body}</p>
          {result.tone === "success" && !show ? (
            <p className="mt-1 text-xs opacity-80">
              {maskApiKey(value)}
              {family ? ` · ${family}` : ""}
              {model ? ` · ${model}` : ""}
            </p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
