import { Check, Download, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStudio } from "@/lib/studio/store";
import { retrySegment } from "@/lib/studio/pipeline";
import { formatDuration } from "@/lib/utils";
import { speakerColorVar } from "@/lib/studio/cast";

export function ResultPlayer() {
  const original = useStudio((s) => s.original);
  const mixUrl = useStudio((s) => s.mixUrl);
  const analysis = useStudio((s) => s.analysis);
  const quality = useStudio((s) => s.quality);
  const segmentAudio = useStudio((s) => s.segmentAudio);
  const busy = useStudio((s) => s.busy);

  if (!mixUrl || !original || !analysis) return null;

  const index = Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i]));
  const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim());

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Result</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Same dialogue order, independent voices, reconstructed on the original timeline.
          </p>
        </div>
        <a href={mixUrl} download="character-voice-studio.wav">
          <Button type="button">
            <Download className="size-4" />
            Download WAV
          </Button>
        </a>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg bg-secondary p-4">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Original</p>
          <audio className="mt-3 w-full" controls src={original.objectUrl} preload="metadata" />
          <p className="mt-2 font-mono text-xs text-muted-foreground tabular-nums">
            {formatDuration(original.duration)}
          </p>
        </div>
        <div className="rounded-lg bg-secondary p-4">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Recast</p>
          <audio className="mt-3 w-full" controls src={mixUrl} preload="metadata" />
          <p className="mt-2 text-xs text-muted-foreground">Expressive character voices, mixed back onto the original clock.</p>
        </div>
      </div>

      {quality.length > 0 ? (
        <ul className="mt-5 grid gap-2 sm:grid-cols-2">
          {quality.map((check) => (
            <li key={check.id} className="flex items-start gap-2 rounded-md bg-secondary px-3 py-2 text-sm">
              {check.passed ? (
                <Check className="mt-0.5 size-3.5 text-success" />
              ) : (
                <X className="mt-0.5 size-3.5 text-destructive" />
              )}
              <span>
                <span className="font-medium">{check.label}</span>
                <span className="block text-xs text-muted-foreground">{check.detail}</span>
              </span>
            </li>
          ))}
        </ul>
      ) : null}

      <div className="mt-6">
        <h3 className="text-sm font-medium">Segments</h3>
        <ul className="mt-3 space-y-2">
          {spoken.map((seg) => {
            const who = analysis.speakers.find((s) => s.speaker_id === seg.speaker_id);
            const clip = segmentAudio[seg.id];
            return (
              <li key={seg.id} className="flex flex-wrap items-center gap-3 rounded-md bg-secondary px-3 py-2">
                <span
                  className="size-2 rounded-full"
                  style={{ background: speakerColorVar(index[seg.speaker_id] ?? 0) }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm">
                    <span className="font-medium">{who?.display_name}</span>
                    <span className="text-muted-foreground"> · {seg.emotion}</span>
                  </p>
                  <p className="truncate text-xs text-muted-foreground">{seg.text}</p>
                </div>
                {clip ? <audio className="h-8 max-w-40" controls src={clip.wavUrl} preload="metadata" /> : null}
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  disabled={busy}
                  onClick={() => void retrySegment(seg.id)}
                >
                  <RefreshCw className="size-3.5" />
                  Retry
                </Button>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
