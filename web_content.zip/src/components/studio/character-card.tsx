import { useRef, useState } from "react";
import { Loader2, MicVocal, RefreshCw, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { CharacterProfile } from "@/lib/studio/types";
import { getVoice, catalogFor } from "@/lib/studio/voices";
import { speakerColorVar } from "@/lib/studio/cast";
import { previewCharacter, recastCharacter } from "@/lib/studio/pipeline";
import { StudioError } from "@/lib/studio/errors";
import { useStudio } from "@/lib/studio/store";

export function CharacterCard({
  speaker,
  index,
}: {
  speaker: CharacterProfile;
  index: number;
}) {
  const generationFamily = useStudio((s) => s.generationFamily);
  const voice = getVoice(speaker.recommended_voice_id, catalogFor(generationFamily ?? "compat"));
  const [previewing, setPreviewing] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  async function onPreview() {
    setPreviewing(true);
    try {
      const url = await previewCharacter(speaker.speaker_id);
      const audio = audioRef.current;
      if (audio) {
        audio.src = url;
        await audio.play();
      }
    } catch (err) {
      toast.error(err instanceof StudioError ? err.message : "Could not preview that voice.");
    } finally {
      setPreviewing(false);
    }
  }

  return (
    <article className="flex flex-col rounded-lg bg-secondary p-4">
      <div className="flex items-start gap-3">
        <span
          className="mt-1 size-2.5 shrink-0 rounded-full"
          style={{ background: speakerColorVar(index) }}
        />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-lg font-medium tracking-tight">{speaker.display_name}</h3>
            <Badge variant="outline">{speaker.speaker_id.replace("_", " ")}</Badge>
            {speaker.is_narrator ? <Badge variant="steel">Narrator</Badge> : null}
            <Badge>{speaker.importance}</Badge>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">{speaker.role}</p>
        </div>
      </div>

      <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Original voice</dt>
          <dd className="mt-1 text-foreground">
            {speaker.original_voice.age_characteristic}, {speaker.original_voice.pitch} pitch,{" "}
            {speaker.original_voice.pace} pace, {speaker.original_voice.texture}, {speaker.original_voice.energy} energy
          </dd>
        </div>
        <div>
          <dt className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Personality</dt>
          <dd className="mt-1">{speaker.personality.join(" · ") || "—"}</dd>
        </div>
        <div>
          <dt className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Emotional style</dt>
          <dd className="mt-1">{speaker.emotional_style.join(" · ") || "—"}</dd>
        </div>
        <div>
          <dt className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Cast voice</dt>
          <dd className="mt-1 flex items-center gap-2">
            <MicVocal className="size-3.5 text-accent" />
            <span>
              {speaker.recommended_voice_id}
              {voice ? ` · ${voice.tagline}` : ""}
            </span>
          </dd>
        </div>
      </dl>

      <p className="mt-3 text-sm text-muted-foreground">{speaker.voice_reason}</p>
      {speaker.story_context ? (
        <p className="mt-2 text-sm text-foreground">{speaker.story_context}</p>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2">
        <Button type="button" variant="outline" size="sm" onClick={() => void onPreview()} disabled={previewing}>
          {previewing ? <Loader2 className="size-3.5 animate-spin" /> : <Volume2 className="size-3.5" />}
          Preview generated voice
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => recastCharacter(speaker.speaker_id)}>
          <RefreshCw className="size-3.5" />
          Recast automatically
        </Button>
      </div>
      <audio ref={audioRef} className="hidden" />
    </article>
  );
}
