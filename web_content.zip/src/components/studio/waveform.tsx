import type { DialogueSegment } from "@/lib/studio/types";
import { speakerColorVar } from "@/lib/studio/cast";

type WaveformProps = {
  peaks: number[];
  segments?: DialogueSegment[];
  speakerIndex?: Record<string, number>;
  duration?: number;
};

export function Waveform({ peaks, segments, speakerIndex, duration }: WaveformProps) {
  const bars = peaks.length > 0 ? peaks : Array.from({ length: 72 }, () => 0.12);

  return (
    <div className="flex h-16 items-end gap-px" aria-hidden="true">
      {bars.map((peak, i) => {
        const t = bars.length > 1 ? i / (bars.length - 1) : 0;
        const time = (duration ?? 1) * t;
        const seg = segments?.find((s) => time >= s.start && time < s.end && !s.is_silence);
        const color = seg && speakerIndex
          ? speakerColorVar(speakerIndex[seg.speaker_id] ?? 0)
          : "var(--color-accent)";
        const h = Math.max(8, Math.round(peak * 100));
        return (
          <span
            key={i}
            className="flex-1 rounded-full"
            style={{
              height: `${h}%`,
              background: color,
              opacity: seg || !segments ? 0.9 : 0.25,
            }}
          />
        );
      })}
    </div>
  );
}
