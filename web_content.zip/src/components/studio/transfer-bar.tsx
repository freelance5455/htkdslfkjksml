import { Progress } from "@/components/ui/progress";
import { formatMegabytes, MAX_AUDIO_BYTES } from "@/lib/studio/limits";
import type { TransferProgress } from "@/lib/studio/types";

export function TransferBar({ progress }: { progress: TransferProgress }) {
  return (
    <div className="rounded-lg bg-secondary p-4">
      <div className="flex items-end justify-between gap-3">
        <p className="text-sm font-medium">{progress.label}</p>
        <p className="font-mono text-sm tabular-nums text-foreground">{progress.percent}%</p>
      </div>
      <Progress className="mt-3 h-2" value={progress.percent} />
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 font-mono text-xs tabular-nums text-muted-foreground">
        <span>
          {formatMegabytes(progress.loaded)} of {formatMegabytes(progress.total)}
        </span>
        <span>Limit {formatMegabytes(MAX_AUDIO_BYTES)} · 30 min</span>
      </div>
    </div>
  );
}
