import { useEffect } from "react";
import { Clapperboard, Loader2, AudioLines, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStudio } from "@/lib/studio/store";
import { runAnalysis, runConversion } from "@/lib/studio/pipeline";
import { StudioError } from "@/lib/studio/errors";
import { maskApiKey } from "@/lib/utils";
import { familyLabel } from "@/lib/studio/providers/ids";
import { ApiKeyPanel } from "./api-key-panel";
import { AudioUploader } from "./audio-uploader";
import { PipelinePanel } from "./pipeline-panel";
import { CharacterCard } from "./character-card";
import { EmotionTimeline } from "./emotion-timeline";
import { ResultPlayer } from "./result-player";
import { Waveform } from "./waveform";

export function StudioApp() {
  const hydrate = useStudio((s) => s.hydrate);
  const workflowUnlocked = useStudio((s) => s.workflowUnlocked);
  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="mx-auto flex min-h-dvh max-w-5xl flex-col px-4 pt-6 pb-16 sm:px-6 sm:pt-10">
      <Header />
      <main className="mt-8 flex flex-col gap-6">
        <ApiKeyPanel />
        {workflowUnlocked ? (
          <>
            <AudioUploader />
            <AnalyzeBar />
            <PipelinePanel />
            <StoryPanel />
            <CharactersPanel />
            <EmotionGate />
            <ConvertBar />
            <ResultPlayer />
            <FooterNote />
          </>
        ) : null}
      </main>
    </div>
  );
}

function Header() {
  const analysisStatus = useStudio((s) => s.analysisStatus);
  const generationStatus = useStudio((s) => s.generationStatus);
  const analysisKey = useStudio((s) => s.analysisKey);
  const generationKey = useStudio((s) => s.generationKey);
  const analysisFamily = useStudio((s) => s.analysisFamily);
  const generationFamily = useStudio((s) => s.generationFamily);
  const analysisLabel = familyLabel(analysisFamily, "Analysis");
  const generationLabel = familyLabel(generationFamily, "Generation");

  return (
    <header className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="text-xs font-medium tracking-[0.22em] text-muted-foreground uppercase">
          Automatic character casting
        </p>
        <h1 className="mt-2 font-display text-[2.15rem] leading-[1.1] font-medium tracking-tight sm:text-5xl">
          Character{" "}
          <em className="italic font-medium text-accent">Voice</em> Studio
        </h1>
        <p className="mt-3 max-w-lg text-sm leading-6 text-muted-foreground sm:text-base">
          Upload one multi-speaker story. The analysis API you connect finds the speakers and casts distinct voices. The generation API speaks each character — then the original timeline is rebuilt.
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant={analysisStatus === "valid" ? "success" : "outline"}>
          {analysisStatus === "valid" ? `${analysisLabel} ${maskApiKey(analysisKey)}` : "Validate analysis key"}
        </Badge>
        <Badge variant={generationStatus === "valid" ? "success" : "outline"}>
          {generationStatus === "valid" ? `${generationLabel} ${maskApiKey(generationKey)}` : "Validate generation key"}
        </Badge>
        <Badge variant="outline">No shared voices</Badge>
      </div>
    </header>
  );
}

function AnalyzeBar() {
  const original = useStudio((s) => s.original);
  const busy = useStudio((s) => s.busy);
  const analysis = useStudio((s) => s.analysis);
  const error = useStudio((s) => s.error);
  const peaks = useStudio((s) => s.peaks);
  const analysisStatus = useStudio((s) => s.analysisStatus);

  if (!original) return null;

  async function onAnalyze() {
    try {
      await runAnalysis();
      toast.success("Speakers cast automatically");
    } catch (err) {
      toast.error(err instanceof StudioError ? err.message : "Something went wrong. Please try processing the audio again.");
    }
  }

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Analyze</h2>
          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            Detect speakers, read the story, and auto-cast a different suitable voice for each character. You do not pick voices by hand.
          </p>
        </div>
        <Button type="button" size="lg" disabled={busy || analysisStatus !== "valid"} onClick={() => void onAnalyze()}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}
          Analyze & cast
        </Button>
      </div>
      {analysis ? (
        <div className="mt-5">
          <Waveform
            peaks={peaks}
            segments={analysis.segments}
            speakerIndex={Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i]))}
            duration={original.duration}
          />
        </div>
      ) : null}
      {error ? <p className="mt-3 text-sm text-destructive">{error}</p> : null}
    </section>
  );
}

function StoryPanel() {
  const analysis = useStudio((s) => s.analysis);
  if (!analysis) return null;
  const { story } = analysis;

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex size-9 items-center justify-center rounded-md bg-secondary text-accent">
          <Clapperboard className="size-4" />
        </span>
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">{story.title}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {story.genre} · {story.mood}
            {story.time_period ? ` · ${story.time_period}` : ""}
          </p>
        </div>
      </div>
      <p className="mt-4 max-w-3xl text-sm leading-6">{story.summary}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <Badge variant="outline">{story.environment}</Badge>
        {story.atmosphere.map((tag) => (
          <Badge key={tag} variant="outline">
            {tag}
          </Badge>
        ))}
        <Badge variant="outline">{analysis.speakers.length} speakers</Badge>
        <Badge variant="outline">{analysis.segments.filter((s) => !s.is_silence).length} spoken lines</Badge>
      </div>
    </section>
  );
}

function CharactersPanel() {
  const analysis = useStudio((s) => s.analysis);
  if (!analysis) return null;

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div>
        <h2 className="font-display text-xl font-medium tracking-tight">Characters & voice casting</h2>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Casting is automatic. Each important character receives a different catalog voice chosen from original timbre, role, personality, and scene mood — including casts with more than 10 speakers.
        </p>
      </div>
      <div className="mt-5 grid gap-3">
        {analysis.speakers.map((speaker, index) => (
          <CharacterCard key={speaker.speaker_id} speaker={speaker} index={index} />
        ))}
      </div>
    </section>
  );
}

function EmotionGate() {
  const analysis = useStudio((s) => s.analysis);
  if (!analysis) return null;
  return <EmotionTimeline analysis={analysis} />;
}

function ConvertBar() {
  const analysis = useStudio((s) => s.analysis);
  const mixUrl = useStudio((s) => s.mixUrl);
  const busy = useStudio((s) => s.busy);
  const generationStatus = useStudio((s) => s.generationStatus);
  if (!analysis) return null;

  async function onConvert() {
    try {
      await runConversion();
      toast.success("Recast mix is ready");
    } catch (err) {
      toast.error(err instanceof StudioError ? err.message : "The voice-conversion engine could not generate one or more speaker segments.");
    }
  }

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Convert voices</h2>
          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            Each speaker is synthesized independently with emotional direction, then laid back on the original clock — pauses included.
          </p>
        </div>
        <Button type="button" size="lg" disabled={busy || generationStatus !== "valid"} onClick={() => void onConvert()}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : <AudioLines className="size-4" />}
          {mixUrl ? "Convert again" : "Convert voices"}
        </Button>
      </div>
    </section>
  );
}

function FooterNote() {
  return (
    <footer className="px-1 pt-4 text-xs leading-5 text-muted-foreground">
      <p>
        The analysis API identifies speakers, characters, original voices, and emotion, then automatically casts a persistent voice for each speaker. The generation API speaks those lines — this is character-aware recasting, not a clone of the original vocal tract. You do not pick voices by hand. Uploaded audio is temporary; this studio does not sell recordings or keep complete API keys in logs.
      </p>
    </footer>
  );
}
