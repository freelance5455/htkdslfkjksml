import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  Copy,
  Download,
  Eye,
  FolderPlus,
  Leaf,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Paperclip,
  Pin,
  Plus,
  Search,
  SendHorizontal,
  Trash2,
  X,
} from "lucide-react";
import { askAlder, type AskMode } from "@/lib/ask";
import { htmlBlocks, MessageBody } from "@/lib/markdown";
import { useStudio, type Thread } from "@/lib/studio-store";

const MODES: { id: AskMode; label: string; hint: string }[] = [
  { id: "swift", label: "Swift", hint: "Short and direct" },
  { id: "studio", label: "Studio", hint: "Balanced, the default" },
  { id: "deep", label: "Deep", hint: "Longer, more careful" },
];

const STARTERS = [
  {
    title: "Announcement",
    body: "A calm launch note, four short paragraphs.",
    prompt:
      "Draft a calm product announcement for a writing studio called Alder Pro. Four short paragraphs, no hype.",
  },
  {
    title: "Onboarding",
    body: "Guided tour versus a blank page.",
    prompt:
      "Compare two onboarding approaches for a notes app: a guided tour versus a blank page with three examples. Recommend one.",
  },
  {
    title: "Reading list",
    body: "Eight essays on attention and craft.",
    prompt:
      "Make a one-page reading list of eight essays about attention and craft. One sentence each on why it matters.",
  },
  {
    title: "Focus timer",
    body: "A live canvas you can actually run.",
    prompt:
      "Build a small focus timer as one complete html document: 25 minutes, start, pause, and reset. Quiet paper colors, large numerals, no external assets or scripts from the network.",
  },
];

export function Studio() {
  const threads = useStudio((s) => s.threads);
  const projects = useStudio((s) => s.projects);
  const activeId = useStudio((s) => s.activeId);
  const mode = useStudio((s) => s.mode);
  const collapsed = useStudio((s) => s.sidebarCollapsed);
  const projectFilter = useStudio((s) => s.projectFilter);
  const setMode = useStudio((s) => s.setMode);
  const setCollapsed = useStudio((s) => s.setSidebarCollapsed);
  const setProjectFilter = useStudio((s) => s.setProjectFilter);
  const setActive = useStudio((s) => s.setActive);
  const newChat = useStudio((s) => s.newChat);
  const addProject = useStudio((s) => s.addProject);
  const renameThread = useStudio((s) => s.renameThread);
  const togglePin = useStudio((s) => s.togglePin);
  const deleteThread = useStudio((s) => s.deleteThread);
  const assignProject = useStudio((s) => s.assignProject);
  const sendLocal = useStudio((s) => s.sendLocal);
  const completeReply = useStudio((s) => s.completeReply);

  const [navOpen, setNavOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [canvas, setCanvas] = useState<string | null>(null);
  const [canvasTab, setCanvasTab] = useState<"preview" | "code">("preview");
  const [modeOpen, setModeOpen] = useState(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [projectName, setProjectName] = useState("");
  const [addingProject, setAddingProject] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    void useStudio.persist.rehydrate();
  }, []);

  const active = threads.find((thread) => thread.id === activeId) ?? null;

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTo({ top: node.scrollHeight, behavior: "smooth" });
  }, [active?.id, active?.messages.length, pending]);

  useEffect(() => {
    if (!modeOpen) return;
    function close() {
      setModeOpen(false);
    }
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [modeOpen]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setNavOpen(true);
        searchRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return threads
      .filter((thread) => {
        if (projectFilter && !q && thread.projectId !== projectFilter) return false;
        if (!q) return true;
        const blob = `${thread.title} ${thread.messages.map((m) => m.content).join(" ")}`.toLowerCase();
        return blob.includes(q);
      })
      .slice()
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
  }, [threads, query, projectFilter]);

  const canvases = useMemo(
    () =>
      threads.flatMap((thread) => {
        const blocks = thread.messages.flatMap((message) =>
          message.role === "assistant" ? htmlBlocks(message.content) : [],
        );
        if (!blocks.length) return [];
        return [{ id: thread.id, title: thread.title, code: blocks[blocks.length - 1].code }];
      }),
    [threads],
  );

  async function reply(threadId: string, messages: { role: "user" | "assistant"; content: string }[]) {
    setPending(true);
    setError(null);
    try {
      const result = await askAlder({ data: { messages, mode: useStudio.getState().mode } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      completeReply(threadId, result.text);
      const blocks = htmlBlocks(result.text);
      if (blocks.length) {
        setCanvas(blocks[blocks.length - 1].code);
        setCanvasTab("preview");
      }
    } catch {
      setError("The studio couldn't reply. Try again in a moment.");
    } finally {
      setPending(false);
    }
  }

  function submit(text: string) {
    if (pending) return;
    const sent = sendLocal(text);
    if (!sent) return;
    setDraft("");
    setNavOpen(false);
    void reply(sent.threadId, sent.messages);
  }

  function retry() {
    if (!active || pending) return;
    const last = active.messages[active.messages.length - 1];
    if (last?.role !== "user") return;
    void reply(
      active.id,
      active.messages.map((message) => ({ role: message.role, content: message.content })),
    );
  }

  function onFile(file: File) {
    if (file.size > 24_000) {
      setError("Keep attached notes under a few pages.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "").slice(0, 6000);
      setDraft((current) => `${current}\n\n--- ${file.name} ---\n${text}`.trim());
    };
    reader.readAsText(file);
  }

  function downloadThread(thread: Thread) {
    const body = thread.messages
      .map((message) => `## ${message.role === "user" ? "You" : "Alder"}\n\n${message.content}`)
      .join("\n\n");
    const blob = new Blob([`# ${thread.title}\n\n${body}\n`], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${thread.title.replace(/[^\w]+/g, "-").slice(0, 40) || "chat"}.md`;
    link.click();
    URL.revokeObjectURL(url);
  }

  const modeMeta = MODES.find((item) => item.id === mode) ?? MODES[1];

  return (
    <div className="flex h-dvh overflow-hidden bg-canvas text-ink">
      {navOpen ? (
        <button
          type="button"
          aria-label="Close menu"
          className="fixed inset-0 z-20 bg-ink/30 lg:hidden"
          onClick={() => setNavOpen(false)}
        />
      ) : null}

      <aside
        className={
          "fixed inset-y-0 left-0 z-30 flex w-72 flex-col border-r border-line bg-sidebar transition-transform duration-200 lg:static lg:translate-x-0 " +
          (navOpen ? "translate-x-0 " : "-translate-x-full ") +
          (collapsed ? "lg:w-16" : "lg:w-72")
        }
      >
        <div className={"flex items-center gap-2 px-3 py-4 " + (collapsed ? "lg:justify-center" : "")}>
          <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-spruce text-mist">
            <Leaf className="size-4" />
          </span>
          <div className={"min-w-0 " + (collapsed ? "lg:hidden" : "")}>
            <div className="flex items-center gap-2">
              <span className="font-serif text-xl leading-none">Alder</span>
            </div>
          </div>
        </div>

        <div className="px-3">
          <button
            type="button"
            onClick={() => {
              newChat();
              setCanvas(null);
              setError(null);
              setNavOpen(false);
            }}
            className={
              "flex h-11 w-full items-center justify-center gap-2 rounded-full bg-spruce text-sm font-medium text-mist transition-transform duration-150 ease-out active:scale-[0.96] " +
              (collapsed ? "lg:mx-auto lg:w-11" : "")
            }
          >
            <Plus className="size-4" />
            <span className={collapsed ? "lg:hidden" : ""}>New chat</span>
          </button>
        </div>

        <div className={"px-3 pt-3 " + (collapsed ? "lg:hidden" : "")}>
          <label className="flex h-11 items-center gap-2 rounded-full border border-line bg-mist px-3">
            <Search className="size-4 shrink-0 text-muted" />
            <input
              ref={searchRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search chats"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted"
            />
          </label>
        </div>

        <div className={"scroll-thin mt-4 flex-1 space-y-5 overflow-y-auto px-2 pb-3 " + (collapsed ? "lg:hidden" : "")}>
          <section>
            <div className="flex items-center justify-between px-2 pb-1">
              <h2 className="text-xs font-semibold tracking-wide text-muted uppercase">Projects</h2>
              <button
                type="button"
                aria-label="New project"
                onClick={() => setAddingProject((value) => !value)}
                className="flex size-8 items-center justify-center rounded-full text-muted hover:bg-chip hover:text-ink"
              >
                <FolderPlus className="size-4" />
              </button>
            </div>
            {addingProject ? (
              <form
                className="px-2 pb-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  addProject(projectName);
                  setProjectName("");
                  setAddingProject(false);
                }}
              >
                <input
                  autoFocus
                  value={projectName}
                  onChange={(event) => setProjectName(event.target.value)}
                  placeholder="Project name"
                  className="h-10 w-full rounded-xl border border-line bg-mist px-3 text-sm outline-none"
                />
              </form>
            ) : null}
            <button
              type="button"
              onClick={() => setProjectFilter(null)}
              className={
                "flex h-10 w-full items-center rounded-xl px-3 text-left text-sm " +
                (projectFilter === null ? "bg-chip font-medium" : "hover:bg-chip")
              }
            >
              All chats
            </button>
            {projects.map((project) => (
              <button
                key={project.id}
                type="button"
                onClick={() => setProjectFilter(project.id)}
                className={
                  "flex h-10 w-full items-center justify-between rounded-xl px-3 text-left text-sm " +
                  (projectFilter === project.id ? "bg-chip font-medium" : "hover:bg-chip")
                }
              >
                <span className="truncate">{project.name}</span>
                <span className="text-xs text-muted tabular-nums">
                  {threads.filter((thread) => thread.projectId === project.id).length}
                </span>
              </button>
            ))}
          </section>

          <section>
            <h2 className="px-2 pb-1 text-xs font-semibold tracking-wide text-muted uppercase">Chats</h2>
            {visible.length === 0 ? (
              <p className="px-3 py-2 text-sm text-muted">Nothing here yet.</p>
            ) : (
              visible.map((thread) => (
                <div
                  key={thread.id}
                  className={
                    "group flex items-center gap-1 rounded-xl pr-1 " +
                    (thread.id === activeId ? "bg-chip" : "hover:bg-chip")
                  }
                >
                  {renaming === thread.id ? (
                    <form
                      className="min-w-0 flex-1"
                      onSubmit={(event) => {
                        event.preventDefault();
                        renameThread(thread.id, renameValue);
                        setRenaming(null);
                      }}
                    >
                      <input
                        autoFocus
                        value={renameValue}
                        onChange={(event) => setRenameValue(event.target.value)}
                        onBlur={() => {
                          renameThread(thread.id, renameValue);
                          setRenaming(null);
                        }}
                        className="h-10 w-full bg-transparent px-3 text-sm outline-none"
                      />
                    </form>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setActive(thread.id);
                        setNavOpen(false);
                        const blocks = thread.messages.flatMap((message) =>
                          message.role === "assistant" ? htmlBlocks(message.content) : [],
                        );
                        setCanvas(blocks.at(-1)?.code ?? null);
                      }}
                      onDoubleClick={() => {
                        setRenaming(thread.id);
                        setRenameValue(thread.title);
                      }}
                      className="h-10 min-w-0 flex-1 truncate px-3 text-left text-sm"
                    >
                      {thread.pinned ? <Pin className="mr-1 inline size-3 text-spruce" /> : null}
                      {thread.title}
                    </button>
                  )}
                  <button
                    type="button"
                    aria-label={thread.pinned ? "Unpin" : "Pin"}
                    onClick={() => togglePin(thread.id)}
                    className={
                      "size-8 shrink-0 items-center justify-center rounded-full text-muted hover:text-ink " +
                      (thread.id === activeId ? "flex" : "hidden group-hover:flex")
                    }
                  >
                    <Pin className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Delete chat"
                    onClick={() => {
                      if (confirmId === thread.id) deleteThread(thread.id);
                      else setConfirmId(thread.id);
                    }}
                    className={
                      "h-8 shrink-0 items-center justify-center rounded-full px-2 text-muted hover:text-ink " +
                      (thread.id === activeId || confirmId === thread.id ? "flex" : "hidden group-hover:flex")
                    }
                  >
                    {confirmId === thread.id ? (
                      <span className="text-xs font-medium">Remove</span>
                    ) : (
                      <Trash2 className="size-3.5" />
                    )}
                  </button>
                </div>
              ))
            )}
          </section>

          {canvases.length ? (
            <section>
              <h2 className="px-2 pb-1 text-xs font-semibold tracking-wide text-muted uppercase">Canvases</h2>
              {canvases.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActive(item.id);
                    setCanvas(item.code);
                    setCanvasTab("preview");
                    setNavOpen(false);
                  }}
                  className="flex h-10 w-full items-center rounded-xl px-3 text-left text-sm hover:bg-chip"
                >
                  <span className="truncate">{item.title}</span>
                </button>
              ))}
            </section>
          ) : null}
        </div>
      </aside>

      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-3">
          <button
            type="button"
            aria-label="Open menu"
            onClick={() => setNavOpen(true)}
            className="flex size-11 items-center justify-center rounded-full hover:bg-chip lg:hidden"
          >
            <Menu className="size-5" />
          </button>
          <button
            type="button"
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            onClick={() => setCollapsed(!collapsed)}
            className="hidden size-11 items-center justify-center rounded-full hover:bg-chip lg:flex"
          >
            {collapsed ? <PanelLeftOpen className="size-5" /> : <PanelLeftClose className="size-5" />}
          </button>

          {active && renaming === active.id ? (
            <form
              className="min-w-0 flex-1"
              onSubmit={(event) => {
                event.preventDefault();
                renameThread(active.id, renameValue);
                setRenaming(null);
              }}
            >
              <input
                autoFocus
                aria-label="Rename chat"
                value={renameValue}
                onChange={(event) => setRenameValue(event.target.value)}
                onBlur={() => {
                  renameThread(active.id, renameValue);
                  setRenaming(null);
                }}
                className="h-10 w-full bg-transparent text-sm font-medium outline-none"
              />
            </form>
          ) : (
            <button
              type="button"
              onClick={() => {
                if (!active) return;
                setRenaming(active.id);
                setRenameValue(active.title);
              }}
              className="min-w-0 flex-1 truncate text-left text-sm font-medium"
            >
              {active?.title ?? "Alder Pro"}
            </button>
          )}

          {active ? (
            <select
              aria-label="Project"
              value={active.projectId ?? ""}
              onChange={(event) => assignProject(active.id, event.target.value || null)}
              className="hidden h-10 max-w-40 truncate rounded-full bg-transparent px-2 text-sm text-muted sm:block"
            >
              <option value="">No project</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
          ) : null}

          {active && active.messages.length > 0 ? (
            <>
              <button
                type="button"
                aria-label="Copy chat"
                onClick={() => {
                  const text = active.messages
                    .map((message) => `${message.role === "user" ? "You" : "Alder"}: ${message.content}`)
                    .join("\n\n");
                  void navigator.clipboard.writeText(text).then(() => {
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1200);
                  });
                }}
                className="flex size-11 items-center justify-center rounded-full hover:bg-chip"
              >
                {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              </button>
              <button
                type="button"
                aria-label="Download markdown"
                onClick={() => downloadThread(active)}
                className="flex size-11 items-center justify-center rounded-full hover:bg-chip"
              >
                <Download className="size-4" />
              </button>
            </>
          ) : null}
        </header>

        <div ref={scroller} className="scroll-thin min-h-0 flex-1 overflow-y-auto">
          {!active || active.messages.length === 0 ? (
            <EmptyState onPick={(prompt) => submit(prompt)} />
          ) : (
            <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8">
              {active.messages.map((message) =>
                message.role === "user" ? (
                  <div key={message.id} className="ml-auto max-w-xl rounded-3xl bg-user px-4 py-3">
                    <p className="text-pretty whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  </div>
                ) : (
                  <div key={message.id} className="flex gap-3">
                    <span className="mt-1 flex size-7 shrink-0 items-center justify-center rounded-full bg-spruce text-mist">
                      <Leaf className="size-3.5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <MessageBody text={message.content} onOpenCanvas={(code) => {
                        setCanvas(code);
                        setCanvasTab("preview");
                      }} />
                    </div>
                  </div>
                ),
              )}
              {pending ? (
                <div className="flex items-center gap-3 text-sm text-muted">
                  <span className="flex size-7 items-center justify-center rounded-full bg-spruce text-mist">
                    <Leaf className="size-3.5" />
                  </span>
                  <span className="flex gap-1" aria-hidden>
                    <span className="dot size-1.5 rounded-full bg-muted" />
                    <span className="dot dot-2 size-1.5 rounded-full bg-muted" />
                    <span className="dot dot-3 size-1.5 rounded-full bg-muted" />
                  </span>
                  Alder is writing
                </div>
              ) : null}
            </div>
          )}
        </div>

        <div className="px-3 pb-4 sm:px-6">
          {error ? (
            <div className="mx-auto mb-2 flex max-w-3xl items-center justify-between gap-3 rounded-2xl bg-chip px-4 py-2 text-sm">
              <p>{error}</p>
              <button type="button" onClick={retry} className="shrink-0 font-medium text-spruce">
                Retry
              </button>
            </div>
          ) : null}
          <form
            onSubmit={(event) => {
              event.preventDefault();
              submit(draft);
            }}
            className="mx-auto max-w-3xl rounded-3xl border border-line bg-mist p-2 shadow-sm"
          >
            <textarea
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  event.currentTarget.form?.requestSubmit();
                }
              }}
              rows={2}
              placeholder="Ask Alder anything"
              className="max-h-40 w-full resize-none bg-transparent px-3 py-2 text-base outline-none placeholder:text-muted"
            />
            <div className="flex items-center gap-2 px-1 pb-1">
              <button
                type="button"
                aria-label="Attach a text note"
                onClick={() => fileRef.current?.click()}
                className="flex size-11 items-center justify-center rounded-full text-muted hover:bg-chip hover:text-ink"
              >
                <Paperclip className="size-4" />
              </button>
              <input
                ref={fileRef}
                type="file"
                accept=".txt,.md,.csv,.json,text/plain"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) onFile(file);
                  event.target.value = "";
                }}
              />
              <div className="relative">
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    setModeOpen((value) => !value);
                  }}
                  className="flex h-11 items-center gap-1 rounded-full px-3 text-sm font-medium hover:bg-chip"
                  aria-expanded={modeOpen}
                >
                  {modeMeta.label}
                  <ChevronDown className="size-4 text-muted" />
                </button>
                {modeOpen ? (
                  <div
                    className="absolute bottom-12 left-0 z-20 w-56 rounded-2xl border border-line bg-mist p-1 shadow-lg"
                    onClick={(event) => event.stopPropagation()}
                  >
                    {MODES.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setMode(item.id);
                          setModeOpen(false);
                        }}
                        className={
                          "flex w-full flex-col items-start rounded-xl px-3 py-2 text-left " +
                          (item.id === mode ? "bg-chip" : "hover:bg-chip")
                        }
                      >
                        <span className="text-sm font-medium">{item.label}</span>
                        <span className="text-xs text-muted">{item.hint}</span>
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
              <span className="ml-auto hidden text-xs text-muted sm:block">Enter to send</span>
              <button
                type="submit"
                disabled={pending || !draft.trim()}
                aria-label="Send"
                className="flex size-11 items-center justify-center rounded-full bg-spruce text-mist transition-transform duration-150 ease-out enabled:active:scale-[0.96] disabled:opacity-40"
              >
                <SendHorizontal className="size-4" />
              </button>
            </div>
          </form>
        </div>
      </div>

      {canvas ? (
        <section className="canvas-pane">
          <div className="flex h-14 items-center gap-2 border-b border-line px-3">
            <Eye className="size-4 text-spruce" />
            <h2 className="font-medium">Canvas</h2>
            <div className="ml-auto flex rounded-full bg-chip p-1 text-sm">
              <button
                type="button"
                onClick={() => setCanvasTab("preview")}
                className={"h-8 rounded-full px-3 " + (canvasTab === "preview" ? "bg-mist" : "")}
              >
                Preview
              </button>
              <button
                type="button"
                onClick={() => setCanvasTab("code")}
                className={"h-8 rounded-full px-3 " + (canvasTab === "code" ? "bg-mist" : "")}
              >
                Code
              </button>
            </div>
            <button
              type="button"
              aria-label="Close canvas"
              onClick={() => setCanvas(null)}
              className="flex size-11 items-center justify-center rounded-full hover:bg-chip"
            >
              <X className="size-4" />
            </button>
          </div>
          {canvasTab === "preview" ? (
            <iframe
              title="Canvas preview"
              sandbox="allow-scripts"
              srcDoc={canvas}
              className="h-full w-full flex-1 bg-mist"
            />
          ) : (
            <pre className="scroll-thin flex-1 overflow-auto p-4 text-sm leading-relaxed">{canvas}</pre>
          )}
        </section>
      ) : null}
    </div>
  );
}

function EmptyState({ onPick }: { onPick: (prompt: string) => void }) {
  return (
    <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col justify-center px-4 py-16">
      <p className="rise text-sm font-medium tracking-wide text-spruce uppercase">Alder Pro</p>
      <h1 className="rise rise-2 mt-3 font-serif text-4xl leading-tight text-balance text-ink sm:text-5xl">
        What should we shape?
      </h1>
      <p className="rise rise-3 mt-3 max-w-xl text-lg text-pretty text-muted">
        A quieter studio for drafts, decisions, and small things you can open on a canvas.
      </p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {STARTERS.map((starter) => (
          <button
            key={starter.title}
            type="button"
            onClick={() => onPick(starter.prompt)}
            className="rise rounded-3xl border border-line bg-mist px-4 py-4 text-left transition-transform duration-150 ease-out hover:bg-chip active:scale-[0.96]"
          >
            <span className="block font-medium">{starter.title}</span>
            <span className="mt-1 block text-sm text-muted">{starter.body}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
