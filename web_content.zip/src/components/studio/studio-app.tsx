import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  Copy,
  Gift,
  Heart,
  MessageCircle,
  Radio,
  Search,
  Share2,
  UserPlus,
  Users,
} from "lucide-react";
import { ChatLine, GoalMeter, ToggleRow } from "@/components/live/bits";
import { playChime, previewVoice, speak, unlockAudio } from "@/lib/live/feedback";
import {
  driftViewers,
  formatCount,
  isChatVisible,
  nextDemo,
  normalizeUsername,
  sampleChat,
  sampleGift,
  SEED,
  type LiveEvent,
  type Settings,
} from "@/lib/live/model";
import { postToFrames, relay } from "@/lib/live/relay";
import { loadStoredSettings, useStudio } from "@/lib/live/store";
import { MIX_VOICE, VOICES, voiceFor } from "@/lib/live/voices";

type Tab = "chat" | "sala" | "capas";

function overlayPath(
  kind: "chat" | "alert" | "goal" | "rank",
  roomId: string,
  settings: Settings,
  metric: "likes" | "follows" | "coins",
) {
  const params = new URLSearchParams({
    room: roomId,
    scale: settings.fontScale,
    hide: String(settings.hideAfter),
    joins: settings.showJoins ? "1" : "0",
    likes: settings.showLikes ? "1" : "0",
    mods: settings.modsOnly ? "1" : "0",
    blocked: settings.blocked,
  });
  if (kind === "goal") {
    const goal = metric === "likes" ? settings.likeGoal : metric === "follows" ? settings.followGoal : settings.coinGoal;
    params.set("metric", metric);
    params.set("goal", String(goal));
  }
  return `/overlay/${kind}?${params.toString()}`;
}

export function StudioApp() {
  const feed = useStudio((s) => s.feed);
  const stats = useStudio((s) => s.stats);
  const username = useStudio((s) => s.username);
  const phase = useStudio((s) => s.phase);
  const notice = useStudio((s) => s.notice);
  const host = useStudio((s) => s.host);
  const roomId = useStudio((s) => s.roomId);
  const settings = useStudio((s) => s.settings);
  const hidden = useStudio((s) => s.hidden);
  const answered = useStudio((s) => s.answered);
  const overlay = useStudio((s) => s.overlay);
  const metric = useStudio((s) => s.metric);
  const setUsername = useStudio((s) => s.setUsername);
  const setRoomId = useStudio((s) => s.setRoomId);
  const setPhase = useStudio((s) => s.setPhase);
  const patchSettings = useStudio((s) => s.patchSettings);
  const hydrateSettings = useStudio((s) => s.hydrateSettings);
  const add = useStudio((s) => s.add);
  const show = useStudio((s) => s.show);
  const setStats = useStudio((s) => s.setStats);
  const resetFeed = useStudio((s) => s.resetFeed);
  const hideUser = useStudio((s) => s.hideUser);
  const toggleAnswered = useStudio((s) => s.toggleAnswered);
  const setOverlay = useStudio((s) => s.setOverlay);
  const setMetric = useStudio((s) => s.setMetric);

  const [tab, setTab] = useState<Tab>("chat");
  const [query, setQuery] = useState("");
  const [signKey, setSignKey] = useState("");
  const [copied, setCopied] = useState("");
  const [listening, setListening] = useState(false);
  const [rail, setRail] = useState<"top" | "preguntas" | "sala">("top");
  const viewers = useRef(stats.viewers || 186);
  const scroller = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const seenSpeech = useRef(new Set<string>(SEED.map((event) => event.id)));

  useEffect(() => {
    const stored = loadStoredSettings();
    if (stored) hydrateSettings(stored);
    const id = localStorage.getItem("onda-room") || crypto.randomUUID();
    localStorage.setItem("onda-room", id);
    setRoomId(id);
    void relay(id, { action: "prime" });
  }, [hydrateSettings, setRoomId]);

  useEffect(() => {
    if (phase !== "demo") return;
    const id = window.setInterval(() => {
      const next = nextDemo(viewers.current);
      viewers.current = next.viewers;
      emit(next.event);
      if (Math.random() > 0.72) {
        const drift = driftViewers(viewers.current);
        viewers.current = drift.count;
        emit(drift);
      }
    }, 2800);
    return () => window.clearInterval(id);
  }, [phase, roomId]);

  useEffect(() => {
    if (!listening || !roomId) return;
    const source = new EventSource(`/api/live?room=${encodeURIComponent(roomId)}`);
    source.onmessage = (message) => {
      const event = JSON.parse(message.data) as LiveEvent;
      if (event.kind === "sync") {
        setStats({
          viewers: event.viewers,
          likes: event.likes,
          follows: event.follows,
          shares: event.shares,
          coins: event.coins,
          ranks: event.ranks,
        });
        broadcast();
        return;
      }
      if (event.kind === "status") {
        setPhase(event.phase, event.message, useStudio.getState().host);
        return;
      }
      if (event.replay) {
        show(event);
        return;
      }
      add(event);
      broadcast();
      voice(event);
    };
    return () => source.close();
  }, [listening, roomId, add, setPhase, setStats, show]);

  useEffect(() => {
    const el = scroller.current;
    if (!el || !stick.current) return;
    el.scrollTop = el.scrollHeight;
  }, [feed.length]);

  const lines = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return feed.filter((event) => {
      if (!isChatVisible(event, settings, hidden)) return false;
      if (!needle) return true;
      const blob =
        event.kind === "chat"
          ? `${event.user.nick} ${event.user.name} ${event.text}`
          : "user" in event
            ? `${event.user.nick} ${event.user.name} ${event.kind}`
            : "";
      return blob.toLowerCase().includes(needle);
    });
  }, [feed, settings, hidden, query]);

  const questions = feed.filter((event) => event.kind === "chat" && event.text.includes("?"));
  const activity = feed.filter(
    (event) => event.kind === "gift" || event.kind === "follow" || event.kind === "share" || event.kind === "join",
  );

  function broadcast() {
    const state = useStudio.getState();
    postToFrames({ snapshot: state.feed, stats: state.stats });
  }

  function emit(event: LiveEvent) {
    const state = useStudio.getState();
    state.add(event);
    broadcast();
    if (state.phase === "demo" && state.roomId) void relay(state.roomId, { action: "push", event });
    voice(event);
  }

  function voice(event: LiveEvent) {
    if (seenSpeech.current.has(event.id)) return;
    seenSpeech.current.add(event.id);
    const state = useStudio.getState();
    const choice = state.settings.voice;
    if (event.kind === "chat" && state.settings.ttsChat) {
      speak(`${event.user.nick} dice ${event.text}`, choice, event.user.name);
    }
    if (event.kind === "gift" && state.settings.ttsGifts) {
      speak(`${event.user.nick} envió ${event.gift}`, choice, event.user.name);
    }
    if (event.kind === "gift" && state.settings.sound) playChime("gift");
    if (event.kind === "follow" && state.settings.sound) playChime("follow");
  }

  async function connectLive() {
    unlockAudio();
    const name = normalizeUsername(username);
    if (!name) {
      setPhase("error", "Escribe un usuario válido, sin espacios. También puedes pegar el enlace del live.");
      return;
    }
    setListening(false);
    resetFeed([]);
    setPhase("connecting", `Buscando el live de @${name}…`, name);
    const response = await fetch("/api/live", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "start",
        roomId,
        username: name,
        signApiKey: signKey.trim() || undefined,
      }),
    });
    if (!response.ok) {
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      setPhase("error", payload?.error || "No se pudo iniciar la lectura.");
      return;
    }
    setListening(true);
  }

  async function backToDemo() {
    setListening(false);
    if (roomId) await relay(roomId, { action: "stop" });
    resetFeed(SEED);
    viewers.current = 186;
    setPhase("demo", "Sala demo otra vez. Los overlays siguen el ejemplo hasta que conectes un live.", "");
    if (roomId) void relay(roomId, { action: "prime" });
  }

  async function trySample(kind: "chat" | "gift") {
    const state = useStudio.getState();
    if (state.phase === "live" || state.phase === "connecting") {
      await relay(state.roomId, { action: "inject", kind });
      return;
    }
    emit(kind === "chat" ? sampleChat() : sampleGift());
  }

  async function copyLink(kind: "chat" | "alert" | "goal" | "rank") {
    const path = overlayPath(kind, roomId, settings, metric);
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${path}`);
      setCopied(kind);
      window.setTimeout(() => setCopied(""), 1600);
    } catch {
      setCopied("");
    }
  }

  const preview = overlayPath(overlay, roomId, settings, metric);
  const goal =
    metric === "likes" ? settings.likeGoal : metric === "follows" ? settings.followGoal : settings.coinGoal;
  const goalValue = metric === "likes" ? stats.likes : metric === "follows" ? stats.follows : stats.coins;

  const pill =
    phase === "live" ? "En vivo" : phase === "connecting" ? "Conectando" : phase === "error" ? "Sin live" : "Sala demo";
  const pillTone =
    phase === "live" || phase === "connecting"
      ? "border-signal text-signal"
      : phase === "error"
        ? "border-hot text-hot"
        : "border-line text-muted";

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg" onPointerDown={unlockAudio}>
      <header className="flex shrink-0 items-center gap-3 border-b border-line px-4 py-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="font-display text-3xl leading-none text-fg">Onda</h1>
            <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-xs font-semibold ${pillTone}`}>
              <span
                className={`h-2 w-2 rounded-full ${phase === "error" ? "bg-hot" : "bg-signal"} ${phase === "demo" ? "" : "onda-led"}`}
              />
              {pill}
              {host ? <span className="font-medium text-fg">@{host}</span> : null}
            </span>
          </div>
          <p className="mt-1 truncate text-sm text-muted">Chat, regalos y capas de un TikTok LIVE</p>
        </div>
        <div className="ml-auto hidden items-center gap-4 tabular-nums text-sm text-muted sm:flex">
          <span className="inline-flex items-center gap-1.5">
            <Users className="h-4 w-4 text-signal" />
            {formatCount(stats.viewers)}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Heart className="h-4 w-4 text-hot" />
            {formatCount(stats.likes)}
          </span>
        </div>
      </header>

      <form
        className="flex shrink-0 gap-2 border-b border-line px-3 py-3 lg:hidden"
        onSubmit={(event: FormEvent) => {
          event.preventDefault();
          void connectLive();
        }}
      >
        <input
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          placeholder="@usuario o enlace"
          aria-label="Usuario de TikTok"
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 text-fg placeholder:text-muted"
        />
        <button type="submit" className="h-11 shrink-0 rounded-md bg-signal px-3 text-sm font-semibold text-bg">
          Leer
        </button>
      </form>

      <div className="grid min-h-0 flex-1 lg:grid-cols-[300px_minmax(0,1fr)_300px]">
        <aside className={`${tab === "capas" ? "flex" : "hidden"} min-h-0 flex-col gap-4 overflow-y-auto border-line p-4 lg:flex lg:border-r`}>
          <form
            className="hidden flex-col gap-3 lg:flex"
            onSubmit={(event: FormEvent) => {
              event.preventDefault();
              void connectLive();
            }}
          >
            <div>
              <h2 className="text-sm font-semibold text-fg">Conexión</h2>
              <p className="mt-1 text-sm text-pretty text-muted">
                El usuario de quien esté emitiendo. Onda lee el chat público: comentarios, regalos, likes y follows.
              </p>
            </div>
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              placeholder="@usuario o enlace del live"
              aria-label="Usuario de TikTok"
              className="h-11 rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
            />
            <button
              type="submit"
              disabled={phase === "connecting"}
              className="h-11 rounded-md bg-signal text-sm font-semibold text-bg disabled:opacity-60"
            >
              {phase === "connecting" ? "Buscando el live…" : "Leer este live"}
            </button>
            {phase !== "demo" ? (
              <button type="button" onClick={() => void backToDemo()} className="h-11 rounded-md border border-line text-sm text-fg">
                Volver a la sala demo
              </button>
            ) : null}
            <details className="text-sm text-muted">
              <summary className="cursor-pointer text-fg">Clave Euler, opcional</summary>
              <p className="mt-2 text-pretty">
                El chat entra sin clave. Pégala solo si TikTok pide una firma extra. No se guarda.
              </p>
              <input
                value={signKey}
                onChange={(event) => setSignKey(event.target.value)}
                type="password"
                autoComplete="off"
                placeholder="Clave"
                aria-label="Clave de Euler Stream"
                className="mt-2 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
              />
            </details>
          </form>

          <div className="flex flex-col gap-2">
            <h2 className="text-sm font-semibold text-fg">Lectura</h2>
            <ToggleRow on={settings.ttsChat} label="Leer comentarios" onClick={() => patchSettings({ ttsChat: !settings.ttsChat })} />
            <ToggleRow on={settings.ttsGifts} label="Leer regalos" onClick={() => patchSettings({ ttsGifts: !settings.ttsGifts })} />
            <ToggleRow on={settings.sound} label="Sonido de alertas" onClick={() => patchSettings({ sound: !settings.sound })} />
            <VoicePicker value={settings.voice} onChange={(voice) => patchSettings({ voice })} />
            <ToggleRow on={settings.showJoins} label="Mostrar entradas" onClick={() => patchSettings({ showJoins: !settings.showJoins })} />
            <ToggleRow on={settings.showLikes} label="Mostrar likes" onClick={() => patchSettings({ showLikes: !settings.showLikes })} />
            <ToggleRow on={settings.modsOnly} label="Solo mods y subs" onClick={() => patchSettings({ modsOnly: !settings.modsOnly })} />
            <label className="text-sm text-muted">
              Palabras bloqueadas
              <input
                value={settings.blocked}
                onChange={(event) => patchSettings({ blocked: event.target.value })}
                placeholder="spoiler, insulto"
                className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-fg placeholder:text-muted"
              />
            </label>
            <label className="text-sm text-muted">
              {settings.hideAfter === 0 ? "Las líneas se quedan en pantalla" : `Las líneas se van a los ${settings.hideAfter}s`}
              <input
                type="range"
                min={0}
                max={30}
                value={settings.hideAfter}
                onChange={(event) => patchSettings({ hideAfter: Number(event.target.value) })}
                className="mt-2 w-full accent-signal"
              />
            </label>
            <div className="flex gap-2">
              {(["sm", "md", "lg"] as const).map((scale) => (
                <button
                  key={scale}
                  type="button"
                  onClick={() => patchSettings({ fontScale: scale })}
                  className={`h-11 flex-1 rounded-md border text-sm ${settings.fontScale === scale ? "border-signal text-signal" : "border-line text-muted"}`}
                >
                  {scale === "sm" ? "Chico" : scale === "md" ? "Medio" : "Grande"}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <h2 className="text-sm font-semibold text-fg">Capas para OBS</h2>
            <p className="text-sm text-pretty text-muted">
              Copia el enlace y pégalo como fuente de navegador o enlace. Deja esta pestaña abierta.
            </p>
            {(
              [
                ["chat", "Chat"],
                ["alert", "Alerta de regalo"],
                ["goal", "Meta"],
                ["rank", "Top regalos"],
              ] as const
            ).map(([kind, label]) => (
              <div key={kind} className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setOverlay(kind)}
                  className={`h-11 flex-1 rounded-md border px-3 text-left text-sm ${overlay === kind ? "border-signal text-fg" : "border-line text-muted"}`}
                >
                  {label}
                </button>
                <button
                  type="button"
                  onClick={() => void copyLink(kind)}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-line text-fg"
                  aria-label={`Copiar enlace de ${label}`}
                >
                  <Copy className="h-4 w-4" />
                </button>
              </div>
            ))}
            {copied ? <p className="text-sm text-signal">Enlace copiado.</p> : null}
            <div className="flex gap-2">
              {(["likes", "follows", "coins"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setMetric(item)}
                  className={`h-11 flex-1 rounded-md border text-sm ${metric === item ? "border-signal text-signal" : "border-line text-muted"}`}
                >
                  {item === "likes" ? "Likes" : item === "follows" ? "Follows" : "Monedas"}
                </button>
              ))}
            </div>
            <label className="text-sm text-muted">
              Meta de {metric === "likes" ? "likes" : metric === "follows" ? "follows" : "monedas"}
              <input
                type="number"
                min={1}
                max={10000000}
                value={goal}
                onChange={(event) => {
                  const value = Math.max(1, Number(event.target.value) || 1);
                  if (metric === "likes") patchSettings({ likeGoal: value });
                  else if (metric === "follows") patchSettings({ followGoal: value });
                  else patchSettings({ coinGoal: value });
                }}
                className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 tabular-nums text-fg"
              />
            </label>
            <div className="flex gap-2">
              <button type="button" onClick={() => void trySample("chat")} className="h-11 flex-1 rounded-md border border-line text-sm text-fg">
                Probar chat
              </button>
              <button type="button" onClick={() => void trySample("gift")} className="h-11 flex-1 rounded-md border border-line text-sm text-fg">
                Probar regalo
              </button>
            </div>
          </div>
        </aside>

        <section className={`${tab === "chat" ? "flex" : "hidden"} min-h-0 flex-col lg:flex`}>
          <div className="flex items-center gap-2 border-b border-line px-3 py-2">
            <Search className="h-4 w-4 text-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Filtrar el chat"
              aria-label="Filtrar el chat"
              className="h-11 min-w-0 flex-1 bg-transparent text-sm text-fg placeholder:text-muted"
            />
          </div>
          <p role="status" className="border-b border-line px-4 py-2 text-sm text-pretty text-muted">
            {notice}
          </p>
          <div
            ref={scroller}
            onScroll={() => {
              const el = scroller.current;
              if (!el) return;
              stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
            }}
            className="min-h-0 flex-1 overflow-y-auto px-2 py-2"
          >
            {lines.length === 0 ? (
              <p className="px-3 py-8 text-sm text-muted">Nada que mostrar con estos filtros.</p>
            ) : (
              lines.map((event) => (
                <ChatLine
                  key={event.id}
                  event={event}
                  onHide={hideUser}
                  scale={settings.fontScale}
                  place={
                    settings.voice === MIX_VOICE &&
                    (settings.ttsChat || settings.ttsGifts) &&
                    (event.kind === "chat" || event.kind === "gift")
                      ? voiceFor(MIX_VOICE, event.user.name).tag
                      : undefined
                  }
                />
              ))
            )}
          </div>
          <div className="hidden border-t border-line p-3 lg:block">
            <div className="scene-preview relative h-40 overflow-hidden rounded-lg border border-line">
              <iframe title="Vista previa de la capa" src={preview} onLoad={() => broadcast()} className="h-full w-full" />
            </div>
          </div>
        </section>

        <aside className={`${tab === "sala" ? "block" : "hidden"} min-h-0 overflow-y-auto border-line p-4 lg:block lg:border-l`}>
          <div className="grid grid-cols-2 gap-2">
            <Stat icon={<Users className="h-4 w-4 text-signal" />} label="Viendo" value={formatCount(stats.viewers)} />
            <Stat icon={<Heart className="h-4 w-4 text-hot" />} label="Likes" value={formatCount(stats.likes)} />
            <Stat icon={<UserPlus className="h-4 w-4 text-signal" />} label="Follows" value={formatCount(stats.follows)} />
            <Stat icon={<Gift className="h-4 w-4 text-hot" />} label="Monedas" value={formatCount(stats.coins)} />
          </div>
          <div className="mt-4 rounded-lg border border-line bg-surface p-3">
            <GoalMeter
              label={metric === "likes" ? "Meta de likes" : metric === "follows" ? "Meta de follows" : "Meta de monedas"}
              value={goalValue}
              goal={goal}
            />
          </div>
          <div className="mt-4 flex gap-2">
            {(
              [
                ["top", "Top"],
                ["preguntas", "Preguntas"],
                ["sala", "Sala"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setRail(id)}
                className={`h-11 flex-1 rounded-md border text-sm ${rail === id ? "border-signal text-fg" : "border-line text-muted"}`}
              >
                {label}
                {id === "preguntas" ? ` ${questions.length}` : ""}
              </button>
            ))}
          </div>
          <div className="mt-3 flex flex-col gap-2">
            {rail === "top"
              ? stats.ranks.slice(0, 5).map((row, index) => (
                  <div key={row.name} className="flex items-center gap-3 rounded-md border border-line px-3 py-2">
                    <span className={`w-5 tabular-nums font-semibold ${index === 0 ? "text-signal" : "text-muted"}`}>
                      {index + 1}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm">{row.nick}</span>
                    <span className="tabular-nums text-sm text-muted">{formatCount(row.coins)}</span>
                  </div>
                ))
              : null}
            {rail === "top" && stats.ranks.length === 0 ? <p className="text-sm text-muted">Todavía no entra un regalo.</p> : null}
            {rail === "preguntas"
              ? questions
                  .slice()
                  .reverse()
                  .map((event) =>
                    event.kind === "chat" ? (
                      <button
                        key={event.id}
                        type="button"
                        onClick={() => toggleAnswered(event.id)}
                        className={`rounded-md border border-line px-3 py-3 text-left ${answered.includes(event.id) ? "opacity-50" : ""}`}
                      >
                        <span className="text-sm font-semibold text-fg">{event.user.nick}</span>
                        <span className="mt-1 block text-sm text-pretty text-fg">{event.text}</span>
                      </button>
                    ) : null,
                  )
              : null}
            {rail === "preguntas" && questions.length === 0 ? (
              <p className="text-sm text-muted">Las preguntas con ? aparecen aquí.</p>
            ) : null}
            {rail === "sala"
              ? activity
                  .slice()
                  .reverse()
                  .slice(0, 12)
                  .map((event) => (
                    <div key={event.id} className="flex items-center gap-2 text-sm text-fg">
                      {event.kind === "gift" ? <Gift className="h-4 w-4 text-hot" /> : null}
                      {event.kind === "follow" ? <UserPlus className="h-4 w-4 text-signal" /> : null}
                      {event.kind === "share" ? <Share2 className="h-4 w-4 text-muted" /> : null}
                      {event.kind === "join" ? <Radio className="h-4 w-4 text-muted" /> : null}
                      <span className="min-w-0 truncate">
                        {"user" in event ? event.user.nick : ""}{" "}
                        <span className="text-muted">
                          {event.kind === "gift"
                            ? event.gift
                            : event.kind === "follow"
                              ? "follow"
                              : event.kind === "share"
                                ? "share"
                                : "entró"}
                        </span>
                      </span>
                    </div>
                  ))
              : null}
          </div>
          <p className="mt-4 flex items-start gap-2 text-sm text-pretty text-muted">
            <MessageCircle className="mt-0.5 h-4 w-4 shrink-0" />
            En la sala demo los comentarios son de prueba. Al conectar, se sustituyen por el live.
          </p>
          {phase !== "demo" ? (
            <button type="button" onClick={() => void backToDemo()} className="mt-3 h-11 w-full rounded-md border border-line text-sm lg:hidden">
              Volver a la sala demo
            </button>
          ) : null}
        </aside>
      </div>

      <nav className="grid shrink-0 grid-cols-3 border-t border-line lg:hidden">
        {(
          [
            ["chat", "Chat"],
            ["sala", "Sala"],
            ["capas", "Capas"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`h-14 text-sm font-semibold ${tab === id ? "text-signal" : "text-muted"}`}
          >
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}

function VoicePicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const selected = value === MIX_VOICE ? null : voiceFor(value);
  const choices = [{ id: MIX_VOICE, label: "Varias" }, ...VOICES.map((voice) => ({ id: voice.id, label: voice.tag }))];
  return (
    <div className="mt-1">
      <p className="text-sm font-semibold text-fg">Acentos</p>
      <p className="mt-1 text-sm text-pretty text-muted">
        {selected
          ? `${selected.name} lee todo, con acento de ${selected.place}.`
          : "Cada persona conserva un acento. Prueba varias para oírlos."}
      </p>
      <div className="mt-2 grid grid-cols-2 gap-2" role="group" aria-label="Acento de la voz">
        {choices.map((choice) => (
          <button
            key={choice.id}
            type="button"
            aria-pressed={value === choice.id}
            onClick={() => onChange(choice.id)}
            className={`h-11 rounded-md border px-2 text-sm ${value === choice.id ? "border-signal text-signal" : "border-line text-muted"}`}
          >
            {choice.label}
          </button>
        ))}
      </div>
      <button
        type="button"
        onClick={() => {
          unlockAudio();
          previewVoice(value);
        }}
        className="mt-2 h-11 w-full rounded-md border border-line text-sm text-fg"
      >
        Probar voz
      </button>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-line bg-surface px-3 py-3">
      <div className="flex items-center gap-1.5 text-xs text-muted">
        {icon}
        {label}
      </div>
      <p className="mt-1 text-xl font-semibold tabular-nums text-fg">{value}</p>
    </div>
  );
}
