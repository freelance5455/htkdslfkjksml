import { Check, Circle, Loader2, X } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useStudio } from "@/lib/studio/store";
import { TransferBar } from "./transfer-bar";

export function PipelinePanel() {
  const pipeline = useStudio((s) => s.pipeline);
  const convertIndex = useStudio((s) => s.convertIndex);
  const convertTotal = useStudio((s) => s.convertTotal);
  const busyLabel = useStudio((s) => s.busyLabel);
  const transfer = useStudio((s) => s.transfer);
  const visible = pipeline.some((s) => s.status !== "idle");
  if (!visible) return null;

  const overall = Math.round(
    pipeline.reduce((sum, stage) => {
      if (stage.status === "done") return sum + 100;
      if (stage.status === "active") return sum + (stage.percent ?? 0);
      return sum;
    }, 0) / pipeline.length,
  );

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-medium tracking-tight">Processing</h2>
          <p className="mt-1 text-sm text-muted-foreground">{busyLabel || "Working through the voice pipeline"}</p>
        </div>
        <span className="font-mono text-sm tabular-nums text-foreground">{overall}%</span>
      </div>
      <Progress className="mt-4 h-2" value={overall} />
      {transfer && (transfer.label.includes("Upload") || transfer.label.includes("Reading")) ? (
        <div className="mt-4">
          <TransferBar progress={transfer} />
        </div>
      ) : null}
      {convertTotal > 0 ? (
        <p className="mt-2 font-mono text-xs text-muted-foreground tabular-nums">
          Converting segment {Math.min(convertIndex, convertTotal)} of {convertTotal} ·{" "}
          {Math.round((Math.min(convertIndex, convertTotal) / convertTotal) * 100)}%
        </p>
      ) : null}
      <ol className="mt-5 grid gap-1 sm:grid-cols-2">
        {pipeline.map((stage) => (
          <li key={stage.id} className="flex items-start gap-2 rounded-md px-2 py-1.5 text-sm">
            <StatusIcon status={stage.status} />
            <span className="min-w-0 flex-1">
              <span className={stage.status === "idle" ? "text-muted-foreground" : "text-foreground"}>
                {stage.label}
              </span>
              {stage.detail && stage.status === "active" ? (
                <span className="mt-0.5 block text-xs text-muted-foreground">{stage.detail}</span>
              ) : null}
            </span>
            <span
              className={`font-mono text-xs tabular-nums ${
                stage.status === "idle" ? "text-muted-foreground/40" : "text-muted-foreground"
              }`}
            >
              {stagePercentLabel(stage.status, stage.percent)}
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}

function stagePercentLabel(status: "idle" | "active" | "done" | "error", percent: number): string {
  if (status === "idle") return "0%";
  if (status === "done") return "100%";
  if (status === "error") return `${Math.round(percent || 0)}%`;
  return `${Math.round(percent || 0)}%`;
}

function StatusIcon({ status }: { status: "idle" | "active" | "done" | "error" }) {
  if (status === "done") return <Check className="mt-0.5 size-3.5 text-success" />;
  if (status === "active") return <Loader2 className="mt-0.5 size-3.5 animate-spin text-accent" />;
  if (status === "error") return <X className="mt-0.5 size-3.5 text-destructive" />;
  return <Circle className="mt-0.5 size-3.5 text-muted-foreground/40" />;
}
