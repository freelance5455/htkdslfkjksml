import { speakerColorVar } from "@/lib/studio/cast";
import type { AnalysisResult } from "@/lib/studio/types";
import { formatTimecode } from "@/lib/utils";

export function EmotionTimeline({ analysis }: { analysis: AnalysisResult }) {
  const duration = Math.max(0.1, analysis.segments.at(-1)?.end ?? 1);
  const index = Object.fromEntries(analysis.speakers.map((s, i) => [s.speaker_id, i]));
  const spoken = analysis.segments.filter((s) => !s.is_silence);

  return (
    <section className="rounded-xl bg-card p-5 shadow-border sm:p-6">
      <h2 className="font-display text-xl font-medium tracking-tight">Emotion</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Detected from the meaning of each line and the scene, then used to drive delivery.
      </p>
      <div className="relative mt-5 h-10 overflow-hidden rounded-md bg-secondary">
        {analysis.segments.map((seg) => {
          const left = (seg.start / duration) * 100;
          const width = Math.max(0.4, ((seg.end - seg.start) / duration) * 100);
          if (seg.is_silence) return null;
          return (
            <span
              key={seg.id}
              title={`${seg.emotion} · ${seg.emotion_intensity}`}
              className="absolute top-1 bottom-1 rounded-sm"
              style={{
                left: `${left}%`,
                width: `${width}%`,
                background: speakerColorVar(index[seg.speaker_id] ?? 0),
                opacity: intensityOpacity(seg.emotion_intensity),
              }}
            />
          );
        })}
      </div>
      <ul className="mt-4 max-h-80 space-y-2 overflow-y-auto pr-1">
        {spoken.map((seg) => {
          const who = analysis.speakers.find((s) => s.speaker_id === seg.speaker_id);
          return (
            <li key={seg.id} className="flex gap-3 text-sm">
              <span className="w-20 shrink-0 font-mono text-xs text-muted-foreground tabular-nums">
                {formatTimecode(seg.start)}
              </span>
              <span
                className="mt-1 size-2 shrink-0 rounded-full"
                style={{ background: speakerColorVar(index[seg.speaker_id] ?? 0) }}
              />
              <div className="min-w-0">
                <p className="font-medium">
                  {who?.display_name ?? seg.speaker_id}
                  <span className="ml-2 font-normal text-muted-foreground">
                    {seg.emotion} · {seg.emotion_intensity.replace("_", " ")}
                  </span>
                </p>
                <p className="truncate text-muted-foreground">{seg.text}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function intensityOpacity(level: string): number {
  switch (level) {
    case "very_low":
      return 0.35;
    case "low":
      return 0.5;
    case "high":
      return 0.88;
    case "very_high":
      return 1;
    default:
      return 0.7;
  }
}
