import React, { useState } from 'react';
import { X, Sparkles, FolderPlus, Gamepad2, Globe, FileCode } from 'lucide-react';
import { Project, ProjectCategory } from '../types';

interface NewProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (project: Project) => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  isOpen,
  onClose,
  onCreate,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ProjectCategory>('game');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    let files = [];
    if (category === 'game') {
      files = [
        {
          id: 'f_html_' + Date.now(),
          name: 'index.html',
          path: 'index.html',
          language: 'html' as const,
          content: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${name}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <canvas id="gameCanvas" width="600" height="400"></canvas>
  <script src="script.js"></script>
</body>
</html>`,
        },
        {
          id: 'f_css_' + Date.now(),
          name: 'style.css',
          path: 'style.css',
          language: 'css' as const,
          content: `body {
  margin: 0;
  background: #090e1a;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
canvas {
  background: #050811;
  border: 2px solid #00f0ff;
  border-radius: 8px;
}`,
        },
        {
          id: 'f_js_' + Date.now(),
          name: 'script.js',
          path: 'script.js',
          language: 'javascript' as const,
          content: `const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let x = canvas.width / 2;
let y = canvas.height / 2;

function render() {
  ctx.fillStyle = '#050811';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = '#00f0ff';
  ctx.beginPath();
  ctx.arc(x, y, 20, 0, Math.PI * 2);
  ctx.fill();

  requestAnimationFrame(render);
}
requestAnimationFrame(render);`,
        },
      ];
    } else if (category === 'python') {
      files = [
        {
          id: 'f_py_' + Date.now(),
          name: 'main.py',
          path: 'main.py',
          language: 'python' as const,
          content: `# ${name}
print("Hello from CODEVERSE Python Studio!")

data = [x * 2 for x in range(1, 10)]
print("Processed Dataset:", data)
`,
        },
      ];
    } else {
      files = [
        {
          id: 'f_html_' + Date.now(),
          name: 'index.html',
          path: 'index.html',
          language: 'html' as const,
          content: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${name}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>Welcome to ${name}</h1>
    <p>Start developing your web application in CODEVERSE.</p>
    <button id="btn">Click Me</button>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
        },
        {
          id: 'f_css_' + Date.now(),
          name: 'style.css',
          path: 'style.css',
          language: 'css' as const,
          content: `body {
  margin: 0;
  font-family: system-ui, sans-serif;
  background: #090e1a;
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.container {
  text-align: center;
  padding: 30px;
  background: #111827;
  border-radius: 12px;
  border: 1px solid #1e293b;
}
button {
  background: #00f0ff;
  border: none;
  padding: 10px 20px;
  font-weight: bold;
  border-radius: 6px;
  cursor: pointer;
  margin-top: 15px;
}`,
        },
        {
          id: 'f_js_' + Date.now(),
          name: 'script.js',
          path: 'script.js',
          language: 'javascript' as const,
          content: `document.getElementById('btn').addEventListener('click', () => {
  console.log('Button clicked!');
  alert('Hello from ${name}!');
});`,
        },
      ];
    }

    const newProject: Project = {
      id: 'proj_' + Date.now(),
      name: name.trim(),
      description: description.trim() || 'A project built in CODEVERSE Studio',
      category,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      activeFileId: files[0]?.id || '',
      files,
    };

    onCreate(newProject);
    setName('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#0f172a] border border-cyan-500/40 rounded-xl max-w-md w-full p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <FolderPlus className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Create New Project</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="text-slate-400 hover:text-white p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="text-slate-300 font-semibold block mb-1">Project Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Cyber Glider 2099"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-[#090d18] text-white p-2.5 rounded-lg border border-slate-700 outline-hidden font-mono focus:border-cyan-400 text-xs"
            />
          </div>

          <div>
            <label className="text-slate-300 font-semibold block mb-1">Project Type</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { cat: 'game', label: '2D Game', icon: Gamepad2 },
                { cat: 'web', label: 'Web App', icon: Globe },
                { cat: 'python', label: 'Python Lab', icon: FileCode },
              ].map(opt => {
                const Icon = opt.icon;
                return (
                  <button
                    type="button"
                    key={opt.cat}
                    onClick={() => setCategory(opt.cat as ProjectCategory)}
                    className={`p-2.5 rounded-lg border text-center flex flex-col items-center gap-1.5 transition-colors ${
                      category === opt.cat
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-semibold block mb-1">Description (Optional)</label>
            <input
              type="text"
              placeholder="Short description..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full bg-[#090d18] text-white p-2.5 rounded-lg border border-slate-700 outline-hidden text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all shadow-md shadow-cyan-500/20"
            >
              Create Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
