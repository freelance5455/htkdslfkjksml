import React, { useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard,
  PlusSquare,
  Package,
  ShoppingCart,
  Users,
  Tags,
  History,
  Settings,
  LogOut,
  Menu,
  X,
  ArrowUpRight,
  ArrowLeft,
  Sparkles,
  Trash2,
  Loader2,
  Check,
} from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { seedInitialCatalogIfEmpty } from '../lib/catalogDefaults';
import { useAuth } from '../context/AuthContext';
import { useStoreData } from '../context/StoreDataContext';
import { AdminSection, Order, UserProfile } from '../types/store';
import { formatCurrency, slugify } from '../lib/formatters';
import { AdminProductManager } from './admin/AdminProductManager';
import { AdminOrdersPanel } from './admin/AdminOrdersPanel';
import { AdminCustomerManager } from './admin/AdminCustomerManager';

interface AdminDashboardViewProps {
  onBackToStore: () => void;
  onLogoutComplete: () => void;
}

const SIDEBAR_ITEMS: { id: AdminSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'add-product', label: 'Add Products', icon: PlusSquare },
  { id: 'all-products', label: 'All Products', icon: Package },
  { id: 'manage-orders', label: 'Manage Orders', icon: ShoppingCart },
  { id: 'customers', label: 'Customers', icon: Users },
  { id: 'categories', label: 'Product Categories', icon: Tags },
  { id: 'order-history', label: 'Order History', icon: History },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function AdminDashboardView({
  onBackToStore,
  onLogoutComplete,
}: AdminDashboardViewProps) {
  const { user, logout } = useAuth();
  const { products, categories, settings, notify } = useStoreData();

  const [activeSection, setActiveSection] = useState<AdminSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<UserProfile[]>([]);
  const [seeding, setSeeding] = useState(false);

  // Category form state
  const [catName, setCatName] = useState('');
  const [catDescription, setCatDescription] = useState('');
  const [savingCat, setSavingCat] = useState(false);

  // Settings form state
  const [storeName, setStoreName] = useState(settings.storeName);
  const [storeAddress, setStoreAddress] = useState(
    settings.storeAddress || 'Assam Badarpur Fashion Hub'
  );
  const [supportEmail, setSupportEmail] = useState(settings.supportEmail);
  const [announcementText, setAnnouncementText] = useState(settings.announcementText);
  const [freeThreshold, setFreeThreshold] = useState(String(settings.freeShippingThreshold));
  const [shippingFee, setShippingFee] = useState(String(settings.standardShippingFee));
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    setStoreName(settings.storeName);
    setStoreAddress(settings.storeAddress || 'Assam Badarpur Fashion Hub');
    setSupportEmail(settings.supportEmail);
    setAnnouncementText(settings.announcementText);
    setFreeThreshold(String(settings.freeShippingThreshold));
    setShippingFee(String(settings.standardShippingFee));
  }, [settings]);

  // Real-time orders & customers subscription for Admin
  useEffect(() => {
    const unsubOrders = onSnapshot(
      query(collection(db, 'orders'), orderBy('createdAt', 'desc')),
      (snap) => {
        setOrders(snap.docs.map((d) => ({ ...d.data(), id: d.id } as Order)));
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'orders');
      }
    );

    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        setCustomers(
          snap.docs.map((d) => ({ ...d.data(), uid: d.data().uid || d.id } as UserProfile))
        );
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'users');
      }
    );

    return () => {
      unsubOrders();
      unsubUsers();
    };
  }, []);

  // Auto-seed starter collection if catalog is completely empty on first admin entry
  useEffect(() => {
    let cancelled = false;
    const autoSeed = async () => {
      if (products.length === 0 && categories.length === 0) {
        try {
          const res = await seedInitialCatalogIfEmpty();
          if (!cancelled && (res.seededProducts > 0 || res.seededCategories > 0)) {
            notify(
              `Starter catalog published (${res.seededProducts} products, ${res.seededCategories} categories).`,
              'success'
            );
          }
        } catch {
          // Handled by manual button if needed
        }
      }
    };
    const timer = setTimeout(autoSeed, 800);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [products.length, categories.length]);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalOrders = orders.length;
    const pendingOrders = orders.filter(
      (o) =>
        o.status === 'Pending' ||
        o.status === 'Confirmed' ||
        o.status === 'Processing' ||
        o.status === 'Shipped'
    ).length;
    const deliveredOrders = orders.filter((o) => o.status === 'Delivered').length;
    const totalSales = orders
      .filter((o) => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + (o.totalAmount || 0), 0);

    return {
      totalProducts,
      totalOrders,
      pendingOrders,
      deliveredOrders,
      totalSales,
    };
  }, [products, orders]);

  const handleManualSeed = async () => {
    setSeeding(true);
    try {
      const res = await seedInitialCatalogIfEmpty();
      if (res.seededProducts === 0 && res.seededCategories === 0) {
        notify('Catalog already contains products and categories.', 'info');
      } else {
        notify(
          `Published ${res.seededProducts} products and ${res.seededCategories} categories.`,
          'success'
        );
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to seed catalog.', 'error');
    } finally {
      setSeeding(false);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = catName.trim();
    if (clean.length < 2) return;
    setSavingCat(true);
    try {
      const slug = slugify(clean);
      const id = `cat-${slug}-${Date.now().toString(36).slice(-4)}`;
      await setDoc(doc(db, 'categories', id), {
        id,
        name: clean.slice(0, 60),
        slug: slug.slice(0, 64),
        description: catDescription.trim().slice(0, 240),
        displayOrder: categories.length + 1,
        isActive: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setCatName('');
      setCatDescription('');
      notify(`Category "${clean}" created.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'categories');
    } finally {
      setSavingCat(false);
    }
  };

  const handleToggleCategory = async (catId: string, nextActive: boolean) => {
    try {
      await updateDoc(doc(db, 'categories', catId), {
        isActive: nextActive,
        updatedAt: serverTimestamp(),
      });
      notify('Category visibility updated.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `categories/${catId}`);
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    try {
      await deleteDoc(doc(db, 'categories', catId));
      notify('Category deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `categories/${catId}`);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await setDoc(
        doc(db, 'settings', 'storeConfig'),
        {
          storeName: storeName.trim().slice(0, 80) || 'Fashion Hub',
          storeAddress: storeAddress.trim().slice(0, 200) || 'Assam Badarpur Fashion Hub',
          supportEmail: supportEmail.trim().slice(0, 150) || 'concierge@fashionhub-atelier.com',
          announcementText: announcementText.trim().slice(0, 140),
          freeShippingThreshold: Math.max(0, Number(freeThreshold) || 0),
          standardShippingFee: Math.max(0, Number(shippingFee) || 0),
          onlinePaymentEnabled: false,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      notify('Store settings saved.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings/storeConfig');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    onLogoutComplete();
  };

  const selectSection = (section: AdminSection) => {
    setActiveSection(section);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen w-full bg-neutral-50 flex flex-col lg:flex-row">
      {/* Mobile Admin Header */}
      <div className="lg:hidden bg-white border-b border-neutral-200 px-4 h-14 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open admin menu"
            className="p-2 -ml-2 text-[#0A0A0A]"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display text-xl font-semibold tracking-wider">
            FASHION HUB ADMIN
          </span>
        </div>
        <button
          type="button"
          onClick={onBackToStore}
          className="text-xs font-medium text-neutral-600 hover:text-[#0A0A0A]"
        >
          Storefront →
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/45"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-72 bg-[#0A0A0A] text-white h-full flex flex-col p-5">
            <div className="flex items-center justify-between pb-6 border-b border-white/10">
              <span className="font-display text-xl font-semibold tracking-widest">
                FASHION HUB
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 py-5 space-y-1">
              {SIDEBAR_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectSection(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      active
                        ? 'bg-white text-[#0A0A0A] font-semibold'
                        : 'text-neutral-300 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <button
              type="button"
              onClick={handleLogout}
              className="flex items-center gap-3 px-3.5 py-2.5 text-xs font-medium text-neutral-300 hover:text-white hover:bg-white/10 rounded-lg cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </aside>
        </div>
      )}

      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:flex w-64 bg-[#0A0A0A] text-white flex-col shrink-0 sticky top-0 h-screen">
        <div className="px-6 py-6 border-b border-white/10">
          <p className="font-display text-2xl font-semibold tracking-[0.14em]">
            FASHION HUB
          </p>
          <p className="text-[11px] text-neutral-400 mt-1 truncate">
            {user?.email}
          </p>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => selectSection(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  active
                    ? 'bg-white text-[#0A0A0A] font-semibold'
                    : 'text-neutral-300 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 space-y-1.5">
          <button
            type="button"
            onClick={onBackToStore}
            className="w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-neutral-300 hover:text-white hover:bg-white/10 rounded-lg cursor-pointer"
          >
            <span>View Storefront</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-medium text-neutral-300 hover:text-white hover:bg-white/10 rounded-lg cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content stretched full-width */}
      <main className="flex-1 min-w-0 p-5 sm:p-8 lg:p-10 w-full">
        {activeSection !== 'dashboard' && (
          <div className="mb-6 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setActiveSection('dashboard')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-neutral-300 bg-white text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <button
              type="button"
              onClick={onBackToStore}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-neutral-300 bg-white text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
            >
              <span>Back to Store</span>
            </button>
          </div>
        )}

        {activeSection === 'dashboard' && (
          <div className="space-y-8 w-full">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-1">
                  {settings.storeAddress || 'Assam Badarpur Fashion Hub'}
                </p>
                <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#0A0A0A]">
                  Admin Control Center
                </h1>
              </div>

              <div className="flex flex-wrap gap-2.5">
                {products.length === 0 && (
                  <button
                    type="button"
                    disabled={seeding}
                    onClick={handleManualSeed}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 cursor-pointer"
                  >
                    {seeding ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    <span>Publish Starter Collection</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setActiveSection('customers')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 cursor-pointer"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Manage Customers ({customers.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSection('add-product')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer"
                >
                  <PlusSquare className="w-3.5 h-3.5" />
                  <span>Add New Item</span>
                </button>
              </div>
            </div>

            {/* 5 Dashboard KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
              <div className="bg-white border border-neutral-200 p-5">
                <p className="text-xs text-neutral-500 mb-2">Total Products</p>
                <p className="text-2xl font-semibold text-[#0A0A0A] tabular-nums">
                  {stats.totalProducts}
                </p>
              </div>
              <div className="bg-white border border-neutral-200 p-5">
                <p className="text-xs text-neutral-500 mb-2">Total Orders</p>
                <p className="text-2xl font-semibold text-[#0A0A0A] tabular-nums">
                  {stats.totalOrders}
                </p>
              </div>
              <div className="bg-white border border-neutral-200 p-5">
                <p className="text-xs text-neutral-500 mb-2">Pending Orders</p>
                <p className="text-2xl font-semibold text-[#0A0A0A] tabular-nums">
                  {stats.pendingOrders}
                </p>
              </div>
              <div className="bg-white border border-neutral-200 p-5">
                <p className="text-xs text-neutral-500 mb-2">Delivered Orders</p>
                <p className="text-2xl font-semibold text-[#0A0A0A] tabular-nums">
                  {stats.deliveredOrders}
                </p>
              </div>
              <div className="bg-white border border-neutral-200 p-5">
                <p className="text-xs text-neutral-500 mb-2">Total Sales</p>
                <p className="text-2xl font-semibold text-[#0A0A0A] tabular-nums">
                  {formatCurrency(stats.totalSales)}
                </p>
              </div>
            </div>

            {/* Recent Orders Snapshot */}
            <div className="bg-white border border-neutral-200">
              <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
                <h2 className="text-sm font-semibold text-[#0A0A0A]">
                  Recent Customer Orders
                </h2>
                <button
                  type="button"
                  onClick={() => setActiveSection('manage-orders')}
                  className="text-xs font-semibold text-[#0A0A0A] hover:underline cursor-pointer"
                >
                  Manage All Orders →
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[680px]">
                  <thead>
                    <tr className="border-b border-neutral-200 bg-neutral-50 text-[11px] uppercase tracking-wider text-neutral-500">
                      <th className="py-3 px-4 font-semibold">Order ID</th>
                      <th className="py-3 px-4 font-semibold">Customer</th>
                      <th className="py-3 px-4 font-semibold">Items</th>
                      <th className="py-3 px-4 font-semibold">Total</th>
                      <th className="py-3 px-4 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 text-xs">
                    {orders.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-10 text-center text-neutral-500">
                          No orders placed yet. New customer orders appear here in real time.
                        </td>
                      </tr>
                    ) : (
                      orders.slice(0, 6).map((order) => (
                        <tr key={order.id} className="hover:bg-neutral-50">
                          <td className="py-3 px-4 font-mono font-medium">
                            {order.orderNumber}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-[#0A0A0A]">{order.customerName}</div>
                            <div className="text-[11px] text-neutral-500">
                              {order.phone}{order.location ? ` · ${order.location}` : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 max-w-[220px] truncate">
                            {order.primaryProductName} ({order.totalQuantity})
                          </td>
                          <td className="py-3 px-4 font-semibold tabular-nums">
                            {formatCurrency(order.totalAmount)}
                          </td>
                          <td className="py-3 px-4 font-medium">{order.status}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'add-product' && (
          <AdminProductManager
            mode="add"
            onSwitchToList={() => setActiveSection('all-products')}
          />
        )}

        {activeSection === 'all-products' && (
          <AdminProductManager
            mode="list"
            onSwitchToList={() => setActiveSection('all-products')}
            onSwitchToAdd={() => setActiveSection('add-product')}
          />
        )}

        {activeSection === 'manage-orders' && (
          <AdminOrdersPanel orders={orders} mode="manage" />
        )}

        {activeSection === 'order-history' && (
          <AdminOrdersPanel orders={orders} mode="history" />
        )}

        {activeSection === 'customers' && (
          <AdminCustomerManager customers={customers} orders={orders} />
        )}

        {activeSection === 'categories' && (
          <div className="space-y-6 w-full max-w-4xl">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A]">
                Product Categories ({categories.length})
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Organize clothing collections displayed across storefront filter tabs.
              </p>
            </div>

            <form
              onSubmit={handleAddCategory}
              className="bg-white border border-neutral-200 p-5 flex flex-col sm:flex-row gap-3"
            >
              <input
                type="text"
                required
                maxLength={60}
                value={catName}
                onChange={(e) => setCatName(e.target.value)}
                placeholder="Category name (e.g. Tailored Blazers)"
                className="flex-1 px-3.5 py-2 text-xs border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
              <input
                type="text"
                maxLength={240}
                value={catDescription}
                onChange={(e) => setCatDescription(e.target.value)}
                placeholder="Short description (optional)"
                className="flex-1 px-3.5 py-2 text-xs border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
              <button
                type="submit"
                disabled={savingCat}
                className="px-5 py-2 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer whitespace-nowrap"
              >
                {savingCat ? 'Adding...' : 'Add Category'}
              </button>
            </form>

            <div className="bg-white border border-neutral-200 divide-y divide-neutral-100">
              {categories.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500">
                  No categories added yet.
                </div>
              ) : (
                categories.map((cat) => (
                  <div
                    key={cat.id}
                    className="p-4 flex items-center justify-between gap-4 text-xs"
                  >
                    <div>
                      <p className="font-semibold text-[#0A0A0A]">{cat.name}</p>
                      {cat.description && (
                        <p className="text-neutral-500 mt-0.5">{cat.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleCategory(cat.id, !cat.isActive)}
                        className={`px-3 py-1 rounded-full border text-[11px] font-medium cursor-pointer ${
                          cat.isActive
                            ? 'border-[#0A0A0A] text-[#0A0A0A]'
                            : 'border-neutral-300 text-neutral-400'
                        }`}
                      >
                        {cat.isActive ? 'Visible' : 'Hidden'}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCategory(cat.id)}
                        aria-label={`Delete ${cat.name}`}
                        className="p-1.5 text-neutral-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeSection === 'settings' && (
          <div className="space-y-6 w-full max-w-3xl">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A]">
                Storefront Settings
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Configure store identity, store address, shipping thresholds, and payment gateway status.
              </p>
            </div>

            <form
              onSubmit={handleSaveSettings}
              className="bg-white border border-neutral-200 p-6 space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Store Name
                </label>
                <input
                  type="text"
                  required
                  maxLength={80}
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Store Flagship Address
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={storeAddress}
                  onChange={(e) => setStoreAddress(e.target.value)}
                  placeholder="Assam Badarpur Fashion Hub"
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Support Email
                </label>
                <input
                  type="email"
                  required
                  maxLength={150}
                  value={supportEmail}
                  onChange={(e) => setSupportEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Top Announcement Banner
                </label>
                <input
                  type="text"
                  maxLength={140}
                  value={announcementText}
                  onChange={(e) => setAnnouncementText(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Free Shipping Threshold (₹ / Rs)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={freeThreshold}
                    onChange={(e) => setFreeThreshold(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Standard Shipping Fee (₹ / Rs)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={shippingFee}
                    onChange={(e) => setShippingFee(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none tabular-nums"
                  />
                </div>
              </div>

              <div className="p-4 border border-neutral-200 bg-neutral-50 text-xs text-neutral-600">
                <p className="font-semibold text-[#0A0A0A] mb-1">
                  Payment Gateway Configuration
                </p>
                <p>
                  Cash on Delivery is active for all verified customer orders. Online card payments remain disabled until a live payment gateway provider key is configured on the server.
                </p>
              </div>

              <button
                type="submit"
                disabled={savingSettings}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer"
              >
                {savingSettings ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                <span>Save Settings</span>
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
