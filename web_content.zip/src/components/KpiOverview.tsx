import React from 'react';
import {
  FileText,
  CheckCircle,
  Clock,
  AlertOctagon,
  Image as ImageIcon,
  ChevronRight,
  TrendingUp,
  Plus
} from 'lucide-react';
import { OperationalReport, Sector } from '../types/report';
import { formatDate, getStatusLabel, getStatusTextColor, getPriorityLabel, getPriorityTextColor } from '../utils/formatters';
import { SectorIcon } from './SectorIcon';

interface Props {
  reports: OperationalReport[];
  sectors: Sector[];
  onOpenReport: (report: OperationalReport) => void;
  onOpenNewReportModal: () => void;
  onFilterBySector: (sectorId: string) => void;
}

export const KpiOverview: React.FC<Props> = ({
  reports,
  sectors,
  onOpenReport,
  onOpenNewReportModal,
  onFilterBySector
}) => {
  const total = reports.length;
  const completed = reports.filter((r) => r.status === 'completato').length;
  const inProgress = reports.filter((r) => r.status === 'in_corso').length;
  const inReview = reports.filter((r) => r.status === 'in_revisione').length;
  const critical = reports.filter((r) => r.status === 'critico').length;
  const totalImages = reports.reduce((acc, r) => acc + r.images.length, 0);

  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

  // Sector stats
  const sectorStats = sectors.map((sector) => {
    const sectorReports = reports.filter((r) => r.sectorId === sector.id);
    const count = sectorReports.length;
    const completedCount = sectorReports.filter((r) => r.status === 'completato').length;
    const criticalCount = sectorReports.filter((r) => r.status === 'critico').length;
    const imagesCount = sectorReports.reduce((acc, r) => acc + r.images.length, 0);
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;
    return {
      sector,
      count,
      completedCount,
      criticalCount,
      imagesCount,
      pct
    };
  });

  const recentReports = [...reports]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Banner & Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-neutral-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-neutral-900">
            Cruscotto Operativo Aziendale
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Monitoraggio centralizzato di turni, interventi manutentivi, sicurezza e flussi di magazzino
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenNewReportModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Nuovo Report Turno</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid (High density, tabular figures, single elevation) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-white border border-neutral-200 p-4 rounded-lg">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium">Totale Report</span>
            <FileText className="w-4 h-4 text-neutral-400" />
          </div>
          <div className="text-2xl font-bold text-neutral-900 font-mono tabular-nums">
            {total}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            Archiviati nel sistema
          </div>
        </div>

        <div className="bg-white border border-neutral-200 p-4 rounded-lg">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium">Tasso Risoluzione</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-neutral-900 font-mono tabular-nums">
            {completionRate}%
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            <span className="font-mono tabular-nums">{completed}</span> interventi chiusi
          </div>
        </div>

        <div className="bg-white border border-neutral-200 p-4 rounded-lg">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium">In Lavorazione</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-neutral-900 font-mono tabular-nums">
            {inProgress + inReview}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            <span className="font-mono tabular-nums">{inProgress}</span> aperti · <span className="font-mono tabular-nums">{inReview}</span> in verifica
          </div>
        </div>

        <div className="bg-white border border-neutral-200 p-4 rounded-lg">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium">Anomalie Critiche</span>
            <AlertOctagon className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-700 font-mono tabular-nums">
            {critical}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            Richiedono intervento immediato
          </div>
        </div>

        <div className="bg-white border border-neutral-200 p-4 rounded-lg col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-medium">Foto Operative</span>
            <ImageIcon className="w-4 h-4 text-neutral-700" />
          </div>
          <div className="text-2xl font-bold text-neutral-900 font-mono tabular-nums">
            {totalImages}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            Prove fotografiche allegate
          </div>
        </div>
      </div>

      {/* 2-Column Split: Sector Performance & Recent Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sector Breakdown */}
        <div className="lg:col-span-5 bg-white border border-neutral-200 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-4">
            <div>
              <h2 className="text-sm font-semibold text-neutral-900">
                Distribuzione per Settore Aziendale
              </h2>
              <p className="text-[11px] text-neutral-500">
                Volume report, completezza e anomalie per reparto
              </p>
            </div>
            <TrendingUp className="w-4 h-4 text-neutral-400" />
          </div>

          <div className="space-y-4">
            {sectorStats.map((item) => (
              <div
                key={item.sector.id}
                onClick={() => onFilterBySector(item.sector.id)}
                className="group cursor-pointer p-2.5 rounded-md hover:bg-neutral-50 transition-colors border border-transparent hover:border-neutral-200"
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <SectorIcon name={item.sector.iconName} className="w-3.5 h-3.5 text-neutral-600" />
                    <span className="font-medium text-neutral-800 group-hover:text-neutral-900">
                      {item.sector.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-500 text-[11px]">
                    <span className="font-mono tabular-nums">{item.count} report</span>
                    <span>·</span>
                    <span className="font-mono tabular-nums">{item.imagesCount} foto</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden flex">
                  <div
                    className="bg-neutral-900 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.max(item.pct, 4)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-neutral-400 mt-1">
                  <span>Chiusi: <strong className="font-mono text-neutral-600 tabular-nums">{item.completedCount}</strong></span>
                  {item.criticalCount > 0 ? (
                    <span className="text-rose-600 font-medium">
                      Criticità aperte: <span className="font-mono tabular-nums">{item.criticalCount}</span>
                    </span>
                  ) : (
                    <span>Nessun blocco</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Recent Reports Feed with Photo Previews */}
        <div className="lg:col-span-7 bg-white border border-neutral-200 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-4">
            <div>
              <h2 className="text-sm font-semibold text-neutral-900">
                Ultime Registrazioni Operative
              </h2>
              <p className="text-[11px] text-neutral-500">
                Attività recenti dai reparti produttivi e manutentivi
              </p>
            </div>
          </div>

          {recentReports.length === 0 ? (
            <div className="py-8 text-center text-xs text-neutral-500">
              Nessun report registrato. Clicca &quot;Nuovo Report Turno&quot; per iniziare.
            </div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {recentReports.map((report) => {
                const sector = sectors.find((s) => s.id === report.sectorId);
                const hasImages = report.images.length > 0;

                return (
                  <div
                    key={report.id}
                    onClick={() => onOpenReport(report)}
                    className="py-3 px-2 flex items-start gap-4 hover:bg-neutral-50 rounded-md transition-colors cursor-pointer group"
                  >
                    {/* Thumbnail preview or icon */}
                    <div className="w-14 h-14 rounded-md overflow-hidden bg-neutral-100 shrink-0 border border-neutral-200 flex items-center justify-center">
                      {hasImages ? (
                        <img
                          src={report.images[0].url}
                          alt={report.images[0].caption || report.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <SectorIcon
                          name={sector?.iconName || 'FileText'}
                          className="w-5 h-5 text-neutral-400"
                        />
                      )}
                    </div>

                    {/* Report Information */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-[11px] text-neutral-500 mb-0.5">
                        <span className="font-mono tabular-nums text-neutral-900 font-medium">
                          {report.protocolNumber}
                        </span>
                        <span>·</span>
                        <span>{sector?.name || report.sectorId}</span>
                        <span>·</span>
                        <span>{formatDate(report.timestamp)}</span>
                      </div>

                      <h3 className="text-xs font-semibold text-neutral-900 group-hover:text-neutral-700 truncate">
                        {report.title}
                      </h3>

                      <p className="text-[11px] text-neutral-500 line-clamp-1 mt-0.5">
                        {report.description}
                      </p>

                      <div className="flex items-center gap-3 mt-1 text-[11px]">
                        <span className={getStatusTextColor(report.status)}>
                          {getStatusLabel(report.status)}
                        </span>
                        <span>·</span>
                        <span className={getPriorityTextColor(report.priority)}>
                          Priorità {getPriorityLabel(report.priority)}
                        </span>
                        <span>·</span>
                        <span className="text-neutral-500">
                          {report.operatorName}
                        </span>
                        {hasImages && (
                          <>
                            <span>·</span>
                            <span className="text-neutral-500 font-mono tabular-nums flex items-center gap-1">
                              <ImageIcon className="w-3 h-3 text-neutral-400" />
                              {report.images.length} {report.images.length === 1 ? 'foto' : 'foto'}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="self-center pl-2 text-neutral-400 group-hover:text-neutral-700 transition-colors">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
