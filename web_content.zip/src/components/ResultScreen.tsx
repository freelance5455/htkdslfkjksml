import { useMemo } from "react";
import type { GameResult } from "@/game/engine";
import { findLesson } from "@/game/words";

interface Props {
  result: GameResult;
  isBest: boolean;
  onRestart: () => void;
  onMenu: () => void;
  onShowScores: () => void;
}

const MODE_LABEL: Record<string, string> = {
  tap: "انتخاب کن",
  type: "تایپ کن",
  meaning: "معنی",
};

const DIFF_LABEL: Record<string, string> = {
  easy: "آرام",
  normal: "عادی",
  hard: "سریع",
};

export default function ResultScreen({
  result,
  isBest,
  onRestart,
  onMenu,
  onShowScores,
}: Props) {
  const lesson = findLesson(result.lessonId);
  const attempts = useMemo(() => {
    const map = new Map<string, boolean>();
    for (const a of result.answered) map.set(a.word.id, a.ok);
    return map;
  }, [result.answered]);

  const attemptsCount = result.correct + result.wrong + result.missed;
  const accuracy = attemptsCount
    ? Math.round((result.correct / attemptsCount) * 100)
    : 0;
  const pct = Math.round((result.mastered / Math.max(1, result.total)) * 100);

  return (
    <div className="h-full w-full overflow-y-auto overscroll-contain">
      <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col items-center gap-4 px-4 py-6">
        <div className="animate-pop-in text-center">
          <div className="text-6xl">{result.win ? "🏆" : "💥"}</div>
          <h2 className="mt-2 font-display text-3xl font-black">
            {result.win ? "درس کامل شد!" : "بازی تمام شد"}
          </h2>
          <p className="mt-1 text-sm text-slate-300">
            {result.lessonTitle} • {MODE_LABEL[result.mode]} • {DIFF_LABEL[result.difficulty]}
          </p>
        </div>

        <div className="animate-pop-in glass w-full rounded-3xl p-4 text-center">
          <div className="text-xs text-slate-400">امتیاز نهایی</div>
          <div className="font-display text-6xl font-black text-cyan-300 drop-shadow-[0_0_22px_rgba(34,211,238,0.55)]">
            {result.score}
          </div>
          {isBest && (
            <div className="mt-1 inline-block rounded-full bg-amber-400/20 px-3 py-1 text-xs font-bold text-amber-200">
              🏅 رکورد جدید!
            </div>
          )}
        </div>

        <div className="grid w-full grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "کلمات درست", value: result.correct, color: "text-lime-300" },
            { label: "دقت", value: `${accuracy}٪`, color: "text-cyan-300" },
            { label: "بیشترین کمبو", value: result.maxCombo, color: "text-amber-300" },
            { label: "زمان", value: `${result.seconds}ث`, color: "text-violet-300" },
          ].map((s) => (
            <div key={s.label} className="glass rounded-2xl px-2 py-2.5 text-center">
              <div className={`font-display text-2xl font-black ${s.color}`}>{s.value}</div>
              <div className="text-[11px] text-slate-400">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="glass w-full rounded-2xl p-3">
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300">پیشرفت درس</span>
            <span className="font-display font-black text-lime-300">
              {result.mastered}/{result.total}
            </span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-l from-lime-400 to-emerald-300 transition-all duration-700"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>

        <div className="glass w-full rounded-2xl p-3">
          <h3 className="mb-2 text-sm font-bold text-slate-300">📖 کلمات این درس</h3>
          <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
            {lesson.words.map((w) => {
              const st = attempts.get(w.id);
              return (
                <li
                  key={w.id}
                  className="flex items-center gap-2 rounded-xl bg-white/[0.04] px-2.5 py-1.5 text-xs"
                >
                  <span
                    className={`grid h-5 w-5 shrink-0 place-items-center rounded-md text-[10px] font-black ${
                      st === true
                        ? "bg-lime-400/25 text-lime-200"
                        : st === false
                          ? "bg-rose-500/25 text-rose-200"
                          : "bg-white/5 text-slate-500"
                    }`}
                  >
                    {st === true ? "✓" : st === false ? "✕" : "–"}
                  </span>
                  <span className="font-display font-bold text-white" style={{ direction: "ltr" }}>
                    {w.en}
                  </span>
                  <span className="truncate text-slate-400">{w.fa}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-3">
          <button
            onClick={onRestart}
            className="rounded-2xl bg-gradient-to-l from-cyan-400 to-violet-600 px-4 py-3 font-display text-lg font-black text-slate-950 shadow-xl shadow-cyan-500/25 transition active:scale-95"
          >
            ↻ شروع دوباره
          </button>
          <button
            onClick={onShowScores}
            className="rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-bold text-slate-100 transition active:scale-95 active:bg-white/15"
          >
            🏆 رکوردها
          </button>
          <button
            onClick={onMenu}
            className="rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-bold text-slate-100 transition active:scale-95 active:bg-white/15"
          >
            📚 تغییر درس
          </button>
        </div>

        <p className="pb-4 text-center text-[11px] text-slate-500">
          کلید <span className="font-display font-bold text-slate-300">Enter</span> = شروع دوباره
        </p>
      </div>
    </div>
  );
}
