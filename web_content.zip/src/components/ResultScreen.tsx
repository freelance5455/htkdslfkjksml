import React, { useState } from "react";
import { CalculationResult, ContactInfo } from "../types";
import { formatINR, formatNumber, generateShareText } from "../utils/calculator";
import {
  Share2,
  PlusCircle,
  RotateCcw,
  Check,
  Phone,
  MessageCircle,
  Copy,
  Info,
  Layers,
  Sparkles,
  ArrowLeft,
  CheckCircle,
  Package,
  HardHat,
  Calculator,
  ShieldCheck,
  Download,
  Smartphone,
} from "lucide-react";

interface ResultScreenProps {
  result: CalculationResult;
  contact: ContactInfo;
  onNewCalculation: () => void;
  onReset: () => void;
  onOpenAi: () => void;
  onBack: () => void;
  onInstallApp?: () => void;
  isInstalled?: boolean;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  result,
  contact,
  onNewCalculation,
  onReset,
  onOpenAi,
  onBack,
  onInstallApp,
  isInstalled,
}) => {
  const [copied, setCopied] = useState(false);
  const [shareSuccess, setShareSuccess] = useState<string | null>(null);

  const handleShare = async () => {
    const text = generateShareText(result);

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Ceiling Calculation - ${result.categoryName}`,
          text: text,
        });
        setShareSuccess("Shared successfully!");
        setTimeout(() => setShareSuccess(null), 3000);
        return;
      } catch (err: any) {
        if (err.name !== "AbortError") {
          console.warn("Share failed, falling back to copy:", err);
        }
      }
    }

    // Fallback: Copy to clipboard
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setShareSuccess("Detailed BOQ & Estimate copied to clipboard!");
      setTimeout(() => {
        setCopied(false);
        setShareSuccess(null);
      }, 3500);
    } catch {
      setShareSuccess("Could not copy text automatically.");
      setTimeout(() => setShareSuccess(null), 3000);
    }
  };

  const cleanPhone = contact.phone.replace(/[^0-9+]/g, "");
  const cleanWhatsapp = contact.whatsapp.replace(/[^0-9]/g, "");

  const whatsappMessage = encodeURIComponent(
    `Hello! I need an estimate & contractor visit for ${result.categoryName}.\n` +
      `📐 Room: ${result.length} × ${result.width} ft (${formatNumber(result.area)} sq ft)\n` +
      `📦 Material Total: ${formatINR(result.materialTotal)}\n` +
      (result.includeLabour ? `👷 Labour Total: ${formatINR(result.labourTotal)}\n` : "") +
      `✨ Grand Total: ${formatINR(result.grandTotal)}\n` +
      `Please provide contractor availability and visit details.`
  );

  return (
    <div className="space-y-6">
      {/* Top Bar with Back & Reset */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-2 rounded-xl active:scale-95 transition-all shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Edit Dimensions</span>
        </button>

        <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
          Calculation Summary & BOQ
        </h2>

        <button
          onClick={onReset}
          className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-2 rounded-xl border border-rose-100 transition-colors shadow-sm"
          title="Reset All"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Share Toast Feedback */}
      {shareSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-semibold flex items-center justify-center gap-2 shadow-sm animate-fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>{shareSuccess}</span>
        </div>
      )}

      {/* Detailed Receipt Display - Geometric Balance Style */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Card Header */}
        <div className="bg-slate-900 text-white p-6 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold tracking-widest text-indigo-400 uppercase">
              CALCULATION SUMMARY
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
              {result.categoryName}
            </h3>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Dimensions: {result.length} × {result.width} ft ({result.categoryHindiName || ""})
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Total Area
            </span>
            <span className="text-2xl sm:text-3xl font-black text-white font-mono">
              {formatNumber(result.area)}
              <span className="text-xs text-slate-400 font-normal ml-1">sq ft</span>
            </span>
          </div>
        </div>

        {/* Detailed Breakdown Sections */}
        <div className="p-6 space-y-6">
          {/* SECTION A: MATERIAL BOQ */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    A) Material BOQ
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Required quantities & materials breakdown
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-slate-400">
                {result.boqItems.length} Items
              </span>
            </div>

            {/* BOQ Message if unconfigured or generic */}
            {result.boqMessage && (
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>{result.boqMessage}</span>
              </div>
            )}

            {/* BOQ Items Table / Card List */}
            {result.boqItems.length > 0 ? (
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="p-3">#</th>
                      <th className="p-3">Material Item</th>
                      <th className="p-3 text-right">Qty</th>
                      <th className="p-3 text-right">Unit Rate</th>
                      <th className="p-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800 font-medium">
                    {result.boqItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-slate-50/70">
                        <td className="p-3 text-slate-400 font-mono">{idx + 1}</td>
                        <td className="p-3">
                          <div className="font-bold text-slate-900">{item.name}</div>
                          {item.hindiName && (
                            <div className="text-[10px] text-slate-500">{item.hindiName}</div>
                          )}
                          {item.size && (
                            <div className="text-[10px] text-indigo-600 font-mono">{item.size}</div>
                          )}
                          {item.note && (
                            <div className="text-[10px] text-slate-400 italic">{item.note}</div>
                          )}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-700">
                          {formatNumber(item.quantity)}{" "}
                          <span className="text-[10px] text-slate-500 font-normal">{item.unit}</span>
                        </td>
                        <td className="p-3 text-right font-mono text-slate-600">
                          ₹{formatNumber(item.unitRate)}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          {formatINR(item.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-2xl text-xs text-slate-500 text-center">
                No individual BOQ components configured for this category.
              </div>
            )}

            {/* Material Total Summary Bar */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wide block">
                  C) Material Total
                </span>
                <span className="text-[11px] text-slate-500">
                  Sum of all material components
                </span>
              </div>
              <span className="text-xl font-black text-slate-900 font-mono">
                {formatINR(result.materialTotal)}
              </span>
            </div>

            {/* Optional Buffer Row */}
            {result.bufferEnabled && result.bufferAmount > 0 && (
              <div className="bg-amber-50/60 p-3.5 rounded-2xl border border-amber-200/80 flex items-center justify-between text-xs text-amber-950">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <div>
                    <span className="font-bold block">Material Buffer / Wastage ({result.bufferPercent}%)</span>
                    <span className="text-[10px] text-amber-700">Optional allowance for site cutting & corners</span>
                  </div>
                </div>
                <span className="font-bold font-mono text-sm">
                  {formatINR(result.bufferAmount)}
                </span>
              </div>
            )}
          </div>

          {/* SECTION B: LABOUR */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between pb-1 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <HardHat className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    B) Labour Calculation
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Installation and fitting charges
                  </p>
                </div>
              </div>
            </div>

            {result.includeLabour && result.labourTotal > 0 ? (
              <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-emerald-900 font-medium">Labour Rate Applied:</span>
                  <span className="font-bold text-emerald-950 font-mono">
                    ₹{result.labourRate} / {result.labourUnit}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-emerald-900 font-medium">Chargeable Units:</span>
                  <span className="font-bold text-emerald-950 font-mono">
                    {formatNumber(result.labourQuantity)} {result.labourUnit}
                  </span>
                </div>
                <div className="h-px bg-emerald-200/60 my-1"></div>
                <div className="flex justify-between items-center text-xs pt-1">
                  <span className="font-bold text-emerald-900 uppercase tracking-wide">
                    D) Labour Total
                  </span>
                  <span className="text-lg font-black text-emerald-700 font-mono">
                    {formatINR(result.labourTotal)}
                  </span>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs text-slate-500 flex items-center justify-between">
                <span>Labour not included in this estimate</span>
                <span className="font-mono font-bold text-slate-700">₹0</span>
              </div>
            )}
          </div>

          {/* SECTION E: GRAND TOTAL */}
          <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-lg space-y-3">
            <div className="flex justify-between items-end">
              <div>
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest block">
                  E) GRAND TOTAL
                </span>
                <span className="text-[11px] text-slate-400">
                  Material Total + Labour Total
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl sm:text-3xl font-black text-white font-mono">
                  {formatINR(result.grandTotal)}
                </span>
              </div>
            </div>

            {/* Zero Mismatch Rule Verification Box */}
            <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-300 font-mono flex flex-wrap items-center justify-between gap-2">
              <span>
                Material: {formatINR(result.materialTotal)}
                {result.bufferEnabled && result.bufferAmount > 0
                  ? ` + Buffer: ${formatINR(result.bufferAmount)}`
                  : ""}
                {result.includeLabour ? ` + Labour: ${formatINR(result.labourTotal)}` : ""}
              </span>
              <span className="text-indigo-400 font-bold">
                = {formatINR(result.grandTotal)}
              </span>
            </div>
          </div>

          {/* Formula clarification */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Calculator className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Exact Formula & Zero Mismatch Rule:</span>
            </div>
            <p className="leading-relaxed">
              • <strong>Room Area:</strong> {result.length} ft × {result.width} ft = {formatNumber(result.area)} sq ft.<br />
              • <strong>Material Total:</strong> Sum of all BOQ items = <strong>{formatINR(result.materialTotal)}</strong>.<br />
              • <strong>Labour Total:</strong> {formatNumber(result.labourQuantity)} {result.labourUnit} × ₹{result.labourRate} = <strong>{formatINR(result.labourTotal)}</strong>.<br />
              • <strong>Grand Total:</strong> {formatINR(result.materialTotal)} + {formatINR(result.labourTotal)} = <strong>{formatINR(result.grandTotal)}</strong>.
            </p>
          </div>
        </div>

        {/* Action Buttons: Share Result, New Calculation, AI Advice, Reset */}
        <div className="p-6 pt-0 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Share Result */}
          <button
            onClick={handleShare}
            id="share-result-btn"
            className="sm:col-span-3 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white font-bold py-4 px-4 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-md transition-all active:scale-[0.98]"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Estimate Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-indigo-400" />
                <span>Share Full BOQ & Estimate (WhatsApp / SMS)</span>
              </>
            )}
          </button>

          {/* New Calculation */}
          <button
            onClick={onNewCalculation}
            id="new-calculation-btn"
            className="bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-1.5 text-xs sm:text-sm shadow-md transition-all active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Calculation</span>
          </button>

          {/* Ask AI about this estimate */}
          <button
            onClick={onOpenAi}
            className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-3.5 px-4 rounded-xl flex items-center justify-center gap-1.5 text-xs sm:text-sm transition-colors border border-slate-200"
          >
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <span>Ask Smart AI</span>
          </button>

          {/* Reset */}
          <button
            onClick={onReset}
            id="reset-btn"
            className="bg-slate-100 hover:bg-slate-200 text-rose-600 font-semibold py-3.5 px-4 rounded-xl flex items-center justify-center gap-1.5 text-xs sm:text-sm transition-colors border border-slate-200"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Form</span>
          </button>
        </div>
      </div>

      {/* Prominent INSTALL APP Banner on Result Screen */}
      {!isInstalled && onInstallApp && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 rounded-3xl p-5 sm:p-6 text-slate-950 shadow-lg border border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center shrink-0 shadow-md p-1 overflow-hidden">
              <img
                src="/icon.svg"
                alt="App Icon"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-slate-950 text-white px-2 py-0.5 rounded">
                OFFICIAL PWA APP
              </span>
              <h3 className="text-base sm:text-lg font-black text-slate-950 mt-1">
                Install "Ceiling Calculation" on Your Phone
              </h3>
              <p className="text-xs text-slate-900 font-medium">
                Keep calculator handy for offline site visits & instant estimates
              </p>
            </div>
          </div>

          <button
            onClick={onInstallApp}
            id="result-install-app-btn"
            className="w-full sm:w-auto bg-slate-950 hover:bg-slate-900 active:bg-slate-800 text-white font-black py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-xl active:scale-95 transition-all uppercase tracking-wide shrink-0"
          >
            <Download className="w-4 h-4 stroke-[2.5] text-amber-400" />
            <span>📲 INSTALL APP</span>
          </button>
        </div>
      )}

      {/* For Enquiry & Work Contact Section */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 rounded-3xl p-6 sm:p-7 text-white shadow-xl space-y-4">
        <div className="text-center sm:text-left space-y-1">
          <span className="text-[11px] uppercase tracking-widest font-extrabold bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full border border-indigo-500/30 inline-block">
            Verified Contractor Support
          </span>
          <h4 className="text-lg sm:text-xl font-black text-white tracking-tight mt-2">
            For Enquiry & Work Contact
          </h4>
          <p className="text-xs text-slate-300">
            Site measurement, material supply & professional ceiling installation
          </p>
        </div>

        {/* Big Prominent Phone Display */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/15 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
              <Phone className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[11px] text-slate-300 font-medium block">Direct Helpline / Contractor</span>
              <a
                href="tel:9068926728"
                className="text-2xl sm:text-3xl font-black text-white hover:text-emerald-300 tracking-wider font-mono transition-colors"
              >
                📞 9068926728
              </a>
            </div>
          </div>

          {/* Action Buttons: CALL NOW & WHATSAPP */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* CALL NOW */}
            <a
              href="tel:9068926728"
              id="call-now-btn"
              className="flex-1 sm:flex-initial bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-slate-950 font-black py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all uppercase tracking-wide"
            >
              <Phone className="w-4 h-4 fill-slate-950 text-slate-950" />
              <span>CALL NOW</span>
            </a>

            {/* WHATSAPP */}
            <a
              href={`https://wa.me/919068926728?text=${whatsappMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              id="whatsapp-enquiry-btn"
              className="flex-1 sm:flex-initial bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-lg shadow-emerald-600/20 active:scale-95 transition-all uppercase tracking-wide"
            >
              <MessageCircle className="w-4 h-4 fill-white text-white" />
              <span>WHATSAPP</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
