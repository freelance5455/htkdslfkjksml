import { useMemo, useState, type FormEvent } from "react";
import { Field, PnlText, Segment, Sheet } from "@/components/ui";
import { formatKrw, formatPct, formatPrice, formatQty, parseNum } from "@/lib/format";
import { cleanSymbol } from "@/lib/symbols";
import { holdingPnl, usePortfolio } from "@/lib/store";
import type { Currency, Holding, PriceMode, TxKind } from "@/lib/types";

export function AssetsView({ onTrade }: { onTrade: (kind: TxKind, holdingId: string) => void }) {
  const data = usePortfolio();
  const [group, setGroup] = useState<"account" | "class">("account");
  const [query, setQuery] = useState("");
  const [editor, setEditor] = useState<Holding | "new" | null>(null);
  const [accountsOpen, setAccountsOpen] = useState(false);
  const fx = data.market.fx;
  const q = query.trim().toLowerCase();
  const visible = data.holdings.filter((holding) => {
    if (!q) return true;
    return `${holding.name} ${holding.symbol}`.toLowerCase().includes(q);
  });
  const open = visible.filter((holding) => holding.quantity > 1e-8);
  const closed = visible.filter((holding) => holding.quantity <= 1e-8);

  const groups = useMemo(() => {
    const source = group === "account" ? data.accounts.map((item) => ({ id: item.id, name: item.name })) : data.classes.map((item) => ({ id: item.id, name: item.name, color: item.color }));
    return source
      .map((item) => {
        const items = open
          .filter((holding) => (group === "account" ? holding.accountId === item.id : holding.classId === item.id))
          .sort((a, b) => holdingPnl(b, fx).value - holdingPnl(a, fx).value);
        const value = items.reduce((sum, holding) => sum + holdingPnl(holding, fx).value, 0);
        return { ...item, items, value };
      })
      .filter((item) => group === "class" || item.items.length > 0 || data.accounts.some((account) => account.id === item.id))
      .sort((a, b) => b.value - a.value);
  }, [data.accounts, data.classes, group, open, fx]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-base font-semibold">보유 자산</h2>
        <div className="flex gap-1">
          <button type="button" className="h-11 px-2 text-sm text-muted" onClick={() => setAccountsOpen(true)}>
            계좌
          </button>
          <button type="button" className="h-11 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg" onClick={() => setEditor("new")}>
            자산 추가
          </button>
        </div>
      </div>
      <Segment
        value={group}
        onChange={setGroup}
        options={[
          { id: "account", label: "계좌별" },
          { id: "class", label: "자산군별" },
        ]}
      />
      <input className="field" placeholder="종목 검색" value={query} onChange={(event) => setQuery(event.target.value)} />
      <p className="text-xs text-muted">달러 손익은 현재 환율로 환산합니다. 적금·파킹은 수량을 1, 평단을 원금, 현재가를 잔액으로 두면 됩니다.</p>

      {groups.map((item) => (
        <section key={item.id} className="card overflow-hidden">
          <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
            <h3 className="flex min-w-0 items-center gap-2 text-sm font-semibold">
              {"color" in item && typeof item.color === "string" ? (
                <span className="size-2 shrink-0 rounded-full" style={{ background: item.color }} />
              ) : null}
              <span className="truncate">{item.name}</span>
            </h3>
            <span className="shrink-0 text-sm tabular-nums">{formatKrw(item.value)}</span>
          </header>
          {item.items.length === 0 ? <p className="px-4 py-3 text-sm text-muted">없음</p> : null}
          <ul>
            {item.items.map((holding) => {
              const pnl = holdingPnl(holding, fx);
              const account = data.accounts.find((entry) => entry.id === holding.accountId);
              const assetClass = data.classes.find((entry) => entry.id === holding.classId);
              return (
                <li key={holding.id} className="border-t border-line first:border-t-0">
                  <button type="button" className="flex w-full items-center gap-3 px-4 py-3 text-left" onClick={() => setEditor(holding)}>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{holding.name}</span>
                      <span className="block truncate text-xs text-muted">
                        {group === "account" ? assetClass?.name : account?.name} ·{" "}
                        {holding.priceMode === "fx"
                          ? `${formatQty(holding.quantity)}달러`
                          : `${formatQty(holding.quantity)} × ${formatPrice(holding.currentPrice, holding.currency)}`}
                      </span>
                    </span>
                    <span className="shrink-0 text-right">
                      <span className="block text-sm tabular-nums">{formatKrw(pnl.value)}</span>
                      <PnlText value={pnl.pnl}>
                        <span className="text-xs">{formatPct(pnl.pct)}</span>
                      </PnlText>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      ))}

      {closed.length > 0 ? (
        <section className="card p-4">
          <h3 className="text-sm font-semibold">수량이 0인 종목</h3>
          <ul className="mt-2 space-y-2">
            {closed.map((holding) => (
              <li key={holding.id}>
                <button type="button" className="text-sm text-muted" onClick={() => setEditor(holding)}>
                  {holding.name}
                </button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <HoldingSheet
        mode={editor}
        onClose={() => setEditor(null)}
        onTrade={(kind, id) => {
          setEditor(null);
          onTrade(kind, id);
        }}
      />
      <AccountSheet open={accountsOpen} onClose={() => setAccountsOpen(false)} />
    </div>
  );
}

function HoldingSheet({
  mode,
  onClose,
  onTrade,
}: {
  mode: Holding | "new" | null;
  onClose: () => void;
  onTrade: (kind: TxKind, holdingId: string) => void;
}) {
  return (
    <Sheet open={mode != null} title={mode === "new" ? "자산 추가" : "자산 수정"} onClose={onClose}>
      {mode ? <HoldingForm key={mode === "new" ? "new" : mode.id} mode={mode} onClose={onClose} onTrade={onTrade} /> : null}
    </Sheet>
  );
}

function HoldingForm({
  mode,
  onClose,
  onTrade,
}: {
  mode: Holding | "new";
  onClose: () => void;
  onTrade: (kind: TxKind, holdingId: string) => void;
}) {
  const data = usePortfolio();
  const initial = mode === "new" ? null : mode;
  const [name, setName] = useState(initial?.name ?? "");
  const [symbol, setSymbol] = useState(initial?.symbol ?? "");
  const [accountId, setAccountId] = useState(initial?.accountId ?? data.accounts[0]?.id ?? "");
  const [newAccount, setNewAccount] = useState("");
  const [classId, setClassId] = useState(initial?.classId ?? data.classes[0]?.id ?? "");
  const [currency, setCurrency] = useState<Currency>(initial?.currency ?? "KRW");
  const [priceMode, setPriceMode] = useState<PriceMode>(initial?.priceMode ?? "auto");
  const [quantity, setQuantity] = useState(initial ? String(initial.quantity) : "");
  const [avgPrice, setAvgPrice] = useState(initial ? String(initial.avgPrice) : "");
  const [currentPrice, setCurrentPrice] = useState(initial ? String(initial.currentPrice) : "");
  const [error, setError] = useState<string | null>(null);

  function submit(event: FormEvent) {
    event.preventDefault();
    const qty = parseNum(quantity);
    const avg = parseNum(avgPrice);
    const current = parseNum(currentPrice);
    if (priceMode === "auto" && !cleanSymbol(symbol)) {
      setError("자동 시세는 티커가 필요합니다. 예: VOO, 005930");
      return;
    }
    const payload = {
      accountId: newAccount.trim() ? "" : accountId,
      newAccountName: newAccount,
      classId,
      name,
      symbol,
      currency,
      priceMode,
      quantity: qty ?? 0,
      avgPrice: avg ?? 0,
      currentPrice: priceMode === "fx" ? data.market.fx : current ?? 0,
    };
    const message = initial ? null : data.addHolding(payload);
    if (initial) {
      if (!name.trim() || !(qty && qty > 0) || !(avg && avg > 0) || !(payload.currentPrice > 0)) {
        setError("이름, 수량, 평단, 현재가를 확인해 주세요.");
        return;
      }
      data.updateHolding(initial.id, {
        ...payload,
        accountId: newAccount.trim() ? initial.accountId : accountId,
      });
      if (newAccount.trim()) {
        const created = data.addAccount(newAccount);
        if (created) {
          setError(created);
          return;
        }
        const newest = usePortfolio.getState().accounts.at(-1);
        if (newest) data.updateHolding(initial.id, { accountId: newest.id });
      }
      onClose();
      return;
    }
    if (message) {
      setError(message);
      return;
    }
    onClose();
  }

  return (
    <form className="space-y-3" onSubmit={submit}>
      <Field label="이름">
        <input className="field" value={name} placeholder="삼성전자, 토스 파킹통장" onChange={(event) => setName(event.target.value)} />
      </Field>
      <Field label="티커 (자동 시세)">
        <input className="field" value={symbol} placeholder="VOO, 005930, 삼성전자" onChange={(event) => setSymbol(event.target.value)} />
      </Field>
      <Field label="계좌">
        <select className="field" value={accountId} onChange={(event) => setAccountId(event.target.value)}>
          {data.accounts.map((account) => (
            <option key={account.id} value={account.id}>
              {account.name}
            </option>
          ))}
          <option value="">새 계좌</option>
        </select>
      </Field>
      {accountId === "" || newAccount ? (
        <Field label="새 계좌 이름">
          <input className="field" value={newAccount} placeholder="미래에셋증권" onChange={(event) => setNewAccount(event.target.value)} />
        </Field>
      ) : null}
      <Field label="자산군">
        <select className="field" value={classId} onChange={(event) => setClassId(event.target.value)}>
          {data.classes.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="시세">
        <select
          className="field"
          value={priceMode}
          onChange={(event) => {
            const next = event.target.value as PriceMode;
            setPriceMode(next);
            if (next === "fx") setCurrentPrice(String(data.market.fx));
          }}
        >
          <option value="auto">티커로 자동</option>
          <option value="manual">직접 입력</option>
          <option value="fx">달러 잔액 · 환율 연동</option>
        </select>
      </Field>
      {priceMode === "fx" ? <p className="text-xs text-muted">수량은 달러 금액, 평단은 샀을 때 환율, 현재가는 오늘 환율로 바뀝니다.</p> : null}
      {priceMode !== "fx" ? (
        <Field label="통화">
          <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
            <option value="KRW">원화</option>
            <option value="USD">달러</option>
          </select>
        </Field>
      ) : null}
      <div className="grid grid-cols-2 gap-2">
        <Field label={priceMode === "fx" ? "달러 수량" : "수량"}>
          <input className="field tabular-nums" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} />
        </Field>
        <Field label={priceMode === "fx" ? "매수 환율" : "평단"}>
          <input className="field tabular-nums" inputMode="decimal" value={avgPrice} onChange={(event) => setAvgPrice(event.target.value)} />
        </Field>
      </div>
      <Field label={priceMode === "fx" ? "현재 환율" : "현재가"}>
        <input className="field tabular-nums" inputMode="decimal" value={currentPrice} onChange={(event) => setCurrentPrice(event.target.value)} />
      </Field>
      {error ? <p className="text-sm text-down">{error}</p> : null}
      <button type="submit" className="h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg">
        저장
      </button>
      {initial ? (
        <div className="grid grid-cols-3 gap-2">
          <button type="button" className="h-11 rounded-lg bg-surface-2 text-sm" onClick={() => onTrade("buy", initial.id)}>
            매수
          </button>
          <button type="button" className="h-11 rounded-lg bg-surface-2 text-sm" onClick={() => onTrade("sell", initial.id)}>
            매도
          </button>
          <button type="button" className="h-11 rounded-lg bg-surface-2 text-sm" onClick={() => onTrade("dividend", initial.id)}>
            배당
          </button>
        </div>
      ) : null}
      {initial ? (
        <button
          type="button"
          className="h-11 w-full text-sm text-down"
          onClick={() => {
            data.removeHolding(initial.id);
            onClose();
          }}
        >
          이 종목 삭제
        </button>
      ) : null}
    </form>
  );
}

function AccountSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const accounts = usePortfolio((state) => state.accounts);
  const addAccount = usePortfolio((state) => state.addAccount);
  const renameAccount = usePortfolio((state) => state.renameAccount);
  const removeAccount = usePortfolio((state) => state.removeAccount);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  return (
    <Sheet open={open} title="계좌" onClose={onClose}>
      <ul className="space-y-2">
        {accounts.map((account) => (
          <li key={account.id} className="flex gap-2">
            <input className="field" value={account.name} aria-label="계좌 이름" onChange={(event) => renameAccount(account.id, event.target.value)} />
            <button
              type="button"
              className="h-11 shrink-0 px-2 text-sm text-down"
              onClick={() => setError(removeAccount(account.id))}
            >
              삭제
            </button>
          </li>
        ))}
      </ul>
      {error ? <p className="mt-2 text-sm text-down">{error}</p> : null}
      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          setError(addAccount(name));
          if (name.trim()) setName("");
        }}
      >
        <input className="field" placeholder="새 계좌" value={name} onChange={(event) => setName(event.target.value)} />
        <button type="submit" className="h-11 shrink-0 rounded-lg bg-primary px-4 text-sm font-medium text-primary-fg">
          추가
        </button>
      </form>
    </Sheet>
  );
}
