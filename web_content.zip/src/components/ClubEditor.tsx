import React, { useState } from 'react';
import { Plus, Save, Shirt, User } from 'lucide-react';
import {
  HAIRSTYLE_OPTIONS,
  HAIR_COLOR_PRESETS,
  KIT_COLOR_PRESETS,
  resolveClubKit,
} from '../data/clubs';
import { TRANSLATIONS } from '../i18n/translations';
import {
  Club,
  CrestIcon,
  CrestPattern,
  HairStyle,
  KitConfig,
  Language,
  Player,
  PlayerPosition,
} from '../types/game';
import { ClubCrest } from './ClubCrest';

interface ClubEditorProps {
  clubs: Club[];
  language: Language;
  onSaveClub: (club: Club) => void;
}

const PATTERNS: CrestPattern[] = ['stripes', 'halves', 'sash', 'cross', 'chevron', 'solid'];
const ICONS: CrestIcon[] = ['crown', 'eagle', 'star', 'flame', 'shield', 'anchor'];
const POSITIONS: PlayerPosition[] = ['GOL', 'ZAG', 'VOL', 'MEI', 'ATA'];

function contrastTextColor(hex: string): string {
  const c = hex.replace('#', '');
  if (c.length !== 6) return '#FFFFFF';
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.62 ? '#0F172A' : '#F8FAFC';
}

const PlayerKitPreview: React.FC<{
  kit: KitConfig;
  player: Player;
}> = ({ kit, player }) => {
  const uid = React.useId().replace(/:/g, '');
  const jerseyClip = `jersey-clip-${uid}`;
  const hairStyle: HairStyle = player.hairStyle ?? 'short';
  const hairColor = player.hairColor ?? '#1E1B18';
  const numColor = contrastTextColor(kit.primaryColor);

  const renderKitPattern = () => {
    switch (kit.pattern) {
      case 'stripes':
        return (
          <>
            <rect x="20" y="54" width="80" height="72" fill={kit.primaryColor} />
            <rect x="34" y="54" width="12" height="72" fill={kit.secondaryColor} />
            <rect x="54" y="54" width="12" height="72" fill={kit.secondaryColor} />
            <rect x="74" y="54" width="12" height="72" fill={kit.secondaryColor} />
          </>
        );
      case 'halves':
        return (
          <>
            <rect x="20" y="54" width="40" height="72" fill={kit.primaryColor} />
            <rect x="60" y="54" width="40" height="72" fill={kit.secondaryColor} />
          </>
        );
      case 'sash':
        return (
          <>
            <rect x="20" y="54" width="80" height="72" fill={kit.primaryColor} />
            <polygon points="18,116 86,50 102,64 34,130" fill={kit.secondaryColor} />
          </>
        );
      case 'cross':
        return (
          <>
            <rect x="20" y="54" width="80" height="72" fill={kit.primaryColor} />
            <rect x="53" y="54" width="14" height="72" fill={kit.secondaryColor} />
            <rect x="20" y="80" width="80" height="14" fill={kit.secondaryColor} />
          </>
        );
      case 'chevron':
        return (
          <>
            <rect x="20" y="54" width="80" height="72" fill={kit.primaryColor} />
            <polygon points="20,68 60,92 100,68 100,82 60,106 20,82" fill={kit.secondaryColor} />
          </>
        );
      case 'solid':
      default:
        return (
          <>
            <rect x="20" y="54" width="80" height="72" fill={kit.primaryColor} />
            <rect x="20" y="54" width="80" height="8" fill={kit.secondaryColor} />
          </>
        );
    }
  };

  const renderHair = () => {
    switch (hairStyle) {
      case 'bald':
        return null;
      case 'fade':
        return (
          <>
            <rect x="47" y="13" width="26" height="14" rx="5" fill={hairColor} />
            <path d="M46 25 Q60 19 74 25 L74 29 Q60 24 46 29 Z" fill={hairColor} opacity="0.7" />
          </>
        );
      case 'afro':
        return <circle cx="60" cy="25" r="21" fill={hairColor} />;
      case 'mohawk':
        return (
          <>
            <path d="M55 8 L65 8 L67 28 L53 28 Z" fill={hairColor} />
            <path d="M47 26 Q60 20 73 26 Z" fill={hairColor} opacity="0.4" />
          </>
        );
      case 'long':
        return (
          <>
            <path d="M42 26 Q42 12 60 12 Q78 12 78 26 L80 48 L69 48 L69 32 L51 32 L51 48 L40 48 Z" fill={hairColor} />
          </>
        );
      case 'short':
      default:
        return <path d="M45 29 Q45 14 60 14 Q75 14 75 29 Q60 22 45 29 Z" fill={hairColor} />;
    }
  };

  return (
    <svg viewBox="0 0 120 175" className="w-28 h-40 shrink-0 drop-shadow-lg" aria-label={player.name}>
      <defs>
        <clipPath id={jerseyClip}>
          <path d="M42 54 L20 66 L26 86 L38 80 L38 124 L82 124 L82 80 L94 86 L100 66 L78 54 Q60 62 42 54 Z" />
        </clipPath>
      </defs>

      {/* Hair behind head for afro/long */}
      {(hairStyle === 'afro' || hairStyle === 'long') && renderHair()}

      {/* Neck & Head */}
      <rect x="54" y="42" width="12" height="14" rx="4" fill="#D99B72" />
      <circle cx="60" cy="31" r="14" fill="#D99B72" />

      {/* Hair on top */}
      {hairStyle !== 'afro' && hairStyle !== 'long' && renderHair()}

      {/* Jersey Silhouette */}
      <g clipPath={`url(#${jerseyClip})`}>
        {renderKitPattern()}
        <rect
          x="45"
          y="78"
          width="30"
          height="28"
          rx="4"
          fill={kit.primaryColor}
          opacity="0.72"
        />
        <text
          x="60"
          y="99"
          textAnchor="middle"
          fill={numColor}
          fontSize="22"
          fontWeight="800"
          fontFamily="Barlow Condensed, sans-serif"
        >
          {player.number}
        </text>
      </g>
      <path
        d="M42 54 L20 66 L26 86 L38 80 L38 124 L82 124 L82 80 L94 86 L100 66 L78 54 Q60 62 42 54 Z"
        fill="none"
        stroke="rgba(255,255,255,0.28)"
        strokeWidth="1.5"
      />

      {/* Shorts */}
      <path d="M38 125 L82 125 L86 154 L63 154 L60 140 L57 154 L34 154 Z" fill={kit.shortsColor} stroke="rgba(255,255,255,0.22)" strokeWidth="1.2" />

      {/* Socks */}
      <rect x="40" y="155" width="13" height="15" rx="2" fill={kit.primaryColor} />
      <rect x="67" y="155" width="13" height="15" rx="2" fill={kit.primaryColor} />
    </svg>
  );
};

export const ClubEditor: React.FC<ClubEditorProps> = ({ clubs, language, onSaveClub }) => {
  const t = TRANSLATIONS[language];
  const [selectedId, setSelectedId] = useState<string>(clubs[0].id);
  const activeClub = clubs.find((c) => c.id === selectedId) || clubs[0];

  const normalizeClub = (club: Club): Club => ({
    ...JSON.parse(JSON.stringify(club)),
    homeKit: resolveClubKit(club, 'home'),
    awayKit: resolveClubKit(club, 'away'),
  });

  const [draft, setDraft] = useState<Club>(() => normalizeClub(activeClub));
  const [kitTab, setKitTab] = useState<'home' | 'away'>('home');
  const [focusedPlayerIdx, setFocusedPlayerIdx] = useState<number>(9);
  const [savedNotice, setSavedNotice] = useState(false);

  const selectClub = (club: Club) => {
    setSelectedId(club.id);
    setDraft(normalizeClub(club));
    setFocusedPlayerIdx(9);
    setSavedNotice(false);
  };

  const handleCreateNew = () => {
    const template = clubs[0];
    const newId = `custom_${Date.now()}`;
    const customClub: Club = {
      ...JSON.parse(JSON.stringify(template)),
      id: newId,
      name: 'FC Nova Era',
      abbr: 'FNE',
      league: 'custom',
      primaryColor: '#4F46E5',
      secondaryColor: '#F5C451',
      pattern: 'sash',
      icon: 'crown',
      homeKit: {
        primaryColor: '#4F46E5',
        secondaryColor: '#F5C451',
        shortsColor: '#1E1B4B',
        pattern: 'sash',
      },
      awayKit: {
        primaryColor: '#F8FAFC',
        secondaryColor: '#4F46E5',
        shortsColor: '#4F46E5',
        pattern: 'solid',
      },
      players: template.players.map((p, idx) => ({
        ...p,
        id: `${newId}_p${idx + 1}`,
        name: `Jogador ${idx + 1}`,
        ovr: 82,
      })),
    };
    onSaveClub(customClub);
    selectClub(customClub);
  };

  const activeKit: KitConfig =
    kitTab === 'home'
      ? draft.homeKit ?? resolveClubKit(draft, 'home')
      : draft.awayKit ?? resolveClubKit(draft, 'away');

  const updateActiveKit = (patch: Partial<KitConfig>) => {
    setDraft((prev) => {
      const current =
        kitTab === 'home'
          ? prev.homeKit ?? resolveClubKit(prev, 'home')
          : prev.awayKit ?? resolveClubKit(prev, 'away');
      const nextKit = { ...current, ...patch };
      if (kitTab === 'home') {
        return {
          ...prev,
          homeKit: nextKit,
          primaryColor: nextKit.primaryColor,
          secondaryColor: nextKit.secondaryColor,
        };
      }
      return { ...prev, awayKit: nextKit };
    });
  };

  const updatePlayer = (idx: number, patch: Partial<Player>) => {
    setDraft((prev) => {
      const nextPlayers = [...prev.players];
      nextPlayers[idx] = { ...nextPlayers[idx], ...patch };
      return { ...prev, players: nextPlayers };
    });
  };

  const handleSave = () => {
    const avg = (list: Player[]) =>
      list.length ? Math.round(list.reduce((s, p) => s + p.ovr, 0) / list.length) : 80;
    const finalized: Club = {
      ...draft,
      abbr: draft.abbr.toUpperCase().slice(0, 3) || 'FC7',
      ovr: avg(draft.players),
      att: avg(draft.players.filter((p) => p.position === 'ATA')),
      mid: avg(draft.players.filter((p) => p.position === 'MEI' || p.position === 'VOL')),
      def: avg(draft.players.filter((p) => p.position === 'ZAG' || p.position === 'GOL')),
    };
    onSaveClub(finalized);
    setDraft(finalized);
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 1800);
  };

  const focusedPlayer = draft.players[focusedPlayerIdx] || draft.players[0];

  return (
    <div className="relative z-10 h-full overflow-y-auto px-4 sm:px-8 py-5 max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Club List */}
        <div className="lg:col-span-4 bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h2 className="font-display font-bold text-xl text-slate-900 dark:text-white">
              {t.navEditor}
            </h2>
            <button
              onClick={handleCreateNew}
              className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.createClub}</span>
            </button>
          </div>
          <div className="space-y-1.5 max-h-[640px] overflow-y-auto pr-1">
            {clubs.map((c) => (
              <button
                key={c.id}
                onClick={() => selectClub(c)}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-left transition-colors ${
                  c.id === draft.id
                    ? 'border-amber-400 bg-amber-400/10'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <ClubCrest club={c} size={30} />
                  <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {c.name}
                  </span>
                </div>
                <span className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                  {c.abbr} · {c.ovr}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Club Identity, Kit Customizer & Player Customizer */}
        <div className="lg:col-span-8 space-y-5">
          {/* Club Identity Card */}
          <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-4">
                <ClubCrest club={draft} size={62} />
                <div>
                  <div className="font-display font-extrabold text-2xl text-slate-900 dark:text-white">
                    {draft.name}
                  </div>
                  <div className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                    {draft.abbr} · OVR {draft.ovr}
                  </div>
                </div>
              </div>
              <button
                onClick={handleSave}
                className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>{savedNotice ? 'OK' : t.saveClub}</span>
              </button>
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  {t.clubName}
                </label>
                <input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  {t.clubAbbr}
                </label>
                <input
                  maxLength={3}
                  value={draft.abbr}
                  onChange={(e) => setDraft({ ...draft, abbr: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-sm font-mono-num uppercase text-slate-900 dark:text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    {t.primaryColor}
                  </label>
                  <input
                    type="color"
                    value={draft.primaryColor}
                    onChange={(e) => setDraft({ ...draft, primaryColor: e.target.value })}
                    className="w-full h-9 rounded-lg cursor-pointer bg-transparent"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    {t.secondaryColor}
                  </label>
                  <input
                    type="color"
                    value={draft.secondaryColor}
                    onChange={(e) => setDraft({ ...draft, secondaryColor: e.target.value })}
                    className="w-full h-9 rounded-lg cursor-pointer bg-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  {t.crestPattern}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {PATTERNS.map((pat) => (
                    <button
                      key={pat}
                      onClick={() => setDraft({ ...draft, pattern: pat })}
                      className={`px-2.5 py-1 rounded text-xs font-semibold capitalize ${
                        draft.pattern === pat
                          ? 'bg-amber-400 text-slate-950'
                          : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {pat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  {t.crestIcon}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {ICONS.map((ic) => (
                    <button
                      key={ic}
                      onClick={() => setDraft({ ...draft, icon: ic })}
                      className={`px-2.5 py-1 rounded text-xs font-semibold capitalize ${
                        draft.icon === ic
                          ? 'bg-amber-400 text-slate-950'
                          : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {ic}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* HOME & AWAY KIT CUSTOMIZER + LIVE PLAYER PREVIEW */}
          <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2">
                <Shirt className="w-5 h-5 text-amber-500 dark:text-amber-400" />
                <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                  {t.kitCustomizer}
                </h3>
              </div>

              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                <button
                  onClick={() => setKitTab('home')}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                    kitTab === 'home'
                      ? 'bg-amber-400 text-slate-950'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.homeKit}
                </button>
                <button
                  onClick={() => setKitTab('away')}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                    kitTab === 'away'
                      ? 'bg-amber-400 text-slate-950'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {t.awayKit}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
              {/* Live SVG Kit + Player Avatar Preview */}
              <div className="md:col-span-4 flex flex-col items-center justify-center p-4 rounded-xl bg-slate-100 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800">
                <PlayerKitPreview kit={activeKit} player={focusedPlayer} />
                <div className="mt-2 text-center">
                  <div className="font-display font-bold text-base text-slate-900 dark:text-white">
                    #{focusedPlayer.number} · {focusedPlayer.name}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {t[`hair_${focusedPlayer.hairStyle ?? 'short'}`]} · {kitTab === 'home' ? t.homeKit : t.awayKit}
                  </div>
                </div>
              </div>

              {/* Kit Colors, Presets & Pattern */}
              <div className="md:col-span-8 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                    {t.kitPresets}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {KIT_COLOR_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        onClick={() =>
                          updateActiveKit({
                            primaryColor: preset.primaryColor,
                            secondaryColor: preset.secondaryColor,
                            shortsColor: preset.shortsColor,
                          })
                        }
                        title={preset.name}
                        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-amber-400 text-[11px] font-semibold text-slate-700 dark:text-slate-200"
                      >
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-white/40"
                          style={{
                            background: `linear-gradient(135deg, ${preset.primaryColor} 50%, ${preset.secondaryColor} 50%)`,
                          }}
                        />
                        <span>{preset.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                      {t.primaryColor}
                    </label>
                    <input
                      type="color"
                      value={activeKit.primaryColor}
                      onChange={(e) => updateActiveKit({ primaryColor: e.target.value })}
                      className="w-full h-9 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                      {t.secondaryColor}
                    </label>
                    <input
                      type="color"
                      value={activeKit.secondaryColor}
                      onChange={(e) => updateActiveKit({ secondaryColor: e.target.value })}
                      className="w-full h-9 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                      {t.shortsColor}
                    </label>
                    <input
                      type="color"
                      value={activeKit.shortsColor}
                      onChange={(e) => updateActiveKit({ shortsColor: e.target.value })}
                      className="w-full h-9 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                    {t.kitPattern}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {PATTERNS.map((pat) => (
                      <button
                        key={pat}
                        onClick={() => updateActiveKit({ pattern: pat })}
                        className={`px-2.5 py-1 rounded text-xs font-semibold capitalize ${
                          activeKit.pattern === pat
                            ? 'bg-amber-400 text-slate-950'
                            : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {pat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Squad & Player Appearance Editor */}
          <div className="bg-white/95 dark:bg-[#0B1120]/92 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-amber-500 dark:text-amber-400" />
                <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white">
                  {t.squadEditor}
                </h3>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                #{focusedPlayer.number} · {focusedPlayer.name}
              </span>
            </div>

            {/* Selected Player Quick Hairstyle & Hair Color Bar */}
            <div className="mb-3 p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mr-1">
                  {t.hairstyle}:
                </span>
                {HAIRSTYLE_OPTIONS.map((hs) => (
                  <button
                    key={hs}
                    onClick={() => updatePlayer(focusedPlayerIdx, { hairStyle: hs })}
                    className={`px-2.5 py-1 rounded text-xs font-semibold ${
                      (focusedPlayer.hairStyle ?? 'short') === hs
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {t[`hair_${hs}`]}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mr-1">
                  {t.hairColor}:
                </span>
                {HAIR_COLOR_PRESETS.map((hc) => (
                  <button
                    key={hc}
                    onClick={() => updatePlayer(focusedPlayerIdx, { hairColor: hc })}
                    className={`w-5 h-5 rounded-full border-2 ${
                      (focusedPlayer.hairColor ?? '#1E1B18').toUpperCase() === hc.toUpperCase()
                        ? 'border-amber-400 scale-110'
                        : 'border-white/40'
                    }`}
                    style={{ backgroundColor: hc }}
                    aria-label={hc}
                  />
                ))}
                <input
                  type="color"
                  value={focusedPlayer.hairColor ?? '#1E1B18'}
                  onChange={(e) => updatePlayer(focusedPlayerIdx, { hairColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent"
                  aria-label={t.hairColor}
                />
              </div>
            </div>

            <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
              {draft.players.map((pl, idx) => {
                const isFocused = idx === focusedPlayerIdx;
                return (
                  <div
                    key={pl.id}
                    onClick={() => setFocusedPlayerIdx(idx)}
                    className={`grid grid-cols-12 items-center gap-2 p-2 rounded-lg border cursor-pointer transition-colors ${
                      isFocused
                        ? 'bg-amber-400/12 border-amber-400'
                        : 'bg-slate-100 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <input
                      value={pl.name}
                      onChange={(e) => updatePlayer(idx, { name: e.target.value })}
                      className="col-span-4 px-2.5 py-1.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-900 dark:text-white"
                    />
                    <select
                      value={pl.position}
                      onChange={(e) => updatePlayer(idx, { position: e.target.value as PlayerPosition })}
                      className="col-span-2 px-2 py-1.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono-num text-slate-900 dark:text-white"
                    >
                      {POSITIONS.map((pos) => (
                        <option key={pos} value={pos}>
                          {pos}
                        </option>
                      ))}
                    </select>
                    <select
                      value={pl.hairStyle ?? 'short'}
                      onChange={(e) => updatePlayer(idx, { hairStyle: e.target.value as HairStyle })}
                      className="col-span-2 px-1.5 py-1.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    >
                      {HAIRSTYLE_OPTIONS.map((hs) => (
                        <option key={hs} value={hs}>
                          {t[`hair_${hs}`]}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min={1}
                      max={99}
                      value={pl.number}
                      onChange={(e) =>
                        updatePlayer(idx, { number: Math.min(99, Math.max(1, Number(e.target.value) || 1)) })
                      }
                      title={t.number}
                      className="col-span-2 px-2 py-1.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono-num text-center text-slate-900 dark:text-white"
                    />
                    <input
                      type="number"
                      min={70}
                      max={99}
                      value={pl.ovr}
                      onChange={(e) =>
                        updatePlayer(idx, { ovr: Math.min(99, Math.max(70, Number(e.target.value) || 75)) })
                      }
                      title={t.overall}
                      className="col-span-2 px-2 py-1.5 rounded bg-amber-400/20 border border-amber-400/60 text-xs font-mono-num font-bold text-center text-amber-600 dark:text-amber-300"
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
