import React, { useState } from 'react';
import {
  X,
  Printer,
  Edit2,
  Trash2,
  CheckCircle,
  Clock,
  MapPin,
  User,
  ShieldCheck,
  Maximize2,
  Tag,
  Share2
} from 'lucide-react';
import { OperationalReport, Sector, ReportImage } from '../types/report';
import {
  formatDate,
  formatDateTime,
  getStatusLabel,
  getStatusTextColor,
  getPriorityLabel,
  getPriorityTextColor,
  getShiftLabel
} from '../utils/formatters';
import { SectorIcon } from './SectorIcon';

interface Props {
  report: OperationalReport | null;
  sectors: Sector[];
  onClose: () => void;
  onEdit: (report: OperationalReport) => void;
  onDelete: (id: string) => void;
  onOpenPhotoLightbox: (image: ReportImage, report: OperationalReport) => void;
  onUpdateReport: (updated: OperationalReport) => void;
}

export const ReportDetailModal: React.FC<Props> = ({
  report,
  sectors,
  onClose,
  onEdit,
  onDelete,
  onOpenPhotoLightbox,
  onUpdateReport
}) => {
  if (!report) return null;

  const sector = sectors.find((s) => s.id === report.sectorId);
  const [supervisorName, setSupervisorName] = useState(
    report.supervisorSignoff?.supervisorName || ''
  );
  const [supervisorNotes, setSupervisorNotes] = useState(
    report.supervisorSignoff?.notes || ''
  );
  const [isSigning, setIsSigning] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleSignoff = () => {
    if (!supervisorName.trim()) return;
    const updated: OperationalReport = {
      ...report,
      supervisorSignoff: {
        signed: true,
        supervisorName: supervisorName.trim(),
        signedAt: new Date().toISOString(),
        notes: supervisorNotes.trim()
      },
      updatedAt: new Date().toISOString()
    };
    onUpdateReport(updated);
    setIsSigning(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-neutral-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden my-auto">
        {/* Modal Top Bar (no-print) */}
        <div className="px-6 py-3.5 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-50 no-print">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-semibold text-neutral-900 bg-neutral-200 px-2 py-0.5 rounded tabular-nums">
              {report.protocolNumber}
            </span>
            <span className="text-xs text-neutral-500">
              {sector?.name}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              title="Stampa Scheda PDF"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-white border border-neutral-300 rounded-md hover:bg-neutral-100 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Stampa / Salva PDF</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onEdit(report);
              }}
              title="Modifica"
              className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors"
            >
              <Edit2 className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                if (window.confirm('Eliminare definitivamente questo report?')) {
                  onDelete(report.id);
                  onClose();
                }
              }}
              title="Elimina"
              className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <div className="w-px h-5 bg-neutral-200 mx-1" />

            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-md transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Content / Printable Document Area */}
        <div className="flex-1 overflow-y-auto p-8 space-y-6 text-neutral-900 print:p-0 print:m-0">
          {/* Printable Header Section */}
          <div className="border-b border-neutral-300 pb-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
                  Verbale Operativo Aziendale · Scheda di Reparto
                </div>
                <h1 className="text-xl font-bold text-neutral-900 leading-tight">
                  {report.title}
                </h1>
              </div>

              <div className="text-right shrink-0">
                <div className="font-mono text-sm font-bold text-neutral-900 tabular-nums">
                  {report.protocolNumber}
                </div>
                <div className="text-xs text-neutral-500 mt-0.5">
                  Registrato: {formatDateTime(report.timestamp)}
                </div>
              </div>
            </div>

            {/* Metadata Bar */}
            <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-neutral-600 pt-3 border-t border-neutral-100">
              <div className="flex items-center gap-1.5">
                <SectorIcon name={sector?.iconName || 'Layers'} className="w-3.5 h-3.5 text-neutral-500" />
                <span className="font-medium text-neutral-900">{sector?.name}</span>
              </div>
              <span className="text-neutral-300">·</span>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                <span>{getShiftLabel(report.shift)}</span>
              </div>
              <span className="text-neutral-300">·</span>
              <div className="flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-neutral-400" />
                <span>Compilatore: <strong className="text-neutral-800">{report.operatorName}</strong> ({report.operatorRole})</span>
              </div>
              <span className="text-neutral-300">·</span>
              <div className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                <span>{report.location}</span>
              </div>
              <span className="text-neutral-300">·</span>
              <div>
                Stato: <span className={getStatusTextColor(report.status)}>{getStatusLabel(report.status)}</span>
              </div>
              <span className="text-neutral-300">·</span>
              <div>
                Priorità: <span className={getPriorityTextColor(report.priority)}>{getPriorityLabel(report.priority)}</span>
              </div>
            </div>
          </div>

          {/* Dynamic Metrics Table if present */}
          {report.metrics && Object.keys(report.metrics).length > 0 && (
            <div className="border border-neutral-200 rounded-lg overflow-hidden">
              <div className="bg-neutral-100/70 px-4 py-2 text-xs font-semibold text-neutral-700 border-b border-neutral-200">
                Parametri Tecnici & Metriche di Settore ({sector?.name})
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0 divide-neutral-200 bg-neutral-50/40">
                {Object.entries(report.metrics).map(([key, val]) => {
                  const fieldDef = sector?.metricFields?.find((f) => f.key === key);
                  const label = fieldDef?.label || key;
                  const unit = fieldDef?.unit ? ` ${fieldDef.unit}` : '';

                  return (
                    <div key={key} className="p-3">
                      <div className="text-[11px] text-neutral-500">{label}</div>
                      <div className="text-sm font-semibold text-neutral-900 font-mono tabular-nums mt-0.5">
                        {String(val)}{unit}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Description & Notes */}
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Descrizione Operativa & Rilievi
              </h3>
              <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 text-xs leading-relaxed text-neutral-800 whitespace-pre-wrap">
                {report.description || 'Nessuna descrizione specificata.'}
              </div>
            </div>

            {report.correctiveActions && (
              <div>
                <h3 className="text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Azioni Correttive Intraprese / Prescrizioni
                </h3>
                <div className="p-4 bg-amber-50/50 rounded-lg border border-amber-200 text-xs leading-relaxed text-neutral-800 whitespace-pre-wrap">
                  {report.correctiveActions}
                </div>
              </div>
            )}
          </div>

          {/* Images Section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold text-neutral-700 uppercase tracking-wider">
                Documentazione Fotografica ({report.images.length})
              </h3>
            </div>

            {report.images.length === 0 ? (
              <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200 text-center text-xs text-neutral-400">
                Nessuna fotografia o allegato grafico inserito per questo report.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {report.images.map((img, idx) => (
                  <div
                    key={img.id}
                    className="border border-neutral-200 rounded-lg overflow-hidden bg-neutral-50 flex flex-col justify-between"
                  >
                    <div
                      className="relative aspect-4/3 bg-neutral-200 cursor-pointer overflow-hidden group"
                      onClick={() => onOpenPhotoLightbox(img, report)}
                    >
                      <img
                        src={img.url}
                        alt={img.caption || `Foto ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-200"
                      />
                      <div className="absolute top-2 left-2 text-[10px] font-semibold text-white bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                        {img.tag}
                      </div>
                      <div className="absolute top-2 right-2 w-7 h-7 rounded bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Maximize2 className="w-3.5 h-3.5" />
                      </div>
                    </div>

                    <div className="p-3 bg-white border-t border-neutral-200 text-xs">
                      <div className="font-medium text-neutral-800">
                        {img.caption || `Fotografia #${idx + 1}`}
                      </div>
                      <div className="text-[10px] text-neutral-400 mt-1 font-mono tabular-nums">
                        Caricata il: {formatDateTime(img.uploadedAt)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Digital Sign-off Section */}
          <div className="pt-4 border-t border-neutral-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-neutral-700 uppercase tracking-wider">
                Visto di Convalida & Firma del Responsabile
              </h3>
              {!report.supervisorSignoff?.signed && !isSigning && (
                <button
                  onClick={() => setIsSigning(true)}
                  className="text-xs font-semibold text-neutral-900 hover:underline no-print"
                >
                  + Apponi Firma o Convalida
                </button>
              )}
            </div>

            {report.supervisorSignoff?.signed ? (
              <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-lg flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs">
                  <div className="font-semibold text-emerald-900">
                    Scheda Convalidata & Approvata
                  </div>
                  <div className="text-emerald-800">
                    Responsabile: <strong>{report.supervisorSignoff.supervisorName}</strong>
                  </div>
                  <div className="text-emerald-700 text-[11px] font-mono tabular-nums">
                    Data firma: {formatDateTime(report.supervisorSignoff.signedAt || report.timestamp)}
                  </div>
                  {report.supervisorSignoff.notes && (
                    <div className="text-emerald-900 text-[11px] italic mt-1 pt-1 border-t border-emerald-200">
                      Note del supervisore: &ldquo;{report.supervisorSignoff.notes}&rdquo;
                    </div>
                  )}
                </div>
              </div>
            ) : isSigning ? (
              <div className="p-4 bg-neutral-50 border border-neutral-300 rounded-lg space-y-3 no-print">
                <div className="text-xs font-semibold text-neutral-800">
                  Convalida del Responsabile / Supervisore di Turno
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">
                      Nome e Titolo del Responsabile
                    </label>
                    <input
                      type="text"
                      value={supervisorName}
                      onChange={(e) => setSupervisorName(e.target.value)}
                      placeholder="es. Ing. Claudio Vianello (Direttore di Stabilimento)"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-neutral-600 mb-1">
                      Note di conformità o prescrizioni
                    </label>
                    <input
                      type="text"
                      value={supervisorNotes}
                      onChange={(e) => setSupervisorNotes(e.target.value)}
                      placeholder="es. Verificate le contromisure applicate. Parametri regolari."
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2 justify-end">
                  <button
                    onClick={() => setIsSigning(false)}
                    className="px-3 py-1 text-xs text-neutral-600 hover:bg-neutral-200 rounded"
                  >
                    Annulla
                  </button>
                  <button
                    onClick={handleSignoff}
                    disabled={!supervisorName.trim()}
                    className="px-3.5 py-1 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded transition-colors disabled:opacity-50"
                  >
                    Conferma Approvazione
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg text-xs text-neutral-500">
                In attesa di firma / visto di supervisione.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
