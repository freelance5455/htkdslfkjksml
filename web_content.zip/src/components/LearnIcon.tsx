import React from 'react';
import { BookOpen, Sparkles } from 'lucide-react';

interface LearnIconProps {
  className?: string;
  isActive?: boolean;
  active?: boolean;
  size?: number;
}

export default function LearnIcon({ 
  className = 'w-5 h-5', 
  isActive = false, 
  active = false,
  size = 20 
}: LearnIconProps) {
  const isSelected = isActive || active;

  return (
    <div className="relative inline-flex items-center justify-center">
      {/* Ambient glowing aura when active */}
      {isSelected && (
        <span className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600/40 via-indigo-500/40 to-blue-500/40 blur-sm animate-pulse" />
      )}
      
      {/* Base Open Book Icon */}
      <BookOpen 
        className={`${className} transition-transform duration-300 ${isSelected ? 'text-indigo-300 scale-105' : 'text-slate-400'}`} 
        style={{ width: size, height: size }}
      />

      {/* Floating AI Sparkle Badge Overlay */}
      <span className="absolute -top-1.5 -right-1.5 flex items-center justify-center">
        <Sparkles 
          className={`w-3.5 h-3.5 ${
            isSelected 
              ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)] animate-bounce' 
              : 'text-purple-400 opacity-80'
          }`} 
        />
      </span>
    </div>
  );
}
