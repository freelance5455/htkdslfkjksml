import React from 'react';
import { History, X, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { ShotRecord } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface ShotHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  historyLogs: ShotRecord[];
  onUndo: () => void;
  canUndo: boolean;
}

export const ShotHistoryModal: React.FC<ShotHistoryModalProps> = ({
  isOpen,
  onClose,
  historyLogs,
  onUndo,
  canUndo,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700/80 p-5 shadow-2xl text-slate-100 flex flex-col max-h-[85vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-xl border border-blue-500/30">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">تاریخچه ضربات و رخدادها</h2>
              <p className="text-xs text-slate-400">
                مجموع ضربات ثبت شده: {toPersianDigits(historyLogs.length)}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 my-2">
          {historyLogs.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              هنوز هیچ ضربه‌ای در این بازی ثبت نشده است.
            </div>
          ) : (
            [...historyLogs].reverse().map((record, index) => {
              const isHit = record.mode === 'hit';
              const isFoul = record.isFoul;
              const date = new Date(record.timestamp);
              const timeStr = `${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}:${String(
                date.getSeconds()
              ).padStart(2, '0')}`;

              return (
                <div
                  key={record.id || index}
                  className={`p-3 rounded-2xl border text-xs flex items-center justify-between gap-3 ${
                    isFoul
                      ? 'bg-rose-950/20 border-rose-900/40 text-rose-200'
                      : isHit
                      ? 'bg-slate-950/40 border-slate-800/80 text-slate-200'
                      : 'bg-slate-950/40 border-slate-800/80 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {isFoul ? (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    ) : (
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 ${isHit ? 'text-emerald-400' : 'text-slate-500'}`}
                      />
                    )}

                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <strong className="text-white font-bold">{record.playerName}</strong>
                        {isFoul ? (
                          <span className="text-rose-400 font-semibold">
                            {record.foulReason || 'خطا'}
                          </span>
                        ) : isHit ? (
                          <span className="text-emerald-300">
                            پاکت {record.ballName}
                          </span>
                        ) : (
                          <span className="text-slate-400">
                            ضربه ناموفق به {record.ballName}
                          </span>
                        )}
                      </div>
                      {record.opponentAwardedName && (
                        <span className="text-[11px] text-emerald-400">
                          (اعطای {toPersianDigits(record.points)} امتیاز به {record.opponentAwardedName})
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span
                      className={`font-black text-sm px-2 py-0.5 rounded-lg ${
                        isFoul
                          ? 'text-rose-400 bg-rose-950/60 border border-rose-800/50'
                          : isHit
                          ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/50'
                          : 'text-rose-400 bg-slate-900'
                      }`}
                    >
                      {isHit ? `+${toPersianDigits(record.points)}` : `-${toPersianDigits(record.points)}`}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {toPersianDigits(timeStr)}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with Undo action */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
            <span>بازگشت آخرین ضربه (Undo)</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-xs transition-colors cursor-pointer"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
