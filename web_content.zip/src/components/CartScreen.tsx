import React, { useState } from 'react';
import { Trash2, Tag, ArrowRight, ShieldCheck, Check, ShoppingBag, MessageCircle } from 'lucide-react';
import { CartItem } from '../types/ecommerce';
import { VENDORS } from '../data/mockData';

interface CartScreenProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onToggleSelect: (id: string) => void;
  onSelectAll: (selected: boolean) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
  appliedCoupon: string | null;
  discountAmount: number;
  onApplyCoupon: (code: string) => boolean;
  onOpenWhatsAppOrder?: () => void;
}

export const CartScreen: React.FC<CartScreenProps> = ({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onToggleSelect,
  onSelectAll,
  onProceedToCheckout,
  onContinueShopping,
  appliedCoupon,
  discountAmount,
  onApplyCoupon,
  onOpenWhatsAppOrder
}) => {
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [couponSuccess, setCouponSuccess] = useState<string | null>(null);

  const selectedItems = cartItems.filter(i => i.selected);
  const allSelected = cartItems.length > 0 && selectedItems.length === cartItems.length;

  // Group by vendor
  const vendorGroups: { [vendorId: string]: CartItem[] } = {};
  cartItems.forEach(item => {
    const vId = item.product.vendorId || 'v1';
    if (!vendorGroups[vId]) vendorGroups[vId] = [];
    vendorGroups[vId].push(item);
  });

  const subtotal = selectedItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const shippingFee = selectedItems.length > 0 
    ? (selectedItems.every(i => i.product.freeShipping) ? 0 : 350)
    : 0;
  const finalTotal = Math.max(0, subtotal + shippingFee - discountAmount);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    setCouponSuccess(null);
    if (!couponInput.trim()) return;

    const ok = onApplyCoupon(couponInput.trim().toUpperCase());
    if (ok) {
      setCouponSuccess(`Coupon ${couponInput.toUpperCase()} applied successfully!`);
      setCouponInput('');
    } else {
      setCouponError('Invalid coupon. Try "SEWORA50" for 15% off or "FREESHIP"');
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="pb-24 pt-12 px-4 bg-slate-50 min-h-screen flex flex-col items-center justify-center text-center">
        <div className="w-20 h-20 bg-orange-100 text-[#FF6600] rounded-full flex items-center justify-center mb-4">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-base font-bold text-slate-900">Your Cart is Empty</h2>
        <p className="text-xs text-slate-500 mt-1 max-w-xs">
          Explore today&apos;s flash sales and discover curated items with free islandwide delivery.
        </p>
        <button
          onClick={onContinueShopping}
          className="mt-6 bg-[#FF6600] text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-md hover:bg-orange-600 transition-colors"
        >
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="pb-28 bg-slate-100 min-h-screen">
      {/* Top Header */}
      <div className="bg-white px-3 py-3 border-b border-slate-200 sticky top-0 z-20 flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-900">
          Shopping Cart ({cartItems.length})
        </h2>
        <button
          onClick={() => onSelectAll(!allSelected)}
          className="text-xs font-semibold text-[#FF6600] hover:underline"
        >
          {allSelected ? 'Deselect All' : 'Select All'}
        </button>
      </div>

      {/* Cart Items Grouped By Vendor */}
      <div className="p-2 space-y-3">
        {Object.entries(vendorGroups).map(([vId, items]) => {
          const vendor = VENDORS[vId] || { name: 'Verified Seller', badge: 'Verified' };

          return (
            <div key={vId} className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
              {/* Vendor Header */}
              <div className="px-3 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-800">{vendor.name}</span>
                  <span className="bg-[#FF6600] text-white text-[8px] font-black px-1 rounded uppercase">
                    {vendor.badge}
                  </span>
                </div>
                <span className="text-[10px] text-emerald-600 font-medium">Free Islandwide Return</span>
              </div>

              {/* Items */}
              <div className="divide-y divide-slate-100">
                {items.map((item) => (
                  <div key={item.id} className="p-3 flex items-start gap-2.5">
                    {/* Checkbox */}
                    <input
                      type="checkbox"
                      checked={item.selected}
                      onChange={() => onToggleSelect(item.id)}
                      className="mt-5 w-4 h-4 rounded border-slate-300 text-[#FF6600] focus:ring-[#FF6600] cursor-pointer"
                    />

                    {/* Image */}
                    <div className="w-16 h-16 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-semibold text-slate-900 truncate">
                        {item.product.title}
                      </h4>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {item.selectedColor} {item.selectedSize ? `· Size ${item.selectedSize}` : ''}
                      </div>

                      <div className="flex items-center justify-between mt-2">
                        <div className="text-xs font-bold text-[#FF6600] tabular-nums">
                          Rs. {(item.product.price * item.quantity).toLocaleString()}
                        </div>

                        {/* Quantity Counter & Delete */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onRemoveItem(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                            aria-label="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                            <button
                              onClick={() => onUpdateQuantity(item.id, -1)}
                              className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-200"
                            >
                              -
                            </button>
                            <span className="w-7 text-center text-xs font-bold tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, 1)}
                              className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-200"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Voucher / Coupon Code Application Section */}
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-2xs space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
            <Tag className="w-3.5 h-3.5 text-[#FF6600]" />
            <span>Sewora Voucher & Promo Code</span>
          </div>

          <form onSubmit={handleApply} className="flex gap-2">
            <input
              type="text"
              value={couponInput}
              onChange={(e) => setCouponInput(e.target.value)}
              placeholder="Enter 'SEWORA50' or 'FREESHIP'"
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none uppercase"
            />
            <button
              type="submit"
              className="bg-slate-900 text-white text-xs font-bold px-4 py-1.5 rounded-xl hover:bg-slate-800 transition-colors"
            >
              Apply
            </button>
          </form>

          {couponSuccess && (
            <div className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>{couponSuccess}</span>
            </div>
          )}
          {couponError && (
            <div className="text-[11px] text-rose-500 font-medium">
              {couponError}
            </div>
          )}
          {appliedCoupon && (
            <div className="flex items-center justify-between text-xs bg-orange-50 border border-orange-200 p-2 rounded-xl text-[#FF6600] font-semibold">
              <span>Applied: {appliedCoupon}</span>
              <span>-Rs. {discountAmount.toLocaleString()}</span>
            </div>
          )}
        </div>

        {/* Price Breakdown */}
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-2xs space-y-1.5 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal ({selectedItems.length} items)</span>
            <span className="font-semibold tabular-nums">Rs. {subtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Shipping Fee</span>
            <span className="font-semibold tabular-nums">
              {shippingFee === 0 ? 'FREE' : `Rs. ${shippingFee}`}
            </span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>Voucher Discount</span>
              <span className="tabular-nums">-Rs. {discountAmount.toLocaleString()}</span>
            </div>
          )}
          <div className="border-t border-slate-100 pt-2 flex justify-between text-sm font-black text-slate-900">
            <span>Estimated Total</span>
            <span className="text-[#FF6600] tabular-nums">Rs. {finalTotal.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Checkout Action */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xl max-w-md mx-auto md:max-w-none">
        <div>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Total to Pay</span>
          <div className="text-base font-extrabold text-[#FF6600] tabular-nums">
            Rs. {finalTotal.toLocaleString()}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenWhatsAppOrder && (
            <button
              onClick={onOpenWhatsAppOrder}
              disabled={selectedItems.length === 0}
              className="bg-[#25D366] hover:bg-emerald-600 text-white font-bold text-xs p-2.5 rounded-xl shadow-xs disabled:opacity-40 transition-all flex items-center gap-1"
              title="Order Cart via WhatsApp"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span className="hidden sm:inline">WhatsApp Order</span>
            </button>
          )}

          <button
            onClick={onProceedToCheckout}
            disabled={selectedItems.length === 0}
            className="bg-[#FF6600] text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md hover:bg-orange-600 disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1.5 transition-all"
          >
            <span>Checkout ({selectedItems.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
