/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Mic, Send, Keyboard } from 'lucide-react';
import { VoiceModeState } from '../types/assistant';

interface CommandBarProps {
  voiceState: VoiceModeState;
  isContinuousActive: boolean;
  onToggleContinuousVoice: () => void;
  onSubmitText: (text: string) => void;
  onOpenSettings: () => void;
}

export const CommandBar: React.FC<CommandBarProps> = ({
  voiceState,
  isContinuousActive,
  onToggleContinuousVoice,
  onSubmitText,
  onOpenSettings,
}) => {
  const [inputText, setInputText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed) return;
    onSubmitText(trimmed);
    setInputText('');
  };

  const handleKeyboardClick = () => {
    inputRef.current?.focus();
  };

  const isProcessing = voiceState === 'PROCESSING';

  return (
    <div className="w-full max-w-xl mx-auto px-4 pb-6 sm:pb-8 relative z-20 flex flex-col items-center select-none">
      {/* Centered Prompt */}
      <h2 className="text-sm sm:text-base font-rajdhani font-medium tracking-wider text-slate-200 mb-4 sm:mb-5">
        How can I help you today?
      </h2>

      {/* Futuristic Command Row (Keyboard Button + Capsule Input + Circular Mic) */}
      <div className="w-full flex items-center justify-center gap-3 sm:gap-4">
        {/* 1. Left Circular Keyboard Button */}
        <button
          type="button"
          onClick={handleKeyboardClick}
          className="w-12 h-12 rounded-full bg-slate-950/80 border border-cyan-500/40 text-cyan-400 hover:text-cyan-200 hover:border-cyan-400/80 hover:bg-cyan-950/30 flex items-center justify-center transition-all duration-200 active:scale-95 shadow-lg shadow-cyan-950/50 flex-shrink-0"
          title="Type command"
          aria-label="Type command"
        >
          <Keyboard className="w-5 h-5 text-cyan-300" />
        </button>

        {/* 2. Center Capsule Input Bar */}
        <form
          onSubmit={handleSubmit}
          className="flex-1 max-w-md h-12 flex items-center gap-2 bg-slate-950/70 border-2 border-cyan-500/60 rounded-full px-4 sm:px-5 shadow-[0_0_20px_rgba(6,182,212,0.25)] relative transition-all focus-within:border-cyan-400 focus-within:shadow-[0_0_25px_rgba(6,182,212,0.45)]"
        >
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type your command..."
            disabled={isProcessing}
            className="flex-1 bg-transparent text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none tracking-wide font-sans disabled:opacity-50"
          />

          {/* Send Arrow Button */}
          <button
            type="submit"
            disabled={!inputText.trim() || isProcessing}
            aria-label="Send command"
            className="p-1.5 text-cyan-400 hover:text-cyan-200 disabled:opacity-30 disabled:pointer-events-none transition-colors active:scale-90 flex-shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

        {/* 3. Right Large Circular Microphone Button (Continuous Voice Mode Toggle) */}
        <button
          type="button"
          onClick={onToggleContinuousVoice}
          aria-label={isContinuousActive ? 'Turn Voice Mode Off' : 'Turn Continuous Voice Mode On'}
          title={isContinuousActive ? 'Continuous Voice Active (Tap to turn OFF)' : 'Tap to start Continuous Voice Mode'}
          className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 active:scale-95 flex-shrink-0 relative ${
            isContinuousActive
              ? 'bg-cyan-500 text-slate-950 shadow-[0_0_30px_rgba(6,182,212,0.7)] ring-4 ring-cyan-300/60'
              : 'bg-slate-950/90 text-cyan-400 border-2 border-cyan-400/70 hover:border-cyan-300 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]'
          }`}
        >
          {/* Subtle Outer Glowing Ripple when Listening */}
          {isContinuousActive && voiceState === 'LISTENING' && (
            <span className="absolute inset-0 rounded-full ring-2 ring-cyan-400 animate-ping opacity-60" />
          )}
          <Mic className={`w-6 h-6 ${isContinuousActive ? 'text-slate-950' : 'text-cyan-400'}`} />
        </button>
      </div>

      {/* Command Suggestion Hint */}
      <p className="text-[11px] sm:text-xs text-slate-400/80 font-sans tracking-wide mt-3.5 text-center">
        &ldquo;Try saying: &lsquo;Open YouTube&rsquo; or &lsquo;What&rsquo;s the weather today?&rsquo;&rdquo;
      </p>
    </div>
  );
};
