import React, { useState } from 'react';
import { QuantumSignal, TradeOrder } from '../types/trading';
import {
  ArrowUpRight,
  ArrowDownRight,
  ChevronDown,
  ChevronUp,
  Zap,
  Send,
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Target,
  ShieldAlert,
  Check,
  X,
  RefreshCw,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
} from 'lucide-react';
import { soundManager } from '../utils/soundEffects';
import { voiceNarrator } from '../utils/voiceNarrator';

interface SignalCardProps {
  signal: QuantumSignal;
  entrySecondsLeft: number;
  tradeEndsSecondsLeft: number;
  onExecuteTrade: () => void;
  isExecuting?: boolean;
  activeTrade?: TradeOrder | null;
  autoExecute: boolean;
  onToggleAutoExecute: () => void;
  onOpenPhotoAnalysis?: () => void;
  onRefreshSignal?: () => void;
}

export const SignalCard: React.FC<SignalCardProps> = ({
  signal,
  entrySecondsLeft,
  tradeEndsSecondsLeft,
  onExecuteTrade,
  isExecuting = false,
  activeTrade,
  autoExecute,
  onToggleAutoExecute,
  onOpenPhotoAnalysis,
  onRefreshSignal,
}) => {
  const [showIndicators, setShowIndicators] = useState(false);
  const [isVoiceSpeaking, setIsVoiceSpeaking] = useState(false);
  const [autoVoice, setAutoVoice] = useState(() => voiceNarrator.isAutoSpeak());
  const isUp = signal.direction === 'UP';

  const handleSpeakVoice = () => {
    if (isVoiceSpeaking) {
      voiceNarrator.stop();
      setIsVoiceSpeaking(false);
    } else {
      soundManager.playPip();
      setIsVoiceSpeaking(true);
      voiceNarrator.speakMarketNarrative(signal);
      setTimeout(() => {
        setIsVoiceSpeaking(false);
      }, 7000);
    }
  };

  const handleToggleAutoVoice = () => {
    soundManager.playPip();
    const next = !autoVoice;
    setAutoVoice(next);
    voiceNarrator.setAutoSpeak(next);
  };

  return (
    <div className="w-full flex flex-col items-center gap-3">
      {/* 0. Market Gatekeeper Quality Grade Banner */}
      {signal.qualityGrade === 'WAIT' ? (
        <div className="w-full max-w-md bg-amber-950/80 border border-amber-500/50 rounded-xl p-2.5 flex items-center gap-2 text-amber-200 text-xs shadow-md">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
          <div>
            <div className="font-bold text-amber-300">MARKET CHOPPINESS DETECTED (STANDBY)</div>
            <div className="text-[11px] text-amber-200/80">
              Low-volume or alternating doji candles. Trade with extreme caution or wait for clean breakout.
            </div>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-md bg-emerald-950/80 border border-emerald-500/50 rounded-xl p-2.5 flex items-center justify-between text-xs shadow-md">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-emerald-300 font-mono">⭐ GRADE A+ INSTITUTIONAL SETUP</span>
              <div className="text-[10px] text-emerald-200/80">Triple EMA + Closed Candle Momentum Confluence</div>
            </div>
          </div>
          <span className="px-2 py-0.5 bg-emerald-900/80 border border-emerald-400/40 rounded text-[10px] font-bold text-emerald-300 font-mono">
            CONFIRMED
          </span>
        </div>
      )}

      {/* 1. Large Circular Pulsing Signal Radar (Screenshot 1) */}
      <div className="relative my-2 flex items-center justify-center">
        {/* Outer ambient glow halo */}
        <div
          className={`absolute w-36 h-36 rounded-full blur-2xl opacity-40 transition-all ${
            isUp ? 'bg-emerald-500' : 'bg-red-500'
          }`}
        />

        {/* Circular Radar Container */}
        <div
          className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-full flex items-center justify-center border-4 transition-all shadow-2xl ${
            isUp
              ? 'border-emerald-500/80 bg-gradient-to-b from-emerald-950/60 to-[#0e2417] shadow-[0_0_35px_rgba(16,185,129,0.35)]'
              : 'border-red-500/80 bg-gradient-to-b from-red-950/60 to-[#270e17] shadow-[0_0_35px_rgba(239,68,68,0.35)]'
          }`}
        >
          {/* Inner ring */}
          <div
            className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full border border-dashed flex items-center justify-center ${
              isUp ? 'border-emerald-400/50' : 'border-red-400/50'
            }`}
          >
            {isUp ? (
              <svg className="w-12 h-12 text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                <polyline points="17 6 23 6 23 12"></polyline>
              </svg>
            ) : (
              <svg className="w-12 h-12 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline>
                <polyline points="17 18 23 18 23 12"></polyline>
              </svg>
            )}
          </div>
        </div>
      </div>

      {/* 2. Direction Badge */}
      <div className="flex flex-col items-center">
        <span
          className={`text-xs font-bold tracking-widest uppercase px-3 py-0.5 rounded-full border ${
            isUp
              ? 'bg-emerald-950/90 text-emerald-400 border-emerald-700/60 shadow-sm'
              : 'bg-red-950/90 text-red-400 border-red-700/60 shadow-sm'
          }`}
        >
          {signal.direction === 'UP' ? 'UPWARD' : 'DOWNWARD'}
        </span>

        {/* Action Title */}
        <h2
          className={`text-2xl sm:text-3xl font-black tracking-tight mt-1 transition-colors ${
            isUp
              ? 'text-emerald-400 drop-shadow-[0_0_12px_rgba(16,185,129,0.5)]'
              : 'text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.5)]'
          }`}
        >
          {signal.action}
        </h2>

        {/* Market Trend Basis */}
        <div className="text-[11px] font-mono text-zinc-400 mt-0.5 text-center px-2">
          {signal.trend}
        </div>

        {signal.isStrongSniper99 && (
          <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-950/60 border border-amber-500/40 px-2.5 py-0.5 rounded-full shadow-sm">
            <Zap className="w-3 h-3 fill-amber-300" />
            <span>99% STRONG SNIPER CONFLUENCE CONFIRMED</span>
          </div>
        )}
      </div>

      {/* 3. Signal Strength & Confidence Cards (Screenshot 1) */}
      <div className="w-full grid grid-cols-2 gap-2.5 max-w-md">
        {/* Signal Strength */}
        <div className="bg-[#1c0812]/90 border border-[#3b1224] rounded-xl p-3 flex flex-col items-center justify-center shadow-md">
          <span className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">
            SIGNAL STRENGTH
          </span>
          {/* Strength Dots */}
          <div className="flex items-center gap-1.5 my-2">
            {[1, 2, 3, 4, 5].map((dot) => {
              const active = dot <= signal.strength;
              return (
                <div
                  key={dot}
                  className={`w-3 h-3 rounded-full transition-all ${
                    active
                      ? isUp
                        ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                        : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]'
                      : 'bg-zinc-800/80'
                  }`}
                />
              );
            })}
          </div>
          <span
            className={`text-xs font-mono font-bold ${
              isUp ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {signal.strength}/5
          </span>
        </div>

        {/* Confidence */}
        <div className="bg-[#1c0812]/90 border border-[#3b1224] rounded-xl p-3 flex flex-col items-center justify-center shadow-md">
          <span className="text-[11px] font-bold tracking-wider text-zinc-400 uppercase">
            CONFIDENCE
          </span>
          <div
            className={`text-2xl sm:text-3xl font-black font-mono my-0.5 tabular-nums ${
              signal.confidence >= 95
                ? 'text-amber-300 drop-shadow-[0_0_10px_rgba(252,211,77,0.5)]'
                : isUp
                ? 'text-emerald-400'
                : 'text-red-400'
            }`}
          >
            {signal.confidence}%
          </div>
          <span className="text-[10px] text-zinc-500 font-medium text-center">
            {signal.isStrongSniper99 ? '99% Confluence Model' : 'Estimate, not a guarantee'}
          </span>
        </div>
      </div>

      {/* 4. Entry Instruction Card (Screenshot 1) */}
      <div className="w-full max-w-md bg-[#180710]/95 border border-[#3f1326] rounded-xl p-3.5 shadow-lg relative overflow-hidden">
        {/* Urgent Strike Zone Banner when candle is within 5 seconds of opening or just opened */}
        {entrySecondsLeft <= 5 && entrySecondsLeft > 0 ? (
          <div className="mb-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white font-mono font-black text-xs py-2 px-3 rounded-lg flex items-center justify-between animate-pulse shadow-[0_0_25px_rgba(239,68,68,0.8)] border border-white/40">
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 fill-amber-300 text-amber-300 animate-bounce" />
              <span>PREPARE: CLICK {signal.action.split(' ')[0]} ON QUOTEX!</span>
            </span>
            <span className="text-base font-black tabular-nums bg-black/40 px-2 py-0.5 rounded border border-white/20">
              {entrySecondsLeft}S
            </span>
          </div>
        ) : entrySecondsLeft >= 56 || entrySecondsLeft === 0 ? (
          <div className="mb-2.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 text-slate-950 font-mono font-black text-xs py-2 px-3 rounded-lg flex items-center justify-between shadow-[0_0_25px_rgba(16,185,129,0.8)] animate-pulse border border-white/40">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>STRIKE ZONE OPEN! CLICK {signal.action.split(' ')[0]} NOW!</span>
            </span>
            <span className="text-[10px] bg-slate-950 text-emerald-300 px-2 py-0.5 rounded font-bold">
              0-5S WINDOW
            </span>
          </div>
        ) : null}

        {/* Dynamic Countdown Header */}
        <h3 className="text-lg sm:text-xl font-black font-mono text-red-500 tracking-tight flex items-center gap-1.5">
          <Clock className="w-4 h-4 text-red-500 animate-spin" style={{ animationDuration: '4s' }} />
          <span>PLACE TRADE IN {entrySecondsLeft}S</span>
        </h3>

        <p className="text-xs text-zinc-300 leading-relaxed mt-1.5 font-normal">
          Wait for the running candle to close. Enter at the next candle open at{' '}
          <strong className="text-white font-mono">{signal.entryCandleTime}</strong>. Expiry is{' '}
          <strong className="text-white font-mono">{signal.expiryTime}</strong> for {signal.timeframe}.
        </p>

        {/* 3-Step Execution Roadmap so trader never misses out */}
        <div className="grid grid-cols-3 gap-1.5 my-2.5 text-center font-mono">
          <div className="bg-[#12040b] border border-[#2d0d1b] rounded-lg p-1.5">
            <span className="text-[9px] text-zinc-400 block font-bold">STEP 1</span>
            <span className="text-[10px] text-amber-300 font-extrabold">{entrySecondsLeft}s To Close</span>
          </div>
          <div className="bg-[#12040b] border border-[#2d0d1b] rounded-lg p-1.5">
            <span className="text-[9px] text-zinc-400 block font-bold">STEP 2</span>
            <span className={`text-[10px] font-extrabold ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
              Hit {signal.action.split(' ')[0]} at Open
            </span>
          </div>
          <div className="bg-[#12040b] border border-[#2d0d1b] rounded-lg p-1.5">
            <span className="text-[9px] text-zinc-400 block font-bold">STEP 3</span>
            <span className="text-[10px] text-zinc-300 font-extrabold">Hold {signal.timeframe}</span>
          </div>
        </div>

        {/* Timers Row */}
        <div className="mt-3 pt-2.5 border-t border-[#310f1e] space-y-1.5 text-xs font-mono">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 uppercase font-semibold text-[11px]">ENTRY IN</span>
            <span className="text-red-500 font-bold tabular-nums text-sm bg-red-950/60 px-1.5 py-0.5 rounded border border-red-800/40">
              {entrySecondsLeft}S
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-zinc-400 uppercase font-semibold text-[11px]">TRADE ENDS IN</span>
            <span className="text-red-500 font-bold tabular-nums text-sm bg-red-950/60 px-1.5 py-0.5 rounded border border-red-800/40">
              {tradeEndsSecondsLeft}S
            </span>
          </div>

          {/* Quick Refresh Link for Next Signal */}
          {onRefreshSignal && (
            <div className="flex items-center justify-between text-[11px] font-mono pt-1.5 border-t border-[#250b18]">
              <span className="text-zinc-500">Finished this candle?</span>
              <button
                onClick={() => {
                  soundManager.playPip();
                  onRefreshSignal();
                }}
                className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1 transition-colors cursor-pointer"
                title="Scan next setup"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Refresh Next Signal</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 4.5. Live Market Power Battle: Who has more strength? (Buyers vs Sellers) */}
      <div className="w-full max-w-md bg-[#11040d] border-2 border-[#ff2a5f]/40 rounded-xl p-3 shadow-lg space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-[11px] font-mono font-bold tracking-wider text-amber-300 uppercase">
              WHO HAS MORE STRENGTH? (POWER BATTLE)
            </span>
          </div>
          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-zinc-300">
            {isUp ? 'MORE BUYING IN MARKET' : 'MORE SELLING IN MARKET'}
          </span>
        </div>

        {/* Live Power Battle Meter */}
        <div className="space-y-1 font-mono">
          <div className="flex items-center justify-between text-xs font-extrabold">
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              BUYERS: {signal.buyerPressure || (isUp ? 78 : 22)}%
            </span>
            <span className="text-xs text-zinc-400 font-normal">VS</span>
            <span className="text-red-400 flex items-center gap-1">
              SELLERS: {signal.sellerPressure || (isUp ? 22 : 78)}%
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
            </span>
          </div>

          {/* Dual Power Bar */}
          <div className="w-full h-3 bg-[#240a18] rounded-full overflow-hidden flex p-0.5 border border-[#3e122b]">
            <div
              className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-l-full transition-all duration-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
              style={{ width: `${signal.buyerPressure || (isUp ? 78 : 22)}%` }}
            />
            <div
              className="h-full bg-gradient-to-r from-red-400 to-red-600 rounded-r-full transition-all duration-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]"
              style={{ width: `${signal.sellerPressure || (isUp ? 22 : 78)}%` }}
            />
          </div>
        </div>

        {/* Trend Alignment Guarantee */}
        <div className="bg-[#1a0614] border border-[#2e0e22] rounded-lg p-2 text-[11px] font-mono space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400">Market Trend:</span>
            <span className={`font-bold ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
              {isUp ? '▲ UPTREND (BULLISH FLOW)' : '▼ DOWNTREND (BEARISH CASCADE)'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-zinc-400">Signal Sentiment:</span>
            <span className="text-amber-300 font-bold">
              ✓ 100% IN LINE WITH TREND (NO COUNTER-TREND)
            </span>
          </div>
          <div className="text-[10px] text-zinc-400 pt-1 border-t border-[#2d0d21] leading-tight">
            {isUp
              ? `Buyers dominate order flow by ${signal.buyerPressure || 78}%. The signal strictly follows this bullish expansion upward.`
              : `Sellers dominate order flow by ${signal.sellerPressure || 78}%. The signal strictly follows this bearish breakdown downward.`}
          </div>
        </div>
      </div>

      {/* 5. Institutional Deep Market Intelligence Radar */}
      <div className="w-full max-w-md bg-[#13050e] border border-[#381123] rounded-xl p-3 shadow-md space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span className="text-[11px] font-bold tracking-wider text-red-400 uppercase">
              DEEP MARKET INTELLIGENCE
            </span>
          </div>
          <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-950/70 border border-amber-600/40 px-1.5 py-0.2 rounded">
            MTF CONFLUENCE: 3/3
          </span>
        </div>

        {/* Market Regime */}
        <div className="bg-[#1c0814] border border-[#2d0e1f] rounded-lg p-2 text-xs">
          <div className="text-[10px] uppercase font-bold text-zinc-400">Market Regime</div>
          <div className="font-semibold text-slate-100 mt-0.5 flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isUp ? 'bg-emerald-400' : 'bg-red-500'}`} />
            <span>{signal.marketRegimeLabel || signal.trend}</span>
          </div>
          {signal.wickRejectionScore && (
            <div className="text-[11px] font-mono text-zinc-400 mt-1 pl-3.5">
              ↳ {signal.wickRejectionScore}
            </div>
          )}
        </div>

        {/* Multi-Timeframe Matrix (5s, 1M, 5M) */}
        <div className="grid grid-cols-3 gap-1.5 text-center font-mono">
          <div className="bg-[#1c0814] border border-[#2d0e1f] rounded-lg py-1.5 px-1">
            <div className="text-[9px] text-zinc-400 uppercase">5S MICRO</div>
            <div className={`text-xs font-bold mt-0.5 ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
              {isUp ? '▲ BULLISH' : '▼ BEARISH'}
            </div>
          </div>
          <div className="bg-[#1c0814] border border-[#2d0e1f] rounded-lg py-1.5 px-1">
            <div className="text-[9px] text-amber-300 uppercase">1M CANDLE</div>
            <div className={`text-xs font-bold mt-0.5 ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
              {isUp ? '▲ BULLISH' : '▼ BEARISH'}
            </div>
          </div>
          <div className="bg-[#1c0814] border border-[#2d0e1f] rounded-lg py-1.5 px-1">
            <div className="text-[9px] text-zinc-400 uppercase">5M MACRO</div>
            <div className={`text-xs font-bold mt-0.5 ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
              {isUp ? '▲ BULLISH' : '▼ BEARISH'}
            </div>
          </div>
        </div>

        {/* Dynamic Key S/R Map Proximity */}
        {signal.supportLevel && signal.resistanceLevel && (
          <div className="flex items-center justify-between text-[10px] font-mono bg-[#180712] px-2.5 py-1.5 rounded-lg border border-[#2e0e1e]">
            <span className="text-zinc-400">
              SUP: <strong className="text-emerald-400">{signal.supportLevel}</strong>
            </span>
            <span className="text-zinc-500">|</span>
            <span className="text-zinc-400">
              TARGET: <strong className="text-amber-300">{signal.targetPrice.toFixed(4)}</strong>
            </span>
            <span className="text-zinc-500">|</span>
            <span className="text-zinc-400">
              RES: <strong className="text-red-400">{signal.resistanceLevel}</strong>
            </span>
          </div>
        )}

        {/* 5-Point Institutional Confluence Checks */}
        {signal.confluenceChecks && signal.confluenceChecks.length > 0 && (
          <div className="pt-2 border-t border-[#260a1a] space-y-1">
            <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1">
              5-Point Institutional Confluence Audit
            </div>
            {signal.confluenceChecks.map((chk, i) => (
              <div key={i} className="flex items-center justify-between text-[11px] py-0.5">
                <div className="flex items-center gap-1.5 text-zinc-300">
                  {chk.passed ? (
                    <Check className="w-3 h-3 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                  )}
                  <span>{chk.name}</span>
                </div>
                <span className={`text-[10px] font-mono font-semibold ${chk.passed ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {chk.detail}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 6. Margin of Safety Zone & MTG-1 Protection Card */}
      {signal.safetyMarginZone && (
        <div className="w-full max-w-md bg-[#11050e] border border-cyan-500/30 rounded-xl p-3 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Target className="w-4 h-4 text-cyan-400" />
              <span className="text-[11px] font-bold text-cyan-300 uppercase tracking-wider">
                MARGIN OF SAFETY ENTRY (ANTI-TIE)
              </span>
            </div>
            <span className="text-[9px] bg-cyan-950 border border-cyan-500/40 text-cyan-300 px-1.5 py-0.2 rounded font-mono">
              HIGH ACCURACY
            </span>
          </div>
          <p className="text-xs text-cyan-100 font-mono leading-relaxed bg-[#190915] p-2 rounded-lg border border-cyan-900/30">
            {signal.safetyMarginZone}
          </p>
          <div className="text-[11px] text-zinc-400 pt-1 border-t border-[#25091a] flex items-start gap-1.5">
            <span className="font-bold text-amber-300 shrink-0">MTG-1:</span>
            <span>{signal.mtgStepAdvice}</span>
          </div>
        </div>
      )}

      {/* 6.5. Smart Market Understanding & Opportunity Breakdown */}
      <div className="w-full max-w-md bg-gradient-to-b from-[#160613] to-[#0f040d] border border-emerald-500/30 rounded-xl p-3 shadow-md space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[11px] font-mono font-bold tracking-wider text-emerald-300 uppercase">
              SMART MARKET UNDERSTANDING
            </span>
          </div>
          <span className="text-[9px] bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
            INSTITUTIONAL EDGE
          </span>
        </div>

        {/* Narrative breakdown */}
        <div className="bg-[#1a0817] p-2.5 rounded-lg border border-[#2e0e29] text-xs font-mono space-y-1.5">
          <div className="text-zinc-200 leading-relaxed text-[11px]">
            {isUp ? (
              <>
                <strong className="text-emerald-400">Why It's Pushing Up:</strong> Major buyers absorbed seller liquidity at support and are driving an impulse wave upward. Triple EMA (7/14/25) confirms clean ascending order flow with open space to resistance.
              </>
            ) : (
              <>
                <strong className="text-red-400">Why It's Dropping Down:</strong> Heavy seller outflow broke below the dynamic baseline. Buyers failed to absorb the drop, opening up room to the next support target.
              </>
            )}
          </div>
          <div className="pt-1.5 border-t border-[#2d0d27] flex items-center justify-between text-[10px]">
            <span className="text-zinc-400">Order Flow Momentum:</span>
            <span className="text-amber-300 font-bold">
              {isUp ? '🚀 Bullish Expansion Wave' : '📉 Bearish Cascade Flow'}
            </span>
          </div>
        </div>

        {/* Never Miss Out Checklist */}
        <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
          <div className="bg-[#140611] p-1.5 rounded border border-[#2b0c24] flex items-center gap-1.5 text-zinc-300">
            <Check className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>Audio Countdown Active</span>
          </div>
          <div className="bg-[#140611] p-1.5 rounded border border-[#2b0c24] flex items-center gap-1.5 text-zinc-300">
            <Check className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>0-5s Strike Window Ready</span>
          </div>
        </div>
      </div>

      {/* 7. How To Follow This Signal Card (Screenshot 1) */}
      <div className="w-full max-w-md bg-[#12050c]/90 border border-[#2b0d19] rounded-xl p-3 shadow-md">
        <div className="text-[11px] font-bold tracking-wider text-emerald-400 uppercase mb-1">
          HOW TO FOLLOW THIS SIGNAL
        </div>
        <p className="text-xs text-zinc-300 leading-relaxed font-normal">
          Enter {signal.direction} at the next candle open ({signal.entryCandleTime}). Hold for the full{' '}
          {signal.timeframe}. If the chart shows a clear trend in the same {signal.direction} direction, the
          setup is safer. Do not re-enter after expiry.
        </p>
      </div>

      {/* Voice Market Narrator Card: The voice tells you what the market is saying */}
      <div className="w-full max-w-md bg-gradient-to-r from-[#170624] via-[#240a38] to-[#170624] border-2 border-purple-500/60 rounded-xl p-3 shadow-[0_0_25px_rgba(168,85,247,0.35)] space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-purple-400 animate-pulse" />
            <span className="text-[11px] font-mono font-black tracking-wider text-purple-300 uppercase">
              VOICE MARKET ANNOUNCER
            </span>
          </div>
          <button
            onClick={handleToggleAutoVoice}
            className={`text-[9px] font-mono px-2 py-0.5 rounded border font-bold transition-colors cursor-pointer ${
              autoVoice
                ? 'bg-purple-950 text-purple-300 border-purple-400'
                : 'bg-zinc-900 text-zinc-500 border-zinc-700'
            }`}
          >
            AUTO-VOICE: {autoVoice ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Listen Button */}
        <button
          onClick={handleSpeakVoice}
          className="w-full py-2.5 px-3 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white rounded-xl text-xs sm:text-sm font-black font-mono tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(147,51,234,0.5)] active:scale-95 cursor-pointer"
        >
          {isVoiceSpeaking ? (
            <>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-3 bg-white animate-bounce rounded-full" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-4.5 bg-white animate-bounce rounded-full" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-3 bg-white animate-bounce rounded-full" style={{ animationDelay: '300ms' }} />
              </div>
              <span>SPEAKING: WHAT THE MARKET IS SAYING...</span>
            </>
          ) : (
            <>
              <Volume2 className="w-4 h-4 text-white" />
              <span>🗣️ LISTEN TO WHAT THE MARKET IS SAYING</span>
            </>
          )}
        </button>

        <p className="text-[10px] text-purple-200/80 font-mono text-center leading-tight">
          Tap above to hear live spoken market narrative, buyer vs seller power, and exact Quotex instruction.
        </p>
      </div>

      {/* 6. Execution Control Buttons & Auto-Trade Switch */}
      <div className="w-full max-w-md flex flex-col gap-2 mt-1">
        <div className="grid grid-cols-2 gap-2">
          {/* Manual / Instant Execution Button */}
          <button
            onClick={() => {
              soundManager.playTradeEntry();
              onExecuteTrade();
            }}
            disabled={isExecuting || (activeTrade?.status === 'OPEN')}
            className={`w-full py-2.5 px-3 rounded-xl font-extrabold text-xs sm:text-sm tracking-wide transition-all flex items-center justify-center gap-1.5 shadow-lg ${
              isUp
                ? 'bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white shadow-emerald-950/60 border border-emerald-400/50'
                : 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white shadow-red-950/60 border border-red-400/50'
            } ${activeTrade?.status === 'OPEN' ? 'opacity-50 cursor-not-allowed' : 'active:scale-95'}`}
          >
            <Send className="w-4 h-4" />
            <span>
              {activeTrade?.status === 'OPEN'
                ? `ACTIVE (${activeTrade.secondsRemaining}s)`
                : `EXECUTE ${signal.action.split(' ')[0]}`}
            </span>
          </button>

          {/* Auto-Trading Bot Toggle */}
          <button
            onClick={() => {
              soundManager.playPip();
              onToggleAutoExecute();
            }}
            className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm tracking-wide transition-all flex items-center justify-center gap-1.5 border ${
              autoExecute
                ? 'bg-gradient-to-r from-purple-700 to-indigo-800 text-white border-purple-400/80 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                : 'bg-[#180710] text-zinc-400 border-[#381121] hover:text-zinc-200'
            }`}
          >
            <Zap className={`w-4 h-4 ${autoExecute ? 'text-amber-300 fill-amber-300 animate-pulse' : 'text-zinc-500'}`} />
            <span>AUTO-BOT: {autoExecute ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Primary Refresh For Next Signal Button */}
        {onRefreshSignal && (
          <button
            onClick={() => {
              soundManager.playPip();
              onRefreshSignal();
            }}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-[#200914] via-[#330f22] to-[#200914] hover:from-[#2e0e1f] hover:to-[#2e0e1f] border-2 border-red-500/70 hover:border-red-400 text-white rounded-xl text-xs sm:text-sm font-black font-mono tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(239,68,68,0.35)] active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4 text-red-400 animate-spin" style={{ animationDuration: '4s' }} />
            <span>🔄 REFRESH FOR NEXT SIGNAL</span>
          </button>
        )}

        {/* 1-Click Scan My Quotex Chart Button */}
        {onOpenPhotoAnalysis && (
          <button
            onClick={() => {
              soundManager.playPip();
              onOpenPhotoAnalysis();
            }}
            className="w-full py-2 px-3 bg-gradient-to-r from-red-950/80 via-[#270e17] to-red-950/80 hover:from-red-900/80 hover:to-red-900/80 border border-red-500/50 hover:border-red-400 text-red-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm"
          >
            <span>📸 Scan My Quotex Chart for 100% Match</span>
          </button>
        )}

        {/* Indicator Confluence Breakdown Accordion */}
        <button
          onClick={() => setShowIndicators(!showIndicators)}
          className="w-full flex items-center justify-between px-3 py-2 bg-[#16060f] border border-[#2e0e1c] rounded-lg text-xs font-medium text-zinc-400 hover:text-zinc-200 transition-colors"
        >
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
            <span>Technical Confluence Breakdown ({signal.indicators.filter((i) => i.confluenceMet).length}/{signal.indicators.length})</span>
          </div>
          {showIndicators ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showIndicators && (
          <div className="w-full bg-[#12040b] border border-[#2d0d1a] rounded-lg p-2.5 space-y-2 text-xs">
            {signal.indicators.map((ind, i) => (
              <div key={i} className="flex items-start justify-between border-b border-[#220a14] pb-1.5 last:border-b-0 last:pb-0">
                <div>
                  <div className="font-semibold text-slate-200 flex items-center gap-1">
                    {ind.confluenceMet ? (
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <div className="w-2.5 h-2.5 rounded-full bg-zinc-600" />
                    )}
                    <span>{ind.name}</span>
                    <span className="text-[10px] font-mono text-zinc-400 font-normal">({ind.value})</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 pl-4">{ind.note}</div>
                </div>
                <span
                  className={`text-[10px] font-bold font-mono px-1.5 py-0.5 rounded ${
                    ind.status === 'BULLISH'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                      : ind.status === 'BEARISH'
                      ? 'bg-red-950 text-red-400 border border-red-800/40'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {ind.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
