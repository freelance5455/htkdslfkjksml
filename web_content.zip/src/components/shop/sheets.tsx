import { Minus, Plus, X } from "lucide-react";
import { useState } from "react";
import {
  catName,
  couponOff,
  discountPct,
  fmt,
  freeDeliveryCopy,
  productName,
  subtotal,
  t,
  totals,
  unitPrice,
  cartLines,
  normalizePhone,
  type PayMethod,
} from "@/lib/shop/model";
import { useShop } from "@/lib/shop/store";

function Meter({ sub, light }: { sub: number; light?: boolean }) {
  const lang = useShop((s) => s.lang);
  const free = useShop((s) => s.settings.free);
  if (!(free > 0) || sub <= 0) return null;
  const pct = Math.max(0, Math.min(100, (sub / free) * 100));
  return (
    <div className={light ? "meter" : "meter ink"}>
      <small>{freeDeliveryCopy(lang, sub, free)}</small>
      <i>
        <b style={{ width: `${pct}%` }} />
      </i>
    </div>
  );
}

export function ProductSheet() {
  const lang = useShop((s) => s.lang);
  const id = useShop((s) => s.productId);
  const p = useShop((s) => s.products.find((x) => x.id === id));
  const categories = useShop((s) => s.categories);
  const products = useShop((s) => s.products);
  const qty = useShop((s) => s.qty);
  const photoIdx = useShop((s) => s.photoIdx);
  const close = useShop((s) => s.closeProduct);
  const bump = useShop((s) => s.bumpQty);
  const add = useShop((s) => s.addToCart);
  const open = useShop((s) => s.openProduct);

  if (!p) return null;
  const cat = categories.find((c) => c.id === p.cat);
  const photos = p.photos || [];
  const off = discountPct(p);
  const price = unitPrice(p);
  const related = products.filter((x) => x.cat === p.cat && x.id !== p.id).slice(0, 6);
  const big = photos[photoIdx] || photos[0];

  return (
    <div className="scrim" style={{ alignItems: "flex-end", justifyContent: "center" }} onClick={close}>
      <div
        className="sheet sheet-bottom"
        role="dialog"
        aria-modal="true"
        aria-label={productName(p, lang)}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center gap-2">
          <b className="flex-1 text-mut">
            {cat ? `${cat.emoji} ${catName(cat, lang)}` : ""}
          </b>
          <button type="button" className="btn iconbtn" onClick={close} aria-label={t(lang, "close")}>
            <X size={18} />
          </button>
        </div>
        {big ? (
          <img src={big} alt={productName(p, lang)} style={{ width: "100%", height: 240, objectFit: "cover", borderRadius: 16 }} />
        ) : (
          <div className="pimg" style={{ height: 200, fontSize: 72 }}>
            {p.img}
          </div>
        )}
        {photos.length > 1 ? (
          <div className="mt-2 flex gap-2 overflow-x-auto">
            {photos.map((src, i) => (
              <button type="button" key={src.slice(0, 32) + i} onClick={() => useShop.setState({ photoIdx: i })}>
                <img
                  src={src}
                  alt=""
                  style={{
                    width: 56,
                    height: 56,
                    objectFit: "cover",
                    borderRadius: 10,
                    border: `2px solid ${i === (photoIdx || 0) ? "var(--em)" : "var(--bd)"}`,
                  }}
                />
              </button>
            ))}
          </div>
        ) : null}
        <h2 className="mt-3 text-2xl font-extrabold tracking-tight">{productName(p, lang)}</h2>
        <div className="mt-1">
          {p.disc > 0 ? (
            <>
              <span className="old">{fmt(p.price, lang)}</span>
              <span className="off" style={{ position: "static" }}>
                −{off}%
              </span>{" "}
            </>
          ) : null}
          <span className="price text-xl">{fmt(price, lang)}</span>
        </div>
        <p className="text-mut">
          {p.stock > 0 ? `${t(lang, "inStock")}: ${p.stock}` : t(lang, "out")}
        </p>
        {p.desc ? <p className="whitespace-pre-wrap">{p.desc}</p> : null}
        <div className="mt-2 flex items-center gap-2">
          <button type="button" className="btn iconbtn" onClick={() => bump(-1)} aria-label="-">
            <Minus size={18} />
          </button>
          <b className="min-w-8 text-center text-lg">{qty}</b>
          <button type="button" className="btn iconbtn" onClick={() => bump(1)} aria-label="+">
            <Plus size={18} />
          </button>
          <button
            type="button"
            className="btn btn-pri flex-1"
            disabled={p.stock < 1}
            onClick={() => {
              if (add(p.id, qty)) close();
            }}
          >
            + {t(lang, "add")} · {fmt(price * qty, lang)}
          </button>
        </div>
        {related.length ? (
          <>
            <h3 className="sec">{t(lang, "related")}</h3>
            <div className="grid-products" style={{ paddingInline: 0 }}>
              {related.map((r) => (
                <button type="button" key={r.id} className="pcard" onClick={() => open(r.id)}>
                  <div className="pimg">{r.photos[0] ? <img src={r.photos[0]} alt="" /> : r.img}</div>
                  <b className="clamp">{productName(r, lang)}</b>
                  <span className="price">{fmt(unitPrice(r), lang)}</span>
                </button>
              ))}
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}

export function CartSheet() {
  const lang = useShop((s) => s.lang);
  const products = useShop((s) => s.products);
  const cart = useShop((s) => s.cart);
  const coupons = useShop((s) => s.coupons);
  const coupon = useShop((s) => s.coupon);
  const settings = useShop((s) => s.settings);
  const customers = useShop((s) => s.customers);
  const me = useShop((s) => s.me);
  const ship = useShop((s) => s.ship);
  const close = useShop((s) => s.closeCart);
  const changeQty = useShop((s) => s.changeQty);
  const applyCoupon = useShop((s) => s.applyCoupon);
  const placeOrder = useShop((s) => s.placeOrder);

  const lines = cartLines(products, cart);
  const sub = subtotal(lines);
  const found = coupon ? coupons.find((c) => c.code === coupon) : undefined;
  const cd = couponOff(found, sub);
  const tt = totals(sub, settings.fee, settings.free, false, cd);

  const [name, setName] = useState(ship?.name || me?.name || "");
  const [phone, setPhone] = useState(ship?.phone || me?.phone || "");
  const [addr, setAddr] = useState(ship?.addr || "");
  const [pm, setPm] = useState<PayMethod>("COD");
  const [code, setCode] = useState(coupon || "");
  const [useCoins, setUseCoins] = useState(false);
  const [busy, setBusy] = useState(false);

  const coins = customers[normalizePhone(phone)]?.coins ?? 0;
  const preview = totals(sub, settings.fee, settings.free, useCoins && coins >= 1000, cd);

  return (
    <div className="scrim" onClick={close}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={t(lang, "cart")} onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center gap-2">
          <h2 className="flex-1 text-xl font-extrabold">{t(lang, "cart")}</h2>
          <button type="button" className="btn iconbtn" onClick={close} aria-label={t(lang, "close")}>
            <X size={18} />
          </button>
        </div>
        {lines.length ? <Meter sub={sub} /> : <p className="text-mut">{t(lang, "empty")}</p>}
        {lines.map((l) => (
          <div key={l.p.id} className="box flex items-center gap-2">
            <span className="text-2xl" aria-hidden>
              {l.p.photos[0] ? (
                <img src={l.p.photos[0]} alt="" style={{ width: 44, height: 44, objectFit: "cover", borderRadius: 10 }} />
              ) : (
                l.p.img
              )}
            </span>
            <div className="min-w-0 flex-1">
              <b className="clamp">{productName(l.p, lang)}</b>
              <div className="text-sm text-mut">{fmt(unitPrice(l.p), lang)}</div>
            </div>
            <button type="button" className="btn iconbtn" onClick={() => changeQty(l.p.id, -1)} aria-label="-">
              <Minus size={16} />
            </button>
            <b>{l.q}</b>
            <button type="button" className="btn iconbtn" onClick={() => changeQty(l.p.id, 1)} aria-label="+">
              <Plus size={16} />
            </button>
          </div>
        ))}
        {lines.length ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (busy) return;
              setBusy(true);
              const ok = placeOrder({ name, phone, addr, pm, useCoins });
              setBusy(false);
              if (!ok) return;
            }}
          >
            <div className="box text-sm">
              <div className="flex justify-between">
                <span>{t(lang, "sub")}</span>
                <span>{fmt(preview.sub, lang)}</span>
              </div>
              <div className="flex justify-between">
                <span>{t(lang, "del")}</span>
                <span>{fmt(preview.fee, lang)}</span>
              </div>
              {preview.cd > 0 ? (
                <div className="flex justify-between">
                  <span>🎟 {coupon}</span>
                  <span>−{fmt(preview.cd, lang)}</span>
                </div>
              ) : null}
              {preview.d > 0 ? (
                <div className="flex justify-between">
                  <span>{t(lang, "coins")}</span>
                  <span>−{fmt(preview.d, lang)}</span>
                </div>
              ) : null}
              <div className="mt-1 flex justify-between text-base font-extrabold">
                <span>{t(lang, "total")}</span>
                <span>{fmt(preview.tot, lang)}</span>
              </div>
            </div>
            <div className="mb-3 flex gap-2">
              <input
                className="inp"
                placeholder={t(lang, "coupon")}
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                aria-label={t(lang, "coupon")}
              />
              <button type="button" className="btn" onClick={() => applyCoupon(code, sub)}>
                {t(lang, "apply")}
              </button>
            </div>
            {!coupon && coupons.some((c) => c.code === "CARE10" && c.active) ? (
              <p className="mb-2 text-sm text-mut">{t(lang, "tryCoupon")}</p>
            ) : null}
            <label className="field">
              <span>{t(lang, "name")}</span>
              <input className="inp" value={name} onChange={(e) => setName(e.target.value)} required />
            </label>
            <label className="field">
              <span>{t(lang, "phone")}</span>
              <input className="inp" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
            </label>
            <label className="field">
              <span>{t(lang, "addr")}</span>
              <textarea className="inp" rows={2} value={addr} onChange={(e) => setAddr(e.target.value)} placeholder={t(lang, "addrPh")} required />
            </label>
            <label className="field">
              <span>{t(lang, "pay")}</span>
              <select className="inp" value={pm} onChange={(e) => setPm(e.target.value as PayMethod)}>
                <option value="COD">Cash on Delivery</option>
                <option value="bKash">bKash</option>
                <option value="Nagad">Nagad</option>
              </select>
            </label>
            {coins >= 1000 ? (
              <label className="mb-3 flex items-center gap-2 text-sm font-semibold">
                <input type="checkbox" checked={useCoins} onChange={(e) => setUseCoins(e.target.checked)} />
                {t(lang, "use")}
              </label>
            ) : null}
            <button type="submit" className="btn btn-pri btn-block" disabled={busy}>
              {t(lang, "place")}
            </button>
            <p className="mt-2 text-sm text-mut">{t(lang, "unpaid")}</p>
          </form>
        ) : null}
      </div>
    </div>
  );
}

export function WaSheet() {
  const lang = useShop((s) => s.lang);
  const wa = useShop((s) => s.wa);
  const dismiss = useShop((s) => s.dismissWa);
  if (!wa) return null;
  return (
    <div className="scrim" style={{ alignItems: "center", justifyContent: "center" }} onClick={dismiss}>
      <div className="sheet modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-2 grid h-16 w-16 place-items-center rounded-full" style={{ background: "#25D366", color: "white" }}>
          <svg viewBox="0 0 52 52" width="36" height="36" aria-hidden>
            <path d="M14 27l8 8 16-18" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h3 className="text-xl font-extrabold">{wa.id}</h3>
        <p className="text-mut">{t(lang, "waHint")}</p>
        <a className="btn btn-pri btn-block mt-3" style={{ background: "#128C7E" }} href={wa.url} target="_blank" rel="noreferrer" onClick={() => setTimeout(dismiss, 400)}>
          {t(lang, "openWa")}
        </a>
        <button type="button" className="btn mt-2" onClick={dismiss}>
          {t(lang, "close")}
        </button>
      </div>
    </div>
  );
}

export { Meter };
