import { Heart, Search, ShieldCheck, SlidersHorizontal, Truck, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";
import {
  catName,
  discountPct,
  fmt,
  productName,
  t,
  unitPrice,
  visibleProducts,
} from "@/lib/shop/model";
import { useShop } from "@/lib/shop/store";
import { cn } from "@/lib/utils";
import { Logo } from "./mark";

export function Home() {
  const lang = useShop((s) => s.lang);
  const settings = useShop((s) => s.settings);
  const products = useShop((s) => s.products);
  const categories = useShop((s) => s.categories);
  const cat = useShop((s) => s.cat);
  const q = useShop((s) => s.q);
  const sort = useShop((s) => s.sort);
  const favOnly = useShop((s) => s.favOnly);
  const wishlist = useShop((s) => s.wishlist);
  const recently = useShop((s) => s.recently);
  const setCat = useShop((s) => s.setCat);
  const setQuery = useShop((s) => s.setQuery);
  const setSort = useShop((s) => s.setSort);
  const toggleFavOnly = useShop((s) => s.toggleFavOnly);
  const openProduct = useShop((s) => s.openProduct);

  const list = visibleProducts(products, { cat, q, favOnly, wishlist, sort, lang });
  const showTiles = cat === "all" && !q && !favOnly && categories.length > 0;
  const recent = recently.map((id) => products.find((p) => p.id === id)).filter((p) => Boolean(p));
  const featured = products.filter((p) => p.feat);

  return (
    <div>
      {settings.ui.bar && settings.announce ? (
        <div className="marquee-wrap">
          <div className="marquee">
            <span>{settings.announce}</span>
            <span>{settings.announce}</span>
          </div>
        </div>
      ) : null}

      {settings.ui.hero ? (
        <section className={cn("hero", settings.banner && "has-banner")}>
          <div className="flex items-center gap-4">
            <div className="min-w-0 flex-1">
              <h1>{settings.brand}</h1>
              <p>{settings.tag || t(lang, "tagline")}</p>
            </div>
            <div className="mark">
              <Logo src={settings.logo} />
            </div>
          </div>
        </section>
      ) : null}

      <div className="trust">
        <span>
          <Truck size={16} aria-hidden /> {t(lang, "fast")}
        </span>
        <span>
          <ShieldCheck size={16} aria-hidden /> {t(lang, "genuine")}
        </span>
        <span>
          <MessageCircle size={16} aria-hidden /> {t(lang, "wa")}
        </span>
      </div>

      <div className="px-3 pt-3">
        <label className="relative block">
          <Search size={18} className="pointer-events-none absolute top-3.5 left-3 text-mut" aria-hidden />
          <input
            className="inp"
            style={{ paddingLeft: 40, borderRadius: 999 }}
            placeholder={t(lang, "search")}
            value={q}
            onChange={(e) => setQuery(e.target.value)}
            aria-label={t(lang, "search")}
          />
        </label>
      </div>

      <div className="flex items-center gap-2 px-3 pt-3">
        <SlidersHorizontal size={16} className="text-mut" aria-hidden />
        <select
          className="inp"
          style={{ width: "auto", flex: 1 }}
          aria-label={t(lang, "sort")}
          value={sort}
          onChange={(e) => setSort(e.target.value as typeof sort)}
        >
          <option value="">{t(lang, "sort")}</option>
          <option value="pa">{t(lang, "pa")}</option>
          <option value="pd">{t(lang, "pd")}</option>
          <option value="d">{t(lang, "big")}</option>
        </select>
        <button type="button" className={cn("btn", favOnly && "btn-pri")} onClick={toggleFavOnly}>
          <Heart size={16} fill={favOnly ? "currentColor" : "none"} aria-hidden /> {wishlist.length}
        </button>
      </div>

      <div className="chips mt-2">
        <button type="button" className={cn("chip", cat === "all" && "on")} onClick={() => setCat("all")}>
          {t(lang, "all")}
        </button>
        {categories.map((c) => (
          <button
            type="button"
            key={c.id}
            className={cn("chip", cat === c.id && "on")}
            onClick={() => setCat(c.id)}
          >
            {c.emoji} {catName(c, lang)}
          </button>
        ))}
      </div>

      {showTiles ? (
        <>
          <h2 className="sec">{t(lang, "byCat")}</h2>
          <div className="tiles">
            {categories.map((c) => (
              <button
                type="button"
                key={c.id}
                className="tile"
                onClick={() => {
                  setCat(c.id);
                  requestAnimationFrame(() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth", block: "start" });
                  });
                }}
              >
                <span className="emo" aria-hidden>
                  {c.emoji}
                </span>
                <b>{catName(c, lang)}</b>
                <small>
                  {products.filter((p) => p.cat === c.id).length} {t(lang, "itemsWord")}
                </small>
              </button>
            ))}
          </div>
        </>
      ) : null}

      {showTiles && featured.length ? (
        <>
          <h2 className="sec">{lang === "bn" ? "ফিচার্ড" : "Featured"}</h2>
          <div className="chips">
            {featured.slice(0, 8).map((p) => (
              <button type="button" key={p.id} className="chip" onClick={() => openProduct(p.id)}>
                {p.img} {productName(p, lang)}
              </button>
            ))}
          </div>
        </>
      ) : null}

      {recent.length && !q ? (
        <>
          <h2 className="sec">{t(lang, "recent")}</h2>
          <div className="chips">
            {recent.map((p) =>
              p ? (
                <button type="button" key={p.id} className="chip" onClick={() => openProduct(p.id)}>
                  {p.photos[0] ? (
                    <img
                      src={p.photos[0]}
                      alt=""
                      style={{ width: 22, height: 22, borderRadius: 6, objectFit: "cover", verticalAlign: "middle" }}
                    />
                  ) : (
                    p.img
                  )}{" "}
                  {productName(p, lang)}
                </button>
              ) : null,
            )}
          </div>
        </>
      ) : null}

      <h2 className="sec" id="catalog">
        {t(lang, "our")}
      </h2>
      <div className="grid-products">
        {list.length ? (
          list.map((p) => <ProductCard key={p.id} id={p.id} />)
        ) : (
          <div className="box" style={{ gridColumn: "1 / -1" }}>
            <p className="text-mut">{q || favOnly || cat !== "all" ? t(lang, "noMatch") : t(lang, "empty")}</p>
            {q || favOnly || cat !== "all" ? (
              <button
                type="button"
                className="btn mt-2"
                onClick={() => {
                  setQuery("");
                  setCat("all");
                  if (favOnly) toggleFavOnly();
                }}
              >
                {t(lang, "clear")}
              </button>
            ) : null}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}

function ProductCard({ id }: { id: number }) {
  const lang = useShop((s) => s.lang);
  const p = useShop((s) => s.products.find((x) => x.id === id));
  const wished = useShop((s) => s.wishlist.includes(id));
  const openProduct = useShop((s) => s.openProduct);
  const toggleWish = useShop((s) => s.toggleWish);
  const addToCart = useShop((s) => s.addToCart);
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (!ok) return;
    const timer = window.setTimeout(() => setOk(false), 1100);
    return () => window.clearTimeout(timer);
  }, [ok]);

  if (!p) return null;
  const off = discountPct(p);
  const price = unitPrice(p);

  return (
    <article className="pcard">
      <button type="button" className="pimg" onClick={() => openProduct(p.id)} aria-label={productName(p, lang)}>
        {off > 0 ? <span className="off">−{off}%</span> : null}
        {p.photos[0] ? <img src={p.photos[0]} alt="" /> : <span aria-hidden>{p.img}</span>}
      </button>
      <button
        type="button"
        className="heart"
        style={{ position: "absolute" }}
        aria-label={t(lang, "wish")}
        aria-pressed={wished}
        onClick={() => toggleWish(p.id)}
      >
        <Heart size={16} fill={wished ? "currentColor" : "none"} />
      </button>
      <button type="button" className="text-left" onClick={() => openProduct(p.id)}>
        <b className="clamp">{productName(p, lang)}</b>
        <div className="mt-1">
          {p.disc > 0 ? <span className="old">{fmt(p.price, lang)}</span> : null}
          <span className="price">{fmt(price, lang)}</span>
        </div>
        <small className="text-mut">
          {p.stock > 0
            ? p.stock <= 5
              ? `${t(lang, "only")} ${p.stock} ${t(lang, "left")}`
              : `${t(lang, "stock")}: ${p.stock}`
            : t(lang, "out")}
        </small>
      </button>
      <button
        type="button"
        className={cn("btn btn-pri btn-block", ok && "ok")}
        disabled={p.stock < 1}
        onClick={() => {
          if (addToCart(p.id, 1)) {
            setOk(true);
            try {
              navigator.vibrate?.(12);
            } catch {
              /* ignore */
            }
          }
        }}
      >
        {ok ? `✓ ${t(lang, "added")}` : `+ ${t(lang, "add")}`}
      </button>
    </article>
  );
}

function Footer() {
  const lang = useShop((s) => s.lang);
  const s = useShop((s) => s.settings);
  const blocks = [
    [t(lang, "about"), s.about],
    [t(lang, "delivery"), s.delv],
    [t(lang, "privacy"), s.priv],
    [t(lang, "terms"), s.terms],
  ].filter((b) => b[1]);

  return (
    <footer className="px-3 pt-2 pb-4">
      {blocks.map(([label, body]) => (
        <details key={label} className="box">
          <summary>{label}</summary>
          <div>{body}</div>
        </details>
      ))}
      <p className="text-center text-sm text-mut">
        {s.addr} · WhatsApp +{s.wa}
        {s.foot ? (
          <>
            <br />
            {s.foot}
          </>
        ) : null}
      </p>
      <p className="mt-3 text-center text-sm text-mut">
        {t(lang, "designed")} <b>Saikoth Rahman</b>
      </p>
    </footer>
  );
}
