export function Mark({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="#0b6b4a" />
      <path
        fill="#c9a24b"
        d="M16 5.4c.35 0 7.4 6.1 7.4 13.8 0 4.5-3.15 7.9-7.4 7.9s-7.4-3.4-7.4-7.9C8.6 11.5 15.65 5.4 16 5.4z"
      />
      <path d="M16 10.2v12.2" fill="none" stroke="#0b6b4a" strokeWidth="1.45" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ src, className }: { src?: string; className?: string }) {
  if (src) return <img src={src} alt="" className={className} />;
  return <Mark className={className} />;
}
