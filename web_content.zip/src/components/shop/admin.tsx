import { useEffect, useRef, useState } from "react";
import {
  compressImage,
  customPasswordSet,
  defaultSettings,
  downloadText,
  fmt,
  num,
  ordersCsv,
  passwordOk,
  savePassword,
  statusLabel,
  t,
  unitPrice,
  STATUSES,
  type Coupon,
  type Order,
  type Product,
  type Settings,
} from "@/lib/shop/model";
import { useShop } from "@/lib/shop/store";
import { cn } from "@/lib/utils";

function blankProduct(cat: string): Product {
  return {
    id: 0,
    en: "",
    bn: "",
    cat,
    img: "📦",
    price: 0,
    disc: 0,
    stock: 0,
    feat: false,
    photos: [],
    desc: "",
  };
}

export function Admin() {
  const admin = useShop((s) => s.admin);
  if (!admin) return <Login />;
  return <Panel />;
}

function Login() {
  const lang = useShop((s) => s.lang);
  const adminIn = useShop((s) => s.adminIn);
  const showToast = useShop((s) => s.showToast);
  const tries = useRef(0);
  const [user, setUser] = useState("");
  const [pw, setPw] = useState("");

  return (
    <div className="px-3 pt-4">
      <h2 className="text-xl font-extrabold">{t(lang, "admin")}</h2>
      <form
        className="box mt-3"
        onSubmit={async (e) => {
          e.preventDefault();
          if (tries.current >= 5) {
            showToast(t(lang, "tooMany"));
            return;
          }
          if (await passwordOk(user, pw)) adminIn();
          else {
            tries.current += 1;
            showToast(t(lang, "badLogin"));
          }
        }}
      >
        <p className="mb-2 text-sm text-mut">{t(lang, "signIn")}</p>
        <label className="field">
          <span>{t(lang, "user")}</span>
          <input className="inp" value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" />
        </label>
        <label className="field">
          <span>{t(lang, "password")}</span>
          <input className="inp" type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
        </label>
        <button type="submit" className="btn btn-pri btn-block">
          {t(lang, "login")}
        </button>
        <p className="mt-3 text-sm text-mut">admin / admin</p>
      </form>
    </div>
  );
}

function Panel() {
  const lang = useShop((s) => s.lang);
  const tab = useShop((s) => s.tab);
  const setTab = useShop((s) => s.setTab);
  const adminOut = useShop((s) => s.adminOut);
  const [customPw, setCustomPw] = useState(true);

  useEffect(() => {
    setCustomPw(customPasswordSet());
  }, [tab]);

  const tabs = [
    ["dash", t(lang, "dash")],
    ["products", t(lang, "products")],
    ["cats", t(lang, "cats")],
    ["orders", t(lang, "orders")],
    ["cpn", t(lang, "cpn")],
    ["cust", t(lang, "cust")],
    ["site", t(lang, "site")],
  ] as const;

  return (
    <div>
      {!customPw ? <div className="box warn mx-3 mt-3 text-sm font-semibold">{t(lang, "defaultPw")}</div> : null}
      <div className="tabs">
        {tabs.map(([id, label]) => (
          <button type="button" key={id} className={cn("chip", tab === id && "on")} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
        <button type="button" className="chip" onClick={adminOut}>
          {t(lang, "logout")}
        </button>
      </div>
      <div className="px-3 pb-6">
        <p className="mb-3 text-sm text-mut">{t(lang, "onDevice")}</p>
        {tab === "dash" ? <Dash /> : null}
        {tab === "products" ? <Products /> : null}
        {tab === "cats" ? <Cats /> : null}
        {tab === "orders" ? <Orders /> : null}
        {tab === "cpn" ? <Coupons /> : null}
        {tab === "cust" ? <Customers /> : null}
        {tab === "site" ? <Site onPassword={() => setCustomPw(true)} /> : null}
      </div>
    </div>
  );
}

function Dash() {
  const lang = useShop((s) => s.lang);
  const orders = useShop((s) => s.orders);
  const products = useShop((s) => s.products);
  const customers = useShop((s) => s.customers);
  const done = orders.filter((o) => o.status === "delivered");
  const rev = done.reduce((a, o) => a + o.total, 0);
  const cells = [
    [fmt(rev, lang), t(lang, "rev")],
    [String(orders.length), t(lang, "orders")],
    [String(orders.filter((o) => o.status === "pending").length), t(lang, "pend")],
    [String(done.length), t(lang, "completed")],
    [String(orders.filter((o) => o.status === "cancelled").length), t(lang, "cancelled")],
    [String(Object.keys(customers).length), t(lang, "cust")],
    [String(products.length), t(lang, "products")],
    [String(products.filter((p) => p.stock <= 10).length), t(lang, "low")],
  ];
  const low = products.filter((p) => p.stock <= 10);
  return (
    <>
      <div className="stats">
        {cells.map(([n, label]) => (
          <div key={label} className="box">
            <b>{n}</b>
            {label}
          </div>
        ))}
      </div>
      {low.length ? (
        <div className="box">
          <b>{t(lang, "low")}</b>
          <ul className="mt-2 text-sm">
            {low.map((p) => (
              <li key={p.id}>
                {p.en} · {p.stock}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </>
  );
}

function Products() {
  const lang = useShop((s) => s.lang);
  const products = useShop((s) => s.products);
  const categories = useShop((s) => s.categories);
  const del = useShop((s) => s.deleteProduct);
  const [edit, setEdit] = useState<Product | null>(null);

  return (
    <>
      <button type="button" className="btn btn-gold mb-3" onClick={() => setEdit(blankProduct(categories[0]?.id || "grocery"))}>
        + {t(lang, "newp")}
      </button>
      {edit ? <ProductForm key={edit.id || "new"} initial={edit} onClose={() => setEdit(null)} /> : null}
      {products.map((p) => (
        <div key={p.id} className="box flex items-center gap-2">
          <span className="text-2xl" aria-hidden>
            {p.photos[0] ? (
              <img src={p.photos[0]} alt="" style={{ width: 44, height: 44, objectFit: "cover", borderRadius: 8 }} />
            ) : (
              p.img
            )}
          </span>
          <div className="min-w-0 flex-1">
            <b className="clamp">{p.en}</b>
            <div className="text-sm text-mut">
              {fmt(unitPrice(p), lang)} · {t(lang, "stock")} {p.stock}
            </div>
          </div>
          <button type="button" className="btn" onClick={() => setEdit({ ...p, photos: [...p.photos] })}>
            {t(lang, "edit")}
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              if (confirm(t(lang, "confirmDel"))) del(p.id);
            }}
          >
            {t(lang, "delete")}
          </button>
        </div>
      ))}
    </>
  );
}

function ProductForm({ initial, onClose }: { initial: Product; onClose: () => void }) {
  const lang = useShop((s) => s.lang);
  const categories = useShop((s) => s.categories);
  const saveProduct = useShop((s) => s.saveProduct);
  const showToast = useShop((s) => s.showToast);
  const [p, setP] = useState(initial);

  return (
    <form
      className="box"
      onSubmit={(e) => {
        e.preventDefault();
        if (saveProduct(p)) onClose();
      }}
    >
      <label className="field">
        <span>{t(lang, "enName")}</span>
        <input className="inp" value={p.en} onChange={(e) => setP({ ...p, en: e.target.value })} />
      </label>
      <label className="field">
        <span>{t(lang, "bnName")}</span>
        <input className="inp" value={p.bn} onChange={(e) => setP({ ...p, bn: e.target.value })} />
      </label>
      <label className="field">
        <span>{t(lang, "desc")}</span>
        <textarea className="inp" rows={3} value={p.desc} onChange={(e) => setP({ ...p, desc: e.target.value })} />
      </label>
      <label className="field">
        <span>{t(lang, "cat")}</span>
        <select className="inp" value={p.cat} onChange={(e) => setP({ ...p, cat: e.target.value })}>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.en}
            </option>
          ))}
        </select>
      </label>
      <label className="field">
        <span>{t(lang, "photos")}</span>
        <input
          className="inp"
          type="file"
          accept="image/*"
          multiple
          onChange={async (e) => {
            const files = [...(e.target.files || [])].slice(0, 6 - p.photos.length);
            const photos = [...p.photos];
            for (const f of files) {
              try {
                photos.push(await compressImage(f, 640));
              } catch {
                showToast(t(lang, "imgBad"));
              }
            }
            setP({ ...p, photos });
            e.target.value = "";
          }}
        />
        <div className="mt-2 flex flex-wrap gap-2">
          {p.photos.map((src, i) => (
            <span key={i} className="relative">
              <img src={src} alt="" style={{ width: 64, height: 64, objectFit: "cover", borderRadius: 8 }} />
              <button
                type="button"
                className="btn btn-danger"
                style={{ position: "absolute", top: 0, right: 0, minHeight: 28, padding: "0 6px" }}
                onClick={() => setP({ ...p, photos: p.photos.filter((_, j) => j !== i) })}
              >
                ×
              </button>
            </span>
          ))}
        </div>
      </label>
      <label className="field">
        <span>{t(lang, "emoji")}</span>
        <input className="inp" value={p.img} onChange={(e) => setP({ ...p, img: e.target.value })} />
      </label>
      <label className="field">
        <span>{t(lang, "price")}</span>
        <input className="inp" inputMode="decimal" value={p.price || ""} onChange={(e) => setP({ ...p, price: num(e.target.value) })} />
      </label>
      <label className="field">
        <span>{t(lang, "disc")}</span>
        <input className="inp" inputMode="decimal" value={p.disc || ""} onChange={(e) => setP({ ...p, disc: num(e.target.value) })} />
      </label>
      <label className="field">
        <span>{t(lang, "stock")}</span>
        <input className="inp" inputMode="numeric" value={String(p.stock)} onChange={(e) => setP({ ...p, stock: Math.floor(num(e.target.value)) })} />
      </label>
      <label className="mb-3 flex items-center gap-2 font-semibold">
        <input type="checkbox" checked={p.feat} onChange={(e) => setP({ ...p, feat: e.target.checked })} />
        {t(lang, "feat")}
      </label>
      <div className="flex gap-2">
        <button type="submit" className="btn btn-pri">
          {t(lang, "save")}
        </button>
        <button type="button" className="btn" onClick={onClose}>
          {t(lang, "close")}
        </button>
      </div>
    </form>
  );
}

function Cats() {
  const lang = useShop((s) => s.lang);
  const categories = useShop((s) => s.categories);
  const update = useShop((s) => s.updateCategory);
  const move = useShop((s) => s.moveCategory);
  const remove = useShop((s) => s.deleteCategory);
  const add = useShop((s) => s.addCategory);
  return (
    <>
      {categories.map((c, i) => (
        <div key={c.id} className="box">
          <input className="inp mb-2" value={c.emoji} onChange={(e) => update(i, { emoji: e.target.value })} aria-label="Emoji" />
          <input className="inp mb-2" value={c.en} onChange={(e) => update(i, { en: e.target.value })} aria-label="English" />
          <input className="inp mb-2" value={c.bn} onChange={(e) => update(i, { bn: e.target.value })} aria-label="বাংলা" />
          <div className="flex gap-2">
            <button type="button" className="btn" onClick={() => move(i, -1)}>
              ↑
            </button>
            <button type="button" className="btn" onClick={() => move(i, 1)}>
              ↓
            </button>
            <button type="button" className="btn btn-danger" onClick={() => remove(i)}>
              {t(lang, "delete")}
            </button>
          </div>
        </div>
      ))}
      <button type="button" className="btn btn-gold" onClick={add}>
        + {t(lang, "newCat")}
      </button>
    </>
  );
}

function Orders() {
  const lang = useShop((s) => s.lang);
  const orders = useShop((s) => s.orders);
  const setStatus = useShop((s) => s.setOrderStatus);
  const togglePaid = useShop((s) => s.togglePaid);
  const brand = useShop((s) => s.settings.brand);
  if (!orders.length) return <p className="text-mut">{t(lang, "empty")}</p>;
  return (
    <>
      {orders.map((o) => (
        <article key={o.id} className="box text-sm">
          <b>{o.id}</b> · {o.name} · {o.phone}
          <div className="text-mut">
            {o.addr} · {o.pm} · {o.paid ? t(lang, "paid") : t(lang, "unpaidWord")}
          </div>
          <div>{o.items.map((i) => `${i.en} ×${i.q}`).join(", ")}</div>
          <b>{fmt(o.total, lang)}</b>
          <div className="mt-2 flex flex-wrap gap-2">
            <select className="inp" style={{ width: "auto" }} value={o.status} onChange={(e) => setStatus(o.id, e.target.value as (typeof STATUSES)[number])}>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {statusLabel(s, lang)}
                </option>
              ))}
            </select>
            <button type="button" className="btn" onClick={() => togglePaid(o.id)}>
              {o.paid ? t(lang, "unmarkPaid") : t(lang, "markPaid")}
            </button>
            <button type="button" className="btn" onClick={() => printOrder(o, brand)}>
              {t(lang, "print")}
            </button>
          </div>
        </article>
      ))}
    </>
  );
}

function printOrder(o: Order, brand: string) {
  const w = window.open("", "_blank", "noopener,noreferrer");
  if (!w) return;
  const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ "&": "&", "<": "<", ">": ">" })[c] || c);
  const rows = o.items
    .map((i) => `<tr><td>${esc(i.en)}</td><td>${i.q}</td><td>৳${i.pr * i.q}</td></tr>`)
    .join("");
  w.document.write(
    `<!doctype html><meta charset="utf-8"><title>${esc(o.id)}</title><body style="font-family:sans-serif;padding:24px"><h1>${esc(brand)}</h1><p><b>${esc(o.id)}</b><br>${esc(o.name)} · ${esc(o.phone)}<br>${esc(o.addr)}</p><table cellpadding="6">${rows}</table><p>Delivery ৳${o.fee}<br><b>Total ৳${o.total}</b></p><script>print()<\/script></body>`,
  );
  w.document.close();
}

function Coupons() {
  const lang = useShop((s) => s.lang);
  const coupons = useShop((s) => s.coupons);
  const toggle = useShop((s) => s.toggleCoupon);
  const resetUse = useShop((s) => s.resetCouponUse);
  const remove = useShop((s) => s.deleteCoupon);
  const [edit, setEdit] = useState<{ coupon: Coupon; orig?: string } | null>(null);
  const fresh = (): Coupon => ({ code: "", type: "percent", value: 10, min: 0, max: 0, limit: 0, exp: "", active: true, used: 0 });

  return (
    <>
      <button type="button" className="btn btn-gold mb-3" onClick={() => setEdit({ coupon: fresh() })}>
        + {t(lang, "cpn")}
      </button>
      {edit ? (
        <CouponForm
          key={edit.orig || "new"}
          initial={edit.coupon}
          orig={edit.orig}
          onClose={() => setEdit(null)}
        />
      ) : null}
      {coupons.map((c, i) => {
        const dead = !c.active || (c.exp && new Date(`${c.exp}T23:59:59+06:00`) < new Date()) || (c.limit > 0 && c.used >= c.limit);
        return (
          <article key={c.code} className="box">
            <div className="flex items-center gap-2">
              <b className="flex-1">{c.code}</b>
              <span className="text-sm text-mut">{dead ? t(lang, "off") : t(lang, "live")}</span>
            </div>
            <p className="text-sm text-mut">
              {c.type === "percent" ? `${c.value}%` : fmt(c.value, lang)} · min {fmt(c.min || 0, lang)}
              {c.max ? ` · cap ${fmt(c.max, lang)}` : ""} · {c.used || 0}
              {c.limit ? `/${c.limit}` : ""}
              {c.exp ? ` · ${c.exp}` : ""}
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" className="btn" onClick={() => setEdit({ coupon: { ...c }, orig: c.code })}>
                {t(lang, "edit")}
              </button>
              <button type="button" className="btn" onClick={() => toggle(i)}>
                {c.active ? t(lang, "disable") : t(lang, "enable")}
              </button>
              <button
                type="button"
                className="btn"
                onClick={() => {
                  let n = `${c.code}-COPY`;
                  let k = 2;
                  while (coupons.some((x) => x.code === n)) {
                    n = `${c.code}-COPY${k}`;
                    k += 1;
                  }
                  setEdit({ coupon: { ...c, code: n, used: 0 } });
                }}
              >
                {t(lang, "copy")}
              </button>
              <button
                type="button"
                className="btn"
                onClick={() => {
                  if (confirm(t(lang, "confirmUsed"))) resetUse(i);
                }}
              >
                {t(lang, "resetUsed")}
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => {
                  if (confirm(t(lang, "confirmDel"))) remove(i);
                }}
              >
                {t(lang, "delete")}
              </button>
            </div>
          </article>
        );
      })}
    </>
  );
}

function CouponForm({ initial, orig, onClose }: { initial: Coupon; orig?: string; onClose: () => void }) {
  const lang = useShop((s) => s.lang);
  const save = useShop((s) => s.saveCoupon);
  const [c, setC] = useState(initial);
  return (
    <form
      className="box"
      onSubmit={(e) => {
        e.preventDefault();
        if (save(c, orig)) onClose();
      }}
    >
      <label className="field">
        <span>{t(lang, "code")}</span>
        <input className="inp" value={c.code} onChange={(e) => setC({ ...c, code: e.target.value.toUpperCase() })} />
      </label>
      <label className="field">
        <span>{t(lang, "type")}</span>
        <select className="inp" value={c.type} onChange={(e) => setC({ ...c, type: e.target.value as Coupon["type"] })}>
          <option value="percent">{t(lang, "percent")}</option>
          <option value="fixed">{t(lang, "fixed")}</option>
        </select>
      </label>
      <label className="field">
        <span>{t(lang, "value")}</span>
        <input className="inp" inputMode="decimal" value={c.value || ""} onChange={(e) => setC({ ...c, value: num(e.target.value) })} />
      </label>
      <label className="field">
        <span>{t(lang, "minOrder")}</span>
        <input className="inp" inputMode="decimal" value={c.min || ""} onChange={(e) => setC({ ...c, min: num(e.target.value) })} />
      </label>
      <label className="field">
        <span>{t(lang, "maxDisc")}</span>
        <input className="inp" inputMode="decimal" value={c.max || ""} onChange={(e) => setC({ ...c, max: num(e.target.value) })} />
      </label>
      <label className="field">
        <span>{t(lang, "limit")}</span>
        <input className="inp" inputMode="numeric" value={c.limit || ""} onChange={(e) => setC({ ...c, limit: Math.floor(num(e.target.value)) })} />
      </label>
      <label className="field">
        <span>{t(lang, "used")}</span>
        <input className="inp" inputMode="numeric" value={String(c.used || 0)} onChange={(e) => setC({ ...c, used: Math.floor(num(e.target.value)) })} />
      </label>
      <label className="field">
        <span>{t(lang, "expiry")}</span>
        <input className="inp" type="date" value={c.exp} onChange={(e) => setC({ ...c, exp: e.target.value })} />
      </label>
      <label className="mb-3 flex items-center gap-2 font-semibold">
        <input type="checkbox" checked={c.active} onChange={(e) => setC({ ...c, active: e.target.checked })} />
        {t(lang, "active")}
      </label>
      <div className="flex gap-2">
        <button type="submit" className="btn btn-pri">
          {t(lang, "save")}
        </button>
        <button type="button" className="btn" onClick={onClose}>
          {t(lang, "close")}
        </button>
      </div>
    </form>
  );
}

function Customers() {
  const customers = useShop((s) => s.customers);
  const phones = Object.keys(customers);
  if (!phones.length) return <p className="text-mut">{useShop.getState().lang === "bn" ? "এখানে কিছু নেই" : "Nothing here yet"}</p>;
  return (
    <>
      {phones.map((phone) => (
        <CustomerRow key={phone} phone={phone} />
      ))}
    </>
  );
}

function CustomerRow({ phone }: { phone: string }) {
  const lang = useShop((s) => s.lang);
  const c = useShop((s) => s.customers[phone]);
  const orders = useShop((s) => s.orders);
  const adjust = useShop((s) => s.adjustCoins);
  const block = useShop((s) => s.toggleBlock);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  if (!c) return null;
  return (
    <article className="box">
      <b>
        {c.name} · {c.phone} {c.blocked ? "· blocked" : ""}
      </b>
      <div className="text-sm text-mut">
        {t(lang, "coins")} {c.coins} · {orders.filter((o) => o.phone === phone).length} {t(lang, "orders")}
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        <input className="inp" style={{ width: 110 }} inputMode="numeric" placeholder="+/-" value={amount} onChange={(e) => setAmount(e.target.value)} aria-label={t(lang, "amount")} />
        <input className="inp" style={{ flex: 1, minWidth: 120 }} placeholder={t(lang, "reason")} value={reason} onChange={(e) => setReason(e.target.value)} />
        <button
          type="button"
          className="btn"
          onClick={() => {
            if (adjust(phone, Math.floor(num(amount)), reason)) {
              setAmount("");
              setReason("");
            }
          }}
        >
          OK
        </button>
        <button type="button" className="btn" onClick={() => block(phone)}>
          {c.blocked ? t(lang, "unblock") : t(lang, "block")}
        </button>
      </div>
    </article>
  );
}

function Site({ onPassword }: { onPassword: () => void }) {
  const lang = useShop((s) => s.lang);
  const saveSettings = useShop((s) => s.saveSettings);
  const resetLook = useShop((s) => s.resetLook);
  const removeSamples = useShop((s) => s.removeSamples);
  const importData = useShop((s) => s.importData);
  const resetAll = useShop((s) => s.resetAll);
  const showToast = useShop((s) => s.showToast);
  const [form, setForm] = useState<Settings>(() => structuredClone(useShop.getState().settings));
  const [pw1, setPw1] = useState("");
  const [pw2, setPw2] = useState("");

  const setUi = (patch: Partial<Settings["ui"]>) => setForm((f) => ({ ...f, ui: { ...f.ui, ...patch } }));

  return (
    <>
      <form
        className="box"
        onSubmit={(e) => {
          e.preventDefault();
          saveSettings(form);
        }}
      >
        <b>{t(lang, "look")}</b>
        <label className="field mt-2">
          <span>{t(lang, "mainColor")}</span>
          <input className="inp" type="color" value={form.ui.c1} onChange={(e) => setUi({ c1: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "accent")}</span>
          <input className="inp" type="color" value={form.ui.c2} onChange={(e) => setUi({ c2: e.target.value })} />
        </label>
        <label className="field">
          <span>
            {t(lang, "radius")}: {form.ui.rad}px
          </span>
          <input className="inp" type="range" min={0} max={28} value={form.ui.rad} onChange={(e) => setUi({ rad: Number(e.target.value) })} />
        </label>
        <label className="field">
          <span>
            {t(lang, "cardW")}: {form.ui.cols}px
          </span>
          <input className="inp" type="range" min={120} max={240} step={10} value={form.ui.cols} onChange={(e) => setUi({ cols: Number(e.target.value) })} />
        </label>
        <label className="mb-2 flex items-center gap-2">
          <input type="checkbox" checked={form.ui.splash} onChange={(e) => setUi({ splash: e.target.checked })} />
          {t(lang, "splash")}
        </label>
        <label className="field">
          <span>
            {t(lang, "splashTime")}: {form.ui.dur}s
          </span>
          <input className="inp" type="range" min={1} max={5} value={form.ui.dur} onChange={(e) => setUi({ dur: Number(e.target.value) })} />
        </label>
        <label className="mb-2 flex items-center gap-2">
          <input type="checkbox" checked={form.ui.hero} onChange={(e) => setUi({ hero: e.target.checked })} />
          {t(lang, "showHero")}
        </label>
        <label className="mb-3 flex items-center gap-2">
          <input type="checkbox" checked={form.ui.bar} onChange={(e) => setUi({ bar: e.target.checked })} />
          {t(lang, "showBar")}
        </label>
        <div className="mb-4 flex gap-2">
          <button type="submit" className="btn btn-pri">
            {t(lang, "save")}
          </button>
          <button
            type="button"
            className="btn"
            onClick={() => {
              resetLook();
              setForm((f) => ({ ...f, ui: { ...defaultSettings().ui } }));
            }}
          >
            {t(lang, "resetLook")}
          </button>
        </div>

        <label className="field">
          <span>{t(lang, "brand")}</span>
          <input className="inp" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "announce")}</span>
          <input className="inp" value={form.announce} onChange={(e) => setForm({ ...form, announce: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "tagline")}</span>
          <input className="inp" value={form.tag} onChange={(e) => setForm({ ...form, tag: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "logo")}</span>
          <input
            className="inp"
            type="file"
            accept="image/*"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setForm({ ...form, logo: await compressImage(f, 320) });
              } catch {
                showToast(t(lang, "imgBad"));
              }
            }}
          />
          <button type="button" className="btn mt-2" onClick={() => setForm({ ...form, logo: undefined })}>
            {t(lang, "useDefault")}
          </button>
        </label>
        <label className="field">
          <span>{t(lang, "banner")}</span>
          <input
            className="inp"
            type="file"
            accept="image/*"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setForm({ ...form, banner: await compressImage(f, 900) });
              } catch {
                showToast(t(lang, "imgBad"));
              }
            }}
          />
        </label>
        <label className="field">
          <span>{t(lang, "addr")}</span>
          <input className="inp" value={form.addr} onChange={(e) => setForm({ ...form, addr: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "about")}</span>
          <textarea className="inp" rows={3} value={form.about} onChange={(e) => setForm({ ...form, about: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "delivery")}</span>
          <textarea className="inp" rows={3} value={form.delv} onChange={(e) => setForm({ ...form, delv: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "privacy")}</span>
          <textarea className="inp" rows={3} value={form.priv} onChange={(e) => setForm({ ...form, priv: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "terms")}</span>
          <textarea className="inp" rows={3} value={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "footer")}</span>
          <input className="inp" value={form.foot} onChange={(e) => setForm({ ...form, foot: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "waNum")}</span>
          <input className="inp" value={form.wa} onChange={(e) => setForm({ ...form, wa: e.target.value })} />
        </label>
        <label className="field">
          <span>{t(lang, "fee")}</span>
          <input className="inp" type="number" value={form.fee} onChange={(e) => setForm({ ...form, fee: num(e.target.value) })} />
        </label>
        <label className="field">
          <span>{t(lang, "freeOver")}</span>
          <input className="inp" type="number" value={form.free} onChange={(e) => setForm({ ...form, free: num(e.target.value) })} />
        </label>
        <button type="submit" className="btn btn-pri">
          {t(lang, "save")}
        </button>
      </form>

      <div className="box flex flex-wrap gap-2">
        <button
          type="button"
          className="btn"
          onClick={() => downloadText("orders.csv", ordersCsv(useShop.getState().orders), "text/csv")}
        >
          {t(lang, "exportCsv")}
        </button>
        <button
          type="button"
          className="btn"
          onClick={() => {
            const s = useShop.getState();
            downloadText(
              "familycarebd-backup.json",
              JSON.stringify({
                products: s.products,
                categories: s.categories,
                settings: s.settings,
                coupons: s.coupons,
                orders: s.orders,
                customers: s.customers,
              }),
              "application/json",
            );
          }}
        >
          {t(lang, "backup")}
        </button>
        <label className="btn">
          {t(lang, "restore")}
          <input
            hidden
            type="file"
            accept="application/json"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const r = new FileReader();
              r.onload = () => {
                try {
                  importData(JSON.parse(String(r.result)));
                } catch {
                  showToast(t(lang, "badBackup"));
                }
              };
              r.readAsText(f);
            }}
          />
        </label>
        <button
          type="button"
          className="btn"
          onClick={() => {
            if (confirm(t(lang, "confirmSamples"))) removeSamples();
          }}
        >
          {t(lang, "removeSamples")}
        </button>
      </div>

      <form
        className="box"
        onSubmit={async (e) => {
          e.preventDefault();
          if (pw1.length < 6 || pw1 !== pw2) {
            showToast(t(lang, "min6"));
            return;
          }
          await savePassword(pw1);
          setPw1("");
          setPw2("");
          onPassword();
          showToast(t(lang, "pwChanged"));
        }}
      >
        <b>{t(lang, "changePw")}</b>
        <input className="inp mt-2" type="password" placeholder={t(lang, "pwNew")} value={pw1} onChange={(e) => setPw1(e.target.value)} />
        <input className="inp mt-2" type="password" placeholder={t(lang, "pwAgain")} value={pw2} onChange={(e) => setPw2(e.target.value)} />
        <button type="submit" className="btn btn-pri mt-3">
          {t(lang, "changePw")}
        </button>
        <button
          type="button"
          className="btn btn-danger mt-3 ml-2"
          onClick={() => {
            if (confirm(t(lang, "confirmReset"))) resetAll();
          }}
        >
          {t(lang, "resetData")}
        </button>
      </form>
    </>
  );
}
