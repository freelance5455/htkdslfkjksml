import React, { useState } from 'react';
import { Star, Heart } from 'lucide-react';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart?: (product: Product, e: React.MouseEvent) => void;
  onBuyNow?: (product: Product, e: React.MouseEvent) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  isWishlisted,
  onToggleWishlist,
}) => {
  const [isHeartPopping, setIsHeartPopping] = useState(false);

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsHeartPopping(true);
    onToggleWishlist(product, e);
    setTimeout(() => setIsHeartPopping(false), 300);
  };

  const discountPercent =
    product.discount > 0
      ? product.discount
      : product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 0;

  return (
    <div
      onClick={() => onSelect(product)}
      className="group relative bg-white border border-[#EAEAEA] hover:border-[#000000] rounded-xl sm:rounded-2xl p-2 sm:p-2.5 flex flex-col justify-between h-full shadow-2xs hover:shadow-xs transition-colors duration-200 cursor-pointer select-none carousel-card-touch"
      style={{
        touchAction: 'pan-y pinch-zoom',
      }}
    >
      <div className="flex flex-col h-full justify-between">
        <div>
          {/* 1:1 Square aspect ratio container */}
          <div
            className="relative w-full aspect-square rounded-lg sm:rounded-xl bg-[#FAFAFA] overflow-hidden flex items-center justify-center border border-[#EAEAEA]/80"
            style={{ touchAction: 'pan-y pinch-zoom' }}
          >
            {/* Wishlist Heart Icon */}
            <button
              onClick={handleHeartClick}
              className={`absolute top-1.5 right-1.5 z-10 w-7 h-7 rounded-full bg-white/90 hover:bg-[#FFD400] shadow-xs flex items-center justify-center transition-all cursor-pointer ${
                isWishlisted
                  ? 'text-[#000000] scale-105'
                  : 'text-[#666666] hover:text-[#000000]'
              } ${isHeartPopping ? 'animate-heart-pulse' : ''}`}
              aria-label={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
            >
              <Heart
                className={`w-4 h-4 transition-colors ${
                  isWishlisted ? 'fill-[#000000] text-[#000000]' : 'stroke-[1.8] text-[#666666]'
                }`}
              />
            </button>

            {/* Product Image */}
            <img
              src={product.images[0]}
              alt={product.name}
              draggable={false}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300 ease-out pointer-events-none select-none"
              style={{ touchAction: 'pan-y pinch-zoom' }}
              loading="lazy"
            />
          </div>

          {/* Titles & Brand Name */}
          <div className="mt-2 px-0.5">
            <div className="text-[10px] sm:text-[11px] font-bold text-[#666666] uppercase tracking-wider truncate">
              {product.brand || product.category}
            </div>

            <h3
              className="text-xs sm:text-[13px] font-semibold text-[#111111] group-hover:text-[#000000] line-clamp-2 leading-[1.3] mt-0.5 transition-colors"
              title={product.name}
            >
              {product.name}
            </h3>

            {/* Ratings Layer */}
            {product.rating > 0 && (
              <div className="flex items-center gap-1.5 mt-1.5">
                <div className="inline-flex items-center gap-0.5 bg-[#000000] text-[#FFD400] font-black text-[10px] px-1.5 py-0.5 rounded leading-none">
                  <span>{product.rating.toFixed(1)}</span>
                  <Star className="w-2.5 h-2.5 fill-[#FFD400] text-[#FFD400]" />
                </div>
                {product.reviewsCount > 0 && (
                  <span className="text-[#666666] text-[10px] sm:text-[10.5px] font-medium leading-none">
                    ({product.reviewsCount >= 1000 ? `${(product.reviewsCount / 1000).toFixed(1)}k` : product.reviewsCount})
                  </span>
                )}
              </div>
            )}

            {/* Pricing Layer */}
            <div className="flex flex-wrap items-baseline gap-1.5 mt-1.5">
              <span className="text-sm sm:text-base font-black text-[#111111] leading-none">
                ₹{product.price.toLocaleString()}
              </span>
              {product.originalPrice > product.price && (
                <>
                  <span className="text-[11px] sm:text-xs text-[#666666] line-through leading-none">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                  <span className="text-[10.5px] sm:text-xs font-black text-[#000000] bg-[#FFF9DB] px-1 py-0.2 rounded border border-[#FFD400]/40 leading-none">
                    {discountPercent}% OFF
                  </span>
                </>
              )}
            </div>

            {/* Delivery / COD Assurance */}
            <div className="flex items-center gap-1.5 mt-1.5 text-[10px] font-medium text-[#666666]">
              <span className="text-[#111111] font-bold">Free Delivery</span>
              <span>•</span>
              <span className="font-semibold text-[#111111]">COD Available</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
