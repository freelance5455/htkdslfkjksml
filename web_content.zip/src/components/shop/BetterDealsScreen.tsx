import React, { useState, useMemo } from 'react';
import {
  Search, ShoppingCart, Star, Heart, X, Zap, Sparkles, ArrowLeft, CheckCircle2
} from 'lucide-react';
import { Product } from '../../types';

interface BetterDealsScreenProps {
  products: Product[];
  cartCount?: number;
  onOpenCart?: () => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart?: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onBack?: () => void;
}

interface DealCategory {
  id: string;
  name: string;
  image: string;
  filterTag: string;
}

const DEAL_CATEGORIES: DealCategory[] = [
  {
    id: 'all-deals',
    name: 'All Deals',
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=160&auto=format&fit=crop&q=80',
    filterTag: 'all',
  },
  {
    id: 'footwear',
    name: 'Footwear',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=160&auto=format&fit=crop&q=80',
    filterTag: 'footwear',
  },
  {
    id: 'fashion',
    name: 'Fashion',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=160&auto=format&fit=crop&q=80',
    filterTag: 'fashion',
  },
  {
    id: 'bags',
    name: 'Bags',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=160&auto=format&fit=crop&q=80',
    filterTag: 'bags',
  },
  {
    id: 'electronics',
    name: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=160&auto=format&fit=crop&q=80',
    filterTag: 'electronics',
  },
  {
    id: 'home',
    name: 'Home',
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?w=160&auto=format&fit=crop&q=80',
    filterTag: 'home',
  },
  {
    id: 'beauty',
    name: 'Beauty',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=160&auto=format&fit=crop&q=80',
    filterTag: 'beauty',
  },
  {
    id: 'more',
    name: 'More',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=160&auto=format&fit=crop&q=80',
    filterTag: 'more',
  },
];

export const BetterDealsScreen: React.FC<BetterDealsScreenProps> = ({
  products,
  cartCount = 0,
  onOpenCart,
  onSelectProduct,
  wishlistIds,
  onToggleWishlist,
  onBack,
}) => {
  const [selectedDealId, setSelectedDealId] = useState<string>('all-deals');
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const activeCategory = useMemo(() => {
    return DEAL_CATEGORIES.find((d) => d.id === selectedDealId) || DEAL_CATEGORIES[0];
  }, [selectedDealId]);

  const dealProducts = useMemo(() => {
    let list = [...products];

    if (activeCategory.filterTag === 'all') {
      list = list.filter((p) => p.discount >= 25);
    } else if (activeCategory.filterTag === 'footwear') {
      list = list.filter(
        (p) =>
          p.category?.toLowerCase() === 'men' ||
          p.category?.toLowerCase() === 'women' ||
          p.subcategory?.toLowerCase().includes('shoe') ||
          p.subcategory?.toLowerCase().includes('sand') ||
          p.subcategory?.toLowerCase().includes('chappal') ||
          p.subcategory?.toLowerCase().includes('slip')
      );
    } else if (activeCategory.filterTag === 'fashion') {
      list = list.filter(
        (p) =>
          p.category?.toLowerCase() === 'men' ||
          p.category?.toLowerCase() === 'women' ||
          p.subcategory?.toLowerCase().includes('sneaker')
      );
    } else if (activeCategory.filterTag === 'bags') {
      list = list.filter(
        (p) =>
          p.category?.toLowerCase() === 'bags' ||
          p.subcategory?.toLowerCase().includes('bag')
      );
    } else if (activeCategory.filterTag === 'electronics') {
      list = list.filter(
        (p) =>
          p.category?.toLowerCase() === 'accessories' ||
          p.category?.toLowerCase() === 'watches' ||
          p.subcategory?.toLowerCase().includes('watch')
      );
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category?.toLowerCase().includes(q) ||
          p.subcategory?.toLowerCase().includes(q)
      );
    }

    list.sort((a, b) => (b.discount || 0) - (a.discount || 0));

    if (list.length === 0) {
      list = products.slice(0, 6);
    }

    return list;
  }, [products, activeCategory, searchQuery]);

  return (
    <div className="w-full min-h-screen bg-[#FAFAFA] pb-24 md:pb-12 text-[#111111]">
      {/* 1. TOP APP BAR */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#EAEAEA] shadow-2xs">
        <div className="max-w-7xl mx-auto px-3.5 sm:px-6 h-[52px] sm:h-[56px] flex items-center justify-between gap-2">
          {/* Left: Back button + Title */}
          <div className="flex items-center gap-2 min-w-0">
            {onBack && (
              <button
                onClick={onBack}
                className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer -ml-1"
                aria-label="Back"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#000000] text-[#FFD400] flex items-center justify-center shadow-xs">
                <Zap className="w-4 h-4 fill-[#FFD400]" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-black text-[#111111] tracking-tight leading-tight">
                  Mega Deals
                </h1>
                <p className="text-[10px] text-[#666666] font-semibold hidden xs:block">
                  Lowest Prices Guaranteed
                </p>
              </div>
            </div>
          </div>

          {/* Right: Search & Cart */}
          <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            <button
              onClick={() => setSearchOpen((prev) => !prev)}
              className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
              aria-label="Search deals"
            >
              <Search className="w-5 h-5" />
            </button>

            <button
              onClick={onOpenCart}
              className="relative w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
              aria-label="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-0.5 right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#000000] text-[#FFD400] text-[10px] font-black flex items-center justify-center ring-2 ring-white shadow-2xs">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Collapsible search bar */}
        {searchOpen && (
          <div className="px-3.5 pb-2.5 pt-1 max-w-7xl mx-auto animate-in slide-in-from-top-1 duration-150">
            <div className="relative flex items-center w-full">
              <Search className="w-4 h-4 text-[#666666] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search deals on footwear, bags..."
                autoFocus
                className="w-full pl-9 pr-8 py-1.5 text-xs sm:text-sm bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:outline-none focus:border-[#000000] focus:ring-2 focus:ring-[#FFD400]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#666666] hover:text-[#111111] p-0.5 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* 2. HORIZONTAL STORY-STYLE CIRCULAR DEAL CATEGORIES */}
      <section className="bg-white border-b border-[#EAEAEA] py-3 shadow-2xs">
        <div className="max-w-7xl mx-auto px-2 sm:px-4">
          <div
            className="flex gap-2.5 sm:gap-4 overflow-x-auto scrollbar-none py-1 px-1 carousel-touch-container"
            style={{
              WebkitOverflowScrolling: 'touch',
              touchAction: 'pan-x pan-y pinch-zoom',
            }}
          >
            {DEAL_CATEGORIES.map((cat) => {
              const isActive = cat.id === selectedDealId;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedDealId(cat.id);
                    setSearchQuery('');
                  }}
                  className="group flex flex-col items-center flex-shrink-0 cursor-pointer select-none transition-transform carousel-card-touch"
                  style={{
                    touchAction: 'pan-y pinch-zoom',
                  }}
                >
                  <div
                    className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full p-0.5 transition-all duration-200 ${
                      isActive
                        ? 'ring-2 ring-[#000000] scale-105 shadow-xs'
                        : 'ring-1 ring-[#EAEAEA] hover:ring-[#FFD400]'
                    }`}
                  >
                    <img
                      src={cat.image}
                      alt={cat.name}
                      draggable={false}
                      className="w-full h-full object-cover rounded-full pointer-events-none select-none"
                    />
                  </div>

                  <span
                    className={`text-[11px] sm:text-xs font-bold mt-1.5 tracking-tight truncate max-w-[68px] ${
                      isActive ? 'text-[#000000] font-black' : 'text-[#666666] group-hover:text-[#111111]'
                    }`}
                  >
                    {cat.name}
                  </span>

                  {isActive && (
                    <span className="w-5 h-[2px] bg-[#FFD400] rounded-full mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. HERO PROMO BANNER */}
      <section className="max-w-7xl mx-auto px-3 sm:px-4 pt-3.5 pb-2">
        <div className="relative rounded-2xl bg-[#000000] text-white p-3.5 sm:p-4 shadow-sm border border-black flex items-center justify-between overflow-hidden">
          <div className="relative z-10 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFD400] text-[#000000] flex items-center justify-center font-black text-sm shadow-xs shrink-0">
              <Zap className="w-5 h-5 fill-black" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-black text-[#FFD400] uppercase tracking-wider">
                <Sparkles className="w-3 h-3" />
                <span>LIMITED TIME OFFER</span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white leading-tight">
                Up to 70% OFF • 100% Cash on Delivery
              </h2>
            </div>
          </div>
          <span className="text-[11px] font-black text-[#000000] bg-[#FFD400] px-3 py-1 rounded-lg shadow-xs flex-shrink-0">
            Free Delivery
          </span>
        </div>
      </section>

      {/* 4. PRODUCT CARDS GRID */}
      <main className="max-w-7xl mx-auto px-2.5 sm:px-4 py-2">
        <div className="flex items-center justify-between mb-3 px-1">
          <p className="text-xs font-bold text-[#111111]">
            Showing <span className="text-[#000000] font-black">{dealProducts.length}</span> deals in {activeCategory.name}
          </p>
          <span className="text-[11px] text-[#666666] font-medium flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#000000]" />
            COD Available
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
          {dealProducts.map((product) => {
            const isWishlisted = wishlistIds.has(product.id);
            const originalPrice = product.originalPrice || Math.round(product.price * 1.5);
            const discountPct =
              product.discount || Math.round(((originalPrice - product.price) / originalPrice) * 100);

            return (
              <div
                key={product.id}
                onClick={() => onSelectProduct(product)}
                className="group relative bg-white rounded-xl sm:rounded-2xl p-2.5 sm:p-3 border border-[#EAEAEA] hover:border-[#000000] shadow-2xs hover:shadow-xs transition-colors duration-200 flex flex-col justify-between cursor-pointer select-none carousel-card-touch"
                style={{
                  touchAction: 'pan-y pinch-zoom',
                }}
              >
                <div>
                  {/* Image container */}
                  <div
                    className="relative w-full aspect-square rounded-lg overflow-hidden bg-[#FAFAFA] mb-2 border border-[#EAEAEA]/70"
                    style={{ touchAction: 'pan-y pinch-zoom' }}
                  >
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      draggable={false}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300 ease-out pointer-events-none select-none"
                      style={{
                        touchAction: 'pan-y pinch-zoom',
                      }}
                      loading="lazy"
                    />

                    {/* Wishlist */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleWishlist(product, e);
                      }}
                      className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-white/90 hover:bg-[#FFD400] flex items-center justify-center text-[#666666] hover:text-[#000000] shadow-xs transition-colors cursor-pointer"
                      aria-label="Wishlist"
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          isWishlisted ? 'fill-[#000000] text-[#000000]' : 'stroke-[1.8]'
                        }`}
                      />
                    </button>

                    {/* Deal badge */}
                    {discountPct > 0 && (
                      <span className="absolute top-1.5 left-1.5 bg-[#FFD400] text-[#000000] text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs uppercase tracking-tight flex items-center gap-0.5">
                        <Zap className="w-2.5 h-2.5 fill-black" />
                        {discountPct}% OFF
                      </span>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-[#000000] text-[#FFD400] text-[10px] font-bold">
                      <span>{product.rating.toFixed(1)}</span>
                      <Star className="w-2.5 h-2.5 fill-current text-[#FFD400]" />
                    </span>
                    <span className="text-[10px] text-[#666666] font-medium">
                      ({product.reviewsCount})
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-xs sm:text-[13px] font-bold text-[#111111] line-clamp-2 leading-snug group-hover:text-[#000000] transition-colors">
                    {product.name}
                  </h3>
                </div>

                {/* Price */}
                <div className="mt-2 pt-2 border-t border-[#EAEAEA]">
                  <div className="flex items-baseline gap-1.5 flex-wrap">
                    <span className="text-sm sm:text-base font-black text-[#111111] tracking-tight">
                      ₹{product.price.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-[#666666] line-through">
                      ₹{originalPrice.toLocaleString()}
                    </span>
                    <span className="text-[10.5px] font-black text-[#000000] ml-auto bg-[#FFF9DB] px-1 py-0.2 rounded border border-[#FFD400]/40">
                      Save ₹{(originalPrice - product.price).toLocaleString()}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="text-[10px] text-[#111111] font-bold">
                      Free Delivery • COD
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default BetterDealsScreen;
