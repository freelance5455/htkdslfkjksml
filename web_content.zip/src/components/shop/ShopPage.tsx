import React, { useState, useMemo } from 'react';
import {
  Search, ArrowUpDown, SlidersHorizontal,
  X, Sparkles
} from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { searchProducts } from '../../services/searchService';
import { useLanguage } from '../../context/LanguageContext';

interface ShopPageProps {
  products: Product[];
  initialCategory?: string;
  isOffersView?: boolean;
  initialSearchQuery?: string;
  onSearchQueryChange?: (query: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  initialCategory,
  isOffersView = false,
  initialSearchQuery = '',
  onSearchQueryChange,
  onSelectProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist,
}) => {
  const { t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>(
    initialCategory && initialCategory.toLowerCase() !== 'offers' ? initialCategory : 'All'
  );
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'rating'>('popular');
  const [searchFilter, setSearchFilter] = useState(initialSearchQuery);
  const [showFiltersPanel, setShowFiltersPanel] = useState(false);
  const [minDiscount, setMinDiscount] = useState<number>(0);

  React.useEffect(() => {
    if (initialCategory) {
      if (initialCategory.toLowerCase() === 'offers') {
        setSelectedCategory('All');
      } else {
        setSelectedCategory(initialCategory);
      }
    }
  }, [initialCategory]);

  React.useEffect(() => {
    setSearchFilter(initialSearchQuery);
  }, [initialSearchQuery]);

  const categories = useMemo(() => {
    const rawCats = Array.from(new Set(products.map((p) => p.category)));
    return ['All', ...rawCats];
  }, [products]);

  const getCategoryLabel = (cat: string) => {
    if (cat.toLowerCase() === 'all') return t('all');
    if (cat.toLowerCase() === 'men') return t('men');
    if (cat.toLowerCase() === 'women') return t('women');
    if (cat.toLowerCase() === 'kids') return t('kids');
    if (cat.toLowerCase() === 'bags') return t('bags');
    if (cat.toLowerCase() === 'footwear') return t('footwear');
    return cat;
  };

  const handleSearchChange = (val: string) => {
    setSearchFilter(val);
    onSearchQueryChange?.(val);
  };

  const handleClearSearch = () => {
    setSearchFilter('');
    onSearchQueryChange?.('');
  };

  const searchResult = useMemo(() => {
    return searchProducts(products, searchFilter, selectedCategory);
  }, [products, searchFilter, selectedCategory]);

  const finalProducts = useMemo(() => {
    let list = searchResult.exactMatches;
    if (minDiscount > 0) {
      list = list.filter((p) => p.discount >= minDiscount);
    }
    return [...list].sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (isOffersView) {
        return (b.discount || 0) - (a.discount || 0);
      }
      return (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0);
    });
  }, [searchResult.exactMatches, minDiscount, sortBy, isOffersView]);

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-24">
      {/* Page Title */}
      <div className="mb-4 sm:mb-6 text-center sm:text-left">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-[#111111] tracking-tight flex items-center justify-center sm:justify-start gap-2">
          {isOffersView ? (
            <>
              <span className="text-[#FFD400]">⚡</span>
              <span>Offers & Mega Deals</span>
            </>
          ) : (
            'All Products'
          )}
        </h1>
        <p className="text-xs sm:text-sm text-[#666666] mt-1">
          {isOffersView
            ? 'Up to 60% Off on Top Footwear, Sneakers & Bags • 100% Cash on Delivery'
            : 'Authentic Products • Free Delivery on ₹999+ • Cash on Delivery'}
        </p>
      </div>

      {/* Control Bar: Categories Filter & Search Filter */}
      <div className="bg-white border border-[#EAEAEA] rounded-xl sm:rounded-2xl p-3 sm:p-3.5 mb-4 space-y-3 sm:space-y-0 sm:flex sm:items-center sm:justify-between gap-3 shadow-2xs">
        {/* Categories Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
                selectedCategory.toLowerCase() === cat.toLowerCase()
                  ? 'bg-[#000000] text-[#FFD400] shadow-xs'
                  : 'bg-[#FAFAFA] text-[#111111] hover:bg-[#FFF9DB] border border-[#EAEAEA]'
              }`}
            >
              {getCategoryLabel(cat)}
            </button>
          ))}
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2">
          {/* Quick Search */}
          <div className="relative flex-1 sm:w-56 lg:w-64">
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search in catalog..."
              className="w-full h-8.5 pl-7 pr-8 text-xs bg-[#FAFAFA] focus:bg-white text-[#111111] border border-[#EAEAEA] focus:border-[#000000] rounded-xl focus:outline-none"
            />
            <Search className="w-3.5 h-3.5 text-[#666666] absolute left-2.5 top-2.5" />
            {searchFilter && (
              <button
                onClick={handleClearSearch}
                className="absolute right-2.5 top-2 text-[#666666] hover:text-[#111111] p-0.5 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Sort Selector */}
          <div className="relative flex items-center">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="h-8.5 pl-2.5 pr-6 text-xs font-semibold bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl text-[#111111] focus:outline-none focus:border-[#000000] appearance-none cursor-pointer"
            >
              <option value="popular">Popular</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
            <ArrowUpDown className="w-3 h-3 text-[#666666] absolute right-2 pointer-events-none" />
          </div>

          {/* Filter Toggle */}
          <button
            onClick={() => setShowFiltersPanel((prev) => !prev)}
            title="Filter"
            aria-label="Filter"
            className={`w-8.5 h-8.5 rounded-xl flex items-center justify-center cursor-pointer transition-colors border ${
              showFiltersPanel || minDiscount > 0
                ? 'bg-[#FFD400] text-[#000000] border-[#FFD400] shadow-xs'
                : 'bg-[#FAFAFA] text-[#111111] hover:bg-[#FFF9DB] border-[#EAEAEA]'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Query Search Tag */}
      {searchFilter.trim() && (
        <div className="mb-4 p-3 bg-white border border-[#EAEAEA] rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold text-[#666666] uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#FFD400]" />
              Search:
            </span>
            <span className="font-extrabold text-[#000000] px-2 py-0.5 bg-[#FFF9DB] border border-[#FFD400]/40 rounded-lg">
              "{searchFilter}"
            </span>
          </div>
          <button
            onClick={handleClearSearch}
            className="text-[11px] font-bold text-[#000000] hover:underline cursor-pointer"
          >
            Clear Search
          </button>
        </div>
      )}

      {/* Collapsible Filters Panel */}
      {showFiltersPanel && (
        <div className="mb-5 p-4 bg-white border border-[#EAEAEA] rounded-xl shadow-xs animate-in slide-in-from-top-2 duration-150">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#EAEAEA]">
            <h3 className="font-black text-sm text-[#111111] flex items-center gap-1.5">
              <SlidersHorizontal className="w-4 h-4 text-[#000000]" />
              <span>Filters</span>
            </h3>
            {minDiscount > 0 && (
              <button
                onClick={() => setMinDiscount(0)}
                className="text-xs text-[#000000] hover:underline font-bold cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
          <div>
            <p className="text-xs font-bold text-[#111111] mb-2">Minimum Discount</p>
            <div className="flex flex-wrap gap-2">
              {[0, 20, 30, 40, 50, 60].map((d) => (
                <button
                  key={d}
                  onClick={() => setMinDiscount(d)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    minDiscount === d
                      ? 'bg-[#000000] text-[#FFD400] shadow-xs'
                      : 'bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#111111] border border-[#EAEAEA]'
                  }`}
                >
                  {d === 0 ? 'All' : `${d}% OFF`}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Results Header Count */}
      <div className="flex items-center justify-between text-xs text-[#666666] mb-3 px-1">
        <span className="font-semibold text-[#111111]">
          {finalProducts.length}{' '}
          {isOffersView ? 'Products on Special Offer' : 'Matching Products'}
        </span>
        {(selectedCategory !== 'All' || minDiscount > 0 || searchFilter) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setMinDiscount(0);
              handleClearSearch();
            }}
            className="text-[#000000] hover:underline font-bold cursor-pointer"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Products Grid */}
      {finalProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2.5 sm:gap-3 md:gap-4">
          {finalProducts.map((prod) => (
            <div key={prod.id} className="h-full">
              <ProductCard
                product={prod}
                onSelect={onSelectProduct}
                onAddToCart={onAddToCart}
                isWishlisted={wishlistIds.has(prod.id)}
                onToggleWishlist={onToggleWishlist}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="py-12 px-4 text-center bg-white rounded-2xl border border-[#EAEAEA] my-6 max-w-2xl mx-auto shadow-2xs">
          <div className="w-12 h-12 rounded-full bg-[#FFF9DB] text-[#000000] flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base sm:text-lg font-black text-[#111111]">
            No matching products found
          </h3>
          <p className="text-xs text-[#666666] mt-1 max-w-md mx-auto">
            Try adjusting your search query or filters.
          </p>
          <div className="mt-6 flex items-center justify-center gap-2">
            <button
              onClick={() => {
                setSelectedCategory('All');
                setMinDiscount(0);
                handleClearSearch();
              }}
              className="px-5 py-2.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs transition-colors cursor-pointer shadow-xs"
            >
              Reset Filters
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShopPage;
