import React, { useState, useRef } from 'react';
import {
  X, Star, Heart, Check,
  ShoppingBag, ArrowRight, Share2, Maximize2,
  ChevronLeft, ChevronRight, Zap, ArrowLeft, Ruler, AlertCircle
} from 'lucide-react';
import { Product } from '../../types';

export interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, size?: string, color?: string) => void;
  onBuyNow: (product: Product, quantity: number, size?: string, color?: string) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  relatedProducts?: Product[];
  onSelectProduct?: (product: Product) => void;
  cartCount?: number;
  onOpenCart?: () => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  isWishlisted,
  onToggleWishlist,
  cartCount = 0,
  onOpenCart,
}) => {
  // Image Gallery State
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const touchStartXRef = useRef<number | null>(null);

  // Variant State (Default to first available variant if present)
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined
  );
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product.colors && product.colors.length > 0 ? product.colors[0].name : undefined
  );

  const [addedNotice, setAddedNotice] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [showSizeGuide, setShowSizeGuide] = useState(false);
  const [isDescExpanded, setIsDescExpanded] = useState(false);

  // Real product images from product data
  const images = product.images && product.images.length > 0 ? product.images : [];
  const activeImage = images[activeImageIndex] || images[0];

  // Pricing & discount calculations
  const discountPercent =
    product.discount > 0
      ? product.discount
      : product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 0;

  const savingsAmount = Math.max(0, product.originalPrice - product.price);

  // Swipe handlers for mobile image gallery
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartXRef.current - touchEndX;

    if (images.length > 1) {
      if (diff > 45) {
        setActiveImageIndex((prev) => (prev + 1) % images.length);
      } else if (diff < -45) {
        setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
      }
    }
    touchStartXRef.current = null;
  };

  const handleAddToCartClick = () => {
    if (product.stock <= 0) return;
    onAddToCart(product, 1, selectedSize, selectedColor);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleBuyNowClick = () => {
    if (product.stock <= 0) return;
    onBuyNow(product, 1, selectedSize, selectedColor);
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: product.name,
          text: `Check out ${product.name} on OMAZIFY!`,
          url,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }
    navigator.clipboard?.writeText(url);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2000);
  };

  const isOutOfStock = product.stock <= 0;

  const hasSpecs =
    Boolean(product.countryOfOrigin) ||
    Boolean(product.netQuantity) ||
    Boolean(product.gender) ||
    Boolean(product.subcategory) ||
    Boolean(product.specifications && Object.keys(product.specifications).length > 0);

  return (
    <div className="fixed inset-0 z-50 bg-[#FAFAFA] overflow-y-auto flex flex-col animate-in fade-in duration-200">
      {/* 1. TOP APP BAR */}
      <header className="sticky top-0 z-40 bg-white border-b border-[#EAEAEA] px-3 sm:px-6 py-2.5 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#111111] hover:text-[#000000] border border-[#EAEAEA] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0"
            aria-label="Back to Catalog"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] font-black uppercase tracking-wider text-[#666666] truncate">
              {product.brand || 'OMAZIFY'}
            </span>
            <span className="text-xs sm:text-sm font-black text-[#111111] truncate">
              {product.name}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
          {/* Share */}
          <button
            onClick={handleShare}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#111111] border border-[#EAEAEA] flex items-center justify-center transition-colors cursor-pointer relative"
            title="Share"
            aria-label="Share"
          >
            {copiedShare ? (
              <Check className="w-4 h-4 text-[#000000]" />
            ) : (
              <Share2 className="w-4 h-4" />
            )}
            {copiedShare && (
              <span className="absolute -bottom-7 right-0 bg-black text-white text-[10px] px-2 py-0.5 rounded shadow-md whitespace-nowrap">
                Link Copied!
              </span>
            )}
          </button>

          {/* Wishlist */}
          <button
            onClick={(e) => onToggleWishlist(product, e)}
            className={`w-9 h-9 rounded-full border border-[#EAEAEA] flex items-center justify-center transition-colors cursor-pointer ${
              isWishlisted
                ? 'bg-[#000000] text-[#FFD400]'
                : 'bg-[#FAFAFA] text-[#666666] hover:bg-[#FFF9DB] hover:text-[#000000]'
            }`}
            title="Wishlist"
            aria-label="Toggle Wishlist"
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#FFD400]' : ''}`} />
          </button>

          {/* Cart Icon with Counter */}
          {onOpenCart && (
            <button
              onClick={onOpenCart}
              className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#111111] border border-[#EAEAEA] flex items-center justify-center transition-colors cursor-pointer relative"
              title="Open Cart"
              aria-label="Cart"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#FFD400] text-[#000000] text-[10px] font-black flex items-center justify-center shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>
          )}

          {/* Close */}
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-colors cursor-pointer ml-1"
            title="Close"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* 2. MAIN SCROLLABLE CONTENT */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-3 sm:p-6 pb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-8 items-start">
          
          {/* LEFT COLUMN: PRODUCT IMAGES */}
          <div className="lg:col-span-6 space-y-3">
            {images.length > 0 && activeImage && (
              <div
                className="relative w-full aspect-square rounded-2xl sm:rounded-3xl bg-white border border-[#EAEAEA] overflow-hidden flex items-center justify-center shadow-xs select-none touch-pan-y"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
              >
                {/* Product Image */}
                <img
                  src={activeImage}
                  alt={product.name}
                  className={`w-full h-full object-cover object-center transition-transform duration-300 ${
                    isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
                  }`}
                  onClick={() => setIsZoomed(!isZoomed)}
                />

                {/* Discount Badge on Top Left */}
                {discountPercent > 0 && (
                  <div className="absolute top-3 left-3 bg-[#FFD400] text-[#000000] text-xs font-black px-2.5 py-1 rounded shadow-xs uppercase tracking-wide">
                    {discountPercent}% OFF
                  </div>
                )}

                {/* Zoom Toggle Button */}
                <button
                  type="button"
                  onClick={() => setIsZoomed(!isZoomed)}
                  className="absolute bottom-3 right-3 px-2.5 py-1 rounded bg-black/75 hover:bg-black text-white text-[10px] font-bold flex items-center gap-1 backdrop-blur-xs cursor-pointer shadow-xs"
                  title="Toggle Zoom"
                >
                  <Maximize2 className="w-3 h-3" />
                  <span>{isZoomed ? 'Reset' : 'Zoom'}</span>
                </button>

                {/* Desktop Navigation Arrows */}
                {images.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() => setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length)}
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 hover:bg-[#FFD400] text-[#000000] flex items-center justify-center shadow-md transition-all cursor-pointer opacity-80 hover:opacity-100"
                      aria-label="Previous Image"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveImageIndex((prev) => (prev + 1) % images.length)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 hover:bg-[#FFD400] text-[#000000] flex items-center justify-center shadow-md transition-all cursor-pointer opacity-80 hover:opacity-100"
                      aria-label="Next Image"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                )}

                {/* Mobile Image Counter */}
                {images.length > 1 && (
                  <div className="absolute top-3 right-3 bg-black/60 text-white text-[10px] font-bold px-2 py-0.5 rounded backdrop-blur-xs">
                    {activeImageIndex + 1} / {images.length}
                  </div>
                )}
              </div>
            )}

            {/* Thumbnail Row */}
            {images.length > 1 && (
              <div
                className="flex gap-2 overflow-x-auto pb-1 scrollbar-none carousel-touch-container"
                style={{
                  WebkitOverflowScrolling: 'touch',
                  touchAction: 'pan-x pan-y pinch-zoom',
                }}
              >
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIndex(idx)}
                    style={{ touchAction: 'pan-y pinch-zoom' }}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl border-2 p-0.5 bg-white overflow-hidden cursor-pointer transition-all flex-shrink-0 ${
                      activeImageIndex === idx
                        ? 'border-[#000000] ring-2 ring-[#FFD400] scale-102'
                        : 'border-[#EAEAEA] opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`thumbnail ${idx}`} className="w-full h-full object-cover rounded-lg" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: UNIFIED NATURAL FLOW */}
          <div className="lg:col-span-6">
            <div className="bg-white rounded-2xl sm:rounded-3xl border border-[#EAEAEA] p-5 sm:p-6 shadow-xs space-y-5">
              
              {/* SECTION A: PRODUCT DETAILS (Title, Brand, Rating) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black text-[#111111] uppercase tracking-wider">
                    {product.brand || 'OMAZIFY'}
                  </span>
                  {product.category && (
                    <span className="text-xs text-[#666666] font-medium">
                      {product.category}
                    </span>
                  )}
                </div>

                <h1 className="text-lg sm:text-2xl font-black text-[#111111] leading-snug">
                  {product.name}
                </h1>

                {/* Real Rating Display */}
                {product.rating > 0 && (
                  <div className="flex items-center gap-2 pt-0.5">
                    <div className="inline-flex items-center gap-1 bg-[#000000] text-[#FFD400] text-xs font-black px-2 py-0.5 rounded">
                      <Star className="w-3 h-3 fill-[#FFD400] text-[#FFD400]" />
                      <span>{product.rating.toFixed(1)}</span>
                    </div>
                    {product.reviewsCount > 0 && (
                      <span className="text-xs text-[#666666] font-medium">
                        {product.reviewsCount.toLocaleString()} {product.reviewsCount === 1 ? 'rating' : 'ratings'}
                      </span>
                    )}
                    <span className="text-xs font-bold text-[#111111]">• Verified Genuine</span>
                  </div>
                )}
              </div>

              {/* SECTION B: PRICING */}
              <div className="pt-4 border-t border-[#EAEAEA] space-y-1.5">
                <div className="flex items-baseline gap-2.5 flex-wrap">
                  <span className="text-2xl sm:text-3xl font-black text-[#111111] tracking-tight">
                    ₹{product.price.toLocaleString()}
                  </span>
                  {product.originalPrice > product.price && (
                    <span className="text-sm sm:text-base text-[#666666] line-through">
                      ₹{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {discountPercent > 0 && (
                    <span className="text-xs font-black text-[#000000] bg-[#FFD400] px-2 py-0.5 rounded">
                      {discountPercent}% OFF
                    </span>
                  )}
                </div>

                {savingsAmount > 0 && (
                  <p className="text-xs font-bold text-[#111111]">
                    You save ₹{savingsAmount.toLocaleString()}
                  </p>
                )}

                <div className="flex items-center justify-between text-xs text-[#666666] pt-1">
                  <span>Inclusive of all taxes</span>
                  {isOutOfStock ? (
                    <span className="text-rose-600 font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Out of Stock
                    </span>
                  ) : (
                    <span className="text-[#111111] font-bold">
                      In Stock • Cash on Delivery
                    </span>
                  )}
                </div>
              </div>

              {/* SECTION C: VARIANTS */}
              {( (product.sizes && product.sizes.length > 0) || (product.colors && product.colors.length > 0) ) && (
                <div className="pt-4 border-t border-[#EAEAEA] space-y-4">
                  {/* Size selection */}
                  {product.sizes && product.sizes.length > 0 && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-bold text-[#111111] uppercase tracking-wide">
                          Size: <span className="text-[#000000] font-black">{selectedSize}</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setShowSizeGuide(true)}
                          className="text-xs font-bold text-[#111111] hover:text-[#000000] flex items-center gap-1 cursor-pointer"
                        >
                          <Ruler className="w-3.5 h-3.5 text-[#FFD400]" />
                          <span>Size Guide</span>
                        </button>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {product.sizes.map((sz) => (
                          <button
                            key={sz}
                            type="button"
                            onClick={() => setSelectedSize(sz)}
                            className={`min-w-[46px] h-9 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center ${
                              selectedSize === sz
                                ? 'bg-[#000000] text-white border-[#000000] shadow-xs'
                                : 'bg-white text-[#111111] border-[#EAEAEA] hover:border-[#000000] hover:bg-[#FAFAFA]'
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Color selection */}
                  {product.colors && product.colors.length > 0 && (
                    <div>
                      <label className="text-xs font-bold text-[#111111] uppercase tracking-wide block mb-2">
                        Color: <span className="text-[#000000] font-black capitalize">{selectedColor}</span>
                      </label>
                      <div className="flex items-center gap-2.5">
                        {product.colors.map((c) => (
                          <button
                            key={c.name}
                            type="button"
                            onClick={() => setSelectedColor(c.name)}
                            className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                              selectedColor === c.name
                                ? 'scale-110 border-[#000000] ring-2 ring-[#FFD400]'
                                : 'border-[#EAEAEA] hover:scale-105'
                            }`}
                            style={{ backgroundColor: c.hex }}
                            title={c.name}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* SECTION D: DESCRIPTION & SPECIFICATIONS */}
              {product.description && (
                <div className="pt-4 border-t border-[#EAEAEA]">
                  <h2 className="text-xs font-bold text-[#111111] uppercase tracking-wide mb-2">
                    Description
                  </h2>
                  <p className={`text-xs sm:text-sm text-[#666666] leading-relaxed ${!isDescExpanded ? 'line-clamp-3' : ''}`}>
                    {product.description}
                  </p>
                  {product.description.length > 150 && (
                    <button
                      type="button"
                      onClick={() => setIsDescExpanded(!isDescExpanded)}
                      className="text-xs font-bold text-[#000000] hover:underline mt-1.5 cursor-pointer block"
                    >
                      {isDescExpanded ? 'Read Less ▲' : 'Read More ▼'}
                    </button>
                  )}
                </div>
              )}

              {/* Key specifications */}
              {hasSpecs && (
                <div className="pt-4 border-t border-[#EAEAEA]">
                  <h2 className="text-xs font-bold text-[#111111] uppercase tracking-wide mb-2.5">
                    Specifications
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-xs">
                    {product.countryOfOrigin && (
                      <div className="flex justify-between py-1 border-b border-[#EAEAEA]">
                        <span className="text-[#666666]">Country of Origin</span>
                        <span className="font-semibold text-[#111111]">{product.countryOfOrigin}</span>
                      </div>
                    )}
                    {product.netQuantity && (
                      <div className="flex justify-between py-1 border-b border-[#EAEAEA]">
                        <span className="text-[#666666]">Net Quantity</span>
                        <span className="font-semibold text-[#111111]">{product.netQuantity}</span>
                      </div>
                    )}
                    {product.gender && (
                      <div className="flex justify-between py-1 border-b border-[#EAEAEA]">
                        <span className="text-[#666666]">Gender</span>
                        <span className="font-semibold text-[#111111]">{product.gender}</span>
                      </div>
                    )}
                    {product.subcategory && (
                      <div className="flex justify-between py-1 border-b border-[#EAEAEA]">
                        <span className="text-[#666666]">Type</span>
                        <span className="font-semibold text-[#111111]">{product.subcategory}</span>
                      </div>
                    )}
                    {product.specifications &&
                      Object.entries(product.specifications).map(([key, val]) => (
                        <div key={key} className="flex justify-between py-1 border-b border-[#EAEAEA]">
                          <span className="text-[#666666]">{key}</span>
                          <span className="font-semibold text-[#111111]">{val}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      </main>

      {/* 3. FIXED BOTTOM PURCHASE BAR */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#EAEAEA] px-3 sm:px-6 py-2.5 shadow-[0_-4px_24px_rgba(0,0,0,0.06)]">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
          {/* Price Preview */}
          <div className="flex flex-col">
            <span className="text-lg sm:text-2xl font-black text-[#111111] leading-tight">
              ₹{product.price.toLocaleString()}
            </span>
            <span className="text-[10px] font-bold text-[#111111]">
              Cash on Delivery Available
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {isOutOfStock ? (
              <button
                type="button"
                disabled
                className="h-11 sm:h-12 px-6 rounded-xl bg-slate-200 text-slate-500 font-bold text-xs sm:text-sm cursor-not-allowed"
              >
                Out of Stock
              </button>
            ) : (
              <>
                {/* Add to Cart (Secondary Action: White background with black border & black text) */}
                <button
                  type="button"
                  onClick={handleAddToCartClick}
                  className={`h-11 sm:h-12 px-4 sm:px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                    addedNotice
                      ? 'bg-[#000000] text-white shadow-xs'
                      : 'bg-white text-[#111111] hover:bg-[#FFF9DB] border border-[#111111]'
                  }`}
                >
                  {addedNotice ? (
                    <>
                      <Check className="w-4 h-4 text-[#FFD400] animate-in zoom-in-75 duration-150" />
                      <span>Added</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4 text-[#111111]" />
                      <span>Add to Cart</span>
                    </>
                  )}
                </button>

                {/* Buy Now (Primary Action: Brand Yellow Background #FFD400 with black text) */}
                <button
                  type="button"
                  onClick={handleBuyNowClick}
                  className="h-11 sm:h-12 px-6 sm:px-8 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-[#FFD400]/30 transition-all cursor-pointer active:scale-95"
                >
                  <Zap className="w-4 h-4 fill-black text-black" />
                  <span>Buy Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 4. SIZE GUIDE MODAL */}
      {showSizeGuide && product.sizes && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-[#EAEAEA] space-y-4">
            <div className="flex items-center justify-between border-b border-[#EAEAEA] pb-3">
              <div className="flex items-center gap-2">
                <Ruler className="w-5 h-5 text-[#FFD400]" />
                <h3 className="text-base font-extrabold text-[#111111]">Standard Size Guide</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSizeGuide(false)}
                className="w-8 h-8 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#666666]">
              Standard Indian sizing reference. Choose the size you normally wear.
            </p>

            <div className="overflow-hidden rounded-xl border border-[#EAEAEA]">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FFF9DB] text-[#000000] font-black uppercase text-[10px]">
                  <tr>
                    <th className="p-2.5">Size</th>
                    <th className="p-2.5">Standard Fit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EAEAEA] text-[#111111] font-medium">
                  {product.sizes.map((sz) => (
                    <tr key={sz}>
                      <td className="p-2.5 font-bold text-[#000000]">{sz}</td>
                      <td className="p-2.5">Standard Sizing</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              type="button"
              onClick={() => setShowSizeGuide(false)}
              className="w-full py-2.5 bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs rounded-xl transition-colors cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductDetailsModal;
