import React, { useState, useMemo } from 'react';
import {
  Search,
  ShoppingCart,
  Star,
  Heart,
  X,
  ArrowLeft,
} from 'lucide-react';
import { Product } from '../../types';

interface CategoriesScreenProps {
  products: Product[];
  initialCategory?: string;
  cartCount?: number;
  onOpenCart?: () => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart?: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onBack?: () => void;
}

export interface CategoryGridItem {
  id: string;
  name: string;
  image: string;
  filterTag: string;
  subtitle?: string;
}

export const ALL_CATEGORIES_GRID: CategoryGridItem[] = [
  {
    id: 'fashion',
    name: 'Fashion',
    subtitle: 'Clothing & More',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Fashion',
  },
  {
    id: 'mobile',
    name: 'Mobile',
    subtitle: 'Phones & Accessories',
    image: 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Mobile',
  },
  {
    id: 'smart-gadgets',
    name: 'Smart Gadgets',
    subtitle: 'Wearables & Audio',
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Electronics',
  },
  {
    id: 'footwear',
    name: 'Footwear',
    subtitle: 'Shoes, Sandals & More',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Footwear',
  },
  {
    id: 'bags',
    name: 'Bags & Luggage',
    subtitle: 'Backpacks & Handbags',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Bags',
  },
  {
    id: 'electronics',
    name: 'Electronics',
    subtitle: 'Headphones & Audio',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Electronics',
  },
  {
    id: 'home',
    name: 'Home & Kitchen',
    subtitle: 'Decor & Essentials',
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Home',
  },
  {
    id: 'beauty',
    name: 'Beauty & Care',
    subtitle: 'Skin, Hair & Fragrance',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Beauty',
  },
  {
    id: 'sports',
    name: 'Sports & Fitness',
    subtitle: 'Gear & Workout',
    image: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=200&auto=format&fit=crop&q=80',
    filterTag: 'Sports',
  },
];

export const CategoriesScreen: React.FC<CategoriesScreenProps> = ({
  products,
  initialCategory,
  cartCount = 0,
  onOpenCart,
  onSelectProduct,
  wishlistIds,
  onToggleWishlist,
  onBack,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryGridItem | null>(() => {
    if (!initialCategory || initialCategory === 'All') return null;
    const match = ALL_CATEGORIES_GRID.find(
      (c) => c.name.toLowerCase() === initialCategory.toLowerCase() || c.filterTag.toLowerCase() === initialCategory.toLowerCase()
    );
    return match || null;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const handleCategoryClick = (category: CategoryGridItem) => {
    setSelectedCategory(category);
    setSearchQuery('');
  };

  const handleBackToGrid = () => {
    setSelectedCategory(null);
    setSearchQuery('');
  };

  const categoryProducts = useMemo(() => {
    if (!selectedCategory) return [];
    const tag = selectedCategory.filterTag.toLowerCase();
    const catName = selectedCategory.name.toLowerCase();

    let list = products.filter((p) => {
      const pCat = p.category?.toLowerCase() || '';
      const pSub = p.subcategory?.toLowerCase() || '';
      return (
        pCat.includes(tag) ||
        pCat.includes(catName) ||
        pSub.includes(tag) ||
        pSub.includes(catName)
      );
    });

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category?.toLowerCase().includes(q) ||
          p.subcategory?.toLowerCase().includes(q)
      );
    }

    if (list.length === 0) {
      list = products.slice(0, 6);
    }

    return list;
  }, [products, selectedCategory, searchQuery]);

  const filteredGridItems = useMemo(() => {
    if (!searchQuery.trim()) return ALL_CATEGORIES_GRID;
    const q = searchQuery.toLowerCase().trim();
    return ALL_CATEGORIES_GRID.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.subtitle?.toLowerCase().includes(q) ||
        c.filterTag.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  return (
    <div className="w-full min-h-screen bg-[#FAFAFA] pb-24 md:pb-12 text-[#111111]">
      {/* 1. CLEAN OMAZIFY HEADER */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#EAEAEA] text-[#111111] shadow-2xs">
        <div className="max-w-7xl mx-auto px-3.5 sm:px-6 h-[52px] sm:h-[56px] flex items-center justify-between gap-2">
          {/* Left: Back button + Title */}
          <div className="flex items-center gap-2 min-w-0">
            {selectedCategory ? (
              <button
                onClick={handleBackToGrid}
                className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer -ml-1"
                aria-label="Back to all categories"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
              </button>
            ) : onBack ? (
              <button
                onClick={onBack}
                className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer -ml-1"
                aria-label="Go back"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
              </button>
            ) : null}

            <h1 className="text-base sm:text-lg font-black text-[#111111] tracking-tight truncate">
              {selectedCategory ? selectedCategory.name : 'All Categories'}
            </h1>
          </div>

          {/* Right: Search icon & Shopping cart */}
          <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            <button
              onClick={() => setIsSearchOpen((prev) => !prev)}
              className="w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer"
              aria-label="Search"
            >
              <Search className="w-5 h-5 stroke-[2.2]" />
            </button>

            <button
              onClick={onOpenCart}
              className="relative w-9 h-9 rounded-full flex items-center justify-center text-[#111111] hover:bg-[#FAFAFA] active:scale-95 transition-all cursor-pointer"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="w-5 h-5 stroke-[2.2]" />
              {cartCount > 0 && (
                <span className="absolute top-0.5 right-0.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#000000] text-[#FFD400] text-[10px] font-black flex items-center justify-center ring-2 ring-white shadow-xs">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Collapsible search bar */}
        {isSearchOpen && (
          <div className="px-3.5 pb-2.5 pt-1 max-w-7xl mx-auto animate-in slide-in-from-top-1 duration-150">
            <div className="relative flex items-center w-full">
              <Search className="w-4 h-4 text-[#666666] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  selectedCategory
                    ? `Search within ${selectedCategory.name}...`
                    : 'Search in all categories...'
                }
                autoFocus
                className="w-full pl-9 pr-8 py-2 text-xs sm:text-sm bg-[#FAFAFA] text-[#111111] placeholder:text-[#666666] rounded-xl border border-[#EAEAEA] focus:border-[#000000] focus:outline-none focus:ring-2 focus:ring-[#FFD400]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#666666] hover:text-[#111111] p-0.5 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* 2. CATEGORY VIEW: 3-COLUMN GRID */}
      {!selectedCategory ? (
        <main className="max-w-7xl mx-auto px-2.5 sm:px-4 py-3 sm:py-4">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 sm:gap-3">
            {filteredGridItems.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategoryClick(cat)}
                className="group bg-white rounded-xl p-2 sm:p-3 border border-[#EAEAEA] hover:border-[#000000] shadow-2xs hover:shadow-xs active:scale-95 transition-all duration-150 flex flex-col items-center justify-between text-center cursor-pointer select-none"
                style={{ minHeight: '110px' }}
              >
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden bg-[#FAFAFA] flex items-center justify-center p-1 mb-1.5 transition-transform group-hover:scale-105 duration-200">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    draggable={false}
                    className="w-full h-full object-cover rounded-full pointer-events-none select-none"
                    loading="lazy"
                  />
                </div>

                <div className="w-full">
                  <span className="block text-[11.5px] sm:text-xs font-bold text-[#111111] group-hover:text-[#000000] leading-tight transition-colors line-clamp-2">
                    {cat.name}
                  </span>
                </div>
              </button>
            ))}
          </div>

          {filteredGridItems.length === 0 && (
            <div className="text-center py-16 bg-white rounded-2xl mt-4 border border-[#EAEAEA]">
              <p className="text-sm font-semibold text-[#666666]">No categories matching "{searchQuery}"</p>
              <button
                onClick={() => setSearchQuery('')}
                className="mt-3 text-xs font-black text-[#000000] hover:underline"
              >
                Clear Search
              </button>
            </div>
          )}
        </main>
      ) : (
        /* 3. PRODUCT LIST VIEW FOR SELECTED CATEGORY */
        <main className="max-w-7xl mx-auto px-2.5 sm:px-4 py-3">
          <div className="bg-white rounded-xl p-3 mb-3 border border-[#EAEAEA] shadow-2xs flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-[#666666] uppercase tracking-wider block">
                CATEGORY
              </span>
              <h2 className="text-base sm:text-lg font-black text-[#111111] leading-tight">
                {selectedCategory.name}
              </h2>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-[#666666]">
                {categoryProducts.length} items
              </span>
              <button
                onClick={handleBackToGrid}
                className="block text-[11px] font-black text-[#000000] hover:underline mt-0.5 cursor-pointer"
              >
                All Categories
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
            {categoryProducts.map((product) => {
              const isWishlisted = wishlistIds.has(product.id);
              const originalPrice = product.originalPrice || Math.round(product.price * 1.5);
              const discountPct =
                product.discount || Math.round(((originalPrice - product.price) / originalPrice) * 100);

              return (
                <div
                  key={product.id}
                  onClick={() => onSelectProduct(product)}
                  className="group relative bg-white rounded-xl sm:rounded-2xl p-2.5 sm:p-3 border border-[#EAEAEA] hover:border-[#000000] shadow-2xs hover:shadow-xs transition-colors duration-200 flex flex-col justify-between cursor-pointer select-none carousel-card-touch"
                  style={{
                    touchAction: 'pan-y pinch-zoom',
                  }}
                >
                  <div>
                    <div
                      className="relative w-full aspect-square rounded-lg overflow-hidden bg-[#FAFAFA] mb-2 border border-[#EAEAEA]/70"
                      style={{ touchAction: 'pan-y pinch-zoom' }}
                    >
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        draggable={false}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300 ease-out pointer-events-none select-none"
                        style={{
                          touchAction: 'pan-y pinch-zoom',
                        }}
                        loading="lazy"
                      />

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(product, e);
                        }}
                        className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-white/90 hover:bg-[#FFD400] flex items-center justify-center text-[#666666] hover:text-[#000000] shadow-xs transition-colors cursor-pointer"
                        aria-label="Wishlist"
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            isWishlisted ? 'fill-[#000000] text-[#000000]' : 'stroke-[1.8]'
                          }`}
                        />
                      </button>

                      {discountPct > 0 && (
                        <span className="absolute top-1.5 left-1.5 bg-[#FFD400] text-[#000000] text-[10px] font-black px-1.5 py-0.5 rounded shadow-2xs">
                          {discountPct}% OFF
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-[#000000] text-[#FFD400] text-[10px] font-black">
                        <span>{product.rating.toFixed(1)}</span>
                        <Star className="w-2.5 h-2.5 fill-current text-[#FFD400]" />
                      </span>
                      <span className="text-[10px] text-[#666666] font-medium">
                        ({product.reviewsCount})
                      </span>
                    </div>

                    <h3 className="text-xs sm:text-[13px] font-bold text-[#111111] line-clamp-2 leading-snug group-hover:text-[#000000] transition-colors">
                      {product.name}
                    </h3>
                  </div>

                  <div className="mt-2 pt-2 border-t border-[#EAEAEA]">
                    <div className="flex items-baseline gap-1.5 flex-wrap">
                      <span className="text-sm sm:text-base font-black text-[#111111] tracking-tight">
                        ₹{product.price.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-[#666666] line-through">
                        ₹{originalPrice.toLocaleString()}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-[10px] text-[#111111] font-bold bg-[#FFF9DB] px-1.5 py-0.5 rounded border border-[#FFD400]/40">
                        Cash on Delivery
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      )}
    </div>
  );
};

export default CategoriesScreen;
