import { ArrowUp, Home, Settings, ShoppingBag, UserRound } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { cartLines, couponOff, fmt, resolvedTheme, subtotal, t, totals } from "@/lib/shop/model";
import { useShop } from "@/lib/shop/store";
import { Account } from "./account";
import { Admin } from "./admin";
import { Home as ShopHome } from "./home";
import { Logo } from "./mark";
import { CartSheet, ProductSheet, WaSheet } from "./sheets";

function applyLook() {
  const s = useShop.getState();
  const root = document.documentElement;
  root.dataset.theme = resolvedTheme(s.mode);
  root.lang = s.lang === "bn" ? "bn" : "en";
  const ui = s.settings.ui;
  root.style.setProperty("--em", ui.c1);
  root.style.setProperty("--gold", ui.c2);
  root.style.setProperty("--radius", `${ui.rad}px`);
  root.style.setProperty("--gc", `${ui.cols}px`);
  root.style.setProperty("--sd", `${ui.dur}s`);
  if (s.settings.banner) root.style.setProperty("--banner", `url("${s.settings.banner}")`);
  else root.style.removeProperty("--banner");
}

export function ShopApp() {
  const [phase, setPhase] = useState<"splash" | "app">("splash");
  const skip = useRef(false);

  useEffect(() => {
    let timer = 0;
    let dead = false;
    void (async () => {
      try {
        await useShop.persist.rehydrate();
      } catch {
        /* keep the seeded shop */
      }
      if (dead || skip.current) return;
      applyLook();
      if (location.hash === "#admin") useShop.getState().unlock();
      const ui = useShop.getState().settings.ui;
      if (!ui.splash) {
        setPhase("app");
        return;
      }
      timer = window.setTimeout(() => setPhase("app"), Math.max(0.6, ui.dur) * 1000);
    })();
    const onHash = () => {
      if (location.hash === "#admin") useShop.getState().unlock();
    };
    window.addEventListener("hashchange", onHash);
    return () => {
      dead = true;
      window.clearTimeout(timer);
      window.removeEventListener("hashchange", onHash);
    };
  }, []);

  useEffect(() => {
    if (phase !== "app") return;
    applyLook();
    const unsub = useShop.subscribe(() => applyLook());
    const clock = window.setInterval(applyLook, 60_000);
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      const s = useShop.getState();
      if (s.wa) s.dismissWa();
      else if (s.productId) s.closeProduct();
      else if (s.drawer) s.closeCart();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      unsub();
      window.clearInterval(clock);
      window.removeEventListener("keydown", onKey);
    };
  }, [phase]);

  const drawer = useShop((s) => s.drawer);
  const productId = useShop((s) => s.productId);
  const wa = useShop((s) => s.wa);
  useEffect(() => {
    document.body.classList.toggle("lock", Boolean(drawer || productId || wa));
  }, [drawer, productId, wa]);

  if (phase === "splash") {
    return <Splash onSkip={() => { skip.current = true; setPhase("app"); }} />;
  }

  return (
    <>
      <ScrollProgress />
      <Topbar />
      <main className="page">
        <View />
      </main>
      <CartBar />
      <Dock />
      {drawer ? <CartSheet /> : null}
      {productId ? <ProductSheet /> : null}
      {wa ? <WaSheet /> : null}
      <BackTop />
      <Toaster />
    </>
  );
}

function View() {
  const view = useShop((s) => s.view);
  if (view === "acct") return <Account />;
  if (view === "admin") return <Admin />;
  return <ShopHome />;
}

function Splash({ onSkip }: { onSkip: () => void }) {
  const brand = useShop((s) => s.settings.brand);
  const tag = useShop((s) => s.settings.tag);
  const logo = useShop((s) => s.settings.logo);
  return (
    <button type="button" className="splash" onClick={onSkip}>
      <div className="ring">
        <div className="mark" style={{ width: "100%", height: "100%" }}>
          <Logo src={logo} />
        </div>
      </div>
      <h1>{brand}</h1>
      <p className="tag">{tag || "Shop Smart · Live Better"}</p>
      <div className="pb">
        <i />
      </div>
      <div className="credit">
        Created by <b style={{ color: "#f0d58a" }}>Saikoth Rahman</b>
      </div>
    </button>
  );
}

function Topbar() {
  const lang = useShop((s) => s.lang);
  const mode = useShop((s) => s.mode);
  const brand = useShop((s) => s.settings.brand);
  const logo = useShop((s) => s.settings.logo);
  const toggleLang = useShop((s) => s.toggleLang);
  const setMode = useShop((s) => s.setMode);
  const setView = useShop((s) => s.setView);
  const unlock = useShop((s) => s.unlock);
  const taps = useRef(0);
  const timer = useRef(0);
  const [clock, setClock] = useState("");

  useEffect(() => {
    const tick = () => {
      setClock(
        new Date().toLocaleString(lang === "bn" ? "bn-BD" : "en-GB", {
          timeZone: "Asia/Dhaka",
          dateStyle: "medium",
          timeStyle: "short",
        }),
      );
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [lang]);

  const parts = brand.split(" ");
  const head = parts.slice(0, 2).join(" ");
  const tail = parts.slice(2).join(" ");

  return (
    <header className="topbar">
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="flex min-w-0 flex-1 items-center gap-2 text-left"
          onClick={() => {
            taps.current += 1;
            window.clearTimeout(timer.current);
            timer.current = window.setTimeout(() => {
              taps.current = 0;
            }, 1800);
            if (taps.current >= 5) {
              taps.current = 0;
              unlock();
              setView("admin");
            } else setView("shop");
          }}
        >
          <span className="mark" style={{ width: 36, height: 36 }}>
            <Logo src={logo} />
          </span>
          <span className="truncate text-lg font-extrabold tracking-tight text-em">
            {head} {tail ? <span className="text-gold">{tail}</span> : null}
          </span>
        </button>
        <button type="button" className="btn" onClick={toggleLang}>
          {t(lang, "langBtn")}
        </button>
        <select
          className="inp"
          style={{ width: "auto" }}
          aria-label={t(lang, "theme")}
          value={mode}
          onChange={(e) => setMode(e.target.value as typeof mode)}
        >
          <option value="auto">auto</option>
          <option value="light">light</option>
          <option value="dark">dark</option>
        </select>
      </div>
      <p className="mt-1 text-xs text-mut">{clock} · Asia/Dhaka</p>
    </header>
  );
}

function Dock() {
  const lang = useShop((s) => s.lang);
  const view = useShop((s) => s.view);
  const cart = useShop((s) => s.cart);
  const unlocked = useShop((s) => s.unlocked);
  const setView = useShop((s) => s.setView);
  const openCart = useShop((s) => s.openCart);
  const n = Object.values(cart).reduce((a, b) => a + (Number(b) || 0), 0);

  return (
    <nav className="dock" aria-label="Primary">
      <button type="button" className={view === "shop" ? "on" : ""} onClick={() => setView("shop")}>
        <Home size={18} aria-hidden />
        {t(lang, "shop")}
      </button>
      <button type="button" onClick={openCart}>
        <ShoppingBag size={18} aria-hidden />
        {t(lang, "cart")}
        {n > 0 ? <span className="badge">{n}</span> : null}
      </button>
      <button type="button" className={view === "acct" ? "on" : ""} onClick={() => setView("acct")}>
        <UserRound size={18} aria-hidden />
        {t(lang, "acct")}
      </button>
      {unlocked ? (
        <button type="button" className={view === "admin" ? "on" : ""} onClick={() => setView("admin")}>
          <Settings size={18} aria-hidden />
          {t(lang, "admin")}
        </button>
      ) : null}
    </nav>
  );
}

function CartBar() {
  const lang = useShop((s) => s.lang);
  const view = useShop((s) => s.view);
  const drawer = useShop((s) => s.drawer);
  const productId = useShop((s) => s.productId);
  const cart = useShop((s) => s.cart);
  const products = useShop((s) => s.products);
  const settings = useShop((s) => s.settings);
  const coupon = useShop((s) => s.coupon);
  const coupons = useShop((s) => s.coupons);
  const openCart = useShop((s) => s.openCart);
  if (view !== "shop" || drawer || productId) return null;
  const lines = cartLines(products, cart);
  const n = lines.reduce((a, l) => a + l.q, 0);
  if (!n) return null;
  const sub = subtotal(lines);
  const found = coupon ? coupons.find((c) => c.code === coupon) : undefined;
  const tt = totals(sub, settings.fee, settings.free, false, couponOff(found, sub));
  const word = n > 1 ? t(lang, "items") : t(lang, "item");
  return (
    <button type="button" className="cartbar" onClick={openCart}>
      <span className="flex items-center gap-2 font-semibold">
        <ShoppingBag size={18} aria-hidden />
        <span className="flex-1 text-left">
          {n} {word}
        </span>
        <b>{fmt(tt.tot, lang)}</b>
        <span className="rounded-full px-2 py-1 text-xs" style={{ background: "#ffffff26" }}>
          {t(lang, "viewCart")}
        </span>
      </span>
      {settings.free > 0 ? (
        <span className="meter">
          <small>
            {sub >= settings.free
              ? t(lang, "freeYes")
              : `${t(lang, "addWord")} ${fmt(settings.free - sub, lang)} ${t(lang, "moreFree")}`}
          </small>
          <i>
            <b style={{ width: `${Math.max(0, Math.min(100, (sub / settings.free) * 100))}%` }} />
          </i>
        </span>
      ) : null}
    </button>
  );
}

function BackTop() {
  const lang = useShop((s) => s.lang);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const tick = () => setOn(window.scrollY > 480);
    tick();
    window.addEventListener("scroll", tick, { passive: true });
    return () => window.removeEventListener("scroll", tick);
  }, []);
  if (!on) return null;
  return (
    <button type="button" className="btt" aria-label={t(lang, "backTop")} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
      <ArrowUp size={18} />
    </button>
  );
}

function ScrollProgress() {
  const bar = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const tick = () => {
      const h = document.documentElement;
      const p = Math.min(1, window.scrollY / Math.max(1, h.scrollHeight - window.innerHeight));
      if (bar.current) bar.current.style.transform = `scaleX(${p})`;
    };
    tick();
    window.addEventListener("scroll", tick, { passive: true });
    return () => window.removeEventListener("scroll", tick);
  }, []);
  return <div ref={bar} className="scp" style={{ transform: "scaleX(0)" }} />;
}

function Toaster() {
  const toast = useShop((s) => s.toast);
  const clear = useShop((s) => s.clearToast);
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(clear, 2400);
    return () => window.clearTimeout(id);
  }, [toast, clear]);
  if (!toast) return null;
  return (
    <div className="toast" role="status">
      {toast.text}
    </div>
  );
}
