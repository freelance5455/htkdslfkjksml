import { useState } from "react";
import { fmt, statusLabel, t, STATUSES, type Order, type OrderStatus } from "@/lib/shop/model";
import { useShop } from "@/lib/shop/store";

function Track({ order }: { order: Order }) {
  const lang = useShop((s) => s.lang);
  if (order.status === "cancelled") return <p className="text-sm text-danger">{statusLabel("cancelled", lang)}</p>;
  const flow = STATUSES.filter((s) => s !== "cancelled");
  const at = flow.indexOf(order.status);
  return (
    <div className="trk" aria-hidden>
      {flow.map((s, i) => (
        <i key={s} className={i <= at ? "on" : ""} title={statusLabel(s as OrderStatus, lang)} />
      ))}
    </div>
  );
}

export function Account() {
  const lang = useShop((s) => s.lang);
  const me = useShop((s) => s.me);
  const customers = useShop((s) => s.customers);
  const orders = useShop((s) => s.orders);
  const guestLogin = useShop((s) => s.guestLogin);
  const logout = useShop((s) => s.logout);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const customer = me ? customers[me.phone] : undefined;
  if (!me || !customer) {
    return (
      <div className="px-3 pt-4">
        <h2 className="text-xl font-extrabold">{t(lang, "acct")}</h2>
        <form
          className="box mt-3"
          onSubmit={(e) => {
            e.preventDefault();
            guestLogin(name, phone);
          }}
        >
          <p className="mb-3 text-sm text-mut">{t(lang, "guest")}</p>
          <label className="field">
            <span>{t(lang, "name")}</span>
            <input className="inp" value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="field">
            <span>{t(lang, "phone")}</span>
            <input className="inp" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </label>
          <button type="submit" className="btn btn-pri btn-block">
            {t(lang, "guestlogin")}
          </button>
        </form>
      </div>
    );
  }

  const mine = orders.filter((o) => o.phone === customer.phone);

  return (
    <div className="px-3 pt-4">
      <h2 className="text-xl font-extrabold">
        {customer.name} · {customer.phone}
      </h2>
      <div className="box mt-3">
        <div className="text-lg font-extrabold text-em">
          {t(lang, "coins")}: {customer.coins}
        </div>
        <p className="text-sm text-mut">{t(lang, "coinHint")}</p>
        <p className="mt-1 text-sm text-mut">{t(lang, "guest")}</p>
      </div>
      <h3 className="mt-2 font-extrabold">{t(lang, "orders")}</h3>
      {mine.length ? (
        mine.map((o) => (
          <article key={o.id} className="box">
            <b>{o.id}</b> · {statusLabel(o.status, lang)}
            <Track order={o} />
            <div>
              {fmt(o.total, lang)} · {new Date(o.t).toLocaleString(lang === "bn" ? "bn-BD" : "en-GB")}
            </div>
            <p className="text-sm text-mut">{o.paid ? t(lang, "paid") : t(lang, "unpaidWord")}</p>
          </article>
        ))
      ) : (
        <p className="text-mut">{t(lang, "empty")}</p>
      )}
      <button type="button" className="btn mt-2" onClick={logout}>
        {t(lang, "logout")}
      </button>
    </div>
  );
}
