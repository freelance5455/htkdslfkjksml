import React from "react";
import { Item } from "../types";

interface HotbarProps {
  hotbar: Item[];
  activeSlot: number;
  isCompact?: boolean;
  onSelectSlot: (slot: number) => void;
}

export const Hotbar: React.FC<HotbarProps> = ({
  hotbar,
  activeSlot,
  isCompact = false,
  onSelectSlot,
}) => {
  const currentItem = hotbar[activeSlot];
  const isHand = currentItem?.id === "hand_empty";

  return (
    <div
      className={`absolute bottom-1.5 left-1/2 -translate-x-1/2 pointer-events-auto z-20 flex flex-col items-center gap-0.5 select-none transition-all duration-200 ${
        isCompact ? "scale-90 origin-bottom" : "scale-100"
      }`}
    >
      {/* Selected tool name banner */}
      {currentItem && (
        <div
          className={`backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-semibold border shadow-md flex items-center gap-1.5 transition ${
            isHand
              ? "bg-amber-950/90 text-amber-200 border-amber-500/80 shadow-amber-900/30"
              : "bg-stone-900/90 text-stone-200 border-stone-700/80"
          }`}
        >
          <span className="font-['Hind_Siliguri'] font-bold text-amber-300">
            {currentItem.bengaliName}
          </span>
          {isHand && (
            <span className="bg-emerald-600/80 text-emerald-100 text-[8px] px-1 rounded font-bold animate-pulse">
              শান্ত ভাব (Peace)
            </span>
          )}
          {currentItem.tier && currentItem.tier > 1 && (
            <span className="bg-amber-600/60 text-amber-200 text-[8px] px-1 rounded font-bold">
              T{currentItem.tier}
            </span>
          )}
        </div>
      )}

      {/* Hotbar Slots Container */}
      <div
        className={`flex items-center gap-1 bg-stone-950/90 backdrop-blur-md rounded-xl border border-stone-800 shadow-2xl transition ${
          isCompact ? "p-0.5 gap-0.5" : "p-1"
        }`}
      >
        {hotbar.map((item, idx) => {
          const isSelected = activeSlot === idx;
          const isThisHand = item?.id === "hand_empty";

          const slotSize = isCompact
            ? "w-8 h-8 sm:w-10 sm:h-10"
            : "w-10 h-10 sm:w-12 sm:h-12";

          return (
            <button
              key={item?.id || idx}
              onClick={() => onSelectSlot(idx)}
              className={`relative ${slotSize} rounded-lg flex flex-col items-center justify-center transition cursor-pointer select-none ${
                isSelected
                  ? isThisHand
                    ? "bg-amber-600/40 border-2 border-yellow-300 shadow-lg shadow-yellow-500/30 scale-105"
                    : "bg-amber-600/35 border-2 border-amber-400 shadow-lg shadow-amber-500/25 scale-105"
                  : isThisHand
                  ? "bg-amber-950/30 border border-amber-700/50 hover:bg-amber-900/40"
                  : "bg-stone-900/80 border border-stone-700/60 hover:bg-stone-800/80"
              }`}
              title={`${item?.bengaliName || "Slot"} [${idx + 1}]`}
            >
              {/* Slot Number hint */}
              <span className="absolute top-0.5 left-1 text-[8px] font-mono text-stone-400 font-bold leading-none">
                {idx + 1}
              </span>

              {/* Item Icon */}
              {item ? (
                <>
                  <span
                    className={`filter drop-shadow transition ${
                      isCompact ? "text-base sm:text-lg" : "text-lg sm:text-2xl"
                    }`}
                  >
                    {item.icon}
                  </span>

                  {/* Quantity badge */}
                  {item.count > 1 && (
                    <span className="absolute bottom-0.5 right-0.5 text-[8px] font-mono font-bold bg-stone-950/95 text-emerald-300 px-0.5 rounded border border-stone-700 leading-none">
                      x{item.count}
                    </span>
                  )}

                  {/* Tier star badge */}
                  {item.tier && item.tier > 1 && (
                    <span className="absolute top-0.5 right-0.5 text-[8px] text-amber-400 leading-none">
                      {"★".repeat(item.tier)}
                    </span>
                  )}
                </>
              ) : (
                <span className="text-stone-700 text-[9px]">খালি</span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
