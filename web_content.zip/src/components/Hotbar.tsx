import { HOTBAR, DEFS } from '../game/blocks';
import { cn } from '../utils/cn';

interface Props {
  icons: Record<number, string>;
  slot: number;
  onSelect: (i: number) => void;
}

export function Hotbar({ icons, slot, onSelect }: Props) {
  return (
    <div className="flex touch-none select-none gap-[3px] rounded-md border-2 border-black/60 bg-black/45 p-[3px] backdrop-blur-[2px]">
      {HOTBAR.map((id, i) => (
        <button
          key={id}
          type="button"
          aria-label={DEFS[id].name}
          onPointerDown={(e) => {
            e.preventDefault();
            onSelect(i);
          }}
          className={cn(
            'relative flex h-[min(8.2vw,42px)] w-[min(8.2vw,42px)] items-center justify-center rounded-[3px] border-2 bg-neutral-700/60',
            i === slot ? 'z-10 scale-110 border-white bg-neutral-500/70' : 'border-neutral-900/70',
          )}
        >
          {icons[id] && (
            <img
              src={icons[id]}
              alt=""
              draggable={false}
              className="h-full w-full object-contain"
              style={{ imageRendering: 'pixelated' }}
            />
          )}
          <span className="absolute left-[2px] top-[-1px] text-[9px] font-bold leading-none text-white/80 [text-shadow:1px_1px_0_#000]">
            {(i + 1) % 10}
          </span>
        </button>
      ))}
    </div>
  );
}
