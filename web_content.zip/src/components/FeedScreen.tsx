import React, { useState, useRef, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Volume2,
  VolumeX,
  Play,
  Search,
  Music,
  Plus,
  Check,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';
import { Post } from '../types';
import { toggleLikePost, toggleSavePost, toggleFollowUser, getUserProfile } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { CommentsDrawer } from './CommentsDrawer';

interface FeedScreenProps {
  posts: Post[];
  onExploreClick: () => void;
  onProfileClick: (username: string) => void;
  onOpenCreate?: () => void;
  onPostUpdated?: (updated: Post) => void;
}

export const FeedScreen: React.FC<FeedScreenProps> = ({
  posts,
  onExploreClick,
  onProfileClick,
  onOpenCreate,
  onPostUpdated,
}) => {
  const { userProfile } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [feedMode, setFeedMode] = useState<'foryou' | 'following'>('foryou');
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeCommentsPost, setActiveCommentsPost] = useState<Post | null>(null);
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [savedPosts, setSavedPosts] = useState<Record<string, boolean>>({});
  const [followedUsers, setFollowedUsers] = useState<Record<string, boolean>>({});
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({});
  const [saveCounts, setSaveCounts] = useState<Record<string, number>>({});
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const currentPost = posts[currentIndex] || posts[0];

  useEffect(() => {
    if (currentPost) {
      if (likedPosts[currentPost.id] === undefined && currentPost.likedByMe !== undefined) {
        setLikedPosts((p) => ({ ...p, [currentPost.id]: !!currentPost.likedByMe }));
      }
      if (likeCounts[currentPost.id] === undefined) {
        setLikeCounts((p) => ({ ...p, [currentPost.id]: currentPost.likesCount }));
      }
      if (saveCounts[currentPost.id] === undefined) {
        setSaveCounts((p) => ({ ...p, [currentPost.id]: currentPost.savesCount }));
      }
    }
  }, [currentPost, likedPosts, likeCounts, saveCounts]);

  // Handle play/pause when index changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  }, [currentIndex]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleNextPost = () => {
    if (currentIndex < posts.length - 1) {
      setCurrentIndex((i) => i + 1);
    }
  };

  const handlePrevPost = () => {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.key === 'j') handleNextPost();
      if (e.key === 'ArrowUp' || e.key === 'k') handlePrevPost();
      if (e.key === ' ') {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, posts.length]);

  const handleLike = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!currentPost) return;
    const isLiked = likedPosts[currentPost.id] || false;
    const newStatus = !isLiked;

    // Optimistic UI update
    setLikedPosts((p) => ({ ...p, [currentPost.id]: newStatus }));
    setLikeCounts((p) => ({
      ...p,
      [currentPost.id]: (p[currentPost.id] || currentPost.likesCount) + (newStatus ? 1 : -1),
    }));

    if (newStatus) {
      setShowHeartBurst(true);
      setTimeout(() => setShowHeartBurst(false), 900);
    }

    try {
      const uid = userProfile?.id || 'demo-user';
      await toggleLikePost(currentPost.id, uid, isLiked);
    } catch {
      // rollback if failed
    }
  };

  const handleSave = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentPost) return;
    const isSaved = savedPosts[currentPost.id] || false;
    const newStatus = !isSaved;

    setSavedPosts((p) => ({ ...p, [currentPost.id]: newStatus }));
    setSaveCounts((p) => ({
      ...p,
      [currentPost.id]: (p[currentPost.id] || currentPost.savesCount) + (newStatus ? 1 : -1),
    }));

    try {
      const uid = userProfile?.id || 'demo-user';
      await toggleSavePost(currentPost.id, uid, isSaved);
    } catch {
      // ignore
    }
  };

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentPost || !userProfile) return;
    const isFollowed = followedUsers[currentPost.userId] || false;
    const newStatus = !isFollowed;

    setFollowedUsers((p) => ({ ...p, [currentPost.userId]: newStatus }));

    try {
      await toggleFollowUser(userProfile.id, userProfile, currentPost.userId, isFollowed);
    } catch {
      // ignore
    }
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({
          title: `ClipShare - @${currentPost.username}`,
          text: currentPost.caption,
          url: window.location.href,
        });
      } catch {
        // Fallback to clipboard
        await navigator.clipboard.writeText(window.location.href);
        setShareSuccess(true);
        setTimeout(() => setShareSuccess(false), 2000);
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2000);
    }
  };

  const formatCount = (count?: number) => {
    if (!count) return '0';
    if (count >= 1000000) return (count / 1000000).toFixed(1).replace('.', ',') + 'M';
    if (count >= 1000) return (count / 1000).toFixed(1).replace('.', ',') + 'K';
    return count.toString();
  };

  if (!currentPost) {
    return (
      <div className="relative w-full h-[calc(100vh-64px)] md:h-[calc(100vh-20px)] max-w-md mx-auto md:max-w-md lg:max-w-lg flex flex-col justify-center items-center text-center px-6 bg-[#050505] md:rounded-3xl border border-[#19191F] select-none">
        <div className="w-20 h-20 rounded-full bg-[#101014] border border-[#272730] flex items-center justify-center mb-4 shadow-xl">
          <img src="/clipshare-bubble.svg" alt="ClipShare" className="w-10 h-10 invert opacity-80" />
        </div>
        <h2 className="text-xl font-extrabold text-white">Nenhum clipe publicado ainda</h2>
        <p className="text-xs text-[#A1A1AA] mt-2 max-w-xs leading-relaxed">
          O feed está limpo! Seja o pioneiro e publique seu primeiro clipe real em vídeo ou foto no ClipShare.
        </p>
        <button
          onClick={onOpenCreate}
          className="mt-6 py-3.5 px-8 rounded-full bg-clipshare-gradient glow-clipshare text-white font-bold text-sm shadow-xl active:scale-95 transition-all cursor-pointer"
        >
          Publicar primeiro clipe
        </button>
      </div>
    );
  }

  const isCurrentLiked = likedPosts[currentPost.id] || false;
  const isCurrentSaved = savedPosts[currentPost.id] || false;
  const isCurrentFollowed = followedUsers[currentPost.userId] || currentPost.followedByMe || false;
  const currentLikes = likeCounts[currentPost.id] ?? currentPost.likesCount;
  const currentSaves = saveCounts[currentPost.id] ?? currentPost.savesCount;

  return (
    <div className="relative w-full h-[calc(100vh-64px)] md:h-[calc(100vh-20px)] max-w-md mx-auto md:max-w-md lg:max-w-lg flex flex-col justify-between overflow-hidden bg-black md:rounded-3xl shadow-2xl border border-[#19191F]">
      {/* Top Bar matching reference image Screen 2:
          For You | Seguindo + Search icon on right */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-6 py-4 bg-gradient-to-b from-black/80 via-black/30 to-transparent">
        <div className="flex items-center gap-5 text-base font-bold">
          {/* For You */}
          <button
            onClick={() => setFeedMode('foryou')}
            className="relative py-1 cursor-pointer transition-colors"
          >
            <span className={feedMode === 'foryou' ? 'text-white' : 'text-[#A1A1AA] hover:text-white'}>
              For You
            </span>
            {feedMode === 'foryou' && (
              <span className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#FF008C] rounded-full shadow-[0_0_8px_#FF008C]" />
            )}
          </button>

          {/* Seguindo */}
          <button
            onClick={() => setFeedMode('following')}
            className="relative py-1 cursor-pointer transition-colors"
          >
            <span className={feedMode === 'following' ? 'text-white' : 'text-[#A1A1AA] hover:text-white'}>
              Seguindo
            </span>
            {feedMode === 'following' && (
              <span className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#FF008C] rounded-full shadow-[0_0_8px_#FF008C]" />
            )}
          </button>
        </div>

        {/* Top Right: Search & Sound toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMuted((m) => !m)}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md text-white/90 hover:text-white"
            title={isMuted ? 'Ativar som' : 'Desativar som'}
          >
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
          <button
            onClick={onExploreClick}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md text-white/90 hover:text-white cursor-pointer"
            title="Explorar"
          >
            <Search size={20} />
          </button>
        </div>
      </div>

      {/* Main Video Viewport */}
      <div
        className="relative w-full h-full flex items-center justify-center cursor-pointer select-none bg-[#050505]"
        onClick={togglePlay}
        onDoubleClick={handleLike}
      >
        {currentPost.mediaType === 'video' ? (
          <video
            ref={videoRef}
            src={currentPost.mediaUrl}
            poster={currentPost.coverUrl}
            autoPlay
            loop
            muted={isMuted}
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <img
            src={currentPost.mediaUrl}
            alt={currentPost.caption}
            className="w-full h-full object-cover"
          />
        )}

        {/* Play/Pause icon badge on pause */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/25 pointer-events-none">
            <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white/90">
              <Play size={32} className="ml-1 fill-white" />
            </div>
          </div>
        )}

        {/* Double-tap heart burst animation */}
        {showHeartBurst && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-ping">
            <Heart size={90} className="fill-[#FF008C] text-[#FF008C] drop-shadow-[0_0_20px_#FF008C]" />
          </div>
        )}

        {/* Desktop Up/Down navigation buttons */}
        <div className="hidden md:flex flex-col gap-2 absolute right-[-54px] top-1/2 -translate-y-1/2 z-30">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePrevPost();
            }}
            disabled={currentIndex === 0}
            className="w-10 h-10 rounded-full bg-[#19191F] border border-[#272730] flex items-center justify-center text-white hover:bg-[#FF008C] disabled:opacity-30 transition-all cursor-pointer"
          >
            <ChevronUp size={20} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleNextPost();
            }}
            disabled={currentIndex === posts.length - 1}
            className="w-10 h-10 rounded-full bg-[#19191F] border border-[#272730] flex items-center justify-center text-white hover:bg-[#FF008C] disabled:opacity-30 transition-all cursor-pointer"
          >
            <ChevronDown size={20} />
          </button>
        </div>
      </div>

      {/* Right Action Bar matching reference image:
          ❤️ Curtir
          💬 Comentar
          ↗️ Compartilhar
          🔖 Salvar
          ➕ Seguir / Music disc */}
      <div className="absolute right-3 bottom-20 z-20 flex flex-col items-center space-y-4">
        {/* Creator profile avatar with follow badge */}
        <div className="relative mb-2">
          <div
            onClick={(e) => {
              e.stopPropagation();
              onProfileClick(currentPost.username);
            }}
            className="w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-[#FF4038] via-[#FF008C] to-[#9900FF] cursor-pointer"
          >
            <img
              src={currentPost.userPhotoURL}
              alt={currentPost.username}
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          {!isCurrentFollowed && (
            <button
              onClick={handleFollow}
              className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-clipshare-gradient flex items-center justify-center text-white border-2 border-black cursor-pointer shadow-md"
            >
              <Plus size={12} strokeWidth={3} />
            </button>
          )}
        </div>

        {/* Like Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={handleLike}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md active:scale-125 transition-transform cursor-pointer"
          >
            <Heart
              size={28}
              className={
                isCurrentLiked
                  ? 'fill-[#FF3B30] text-[#FF3B30] filter drop-shadow-[0_0_8px_#FF3B30]'
                  : 'text-white'
              }
            />
          </button>
          <span className="text-xs font-semibold text-white drop-shadow mt-1">
            {formatCount(currentLikes)}
          </span>
        </div>

        {/* Comment Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setActiveCommentsPost(currentPost);
            }}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md active:scale-110 transition-transform cursor-pointer"
          >
            <MessageCircle size={28} className="text-white" />
          </button>
          <span className="text-xs font-semibold text-white drop-shadow mt-1">
            {formatCount(currentPost.commentsCount)}
          </span>
        </div>

        {/* Share Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={handleShare}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md active:scale-110 transition-transform cursor-pointer"
          >
            <Share2 size={26} className="text-white" />
          </button>
          <span className="text-xs font-semibold text-white drop-shadow mt-1">
            {formatCount(currentPost.sharesCount)}
          </span>
        </div>

        {/* Save / Bookmark Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={handleSave}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md active:scale-110 transition-transform cursor-pointer"
          >
            <Bookmark
              size={26}
              className={isCurrentSaved ? 'fill-[#FF008C] text-[#FF008C]' : 'text-white'}
            />
          </button>
          <span className="text-xs font-semibold text-white drop-shadow mt-1">
            {formatCount(currentSaves)}
          </span>
        </div>

        {/* Spinning Vinyl Music Disc */}
        <div className="relative pt-1 cursor-pointer" onClick={(e) => e.stopPropagation()}>
          <div className="w-10 h-10 rounded-full bg-[#101014] border-2 border-white/30 flex items-center justify-center animate-[spin_4s_linear_infinite] shadow-lg">
            <div className="w-4 h-4 rounded-full bg-gradient-to-tr from-[#FF4038] to-[#9900FF]" />
          </div>
          <span className="absolute -top-1 -left-1 text-[11px] animate-bounce">🎵</span>
        </div>
      </div>

      {/* Bottom Overlay matching reference image Screen 2:
          - @anaclaras · 2h atrás
          - Vibez da noite ✨🔥
          - #dance #vibes #clipshare
          - Music marquee */}
      <div className="absolute bottom-3 left-0 right-16 z-20 px-5 text-left pointer-events-auto">
        <div
          onClick={() => onProfileClick(currentPost.username)}
          className="inline-flex items-center gap-1.5 cursor-pointer group"
        >
          <span className="text-sm font-bold text-white group-hover:text-[#FF008C] transition-colors">
            @{currentPost.username}
          </span>
          <span className="text-xs text-[#A1A1AA]">· 2h atrás</span>
        </div>

        <p className="text-xs md:text-sm text-white/95 mt-1 font-medium leading-relaxed drop-shadow-md">
          {currentPost.caption}
        </p>

        {currentPost.hashtags && currentPost.hashtags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-1.5">
            {currentPost.hashtags.map((tag) => (
              <span
                key={tag}
                onClick={onExploreClick}
                className="text-xs font-semibold text-[#FF008C] hover:underline cursor-pointer"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Music Marquee */}
        <div className="flex items-center gap-2 mt-2 text-xs text-white/80 max-w-[240px] truncate">
          <Music size={13} className="shrink-0 text-[#FF008C]" />
          <span className="truncate">{currentPost.musicTitle || 'Áudio original - ClipShare'}</span>
        </div>
      </div>

      {/* Share Toast */}
      {shareSuccess && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#101014] border border-[#272730] text-xs font-semibold text-white shadow-xl flex items-center gap-2">
          <Check size={14} className="text-[#20E060]" />
          <span>Link copiado para a área de transferência!</span>
        </div>
      )}

      {/* Comments Drawer Modal */}
      {activeCommentsPost && (
        <CommentsDrawer
          post={activeCommentsPost}
          isOpen={true}
          onClose={() => setActiveCommentsPost(null)}
        />
      )}
    </div>
  );
};
