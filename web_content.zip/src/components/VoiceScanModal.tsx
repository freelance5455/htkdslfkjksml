import React, { useState } from 'react';
import { X, Mic, MicOff, Sparkles, Check, RefreshCw } from 'lucide-react';
import { MealItem, TierLevel } from '../types';
import { analyzeFoodImageOrVoice, AnalysisResult } from '../utils/aiVision';
import confetti from 'canvas-confetti';

interface VoiceScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMeal: (meal: MealItem) => void;
  currentTier: TierLevel;
  scansUsedToday: number;
  dailyScanLimit: number;
  onOpenPaywall: () => void;
}

export const VoiceScanModal: React.FC<VoiceScanModalProps> = ({
  isOpen,
  onClose,
  onAddMeal,
  currentTier,
  scansUsedToday,
  dailyScanLimit,
  onOpenPaywall,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scanResult, setScanResult] = useState<AnalysisResult | null>(null);

  const isLimitReached = currentTier < 3 && scansUsedToday >= dailyScanLimit;

  if (!isOpen) return null;

  const sampleVoicePrompts = [
    'أكلت طبق شوفان بالبروتين مع حليب لوز وتوت طازج وعسل',
    'صدر دجاج مشوي متبل مع صحن أرز بسمتي وسلطة خضراء',
    'قطعة ستيك لحم بقري 200غ مع بطاطس حلوة وهليون مشوي',
    'علبة تونة مصفاة مع بيضة مسلوقة وسلطة خضار وزيت زيتون',
  ];

  const handleStartSimulatedListening = () => {
    setIsRecording(true);
    setTranscript('');
    setScanResult(null);

    // Pick random or cycle
    const randomSample = sampleVoicePrompts[Math.floor(Math.random() * sampleVoicePrompts.length)];
    let currentIdx = 0;

    const interval = setInterval(() => {
      currentIdx += 4;
      if (currentIdx >= randomSample.length) {
        clearInterval(interval);
        setTranscript(randomSample);
        setIsRecording(false);
        runVoiceAnalysis(randomSample);
      } else {
        setTranscript(randomSample.slice(0, currentIdx));
      }
    }, 120);
  };

  const runVoiceAnalysis = async (text: string) => {
    setIsAnalyzing(true);
    try {
      const res = await analyzeFoodImageOrVoice({ textDescription: text });
      setScanResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleConfirm = () => {
    if (!scanResult) return;
    const newMeal: MealItem = {
      id: `meal-${Date.now()}`,
      name: scanResult.mealName,
      nameEn: scanResult.mealNameEn,
      category: scanResult.category,
      imageUrl: '/src/assets/images/meal_mediterranean_bowl_1791967840332.jpg',
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      weightGrams: scanResult.weightGrams,
      macros: scanResult.macros,
      healthScore: scanResult.healthScore,
      aiInsight: scanResult.aiInsight,
      aiSwaps: scanResult.aiSwaps,
      ingredients: scanResult.ingredients,
    };

    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
    });

    onAddMeal(newMeal);
    setTranscript('');
    setScanResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">المسح الصوتي الذكي (Voice AI Snap)</h2>
              <p className="text-xs text-slate-400">تحدث بما أكلته، وسيقوم الذكاء الاصطناعي بحساب الماكروز تلقائياً</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isLimitReached ? (
          <div className="p-6 text-center space-y-3">
            <p className="text-sm text-amber-400 font-semibold">استنفدت المسحات المجانية لهذا اليوم (3/3)</p>
            <button
              onClick={() => {
                onClose();
                onOpenPaywall();
              }}
              className="py-2 px-4 bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs"
            >
              الترقية للمستوى 3 للوصول غير المحدود
            </button>
          </div>
        ) : (
          <div className="p-6 space-y-5">
            {/* Visualizer & Mic Button */}
            {!scanResult && (
              <div className="text-center space-y-4">
                <div className="relative inline-flex items-center justify-center">
                  {isRecording && (
                    <span className="absolute w-24 h-24 rounded-full bg-indigo-500/20 animate-ping" />
                  )}
                  <button
                    onClick={handleStartSimulatedListening}
                    disabled={isRecording || isAnalyzing}
                    className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer ${
                      isRecording
                        ? 'bg-rose-500 text-white shadow-rose-500/30'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                    }`}
                  >
                    {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
                  </button>
                </div>

                <div className="text-xs text-slate-300 font-medium">
                  {isRecording
                    ? 'جاري الاستماع لصوتك...'
                    : isAnalyzing
                    ? 'جاري تحليل الوصف بالذكاء الاصطناعي...'
                    : 'انقر على الميكروفون وتحدث بما أكلته'}
                </div>

                {/* Transcript preview box */}
                {transcript && (
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-200 min-h-[50px] flex items-center justify-center">
                    "{transcript}"
                  </div>
                )}

                {/* Quick suggestions */}
                <div className="pt-2 text-right">
                  <div className="text-xs font-semibold text-slate-400 mb-2">أو انقر على جملة جاهزة لتجربتها:</div>
                  <div className="space-y-1.5">
                    {sampleVoicePrompts.map((prompt, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setTranscript(prompt);
                          runVoiceAnalysis(prompt);
                        }}
                        className="w-full text-right p-2 text-xs bg-slate-950 hover:bg-slate-800/80 border border-slate-800 rounded-lg text-slate-300 transition-colors"
                      >
                        "{prompt}"
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Results Screen */}
            {scanResult && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between text-xs text-emerald-400 font-semibold mb-1">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      تم استخراج بيانات الوجبة صوتياً
                    </span>
                    <span className="text-slate-400 tabular-nums">الوزن المقدر: {scanResult.weightGrams}غ</span>
                  </div>
                  <h3 className="text-base font-bold text-white">{scanResult.mealName}</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{scanResult.aiInsight}</p>
                </div>

                {/* Macros */}
                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-white tabular-nums">{scanResult.macros.calories}</div>
                    <div className="text-[10px] text-slate-400">سعرة حرارية</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-rose-400 tabular-nums">{scanResult.macros.protein}غ</div>
                    <div className="text-[10px] text-slate-400">بروتين</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-amber-400 tabular-nums">{scanResult.macros.carbs}غ</div>
                    <div className="text-[10px] text-slate-400">كارب</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-sky-400 tabular-nums">{scanResult.macros.fat}غ</div>
                    <div className="text-[10px] text-slate-400">دهون</div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={handleConfirm}
                    className="flex-1 py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>إضافة الوجبة فوراً</span>
                  </button>
                  <button
                    onClick={() => {
                      setScanResult(null);
                      setTranscript('');
                    }}
                    className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>وصف آخر</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
