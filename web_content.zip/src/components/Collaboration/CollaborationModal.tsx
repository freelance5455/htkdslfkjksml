import React, { useState } from 'react';
import {
  X,
  Users,
  Copy,
  Check,
  Radio,
  LogOut,
  Sparkles,
  Link2,
  Wifi,
  WifiOff,
  UserCheck,
} from 'lucide-react';
import { PeerInfo, CollabConnectionStatus } from '../../collaboration/types';

interface CollaborationModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: CollabConnectionStatus;
  roomId: string | null;
  peers: PeerInfo[];
  localPeer: PeerInfo;
  onStartCollaboration: (targetRoomId?: string) => void;
  onLeaveCollaboration: () => void;
  onUpdateLocalPeer: (name: string, color: string) => void;
}

const AVATAR_COLORS = [
  '#0284c7', // Sky Blue
  '#2563eb', // Royal Blue
  '#7c3aed', // Violet
  '#c026d3', // Fuchsia
  '#db2777', // Pink
  '#e11d48', // Rose
  '#ea580c', // Orange
  '#d97706', // Amber
  '#059669', // Emerald
  '#0d9488', // Teal
];

export const CollaborationModal: React.FC<CollaborationModalProps> = ({
  isOpen,
  onClose,
  status,
  roomId,
  peers,
  localPeer,
  onStartCollaboration,
  onLeaveCollaboration,
  onUpdateLocalPeer,
}) => {
  const [copied, setCopied] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [editingName, setEditingName] = useState(localPeer.name);
  const [selectedColor, setSelectedColor] = useState(localPeer.color);

  if (!isOpen) return null;

  const isConnected = status === 'connected';
  const isCollaborating = status === 'connected' || status === 'connecting' || status === 'reconnecting';

  const shareableUrl = roomId
    ? `${window.location.origin}${window.location.pathname}?room=${roomId}`
    : '';

  const handleCopyLink = () => {
    if (!shareableUrl) return;
    navigator.clipboard.writeText(shareableUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSaveProfile = () => {
    if (editingName.trim()) {
      onUpdateLocalPeer(editingName.trim(), selectedColor);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="flex flex-col w-full max-w-md rounded-3xl bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)] shadow-2xl border border-[var(--md-sys-color-outline-variant)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--md-sys-color-outline-variant)]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] flex items-center justify-center">
              <Users className="w-5 h-5 text-[var(--md-sys-color-primary)]" />
            </div>
            <div>
              <h2 className="text-base font-bold">Real-Time Collaboration</h2>
              <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                Invite anyone to co-draw in real time
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Collaboration"
            className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface-variant)] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          
          {/* Status Banner */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] border border-[var(--md-sys-color-outline-variant)]">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3">
                {isConnected && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                )}
                <span
                  className={`relative inline-flex rounded-full h-3 w-3 ${
                    isConnected
                      ? 'bg-emerald-500'
                      : status === 'connecting' || status === 'reconnecting'
                      ? 'bg-amber-500 animate-pulse'
                      : 'bg-slate-500'
                  }`}
                />
              </span>
              <div>
                <div className="text-xs font-bold capitalize">
                  {isConnected ? 'Live Session Active' : status === 'connecting' ? 'Connecting to Room...' : status === 'reconnecting' ? 'Reconnecting...' : 'Offline (Local Only)'}
                </div>
                <div className="text-[11px] text-[var(--md-sys-color-on-surface-variant)]">
                  {isConnected ? `${peers.length + 1} online collaborator${peers.length > 0 ? 's' : ''}` : 'No active network session'}
                </div>
              </div>
            </div>

            {isCollaborating ? (
              <button
                onClick={onLeaveCollaboration}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-500/15 text-rose-400 text-xs font-semibold hover:bg-rose-500/25 transition active:scale-95"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Disconnect</span>
              </button>
            ) : (
              <button
                onClick={() => onStartCollaboration()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-semibold hover:opacity-95 shadow-sm transition active:scale-95"
              >
                <Radio className="w-3.5 h-3.5 animate-pulse" />
                <span>Go Live</span>
              </button>
            )}
          </div>

          {/* Share Link Section when connected */}
          {isCollaborating && roomId && (
            <div className="space-y-2 p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
              <label className="block text-xs font-semibold text-[var(--md-sys-color-on-surface)]">
                Shareable Board Link
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={shareableUrl}
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] text-[var(--md-sys-color-on-surface)] font-mono select-all outline-none"
                />
                <button
                  onClick={handleCopyLink}
                  aria-label="Copy invitation link"
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] text-xs font-semibold hover:brightness-105 active:scale-95 transition"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <p className="text-[11px] text-[var(--md-sys-color-on-surface-variant)] mt-1">
                Anyone with this link can join this board instantly without creating an account.
              </p>
            </div>
          )}

          {/* Join with Room ID if not collaborating */}
          {!isCollaborating && (
            <div className="space-y-2 p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
              <label className="block text-xs font-semibold text-[var(--md-sys-color-on-surface)]">
                Join an Existing Room Code
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value.trim())}
                  placeholder="e.g. room-alpha-99"
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] text-[var(--md-sys-color-on-surface)] outline-none"
                />
                <button
                  onClick={() => {
                    if (joinCodeInput) {
                      onStartCollaboration(joinCodeInput);
                    }
                  }}
                  disabled={!joinCodeInput}
                  className="px-4 py-2 rounded-xl bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-semibold disabled:opacity-40 hover:opacity-95 transition active:scale-95"
                >
                  Join
                </button>
              </div>
            </div>
          )}

          {/* Active Collaborators Stack */}
          {isCollaborating && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--md-sys-color-on-surface-variant)]">
                  Collaborators In This Room ({peers.length + 1})
                </span>
              </div>

              <div className="space-y-2">
                {/* Local user */}
                <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] border border-[var(--md-sys-color-outline-variant)]">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-sm"
                      style={{ backgroundColor: localPeer.color }}
                    >
                      {localPeer.name.charAt(0)}
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[var(--md-sys-color-on-surface)]">
                        {localPeer.name}
                      </span>
                      <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-medium bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]">
                        You
                      </span>
                    </div>
                  </div>
                </div>

                {/* Remote peers */}
                {peers.map((peer) => (
                  <div
                    key={peer.id}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]"
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-sm"
                        style={{ backgroundColor: peer.color }}
                      >
                        {peer.name.charAt(0)}
                      </div>
                      <span className="text-xs font-medium text-[var(--md-sys-color-on-surface)]">
                        {peer.name}
                      </span>
                    </div>
                    <span className="w-2 h-2 rounded-full bg-emerald-400" title="Active" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Anonymous Profile Customization */}
          <div className="space-y-3 p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--md-sys-color-on-surface-variant)]">
              Your Anonymous Profile
            </span>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  onBlur={handleSaveProfile}
                  placeholder="Your nickname"
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline-variant)] text-[var(--md-sys-color-on-surface)] outline-none"
                />
              </div>

              {/* Avatar Color Swatches */}
              <div className="flex items-center gap-2 pt-1">
                {AVATAR_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setSelectedColor(c);
                      onUpdateLocalPeer(editingName, c);
                    }}
                    className={`w-6 h-6 rounded-full transition-transform ${
                      selectedColor === c ? 'scale-125 ring-2 ring-[var(--md-sys-color-primary)]' : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 border-t border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-semibold hover:opacity-95 transition active:scale-95"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
