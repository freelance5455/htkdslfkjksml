import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Check,
  Clock,
  ChevronDown,
  Trophy,
  Flame,
  FileText,
  AlertCircle,
  Dumbbell,
  ArrowUpDown,
  Minimize2,
  Sparkles,
  Award,
  Calculator,
  Hash,
  Scale,
  Minus,
  RotateCcw
} from 'lucide-react';
import { useWorkout, WorkoutSummaryResult } from '../context/WorkoutContext';
import { Exercise, SetTrackingMode, SetType } from '../types';
import { MuscleMapCharacter } from './MuscleMapCharacter';
import { PRBadgeChip, PRSummaryShowcase } from './PRBadge';

const SET_TYPE_ORDER: SetType[] = [
  'normal',
  'dropset',
  'superset',
  'warmup',
  'restpause',
  'amrap',
  'tempo',
  'cluster'
];

export const SET_TYPE_META: Record<
  SetType,
  { short: string; label: string; badgeClass: string; desc: string }
> = {
  normal: {
    short: '#',
    label: 'Working Set',
    badgeClass: 'bg-neutral-800/90 text-slate-300 border-neutral-700',
    desc: 'Standard working set'
  },
  dropset: {
    short: 'DROP',
    label: 'Drop Set',
    badgeClass: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    desc: 'Reduce load or mechanical leverage immediately with zero rest'
  },
  superset: {
    short: 'SUPER',
    label: 'Superset',
    badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    desc: 'Perform back-to-back with paired exercise with minimal rest'
  },
  warmup: {
    short: 'WARM',
    label: 'Warm-Up',
    badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    desc: 'Lighter preparatory joint & muscle activation set'
  },
  restpause: {
    short: 'R-P',
    label: 'Rest-Pause',
    badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    desc: 'Hit near failure, rest 15s, then squeeze out 2-4 extra reps'
  },
  amrap: {
    short: 'AMRAP',
    label: 'AMRAP / Max',
    badgeClass: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
    desc: 'As Many Reps/Seconds As Possible with strict form'
  },
  tempo: {
    short: 'TEMPO',
    label: 'Slow Eccentric',
    badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    desc: '4-second slow eccentric negative on every rep'
  },
  cluster: {
    short: 'CLUST',
    label: 'Cluster Set',
    badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
    desc: 'Mini-clusters of 2-3 reps with 10-15s intra-set breaths'
  }
};

export const ActiveWorkoutView: React.FC = () => {
  const {
    activeWorkout,
    isWorkoutModalOpen,
    setIsWorkoutModalOpen,
    finishActiveWorkout,
    cancelActiveWorkout,
    exercises,
    addSetToActiveExercise,
    removeSetFromActiveExercise,
    updateActiveSet,
    toggleActiveSetComplete,
    addExerciseToActiveWorkout,
    removeExerciseFromActiveWorkout,
    updateActiveExerciseNotes,
    updateActiveWorkoutNotes,
    startRestTimer,
    stopRestTimer,
    isTimerRunning,
    timerSecondsLeft,
    setIsTimerModalOpen,
    personalRecords,
    triggerPRNotification,
    triggerLevelUpTierNotification,
    user
  } = useWorkout();

  const [isExercisePickerOpen, setIsExercisePickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerCategory, setPickerCategory] = useState<string>('all');
  const [summaryResult, setSummaryResult] = useState<WorkoutSummaryResult | null>(null);
  const [confirmCancelOpen, setConfirmCancelOpen] = useState(false);
  const [expandedNotesIndex, setExpandedNotesIndex] = useState<number | null>(null);
  const [showActiveMuscleMap, setShowActiveMuscleMap] = useState<boolean>(true);
  const [focusedActiveExerciseId, setFocusedActiveExerciseId] = useState<string | null>(null);

  // Set Calculator & Tracking Mode Tool State
  const [openCalcTarget, setOpenCalcTarget] = useState<{
    exIdx: number;
    setId: string;
  } | null>(null);
  const [calcBodyweight, setCalcBodyweight] = useState<number>(72);

  if (!isWorkoutModalOpen || (!activeWorkout && !summaryResult)) return null;

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleFinish = () => {
    const res = finishActiveWorkout();
    if (res) {
      setSummaryResult(res);
    }
  };

  const filteredExercises = exercises.filter((ex) => {
    const matchesSearch = ex.name.toLowerCase().includes(pickerSearch.toLowerCase());
    const isSkill =
      ex.id.includes('planche') ||
      ex.id.includes('lever') ||
      ex.id.includes('ninety-degree') ||
      ex.id.includes('l-sit') ||
      ex.id.includes('v-sit') ||
      ex.id.includes('manna') ||
      ex.id.includes('handstand') ||
      ex.id.includes('human-flag') ||
      ex.id.includes('dragon-flag') ||
      ex.id.includes('muscle-up') ||
      ex.id.includes('hefesto') ||
      ex.id.includes('victorian') ||
      ex.id.includes('iron-cross') ||
      ex.id.includes('two-finger') ||
      ex.name.toLowerCase().includes('one-arm');
    const matchesCategory =
      pickerCategory === 'all' ||
      ex.category === pickerCategory ||
      (pickerCategory === 'skills' && isSkill) ||
      (pickerCategory === 'resistance band' && ex.equipment === 'resistance band') ||
      (pickerCategory === 'towel' && ex.equipment === 'towel');
    return matchesSearch && matchesCategory;
  });

  const totalSetsInSession = activeWorkout
    ? activeWorkout.exercises.reduce((sum, ex) => sum + ex.sets.length, 0)
    : 0;
  const completedSetsInSession = activeWorkout
    ? activeWorkout.exercises.reduce(
        (sum, ex) => sum + ex.sets.filter((s) => s.completed).length,
        0
      )
    : 0;
  const completionPercentage =
    totalSetsInSession > 0 ? Math.round((completedSetsInSession / totalSetsInSession) * 100) : 0;

  return (
    <>
      {activeWorkout && (
      <div className="fixed inset-0 z-50 bg-[#0a0b0e] flex flex-col overflow-hidden animate-in fade-in duration-200">
        {/* Top Sticky Header */}
        <header className="sticky top-0 z-20 bg-[#0f1218]/95 backdrop-blur-md border-b border-neutral-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsWorkoutModalOpen(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 transition-colors"
              title="Minimize Workout"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                {activeWorkout.name}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span className="font-mono font-semibold text-slate-200">
                  {formatSeconds(activeWorkout.elapsedSeconds)}
                </span>
                <span>·</span>
                <span>{activeWorkout.exercises.length} Exercises</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setConfirmCancelOpen(true)}
              className="p-2 text-slate-400 hover:text-red-400 rounded-xl hover:bg-red-500/10 transition-colors"
              title="Cancel Workout"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleFinish}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Finish</span>
            </button>
          </div>
        </header>

        {/* Workout Completion Progression Line Bar */}
        <div className="sticky top-[57px] z-10 bg-[#0f1218]/95 backdrop-blur-md px-4 py-2 border-b border-neutral-800/80">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="text-slate-400 font-medium">Session Progress</span>
            <span className="font-mono font-bold text-cyan-400">
              {completedSetsInSession} of {totalSetsInSession} sets ({completionPercentage}%)
            </span>
          </div>
          <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden">
            <div
              style={{ width: `${completionPercentage}%` }}
              className="h-full bg-gradient-to-r from-cyan-600 via-cyan-400 to-cyan-300 rounded-full transition-all duration-500 glow-cyan-sm"
            />
          </div>
        </div>

        {/* Active Rest Countdown Bar with Direct Stop Option */}
        {isTimerRunning && (
          <div className="bg-cyan-950/40 border-b border-cyan-500/30 px-4 py-2 flex items-center justify-between animate-in slide-in-from-top duration-200">
            <button
              onClick={() => setIsTimerModalOpen(true)}
              className="flex items-center gap-2 text-xs font-semibold text-cyan-300 hover:text-white transition-colors"
              title="Open Rest Timer"
            >
              <Clock className="w-3.5 h-3.5 animate-spin text-cyan-400" style={{ animationDuration: '6s' }} />
              <span>
                Rest Interval: <strong className="font-mono text-white text-sm">{formatSeconds(timerSecondsLeft)}</strong>
              </span>
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsTimerModalOpen(true)}
                className="px-2.5 py-1 text-[11px] font-semibold bg-neutral-900 border border-neutral-700 text-slate-300 rounded-lg hover:text-white"
              >
                Adjust
              </button>
              <button
                onClick={stopRestTimer}
                className="px-2.5 py-1 text-[11px] font-bold bg-red-500/20 border border-red-500/40 text-red-300 rounded-lg hover:bg-red-500/30 transition-colors flex items-center gap-1 active:scale-95"
                title="Stop Rest Timer"
              >
                <X className="w-3 h-3" />
                <span>Stop</span>
              </button>
            </div>
          </div>
        )}

        {/* Workout Scrollable Body */}
        <div className="flex-1 overflow-y-auto px-4 py-5 max-w-lg mx-auto w-full space-y-5 pb-32">
          {activeWorkout.exercises.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Active Session Muscle Map
                </span>
                <button
                  type="button"
                  onClick={() => setShowActiveMuscleMap((prev) => !prev)}
                  className="text-xs font-semibold text-cyan-400 hover:text-cyan-300"
                >
                  {showActiveMuscleMap ? 'Hide Character' : 'Show Character'}
                </button>
              </div>
              {showActiveMuscleMap && (
                <MuscleMapCharacter
                  exercise={
                    focusedActiveExerciseId
                      ? exercises.find((e) => e.id === focusedActiveExerciseId) || null
                      : null
                  }
                  exercises={
                    focusedActiveExerciseId
                      ? undefined
                      : activeWorkout.exercises
                          .map((we) => exercises.find((e) => e.id === we.exerciseId))
                          .filter((e): e is Exercise => Boolean(e))
                  }
                  size="sm"
                  title={
                    focusedActiveExerciseId
                      ? `Targeting: ${exercises.find((e) => e.id === focusedActiveExerciseId)?.name || ''}`
                      : 'Active Workout Plan Target Muscles'
                  }
                  subtitle="Highlighted in cyan: muscles worked in this session"
                />
              )}
            </div>
          )}

          {activeWorkout.exercises.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-neutral-900/60 border border-dashed border-neutral-800">
              <Dumbbell className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-white mb-1">Your workout is empty</h3>
              <p className="text-xs text-slate-400 mb-5">
                Add your first calisthenics or home exercise to begin tracking sets.
              </p>
              <button
                onClick={() => setIsExercisePickerOpen(true)}
                className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-semibold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                + Add Exercise
              </button>
            </div>
          ) : (
            activeWorkout.exercises.map((we, exIdx) => {
              const exDef = exercises.find((e) => e.id === we.exerciseId);
              const isHold = exDef?.isHold || false;

              // Check existing PRs to show live PR indicators when a completed set beats the record
              const existingRepPR =
                personalRecords.find((p) => p.exerciseId === we.exerciseId && p.unit === 'reps')
                  ?.value ?? 0;
              const existingHoldPR =
                personalRecords.find((p) => p.exerciseId === we.exerciseId && p.unit === 'seconds')
                  ?.value ?? 0;
              const existingWeightPR =
                personalRecords.find(
                  (p) =>
                    p.exerciseId === `${we.exerciseId}-weight` ||
                    (p.exerciseId === we.exerciseId && (p.unit === 'kg' || p.unit === 'lbs'))
                )?.value ?? 0;

              const maxCompletedVal = we.sets
                .filter((s) => s.completed)
                .reduce((max, s) => Math.max(max, isHold ? s.durationSec || 0 : s.reps || 0), 0);
              const maxCompletedWeight = we.sets
                .filter((s) => s.completed)
                .reduce((max, s) => Math.max(max, s.weightKg || 0), 0);

              const hasLiveRepOrHoldPR = isHold
                ? maxCompletedVal > 0 && maxCompletedVal > existingHoldPR
                : maxCompletedVal > 0 && maxCompletedVal > existingRepPR;
              const hasLiveWeightPR = maxCompletedWeight > 0 && maxCompletedWeight > existingWeightPR;

              return (
                <div
                  key={`${we.exerciseId}_${exIdx}`}
                  className="bg-[#12151c] border border-neutral-800/90 rounded-2xl overflow-hidden shadow-sm"
                >
                  {/* Exercise Header */}
                  <div className="p-4 border-b border-neutral-800/60 flex items-start justify-between">
                    <div
                      className="cursor-pointer"
                      onClick={() =>
                        setFocusedActiveExerciseId((prev) =>
                          prev === we.exerciseId ? null : we.exerciseId
                        )
                      }
                      title="Tap to highlight this exercise's muscles on the character"
                    >
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-1">
                        <span className="capitalize text-cyan-400 font-medium">
                          {exDef?.category || 'Strength'}
                        </span>
                        {exDef?.targetMuscles && exDef.targetMuscles.length > 0 && (
                          <>
                            <span>·</span>
                            <span className="text-slate-300 truncate max-w-[210px]">
                              {exDef.targetMuscles.slice(0, 2).join(', ')}
                            </span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">{exDef?.equipment || 'Bodyweight'}</span>
                        {exDef?.progressionLevel && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>Level {exDef.progressionLevel}</span>
                          </>
                        )}
                      </div>
                      <div className="flex items-center flex-wrap gap-2">
                        <h3 className="text-base font-bold text-white">{exDef?.name || we.exerciseId}</h3>
                        {hasLiveRepOrHoldPR && (
                          <PRBadgeChip
                            type={isHold ? 'hold' : 'reps'}
                            value={maxCompletedVal}
                            unit={isHold ? 's' : 'reps'}
                            size="xs"
                          />
                        )}
                        {hasLiveWeightPR && (
                          <PRBadgeChip
                            type="weight"
                            value={`+${maxCompletedWeight}`}
                            unit={user.units === 'imperial' ? 'lbs' : 'kg'}
                            size="xs"
                          />
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          const targetSetId = we.sets[0]?.id;
                          if (!targetSetId) return;
                          setOpenCalcTarget((prev) =>
                            prev?.exIdx === exIdx ? null : { exIdx, setId: targetSetId }
                          );
                        }}
                        className={`px-2 py-1.5 rounded-lg border text-[11px] font-bold transition-all flex items-center gap-1 ${
                          openCalcTarget?.exIdx === exIdx
                            ? 'text-cyan-300 bg-cyan-500/20 border-cyan-500/50 shadow-sm'
                            : 'text-slate-300 bg-neutral-900 border-neutral-800 hover:text-cyan-400 hover:border-cyan-500/40'
                        }`}
                        title="Open Set Calculator & Toggle Reps / Time (s) / Weight (kg/lbs)"
                      >
                        <Calculator className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="hidden sm:inline">Calc / Mode</span>
                      </button>
                      <button
                        onClick={() => startRestTimer(we.restTimeSec || user.defaultRestTimeSec)}
                        className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-neutral-800/60 rounded-lg transition-colors"
                        title="Start Rest Timer"
                      >
                        <Clock className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() =>
                          setExpandedNotesIndex(expandedNotesIndex === exIdx ? null : exIdx)
                        }
                        className={`p-2 rounded-lg transition-colors ${
                          we.notes
                            ? 'text-cyan-400 bg-cyan-950/30'
                            : 'text-slate-400 hover:text-white hover:bg-neutral-800/60'
                        }`}
                        title="Notes"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => removeExerciseFromActiveWorkout(exIdx)}
                        className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                        title="Remove Exercise"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Notes input */}
                  {expandedNotesIndex === exIdx && (
                    <div className="px-4 pt-3 pb-1 border-b border-neutral-800/40 bg-neutral-900/40">
                      <input
                        type="text"
                        placeholder="Add notes (e.g. explosive tempo, clean lock)..."
                        value={we.notes || ''}
                        onChange={(e) => updateActiveExerciseNotes(exIdx, e.target.value)}
                        className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/60"
                      />
                    </div>
                  )}

                  {/* Interactive Set Calculator & Tracking Mode Tool Drawer */}
                  {openCalcTarget?.exIdx === exIdx && (() => {
                    const activeSet =
                      we.sets.find((s) => s.id === openCalcTarget.setId) || we.sets[0];
                    if (!activeSet) return null;

                    const unitLabel = user.units === 'imperial' ? 'lbs' : 'kg';
                    const activeMode: SetTrackingMode =
                      activeSet.trackingMode || (isHold ? 'time' : 'reps');
                    const curReps = activeSet.reps ?? exDef?.defaultReps ?? 10;
                    const curTime = activeSet.durationSec ?? exDef?.defaultHoldSec ?? 30;
                    const curWeight = activeSet.weightKg ?? 0;

                    // Convert kg <-> lbs helper
                    const convertedWeight =
                      user.units === 'imperial'
                        ? (curWeight * 0.453592).toFixed(1)
                        : (curWeight * 2.20462).toFixed(1);
                    const oppositeUnit = user.units === 'imperial' ? 'kg' : 'lbs';

                    // Weighted Calisthenics Metrics (Total System Load, % BW, Epley 1RM)
                    const totalSystemLoad = calcBodyweight + curWeight;
                    const addedBwPercent =
                      calcBodyweight > 0 ? Math.round((curWeight / calcBodyweight) * 100) : 0;
                    const estimatedOneRepMaxAdded =
                      curReps > 1
                        ? Math.round(
                            (totalSystemLoad * (1 + curReps / 30) - calcBodyweight) * 10
                          ) / 10
                        : curWeight;

                    const applyModeToAllSets = (mode: SetTrackingMode) => {
                      we.sets.forEach((s) => {
                        updateActiveSet(exIdx, s.id, {
                          trackingMode: mode,
                          reps: s.reps ?? exDef?.defaultReps ?? 10,
                          durationSec: s.durationSec ?? exDef?.defaultHoldSec ?? 30
                        });
                      });
                    };

                    return (
                      <div className="mx-3 mt-3 p-3.5 rounded-2xl bg-neutral-950/95 border border-cyan-500/40 shadow-lg space-y-3 animate-in fade-in duration-150">
                        {/* Calculator Header & Set Selector */}
                        <div className="flex items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                              <Calculator className="w-3.5 h-3.5" />
                            </div>
                            <div>
                              <div className="text-xs font-extrabold text-white">
                                Set Calculator & Tracking Mode
                              </div>
                              <div className="text-[10px] text-slate-400">
                                Toggle Reps, Time (sec), or Weight ({unitLabel}) per set
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1">
                            {we.sets.map((s) => (
                              <button
                                key={s.id}
                                type="button"
                                onClick={() => setOpenCalcTarget({ exIdx, setId: s.id })}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold border transition-all ${
                                  activeSet.id === s.id
                                    ? 'bg-cyan-500 text-neutral-950 border-cyan-400'
                                    : 'bg-neutral-900 text-slate-400 border-neutral-800 hover:text-white'
                                }`}
                              >
                                #{s.setNumber}
                              </button>
                            ))}
                            <button
                              type="button"
                              onClick={() => setOpenCalcTarget(null)}
                              className="p-1 text-slate-400 hover:text-white ml-1"
                              title="Close Calculator"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Tracking Mode Toggle: Reps | Time (seconds) | Weight (kg/lbs) */}
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                            <span>Set #{activeSet.setNumber} Primary Tracking Mode</span>
                            <button
                              type="button"
                              onClick={() => applyModeToAllSets(activeMode)}
                              className="text-cyan-400 hover:underline font-bold normal-case"
                            >
                              Apply mode to all {we.sets.length} sets
                            </button>
                          </div>

                          <div className="grid grid-cols-3 gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
                            {(
                              [
                                { id: 'reps', label: 'Reps', icon: Hash },
                                { id: 'time', label: 'Time (sec)', icon: Clock },
                                { id: 'weight', label: `Weight (${unitLabel})`, icon: Scale }
                              ] as { id: SetTrackingMode; label: string; icon: React.ElementType }[]
                            ).map((modeOpt) => {
                              const IconComp = modeOpt.icon;
                              const isSelected = activeMode === modeOpt.id;
                              return (
                                <button
                                  key={modeOpt.id}
                                  type="button"
                                  onClick={() =>
                                    updateActiveSet(exIdx, activeSet.id, {
                                      trackingMode: modeOpt.id,
                                      reps: activeSet.reps ?? exDef?.defaultReps ?? 10,
                                      durationSec:
                                        activeSet.durationSec ?? exDef?.defaultHoldSec ?? 30
                                    })
                                  }
                                  className={`py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                                    isSelected
                                      ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                                      : 'text-slate-300 hover:text-white'
                                  }`}
                                >
                                  <IconComp className="w-3.5 h-3.5" />
                                  <span>{modeOpt.label}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Mode-Specific Calculator Controls */}
                        {activeMode === 'reps' && (
                          <div className="space-y-2 pt-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-semibold text-slate-300">
                                Target Repetitions (Set #{activeSet.setNumber})
                              </span>
                              <span className="text-sm font-extrabold font-mono text-cyan-400">
                                {curReps} reps {curWeight > 0 ? `@ +${curWeight}${unitLabel}` : '(Bodyweight)'}
                              </span>
                            </div>

                            {/* Quick Rep Presets & Steppers */}
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {[3, 5, 8, 10, 12, 15, 20, 25].map((presetRep) => (
                                <button
                                  key={presetRep}
                                  type="button"
                                  onClick={() =>
                                    updateActiveSet(exIdx, activeSet.id, { reps: presetRep })
                                  }
                                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border transition-all ${
                                    curReps === presetRep
                                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                                      : 'bg-neutral-900 border-neutral-800 text-slate-300 hover:border-cyan-500/40'
                                  }`}
                                >
                                  {presetRep}
                                </button>
                              ))}
                              <button
                                type="button"
                                onClick={() =>
                                  updateActiveSet(exIdx, activeSet.id, {
                                    reps: Math.max(1, curReps - 1)
                                  })
                                }
                                className="px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-bold text-slate-300 flex items-center gap-0.5"
                              >
                                <Minus className="w-3 h-3" />1
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  updateActiveSet(exIdx, activeSet.id, { reps: curReps + 1 })
                                }
                                className="px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-bold text-cyan-400 flex items-center gap-0.5"
                              >
                                <Plus className="w-3 h-3" />1
                              </button>
                            </div>
                          </div>
                        )}

                        {activeMode === 'time' && (
                          <div className="space-y-2 pt-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-semibold text-slate-300">
                                Isometric Hold / Time Under Tension (Set #{activeSet.setNumber})
                              </span>
                              <span className="text-sm font-extrabold font-mono text-cyan-400">
                                {curTime}s ({formatSeconds(curTime)})
                              </span>
                            </div>

                            {/* Quick Hold Second Presets & Steppers */}
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {[10, 15, 20, 30, 45, 60, 90].map((presetSec) => (
                                <button
                                  key={presetSec}
                                  type="button"
                                  onClick={() =>
                                    updateActiveSet(exIdx, activeSet.id, {
                                      durationSec: presetSec,
                                      trackingMode: 'time'
                                    })
                                  }
                                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border transition-all ${
                                    curTime === presetSec
                                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                                      : 'bg-neutral-900 border-neutral-800 text-slate-300 hover:border-cyan-500/40'
                                  }`}
                                >
                                  {presetSec}s
                                </button>
                              ))}
                              <button
                                type="button"
                                onClick={() =>
                                  updateActiveSet(exIdx, activeSet.id, {
                                    durationSec: Math.max(5, curTime - 5),
                                    trackingMode: 'time'
                                  })
                                }
                                className="px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-bold text-slate-300"
                              >
                                -5s
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  updateActiveSet(exIdx, activeSet.id, {
                                    durationSec: curTime + 5,
                                    trackingMode: 'time'
                                  })
                                }
                                className="px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-bold text-cyan-400"
                              >
                                +5s
                              </button>
                            </div>
                          </div>
                        )}

                        {activeMode === 'weight' && (
                          <div className="space-y-2.5 pt-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-semibold text-slate-300">
                                Added Load Calculator (Backpack / Vest / Plates)
                              </span>
                              <div className="text-right">
                                <span className="text-sm font-extrabold font-mono text-cyan-400">
                                  +{curWeight} {unitLabel}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono ml-1.5">
                                  (≈ {convertedWeight} {oppositeUnit})
                                </span>
                              </div>
                            </div>

                            {/* Quick Add Weight Increments */}
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {[1, 2.5, 5, 10, 15, 20].map((inc) => (
                                <button
                                  key={inc}
                                  type="button"
                                  onClick={() =>
                                    updateActiveSet(exIdx, activeSet.id, {
                                      weightKg: Math.round((curWeight + inc) * 10) / 10
                                    })
                                  }
                                  className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-cyan-500/40 text-xs font-mono font-bold text-cyan-300 active:scale-95 transition-all"
                                >
                                  +{inc}
                                  {unitLabel}
                                </button>
                              ))}
                              <button
                                type="button"
                                onClick={() =>
                                  updateActiveSet(exIdx, activeSet.id, { weightKg: 0 })
                                }
                                className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-red-950/30 border border-neutral-800 text-[11px] font-semibold text-slate-400 hover:text-red-300 flex items-center gap-1"
                              >
                                <RotateCcw className="w-3 h-3" />
                                <span>0 (BW)</span>
                              </button>
                            </div>

                            {/* Bodyweight & Relative Strength Calculator Readout */}
                            <div className="p-2.5 rounded-xl bg-neutral-900/90 border border-neutral-800 grid grid-cols-3 gap-2 text-center">
                              <div>
                                <div className="text-[9px] text-slate-400 uppercase font-bold">
                                  Your BW ({unitLabel})
                                </div>
                                <input
                                  type="number"
                                  min="30"
                                  max="250"
                                  value={calcBodyweight}
                                  onChange={(e) =>
                                    setCalcBodyweight(parseFloat(e.target.value) || 70)
                                  }
                                  className="w-16 mt-0.5 text-center text-xs font-mono font-bold bg-neutral-950 border border-neutral-800 rounded px-1 py-0.5 text-white"
                                />
                              </div>
                              <div>
                                <div className="text-[9px] text-slate-400 uppercase font-bold">
                                  Total Load
                                </div>
                                <div className="text-xs font-mono font-extrabold text-white mt-1">
                                  {totalSystemLoad} {unitLabel}{' '}
                                  <span className="text-[10px] text-cyan-400">
                                    (+{addedBwPercent}% BW)
                                  </span>
                                </div>
                              </div>
                              <div>
                                <div className="text-[9px] text-slate-400 uppercase font-bold">
                                  Est. 1RM Load
                                </div>
                                <div className="text-xs font-mono font-extrabold text-amber-400 mt-1">
                                  +{ Math.max(0, estimatedOneRepMaxAdded) } {unitLabel}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {/* Sets Table */}
                  <div className="p-3">
                    <div className="grid grid-cols-12 gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider pb-2 px-1 text-center">
                      <div className="col-span-3 text-left" title="Tap badge to cycle Set Variation">
                        Set / Type
                      </div>
                      <div className="col-span-3">+{user.units === 'imperial' ? 'Lbs' : 'Kg'}</div>
                      <div className="col-span-3">Reps / Sec</div>
                      <div className="col-span-2">Done</div>
                      <div className="col-span-1"></div>
                    </div>

                    <div className="space-y-1.5">
                      {we.sets.map((set) => {
                        const currentSetType: SetType = set.setType || 'normal';
                        const typeMeta = SET_TYPE_META[currentSetType];
                        const setMode: SetTrackingMode =
                          set.trackingMode || (isHold ? 'time' : 'reps');
                        const isSetTrackingTime = setMode === 'time';

                        const cycleSetType = () => {
                          const nextIdx =
                            (SET_TYPE_ORDER.indexOf(currentSetType) + 1) % SET_TYPE_ORDER.length;
                          updateActiveSet(exIdx, set.id, { setType: SET_TYPE_ORDER[nextIdx] });
                        };

                        const cycleTrackingMode = () => {
                          const modes: SetTrackingMode[] = ['reps', 'time', 'weight'];
                          const nextMode = modes[(modes.indexOf(setMode) + 1) % modes.length];
                          updateActiveSet(exIdx, set.id, {
                            trackingMode: nextMode,
                            reps: set.reps ?? exDef?.defaultReps ?? 10,
                            durationSec: set.durationSec ?? exDef?.defaultHoldSec ?? 30
                          });
                          if (nextMode === 'weight') {
                            setOpenCalcTarget({ exIdx, setId: set.id });
                          }
                        };

                        return (
                          <div
                            key={set.id}
                            className={`grid grid-cols-12 gap-2 items-center p-1.5 rounded-xl transition-colors ${
                              set.completed
                                ? 'bg-cyan-950/20 border border-cyan-500/30'
                                : 'bg-neutral-900/60 border border-neutral-800/60'
                            }`}
                          >
                            {/* Set Number & Interactive Set Type Variation Badge */}
                            <div className="col-span-3 text-left pl-1 flex items-center gap-1">
                              <button
                                type="button"
                                onClick={cycleSetType}
                                className={`px-1.5 py-1 rounded-lg border font-mono text-[10px] font-extrabold tracking-tight transition-all active:scale-95 flex items-center gap-1 ${typeMeta.badgeClass}`}
                                title={`${typeMeta.label}: ${typeMeta.desc} (Tap to change set variation)`}
                              >
                                {currentSetType === 'normal' ? (
                                  <span>#{set.setNumber}</span>
                                ) : (
                                  <>
                                    <span>{set.setNumber}</span>
                                    <span>·</span>
                                    <span>{typeMeta.short}</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Weight (+kg or +lbs) */}
                            <div className="col-span-3">
                              <input
                                type="number"
                                min="0"
                                step="0.5"
                                value={set.weightKg ?? 0}
                                onChange={(e) =>
                                  updateActiveSet(exIdx, set.id, {
                                    weightKg: parseFloat(e.target.value) || 0
                                  })
                                }
                                className={`w-full text-center text-xs font-mono font-semibold bg-neutral-950/80 border rounded-lg py-1.5 text-white focus:outline-none focus:border-cyan-500 ${
                                  setMode === 'weight'
                                    ? 'border-cyan-500/70 ring-1 ring-cyan-500/20'
                                    : 'border-neutral-800/80'
                                }`}
                                placeholder="0"
                              />
                            </div>

                            {/* Reps or Hold Seconds with 1-Tap Mode Toggle Pill */}
                            <div className="col-span-3 flex items-center gap-1">
                              {isSetTrackingTime ? (
                                <input
                                  type="number"
                                  min="1"
                                  value={set.durationSec ?? exDef?.defaultHoldSec ?? 30}
                                  onChange={(e) =>
                                    updateActiveSet(exIdx, set.id, {
                                      durationSec: parseInt(e.target.value, 10) || 0
                                    })
                                  }
                                  className="w-full text-center text-xs font-mono font-semibold bg-neutral-950/80 border border-cyan-500/50 rounded-lg py-1.5 text-white focus:outline-none focus:border-cyan-500"
                                />
                              ) : (
                                <input
                                  type="number"
                                  min="1"
                                  value={set.reps ?? exDef?.defaultReps ?? 10}
                                  onChange={(e) =>
                                    updateActiveSet(exIdx, set.id, {
                                      reps: parseInt(e.target.value, 10) || 0
                                    })
                                  }
                                  className="w-full text-center text-xs font-mono font-semibold bg-neutral-950/80 border border-neutral-800/80 rounded-lg py-1.5 text-white focus:outline-none focus:border-cyan-500"
                                />
                              )}
                              <button
                                type="button"
                                onClick={cycleTrackingMode}
                                className={`px-1.5 py-1.5 rounded-lg border text-[9px] font-mono font-extrabold uppercase shrink-0 transition-colors ${
                                  isSetTrackingTime
                                    ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                                    : setMode === 'weight'
                                    ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                                    : 'bg-neutral-900 border-neutral-800 text-slate-400 hover:text-white'
                                }`}
                                title="Tap to toggle between Reps, Time (sec), or Weight Calculator"
                              >
                                {isSetTrackingTime ? 'SEC' : setMode === 'weight' ? 'WT' : 'REP'}
                              </button>
                            </div>

                            {/* Complete Checkbox */}
                            <div className="col-span-2 flex justify-center">
                              <button
                                onClick={() => toggleActiveSetComplete(exIdx, set.id)}
                                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                                  set.completed
                                    ? 'bg-cyan-500 text-neutral-950 shadow-sm shadow-cyan-500/40 active:scale-90'
                                    : 'bg-neutral-800/90 text-slate-400 hover:text-white hover:bg-neutral-700 active:scale-95'
                                }`}
                              >
                                <Check className="w-4 h-4 stroke-[3]" />
                              </button>
                            </div>

                            {/* Delete Set */}
                            <div className="col-span-1 flex justify-center">
                              {we.sets.length > 1 && (
                                <button
                                  onClick={() => removeSetFromActiveExercise(exIdx, set.id)}
                                  className="text-slate-500 hover:text-red-400 p-1 transition-colors"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Quick Add Set & Set Variations Bar (Drop Set, Superset, Rest-Pause, AMRAP, Tempo, Cluster) */}
                    <div className="mt-3 space-y-1.5">
                      <button
                        type="button"
                        onClick={() => addSetToActiveExercise(exIdx, 'normal')}
                        className="w-full py-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 bg-neutral-900 hover:bg-neutral-800 rounded-xl border border-neutral-800 transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Working Set</span>
                      </button>

                      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                        {(
                          [
                            'dropset',
                            'superset',
                            'restpause',
                            'amrap',
                            'tempo',
                            'warmup',
                            'cluster'
                          ] as SetType[]
                        ).map((variation) => {
                          const meta = SET_TYPE_META[variation];
                          return (
                            <button
                              key={variation}
                              type="button"
                              onClick={() => addSetToActiveExercise(exIdx, variation)}
                              className={`px-2.5 py-1 rounded-lg border text-[10px] font-bold whitespace-nowrap transition-all active:scale-95 flex items-center gap-1 ${meta.badgeClass}`}
                              title={`Add ${meta.label}: ${meta.desc}`}
                            >
                              <Plus className="w-2.5 h-2.5" />
                              <span>{meta.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Add Exercise CTA */}
          <button
            onClick={() => setIsExercisePickerOpen(true)}
            className="w-full py-3.5 border border-dashed border-cyan-500/40 hover:border-cyan-400 text-cyan-400 hover:text-cyan-300 rounded-2xl bg-cyan-950/10 hover:bg-cyan-950/20 font-bold text-xs tracking-wide uppercase transition-all flex items-center justify-center gap-2 active:scale-[0.99]"
          >
            <Plus className="w-4 h-4" />
            Add Exercise to Workout
          </button>

          {/* Workout Notes Textarea Field (Saved to localStorage) */}
          <div className="bg-[#12151c] border border-neutral-800/90 rounded-2xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label
                htmlFor="active-workout-notes"
                className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider cursor-pointer"
              >
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>Workout Notes</span>
              </label>
              <div className="flex items-center gap-2">
                {activeWorkout.notes && activeWorkout.notes.trim().length > 0 ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-cyan-400 bg-cyan-950/40 border border-cyan-500/30 px-2 py-0.5 rounded-full">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                    Saved to localStorage
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-500 font-medium">
                    Auto-saves to session log
                  </span>
                )}
              </div>
            </div>

            {/* Quick Training Cue Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {[
                '⚡ High Energy',
                '🎯 Clean Lockouts',
                '🔥 Controlled Eccentrics',
                '💪 Strong Scapular Control',
                '🧘 Solid Joint Recovery'
              ].map((cue) => (
                <button
                  key={cue}
                  type="button"
                  onClick={() => {
                    const current = activeWorkout.notes || '';
                    const separator = current.trim().length > 0 ? ' • ' : '';
                    updateActiveWorkoutNotes(`${current}${separator}${cue}`);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-cyan-500/40 text-[10px] font-medium text-slate-300 hover:text-cyan-300 whitespace-nowrap transition-colors active:scale-95"
                >
                  + {cue}
                </button>
              ))}
            </div>

            <textarea
              id="active-workout-notes"
              rows={3}
              value={activeWorkout.notes || ''}
              onChange={(e) => updateActiveWorkoutNotes(e.target.value)}
              placeholder="Log how you felt today, energy levels, RPE, or specific training cues for this session (e.g., hollow body tension, full ROM, shoulder warm-up)..."
              className="w-full text-xs leading-relaxed bg-neutral-950/80 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500/70 focus:ring-1 focus:ring-cyan-500/30 resize-y transition-all"
            />
          </div>
        </div>
      </div>
      )}

      {/* Exercise Picker Modal */}
      {isExercisePickerOpen && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-md flex flex-col justify-end sm:justify-center p-0 sm:p-4">
          <div className="bg-[#12151c] border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-lg mx-auto max-h-[85vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
            {/* Header */}
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Select Exercise</h3>
                <p className="text-xs text-slate-400">Choose from calisthenics & home library</p>
              </div>
              <button
                onClick={() => setIsExercisePickerOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search and Category Tabs */}
            <div className="p-4 border-b border-neutral-800 space-y-3">
              <input
                type="text"
                placeholder="Search exercises (e.g. Pull-up, Planche)..."
                value={pickerSearch}
                onChange={(e) => setPickerSearch(e.target.value)}
                className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />

              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {['all', 'pull', 'push', 'core', 'legs', 'resistance band', 'towel', 'backpack'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setPickerCategory(cat)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg capitalize whitespace-nowrap transition-colors ${
                      pickerCategory === cat
                        ? 'bg-cyan-500 text-neutral-950 font-bold'
                        : 'bg-neutral-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Exercise List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {filteredExercises.map((ex) => (
                <button
                  key={ex.id}
                  onClick={() => {
                    addExerciseToActiveWorkout(ex.id);
                    setIsExercisePickerOpen(false);
                  }}
                  className="w-full text-left p-3 rounded-2xl bg-neutral-900/60 hover:bg-neutral-850 border border-neutral-800/80 transition-all flex items-center justify-between group active:scale-[0.99]"
                >
                  <div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-0.5">
                      <span className="capitalize text-cyan-400 font-medium">{ex.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{ex.equipment}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{ex.difficulty}</span>
                    </div>
                    <div className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {ex.name}
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-xl bg-neutral-800 group-hover:bg-cyan-500 group-hover:text-neutral-950 flex items-center justify-center text-slate-300 transition-colors">
                    <Plus className="w-4 h-4" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Discard Confirmation Modal */}
      {confirmCancelOpen && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-red-500/30 rounded-2xl p-6 max-w-xs w-full text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">Discard Workout?</h3>
            <p className="text-xs text-slate-400 mb-5">
              All tracked sets and progress in this session will be lost.
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setConfirmCancelOpen(false)}
                className="flex-1 py-2.5 bg-neutral-900 text-slate-300 text-xs font-semibold rounded-xl"
              >
                Keep Going
              </button>
              <button
                onClick={() => {
                  setConfirmCancelOpen(false);
                  cancelActiveWorkout();
                }}
                className="flex-1 py-2.5 bg-red-600 text-white text-xs font-semibold rounded-xl hover:bg-red-500"
              >
                Discard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Workout Completion Summary Modal */}
      {summaryResult && (
        <div className="fixed inset-0 z-60 bg-black/90 backdrop-blur-lg flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="bg-[#12151c] border border-cyan-500/40 rounded-3xl p-5 sm:p-6 max-w-md w-full max-h-[90vh] flex flex-col text-center shadow-2xl shadow-cyan-950/50 overflow-hidden">
            {/* Scrollable Summary Content */}
            <div className="flex-1 overflow-y-auto pr-0.5 space-y-4">
              {/* Celebration Header */}
              <div className="pt-1">
                <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-cyan-300 to-amber-300 flex items-center justify-center text-neutral-950 mx-auto mb-3 shadow-lg shadow-cyan-500/30 animate-badge-pop">
                  <Trophy className="w-8 h-8 fill-neutral-950" />
                  {summaryResult.newPRs.length > 0 && (
                    <span className="absolute -top-2 -right-2 px-1.5 py-0.5 rounded-full bg-amber-400 text-neutral-950 font-black text-[10px] shadow-md border border-neutral-950">
                      {summaryResult.newPRs.length} PR{summaryResult.newPRs.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>

                <div className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-1">
                  {summaryResult.newPRs.length > 0
                    ? 'Workout Complete · New Personal Record!'
                    : 'Workout Complete'}
                </div>
                <h2 className="text-xl font-extrabold text-white">
                  {summaryResult.workout.name}
                </h2>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 p-3 bg-neutral-900/80 rounded-2xl border border-neutral-800">
                <div>
                  <div className="text-lg font-extrabold text-white font-mono">
                    {formatSeconds(summaryResult.workout.durationSec)}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">Duration</div>
                </div>
                <div className="border-x border-neutral-800">
                  <div className="text-lg font-extrabold text-white font-mono">
                    {summaryResult.workout.totalSets}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">Total Sets</div>
                </div>
                <div>
                  <div className="text-lg font-extrabold text-white font-mono">
                    {summaryResult.workout.totalReps}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">Total Reps</div>
                </div>
              </div>

              {/* Visual 'PR' (Personal Record) Badge Showcase */}
              {summaryResult.newPRs.length > 0 && (
                <PRSummaryShowcase
                  records={summaryResult.newPRs}
                  onCelebratePR={triggerPRNotification}
                />
              )}

              {/* First Workout in a New Difficulty Tier Level Up Banner */}
              {summaryResult.newDifficultyTier && (
                <button
                  type="button"
                  onClick={() =>
                    summaryResult.newDifficultyTier &&
                    triggerLevelUpTierNotification(summaryResult.newDifficultyTier)
                  }
                  className="w-full text-left p-3.5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-[#121826] to-amber-950/40 border border-cyan-400/50 hover:border-amber-300/60 shadow-[0_0_20px_-5px_rgba(34,211,238,0.25)] transition-all flex items-center justify-between gap-3 group active:scale-[0.99]"
                  title="Tap to replay Level Up confetti celebration"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-300 to-cyan-400 p-[1.5px] shrink-0">
                      <div className="w-full h-full rounded-[10px] bg-neutral-950 flex items-center justify-center">
                        <Award className="w-5 h-5 text-amber-300" />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-300/50 text-amber-200 text-[9px] font-black uppercase tracking-widest">
                          Level Up
                        </span>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300">
                          New Difficulty Tier
                        </span>
                      </div>
                      <div className="text-xs font-extrabold text-white capitalize">
                        First {summaryResult.newDifficultyTier} Tier Workout Completed!
                      </div>
                    </div>
                  </div>
                  <Sparkles className="w-4 h-4 text-amber-300 group-hover:scale-110 transition-transform shrink-0" />
                </button>
              )}

              {/* Session Exercise Breakdown with Visual PR Badges */}
              <div className="text-left space-y-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Session Exercise Summary
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    {summaryResult.workout.exercises.length} Exercises
                  </span>
                </div>

                <div className="space-y-2">
                  {summaryResult.workout.exercises.map((exItem, idx) => {
                    const exDef = exercises.find((e) => e.id === exItem.exerciseId);
                    const isHold = exDef?.isHold || false;

                    // Find any PRs achieved for this exercise in this workout
                    const repOrHoldPR = summaryResult.newPRs.find(
                      (p) =>
                        p.exerciseId === exItem.exerciseId &&
                        (p.unit === 'reps' || p.unit === 'seconds')
                    );
                    const weightPR = summaryResult.newPRs.find(
                      (p) =>
                        p.exerciseId === `${exItem.exerciseId}-weight` ||
                        (p.exerciseId === exItem.exerciseId &&
                          (p.unit === 'kg' || p.unit === 'lbs'))
                    );
                    const hasAnyPR = Boolean(repOrHoldPR || weightPR);

                    return (
                      <div
                        key={`${exItem.exerciseId}_${idx}`}
                        className={`p-3 rounded-2xl border transition-all ${
                          hasAnyPR
                            ? 'bg-gradient-to-r from-cyan-950/35 via-[#111622] to-[#12151c] border-cyan-400/50 shadow-[0_0_16px_-4px_rgba(34,211,238,0.25)]'
                            : 'bg-neutral-900/60 border-neutral-800/90'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                          <span className="text-xs font-bold text-white">
                            {exDef?.name || exItem.exerciseId}
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {repOrHoldPR && (
                              <PRBadgeChip
                                type={isHold ? 'hold' : 'reps'}
                                value={repOrHoldPR.value}
                                unit={repOrHoldPR.unit}
                                size="xs"
                              />
                            )}
                            {weightPR && (
                              <PRBadgeChip
                                type="weight"
                                value={`+${weightPR.value}`}
                                unit={weightPR.unit}
                                size="xs"
                              />
                            )}
                          </div>
                        </div>

                        <div className="space-y-1">
                          {exItem.sets
                            .filter((s) => s.completed)
                            .map((s) => {
                              const isRepPRSet =
                                repOrHoldPR &&
                                (isHold
                                  ? s.durationSec === repOrHoldPR.value
                                  : s.reps === repOrHoldPR.value);
                              const isWeightPRSet =
                                weightPR && s.weightKg === weightPR.value;

                              return (
                                <div
                                  key={s.id}
                                  className={`flex items-center justify-between text-[11px] font-mono px-2 py-1 rounded-lg ${
                                    isRepPRSet || isWeightPRSet
                                      ? 'bg-cyan-500/15 border border-cyan-400/30 text-cyan-200 font-bold'
                                      : 'text-slate-300 bg-neutral-950/50'
                                  }`}
                                >
                                  <span className="text-slate-400">Set #{s.setNumber}</span>
                                  <div className="flex items-center gap-2">
                                    <span>
                                      {s.weightKg && s.weightKg > 0
                                        ? `+${s.weightKg}${user.units === 'imperial' ? 'lbs' : 'kg'} × `
                                        : ''}
                                      {isHold
                                        ? `${s.durationSec || 0}s hold`
                                        : `${s.reps || 0} reps`}
                                    </span>
                                    {(isRepPRSet || isWeightPRSet) && (
                                      <span className="px-1.5 py-0.2 rounded bg-amber-400/20 border border-amber-300/50 text-amber-300 text-[9px] font-extrabold uppercase tracking-wider">
                                        PR SET
                                      </span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Logged Session Workout Notes */}
              {summaryResult.workout.notes && (
                <div className="text-left p-3.5 rounded-2xl bg-neutral-900/70 border border-neutral-800 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Workout Notes</span>
                  </div>
                  <p className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                    {summaryResult.workout.notes}
                  </p>
                </div>
              )}
            </div>

            <div className="pt-4 mt-2 border-t border-neutral-800/80">
              <button
                onClick={() => {
                  setSummaryResult(null);
                  setIsWorkoutModalOpen(false);
                }}
                className="w-full py-3 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
              >
                Continue to Dashboard
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
