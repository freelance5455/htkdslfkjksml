import React, { useState } from 'react';
import { MessageCircle, Phone, Copy, Check, Clock, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface WhatsAppCardProps {
  language: Language;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const WhatsAppCard: React.FC<WhatsAppCardProps> = ({ language, onShowToast }) => {
  const tr = t[language];
  const [copied, setCopied] = useState(false);
  const rawNumber = '03333997576';
  const internationalNumber = '923333997576';

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(rawNumber);
    setCopied(true);
    sounds.playClick();
    onShowToast(language === 'ur' ? 'نمبر کاپی ہو گیا ہے' : 'Phone number copied', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const openWhatsApp = () => {
    sounds.playClick();
    const message = encodeURIComponent(
      language === 'ur'
        ? 'السلام علیکم! مجھے AKS 668 پریمیم سسٹم کے حوالے سے رہنمائی چاہیے۔'
        : 'Hello AKS Support, I need assistance with the 668 SMS management system.'
    );
    window.open(`https://wa.me/${internationalNumber}?text=${message}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="card-cyber relative p-6 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] text-center transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-center gap-2 mb-2">
        <MessageCircle className="w-6 h-6 text-[#25D366]" />
        <h3 className="text-lg font-bold text-[#41eaff] tracking-wider m-0">
          {tr.whatsAppSupport}
        </h3>
      </div>

      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/40 text-[#50f6b0] text-xs font-semibold font-mono tracking-wider mb-3">
        <Clock className="w-3.5 h-3.5" />
        <span>{tr.supportAvailable}</span>
      </div>

      {/* Number Display with Copy */}
      <div className="my-2 flex items-center justify-center gap-2">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#4ceaff] font-mono tracking-widest drop-shadow-[0_0_12px_rgba(76,234,255,0.4)] m-0">
          0333 3997576
        </h2>
        <button
          type="button"
          onClick={handleCopyNumber}
          className="p-1.5 rounded-lg bg-[#0b2440] hover:bg-[#12365e] text-cyan-300 transition-colors"
          title="Copy phone number"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>

      <p className="text-xs text-[#9cb9d5] max-w-sm mx-auto mb-4">
        {language === 'ur'
          ? 'کسی بھی سوال، سم رجسٹریشن استفسار یا تکنیکی معاونت کے لیے براہ راست رابطہ کریں۔'
          : 'For any technical assistance, SIM inquiry queries or system help, contact our 24/7 team.'}
      </p>

      {/* Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-md mx-auto">
        <button
          type="button"
          onClick={openWhatsApp}
          className="w-full p-3.5 border-0 rounded-xl bg-gradient-to-r from-[#087a58] to-[#12c995] text-white font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(18,201,149,0.25)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{tr.openWhatsAppBtn}</span>
        </button>

        <a
          href={`tel:+${internationalNumber}`}
          onClick={() => sounds.playClick()}
          className="w-full p-3.5 rounded-xl border border-[#208fc0]/60 bg-[#0d2a4a] hover:bg-[#143a63] text-cyan-200 font-bold text-sm tracking-wide transition-all flex items-center justify-center gap-2 text-decoration-none"
        >
          <Phone className="w-4 h-4 text-cyan-400" />
          <span>{language === 'ur' ? 'کال کریں' : 'Direct Call'}</span>
        </a>
      </div>

      <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 mt-4">
        <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
        <span>Verified Support Line · Pakistan Telecom Direct Assistance</span>
      </div>
    </div>
  );
};
