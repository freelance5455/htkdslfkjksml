import React,{useState} from "react";
export default function OwnerApproval({open,onClose,onApprove}){
 const [otp,setOtp]=useState("");
 if(!open)return null;
 return <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-5">
  <div className="glass rounded-3xl p-7 w-full max-w-md"><h2 className="text-xl font-black">Awaiting Owner Approval</h2><p className="text-sm text-slate-400 mt-2">Critical action frozen. A mock 6-digit OTP was sent to the registered owner email.</p>
  <input value={otp} maxLength={6} onChange={e=>setOtp(e.target.value.replace(/\D/g,""))} placeholder="6-digit OTP" className="w-full mt-5 p-3 rounded-xl bg-black/20 border border-white/10 text-center tracking-[.5em]"/>
  <div className="flex gap-3 mt-4"><button onClick={onClose} className="flex-1 p-3 rounded-xl border border-white/10">Cancel</button><button disabled={otp.length!==6} onClick={()=>{onApprove();onClose()}} className="flex-1 p-3 rounded-xl bg-cyan-400 text-slate-950 font-bold disabled:opacity-30">Approve</button></div>
  </div></div>
}