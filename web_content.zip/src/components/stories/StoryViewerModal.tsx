import React, { useState, useEffect } from 'react';
import { StoriesGroup } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { X, ChevronLeft, ChevronRight, Eye, Send, Trash2, Heart, Flame } from 'lucide-react';

interface StoryViewerModalProps {
  group: StoriesGroup | null;
  onClose: () => void;
  onStoryDeleted: () => void;
}

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  group,
  onClose,
  onStoryDeleted
}) => {
  const { currentUser } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [replyText, setReplyText] = useState('');
  const [showViewers, setShowViewers] = useState(false);
  const [reactionSent, setReactionSent] = useState<string | null>(null);

  if (!group || !group.stories || group.stories.length === 0) return null;

  const currentStory = group.stories[currentIndex];
  const isAuthor = currentUser?.id === group.authorId;

  // Mark as viewed on mount / index change
  useEffect(() => {
    if (currentStory && currentUser) {
      api.viewStory(currentStory.id, currentUser.id).catch(() => {});
    }
  }, [currentStory?.id, currentUser?.id]);

  // Progress timer (5 seconds per story)
  useEffect(() => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < group.stories.length - 1) {
            setCurrentIndex(i => i + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [currentIndex, group.stories.length]);

  const handleNext = () => {
    if (currentIndex < group.stories.length - 1) {
      setCurrentIndex(i => i + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(i => i - 1);
    }
  };

  const handleSendReaction = async (emoji: string) => {
    if (!currentUser || !currentStory) return;
    try {
      await api.reactStory(currentStory.id, currentUser.id, emoji);
      setReactionSent(emoji);
      setTimeout(() => setReactionSent(null), 1500);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !currentUser || !currentStory) return;

    try {
      // Find or create direct conversation with author
      const convRes = await api.getOrCreateDirectConversation(currentUser.id, group.authorId);
      if (convRes.conversation) {
        await api.sendMessage({
          conversationId: convRes.conversation.id,
          senderId: currentUser.id,
          text: `Em resposta ao seu story: "${replyText.trim()}"`,
          type: 'text'
        });
      }
      setReplyText('');
      setReactionSent('Mensagem enviada!');
      setTimeout(() => setReactionSent(null), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async () => {
    if (!currentUser || !currentStory) return;
    if (!window.confirm('Tem a certeza de que deseja eliminar este story?')) return;

    try {
      await api.deleteStory(currentStory.id, currentUser.id);
      onStoryDeleted();
      onClose();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md">
      <div className="relative w-full max-w-sm h-[90vh] max-h-[750px] bg-slate-950 rounded-2xl overflow-hidden flex flex-col shadow-2xl border border-slate-800">

        {/* Progress Bars */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1.5">
          {group.stories.map((st, i) => (
            <div key={st.id} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-100 ease-linear"
                style={{
                  width: i === currentIndex ? `${progress}%` : i < currentIndex ? '100%' : '0%'
                }}
              />
            </div>
          ))}
        </div>

        {/* Top Header */}
        <div className="absolute top-6 left-3 right-3 z-30 flex items-center justify-between text-white drop-shadow">
          <div className="flex items-center gap-2.5">
            <img
              src={group.user?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
              alt={group.user?.name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-amber-500/80"
            />
            <div>
              <p className="text-xs font-bold leading-tight drop-shadow">{group.user?.name}</p>
              <p className="text-[10px] text-slate-300 drop-shadow">
                {new Date(currentStory.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {isAuthor && (
              <button
                onClick={handleDelete}
                className="p-1.5 text-red-400 hover:text-red-300 rounded-lg hover:bg-black/30 transition-colors"
                title="Eliminar Story"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-black/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Story Body Content */}
        <div className="relative flex-1 flex items-center justify-center bg-slate-900 select-none">
          {currentStory.mediaType === 'image' && currentStory.mediaUrl ? (
            <img
              src={currentStory.mediaUrl}
              alt="Story"
              className="w-full h-full object-cover"
            />
          ) : currentStory.mediaType === 'video' && currentStory.mediaUrl ? (
            <video
              src={currentStory.mediaUrl}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className={`w-full h-full flex items-center justify-center p-8 text-center ${currentStory.backgroundGradient || 'bg-gradient-to-tr from-red-600 via-amber-600 to-amber-400'}`}>
              <p className="text-xl sm:text-2xl font-bold text-white drop-shadow-md font-display">
                {currentStory.textContent}
              </p>
            </div>
          )}

          {/* Left / Right Tap zones */}
          <button
            onClick={handlePrev}
            className="absolute left-0 top-0 bottom-0 w-1/3 z-20 opacity-0 hover:opacity-20 flex items-center justify-start pl-2 text-white bg-gradient-to-r from-black/40 to-transparent"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-0 top-0 bottom-0 w-1/3 z-20 opacity-0 hover:opacity-20 flex items-center justify-end pr-2 text-white bg-gradient-to-l from-black/40 to-transparent"
          >
            <ChevronRight className="w-8 h-8" />
          </button>

          {/* Animated reaction pop */}
          {reactionSent && (
            <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none animate-in zoom-in-50 duration-200">
              <span className="text-4xl filter drop-shadow-lg">{reactionSent}</span>
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="p-3 bg-slate-950/90 border-t border-slate-800 text-white z-30">
          {isAuthor ? (
            <div className="flex items-center justify-between text-xs text-slate-300">
              <button
                onClick={() => setShowViewers(prev => !prev)}
                className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-white transition-colors"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>{currentStory.views.length} Visualizações</span>
              </button>
              <div className="flex items-center gap-1">
                {currentStory.reactions.map((r, i) => (
                  <span key={i} className="text-sm">{r.emoji}</span>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {/* Quick Emojis */}
              <div className="flex items-center justify-around pb-1">
                {['❤️', '🔥', '👏🏾', '😂', '🇦🇴', '🙌'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleSendReaction(emoji)}
                    className="text-xl hover:scale-125 active:scale-95 transition-transform"
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSendReply} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder={`Responder a ${group.user?.name?.split(' ')[0]}...`}
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-full px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center hover:bg-amber-400 disabled:opacity-40 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}

          {/* Viewers list popover for Author */}
          {showViewers && (
            <div className="mt-2 pt-2 border-t border-slate-800 max-h-32 overflow-y-auto space-y-1">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Pessoas que viram:</p>
              {currentStory.views.length === 0 ? (
                <p className="text-xs text-slate-500 py-1">Ainda sem visualizações.</p>
              ) : (
                currentStory.views.map((v, i) => (
                  <div key={i} className="flex items-center justify-between text-xs py-1">
                    <span className="text-slate-200">Utilizador {v.userId.substring(0, 6)}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(v.viewedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
