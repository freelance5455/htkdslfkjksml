import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { X, Image as ImageIcon, Type, Sparkles, RefreshCw } from 'lucide-react';

interface CreateStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStoryCreated: () => void;
}

const GRADIENTS = [
  { name: 'Kwanza Sunset', class: 'bg-gradient-to-tr from-red-600 via-amber-600 to-amber-400' },
  { name: 'Baía de Luanda', class: 'bg-gradient-to-tr from-slate-900 via-blue-900 to-cyan-500' },
  { name: 'Samakaka Red', class: 'bg-gradient-to-tr from-black via-red-700 to-amber-500' },
  { name: 'Huambo Garden', class: 'bg-gradient-to-tr from-emerald-950 via-emerald-800 to-teal-500' },
  { name: 'Namibe Desert', class: 'bg-gradient-to-tr from-stone-900 via-amber-800 to-yellow-600' }
];

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({
  isOpen,
  onClose,
  onStoryCreated
}) => {
  const { currentUser } = useAuth();
  const [tab, setTab] = useState<'media' | 'text'>('media');
  const [textContent, setTextContent] = useState('');
  const [selectedGradient, setSelectedGradient] = useState(GRADIENTS[0].class);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [privacy, setPrivacy] = useState<'public' | 'friends' | 'private'>('public');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !currentUser) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    setMediaType(isVideo ? 'video' : 'image');

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploadRes = await api.uploadFile(base64, file.name);
        setMediaUrl(uploadRes.url);
      } catch (err: any) {
        setErrorMsg('Erro ao carregar mídia: ' + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (tab === 'media' && !mediaUrl) {
      setErrorMsg('Selecione uma foto ou vídeo para publicar.');
      return;
    }

    if (tab === 'text' && !textContent.trim()) {
      setErrorMsg('Escreva o texto do seu story.');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.createStory({
        authorId: currentUser.id,
        mediaUrl: tab === 'media' ? (mediaUrl || undefined) : undefined,
        mediaType: tab === 'media' ? mediaType : 'text',
        textContent: tab === 'text' ? textContent.trim() : undefined,
        backgroundGradient: tab === 'text' ? selectedGradient : undefined,
        privacy
      });

      onStoryCreated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95">

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/50">
          <h3 className="font-bold text-sm text-white font-display flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Criar Story (Desaparece em 24h)</span>
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-800 text-xs font-medium">
          <button
            type="button"
            onClick={() => setTab('media')}
            className={`flex-1 py-3 flex items-center justify-center gap-2 border-b-2 transition-colors ${tab === 'media' ? 'border-amber-400 text-amber-400 font-semibold bg-amber-500/5' : 'border-transparent text-slate-400 hover:text-white'}`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Foto / Vídeo</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('text')}
            className={`flex-1 py-3 flex items-center justify-center gap-2 border-b-2 transition-colors ${tab === 'text' ? 'border-amber-400 text-amber-400 font-semibold bg-amber-500/5' : 'border-transparent text-slate-400 hover:text-white'}`}
          >
            <Type className="w-4 h-4" />
            <span>Cartão de Texto</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/60">{errorMsg}</p>
          )}

          {tab === 'media' ? (
            <div>
              {mediaUrl ? (
                <div className="relative w-full h-60 bg-slate-950 rounded-xl overflow-hidden border border-slate-800">
                  {mediaType === 'image' ? (
                    <img src={mediaUrl} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <video src={mediaUrl} controls className="w-full h-full object-cover" />
                  )}
                  <button
                    type="button"
                    onClick={() => setMediaUrl(null)}
                    className="absolute top-2 right-2 p-1.5 bg-black/70 hover:bg-black rounded-lg text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-56 border-2 border-dashed border-slate-700 hover:border-amber-500/80 rounded-2xl cursor-pointer bg-slate-950 hover:bg-slate-950/80 transition-colors p-4">
                  <ImageIcon className="w-10 h-10 text-amber-400 mb-2" />
                  <span className="text-xs font-semibold text-slate-200">Escolha uma foto ou vídeo</span>
                  <span className="text-[11px] text-slate-500 mt-1">Galeria, câmera ou ficheiro</span>
                  <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {/* Preview Box */}
              <div className={`w-full h-52 rounded-2xl ${selectedGradient} flex items-center justify-center p-6 text-center shadow-inner`}>
                <p className="text-lg font-bold text-white font-display break-words max-w-full drop-shadow">
                  {textContent || 'Escreva a sua mensagem aqui...'}
                </p>
              </div>

              <div>
                <textarea
                  rows={2}
                  placeholder="Escreva algo inspirador..."
                  value={textContent}
                  onChange={(e) => setTextContent(e.target.value)}
                  maxLength={160}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 resize-none"
                />
              </div>

              {/* Gradient Presets */}
              <div>
                <p className="text-[11px] font-medium text-slate-400 mb-1.5">Escolher Tema Visual:</p>
                <div className="flex items-center gap-2">
                  {GRADIENTS.map((g) => (
                    <button
                      key={g.name}
                      type="button"
                      onClick={() => setSelectedGradient(g.class)}
                      className={`w-7 h-7 rounded-full ${g.class} ring-2 transition-all ${selectedGradient === g.class ? 'ring-amber-400 scale-110' : 'ring-transparent'}`}
                      title={g.name}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Privacy */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Privacidade do Story</label>
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              <option value="public">Público (Todos no Angola Connect)</option>
              <option value="friends">Apenas Amigos</option>
              <option value="private">Privado</option>
            </select>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {isSubmitting ? (
              <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
            ) : (
              <span>Partilhar no Story 🇦🇴</span>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
