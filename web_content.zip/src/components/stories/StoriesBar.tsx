import React from 'react';
import { StoriesGroup } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { Plus } from 'lucide-react';

interface StoriesBarProps {
  storiesGrouped: StoriesGroup[];
  onOpenStory: (group: StoriesGroup) => void;
  onOpenCreateStory: () => void;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({
  storiesGrouped,
  onOpenStory,
  onOpenCreateStory
}) => {
  const { currentUser } = useAuth();

  // Check if current user has an active story
  const myStoryGroup = storiesGrouped.find(g => g.authorId === currentUser?.id);

  return (
    <div className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl p-4 mb-5 overflow-hidden">
      <div className="flex items-center gap-3.5 overflow-x-auto pb-1 scrollbar-none">

        {/* Add story card / button */}
        <button
          onClick={onOpenCreateStory}
          className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-none"
        >
          <div className="relative w-16 h-16 rounded-full p-0.5 border-2 border-dashed border-amber-500/60 hover:border-amber-400 flex items-center justify-center transition-colors bg-slate-950">
            {currentUser ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-full h-full rounded-full object-cover group-hover:scale-105 transition-transform"
              />
            ) : (
              <div className="w-full h-full rounded-full bg-slate-800" />
            )}
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-md ring-2 ring-slate-900">
              <Plus className="w-4 h-4 stroke-[3]" />
            </div>
          </div>
          <span className="text-[11px] font-medium text-slate-300 group-hover:text-amber-400 transition-colors w-16 text-center truncate">
            Criar Story
          </span>
        </button>

        {/* List of active stories */}
        {storiesGrouped.map((group) => {
          const isMe = group.authorId === currentUser?.id;
          const user = group.user;
          const displayName = isMe ? 'O Meu Story' : (user?.name ? user.name.split(' ')[0] : 'Utilizador');

          return (
            <button
              key={group.authorId}
              onClick={() => onOpenStory(group)}
              className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-none"
            >
              <div className={`w-16 h-16 rounded-full p-0.5 transition-all ${
                group.hasUnseen
                  ? 'bg-gradient-to-tr from-red-600 via-amber-500 to-amber-400 shadow-md shadow-amber-500/20 group-hover:scale-105'
                  : 'bg-slate-700/80 group-hover:bg-slate-600'
              }`}>
                <div className="w-full h-full rounded-full p-0.5 bg-slate-950">
                  <img
                    src={user?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
                    alt={user?.name || ''}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
              </div>
              <span className={`text-[11px] font-medium w-16 text-center truncate ${group.hasUnseen ? 'text-white font-semibold' : 'text-slate-400'}`}>
                {displayName}
              </span>
            </button>
          );
        })}

      </div>
    </div>
  );
};
