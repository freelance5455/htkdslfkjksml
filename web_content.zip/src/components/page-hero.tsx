import type { CSSProperties, ReactNode } from "react";
import { LogoMark } from "@/components/logo-mark";

/** Small gold eyebrow label with the lattice emblem, used above section titles. */
export function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return (
    <p
      className={`inline-flex items-center gap-3 text-sm font-medium tracking-wide ${
        light ? "text-gold-light" : "text-gold"
      }`}
    >
      <LogoMark className="size-4" />
      {children}
    </p>
  );
}

/** Ivory wave that separates a dark hero from the light page body. */
export function WaveDivider({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 1440 80"
      preserveAspectRatio="none"
      className={`pointer-events-none absolute inset-x-0 -bottom-px block h-10 w-full sm:h-16 ${className}`}
      aria-hidden="true"
    >
      <path d="M0 80V40C240 40 420 0 720 0s480 40 720 40v40Z" fill="#F8F7F4" />
    </svg>
  );
}

type PageHeroProps = {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
};

/** Dark navy hero used at the top of every inner page (matches the homepage hero). */
export function PageHero({ eyebrow, title, description, children }: PageHeroProps) {
  return (
    <section className="relative isolate overflow-hidden bg-navy-deep pt-36 pb-28 text-ivory sm:pt-44 sm:pb-36">
      <div
        className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_70%_60%_at_25%_45%,rgba(49,75,117,0.9),transparent_70%),radial-gradient(ellipse_50%_40%_at_25%_30%,rgba(182,154,105,0.28),transparent_70%),linear-gradient(180deg,#0F1828_0%,#17243A_60%,#1B2C48_100%)]"
        aria-hidden="true"
      />
      <div className="pattern-lattice mask-radial absolute inset-0 -z-10 opacity-[0.09]" aria-hidden="true" />
      <div className="grain absolute inset-0 -z-10 opacity-[0.06] mix-blend-overlay" aria-hidden="true" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="hero-enter" style={{ "--enter-delay": "100ms" } as CSSProperties}>
          <span className="mb-6 inline-flex items-center gap-3 rounded-full border border-gold/30 bg-navy/40 px-4 py-1.5 text-sm text-gold-light backdrop-blur">
            <LogoMark className="size-4" />
            {eyebrow}
          </span>
        </div>
        <h1
          className="hero-enter font-serif text-6xl leading-[1.2] font-bold sm:text-7xl lg:text-8xl"
          style={{ "--enter-delay": "250ms" } as CSSProperties}
        >
          {title}
        </h1>
        {description && (
          <p
            className="hero-enter mt-6 max-w-2xl text-lg leading-9 text-ivory/80 sm:text-xl"
            style={{ "--enter-delay": "400ms" } as CSSProperties}
          >
            {description}
          </p>
        )}
        {children && (
          <div
            className="hero-enter mt-10 flex flex-wrap gap-4"
            style={{ "--enter-delay": "550ms" } as CSSProperties}
          >
            {children}
          </div>
        )}
      </div>
      <WaveDivider />
    </section>
  );
}
