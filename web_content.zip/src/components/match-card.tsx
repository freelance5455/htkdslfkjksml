import Link from "next/link";
import { TeamLogo } from "./cricket";
import { DeleteMatchButton } from "./match-admin";

export type MatchCardData = {
  id: string;
  teamA: string;
  teamB: string;
  logoA?: string;
  logoB?: string;
  format: string;
  overs: number;
  venue: string | null;
  date: string;
  status: string;
  result: string | null;
  playerOfMatch: string | null;
  scores: { team: string; line: string }[];
};

export function MatchListCard({ m, showScorer }: { m: MatchCardData; showScorer?: boolean }) {
  const date = new Date(m.date);
  return (
    <div className="mc-card flex flex-col gap-3 px-4 py-4">
      <div className="flex items-center justify-between">
        <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-black tracking-widest text-emerald-300">
          {m.format} · {m.overs} OV
        </span>
        <span
          className={`rounded-md px-2 py-0.5 text-[10px] font-black tracking-widest ${
            m.status === "completed"
              ? "bg-slate-700 text-slate-200"
              : "bg-red-500/15 text-red-400"
          }`}
        >
          {m.status === "completed" ? "RESULT" : "LIVE"}
        </span>
      </div>

      <div className="space-y-2">
        {[
          { team: m.teamA, logo: m.logoA },
          { team: m.teamB, logo: m.logoB },
        ].map(({ team, logo }) => {
          const score = m.scores.find((s) => s.team === team);
          return (
            <div key={team} className="flex items-center gap-2">
              <TeamLogo name={team} logo={logo} size={28} />
              <span className="flex-1 truncate text-sm font-bold">{team}</span>
              <span className="text-sm font-black text-emerald-400">{score?.line ?? "—"}</span>
            </div>
          );
        })}
      </div>

      <p className="text-xs text-slate-500">
        {m.venue ? `${m.venue} · ` : ""}
        {date.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
      </p>
      <p className="text-xs font-semibold text-slate-300">{m.result ?? "Match in progress"}</p>
      {m.playerOfMatch && (
        <p className="text-xs text-amber-300">🏆 Player of the Match: {m.playerOfMatch}</p>
      )}

      <div className="mt-auto flex gap-2 pt-2">
        <Link
          href={`/match?id=${m.id}`}
          className="mc-btn flex-1 rounded-lg border border-slate-700 px-3 py-2 text-center text-sm font-bold hover:bg-slate-800"
        >
          {m.status === "completed" ? "VIEW SCORECARD" : "LIVE VIEW"}
        </Link>
        {showScorer && m.status !== "completed" && (
          <Link
            href={`/scorer?id=${m.id}`}
            className="mc-btn flex-1 rounded-lg bg-emerald-500 px-3 py-2 text-center text-sm font-black text-slate-950 hover:bg-emerald-400"
          >
            RESUME MATCH
          </Link>
        )}
        <DeleteMatchButton id={m.id} title={`${m.teamA} vs ${m.teamB}`} />
      </div>
    </div>
  );
}
