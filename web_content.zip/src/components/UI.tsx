import { cn } from "@/utils/cn";
import type { ReactNode } from "react";

export function Card({
  title,
  icon,
  desc,
  children,
  action,
  className,
}: {
  title?: string;
  icon?: ReactNode;
  desc?: string;
  children?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-3xl border border-white/10 bg-slate-900/60 p-4 shadow-lg shadow-black/30 backdrop-blur",
        className,
      )}
    >
      {(title || action) && (
        <header className="mb-3 flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            {icon && (
              <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-lime-400/15 text-base">
                {icon}
              </span>
            )}
            <div>
              {title && <h3 className="text-sm font-semibold tracking-wide text-slate-100">{title}</h3>}
              {desc && <p className="mt-0.5 text-xs leading-relaxed text-slate-400">{desc}</p>}
            </div>
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  suffix = "%",
  hint,
  accent = "lime",
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  suffix?: string;
  hint?: string;
  accent?: "lime" | "cyan" | "amber" | "rose";
  format?: (v: number) => string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  const colors = {
    lime: "from-lime-300 to-emerald-400 text-lime-300",
    cyan: "from-cyan-300 to-sky-400 text-cyan-300",
    amber: "from-amber-300 to-orange-400 text-amber-300",
    rose: "from-rose-300 to-pink-500 text-rose-300",
  }[accent];

  const set = (v: number) => onChange(Math.min(max, Math.max(min, Math.round(v / step) * step)));

  return (
    <div className="select-none">
      <div className="flex items-baseline justify-between gap-2">
        <label className="text-[13px] font-medium text-slate-200">{label}</label>
        <span className={cn("font-mono text-[13px] font-semibold tabular-nums", colors.split(" ")[1])}>
          {format ? format(value) : value}
          {suffix}
        </span>
      </div>
      {hint && <p className="mb-1.5 mt-0.5 text-[11px] leading-snug text-slate-500">{hint}</p>}
      <div className="flex items-center gap-2">
        <button
          type="button"
          aria-label={`Diminuir ${label}`}
          onPointerDown={() => set(value - step)}
          className="h-9 w-9 shrink-0 rounded-xl border border-white/10 bg-white/5 text-lg leading-none text-slate-300 active:bg-white/15"
        >
          −
        </button>
        <div className="relative h-9 flex-1">
          <div className="absolute inset-x-0 top-1/2 h-2 -translate-y-1/2 overflow-hidden rounded-full bg-white/10">
            <div
              className={cn("h-full rounded-full bg-gradient-to-r", colors.split(" ")[0])}
              style={{ width: `${pct}%` }}
            />
          </div>
          <input
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            className="absolute inset-0 h-full w-full cursor-pointer appearance-none bg-transparent
              [&::-webkit-slider-thumb]:h-7 [&::-webkit-slider-thumb]:w-7 [&::-webkit-slider-thumb]:appearance-none
              [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2
              [&::-webkit-slider-thumb]:border-slate-900 [&::-webkit-slider-thumb]:bg-white
              [&::-webkit-slider-thumb]:shadow-[0_0_0_4px_rgba(0,0,0,0.25)]
              [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:rounded-full
              [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-slate-900 [&::-moz-range-thumb]:bg-white"
          />
        </div>
        <button
          type="button"
          aria-label={`Aumentar ${label}`}
          onPointerDown={() => set(value + step)}
          className="h-9 w-9 shrink-0 rounded-xl border border-white/10 bg-white/5 text-lg leading-none text-slate-300 active:bg-white/15"
        >
          +
        </button>
      </div>
    </div>
  );
}

export function Toggle({
  label,
  desc,
  checked,
  onChange,
  icon,
}: {
  label: string;
  desc?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  icon?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn(
        "flex w-full items-center justify-between gap-3 rounded-2xl border px-3 py-2.5 text-left transition",
        checked
          ? "border-lime-400/40 bg-lime-400/10"
          : "border-white/10 bg-white/[0.03] active:bg-white/10",
      )}
    >
      <span className="flex items-center gap-2.5">
        {icon && <span className="text-base">{icon}</span>}
        <span>
          <span className="block text-[13px] font-medium text-slate-100">{label}</span>
          {desc && <span className="mt-0.5 block text-[11px] leading-snug text-slate-400">{desc}</span>}
        </span>
      </span>
      <span
        className={cn(
          "relative h-6 w-11 shrink-0 rounded-full transition",
          checked ? "bg-lime-400" : "bg-slate-700",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
            checked ? "left-[22px]" : "left-0.5",
          )}
        />
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label?: string;
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div>
      {label && <div className="mb-1.5 text-[13px] font-medium text-slate-200">{label}</div>}
      <div className="flex flex-wrap gap-1.5 rounded-2xl border border-white/10 bg-black/30 p-1">
        {options.map((o) => (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={cn(
              "flex-1 rounded-xl px-2.5 py-1.5 text-xs font-semibold transition",
              value === o.value
                ? "bg-lime-400 text-slate-950 shadow"
                : "text-slate-300 active:bg-white/10",
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = "ghost",
  className,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "ghost" | "primary" | "danger";
  className?: string;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition active:scale-[0.97]",
        variant === "primary" && "bg-lime-400 text-slate-950 shadow-lg shadow-lime-500/20",
        variant === "danger" && "bg-rose-500/90 text-white",
        variant === "ghost" && "border border-white/10 bg-white/5 text-slate-200 active:bg-white/10",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Stat({
  label,
  value,
  tone = "slate",
}: {
  label: string;
  value: ReactNode;
  tone?: "slate" | "lime" | "cyan" | "amber" | "rose";
}) {
  const tones = {
    slate: "text-slate-100",
    lime: "text-lime-300",
    cyan: "text-cyan-300",
    amber: "text-amber-300",
    rose: "text-rose-300",
  }[tone];
  return (
    <div className="rounded-2xl border border-white/10 bg-black/25 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className={cn("mt-0.5 font-mono text-sm font-semibold tabular-nums", tones)}>{value}</div>
    </div>
  );
}
