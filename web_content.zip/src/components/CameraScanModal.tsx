import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, Image as ImageIcon, Sparkles, Check, RefreshCw, Zap, ShieldAlert } from 'lucide-react';
import { MealItem, TierLevel } from '../types';
import { PRESET_SCAN_SAMPLES } from '../data/sampleMeals';
import { analyzeFoodImageOrVoice, AnalysisResult } from '../utils/aiVision';
import confetti from 'canvas-confetti';

interface CameraScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMeal: (meal: MealItem) => void;
  currentTier: TierLevel;
  scansUsedToday: number;
  dailyScanLimit: number;
  onOpenPaywall: () => void;
}

export const CameraScanModal: React.FC<CameraScanModalProps> = ({
  isOpen,
  onClose,
  onAddMeal,
  currentTier,
  scansUsedToday,
  dailyScanLimit,
  onOpenPaywall,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<AnalysisResult | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const isLimitReached = currentTier < 3 && scansUsedToday >= dailyScanLimit;

  // Start camera when modal opens
  useEffect(() => {
    if (isOpen && !selectedImage && !scanResult && !isLimitReached) {
      startCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, selectedImage, scanResult, isLimitReached]);

  const startCamera = async () => {
    setStreamError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        mediaStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setCameraActive(true);
      } else {
        setStreamError('الكاميرا غير مدعومة في هذا المتصفح، يمكنك استخدام رفع صورة أو النماذج الجاهزة.');
      }
    } catch {
      setStreamError('لم نتمكن من الوصول لكاميرا الجهاز. يمكنك رفع صورة أو تجربة الأطباق الجاهزة.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setCameraActive(false);
  };

  const captureFrame = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setSelectedImage(dataUrl);
        stopCamera();
        runAnalysis({ imageSrc: dataUrl });
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setSelectedImage(dataUrl);
        stopCamera();
        runAnalysis({ imageSrc: dataUrl });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (preset: typeof PRESET_SCAN_SAMPLES[0]) => {
    setSelectedImage(preset.imageUrl);
    stopCamera();
    runAnalysis({ sampleMeal: preset });
  };

  const runAnalysis = async (params: { imageSrc?: string; sampleMeal?: any }) => {
    setIsScanning(true);
    setScanResult(null);
    try {
      const res = await analyzeFoodImageOrVoice(params);
      setScanResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleConfirmAddMeal = () => {
    if (!scanResult) return;
    const newMeal: MealItem = {
      id: `meal-${Date.now()}`,
      name: scanResult.mealName,
      nameEn: scanResult.mealNameEn,
      category: scanResult.category,
      imageUrl: selectedImage || '/src/assets/images/hero_food_scanner_1791967840424.jpg',
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      weightGrams: scanResult.weightGrams,
      macros: scanResult.macros,
      healthScore: scanResult.healthScore,
      aiInsight: scanResult.aiInsight,
      aiSwaps: scanResult.aiSwaps,
      ingredients: scanResult.ingredients,
    };

    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
    });

    onAddMeal(newMeal);
    handleReset();
    onClose();
  };

  const handleReset = () => {
    setSelectedImage(null);
    setScanResult(null);
    setIsScanning(false);
    startCamera();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">مسح الوجبة بالذكاء الاصطناعي (Cal AI Vision)</h2>
              <p className="text-xs text-slate-400">
                {currentTier >= 3 ? (
                  <span className="text-emerald-400 font-semibold">مسحات غير محدودة (المستوى {currentTier})</span>
                ) : (
                  <span className="tabular-nums">
                    المسحات اليومية: {scansUsedToday} من {dailyScanLimit}
                  </span>
                )}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scan limit reached warning */}
        {isLimitReached ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white">استنفدت المسحات المجانية لهذا اليوم (3/3)</h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              وفقاً لنظام التطبيق، يتطلب المسح غير المحدود الترقية إلى <span className="text-amber-400 font-semibold">المستوى 3</span> إما عبر الاشتراك أو عبر اشتراك أصدقائك المدعوين!
            </p>
            <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => {
                  onClose();
                  onOpenPaywall();
                }}
                className="py-2.5 px-6 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-transform active:scale-95 cursor-pointer"
              >
                فتح المستوى 3 والمسح غير المحدود
              </button>
              <button
                onClick={onClose}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm transition-colors cursor-pointer"
              >
                لاحقاً
              </button>
            </div>
          </div>
        ) : (
          <div className="p-5 space-y-4">
            {/* Viewfinder or Image preview */}
            {!scanResult && (
              <div className="relative aspect-4/3 w-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                {selectedImage ? (
                  <img src={selectedImage} alt="الطبق الممسوح" className="w-full h-full object-cover" />
                ) : cameraActive ? (
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    autoPlay
                    className="w-full h-full object-cover mirror"
                  />
                ) : (
                  <div className="text-center p-6 space-y-3">
                    <ImageIcon className="w-10 h-10 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400 max-w-xs">{streamError || 'جاري تجهيز الكاميرا أو يمكنك رفع صورة'}</p>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      اختيار صورة من الجهاز
                    </button>
                  </div>
                )}

                {/* Viewfinder Overlay Targeting Grid */}
                <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
                  <div className="flex justify-between items-start">
                    <div className="w-8 h-8 border-t-2 border-r-2 border-emerald-400 rounded-tr-lg" />
                    <div className="w-8 h-8 border-t-2 border-l-2 border-emerald-400 rounded-tl-lg" />
                  </div>

                  {/* Scanning Laser Animation */}
                  {isScanning && (
                    <div className="w-full h-0.5 bg-emerald-400 shadow-[0_0_12px_#34d399] animate-bounce" />
                  )}

                  <div className="flex justify-between items-end">
                    <div className="w-8 h-8 border-b-2 border-r-2 border-emerald-400 rounded-br-lg" />
                    <div className="w-8 h-8 border-b-2 border-l-2 border-emerald-400 rounded-bl-lg" />
                  </div>
                </div>

                {/* Scanning Spinner Overlay */}
                {isScanning && (
                  <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs flex flex-col items-center justify-center gap-3">
                    <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
                    <div className="text-sm font-semibold text-white">جاري تحليل الطبق بالذكاء الاصطناعي...</div>
                    <div className="text-xs text-slate-400">تقدير الحجم · حساب الماكروز · تقييم الصحة الغذائية</div>
                  </div>
                )}
              </div>
            )}

            {/* Scan Actions if not showing result */}
            {!scanResult && (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-4">
                  {cameraActive && (
                    <button
                      onClick={captureFrame}
                      disabled={isScanning}
                      className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
                      title="التقاط صورة للطبق"
                    >
                      <Camera className="w-7 h-7" />
                    </button>
                  )}

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <ImageIcon className="w-4 h-4 text-emerald-400" />
                    <span>رفع صورة من الاستوديو</span>
                  </button>
                </div>

                {/* Preset sample plates for instant testing */}
                <div className="pt-2">
                  <div className="text-xs font-semibold text-slate-400 mb-2">
                    أو جرب مسح أحد الأطباق النموذجية فوراً:
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {PRESET_SCAN_SAMPLES.map((sample, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSelectPreset(sample)}
                        className="flex items-center gap-2.5 p-2 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 rounded-xl text-right transition-colors cursor-pointer group"
                      >
                        <img
                          src={sample.imageUrl}
                          alt={sample.name}
                          className="w-12 h-12 rounded-lg object-cover shrink-0 group-hover:scale-105 transition-transform"
                        />
                        <div className="overflow-hidden">
                          <div className="text-xs font-bold text-slate-200 truncate">{sample.name}</div>
                          <div className="text-[11px] text-emerald-400 tabular-nums">
                            {sample.macros.calories} كالوري · {sample.macros.protein}غ بروتين
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Analysis Result Screen */}
            {scanResult && (
              <div className="space-y-4">
                <div className="flex gap-4 items-start">
                  {selectedImage && (
                    <img
                      src={selectedImage}
                      alt={scanResult.mealName}
                      className="w-24 h-24 rounded-xl object-cover shrink-0 border border-slate-800"
                    />
                  )}
                  <div className="flex-grow">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                        تم التعرف بنجاح (دقة {Math.round(scanResult.confidence * 100)}%)
                      </span>
                      <span className="text-xs text-slate-400 tabular-nums">
                        الوزن المقدر: {scanResult.weightGrams}غ
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white mt-0.5">{scanResult.mealName}</h3>
                    <p className="text-xs text-slate-400">{scanResult.mealNameEn}</p>
                    
                    {/* Health score badge */}
                    <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/60 border border-emerald-500/30 rounded-lg text-xs font-bold text-emerald-400">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>درجة الجودة الغذائية: {scanResult.healthScore} / 100</span>
                    </div>
                  </div>
                </div>

                {/* Macro summary cards */}
                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-white tabular-nums">{scanResult.macros.calories}</div>
                    <div className="text-[10px] text-slate-400">سعرة حرارية</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-rose-400 tabular-nums">{scanResult.macros.protein}غ</div>
                    <div className="text-[10px] text-slate-400">بروتين</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-amber-400 tabular-nums">{scanResult.macros.carbs}غ</div>
                    <div className="text-[10px] text-slate-400">كاربوهيدرات</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-base font-extrabold text-sky-400 tabular-nums">{scanResult.macros.fat}غ</div>
                    <div className="text-[10px] text-slate-400">دهون صحية</div>
                  </div>
                </div>

                {/* Micronutrients for tier 2+ */}
                <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-300">المغذيات الدقيقة المفصلة:</span>
                    {currentTier < 2 && (
                      <span className="text-[11px] text-amber-400">ميزة المستوى 2 وفوق</span>
                    )}
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-[11px] text-slate-300">
                    <div>ألياف: <span className="font-bold text-white tabular-nums">{scanResult.macros.fiber}غ</span></div>
                    <div>سكريات: <span className="font-bold text-white tabular-nums">{scanResult.macros.sugar}غ</span></div>
                    <div>صوديوم: <span className="font-bold text-white tabular-nums">{scanResult.macros.sodium}مغ</span></div>
                    <div>دهون مشبعة: <span className="font-bold text-white tabular-nums">{scanResult.macros.saturatedFat}غ</span></div>
                  </div>
                </div>

                {/* AI Insight */}
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-400 mb-1">
                    <Zap className="w-3.5 h-3.5" />
                    <span>تحليل Cal AI الذكي:</span>
                  </div>
                  <p>{scanResult.aiInsight}</p>
                </div>

                {/* Confirm Add Meal */}
                <div className="pt-2 flex gap-3">
                  <button
                    onClick={handleConfirmAddMeal}
                    className="flex-1 py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-transform active:scale-98 cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>إضافة الوجبة إلى يومي</span>
                  </button>
                  <button
                    onClick={handleReset}
                    className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>مسح آخر</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
