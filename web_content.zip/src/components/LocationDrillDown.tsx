import React, { useState, useMemo } from 'react';
import { INDIA_STATES_AND_UTS } from '../data/indiaLocations';
import { JobCategory, JobPosting } from '../types/job';
import { JobCard } from './JobCard';
import { useTheme } from '../context/ThemeContext';
import {
  MapPin,
  Search,
  ChevronRight,
  Layers,
  ArrowLeft,
  RotateCcw,
  Briefcase,
  SlidersHorizontal,
  Building2
} from 'lucide-react';

interface LocationDrillDownProps {
  jobs: JobPosting[];
  savedJobIds: string[];
  onToggleSave: (jobId: string) => void;
  onOpenDetail: (job: JobPosting) => void;
  onReportJob?: (job: JobPosting) => void;
  initialState?: string;
  initialDistrict?: string;
  initialCategory?: JobCategory;
}

const CATEGORIES: JobCategory[] = [
  'All',
  'Government Jobs',
  'Private Jobs',
  'Latest Jobs',
  'ITI Jobs',
  'Diploma Jobs',
  'Graduate Jobs',
  'Railway Jobs',
  'Banking Jobs',
  'Defence Jobs',
  'Apprenticeship Jobs'
];

export const LocationDrillDown: React.FC<LocationDrillDownProps> = ({
  jobs,
  savedJobIds,
  onToggleSave,
  onOpenDetail,
  onReportJob,
  initialState = '',
  initialDistrict = '',
  initialCategory = 'All'
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Step 1: State, Step 2: District, Step 3: Category, Step 4: Results
  const [currentStep, setCurrentStep] = useState<number>(
    initialDistrict ? 3 : initialState ? 2 : 1
  );

  const [selectedState, setSelectedState] = useState<string>(initialState);
  const [selectedDistrict, setSelectedDistrict] = useState<string>(initialDistrict);
  const [selectedCategory, setSelectedCategory] = useState<JobCategory>(initialCategory);

  const [stateSearch, setStateSearch] = useState('');
  const [districtSearch, setDistrictSearch] = useState('');

  // Selected State object
  const activeStateObj = useMemo(() => {
    return INDIA_STATES_AND_UTS.find(
      s => s.name.toLowerCase() === selectedState.toLowerCase()
    );
  }, [selectedState]);

  // Filtered States
  const filteredStates = useMemo(() => {
    if (!stateSearch.trim()) return INDIA_STATES_AND_UTS;
    return INDIA_STATES_AND_UTS.filter(s =>
      s.name.toLowerCase().includes(stateSearch.toLowerCase()) ||
      s.code.toLowerCase().includes(stateSearch.toLowerCase())
    );
  }, [stateSearch]);

  // Filtered Districts for selected state
  const availableDistricts = useMemo(() => {
    if (!activeStateObj) return [];
    return activeStateObj.districts;
  }, [activeStateObj]);

  const filteredDistricts = useMemo(() => {
    if (!districtSearch.trim()) return availableDistricts;
    return availableDistricts.filter(d =>
      d.toLowerCase().includes(districtSearch.toLowerCase())
    );
  }, [availableDistricts, districtSearch]);

  // Final Filtered Jobs for Step 4
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // State matching
      const matchState = !selectedState || selectedState === 'All'
        ? true
        : job.state.toLowerCase() === selectedState.toLowerCase();

      // District matching
      const matchDistrict = !selectedDistrict || selectedDistrict === 'All Districts'
        ? true
        : job.district.toLowerCase() === selectedDistrict.toLowerCase();

      // Category matching
      const matchCategory = selectedCategory === 'All'
        ? true
        : job.category.includes(selectedCategory);

      return matchState && matchDistrict && matchCategory;
    });
  }, [jobs, selectedState, selectedDistrict, selectedCategory]);

  // Fallback jobs from same state if no specific district jobs
  const stateLevelJobs = useMemo(() => {
    if (!selectedState) return [];
    return jobs.filter(job => {
      const matchState = job.state.toLowerCase() === selectedState.toLowerCase();
      const matchCategory = selectedCategory === 'All' ? true : job.category.includes(selectedCategory);
      return matchState && matchCategory;
    });
  }, [jobs, selectedState, selectedCategory]);

  const handleReset = () => {
    setSelectedState('');
    setSelectedDistrict('');
    setSelectedCategory('All');
    setCurrentStep(1);
    setStateSearch('');
    setDistrictSearch('');
  };

  return (
    <div
      className={`flex-1 flex flex-col p-3 sm:p-5 transition-colors ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Header Breadcrumb & Step Tracker */}
      <div
        className={`p-3 sm:p-4 rounded-2xl mb-4 border shadow-sm transition-colors ${
          isDark
            ? 'bg-slate-900/90 border-slate-800'
            : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between gap-2 mb-2">
          <div
            className={`flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${
              isDark ? 'text-indigo-400' : 'text-indigo-600'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>State → District → Category → Jobs</span>
          </div>

          {(selectedState || currentStep > 1) && (
            <button
              onClick={handleReset}
              className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg transition-colors border ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900'
              }`}
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}
        </div>

        {/* Dynamic Interactive Breadcrumb Trail */}
        <div className="flex items-center gap-1.5 flex-wrap text-xs">
          <button
            onClick={() => setCurrentStep(1)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-all ${
              currentStep === 1
                ? 'bg-indigo-600 border-indigo-500 text-white font-semibold'
                : selectedState
                ? isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900'
                : isDark
                ? 'bg-slate-800/40 border-slate-800 text-slate-500'
                : 'bg-slate-50 border-slate-200 text-slate-400'
            }`}
          >
            {selectedState ? `1. ${selectedState}` : '1. Select State'}
          </button>

          <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isDark ? 'text-slate-600' : 'text-slate-400'}`} />

          <button
            onClick={() => selectedState && setCurrentStep(2)}
            disabled={!selectedState}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-all ${
              currentStep === 2
                ? 'bg-indigo-600 border-indigo-500 text-white font-semibold'
                : selectedDistrict
                ? isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900'
                : isDark
                ? 'bg-slate-800/40 border-slate-800 text-slate-500 disabled:opacity-50'
                : 'bg-slate-50 border-slate-200 text-slate-400 disabled:opacity-50'
            }`}
          >
            {selectedDistrict ? `2. ${selectedDistrict}` : '2. Select District'}
          </button>

          <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isDark ? 'text-slate-600' : 'text-slate-400'}`} />

          <button
            onClick={() => selectedDistrict && setCurrentStep(3)}
            disabled={!selectedDistrict}
            className={`px-2.5 py-1 rounded-lg border text-xs font-medium transition-all ${
              currentStep === 3
                ? 'bg-indigo-600 border-indigo-500 text-white font-semibold'
                : selectedCategory !== 'All'
                ? isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900'
                : isDark
                ? 'bg-slate-800/40 border-slate-800 text-slate-500 disabled:opacity-50'
                : 'bg-slate-50 border-slate-200 text-slate-400 disabled:opacity-50'
            }`}
          >
            {selectedCategory !== 'All' ? `3. ${selectedCategory}` : '3. Category'}
          </button>
        </div>
      </div>

      {/* STEP 1: SELECT STATE / UT */}
      {currentStep === 1 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2
              className={`text-sm font-bold flex items-center gap-1.5 ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              <MapPin className={`w-4 h-4 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
              <span>Step 1: Choose State or Union Territory</span>
            </h2>
            <span className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              36 States & UTs
            </span>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-state-search"
              type="text"
              value={stateSearch}
              onChange={(e) => setStateSearch(e.target.value)}
              placeholder="Search State (e.g., Maharashtra, UP, Delhi, Bihar)..."
              className={`w-full pl-9 pr-4 py-2.5 border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-colors ${
                isDark
                  ? 'bg-slate-900 border-slate-800 text-white placeholder-slate-500'
                  : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 shadow-sm'
              }`}
            />
          </div>

          {/* States Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto pr-1">
            {filteredStates.map((state) => (
              <button
                key={state.code}
                id={`btn-state-${state.code}`}
                onClick={() => {
                  setSelectedState(state.name);
                  setSelectedDistrict('');
                  setCurrentStep(2);
                }}
                className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all group ${
                  selectedState === state.name
                    ? isDark
                      ? 'bg-indigo-600/20 border-indigo-500 text-white'
                      : 'bg-indigo-50 border-indigo-300 text-indigo-900'
                    : isDark
                    ? 'bg-slate-900/80 border-slate-800/80 hover:bg-slate-800 hover:border-slate-700 text-slate-200'
                    : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-900 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-semibold text-xs ${
                        isDark
                          ? 'text-white group-hover:text-indigo-300'
                          : 'text-slate-900 group-hover:text-indigo-600'
                      }`}
                    >
                      {state.name}
                    </span>
                    {state.isUT && (
                      <span
                        className={`px-1.5 py-0.2 text-[9px] font-bold rounded border ${
                          isDark
                            ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                            : 'bg-purple-100 text-purple-800 border-purple-200'
                        }`}
                      >
                        UT
                      </span>
                    )}
                  </div>
                  <p className={`text-[11px] mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                    {state.districts.length} Districts • Capital: {state.capital || 'N/A'}
                  </p>
                </div>
                <ChevronRight
                  className={`w-4 h-4 transition-transform group-hover:translate-x-0.5 ${
                    isDark
                      ? 'text-slate-500 group-hover:text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-600'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* STEP 2: SELECT DISTRICT */}
      {currentStep === 2 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentStep(1)}
                className={`p-1.5 rounded-lg border transition-colors ${
                  isDark
                    ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 shadow-sm'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2
                  className={`text-sm font-bold flex items-center gap-1.5 ${
                    isDark ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  <Building2 className={`w-4 h-4 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
                  <span>Step 2: Select District in {selectedState}</span>
                </h2>
                <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {availableDistricts.length} districts available
                </p>
              </div>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-district-search"
              type="text"
              value={districtSearch}
              onChange={(e) => setDistrictSearch(e.target.value)}
              placeholder={`Search district in ${selectedState}...`}
              className={`w-full pl-9 pr-4 py-2.5 border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-colors ${
                isDark
                  ? 'bg-slate-900 border-slate-800 text-white placeholder-slate-500'
                  : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 shadow-sm'
              }`}
            />
          </div>

          {/* All Districts option */}
          <button
            id="btn-district-all"
            onClick={() => {
              setSelectedDistrict('All Districts');
              setCurrentStep(3);
            }}
            className={`w-full p-3 rounded-xl border text-xs font-semibold flex items-center justify-between transition-colors shadow-sm ${
              isDark
                ? 'bg-indigo-950/40 border-indigo-800/60 hover:bg-indigo-900/50 text-indigo-200'
                : 'bg-indigo-50 border-indigo-200 hover:bg-indigo-100 text-indigo-900'
            }`}
          >
            <span>All Districts in {selectedState}</span>
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Districts List */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[55vh] overflow-y-auto pr-1">
            {filteredDistricts.map((district) => (
              <button
                key={district}
                id={`btn-district-${district.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => {
                  setSelectedDistrict(district);
                  setCurrentStep(3);
                }}
                className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all truncate flex items-center justify-between group ${
                  selectedDistrict === district
                    ? isDark
                      ? 'bg-indigo-600/20 border-indigo-500 text-white'
                      : 'bg-indigo-50 border-indigo-300 text-indigo-900 font-semibold'
                    : isDark
                    ? 'bg-slate-900/80 border-slate-800 hover:bg-slate-800 hover:border-slate-700 text-slate-200'
                    : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-800 shadow-sm'
                }`}
                title={district}
              >
                <span className="truncate">{district}</span>
                <ChevronRight
                  className={`w-3 h-3 shrink-0 ${
                    isDark
                      ? 'text-slate-500 group-hover:text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-600'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* STEP 3: SELECT CATEGORY */}
      {currentStep === 3 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentStep(2)}
                className={`p-1.5 rounded-lg border transition-colors ${
                  isDark
                    ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 shadow-sm'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2
                  className={`text-sm font-bold flex items-center gap-1.5 ${
                    isDark ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  <Briefcase className={`w-4 h-4 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
                  <span>Step 3: Select Job Category</span>
                </h2>
                <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  Targeting: {selectedState} → {selectedDistrict}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  id={`btn-cat-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                  onClick={() => {
                    setSelectedCategory(cat);
                    setCurrentStep(4);
                  }}
                  className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all group ${
                    isSelected
                      ? isDark
                        ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                        : 'bg-indigo-50 border-indigo-300 text-indigo-900 shadow-sm font-semibold'
                      : isDark
                      ? 'bg-slate-900/80 border-slate-800 hover:bg-slate-800 hover:border-slate-700 text-slate-200'
                      : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-900 shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold border ${
                        isDark
                          ? 'bg-slate-800 border-slate-700/60'
                          : 'bg-slate-100 border-slate-200'
                      }`}
                    >
                      {cat === 'Government Jobs' ? '🏛️' :
                       cat === 'Private Jobs' ? '🏢' :
                       cat === 'Railway Jobs' ? '🚆' :
                       cat === 'Banking Jobs' ? '🏦' :
                       cat === 'Defence Jobs' ? '⚔️' :
                       cat === 'ITI Jobs' ? '🔧' :
                       cat === 'Diploma Jobs' ? '📐' :
                       cat === 'Graduate Jobs' ? '🎓' :
                       cat === 'Apprenticeship Jobs' ? '⚙️' : '📋'}
                    </div>
                    <div>
                      <span
                        className={`font-semibold text-xs ${
                          isDark
                            ? 'text-white group-hover:text-indigo-300'
                            : 'text-slate-900 group-hover:text-indigo-600'
                        }`}
                      >
                        {cat}
                      </span>
                    </div>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 transition-transform group-hover:translate-x-0.5 ${
                      isDark
                        ? 'text-slate-500 group-hover:text-indigo-400'
                        : 'text-slate-400 group-hover:text-indigo-600'
                    }`}
                  />
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 4: JOB RESULTS */}
      {currentStep === 4 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentStep(3)}
                className={`p-1.5 rounded-lg border transition-colors ${
                  isDark
                    ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 shadow-sm'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2
                  className={`text-sm font-bold ${
                    isDark ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  {selectedCategory === 'All' ? 'All Jobs' : selectedCategory} in {selectedDistrict}
                </h2>
                <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {selectedState} • {filteredJobs.length} Vacancy Alerts
                </p>
              </div>
            </div>

            <button
              onClick={() => setCurrentStep(3)}
              className={`flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg border transition-colors ${
                isDark
                  ? 'text-indigo-400 bg-slate-900 border-slate-800 hover:bg-slate-800'
                  : 'text-indigo-700 bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
              }`}
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span>Filter</span>
            </button>
          </div>

          {/* Results List */}
          {filteredJobs.length > 0 ? (
            <div className="space-y-3">
              {filteredJobs.map(job => (
                <JobCard
                  key={job.id}
                  job={job}
                  isSaved={savedJobIds.includes(job.id)}
                  onToggleSave={onToggleSave}
                  onOpenDetail={onOpenDetail}
                  onReportJob={onReportJob}
                />
              ))}
            </div>
          ) : (
            <div
              className={`border rounded-2xl p-6 text-center space-y-3 transition-colors ${
                isDark
                  ? 'bg-slate-900/70 border-slate-800'
                  : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              <MapPin className={`w-8 h-8 mx-auto opacity-80 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
              <div>
                <h3 className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  No direct local openings for {selectedDistrict} in "{selectedCategory}"
                </h3>
                <p className={`text-xs max-w-md mx-auto mt-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  However, state-level and Central Government / All-India vacancies are available and applicable to candidates from {selectedDistrict}!
                </p>
              </div>

              {stateLevelJobs.length > 0 && (
                <div className="pt-2">
                  <p className={`text-xs font-semibold mb-2 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                    Available openings across {selectedState}:
                  </p>
                  <div className="space-y-3 text-left">
                    {stateLevelJobs.map(job => (
                      <JobCard
                        key={job.id}
                        job={job}
                        isSaved={savedJobIds.includes(job.id)}
                        onToggleSave={onToggleSave}
                        onOpenDetail={onOpenDetail}
                        onReportJob={onReportJob}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
