import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ServiceType } from '../types';
import { translations } from '../data/translations';
import { 
  Send, 
  CheckCircle, 
  ShieldCheck, 
  Building2, 
  HeartPulse, 
  Palmtree, 
  Plane, 
  Activity, 
  Globe2, 
  ArrowLeft, 
  ArrowRight, 
  LayoutDashboard, 
  User, 
  Phone, 
  Mail, 
  Crown,
  Sparkles
} from 'lucide-react';

export const RequestFormView: React.FC = () => {
  const { 
    language, 
    setCurrentView, 
    selectedServiceForForm, 
    setSelectedServiceForForm, 
    addNewRequest,
    setTrackingCode 
  } = useApp();

  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  // Form State
  const [formData, setFormData] = useState({
    patientName: '',
    country: isAr ? 'المملكة العربية السعودية' : 'Saudi Arabia',
    phone: '',
    email: '',
    preferredLanguage: isAr ? 'العربية' : 'English',
    serviceType: (selectedServiceForForm || 'medical_sector') as ServiceType,
    specialtyOrNeed: '',
    description: '',
    preferredContact: 'whatsapp' as 'whatsapp' | 'phone' | 'email',
    agreedToPrivacy: true,
  });

  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const serviceOptions: { value: ServiceType; labelAr: string; labelEn: string; icon: React.ReactNode }[] = [
    { value: 'medical_sector', labelAr: 'القطاع الطبي الشامل (مستشفيات، عيادات، جراحة)', labelEn: 'Comprehensive Medical (Hospitals, Surgeries)', icon: <HeartPulse className="w-4 h-4 text-[#D4AF37]" /> },
    { value: 'addiction_rehab', labelAr: 'علاج الإدمان والتأهيل السلوكي والنفسي', labelEn: 'Addiction Treatment & Psychological Rehab', icon: <Building2 className="w-4 h-4 text-[#D4AF37]" /> },
    { value: 'medical_tourism', labelAr: 'السياحة العلاجية والاستشفائية (سيوة، أسوان، سفاجا)', labelEn: 'Medical & Wellness Tourism (Siwa, Aswan, Safaga)', icon: <Palmtree className="w-4 h-4 text-[#D4AF37]" /> },
    { value: 'foreign_reception', labelAr: 'استقبال مريض أجنبي ولوجستيات السفر والإقامة', labelEn: 'Foreign Patient VIP Reception & Logistics', icon: <Plane className="w-4 h-4 text-[#D4AF37]" /> },
    { value: 'patient_followup', labelAr: 'متابعة مريض مسجل مسبقاً وتنسيق فحوصات', labelEn: 'Patient Follow-up & Scheduled Reviews', icon: <Activity className="w-4 h-4 text-[#D4AF37]" /> },
    { value: 'international_services', labelAr: 'الخدمات الدولية وتأشيرة العلاج والاستشارة عن بُعد', labelEn: 'International Desks, Medical Visa & Telehealth', icon: <Globe2 className="w-4 h-4 text-[#D4AF37]" /> },
  ];

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!formData.patientName.trim()) {
      errs.patientName = isAr ? 'يرجى كتابة الاسم بالكامل' : 'Full name is required';
    }
    if (!formData.phone.trim()) {
      errs.phone = isAr ? 'يرجى إدخال رقم هاتف للتواصل' : 'Phone number is required';
    }
    if (!formData.specialtyOrNeed.trim()) {
      errs.specialtyOrNeed = isAr ? 'يرجى تحديد التخصص أو الاحتياج' : 'Specialty or need is required';
    }
    if (!formData.agreedToPrivacy) {
      errs.agreedToPrivacy = isAr ? 'يرجى الموافقة على سياسة الخصوصية للمتابعة' : 'Must accept terms to proceed';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const newId = addNewRequest({
      patientName: formData.patientName,
      country: formData.country,
      phone: formData.phone,
      email: formData.email || 'demo@patient.com',
      preferredLanguage: formData.preferredLanguage,
      serviceType: formData.serviceType,
      specialtyOrNeed: formData.specialtyOrNeed,
      description: formData.description || (isAr ? 'طلب تنسيق استشاري تجريبي' : 'Demo clinical coordination inquiry'),
      preferredContact: formData.preferredContact,
      agreedToPrivacy: formData.agreedToPrivacy,
    });

    setSubmittedId(newId);
  };

  const handleFillDemoData = () => {
    setFormData({
      patientName: isAr ? 'سلطان بن عبدالعزيز المطيري' : 'Sultan Al-Mutairi',
      country: isAr ? 'دولة الكويت' : 'Kuwait',
      phone: '+965 9445 1209',
      email: 'sultan.mutairi@example.com',
      preferredLanguage: isAr ? 'العربية' : 'Arabic / English',
      serviceType: 'medical_sector',
      specialtyOrNeed: isAr ? 'جراحة دقيقة للعمود الفقري بالمناظير وتأهيل حركي' : 'Minimally invasive spine surgery & physical rehab',
      description: isAr 
        ? 'أرغب في عرض تقارير الرنين المغناطيسي على بروفيسور جراحة عظام متخصص مع ترتيب شقة فندقية للمرافقين لمدة 10 أيام.'
        : 'Seeking review of lumbar MRI scans by a leading spine surgeon with 10-day serviced apartment booking for companions.',
      preferredContact: 'whatsapp',
      agreedToPrivacy: true,
    });
    setErrors({});
  };

  return (
    <div className="py-12 bg-black min-h-screen text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb & Quick Switch */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-zinc-400 hover:text-amber-300 transition-colors"
          >
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>{t.backToHome}</span>
          </button>

          <span className="text-xs bg-zinc-900 border border-[#D4AF37]/40 text-amber-300 font-bold px-3 py-1 rounded-full">
            {isAr ? 'نموذج التنسيق الطبي الرسمي' : 'Official Medical Coordination Form'}
          </span>
        </div>

        {/* Success Modal / Card State */}
        {submittedId ? (
          <div className="bg-zinc-950 rounded-3xl p-8 sm:p-10 border border-[#D4AF37]/50 shadow-2xl text-center space-y-6 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-amber-300 rounded-full flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-amber-200 via-amber-400 to-[#D4AF37] bg-clip-text text-transparent">
                {t.formSuccessTitle}
              </h2>
              <p className="text-sm text-zinc-300 max-w-lg mx-auto">
                {t.formSuccessDesc}
              </p>
            </div>

            {/* Tracking Code Highlight Box */}
            <div className="bg-black border-2 border-dashed border-[#D4AF37]/60 rounded-2xl p-5 max-w-md mx-auto shadow-inner">
              <div className="text-xs text-amber-200/80 font-medium mb-1">
                {t.formYourCode}
              </div>
              <div className="text-2xl sm:text-3xl font-black text-amber-400 font-mono tracking-wider">
                {submittedId}
              </div>
              <div className="text-[11px] text-zinc-500 mt-2">
                {isAr
                  ? 'تم حفظ الطلب فورياً في لوحة الإدارة التجريبية ويمكنك مشاهدته وتعديل حالته هناك'
                  : 'Instantly synced into Admin Dashboard and Patient Portal'}
              </div>
            </div>

            {/* Investor Flow Quick Jump Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-zinc-900">
              <button
                onClick={() => {
                  setCurrentView('admin');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold text-xs sm:text-sm rounded-xl shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all"
              >
                <LayoutDashboard className="w-4 h-4 text-black" />
                <span>{isAr ? 'مشاهدة هذا الطلب في لوحة الإدارة' : 'View this in Admin Dashboard'}</span>
              </button>

              <button
                onClick={() => {
                  setTrackingCode(submittedId);
                  setCurrentView('tracking');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full sm:w-auto px-6 py-3.5 bg-black hover:bg-zinc-900 text-amber-300 font-bold text-xs sm:text-sm rounded-xl border border-[#D4AF37]/50 flex items-center justify-center gap-2 transition-all"
              >
                <Activity className="w-4 h-4 text-[#D4AF37]" />
                <span>{isAr ? 'متابعة خطة الطلب في ملف المريض' : 'Track in Patient Portal'}</span>
              </button>

              <button
                onClick={() => {
                  setSubmittedId(null);
                  setFormData(prev => ({
                    ...prev,
                    patientName: '',
                    phone: '',
                    specialtyOrNeed: '',
                    description: '',
                  }));
                }}
                className="w-full sm:w-auto px-4 py-3.5 border border-zinc-800 hover:bg-zinc-900 text-zinc-300 font-semibold text-xs sm:text-sm rounded-xl transition-colors"
              >
                {isAr ? 'تقديم طلب جديد' : 'Submit Another'}
              </button>
            </div>
          </div>
        ) : (
          /* Main Interactive Form Card */
          <div className="bg-zinc-950 rounded-3xl p-6 sm:p-10 border border-[#D4AF37]/40 shadow-2xl">
            
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-8 border-b border-zinc-900 gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
                  {t.formTitle}
                </h1>
                <p className="text-xs sm:text-sm text-zinc-400 mt-1">
                  {t.formSubtitle}
                </p>
              </div>

              {/* Demo Helper Button */}
              <button
                type="button"
                onClick={handleFillDemoData}
                className="self-start sm:self-auto bg-black hover:bg-zinc-900 border border-[#D4AF37]/50 text-amber-300 text-xs font-bold px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5 shadow-sm"
                title={isAr ? 'ملء بيانات مريض خليجي تجريبية بنقرة واحدة للعرض السريع' : 'Autofill sample patient data for testing'}
              >
                <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{isAr ? 'ملء بيانات تجريبية سريعة' : 'Autofill Demo Data'}</span>
              </button>
            </div>

            {/* Safe Data Collection Advisory */}
            <div className="bg-black border border-[#D4AF37]/30 rounded-2xl p-4 mb-8 text-xs text-amber-200/90 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold text-amber-300">
                  {isAr ? 'حماية الخصوصية وضمان أمن البيانات:' : 'Privacy & Security Guarantee:'}
                </strong>{' '}
                {isAr
                  ? 'هذا النموذج التجريبي مخصص للتنسيق الإداري المبدئي. يرجى عدم إدخال تقارير طبية حساسة للغاية هنا؛ سيتم فتح قناة مشفرة مخصصة لرفع التقارير بعد تأكيد التواصل مع الاستشاري المختص.'
                  : 'This demo form is for preliminary coordination. Sensitive medical records will only be collected through encrypted clinical channels following coordinator verification.'}
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Service Type Selection */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-2">
                  {t.formServiceType} *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {serviceOptions.map(opt => (
                    <button
                      type="button"
                      key={opt.value}
                      onClick={() => setFormData({ ...formData, serviceType: opt.value })}
                      className={`p-3 rounded-xl border text-start transition-all flex items-center gap-3 ${
                        formData.serviceType === opt.value
                          ? 'border-[#D4AF37] bg-black ring-1 ring-[#D4AF37] font-bold text-amber-300 shadow-[0_0_12px_rgba(212,175,55,0.15)]'
                          : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/60 text-zinc-300'
                      }`}
                    >
                      <div className="p-1.5 rounded-lg bg-black border border-[#D4AF37]/30 shadow-2xs">
                        {opt.icon}
                      </div>
                      <span className="text-xs">
                        {isAr ? opt.labelAr : opt.labelEn}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Patient Name & Country */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formName} *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-zinc-500 absolute right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={formData.patientName}
                      onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                      placeholder={isAr ? 'مثال: فيصل العتيبي' : 'e.g. Faisal Al-Otaibi'}
                      className={`w-full text-xs sm:text-sm px-9 py-2.5 rounded-xl bg-black border ${
                        errors.patientName ? 'border-rose-400 bg-rose-950/20' : 'border-zinc-800'
                      } text-white focus:outline-hidden focus:border-[#D4AF37]`}
                    />
                  </div>
                  {errors.patientName && <p className="text-[11px] text-rose-400 mt-1">{errors.patientName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formCountry} *
                  </label>
                  <input
                    type="text"
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    placeholder={isAr ? 'مثال: قطر، عمان، الإمارات، السودان، كندا' : 'e.g. UAE, Oman, Sudan, UK'}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formPhone} *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-zinc-500 absolute right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+966 50 000 0000"
                      className={`w-full text-xs sm:text-sm px-9 py-2.5 rounded-xl bg-black border ${
                        errors.phone ? 'border-rose-400 bg-rose-950/20' : 'border-zinc-800'
                      } text-white focus:outline-hidden focus:border-[#D4AF37] font-mono`}
                    />
                  </div>
                  {errors.phone && <p className="text-[11px] text-rose-400 mt-1">{errors.phone}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formEmail}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-zinc-500 absolute right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="patient@example.com"
                      className="w-full text-xs sm:text-sm px-9 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                    />
                  </div>
                </div>
              </div>

              {/* Language & Preferred Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formPrefLang}
                  </label>
                  <select
                    value={formData.preferredLanguage}
                    onChange={(e) => setFormData({ ...formData, preferredLanguage: e.target.value })}
                    className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                  >
                    <option value="العربية">العربية (Arabic)</option>
                    <option value="English">English</option>
                    <option value="Français">Français (French)</option>
                    <option value="Русский">Русский (Russian)</option>
                    <option value="Swahili">Kiswahili (East Africa)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-200 mb-1.5">
                    {t.formContactMethod}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['whatsapp', 'phone', 'email'] as const).map(method => (
                      <button
                        type="button"
                        key={method}
                        onClick={() => setFormData({ ...formData, preferredContact: method })}
                        className={`py-2 px-2 text-xs rounded-xl border font-medium text-center transition-all ${
                          formData.preferredContact === method
                            ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-black'
                            : 'border-zinc-800 bg-black text-zinc-300 hover:border-zinc-700'
                        }`}
                      >
                        {method === 'whatsapp' ? 'واتساب' : method === 'phone' ? 'هاتفياً' : 'بريد'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Specialty or Specific Need */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1.5">
                  {t.formSpecialty} *
                </label>
                <input
                  type="text"
                  value={formData.specialtyOrNeed}
                  onChange={(e) => setFormData({ ...formData, specialtyOrNeed: e.target.value })}
                  placeholder={isAr ? 'مثال: جراحة استبدال مفصل الورك، سحب سموم وتأهيل، استشفاء بيئي في سيوة...' : 'e.g., Hip replacement, detox retreat, Siwa salt wellness...'}
                  className={`w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl bg-black border ${
                    errors.specialtyOrNeed ? 'border-rose-400 bg-rose-950/20' : 'border-zinc-800'
                  } text-white focus:outline-hidden focus:border-[#D4AF37]`}
                />
                {errors.specialtyOrNeed && <p className="text-[11px] text-rose-400 mt-1">{errors.specialtyOrNeed}</p>}
              </div>

              {/* Brief Description */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1.5">
                  {t.formDesc}
                </label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder={isAr ? 'وضح أي رغبات إضافية مثل: استقبال من المطار، مرافقة مترجم، تفضيل مستشفى معين...' : 'Provide additional requests such as airport transfer, hotel booking, or preferred doctor...'}
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                ></textarea>
              </div>

              {/* Privacy Consent Checkbox */}
              <div>
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.agreedToPrivacy}
                    onChange={(e) => setFormData({ ...formData, agreedToPrivacy: e.target.checked })}
                    className="mt-0.5 rounded border-zinc-700 bg-black text-amber-500 focus:ring-[#D4AF37] w-4 h-4 shrink-0"
                  />
                  <span className="text-xs text-zinc-400 leading-relaxed">
                    {t.formPrivacyConsent}
                  </span>
                </label>
                {errors.agreedToPrivacy && (
                  <p className="text-[11px] text-rose-400 mt-1">{errors.agreedToPrivacy}</p>
                )}
              </div>

              {/* Submit CTA in Gold */}
              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-black py-4 px-6 rounded-2xl shadow-xl shadow-amber-500/25 transition-all duration-200 flex items-center justify-center gap-2 text-sm sm:text-base border border-amber-300"
                >
                  <Send className="w-5 h-5 text-black" />
                  <span>{t.formSubmitBtn}</span>
                </button>
              </div>

            </form>

          </div>
        )}

      </div>
    </div>
  );
};
