import React, { useState } from 'react';
import { QUESTIONS_DATA } from '../data/questions';
import { X, Search, Check, Sparkles, BookCheck } from 'lucide-react';

interface StudyGuideModalProps {
  onClose: () => void;
}

export const StudyGuideModal: React.FC<StudyGuideModalProps> = ({ onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('ALL');

  const topics = ['ALL', ...Array.from(new Set(QUESTIONS_DATA.map((q) => q.topic || 'General')))];

  const filteredQuestions = QUESTIONS_DATA.filter((q) => {
    const matchesTopic = selectedTopic === 'ALL' || q.topic === selectedTopic;
    const matchesSearch =
      searchTerm.trim() === '' ||
      q.q.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.e.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.a.some((opt) => opt.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesTopic && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#030615e6] backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl bg-gradient-to-b from-[#121c45] to-[#080d24] border border-[#5577cc] shadow-[0_0_40px_rgba(76,245,255,0.2)] text-white overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-[#253669]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1b2b63] border border-[#4cf5ff60] flex items-center justify-center text-xl">
              📖
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[#4cf5ff]">
                دليل مراجعة الكيمياء التحليلية الصيدلية
              </h2>
              <p className="text-xs text-slate-400">
                مرجع الـ 20 محطة مع الشروحات الصيدلية النموذجية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-[#14224e] hover:bg-[#1d316e] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-4 bg-[#0d1638] border-b border-[#253669] flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث في الأسئلة أو الشروحات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#13204c] border border-[#3b5293] rounded-xl pr-9 pl-4 py-2 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-[#4cf5ff]"
            />
          </div>

          {/* Topic Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {topics.map((t) => (
              <button
                key={t}
                onClick={() => setSelectedTopic(t)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedTopic === t
                    ? 'bg-[#4cf5ff] text-[#08122c]'
                    : 'bg-[#152352] text-slate-300 hover:bg-[#1c3070]'
                }`}
              >
                {t === 'ALL' ? 'كل المحطات (20)' : t}
              </button>
            ))}
          </div>
        </div>

        {/* Questions List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {filteredQuestions.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <BookCheck className="w-12 h-12 mx-auto text-slate-600 mb-2" />
              <p>لم يتم العثور على نتائج تطابق بحثك.</p>
            </div>
          ) : (
            filteredQuestions.map((q) => (
              <div
                key={q.id}
                className="rounded-2xl bg-[#0f193f] border border-[#2c3f7c] p-4 text-right shadow-sm hover:border-[#4cf5ff60] transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#ffe18a]">
                    محطة {String(q.id).padStart(2, '0')} • {q.topic}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#4cf5ff]" /> سؤال مؤكد
                  </span>
                </div>

                <h3 className="font-bold text-white text-base mb-3 font-latin leading-snug" dir="ltr">
                  {q.q}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3" dir="ltr">
                  {q.a.map((opt, idx) => {
                    const isCorrect = idx === q.c;
                    return (
                      <div
                        key={idx}
                        className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-between ${
                          isCorrect
                            ? 'bg-[#094030] border-[#38ef7d] text-[#b4ffd8]'
                            : 'bg-[#0b122e] border-[#223161] text-slate-400'
                        }`}
                      >
                        <span>{opt}</span>
                        {isCorrect && <Check className="w-4 h-4 text-[#38ef7d] shrink-0" />}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div className="bg-[#091129] p-3 rounded-xl border border-[#233568] text-xs leading-relaxed text-slate-300">
                  <strong className="text-[#ffe18a] block mb-1">💡 الشرح الصيدلي:</strong>
                  {q.e}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#253669] bg-[#0c1433] flex items-center justify-between">
          <span className="text-xs text-slate-400">
            عدد المحطات المعروضة: {filteredQuestions.length} من {QUESTIONS_DATA.length}
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#071129] font-bold text-sm cursor-pointer hover:opacity-90"
          >
            إغلاق المراجعة
          </button>
        </div>
      </div>
    </div>
  );
};
