import React, { useState } from 'react';
import { X, Sparkles, HelpCircle, Check } from 'lucide-react';
import { ModelSettings, ChatModelType, ResponseLengthType, ImageModelType, VideoModelType } from '../types';

interface GlobalModelModalProps {
  currentSettings: ModelSettings;
  onSave: (newSettings: ModelSettings) => void;
  onClose: () => void;
}

export const GlobalModelModal: React.FC<GlobalModelModalProps> = ({
  currentSettings,
  onSave,
  onClose,
}) => {
  const [chatModel, setChatModel] = useState<ChatModelType>(currentSettings.chatModel);
  const [responseLength, setResponseLength] = useState<ResponseLengthType>(
    currentSettings.responseLength
  );
  const [imageModel, setImageModel] = useState<ImageModelType>(currentSettings.imageModel);
  const [videoModel, setVideoModel] = useState<VideoModelType>(currentSettings.videoModel);

  const chatModelsList: ChatModelType[] = [
    'DeepSeek-V3',
    'Step 3.5 F',
    'Grok-4.1 F',
    'Mistral AI',
    'Gemini 3.5',
  ];

  const responseLengthsList: ResponseLengthType[] = ['تلقائي', 'منخفض', 'طويل'];
  const imageModelsList: ImageModelType[] = ['FLUX', 'Nano-Ban'];
  const videoModelsList: VideoModelType[] = ['Pixverse', 'Seedance', 'Kling 2.0', 'Veo 3.1'];

  const handleSave = () => {
    onSave({
      chatModel,
      responseLength,
      imageModel,
      videoModel,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 dir-rtl">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 text-white shadow-2xl overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2 space-x-reverse">
            <HelpCircle className="w-5 h-5 text-slate-400" />
            <h2 className="text-base font-bold text-white">اختيار النموذج العالمي</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 1: Chat Models matching Screenshot 7 */}
        <div className="mb-5">
          <h3 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1">
            <span>إعدادات الدردشة</span>
            <span className="text-[10px] text-slate-500 font-normal">(نموذج قياسي)</span>
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {chatModelsList.map((model) => {
              const isSelected = chatModel === model;
              return (
                <button
                  key={model}
                  type="button"
                  onClick={() => setChatModel(model)}
                  className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-all border ${
                    isSelected
                      ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                      : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{model}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-purple-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 2: Response Length */}
        <div className="mb-5">
          <h3 className="text-xs font-bold text-slate-300 mb-2">طول الاستجابة</h3>
          <div className="grid grid-cols-3 gap-2">
            {responseLengthsList.map((len) => {
              const isSelected = responseLength === len;
              return (
                <button
                  key={len}
                  type="button"
                  onClick={() => setResponseLength(len)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-pink-500/20 border-pink-500 text-pink-300'
                      : 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {len}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 3: Image Models */}
        <div className="mb-5">
          <h3 className="text-xs font-bold text-slate-300 mb-2">إعدادات الصور</h3>
          <div className="grid grid-cols-2 gap-2">
            {imageModelsList.map((imgM) => {
              const isSelected = imageModel === imgM;
              return (
                <button
                  key={imgM}
                  type="button"
                  onClick={() => setImageModel(imgM)}
                  className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-between border ${
                    isSelected
                      ? 'bg-pink-600/20 border-pink-500 text-pink-200'
                      : 'bg-slate-800/80 border-slate-700/80 text-slate-300'
                  }`}
                >
                  <span>{imgM} 🍌</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-pink-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 4: Video Models */}
        <div className="mb-6">
          <h3 className="text-xs font-bold text-slate-300 mb-2">إعدادات الفيديو</h3>
          <div className="grid grid-cols-2 gap-2">
            {videoModelsList.map((vidM) => {
              const isSelected = videoModel === vidM;
              return (
                <button
                  key={vidM}
                  type="button"
                  onClick={() => setVideoModel(vidM)}
                  className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-between border ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500 text-blue-200'
                      : 'bg-slate-800/80 border-slate-700/80 text-slate-300'
                  }`}
                >
                  <span>{vidM}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-blue-400" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Save Button */}
        <button
          onClick={handleSave}
          className="w-full bg-slate-950 hover:bg-black border border-slate-700 text-white font-bold py-3.5 rounded-2xl text-xs shadow-xl transition-all"
        >
          حفظ
        </button>
      </div>
    </div>
  );
};
