import { useState, useEffect } from 'react'
import {
  db,
  addCustomer,
  customerBalance,
  customerLedger,
  addPayment,
  updateCustomerPhone,
} from '../db/database'
import { inr, fmtDateTime } from '../lib/format'

function entryTitle(e) {
  if (e.type === 'due') return `Bill #${e.billNo}`
  if (e.type === 'void') return `Bill #${e.billNo} wapas`
  return 'Jama'
}

export default function Ledger() {
  const [customers, setCustomers] = useState([])
  const [detail, setDetail] = useState(null)
  const [pay, setPay] = useState(null)
  const [name, setName] = useState('')
  const [query, setQuery] = useState('')
  const [notice, setNotice] = useState('')
  const [refresh, setRefresh] = useState(0)

  useEffect(() => {
    ;(async () => {
      const all = await db.customers.toArray()
      const withBal = await Promise.all(
        all.map(async (c) => ({ ...c, ...(await customerBalance(c.id)) })),
      )
      setCustomers(withBal.sort((a, b) => b.balance - a.balance))
    })()
  }, [refresh])

  const totalOutstanding = customers.reduce((s, c) => s + Math.max(0, c.balance), 0)
  const dues = customers.filter((c) => c.balance > 0)
  const q = query.trim().toLowerCase()
  const filtered = q
    ? customers.filter(
        (c) => c.name.toLowerCase().includes(q) || (c.phone || '').toLowerCase().includes(q),
      )
    : customers

  async function openDetail(c) {
    const ledger = await customerLedger(c.id)
    setDetail({ ...c, ledger })
  }

  async function addNewCustomer() {
    try {
      const c = await addCustomer(name)
      setName('')
      if (customers.some((x) => x.id === c.id))
        flush(`${c.name} already list me hai`)
      else flush(`${c.name} add ho gaya`)
      setRefresh((r) => r + 1)
    } catch (e) {
      flush(e.message || 'Customer add nahi hua')
    }
  }

  function flush(msg) {
    setNotice(msg)
    setTimeout(() => setNotice(''), 3000)
  }

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card highlight">
          <div className="stat-label">Total Baki</div>
          <div className="stat-value">{inr(totalOutstanding)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Customers</div>
          <div className="stat-value">{customers.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Jinki baki hai</div>
          <div className="stat-value">{dues.length}</div>
        </div>
      </div>

      <div className="row">
        <input
          className="input grow"
          placeholder="Naam / phone se khojo…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="row">
        <input
          className="input grow"
          placeholder="Naya customer naam…"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button className="btn btn-primary" onClick={addNewCustomer}>
          Add
        </button>
      </div>

      {notice && <p className="green">{notice}</p>}

      <p className="muted count">{filtered.length} customers</p>

      <ul className="list">
        {filtered.map((c) => (
          <li key={c.id} className="list-item" onClick={() => openDetail(c)}>
            <div className="item-main">
              <div className="item-title">{c.name}</div>
              <div className={`item-sub ${c.balance > 0 ? 'balance-due' : 'muted'}`}>
                {c.phone ? `${c.phone} · ` : ''}
                {c.balance > 0 ? `Laan: ${inr(c.balance)}` : 'Koi udhar nahi'}
              </div>
            </div>
            <button
              className="btn btn-small detail-arrow"
              aria-label={`${c.name} ka ledger kholo`}
            >
              ›
            </button>
          </li>
        ))}
        {filtered.length === 0 && <li className="muted">Koi customer nahi</li>}
      </ul>

      {detail && (
        <DetailModal
          customer={detail}
          onClose={() => setDetail(null)}
          onPay={() => setPay(detail)}
          onUpdated={(phone) => setDetail({ ...detail, phone })}
        />
      )}

      {pay && (
        <PayModal
          customer={pay}
          onClose={() => setPay(null)}
          onDone={() => {
            setPay(null)
            setRefresh((r) => r + 1)
          }}
        />
      )}
    </div>
  )
}

function DetailModal({ customer, onClose, onPay, onUpdated }) {
  const [editPhone, setEditPhone] = useState(false)
  const [phone, setPhone] = useState(customer.phone || '')

  async function savePhone() {
    const clean = await updateCustomerPhone(customer.id, phone)
    onUpdated(clean)
    setEditPhone(false)
  }

  return (
    <div className="scanner-overlay" role="dialog" aria-modal="true">
      <div className="scanner-card form-card">
        <div className="scanner-header">
          <strong>{customer.name}</strong>
          <button className="btn btn-ghost" aria-label="Band karo" onClick={onClose}>
            ✕
          </button>
        </div>

        <div className="stat-card highlight">
          <div className="stat-label">Baki</div>
          <div className="stat-value">{inr(customer.balance)}</div>
        </div>

        <div className="row">
          <span className="field-label grow">Phone</span>
          {editPhone ? (
            <>
              <input
                className="input grow"
                inputMode="tel"
                autoFocus
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && savePhone()}
              />
              <button className="btn btn-primary" onClick={savePhone}>
                Save
              </button>
            </>
          ) : (
            <>
              <span className="muted grow">{customer.phone || '—'}</span>
              <button className="btn btn-small" onClick={() => setEditPhone(true)}>
                ✎ Edit
              </button>
            </>
          )}
        </div>

        <button className="btn btn-primary btn-big" onClick={onPay}>
          + Jama (Paisa Lya)
        </button>

        <h3>History</h3>
        <ul className="list">
          {customer.ledger.map((e) => (
            <li key={e.id} className="list-item">
              <div className="item-main">
                <div className="item-title">{entryTitle(e)}</div>
                <div className="item-sub muted">{fmtDateTime(e.createdAt)}</div>
              </div>
              <div className={`item-price ${e.type === 'due' ? '' : 'green'}`}>
                {e.type === 'due' ? '+' : '-'}
                {inr(e.amount)}
              </div>
            </li>
          ))}
          {customer.ledger.length === 0 && <li className="muted">Koi entry nahi</li>}
        </ul>
      </div>
    </div>
  )
}

function PayModal({ customer, onClose, onDone }) {
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')

  async function submit() {
    const amt = Number(amount)
    if (!amt || amt <= 0) return
    await addPayment(customer.id, amt, note)
    onDone()
  }

  return (
    <div className="scanner-overlay" role="dialog" aria-modal="true">
      <div className="scanner-card form-card">
        <div className="scanner-header">
          <strong>Jama — {customer.name}</strong>
          <button className="btn btn-ghost" aria-label="Band karo" onClick={onClose}>
            ✕
          </button>
        </div>
        <label className="field">
          <span className="field-label">Kitne paise?</span>
          <input
            className="input"
            type="number"
            inputMode="decimal"
            autoFocus
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </label>
        <label className="field">
          <span className="field-label">Note (optional)</span>
          <input
            className="input"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </label>
        <button className="btn btn-primary btn-big" onClick={submit}>
          Save Jama
        </button>
      </div>
    </div>
  )
}