import { X, Send, ShieldCheck, CheckCircle, ExternalLink, Sparkles } from 'lucide-react';
import { cyberAudio } from '../audio';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function TelegramVIPModal({ isOpen, onClose }: Props) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-md bg-[#05080c] border border-cyan-500/60 rounded-2xl p-6 shadow-[0_0_50px_rgba(0,229,255,0.3)]">
        <button
          onClick={() => {
            cyberAudio.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 text-emerald-500 hover:text-emerald-300 p-1 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
            <Send className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-cyber font-black text-cyan-300 text-base tracking-wider">
              TELEGRAM VIP CHANNEL
            </h2>
            <p className="text-[11px] font-mono text-emerald-400">
              GX TEAM • MEHEDI VAI OFFICIAL COMMUNITY
            </p>
          </div>
        </div>

        <div className="space-y-3 font-mono text-xs text-emerald-300/90 my-4 bg-black/70 p-4 rounded-xl border border-emerald-500/30">
          <div className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>প্রতিদিন লাইভ ফ্রি এবং ভিআইপি ১০০% শিউর-শট সিগন্যাল</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>Quotex, 1xBet, 1Win এবং Pocket Option স্পেশাল বট আপডেট</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>লাইভ সাপোর্ট এবং উইথড্র সমস্যা সমাধান গাইড</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-center font-mono text-xs text-cyan-300 mb-6">
          <span>সিকিউরিটি পাসওয়ার্ড: </span>
          <span className="font-bold text-white bg-cyan-500/30 px-2 py-0.5 rounded">
            MEHEDIVAI115
          </span>
        </div>

        <a
          href="https://t.me"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => {
            cyberAudio.playClick();
          }}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-cyber font-black text-xs tracking-wider uppercase transition-all shadow-[0_0_20px_rgba(0,229,255,0.4)] cursor-pointer flex items-center justify-center gap-2"
        >
          <Send className="w-4 h-4" />
          <span>JOIN TELEGRAM VIP // টেলিগ্রামে যুক্ত হোন</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
}
