import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  KeyRound,
  Lock,
  Mail,
  Moon,
  ShieldCheck,
  Smartphone,
  Sun,
  UserRound,
} from 'lucide-react';
import { apiRequest, setAuthToken } from '../lib/api';
import type { MembershipInfo, PaymentRecord, ThemeMode, UserAccount } from '../types/studio';
import { BrandLogo } from './BrandLogo';

interface AuthViewProps {
  initialMode?: 'login' | 'register' | 'forgot';
  theme: ThemeMode;
  onToggleTheme: () => void;
  onBackHome: () => void;
  onAuthenticated: (payload: {
    user: UserAccount;
    membership: MembershipInfo;
    payments: PaymentRecord[];
    unreadNotifications?: number;
  }) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({
  initialMode = 'login',
  theme,
  onToggleTheme,
  onBackHome,
  onAuthenticated,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'reset'>(initialMode);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      if (mode === 'forgot') {
        const res = await apiRequest<{ ok: boolean; smtpConfigured: boolean; message: string }>(
          '/api/auth/forgot-password',
          {
            method: 'POST',
            body: JSON.stringify({ email }),
          }
        );
        setInfoMsg(res.message);
        setMode('reset');
        return;
      }

      if (mode === 'reset') {
        const res = await apiRequest<{ ok: boolean; message: string }>(
          '/api/auth/reset-password',
          {
            method: 'POST',
            body: JSON.stringify({ token: resetToken, newPassword }),
          }
        );
        setInfoMsg(res.message);
        setMode('login');
        return;
      }

      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const payload =
        mode === 'login' ? { email, password } : { username, email, password };
      const res = await apiRequest<{
        token: string;
        user: UserAccount;
        membership: MembershipInfo;
        payments: PaymentRecord[];
        unreadNotifications?: number;
      }>(endpoint, {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setAuthToken(res.token);
      onAuthenticated({
        user: res.user,
        membership: res.membership,
        payments: res.payments || [],
        unreadNotifications: res.unreadNotifications || 0,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'İşlem başarısız oldu.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-[#0B1020] dark:text-[#F8FAFC] flex flex-col">
      <header className="h-16 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
        <button
          type="button"
          onClick={onBackHome}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Ana Sayfaya Dön</span>
        </button>

        <BrandLogo variant="horizontal" size="sm" />

        <button
          type="button"
          onClick={onToggleTheme}
          aria-label="Tema Değiştir"
          className="p-2 rounded-lg border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#111827] text-slate-700 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </header>

      <div className="flex-1 flex flex-col justify-center px-4 sm:px-6 py-10">
        <div className="max-w-5xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: Platform Summary */}
          <div className="lg:col-span-6 flex flex-col justify-between bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-8">
            <div className="space-y-4">
              <BrandLogo variant="horizontal" size="lg" showSlogan />
              <h1 className="pt-4 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] leading-tight [text-wrap:balance]">
                HTML Projelerinizi Gerçek Android APK Dosyalarına Dönüştürün
              </h1>
              <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                Güvenli geliştirici hesabınızla HTML/CSS/JS veya ZIP projelerinizi yükleyin,
                Android WebView yapılandırmasını tamamlayın ve imzalı APK çıktısını indirin.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-5 pt-6 border-t border-slate-200 dark:border-white/[0.08]">
              <div className="flex items-start gap-3">
                <Smartphone className="w-5 h-5 text-[#6366F1] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    Gerçek APK Derleme
                  </h3>
                  <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                    Android SDK build-tools ve Adaptive Icon desteğiyle kurulumu hazır APK.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-[#3B82F6] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    Uçtan Uca Güvenlik
                  </h3>
                  <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                    HttpOnly oturumlar, CSRF koruması, ZIP Slip ve Path Traversal denetimi.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Auth Card */}
          <div className="lg:col-span-6 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-8 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
                <h2 className="text-lg font-bold text-slate-900 dark:text-[#F8FAFC]">
                  {mode === 'login'
                    ? 'Hesabınıza Giriş Yapın'
                    : mode === 'register'
                    ? 'Yeni Hesap Oluşturun'
                    : mode === 'forgot'
                    ? 'Şifremi Unuttum'
                    : 'Şifreyi Sıfırla'}
                </h2>

                <div className="inline-flex p-1 bg-slate-100 dark:bg-[#0B1020] rounded-lg border border-slate-200 dark:border-white/[0.08]">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setError(null);
                      setInfoMsg(null);
                    }}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      mode === 'login'
                        ? 'bg-[#6366F1] text-white'
                        : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Giriş Yap
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('register');
                      setError(null);
                      setInfoMsg(null);
                    }}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      mode === 'register'
                        ? 'bg-[#6366F1] text-white'
                        : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Kayıt Ol
                  </button>
                </div>
              </div>

              {error && (
                <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-300">
                  {error}
                </div>
              )}

              {infoMsg && (
                <div className="mb-4 px-4 py-3 rounded-xl bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
                  {infoMsg}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'register' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                      Kullanıcı Adı
                    </label>
                    <div className="relative">
                      <UserRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="ör. ahmet_dev"
                        className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:border-[#6366F1]"
                      />
                    </div>
                  </div>
                )}

                {(mode === 'login' || mode === 'register' || mode === 'forgot') && (
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                      E-posta Adresi
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="gelistirici@alanadi.com"
                        className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:border-[#6366F1]"
                      />
                    </div>
                  </div>
                )}

                {(mode === 'login' || mode === 'register') && (
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-medium text-slate-600 dark:text-[#94A3B8]">
                        Şifre
                      </label>
                      {mode === 'login' && (
                        <button
                          type="button"
                          onClick={() => {
                            setMode('forgot');
                            setError(null);
                            setInfoMsg(null);
                          }}
                          className="text-xs text-[#6366F1] hover:underline"
                        >
                          Şifremi Unuttum
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        required
                        minLength={6}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="En az 6 karakter"
                        className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:border-[#6366F1]"
                      />
                    </div>
                  </div>
                )}

                {mode === 'reset' && (
                  <>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                        Sıfırlama Jetonu
                      </label>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          value={resetToken}
                          onChange={(e) => setResetToken(e.target.value)}
                          placeholder="Sıfırlama jetonunu girin"
                          className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl pl-10 pr-4 py-2.5 text-sm font-mono text-slate-900 dark:text-[#F8FAFC]"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                        Yeni Şifre
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          required
                          minLength={6}
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="En az 6 karakter"
                          className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-[#F8FAFC]"
                        />
                      </div>
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 flex items-center justify-center gap-2 bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-60 text-white font-semibold text-sm py-2.5 px-4 rounded-xl transition-colors whitespace-nowrap"
                >
                  <span>
                    {loading
                      ? 'İşleniyor...'
                      : mode === 'login'
                      ? 'Giriş Yap'
                      : mode === 'register'
                      ? 'Hesap Oluştur'
                      : mode === 'forgot'
                      ? 'Sıfırlama Kodu Oluştur'
                      : 'Şifreyi Güncelle'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {(mode === 'forgot' || mode === 'reset') && (
                <div className="mt-4 flex items-center justify-between text-xs text-slate-500 dark:text-[#94A3B8]">
                  <button
                    type="button"
                    onClick={() => setMode(mode === 'forgot' ? 'reset' : 'forgot')}
                    className="text-[#3B82F6] hover:underline"
                  >
                    {mode === 'forgot' ? 'Zaten kodum var' : 'Yeni kod talep et'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="hover:text-slate-900 dark:hover:text-white"
                  >
                    Girişe dön
                  </button>
                </div>
              )}
            </div>

            <div className="mt-6 pt-5 border-t border-slate-200 dark:border-white/[0.08] text-xs text-slate-500 dark:text-[#94A3B8]">
              Tüm oturumlar HttpOnly çerez, CSRF koruması ve bcrypt parolalama ile güvence altındadır.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
