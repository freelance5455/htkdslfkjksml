import React from 'react';
import { 
  Sparkles, 
  Search, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  Boxes, 
  TrendingUp, 
  RefreshCw,
  PlusCircle
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './ProductCard';
import { ProductCategory, Product } from '../types';

interface StorefrontProps {
  onSelectProduct: (p: Product) => void;
  onOpenAddProduct: () => void;
}

export const Storefront: React.FC<StorefrontProps> = ({ onSelectProduct, onOpenAddProduct }) => {
  const { 
    products, 
    selectedCategory, 
    setSelectedCategory, 
    searchQuery, 
    setSearchQuery,
    setCurrentView,
    simulateIncomingSale
  } = useStore();

  const categories: { id: ProductCategory; label: string }[] = [
    { id: 'all', label: 'Todos os Produtos' },
    { id: 'ebooks', label: 'eBooks & Capas' },
    { id: 'spreadsheets', label: 'Planilhas' },
    { id: 'covers3d', label: 'Capas 3D' },
    { id: 'ads_banners', label: 'Anúncios & Banners' },
    { id: 'courses_vsl', label: 'Cursos & VSL' },
    { id: 'physical', label: 'Produtos Físicos' }
  ];

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const totalStockUnits = products.reduce((acc, p) => acc + p.stock, 0);
  const lowStockCount = products.filter(p => p.stock <= p.minStockAlert && p.stock > 0).length;
  const outOfStockCount = products.filter(p => p.stock === 0).length;

  return (
    <div className="space-y-8 pb-16">
      
      {/* Hero Section matching Screenshot 2 (EscaleBuilder purple/dark violet hero) */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#2a1147] via-[#1a0c30] to-[#091b15] text-white p-6 sm:p-10 border border-purple-900/30 shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
            <span>Ideias em Produtos Digitais & Físicos</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight leading-tight text-white text-balance">
            Transforma a tua ideia num produto que <span className="text-emerald-400">vende</span>
          </h1>

          <p className="text-sm sm:text-base text-purple-200/90 leading-relaxed max-w-xl">
            eBooks completos, planilhas com fórmulas, capas 3D, anúncios e VSLs prontos para vender com pagamento integrado via M-Pesa, e-Mola e cartões, com baixa de estoque em tempo real.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setCurrentView('plans')}
              className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-950/40 flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
            >
              <span>Pagar para usar</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentView('inventory')}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white font-medium text-sm rounded-xl border border-white/20 transition-colors flex items-center gap-2"
            >
              <Boxes className="w-4 h-4 text-emerald-400" />
              <span>Painel de Estoque ({totalStockUnits} un.)</span>
            </button>

            <button
              onClick={simulateIncomingSale}
              title="Simula uma venda simultânea para testar a baixa de estoque em tempo real"
              className="px-3.5 py-2.5 bg-purple-900/50 hover:bg-purple-800/60 text-purple-200 text-xs font-medium rounded-xl border border-purple-500/30 transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-purple-400 animate-spin-reverse" />
              <span>Simular Venda Real-time</span>
            </button>
          </div>

          <div className="pt-2 text-xs text-purple-300/70 flex items-center gap-3">
            <span>Planos a partir de 97 MT</span>
            <span aria-hidden="true">·</span>
            <span>Pagamento seguro M-Pesa / e-Mola</span>
            <span aria-hidden="true">·</span>
            <span>Entrega imediata</span>
          </div>
        </div>

        {/* Ambient glow accent */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute right-12 bottom-0 w-64 h-64 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />
      </section>

      {/* Real-time Inventory Quick Stats Bar */}
      <section className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
          
          <div className="pt-2 sm:pt-0 sm:px-3 first:px-0">
            <div className="text-xs text-slate-500 font-medium">Produtos Ativos</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono text-slate-900 tabular-nums">
                {products.length}
              </span>
              <span className="text-xs text-emerald-600 font-medium">em catálogo</span>
            </div>
          </div>

          <div className="pt-2 sm:pt-0 sm:px-3">
            <div className="text-xs text-slate-500 font-medium">Estoque Global</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono text-slate-900 tabular-nums">
                {totalStockUnits}
              </span>
              <span className="text-xs text-slate-500">unidades totais</span>
            </div>
          </div>

          <div className="pt-2 sm:pt-0 sm:px-3">
            <div className="text-xs text-slate-500 font-medium">Estoque Baixo</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono text-amber-600 tabular-nums">
                {lowStockCount}
              </span>
              <span className="text-xs text-amber-600">itens em alerta</span>
            </div>
          </div>

          <div className="pt-2 sm:pt-0 sm:px-3">
            <div className="text-xs text-slate-500 font-medium">Esgotados</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono text-slate-700 tabular-nums">
                {outOfStockCount}
              </span>
              <span className="text-xs text-slate-400">reposição pendente</span>
            </div>
          </div>

        </div>
      </section>

      {/* Catalog Controls: Categories Segmented Tabs & Search */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Interactive filter tabs (segmented control as per frontend-design guidelines) */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search bar & Add Product CTA */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Pesquisar produto ou SKU..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
              />
            </div>

            <button
              onClick={onOpenAddProduct}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Novo Produto</span>
            </button>
          </div>

        </div>
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl border border-slate-200 p-8 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900">Nenhum produto encontrado</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Nenhum item corresponde à pesquisa "{searchQuery}". Tente outro termo ou limpe os filtros.
          </p>
          <button
            onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
            className="px-3.5 py-1.5 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg transition-colors"
          >
            Limpar Filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
            />
          ))}
        </div>
      )}

      {/* Value Proposition / Mozambican Payment Assurance Section */}
      <section className="bg-emerald-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-900/50">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/80 border border-emerald-700/50 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white">Pagamentos Moçambique 100% Seguros</h4>
            <p className="text-xs text-emerald-200/80 leading-relaxed">
              Integração nativa com M-Pesa (Vodacom) e e-Mola (Movitel) em Meticais (MT) sem taxas extras para o cliente.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/80 border border-emerald-700/50 flex items-center justify-center text-emerald-400">
              <Boxes className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white">Gestão de Estoque em Tempo Real</h4>
            <p className="text-xs text-emerald-200/80 leading-relaxed">
              Cada transação confirmada desconta as unidades vendidas instantaneamente, emitindo alertas automáticos de reposição.
            </p>
          </div>

          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/80 border border-emerald-700/50 flex items-center justify-center text-emerald-400">
              <Zap className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white">Entrega Imediata de Infoprodutos</h4>
            <p className="text-xs text-emerald-200/80 leading-relaxed">
              Downloads liberados imediatamente no ecrã e enviados para o email e WhatsApp cadastrados do cliente.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
