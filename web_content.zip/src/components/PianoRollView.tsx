import React, { useState, useRef, useEffect } from 'react';
import {
  Pencil,
  Eraser,
  Volume2,
  Trash2,
  Sparkles,
  Maximize2,
  Music,
  Plus,
  ChevronDown
} from 'lucide-react';
import { Project, Track, Clip, Note, midiToNoteName, SCALES } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';

interface PianoRollViewProps {
  project: Project;
  playhead: PlayheadState;
  selectedTrackId: string | null;
  selectedClipId: string | null;
  onSelectTrack: (trackId: string) => void;
  onSelectClip: (clipId: string) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
}

export const PianoRollView: React.FC<PianoRollViewProps> = ({
  project,
  playhead,
  selectedTrackId,
  selectedClipId,
  onSelectTrack,
  onSelectClip,
  onUpdateProject,
}) => {
  // Find currently active track & clip (default to first synth/keys/bass track)
  const track = project.tracks.find(t => t.id === selectedTrackId) ||
    project.tracks.find(t => t.type !== 'drums') ||
    project.tracks[0];

  const clip = track.clips.find(c => c.id === selectedClipId) || track.clips[0];

  const [tool, setTool] = useState<'draw' | 'erase'>('draw');
  const [scale, setScale] = useState<string>('minor');
  const [rootKey, setRootKey] = useState<number>(0); // 0 = C, 1 = C#, 2 = D...
  const [snap, setSnap] = useState<number>(0.25); // 0.25 beat = 1/16th note
  const [defaultDuration, setDefaultDuration] = useState<number>(0.5); // 0.5 beat = 1/8th note

  // Piano keys range: C2 (36) to C6 (84) -> 49 notes
  const minMidi = 36;
  const maxMidi = 84;
  const numNotes = maxMidi - minMidi + 1;
  const noteRowHeight = 22; // px per semitone
  const beatWidth = 56; // px per beat

  const totalBeats = clip ? clip.durationBeats : 8;
  const gridWidth = totalBeats * beatWidth;
  const gridHeight = numNotes * noteRowHeight;

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to center octave (around C4 ~ MIDI 60) on initial mount
  useEffect(() => {
    if (scrollContainerRef.current) {
      const c4Y = (maxMidi - 60) * noteRowHeight - 120;
      scrollContainerRef.current.scrollTop = Math.max(0, c4Y);
    }
  }, []);

  // Check if midi note is in selected scale
  const isScaleNote = (midi: number) => {
    const semitone = (midi % 12 - rootKey + 12) % 12;
    const activeScale = SCALES[scale];
    if (!activeScale) return true;
    return activeScale.intervals.includes(semitone);
  };

  const isBlackKey = (midi: number) => {
    const n = midi % 12;
    return [1, 3, 6, 8, 10].includes(n);
  };

  // Note preview on piano key press
  const handleKeyAudition = (midi: number) => {
    if (track) {
      engine.playTrackNoteLive(track, midi, 0.85);
    }
  };

  // Drawing notes on grid
  const handleGridClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!clip || !track) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const rawBeat = x / beatWidth;
    const snappedBeat = Math.floor(rawBeat / snap) * snap;
    const rowIndex = Math.floor(y / noteRowHeight);
    const pitch = maxMidi - rowIndex;

    if (pitch < minMidi || pitch > maxMidi || snappedBeat >= totalBeats) return;

    if (tool === 'draw') {
      // Audition note
      engine.playTrackNoteLive(track, pitch, 0.8);

      // Check if note already exists at this pitch and beat
      const existing = (clip.notes || []).find(
        n => n.pitch === pitch && Math.abs(n.startBeat - snappedBeat) < snap * 0.8
      );

      if (existing) {
        // Remove note
        handleDeleteNote(existing.id);
      } else {
        // Add note
        const newNote: Note = {
          id: `n_${Date.now()}_${Math.random()}`,
          pitch,
          startBeat: snappedBeat,
          durationBeats: defaultDuration,
          velocity: 0.85,
        };

        onUpdateProject(p => ({
          ...p,
          tracks: p.tracks.map(t =>
            t.id === track.id
              ? {
                  ...t,
                  clips: t.clips.map(c =>
                    c.id === clip.id
                      ? { ...c, notes: [...(c.notes || []), newNote] }
                      : c
                  ),
                }
              : t
          ),
        }));
      }
    }
  };

  const handleDeleteNote = (noteId: string) => {
    if (!clip || !track) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id
                  ? { ...c, notes: (c.notes || []).filter(n => n.id !== noteId) }
                  : c
              ),
            }
          : t
      ),
    }));
  };

  const handleClearAllNotes = () => {
    if (!clip || !track) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id ? { ...c, notes: [] } : c
              ),
            }
          : t
      ),
    }));
  };

  // Add standard chord at current playhead
  const handleInsertChord = (chordType: 'minor' | 'major' | 'seventh') => {
    if (!clip || !track) return;
    const baseMidi = 60 + rootKey; // C4 + root
    const offsets = chordType === 'minor' ? [0, 3, 7] : chordType === 'major' ? [0, 4, 7] : [0, 3, 7, 10];
    const newNotes: Note[] = offsets.map((off, idx) => ({
      id: `chord_${Date.now()}_${idx}`,
      pitch: baseMidi + off,
      startBeat: Math.floor(playhead.currentBeat % clip.durationBeats),
      durationBeats: 2.0,
      velocity: 0.8,
    }));

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id
                  ? { ...c, notes: [...(c.notes || []), ...newNotes] }
                  : c
              ),
            }
          : t
      ),
    }));
  };

  return (
    <div className="flex-1 flex flex-col bg-[#12141a] overflow-hidden select-none">
      {/* Piano Roll Toolbar */}
      <div className="h-11 bg-[#161922] border-b border-[#252b37] px-3 sm:px-4 flex items-center justify-between gap-3 shrink-0 flex-wrap">
        <div className="flex items-center gap-2">
          {/* Active Track / Clip Dropdown */}
          <div className="flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2.5 py-1 text-xs">
            <span className="text-slate-400 font-medium">Track:</span>
            <select
              value={track.id}
              onChange={e => {
                onSelectTrack(e.target.value);
                const sel = project.tracks.find(t => t.id === e.target.value);
                if (sel && sel.clips.length > 0) onSelectClip(sel.clips[0].id);
              }}
              className="bg-transparent text-slate-100 font-semibold focus:outline-none cursor-pointer"
            >
              {project.tracks.map(t => (
                <option key={t.id} value={t.id} className="bg-[#1e232e]">
                  {t.name} ({t.type})
                </option>
              ))}
            </select>
          </div>

          {/* Tools: Draw & Erase */}
          <div className="flex items-center bg-[#1e232e] border border-[#2f3747] rounded-lg p-0.5">
            <button
              onClick={() => setTool('draw')}
              className={`p-1.5 rounded-md transition-colors ${
                tool === 'draw'
                  ? 'bg-[#00e5ff] text-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Pencil Draw Tool"
            >
              <Pencil className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setTool('erase')}
              className={`p-1.5 rounded-md transition-colors ${
                tool === 'erase'
                  ? 'bg-red-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Eraser Tool"
            >
              <Eraser className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Scale Highlighting Helper */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2 py-1 text-xs">
            <span className="text-slate-400 font-medium">Scale:</span>
            <select
              value={scale}
              onChange={e => setScale(e.target.value)}
              className="bg-transparent text-[#00e5ff] font-semibold focus:outline-none cursor-pointer"
            >
              {Object.entries(SCALES).map(([k, s]) => (
                <option key={k} value={k} className="bg-[#1e232e]">
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Grid Snap */}
          <div className="flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2 py-1 text-xs">
            <span className="text-slate-400 font-medium">Snap:</span>
            <select
              value={snap}
              onChange={e => setSnap(Number(e.target.value))}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="1" className="bg-[#1e232e]">1 Beat (1/4)</option>
              <option value="0.5" className="bg-[#1e232e]">1/2 Beat (1/8)</option>
              <option value="0.25" className="bg-[#1e232e]">1/4 Beat (1/16)</option>
              <option value="0.125" className="bg-[#1e232e]">1/8 Beat (1/32)</option>
            </select>
          </div>
        </div>

        {/* Quick Chord / Clear Actions */}
        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-1">
            <button
              onClick={() => handleInsertChord('minor')}
              className="px-2 py-1 rounded bg-[#252b38] hover:bg-[#323a4d] text-slate-200 text-xs font-medium transition-colors"
              title="Add Minor Triad"
            >
              + Minor
            </button>
            <button
              onClick={() => handleInsertChord('major')}
              className="px-2 py-1 rounded bg-[#252b38] hover:bg-[#323a4d] text-slate-200 text-xs font-medium transition-colors"
              title="Add Major Triad"
            >
              + Major
            </button>
          </div>

          <button
            onClick={handleClearAllNotes}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-400 text-xs font-medium transition-colors"
            title="Clear All Notes in Pattern"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </div>
      </div>

      {/* Main Piano Roll Container (Piano Keys on Left, Grid on Right) */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-x-auto overflow-y-auto flex relative bg-[#0e1015]"
      >
        {/* Left Sticky Piano Keyboard (Width: 64px) */}
        <div
          className="sticky left-0 z-30 w-16 bg-[#161a22] border-r border-[#262c38] flex flex-col shrink-0 select-none shadow-xl"
          style={{ height: gridHeight }}
        >
          {Array.from({ length: numNotes }).map((_, idx) => {
            const midi = maxMidi - idx;
            const isBlack = isBlackKey(midi);
            const inScale = isScaleNote(midi);
            const noteLabel = midiToNoteName(midi);
            const isC = midi % 12 === 0;

            return (
              <button
                key={midi}
                onMouseDown={() => handleKeyAudition(midi)}
                style={{ height: noteRowHeight }}
                className={`w-full flex items-center justify-between px-1.5 text-[10px] font-mono border-b transition-colors active:brightness-125 ${
                  isBlack
                    ? 'bg-[#181b22] text-slate-400 border-[#242934]'
                    : 'bg-[#e2e8f0] text-slate-900 border-[#cbd5e1] font-semibold'
                }`}
                title={`Note: ${noteLabel} (MIDI ${midi})`}
              >
                <span className="truncate">
                  {isC || (!isBlack && inScale) ? noteLabel : ''}
                </span>
                {inScale && (
                  <div
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: track.color }}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Right Note Grid Canvas */}
        <div
          onClick={handleGridClick}
          className="relative cursor-crosshair select-none"
          style={{ width: gridWidth, height: gridHeight }}
        >
          {/* Background note rows & scale highlight */}
          {Array.from({ length: numNotes }).map((_, idx) => {
            const midi = maxMidi - idx;
            const isBlack = isBlackKey(midi);
            const inScale = isScaleNote(midi);

            return (
              <div
                key={midi}
                style={{ height: noteRowHeight, width: gridWidth }}
                className={`border-b ${
                  isBlack
                    ? inScale ? 'bg-[#141720] border-[#1d212b]' : 'bg-[#101217] border-[#181b22]'
                    : inScale ? 'bg-[#191d28] border-[#222734]' : 'bg-[#14161f] border-[#1c202a]'
                }`}
              />
            );
          })}

          {/* Vertical beat divider lines */}
          <div className="absolute inset-0 flex pointer-events-none">
            {Array.from({ length: totalBeats * 4 }).map((_, stepIdx) => {
              const isBar = stepIdx % 16 === 0;
              const isBeat = stepIdx % 4 === 0;
              return (
                <div
                  key={stepIdx}
                  style={{ width: beatWidth / 4 }}
                  className={`h-full border-r ${
                    isBar
                      ? 'border-[#3a4456]'
                      : isBeat
                      ? 'border-[#262c38]'
                      : 'border-[#171a22]'
                  }`}
                />
              );
            })}
          </div>

          {/* Playhead in Piano Roll */}
          {playhead.isPlaying && (
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-[#ff1744] z-30 pointer-events-none shadow-[0_0_8px_rgba(255,23,68,0.8)]"
              style={{
                left: ((playhead.currentBeat % totalBeats) * beatWidth),
              }}
            />
          )}

          {/* Render Active Notes in Clip */}
          {clip &&
            clip.notes &&
            clip.notes.map((n) => {
              const rowIndex = maxMidi - n.pitch;
              const noteTop = rowIndex * noteRowHeight + 1;
              const noteLeft = n.startBeat * beatWidth;
              const noteWidth = Math.max(8, n.durationBeats * beatWidth - 2);

              return (
                <div
                  key={n.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (tool === 'erase') {
                      handleDeleteNote(n.id);
                    } else {
                      // Audition on click
                      engine.playTrackNoteLive(track, n.pitch, n.velocity);
                    }
                  }}
                  style={{
                    top: noteTop,
                    left: noteLeft,
                    width: noteWidth,
                    height: noteRowHeight - 2,
                    backgroundColor: track.color,
                  }}
                  className="absolute rounded-md shadow-md border border-white/30 flex items-center justify-between px-1.5 text-[9px] font-mono text-black font-bold truncate cursor-pointer hover:brightness-110 active:scale-[0.98] transition-transform z-10"
                >
                  <span className="truncate">{midiToNoteName(n.pitch)}</span>
                  <span className="text-[8px] opacity-75 font-normal">
                    {Math.round(n.velocity * 100)}%
                  </span>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
