import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Building2,
  Castle,
  CheckCircle2,
  Clock,
  Hammer,
  Info,
  Loader2,
  RefreshCw,
  Search,
  Wrench,
} from 'lucide-react';
import {
  ActiveUpgradeEntry,
  ClanDashboardState,
  SyncProgressInfo,
  SyncRunSummary,
  VillageId,
} from '../shared/cocData';
import { formatDateTimeRu, formatRelativeTimeRu } from '../utils/formatters';
import {
  CocUnitBadge,
  formatCountdownRu,
  getDataSourceLabel,
  getUpgradeCategoryShortLabel,
  getVillageRuTitle,
  getVillageShortTitle,
  isActualUpgradeEvent,
  resolveUpgradeDetailType,
  resolveUpgradeVillage,
} from './CocUnitBadge';

interface ActiveUpgradesViewProps {
  state: ClanDashboardState;
  nowMs: number;
  isSyncing: boolean;
  syncProgress: SyncProgressInfo | null;
  lastSyncSummary: SyncRunSummary | null;
  onSyncNow: () => void;
  onOpenJsonImport?: (playerTag?: string) => void;
  onSelectPlayer: (tag: string) => void;
  onSelectVillage?: (village: VillageId) => void;
}

export const ActiveUpgradesView: React.FC<ActiveUpgradesViewProps> = ({
  state,
  nowMs,
  isSyncing,
  syncProgress,
  lastSyncSummary,
  onSyncNow,
  onSelectPlayer,
}) => {
  const [villageFilter, setVillageFilter] = useState<'all' | VillageId>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in_progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const allEntries: ActiveUpgradeEntry[] = useMemo(() => {
    const raw = [...(state.activeUpgrades ?? [])];
    for (const p of state.players) {
      for (const b of p.activeBuilders ?? []) {
        if (!raw.some((r) => r.id === b.id)) {
          raw.push({
            id: b.id,
            dedupKey: `legacy:${p.tag}:${b.id}`,
            village: 'home',
            playerTag: p.tag,
            playerName: p.name,
            townHallLevel: p.townHallLevel,
            builderHallLevel: p.builderHallLevel,
            objectName: b.itemNameRu,
            objectNameRu: b.itemNameRu,
            detailType: 'building',
            fromLevel: b.fromLevel,
            toLevel: b.toLevel,
            status: new Date(b.finishesAt).getTime() <= nowMs ? 'completed' : 'in_progress',
            source: 'manual',
            detectedAt: b.startedAt,
            lastConfirmedAt: b.startedAt,
            estimatedFinishesAt: b.finishesAt,
          });
        }
      }
    }
    return raw.sort((a, b) => {
      if (a.status !== b.status) return a.status === 'in_progress' ? -1 : 1;
      return new Date(b.lastConfirmedAt).getTime() - new Date(a.lastConfirmedAt).getTime();
    });
  }, [state.activeUpgrades, state.players, nowMs]);

  const actualApiEvents = useMemo(
    () => state.events.filter(isActualUpgradeEvent),
    [state.events]
  );

  const countsByVillage = useMemo(() => {
    const active = { all: 0, home: 0, builderBase: 0, clanCapital: 0 };
    for (const item of allEntries) {
      if (item.status === 'in_progress') {
        active.all += 1;
        active[item.village] += 1;
      }
    }
    const detected = { all: actualApiEvents.length, home: 0, builderBase: 0, clanCapital: 0 };
    for (const ev of actualApiEvents) {
      detected[resolveUpgradeVillage(ev)] += 1;
    }
    return { active, detected };
  }, [allEntries, actualApiEvents]);

  const filteredEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allEntries.filter((item) => {
      if (villageFilter !== 'all' && item.village !== villageFilter) return false;
      if (statusFilter !== 'all' && item.status !== statusFilter) return false;
      if (q) {
        const hay = `${item.playerName} ${item.playerTag} ${item.objectName} ${item.objectNameRu}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [allEntries, villageFilter, statusFilter, searchQuery]);

  const filteredRecentApiUpgrades = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return actualApiEvents
      .filter((ev) => {
        if (villageFilter !== 'all' && resolveUpgradeVillage(ev) !== villageFilter) return false;
        if (q) {
          const hay = `${ev.playerName} ${ev.playerTag} ${ev.apiName || ''} ${ev.itemNameRu}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .slice(0, 20);
  }, [actualApiEvents, villageFilter, searchQuery]);

  const showLiveProgress = isSyncing || Boolean(syncProgress?.inProgress);
  const checkedNow = syncProgress?.checkedMembers ?? 0;
  const totalNow = syncProgress?.totalMembers || state.players.length;
  const pctNow = totalNow > 0 ? Math.min(100, Math.round((checkedNow / totalNow) * 100)) : 0;

  return (
    <div className="space-y-6">
      {/* Header + Sync Action */}
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-5 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Сейчас улучшается и текущий мониторинг
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Мониторинг активных улучшений и последних изменений уровней через официальный Supercell API
          </p>
          {state.syncConfig.lastSyncAt && (
            <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
              <Clock className="h-3.5 w-3.5 text-amber-400" />
              <span>
                Последняя синхронизация: {formatDateTimeRu(state.syncConfig.lastSyncAt)} ({formatRelativeTimeRu(state.syncConfig.lastSyncAt, nowMs)})
              </span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onSyncNow}
            disabled={showLiveProgress || !state.clan}
            className="inline-flex items-center justify-center gap-2.5 rounded-lg bg-amber-500 px-5 py-3 text-xs sm:text-sm font-bold text-slate-950 transition-colors hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap"
          >
            <RefreshCw className={`h-4 w-4 ${showLiveProgress ? 'animate-spin' : ''}`} />
            <span>{showLiveProgress ? 'СИНХРОНИЗАЦИЯ...' : 'СИНХРОНИЗИРОВАТЬ ДАННЫЕ'}</span>
          </button>
        </div>
      </section>

      {/* Live Sync Progress / Summary */}
      {showLiveProgress && (
        <section className="rounded-lg border border-amber-500/40 bg-[#121824] p-4 space-y-2.5">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <span className="inline-flex items-center gap-2 font-semibold text-amber-300">
              <Loader2 className="h-4 w-4 animate-spin" />
              {syncProgress?.statusText || 'Синхронизация с Supercell API...'}
            </span>
            <span className="font-mono text-slate-300">{pctNow}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
            <div className="h-full bg-amber-500 transition-all" style={{ width: `${pctNow}%` }} />
          </div>
          <div className="flex flex-wrap gap-6 text-xs font-mono text-slate-300">
            <span>Проверено: {checkedNow} / {totalNow}</span>
            <span>Обнаружено изменений API: {syncProgress?.upgradesFound ?? 0}</span>
          </div>
        </section>
      )}

      {!showLiveProgress && lastSyncSummary && (
        <section className="rounded-lg border border-slate-700 bg-[#121824] px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 font-medium text-slate-100">
            {lastSyncSummary.errorMessage ? (
              <AlertCircle className="h-4 w-4 text-rose-400" />
            ) : (
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            )}
            <span>
              {lastSyncSummary.errorMessage
                ? `Ошибка синхронизации: ${lastSyncSummary.errorMessage}`
                : `Синхронизация выполнена · Проверено участников: ${lastSyncSummary.checkedMembers} · Обнаружено повышений уровней: ${lastSyncSummary.upgradesFound}`}
            </span>
          </div>
          <span className="font-mono text-slate-400">
            {formatDateTimeRu(lastSyncSummary.completedAt)}
          </span>
        </section>
      )}

      {/* 3 Big Village Switchers + All */}
      <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(
          [
            {
              id: 'all' as const,
              title: 'ВСЕ ДЕРЕВНИ',
              subtitle: 'Сводка по всем базам',
              icon: Hammer,
              activeCount: countsByVillage.active.all,
              detectedCount: countsByVillage.detected.all,
            },
            {
              id: 'home' as const,
              title: 'HOME VILLAGE',
              subtitle: 'Родная деревня',
              icon: Building2,
              activeCount: countsByVillage.active.home,
              detectedCount: countsByVillage.detected.home,
            },
            {
              id: 'builderBase' as const,
              title: 'BUILDER BASE',
              subtitle: 'Деревня строителя',
              icon: Wrench,
              activeCount: countsByVillage.active.builderBase,
              detectedCount: countsByVillage.detected.builderBase,
            },
            {
              id: 'clanCapital' as const,
              title: 'CLAN CAPITAL',
              subtitle: 'Столица клана',
              icon: Castle,
              activeCount: countsByVillage.active.clanCapital,
              detectedCount: countsByVillage.detected.clanCapital,
            },
          ]
        ).map((v) => {
          const Icon = v.icon;
          const active = villageFilter === v.id;
          return (
            <button
              key={v.id}
              type="button"
              onClick={() => setVillageFilter(v.id)}
              className={`rounded-xl border p-4 text-left transition-all ${
                active
                  ? 'border-amber-500 bg-amber-500/12 shadow-lg shadow-amber-500/5'
                  : 'border-slate-800 bg-[#121824] hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-2 font-display text-xs font-bold tracking-wider text-slate-300">
                  <Icon className={`h-4 w-4 ${active ? 'text-amber-400' : 'text-slate-400'}`} />
                  {v.title}
                </span>
                <span className="font-mono text-sm font-bold tabular-nums text-emerald-400">
                  {v.detectedCount} изм.
                </span>
              </div>
              <div className="mt-1 flex items-center justify-between text-xs text-slate-400">
                <span>{v.subtitle}</span>
                {v.activeCount > 0 && (
                  <span className="font-mono text-amber-300">Таймеры: {v.activeCount}</span>
                )}
              </div>
            </button>
          );
        })}
      </section>

      {/* Honest Supercell API Limitation Note */}
      <section className="flex items-start gap-3 rounded-lg border border-amber-500/30 bg-[#121824] px-4 py-3.5 text-xs text-slate-300 leading-relaxed">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <div className="space-y-1">
          <div className="font-semibold text-slate-100">
            Информация о текущем строительстве зданий и активных таймерах недоступна через официальный Supercell API
          </div>
          <p className="text-slate-400">
            Официальный API Clash of Clans не передаёт список активных строителей, очереди лаборатории, уровни отдельных оборонительных зданий и оставшееся время улучшений.
            Это <strong className="text-slate-200">ограничение самого API игры</strong>, а не отсутствие улучшений у игроков.
            При каждой синхронизации приложение автоматически проверяет все профили участников, отслеживает изменения уровней Ратуши, Дома строителя, героев, снаряжения, войск, заклинаний, питомцев, осадных машин и районов Столицы и сохраняет каждое завершённое улучшение в истории.
          </p>
        </div>
      </section>

      {/* Filter Toolbar */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        {allEntries.length > 0 ? (
          <div className="flex flex-wrap items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
            {(
              [
                { id: 'all', label: 'Все статусы' },
                { id: 'in_progress', label: 'В процессе' },
                { id: 'completed', label: 'Завершено' },
              ] as const
            ).map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => setStatusFilter(st.id)}
                className={`px-3 py-1.5 text-xs rounded transition-colors whitespace-nowrap ${
                  statusFilter === st.id
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        ) : (
          <div className="text-xs text-slate-400">
            Фильтр по игроку и объекту для отслеживания изменений и покрытию участников:
          </div>
        )}

        <div className="relative w-full lg:w-80">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск игрока, #тега или объекта..."
            className="w-full rounded-md border border-slate-800 bg-[#0B0F17] py-2 pl-9 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
          />
        </div>
      </section>

      {/* Optional Active Timers Cards (only rendered if optional timers exist) */}
      {filteredEntries.length > 0 ? (
        <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {filteredEntries.map((item) => {
            const isInProgress = item.status === 'in_progress';
            const countdown = isInProgress ? formatCountdownRu(item.estimatedFinishesAt, nowMs) : null;

            return (
              <div
                key={item.id}
                className={`rounded-xl border p-5 space-y-4 transition-colors ${
                  isInProgress
                    ? 'border-amber-500/50 bg-[#121824] shadow-lg shadow-amber-500/5'
                    : 'border-emerald-500/35 bg-[#121824]'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <button
                    type="button"
                    onClick={() => onSelectPlayer(item.playerTag)}
                    className="text-left hover:text-amber-400 transition-colors"
                  >
                    <div className="font-display text-base font-bold text-slate-100">
                      {item.playerName}
                    </div>
                    <div className="mt-0.5 flex items-center gap-2 font-mono text-xs text-slate-400">
                      <span>{item.playerTag}</span>
                      <span>·</span>
                      <span className="text-amber-300 font-semibold">
                        {getVillageShortTitle(item.village)}
                      </span>
                      <span className="text-slate-500">({getVillageRuTitle(item.village)})</span>
                    </div>
                  </button>

                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 font-mono text-[11px] font-bold tracking-wide ${
                        isInProgress
                          ? 'border-amber-500/50 bg-amber-500/15 text-amber-300'
                          : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                      }`}
                    >
                      {isInProgress && (
                        <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                      )}
                      <span>{isInProgress ? 'УЛУЧШАЕТСЯ' : 'ЗАВЕРШЕНО'}</span>
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Источник: <strong className="text-sky-300">{getDataSourceLabel(item.source)}</strong>
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <CocUnitBadge
                      detailType={item.detailType}
                      apiName={item.objectName}
                      size="lg"
                    />
                    <div className="min-w-0">
                      <div className="text-lg font-bold text-slate-100 truncate">
                        {item.objectName}
                      </div>
                      {item.objectNameRu !== item.objectName && (
                        <div className="text-xs text-slate-400">{item.objectNameRu}</div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 rounded-lg border border-slate-700/80 bg-[#0B0F17] px-4 py-2.5 font-mono tabular-nums shrink-0">
                    <span className="text-lg font-semibold text-slate-300">
                      Ур. {item.fromLevel}
                    </span>
                    <ArrowRight className={`h-5 w-5 ${isInProgress ? 'text-amber-400' : 'text-emerald-400'}`} />
                    <span className={`text-2xl font-extrabold ${isInProgress ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {item.toLevel}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2 rounded-lg border border-slate-800/80 bg-[#0B0F17] p-3 text-xs font-mono sm:grid-cols-2">
                  <div className="text-slate-400">
                    Обнаружено: <span className="text-slate-200">{formatDateTimeRu(item.detectedAt)}</span>
                  </div>
                  <div className="text-slate-400">
                    Последнее подтверждение:{' '}
                    <span className="text-slate-200">{formatDateTimeRu(item.lastConfirmedAt)}</span>
                  </div>
                  {isInProgress && (
                    <div className="sm:col-span-2 pt-1 border-t border-slate-800/80 flex items-center gap-2">
                      <Clock className={`h-3.5 w-3.5 ${countdown?.expired ? 'text-amber-400' : 'text-emerald-400'}`} />
                      <span className={countdown?.expired ? 'text-amber-300' : 'text-emerald-300 font-semibold'}>
                        {countdown ? countdown.label : 'Оставшееся время недоступно в источнике'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </section>
      ) : (
        <section className="rounded-xl border border-slate-800 bg-[#121824] p-6 text-center space-y-2">
          <div className="text-sm font-semibold text-slate-200">
            Таймеры активного строительства зданий не предоставляются Supercell API
          </div>
          <p className="mx-auto max-w-2xl text-xs text-slate-400 leading-relaxed">
            Официальный API Clash of Clans возвращает текущие уровни всех юнитов, героев, снаряжения, заклинаний, питомцев и ратуши, но не содержит активных таймеров стройки.
            Как только любой участник клана завершит улучшение — оно автоматически зафиксируется при синхронизации в блоке ниже и в разделе «История улучшений».
          </p>
        </section>
      )}

      {/* Recent Auto-Detected API Upgrades */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-5 py-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Последние автоматически обнаруженные изменения (Supercell API)
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Реальные повышения уровней, зафиксированные при сравнении снимков участников ({filteredRecentApiUpgrades.length})
            </p>
          </div>
          <span className="font-mono text-xs text-emerald-400">Источник: Supercell API</span>
        </div>

        {filteredRecentApiUpgrades.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400 leading-relaxed">
            Новых завершённых повышений уровней для выбранного фильтра пока не зафиксировано. При последующих синхронизациях после повышения уровня у кого-либо из участников запись появится здесь и останется в постоянной истории.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70">
            {filteredRecentApiUpgrades.map((ev) => {
              const dt = resolveUpgradeDetailType(ev);
              const objName = ev.apiName || ev.itemNameRu;
              const village = resolveUpgradeVillage(ev);
              return (
                <div
                  key={ev.id}
                  className="flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <CocUnitBadge
                      detailType={dt}
                      apiName={objName}
                      isSuperTroop={ev.isSuperTroop}
                      size="md"
                    />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        {village === 'clanCapital' ? (
                          <span className="font-semibold text-emerald-300">{ev.playerName}</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectPlayer(ev.playerTag)}
                            className="font-semibold text-slate-100 hover:text-amber-400"
                          >
                            {ev.playerName}
                          </button>
                        )}
                        <span className="font-mono text-slate-500">{ev.playerTag}</span>
                        <span className="text-slate-600">·</span>
                        <span className="font-mono text-sky-300">{getVillageShortTitle(village)}</span>
                      </div>
                      <div className="mt-0.5 text-sm font-bold text-amber-400">
                        {objName}
                      </div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                        <span>{getUpgradeCategoryShortLabel(dt)}</span>
                        <span>·</span>
                        <span className="font-mono">{formatDateTimeRu(ev.detectedAt || ev.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-sm font-bold tabular-nums shrink-0 pl-12 sm:pl-0">
                    <span className="text-slate-400">Ур. {ev.fromLevel}</span>
                    <ArrowRight className="h-4 w-4 text-emerald-400" />
                    <span className="text-lg text-emerald-400">{ev.toLevel}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Per-Member API Monitoring Coverage */}
      {state.players.length > 0 && (
        <section className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden">
          <div className="border-b border-slate-800 px-5 py-4">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Покрытие мониторинга участников через Supercell API ({state.players.length})
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Полные профили игроков (герои, снаряжение, войска, заклинания, питомцы, осадные машины, ТХ и ДС) отслеживаются автоматически без ручного импорта
            </p>
          </div>
          <div className="divide-y divide-slate-800/70">
            {state.players
              .filter((p) => {
                const q = searchQuery.trim().toLowerCase();
                if (!q) return true;
                return `${p.name} ${p.tag}`.toLowerCase().includes(q);
              })
              .map((p) => {
                const trackedCount =
                  p.apiHeroes.length +
                  p.apiHeroEquipment.length +
                  p.apiTroops.length +
                  p.apiSpells.length +
                  p.apiPets.length +
                  p.apiSiegeMachines.length;
                return (
                  <div
                    key={p.tag}
                    className="flex flex-col gap-2 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between text-xs"
                  >
                    <div>
                      <button
                        type="button"
                        onClick={() => onSelectPlayer(p.tag)}
                        className="font-semibold text-sm text-slate-100 hover:text-amber-400 transition-colors"
                      >
                        {p.name}{' '}
                        <span className="font-mono text-xs font-normal text-slate-400">
                          {p.tag} · TH{p.townHallLevel}
                          {p.townHallWeaponLevel ? ` (ор. ${p.townHallWeaponLevel})` : ''} / BH{p.builderHallLevel || '—'}
                        </span>
                      </button>
                      <div className="mt-0.5 text-slate-400 font-mono">
                        API обновлён: {formatDateTimeRu(p.lastSyncedAt)} · Героев: {p.apiHeroes.length} · Снаряжения: {p.apiHeroEquipment.length} · Войск: {p.apiTroops.length} · Закл.: {p.apiSpells.length}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 font-mono">
                      <span className="inline-flex items-center gap-1.5 rounded border border-emerald-500/35 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-300">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Отслеживается ({trackedCount} поз. API)</span>
                      </span>
                    </div>
                  </div>
                );
              })}
          </div>
        </section>
      )}
    </div>
  );
};
