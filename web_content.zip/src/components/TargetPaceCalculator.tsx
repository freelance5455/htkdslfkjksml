import React, { useState } from 'react';
import {
  calculate1600mSplits,
  calculateCustomDistanceSplit,
  calculateTrainingPaces,
  parseTimeToSeconds,
} from '../utils/runningCalculations';
import { Timer, Zap, Compass, Info, Check } from 'lucide-react';

interface TargetPaceCalculatorProps {
  initialTarget?: string; // default "4:50"
  baselinePb?: string; // default "5:30"
}

export const TargetPaceCalculator: React.FC<TargetPaceCalculatorProps> = ({
  initialTarget = '4:50',
  baselinePb = '5:30',
}) => {
  const [targetTimeStr, setTargetTimeStr] = useState(initialTarget);
  const [selectedCustomDistance, setSelectedCustomDistance] = useState<number>(400);

  const targetSeconds = parseTimeToSeconds(targetTimeStr);
  const baselineSeconds = parseTimeToSeconds(baselinePb);

  const splits1600m = calculate1600mSplits(targetSeconds);
  const sustainablePaces = calculateTrainingPaces(baselineSeconds);

  const customDistances = [100, 200, 400, 800, 1000, 1500, 1600];
  const customSplitResult = calculateCustomDistanceSplit(selectedCustomDistance, targetSeconds);

  return (
    <div className="space-y-4">
      {/* Target Setup Header */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Timer className="w-5 h-5 text-[#00FF66]" />
            <h2 className="font-athletic text-lg font-black uppercase text-white">
              Target Pace Calculator
            </h2>
          </div>
          <span className="text-xs font-mono-numbers px-2 py-0.5 rounded bg-[#00FF66]/20 text-[#00FF66] font-bold border border-[#00FF66]/30">
            1600M Focus
          </span>
        </div>

        {/* Target Time Selector Pills */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 block mb-2">
            Goal 1600m Finish Time
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {['4:40', '4:45', '4:50', '5:00', '5:15'].map((time) => (
              <button
                key={time}
                onClick={() => setTargetTimeStr(time)}
                className={`py-2 rounded-xl font-mono-numbers text-xs font-bold transition ${
                  targetTimeStr === time
                    ? 'bg-[#00FF66] text-black shadow-md glow-neon-sm'
                    : 'bg-black border border-zinc-800 text-zinc-300 hover:border-zinc-600'
                }`}
              >
                {time}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Official 1600m Lap Splits Matrix */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white mb-3 flex items-center justify-between">
          <span>Target Splits for {targetTimeStr} Finish</span>
          <span className="text-xs text-[#00FF66] font-mono-numbers">
            {(targetSeconds / 4).toFixed(1)}s / lap
          </span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {splits1600m.map((split, i) => (
            <div
              key={split.distance}
              className="bg-black/60 border border-zinc-800/90 rounded-xl p-3 text-center relative overflow-hidden"
            >
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">
                {split.distance}
              </span>
              <p className="font-mono-numbers text-xl font-black text-white mt-1">
                {split.targetSplit}
              </p>
              <span className="text-[10px] text-[#00FF66] font-mono-numbers block mt-0.5">
                Total: {split.cumulativeTime}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Custom Distance Split Selector */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white mb-2">
          Custom Distance Calculator
        </h3>
        <p className="text-xs text-zinc-400 mb-3">
          Exact repetition split at {targetTimeStr} ({(targetSeconds / 1.6).toFixed(1)}s/km) pace:
        </p>

        {/* Distance Chips */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {customDistances.map((dist) => (
            <button
              key={dist}
              onClick={() => setSelectedCustomDistance(dist)}
              className={`px-3 py-1.5 rounded-xl font-mono-numbers text-xs font-bold transition ${
                selectedCustomDistance === dist
                  ? 'bg-white text-black'
                  : 'bg-black border border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {dist}m
            </button>
          ))}
        </div>

        {/* Custom Split Output Card */}
        <div className="p-3.5 bg-black/70 border border-zinc-800 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-zinc-400 uppercase font-semibold">
              {selectedCustomDistance}m Repetition Time:
            </span>
            <h4 className="font-mono-numbers text-2xl font-black text-[#00FF66]">
              {customSplitResult.timeFormatted}
            </h4>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-zinc-400 block">Required Pace:</span>
            <span className="font-mono-numbers text-sm font-bold text-white">
              {customSplitResult.paceMinKm} /km
            </span>
          </div>
        </div>
      </div>

      {/* Sustainable Training Pace Guidelines (CRITICAL REQUIREMENT #5) */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex items-start gap-2 text-xs text-zinc-300">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-snug">
            <strong>Important Coaching Discipline:</strong> Do not run at target 4:50 race pace during every session! Training pace must be guided by current sustainable physiological zones:
          </p>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-2.5 bg-black/40 border border-zinc-800/80 rounded-xl flex justify-between items-center">
            <div>
              <span className="font-bold text-white block">Easy Aerobic Base Runs</span>
              <span className="text-[10px] text-zinc-400">Conversational 3:3 breathing effort</span>
            </div>
            <span className="font-mono-numbers font-bold text-[#00FF66]">
              {sustainablePaces.easyAerobicPace}
            </span>
          </div>

          <div className="p-2.5 bg-black/40 border border-zinc-800/80 rounded-xl flex justify-between items-center">
            <div>
              <span className="font-bold text-white block">Tempo / Lactate Threshold</span>
              <span className="text-[10px] text-zinc-400">Controlled hard 2:2 breathing</span>
            </div>
            <span className="font-mono-numbers font-bold text-amber-400">
              {sustainablePaces.tempoLactatePace}
            </span>
          </div>

          <div className="p-2.5 bg-black/40 border border-zinc-800/80 rounded-xl flex justify-between items-center">
            <div>
              <span className="font-bold text-white block">Current 400m Repetition Pace</span>
              <span className="text-[10px] text-zinc-400">Sustainable intervals (baseline ~5:30)</span>
            </div>
            <span className="font-mono-numbers font-bold text-cyan-400">
              {sustainablePaces.interval400mPace}
            </span>
          </div>

          <div className="p-2.5 bg-black/40 border border-zinc-800/80 rounded-xl flex justify-between items-center">
            <div>
              <span className="font-bold text-white block">Target 400m Race Split</span>
              <span className="text-[10px] text-zinc-400">Goal sub-4:50</span>
            </div>
            <span className="font-mono-numbers font-bold text-[#00FF66]">
              {sustainablePaces.targetGoal400mPace}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
