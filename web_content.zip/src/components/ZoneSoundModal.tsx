import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Upload,
  Mic,
  Square,
  Volume2,
  Trash2,
  Sliders,
  Layers,
  Play,
  Music,
} from 'lucide-react';
import type {
  BuiltInSoundMeta,
  PadConfig,
  PadLayoutType,
  PadZoneConfig,
  PlaybackMode,
  StoredSound,
  VelocityMode,
  ZoneSplitMode,
} from '../types/octapad';
import { BUILT_IN_SOUNDS, audioEngine } from '../audio/synthEngine';

interface ZoneSoundModalProps {
  isOpen: boolean;
  pads: PadConfig[];
  selectedPadIndex: number;
  selectedZoneId: 'primary' | 'secondary';
  layoutType: PadLayoutType;
  customSounds: StoredSound[];
  initialTab?: 'sound' | 'zones';
  onClose: () => void;
  onSelectPadAndZone: (padIndex: number, zoneId: 'primary' | 'secondary') => void;
  onUpdatePad: (padIndex: number, updater: (pad: PadConfig) => PadConfig) => void;
  onImportFiles: (files: FileList, assignToPadIndex?: number, assignToZoneId?: 'primary' | 'secondary') => Promise<void>;
  onSaveRecordedSound: (blob: Blob, name: string, padIndex: number, zoneId: 'primary' | 'secondary') => Promise<void>;
  onDeleteCustomSound: (soundId: string) => Promise<void>;
}

const ACCENT_SWATCHES = [
  '#10d2f2',
  '#38bdf8',
  '#34d399',
  '#facc15',
  '#f97316',
  '#fb7185',
  '#a78bfa',
];

const CATEGORIES: Array<BuiltInSoundMeta['category']> = [
  'Timli & Folk',
  'Acoustic Kit',
  '808 & Trap',
  'Electro & Perc',
];

export const ZoneSoundModal: React.FC<ZoneSoundModalProps> = ({
  isOpen,
  pads,
  selectedPadIndex,
  selectedZoneId,
  layoutType,
  customSounds,
  initialTab = 'sound',
  onClose,
  onSelectPadAndZone,
  onUpdatePad,
  onImportFiles,
  onSaveRecordedSound,
  onDeleteCustomSound,
}) => {
  const [activeTab, setActiveTab] = useState<'sound' | 'zones'>(initialTab);
  const [activeCategory, setActiveCategory] = useState<BuiltInSoundMeta['category'] | 'Custom'>('Custom');
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      if (customSounds.length === 0 && activeCategory === 'Custom') {
        setActiveCategory('Timli & Folk');
      }
    }
  }, [isOpen, initialTab, customSounds.length]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  if (!isOpen) return null;

  const pad = pads[selectedPadIndex] ?? pads[0];
  const zoneIndex = selectedZoneId === 'secondary' && pad.splitMode !== 'single' ? 1 : 0;
  const activeZone = pad.zones[zoneIndex];

  const updateZone = (updater: (z: PadZoneConfig) => PadZoneConfig) => {
    onUpdatePad(pad.index, (p) => {
      const nextZones: [PadZoneConfig, PadZoneConfig] = [
        zoneIndex === 0 ? updater(p.zones[0]) : p.zones[0],
        zoneIndex === 1 ? updater(p.zones[1]) : p.zones[1],
      ];
      return { ...p, zones: nextZones };
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setImportError(null);
    setIsImporting(true);
    try {
      await onImportFiles(files, pad.index, selectedZoneId);
      setActiveCategory('Custom');
    } catch (err) {
      setImportError(
        err instanceof Error ? err.message : 'Unable to decode audio file. Try WAV, MP3, or OGG.'
      );
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  const toggleMicRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    setImportError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const stamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        try {
          await onSaveRecordedSound(blob, `Mic Sample ${stamp}`, pad.index, selectedZoneId);
          setActiveCategory('Custom');
        } catch {
          setImportError('Could not process recorded audio sample.');
        }
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecordingSeconds(0);
      setIsRecording(true);
      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setImportError('Microphone permission denied or unavailable.');
    }
  };

  const assignBuiltIn = (sound: BuiltInSoundMeta) => {
    const updated: PadZoneConfig = {
      ...activeZone,
      soundId: sound.id,
      soundName: sound.name,
      label: sound.name,
      isCustom: false,
      startOffset: 0,
      endOffset: 1,
      accentColor: sound.color,
    };
    updateZone(() => updated);
    audioEngine.triggerZone(`preview-${pad.index}-${zoneIndex}`, updated, 1.0);
  };

  const assignCustom = (sound: StoredSound) => {
    const updated: PadZoneConfig = {
      ...activeZone,
      soundId: sound.id,
      soundName: sound.name,
      label: sound.name,
      isCustom: true,
      startOffset: 0,
      endOffset: 1,
    };
    updateZone(() => updated);
    audioEngine.triggerZone(`preview-${pad.index}-${zoneIndex}`, updated, 1.0);
  };

  const auditionCurrentZone = () => {
    audioEngine.triggerZone(`preview-${pad.index}-${zoneIndex}`, activeZone, 1.0);
  };

  const customDuration = activeZone.isCustom
    ? audioEngine.getCustomBufferDuration(activeZone.soundId)
    : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#11151C] text-slate-100 border border-slate-800 w-full sm:max-w-3xl max-h-[92vh] sm:rounded-2xl rounded-t-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-slate-800 shrink-0">
          <div className="min-w-0">
            <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
              Pad {pad.index + 1} · {activeZone.label || activeZone.soundName}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 truncate">
              {pad.splitMode === 'single'
                ? 'Single Touch Zone'
                : `${pad.splitMode === 'center-rim' ? 'Center / Rim' : 'Dual Zone'} · Editing ${
                    zoneIndex === 0 ? 'Zone A (Primary)' : 'Zone B (Secondary)'
                  }`}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={auditionCurrentZone}
              className="min-h-[40px] px-3 py-1.5 rounded-lg bg-cyan-400/15 hover:bg-cyan-400/25 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Test Hit</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close modal"
              className="min-h-[40px] min-w-[40px] rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pad Selector Strip & Zone Switcher */}
        <div className="px-5 py-3 bg-[#0C0F14] border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {pads.map((p) => (
              <button
                key={p.index}
                type="button"
                onClick={() => onSelectPadAndZone(p.index, 'primary')}
                className={`min-h-[36px] min-w-[38px] px-2.5 rounded-lg font-mono-tabular text-xs font-bold transition-colors cursor-pointer ${
                  p.index === pad.index
                    ? 'bg-[#10D2F2] text-[#091117]'
                    : 'bg-[#1B202B] text-slate-300 hover:bg-[#242B38]'
                }`}
              >
                P{p.index + 1}
              </button>
            ))}
          </div>

          {pad.splitMode !== 'single' && (
            <div className="flex items-center bg-[#181C24] rounded-lg p-0.5 border border-slate-800">
              <button
                type="button"
                onClick={() => onSelectPadAndZone(pad.index, 'primary')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  zoneIndex === 0
                    ? 'bg-cyan-400 text-slate-950'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {pad.splitMode === 'center-rim' ? 'Center Zone' : 'Zone A'}
              </button>
              <button
                type="button"
                onClick={() => onSelectPadAndZone(pad.index, 'secondary')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                  zoneIndex === 1
                    ? 'bg-cyan-400 text-slate-950'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {pad.splitMode === 'center-rim' ? 'Rim Zone' : 'Zone B'}
              </button>
            </div>
          )}
        </div>

        {/* Main Section Tabs: Sound & Shaping vs Touch Zone Geometry */}
        <div className="px-5 pt-3 flex items-center gap-2 border-b border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('sound')}
            className={`pb-2.5 px-2 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'sound'
                ? 'border-[#10D2F2] text-[#10D2F2]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Custom Sound &amp; Shaping</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('zones')}
            className={`pb-2.5 px-2 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'zones'
                ? 'border-[#10D2F2] text-[#10D2F2]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Touch Zone Geometry</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {activeTab === 'sound' ? (
            <>
              {/* Import Custom Audio File / Record Mic */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*,.wav,.mp3,.ogg,.m4a,.aac,.flac"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={isImporting}
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[48px] px-4 py-3 rounded-xl bg-[#10D2F2] hover:bg-[#22d3ee] text-[#091117] font-bold text-xs tracking-wide flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
                >
                  <Upload className="w-4 h-4" />
                  <span>{isImporting ? 'Decoding Audio...' : 'Import Audio File (.wav, .mp3)'}</span>
                </button>

                <button
                  type="button"
                  onClick={toggleMicRecording}
                  className={`min-h-[48px] px-4 py-3 rounded-xl border font-bold text-xs tracking-wide flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    isRecording
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                      : 'bg-[#1B202B] hover:bg-[#242B38] border-slate-700 text-slate-200'
                  }`}
                >
                  {isRecording ? <Square className="w-4 h-4 fill-current" /> : <Mic className="w-4 h-4 text-cyan-400" />}
                  <span>
                    {isRecording
                      ? `Stop Recording (${recordingSeconds}s)`
                      : 'Record Mic Sample'}
                  </span>
                </button>
              </div>

              {importError && (
                <div className="px-3.5 py-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300">
                  {importError}
                </div>
              )}

              {/* Sound Library Browser */}
              <div className="space-y-3">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setActiveCategory('Custom')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      activeCategory === 'Custom'
                        ? 'bg-cyan-400/20 text-cyan-300 border border-cyan-400/40'
                        : 'bg-[#181C24] text-slate-400 hover:text-slate-200 border border-transparent'
                    }`}
                  >
                    My Imports ({customSounds.length})
                  </button>
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setActiveCategory(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                        activeCategory === cat
                          ? 'bg-cyan-400/20 text-cyan-300 border border-cyan-400/40'
                          : 'bg-[#181C24] text-slate-400 hover:text-slate-200 border border-transparent'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {activeCategory === 'Custom' ? (
                  customSounds.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-700/80 p-6 text-center">
                      <p className="text-sm font-medium text-slate-300">No custom drum sounds imported yet</p>
                      <p className="text-xs text-slate-500 mt-1">
                        Import .wav, .mp3, or .ogg samples from your device or record directly with your microphone.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                      {customSounds.map((sound) => {
                        const isAssigned = activeZone.isCustom && activeZone.soundId === sound.id;
                        return (
                          <div
                            key={sound.id}
                            className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl border transition-colors ${
                              isAssigned
                                ? 'bg-cyan-400/15 border-cyan-400/60'
                                : 'bg-[#171B23] border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <button
                              type="button"
                              onClick={() => assignCustom(sound)}
                              className="flex-1 min-w-0 text-left cursor-pointer"
                            >
                              <p className="text-xs font-semibold text-white truncate">{sound.name}</p>
                              <p className="font-mono-tabular text-[11px] text-slate-400">
                                {sound.duration.toFixed(2)}s
                              </p>
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteCustomSound(sound.id)}
                              aria-label={`Delete ${sound.name}`}
                              className="p-1.5 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
                    {BUILT_IN_SOUNDS.filter((s) => s.category === activeCategory).map((sound) => {
                      const isAssigned = !activeZone.isCustom && activeZone.soundId === sound.id;
                      return (
                        <button
                          key={sound.id}
                          type="button"
                          onClick={() => assignBuiltIn(sound)}
                          className={`px-3 py-2.5 rounded-xl border text-left transition-colors cursor-pointer flex items-center justify-between gap-2 ${
                            isAssigned
                              ? 'bg-cyan-400/15 border-cyan-400/60 text-cyan-200'
                              : 'bg-[#171B23] border-slate-800 hover:border-slate-700 text-slate-200'
                          }`}
                        >
                          <span className="text-xs font-medium truncate">{sound.name}</span>
                          <Volume2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Zone Sound Shaping */}
              <div className="pt-2 border-t border-slate-800/80 space-y-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Zone Sound Parameters
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      Pad Zone Label
                    </label>
                    <input
                      type="text"
                      value={activeZone.label}
                      maxLength={24}
                      onChange={(e) => updateZone((z) => ({ ...z, label: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      Hit Flash Color
                    </label>
                    <div className="flex items-center gap-2 pt-1">
                      {ACCENT_SWATCHES.map((hex) => (
                        <button
                          key={hex}
                          type="button"
                          onClick={() => updateZone((z) => ({ ...z, accentColor: hex }))}
                          aria-label={`Select color ${hex}`}
                          className={`w-6 h-6 rounded-md transition-transform cursor-pointer ${
                            activeZone.accentColor === hex
                              ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-[#11151C]'
                              : 'opacity-80 hover:opacity-100'
                          }`}
                          style={{ backgroundColor: hex }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">Volume</span>
                      <span className="font-mono-tabular text-slate-200">
                        {Math.round(activeZone.volume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1.2}
                      step={0.02}
                      value={activeZone.volume}
                      onChange={(e) =>
                        updateZone((z) => ({ ...z, volume: parseFloat(e.target.value) }))
                      }
                      className="w-full accent-[#10D2F2]"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">Pitch</span>
                      <span className="font-mono-tabular text-slate-200">
                        {activeZone.pitch > 0 ? `+${activeZone.pitch}` : activeZone.pitch} st
                      </span>
                    </div>
                    <input
                      type="range"
                      min={-12}
                      max={12}
                      step={1}
                      value={activeZone.pitch}
                      onChange={(e) =>
                        updateZone((z) => ({ ...z, pitch: parseInt(e.target.value, 10) }))
                      }
                      className="w-full accent-[#10D2F2]"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">Pan</span>
                      <span className="font-mono-tabular text-slate-200">
                        {activeZone.pan === 0
                          ? 'Center'
                          : activeZone.pan < 0
                            ? `L ${Math.round(Math.abs(activeZone.pan) * 100)}`
                            : `R ${Math.round(activeZone.pan * 100)}`}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={-1}
                      max={1}
                      step={0.05}
                      value={activeZone.pan}
                      onChange={(e) =>
                        updateZone((z) => ({ ...z, pan: parseFloat(e.target.value) }))
                      }
                      className="w-full accent-[#10D2F2]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      Trigger Mode
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 bg-[#0B0E14] p-1 rounded-lg border border-slate-800">
                      {(['one-shot', 'gate', 'loop'] as PlaybackMode[]).map((mode) => (
                        <button
                          key={mode}
                          type="button"
                          onClick={() => updateZone((z) => ({ ...z, playbackMode: mode }))}
                          className={`py-1.5 rounded-md text-xs font-semibold capitalize transition-colors cursor-pointer ${
                            activeZone.playbackMode === mode
                              ? 'bg-[#10D2F2] text-[#091117]'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {mode === 'one-shot' ? 'One-Shot' : mode === 'gate' ? 'Hold' : 'Loop'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      Choke / Mute Group
                    </label>
                    <select
                      value={activeZone.chokeGroup}
                      onChange={(e) =>
                        updateZone((z) => ({ ...z, chokeGroup: parseInt(e.target.value, 10) }))
                      }
                      className="w-full px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                    >
                      <option value={0}>None (Polyphonic)</option>
                      <option value={1}>Group 1 (e.g. Hi-Hat Choke)</option>
                      <option value={2}>Group 2</option>
                      <option value={3}>Group 3</option>
                      <option value={4}>Group 4</option>
                    </select>
                  </div>
                </div>

                {/* Custom Sample Trim Controls */}
                {activeZone.isCustom && customDuration !== null && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400">Sample Start Trim</span>
                        <span className="font-mono-tabular text-slate-200">
                          {(activeZone.startOffset * customDuration).toFixed(2)}s
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0.05, activeZone.endOffset - 0.05)}
                        step={0.01}
                        value={activeZone.startOffset}
                        onChange={(e) =>
                          updateZone((z) => ({ ...z, startOffset: parseFloat(e.target.value) }))
                        }
                        className="w-full accent-[#10D2F2]"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400">Sample End Trim</span>
                        <span className="font-mono-tabular text-slate-200">
                          {(activeZone.endOffset * customDuration).toFixed(2)}s
                        </span>
                      </div>
                      <input
                        type="range"
                        min={Math.min(0.95, activeZone.startOffset + 0.05)}
                        max={1}
                        step={0.01}
                        value={activeZone.endOffset}
                        onChange={(e) =>
                          updateZone((z) => ({ ...z, endOffset: parseFloat(e.target.value) }))
                        }
                        className="w-full accent-[#10D2F2]"
                      />
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* TOUCH ZONE GEOMETRY TAB */
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                  Pad {pad.index + 1} Touch Zone Split Layout
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {(
                    [
                      { id: 'single', label: 'Single Pad', desc: '1 full touch zone' },
                      { id: 'split-v', label: 'Left / Right', desc: '2 vertical zones' },
                      { id: 'split-h', label: 'Top / Bottom', desc: '2 horizontal zones' },
                      { id: 'center-rim', label: 'Center + Rim', desc: 'Concentric dual zone' },
                    ] as Array<{ id: ZoneSplitMode; label: string; desc: string }>
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() =>
                        onUpdatePad(pad.index, (p) => ({ ...p, splitMode: opt.id }))
                      }
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        pad.splitMode === opt.id
                          ? 'bg-cyan-400/15 border-cyan-400 text-white'
                          : 'bg-[#171B23] border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <p className="text-xs font-bold">{opt.label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{opt.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {(pad.splitMode === 'split-v' || pad.splitMode === 'split-h') && (
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-slate-300 font-medium">
                      Zone Split Ratio ({pad.splitMode === 'split-v' ? 'Left / Right' : 'Top / Bottom'})
                    </span>
                    <span className="font-mono-tabular text-cyan-300">
                      {Math.round(pad.splitRatio * 100)}% / {Math.round((1 - pad.splitRatio) * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.22}
                    max={0.78}
                    step={0.02}
                    value={pad.splitRatio}
                    onChange={(e) =>
                      onUpdatePad(pad.index, (p) => ({
                        ...p,
                        splitRatio: parseFloat(e.target.value),
                      }))
                    }
                    className="w-full accent-[#10D2F2]"
                  />
                </div>
              )}

              {pad.splitMode === 'center-rim' && (
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-slate-300 font-medium">Outer Rim Zone Thickness</span>
                    <span className="font-mono-tabular text-cyan-300">
                      {Math.round(pad.rimThickness * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.18}
                    max={0.45}
                    step={0.02}
                    value={pad.rimThickness}
                    onChange={(e) =>
                      onUpdatePad(pad.index, (p) => ({
                        ...p,
                        rimThickness: parseFloat(e.target.value),
                      }))
                    }
                    className="w-full accent-[#10D2F2]"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-slate-300 font-medium">Edge Deadzone (Hitbox Inset)</span>
                    <span className="font-mono-tabular text-cyan-300">{pad.hitboxInset}px</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={18}
                    step={1}
                    value={pad.hitboxInset}
                    onChange={(e) =>
                      onUpdatePad(pad.index, (p) => ({
                        ...p,
                        hitboxInset: parseInt(e.target.value, 10),
                      }))
                    }
                    className="w-full accent-[#10D2F2]"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Shrinks active touch zone inward to avoid accidental edge misfires.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Touch Velocity Response
                  </label>
                  <select
                    value={pad.velocityMode}
                    onChange={(e) =>
                      onUpdatePad(pad.index, (p) => ({
                        ...p,
                        velocityMode: e.target.value as VelocityMode,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="fixed">Fixed 100% (Live Stage Punch)</option>
                    <option value="radial">Radial (Center Loud / Edge Soft)</option>
                    <option value="vertical">Vertical (Bottom Loud / Top Soft)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Keyboard Trigger Key
                  </label>
                  <input
                    type="text"
                    maxLength={1}
                    value={pad.keyHint}
                    onChange={(e) =>
                      onUpdatePad(pad.index, (p) => ({
                        ...p,
                        keyHint: e.target.value.toUpperCase(),
                      }))
                    }
                    className="w-24 px-3 py-2 rounded-lg bg-[#0B0E14] border border-slate-800 font-mono-tabular text-sm font-bold text-center text-cyan-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {layoutType === 'freeform' && (
                <div className="pt-3 border-t border-slate-800 space-y-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Freeform Zone Coordinates (%)
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {(
                      [
                        { key: 'x', label: 'X Pos', min: 0, max: 85 },
                        { key: 'y', label: 'Y Pos', min: 0, max: 85 },
                        { key: 'w', label: 'Width', min: 12, max: 100 },
                        { key: 'h', label: 'Height', min: 14, max: 100 },
                      ] as const
                    ).map((field) => (
                      <div key={field.key}>
                        <div className="flex justify-between text-[11px] mb-1">
                          <span className="text-slate-400">{field.label}</span>
                          <span className="font-mono-tabular text-slate-200">
                            {Math.round(pad.layoutRect[field.key])}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min={field.min}
                          max={field.max}
                          step={1}
                          value={pad.layoutRect[field.key]}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            onUpdatePad(pad.index, (p) => ({
                              ...p,
                              layoutRect: {
                                ...p.layoutRect,
                                [field.key]: val,
                              },
                            }));
                          }}
                          className="w-full accent-[#10D2F2]"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
