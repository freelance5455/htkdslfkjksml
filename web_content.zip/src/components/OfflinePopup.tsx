import { AnimatePresence, motion } from 'motion/react';
import { WifiOff, X } from 'lucide-react';
import { TactileButton } from './InteractiveButton';

interface OfflinePopupProps {
  visible: boolean;
  onDismiss: () => void;
}

export function OfflinePopup({ visible, onDismiss }: OfflinePopupProps) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="offline-popup-title"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-7 shadow-xl text-center relative"
          >
            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onDismiss}
              aria-label="إغلاق التنبيه"
              className="absolute top-4 left-4 min-w-[44px] min-h-[44px] rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer active:shadow-none"
            >
              <X className="w-5 h-5" />
            </motion.button>

            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-orange-50 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 flex items-center justify-center">
              <WifiOff className="w-8 h-8" />
            </div>

            <h2
              id="offline-popup-title"
              className="font-display text-xl font-bold text-slate-900 dark:text-white mb-2"
            >
              أنت الآن في وضع عدم الاتصال
            </h2>

            <p className="text-slate-700 dark:text-slate-200 text-base font-medium leading-relaxed mb-4">
              افتح الإنترنت لاستخدام الذكاء الاصطناعي أو ما الجديد
            </p>

            <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
              موادي ومهامي ومؤقت بومودورو ودفتر الملاحظات تعمل جميعها بشكل كامل بدون إنترنت.
            </p>

            <TactileButton
              type="button"
              onClick={onDismiss}
              className="w-full py-3.5 px-6 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-base min-h-[48px]"
            >
              حسناً، متابعة المذاكرة
            </TactileButton>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
