import React from 'react';
import { useApp } from '../context/AppContext';
import { SecretGossipLogo } from './SecretGossipLogo';
import { 
  Flame, 
  Compass, 
  MessageCircle, 
  Gamepad2, 
  Trophy, 
  Share2, 
  User, 
  Plus, 
  ShieldCheck, 
  Coins, 
  Crown,
  Code
} from 'lucide-react';

export const DesktopNavSidebar: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    setIsCreateOpen, 
    setIsCollegeModalOpen, 
    setIsPremiumModalOpen,
    setIsExportModalOpen,
    user, 
    secretCoins,
    t 
  } = useApp();

  const navItems = [
    { id: 'feed', label: t.home, icon: Flame, badge: 'Live' },
    { id: 'explore', label: t.explore, icon: Compass },
    { id: 'chat', label: t.chat, icon: MessageCircle, badge: '4 Active' },
    { id: 'games', label: t.games, icon: Gamepad2 },
    { id: 'leaderboard', label: t.leaderboard, icon: Trophy },
    { id: 'referral', label: t.referral, icon: Share2, highlight: true },
    { id: 'profile', label: t.profile, icon: User },
  ];

  return (
    <aside className="w-64 xl:w-72 shrink-0 hidden lg:flex flex-col justify-between py-6 pr-4 pl-2 sticky top-0 h-screen overflow-y-auto border-r border-slate-800/80">
      
      {/* Top Brand + Navigation */}
      <div className="space-y-6">
        
        {/* Brand Logo */}
        <div 
          onClick={() => setActiveTab('feed')}
          className="cursor-pointer px-2"
        >
          <SecretGossipLogo size="md" />
        </div>

        {/* Verified College Chip */}
        <div className="px-2">
          <div 
            onClick={() => setIsCollegeModalOpen(true)}
            className="p-3 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/20 to-slate-900 border border-slate-800 hover:border-cyan-500/50 cursor-pointer transition-all group"
          >
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-[10px] uppercase font-mono text-cyan-400 font-bold tracking-wider">
                Current Campus
              </span>
              <span className="text-[10px] text-slate-500 group-hover:text-cyan-300 transition-colors">
                Switch ↻
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-base">🏛️</span>
              <div className="truncate">
                <p className="font-semibold text-xs text-slate-100 truncate">
                  {user.collegeName}
                </p>
                <p className="text-[10px] text-slate-400 font-mono">
                  {user.collegeCode} · {user.classInfo.split(' ')[0]}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Primary Navigation Links */}
        <nav className="space-y-1 px-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-2xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/15 via-purple-500/10 to-transparent border border-cyan-500/50 text-cyan-300 shadow-sm shadow-cyan-500/10'
                    : item.highlight
                    ? 'text-amber-300 hover:bg-amber-950/20 hover:text-amber-200 border border-amber-500/20'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/60 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : item.highlight ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {item.badge}
                  </span>
                )}

                {item.highlight && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                    +100 🪙
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Big Create Whisper Button */}
        <div className="px-2 pt-2">
          <button
            onClick={() => setIsCreateOpen(true)}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-purple-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-display font-extrabold text-xs tracking-wide transition-all shadow-lg shadow-cyan-500/25 active:scale-98 flex items-center justify-center gap-2 group"
          >
            <Plus className="w-4 h-4 stroke-[3] group-hover:rotate-90 transition-transform duration-300" />
            <span>Drop a Secret</span>
          </button>
        </div>

      </div>

      {/* Bottom Profile & Coins Card */}
      <div className="space-y-3 px-2 pt-4 border-t border-slate-800/80">
        
        {/* Secret Coins Chip */}
        <div 
          onClick={() => setActiveTab('referral')}
          className="p-3 rounded-2xl bg-slate-900/90 border border-amber-500/30 hover:border-amber-400/60 cursor-pointer transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">🪙</span>
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Secret Coins
              </span>
              <span className="font-mono text-xs font-bold text-amber-300 tabular-nums">
                {secretCoins} Coins
              </span>
            </div>
          </div>
          <span className="text-[10px] font-semibold text-cyan-400 hover:underline">
            Earn More →
          </span>
        </div>

        {/* User Persona Chip */}
        <div 
          onClick={() => setActiveTab('profile')}
          className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5 truncate">
            <div className="w-8 h-8 rounded-full bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-sm shrink-0">
              {user.avatarEmoji}
            </div>
            <div className="truncate">
              <p className="text-xs font-semibold text-slate-200 truncate">
                {user.avatarName}
              </p>
              <p className="font-mono text-[9px] text-slate-500 truncate">
                {user.secretHashId}
              </p>
            </div>
          </div>

          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>

      </div>

    </aside>
  );
};
