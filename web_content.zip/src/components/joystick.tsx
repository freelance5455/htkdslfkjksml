import { useEffect, useRef } from "react";

type Props = {
  onMove: (x: number, y: number) => void;
  onLook: (x: number, y: number) => void;
};

export function TouchControls({ onMove, onLook }: Props) {
  const moveRef = useRef<HTMLDivElement>(null);
  const lookRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const moveEl = moveRef.current;
    const lookEl = lookRef.current;
    if (!moveEl || !lookEl) return;
    let moveId: number | null = null;
    let lookId: number | null = null;
    let ox = 0;
    let oy = 0;
    let lx = 0;
    let ly = 0;

    const md = (e: PointerEvent) => {
      moveEl.setPointerCapture(e.pointerId);
      moveId = e.pointerId;
      ox = e.clientX;
      oy = e.clientY;
    };
    const mm = (e: PointerEvent) => {
      if (e.pointerId !== moveId) return;
      const dx = (e.clientX - ox) / 48;
      const dy = (e.clientY - oy) / 48;
      const m = Math.hypot(dx, dy) || 1;
      const s = m > 1 ? 1 / m : 1;
      onMove(dx * s, dy * s);
    };
    const mu = (e: PointerEvent) => {
      if (e.pointerId !== moveId) return;
      moveId = null;
      onMove(0, 0);
    };
    const ld = (e: PointerEvent) => {
      lookEl.setPointerCapture(e.pointerId);
      lookId = e.pointerId;
      lx = e.clientX;
      ly = e.clientY;
    };
    const lm = (e: PointerEvent) => {
      if (e.pointerId !== lookId) return;
      onLook(e.clientX - lx, e.clientY - ly);
      lx = e.clientX;
      ly = e.clientY;
    };
    const lu = (e: PointerEvent) => {
      if (e.pointerId !== lookId) return;
      lookId = null;
      onLook(0, 0);
    };

    moveEl.addEventListener("pointerdown", md);
    moveEl.addEventListener("pointermove", mm);
    moveEl.addEventListener("pointerup", mu);
    moveEl.addEventListener("pointercancel", mu);
    lookEl.addEventListener("pointerdown", ld);
    lookEl.addEventListener("pointermove", lm);
    lookEl.addEventListener("pointerup", lu);
    lookEl.addEventListener("pointercancel", lu);
    return () => {
      moveEl.removeEventListener("pointerdown", md);
      moveEl.removeEventListener("pointermove", mm);
      moveEl.removeEventListener("pointerup", mu);
      moveEl.removeEventListener("pointercancel", mu);
      lookEl.removeEventListener("pointerdown", ld);
      lookEl.removeEventListener("pointermove", lm);
      lookEl.removeEventListener("pointerup", lu);
      lookEl.removeEventListener("pointercancel", lu);
    };
  }, [onLook, onMove]);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 md:hidden">
      <div
        ref={moveRef}
        className="pointer-events-auto absolute bottom-20 left-5 size-[116px] rounded-full border border-border bg-surface/55"
        style={{ touchAction: "none" }}
      >
        <div className="absolute inset-7 rounded-full border border-border-strong bg-elevated/80" />
      </div>
      <div
        ref={lookRef}
        className="pointer-events-auto absolute top-16 right-0 bottom-28 w-[38%]"
        style={{ touchAction: "none" }}
      />
    </div>
  );
}
