import React, { useState } from 'react';
import { X, Check, Search, BookOpen, Award, CheckSquare, RefreshCw } from 'lucide-react';
import { ACADEMIC_SUBJECTS, COMPETITIVE_SUBJECTS } from '../presets';
import { getTranslatedSubjectName } from '../lib/languageUtils';

interface SubjectSelectionModalProps {
  language: string;
  selectedSubjects: string[];
  onSave: (newSubjects: string[]) => void;
  onClose: () => void;
}

export default function SubjectSelectionModal({
  language,
  selectedSubjects: initialSelected,
  onSave,
  onClose
}: SubjectSelectionModalProps) {
  const [selected, setSelected] = useState<string[]>(initialSelected && initialSelected.length > 0 ? initialSelected : ['Reasoning', 'General Knowledge', 'Current Affairs']);
  const [activeTab, setActiveTab] = useState<'academic' | 'competitive'>('academic');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const toggleSubject = (subjectName: string) => {
    setSelected(prev => {
      if (prev.includes(subjectName)) {
        if (prev.length === 1) {
          alert(language === 'bn' ? 'কমপক্ষে একটি বিষয় নির্বাচন করতে হবে!' : 'Select at least one subject!');
          return prev;
        }
        return prev.filter(s => s !== subjectName);
      } else {
        return [...prev, subjectName];
      }
    });
  };

  const handleSelectAllCategory = (list: string[]) => {
    const combined = Array.from(new Set([...selected, ...list]));
    setSelected(combined);
  };

  const handleClearCategory = (list: string[]) => {
    const remaining = selected.filter(s => !list.includes(s));
    if (remaining.length === 0) {
      alert(language === 'bn' ? 'কমপক্ষে একটি বিষয় সক্রিয় রাখা আবশ্যক!' : 'At least one subject must remain selected!');
      return;
    }
    setSelected(remaining);
  };

  const currentList = activeTab === 'academic' ? ACADEMIC_SUBJECTS : COMPETITIVE_SUBJECTS;
  const filteredList = currentList.filter(s => s.toLowerCase().includes(searchQuery.toLowerCase().trim()));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 md:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* MODAL HEADER */}
        <div className="bg-slate-800/90 border-b border-slate-700/80 px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600/30 border border-indigo-500/40 rounded-2xl text-indigo-400">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                {language === 'bn' ? 'পড়াশোনার বিষয়সমূহ বেছে নিন (Select Subjects)' : 'Select Study Subjects'}
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'bn' 
                  ? 'আপনার নির্বাচিত বিষয়গুলো থেকেই আজকের ১০০টি প্রশ্ন তৈরি হবে' 
                  : 'Your daily 100 questions will strictly be generated from these selected subjects'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 rounded-full transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS & CONTROLS */}
        <div className="p-4 md:px-6 bg-slate-900 border-b border-slate-800 space-y-3 shrink-0">
          {/* SEARCH BOX */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'bn' ? 'বিষয় অনুসন্ধান করুন... (যেমন: History, Reasoning, Science)' : 'Search subject... (e.g. Physics, History, Reasoning)'}
              className="w-full bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
          </div>

          {/* CATEGORY TABS & ACTION BUTTONS */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
            <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800">
              <button
                onClick={() => setActiveTab('academic')}
                className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'academic'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                {language === 'bn' ? 'একাডেমিক (Academic)' : 'Academic Subjects'}
              </button>
              <button
                onClick={() => setActiveTab('competitive')}
                className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'competitive'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Award className="w-4 h-4" />
                {language === 'bn' ? 'সাধারণ ও প্রতিযোগিতামূলক' : 'General & Competitive'}
              </button>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                onClick={() => handleSelectAllCategory(currentList)}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-bold rounded-xl border border-slate-700 transition-all cursor-pointer"
              >
                {language === 'bn' ? 'সবগুলো সিলেক্ট' : 'Select All'}
              </button>
              <button
                onClick={() => handleClearCategory(currentList)}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs font-bold rounded-xl border border-slate-700 transition-all cursor-pointer"
              >
                {language === 'bn' ? 'ক্লিয়ার' : 'Deselect Category'}
              </button>
            </div>
          </div>
        </div>

        {/* SUBJECT SELECTION GRID */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {filteredList.map((subject) => {
              const isChecked = selected.includes(subject);
              return (
                <button
                  key={subject}
                  type="button"
                  onClick={() => toggleSubject(subject)}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between gap-2 ${
                    isChecked
                      ? 'bg-indigo-900/40 border-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex flex-col max-w-[190px]">
                    <span className="font-extrabold text-xs truncate">
                      {getTranslatedSubjectName(subject, language)}
                    </span>
                    {getTranslatedSubjectName(subject, language) !== subject && (
                      <span className="text-[10px] text-slate-400 font-medium">
                        {subject}
                      </span>
                    )}
                  </div>
                  
                  <div className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 transition-all ${
                    isChecked
                      ? 'bg-indigo-600 border-indigo-400 text-white'
                      : 'border-slate-700 bg-slate-900 text-transparent'
                  }`}>
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                </button>
              );
            })}
          </div>

          {filteredList.length === 0 && (
            <div className="text-center py-12 text-slate-500 text-xs font-semibold">
              {language === 'bn' ? 'কোনো বিষয় পাওয়া যায়নি' : 'No subject matches your search'}
            </div>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="bg-slate-800/90 border-t border-slate-700/80 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-300 font-bold flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 rounded-lg">
              {selected.length} {language === 'bn' ? 'টি বিষয় নির্বাচিত' : 'Subjects Selected'}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              onClick={() => {
                onSave(selected);
                onClose();
              }}
              className="flex-1 sm:flex-initial px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              {language === 'bn' ? 'সংরক্ষণ ও প্রয়োগ করুন' : 'Save & Apply Subjects'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
