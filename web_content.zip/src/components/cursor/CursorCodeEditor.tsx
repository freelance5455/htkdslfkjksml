import React, { useState, useEffect, useRef } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-css';
import { 
  Code2, Play, Sparkles, Send, Bot, User, FileCode, 
  Copy, Check, Plus, Trash2, Terminal, RefreshCw, Wand2, 
  HelpCircle, Bug, CheckSquare, Layers 
} from 'lucide-react';
import { CodeFile } from '../../types';

interface Props {
  codeFiles: CodeFile[];
  onUpdateFile: (file: CodeFile) => void;
  onAddFile: (file: Omit<CodeFile, 'id'>) => void;
  onDeleteFile: (fileId: string) => void;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export const CursorCodeEditor: React.FC<Props> = ({
  codeFiles,
  onUpdateFile,
  onAddFile,
  onDeleteFile,
}) => {
  const [activeFileId, setActiveFileId] = useState<string>(codeFiles[0]?.id || '');
  const [activeFile, setActiveFile] = useState<CodeFile | undefined>(
    codeFiles.find((f) => f.id === activeFileId) || codeFiles[0]
  );
  const [currentCode, setCurrentCode] = useState<string>(activeFile?.content || '');

  // AI Chat Sidebar state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content:
        "Hello! I'm your Cursor-style AI coding companion. Ask me to write, refactor, explain, or optimize retail automation scripts, SQL queries, or POS logic.",
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Terminal / Run output state
  const [terminalOutput, setTerminalOutput] = useState<string | null>(null);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);

  // New File modal state
  const [isNewFileModalOpen, setIsNewFileModalOpen] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [newFileLang, setNewFileLang] = useState('typescript');

  const editorTextareaRef = useRef<HTMLTextAreaElement>(null);
  const codeHighlightRef = useRef<HTMLElement>(null);

  // Update active file when selection changes
  useEffect(() => {
    const file = codeFiles.find((f) => f.id === activeFileId);
    if (file) {
      setActiveFile(file);
      setCurrentCode(file.content);
    }
  }, [activeFileId, codeFiles]);

  // Syntax highlighting trigger
  useEffect(() => {
    if (codeHighlightRef.current) {
      Prism.highlightElement(codeHighlightRef.current);
    }
  }, [currentCode, activeFile?.language]);

  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setCurrentCode(val);
    if (activeFile) {
      onUpdateFile({ ...activeFile, content: val });
    }
  };

  // Run/Execute script simulation
  const handleRunCode = () => {
    setIsTerminalOpen(true);
    setTerminalOutput('Executing script in virtual runtime sandbox...\n');

    setTimeout(() => {
      try {
        if (activeFile?.language === 'javascript' || activeFile?.language === 'typescript') {
          // Safe evaluation of console outputs
          const logs: string[] = [];
          const customConsole = {
            log: (...args: any[]) => logs.push(args.map((a) => (typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a))).join(' ')),
            warn: (...args: any[]) => logs.push('[WARN] ' + args.join(' ')),
            error: (...args: any[]) => logs.push('[ERROR] ' + args.join(' ')),
          };

          // Simple safe regex evaluation simulation or quick test
          setTerminalOutput(
            `[Process exited with code 0 at ${new Date().toLocaleTimeString()}]\n` +
            `Output simulation:\n` +
            `> Compiled successfully with esbuild/tsx\n` +
            `> Daily Summary: { totalRevenue: 233.1, totalCost: 151.8, netProfit: 81.3, profitMarginPercent: 34.9, transactionsCount: 2 }`
          );
        } else if (activeFile?.language === 'sql') {
          setTerminalOutput(
            `[SQL Query Execution Completed: 2 rows affected, 12ms]\n\n` +
            `| id       | barcode     | name                 | stock | min_stock | suggested_order | est_cost |\n` +
            `|----------|-------------|----------------------|-------|-----------|-----------------|----------|\n` +
            `| prod-12  | 6281001012  | معجون أسنان 100 مل   | 1     | 5         | 9               | 81.00    |\n` +
            `| prod-8   | 6281001008  | مناديل ورقية ناعمة   | 2     | 8         | 14              | 196.00   |\n` +
            `| prod-6   | 6281001006  | سكر أبيض 2 كجم       | 3     | 6         | 9               | 58.50    |`
          );
        } else {
          setTerminalOutput(
            `[Process executed successfully]\n${activeFile?.name} output received without runtime errors.`
          );
        }
      } catch (err: any) {
        setTerminalOutput(`[Execution Error]: ${err?.message || 'Script syntax error'}`);
      }
    }, 400);
  };

  // AI Prompting
  const handleSendAiPrompt = async (presetMode?: string, promptText?: string) => {
    const query = promptText || chatInput.trim();
    if (!query && !presetMode) return;

    const userMessage = presetMode ? `${presetMode}: ${query || activeFile?.name}` : query;
    setChatMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setChatInput('');
    setIsAiLoading(true);

    try {
      const res = await fetch('/api/gemini/code-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMessage,
          code: currentCode,
          language: activeFile?.language || 'typescript',
          mode: presetMode,
        }),
      });

      const data = await res.json();
      if (data.error) {
        setChatMessages((prev) => [
          ...prev,
          { role: 'assistant', content: `Error: ${data.error}` },
        ]);
      } else {
        setChatMessages((prev) => [
          ...prev,
          { role: 'assistant', content: data.text || 'No response returned.' },
        ]);
      }
    } catch (err: any) {
      setChatMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Failed to connect to AI code assistant.' },
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Create new file
  const handleCreateNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    const newFile: Omit<CodeFile, 'id'> = {
      name: newFileName.trim(),
      language: newFileLang,
      content: `// ${newFileName.trim()}\n// Created on ${new Date().toLocaleDateString()}\n\n`,
    };

    onAddFile(newFile);
    setIsNewFileModalOpen(false);
    setNewFileName('');
  };

  // Helper to extract code block from AI response and apply to editor
  const handleApplyCodeToEditor = (content: string) => {
    const match = content.match(/```(?:\w+)?\n([\s\S]*?)```/);
    const codeToApply = match ? match[1] : content;
    setCurrentCode(codeToApply);
    if (activeFile) {
      onUpdateFile({ ...activeFile, content: codeToApply });
    }
  };

  // Line numbers calculation
  const lineCount = currentCode.split('\n').length;
  const lineNumbers = Array.from({ length: lineCount }, (_, i) => i + 1);

  return (
    <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-slate-950 font-mono text-xs select-text" dir="ltr">
      {/* Code Editor Main Column */}
      <div className="flex-1 flex flex-col border-r border-slate-800 overflow-hidden">
        {/* Top File Tabs Bar */}
        <div className="flex items-center justify-between bg-slate-900 border-b border-slate-800 px-2 pt-2">
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
            {codeFiles.map((file) => {
              const isActive = file.id === activeFileId;
              return (
                <div
                  key={file.id}
                  onClick={() => setActiveFileId(file.id)}
                  className={`group flex items-center gap-2 px-3 py-2 rounded-t-xl cursor-pointer border-t border-x text-xs transition ${
                    isActive
                      ? 'bg-slate-950 text-white border-slate-700 font-semibold shadow-inner'
                      : 'bg-slate-900/60 text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-850'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
                  <span>{file.name}</span>

                  {codeFiles.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteFile(file.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-0.5 rounded transition"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}

            <button
              onClick={() => setIsNewFileModalOpen(true)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              title="Add New File"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 pb-1.5">
            <button
              onClick={handleRunCode}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-md shadow-emerald-600/20 transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Script</span>
            </button>
          </div>
        </div>

        {/* Code Workspace: Line Numbers + Textarea Editor */}
        <div className="flex-1 relative overflow-hidden bg-slate-950 flex">
          {/* Line Numbers Column */}
          <div className="w-12 py-3 px-2 bg-slate-950/80 border-r border-slate-850 text-slate-600 text-right select-none font-mono text-[11px] leading-[1.6]">
            {lineNumbers.map((num) => (
              <div key={num}>{num}</div>
            ))}
          </div>

          {/* Code Textarea with Realtime Highlighting */}
          <div className="flex-1 relative overflow-auto font-mono text-[13px] leading-[1.6]">
            <textarea
              ref={editorTextareaRef}
              value={currentCode}
              onChange={handleCodeChange}
              spellCheck={false}
              className="w-full h-full p-3 bg-transparent text-slate-100 font-mono resize-none focus:outline-none focus:ring-0 leading-[1.6] tab-4 whitespace-pre font-['JetBrains_Mono',monospace]"
              style={{ minHeight: '100%' }}
            />
          </div>
        </div>

        {/* Output Console / Terminal */}
        {isTerminalOpen && (
          <div className="h-44 bg-slate-900 border-t border-slate-800 flex flex-col">
            <div className="flex items-center justify-between px-3 py-1.5 bg-slate-850 border-b border-slate-800 text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-bold text-slate-200">Execution Console</span>
              </div>
              <button
                onClick={() => setIsTerminalOpen(false)}
                className="text-slate-500 hover:text-white"
              >
                ✕
              </button>
            </div>
            <pre className="flex-1 p-3 overflow-y-auto text-[11px] font-mono text-emerald-400 whitespace-pre-wrap selection:bg-emerald-900">
              {terminalOutput}
            </pre>
          </div>
        )}

        {/* Status Bar */}
        <div className="px-3 py-1 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span>Language: <strong className="text-blue-400">{activeFile?.language}</strong></span>
            <span>Lines: {lineCount}</span>
            <span>UTF-8</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Cursor AI Ready</span>
          </div>
        </div>
      </div>

      {/* Cursor AI Chat Sidebar (Right side in LTR) */}
      <div className="w-full md:w-96 lg:w-[400px] bg-slate-900 flex flex-col shrink-0">
        {/* AI Sidebar Header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-850">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs flex items-center gap-1.5">
                <span>Cursor AI Assistant</span>
                <span className="text-[9px] bg-indigo-600/30 text-indigo-300 px-1.5 py-0.5 rounded font-mono">
                  Gemini 3.8
                </span>
              </h4>
              <p className="text-[10px] text-slate-400">Context: {activeFile?.name}</p>
            </div>
          </div>
        </div>

        {/* Fast Action Preset Chips */}
        <div className="p-2 border-b border-slate-800 bg-slate-950/40 flex flex-wrap gap-1.5">
          <button
            onClick={() => handleSendAiPrompt('Explain this code step by step')}
            disabled={isAiLoading}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-md text-[10px] border border-slate-700 transition"
          >
            <HelpCircle className="w-3 h-3 text-blue-400" />
            <span>Explain</span>
          </button>

          <button
            onClick={() => handleSendAiPrompt('Find potential bugs or edge cases in this code')}
            disabled={isAiLoading}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-md text-[10px] border border-slate-700 transition"
          >
            <Bug className="w-3 h-3 text-red-400" />
            <span>Find Bugs</span>
          </button>

          <button
            onClick={() => handleSendAiPrompt('Refactor and optimize for readability and performance')}
            disabled={isAiLoading}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-md text-[10px] border border-slate-700 transition"
          >
            <Wand2 className="w-3 h-3 text-purple-400" />
            <span>Optimize</span>
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {chatMessages.map((msg, idx) => {
            const isUser = msg.role === 'user';
            const hasCode = msg.content.includes('```');

            return (
              <div
                key={idx}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-6 h-6 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/30 mt-0.5">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[90%] p-3 rounded-xl text-xs leading-relaxed ${
                    isUser
                      ? 'bg-blue-600 text-white font-sans'
                      : 'bg-slate-800/90 text-slate-200 border border-slate-750 shadow-sm'
                  }`}
                >
                  <div className="whitespace-pre-wrap font-sans text-xs">{msg.content}</div>

                  {!isUser && hasCode && (
                    <div className="mt-2.5 pt-2 border-t border-slate-700 flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleApplyCodeToEditor(msg.content)}
                        className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold transition shadow-xs"
                      >
                        <CheckSquare className="w-3 h-3" />
                        <span>Apply to Editor</span>
                      </button>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}

          {isAiLoading && (
            <div className="flex items-center gap-2 text-slate-400 text-xs p-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-400" />
              <span>Cursor AI is thinking...</span>
            </div>
          )}
        </div>

        {/* Input prompt form */}
        <div className="p-3 bg-slate-850 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendAiPrompt();
            }}
            className="flex items-center gap-1.5"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask Cursor AI (e.g. Write a script to calculate vat)..."
              disabled={isAiLoading}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-sans"
            />
            <button
              type="submit"
              disabled={!chatInput.trim() || isAiLoading}
              className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl transition"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* New File Modal */}
      {isNewFileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 text-white">
            <h3 className="font-bold text-sm mb-3">Create New Script File</h3>
            <form onSubmit={handleCreateNewFile} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">File Name:</label>
                <input
                  type="text"
                  required
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="e.g. discount-calc.ts"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Language:</label>
                <select
                  value={newFileLang}
                  onChange={(e) => setNewFileLang(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs"
                >
                  <option value="typescript">TypeScript</option>
                  <option value="javascript">JavaScript</option>
                  <option value="sql">SQL</option>
                  <option value="python">Python</option>
                  <option value="json">JSON</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewFileModalOpen(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
