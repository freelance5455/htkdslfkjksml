import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { DriverTrip } from '../../types';
import {
  Truck,
  MapPin,
  Phone,
  Navigation,
  CheckCircle2,
  AlertCircle,
  Camera,
  Edit2,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Clock,
  Compass
} from 'lucide-react';

export const DriverApp: React.FC = () => {
  const {
    t,
    driverTrips,
    acceptDriverTrip,
    rejectDriverTrip,
    confirmLoading,
    startTripNavigation,
    completeDriverDelivery,
    orders
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'requests' | 'active_trip' | 'earnings'>('dashboard');
  const [selectedTripId, setSelectedTripId] = useState<string>('TRIP-7021');

  // Screen 32: Loading Confirmation state
  const [loadedVehicleNo, setLoadedVehicleNo] = useState('WB 39 B 4812');
  const [loadingConfirmed, setLoadingConfirmed] = useState(false);

  // Screen 34: Delivery confirmation state
  const [deliveryOtpInput, setDeliveryOtpInput] = useState('');
  const [deliveryOtpError, setDeliveryOtpError] = useState('');
  const [deliverySuccessMessage, setDeliverySuccessMessage] = useState('');
  const [signatureDrawn, setSignatureDrawn] = useState(false);

  // Signature canvas ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const activeTrip = driverTrips.find((t) => t.id === selectedTripId) || driverTrips[0];
  const relatedOrder = orders.find((o) => o.id === activeTrip?.orderId);

  // Signature canvas handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = '#e55938';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setSignatureDrawn(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureDrawn(false);
  };

  const handleCompleteDeliverySubmit = () => {
    if (!deliveryOtpInput) {
      setDeliveryOtpError('Please enter the customer 6-digit delivery OTP.');
      return;
    }
    if (!signatureDrawn) {
      setDeliveryOtpError('Customer signature is required before completing handover.');
      return;
    }

    const result = completeDriverDelivery(
      activeTrip.id,
      deliveryOtpInput,
      'Digital Signature Verified On-Site'
    );

    if (result.success) {
      setDeliverySuccessMessage(result.message);
      setDeliveryOtpError('');
      setTimeout(() => {
        setDeliverySuccessMessage('');
        setActiveTab('earnings');
      }, 2000);
    } else {
      setDeliveryOtpError(result.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Sub header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#131822] border border-[#242f40] p-2 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center">
            <Truck className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">
              Ramen Das • Transporter Fleet Portal
            </h2>
            <span className="text-[10px] text-slate-400 font-medium">
              Heavy 10-Wheeler (WB 39 B 4812) • Bholanath Roadways
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'dashboard' as const, label: 'Dashboard' },
            { id: 'active_trip' as const, label: '📍 Active Trip & Nav' },
            { id: 'requests' as const, label: 'Trip Requests (1)' },
            { id: 'earnings' as const, label: 'Driver Earnings' }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`driver-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-orange-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2432]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* =========================================================================
          SCREEN 29: DRIVER DASHBOARD
      ========================================================================= */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Metrics (Screen 29: Today's trips, Pending trips, Completed trips, Earnings) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">Today's Assigned Trips</span>
              <div className="text-2xl font-black text-white mt-1">2</div>
              <span className="text-[10px] text-emerald-400">1 in transit</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">Pending Requests</span>
              <div className="text-2xl font-black text-amber-400 mt-1">1</div>
              <span className="text-[10px] text-slate-400">Near Ghatakpukur Kiln</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">Completed Trips</span>
              <div className="text-2xl font-black text-white mt-1">14</div>
              <span className="text-[10px] text-emerald-400">This month</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">Today's Net Earnings</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">₹3,420</div>
              <span className="text-[10px] text-slate-400">+ Toll Allowance</span>
            </div>
          </div>

          {/* Active Trip Banner Card */}
          {activeTrip && (
            <div className="bg-gradient-to-r from-[#1b2330] via-[#161d28] to-[#121721] border border-[#28364b] rounded-2xl p-5 shadow-xl">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px] uppercase">
                      Current Active Transit
                    </span>
                    <span className="font-mono text-xs text-slate-400 font-bold">{activeTrip.id}</span>
                  </div>
                  <h3 className="text-lg font-bold text-white mt-1">
                    Delivering {activeTrip.brickQuantityThousand}k Bricks to Anandapur Site
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Kiln: {activeTrip.manufacturerName} • Payout: <strong className="text-emerald-400">₹{activeTrip.driverEarnings}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    id="resume-nav-btn"
                    onClick={() => setActiveTab('active_trip')}
                    className="px-4 py-2.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg shadow-orange-600/20 transition-colors cursor-pointer"
                  >
                    <Navigation className="w-4 h-4" />
                    <span>Open Live Navigation</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Recent Trips Table */}
          <div className="bg-[#141a24] border border-[#253243] rounded-2xl p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">
              All Haulage Trips
            </h3>
            <div className="space-y-3 text-xs">
              {driverTrips.map((trip) => (
                <div
                  key={trip.id}
                  className="p-3.5 bg-[#10141e] border border-[#222c3d] rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white">{trip.id}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          trip.status === 'delivered'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : trip.status === 'in_transit'
                            ? 'bg-orange-500/20 text-orange-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        {trip.status}
                      </span>
                    </div>
                    <p className="text-slate-300 mt-1">
                      {trip.customerName} • {trip.brickQuantityThousand}k Bricks ({trip.estimatedDistanceKm} km)
                    </p>
                    <p className="text-slate-400 text-[11px] truncate max-w-md">
                      To: {trip.destinationAddress}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400">Driver Payout</span>
                      <div className="font-bold text-emerald-400 text-sm">
                        ₹{trip.driverEarnings.toLocaleString()}
                      </div>
                    </div>
                    <button
                      id={`select-trip-${trip.id}`}
                      onClick={() => {
                        setSelectedTripId(trip.id);
                        setActiveTab('active_trip');
                      }}
                      className="px-3 py-1.5 bg-[#1e2736] hover:bg-[#283549] text-slate-200 font-semibold rounded-lg text-xs"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 30: TRIP REQUEST (Accept / Reject)
      ========================================================================= */}
      {activeTab === 'requests' && (
        <div className="max-w-2xl mx-auto space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-orange-400 tracking-wider">
              Screen 30 • Incoming Kiln Dispatch Requests
            </span>
            <h2 className="text-xl font-bold text-white">{t('tripRequests')}</h2>
          </div>

          {driverTrips
            .filter((t) => t.status === 'requested')
            .map((trip) => (
              <div
                key={trip.id}
                className="bg-[#151b25] border border-[#28364b] rounded-2xl p-6 shadow-xl space-y-4 text-xs"
              >
                <div className="flex items-center justify-between pb-3 border-b border-[#232f41]">
                  <div>
                    <span className="font-mono font-bold text-white text-base">{trip.id}</span>
                    <p className="text-slate-400 text-[11px]">Kiln: {trip.manufacturerName}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Net Payout</span>
                    <div className="text-xl font-black text-emerald-400">
                      ₹{trip.driverEarnings.toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="space-y-2.5 p-3.5 bg-[#10141e] border border-[#212b3c] rounded-xl">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Kiln Pickup:</span>
                      <p className="font-semibold text-white">{trip.pickupAddress}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 pt-2 border-t border-[#1e2736]">
                    <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Customer Site Destination:</span>
                      <p className="font-semibold text-white">{trip.destinationAddress}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center p-3 bg-[#10141e] rounded-xl">
                  <div>
                    <span className="text-[10px] text-slate-400">Load</span>
                    <div className="font-bold text-white">{trip.brickQuantityThousand}k Bricks</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Distance</span>
                    <div className="font-bold text-white">{trip.estimatedDistanceKm} km</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Vehicle Type</span>
                    <div className="font-bold text-amber-400 truncate">{trip.vehicleType}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    id={`accept-trip-${trip.id}`}
                    onClick={() => {
                      acceptDriverTrip(trip.id);
                      setSelectedTripId(trip.id);
                      setActiveTab('active_trip');
                    }}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition-colors cursor-pointer text-xs uppercase tracking-wider"
                  >
                    Accept Haulage Trip
                  </button>
                  <button
                    id={`reject-trip-${trip.id}`}
                    onClick={() => rejectDriverTrip(trip.id)}
                    className="px-5 py-3 bg-[#1e2634] hover:bg-rose-500/20 text-rose-300 font-semibold rounded-xl text-xs"
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
        </div>
      )}

      {/* =========================================================================
          SCREENS 31, 32, 33, 34: ACTIVE TRIP, NAVIGATION & DELIVERY CONFIRMATION
      ========================================================================= */}
      {activeTab === 'active_trip' && activeTrip && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Trip Details & Loading Confirmation (Screens 31 & 32) */}
          <div className="lg:col-span-1 space-y-4">
            {/* Screen 31: Trip Details */}
            <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-5 text-xs text-slate-300 space-y-3">
              <span className="text-[10px] uppercase font-bold text-orange-400 tracking-wider">
                Screen 31 • Trip & Consignment Info
              </span>
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-white text-base">{activeTrip.id}</span>
                <span className="px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 font-bold text-[10px]">
                  {activeTrip.status}
                </span>
              </div>

              <div className="space-y-2 p-3 bg-[#10141d] rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase">Customer</span>
                  <div className="font-semibold text-white">{activeTrip.customerName}</div>
                  <div className="text-[11px] text-slate-400">{activeTrip.customerMobile}</div>
                </div>
                <div className="pt-2 border-t border-[#1f2837]">
                  <span className="text-[10px] text-slate-400 uppercase">Load Details</span>
                  <div className="font-bold text-[#e55938]">
                    {activeTrip.brickQuantityThousand}k Bricks ({activeTrip.brickQuantityThousand * 1000} units)
                  </div>
                </div>
              </div>
            </div>

            {/* Screen 32: Kiln Loading Confirmation */}
            <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-5 text-xs text-slate-300 space-y-3">
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                Screen 32 • Kiln Loading Verification
              </span>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Registered Truck License Plate
                </label>
                <input
                  id="driver-vehicle-no-input"
                  type="text"
                  value={loadedVehicleNo}
                  onChange={(e) => setLoadedVehicleNo(e.target.value)}
                  className="w-full bg-[#10141d] border border-[#273344] rounded-xl px-3 py-2 text-white font-mono font-bold outline-none"
                />
              </div>

              <div className="p-3 bg-[#10141d] border border-dashed border-[#2b3749] rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Camera className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-400 text-[11px]">Kiln Loading Photo</span>
                </div>
                <span className="text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Attached
                </span>
              </div>

              {activeTrip.status !== 'in_transit' && activeTrip.status !== 'delivered' && (
                <button
                  id="confirm-loading-start-trip-btn"
                  onClick={() => {
                    confirmLoading(activeTrip.id, loadedVehicleNo);
                    startTripNavigation(activeTrip.id);
                  }}
                  className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-orange-600/20"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Verify Loading & Start Trip</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Column: Screen 33 Navigation & Screen 34 Delivery Handover */}
          <div className="lg:col-span-2 space-y-5">
            {/* Screen 33: Google Maps Integrated Navigation Screen */}
            <div className="bg-[#151b25] border border-[#263345] rounded-2xl overflow-hidden shadow-xl">
              <div className="p-4 bg-[#10141d] border-b border-[#232f41] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-orange-400 animate-spin" />
                  <span className="font-bold text-white text-xs">
                    Screen 33 • Turn-by-Turn GPS Guidance
                  </span>
                </div>
                <button
                  id="call-customer-driver-btn"
                  onClick={() => alert(`Calling customer ${activeTrip.customerName} at ${activeTrip.customerMobile}...`)}
                  className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Phone className="w-3 h-3" />
                  <span>Call Customer</span>
                </button>
              </div>

              {/* Turn Instruction Header banner */}
              <div className="p-3.5 bg-emerald-950/60 border-b border-emerald-800/40 text-emerald-200 text-xs flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500 text-black font-black text-sm flex items-center justify-center">
                  ↱
                </div>
                <div>
                  <div className="font-bold text-white text-sm">In 600m, take slight right onto EM Bypass</div>
                  <div className="text-[11px] text-emerald-300">Remaining to site: 11.4 km (ETA: 24 mins)</div>
                </div>
              </div>

              {/* Vector Map Container */}
              <div className="relative bg-[#0b0f15] min-h-[220px] p-4 flex items-center justify-center">
                <svg viewBox="0 0 450 180" className="w-full max-w-md h-auto">
                  <path
                    d="M 40 140 Q 200 40 400 60"
                    fill="none"
                    stroke="#1e293b"
                    strokeWidth="12"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 40 140 Q 200 40 400 60"
                    fill="none"
                    stroke="#e55938"
                    strokeWidth="6"
                    strokeDasharray="6 4"
                    strokeLinecap="round"
                  />
                  {/* Current driver truck */}
                  <g transform="translate(230, 72)">
                    <circle r="14" fill="#e55938" stroke="#fff" strokeWidth="2" className="animate-ping opacity-75" />
                    <circle r="10" fill="#e55938" />
                  </g>
                </svg>
              </div>
            </div>

            {/* Screen 34: Delivery Handover Confirmation (OTP + Signature) */}
            <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-5 text-xs text-slate-300 space-y-4">
              <div className="pb-3 border-b border-[#232f41]">
                <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                  Screen 34 • Site Handover & Unloading Verification
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">{t('completeDelivery')}</h3>
                <p className="text-slate-400 text-[11px]">
                  Requires customer OTP verification and digital signature upon brick unloading
                </p>
              </div>

              {deliverySuccessMessage && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 rounded-xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{deliverySuccessMessage}</span>
                </div>
              )}

              {deliveryOtpError && (
                <div className="p-3 bg-rose-500/20 border border-rose-500/30 text-rose-300 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400" />
                  <span>{deliveryOtpError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* OTP entry field */}
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    {t('customerOtp')} (Ask site receiver)
                  </label>
                  <input
                    id="driver-delivery-otp-input"
                    type="text"
                    maxLength={6}
                    value={deliveryOtpInput}
                    onChange={(e) => setDeliveryOtpInput(e.target.value)}
                    placeholder="e.g. 741852"
                    className="w-full bg-[#10141d] border border-[#283549] rounded-xl px-3.5 py-2.5 text-white font-mono text-center tracking-widest text-lg font-bold outline-none focus:border-emerald-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Customer sees this OTP in their live tracking dashboard.
                  </p>
                </div>

                {/* Delivered quantity */}
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Delivered Quantity
                  </label>
                  <div className="w-full bg-[#10141d] border border-[#283549] rounded-xl px-3.5 py-2.5 text-white font-semibold">
                    {activeTrip.brickQuantityThousand}k Bricks (All Intact)
                  </div>
                </div>
              </div>

              {/* Digital Signature Canvas Pad */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <Edit2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{t('customerSignature')} (Sign on Canvas)</span>
                  </label>
                  <button
                    id="clear-signature-btn"
                    onClick={clearSignature}
                    className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
                  >
                    Clear Signature
                  </button>
                </div>

                <div className="border border-[#28364b] bg-[#0c1017] rounded-xl overflow-hidden cursor-crosshair">
                  <canvas
                    ref={canvasRef}
                    width={480}
                    height={120}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="w-full h-[120px] block"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Draw signature above using touch or mouse pointer to authenticate site handover.
                </p>
              </div>

              <button
                id="submit-delivery-handover-btn"
                onClick={handleCompleteDeliverySubmit}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-emerald-600/25 text-xs uppercase tracking-wider"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Verify OTP & Complete Delivery</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 35: DRIVER EARNINGS
      ========================================================================= */}
      {activeTab === 'earnings' && (
        <div className="space-y-6">
          <div>
            <span className="text-[10px] uppercase font-bold text-orange-400 tracking-wider">
              Screen 35 • Transporter Payouts & Fuel Settlements
            </span>
            <h2 className="text-xl font-bold text-white">{t('driverEarnings')}</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-slate-400">Total Haulage Gross</span>
              <div className="text-2xl font-black text-white mt-1">₹42,800</div>
              <span className="text-[10px] text-slate-400">Across 14 completed trips</span>
            </div>
            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-slate-400">Platform Freight Cut (5%)</span>
              <div className="text-2xl font-black text-rose-400 mt-1">-₹2,140</div>
              <span className="text-[10px] text-slate-400">Brokerage & insurance</span>
            </div>
            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-slate-400">Net Settled to Bank</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">₹40,660</div>
              <span className="text-[10px] text-emerald-400">IMPS instantaneous transfer</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
