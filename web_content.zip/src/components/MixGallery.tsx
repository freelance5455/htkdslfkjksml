import React, { useState } from 'react';
import { Play, Pause, Download, Music, Flame, Headphones, Volume2, Sparkles, MessageCircle } from 'lucide-react';
import { MIXTAPE_GALLERY, MixtapeCover } from '../data/djData';
import { audioCues } from '../utils/audioCueEngine';

export const MixGallery: React.FC = () => {
  const [activeMixId, setActiveMixId] = useState<string>(MIXTAPE_GALLERY[0].id);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const activeMix = MIXTAPE_GALLERY.find((m) => m.id === activeMixId) || MIXTAPE_GALLERY[0];

  const handleTogglePlay = (mix: MixtapeCover) => {
    if (activeMixId === mix.id) {
      const playingState = audioCues.toggleAfrobeatLoop((status) => {
        setIsPlaying(status);
      });
      setIsPlaying(playingState);
    } else {
      setActiveMixId(mix.id);
      audioCues.stopAfrobeatLoop();
      const playingState = audioCues.toggleAfrobeatLoop((status) => {
        setIsPlaying(status);
      });
      setIsPlaying(playingState);
    }
  };

  const handleWhatsAppOrderMix = (mixTitle: string) => {
    const text = encodeURIComponent(
      `Hello DJ EVAN PRO UG! I would like to get the full audio file for *${mixTitle}* (or order a custom mixtape for UGX 50k). Please send me download details!`
    );
    window.open(`https://wa.me/256742094651?text=${text}`, '_blank');
  };

  return (
    <section id="mixtapes" className="py-14 px-4 max-w-6xl mx-auto">
      {/* Section Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-widest bg-cyan-950/60 px-3 py-1 rounded-full border border-cyan-800/40 mb-3">
          <Headphones className="w-3.5 h-3.5" />
          The Cue King Mixtape Vault
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
          Mix Gallery &amp; Live Drops
        </h2>
        <p className="text-sm text-slate-300 max-w-xl mx-auto mt-2">
          Stream signature mixes recorded live in Bwaise on Cross DJ Pro. Tap any mix cover to listen to the preview groove.
        </p>
      </div>

      {/* Featured Active Player Bar */}
      <div className="mb-10 bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border-2 border-purple-500/40 rounded-2xl p-4 sm:p-6 shadow-[0_0_35px_rgba(168,85,247,0.2)]">
        <div className="flex flex-col md:flex-row items-center justify-between gap-5">
          {/* Mini Album Cover & Title */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div
              className={`w-16 h-16 rounded-xl bg-gradient-to-br ${activeMix.gradient} border border-purple-500/50 flex items-center justify-center shadow-lg relative overflow-hidden shrink-0`}
            >
              <Music className="w-7 h-7 text-purple-300" />
              {isPlaying && (
                <div className="absolute inset-0 bg-purple-600/30 backdrop-blur-xs flex items-center justify-center gap-0.5">
                  <span className="w-1 h-6 bg-cyan-400 rounded-full animate-eq-1" />
                  <span className="w-1 h-8 bg-purple-400 rounded-full animate-eq-2" />
                  <span className="w-1 h-5 bg-pink-400 rounded-full animate-eq-3" />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono bg-purple-600/40 text-purple-200 px-2 py-0.5 rounded font-bold">
                  {isPlaying ? 'NOW PLAYING PREVIEW' : 'SELECT TO PLAY'}
                </span>
                <span className="text-xs text-slate-400 font-mono">{activeMix.duration}</span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
                {activeMix.title}
              </h3>
              <p className="text-xs text-cyan-400 font-medium">
                {activeMix.genre} • {activeMix.bpm}
              </p>
            </div>
          </div>

          {/* Player Controls & Waveform Simulation */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            <button
              onClick={() => handleTogglePlay(activeMix)}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-600 hover:brightness-110 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md active:scale-95"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              <span>{isPlaying ? 'Pause Preview' : 'Play Live Mix'}</span>
            </button>

            <button
              onClick={() => handleWhatsAppOrderMix(activeMix.title)}
              className="flex items-center gap-1.5 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md active:scale-95 whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>Get Full MP3 (Free)</span>
            </button>
          </div>
        </div>

        {/* Animated Soundwave Visualizer Bars */}
        <div className="mt-4 pt-3 border-t border-purple-900/40 flex items-center gap-1 sm:gap-1.5 h-6 overflow-hidden">
          {Array.from({ length: 36 }).map((_, i) => (
            <div
              key={i}
              className={`flex-1 rounded-full transition-all duration-300 ${
                isPlaying
                  ? 'bg-gradient-to-t from-purple-500 via-pink-400 to-cyan-300'
                  : 'bg-purple-950/60'
              }`}
              style={{
                height: isPlaying
                  ? `${Math.max(15, Math.sin(i * 0.4 + Date.now() / 300) * 85 + 15)}%`
                  : '25%',
              }}
            />
          ))}
        </div>
      </div>

      {/* Mixtape Gallery Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {MIXTAPE_GALLERY.map((mix) => (
          <div
            key={mix.id}
            className={`group rounded-2xl p-4 transition-all flex flex-col justify-between ${
              activeMixId === mix.id
                ? 'bg-[#150d27] border-2 border-purple-500 shadow-xl'
                : 'bg-[#0e091b] border border-purple-900/50 hover:border-purple-600/50'
            }`}
          >
            {/* Mixtape Album Art Placeholder Banner */}
            <div
              className={`relative w-full aspect-4/3 rounded-xl bg-gradient-to-br ${mix.gradient} border border-purple-700/40 p-4 flex flex-col justify-between overflow-hidden shadow-inner group-hover:scale-[1.01] transition-transform`}
            >
              {/* Graphic Vinyl Disc in Background */}
              <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full border-4 border-slate-800 bg-slate-950/80 opacity-60 flex items-center justify-center pointer-events-none group-hover:rotate-45 transition-transform duration-700">
                <div className="w-16 h-16 rounded-full border border-purple-500/40 bg-purple-900/40" />
              </div>

              {/* Tag header */}
              <div className="flex items-center justify-between z-10">
                <span className="text-[10px] font-black uppercase tracking-wider bg-black/70 backdrop-blur-xs text-white px-2.5 py-1 rounded-md border border-white/10">
                  {mix.releaseYear}
                </span>
                <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/40">
                  {mix.highlightTag}
                </span>
              </div>

              {/* Center Title in Cover Art */}
              <div className="z-10 my-auto text-center py-2">
                <p className="text-[10px] font-mono tracking-widest text-cyan-300 font-bold uppercase">
                  DJ EVAN PRO UG
                </p>
                <h4 className="text-lg sm:text-xl font-black text-white uppercase tracking-tight leading-tight drop-shadow-md">
                  {mix.title}
                </h4>
                <p className="text-[11px] text-purple-200 mt-1 font-semibold">
                  THE CUE KING MIXTAPE
                </p>
              </div>

              {/* Bottom metadata */}
              <div className="z-10 flex items-center justify-between text-[11px] text-slate-300 font-mono">
                <span>{mix.duration}</span>
                <span>{mix.bpm}</span>
              </div>
            </div>

            {/* Content Details */}
            <div className="mt-4">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="text-purple-300 font-bold">{mix.genre}</span>
                <span>{mix.downloadSize}</span>
              </div>

              {/* Tracklist Snippet */}
              <div className="bg-black/40 rounded-lg p-2.5 my-3 border border-purple-900/30 text-[11px] text-slate-300 space-y-1">
                <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                  Featured Vibes:
                </div>
                {mix.tracklistSnippet.map((track, i) => (
                  <div key={i} className="truncate text-slate-300 flex items-center gap-1.5">
                    <span className="text-purple-500">▶</span>
                    <span>{track}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => handleTogglePlay(mix)}
                  className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors ${
                    activeMixId === mix.id && isPlaying
                      ? 'bg-rose-600 text-white'
                      : 'bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-700/50'
                  }`}
                >
                  {activeMixId === mix.id && isPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5 fill-white" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>Preview</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => handleWhatsAppOrderMix(mix.title)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600/90 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-white" />
                  <span>Get on WA</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Custom Mix Production Upsell */}
      <div className="mt-12 bg-gradient-to-r from-purple-900/40 via-pink-950/30 to-purple-900/40 border border-purple-700/50 rounded-2xl p-6 text-center">
        <span className="text-xs font-mono font-bold text-yellow-300 uppercase tracking-widest bg-yellow-950/60 px-3 py-1 rounded-full border border-yellow-700/50">
          Studio Mixtape Service • UGX 50k
        </span>
        <h3 className="text-xl sm:text-2xl font-black text-white mt-2 mb-1">
          Want a Personalized Mixtape with Your Voice Drop?
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto mb-4">
          Send DJ Evan Pro your favorite 25 songs. He will mix them with seamless cues, custom DJ drops with your name, and deliver in 24 hours.
        </p>
        <a
          href="https://wa.me/256742094651?text=Hello%20DJ%20Evan!%20I%20want%20to%20order%20a%20Custom%20Mixtape%20for%2050k%20with%20my%20own%20tracklist%20and%20name%20drops."
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition-all"
        >
          <MessageCircle className="w-4 h-4 fill-white" />
          <span>Order 50k Mixtape on WhatsApp</span>
        </a>
      </div>
    </section>
  );
};
