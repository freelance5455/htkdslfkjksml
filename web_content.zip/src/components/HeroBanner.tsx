import React from 'react';
import { BookOpen, HelpCircle, Sparkles, CheckCircle2 } from 'lucide-react';

interface HeroBannerProps {
  language: 'om' | 'en';
  onStartAfaanOromoo: () => void;
  onStartQuiz: () => void;
  onOpenAiGenerator: () => void;
  totalModules: number;
  totalQuestions: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  language,
  onStartAfaanOromoo,
  onStartQuiz,
  onOpenAiGenerator,
  totalModules,
  totalQuestions,
}) => {
  return (
    <div className="bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 lg:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Heading and Value Proposition */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-800 bg-amber-50 px-3 py-1 rounded-md border border-amber-200/60">
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
              <span>
                {language === 'om'
                  ? 'Kutaa 9ffaa: Sagantaa Barnoota Itoophiyaa & Oromiyaa'
                  : 'Ethiopian Grade 9 National Curriculum Standards'}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
              {language === 'om' ? (
                <>
                  Qabxii Qorannoo fi <span className="text-amber-600">Gaaffilee Mirkaneeffannaa 5</span> Kutaa 9
                </>
              ) : (
                <>
                  Concise Study Notes & <span className="text-amber-600">5 Review Questions</span> for Grade 9
                </>
              )}
            </h1>

            <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
              {language === 'om'
                ? 'Barnoota Afaan Oromoo, Saayinsii, fi Herrega Kutaa 9ffaaf qabxiilee gabaaboo, ifa ta\'an, fi qormaata 5 MCQs deebii fi ibsa bal\'aa qaban baradhu.'
                : 'Master Grade 9 Afaan Oromoo, Biology, Chemistry, and essential subjects with bite-sized revision notes, key concepts, and 5-question review tests with answer keys and thorough explanations.'}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onStartAfaanOromoo}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm cursor-pointer active:scale-[0.98]"
              >
                <BookOpen className="w-4 h-4" />
                <span>{language === 'om' ? 'Afaan Oromoo Dubbisi' : 'Read Afaan Oromoo'}</span>
              </button>

              <button
                onClick={onStartQuiz}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-all cursor-pointer active:scale-[0.98]"
              >
                <HelpCircle className="w-4 h-4 text-slate-600" />
                <span>{language === 'om' ? 'Qormaata Jalqabi (5 MCQs)' : 'Take 5 Review Questions'}</span>
              </button>

              <button
                onClick={onOpenAiGenerator}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>{language === 'om' ? 'Mata-duree Haaraa Uumi' : 'Generate Any Topic'}</span>
              </button>
            </div>

            {/* Micro stats strip */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
              <div>
                <p className="font-bold text-slate-900 text-base tabular-nums">{totalModules}</p>
                <p className="text-slate-500 font-medium">
                  {language === 'om' ? 'Boqonnaalee Qorannoo' : 'Study Modules'}
                </p>
              </div>
              <div>
                <p className="font-bold text-slate-900 text-base tabular-nums">{totalQuestions}+</p>
                <p className="text-slate-500 font-medium">
                  {language === 'om' ? 'Gaaffilee Deebii Qaban' : 'MCQs with Keys'}
                </p>
              </div>
              <div>
                <p className="font-bold text-slate-900 text-base">Afaan Oromoo</p>
                <p className="text-slate-500 font-medium">
                  {language === 'om' ? '& Ingiliffa (Bilingual)' : '& English Support'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Image Asset */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-slate-100 aspect-16/10">
              <img
                src="/src/assets/images/ethiopian_grade9_study_1792618162255.jpg"
                alt="Ethiopian Grade 9 high school students studying with books and digital tools in a warm classroom"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent flex items-end p-4">
                <div className="text-white text-xs">
                  <span className="font-bold">Barattoota Itoophiyaa</span> · Grade 9 Mobile Study Companion
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
