import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  Moon,
  Sparkles,
  Radio,
  Clock,
  BookOpen,
  Search,
  Filter,
  Volume2,
  Calendar,
  Share2,
  Heart,
  ChevronRight,
  Flame,
} from 'lucide-react';
import { SpecialRecitation, ActiveSpecialTrack } from '../types';
import { SPECIAL_RECITATIONS, filterSpecialRecitations } from '../data/specialRecitations';

interface SpecialRecitationsViewProps {
  onPlayTrack: (track: ActiveSpecialTrack) => void;
  activeSpecialTrack: ActiveSpecialTrack | null;
  isPlaying: boolean;
  onOpenSurah: (surahNumber: number) => void;
}

type CategoryTab = 'all' | 'ramadan_maghrib' | 'khashia';

export const SpecialRecitationsView: React.FC<SpecialRecitationsViewProps> = ({
  onPlayTrack,
  activeSpecialTrack,
  isPlaying,
  onOpenSurah,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryTab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReciter, setSelectedReciter] = useState<string>('all');

  // Extract unique reciters
  const uniqueReciters = useMemo(() => {
    const set = new Set<string>();
    SPECIAL_RECITATIONS.forEach((r) => set.add(r.reciterName));
    return Array.from(set);
  }, []);

  // Filtered recitations
  const filteredList = useMemo(() => {
    return filterSpecialRecitations(SPECIAL_RECITATIONS, {
      category: selectedCategory,
      query: searchQuery,
      reciterName: selectedReciter === 'all' ? '' : selectedReciter,
    });
  }, [selectedCategory, searchQuery, selectedReciter]);

  const maghribCount = SPECIAL_RECITATIONS.filter((r) => r.category === 'ramadan_maghrib').length;
  const khashiaCount = SPECIAL_RECITATIONS.filter((r) => r.category === 'khashia').length;

  return (
    <div id="special-recitations-container" className="space-y-6">
      {/* Decorative Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-stone-900 via-emerald-950 to-stone-900 border border-emerald-700/40 p-5 sm:p-7 text-white shadow-xl">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-6 -ml-6 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/15 border border-amber-300/30 text-amber-300 text-xs font-bold mb-3">
            <Radio className="w-3.5 h-3.5" />
            <span>تسجيلات نادرة وتلاوات خاشعة</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold font-['Cairo',sans-serif] text-white leading-tight mb-2">
            نوادر قرآن المغرب في رمضان والتلاوات الخاشعة
          </h2>

          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-sans mb-4">
            استمع إلى عبق الزمن الجميل ونفحات إذاعة القرآن الكريم من القاهرة قبيل مدفع الإفطار
            بأصوات عمالقة القراء المصريين (الشيخ رفعت، عبد الباسط، المنشاوي، مصطفى إسماعيل، والفشني)،
            إلى جانب باقة مختارة من أخشع التلاوات المؤثرة التي ترق لها القلوب.
          </p>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800/80 border border-stone-700/80 text-amber-300 font-medium">
              <Moon className="w-3.5 h-3.5" />
              <span>{maghribCount} تسجيل نادر لقرآن المغرب</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800/80 border border-stone-700/80 text-emerald-300 font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{khashiaCount} تلاوة خاشعة مؤثرة</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="grid grid-cols-3 sm:flex items-center gap-1.5 p-1 rounded-2xl bg-stone-200 dark:bg-stone-800/80 border border-stone-300 dark:border-stone-700/80">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              selectedCategory === 'all'
                ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-amber-300 shadow-sm'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <span>الكل</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-100 dark:bg-stone-800">
              {SPECIAL_RECITATIONS.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('ramadan_maghrib')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              selectedCategory === 'ramadan_maghrib'
                ? 'bg-amber-500 text-stone-950 shadow-sm font-bold'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <Moon className="w-3.5 h-3.5" />
            <span className="truncate">قرآن المغرب (مصر)</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-900/20">
              {maghribCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('khashia')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              selectedCategory === 'khashia'
                ? 'bg-emerald-600 text-white shadow-sm font-bold'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="truncate">تلاوات خاشعة</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/20">
              {khashiaCount}
            </span>
          </button>
        </div>

        {/* Search within special recitations */}
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بقارئ أو سورة أو مناسبة..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 outline-none focus:ring-2 focus:ring-emerald-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Reciter Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
        <span className="text-stone-500 dark:text-stone-400 shrink-0 font-medium flex items-center gap-1">
          <Filter className="w-3.5 h-3.5" />
          تصفية بالشيخ:
        </span>

        <button
          type="button"
          onClick={() => setSelectedReciter('all')}
          className={`px-3 py-1 rounded-full whitespace-nowrap transition ${
            selectedReciter === 'all'
              ? 'bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 font-bold'
              : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
          }`}
        >
          جميع القراء
        </button>

        {uniqueReciters.map((recName) => (
          <button
            key={recName}
            type="button"
            onClick={() => setSelectedReciter(recName)}
            className={`px-3 py-1 rounded-full whitespace-nowrap transition ${
              selectedReciter === recName
                ? 'bg-amber-500 text-stone-950 font-bold shadow-xs'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
            }`}
          >
            {recName.replace('الشيخ ', '')}
          </button>
        ))}
      </div>

      {/* Recitations Grid */}
      {filteredList.length === 0 ? (
        <div className="p-12 text-center rounded-3xl border border-dashed border-stone-300 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
          <Radio className="w-10 h-10 text-stone-400 mx-auto mb-2 opacity-50" />
          <h4 className="text-base font-bold text-stone-800 dark:text-stone-200 mb-1">
            لا توجد تلاوات مطابقة لمعايير البحث
          </h4>
          <p className="text-xs text-stone-500 dark:text-stone-400">
            جرّب تغيير كلمات البحث أو اختيار تبويب مختلف
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredList.map((item) => {
            const isCurrentTrack = activeSpecialTrack?.id === item.id;
            const isCurrentPlaying = isCurrentTrack && isPlaying;
            const isMaghrib = item.category === 'ramadan_maghrib';

            return (
              <div
                key={item.id}
                className={`group rounded-3xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                  isCurrentTrack
                    ? isMaghrib
                      ? 'bg-amber-50/90 dark:bg-amber-950/30 border-amber-500/80 shadow-md ring-1 ring-amber-400'
                      : 'bg-emerald-50/90 dark:bg-emerald-950/30 border-emerald-500/80 shadow-md ring-1 ring-emerald-400'
                    : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-emerald-600/40 hover:shadow-lg'
                }`}
              >
                <div>
                  {/* Top Bar: Category, Duration, Year */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                        isMaghrib
                          ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300/40 dark:border-amber-700/50'
                          : 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-700/50'
                      }`}
                    >
                      {isMaghrib ? <Moon className="w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
                      <span>{isMaghrib ? 'قرآن المغرب في رمضان' : 'تلاوة خاشعة'}</span>
                    </span>

                    <div className="flex items-center gap-2 text-[11px] text-stone-500 dark:text-stone-400 font-sans">
                      {item.durationText && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{item.durationText}</span>
                        </span>
                      )}
                      {item.year && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{item.year}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Title & Surah Name */}
                  <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 mb-1 font-['Cairo',sans-serif] group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition leading-snug">
                    {item.title}
                  </h3>

                  {/* Reciter Name */}
                  <div className="flex items-center gap-2 mb-2.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                    <Radio className="w-3.5 h-3.5" />
                    <span>{item.reciterName}</span>
                    {item.ayahRange && (
                      <span className="text-stone-400 font-normal">• {item.ayahRange}</span>
                    )}
                  </div>

                  {/* Description / Story */}
                  <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed font-sans mb-3 line-clamp-3">
                    {item.description}
                  </p>

                  {/* Occasion / Broadcast Station */}
                  {item.stationOrOccasion && (
                    <div className="text-[11px] text-stone-500 dark:text-stone-400 bg-stone-100 dark:bg-stone-800/60 px-3 py-1.5 rounded-xl mb-3 flex items-center gap-1.5">
                      <span className="font-bold text-stone-700 dark:text-stone-300">المصدر:</span>
                      <span className="truncate">{item.stationOrOccasion}</span>
                    </div>
                  )}

                  {/* Tags */}
                  {item.tags && item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {item.tags.map((t) => (
                        <span
                          key={t}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-500 dark:text-stone-400"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom Action Controls */}
                <div className="pt-3 border-t border-stone-200/80 dark:border-stone-800 flex items-center justify-between gap-2">
                  {/* Play Button */}
                  <button
                    type="button"
                    onClick={() =>
                      onPlayTrack({
                        id: item.id,
                        title: item.title,
                        reciterName: item.reciterName,
                        category: item.category,
                        surahNumber: item.surahNumber,
                        surahName: item.surahName,
                        audioUrl: item.audioUrl,
                        stationOrOccasion: item.stationOrOccasion,
                      })
                    }
                    className={`flex-1 py-2.5 px-4 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-sm active:scale-98 ${
                      isCurrentPlaying
                        ? 'bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold'
                        : isCurrentTrack
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : isMaghrib
                        ? 'bg-amber-500/90 hover:bg-amber-500 text-stone-950'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {isCurrentPlaying ? (
                      <>
                        <Pause className="w-4 h-4 fill-current" />
                        <span>جاري الاستماع...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-current" />
                        <span>{isCurrentTrack ? 'متابعة الاستماع' : 'استمع الآن'}</span>
                      </>
                    )}
                  </button>

                  {/* Read in Mushaf Button */}
                  <button
                    type="button"
                    onClick={() => onOpenSurah(item.surahNumber)}
                    className="py-2.5 px-3 rounded-2xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-bold transition flex items-center gap-1.5 shrink-0"
                    title={`فتح سورة ${item.surahName} للقراءة`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">قراءة السورة</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
