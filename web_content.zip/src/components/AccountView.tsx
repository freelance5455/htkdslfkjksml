import React, { useState } from 'react';
import {
  Calendar,
  Camera,
  Crown,
  Download,
  KeyRound,
  LogOut,
  Save,
  Shield,
  ShieldCheck,
  UserRound,
} from 'lucide-react';
import { apiRequest, formatBytes, formatDateTr } from '../lib/api';
import type {
  BuildJob,
  MembershipInfo,
  NavSection,
  PaymentRecord,
  UserAccount,
} from '../types/studio';
import { AdminCodeExplorer } from './AdminCodeExplorer';

interface AccountViewProps {
  user: UserAccount;
  membership: MembershipInfo;
  payments: PaymentRecord[];
  builds: BuildJob[];
  onNavigate: (section: NavSection) => void;
  onUserUpdated: (user: UserAccount) => void;
  onDownloadBuild: (buildId: string) => void;
  onLogout: () => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  user,
  membership,
  payments,
  builds,
  onNavigate,
  onUserUpdated,
  onDownloadBuild,
  onLogout,
}) => {
  const [username, setUsername] = useState(user.username);
  const [bio, setBio] = useState(user.bio || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setFeedback(null);
    try {
      const res = await apiRequest<{ ok: boolean; user: UserAccount }>('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ username, bio }),
      });
      onUserUpdated({ ...user, ...res.user });
      setFeedback({ type: 'ok', text: 'Profil bilgileriniz güncellendi.' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Profil güncellenemedi.',
      });
    } finally {
      setSavingProfile(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    setFeedback(null);
    try {
      const form = new FormData();
      form.append('avatar', file);
      const res = await apiRequest<{ ok: boolean; avatarUrl: string }>('/api/auth/avatar', {
        method: 'POST',
        body: form,
      });
      onUserUpdated({ ...user, avatarUrl: res.avatarUrl });
      setFeedback({ type: 'ok', text: 'Profil fotoğrafınız güncellendi.' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Profil fotoğrafı yüklenemedi.',
      });
    } finally {
      setUploadingAvatar(false);
      e.target.value = '';
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPassword(true);
    setFeedback(null);
    try {
      await apiRequest('/api/auth/password', {
        method: 'PUT',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      setFeedback({ type: 'ok', text: 'Hesap şifreniz güvenli şekilde değiştirildi.' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Şifre değiştirilemedi.',
      });
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Hesabım & Profil
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Profil bilgilerinizi, güvenlik ayarlarınızı, APK derleme ve satın alma geçmişinizi
            yönetin.
          </p>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-[#151D2E] text-slate-700 dark:text-[#CBD5E1] hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Çıkış Yap</span>
        </button>
      </div>

      {feedback && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-700 dark:text-[#22C55E]'
              : 'bg-red-500/10 border-red-500/25 text-red-600 dark:text-[#EF4444]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Profile Edit + Avatar */}
        <form
          onSubmit={handleSaveProfile}
          className="lg:col-span-5 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-5"
        >
          <div className="flex items-center gap-4">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-[#6366F1]/15 border border-[#6366F1]/30 flex items-center justify-center shrink-0">
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.username}
                  className="w-full h-full object-cover"
                />
              ) : (
                <UserRound className="w-6 h-6 text-[#6366F1]" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                {user.username}
              </h2>
              <p className="text-xs text-slate-500 dark:text-[#94A3B8] truncate">{user.email}</p>
              <label className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-medium text-[#3B82F6] hover:underline cursor-pointer">
                <Camera className="w-3 h-3" />
                <span>{uploadingAvatar ? 'Yükleniyor...' : 'Profil Fotoğrafı Değiştir'}</span>
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg,.webp"
                  disabled={uploadingAvatar}
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-white/[0.08]">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                Kullanıcı Adı
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                Hakkında / Geliştirici Notu
              </label>
              <textarea
                rows={2}
                maxLength={300}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Kısa geliştirici biyografiniz..."
                className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
              />
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-500 dark:text-[#94A3B8]">Yetki Rolü</span>
              <span className="inline-flex items-center gap-1.5 font-medium text-slate-900 dark:text-[#F8FAFC]">
                <Shield className="w-3.5 h-3.5 text-[#3B82F6]" />
                <span>{user.role === 'admin' ? 'Yönetici' : 'Geliştirici'}</span>
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-[#94A3B8]">Kayıt Tarihi</span>
              <span className="text-slate-700 dark:text-[#CBD5E1] tabular-nums">
                {formatDateTr(user.createdAt)}
              </span>
            </div>
          </div>

          <button
            type="submit"
            disabled={savingProfile}
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white text-xs font-semibold transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{savingProfile ? 'Kaydediliyor...' : 'Profili Güncelle'}</span>
          </button>
        </form>

        {/* Subscription & Password Change */}
        <div className="lg:col-span-7 space-y-6">
          {/* Subscription Card */}
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Crown
                  className={`w-5 h-5 ${
                    membership.isPremium ? 'text-[#EAB308]' : 'text-slate-400'
                  }`}
                />
                <h2 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  Premium Bilgileri ve Kotalar
                </h2>
              </div>
              <span
                className={`text-xs font-semibold ${
                  membership.isPremium
                    ? 'text-[#CA8A04] dark:text-[#EAB308]'
                    : 'text-slate-500 dark:text-[#94A3B8]'
                }`}
              >
                {membership.planName}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] rounded-xl p-3.5">
                <p className="text-[11px] text-slate-500 dark:text-[#94A3B8]">Proje Kullanımı</p>
                <p className="mt-1 text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                  {membership.usage.projectCount} / {membership.limits.maxProjects}
                </p>
              </div>
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] rounded-xl p-3.5">
                <p className="text-[11px] text-slate-500 dark:text-[#94A3B8]">Aylık Derleme</p>
                <p className="mt-1 text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                  {membership.usage.monthlyBuildsUsed} / {membership.limits.monthlyBuilds}
                </p>
              </div>
              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] rounded-xl p-3.5">
                <p className="text-[11px] text-slate-500 dark:text-[#94A3B8]">Kalan Süre</p>
                <p className="mt-1 text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] tabular-nums inline-flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#6366F1]" />
                  <span>
                    {!membership.isPremium
                      ? 'Ücretsiz Plan'
                      : membership.isLifetime
                      ? 'Süresiz'
                      : `${membership.remainingDays ?? 0} gün`}
                  </span>
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-[#94A3B8]">
                Maks. yükleme: {membership.limits.maxUploadMb} MB ·{' '}
                {membership.limits.priorityQueue ? 'Öncelikli kuyruk aktif' : 'Standart kuyruk'}
              </span>
              {!membership.isLifetime && (
                <button
                  type="button"
                  onClick={() => onNavigate('premium')}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#EAB308] hover:bg-[#CA8A04] text-[#0B1020] transition-colors whitespace-nowrap"
                >
                  {membership.isPremium ? 'Planı Yükselt' : 'Premium’a Geç'}
                </button>
              )}
            </div>
          </div>

          {/* Security & Password Change */}
          <form
            onSubmit={handleChangePassword}
            className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#6366F1]" />
                <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  Güvenlik Ayarları & Şifre Değiştir
                </h2>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#22C55E]">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>HttpOnly + CSRF Aktif</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                  Mevcut Şifre
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                  Yeni Şifre (En az 6 karakter)
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={savingPassword}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 dark:bg-white/[0.08] hover:bg-slate-800 dark:hover:bg-white/[0.14] text-white transition-colors"
              >
                {savingPassword ? 'Güncelleniyor...' : 'Şifreyi Güncelle'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* APK History & Purchase History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              APK Geçmişim
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('build')}
              className="text-xs text-[#3B82F6] hover:underline"
            >
              Tümünü Gör
            </button>
          </div>
          {builds.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
              Henüz oluşturulmuş APK kaydınız yok.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-72 overflow-y-auto text-xs">
              {builds.slice(0, 8).map((b) => {
                const canDl = b.status === 'completed_apk' || b.status === 'completed_bundle';
                return (
                  <div key={b.id} className="px-6 py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium text-slate-900 dark:text-[#F8FAFC] truncate">
                        {b.app_name || b.project_name}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                        v{b.version_name} · {formatDateTr(b.created_at)}
                      </div>
                    </div>
                    {canDl ? (
                      <button
                        type="button"
                        onClick={() => onDownloadBuild(b.id)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#3B82F6] hover:underline shrink-0"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{formatBytes(b.artifact_size_bytes)}</span>
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-500 dark:text-[#94A3B8] shrink-0">
                        {b.status}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Satın Alma Geçmişi
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('payments')}
              className="text-xs text-[#3B82F6] hover:underline"
            >
              Ödemeler Sayfası
            </button>
          </div>
          {payments.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
              Henüz bir satın alma işleminiz bulunmuyor.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-72 overflow-y-auto text-xs">
              {payments.map((pay) => (
                <div key={pay.id} className="px-6 py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-[#F8FAFC]">
                      {pay.plan_name}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8]">
                      {pay.provider_reference} · {formatDateTr(pay.created_at)}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono font-semibold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
                      {pay.amount_try.toLocaleString('tr-TR')} {pay.currency}
                    </div>
                    <div
                      className={`text-[11px] ${
                        pay.status === 'completed'
                          ? 'text-[#22C55E]'
                          : pay.status === 'failed'
                          ? 'text-[#EF4444]'
                          : 'text-amber-500'
                      }`}
                    >
                      {pay.status === 'completed' ? 'Onaylandı' : pay.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ADMIN-ONLY BOTTOM SECTION: Kaynak Kodları ve Oluşturulan Dosyalar */}
      {user.role === 'admin' && <AdminCodeExplorer />}
    </div>
  );
};
