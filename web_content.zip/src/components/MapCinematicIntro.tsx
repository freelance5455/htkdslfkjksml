import React, { useState, useEffect, useRef } from 'react';
import { MAP_CATALOG, MapInfo } from '../game/map/MapRegistry';
import { GameEngine } from '../game/core/GameEngine';
import { CharacterModels } from '../game/models/CharacterModels';
import { WeaponModels } from '../game/models/WeaponModels';
import { ZombieModels, ZombieRig } from '../game/models/ZombieModels';
import { sound } from '../audio/SoundEngine';
import { FastForward, Radio, AlertTriangle } from 'lucide-react';
import * as THREE from 'three';

interface MapCinematicIntroProps {
  mapId: string;
  engine: GameEngine;
  onFinish: () => void;
}

interface NarrativeSegment {
  time: number;
  text: string;
  camPos: THREE.Vector3;
  camLook: THREE.Vector3;
}

export const MapCinematicIntro: React.FC<MapCinematicIntroProps> = ({ mapId, engine, onFinish }) => {
  const map: MapInfo = MAP_CATALOG.find(m => m.id === mapId) || MAP_CATALOG[0];
  const [currentText, setCurrentText] = useState('');
  const [secondsRemaining, setSecondsRemaining] = useState(15);
  const [isFadingOut, setIsFadingOut] = useState(false);

  const animRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(performance.now());
  const cinematicActorsRef = useRef<THREE.Object3D[]>([]);
  const cinematicZombiesRef = useRef<ZombieRig[]>([]);

  // Map-specific 15-second camera flight paths (Requirement 7 & 8)
  const getSegments = (): NarrativeSegment[] => {
    const sp = engine.mapBuilder.playerSpawn || new THREE.Vector3(0, 0, 8);

    switch (mapId) {
      case 'hospital':
        return [
          { time: 0, text: "04:12 HRS — ST. JUDE MEDICAL CENTER: UNIDENTIFIED PATHOGEN SURGES THROUGH EMERGENCY ADMISSIONS.", camPos: new THREE.Vector3(0, 20, 32), camLook: new THREE.Vector3(0, 4, -10) },
          { time: 4, text: "04:38 HRS — EMERGENCY TRIAGE OVERRUN: SECURITY BARRIERS BREACHED, POWER SYSTEM TRIPS.", camPos: new THREE.Vector3(-22, 6, 14), camLook: new THREE.Vector3(0, 2, -5) },
          { time: 8, text: "05:01 HRS — SURVIVORS CUT OFF: INFECTED HORDE BREAKS THROUGH GROUND ENTRANCE.", camPos: new THREE.Vector3(16, 5, -8), camLook: new THREE.Vector3(0, 2, -2) },
          { time: 11.5, text: "05:15 HRS — OPERATOR ENGAGEMENT: HOLD THE EMERGENCY BAY. PREPARE FOR CONTACT.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
      case 'military':
        return [
          { time: 0, text: "02:15 HRS — FORT OMEGA: DECOMMISSIONED ARTILLERY DEPOT DETECTS SECTOR INFILTRATION.", camPos: new THREE.Vector3(0, 24, 30), camLook: new THREE.Vector3(0, 4, -15) },
          { time: 4, text: "02:40 HRS — WATCHTOWER BLACKOUT: COMMUNICATIONS TERMINATE ACROSS ALL PERIMETER BUNKERS.", camPos: new THREE.Vector3(-22, 8, -5), camLook: new THREE.Vector3(0, 6, -15) },
          { time: 8, text: "03:10 HRS — DEFENSIVE GATES COLLAPSE: REINFORCED BLAST DOORS COMPROMISED FROM INSIDE.", camPos: new THREE.Vector3(18, 6, 8), camLook: new THREE.Vector3(0, 2, 20) },
          { time: 11.5, text: "03:22 HRS — STANDBY TO FIRE: FORTIFY CHECKPOINTS. REPEL INCOMING HOSTILES.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
      case 'forest':
        return [
          { time: 0, text: "01:10 HRS — BIO-LAB DELTA: DEEP CANOPY RESEARCH POST REPORTED PROTOCOL FAILURE.", camPos: new THREE.Vector3(0, 20, 28), camLook: new THREE.Vector3(0, 3, -12) },
          { time: 4, text: "01:35 HRS — QUARANTINE BREACH: SPECIMEN DUCTS DAMAGED, HAZARD DISPERSES INTO DENSE WOODS.", camPos: new THREE.Vector3(-25, 7, 12), camLook: new THREE.Vector3(0, 3, -12) },
          { time: 8, text: "02:00 HRS — RESEARCH PERSONNEL INFECTED: SILENT PINE TRAILS ECHO WITH UNDEAD CALLS.", camPos: new THREE.Vector3(20, 9, -15), camLook: new THREE.Vector3(-5, 2, 0) },
          { time: 11.5, text: "02:15 HRS — RECON PROTOCOL: HOLD THE RESEARCH CLEARING. SURVIVE THE NIGHT.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
      case 'industrial':
        return [
          { time: 0, text: "03:45 HRS — RED-ZONE FOUNDRY: OVERNIGHT METALLURGY COMPLEX TRIGGERS EMERGENCY HALT.", camPos: new THREE.Vector3(0, 26, 28), camLook: new THREE.Vector3(0, 6, -20) },
          { time: 4, text: "04:10 HRS — CONTAINER LABYRINTH OVERRUN: INFECTED SWARM THROUGH FREIGHT CORRIDORS.", camPos: new THREE.Vector3(-20, 8, 14), camLook: new THREE.Vector3(8, 3, 14) },
          { time: 8, text: "04:35 HRS — ESCAPES CUT OFF: HIGH GROUND CATWALKS BECOME SOLE REFUGE.", camPos: new THREE.Vector3(16, 12, -8), camLook: new THREE.Vector3(0, 4, 10) },
          { time: 11.5, text: "04:50 HRS — ENGAGEMENT AUTHORIZED: DEFEND THE FOUNDRY GATES AGAINST ESCALATING WAVES.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
      case 'night_city':
        return [
          { time: 0, text: "00:30 HRS — METRO DOWNTOWN: STREET LIGHTS FLICKER AS SHADOWS MOVE THROUGH TRANSIT TUNNELS.", camPos: new THREE.Vector3(0, 22, 28), camLook: new THREE.Vector3(0, 3, -15) },
          { time: 4, text: "01:00 HRS — URBAN OUTBREAK ACCELERATES: VEHICLES CRASH, TRANSIT ACCESS COMPROMISED.", camPos: new THREE.Vector3(-18, 6, 12), camLook: new THREE.Vector3(10, 2, -5) },
          { time: 8, text: "01:25 HRS — STREET BLOCKADES FALL: STOREFRONTS SHATTER UNDER THE DEAD'S ADVANCE.", camPos: new THREE.Vector3(14, 8, -12), camLook: new THREE.Vector3(-5, 2, 5) },
          { time: 11.5, text: "01:45 HRS — SWEEP AND PURGE: LOCK DOWN THE AVENUE. ELIMINATE ALL THREATS.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
      default:
        return [
          { time: 0, text: "03:15 HRS — SUBURBAN SECTOR 07: ANOMALOUS INCIDENT DETECTED IN RESIDENTIAL DISTRICT.", camPos: new THREE.Vector3(-18, 18, 28), camLook: new THREE.Vector3(0, 2, 0) },
          { time: 4, text: "03:40 HRS — FIRST HORDE EMERGES: NEIGHBORHOOD WINDOWS AND BARRIERS SHATTER.", camPos: new THREE.Vector3(22, 9, -15), camLook: new THREE.Vector3(-8, 2, 0) },
          { time: 8, text: "04:05 HRS — LOCAL FORCES OVERRUN: STREETS CHOKED BY ABANDONED VEHICLES.", camPos: new THREE.Vector3(-20, 7, -12), camLook: new THREE.Vector3(8, 3, 8) },
          { time: 11.5, text: "04:30 HRS — WEAPONS HOT: SECURE THE SECTOR CROSSROADS. STAND YOUR GROUND.", camPos: new THREE.Vector3(sp.x + 2.5, sp.y + 2.2, sp.z + 3.8), camLook: new THREE.Vector3(sp.x, sp.y + 1.6, sp.z) },
        ];
    }
  };

  const segments = getSegments();

  useEffect(() => {
    sound.startCinematicMusic();
    sound.speakAnnouncement("Incident surveillance feed active.");

    const sp = engine.mapBuilder.playerSpawn || new THREE.Vector3(0, 0, 8);

    // Requirement 3 & 7: Visibly spawn the player character & weapon during cinematic!
    const playerActor = CharacterModels.createCharacterMesh(engine.player.stats.characterId);
    playerActor.position.set(sp.x, sp.y, sp.z);
    playerActor.rotation.y = Math.PI; // Facing into the road

    // Attach physical weapon into player's hands
    const wepBuilt = WeaponModels.buildWeapon(engine.weapons.activeWeapon.def.id, engine.weapons.activeWeapon.def.skin);
    const wepMesh = wepBuilt.model;
    wepMesh.position.set(0.18, 1.15, -0.2);
    wepMesh.rotation.set(0, -Math.PI / 2, 0);
    wepMesh.scale.setScalar(0.9);
    playerActor.add(wepMesh);

    engine.scene.add(playerActor);
    cinematicActorsRef.current.push(playerActor);

    // Requirement 6: Visibly spawn zombies entering the area during the cinematic!
    const zombie1 = ZombieModels.buildHumanoidZombie('civilian', 'walker');
    zombie1.root.position.set(sp.x - 8, sp.y, sp.z - 16);
    zombie1.root.rotation.y = 0.3;
    engine.scene.add(zombie1.root);
    cinematicZombiesRef.current.push(zombie1);
    cinematicActorsRef.current.push(zombie1.root);

    const zombie2 = ZombieModels.buildHumanoidZombie('worker', 'runner');
    zombie2.root.position.set(sp.x + 6, sp.y, sp.z - 14);
    zombie2.root.rotation.y = -0.2;
    engine.scene.add(zombie2.root);
    cinematicZombiesRef.current.push(zombie2);
    cinematicActorsRef.current.push(zombie2.root);

    const zombie3 = ZombieModels.buildHumanoidZombie('military', 'walker');
    zombie3.root.position.set(sp.x - 12, sp.y, sp.z - 10);
    zombie3.root.rotation.y = 0.5;
    engine.scene.add(zombie3.root);
    cinematicZombiesRef.current.push(zombie3);
    cinematicActorsRef.current.push(zombie3.root);

    const totalDuration = 15.0; // 15 seconds

    const tick = (now: number) => {
      const elapsed = (now - startTimeRef.current) / 1000;
      const remain = Math.max(0, Math.ceil(totalDuration - elapsed));
      setSecondsRemaining(remain);

      // Determine active narrative segment
      let activeSeg = segments[0];
      for (let i = segments.length - 1; i >= 0; i--) {
        if (elapsed >= segments[i].time) {
          activeSeg = segments[i];
          break;
        }
      }
      setCurrentText(activeSeg.text);

      // Smooth camera motion
      let nextSeg = segments[segments.indexOf(activeSeg) + 1] || activeSeg;
      const segDuration = (nextSeg.time - activeSeg.time) || 3.5;
      const segT = Math.min(1, Math.max(0, (elapsed - activeSeg.time) / segDuration));
      const easedT = segT * segT * (3 - 2 * segT); // Smoothstep

      const currentCamPos = new THREE.Vector3().lerpVectors(activeSeg.camPos, nextSeg.camPos, easedT);
      const currentCamLook = new THREE.Vector3().lerpVectors(activeSeg.camLook, nextSeg.camLook, easedT);

      // Subtle slow cinematic camera orbit
      const orbitOffset = Math.sin(elapsed * 0.4) * 0.8;
      currentCamPos.x += orbitOffset;

      engine.camera.position.copy(currentCamPos);
      engine.camera.lookAt(currentCamLook);

      // Animate cinematic zombies breaking into the scene (Requirement 6)
      cinematicZombiesRef.current.forEach((z, idx) => {
        const animSpeed = 4.0;
        const swing = Math.sin(elapsed * animSpeed + idx * 1.5);
        z.leftArm.rotation.x = -Math.PI / 2.5 + swing * 0.4;
        z.rightArm.rotation.x = -Math.PI / 2.5 - swing * 0.4;
        z.leftLeg.rotation.x = swing * 0.6;
        z.rightLeg.rotation.x = -swing * 0.6;
        z.root.position.z += 0.015; // Slow forward shambling advance
      });

      // Animate player operator readying weapon
      const idleBob = Math.sin(elapsed * 2.0) * 0.02;
      wepMesh.position.y = 1.15 + idleBob;

      // Fade to black in last 0.7s
      if (elapsed >= totalDuration - 0.7 && !isFadingOut) {
        setIsFadingOut(true);
      }

      if (elapsed < totalDuration) {
        animRef.current = requestAnimationFrame(tick);
      } else {
        finishCinematic();
      }
    };

    animRef.current = requestAnimationFrame(tick);

    return () => {
      cleanupActors();
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [mapId]);

  const cleanupActors = () => {
    cinematicActorsRef.current.forEach(actor => {
      engine.scene.remove(actor);
    });
    cinematicActorsRef.current = [];
    cinematicZombiesRef.current = [];
  };

  const finishCinematic = () => {
    if (animRef.current) cancelAnimationFrame(animRef.current);
    setIsFadingOut(true);
    setTimeout(() => {
      cleanupActors();
      onFinish();
    }, 400);
  };

  return (
    <div className={`absolute inset-0 z-40 pointer-events-none select-none overflow-hidden transition-opacity duration-500 font-sans ${isFadingOut ? 'opacity-0' : 'opacity-100'}`}>
      {/* Widescreen Cinematic Letterbox Bars */}
      <div className="absolute top-0 left-0 right-0 h-[10vh] bg-black/90 border-b border-zinc-800/80 z-30 flex items-center justify-between px-6">
        <div className="flex items-center gap-2 text-red-500 font-mono-tech text-xs tracking-widest uppercase font-bold">
          <Radio className="w-4 h-4 animate-pulse text-red-500" />
          <span>INCIDENT SURVEILLANCE FEED // {map.codename}</span>
        </div>

        {/* Skip button for quick jumping into gameplay */}
        <button
          onClick={finishCinematic}
          className="pointer-events-auto px-4 py-1.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700/80 font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 cursor-pointer shadow-lg active:scale-95 transition-all"
        >
          <span>SKIP INTRO</span>
          <FastForward className="w-4 h-4 text-red-400" />
        </button>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-[13vh] bg-black/90 border-t border-zinc-800/80 z-30 flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-500 flex items-center justify-center text-red-400 shrink-0">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-mono-tech text-zinc-400 uppercase tracking-widest">
              MISSION BRIEFING ({secondsRemaining}S REMAINING)
            </span>
            <span className="text-sm sm:text-base font-mono-tech text-white font-semibold tracking-wide">
              {currentText}
            </span>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-1 text-[11px] font-mono-tech text-zinc-500 uppercase">
          <span>THEATER:</span>
          <span className="text-amber-400 font-bold">{map.name}</span>
        </div>
      </div>

      {/* Subtle CRT Scanline overlay */}
      <div className="absolute inset-0 opacity-15 bg-[linear-gradient(to_bottom,transparent_50%,rgba(0,0,0,0.8)_51%)] [background-size:100%_4px] pointer-events-none" />
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />
    </div>
  );
};
