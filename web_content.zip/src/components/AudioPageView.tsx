import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Play, Pause, Download, Share2, Heart, MessageSquare, Bell, DollarSign, Send, Check, Shield, Sparkles, Upload, FileAudio, Plus, X, Search, Filter, HardDrive, CheckCircle2, Tag } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { tagManagementService } from '../lib/tagManagementService';
import { UploadedMediaItem } from '../types';
import { LazyMediaCard } from './LazyMediaCard';

interface AudioPageViewProps {
  onOpenSupportModal?: () => void;
}

export const AudioPageView: React.FC<AudioPageViewProps> = ({ onOpenSupportModal }) => {
  const [mediaList, setMediaList] = useState<UploadedMediaItem[]>(
    offlineCache.getUploadedMedia().filter(m => m.type === 'audio')
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<{ [key: string]: string }>({});
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: { [commentId: string]: string } }>({});
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [showUploadDrawer, setShowUploadDrawer] = useState(false);

  // Audio Upload Form State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [audioPreviewUrl, setAudioPreviewUrl] = useState<string | null>(null);
  const [trackTitle, setTrackTitle] = useState('');
  const [artistName, setArtistName] = useState('Prophet JUHNKRIX SYNVAGORD');
  const [frequencyCategory, setFrequencyCategory] = useState('528Hz Soaking Worship');
  const [scriptureRef, setScriptureRef] = useState('Psalm 23:1-6');
  const [tagsInput, setTagsInput] = useState('prophetic, worship, 528hz, healing');
  const [audioDescription, setAudioDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    const handleSync = () => {
      setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
    };
    const unsubscribe = offlineCache.subscribe(handleSync);
    window.addEventListener('juhnkrix-media-updated', handleSync);
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      window.removeEventListener('juhnkrix-media-updated', handleSync);
    };
  }, []);

  const profile = offlineCache.getProfile();
  const userName = profile.name || 'Prophetic Believer';

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    setSelectedFile(file);

    const prevUrl = URL.createObjectURL(file);
    setAudioPreviewUrl(prevUrl);

    // Auto fill title if empty
    if (!trackTitle) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_]/g, ' ');
      setTrackTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }
    if (!audioDescription) {
      setAudioDescription(`Anointed audio track recorded and stored directly into the JUHNKRIX MUSIKA sanctuary vault.`);
    }
  };

  const handleDeviceAudioUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      alert('Please select an audio file from your device first.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(15);

    try {
      // Simulate stepped progress for smooth UX
      const progressTimer = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 85) {
            clearInterval(progressTimer);
            return 85;
          }
          return prev + 20;
        });
      }, 100);

      const titleToSave = trackTitle.trim() || selectedFile.name.replace(/\.[^/.]+$/, '');
      const descToSave = `${audioDescription.trim()} [Category: ${frequencyCategory} | Scripture: ${scriptureRef}]`;
      const parsedTags = tagsInput
        .split(',')
        .map((s) => s.trim().toLowerCase().replace(/^#/, ''))
        .filter(Boolean);

      await offlineCache.uploadDeviceMedia(selectedFile, {
        type: 'audio',
        title: titleToSave,
        artistOrProphet: artistName.trim() || 'Prophet JUHNKRIX SYNVAGORD',
        description: descToSave,
        thumbnailUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
        tags: parsedTags.length > 0 ? parsedTags : ['prophetic', 'worship', '528hz']
      });

      setUploadProgress(100);
      clearInterval(progressTimer);

      setTimeout(() => {
        setIsUploading(false);
        setUploadProgress(0);
        setSelectedFile(null);
        setAudioPreviewUrl(null);
        setTrackTitle('');
        setAudioDescription('');
        setShowUploadDrawer(false);
        setUploadSuccessToast(`✓ Audio track "${titleToSave}" uploaded and stored in JUHNKRIX MUSIKA storage!`);
        setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
        setTimeout(() => setUploadSuccessToast(null), 5000);
      }, 400);
    } catch (err) {
      console.error('Audio upload error:', err);
      setIsUploading(false);
      alert('Failed to process audio file. Please try again.');
    }
  };

  const handleLike = (id: string) => {
    offlineCache.toggleLikeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
  };

  const handleDownload = (item: UploadedMediaItem) => {
    offlineCache.incrementDownloadMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
    try {
      const a = document.createElement('a');
      a.href = item.url;
      a.download = `${item.title.replace(/\s+/g, '_')}.mp3`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch {
      window.open(item.url, '_blank');
    }
  };

  const handleShare = (item: UploadedMediaItem) => {
    offlineCache.incrementShareMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
    navigator.clipboard?.writeText(window.location.href);
    setShareNotice(`Link copied for "${item.title}"!`);
    setTimeout(() => setShareNotice(null), 3000);
  };

  const handleSubscribe = (id: string) => {
    offlineCache.toggleSubscribeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
  };

  const handleAddComment = (mediaId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[mediaId];
    if (!text || !text.trim()) return;
    offlineCache.addCommentMedia(mediaId, text.trim(), userName);
    setCommentInputs({ ...commentInputs, [mediaId]: '' });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
  };

  const handleAddReply = (mediaId: string, commentId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = replyInputs[mediaId]?.[commentId];
    if (!text || !text.trim()) return;
    offlineCache.addReplyCommentMedia(mediaId, commentId, text.trim(), userName);
    setReplyInputs({
      ...replyInputs,
      [mediaId]: { ...replyInputs[mediaId], [commentId]: '' }
    });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'audio'));
  };

  const filteredMedia = mediaList.filter(item => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.artistOrProphet.toLowerCase().includes(q)
    );
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-8 max-w-5xl mx-auto pb-20 px-4 sm:px-6"
    >
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/90 via-slate-900 to-slate-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Prophet JUHNKRIX SYNVAGORD • Inbuilt Audio Storage Vault</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold font-serif tracking-tight text-amber-100">
              AUDIO SANCTUARY
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Listen to and manage anointed soaking worship tracks, prophetic prayer sessions, and audio recordings. Upload audio directly from your device storage to store permanently in JUHNKRIX MUSIKA inbuilt storage.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowUploadDrawer(!showUploadDrawer)}
              className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-xl shadow-amber-500/30 hover:scale-105 transition-all border border-amber-300"
            >
              <Upload className="w-4 h-4" />
              <span>{showUploadDrawer ? 'Close Uploader' : '📤 Upload Audio from Device'}</span>
            </button>
            <button
              onClick={onOpenSupportModal}
              className="flex items-center space-x-2 px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-bold border border-amber-500/30 transition-all"
            >
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Support Ministry</span>
            </button>
          </div>
        </div>
      </div>

      {/* Upload Success Toast */}
      {uploadSuccessToast && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs px-5 py-4 rounded-2xl shadow-xl flex items-center justify-between"
        >
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold">{uploadSuccessToast}</span>
          </div>
          <span className="text-[11px] font-mono text-emerald-300/80">Reflected Publicly</span>
        </motion.div>
      )}

      {/* Share Notice Toast */}
      {shareNotice && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-3 rounded-2xl shadow-lg flex items-center space-x-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{shareNotice}</span>
        </div>
      )}

      {/* Dedicated Inbuilt Audio Device Uploader Panel */}
      <AnimatePresence>
        {showUploadDrawer && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                    <FileAudio className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold font-serif text-amber-100">
                      Upload Audio to Audio Page & Inbuilt Storage
                    </h2>
                    <p className="text-xs text-amber-300/80 font-mono">
                      Select audio from device storage (.mp3, .wav, .aac, .m4a, .ogg) • Stored permanently in IndexedDB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowUploadDrawer(false)}
                  className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-amber-500/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleDeviceAudioUpload} className="space-y-6">
                {/* File Drop / Select Area */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept="audio/*,.mp3,.wav,.aac,.m4a,.ogg,.flac"
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    selectedFile
                      ? 'border-emerald-500/60 bg-emerald-950/20'
                      : 'border-amber-500/40 hover:border-amber-400 bg-slate-950/80'
                  }`}
                >
                  {selectedFile ? (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                        <FileAudio className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-emerald-200">
                        Selected: {selectedFile.name}
                      </p>
                      <p className="text-[11px] font-mono text-slate-400">
                        Size: {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Type: {selectedFile.type || 'audio/mp3'}
                      </p>
                      <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                        Click to change file
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/40">
                        <Upload className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-amber-200">
                        Click to Select Audio File Directly from Device Storage
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Supports MP3, WAV, AAC, M4A, OGG, FLAC formats
                      </p>
                    </div>
                  )}
                </div>

                {/* Audio Preview Player */}
                {audioPreviewUrl && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
                    <p className="text-[11px] font-mono font-bold text-amber-300 flex items-center space-x-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Audio File Preview (Before Storage)</span>
                    </p>
                    <audio controls src={audioPreviewUrl} className="w-full accent-amber-500" />
                  </div>
                )}

                {/* Metadata Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Audio Track Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={trackTitle}
                      onChange={(e) => setTrackTitle(e.target.value)}
                      placeholder="e.g. 528Hz Prophetic Soaking Deliverance"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Prophet / Minister / Artist
                    </label>
                    <input
                      type="text"
                      value={artistName}
                      onChange={(e) => setArtistName(e.target.value)}
                      placeholder="Prophet JUHNKRIX SYNVAGORD"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Frequency & Worship Category
                    </label>
                    <select
                      value={frequencyCategory}
                      onChange={(e) => setFrequencyCategory(e.target.value)}
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    >
                      <option value="528Hz Soaking Worship">528Hz Soaking Worship (Miracle Frequency)</option>
                      <option value="432Hz Spiritual Healing">432Hz Spiritual Healing & Peace</option>
                      <option value="396Hz Deliverance Warfare">396Hz Deliverance Warfare Chants</option>
                      <option value="High Praise & Anointing">High Praise & Thanksgiving</option>
                      <option value="Prophetic Intercession">Prophetic Midnight Intercession</option>
                      <option value="Audio Sermon Broadcast">Audio Sermon Broadcast</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Key Scripture Anchor
                    </label>
                    <input
                      type="text"
                      value={scriptureRef}
                      onChange={(e) => setScriptureRef(e.target.value)}
                      placeholder="e.g. Psalm 23:1-6, Isaiah 40:31"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-amber-300 mb-1 flex items-center space-x-1.5">
                      <Tag className="w-3.5 h-3.5 text-amber-400" />
                      <span>Searchable Tags (Comma-Separated, e.g. prophetic, worship, 528hz, healing)</span>
                    </label>
                    <input
                      type="text"
                      value={tagsInput}
                      onChange={(e) => setTagsInput(e.target.value)}
                      placeholder="prophetic, worship, 528hz, soaking, deliverance"
                      className="w-full bg-slate-950 text-amber-200 border border-amber-500/40 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Spiritual Description & Prophetic Decree
                  </label>
                  <textarea
                    rows={2}
                    value={audioDescription}
                    onChange={(e) => setAudioDescription(e.target.value)}
                    placeholder="Enter anointing notes, prayer instructions, or testimony background..."
                    className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Upload Progress Bar */}
                {isUploading && (
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-[11px] font-mono text-amber-300">
                      <span>Storing into JUHNKRIX MUSIKA Inbuilt Storage...</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-amber-500/30">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 transition-all duration-200"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isUploading || !selectedFile}
                  className={`w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all shadow-xl ${
                    isUploading || !selectedFile
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:scale-[1.01] text-slate-950 border border-amber-300 shadow-amber-500/20'
                  }`}
                >
                  <Upload className="w-4 h-4" />
                  <span>
                    {isUploading ? 'Writing to Inbuilt Storage...' : 'Save & Publish Audio to Audio Sanctuary'}
                  </span>
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 border border-amber-500/20 rounded-2xl p-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audio tracks, prophets, scriptures..."
            className="w-full bg-slate-950 border border-amber-500/30 rounded-xl pl-9 pr-3 py-2 text-xs text-amber-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono text-slate-400 w-full sm:w-auto justify-end">
          <HardDrive className="w-4 h-4 text-amber-400" />
          <span>{filteredMedia.length} Audio Tracks Available</span>
        </div>
      </div>

      {/* Audio List */}
      <div className="space-y-6">
        {filteredMedia.length === 0 ? (
          <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto border border-amber-500/40">
              <Music className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">
              {searchQuery ? 'No Audio Tracks Matched Search' : 'No Audio Tracks Uploaded Yet'}
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Select audio from your device storage using the "Upload Audio from Device" button above to store it into JUHNKRIX MUSIKA inbuilt storage and display it here publicly.
            </p>
            <button
              onClick={() => setShowUploadDrawer(true)}
              className="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-lg"
            >
              + Upload First Audio Track
            </button>
          </div>
        ) : (
          filteredMedia.map((item) => (
            <LazyMediaCard key={item.id} item={item}>
              {(isLoaded) => (
                <div
                  className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden"
                >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 flex-shrink-0 shadow-lg relative overflow-hidden group">
                    {item.thumbnailUrl ? (
                      <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                    ) : (
                      <Music className="w-7 h-7" />
                    )}
                    <button
                      onClick={() => setPlayingId(playingId === item.id ? null : item.id)}
                      className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-amber-300"
                    >
                      {playingId === item.id ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 fill-amber-300" />}
                    </button>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                        🎵 Inbuilt Audio Storage
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{item.date}</span>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold font-serif text-amber-100">{item.title}</h3>
                    <p className="text-xs text-amber-300/80 font-mono">By {item.artistOrProphet}</p>
                    <p className="text-xs text-slate-300 pt-1 leading-relaxed">{item.description}</p>
                    {item.tags && item.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {item.tags.map((tag, tIdx) => (
                          <span
                            key={tIdx}
                            className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 text-[10px] font-mono border border-amber-500/30"
                          >
                            <Tag className="w-2.5 h-2.5 text-amber-400" />
                            <span>#{tag}</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Subscribe Button */}
                <button
                  onClick={() => handleSubscribe(item.id)}
                  className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    item.isSubscribed
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-950 text-slate-300 border-slate-700 hover:border-amber-500/40'
                  }`}
                >
                  <Bell className={`w-3.5 h-3.5 ${item.isSubscribed ? 'text-amber-400 fill-amber-400' : ''}`} />
                  <span>{item.isSubscribed ? 'Subscribed' : 'Subscribe'}</span>
                </button>
              </div>

              {/* Audio HTML5 Player */}
              <div className="bg-slate-950/80 p-4 rounded-2xl border border-amber-500/20 space-y-3">
                <audio
                  controls
                  src={item.url}
                  className="w-full accent-amber-500"
                  preload="metadata"
                />
              </div>

              {/* Action Bar (Like, Download, Share, Support) */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-amber-500/20 text-xs">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handleLike(item.id)}
                    className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border transition-all ${
                      item.isLiked
                        ? 'bg-red-500/20 text-red-300 border-red-500/40 shadow-lg'
                        : 'bg-slate-950 text-slate-300 border-amber-500/20 hover:border-amber-400'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${item.isLiked ? 'text-red-400 fill-red-400' : ''}`} />
                    <span>{item.likes} Likes</span>
                  </button>

                  <button
                    onClick={() => handleDownload(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>{item.downloads} Downloads</span>
                  </button>

                  <button
                    onClick={() => handleShare(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>{item.shares} Shares</span>
                  </button>
                </div>

                <button
                  onClick={onOpenSupportModal}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold transition-all"
                >
                  <DollarSign className="w-4 h-4 text-amber-400" />
                  <span>Support Audio Ministry</span>
                </button>
              </div>

              {/* Comments & Reply Section */}
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>Comments & Testimonies ({item.comments.length})</span>
                </div>

                <form onSubmit={(e) => handleAddComment(item.id, e)} className="flex gap-2">
                  <input
                    type="text"
                    value={commentInputs[item.id] || ''}
                    onChange={(e) => setCommentInputs({ ...commentInputs, [item.id]: e.target.value })}
                    placeholder="Leave a spiritual testimony or comment..."
                    className="flex-1 bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Post</span>
                  </button>
                </form>

                {/* Comment List */}
                <div className="space-y-3 pt-2">
                  {item.comments.map((cmt) => (
                    <div key={cmt.id} className="bg-slate-950/60 border border-amber-500/20 p-4 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-200">{cmt.author}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{cmt.date}</span>
                      </div>
                      <p className="text-xs text-slate-300">{cmt.text}</p>

                      {/* Replies */}
                      {cmt.replies && cmt.replies.length > 0 && (
                        <div className="pl-4 sm:pl-6 space-y-2 border-l-2 border-amber-500/30 pt-2">
                          {cmt.replies.map((rep) => (
                            <div key={rep.id} className="bg-slate-900/80 p-3 rounded-xl space-y-1">
                              <div className="flex items-center justify-between text-[11px]">
                                <span className="font-bold text-amber-300">{rep.author}</span>
                                <span className="text-[9px] text-slate-400 font-mono">{rep.date}</span>
                              </div>
                              <p className="text-xs text-slate-300">{rep.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reply Input */}
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleAddReply(item.id, cmt.id, e);
                        }}
                        className="flex gap-2 pt-1"
                      >
                        <input
                          type="text"
                          value={replyInputs[item.id]?.[cmt.id] || ''}
                          onChange={(e) =>
                            setReplyInputs({
                              ...replyInputs,
                              [item.id]: { ...(replyInputs[item.id] || {}), [cmt.id]: e.target.value }
                            })
                          }
                          placeholder="Reply to comment..."
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-amber-400"
                        />
                        <button
                          type="submit"
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-bold"
                        >
                          Reply
                        </button>
                      </form>
                    </div>
                  ))}
                </div>
              </div>
            </div>
              )}
            </LazyMediaCard>
          ))
        )}
      </div>
    </motion.div>
  );
};
