import React, { useState, useMemo } from 'react';
import {
  Search,
  ExternalLink,
  Trophy,
  Filter,
  CheckCircle2,
  XCircle,
  Truck,
  Tag,
  Building2,
  Package,
  Zap,
  Info,
  Clock,
  RotateCcw,
  AlertCircle,
  Sparkles,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PreferredLanguage } from '../types';
import { ReadAloudButton } from './ReadAloudButton';

type Language = PreferredLanguage;

interface MedicinePriceCompareViewProps {
  onBack?: () => void;
  language: Language;
}

export interface PlatformListing {
  platformId: '1mg' | 'pharmeasy' | 'apollo' | 'netmeds' | 'medplus' | 'amazon' | 'flipkart';
  platformName: string;
  logoBg: string;
  badgeColor: string;
  price: number | null; // null means live price unavailable
  mrp: number | null;
  discountPercent: number | null;
  deliveryText: string;
  deliveryDays: number;
  inStock: boolean;
  officialUrl: string;
}

export interface MedicineData {
  id: string;
  name: string;
  genericName: string;
  strength: string;
  manufacturer: string;
  packSize: string;
  category: string;
  platforms: PlatformListing[];
}

type FilterType = 'lowest-price' | 'highest-discount' | 'fastest-delivery' | 'in-stock';

// Popular search tags requested by prompt
const POPULAR_SEARCHES = [
  'Dolo 650',
  'Paracetamol',
  'Crocin',
  'Pan 40',
  'Azithromycin',
  'Augmentin 625',
  'Pantoprazole',
  'Metformin',
  'Telma 40',
  'Montair LC',
  'Cetirizine',
  'Gelusil',
];

// Catalogue metadata helper for category & specs lookup
const MEDICINE_METADATA_MAP: Record<
  string,
  {
    genericName: string;
    strength: string;
    manufacturer: string;
    packSize: string;
    category: string;
  }
> = {
  'dolo 650': {
    genericName: 'Paracetamol / Acetaminophen',
    strength: '650 mg',
    manufacturer: 'Micro Labs Ltd',
    packSize: 'Strip of 15 tablets',
    category: 'Fever & Pain Relief',
  },
  'paracetamol': {
    genericName: 'Paracetamol',
    strength: '500 mg',
    manufacturer: 'IPCA Laboratories',
    packSize: 'Strip of 10 tablets',
    category: 'Fever & Pain Relief',
  },
  'crocin': {
    genericName: 'Paracetamol + Caffeine',
    strength: '650 mg + 50 mg',
    manufacturer: 'GlaxoSmithKline Consumer Healthcare',
    packSize: 'Strip of 15 tablets',
    category: 'Fever & Pain Relief',
  },
  'pan 40': {
    genericName: 'Pantoprazole Sodium',
    strength: '40 mg',
    manufacturer: 'Alkem Laboratories Ltd',
    packSize: 'Strip of 15 tablets',
    category: 'Acidity & Gastric Relief',
  },
  'pantoprazole': {
    genericName: 'Pantoprazole Sodium Gastro-resistant',
    strength: '40 mg',
    manufacturer: 'Cipla Ltd',
    packSize: 'Strip of 10 tablets',
    category: 'Acidity & Gastric Relief',
  },
  'azithromycin': {
    genericName: 'Azithromycin Dihydrate',
    strength: '500 mg',
    manufacturer: 'Lupin Ltd',
    packSize: 'Strip of 5 tablets',
    category: 'Antibiotics',
  },
  'augmentin': {
    genericName: 'Amoxicillin & Potassium Clavulanate',
    strength: '500 mg + 125 mg',
    manufacturer: 'GSK Pharmaceuticals Ltd',
    packSize: 'Strip of 10 tablets',
    category: 'Antibiotics',
  },
  'metformin': {
    genericName: 'Metformin Hydrochloride SR',
    strength: '500 mg',
    manufacturer: 'Sun Pharmaceutical Industries',
    packSize: 'Strip of 10 tablets',
    category: 'Diabetes Care',
  },
  'telma 40': {
    genericName: 'Telmisartan',
    strength: '40 mg',
    manufacturer: 'Glenmark Pharmaceuticals Ltd',
    packSize: 'Strip of 30 tablets',
    category: 'Blood Pressure & Heart',
  },
  'montair lc': {
    genericName: 'Montelukast Sodium + Levocetirizine',
    strength: '10 mg + 5 mg',
    manufacturer: 'Cipla Ltd',
    packSize: 'Strip of 15 tablets',
    category: 'Allergy & Respiratory',
  },
  'cetirizine': {
    genericName: 'Cetirizine Hydrochloride',
    strength: '10 mg',
    manufacturer: "Dr Reddy's Laboratories",
    packSize: 'Strip of 10 tablets',
    category: 'Allergy & Cold',
  },
  'gelusil': {
    genericName: 'Aluminium Hydroxide + Magnesium Hydroxide + Dimethicone',
    strength: '200 ml Bottle',
    manufacturer: 'Pfizer Ltd',
    packSize: '200 ml Bottle',
    category: 'Acidity & Digestion',
  },
};

export const MedicinePriceCompareView: React.FC<MedicinePriceCompareViewProps> = ({
  language,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedMedicine, setSelectedMedicine] = useState<MedicineData | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>('lowest-price');
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('med_recent_searches');
      return saved ? JSON.parse(saved) : ['Dolo 650', 'Pan 40', 'Crocin'];
    } catch {
      return ['Dolo 650', 'Pan 40', 'Crocin'];
    }
  });

  // Save recent searches
  const addRecentSearch = (term: string) => {
    const clean = term.trim();
    if (!clean) return;
    setRecentSearches((prev) => {
      const filtered = prev.filter((s) => s.toLowerCase() !== clean.toLowerCase());
      const updated = [clean, ...filtered].slice(0, 6);
      try {
        localStorage.setItem('med_recent_searches', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Live dropdown suggestions based on current query typing
  const liveSuggestions = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return POPULAR_SEARCHES;
    return POPULAR_SEARCHES.filter((item) => item.toLowerCase().includes(query));
  }, [searchQuery]);

  // Execute search for user query by fetching live platform prices from backend
  const handleExecuteSearch = async (queryToSearch: string) => {
    const cleanQuery = queryToSearch.trim();
    if (!cleanQuery) return;

    setSearchQuery(cleanQuery);
    setHasSearched(true);
    setShowDropdown(false);
    setIsLoading(true);

    const lowerQuery = cleanQuery.toLowerCase();
    const metaKey = Object.keys(MEDICINE_METADATA_MAP).find(
      (k) => lowerQuery.includes(k) || k.includes(lowerQuery)
    );
    const meta = metaKey ? MEDICINE_METADATA_MAP[metaKey] : null;

    try {
      // Query server endpoint for verified live prices
      const response = await fetch(
        `/api/medicine-price?query=${encodeURIComponent(cleanQuery)}`
      );

      if (response.ok) {
        const data = await response.json();
        const returnedPlatforms: PlatformListing[] = data.platforms || [];

        const formattedMedicine: MedicineData = {
          id: cleanQuery.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          name: data.medicineName || cleanQuery,
          genericName: meta?.genericName || `${cleanQuery} Formulation`,
          strength: meta?.strength || 'Standard Dosage',
          manufacturer: meta?.manufacturer || 'Certified Pharmaceutical Manufacturer',
          packSize: meta?.packSize || 'Commercial Pack',
          category: meta?.category || 'General Healthcare & Pharmacy',
          platforms: returnedPlatforms,
        };

        setSelectedMedicine(formattedMedicine);
        addRecentSearch(cleanQuery);
      } else {
        setSelectedMedicine(null);
      }
    } catch (err) {
      console.error('Error fetching live medicine prices:', err);
      setSelectedMedicine(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setHasSearched(false);
    setSelectedMedicine(null);
    setIsLoading(false);
  };

  // Process platform listings for the searched medicine based on active filter
  const processedPlatforms = useMemo(() => {
    if (!selectedMedicine) return [];
    let list = [...selectedMedicine.platforms];

    if (activeFilter === 'in-stock') {
      list = list.filter((p) => p.inStock && p.price !== null);
    }

    list.sort((a, b) => {
      // Put platforms without available live price at the end
      if (a.price === null) return 1;
      if (b.price === null) return -1;

      if (activeFilter === 'lowest-price') {
        return a.price - b.price;
      }
      if (activeFilter === 'highest-discount') {
        return (b.discountPercent || 0) - (a.discountPercent || 0);
      }
      if (activeFilter === 'fastest-delivery') {
        return a.deliveryDays - b.deliveryDays;
      }
      if (activeFilter === 'in-stock') {
        return a.price - b.price;
      }
      return 0;
    });

    return list;
  }, [selectedMedicine, activeFilter]);

  // Calculate best deal metrics from platforms with verified live prices
  const bestDealInfo = useMemo(() => {
    if (!selectedMedicine) return null;
    const validPlatforms = selectedMedicine.platforms.filter(
      (p) => p.price !== null && p.price > 0
    );

    if (validPlatforms.length === 0) return null;

    const validPrices = validPlatforms.map((p) => p.price as number);
    const minPrice = Math.min(...validPrices);
    const maxPrice = Math.max(...validPrices);
    const savings = maxPrice - minPrice;

    const bestPlatform = validPlatforms.find((p) => p.price === minPrice);

    return {
      minPrice,
      maxPrice,
      savings: savings > 0 ? savings : 0,
      bestPlatform,
    };
  }, [selectedMedicine]);

  // UI Localized Strings
  const t = {
    title: {
      English: 'Medicine Price Compare',
      Hindi: 'दवा मूल्य तुलना',
      Marathi: 'औषध किंमत तुलना',
    },
    subtitle: {
      English:
        'Retrieve live official prices directly from Tata 1mg, PharmEasy, Apollo, Netmeds, MedPlus, Amazon & Flipkart',
      Hindi:
        'टाटा 1mg, फार्मईज़ी, अपोलो, नेटमेड्स, मेडप्लस, अमेज़न और फ्लिपकार्ट से सीधे लाइव आधिकारिक कीमतें प्राप्त करें',
      Marathi:
        'टाटा 1mg, फार्मईझी, अपोलो, नेटमेड्स, मेडप्लस, अॅमेझॉन आणि फ्लिपकार्टवरून थेट अधिकृत किमती मिळवा',
    },
    searchPlaceholder: {
      English: 'Search Medicine Name (e.g. Dolo 650, Pan 40)',
      Hindi: 'दवा का नाम खोजें (उदा. डोलो 650, पैन 40)',
      Marathi: 'औषधाचे नाव शोधा (उदा. डोलो ६५०, पॅन ४०)',
    },
    popularSearchLabel: {
      English: 'Popular Searches:',
      Hindi: 'लोकप्रिय खोजें:',
      Marathi: 'लोकप्रिय शोध:',
    },
    recentSearchLabel: {
      English: 'Recent Searches:',
      Hindi: 'हाल की खोजें:',
      Marathi: 'अलीकडील शोध:',
    },
    noResultTitle: {
      English: 'Medicine live details not available',
      Hindi: 'दवा का विवरण उपलब्ध नहीं है',
      Marathi: 'औषधाचे थेट तपशील उपलब्ध नाहीत',
    },
    noResultSubtitle: {
      English:
        'Could not fetch live price data for this search. Please verify spelling or try another medicine like Dolo 650, Paracetamol, or Pan 40.',
      Hindi:
        'इस खोज के लिए लाइव मूल्य प्राप्त नहीं हो सका। कृपया वर्तनी की जांच करें या डोलो 650, पैरासिटामोल, या पैन 40 आज़माएं।',
      Marathi:
        'या शोधासाठी थेट किमती मिळवता आल्या नाहीत. कृपया स्पेलिंग तपासा किंवा डोलो ६५०, पॅरासिटामॉल किंवा पॅन ४० वापरून पहा.',
    },
    initialSearchPromptTitle: {
      English: 'Search Any Medicine to Compare Official Prices',
      Hindi: 'आधिकारिक कीमतों की तुलना करने के लिए कोई भी दवा खोजें',
      Marathi: 'अधिकृत किमतींची तुलना करण्यासाठी कोणतेही औषध शोधा',
    },
    initialSearchPromptSubtitle: {
      English:
        'Type the medicine name above to fetch verified live prices, discounts, and direct store links.',
      Hindi:
        'सत्यापित लाइव कीमतें, छूट और सीधे स्टोर लिंक प्राप्त करने के लिए ऊपर दवा का नाम टाइप करें।',
      Marathi:
        'थेट किमती, सूट आणि थेट स्टोअर लिंक्स मिळवण्यासाठी वर औषधाचे नाव टाईप करा.',
    },
    filters: {
      lowestPrice: {
        English: 'Lowest Price',
        Hindi: 'कम कीमत (Lowest Price)',
        Marathi: 'सर्वात कमी किंमत',
      },
      highestDiscount: {
        English: 'Highest Discount',
        Hindi: 'अधिकतम छूट (Highest Discount)',
        Marathi: 'सर्वात मोठी सूट',
      },
      fastestDelivery: {
        English: 'Fastest Delivery',
        Hindi: 'तेज़ डिलीवरी (Fastest Delivery)',
        Marathi: 'जलद डिलिव्हरी',
      },
      inStock: {
        English: 'In Stock',
        Hindi: 'उपलब्ध (In Stock)',
        Marathi: 'उपलब्ध स्टॉक',
      },
    },
    bestDealHeading: {
      English: 'Best Live Deal',
      Hindi: 'उत्कृष्ट लाइव डील',
      Marathi: 'सर्वोत्तम लाईव्ह ऑफर',
    },
    saveNotice: (savings: string) => {
      const msgs = {
        English: `You save ₹${savings} compared with the highest listed live price.`,
        Hindi: `आप उच्चतम सूचीबद्ध लाइव मूल्य की तुलना में ₹${savings} की बचत कर रहे हैं।`,
        Marathi: `तुम्ही सर्वोच्च सूचीबद्ध किमतीच्या तुलनेत ₹${savings} बचत करत आहात.`,
      };
      return msgs[language];
    },
    buyButton: {
      English: 'Buy on Official Website',
      Hindi: 'आधिकारिक वेबसाइट पर खरीदें',
      Marathi: 'अधिकृत वेबसाइटवरून खरेदी करा',
    },
    unavailableNotice: {
      English: 'Live price unavailable',
      Hindi: 'Live price unavailable',
      Marathi: 'Live price unavailable',
    },
    visitSite: {
      English: 'Visit Official Site',
      Hindi: 'आधिकारिक साइट पर जाएं',
      Marathi: 'अधिकृत साइटला भेट द्या',
    },
    disclaimer: {
      English:
        'Prices are retrieved directly from official pharmacy platforms. If live price is temporarily unavailable, tap "Visit Official Site" to view current listing directly on the platform.',
      Hindi:
        'कीमतें सीधे आधिकारिक फ़ार्मेसी प्लेटफ़ॉर्म से प्राप्त की जाती हैं। यदि लाइव कीमत अस्थायी रूप से अनुपलब्ध है, तो प्लेटफ़ॉर्म पर सीधे वर्तमान सूची देखने के लिए "आधिकारिक साइट पर जाएं" पर टैप करें।',
      Marathi:
        'किमती थेट अधिकृत फार्मसी प्लॅटफॉर्मवरून मिळवल्या जातात. थेट किंमत तात्पुरती उपलब्ध नसल्यास, प्लॅटफॉर्मवर थेट यादी पाहण्यासाठी "अधिकृत साइटला भेट द्या" वर टॅप करा.',
    },
  };

  return (
    <div className="space-y-6">
      {/* Search Header Banner */}
      <div className="bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 rounded-3xl p-5 sm:p-6 text-white shadow-xl relative overflow-hidden space-y-4">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center gap-2 text-blue-200 text-xs font-bold uppercase tracking-wider">
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Verified Official Pharmacy Live Aggregator</span>
        </div>
        <div className="space-y-1">
          <h1 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
            <span>💊</span>
            <span>{t.title[language]}</span>
          </h1>
          <p className="text-xs sm:text-sm text-blue-100/90 font-medium max-w-xl leading-relaxed">
            {t.subtitle[language]}
          </p>
        </div>

        {/* FUNCTIONAL SEARCH BAR */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleExecuteSearch(searchQuery);
          }}
          className="relative pt-2"
        >
          <div className="relative flex items-center">
            <Search className="w-5 h-5 absolute left-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowDropdown(true);
              }}
              onFocus={() => setShowDropdown(true)}
              placeholder={t.searchPlaceholder[language]}
              className="w-full bg-white text-slate-900 placeholder:text-slate-400 text-sm font-semibold pl-11 pr-24 py-3.5 rounded-2xl border-2 border-transparent focus:border-amber-400 focus:outline-none shadow-lg transition-all"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="absolute right-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1 disabled:opacity-70"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Fetching...</span>
                </>
              ) : (
                <>
                  <span>Search</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>

          {/* Live Typing Suggestions Dropdown */}
          <AnimatePresence>
            {showDropdown && searchQuery.trim().length > 0 && liveSuggestions.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden text-slate-900 max-h-60 overflow-y-auto"
              >
                <div className="p-2 bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-500 uppercase tracking-wider px-3">
                  Search Suggestions
                </div>
                {liveSuggestions.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => handleExecuteSearch(item)}
                    className="w-full text-left px-4 py-2.5 hover:bg-blue-50/80 transition-colors border-b border-slate-100 last:border-0 flex items-center justify-between text-xs font-bold text-slate-800 cursor-pointer"
                  >
                    <span>💊 {item}</span>
                    <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                      Get Live Prices
                    </span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </form>

        {/* POPULAR SEARCHES CHIPS */}
        <div className="pt-1 space-y-2">
          <div className="flex items-center gap-1.5 text-xs text-blue-200 font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{t.popularSearchLabel[language]}</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {POPULAR_SEARCHES.slice(0, 8).map((med) => (
              <button
                key={med}
                type="button"
                onClick={() => handleExecuteSearch(med)}
                disabled={isLoading}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedMedicine?.name.toLowerCase().includes(med.toLowerCase())
                    ? 'bg-amber-400 text-slate-950 shadow-sm font-extrabold'
                    : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
              >
                {med}
              </button>
            ))}
          </div>
        </div>

        {/* RECENT SEARCHES CHIPS */}
        {recentSearches.length > 0 && (
          <div className="pt-1 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-blue-300 font-bold flex items-center gap-1">
              <Clock className="w-3 h-3 text-blue-200" />
              {t.recentSearchLabel[language]}
            </span>
            {recentSearches.map((term) => (
              <button
                key={term}
                type="button"
                onClick={() => handleExecuteSearch(term)}
                disabled={isLoading}
                className="px-2.5 py-0.5 bg-blue-900/60 hover:bg-blue-900/90 text-blue-100 rounded-lg font-semibold text-[11px] border border-blue-400/30 transition-all cursor-pointer"
              >
                {term}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* SEARCH RESULT DISPLAY AREA */}
      {isLoading ? (
        /* LOADING STATE WHILE FETCHING LIVE PRICES */
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-3xl p-10 border border-slate-200/90 shadow-md text-center space-y-4"
        >
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mx-auto border border-blue-100 shadow-inner">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-slate-900">
              Retrieving Latest Live Prices...
            </h3>
            <p className="text-xs text-slate-500 font-medium max-w-md mx-auto">
              Connecting to official platforms (Tata 1mg, PharmEasy, Apollo, Netmeds, MedPlus, Amazon, Flipkart) to verify live prices for &quot;{searchQuery}&quot;.
            </p>
          </div>
        </motion.div>
      ) : hasSearched ? (
        selectedMedicine ? (
          /* COMPARISON RESULT CARD FOR SEARCHED MEDICINE */
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-md space-y-5"
          >
            {/* Medicine Header Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-black uppercase tracking-wider">
                      {selectedMedicine.category}
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      {selectedMedicine.strength}
                    </span>
                  </div>
                  <ReadAloudButton
                    id={`price-compare-${selectedMedicine.id}`}
                    text={(() => {
                      const parts: string[] = [];
                      parts.push(`Medicine: ${selectedMedicine.name}`);
                      parts.push(`Generic formula: ${selectedMedicine.genericName}`);
                      parts.push(`Strength: ${selectedMedicine.strength}`);
                      parts.push(`Manufacturer: ${selectedMedicine.manufacturer}`);
                      if (bestDealInfo) {
                        parts.push(`Lowest available price: ₹${bestDealInfo.minPrice.toFixed(2)} on ${bestDealInfo.bestPlatform?.platformName || 'top store'}`);
                        if (bestDealInfo.savings > 0) {
                          parts.push(`You save up to ₹${bestDealInfo.savings.toFixed(2)} (${bestDealInfo.maxDiscount?.toFixed(0)}% discount)`);
                        }
                      }
                      return parts.join('. ');
                    })()}
                    language={language}
                    variant="pill"
                  />
                </div>
                <h2 className="text-2xl font-black text-slate-900">{selectedMedicine.name}</h2>
                <p className="text-xs text-slate-500 font-semibold">
                  {selectedMedicine.genericName}
                </p>
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 space-y-1 text-xs text-slate-600 sm:text-right">
                <div className="flex items-center gap-1.5 sm:justify-end font-bold text-slate-800">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Manufacturer: {selectedMedicine.manufacturer}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:justify-end font-medium text-slate-500">
                  <Package className="w-3.5 h-3.5 text-teal-600" />
                  <span>Pack Size: {selectedMedicine.packSize}</span>
                </div>
              </div>
            </div>

            {/* BEST DEAL HIGHLIGHT CARD */}
            {bestDealInfo && (
              <motion.div
                initial={{ scale: 0.98, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 p-0.5 rounded-3xl shadow-lg"
              >
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-4 sm:p-5 rounded-[22px] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-md">
                      <Trophy className="w-6 h-6 animate-bounce" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="bg-amber-500 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                          🏆 {t.bestDealHeading[language]}
                        </span>
                        <span className="text-xs font-extrabold text-amber-900">
                          Lowest Live Price: ₹{bestDealInfo.minPrice.toFixed(2)}
                        </span>
                      </div>
                      {bestDealInfo.savings > 0 && (
                        <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                          {t.saveNotice(bestDealInfo.savings.toFixed(2))}
                        </p>
                      )}
                      {bestDealInfo.bestPlatform && (
                        <p className="text-xs font-semibold text-slate-700">
                          Available at lowest price on{' '}
                          <span className="font-extrabold text-blue-900">
                            {bestDealInfo.bestPlatform.platformName}
                          </span>
                        </p>
                      )}
                    </div>
                  </div>

                  {bestDealInfo.bestPlatform && (
                    <a
                      href={bestDealInfo.bestPlatform.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto px-5 py-3 bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 font-black text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer border border-amber-600/30 whitespace-nowrap"
                    >
                      <span>Buy on {bestDealInfo.bestPlatform.platformName}</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </motion.div>
            )}

            {/* FILTERS TOOLBAR */}
            <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-xs font-extrabold text-slate-700">
                <Filter className="w-4 h-4 text-blue-600" />
                <span>Filter & Sort Platforms:</span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
                {(
                  [
                    { id: 'lowest-price', label: t.filters.lowestPrice[language] },
                    { id: 'highest-discount', label: t.filters.highestDiscount[language] },
                    { id: 'fastest-delivery', label: t.filters.fastestDelivery[language] },
                    { id: 'in-stock', label: t.filters.inStock[language] },
                  ] as { id: FilterType; label: string }[]
                ).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setActiveFilter(f.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeFilter === f.id
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* PLATFORMS COMPARISON LIST */}
            <div className="space-y-3.5">
              {processedPlatforms.map((platform) => {
                const isLowest =
                  bestDealInfo?.bestPlatform?.platformId === platform.platformId;

                return (
                  <div
                    key={platform.platformId}
                    className={`p-4 rounded-2xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                      isLowest
                        ? 'bg-amber-50/50 border-amber-300 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {/* Platform Name & Badge */}
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-12 h-12 rounded-2xl ${platform.logoBg} font-black text-xs flex items-center justify-center p-2 text-center shadow-xs shrink-0`}
                      >
                        {platform.platformName}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-slate-900">
                            {platform.platformName}
                          </span>
                          {isLowest && (
                            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full">
                              🏆 Lowest
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          {platform.price !== null ? (
                            platform.inStock ? (
                              <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                In Stock
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-rose-600 font-bold">
                                <XCircle className="w-3.5 h-3.5" />
                                Out of Stock
                              </span>
                            )
                          ) : (
                            <span className="inline-flex items-center gap-1 text-amber-700 font-semibold">
                              <Info className="w-3.5 h-3.5 text-amber-600" />
                              Official Listing Link Available
                            </span>
                          )}

                          <span className="text-slate-300">•</span>

                          <span className="inline-flex items-center gap-1 text-slate-600 font-medium">
                            <Truck className="w-3.5 h-3.5 text-blue-600" />
                            {platform.deliveryText}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Pricing & Redirect Action */}
                    <div className="flex items-center justify-between w-full md:w-auto gap-4 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                      {platform.price !== null ? (
                        <div className="text-right space-y-0.5">
                          <div className="flex items-baseline gap-2">
                            <span className="text-xl font-black text-slate-900">
                              ₹{platform.price.toFixed(2)}
                            </span>
                            {platform.mrp && platform.mrp > platform.price && (
                              <span className="text-xs font-bold text-slate-400 line-through">
                                ₹{platform.mrp.toFixed(2)}
                              </span>
                            )}
                          </div>
                          {platform.discountPercent && platform.discountPercent > 0 ? (
                            <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[11px] font-extrabold">
                              <Tag className="w-3 h-3 text-emerald-600" />
                              <span>{platform.discountPercent}% OFF</span>
                            </div>
                          ) : null}
                        </div>
                      ) : (
                        <div className="text-right">
                          <span className="text-xs font-extrabold text-amber-800 bg-amber-50 px-2.5 py-1.5 rounded-xl border border-amber-200 inline-block">
                            {t.unavailableNotice[language]}
                          </span>
                        </div>
                      )}

                      <a
                        href={platform.officialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-xs ${
                          platform.price !== null
                            ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20 active:scale-95'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                        }`}
                      >
                        <span>
                          {platform.price !== null
                            ? t.buyButton[language]
                            : t.visitSite[language]}
                        </span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Safe Redirect Disclaimer */}
            <div className="pt-2">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-500 leading-relaxed font-medium">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p>{t.disclaimer[language]}</p>
              </div>
            </div>
          </motion.div>
        ) : (
          /* MEDICINE NOT FOUND STATE */
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 border border-slate-200/90 shadow-md text-center space-y-4 max-w-lg mx-auto"
          >
            <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-3xl flex items-center justify-center mx-auto border border-rose-100 shadow-inner">
              <AlertCircle className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-extrabold text-slate-900">
                {t.noResultTitle[language]}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {t.noResultSubtitle[language]}
              </p>
            </div>

            <div className="pt-2 flex justify-center gap-2">
              <button
                onClick={handleClearSearch}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 mx-auto"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Try Another Search</span>
              </button>
            </div>
          </motion.div>
        )
      ) : (
        /* INITIAL CLEAN HOME PAGE STATE */
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-8 border border-slate-200/90 shadow-md text-center space-y-6"
        >
          <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mx-auto border border-blue-100 shadow-xs">
            <Search className="w-10 h-10" />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="text-xl font-extrabold text-slate-900">
              {t.initialSearchPromptTitle[language]}
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-medium">
              {t.initialSearchPromptSubtitle[language]}
            </p>
          </div>

          {/* Supported Official Platforms Grid */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
              Supported Official Pharmacies
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 max-w-lg mx-auto">
              {[
                { name: 'Tata 1mg', color: 'bg-orange-100 text-orange-800' },
                { name: 'PharmEasy', color: 'bg-emerald-100 text-emerald-800' },
                { name: 'Apollo 24|7', color: 'bg-blue-100 text-blue-800' },
                { name: 'Netmeds', color: 'bg-teal-100 text-teal-800' },
                { name: 'MedPlus Mart', color: 'bg-red-100 text-red-800' },
                { name: 'Amazon Pharmacy', color: 'bg-amber-100 text-amber-900' },
                { name: 'Flipkart Health+', color: 'bg-blue-100 text-blue-900' },
              ].map((p) => (
                <span
                  key={p.name}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold ${p.color}`}
                >
                  {p.name}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
