import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle,
  ChevronRight,
  Code,
  Compass,
  Cpu,
  Database,
  FileCode,
  Layers,
  Network,
  Radio,
  Server,
  Shield,
  TestTube,
  Zap,
} from 'lucide-react';

export const ArchitectureDocs: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('master_architecture');

  const SECTIONS = [
    { id: 'master_architecture', title: '1. Master Architecture', icon: <Layers className="w-4 h-4" /> },
    { id: 'component_responsibilities', title: '2. Component Responsibilities', icon: <Compass className="w-4 h-4" /> },
    { id: 'data_flow', title: '3. Data Flow & Core Loop', icon: <Radio className="w-4 h-4" /> },
    { id: 'dependency_relationships', title: '4. Dependency Relationships', icon: <Network className="w-4 h-4" /> },
    { id: 'directory_structure', title: '5. Directory & Module Structure', icon: <FileCode className="w-4 h-4" /> },
    { id: 'database_design', title: '6. Database Design & Entities', icon: <Database className="w-4 h-4" /> },
    { id: 'api_architecture', title: '7. API Architecture', icon: <Server className="w-4 h-4" /> },
    { id: 'security_boundaries', title: '8. Security Boundaries', icon: <Shield className="w-4 h-4" /> },
    { id: 'model_router', title: '9. Model Router Architecture', icon: <Cpu className="w-4 h-4" /> },
    { id: 'tool_skill', title: '10. Tool & Skill Architecture', icon: <Zap className="w-4 h-4" /> },
    { id: 'agent_architecture', title: '11. Agent Architecture', icon: <Compass className="w-4 h-4" /> },
    { id: 'verification_architecture', title: '12. Verification Architecture', icon: <CheckCircle className="w-4 h-4" /> },
    { id: 'deployment_architecture', title: '13. Deployment Architecture', icon: <Server className="w-4 h-4" /> },
    { id: 'testing_strategy', title: '14. Testing Strategy', icon: <TestTube className="w-4 h-4" /> },
    { id: 'future_extensions', title: '15. Future Extension Points', icon: <BookOpen className="w-4 h-4" /> },
  ];

  return (
    <div id="architecture-docs-panel" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Navigation Sidebar */}
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-4 flex flex-col h-[720px] shadow-xs">
        <div className="px-2 py-2 border-b border-slate-200 mb-3">
          <h3 className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <BookOpen className="w-3.5 h-3.5 text-sky-600" />
            Systems Architecture Spec
          </h3>
          <span className="text-[10px] font-mono text-slate-500 font-semibold">15 CORE ENGINEERING MODULES</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 scrollbar-thin">
          {SECTIONS.map((sec) => {
            const isSelected = activeSection === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id)}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-mono flex items-center justify-between transition-all ${
                  isSelected
                    ? 'bg-sky-50 border border-sky-300 text-sky-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className={isSelected ? 'text-sky-700' : 'text-slate-400'}>{sec.icon}</span>
                  <span className="truncate">{sec.title}</span>
                </div>
                {isSelected && <ChevronRight className="w-3.5 h-3.5 text-sky-700 flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Reader */}
      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-6 h-[720px] overflow-y-auto font-sans text-sm text-slate-700 leading-relaxed space-y-5 shadow-xs scrollbar-thin">
        {activeSection === 'master_architecture' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-sans">
                <Layers className="w-5 h-5 text-sky-600" />
                1. Master Architecture Overview
              </h2>
              <p className="text-xs text-slate-500 font-mono mt-1 font-medium">
                Integrated, modular, production-oriented personal autonomous AI operating system.
              </p>
            </div>

            <p>
              JARVIS is structured around a centralized reactive kernel (JARVIS Core) coordinating an autonomous agentic
              loop. Rather than executing simple conversational responses or matching fixed commands, JARVIS accepts
              unstructured digital objectives, formulates directed acyclic task graphs, routes requests to optimal model
              providers, binds specialized sub-agents, executes sandboxed tools, verifies empirical outputs, and
              dynamically replans in the event of failures.
            </p>

            <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 font-mono text-xs space-y-2.5 shadow-xs">
              <span className="text-sky-800 font-bold block uppercase tracking-wider">Subsystem Layers</span>
              <ul className="space-y-2 text-slate-700">
                <li>• <strong>Orchestration Kernel:</strong> JarvisCore (11-stage loop, state coordination, event bus)</li>
                <li>• <strong>Cognitive Router:</strong> ModelRouter (Gemini 3.8 Flash, Gemini 3.1 Pro, Local Heuristic)</li>
                <li>• <strong>Storage Layer:</strong> IDatabase abstraction (Users, Tasks, Steps, Audit, Memories)</li>
                <li>• <strong>Executive Agents:</strong> General, Planner, Research, Coding, Vision, Automation</li>
                <li>• <strong>Tool Engine:</strong> Parameter schema validation, timeout wrappers, sandbox boundaries</li>
                <li>• <strong>Security Subsystem:</strong> Four-tier permission gate (READ, SAFE_WRITE, SENSITIVE, EXTERNAL_ACTION)</li>
                <li>• <strong>Verification Engine:</strong> Empirical validation, criteria score, recovery and replanning</li>
              </ul>
            </div>
          </div>
        )}

        {activeSection === 'component_responsibilities' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-sans">
                <Compass className="w-5 h-5 text-sky-600" />
                2. Component Responsibilities
              </h2>
            </div>
            <div className="space-y-3 font-mono text-xs">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-xs">
                <strong className="text-sky-800 font-bold">JARVIS Core (`server/core/jarvisCore.ts`):</strong>
                <p className="text-slate-600 font-sans text-xs mt-1 leading-relaxed">
                  Enforces task lifecycle transitions, manages the SSE event stream, halts execution on security
                  challenges, and resumes when authorization tokens are issued.
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-xs">
                <strong className="text-purple-800 font-bold">Planner Engine (`server/planner/plannerEngine.ts`):</strong>
                <p className="text-slate-600 font-sans text-xs mt-1 leading-relaxed">
                  Breaks user goals into ordered steps, binds appropriate agents, injects verification criteria, and
                  generates recovery plans upon step failure.
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-xs">
                <strong className="text-emerald-800 font-bold">Security Layer (`server/security/securityLayer.ts`):</strong>
                <p className="text-slate-600 font-sans text-xs mt-1 leading-relaxed">
                  Intercepts all tool execution intents, verifies permission boundaries, holds sensitive calls in pending
                  authorization challenges, and writes immutable audit logs.
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-xs">
                <strong className="text-amber-800 font-bold">Verification Engine (`server/verification/verificationEngine.ts`):</strong>
                <p className="text-slate-600 font-sans text-xs mt-1 leading-relaxed">
                  Empirically validates tool outputs against step contracts, scores completion, and classifies failures
                  into RECOVERABLE, TIMEOUT, PERMISSION_DENIED, or CRITICAL.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'data_flow' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-sans">
                <Radio className="w-5 h-5 text-sky-600" />
                3. Data Flow & The 11-Stage Core Loop
              </h2>
            </div>
            <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 font-mono text-xs space-y-2.5 shadow-xs">
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">1. PERCEIVE:</strong> Raw input ingested via chat/voice/webhook. Rate limits and sanitization applied.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">2. UNDERSTAND:</strong> Intent parsing, entity extraction, boundary constraints established.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">3. REMEMBER:</strong> MemorySystem queries short-term conversation, long-term profile, and knowledge docs.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">4. PLAN:</strong> PlannerEngine constructs multi-step TaskPlan with assigned agents and criteria.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">5. SELECT MODEL:</strong> ModelRouter chooses optimal provider (Gemini 3.8 Flash, Pro, or Heuristic).
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">6. SELECT TOOLS/SKILLS:</strong> Dynamic bindings checked against registry definitions and permissions.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">7. EXECUTE:</strong> Sub-agents execute steps. Security layer challenges SENSITIVE/EXTERNAL_ACTION actions.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">8. OBSERVE:</strong> Telemetry captured: stdout, error codes, latency, and memory consumption.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">9. VERIFY:</strong> VerificationEngine validates result against criteria. Scores outcome (0.0 to 1.0).
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">10. REPLAN IF NECESSARY:</strong> Recovery policy triggers retry or generates alternative task branch.
              </p>
              <p className="text-slate-700">
                <strong className="text-sky-800 font-bold">11. RESPOND:</strong> Executive synthesis formulated and presented to operator via terminal and voice.
              </p>
            </div>
          </div>
        )}

        {activeSection === 'dependency_relationships' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Network className="w-5 h-5 text-emerald-600" />
                4. Dependency Relationships
              </h2>
            </div>
            <p>
              All subsystems strictly interact through typed dependency injection and abstract interfaces:
            </p>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 font-mono text-xs text-slate-800">
              <code>
                {`JarvisCore
 ├── IDatabase (Persistence)
 ├── MemorySystem ──> IVectorStore
 ├── ModelRouter ──> GoogleGenAI SDK / Heuristic Fallback
 ├── PlannerEngine
 ├── AgentCoordinator ──> [General, Planner, Research, Coding, Vision, Automation]
 ├── ToolRegistry ──> [web_search, code_sandbox, finance_analyzer, etc.]
 ├── SkillRegistry
 ├── SecurityLayer (RBAC & Audit)
 └── VerificationEngine`}
              </code>
            </div>
          </div>
        )}

        {activeSection === 'directory_structure' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FileCode className="w-5 h-5 text-amber-600" />
                5. Directory & Module Structure
              </h2>
            </div>
            <pre className="bg-slate-50 p-4 rounded-xl border border-slate-200 font-mono text-xs text-slate-800 overflow-x-auto">
{`/server.ts                     # Express server & Vite middleware
/server
  ├── types.ts                 # Canonical domain types & interfaces
  ├── api/                     # Modular API route controllers
  ├── db/database.ts           # IDatabase abstraction & InMemoryDatabase
  ├── models/modelRouter.ts    # ModelRouter with latency/cost/fallback tracking
  ├── memory/memorySystem.ts   # Hierarchical memory & vector abstraction
  ├── tools/toolRegistry.ts    # 10 production tools with validation & timeouts
  ├── skills/skillRegistry.ts  # Composed multi-tool dynamic skill registry
  ├── agents/agentSystem.ts    # 6 specialized agents & communication bus
  ├── planner/plannerEngine.ts  # Goal decomposition & replanning engine
  ├── verification/verificationEngine.ts # Empirical outcome verification
  ├── security/securityLayer.ts# 4-tier permission gating & audit logs
  └── core/jarvisCore.ts       # 11-stage autonomous orchestrator kernel
/src
  ├── main.tsx                 # React entry point
  ├── App.tsx                  # Master JARVIS operating system shell
  ├── types.ts                 # Client TypeScript contracts
  └── components/              # Modular HUD, Console, Inspector, Monitors`}
            </pre>
          </div>
        )}

        {activeSection === 'database_design' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-sky-600" />
                6. Database Design & Entities
              </h2>
            </div>
            <p>
              The clean persistence layer defines 14 core entities supporting complete state recovery:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-xs">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">Users:</strong> id, username, name, role
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">Conversations:</strong> id, userId, title
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">Messages:</strong> id, role, content, metadata
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">Memories:</strong> id, type, key, importance, tags
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">Tasks:</strong> id, rawPrompt, status, currentStage
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">TaskSteps:</strong> id, stepNumber, tool, criteria
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">ToolCalls:</strong> id, toolName, duration, success
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-800">
                <strong className="text-sky-800">AuditLogs:</strong> id, actor, permissionLevel, status
              </div>
            </div>
          </div>
        )}

        {activeSection === 'api_architecture' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Server className="w-5 h-5 text-blue-600" />
                7. API Architecture
              </h2>
            </div>
            <div className="space-y-2 font-mono text-xs">
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /health • Kernel liveness and uptime
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /api/status • Subsystem telemetry and resource counts
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-blue-700 font-bold">POST</span> /api/chat • Executes complete 11-stage autonomous loop
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /api/tasks & <span className="text-blue-700 font-bold">POST</span> /api/tasks • Task lifecycle endpoints
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-blue-700 font-bold">POST</span> /api/tasks/:id/approve • Grants clearance for gated actions
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /api/memory & <span className="text-blue-700 font-bold">POST</span> /api/memory • Memory bank queries & storage
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /api/tools & <span className="text-emerald-700 font-bold">GET</span> /api/skills • Dynamic registry discovery
              </div>
              <div className="bg-slate-50 p-2 rounded-lg border border-slate-200 text-slate-800">
                <span className="text-emerald-700 font-bold">GET</span> /api/events • Real-time Server-Sent Events (SSE) telemetry
              </div>
            </div>
          </div>
        )}

        {activeSection === 'security_boundaries' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Shield className="w-5 h-5 text-rose-600" />
                8. Security Boundaries & Guardrails
              </h2>
            </div>
            <p>
              Security is enforced server-side. No secret keys or credentials are ever transmitted to the client. The
              4-tier permission model blocks arbitrary command execution:
            </p>
            <ul className="list-disc list-inside space-y-1 text-xs text-slate-700">
              <li><strong>READ:</strong> Zero consequence operations (search, system status).</li>
              <li><strong>SAFE_WRITE:</strong> Internal state mutations (persisting memory). Audited.</li>
              <li><strong>SENSITIVE:</strong> Code sandboxes and AST checks. Strict sandbox constraints.</li>
              <li><strong>EXTERNAL_ACTION:</strong> Dispatching notifications or webhooks. Requires human operator approval.</li>
            </ul>
          </div>
        )}

        {activeSection === 'model_router' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-sky-600" />
                9. Model Router Architecture
              </h2>
            </div>
            <p>
              The ModelRouter decouples JARVIS from any single proprietary vendor. It dynamically routes requests based
              on task category (general, reasoning, coding, vision), tracks health status, calculates estimated dollar
              costs, and falls back gracefully to a deterministic local heuristic orchestrator when external keys are
              absent or rate limited.
            </p>
          </div>
        )}

        {activeSection === 'tool_skill' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-600" />
                10. Tool & Skill Engine Architecture
              </h2>
            </div>
            <p>
              Tools are atomic, schema-validated execution primitives. Skills compose multiple tools into higher-order
              workflows (e.g. Deep Research = web search + page extract + citation verification). Arbitrary code execution
              is prohibited; all scripts run through parameter-bounded sandboxes.
            </p>
          </div>
        )}

        {activeSection === 'agent_architecture' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Compass className="w-5 h-5 text-purple-600" />
                11. Multi-Agent Coordination Architecture
              </h2>
            </div>
            <p>
              Six autonomous agents run within the system, each possessing specific domain capabilities:
              General Agent, Planner Agent, Research Agent, Coding Agent, Vision Agent, and Automation Agent.
              Inter-agent communication travels across a typed message bus enabling verifiable handoffs.
            </p>
          </div>
        )}

        {activeSection === 'verification_architecture' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                12. Verification & Recovery Architecture
              </h2>
            </div>
            <p>
              Every executed step must produce verifiable evidence before the kernel advances. The VerificationEngine
              validates data payloads against criteria strings, classifies anomalies (NONE, RECOVERABLE, TIMEOUT,
              PERMISSION_DENIED, CRITICAL), and recommends retry or dynamic replanning.
            </p>
          </div>
        )}

        {activeSection === 'deployment_architecture' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Server className="w-5 h-5 text-sky-600" />
                13. Production Deployment Architecture
              </h2>
            </div>
            <p>
              JARVIS is container-native, deployable to Cloud Run, AWS ECS, Kubernetes, or bare-metal Linux. The
              production build bundles the Express server with esbuild into a standalone CommonJS bundle (`dist/server.cjs`)
              and compiles the React frontend to static assets in `dist/`.
            </p>
          </div>
        )}

        {activeSection === 'testing_strategy' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <TestTube className="w-5 h-5 text-emerald-600" />
                14. Testing & Verification Strategy
              </h2>
            </div>
            <p>
              Testing encompasses static analysis (`tsc --noEmit`), tool unit validations (parameter schema boundary
              checks), security challenge simulation tests, and mock agent message bus evaluations.
            </p>
          </div>
        )}

        {activeSection === 'future_extensions' && (
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-purple-600" />
                15. Future Extension Points
              </h2>
            </div>
            <ul className="list-disc list-inside space-y-1 text-xs text-slate-700">
              <li>• Integration of pgvector / Pinecone into the `IVectorStore` interface.</li>
              <li>• WebSocket-based native duplex audio streaming for low-latency voice.</li>
              <li>• Real-time OS containerized micro-VMs (Firecracker / gVisor) for sandbox isolation.</li>
              <li>• Distributed multi-node agent consensus for mission-critical tasks.</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
