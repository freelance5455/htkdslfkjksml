import React from 'react';
import { 
  Layers, Cpu, Wifi, Bluetooth, Radio, ShieldAlert, CheckCircle, 
  Terminal, Sparkles, BookOpen, AlertOctagon, HelpCircle 
} from 'lucide-react';

export const ArchitectureDocs: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Intro */}
      <div className="bg-gradient-to-r from-purple-500/10 via-cyan-500/10 to-transparent border border-purple-500/20 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <div className="p-3 bg-purple-500/20 text-purple-400 rounded-xl">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-white text-lg">
              التصميم المعماري الشامل (Clean Architecture + MVVM + Hilt)
            </h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              تم بناء تطبيق <strong className="text-cyan-400">Universal Remote Pro</strong> وفقاً لأحدث المعايير الهندسية الرسمية لنظام Android (Jetpack Compose, Coroutines & Flow, Hilt, Room, Strategy Pattern).
            </p>
          </div>
        </div>
      </div>

      {/* Layer breakdown cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Domain Layer */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2 text-cyan-400">
            <BookOpen className="w-4 h-4" />
            <h4 className="font-bold text-sm text-white">1. طبقة النطاق (Domain Layer)</h4>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            مستقلة تماماً عن إطار عمل أندرويد وتحتوي على قواعد العمل الأساسية:
          </p>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li><code className="text-cyan-300 font-mono">RemoteKey</code>: Enum موحد لجميع الأزرار (أرقام، اتجاهات، ألوان، وسائط).</li>
            <li><code className="text-cyan-300 font-mono">RemoteTransport</code>: الواجهة الموحدة لقنوات النقل (Strategy Pattern).</li>
            <li>UseCases: <code className="text-slate-400 font-mono">SendKeyUseCase</code>, <code className="text-slate-400 font-mono">PairDeviceUseCase</code>.</li>
          </ul>
        </div>

        {/* Core & Drivers Layer */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2 text-emerald-400">
            <Cpu className="w-4 h-4" />
            <h4 className="font-bold text-sm text-white">2. طبقة النقل والعتاد (Core Layer)</h4>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            تتعامل مع عتاد الهاتف والشبكات:
          </p>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li><code className="text-emerald-300 font-mono">IrEncoder</code>: توليد النبضات الدقيقة (NEC, Sunplus, Sony, RC5).</li>
            <li><code className="text-emerald-300 font-mono">ConsumerIrManagerHelper</code>: الإرسال عبر هاتف الأندرويد.</li>
            <li><code className="text-emerald-300 font-mono">IRemoteDriver</code>: مشغلات Wi-Fi (Tizen, webOS, Roku, Android TV).</li>
            <li><code className="text-emerald-300 font-mono">BluetoothHidManager</code>: بروفايل HID Device الرسمي.</li>
          </ul>
        </div>

        {/* Data & UI Layer */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2 text-purple-400">
            <Layers className="w-4 h-4" />
            <h4 className="font-bold text-sm text-white">3. طبقة البيانات والواجهات (Data & UI)</h4>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            التخزين المحلي والواجهات التفاعلية:
          </p>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li><code className="text-purple-300 font-mono">AppDatabase & Room</code>: حفظ الأجهزة والمفضلات والأكواد.</li>
            <li><code className="text-purple-300 font-mono">Jetpack Compose & Material 3</code>: واجهات متجاوبة تدعم RTL/LTR والوضع الليلي.</li>
            <li><code className="text-purple-300 font-mono">Hilt DI</code>: حقن الاعتماديات لسهولة الاختبار والصيانة.</li>
          </ul>
        </div>
      </div>

      {/* Build and Test Instructions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h4 className="font-bold text-white text-base mb-3 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-cyan-400" />
          <span>طريقة البناء والتشغيل والاختبار على جهاز حقيقي</span>
        </h4>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="font-bold text-cyan-400 block mb-1">الخطوة 1: استيراد المشروع في Android Studio</span>
            قم بتحميل ملف الـ ZIP من تبويب "مستكشف الكود"، وفك الضغط، ثم افتحه عبر Android Studio (إصدار Ladybug 2024.2 أو Koala أو الأحدث) مع تحديد JDK 17 أو 21.
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="font-bold text-cyan-400 block mb-1">الخطوة 2: فحص الاعتماديات وبناء التطبيق عبر Gradle</span>
            <div className="font-mono text-[11px] bg-slate-900 p-2 rounded text-emerald-400 mt-1">
              ./gradlew assembleDebug
            </div>
            سيتم إنشاء ملف الـ APK في المسار: <code className="text-slate-400">app/build/outputs/apk/debug/app-debug.apk</code>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="font-bold text-cyan-400 block mb-1">الخطوة 3: تنفيذ اختبارات الوحدة (Unit Tests)</span>
            <div className="font-mono text-[11px] bg-slate-900 p-2 rounded text-emerald-400 mt-1">
              ./gradlew testDebugUnitTest
            </div>
            يتحقق الاختبار من دقة تردد الـ 38kHz لبروتوكول Sunplus و NEC وتوقيت نبضات الـ Leader (9000µs / 4500µs).
          </div>
        </div>
      </div>

      {/* Hardware Limits & Real-world Notes */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h4 className="font-bold text-white text-base mb-3 flex items-center gap-2">
          <AlertOctagon className="w-5 h-5 text-amber-400" />
          <span>قائمة بالحدود التقنية والملاحظات الهندسية (Hardware Limitations)</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 font-bold text-amber-400 mb-1">
              <Radio className="w-4 h-4" />
              <span>1. مرسل الأشعة تحت الحمراء (IR Blaster)</span>
            </div>
            <p className="text-slate-400">
              خاصية الـ IR تتطلب وجود عتاد فيزيائي (IR Diode) في الهاتف (مثل هواتف Xiaomi, Redmi, Poco, Huawei, أو بعض هواتف سامسونج القديمة). إذا كان الهاتف لا يحتوي على IR، سيعرض التطبيق تنبيهاً واضحاً للمستخدم، ويتيح له استخدام تحكم الواي فاي أو البلوتوث.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 font-bold text-emerald-400 mb-1">
              <Wifi className="w-4 h-4" />
              <span>2. تشغيل الشاشات عبر الواي فاي (Power-On Limitation)</span>
            </div>
            <p className="text-slate-400">
              معظم الشاشات الذكية (LG, Samsung) تقطع اتصال الـ Wi-Fi تماماً عند إيقاف التشغيل الكامل (Deep Standby). لذلك فإن زر Power On عبر الشبكة يتطلب تفعيل خاصية Wake-on-LAN (WoL) في إعدادات الشاشة، أو استخدام IR / Bluetooth كبديل للتشغيل الأولي.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 font-bold text-blue-400 mb-1">
              <Bluetooth className="w-4 h-4" />
              <span>3. متطلبات البلوتوث HID Device</span>
            </div>
            <p className="text-slate-400">
              تحويل الهاتف إلى لوحة مفاتيح / ريموت HID يتطلب نظام Android 9.0 (API 28) على الأقل ودعم تعريف الرقاقة (Bluetooth Chipset) لوضع HID Peripheral. كما يتطلب أندرويد 12+ منح إذن <code className="text-blue-300 font-mono">BLUETOOTH_CONNECT</code> وقت التشغيل.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 font-bold text-purple-400 mb-1">
              <Cpu className="w-4 h-4" />
              <span>4. خصوصية معالجات صن بلص (Sunplus Receivers)</span>
            </div>
            <p className="text-slate-400">
              تستخدم ريسيفرات Sunplus (مثل 1506G, 1506TV, 1507) بروتوكول NEC Extended مع أكواد عميل تختلف باختلاف الشركة المصنعة (0x00FF القياسي، 0xBF40 الكلاسيكي، 0x807F لأجهزة تايجر). يوفر التطبيق وضع "فحص الأكواد" التلقائي لاكتشاف الكود المناسب لأي ريسيفر في ثوانٍ.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
