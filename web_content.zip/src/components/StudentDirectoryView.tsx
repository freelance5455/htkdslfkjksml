import React, { useState } from 'react';
import { ClassInfo, Language, Student, StudentBehavior } from '../types';
import { translations, formatWhatsappUrl } from '../utils/translations';
import {
  Search,
  Plus,
  Filter,
  Award,
  CheckCircle2,
  XCircle,
  MessageCircle,
  Calendar,
  Clock,
  Sparkles,
  Camera,
  GraduationCap,
  AlertTriangle,
  UserCheck,
  Edit2,
  Trash2,
  ExternalLink,
  Phone
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface StudentDirectoryViewProps {
  students: Student[];
  classes: ClassInfo[];
  lang: Language;
  onAddStudent: (newStudent: Omit<Student, 'id'>) => void;
  onUpdateStudent: (updatedStudent: Student) => void;
  onDeleteStudent: (studentId: string) => void;
  onToggleFeeStatus: (studentId: string) => void;
  onGraduateStudent: (studentId: string, gradDate: string, gradTime: string) => void;
}

export const StudentDirectoryView: React.FC<StudentDirectoryViewProps> = ({
  students,
  classes,
  lang,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent,
  onToggleFeeStatus,
  onGraduateStudent,
}) => {
  const t = translations[lang];

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>('all');
  const [selectedFeeFilter, setSelectedFeeFilter] = useState<'all' | 'paid' | 'unpaid'>('all');
  const [selectedBehaviorFilter, setSelectedBehaviorFilter] = useState<'all' | StudentBehavior>('all');
  const [selectedGenderFilter, setSelectedGenderFilter] = useState<'all' | 'male' | 'female'>('all');

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [graduatingStudentId, setGraduatingStudentId] = useState<string | null>(null);
  const [gradDateInput, setGradDateInput] = useState<string>('2026-11-05');
  const [gradTimeInput, setGradTimeInput] = useState<string>('11:00 AM');
  const [activePhotoUploadStudentId, setActivePhotoUploadStudentId] = useState<string | null>(null);

  // Form State for Adding / Editing
  const [formData, setFormData] = useState({
    name: '',
    fatherName: '',
    whatsappNumber: '+923',
    classId: classes[0]?.id || '',
    gender: 'male' as 'male' | 'female',
    photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80',
    position: 'None',
    behavior: 'moral_intelligent' as StudentBehavior,
    behaviorNotes: '',
    feeStatus: 'unpaid' as 'paid' | 'unpaid',
    feeAmount: 1500,
  });

  const classMap = new Map<string, ClassInfo>();
  classes.forEach((c) => classMap.set(c.id, c));

  // Search filter
  const filteredStudents = students.filter((s) => {
    const cls = classMap.get(s.classId);
    const classNameText = cls ? `${cls.nameEn} ${cls.namePs} ${cls.nameUr}` : '';
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.fatherName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      classNameText.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.position.toLowerCase().includes(searchTerm.toLowerCase());

    const matchClass = selectedClassId === 'all' || s.classId === selectedClassId;
    const matchFee = selectedFeeFilter === 'all' || s.feeStatus === selectedFeeFilter;
    const matchBehavior = selectedBehaviorFilter === 'all' || s.behavior === selectedBehaviorFilter;
    const matchGender = selectedGenderFilter === 'all' || s.gender === selectedGenderFilter;

    return matchSearch && matchClass && matchFee && matchBehavior && matchGender;
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>, studentId?: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          if (studentId) {
            const student = students.find((s) => s.id === studentId);
            if (student) {
              onUpdateStudent({ ...student, photoUrl: reader.result });
              setActivePhotoUploadStudentId(null);
            }
          } else {
            setFormData((prev) => ({ ...prev, photoUrl: reader.result as string }));
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.fatherName.trim()) return;

    const targetClass = classMap.get(formData.classId);
    const feeToCharge = targetClass ? targetClass.monthlyFeePkr : formData.feeAmount;

    onAddStudent({
      name: formData.name.trim(),
      fatherName: formData.fatherName.trim(),
      whatsappNumber: formData.whatsappNumber.trim(),
      classId: formData.classId,
      gender: formData.gender,
      photoUrl: formData.photoUrl,
      position: formData.position,
      behavior: formData.behavior,
      behaviorNotes: formData.behaviorNotes,
      feeStatus: formData.feeStatus,
      feeAmount: feeToCharge,
      feePaidDate: formData.feeStatus === 'paid' ? new Date().toISOString().split('T')[0] : undefined,
      monthlyAttendancePresentDays: 24,
      monthlyTotalWorkingDays: 26,
      attendanceHistory: [],
      isGraduated: false,
      enrolledDate: new Date().toISOString().split('T')[0],
    });

    setIsAddModalOpen(false);
    // Reset form
    setFormData({
      name: '',
      fatherName: '',
      whatsappNumber: '+923',
      classId: classes[0]?.id || '',
      gender: 'male',
      photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80',
      position: 'None',
      behavior: 'moral_intelligent',
      behaviorNotes: '',
      feeStatus: 'unpaid',
      feeAmount: 1500,
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    onUpdateStudent(editingStudent);
    setEditingStudent(null);
  };

  const handleConfirmGraduation = (studentId: string) => {
    onGraduateStudent(studentId, gradDateInput, gradTimeInput);
    setGraduatingStudentId(null);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const getBehaviorBadge = (behavior: StudentBehavior) => {
    switch (behavior) {
      case 'moral_intelligent':
        return {
          label: t.behavior_moral_intelligent,
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
          icon: Sparkles,
          iconColor: 'text-emerald-600'
        };
      case 'diligent_learner':
        return {
          label: t.behavior_diligent_learner,
          bg: 'bg-blue-50 text-blue-800 border-blue-300',
          icon: UserCheck,
          iconColor: 'text-blue-600'
        };
      case 'needs_improvement_lazy':
        return {
          label: t.behavior_needs_improvement_lazy,
          bg: 'bg-amber-50 text-amber-900 border-amber-300',
          icon: AlertTriangle,
          iconColor: 'text-amber-600'
        };
      default:
        return {
          label: t.behavior_average,
          bg: 'bg-slate-50 text-slate-700 border-slate-300',
          icon: UserCheck,
          iconColor: 'text-slate-500'
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Add */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full mb-2 border border-emerald-200">
            <GraduationCap className="w-3.5 h-3.5 text-emerald-600" />
            <span>Rahbar English Center Student Records & Search</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900">
            {t.navStudents}
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            {lang === 'ps'
              ? 'د زده کوونکي، د پلار نوم، ټولګي، ترلاسه شوي مقام، د فیس وضعیت (✅ / ❌)، عکس او بااخلاقه یا سست زده کوونکي پلټنه او کتل'
              : lang === 'ur'
              ? 'طلباء کا مکمل ریکارڈ: تصویر، والد کا نام، کلاس، پوزیشن، فیس کی صورتحال (✅ / ❌)، اور بااخلاق و ذہین یا سست رویہ کا جائزہ'
              : 'Search students by name, father name, class photo, position honors, fee payment (✅ / ❌), and conduct characterization.'}
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-2xl text-xs shadow-lg shadow-emerald-700/20 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t.addStudent}</span>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:bg-white outline-none transition"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <div className="flex items-center gap-1 text-slate-400 text-[11px] font-bold">
            <Filter className="w-3.5 h-3.5" />
            <span>{t.filterByClass}:</span>
          </div>

          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-xs px-2.5 py-1.5 rounded-xl font-medium outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{t.allClasses}</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {lang === 'ps' ? c.namePs : lang === 'ur' ? c.nameUr : c.nameEn}
              </option>
            ))}
          </select>

          {/* Fee Filter */}
          <select
            value={selectedFeeFilter}
            onChange={(e) => setSelectedFeeFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-xs px-2.5 py-1.5 rounded-xl font-medium outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{t.filterByFee}: {lang === 'ps' ? 'ټول' : lang === 'ur' ? 'سب' : 'All'}</option>
            <option value="paid">{t.paidMark}</option>
            <option value="unpaid">{t.unpaidMark}</option>
          </select>

          {/* Conduct Filter */}
          <select
            value={selectedBehaviorFilter}
            onChange={(e) => setSelectedBehaviorFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 text-slate-700 text-xs px-2.5 py-1.5 rounded-xl font-medium outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{t.filterByBehavior}: {lang === 'ps' ? 'ټول' : lang === 'ur' ? 'سب' : 'All'}</option>
            <option value="moral_intelligent">{t.behavior_moral_intelligent}</option>
            <option value="needs_improvement_lazy">{t.behavior_needs_improvement_lazy}</option>
            <option value="diligent_learner">{t.behavior_diligent_learner}</option>
          </select>

          {/* Gender Section Filter */}
          <div className="inline-flex bg-slate-100 p-0.5 rounded-xl">
            <button
              onClick={() => setSelectedGenderFilter('all')}
              className={`px-2 py-1 text-[11px] rounded-lg font-bold transition ${
                selectedGenderFilter === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              {t.allGenders}
            </button>
            <button
              onClick={() => setSelectedGenderFilter('male')}
              className={`px-2 py-1 text-[11px] rounded-lg font-bold transition ${
                selectedGenderFilter === 'male' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500'
              }`}
            >
              {t.maleSection}
            </button>
            <button
              onClick={() => setSelectedGenderFilter('female')}
              className={`px-2 py-1 text-[11px] rounded-lg font-bold transition ${
                selectedGenderFilter === 'female' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-500'
              }`}
            >
              {t.femaleSection}
            </button>
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
        <span>
          {lang === 'ps'
            ? `موندل شوي زده کوونکي: ${filteredStudents.length}`
            : lang === 'ur'
            ? `دستیاب طلباء: ${filteredStudents.length}`
            : `Showing ${filteredStudents.length} Students`}
        </span>
      </div>

      {/* Students Grid */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
          <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">{t.noStudentsFound}</h3>
          <p className="text-xs text-slate-500 mt-1">Try resetting your search query or filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredStudents.map((student) => {
            const studentClass = classMap.get(student.classId);
            const className = studentClass
              ? lang === 'ps'
                ? studentClass.namePs
                : lang === 'ur'
                ? studentClass.nameUr
                : studentClass.nameEn
              : 'Unknown Class';

            const behaviorBadge = getBehaviorBadge(student.behavior);
            const BehaviorIcon = behaviorBadge.icon;
            const hasPosition = student.position && student.position !== 'None';
            const isFirst = student.position?.includes('1st');

            return (
              <div
                key={student.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between overflow-hidden relative group"
              >
                {/* Top Class Picture & Student Header */}
                <div className="relative p-4 pb-3 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
                  {/* Subtle class background thumbnail */}
                  {studentClass?.imageUrl && (
                    <div className="absolute inset-0 opacity-15 overflow-hidden">
                      <img
                        src={studentClass.imageUrl}
                        alt="Class background"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  <div className="relative z-10 flex items-start gap-3.5">
                    {/* Student Uploadable Avatar */}
                    <div className="relative shrink-0">
                      <img
                        src={student.photoUrl}
                        alt={student.name}
                        className="w-16 h-16 rounded-2xl object-cover ring-2 ring-emerald-400/80 shadow-md bg-slate-800"
                      />
                      <button
                        onClick={() => setActivePhotoUploadStudentId(student.id)}
                        className="absolute -bottom-1 -right-1 bg-slate-900/90 hover:bg-emerald-600 text-white p-1 rounded-full shadow text-[10px] border border-white/20 transition"
                        title={t.uploadPhoto}
                      >
                        <Camera className="w-3 h-3 text-amber-300" />
                      </button>
                    </div>

                    {/* Basic Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[11px] font-bold text-emerald-300 truncate block">
                          {className}
                        </span>

                        {student.isGraduated ? (
                          <span className="bg-amber-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full shadow flex items-center gap-1">
                            <GraduationCap className="w-2.5 h-2.5" />
                            {t.graduatedStatus}
                          </span>
                        ) : (
                          <span className="bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 text-[9px] px-1.5 py-0.2 rounded font-bold">
                            {t.activeStatus}
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-extrabold text-white truncate leading-snug">
                        {student.name}
                      </h3>

                      <p className="text-xs text-slate-300 truncate">
                        <span className="text-slate-400">{t.fatherName}:</span> {student.fatherName}
                      </p>

                      {/* Position Ribbon */}
                      {hasPosition && (
                        <div className="mt-1.5 inline-flex items-center gap-1 bg-amber-400/20 border border-amber-400/40 text-amber-300 text-[11px] font-extrabold px-2 py-0.5 rounded-lg shadow-sm">
                          <Award className="w-3 h-3 text-amber-400" />
                          <span>{student.position}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-4 space-y-3 flex-1 flex flex-col justify-between text-xs">
                  {/* Moral / Academic Conduct Badge */}
                  <div>
                    <div className={`p-2 rounded-xl border text-[11px] flex items-start gap-2 ${behaviorBadge.bg}`}>
                      <BehaviorIcon className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${behaviorBadge.iconColor}`} />
                      <div>
                        <span className="font-extrabold block leading-tight">{behaviorBadge.label}</span>
                        {student.behaviorNotes && (
                          <span className="text-[10px] opacity-80 block mt-0.5 line-clamp-1">{student.behaviorNotes}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Fee Status & Quick Toggle */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/90 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 block uppercase">
                        {t.feeStatus}
                      </span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {student.feeStatus === 'paid' ? (
                          <span className="inline-flex items-center gap-1 font-extrabold text-emerald-700 text-xs">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>{t.paidMark} (PKR {student.feeAmount})</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-extrabold text-rose-700 text-xs">
                            <XCircle className="w-4 h-4 text-rose-600" />
                            <span>{t.unpaidMark} (PKR {student.feeAmount})</span>
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleFeeStatus(student.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition shadow-sm border ${
                        student.feeStatus === 'paid'
                          ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                          : 'bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700'
                      }`}
                    >
                      {student.feeStatus === 'paid' ? t.markAsUnpaid : t.markAsPaid}
                    </button>
                  </div>

                  {/* Monthly Attendance */}
                  <div className="flex items-center justify-between text-[11px] text-slate-600 bg-slate-50/70 p-2 rounded-xl border border-slate-100">
                    <span className="font-semibold">{t.monthlyAttendance}:</span>
                    <span className="font-bold text-slate-900">
                      {student.monthlyAttendancePresentDays} {t.daysOutOf} {student.monthlyTotalWorkingDays} {t.days}
                      {' '}({Math.round((student.monthlyAttendancePresentDays / student.monthlyTotalWorkingDays) * 100)}%)
                    </span>
                  </div>

                  {/* Graduation Details if graduated */}
                  {student.isGraduated && student.graduationDate && (
                    <div className="bg-amber-50/80 border border-amber-200/90 p-2 rounded-xl text-[11px] text-amber-900 space-y-0.5">
                      <div className="flex items-center gap-1.5 font-bold">
                        <GraduationCap className="w-3.5 h-3.5 text-amber-700" />
                        <span>Graduated from Rahbar Center</span>
                      </div>
                      <div className="text-[10px] text-amber-800 flex items-center justify-between">
                        <span>{t.graduationDate}: <strong>{student.graduationDate}</strong></span>
                        <span>{t.graduationTime}: <strong>{student.graduationTime || '11:00 AM'}</strong></span>
                      </div>
                    </div>
                  )}

                  {/* Actions Footer */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1.5">
                    {/* WhatsApp Father Button */}
                    <a
                      href={formatWhatsappUrl(
                        student.whatsappNumber,
                        `Assalam-o-Alaikum Respected ${student.fatherName}. This is an official message from Rahbar English Center, Trat, Pishin regarding your student ${student.name}.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition shadow-sm"
                      title="Send message to father's WhatsApp"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                      <span>WhatsApp</span>
                    </a>

                    {/* Graduation Trigger */}
                    {!student.isGraduated && (
                      <button
                        onClick={() => {
                          setGraduatingStudentId(student.id);
                        }}
                        className="inline-flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 px-2 py-1.5 rounded-xl text-[11px] font-bold transition"
                        title={t.markGraduated}
                      >
                        <Award className="w-3.5 h-3.5 text-amber-600" />
                        <span>Graduate 🎓</span>
                      </button>
                    )}

                    {/* Edit Student */}
                    <button
                      onClick={() => setEditingStudent(student)}
                      className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
                      title={t.editStudent}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete Student */}
                    <button
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to remove student "${student.name}"?`)) {
                          onDeleteStudent(student.id);
                        }
                      }}
                      className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                      title={t.deleteStudent}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 my-8 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" />
                {t.addStudent}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitAdd} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.studentName} *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ahmad Khan Kakar"
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.fatherName} *</label>
                  <input
                    type="text"
                    required
                    value={formData.fatherName}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="e.g. Haji Abdul Wali"
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.whatsappNumber} *</label>
                  <input
                    type="text"
                    required
                    value={formData.whatsappNumber}
                    onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                    placeholder="+923001234567"
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.classEnrolled}</label>
                  <select
                    value={formData.classId}
                    onChange={(e) => setFormData({ ...formData, classId: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nameEn} ({c.startTime} - {c.endTime})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Photo & Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.studentPhoto}</label>
                  <label className="cursor-pointer flex items-center justify-center gap-2 border border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-2.5 bg-slate-50 transition">
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span className="font-semibold text-slate-700">{t.uploadPhoto}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handlePhotoUpload(e)}
                      className="hidden"
                    />
                  </label>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.positionAwarded}</label>
                  <select
                    value={formData.position}
                    onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="None">None</option>
                    <option value="1st Position 🥇">1st Position 🥇</option>
                    <option value="2nd Position 🥈">2nd Position 🥈</option>
                    <option value="3rd Position 🥉">3rd Position 🥉</option>
                    <option value="Top 5">Top 5</option>
                    <option value="Top 10">Top 10</option>
                    <option value="Honor Roll">Honor Roll</option>
                  </select>
                </div>
              </div>

              {/* Behavior & Moral Character */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">{t.conductRating}</label>
                <select
                  value={formData.behavior}
                  onChange={(e) => setFormData({ ...formData, behavior: e.target.value as StudentBehavior })}
                  className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                >
                  <option value="moral_intelligent">{t.behavior_moral_intelligent}</option>
                  <option value="diligent_learner">{t.behavior_diligent_learner}</option>
                  <option value="average">{t.behavior_average}</option>
                  <option value="needs_improvement_lazy">{t.behavior_needs_improvement_lazy}</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Teacher Notes on Character & Progress</label>
                <input
                  type="text"
                  value={formData.behaviorNotes}
                  onChange={(e) => setFormData({ ...formData, behaviorNotes: e.target.value })}
                  placeholder="e.g. Speaks fluent English, respectful to teachers, memorizes rules quickly"
                  className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              {/* Fee Status */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.feeStatus}</label>
                  <select
                    value={formData.feeStatus}
                    onChange={(e) => setFormData({ ...formData, feeStatus: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="unpaid">{t.unpaidMark}</option>
                    <option value="paid">{t.paidMark}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Gender Section</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="male">Male (Boys Wing)</option>
                    <option value="female">Female (Girls Wing)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-md shadow-emerald-700/20"
                >
                  {t.addStudent}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Student Modal */}
      {editingStudent && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 my-8 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-emerald-600" />
                {t.editStudent}: {editingStudent.name}
              </h3>
              <button
                onClick={() => setEditingStudent(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.studentName}</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.name}
                    onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.fatherName}</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.fatherName}
                    onChange={(e) => setEditingStudent({ ...editingStudent, fatherName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.whatsappNumber}</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.whatsappNumber}
                    onChange={(e) => setEditingStudent({ ...editingStudent, whatsappNumber: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.classEnrolled}</label>
                  <select
                    value={editingStudent.classId}
                    onChange={(e) => setEditingStudent({ ...editingStudent, classId: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nameEn} ({c.startTime} - {c.endTime})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.positionAwarded}</label>
                  <select
                    value={editingStudent.position}
                    onChange={(e) => setEditingStudent({ ...editingStudent, position: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="None">None</option>
                    <option value="1st Position 🥇">1st Position 🥇</option>
                    <option value="2nd Position 🥈">2nd Position 🥈</option>
                    <option value="3rd Position 🥉">3rd Position 🥉</option>
                    <option value="Top 5">Top 5</option>
                    <option value="Top 10">Top 10</option>
                    <option value="Honor Roll">Honor Roll</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.conductRating}</label>
                  <select
                    value={editingStudent.behavior}
                    onChange={(e) => setEditingStudent({ ...editingStudent, behavior: e.target.value as StudentBehavior })}
                    className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="moral_intelligent">{t.behavior_moral_intelligent}</option>
                    <option value="diligent_learner">{t.behavior_diligent_learner}</option>
                    <option value="average">{t.behavior_average}</option>
                    <option value="needs_improvement_lazy">{t.behavior_needs_improvement_lazy}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Behavior & Academic Progress Notes</label>
                <input
                  type="text"
                  value={editingStudent.behaviorNotes || ''}
                  onChange={(e) => setEditingStudent({ ...editingStudent, behaviorNotes: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-md shadow-emerald-700/20"
                >
                  {t.saveChanges}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Graduation Date/Time Modal */}
      {graduatingStudentId && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                {t.markGraduated}
              </h3>
              <button
                onClick={() => setGraduatingStudentId(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Please enter the official graduation ceremony date and time for this student's diploma record:
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-600" />
                  {t.graduationDate}
                </label>
                <input
                  type="date"
                  value={gradDateInput}
                  onChange={(e) => setGradDateInput(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-amber-600" />
                  {t.graduationTime}
                </label>
                <input
                  type="text"
                  value={gradTimeInput}
                  onChange={(e) => setGradTimeInput(e.target.value)}
                  placeholder="e.g. 11:30 AM"
                  className="w-full px-3 py-2 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-800"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t">
              <button
                onClick={() => setGraduatingStudentId(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => handleConfirmGraduation(graduatingStudentId)}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black shadow-md flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Confirm Graduation 🎓</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Photo Modal for Existing Student */}
      {activePhotoUploadStudentId && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-600" />
                {t.uploadPhoto}
              </h3>
              <button
                onClick={() => setActivePhotoUploadStudentId(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <label className="cursor-pointer flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-6 bg-slate-50 transition text-center">
              <Camera className="w-8 h-8 text-slate-400 mb-2" />
              <span className="text-xs font-bold text-slate-800">{t.uploadPhoto}</span>
              <span className="text-[10px] text-slate-400 mt-1">PNG, JPG or WebP</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handlePhotoUpload(e, activePhotoUploadStudentId)}
                className="hidden"
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
};
