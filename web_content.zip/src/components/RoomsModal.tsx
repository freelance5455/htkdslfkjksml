import React, { useState } from 'react';
import { Check, Copy, DoorOpen, LogOut, Play, PlusCircle, Users, X } from 'lucide-react';
import type { FriendInfo, RoomInfo } from '../game/types';

interface RoomsModalProps {
  open: boolean;
  wsConnected: boolean;
  activeRoom: RoomInfo | null;
  roomError: string | null;
  friends: FriendInfo[];
  onClose: () => void;
  onCreateRoom: () => void;
  onJoinRoom: (roomId: string) => void;
  onLeaveRoom: () => void;
  onEnterMapWithRoom: () => void;
}

export const RoomsModal: React.FC<RoomsModalProps> = ({
  open,
  wsConnected,
  activeRoom,
  roomError,
  friends,
  onClose,
  onCreateRoom,
  onJoinRoom,
  onLeaveRoom,
  onEnterMapWithRoom,
}) => {
  const [joinCode, setJoinCode] = useState('');
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  const friendsInRooms = friends.filter((f) => f.online && f.roomId);

  const handleCopyRoomId = async () => {
    if (!activeRoom) return;
    try {
      await navigator.clipboard.writeText(activeRoom.roomId);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onJoinRoom(joinCode);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-lg font-bold text-white">Salas Multiplayer</h2>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="flex items-center gap-1.5 text-xs text-neutral-300">
              <span
                className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400' : 'bg-rose-400'}`}
              />
              {wsConnected ? 'Online' : 'Conectando...'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            aria-label="Fechar Salas"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {roomError && (
            <div className="px-3.5 py-2.5 rounded-xl bg-rose-950/75 border border-rose-500/40 text-xs font-medium text-rose-200">
              {roomError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* CRIAR SALA */}
            <div className="bg-neutral-950/70 border border-white/10 rounded-xl p-4 flex flex-col justify-between gap-3">
              <div className="space-y-2">
                <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                  <PlusCircle className="w-4 h-4 text-amber-400" />
                  Criar Sala
                </h3>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Crie uma sala para gerar o ID e enviar ao seu amigo entrarem juntos no mesmo mapa.
                </p>
              </div>

              {activeRoom ? (
                <div className="space-y-3">
                  <div className="rounded-xl bg-neutral-900 border border-amber-400/40 p-3 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-neutral-400">
                      <span>ID da Sala</span>
                      <button
                        type="button"
                        onClick={handleCopyRoomId}
                        className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copied ? 'Copiado!' : 'Copiar ID'}</span>
                      </button>
                    </div>
                    <div className="font-mono-tabular text-2xl font-bold tracking-[0.18em] text-amber-400">
                      {activeRoom.roomId}
                    </div>
                    <div className="text-[11px] text-neutral-300 pt-1 border-t border-white/10">
                      Pilotos na sala ({activeRoom.players.length}):{' '}
                      <span className="text-white font-semibold">
                        {activeRoom.players.map((p) => p.name).join(', ')}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={onEnterMapWithRoom}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-display font-bold text-sm cursor-pointer whitespace-nowrap"
                    >
                      <Play className="w-4 h-4" />
                      <span>Entrar no Mapa</span>
                    </button>
                    <button
                      type="button"
                      onClick={onLeaveRoom}
                      title="Sair da Sala"
                      className="px-3 py-2.5 rounded-xl bg-neutral-800 hover:bg-rose-900/70 text-neutral-300 hover:text-rose-200 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  disabled={!wsConnected}
                  onClick={onCreateRoom}
                  className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-display font-bold text-sm tracking-wide transition-colors cursor-pointer"
                >
                  Criar Sala
                </button>
              )}
            </div>

            {/* COLOCAR SALA */}
            <div className="bg-neutral-950/70 border border-white/10 rounded-xl p-4 flex flex-col justify-between gap-3">
              <div className="space-y-2">
                <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                  <DoorOpen className="w-4 h-4 text-sky-400" />
                  Colocar Sala
                </h3>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Recebeu o ID da sala do seu amigo? Cole abaixo e clique em Confirmar para entrar no mesmo mapa.
                </p>
              </div>

              <form onSubmit={handleJoinSubmit} className="space-y-2.5">
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={10}
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  placeholder="Digite o ID da sala"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-white/15 font-mono-tabular text-base font-bold tracking-widest text-white placeholder:font-sans placeholder:tracking-normal placeholder:font-normal placeholder:text-xs placeholder:text-neutral-500 focus:outline-none focus:border-sky-400"
                />
                <button
                  type="submit"
                  disabled={!wsConnected || !joinCode.trim()}
                  className="w-full py-3 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-neutral-950 font-display font-bold text-sm tracking-wide transition-colors cursor-pointer"
                >
                  Confirmar
                </button>
              </form>

              {friendsInRooms.length > 0 && (
                <div className="pt-2 border-t border-white/10 space-y-1.5">
                  <div className="text-[11px] font-semibold text-neutral-400">
                    Amigos em sala agora:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {friendsInRooms.map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => onJoinRoom(f.roomId!)}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-sky-500 hover:text-neutral-950 text-[11px] font-semibold text-sky-300 transition-colors cursor-pointer"
                      >
                        {f.name} ({f.roomId})
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
