/**
 * GODEX Phase 4 - AI Agent Studio Main Workspace
 * Professional AI Engineering Studio featuring:
 * - Agent Header (Status: IDLE, THINKING, PLANNING, EXECUTING, WAITING_FOR_APPROVAL, VERIFYING, COMPLETED, FAILED)
 * - Navigation Sub-tabs: Chat & Stream, Task Tree, Agent Matrix, Tools, Artifacts, Context Pack
 * - Structured Agent Chat with expandable technical details
 * - Live Agent Activity stream with EventBus telemetry
 * - Elevated Bottom Agent Composer with Autonomy Control & Stop/Cancel
 */

import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  ListChecks, 
  Users, 
  Wrench, 
  Compass, 
  Layers, 
  Cpu, 
  ShieldCheck,
  Radio
} from 'lucide-react';
import { 
  ChatMessage, 
  ChatAttachment,
  TaskState, 
  ExecutionMode, 
  ActivityLogItem, 
  VerificationReport,
  AICenterTab 
} from '../types';
import { GodexControlPlane } from '../godex/godexControlPlane';
import { OperationState } from '../godex/operationState';
import { GodexLogo } from './GodexLogo';
import { GodexChatView } from './GodexChatView';
import { GodexTaskTreeView } from './GodexTaskTreeView';
import { GodexAgentMatrixView } from './GodexAgentMatrixView';
import { GodexToolActivityView } from './GodexToolActivityView';
import { GodexArtifactsView } from './GodexArtifactsView';
import { GodexAgentComposer } from './GodexAgentComposer';
import { GodexEngineeringOracleView } from './GodexEngineeringOracleView';
import { AutonomousLoopStudioView } from './AutonomousLoopStudioView';
import { Activity, Crosshair } from 'lucide-react';

interface GodexAgentStudioShellProps {
  messages: ChatMessage[];
  taskState: TaskState;
  executionMode: ExecutionMode;
  activityLogs: ActivityLogItem[];
  verificationReport: VerificationReport | null;
  files: Record<string, string>;
  activeAiTab?: AICenterTab;
  isRunning?: boolean;
  onSelectAiTab?: (tab: AICenterTab) => void;
  onSendMessage: (prompt: string, attachments?: ChatAttachment[]) => void;
  onClearChat: () => void;
  onToggleExecutionMode: () => void;
  onSelectFile?: (path: string) => void;
  onOpenPreview?: () => void;
  onRunVerification?: () => void;
  onOpenModelSettings?: () => void;
  onOpenCommandPalette?: () => void;
  onApplyFileMutation?: (path: string, content: string) => Promise<boolean>;
  onCancelOperation?: () => void;
}

export const GodexAgentStudioShell: React.FC<GodexAgentStudioShellProps> = ({
  messages,
  taskState,
  executionMode,
  activityLogs,
  verificationReport,
  files,
  activeAiTab = 'chat',
  isRunning,
  onSelectAiTab,
  onSendMessage,
  onClearChat,
  onToggleExecutionMode,
  onSelectFile,
  onOpenPreview,
  onRunVerification,
  onOpenModelSettings,
  onOpenCommandPalette,
  onApplyFileMutation,
  onCancelOperation
}) => {
  const [internalTab, setInternalTab] = useState<AICenterTab>(activeAiTab);
  const [controlState, setControlState] = useState<OperationState>(() => {
    return GodexControlPlane.getInstance().getState();
  });

  useEffect(() => {
    setInternalTab(activeAiTab);
  }, [activeAiTab]);

  useEffect(() => {
    const unsub = GodexControlPlane.getInstance().subscribe(state => {
      setControlState({ ...state });
    });
    return () => unsub();
  }, []);

  const handleTabChange = (tab: AICenterTab) => {
    setInternalTab(tab);
    onSelectAiTab?.(tab);
  };

  const isWorking = taskState !== 'IDLE' && taskState !== 'COMPLETED' && taskState !== 'FAILED';

  // Compute canonical status label & color
  const getAgentStatusInfo = () => {
    const s = controlState.status || taskState;
    switch (s) {
      case 'IDLE':
        return { label: 'IDLE', color: 'bg-emerald-950/60 text-emerald-300 border-emerald-800/70', dot: 'bg-emerald-400' };
      case 'RECEIVING':
      case 'ANALYZING':
        return { label: 'THINKING', color: 'bg-cyan-950/70 text-cyan-300 border-cyan-700/80 animate-pulse', dot: 'bg-cyan-400' };
      case 'PLANNING':
        return { label: 'PLANNING', color: 'bg-amber-950/70 text-amber-300 border-amber-700/80 animate-pulse', dot: 'bg-amber-400' };
      case 'GENERATING':
      case 'EDITING':
      case 'CODING':
        return { label: 'EXECUTING', color: 'bg-indigo-950/70 text-indigo-300 border-indigo-700/80 animate-pulse', dot: 'bg-indigo-400' };
      case 'WAITING_APPROVAL':
        return { label: 'WAITING_FOR_APPROVAL', color: 'bg-amber-950/80 text-amber-300 border-amber-500 animate-pulse', dot: 'bg-amber-400' };
      case 'TESTING':
      case 'VALIDATING':
      case 'VERIFYING':
        return { label: 'VERIFYING', color: 'bg-cyan-950/70 text-cyan-300 border-cyan-700/80 animate-pulse', dot: 'bg-cyan-400' };
      case 'COMPLETED':
        return { label: 'COMPLETED', color: 'bg-emerald-950/80 text-emerald-300 border-emerald-800/70', dot: 'bg-emerald-400' };
      case 'FAILED':
        return { label: 'FAILED', color: 'bg-rose-950/80 text-rose-300 border-rose-800/70', dot: 'bg-rose-400' };
      default:
        return { label: 'READY', color: 'bg-[#0E131E] text-neutral-400 border-[#1C2538]', dot: 'bg-neutral-500' };
    }
  };

  const statusInfo = getAgentStatusInfo();

  return (
    <div 
      id="godex-agent-studio-shell"
      className="flex-1 h-full flex flex-col bg-[#07090D] overflow-hidden select-none font-sans"
    >
      {/* AGENT HEADER */}
      <div className="h-12 border-b border-[#151B27] bg-[#0A0D15] px-4 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-3">
          <GodexLogo size={28} showText={false} pulse={isWorking} />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs font-bold text-white tracking-wide font-mono">GODEX Agent Studio</h2>
              <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono font-medium border ${statusInfo.color}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${statusInfo.dot} ${isWorking ? 'animate-pulse' : ''}`} aria-hidden="true" />
                <span>{statusInfo.label}</span>
              </div>
            </div>
            <div className="text-[10px] text-neutral-400 font-mono truncate max-w-xs sm:max-w-md">
              {controlState.operationId ? `Op: ${controlState.operationId}` : 'Ready for autonomous software engineering tasks'}
            </div>
          </div>
        </div>

        {/* Right Status / Autonomy Pill */}
        <div className="flex items-center gap-2 font-mono text-[10px]">
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0C1018] border border-[#182132] text-neutral-300">
            <span className="text-neutral-500">AUTONOMY:</span>
            <strong className="text-cyan-300 uppercase">{executionMode}</strong>
          </div>
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0C1018] border border-[#182132] text-neutral-300">
            <Cpu className="w-3 h-3 text-indigo-400" aria-hidden="true" />
            <strong className="text-white">gemini-3.7-flash</strong>
          </div>
        </div>
      </div>

      {/* STUDIO SUB-TABS NAVIGATION */}
      <div className="h-9 border-b border-[#151B27] bg-[#080B10] px-3 flex items-center gap-1 shrink-0 font-mono text-[11px] overflow-x-auto no-scrollbar">
        {[
          { id: 'chat', label: 'Chat & Stream', icon: Sparkles },
          { id: 'plan', label: 'Task Tree', icon: ListChecks, count: controlState.tasks.length },
          { id: 'agents', label: 'Agent Matrix', icon: Users, count: controlState.agents.length || 9 },
          { id: 'visual-loop', label: 'Visual Loop', icon: Crosshair },
          { id: 'oracle', label: 'Engineering Oracle', icon: Activity },
          { id: 'simulation', label: 'Tool Registry', icon: Wrench },
          { id: 'orchestration', label: 'Artifacts', icon: Layers },
          { id: 'context', label: 'Context Pack', icon: Compass }
        ].map((tab) => {
          const Icon = tab.icon;
          const active = internalTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id as any)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all whitespace-nowrap focus:outline-none focus:ring-1 focus:ring-indigo-500/40 ${
                active
                  ? 'bg-[#121927] text-cyan-300 font-semibold border border-indigo-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E131E] border border-transparent'
              }`}
              aria-label={`Switch to tab: ${tab.label}`}
            >
              <Icon className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-[#0C1018] text-cyan-400 border border-[#1A2336]">
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* MAIN STUDIO VIEWPORT */}
      <div className="flex-1 overflow-hidden relative flex flex-col">
        {/* VIEW 1: AGENT CHAT & STREAM */}
        {internalTab === 'chat' && (
          <GodexChatView
            messages={messages}
            taskState={taskState}
            executionMode={executionMode}
            activityLogs={activityLogs}
            verificationReport={verificationReport}
            isRunning={isRunning}
            onSendMessage={onSendMessage}
            onClearChat={onClearChat}
            onToggleExecutionMode={onToggleExecutionMode}
            onSelectFile={onSelectFile}
            onCancelOperation={onCancelOperation}
          />
        )}

        {/* VIEW 2: TASK TREE */}
        {internalTab === 'plan' && (
          <GodexTaskTreeView
            tasks={controlState.tasks}
            operationId={controlState.operationId}
            operationStatus={controlState.status}
            onSelectFile={onSelectFile}
          />
        )}

        {/* VIEW 3: AGENT MATRIX */}
        {internalTab === 'agents' && (
          <GodexAgentMatrixView
            agents={controlState.agents}
            currentAgentId={controlState.currentAgentId}
          />
        )}

        {/* VIEW 4: TOOL REGISTRY & ACTIVITY */}
        {internalTab === 'simulation' && (
          <GodexToolActivityView />
        )}

        {/* VIEW 5: ARTIFACTS */}
        {internalTab === 'orchestration' && (
          <GodexArtifactsView
            onSelectFile={onSelectFile}
            onOpenPreview={onOpenPreview}
          />
        )}

        {/* VIEW 6: CONTEXT PACK */}
        {internalTab === 'context' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#07090D] select-text">
            <div className="flex items-center justify-between pb-2 border-b border-[#151B27]">
              <h3 className="font-bold text-white text-sm flex items-center gap-2 font-mono">
                <Compass className="w-4 h-4 text-emerald-400" aria-hidden="true" />
                <span>Authoritative Grounded ContextPack</span>
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-800/60 font-bold">
                AST GROUNDED
              </span>
            </div>

            {controlState.context ? (
              <div className="space-y-4 font-mono text-xs">
                <div className="p-3.5 rounded-xl bg-[#0B0E17] border border-[#182234] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Token Budget:</span>
                    <strong className="text-cyan-300">{controlState.context.tokenUsage} / {controlState.context.tokenBudget} tokens</strong>
                  </div>
                  <div className="w-full h-1.5 bg-[#121826] rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"
                      style={{ width: `${Math.min(100, Math.round((controlState.context.tokenUsage / controlState.context.tokenBudget) * 100))}%` }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="font-bold text-neutral-200 uppercase tracking-wider text-[11px]">
                    Relevant Target Files ({controlState.context.files.length})
                  </div>
                  <div className="space-y-1.5">
                    {controlState.context.files.map((rf, rfi) => (
                      <div key={rfi} className="p-2 rounded-lg bg-[#0A0D14] border border-[#151B27] flex items-center justify-between">
                        <span className="text-cyan-300">{rf.path}</span>
                        <span className="text-[10px] text-neutral-500">{rf.tokens} tokens</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-neutral-500 rounded-xl bg-[#0A0D15] border border-dashed border-[#182132]">
                No active ContextPack loaded. Send a prompt to ground the AI model with AST symbols.
              </div>
            )}
          </div>
        )}

        {/* VIEW 7: ENGINEERING ORACLE & EVOLUTION */}
        {internalTab === 'oracle' && (
          <GodexEngineeringOracleView
            files={files}
            realityRecords={[]}
            onSelectFile={onSelectFile}
          />
        )}

        {/* VIEW 8: AUTONOMOUS VISUAL ENGINEERING LOOP */}
        {internalTab === 'visual-loop' && (
          <AutonomousLoopStudioView
            files={files}
            onSelectFile={onSelectFile}
            onApplyFileMutation={onApplyFileMutation}
          />
        )}
      </div>

      {/* AGENT COMPOSER (Bottom) */}
      {internalTab !== 'chat' && (
        <GodexAgentComposer
          onSendMessage={onSendMessage}
          isRunning={isWorking}
          taskState={taskState}
          executionMode={executionMode}
          onToggleExecutionMode={onToggleExecutionMode}
          onOpenModelSettings={onOpenModelSettings}
          onOpenCommandPalette={onOpenCommandPalette}
        />
      )}
    </div>
  );
};

