import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, X, Volume2, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface VoiceModalProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
}

export default function VoiceCommandModal({ language, isOpen, onClose }: VoiceModalProps) {
  const isSw = language === 'sw';
  const [isListening, setIsListening] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const queryPresets = [
    {
      sw: 'Bei ya mahindi Kariakoo leo ni ngapi?',
      en: 'What is the maize price at Kariakoo today?',
      answerSw: 'Mahindi yanauzwa Tsh 720 kwa kilo kwenye Soko la Kariakoo, ongezeko la 2.1% wiki hii.',
      answerEn: 'Maize is trading at Tsh 720 per kg at Kariakoo Market, up 2.1% this week.',
    },
    {
      sw: 'Mvua itanyesha saa ngapi Morogoro?',
      en: 'What time will it rain in Morogoro?',
      answerSw: 'Mvua nyepesi inatarajiwa kuanzia saa 9:00 alasiri leo. Panga kunyunyizia mbolea asubuhi.',
      answerEn: 'Light rain is forecast starting at 3:00 PM today. Plan to complete fertilization this morning.',
    },
    {
      sw: 'Kuna wanunuzi wa mpunga wiki hii?',
      en: 'Are there rice buyers this week?',
      answerSw: 'Ndiyo, Tanga Grain Millers wananunua mpunga kwa Tsh 1,180/kg kuanzia kiasi cha tan 5.',
      answerEn: 'Yes, Tanga Grain Millers are buying paddy at Tsh 1,180/kg for minimum 5-ton lots.',
    },
  ];

  const handleAsk = (preset: typeof queryPresets[0]) => {
    playKeyTap();
    setIsListening(true);
    setResponse(null);

    setTimeout(() => {
      setIsListening(false);
      setResponse(isSw ? preset.answerSw : preset.answerEn);
      playSuccessChime();
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-sm bg-[var(--paper)] rounded-3xl p-6 border border-[var(--line)] shadow-2xl relative text-center"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Pulsing Mic Circle */}
        <div className="relative w-20 h-20 mx-auto my-3 flex items-center justify-center">
          {isListening && (
            <span className="absolute inset-0 rounded-full border-4 border-[var(--soil)] animate-ping opacity-60" />
          )}
          <div
            className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg transition-colors ${
              isListening ? 'bg-[var(--soil)]' : 'bg-[var(--forest)]'
            }`}
          >
            <Mic className="w-7 h-7" />
          </div>
        </div>

        <h3 className="font-display text-lg font-bold text-[var(--ink)] mb-1">
          {isListening
            ? (isSw ? 'Ninasikiliza sauti yako...' : 'Listening to your voice...')
            : (isSw ? 'Msaidizi wa Sauti wa Ardhi' : 'Ardhi Voice Assistant')}
        </h3>

        <p className="text-xs text-[var(--ink-soft)] mb-4">
          {isSw
            ? 'Unaweza kuuliza maswali kuhusu bei, hali ya hewa na wanunuzi bila kuandika.'
            : 'Ask hands-free questions about crop pricing, weather, or buyers.'}
        </p>

        {/* Answer Box if answered */}
        {response && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-left text-xs space-y-1"
          >
            <div className="font-bold text-[var(--forest)] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{isSw ? 'Jibu la Ardhi:' : 'Ardhi Response:'}</span>
            </div>
            <p className="text-[var(--ink)] leading-relaxed">{response}</p>
          </motion.div>
        )}

        {/* Quick query choices */}
        <div className="space-y-2 text-left">
          <div className="text-[10px] font-bold text-[var(--ink-soft)] uppercase tracking-wider">
            {isSw ? 'Maswali ya Haraka:' : 'Quick Voice Prompts:'}
          </div>
          {queryPresets.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleAsk(q)}
              className="w-full p-2.5 rounded-xl bg-[var(--bg)] hover:border-[var(--forest)] border border-[var(--line)] text-left text-xs text-[var(--ink)] font-medium flex items-center justify-between group transition-all"
            >
              <span>"{isSw ? q.sw : q.en}"</span>
              <Volume2 className="w-3.5 h-3.5 text-[var(--ink-soft)] group-hover:text-[var(--forest)] flex-shrink-0 ml-2" />
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
