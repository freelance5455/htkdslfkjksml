import React from 'react';
import { SecuritySettings, AppSettings } from '../types';
import { AppLockModal } from './AppLock/AppLockModal';

interface SecurityLockModalProps {
  isLocked: boolean;
  securitySettings: SecuritySettings;
  onUnlock: () => void;
  appSettings?: AppSettings;
}

export const SecurityLockModal: React.FC<SecurityLockModalProps> = (props) => {
  return <AppLockModal {...props} />;
};
