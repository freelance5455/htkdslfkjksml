import React from 'react';
import {
  CheckCircle2,
  Pin,
  MapPin,
  HeartHandshake,
  Users,
  Sparkles,
  Crown,
  Smile,
  RotateCcw,
  Volume2,
  Clock,
  Heart,
  Quote,
} from 'lucide-react';
import { Visitor, FontSizeLevel, AltarTheme } from '../../types';
import { useChurch } from '../../context/ChurchContext';

interface Props {
  visitor: Visitor;
  fontSize: FontSizeLevel;
  theme: AltarTheme;
}

export const VisitorCard: React.FC<Props> = ({ visitor, fontSize, theme }) => {
  const { markAsPresented, markAsPending, togglePin } = useChurch();

  const isPresented = visitor.status === 'presented';

  // Dynamic font sizing
  const nameSizeClasses = {
    normal: 'text-xl sm:text-2xl',
    grande: 'text-2xl sm:text-3xl',
    extragrande: 'text-3xl sm:text-4xl',
    gigante: 'text-4xl sm:text-5xl',
  }[fontSize];

  const detailSizeClasses = {
    normal: 'text-sm sm:text-base',
    grande: 'text-base sm:text-lg',
    extragrande: 'text-lg sm:text-xl',
    gigante: 'text-xl sm:text-2xl',
  }[fontSize];

  // Pastoral suggestion phrase for the microphone
  const getMicrophoneScript = () => {
    const parts: string[] = [];
    parts.push(`Seja muito bem-vindo(a) ${visitor.name}`);
    if (visitor.companionCount > 0) {
      parts.push(`juntamente com ${visitor.companionsDetails || 'seus acompanhantes'}`);
    }
    if (visitor.cityOrNeighborhood) {
      parts.push(`vindo(a) de ${visitor.cityOrNeighborhood}`);
    }
    if (visitor.invitedBy) {
      parts.push(`a convite de ${visitor.invitedBy}`);
    }
    return parts.join(', ') + '! A igreja se alegra com sua presença!';
  };

  return (
    <div
      className={`relative rounded-3xl transition-all border-2 p-5 sm:p-7 shadow-xl ${
        isPresented
          ? 'bg-neutral-900/60 border-neutral-800/80 opacity-70'
          : visitor.isPinned
          ? 'bg-amber-950/20 border-amber-500/80 shadow-amber-500/10 ring-2 ring-amber-500/30'
          : 'bg-neutral-900 border-neutral-700/80 hover:border-amber-500/50'
      }`}
    >
      {/* Top badges & Pin */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-neutral-800">
        <div className="flex flex-wrap items-center gap-2">
          {visitor.isPinned && (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500 px-3 py-0.5 text-xs font-black text-neutral-950 shadow-sm">
              <Pin className="h-3.5 w-3.5 fill-current" /> FIXADO NO TOPO
            </span>
          )}

          {visitor.category === 'pastor_lider' && (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/20 border border-amber-500/40 px-3 py-0.5 text-xs font-bold text-amber-300">
              <Crown className="h-3.5 w-3.5 text-amber-400" /> PASTOR / LÍDER VISITANTE
            </span>
          )}

          {visitor.isFirstTime && (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-0.5 text-xs font-bold text-emerald-300">
              <Sparkles className="h-3.5 w-3.5" /> 1ª Vez na Igreja
            </span>
          )}

          <span className="text-xs text-neutral-400 flex items-center gap-1">
            <Clock className="h-3 w-3" /> Chegou às{' '}
            {new Date(visitor.registeredAt).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>

        {/* Pin button */}
        <button
          onClick={() => togglePin(visitor.id)}
          className={`p-2 rounded-xl transition ${
            visitor.isPinned
              ? 'bg-amber-500/20 text-amber-400'
              : 'text-neutral-500 hover:text-white hover:bg-neutral-800'
          }`}
          title={visitor.isPinned ? 'Desafixar' : 'Fixar no topo'}
        >
          <Pin className={`h-5 w-5 ${visitor.isPinned ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Big Visitor Name */}
      <div className="mb-4">
        <div className="flex items-center gap-3">
          <h3 className={`font-black tracking-tight text-white ${nameSizeClasses} leading-tight`}>
            {visitor.name}
          </h3>
          {visitor.companionCount > 0 && (
            <span className="rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-300 px-3 py-1 font-bold text-sm sm:text-base shrink-0">
              +{visitor.companionCount} {visitor.companionCount === 1 ? 'pessoa' : 'pessoas'}
            </span>
          )}
        </div>

        {visitor.companionsDetails && (
          <p className="mt-1 text-sm sm:text-base text-neutral-300 flex items-center gap-2">
            <Users className="h-4 w-4 text-amber-400 shrink-0" />
            <span>Acompanhantes: <strong>{visitor.companionsDetails}</strong></span>
          </p>
        )}
      </div>

      {/* Visitor Key Context Details (Large for pulpit reading) */}
      <div className={`space-y-2 mb-4 ${detailSizeClasses} text-neutral-300`}>
        {visitor.cityOrNeighborhood && (
          <div className="flex items-center gap-2.5">
            <MapPin className="h-5 w-5 text-amber-400 shrink-0" />
            <span>
              Vem de: <strong className="text-white">{visitor.cityOrNeighborhood}</strong>
            </span>
          </div>
        )}

        {visitor.invitedBy && (
          <div className="flex items-center gap-2.5">
            <HeartHandshake className="h-5 w-5 text-amber-400 shrink-0" />
            <span>
              Convidado(a) por: <strong className="text-amber-300">{visitor.invitedBy}</strong>
            </span>
          </div>
        )}

        {visitor.prayerRequest && (
          <div className="mt-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 p-3 sm:p-4 text-amber-200">
            <div className="flex items-center gap-2 font-bold text-amber-300 text-xs sm:text-sm mb-1">
              <Heart className="h-4 w-4 text-rose-400" />
              <span>Pedido de Oração / Motivo Especial:</span>
            </div>
            <p className="italic text-white font-medium text-sm sm:text-base">
              &ldquo;{visitor.prayerRequest}&rdquo;
            </p>
          </div>
        )}
      </div>

      {/* Pastoral Script Suggestion Box (Helpful for worship leaders) */}
      <div className="mb-5 rounded-2xl bg-neutral-950/70 border border-neutral-800 p-3.5 text-xs sm:text-sm text-neutral-300 flex items-start gap-2.5">
        <Quote className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed text-neutral-300">
          <strong className="text-amber-400">Sugestão ao microfone:</strong> {getMicrophoneScript()}
        </p>
      </div>

      {/* Big Action Buttons */}
      <div className="flex items-center gap-3 pt-2">
        {!isPresented ? (
          <button
            onClick={() => markAsPresented(visitor.id)}
            className="flex-1 flex items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-extrabold py-3.5 sm:py-4 px-6 text-base sm:text-lg shadow-lg shadow-emerald-600/30 active:scale-[0.98] transition"
          >
            <CheckCircle2 className="h-6 w-6 shrink-0" />
            <span>APRESENTAR / MARCAR COMO SAUDADO ✓</span>
          </button>
        ) : (
          <div className="flex-1 flex items-center justify-between bg-neutral-800/80 rounded-2xl p-3 border border-neutral-700">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm sm:text-base">
              <CheckCircle2 className="h-5 w-5" />
              <span>Já apresentado pelo Pastor</span>
              {visitor.presentedAt && (
                <span className="text-xs text-neutral-400 font-normal">
                  (às {new Date(visitor.presentedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                </span>
              )}
            </div>
            <button
              onClick={() => markAsPending(visitor.id)}
              className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white px-2 py-1 rounded-lg hover:bg-neutral-700 transition"
              title="Voltar para a lista de pendentes"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Desmarcar</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
