import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  X,
  Volume2,
  Users,
  MapPin,
  HeartHandshake,
  Heart,
  Crown,
  Sparkles,
  Quote,
} from 'lucide-react';
import { Visitor, FontSizeLevel, AltarTheme } from '../../types';
import { useChurch } from '../../context/ChurchContext';

interface Props {
  visitors: Visitor[];
  onClose: () => void;
  fontSize: FontSizeLevel;
  theme: AltarTheme;
}

export const AltarReadingMode: React.FC<Props> = ({ visitors, onClose, fontSize, theme }) => {
  const { markAsPresented } = useChurch();
  const [currentIndex, setCurrentIndex] = useState(0);

  // If no visitors
  if (visitors.length === 0) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-6 text-white text-center">
        <div className="space-y-4 max-w-md">
          <p className="text-2xl font-bold">Nenhum visitante cadastrado no momento.</p>
          <button
            onClick={onClose}
            className="rounded-2xl bg-amber-500 px-6 py-3 font-bold text-neutral-950"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  const current = visitors[currentIndex] || visitors[0];
  const isPresented = current.status === 'presented';

  const handleNext = () => {
    if (currentIndex < visitors.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handlePresentAndNext = () => {
    markAsPresented(current.id);
    if (currentIndex < visitors.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-black text-white p-4 sm:p-8 select-none">
      {/* Top Bar with Counter and Exit */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
        <div className="flex items-center gap-3">
          <span className="rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 font-mono font-bold text-base sm:text-lg">
            Visitante {currentIndex + 1} de {visitors.length}
          </span>
          {current.category === 'pastor_lider' && (
            <span className="flex items-center gap-1.5 rounded-full bg-amber-500 px-3 py-1 text-xs font-black text-neutral-950">
              <Crown className="h-4 w-4" /> PASTOR / LÍDER
            </span>
          )}
          {current.isFirstTime && (
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 px-3 py-1 text-xs font-bold text-emerald-300">
              <Sparkles className="h-4 w-4" /> 1ª VEZ
            </span>
          )}
        </div>

        <button
          onClick={onClose}
          className="flex items-center gap-2 rounded-2xl bg-neutral-900 border border-neutral-700 px-4 py-2 font-bold text-neutral-300 hover:text-white hover:bg-neutral-800 transition"
        >
          <X className="h-5 w-5" />
          <span>Fechar Modo Púlpito</span>
        </button>
      </div>

      {/* Center Giant Visitor Presentation Card */}
      <div className="my-auto max-w-4xl mx-auto w-full text-center space-y-6 sm:space-y-8 py-4">
        {/* Name in Massive Size */}
        <div>
          <h2 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white leading-tight">
            {current.name}
          </h2>
          {current.companionCount > 0 && (
            <div className="mt-3 inline-flex items-center gap-2 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 px-5 py-2 text-xl font-bold">
              <Users className="h-6 w-6" />
              <span>
                +{current.companionCount} {current.companionCount === 1 ? 'Acompanhante' : 'Acompanhantes'}
                {current.companionsDetails ? ` (${current.companionsDetails})` : ''}
              </span>
            </div>
          )}
        </div>

        {/* Location & Invitation */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xl sm:text-2xl text-neutral-300 font-medium">
          {current.cityOrNeighborhood && (
            <div className="flex items-center gap-2">
              <MapPin className="h-7 w-7 text-amber-400" />
              <span>
                Vem de: <strong className="text-white">{current.cityOrNeighborhood}</strong>
              </span>
            </div>
          )}

          {current.invitedBy && (
            <div className="flex items-center gap-2">
              <HeartHandshake className="h-7 w-7 text-amber-400" />
              <span>
                Convidado por: <strong className="text-amber-300">{current.invitedBy}</strong>
              </span>
            </div>
          )}
        </div>

        {/* Prayer Request */}
        {current.prayerRequest && (
          <div className="max-w-2xl mx-auto rounded-3xl bg-neutral-900 border border-amber-500/40 p-5 text-amber-200">
            <div className="flex items-center justify-center gap-2 font-bold text-amber-400 text-sm mb-1">
              <Heart className="h-5 w-5 text-rose-400" />
              <span>Pedido de Oração para a Igreja Apresentar a Deus:</span>
            </div>
            <p className="text-xl sm:text-2xl font-semibold italic text-white">
              &ldquo;{current.prayerRequest}&rdquo;
            </p>
          </div>
        )}

        {/* Status Indicator */}
        {isPresented && (
          <div className="inline-flex items-center gap-2 text-emerald-400 text-lg font-bold">
            <CheckCircle2 className="h-6 w-6" />
            <span>Já Saudado pelo Dirigente</span>
          </div>
        )}
      </div>

      {/* Bottom Large Touch Controls */}
      <div className="border-t border-neutral-800 pt-4 max-w-4xl mx-auto w-full flex items-center justify-between gap-4">
        {/* Previous */}
        <button
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className={`flex items-center gap-2 rounded-2xl px-6 py-4 font-bold text-lg transition ${
            currentIndex === 0
              ? 'bg-neutral-900 text-neutral-600 cursor-not-allowed'
              : 'bg-neutral-800 text-white hover:bg-neutral-700'
          }`}
        >
          <ChevronLeft className="h-6 w-6" />
          <span className="hidden sm:inline">Anterior</span>
        </button>

        {/* Giant Present Button */}
        <button
          onClick={handlePresentAndNext}
          className="flex-1 max-w-lg flex items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-black py-5 px-6 text-xl sm:text-2xl shadow-xl shadow-emerald-500/30 active:scale-[0.98] transition"
        >
          <CheckCircle2 className="h-8 w-8" />
          <span>{isPresented ? 'PRÓXIMO VISITANTE' : 'APRESENTAR ✓'}</span>
        </button>

        {/* Next */}
        <button
          onClick={handleNext}
          disabled={currentIndex === visitors.length - 1}
          className={`flex items-center gap-2 rounded-2xl px-6 py-4 font-bold text-lg transition ${
            currentIndex === visitors.length - 1
              ? 'bg-neutral-900 text-neutral-600 cursor-not-allowed'
              : 'bg-neutral-800 text-white hover:bg-neutral-700'
          }`}
        >
          <span className="hidden sm:inline">Próximo</span>
          <ChevronRight className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
};
