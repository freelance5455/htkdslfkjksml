import React, { useState } from 'react';
import {
  BookOpen,
  Users,
  CheckCircle2,
  Bell,
  Sliders,
  Type,
  Maximize2,
  Sparkles,
  Volume2,
  VolumeX,
  Clock,
  Pin,
  X,
  Church,
} from 'lucide-react';
import { useChurch } from '../../context/ChurchContext';
import { VisitorCard } from './VisitorCard';
import { AltarReadingMode } from './AltarReadingMode';
import { FontSizeLevel, AltarTheme } from '../../types';
import { churchAudio } from '../../utils/audio';

export const AltarView: React.FC = () => {
  const {
    visitors,
    service,
    fontSizeLevel,
    setFontSizeLevel,
    altarTheme,
    setAltarTheme,
    activeNewVisitorBanner,
    dismissNewVisitorBanner,
    isAudioEnabled,
    setIsAudioEnabled,
    unreadCountForAltar,
    resetUnreadCount,
  } = useChurch();

  const [activeTab, setActiveTab] = useState<'pending' | 'presented' | 'all'>('pending');
  const [isReadingModeOpen, setIsReadingModeOpen] = useState(false);

  // Filter visitors
  const pendingVisitors = visitors.filter((v) => v.status === 'pending');
  const presentedVisitors = visitors.filter((v) => v.status === 'presented');

  // Sort: Pinned first, then by time
  const sortVisitors = (list: typeof visitors) => {
    return [...list].sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.registeredAt).getTime() - new Date(a.registeredAt).getTime();
    });
  };

  const displayedVisitors = sortVisitors(
    activeTab === 'pending'
      ? pendingVisitors
      : activeTab === 'presented'
      ? presentedVisitors
      : visitors
  );

  const themeClasses: Record<AltarTheme, string> = {
    pulpito_dark: 'bg-black text-white',
    dourado_luxo: 'bg-neutral-950 text-amber-50',
    claro_solar: 'bg-neutral-100 text-neutral-900',
    alto_contraste: 'bg-black text-yellow-300',
  };

  const handleTestSound = () => {
    churchAudio.playVisitorArrivalBell();
  };

  return (
    <div className={`min-h-[calc(100vh-105px)] p-3 sm:p-6 transition-colors duration-300 ${themeClasses[altarTheme]}`}>
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Real-time Alert Banner when Door registers a new visitor */}
        {activeNewVisitorBanner && (
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 p-5 text-neutral-950 shadow-2xl shadow-amber-500/30 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-neutral-950 text-amber-400 shrink-0">
                  <Bell className="h-6 w-6 animate-bounce" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-neutral-950 px-2.5 py-0.5 text-xs font-black uppercase text-amber-300">
                      Chegou Agora na Porta!
                    </span>
                    <span className="text-xs font-semibold text-neutral-900">
                      {new Date(activeNewVisitorBanner.registeredAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <h4 className="text-xl sm:text-2xl font-black text-neutral-950 leading-tight">
                    {activeNewVisitorBanner.name}
                    {activeNewVisitorBanner.companionCount > 0 &&
                      ` (+${activeNewVisitorBanner.companionCount})`}
                  </h4>
                  {activeNewVisitorBanner.cityOrNeighborhood && (
                    <p className="text-xs sm:text-sm font-semibold text-neutral-900">
                      Vem do bairro: {activeNewVisitorBanner.cityOrNeighborhood}
                      {activeNewVisitorBanner.invitedBy && ` • Convite: ${activeNewVisitorBanner.invitedBy}`}
                    </p>
                  )}
                </div>
              </div>

              <button
                onClick={dismissNewVisitorBanner}
                className="rounded-2xl bg-neutral-950/20 p-2 text-neutral-950 hover:bg-neutral-950/40 transition shrink-0"
                title="Fechar alerta"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>
        )}

        {/* Altar Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 p-4 sm:p-5 shadow-xl text-white">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <BookOpen className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  Tablet do Altar / Púlpito
                </h2>
                <span className="rounded-full bg-amber-500/20 border border-amber-500/40 px-2.5 py-0.5 text-xs font-bold text-amber-300">
                  Dirigente: {service.leaderName || 'Pastor'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-400">
                Os visitantes cadastrados na recepção aparecem aqui instantaneamente para apresentação.
              </p>
            </div>
          </div>

          {/* Quick Pulpit Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Fullscreen Reading Mode Button */}
            <button
              onClick={() => setIsReadingModeOpen(true)}
              className="flex items-center gap-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-neutral-950 px-4 py-2.5 font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition active:scale-95"
            >
              <Maximize2 className="h-4 w-4" />
              <span>Modo Púlpito (1 por vez)</span>
            </button>

            {/* Test Bell Audio */}
            <button
              onClick={handleTestSound}
              className="flex items-center gap-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 px-3 py-2 text-xs font-semibold text-neutral-300 transition"
              title="Testar som discreto da chegada de visitante"
            >
              <Bell className="h-3.5 w-3.5 text-amber-400" />
              <span className="hidden sm:inline">Testar Sino</span>
            </button>
          </div>
        </div>

        {/* Pulpit Settings & Font Sizing Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 px-4 py-3 text-neutral-300 text-xs">
          {/* Font Size Adjuster */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-400 flex items-center gap-1.5">
              <Type className="h-4 w-4 text-amber-400" /> Tamanho do Texto:
            </span>
            <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
              {(
                [
                  { id: 'normal', label: 'A' },
                  { id: 'grande', label: 'A+' },
                  { id: 'extragrande', label: 'A++' },
                  { id: 'gigante', label: 'A+++' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFontSizeLevel(f.id)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    fontSizeLevel === f.id
                      ? 'bg-amber-500 text-neutral-950'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Selector */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-400">Tema do Púlpito:</span>
            <select
              value={altarTheme}
              onChange={(e) => setAltarTheme(e.target.value as AltarTheme)}
              className="rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-1.5 text-xs font-semibold text-white focus:outline-none focus:border-amber-400"
            >
              <option value="pulpito_dark">Púlpito Noturno (OLED Preto)</option>
              <option value="dourado_luxo">Dourado Solene</option>
              <option value="alto_contraste">Alto Contraste (Amarelo)</option>
              <option value="claro_solar">Claro Solar (Manhã)</option>
            </select>
          </div>
        </div>

        {/* Tabs: Para Apresentar vs Já Apresentados */}
        <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
          <button
            onClick={() => setActiveTab('pending')}
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-sm sm:text-base font-extrabold transition ${
              activeTab === 'pending'
                ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                : 'bg-neutral-900/60 text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            <span>Para Apresentar</span>
            <span
              className={`rounded-full px-2 py-0.5 text-xs font-black ${
                activeTab === 'pending'
                  ? 'bg-neutral-950 text-amber-400'
                  : 'bg-amber-500/20 text-amber-300'
              }`}
            >
              {pendingVisitors.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('presented')}
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-sm sm:text-base font-bold transition ${
              activeTab === 'presented'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-neutral-900/60 text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>Já Apresentados</span>
            <span className="rounded-full bg-neutral-800 px-2 py-0.5 text-xs font-bold text-neutral-300">
              {presentedVisitors.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('all')}
            className={`flex items-center gap-2 px-4 py-3 rounded-2xl text-sm font-semibold transition ${
              activeTab === 'all'
                ? 'bg-neutral-700 text-white'
                : 'bg-neutral-900/60 text-neutral-400 hover:text-white'
            }`}
          >
            <span>Todos ({visitors.length})</span>
          </button>
        </div>

        {/* Visitors Card Feed */}
        <div className="space-y-4">
          {displayedVisitors.length === 0 ? (
            <div className="py-20 text-center rounded-3xl bg-neutral-900/40 border border-neutral-800/80 p-8 space-y-3">
              <Users className="h-12 w-12 mx-auto text-neutral-600" />
              {activeTab === 'pending' ? (
                <>
                  <h3 className="text-xl font-bold text-white">
                    Nenhum visitante pendente para apresentar!
                  </h3>
                  <p className="text-sm text-neutral-400 max-w-md mx-auto">
                    Assim que a equipe da portaria registrar alguém no tablet da porta, o nome surgirá aqui instantaneamente.
                  </p>
                </>
              ) : (
                <p className="text-neutral-400">Nenhum visitante nesta categoria.</p>
              )}
            </div>
          ) : (
            displayedVisitors.map((visitor) => (
              <VisitorCard
                key={visitor.id}
                visitor={visitor}
                fontSize={fontSizeLevel}
                theme={altarTheme}
              />
            ))
          )}
        </div>
      </div>

      {/* Fullscreen Reading Mode Modal */}
      {isReadingModeOpen && (
        <AltarReadingMode
          visitors={displayedVisitors.length > 0 ? displayedVisitors : visitors}
          onClose={() => setIsReadingModeOpen(false)}
          fontSize={fontSizeLevel}
          theme={altarTheme}
        />
      )}
    </div>
  );
};
