import React from "react";
import { motion, useReducedMotion, Transition } from "motion/react";
import { FloatingFrame } from "../types";

interface FloatingFoodFrameProps {
  frame: FloatingFrame;
  className?: string;
  onClick?: () => void;
}

export const FloatingFoodFrame: React.FC<FloatingFoodFrameProps> = ({
  frame,
  className = "",
  onClick,
}) => {
  const shouldReduceMotion = useReducedMotion();

  const getAnimation = () => {
    if (shouldReduceMotion) {
      return {
        animate: { transform: `rotate(${frame.rotation}deg)` },
        transition: undefined,
      };
    }

    const baseTransition: Transition = {
      duration: frame.duration || 10,
      repeat: Infinity,
      repeatType: "loop",
      ease: [0.42, 0, 0.58, 1],
      delay: frame.delay || 0,
    };

    switch (frame.motionType) {
      case "drift":
        return {
          animate: {
            y: [-4, 4, -4],
            rotate: [frame.rotation, frame.rotation + 0.6, frame.rotation],
          },
          transition: baseTransition,
        };
      case "rotate":
        return {
          animate: {
            rotate: [frame.rotation - 0.8, frame.rotation + 0.8, frame.rotation - 0.8],
          },
          transition: baseTransition,
        };
      case "diagonal":
        return {
          animate: {
            x: [-3, 3, -3],
            y: [-4, 3, -4],
            rotate: [frame.rotation, frame.rotation - 0.5, frame.rotation],
          },
          transition: baseTransition,
        };
      case "scale":
        return {
          animate: {
            scale: [1, 1.018, 1],
            rotate: [frame.rotation, frame.rotation + 0.4, frame.rotation],
          },
          transition: baseTransition,
        };
      case "horizontal":
        return {
          animate: {
            x: [-4, 4, -4],
            rotate: [frame.rotation, frame.rotation + 0.5, frame.rotation],
          },
          transition: baseTransition,
        };
      default:
        return {
          animate: {
            rotate: frame.rotation,
          },
          transition: undefined,
        };
    }
  };

  const { animate, transition } = getAnimation();

  return (
    <motion.div
      animate={animate}
      transition={transition}
      onClick={onClick}
      className={`relative inline-block select-none pointer-events-auto cursor-pointer transition-shadow hover:shadow-xl ${className}`}
      style={{ willChange: "transform" }}
    >
      <div className="p-2 sm:p-2.5 bg-[#FDFBF7] border border-[#D8D0C2]/60 rounded-sm paper-frame group overflow-hidden">
        <div className="relative overflow-hidden bg-[#EAE4D7]">
          <img
            src={frame.imageUrl}
            alt={frame.alt}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
        </div>
        {frame.title && (
          <div className="pt-2 px-1 flex items-center justify-between text-[11px] tracking-widest uppercase text-[#17201C]/60 font-medium">
            <span className="truncate">{frame.title}</span>
            <span className="text-[#9BAF82] text-[10px] ml-1">●</span>
          </div>
        )}
      </div>
    </motion.div>
  );
};
