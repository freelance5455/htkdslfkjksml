import React from "react";
import { motion } from "motion/react";
import { ArrowRight, Sparkles, UploadCloud } from "lucide-react";
import { MenuCategory } from "../types";

interface MenuMegaPanelProps {
  categories: MenuCategory[];
  isOpen: boolean;
  onClose: () => void;
  onSelectCategory: (categoryId: string) => void;
  onOpenImport: () => void;
}

export const MenuMegaPanel: React.FC<MenuMegaPanelProps> = ({
  categories,
  isOpen,
  onClose,
  onSelectCategory,
  onOpenImport,
}) => {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      onMouseLeave={onClose}
      className="absolute top-full left-0 w-full bg-[#FDFBF7] text-[#17201C] border-b border-[#D8D0C2] shadow-xl z-50 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 py-8 sm:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Editorial Heading & Overview */}
          <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-[#D8D0C2]/70 pb-6 lg:pb-0 lg:pr-8">
            <div className="text-[11px] font-sans uppercase tracking-widest text-[#17201C]/50 font-semibold mb-2">
              Kaloreez Dining Architecture
            </div>
            <h3 className="font-serif text-3xl sm:text-4xl text-[#17201C] leading-tight mb-3">
              The Wholesome Menu
            </h3>
            <p className="text-sm text-[#17201C]/75 font-sans leading-relaxed mb-6">
              Thoughtfully prepared with honest ingredients, cold-pressed botanicals, and clean seasonings in Daspalla Hills, Vizag.
            </p>

            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => onSelectCategory("all")}
                className="inline-flex items-center justify-between w-full px-4 py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium uppercase tracking-widest hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors cursor-pointer"
              >
                <span>View Complete Menu</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={onOpenImport}
                className="inline-flex items-center justify-center gap-2 w-full px-4 py-2 rounded-full border border-[#D8D0C2] text-xs uppercase tracking-wider text-[#17201C]/80 hover:border-[#17201C] hover:text-[#17201C] transition-colors cursor-pointer"
              >
                <UploadCloud className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Import Menu Photos (OCR)</span>
              </button>
            </div>
          </div>

          {/* Right Column: Dynamically Detected Categories Grid */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-4">
              <div className="text-xs uppercase tracking-widest text-[#17201C]/60 font-semibold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#9BAF82]" />
                Dynamically Detected Offerings ({categories.length} Categories)
              </div>
              <span className="text-[11px] text-[#17201C]/50">Select to explore dishes</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => onSelectCategory(category.id)}
                  className="group text-left p-3.5 rounded-xs bg-[#F4F0E7]/60 border border-transparent hover:border-[#D8D0C2] hover:bg-[#F4F0E7] transition-all cursor-pointer"
                >
                  <div className="font-serif text-lg text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-snug">
                    {category.name}
                  </div>
                  <div className="text-[11px] text-[#17201C]/60 font-sans mt-0.5 line-clamp-1">
                    {category.dishes.length} {category.dishes.length === 1 ? "dish" : "dishes"} · {category.dishes[0]?.name || "Verified offerings"}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
