// Cash Register & Shift Reconciliation View
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import { CashSession } from '../../types';
import { CreditCard, DollarSign, Clock, AlertTriangle, CheckCircle2, Lock, Unlock } from 'lucide-react';

export const CashRegisterView: React.FC = () => {
  const { currentBranch, currentUser } = useAuth();
  const settings = dbStore.getSettings();
  const registers = dbStore.getCashRegisters(currentBranch.id);

  const [activeSession, setActiveSession] = useState<CashSession | undefined>(
    currentUser ? dbStore.getActiveCashSession(currentUser.id) : undefined
  );
  const [openingFloat, setOpeningFloat] = useState<number>(1000);
  const [selectedRegisterId, setSelectedRegisterId] = useState<string>(registers[0]?.id || '');
  const [closingCash, setClosingCash] = useState<number>(0);
  const [closeNotes, setCloseNotes] = useState<string>('');
  const [isCloseModalOpen, setIsCloseModalOpen] = useState(false);

  const handleOpenSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const session = dbStore.openCashSession(
      selectedRegisterId || registers[0].id,
      currentUser.id,
      currentUser.name,
      openingFloat
    );
    setActiveSession(session);
  };

  const handleCloseSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !activeSession) return;
    const closed = dbStore.closeCashSession(
      activeSession.id,
      closingCash,
      currentUser.id,
      currentUser.name,
      closeNotes
    );
    setActiveSession(undefined);
    setIsCloseModalOpen(false);
    alert(
      `Shift Closed!\nExpected: ${settings.currency} ${closed.expectedCash?.toFixed(2)}\nActual: ${settings.currency} ${closed.actualCash?.toFixed(2)}\nVariance: ${settings.currency} ${closed.difference?.toFixed(2)}`
    );
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-emerald-400" />
          <h1 className="text-xl font-bold text-slate-100">Cash Register Lanes & Shift Balances</h1>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Open daily till sessions, perform end-of-shift cash drawer counts, and audit cash variance.
        </p>
      </div>

      {/* Active Cashier Session Status Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h2 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-400" />
          Cashier Drawer Session ({currentUser?.name})
        </h2>

        {activeSession ? (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span className="font-bold text-emerald-300 text-sm">Shift Active & Unlocked</span>
                  <span className="text-xs font-mono text-emerald-400/80">({activeSession.id})</span>
                </div>
                <div className="text-xs text-slate-300 mt-1">
                  Opened at:{' '}
                  <span className="font-mono text-white">
                    {new Date(activeSession.openedAt).toLocaleTimeString()}
                  </span>{' '}
                  with initial float of{' '}
                  <span className="font-mono font-bold text-emerald-400">
                    {settings.currency} {activeSession.openingBalance.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  setClosingCash(activeSession.openingBalance);
                  setIsCloseModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold shadow-sm"
              >
                <Lock className="w-4 h-4" />
                Close Shift & Count Drawer
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleOpenSession} className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-4">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold">
              <Unlock className="w-4 h-4" />
              No active cash session found for your operator profile. Please open a till before taking sales.
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Select Checkout Lane</label>
                <select
                  value={selectedRegisterId}
                  onChange={(e) => setSelectedRegisterId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200"
                >
                  {registers.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} ({r.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Opening Cash Float ({settings.currency})</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={openingFloat}
                  onChange={(e) => setOpeningFloat(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm shadow-emerald-900/30"
            >
              Open Cash Drawer Shift
            </button>
          </form>
        )}
      </div>

      {/* Lanes Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="px-5 py-3 border-b border-slate-800 font-bold text-xs text-slate-300">
          Supermarket Checkout POS Lanes in {currentBranch.name}
        </div>
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60 font-semibold">
              <th className="py-3 px-4">Lane Code</th>
              <th className="py-3 px-4">Terminal Name</th>
              <th className="py-3 px-4 text-center">Hardware Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {registers.map((r) => (
              <tr key={r.id}>
                <td className="py-3 px-4 font-mono font-bold text-emerald-400">{r.code}</td>
                <td className="py-3 px-4">{r.name}</td>
                <td className="py-3 px-4 text-center">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      r.status === 'OPEN'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {r.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* End of Shift Close Modal */}
      {isCloseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4">
            <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Lock className="w-4 h-4 text-rose-400" />
              Reconcile & Close Cash Session
            </h2>

            <form onSubmit={handleCloseSession} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Physical Cash Count in Drawer ({settings.currency})
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={closingCash}
                  onChange={(e) => setClosingCash(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Shift Notes / Explanations</label>
                <textarea
                  rows={2}
                  value={closeNotes}
                  onChange={(e) => setCloseNotes(e.target.value)}
                  placeholder="e.g. Clean drawer, handed key to night supervisor"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCloseModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-lg shadow-sm"
                >
                  Finalize & Close Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
