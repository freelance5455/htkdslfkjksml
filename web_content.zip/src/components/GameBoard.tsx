import React, { useState, useRef } from 'react';
import { Arrow, Direction, Point } from '../types/game';
import { ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

interface GameBoardProps {
  gridRows: number;
  gridCols: number;
  arrows: Arrow[];
  onArrowClick: (arrow: Arrow) => void;
  isPaused: boolean;
  animationSpeed: 'normal' | 'fast';
  theme: 'paper_light' | 'pure_black' | 'charcoal';
}

export const GameBoard: React.FC<GameBoardProps> = ({
  gridRows,
  gridCols,
  arrows,
  onArrowClick,
  isPaused,
  animationSpeed,
  theme,
}) => {
  const [hoveredArrowId, setHoveredArrowId] = useState<string | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const containerRef = useRef<HTMLDivElement>(null);

  // Dynamic cell sizing based on density
  const cellSize = gridCols > 24 ? 26 : gridCols > 16 ? 30 : 36;
  const padding = 28;
  const svgWidth = gridCols * cellSize + padding * 2;
  const svgHeight = gridRows * cellSize + padding * 2;

  const toPx = (p: Point) => ({
    x: padding + p.x * cellSize + cellSize / 2,
    y: padding + p.y * cellSize + cellSize / 2,
  });

  const makePathData = (points: Point[]) => {
    if (points.length === 0) return '';
    const pxPoints = points.map(toPx);
    let d = `M ${pxPoints[0].x} ${pxPoints[0].y}`;
    for (let i = 1; i < pxPoints.length; i++) {
      d += ` L ${pxPoints[i].x} ${pxPoints[i].y}`;
    }
    return d;
  };

  const makeArrowHead = (headPt: Point, dir: Direction) => {
    const { x, y } = toPx(headPt);
    const arrowSize = cellSize > 30 ? 9 : 7.5;
    const arrowLen = cellSize > 30 ? 13 : 11;

    switch (dir) {
      case 'UP':
        return `${x},${y - arrowLen + 3} ${x - arrowSize},${y + 4} ${x + arrowSize},${y + 4}`;
      case 'DOWN':
        return `${x},${y + arrowLen - 3} ${x - arrowSize},${y - 4} ${x + arrowSize},${y - 4}`;
      case 'LEFT':
        return `${x - arrowLen + 3},${y} ${x + 4},${y - arrowSize} ${x + 4},${y + arrowSize}`;
      case 'RIGHT':
        return `${x + arrowLen - 3},${y} ${x - 4},${y - arrowSize} ${x - 4},${y + arrowSize}`;
    }
  };

  /**
   * Smooth physical directional exit translation:
   * RIGHT: smoothly glides right and exits the board completely
   * LEFT: smoothly glides left and exits the board completely
   * UP: smoothly glides upward and exits the board completely
   * DOWN: smoothly glides downward and exits the board completely
   */
  const getEscapeStyle = (arrow: Arrow): React.CSSProperties => {
    if (!arrow.isEscaping) {
      return {
        transform: 'translate3d(0, 0, 0)',
        opacity: 1,
      };
    }

    const duration = animationSpeed === 'fast' ? '0.28s' : '0.42s';
    const exitDist = Math.max(svgWidth, svgHeight) + 160;

    let transform = 'translate3d(0, 0, 0)';
    switch (arrow.direction) {
      case 'RIGHT':
        transform = `translate3d(${exitDist}px, 0, 0)`;
        break;
      case 'LEFT':
        transform = `translate3d(-${exitDist}px, 0, 0)`;
        break;
      case 'UP':
        transform = `translate3d(0, -${exitDist}px, 0)`;
        break;
      case 'DOWN':
        transform = `translate3d(0, ${exitDist}px, 0)`;
        break;
    }

    return {
      transform,
      opacity: 0,
      transition: `transform ${duration} cubic-bezier(0.16, 1, 0.3, 1), opacity ${duration} cubic-bezier(0.4, 0, 1, 1)`,
      pointerEvents: 'none',
    };
  };

  // Palette styling based on active theme
  const isLight = theme === 'paper_light';
  const boardBg = isLight ? '#FFFFFF' : theme === 'pure_black' ? '#000000' : '#0D0D0D';
  const boardBorder = isLight ? '#E5E5E5' : '#222222';
  const defaultStroke = isLight ? '#000000' : '#FFFFFF';
  const hoverStroke = isLight ? '#3B82F6' : '#60A5FA';
  const hintStroke = '#F59E0B';
  const invalidStroke = '#EF4444';

  const strokeWidth = cellSize > 30 ? 4.5 : 3.8;

  return (
    <div className="relative w-full flex flex-col items-center">
      {/* Zoom controls for large dense levels */}
      {(gridCols > 15 || gridRows > 18) && (
        <div className="flex items-center gap-1 mb-2 px-2.5 py-1 bg-[#121212]/90 border border-[#2a2a2a] rounded-full text-xs select-none shadow">
          <button
            type="button"
            onClick={() => setZoomLevel((z) => Math.max(0.75, Number((z - 0.15).toFixed(2))))}
            className="p-1 hover:text-white text-neutral-400 transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-[11px] text-neutral-300 px-1">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setZoomLevel((z) => Math.min(1.8, Number((z + 0.15).toFixed(2))))}
            className="p-1 hover:text-white text-neutral-400 transition-colors cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoomLevel(1)}
            className="p-1 hover:text-white text-neutral-400 transition-colors ml-1 cursor-pointer"
            title="Reset Zoom"
          >
            <Maximize2 className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Board Frame */}
      <div
        ref={containerRef}
        className="relative w-full max-w-[540px] max-h-[68vh] mx-auto p-2 sm:p-4 rounded-3xl transition-colors duration-300 select-none shadow-2xl flex items-center justify-center overflow-auto"
        style={{
          backgroundColor: boardBg,
          borderColor: boardBorder,
          borderWidth: '2px',
          boxShadow: isLight
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 1px 3px rgba(0, 0, 0, 0.05)'
            : '0 20px 50px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.08)',
        }}
      >
        <div
          className="w-full flex items-center justify-center transition-transform duration-150 origin-center"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-auto overflow-visible"
            style={{ touchAction: 'manipulation' }}
          >
            {/* Subtle background grid dots for spatial orientation */}
            <g opacity={isLight ? 0.07 : 0.12}>
              {Array.from({ length: gridRows }).map((_, r) =>
                Array.from({ length: gridCols }).map((_, c) => {
                  const pt = toPx({ x: c, y: r });
                  return (
                    <circle
                      key={`dot-${r}-${c}`}
                      cx={pt.x}
                      cy={pt.y}
                      r={1.2}
                      fill={isLight ? '#000000' : '#FFFFFF'}
                    />
                  );
                })
              )}
            </g>

            {/* Arrows */}
            {arrows.map((arrow) => {
              const isHovered = hoveredArrowId === arrow.id;
              const headPt =
                arrow.points.length > 0
                  ? arrow.points[arrow.points.length - 1]
                  : { x: arrow.col, y: arrow.row };

              const strokeColor = arrow.isInvalid
                ? invalidStroke
                : arrow.isHinted
                ? hintStroke
                : isHovered
                ? hoverStroke
                : defaultStroke;

              const pathD = makePathData(arrow.points);
              const headPoints = makeArrowHead(headPt, arrow.direction);
              const escapeStyle = getEscapeStyle(arrow);

              return (
                <g
                  key={arrow.id}
                  onClick={() => !isPaused && !arrow.isEscaping && onArrowClick(arrow)}
                  onMouseEnter={() => setHoveredArrowId(arrow.id)}
                  onMouseLeave={() => setHoveredArrowId(null)}
                  className={`cursor-pointer ${arrow.isInvalid ? 'animate-invalid' : ''} ${
                    arrow.isHinted ? 'animate-hint' : ''
                  }`}
                  style={escapeStyle}
                >
                  {/* Invisible wide touch buffer (26px touch buffer) */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke="transparent"
                    strokeWidth={26}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Glow outline on hover or hint */}
                  {(isHovered || arrow.isHinted) && (
                    <path
                      d={pathD}
                      fill="none"
                      stroke={
                        arrow.isHinted
                          ? 'rgba(245, 158, 11, 0.45)'
                          : 'rgba(59, 130, 246, 0.4)'
                      }
                      strokeWidth={strokeWidth + 5}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  )}

                  {/* Solid vector path */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    strokeLinecap="square"
                    strokeLinejoin="miter"
                    strokeMiterlimit={4}
                  />

                  {/* Directional arrowhead */}
                  <polygon
                    points={headPoints}
                    fill={strokeColor}
                    stroke={strokeColor}
                    strokeWidth={1}
                    strokeLinejoin="miter"
                  />
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
