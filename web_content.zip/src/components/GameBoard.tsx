import React, { forwardRef, useState } from 'react';
import { BlockVisualEffect, DragState, GridCell, PowerUpType } from '../types/game';
import { ThemeConfig, GAME_THEMES } from '../constants/themes';
import { BlockCell } from './BlockPiece';

interface GameBoardProps {
  grid: GridCell[][];
  dragState: DragState | null;
  isShaking: boolean;
  theme?: ThemeConfig;
  activePowerUp?: PowerUpType | null;
  visualStyle?: BlockVisualEffect;
  boardSize?: number;
  innerGridRef?: React.RefObject<HTMLDivElement | null>;
  onCellClick?: (row: number, col: number) => void;
}

export const GameBoard = forwardRef<HTMLDivElement, GameBoardProps>(
  (
    {
      grid,
      dragState,
      isShaking,
      theme = GAME_THEMES.cosmic,
      activePowerUp = null,
      visualStyle = 'crystalline',
      boardSize,
      innerGridRef,
      onCellClick,
    },
    ref
  ) => {
    const [hoveredCell, setHoveredCell] = useState<{ r: number; c: number } | null>(null);

    // Determine ghost cells from dragState
    const ghostCells = new Set<string>();
    const clearingPreviewRows = new Set<number>(dragState?.clearedLinesPreview.rows || []);
    const clearingPreviewCols = new Set<number>(dragState?.clearedLinesPreview.cols || []);

    if (dragState && dragState.isValidPlacement && dragState.gridRow !== null && dragState.gridCol !== null) {
      const { piece, gridRow, gridCol } = dragState;
      for (let r = 0; r < piece.height; r++) {
        for (let c = 0; c < piece.width; c++) {
          if (piece.matrix[r][c] === 1) {
            ghostCells.add(`${gridRow + r},${gridCol + c}`);
          }
        }
      }
    }

    // Determine powerup blast radius cells
    const powerUpTargetCells = new Set<string>();
    if (activePowerUp && hoveredCell) {
      if (activePowerUp === 'HAMMER') {
        powerUpTargetCells.add(`${hoveredCell.r},${hoveredCell.c}`);
      } else if (activePowerUp === 'BOMB_BLAST') {
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            const tr = hoveredCell.r + dr;
            const tc = hoveredCell.c + dc;
            if (tr >= 0 && tr < 10 && tc >= 0 && tc < 10) {
              powerUpTargetCells.add(`${tr},${tc}`);
            }
          }
        }
      }
    }

    return (
      <div className="relative flex items-center justify-center p-0.5 sm:p-1 w-auto mx-auto select-none touch-none">
        {/* Outer ambient glow frame */}
        <div
          className="absolute inset-0 rounded-2xl filter blur-xl pointer-events-none transition-colors duration-300"
          style={{ background: theme.boardGlow }}
        />

        {/* Board Enclosure */}
        <div
          ref={ref}
          id="game-board-container"
          style={{
            backgroundColor: theme.boardBg,
            borderColor: theme.boardBorder,
            width: boardSize ? `${boardSize}px` : undefined,
            height: boardSize ? `${boardSize}px` : undefined,
          }}
          className={`relative z-10 ${
            !boardSize ? 'w-[min(calc(100vw-16px),calc(100dvh-200px),375px)] h-[min(calc(100vw-16px),calc(100dvh-200px),375px)]' : ''
          } aspect-square p-1.5 sm:p-2 rounded-2xl border shadow-[0_10px_35px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.12)] transition-all duration-100 ${
            isShaking ? 'shake-animation' : ''
          } ${activePowerUp ? 'cursor-crosshair ring-2 ring-cyan-400/50' : ''}`}
        >
          {/* 10x10 CSS Grid with exact ref for touch measurement */}
          <div
            ref={innerGridRef}
            className="grid grid-cols-10 grid-rows-10 gap-0.5 sm:gap-1 w-full h-full touch-none"
          >
            {grid.map((row, r) =>
              row.map((cell, c) => {
                const key = `${r},${c}`;
                const isGhost = ghostCells.has(key);
                const isWillClear = clearingPreviewRows.has(r) || clearingPreviewCols.has(c);
                const isTargetedByPowerUp = powerUpTargetCells.has(key);

                return (
                  <div
                    key={key}
                    data-row={r}
                    data-col={c}
                    onPointerEnter={() => {
                      if (activePowerUp) setHoveredCell({ r, c });
                    }}
                    onPointerLeave={() => {
                      if (activePowerUp) setHoveredCell(null);
                    }}
                    onClick={() => {
                      if (activePowerUp && onCellClick) {
                        onCellClick(r, c);
                      }
                    }}
                    className={`relative w-full h-full rounded sm:rounded-md overflow-hidden transition-all duration-75 flex items-center justify-center ${
                      cell.filled
                        ? ''
                        : isGhost
                        ? ''
                        : isWillClear
                        ? 'bg-cyan-900/40 border border-cyan-400/60 shadow-[inset_0_0_8px_rgba(6,182,212,0.4)]'
                        : isTargetedByPowerUp
                        ? 'bg-rose-500/25 border border-rose-400 animate-pulse'
                        : 'bg-[#10192e]/90 border border-slate-800/80 shadow-[inset_0_1px_3px_rgba(0,0,0,0.6)]'
                    }`}
                  >
                    {/* Render existing filled cell */}
                    {cell.filled && cell.color && (
                      <BlockCell
                        color={cell.color}
                        isClearing={cell.clearing}
                        isBomb={cell.isBomb}
                        bombCountdown={cell.bombCountdown}
                        isTargeted={isTargetedByPowerUp}
                        visualStyle={visualStyle}
                        className={isWillClear ? 'brightness-125' : ''}
                      />
                    )}

                    {/* Render projected ghost cell */}
                    {!cell.filled && isGhost && dragState && (
                      <BlockCell
                        color={dragState.piece.color}
                        isGhost={true}
                      />
                    )}

                    {/* PowerUp crosshair on empty targeted cell */}
                    {!cell.filled && isTargetedByPowerUp && (
                      <div className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
                    )}

                    {/* Subtle cell center dot for empty cells */}
                    {!cell.filled && !isGhost && !isWillClear && !isTargetedByPowerUp && (
                      <div className="w-1 h-1 rounded-full bg-slate-700/35 pointer-events-none" />
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  }
);

GameBoard.displayName = 'GameBoard';
