import React, { useRef, useState, useEffect } from 'react';
import { BoardTile } from '../types';
import { ArrowTile, TILE_COLOR_CONFIGS } from './ArrowTile';
import { LongArrowPiece } from './LongArrowPiece';
import { EscapeParticles, ParticleBurst } from './EscapeParticles';

interface GameBoardProps {
  tiles: BoardTile[];
  gridWidth: number;
  gridHeight: number;
  arrowSkin: string;
  boardTheme: string;
  onTileTap: (tile: BoardTile) => void;
  blockedTileId: string | null;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  tiles,
  gridWidth,
  gridHeight,
  arrowSkin,
  boardTheme,
  onTileTap,
  blockedTileId,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tileSize, setTileSize] = useState(28);
  const [bursts, setBursts] = useState<ParticleBurst[]>([]);
  const prevEscapingRef = useRef<Set<string>>(new Set());

  const safeGridWidth = Number.isFinite(gridWidth) && gridWidth > 0 ? gridWidth : 10;
  const safeGridHeight = Number.isFinite(gridHeight) && gridHeight > 0 ? gridHeight : 10;
  const gap = 2.5; // Very small gap between compact tiles
  const padding = 12;

  // Dynamically calculate responsive tile size: adapts for both compact square grids and long arrow boards
  useEffect(() => {
    const updateSize = () => {
      if (!containerRef.current) return;
      const { clientWidth, clientHeight } = containerRef.current;
      if (clientWidth <= 0 || clientHeight <= 0) return;

      // Available space with safe margins for small to large Android screens
      const maxAvailableWidth = Math.max(180, clientWidth - 16);
      const maxAvailableHeight = Math.max(180, clientHeight - 16);

      const sizeFromWidth = Math.floor(
        (maxAvailableWidth - padding * 2 - (safeGridWidth - 1) * gap) / safeGridWidth
      );
      const sizeFromHeight = Math.floor(
        (maxAvailableHeight - padding * 2 - (safeGridHeight - 1) * gap) / safeGridHeight
      );

      const raw = Math.min(sizeFromWidth, sizeFromHeight);
      if (Number.isFinite(raw) && raw > 0) {
        // Comfortably scale up on larger phones/screens, scale down on small screens
        const maxCap = safeGridWidth <= 7 ? 48 : safeGridWidth <= 9 ? 42 : 36;
        const computed = Math.max(18, Math.min(maxCap, raw));
        setTileSize(computed);
      }
    };

    updateSize();

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      resizeObserver = new ResizeObserver(() => {
        updateSize();
      });
      resizeObserver.observe(containerRef.current);
    }

    window.addEventListener('resize', updateSize);
    window.addEventListener('orientationchange', updateSize);
    return () => {
      if (resizeObserver) resizeObserver.disconnect();
      window.removeEventListener('resize', updateSize);
      window.removeEventListener('orientationchange', updateSize);
    };
  }, [safeGridWidth, safeGridHeight]);

  const safeTile = Number.isFinite(tileSize) && tileSize > 0 ? tileSize : 28;
  const boardWidth = safeGridWidth * safeTile + (safeGridWidth - 1) * gap + padding * 2;
  const boardHeight = safeGridHeight * safeTile + (safeGridHeight - 1) * gap + padding * 2;

  // Watch for escaping tiles to trigger particle bursts
  useEffect(() => {
    if (tiles.length > 0 && tiles.every((t) => !t.isEscaping)) {
      prevEscapingRef.current.clear();
    }

    tiles.forEach((t) => {
      if (t.isEscaping && !prevEscapingRef.current.has(t.id)) {
        prevEscapingRef.current.add(t.id);
        const hx = padding + t.x * (safeTile + gap) + safeTile / 2;
        const hy = padding + t.y * (safeTile + gap) + safeTile / 2;
        
        const activeColorKey =
          arrowSkin && TILE_COLOR_CONFIGS[arrowSkin] ? arrowSkin : 'black';
        const colorCfg = TILE_COLOR_CONFIGS[activeColorKey] || TILE_COLOR_CONFIGS.black;

        setBursts((prev) => [
          ...prev,
          {
            id: `${t.id}-${Date.now()}`,
            x: hx,
            y: hy,
            color: colorCfg.arrowFill !== '#ffffff' ? colorCfg.arrowFill : colorCfg.tileBottomLip,
          },
        ]);
      }
    });
  }, [tiles, safeTile, padding, arrowSkin, gap]);

  const handleBurstComplete = (id: string) => {
    setBursts((prev) => prev.filter((b) => b.id !== id));
  };

  // Board theme visual styling
  const getThemeStyles = () => {
    switch (boardTheme) {
      case 'paper':
        return {
          bg: 'bg-amber-100/90 border-amber-200 shadow-amber-900/10',
          dot: 'rgba(217, 119, 6, 0.15)',
        };
      case 'midnight':
        return {
          bg: 'bg-slate-900/95 border-slate-800 shadow-black/50',
          dot: 'rgba(100, 116, 139, 0.15)',
        };
      case 'forest':
        return {
          bg: 'bg-emerald-950/90 border-emerald-800 shadow-emerald-950/40',
          dot: 'rgba(16, 185, 129, 0.15)',
        };
      case 'slate':
      default:
        return {
          bg: 'bg-white/95 dark:bg-slate-850 border-slate-200/90 dark:border-slate-800 shadow-xl dark:shadow-black/40',
          dot: 'rgba(148, 163, 184, 0.2)',
        };
    }
  };

  const themeStyle = getThemeStyles();

  return (
    <div
      ref={containerRef}
      className="flex-1 w-full flex items-center justify-center p-2 relative overflow-hidden select-none"
    >
      {/* Board surface container - holds many small compact tiles packed closely together */}
      <div
        id="puzzle-board-surface"
        className={`relative rounded-2xl border-2 backdrop-blur-md transition-all duration-300 ${themeStyle.bg}`}
        style={{
          width: boardWidth,
          height: boardHeight,
        }}
      >
        {/* Subtle grid dots for alignment */}
        <div 
          className="absolute inset-0 pointer-events-none rounded-2xl"
          style={{
            backgroundImage: `radial-gradient(${themeStyle.dot} 1px, transparent 1px)`,
            backgroundSize: `${safeTile + gap}px ${safeTile + gap}px`,
            backgroundPosition: `${padding}px ${padding}px`,
          }}
        />

        {/* Particle bursts on tile escape */}
        <EscapeParticles bursts={bursts} onBurstComplete={handleBurstComplete} />

        {/* Arrow Tiles Layer (supports both compact square tiles and long interlocking arrows) */}
        <div className="relative w-full h-full">
          {tiles.map((tile) => {
            const isMultiCell = tile.points && tile.points.length > 1;
            if (isMultiCell) {
              return (
                <LongArrowPiece
                  key={tile.id}
                  tile={tile}
                  tileSize={safeTile}
                  gap={gap}
                  padding={padding}
                  arrowSkin={arrowSkin}
                  isBlockedShaking={blockedTileId === tile.id}
                  onTap={onTileTap}
                  gridWidth={safeGridWidth}
                  gridHeight={safeGridHeight}
                />
              );
            }

            return (
              <ArrowTile
                key={tile.id}
                tile={tile}
                tileSize={safeTile}
                gap={gap}
                padding={padding}
                arrowSkin={arrowSkin}
                isBlockedShaking={blockedTileId === tile.id}
                onTap={onTileTap}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};
