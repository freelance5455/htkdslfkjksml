import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { quizQuestions } from '../data/quizData';
import { useLanguage } from '../context/LanguageContext';
import { useUserData } from '../context/UserDataContext';
import { useAuth } from '../context/AuthContext';
import {
  Sparkles,
  CheckCircle,
  XCircle,
  RotateCcw,
  Trophy,
  ArrowRight,
  ArrowLeft,
  LogIn
} from 'lucide-react';

export const QuizView: React.FC = () => {
  const { language, getText, isRtl } = useLanguage();
  const { recordQuizResult } = useUserData();
  const { user, signInWithGoogle } = useAuth();

  const [categoryFilter, setCategoryFilter] = useState<'all' | 'sarf' | 'nahw'>('all');
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const filteredQuestions = quizQuestions.filter((q) => {
    if (categoryFilter === 'all') return true;
    return q.category === categoryFilter;
  });

  const currentQ = filteredQuestions[currentIdx] || filteredQuestions[0];
  const selectedOptionId = selectedAnswers[currentQ?.id];

  const handleSelectOption = (optionId: string) => {
    if (selectedOptionId) return; // prevent changing after selecting
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQ.id]: optionId
    });
    setShowExplanation(true);
  };

  const handleNext = () => {
    setShowExplanation(false);
    if (currentIdx < filteredQuestions.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      finishQuiz();
    }
  };

  const calculateScore = () => {
    let score = 0;
    filteredQuestions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctOptionId) {
        score++;
      }
    });
    return score;
  };

  const finishQuiz = async () => {
    setQuizFinished(true);
    const score = calculateScore();
    const total = filteredQuestions.length;
    if (score >= Math.ceil(total * 0.7)) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
    const recCategory = categoryFilter === 'all' ? 'mixed' : categoryFilter;
    await recordQuizResult(score, total, recCategory);
  };

  const restartQuiz = () => {
    setCurrentIdx(0);
    setSelectedAnswers({});
    setShowExplanation(false);
    setQuizFinished(false);
  };

  if (!currentQ) {
    return <div>No questions available.</div>;
  }

  const score = calculateScore();
  const percentage = Math.round((score / filteredQuestions.length) * 100);

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-amber-950 text-white p-6 sm:p-8 rounded-3xl border border-amber-500/20 shadow-lg text-center relative overflow-hidden">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>
            {language === 'pashto'
              ? 'د علم الصرف او علم النحو ازموینه'
              : language === 'urdu'
              ? 'صرف و نحو کی انٹرایکٹو آزمائش'
              : 'Interactive Morphology & Syntax Quiz'}
          </span>
        </div>

        <h2 className="font-arabic text-3xl sm:text-4xl font-bold text-amber-200 mb-2">
          اخْتِبَارُ الْمَهَارَاتِ فِي الصَّرْفِ وَالنَّحْوِ
        </h2>

        <p className="text-stone-300 text-xs sm:text-sm max-w-xl mx-auto">
          {language === 'pashto'
            ? 'خپل معلومات و ازمویئ او په کلاوډ کې خپل ریکارډ ثبت کړئ.'
            : language === 'urdu'
            ? 'اپنے علم کو پرکھیں اور نتائج کو کلاؤڈ میں محفوظ کریں۔'
            : 'Evaluate your mastery with instant feedback, explanations, and cloud record persistence.'}
        </p>

        {/* Category Filter */}
        <div className="mt-4 flex justify-center gap-2">
          {(['all', 'sarf', 'nahw'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setCategoryFilter(cat);
                restartQuiz();
              }}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                categoryFilter === cat
                  ? 'bg-amber-500 text-stone-950 shadow-sm'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              {cat === 'all'
                ? language === 'pashto' ? 'ټول موضوعات' : language === 'urdu' ? 'تمام' : 'All Topics'
                : cat === 'sarf'
                ? 'علم الصرف'
                : 'علم النحو'}
            </button>
          ))}
        </div>
      </div>

      {quizFinished ? (
        /* Result Screen */
        <div className="bg-white rounded-3xl p-8 border border-stone-200 shadow-sm text-center space-y-6">
          <div className="w-20 h-20 mx-auto rounded-full bg-amber-100 flex items-center justify-center text-amber-600 shadow-inner">
            <Trophy className="w-10 h-10" />
          </div>

          <div>
            <h3 className="text-2xl font-bold text-stone-900 mb-1">
              {language === 'pashto'
                ? 'ازموینه پای ته ورسېده!'
                : language === 'urdu'
                ? 'آزمائش مکمل ہوئی!'
                : 'Quiz Completed!'}
            </h3>
            <p className="text-stone-500 text-sm">
              {language === 'pashto'
                ? `تاسو له ${filteredQuestions.length} پوښتنو څخه ${score} سم ځوابونه ورکړل.`
                : language === 'urdu'
                ? `آپ نے ${filteredQuestions.length} میں سے ${score} درست جوابات دیے۔`
                : `You scored ${score} out of ${filteredQuestions.length} questions.`}
            </p>
          </div>

          {/* Percentage badge */}
          <div className="inline-block px-6 py-3 rounded-2xl bg-emerald-50 border border-emerald-200">
            <span className="text-4xl font-extrabold text-emerald-800">{percentage}%</span>
            <span className="block text-xs font-semibold text-emerald-700 mt-1">
              {percentage >= 70
                ? language === 'pashto' ? 'ډېر غوره او ممتاز!' : language === 'urdu' ? 'بہت خوب، شاندار!' : 'Excellent Mastery!'
                : language === 'pashto' ? 'نورې مطالعې ته اړتیا لرئ.' : language === 'urdu' ? 'مزید مشق کی ضرورت ہے۔' : 'Keep Practicing!'}
            </span>
          </div>

          {!user && (
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 max-w-md mx-auto text-xs text-amber-900 flex items-center justify-between gap-3">
              <span>
                {language === 'pashto'
                  ? 'د خپلې نمرې او پرمختګ تلپاتې ساتلو لپاره ننوځئ.'
                  : language === 'urdu'
                  ? 'اپنے نتائج محفوظ رکھنے کے لیے سائن ان کریں۔'
                  : 'Sign in to permanently save your progress to Firebase.'}
              </span>
              <button
                onClick={signInWithGoogle}
                className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold flex items-center gap-1.5 flex-shrink-0"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Google</span>
              </button>
            </div>
          )}

          <div>
            <button
              onClick={restartQuiz}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold shadow-md transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>
                {language === 'pashto' ? 'بیا ځلي ازموینه ورکول' : language === 'urdu' ? 'دوبارہ کوشش کریں' : 'Retake Quiz'}
              </span>
            </button>
          </div>
        </div>
      ) : (
        /* Question Card */
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm space-y-6">
          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-stone-500 font-medium">
              <span>
                {language === 'pashto' ? 'پوښتنه' : language === 'urdu' ? 'سوال' : 'Question'} {currentIdx + 1} / {filteredQuestions.length}
              </span>
              <span>
                {Math.round(((currentIdx + 1) / filteredQuestions.length) * 100)}%
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
              <div
                className="h-full bg-emerald-600 transition-all duration-300"
                style={{ width: `${((currentIdx + 1) / filteredQuestions.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Text & Arabic Verse */}
          <div className="space-y-3">
            {currentQ.arabicPhrase && (
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-center">
                <span className="font-arabic text-2xl font-bold text-emerald-950">
                  {currentQ.arabicPhrase}
                </span>
              </div>
            )}

            <h3 className="text-base sm:text-lg font-bold text-stone-900 leading-snug">
              {getText(currentQ.question)}
            </h3>
          </div>

          {/* Options */}
          <div className="space-y-2.5">
            {currentQ.options.map((option) => {
              const isSelected = selectedOptionId === option.id;
              const isCorrect = option.id === currentQ.correctOptionId;

              let btnStyle = 'bg-stone-50 text-stone-800 border-stone-200 hover:bg-stone-100';
              if (selectedOptionId) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-50 text-emerald-900 border-emerald-500 ring-2 ring-emerald-500/20';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-50 text-rose-900 border-rose-500 ring-2 ring-rose-500/20';
                } else {
                  btnStyle = 'bg-stone-50 text-stone-400 border-stone-200 opacity-60';
                }
              }

              return (
                <button
                  key={option.id}
                  disabled={Boolean(selectedOptionId)}
                  onClick={() => handleSelectOption(option.id)}
                  className={`w-full p-4 rounded-xl border text-left rtl:text-right font-medium text-xs sm:text-sm flex items-center justify-between gap-3 transition-all cursor-pointer ${btnStyle}`}
                >
                  <span>{getText(option.text)}</span>
                  {selectedOptionId && (
                    <span>
                      {isCorrect ? (
                        <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                      ) : isSelected ? (
                        <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
                      ) : null}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {showExplanation && (
            <div className="bg-amber-50/80 p-4 rounded-xl border border-amber-200 text-xs sm:text-sm space-y-1">
              <span className="font-bold text-amber-900 block">
                {language === 'pashto' ? 'علمي وضاحت او صحیح ځواب:' : language === 'urdu' ? 'وضاحت اور صحیح جواب:' : 'Explanation & Correct Insight:'}
              </span>
              <p className="text-stone-800 leading-relaxed">
                {getText(currentQ.explanation)}
              </p>
            </div>
          )}

          {/* Next Button */}
          {selectedOptionId && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleNext}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold shadow-md transition-all"
              >
                <span>
                  {currentIdx === filteredQuestions.length - 1
                    ? language === 'pashto' ? 'پایلې وګورئ' : language === 'urdu' ? 'نتائج دیکھیں' : 'See Results'
                    : language === 'pashto' ? 'بله پوښتنه' : language === 'urdu' ? 'اگلا سوال' : 'Next Question'}
                </span>
                {isRtl ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
