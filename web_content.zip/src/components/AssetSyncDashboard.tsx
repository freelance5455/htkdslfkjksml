import React, { useState, useEffect } from 'react';
import { RefreshCw, Database, Activity, CheckCircle2, Cloud } from 'lucide-react';
import { motion } from 'motion/react';

export const AssetSyncDashboard: React.FC = () => {
  const [syncProgress, setSyncProgress] = useState(100);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSync, setLastSync] = useState(new Date().toLocaleTimeString());

  const handleForceRefresh = () => {
    if (isSyncing) return;
    setIsSyncing(true);
    setSyncProgress(0);

    const interval = setInterval(() => {
      setSyncProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsSyncing(false);
          setLastSync(new Date().toLocaleTimeString());
          return 100;
        }
        return prev + Math.floor(Math.random() * 20) + 10;
      });
    }, 400);
  };

  return (
    <div className="bg-slate-900 border-2 border-emerald-500/30 rounded-3xl p-6 shadow-xl space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-emerald-200 uppercase tracking-wider flex items-center space-x-2">
          <Database className="w-4 h-4 text-emerald-400" />
          <span>Asset Sync Dashboard</span>
        </h3>
        <button
          onClick={handleForceRefresh}
          disabled={isSyncing}
          className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-[10px] font-bold flex items-center space-x-1.5 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>FORCE REFRESH</span>
        </button>
      </div>

      <p className="text-xs text-slate-400">
        Monitors the real-time synchronization state between the JUHNKRIX internal ledger and external blockchain networks.
      </p>

      <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center space-x-1.5">
            <Cloud className="w-4 h-4 text-slate-500" />
            <span>Blockchain Cross-Sync</span>
          </span>
          <span className="font-mono text-emerald-400 font-bold">
            {syncProgress}%
          </span>
        </div>

        {/* Progress Bar */}
        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400"
            initial={{ width: '100%' }}
            animate={{ width: `${Math.min(100, syncProgress)}%` }}
            transition={{ type: 'tween', ease: 'easeOut', duration: 0.3 }}
          />
        </div>

        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
          <div className="flex items-center space-x-1">
            <Activity className="w-3 h-3 text-emerald-500/70" />
            <span>Active Nodes: 124</span>
          </div>
          <div className="flex items-center space-x-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Last Sync: {lastSync}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
