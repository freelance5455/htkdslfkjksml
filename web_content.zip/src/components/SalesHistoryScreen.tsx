import React, { useState, useEffect } from 'react';
import { SaleInvoice } from '../types/business';
import { StorageService } from '../db/storage';
import {
  ArrowLeft,
  Search,
  Calendar,
  Eye,
  Edit2,
  Trash2,
  Printer,
  Share2,
  Receipt,
  Filter,
} from 'lucide-react';

interface SalesHistoryScreenProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  onViewInvoice: (invoice: SaleInvoice) => void;
  onEditInvoice: (invoice: SaleInvoice) => void;
}

export const SalesHistoryScreen: React.FC<SalesHistoryScreenProps> = ({
  lang,
  onBack,
  onViewInvoice,
  onEditInvoice,
}) => {
  const [invoices, setInvoices] = useState<SaleInvoice[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month' | 'year' | 'custom'>('all');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [deleteCandidate, setDeleteCandidate] = useState<SaleInvoice | null>(null);

  const refreshInvoices = () => {
    setInvoices(StorageService.getInvoices());
  };

  useEffect(() => {
    refreshInvoices();
  }, []);

  const handleDeleteInvoice = () => {
    if (deleteCandidate) {
      StorageService.deleteSaleInvoice(deleteCandidate.id);
      setDeleteCandidate(null);
      refreshInvoices();
    }
  };

  // Filter invoices
  const filteredInvoices = invoices.filter((inv) => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.customerName.toLowerCase().includes(q) ||
      inv.customerPhone.includes(q) ||
      inv.items.some(
        (it) =>
          it.modelNumber.toLowerCase().includes(q) ||
          it.brand.toLowerCase().includes(q)
      );

    if (!matchSearch) return false;

    const invDate = new Date(inv.date);
    const now = new Date();

    if (dateFilter === 'today') {
      const todayStr = now.toISOString().split('T')[0];
      return inv.date === todayStr;
    } else if (dateFilter === 'week') {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(now.getDate() - 7);
      return invDate >= oneWeekAgo;
    } else if (dateFilter === 'month') {
      return (
        invDate.getMonth() === now.getMonth() &&
        invDate.getFullYear() === now.getFullYear()
      );
    } else if (dateFilter === 'year') {
      return invDate.getFullYear() === now.getFullYear();
    } else if (dateFilter === 'custom') {
      if (customStartDate && inv.date < customStartDate) return false;
      if (customEndDate && inv.date > customEndDate) return false;
      return true;
    }

    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <Receipt className="w-5 h-5 text-indigo-600" />
                <span>{lang === 'bn' ? 'বিক্রয় ও চালান হিস্টোরি' : 'Sales & Invoice History'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? `মোট ${invoices.length} টি চালান সংরক্ষিত রয়েছে`
                  : `Total ${invoices.length} invoices saved`}
              </p>
            </div>
          </div>
        </div>

        {/* Search & Date Filters */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 border-t border-slate-100 flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="চালান নম্বর, কাস্টমার, ফোন বা পার্টস দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            {[
              { id: 'all', label: 'সব' },
              { id: 'today', label: 'আজকে' },
              { id: 'week', label: 'এই সপ্তাহ' },
              { id: 'month', label: 'এই মাস' },
              { id: 'year', label: 'এই বছর' },
              { id: 'custom', label: 'কাস্টম তারিখ' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setDateFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-all ${
                  dateFilter === tab.id
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Date Range Picker */}
        {dateFilter === 'custom' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 border-t border-slate-100 flex items-center gap-3 text-xs bg-slate-50">
            <span className="font-semibold text-slate-600">তারিখ রেঞ্জ:</span>
            <input
              type="date"
              value={customStartDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="px-2 py-1 rounded-lg border border-slate-200 bg-white"
            />
            <span>থেকে</span>
            <input
              type="date"
              value={customEndDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="px-2 py-1 rounded-lg border border-slate-200 bg-white"
            />
          </div>
        )}
      </div>

      {/* Invoice Cards List */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {filteredInvoices.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto">
            <Receipt className="w-12 h-12 mx-auto text-slate-300 mb-3" />
            <h3 className="font-bold text-slate-800 text-sm">কোন বিক্রয় রেকর্ড পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-500 mt-1">
              ফিল্টার পরিবর্তন করুন অথবা নতুন বিক্রয় সম্পন্ন করুন।
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredInvoices.map((inv) => (
              <div
                key={inv.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs hover:shadow-md transition-shadow flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Left: Invoice Info */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-extrabold text-sm text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-lg border border-indigo-100">
                      {inv.invoiceNumber}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {inv.date} • {inv.time}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        inv.dueAmount > 0
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {inv.dueAmount > 0 ? `বাকি: ৳${inv.dueAmount}` : 'পরিশোধিত'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pt-1 text-xs">
                    <strong className="text-slate-900">{inv.customerName}</strong>
                    {inv.customerPhone && (
                      <span className="text-slate-500 font-mono">({inv.customerPhone})</span>
                    )}
                  </div>

                  {/* Items summary */}
                  <div className="text-xs text-slate-600 line-clamp-1">
                    পণ্য: {inv.items.map((i) => `${i.brand} ${i.modelNumber} (${i.quantity} pcs)`).join(', ')}
                  </div>
                </div>

                {/* Right: Amounts & Actions */}
                <div className="flex flex-wrap items-center justify-between md:justify-end gap-4 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-medium">সর্বমোট বিল</span>
                    <span className="font-extrabold text-base text-slate-900">
                      ৳{inv.finalPayableAmount.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      পেইড: ৳{inv.paidAmount} ({inv.paymentMethod})
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-1.5">
                    {/* View */}
                    <button
                      onClick={() => onViewInvoice(inv)}
                      className="p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors cursor-pointer"
                      title="ইনভয়েস দেখুন / প্রিন্ট"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {/* Edit */}
                    <button
                      onClick={() => onEditInvoice(inv)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                      title="সম্পাদনা করুন"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => setDeleteCandidate(inv)}
                      className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 transition-colors cursor-pointer"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal with Accounting Reverse explanation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 text-center border border-slate-100">
            <div className="w-14 h-14 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">
              আপনি কি এই বিক্রয়টি মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-slate-500 mt-2 mb-4">
              চালান: <strong className="text-slate-800">{deleteCandidate.invoiceNumber}</strong> • ক্রেতা:{' '}
              {deleteCandidate.customerName}
            </p>
            <div className="p-3 bg-red-50 rounded-xl text-left text-[11px] text-red-700 space-y-1 mb-5">
              <span className="font-bold block">মুছে ফেললে স্বয়ংক্রিয়ভাবে:</span>
              <span>• বিক্রি হওয়া {deleteCandidate.totalQuantity} পিস পণ্য পুনরায় স্টকে যোগ হবে।</span>
              <span>• মোট বিক্রয় ও লাভের হিসাব সমন্বয় করা হবে।</span>
              <span>• কাস্টমারের বাকি বিল সমন্বয় করা হবে।</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
              >
                Cancel / বাতিল
              </button>
              <button
                onClick={handleDeleteInvoice}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-500/20 cursor-pointer"
              >
                Delete / মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
