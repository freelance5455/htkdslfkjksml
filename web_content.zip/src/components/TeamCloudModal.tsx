import React, { useState } from 'react';
import {
  Cloud,
  Users,
  CheckCircle2,
  LogOut,
  UploadCloud,
  Copy,
  Check,
  X,
  Activity,
  ShoppingCart,
  ShoppingBag,
  Receipt,
  CreditCard,
  Edit3,
  Trash2,
  UserCheck,
  Sparkles,
  Share2,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import type { ActivityLogItem } from '../types/pharmacy.ts';
import type { User } from '../services/firebase.ts';
import { formatIQD } from '../utils/calculations.ts';

interface TeamCloudModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  actorName: string;
  onUpdateActorName: (name: string) => void;
  onSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onSyncLocalToCloud: () => Promise<void>;
  activityLogs: ActivityLogItem[];
  isCloudSyncing: boolean;
  cloudError: string | null;
}

export const TeamCloudModal: React.FC<TeamCloudModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  actorName,
  onUpdateActorName,
  onSignIn,
  onSignOut,
  onSyncLocalToCloud,
  activityLogs,
  isCloudSyncing,
  cloudError,
}) => {
  const [nameInput, setNameInput] = useState(actorName);
  const [nameSaved, setNameSaved] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [filterMember, setFilterMember] = useState<string>('ALL');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  if (!isOpen) return null;

  const uniqueMembers = Array.from(
    new Set(activityLogs.map((l) => l.actorName).filter(Boolean))
  );

  const filteredLogs = activityLogs.filter(
    (log) => filterMember === 'ALL' || log.actorName === filterMember
  );

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onUpdateActorName(nameInput.trim());
    setNameSaved(true);
    setTimeout(() => setNameSaved(false), 2000);
  };

  const handleCopyShareLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleUploadLocal = async () => {
    setIsUploading(true);
    setUploadSuccess(false);
    try {
      await onSyncLocalToCloud();
      setUploadSuccess(true);
      setTimeout(() => setUploadSuccess(false), 3000);
    } finally {
      setIsUploading(false);
    }
  };

  const formatRelativeTime = (ms: number) => {
    const diffSec = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (diffSec < 60) return 'الآن';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `منذ ${diffHr} ساعة`;
    const diffDays = Math.floor(diffHr / 24);
    return `منذ ${diffDays} يوم`;
  };

  const getActionBadge = (type: ActivityLogItem['actionType']) => {
    switch (type) {
      case 'add_purchase':
        return {
          label: 'قائمة شراء',
          icon: ShoppingCart,
          cls: 'bg-teal-100 text-teal-800 border-teal-200',
        };
      case 'add_sale':
        return {
          label: 'قائمة بيع',
          icon: ShoppingBag,
          cls: 'bg-emerald-100 text-emerald-800 border-emerald-200',
        };
      case 'add_expense':
        return {
          label: 'مصروف',
          icon: Receipt,
          cls: 'bg-amber-100 text-amber-800 border-amber-200',
        };
      case 'add_payment':
        return {
          label: 'تسديد دين',
          icon: CreditCard,
          cls: 'bg-indigo-100 text-indigo-800 border-indigo-200',
        };
      case 'edit_medicine':
        return {
          label: 'تحديث دواء',
          icon: Edit3,
          cls: 'bg-sky-100 text-sky-800 border-sky-200',
        };
      case 'delete_record':
        return {
          label: 'حذف سجل',
          icon: Trash2,
          cls: 'bg-rose-100 text-rose-800 border-rose-200',
        };
      default:
        return {
          label: 'مزامنة سحابية',
          icon: Cloud,
          cls: 'bg-purple-100 text-purple-800 border-purple-200',
        };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full sm:max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-teal-900 via-teal-800 to-emerald-900 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-white/15 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Users className="h-6 w-6 text-amber-300" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black flex items-center gap-2">
                السحابة وسجل نشاط الفريق
                {currentUser && (
                  <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 px-2 py-0.5 rounded-full font-bold">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    متصل مباشر
                  </span>
                )}
              </h2>
              <p className="text-xs text-teal-100/80">
                مزامنة فورية للمخزون والقوائم بين جميع الموظفين والأجهزة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl bg-white/10 hover:bg-white/20 p-2 text-white transition"
            aria-label="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Cloud Auth & Team Setup Card */}
          <div className="rounded-2xl bg-slate-50 border border-slate-200/90 p-4 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div
                  className={`p-2.5 rounded-xl ${
                    currentUser
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-amber-100 text-amber-700'
                  }`}
                >
                  <Cloud className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {currentUser
                      ? `متصل بالسحابة (${currentUser.email})`
                      : 'ربط التطبيق بالسحابة المشتركة (Google Cloud)'}
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {currentUser
                      ? 'أي قائمة شراء أو بيع أو مصروف تضيفها الآن تظهر فوراً عند جميع زملائك بالعمل مع اسمك.'
                      : 'سجّل الدخول بحساب Google لتفعيل المزامنة السحابية الفورية مع فريق العمل على نفس المخزون.'}
                  </p>
                </div>
              </div>

              {currentUser ? (
                <button
                  onClick={onSignOut}
                  className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition shrink-0"
                >
                  <LogOut className="h-4 w-4" />
                  تسجيل خروج
                </button>
              ) : (
                <button
                  onClick={onSignIn}
                  disabled={isCloudSyncing}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-black shadow-sm transition active:scale-95 shrink-0"
                >
                  <Cloud className="h-4 w-4" />
                  {isCloudSyncing ? 'جاري الاتصال...' : 'تسجيل دخول Google للسحابة'}
                </button>
              )}
            </div>

            {cloudError && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-800 font-bold">
                تنبيه السحابة: {cloudError}
              </div>
            )}

            {/* Employee Display Name Setting */}
            <form
              onSubmit={handleSaveName}
              className="pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row items-stretch sm:items-end gap-2.5"
            >
              <div className="flex-1">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسمك الذي يظهر عند إضافة القوائم (من أضاف القائمة):
                </label>
                <div className="relative">
                  <UserCheck className="h-4 w-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="مثال: د. علي / أحمد المبيعات / سجاد المخزن"
                    className="w-full rounded-xl border border-slate-300 bg-white pr-9 pl-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-none"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                {nameSaved ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    تم حفظ الاسم
                  </>
                ) : (
                  'حفظ اسم الموظف'
                )}
              </button>
            </form>

            {/* Share App Link & Upload Local Data */}
            <div className="pt-3 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleCopyShareLink}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold transition"
              >
                {copiedLink ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-600" />
                    تم نسخ رابط التطبيق لمشاركته مع الفريق!
                  </>
                ) : (
                  <>
                    <Share2 className="h-4 w-4 text-teal-700" />
                    نسخ رابط التطبيق لإرساله للموظفين
                  </>
                )}
              </button>

              {currentUser && (
                <button
                  type="button"
                  onClick={handleUploadLocal}
                  disabled={isUploading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-bold transition"
                >
                  <UploadCloud className="h-4 w-4" />
                  {isUploading
                    ? 'جاري رفع البيانات...'
                    : uploadSuccess
                    ? 'تم رفع البيانات للسحابة بنجاح!'
                    : 'رفع البيانات الحالية للسحابة المشتركة'}
                </button>
              )}
            </div>
          </div>

          {/* Live Activity Feed Section */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-teal-700" />
                <h3 className="text-sm sm:text-base font-black text-slate-900">
                  سجل إضافات الفريق (من أضاف القوائم مؤخراً)
                </h3>
              </div>

              {/* Filter by Member */}
              {uniqueMembers.length > 0 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    onClick={() => setFilterMember('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition shrink-0 ${
                      filterMember === 'ALL'
                        ? 'bg-teal-700 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    الكل ({activityLogs.length})
                  </button>
                  {uniqueMembers.map((member) => (
                    <button
                      key={member}
                      onClick={() => setFilterMember(member)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition shrink-0 ${
                        filterMember === member
                          ? 'bg-teal-700 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {member}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {filteredLogs.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                <Clock className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-bold text-slate-700">لا توجد حركات مسجلة بعد</p>
                <p className="text-xs text-slate-500 mt-1">
                  عند إضافة أي قائمة شراء أو بيع أو مصروف سيظهر هنا اسم الشخص والتوقيت.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredLogs.slice(0, 40).map((log) => {
                  const badge = getActionBadge(log.actionType);
                  const BadgeIcon = badge.icon;
                  return (
                    <div
                      key={log.id}
                      className="rounded-2xl bg-white border border-slate-200/90 p-3.5 shadow-2xs hover:border-teal-300 transition flex items-start justify-between gap-3"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <div className={`p-2.5 rounded-xl border shrink-0 ${badge.cls}`}>
                          <BadgeIcon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-900 text-white text-[11px] font-black">
                              <UserCheck className="h-3 w-3 text-amber-300" />
                              {log.actorName}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${badge.cls}`}
                            >
                              {badge.label}
                            </span>
                            <span className="text-[11px] text-slate-400 font-medium">
                              • {formatRelativeTime(log.createdAtMs)}
                            </span>
                          </div>
                          <p className="text-xs sm:text-sm font-black text-slate-900 mt-1 truncate">
                            {log.title}
                          </p>
                          {log.details && (
                            <p className="text-xs text-slate-600 mt-0.5">{log.details}</p>
                          )}
                        </div>
                      </div>

                      {log.amount > 0 && (
                        <div className="text-left shrink-0">
                          <span className="text-xs font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded-xl border border-slate-200 block">
                            {formatIQD(log.amount)}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
