import React, { useState } from 'react';
import {
  Cloud,
  Users,
  CheckCircle2,
  LogOut,
  UploadCloud,
  Check,
  X,
  Activity,
  ShoppingCart,
  ShoppingBag,
  Receipt,
  CreditCard,
  Edit3,
  Trash2,
  UserCheck,
  Share2,
  Clock,
  ShieldAlert,
  RefreshCw,
  Database,
  AlertTriangle,
} from 'lucide-react';
import type { ActivityLogItem, AppDatabase } from '../types/pharmacy.ts';
import type { User, CloudCollectionName } from '../services/firebase.ts';
import { formatIQD } from '../utils/calculations.ts';

interface TeamCloudModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  isCloudConnected: boolean;
  actorName: string;
  onUpdateActorName: (name: string) => void;
  onSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onSyncLocalToCloud: () => Promise<void>;
  onWipeAllCloudData: () => Promise<void>;
  onWipeCloudCollection: (col: CloudCollectionName) => Promise<void>;
  onResetSampleToCloud: () => Promise<void>;
  db: AppDatabase;
  activityLogs: ActivityLogItem[];
  isCloudSyncing: boolean;
  cloudError: string | null;
}

export const TeamCloudModal: React.FC<TeamCloudModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  isCloudConnected,
  actorName,
  onUpdateActorName,
  onSignOut,
  onSyncLocalToCloud,
  onWipeAllCloudData,
  onWipeCloudCollection,
  onResetSampleToCloud,
  db,
  activityLogs,
  cloudError,
}) => {
  const [activeTab, setActiveTab] = useState<'control' | 'logs'>('control');
  const [nameInput, setNameInput] = useState(actorName);
  const [nameSaved, setNameSaved] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [filterMember, setFilterMember] = useState<string>('ALL');

  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'danger';
    text: string;
  } | null>(null);

  // Inline confirmation states (avoiding window.confirm for iOS WebClip & iframe compatibility)
  const [confirmWipeAll, setConfirmWipeAll] = useState(false);
  const [confirmWipeCol, setConfirmWipeCol] = useState<CloudCollectionName | null>(null);

  if (!isOpen) return null;

  const uniqueMembers = Array.from(
    new Set(activityLogs.map((l) => l.actorName).filter(Boolean))
  );

  const filteredLogs = activityLogs.filter(
    (log) => filterMember === 'ALL' || log.actorName === filterMember
  );

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onUpdateActorName(nameInput.trim());
    setNameSaved(true);
    setTimeout(() => setNameSaved(false), 2000);
  };

  const handleCopyShareLink = async () => {
    try {
      await navigator.clipboard.writeText('https://meshmesh-sync.surge.sh');
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleUploadLocal = async () => {
    setBusyAction('upload');
    setStatusMessage(null);
    try {
      await onSyncLocalToCloud();
      setStatusMessage({
        type: 'success',
        text: 'تم رفع ومزامنة بيانات هذا الجهاز مع السحابة بنجاح!',
      });
    } finally {
      setBusyAction(null);
    }
  };

  const handleExecuteWipeAll = async () => {
    setBusyAction('wipe_all');
    setStatusMessage(null);
    try {
      await onWipeAllCloudData();
      setConfirmWipeAll(false);
      setStatusMessage({
        type: 'danger',
        text: 'تم مسح وتصفير كافة البيانات السحابية من جميع الأجهزة بنجاح!',
      });
    } finally {
      setBusyAction(null);
    }
  };

  const handleExecuteWipeCollection = async (col: CloudCollectionName) => {
    setBusyAction(`wipe_${col}`);
    setStatusMessage(null);
    try {
      await onWipeCloudCollection(col);
      setConfirmWipeCol(null);
      setStatusMessage({
        type: 'danger',
        text: 'تم مسح القسم المحدد من السحابة وتصفيره على جميع الأجهزة!',
      });
    } finally {
      setBusyAction(null);
    }
  };

  const handleExecuteRestoreSample = async () => {
    setBusyAction('sample');
    setStatusMessage(null);
    try {
      await onResetSampleToCloud();
      setStatusMessage({
        type: 'success',
        text: 'تم تحميل البيانات التجريبية ومزامنتها على جميع الأجهزة!',
      });
    } finally {
      setBusyAction(null);
    }
  };

  const formatRelativeTime = (ms: number) => {
    const diffSec = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (diffSec < 60) return 'الآن';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `منذ ${diffHr} ساعة`;
    const diffDays = Math.floor(diffHr / 24);
    return `منذ ${diffDays} يوم`;
  };

  const getActionBadge = (type: ActivityLogItem['actionType']) => {
    switch (type) {
      case 'add_purchase':
        return {
          label: 'قائمة شراء',
          icon: ShoppingCart,
          cls: 'bg-teal-100 text-teal-800 border-teal-200',
        };
      case 'add_sale':
        return {
          label: 'قائمة بيع',
          icon: ShoppingBag,
          cls: 'bg-emerald-100 text-emerald-800 border-emerald-200',
        };
      case 'add_expense':
        return {
          label: 'مصروف',
          icon: Receipt,
          cls: 'bg-amber-100 text-amber-800 border-amber-200',
        };
      case 'add_payment':
        return {
          label: 'تسديد دين',
          icon: CreditCard,
          cls: 'bg-indigo-100 text-indigo-800 border-indigo-200',
        };
      case 'edit_medicine':
        return {
          label: 'تحديث دواء',
          icon: Edit3,
          cls: 'bg-sky-100 text-sky-800 border-sky-200',
        };
      case 'delete_record':
        return {
          label: 'حذف سجل',
          icon: Trash2,
          cls: 'bg-rose-100 text-rose-800 border-rose-200',
        };
      default:
        return {
          label: 'مزامنة سحابية',
          icon: Cloud,
          cls: 'bg-purple-100 text-purple-800 border-purple-200',
        };
    }
  };

  const collectionStats: Array<{
    key: CloudCollectionName;
    label: string;
    count: number;
  }> = [
    { key: 'sales', label: 'فواتير المبيعات', count: db.sales.length },
    { key: 'purchases', label: 'فواتير المشتريات', count: db.purchases.length },
    { key: 'medicines', label: 'الأدوية والباركود', count: db.medicines.length },
    { key: 'expenses', label: 'سجل المصاريف', count: db.expenses.length },
    { key: 'payments', label: 'تسديدات الديون', count: db.payments.length },
    { key: 'activityLogs', label: 'سجل نشاط الفريق', count: activityLogs.length },
  ];

  const totalCloudRecords = collectionStats.reduce((sum, item) => sum + item.count, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/65 backdrop-blur-xs p-0 sm:p-4 animate-fadeIn">
      <div className="bg-white w-full sm:max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-teal-950 via-teal-900 to-emerald-950 text-white px-4 sm:px-5 py-3.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-10 w-10 rounded-xl bg-white/15 flex items-center justify-center border border-white/20 shrink-0">
              <Cloud className="h-5 w-5 text-amber-300" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-black flex items-center gap-2 truncate">
                <span>التحكم الكامل بالسحابة والفريق</span>
                <span
                  className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md font-bold ${
                    isCloudConnected
                      ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30'
                      : 'bg-amber-500/20 text-amber-200 border border-amber-400/30'
                  }`}
                >
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      isCloudConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                    }`}
                  />
                  {isCloudConnected ? 'متصل مباشر' : 'محلي'}
                </span>
              </h2>
              <p className="text-[11px] text-teal-100/80 truncate">
                إدارة البيانات السحابية المشتركة ومسحها أو مزامنتها عبر جميع الأجهزة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl bg-white/10 hover:bg-white/20 p-2 text-white transition shrink-0"
            aria-label="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="bg-slate-100 p-1.5 border-b border-slate-200 grid grid-cols-2 gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('control')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-black transition ${
              activeTab === 'control'
                ? 'bg-teal-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            <span>التحكم ببيانات السحابة ({totalCloudRecords})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-black transition ${
              activeTab === 'logs'
                ? 'bg-teal-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>سجل نشاط الفريق ({activityLogs.length})</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {statusMessage && (
            <div
              className={`rounded-xl p-3 text-xs font-black flex items-center justify-between gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  : 'bg-rose-50 text-rose-900 border border-rose-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>{statusMessage.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setStatusMessage(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>
          )}

          {cloudError && (
            <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-800 font-bold">
              تنبيه السحابة: {cloudError}
            </div>
          )}

          {activeTab === 'control' ? (
            <>
              {/* 1. Employee Identity & Share Link */}
              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 space-y-3">
                <form
                  onSubmit={handleSaveName}
                  className="flex flex-col sm:flex-row items-stretch sm:items-end gap-2"
                >
                  <div className="flex-1">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      اسمك على هذا الجهاز (يظهر عند إضافة الفواتير):
                    </label>
                    <div className="relative">
                      <UserCheck className="h-4 w-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        placeholder="مثال: د. علي / أحمد المبيعات"
                        className="w-full rounded-xl border border-slate-300 bg-white pr-9 pl-3 py-2 text-xs font-bold text-slate-900 focus:border-teal-600 focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shrink-0"
                  >
                    {nameSaved ? (
                      <>
                        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                        <span>تم الحفظ</span>
                      </>
                    ) : (
                      'حفظ الاسم'
                    )}
                  </button>
                </form>

                <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={handleCopyShareLink}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold transition"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="h-4 w-4 text-emerald-600" />
                        <span>تم نسخ رابط التطبيق!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="h-4 w-4 text-teal-700" />
                        <span>نسخ رابط التطبيق للموظفين</span>
                      </>
                    )}
                  </button>

                  {currentUser && (
                    <button
                      onClick={onSignOut}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      <span>تسجيل خروج</span>
                    </button>
                  )}
                </div>
              </div>

              {/* 2. Cloud Collections Breakdown & Selective Wipe */}
              <div className="rounded-2xl bg-white border border-slate-200 p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-1.5">
                    <Database className="h-4 w-4 text-teal-700" />
                    <span>إحصائيات السحابة والمسح الانتقائي حسب القسم</span>
                  </h3>
                  <span className="text-[11px] font-bold text-slate-500">
                    إجمالي السجلات: {totalCloudRecords}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {collectionStats.map((col) => (
                    <div
                      key={col.key}
                      className="rounded-xl border border-slate-200 bg-slate-50/70 p-2.5 flex flex-col justify-between gap-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-slate-600">{col.label}</span>
                        <span className="font-mono text-sm font-black text-slate-900">
                          {col.count}
                        </span>
                      </div>

                      {confirmWipeCol === col.key ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            disabled={busyAction !== null}
                            onClick={() => handleExecuteWipeCollection(col.key)}
                            className="flex-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white py-1 text-[10px] font-black transition"
                          >
                            {busyAction === `wipe_${col.key}` ? 'جاري المسح...' : 'تأكيد المسح'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmWipeCol(null)}
                            className="rounded-lg bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-700"
                          >
                            إلغاء
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={col.count === 0 || busyAction !== null}
                          onClick={() => setConfirmWipeCol(col.key)}
                          className="w-full flex items-center justify-center gap-1 rounded-lg border border-rose-200 bg-white hover:bg-rose-50 text-rose-700 py-1 text-[10px] font-bold disabled:opacity-40 transition"
                        >
                          <Trash2 className="h-3 w-3" />
                          <span>مسح القسم من السحابة</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. Full Cloud Actions: Sync / Restore Sample / Wipe Everything */}
              <div className="rounded-2xl border-2 border-rose-200 bg-rose-50/40 p-3.5 space-y-3">
                <div className="flex items-start gap-2.5">
                  <ShieldAlert className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-xs sm:text-sm font-black text-rose-950">
                      التحكم الشامل بقاعدة البيانات السحابية (لكل الأجهزة)
                    </h3>
                    <p className="text-[11px] text-rose-800/90 mt-0.5 leading-relaxed">
                      يمكنك من هنا مسح وتصفير كافة البيانات السحابية ليتم مسحها فوراً من جميع الهواتف والحاسبات المربوطة، أو رفع بيانات هذا الجهاز لتعميمها على الجميع.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={handleUploadLocal}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white px-3.5 py-2 text-xs font-black transition disabled:opacity-50"
                  >
                    <UploadCloud className="h-4 w-4" />
                    <span>
                      {busyAction === 'upload'
                        ? 'جاري الرفع للسحابة...'
                        : 'رفع بيانات هذا الجهاز للسحابة'}
                    </span>
                  </button>

                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={handleExecuteRestoreSample}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-white hover:bg-slate-100 text-teal-900 border border-teal-300 px-3.5 py-2 text-xs font-bold transition disabled:opacity-50"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    <span>
                      {busyAction === 'sample'
                        ? 'جاري التحميل...'
                        : 'تحميل عينة تجريبية للسحابة'}
                    </span>
                  </button>

                  {!confirmWipeAll ? (
                    <button
                      type="button"
                      disabled={busyAction !== null}
                      onClick={() => setConfirmWipeAll(true)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 text-xs font-black shadow-xs transition active:scale-95 disabled:opacity-50"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>مسح كل البيانات السحابية من جميع الأجهزة</span>
                    </button>
                  ) : (
                    <div className="w-full rounded-xl bg-rose-100 border border-rose-300 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs font-black text-rose-950">
                        <AlertTriangle className="h-4 w-4 text-rose-700 shrink-0" />
                        <span>
                          هل أنت متأكد؟ سيتم مسح جميع الفواتير والمواد من السحابة ومن كل الأجهزة فوراً!
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          disabled={busyAction !== null}
                          onClick={handleExecuteWipeAll}
                          className="rounded-xl bg-rose-700 hover:bg-rose-800 text-white px-4 py-1.5 text-xs font-black transition"
                        >
                          {busyAction === 'wipe_all'
                            ? 'جاري مسح السحابة...'
                            : 'نعم، امسح كل بيانات السحابة'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmWipeAll(false)}
                          className="rounded-xl bg-white px-3 py-1.5 text-xs font-bold text-slate-700 border border-slate-300"
                        >
                          تراجع
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            /* Live Activity Feed Section */
            <div className="space-y-3">
              {uniqueMembers.length > 0 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    onClick={() => setFilterMember('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition shrink-0 ${
                      filterMember === 'ALL'
                        ? 'bg-teal-700 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    الكل ({activityLogs.length})
                  </button>
                  {uniqueMembers.map((member) => (
                    <button
                      key={member}
                      onClick={() => setFilterMember(member)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition shrink-0 ${
                        filterMember === member
                          ? 'bg-teal-700 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {member}
                    </button>
                  ))}
                </div>
              )}

              {filteredLogs.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                  <Clock className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-sm font-bold text-slate-700">لا توجد حركات مسجلة في السحابة</p>
                  <p className="text-xs text-slate-500 mt-1">
                    عند إضافة أي قائمة شراء أو بيع أو مصروف سيظهر هنا اسم الشخص والتوقيت فوراً.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredLogs.slice(0, 40).map((log) => {
                    const badge = getActionBadge(log.actionType);
                    const BadgeIcon = badge.icon;
                    return (
                      <div
                        key={log.id}
                        className="rounded-2xl bg-white border border-slate-200/90 p-3 flex items-start justify-between gap-2.5"
                      >
                        <div className="flex items-start gap-2.5 min-w-0">
                          <div className={`p-2 rounded-xl border shrink-0 ${badge.cls}`}>
                            <BadgeIcon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="text-xs font-black text-slate-900">
                                {log.actorName}
                              </span>
                              <span className="text-[11px] text-slate-400">·</span>
                              <span className="text-[11px] font-bold text-teal-800">
                                {badge.label}
                              </span>
                              <span className="text-[11px] text-slate-400">·</span>
                              <span className="text-[11px] text-slate-400">
                                {formatRelativeTime(log.createdAtMs)}
                              </span>
                            </div>
                            <p className="text-xs font-bold text-slate-900 mt-0.5 truncate">
                              {log.title}
                            </p>
                            {log.details && (
                              <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                                {log.details}
                              </p>
                            )}
                          </div>
                        </div>

                        {log.amount > 0 && (
                          <div className="text-left shrink-0 font-mono text-xs font-black text-slate-900">
                            {formatIQD(log.amount)}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
