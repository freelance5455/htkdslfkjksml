import React from 'react';
import { X, ShoppingBag, Minus, Plus, Trash2, ArrowRight, ArrowLeft } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useStoreData } from '../context/StoreDataContext';
import { formatCurrency } from '../lib/formatters';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
}

export function CartDrawer({ onProceedToCheckout }: CartDrawerProps) {
  const {
    items,
    isCartOpen,
    totalItems,
    subtotal,
    totalSavings,
    closeCart,
    removeFromCart,
    updateQuantity,
  } = useCart();
  const { settings } = useStoreData();

  if (!isCartOpen) return null;

  const freeThreshold = settings.freeShippingThreshold ?? 999;
  const standardFee = settings.standardShippingFee ?? 60;
  const shippingFee = items.length === 0 ? 0 : subtotal >= freeThreshold ? 0 : standardFee;
  const totalAmount = subtotal + shippingFee;
  const amountToFreeShipping = Math.max(0, freeThreshold - subtotal);

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="Shopping Bag">
      <div
        className="fixed inset-0 bg-black/45 backdrop-blur-[1px]"
        onClick={closeCart}
      />

      <aside className="relative z-10 w-full max-w-md bg-white h-full flex flex-col shadow-2xl border-l border-neutral-200">
        {/* Header */}
        <div className="px-6 py-5 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={closeCart}
              aria-label="Back to shopping"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
            <ShoppingBag className="w-4 h-4 text-[#0A0A0A]" />
            <h2 className="text-sm font-semibold tracking-wide uppercase">
              Bag ({totalItems})
            </h2>
          </div>
          <button
            type="button"
            onClick={closeCart}
            aria-label="Close shopping bag"
            className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Free Shipping Meter */}
        {items.length > 0 && (
          <div className="px-6 py-3 bg-neutral-50 border-b border-neutral-200 text-xs text-neutral-700">
            {amountToFreeShipping > 0 ? (
              <span>
                Add <strong className="tabular-nums text-[#0A0A0A]">{formatCurrency(amountToFreeShipping)}</strong> more for complimentary express delivery.
              </span>
            ) : (
              <span className="font-medium text-[#0A0A0A]">
                Your order qualifies for complimentary express delivery.
              </span>
            )}
          </div>
        )}

        {/* Items List */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-16">
              <div className="w-14 h-14 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
                <ShoppingBag className="w-6 h-6 text-neutral-400" />
              </div>
              <p className="font-display text-2xl font-semibold mb-1">Your bag is empty</p>
              <p className="text-xs text-neutral-500 max-w-xs mb-6">
                Explore curated essentials across outerwear, tailoring, denim, and heritage silhouettes.
              </p>
              <button
                type="button"
                onClick={closeCart}
                className="px-6 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={`${item.productId}-${item.selectedSize}-${item.selectedColor}`}
                className="flex gap-4 pb-5 border-b border-neutral-100 last:border-b-0"
              >
                <div className="w-20 h-26 bg-neutral-100 shrink-0 overflow-hidden">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#0A0A0A] leading-snug line-clamp-2">
                        {item.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() =>
                          removeFromCart(item.productId, item.selectedSize, item.selectedColor)
                        }
                        aria-label={`Remove ${item.name}`}
                        className="p-1 text-neutral-400 hover:text-red-600 transition-colors cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Size {item.selectedSize} <span aria-hidden="true">·</span> {item.selectedColor}
                    </p>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div className="inline-flex items-center border border-neutral-200 rounded-full">
                      <button
                        type="button"
                        onClick={() =>
                          updateQuantity(
                            item.productId,
                            item.selectedSize,
                            item.selectedColor,
                            item.quantity - 1
                          )
                        }
                        aria-label="Decrease quantity"
                        className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:text-[#0A0A0A] cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        disabled={item.quantity >= item.maxStock}
                        onClick={() =>
                          updateQuantity(
                            item.productId,
                            item.selectedSize,
                            item.selectedColor,
                            item.quantity + 1
                          )
                        }
                        aria-label="Increase quantity"
                        className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:text-[#0A0A0A] disabled:opacity-35 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="text-right tabular-nums">
                      <div className="text-sm font-semibold text-[#0A0A0A]">
                        {formatCurrency(item.effectivePrice * item.quantity)}
                      </div>
                      {item.price > item.effectivePrice && (
                        <div className="text-[11px] text-neutral-400 line-through">
                          {formatCurrency(item.price * item.quantity)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Summary Footer */}
        {items.length > 0 && (
          <div className="p-6 border-t border-neutral-200 bg-neutral-50/70 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal</span>
                <span className="tabular-nums font-medium text-[#0A0A0A]">
                  {formatCurrency(subtotal)}
                </span>
              </div>
              {totalSavings > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Collection Savings</span>
                  <span className="tabular-nums font-medium">
                    -{formatCurrency(totalSavings)}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-neutral-600">
                <span>Delivery</span>
                <span className="tabular-nums font-medium text-[#0A0A0A]">
                  {shippingFee === 0 ? 'Complimentary' : formatCurrency(shippingFee)}
                </span>
              </div>
              <div className="pt-2 border-t border-neutral-200 flex justify-between text-sm font-semibold text-[#0A0A0A]">
                <span>Total</span>
                <span className="tabular-nums">{formatCurrency(totalAmount)}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                closeCart();
                onProceedToCheckout();
              }}
              className="w-full py-3.5 px-6 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold tracking-wide hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Order Now · Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={closeCart}
              className="w-full py-2.5 px-6 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:bg-white transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Shopping</span>
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
