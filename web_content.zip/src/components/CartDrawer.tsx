import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, Tag, ShieldCheck } from 'lucide-react';
import { CartItem, CurrencyCode } from '../types';
import { formatPrice } from '../utils/currency';

interface CartDrawerProps {
  isOpen: boolean;
  cart: CartItem[];
  activeCurrency: CurrencyCode;
  onClose: () => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onOpenCheckout: (discountPercent: number) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  cart,
  activeCurrency,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onOpenCheckout
}) => {
  if (!isOpen) return null;

  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');

  const subtotalUsd = cart.reduce((sum, item) => sum + item.product.priceUsd * item.quantity, 0);
  const discountUsd = (subtotalUsd * discountPercent) / 100;
  const freeShippingThresholdUsd = 75;
  const progressToFreeShipping = Math.min(100, (subtotalUsd / freeShippingThresholdUsd) * 100);
  const remainingForFreeShipping = Math.max(0, freeShippingThresholdUsd - subtotalUsd);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    setPromoSuccess('');

    const cleanCode = promoCode.trim().toUpperCase();
    if (cleanCode === 'BAIT10') {
      setDiscountPercent(10);
      setPromoSuccess('10% VIP Discount Applied!');
    } else if (cleanCode === 'SANCTUARY') {
      setDiscountPercent(15);
      setPromoSuccess('15% Sanctuary Home Discount Applied!');
    } else {
      setPromoError('Invalid code. Try "BAIT10" or "SANCTUARY"');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-stone-900/50 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-stone-200">
          {/* Header */}
          <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-[#FAF8F5]">
            <div>
              <h2 className="font-serif text-xl font-semibold text-stone-900">
                Your Sanctuary Bag
              </h2>
              <p className="text-xs text-stone-500">
                {cart.length} {cart.length === 1 ? 'item' : 'items'} ready for delivery
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-stone-500 hover:text-stone-900 rounded-full hover:bg-stone-200/60 transition-colors cursor-pointer"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Meter */}
          <div className="px-5 py-3 bg-stone-100/70 border-b border-stone-200 text-xs">
            {remainingForFreeShipping > 0 ? (
              <p className="text-stone-700">
                Add <span className="font-semibold text-stone-900">{formatPrice(remainingForFreeShipping, activeCurrency)}</span> more for Free Standard Delivery.
              </p>
            ) : (
              <p className="text-emerald-800 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>You unlocked Free Standard Delivery!</span>
              </p>
            )}
            <div className="w-full bg-stone-200 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-stone-800 h-full transition-all duration-300"
                style={{ width: `${progressToFreeShipping}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 divide-y divide-stone-100">
            {cart.length === 0 ? (
              <div className="py-20 text-center flex flex-col items-center">
                <p className="font-serif text-xl text-stone-800 mb-2">Your bag is empty</p>
                <p className="text-xs text-stone-500 max-w-xs mb-6">
                  Explore our handcrafted linen textiles, oud fragrances, and ceramic dinnerware.
                </p>
                <button
                  onClick={onClose}
                  className="px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-medium hover:bg-stone-800 cursor-pointer"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.product.id} className="py-4 flex gap-4 items-center">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 object-cover rounded-lg bg-stone-100 shrink-0 border border-stone-200"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-semibold text-stone-900 truncate">
                      {item.product.name}
                    </h3>
                    <p className="text-[11px] text-stone-500 truncate">
                      {item.product.category}
                    </p>
                    <div className="mt-2 flex items-center justify-between">
                      {/* Quantity Stepper */}
                      <div className="flex items-center border border-stone-200 rounded bg-stone-50 text-xs">
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                          className="px-2 py-1 text-stone-600 hover:text-stone-900 cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 font-medium tabular-nums text-stone-900">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                          className="px-2 py-1 text-stone-600 hover:text-stone-900 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Line Item Total */}
                      <span className="text-xs font-semibold text-stone-900 tabular-nums">
                        {formatPrice(item.product.priceUsd * item.quantity, activeCurrency)}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveItem(item.product.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Action */}
          {cart.length > 0 && (
            <div className="p-5 border-t border-stone-200 bg-[#FAF8F5] space-y-4">
              {/* Promo code input */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Promo code (e.g. BAIT10)"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 bg-white border border-stone-300 rounded text-xs uppercase focus:outline-none focus:border-stone-600"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-stone-800 text-white rounded text-xs font-medium hover:bg-stone-900 cursor-pointer"
                >
                  Apply
                </button>
              </form>

              {promoSuccess && <p className="text-[11px] text-emerald-800 font-medium">{promoSuccess}</p>}
              {promoError && <p className="text-[11px] text-rose-600">{promoError}</p>}

              {/* Subtotal, discount & total */}
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-medium text-stone-800">
                    {formatPrice(subtotalUsd, activeCurrency)}
                  </span>
                </div>
                {discountPercent > 0 && (
                  <div className="flex justify-between text-emerald-800">
                    <span>Discount ({discountPercent}%)</span>
                    <span className="tabular-nums font-medium">
                      -{formatPrice(discountUsd, activeCurrency)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Standard Shipping</span>
                  <span className="tabular-nums font-medium text-stone-800">
                    {remainingForFreeShipping === 0 ? 'FREE' : formatPrice(10, activeCurrency)}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-stone-900 pt-2 border-t border-stone-200">
                  <span>Estimated Total</span>
                  <span className="tabular-nums">
                    {formatPrice(
                      subtotalUsd - discountUsd + (remainingForFreeShipping === 0 ? 0 : 10),
                      activeCurrency
                    )}
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => {
                  onClose();
                  onOpenCheckout(discountPercent);
                }}
                className="w-full py-3 bg-[#2D2A26] hover:bg-stone-850 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
