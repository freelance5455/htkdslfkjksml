import React from 'react';
import { CartItem, StoreSettings, AppLanguage } from '../types';
import { formatPKR } from '../utils/storage';
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingBag, Truck, Gift } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  settings: StoreSettings;
  language: AppLanguage;
  customNotes: string;
  setCustomNotes: (notes: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  settings,
  language,
  customNotes,
  setCustomNotes
}) => {
  if (!isOpen) return null;
  const isUrdu = language === 'ur';

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeDelivery = subtotal >= settings.freeDeliveryThreshold;
  const deliveryFee = cart.length === 0 ? 0 : (isFreeDelivery ? 0 : settings.deliveryFee);
  const total = subtotal + deliveryFee;
  const amountNeededForFree = Math.max(0, settings.freeDeliveryThreshold - subtotal);
  const progressPercent = Math.min(100, Math.round((subtotal / settings.freeDeliveryThreshold) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 bg-emerald-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-300" />
            <div>
              <h2 className="font-bold text-base sm:text-lg">
                {isUrdu ? 'آپ کا شاپنگ تھیلا' : 'Your Shopping Cart'}
              </h2>
              <p className="text-xs text-emerald-200">
                {cart.length} {isUrdu ? 'آئٹمز منتخب شدہ' : 'items selected'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {cart.length > 0 && (
              <button
                onClick={onClearCart}
                className="text-xs text-emerald-200 hover:text-white px-2 py-1 rounded hover:bg-emerald-700/60 transition"
                title="سب خالی کریں"
              >
                {isUrdu ? 'خالی کریں' : 'Clear'}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-emerald-700 transition"
              aria-label="بند کریں"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Free Delivery Bar */}
        <div className="bg-emerald-50 px-4 py-2.5 border-b border-emerald-100 text-xs">
          <div className="flex items-center justify-between text-emerald-900 font-medium mb-1">
            <span className="flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-emerald-600" />
              {isFreeDelivery ? (
                <span className="text-emerald-700 font-bold">
                  {isUrdu ? 'مبارک! آپ کو مفت ڈیلیوری ملے گی' : 'Congratulations! Free Delivery unlocked'}
                </span>
              ) : (
                <span>
                  {isUrdu 
                    ? `صرف ${formatPKR(amountNeededForFree, true)} مزید سامان لیں اور مفت ڈیلیوری پائیں`
                    : `Add ${formatPKR(amountNeededForFree)} more for Free Delivery`}
                </span>
              )}
            </span>
            <span className="font-bold text-emerald-700">{progressPercent}%</span>
          </div>
          <div className="w-full bg-emerald-200/70 h-2 rounded-full overflow-hidden">
            <div
              className="bg-emerald-600 h-full transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                <ShoppingBag className="w-8 h-8 text-slate-300" />
              </div>
              <h3 className="font-bold text-slate-700 text-base mb-1">
                {isUrdu ? 'آپ کا تھیلا خالی ہے' : 'Your cart is empty'}
              </h3>
              <p className="text-xs text-slate-400 max-w-xs mb-4">
                {isUrdu 
                  ? 'کریانہ، راشن، پنسار، کاسمیٹکس یا کتابوں کے سامان میں سے اپنی پسند کی چیزیں شامل کریں'
                  : 'Add items from Grocery, Cosmetics, Pansar, or Books to begin'}
              </p>
              <button
                onClick={onClose}
                className="bg-emerald-600 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md hover:bg-emerald-700 transition"
              >
                {isUrdu ? 'سامان دیکھنا شروع کریں' : 'Start Shopping'}
              </button>
            </div>
          ) : (
            <>
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="bg-slate-50 border border-slate-200/80 rounded-2xl p-2.5 flex items-center justify-between gap-3 shadow-2xs hover:border-emerald-200 transition"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.product.image}
                    alt={item.product.urduName}
                    className="w-14 h-14 rounded-xl object-cover shrink-0 bg-white border border-slate-200"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-slate-800 text-xs sm:text-sm truncate">
                      {isUrdu ? item.product.urduName : item.product.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-medium">
                      {item.product.unit} • {formatPKR(item.product.price, isUrdu)}
                    </p>
                    <p className="text-xs font-black text-emerald-800 mt-0.5">
                      {formatPKR(item.product.price * item.quantity, isUrdu)}
                    </p>
                  </div>

                  {/* Quantity Stepper & Delete */}
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="w-6 h-6 flex items-center justify-center rounded hover:bg-slate-100 text-slate-700 transition"
                        aria-label="کم کریں"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-5 text-center font-bold text-xs text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="w-6 h-6 flex items-center justify-center rounded hover:bg-slate-100 text-slate-700 transition"
                        aria-label="زیادہ کریں"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-slate-400 hover:text-red-600 transition p-1"
                      title="ہٹائیں"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}

              {/* Custom Missing Items Box */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isUrdu ? 'کوئی اور سامان جو لسٹ میں نہیں ملا؟ (یہاں لکھ دیں)' : 'Need something else not in the list? Write here:'}
                </label>
                <textarea
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder={isUrdu ? "مثلاً: ساتھ 2 پیکٹ ماچس، دہی 1 پاؤ یا کوئی خاص کتاب بھی بھیج دینا..." : "e.g. Please also bring 2 matchboxes, milk, or specific notebook..."}
                  rows={2}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white resize-none"
                />
              </div>
            </>
          )}
        </div>

        {/* Footer Checkout Summary */}
        {cart.length > 0 && (
          <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-3">
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>{isUrdu ? 'سامان کی کل رقم:' : 'Subtotal:'}</span>
                <span className="font-bold text-slate-800">{formatPKR(subtotal, isUrdu)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-slate-500" />
                  {isUrdu ? 'گاؤں ڈیلیوری فیس:' : 'Village Delivery Fee:'}
                </span>
                <span className={`font-bold ${isFreeDelivery ? 'text-emerald-700' : 'text-slate-800'}`}>
                  {isFreeDelivery ? (isUrdu ? 'مفت (Free)' : 'FREE') : formatPKR(deliveryFee, isUrdu)}
                </span>
              </div>
              <div className="pt-1.5 border-t border-slate-200 flex justify-between text-sm sm:text-base font-black text-slate-900">
                <span>{isUrdu ? 'کل رقم:' : 'Grand Total:'}</span>
                <span className="text-emerald-800">{formatPKR(total, isUrdu)}</span>
              </div>
            </div>

            <button
              onClick={onProceedToCheckout}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-sm transition transform active:scale-98"
            >
              <span>{isUrdu ? 'آرڈر فارم اور ڈیلیوری مکمل کریں' : 'Proceed to Village Delivery'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
