import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingCart, 
  MessageCircle, 
  AlertCircle, 
  CheckCircle,
  Truck,
  ArrowRight
} from 'lucide-react';
import { OrderFormData } from '../types';

export const CartDrawer: React.FC = () => {
  const { 
    isCartOpen, 
    setIsCartOpen, 
    cart, 
    removeFromCart, 
    updateQuantity, 
    cartTotal, 
    cartCount, 
    clearCart,
    sendOrderViaWhatsApp,
    shopSettings,
    language,
    t
  } = useApp();

  const [formData, setFormData] = useState<OrderFormData>({
    customerName: '',
    phoneNumber: '',
    deliveryAddress: '',
    cityPincode: '',
    specialNotes: '',
    targetWhatsAppNumber: shopSettings.phone1
  });

  const [formError, setFormError] = useState('');

  if (!isCartOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName.trim()) {
      setFormError(language === 'hi' ? 'कृपया अपना पूरा नाम लिखें।' : 'Please enter your full name.');
      return;
    }
    const cleanPhone = formData.phoneNumber.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setFormError(language === 'hi' ? 'कृपया सही 10 अंकों का मोबाइल नंबर लिखें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!formData.deliveryAddress.trim()) {
      setFormError(language === 'hi' ? 'कृपया अपना डिलीवरी पता दर्ज करें।' : 'Please enter your delivery address.');
      return;
    }

    setFormError('');
    sendOrderViaWhatsApp(formData);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400">
                <ShoppingCart className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">
                  {t.cart.title}
                </h3>
                <p className="text-xs text-slate-400">
                  {cartCount} {t.cart.itemsCount}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
            {cart.length === 0 ? (
              <div className="py-16 text-center space-y-4">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-slate-800 text-slate-500">
                  <ShoppingCart className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-white text-base">{t.cart.empty}</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">
                    {t.cart.emptySub}
                  </p>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition shadow-md"
                >
                  {t.cart.browseBtn}
                </button>
              </div>
            ) : (
              <>
                {/* Items List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      {language === 'hi' ? 'चुने हुए सामान:' : 'Selected Items:'}
                    </span>
                    <button
                      onClick={clearCart}
                      className="text-xs text-red-400 hover:text-red-300 transition"
                    >
                      {language === 'hi' ? 'सब हटाएं' : 'Clear All'}
                    </button>
                  </div>

                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex gap-3 items-center justify-between"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name.en}
                        className="w-14 h-14 object-cover rounded-lg flex-shrink-0 bg-slate-900 border border-slate-800"
                      />
                      <div className="flex-1 min-w-0 px-2">
                        <h4 className="text-xs font-bold text-white truncate">
                          {item.product.name[language] || item.product.name.en}
                        </h4>
                        <div className="text-xs font-semibold text-blue-400 mt-0.5">
                          ₹{item.product.price.toLocaleString('en-IN')}
                        </div>
                      </div>

                      {/* Quantity buttons */}
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <div className="flex items-center border border-slate-700 rounded-lg bg-slate-900">
                          <button
                            onClick={() => updateQuantity(item.product.id, -1)}
                            className="p-1 text-slate-400 hover:text-white"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-2 text-xs font-bold text-white">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product.id, 1)}
                            className="p-1 text-slate-400 hover:text-white"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-1.5 text-slate-500 hover:text-red-400 transition"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Subtotal Banner */}
                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                  <span className="text-xs text-slate-300 font-semibold">{t.cart.subtotal}:</span>
                  <span className="text-xl font-extrabold text-white">
                    ₹{cartTotal.toLocaleString('en-IN')}
                  </span>
                </div>

                {/* Mandatory Payment & Confirmation Disclaimer */}
                <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-300/90 text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-amber-300">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{t.cart.notice}</span>
                  </div>
                  <p className="leading-relaxed text-[11px] text-amber-200/80">
                    {t.cart.noticeText}
                  </p>
                </div>

                {/* Checkout Information Form */}
                <form id="cart-checkout-form" onSubmit={handleSubmit} className="space-y-3.5 pt-2 border-t border-slate-800">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    {t.cart.customerDetailsTitle}
                  </h4>

                  {formError && (
                    <div className="p-2.5 rounded-lg bg-red-950/60 border border-red-500/40 text-red-200 text-xs font-medium">
                      {formError}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      {t.cart.nameLabel} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.customerName}
                      onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                      placeholder={t.cart.namePlaceholder}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      {t.cart.phoneLabel} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                      placeholder={t.cart.phonePlaceholder}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      {t.cart.addressLabel} *
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={formData.deliveryAddress}
                      onChange={(e) => setFormData({ ...formData, deliveryAddress: e.target.value })}
                      placeholder={t.cart.addressPlaceholder}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        {t.cart.pincodeLabel}
                      </label>
                      <input
                        type="text"
                        value={formData.cityPincode}
                        onChange={(e) => setFormData({ ...formData, cityPincode: e.target.value })}
                        placeholder={t.cart.pincodePlaceholder}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        {language === 'hi' ? 'व्हाट्सएप नंबर चुनें' : 'WhatsApp Number'}
                      </label>
                      <select
                        value={formData.targetWhatsAppNumber}
                        onChange={(e) => setFormData({ ...formData, targetWhatsAppNumber: e.target.value })}
                        className="w-full px-2 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value={shopSettings.phone1}>{shopSettings.phone1} (Main)</option>
                        <option value={shopSettings.phone2}>{shopSettings.phone2} (Secondary)</option>
                      </select>
                    </div>
                  </div>
                </form>
              </>
            )}
          </div>

          {/* Footer Submit */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950/70 space-y-2">
              <button
                type="submit"
                form="cart-checkout-form"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{t.cart.placeOrderWhatsApp}</span>
              </button>
              <p className="text-[10px] text-center text-slate-400">
                {language === 'hi' 
                  ? 'क्लिक करने पर आपका पूरा ऑर्डर व्हाट्सएप पर सीधे खुलेगा।' 
                  : 'Clicking opens formatted order summary in WhatsApp directly.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
