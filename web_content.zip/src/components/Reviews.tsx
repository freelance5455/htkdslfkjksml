import React from 'react';
import { Star, CheckCircle, Quote, ThumbsUp, MapPin } from 'lucide-react';
import { CLIENT_REVIEWS } from '../data/djData';

export const Reviews: React.FC = () => {
  return (
    <section className="py-14 px-4 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-950/60 px-3 py-1 rounded-full border border-amber-800/40 mb-3">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          5.0 Star Client Satisfaction
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
          What Ugandan Clients Say
        </h2>
        <p className="text-sm text-slate-300 max-w-xl mx-auto mt-2">
          Real feedback from wedding couples, bar managers, family elders, and party organizers across Kampala, Wakiso &amp; Mukono.
        </p>

        {/* Overall Score Badge */}
        <div className="inline-flex items-center gap-3 mt-6 px-4 py-2 rounded-xl bg-purple-950/60 border border-purple-800/50">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} className="w-4 h-4 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span className="text-xs font-bold text-white">5.0 / 5.0 Rating</span>
          <span className="text-slate-500">·</span>
          <span className="text-xs text-purple-300">100% Recommendation Rate</span>
        </div>
      </div>

      {/* Reviews Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CLIENT_REVIEWS.map((rev) => (
          <div
            key={rev.id}
            className="p-6 rounded-2xl bg-[#0f0b1b] border border-purple-900/50 hover:border-purple-600/50 transition-all flex flex-col justify-between shadow-lg"
          >
            <div>
              {/* Star Rating & Event Badge */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-1">
                  {Array.from({ length: rev.rating }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                  {rev.service}
                </span>
              </div>

              {/* Review Text */}
              <p className="text-xs text-slate-200 leading-relaxed italic mb-4">
                "{rev.comment}"
              </p>
            </div>

            {/* Reviewer Details */}
            <div className="pt-4 border-t border-purple-900/40 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1">
                  <span>{rev.name}</span>
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                </div>
                <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3 text-purple-400 shrink-0" />
                  <span>{rev.location}</span>
                </div>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">{rev.date}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
