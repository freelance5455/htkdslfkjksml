import React, { useState, useEffect, useMemo, useRef } from 'react';
import { FileItem } from '../types';
import { 
  RotateCw, 
  ExternalLink, 
  Maximize, 
  Minimize, 
  Monitor, 
  Tablet, 
  Smartphone, 
  Check, 
  Globe 
} from 'lucide-react';

interface PreviewViewProps {
  files: FileItem[];
  activeFileId: string | null;
}

export const PreviewView: React.FC<PreviewViewProps> = ({ files, activeFileId }) => {
  const [device, setDevice] = useState<'current' | 'mobile' | 'tablet' | 'pc'>('current');
  const [refreshKey, setRefreshKey] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // All HTML files
  const htmlFiles = useMemo(
    () => files.filter((f) => !f.isFolder && (f.name.endsWith('.html') || f.language === 'html')),
    [files]
  );

  const [selectedHtmlId, setSelectedHtmlId] = useState<string | null>(null);

  useEffect(() => {
    if (activeFileId) {
      const active = files.find((f) => f.id === activeFileId);
      if (active && !active.isFolder && (active.name.endsWith('.html') || active.language === 'html')) {
        setSelectedHtmlId(active.id);
        return;
      }
    }
    if (!selectedHtmlId || !htmlFiles.some((f) => f.id === selectedHtmlId)) {
      const indexHtml = htmlFiles.find((f) => f.name === 'index.html') || htmlFiles[0];
      if (indexHtml) setSelectedHtmlId(indexHtml.id);
    }
  }, [activeFileId, files, htmlFiles, selectedHtmlId]);

  // Handle internal navigation from iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === 'NOXORA_NAVIGATE_HTML') {
        const targetPath = (e.data.path || '').trim().toLowerCase();
        if (!targetPath) return;

        const found = htmlFiles.find((f) => {
          const name = f.name.trim().toLowerCase();
          const cleanName = name.replace(/\.html$/, '');
          const cleanTarget = targetPath.replace(/\.html$/, '');
          return name === targetPath || cleanName === cleanTarget || f.id === targetPath;
        });

        if (found) {
          setSelectedHtmlId(found.id);
        } else {
          console.warn(`[Preview] Target file "${targetPath}" not found in project.`);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [htmlFiles]);

  // Construct iframe document
  const previewHtml = useMemo(() => {
    const targetHtml =
      htmlFiles.find((f) => f.id === selectedHtmlId) ||
      files.find((f) => f.name === 'index.html') ||
      htmlFiles[0] ||
      null;

    const cssFiles = files.filter((f) => !f.isFolder && f.name.endsWith('.css'));
    const jsFiles = files.filter((f) => !f.isFolder && f.name.endsWith('.js'));

    if (!targetHtml) {
      return `<!DOCTYPE html>
<html>
<body style="font-family:sans-serif;padding:3rem;text-align:center;background:#0f172a;color:#94a3b8;">
  <div style="max-width:400px;margin:0 auto;background:#1e293b;padding:2rem;border-radius:1rem;border:1px solid #334155;">
    <h2 style="color:#f8fafc;margin-top:0;">No HTML File Found</h2>
    <p style="font-size:13px;line-height:1.5;">Create an <code>index.html</code> file in your project to view live output.</p>
  </div>
</body>
</html>`;
    }

    let html = targetHtml.content;

    // Inject console bridge script
    const consoleBridge = `
<script>
(function() {
  const origLog = console.log;
  const origWarn = console.warn;
  const origError = console.error;
  const origInfo = console.info;

  function sendToParent(type, args) {
    try {
      const cleanArgs = Array.from(args).map(arg => {
        if (typeof arg === 'object') {
          try { return JSON.stringify(arg, null, 2); } catch(e) { return String(arg); }
        }
        return String(arg);
      });
      window.parent.postMessage({ type: 'NOXORA_CONSOLE', logType: type, content: cleanArgs.join(' ') }, '*');
    } catch(e) {}
  }

  console.log = function(...args) { origLog.apply(console, args); sendToParent('log', args); };
  console.warn = function(...args) { origWarn.apply(console, args); sendToParent('warn', args); };
  console.error = function(...args) { origError.apply(console, args); sendToParent('error', args); };
  console.info = function(...args) { origInfo.apply(console, args); sendToParent('info', args); };

  // Intercept anchor clicks
  document.addEventListener('click', function(e) {
    const a = e.target.closest('a');
    if (a && a.getAttribute('href')) {
      const href = a.getAttribute('href');
      if (href && !href.startsWith('http://') && !href.startsWith('https://') && !href.startsWith('#') && !href.startsWith('javascript:')) {
        e.preventDefault();
        window.parent.postMessage({ type: 'NOXORA_NAVIGATE_HTML', path: href }, '*');
      }
    }
  }, true);
})();
</script>
`;

    // Inject Tailwind CSS v4 CDN
    const tailwindScript = '<script src="https://cdn.tailwindcss.com"></script>';

    // Inject CSS styles
    const combinedCss = cssFiles.map((c) => `<style id="injected-${c.name}">\n${c.content}\n</style>`).join('\n');

    // Inject JS scripts
    const combinedJs = jsFiles
      .map(
        (j) => `<script id="injected-${j.name}">
try {
${j.content}
} catch(e) { console.error("Script error in ${j.name}:", e); }
</script>`
      )
      .join('\n');

    // Place into HTML
    if (html.includes('<head>')) {
      html = html.replace('<head>', `<head>\n${consoleBridge}\n${tailwindScript}\n${combinedCss}`);
    } else {
      html = `${consoleBridge}\n${tailwindScript}\n${combinedCss}\n${html}`;
    }

    if (html.includes('</body>')) {
      html = html.replace('</body>', `${combinedJs}\n</body>`);
    } else {
      html = `${html}\n${combinedJs}`;
    }

    return html;
  }, [files, selectedHtmlId, htmlFiles]);

  const handleOpenNewTab = () => {
    try {
      const blob = new Blob([previewHtml], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (e) {
      console.error('Failed to open preview in new tab:', e);
    }
  };

  const handleToggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        setIsFullscreen(false);
      } else if (containerRef.current) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      }
    } catch (e) {
      console.warn('Fullscreen error:', e);
    }
  };

  const getDeviceDimensions = () => {
    switch (device) {
      case 'mobile':
        return { width: '390px', height: '844px', label: 'Mobile (390 × 844)' };
      case 'tablet':
        return { width: '768px', height: '1024px', label: 'Tablet (768 × 1024)' };
      case 'pc':
        return { width: '100%', maxWidth: '1440px', height: '900px', label: 'PC Desktop (1440 × 900)' };
      default:
        return { width: '100%', height: '100%', label: 'Current Display' };
    }
  };

  const dims = getDeviceDimensions();

  return (
    <div
      ref={containerRef}
      className="h-full w-full flex flex-col overflow-hidden theme-bg-main relative"
    >
      {/* Preview Top Toolbar */}
      <div className="h-9 px-3 flex items-center justify-between border-b theme-border bg-[#181920] shrink-0 text-xs">
        {/* Left: Target HTML Selector */}
        <div className="flex items-center space-x-2">
          <Globe className="w-3.5 h-3.5 text-[#359efe] shrink-0" />
          <span className="font-medium text-[11px] theme-text-muted hidden sm:inline">Page:</span>
          {htmlFiles.length > 0 ? (
            <select
              value={selectedHtmlId || ''}
              onChange={(e) => setSelectedHtmlId(e.target.value)}
              className="bg-transparent border theme-border rounded px-2 py-0.5 text-xs font-mono font-semibold theme-text-main outline-none cursor-pointer"
            >
              {htmlFiles.map((hf) => (
                <option key={hf.id} value={hf.id} className="theme-bg-main theme-text-main">
                  {hf.name}
                </option>
              ))}
            </select>
          ) : (
            <span className="text-xs text-amber-400 font-mono">No HTML file</span>
          )}
        </div>

        {/* Center: Device Viewport Controls */}
        <div className="hidden sm:flex items-center space-x-1 bg-[#121318] p-0.5 rounded-lg border theme-border">
          <button
            onClick={() => setDevice('current')}
            className={`px-2 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
              device === 'current'
                ? 'bg-[#359efe] text-white shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
            title="Full Display"
          >
            Auto
          </button>
          <button
            onClick={() => setDevice('mobile')}
            className={`p-1 rounded transition-colors cursor-pointer ${
              device === 'mobile'
                ? 'bg-[#359efe] text-white shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
            title="Mobile (390x844)"
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setDevice('tablet')}
            className={`p-1 rounded transition-colors cursor-pointer ${
              device === 'tablet'
                ? 'bg-[#359efe] text-white shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
            title="Tablet (768x1024)"
          >
            <Tablet className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setDevice('pc')}
            className={`p-1 rounded transition-colors cursor-pointer ${
              device === 'pc'
                ? 'bg-[#359efe] text-white shadow-xs'
                : 'theme-text-muted hover:theme-text-main'
            }`}
            title="PC Desktop"
          >
            <Monitor className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center space-x-1">
          {/* Refresh */}
          <button
            onClick={() => setRefreshKey((k) => k + 1)}
            className="p-1.5 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title="Refresh Preview"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          {/* Open New Tab */}
          <button
            onClick={handleOpenNewTab}
            className="p-1.5 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title="Open Live Preview in New Window"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={handleToggleFullscreen}
            className="p-1.5 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? (
              <Minimize className="w-3.5 h-3.5" />
            ) : (
              <Maximize className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>

      {/* Preview Frame Wrapper */}
      <div className="flex-grow w-full h-[calc(100%-2.25rem)] bg-[#0b0c10] flex items-center justify-center p-2 overflow-auto">
        <div
          style={{
            width: dims.width,
            maxWidth: dims.maxWidth || '100%',
            height: dims.height,
            maxHeight: '100%',
          }}
          className={`bg-white rounded-lg shadow-2xl overflow-hidden transition-all duration-200 border border-[#2a2c3a] flex flex-col ${
            device !== 'current' ? 'my-auto' : ''
          }`}
        >
          <iframe
            key={refreshKey}
            ref={iframeRef}
            srcDoc={previewHtml}
            title="Live Preview"
            sandbox="allow-scripts allow-modals allow-same-origin allow-forms"
            className="w-full h-full border-none bg-white"
          />
        </div>
      </div>
    </div>
  );
};
