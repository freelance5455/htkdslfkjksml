import React, { useEffect, useState } from 'react';
import { AlertCircle, Monitor, RotateCw, Smartphone, Sparkles, Tablet } from 'lucide-react';
import { getAuthToken } from '../lib/api';
import type { ProjectDetail, ProjectSummary } from '../types/studio';

interface PreviewViewProps {
  projects: ProjectSummary[];
  selectedProject: ProjectDetail | null;
  onSelectProject: (id: string) => void;
}

interface PreviewErrorItem {
  id: number;
  type: string;
  message: string;
  time: string;
}

export const PreviewView: React.FC<PreviewViewProps> = ({
  projects,
  selectedProject,
  onSelectProject,
}) => {
  const [device, setDevice] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');
  const [reloadNonce, setReloadNonce] = useState(0);
  const [errors, setErrors] = useState<PreviewErrorItem[]>([]);
  const [showSplashSim, setShowSplashSim] = useState(false);

  useEffect(() => {
    const handler = (event: MessageEvent) => {
      if (event.data && event.data.source === 'html-apk-preview') {
        setErrors((prev) => [
          {
            id: Date.now() + Math.random(),
            type: String(event.data.type || 'error'),
            message: String(event.data.message || 'Bilinmeyen çalışma zamanı hatası'),
            time: new Date().toLocaleTimeString('tr-TR'),
          },
          ...prev.slice(0, 19),
        ]);
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, []);

  useEffect(() => {
    if (!showSplashSim) return;
    const ms = Math.min(3500, Math.max(800, selectedProject?.config.splashDurationMs || 1400));
    const timer = setTimeout(() => setShowSplashSim(false), ms);
    return () => clearTimeout(timer);
  }, [showSplashSim, selectedProject?.config.splashDurationMs]);

  const token = getAuthToken();
  const previewUrl = selectedProject
    ? `/api/projects/${selectedProject.id}/preview/${selectedProject.entry_file}?${
        token ? `token=${encodeURIComponent(token)}&` : ''
      }r=${reloadNonce}`
    : null;

  const frameDimensionClass =
    device === 'mobile'
      ? 'w-[390px] h-[760px] rounded-[34px] border-[10px] border-slate-800 dark:border-[#1E293B]'
      : device === 'tablet'
      ? 'w-[768px] max-w-full h-[760px] rounded-[24px] border-[10px] border-slate-800 dark:border-[#1E293B]'
      : 'w-full h-[760px] rounded-xl border border-slate-200 dark:border-white/[0.1]';

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Canlı HTML Önizleme
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Gerçek CSS, JavaScript ve yerel medya dosyalarıyla mobil, tablet ve masaüstü görünümü
            test edin.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {projects.length > 0 && (
            <select
              value={selectedProject?.id || ''}
              onChange={(e) => {
                setErrors([]);
                onSelectProject(e.target.value);
              }}
              className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC] focus:outline-none"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          )}

          {/* Device Switcher */}
          <div className="inline-flex p-1 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl">
            <button
              type="button"
              onClick={() => setDevice('mobile')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                device === 'mobile'
                  ? 'bg-[#6366F1] text-white'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobil</span>
            </button>
            <button
              type="button"
              onClick={() => setDevice('tablet')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                device === 'tablet'
                  ? 'bg-[#6366F1] text-white'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>Tablet</span>
            </button>
            <button
              type="button"
              onClick={() => setDevice('desktop')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                device === 'desktop'
                  ? 'bg-[#6366F1] text-white'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Masaüstü</span>
            </button>
          </div>

          {selectedProject?.config.splashEnabled && (
            <button
              type="button"
              onClick={() => setShowSplashSim(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl bg-white dark:bg-[#151D2E] hover:bg-slate-50 dark:hover:bg-white/[0.06] border border-slate-200 dark:border-white/[0.08] text-slate-800 dark:text-[#F8FAFC] transition-colors whitespace-nowrap"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#3B82F6]" />
              <span>Splash Test Et</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setErrors([]);
              setReloadNonce((n) => n + 1);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl bg-white dark:bg-[#151D2E] hover:bg-slate-50 dark:hover:bg-white/[0.06] border border-slate-200 dark:border-white/[0.08] text-slate-800 dark:text-[#F8FAFC] transition-colors whitespace-nowrap"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Yenile</span>
          </button>
        </div>
      </div>

      {!selectedProject || !previewUrl ? (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-12 text-center text-sm text-slate-600 dark:text-[#94A3B8]">
          Önizleme için önce bir proje seçin veya yükleyin.
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Device Viewport */}
          <div className="xl:col-span-9 bg-slate-100 dark:bg-[#111827] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 flex justify-center overflow-x-auto">
            <div
              className={`relative ${frameDimensionClass} bg-white overflow-hidden shadow-xl shrink-0`}
            >
              {showSplashSim && (
                <div
                  className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 text-center"
                  style={{ backgroundColor: selectedProject.config.splashBgColor || '#0B1020' }}
                >
                  <div className="text-lg font-bold text-white">
                    {selectedProject.config.splashTitle || selectedProject.config.appName}
                  </div>
                  <div className="mt-2 text-xs text-white/70 font-mono">
                    Splash Önizleme ({selectedProject.config.splashDurationMs} ms)
                  </div>
                </div>
              )}
              <iframe
                key={`${selectedProject.id}-${reloadNonce}`}
                title="Canlı HTML Önizleme"
                src={previewUrl}
                className="w-full h-full border-0"
                sandbox="allow-scripts allow-forms allow-same-origin allow-modals"
              />
            </div>
          </div>

          {/* Runtime Error & Preview Diagnostics */}
          <div className="xl:col-span-3 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-5 space-y-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Önizleme Tanılama
              </h2>
              <p className="mt-1 text-xs font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                Giriş: {selectedProject.entry_file}
              </p>
              <p className="mt-1 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                Yön: {selectedProject.config.orientation} · Tam ekran:{' '}
                {selectedProject.config.fullscreen ? 'Açık' : 'Kapalı'}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/[0.08]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-600 dark:text-[#94A3B8]">
                  Çalışma Zamanı Hataları ({errors.length})
                </span>
                {errors.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setErrors([])}
                    className="text-[11px] text-[#3B82F6] hover:underline"
                  >
                    Temizle
                  </button>
                )}
              </div>

              {errors.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-[#94A3B8] leading-relaxed">
                  Sayfada yakalanan JavaScript veya konsol hatası bulunmuyor.
                </p>
              ) : (
                <div className="space-y-2 max-h-[420px] overflow-y-auto">
                  {errors.map((err) => (
                    <div
                      key={err.id}
                      className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-600 dark:text-red-300 space-y-1"
                    >
                      <div className="flex items-center justify-between gap-2 text-[10px] text-[#EF4444] font-mono">
                        <span className="inline-flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{err.type}</span>
                        </span>
                        <span>{err.time}</span>
                      </div>
                      <p className="break-words">{err.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
