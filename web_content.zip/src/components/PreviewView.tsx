import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw, Monitor, Smartphone, Tablet, Trash2, AlertTriangle, Terminal } from "lucide-react";
import type { StudioApi } from "@/hooks/useStudio";
import { cn } from "@/lib/utils";

interface Props {
  studio: StudioApi;
}

interface LogEntry {
  type: "log" | "warn" | "error" | "info";
  message: string;
  time: number;
}

const DEVICES = [
  { id: "phone", label: "هاتف", width: 375, icon: Smartphone },
  { id: "tablet", label: "لوحي", width: 768, icon: Tablet },
  { id: "desktop", label: "سطح المكتب", width: 0, icon: Monitor },
] as const;

export function PreviewView({ studio }: Props) {
  const { files, saveAll } = studio;
  const [device, setDevice] = useState<(typeof DEVICES)[number]["id"]>("phone");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [filter, setFilter] = useState<"all" | "error" | "warn">("all");
  const [reloadKey, setReloadKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const mainFile = useMemo(
    () => files.find((f) => f.isMain && f.language === "html") ?? files.find((f) => f.language === "html"),
    [files]
  );

  const srcDoc = useMemo(() => {
    if (!mainFile) return "";
    let html = mainFile.content;

    // Inline local CSS files
    html = html.replace(
      /<link[^>]*href=["']([^"']+\.css)["'][^>]*>/gi,
      (match, href: string) => {
        const clean = href.replace(/^\.\//, "");
        const cssFile = files.find((f) => f.name === clean || f.path === clean);
        if (cssFile) return `<style>\n${cssFile.content}\n</style>`;
        return match;
      }
    );

    // Inline local JS files
    html = html.replace(
      /<script[^>]*src=["']([^"']+\.js)["'][^>]*><\/script>/gi,
      (match, src: string) => {
        const clean = src.replace(/^\.\//, "");
        const jsFile = files.find((f) => f.name === clean || f.path === clean);
        if (jsFile) return `<script>\n${jsFile.content}\n</script>`;
        return match;
      }
    );

    // Inject console bridge
    const bridge = `<script>
(function(){
  var send = function(type, args){
    try {
      var msg = Array.prototype.map.call(args, function(a){
        if (a instanceof Error) return a.message;
        if (typeof a === 'object') { try { return JSON.stringify(a); } catch(e){ return String(a); } }
        return String(a);
      }).join(' ');
      parent.postMessage({ __mcs: true, type: type, message: msg }, '*');
    } catch(e){}
  };
  ['log','warn','error','info'].forEach(function(t){
    var orig = console[t];
    console[t] = function(){ send(t, arguments); orig && orig.apply(console, arguments); };
  });
  window.addEventListener('error', function(e){
    send('error', [e.message + ' (line ' + e.lineno + ')']);
  });
  window.addEventListener('unhandledrejection', function(e){
    send('error', ['Unhandled: ' + e.reason]);
  });
})();
</script>`;

    if (html.includes("<head>")) {
      html = html.replace("<head>", "<head>" + bridge);
    } else {
      html = bridge + html;
    }

    return html;
  }, [mainFile, files]);

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data && e.data.__mcs) {
        setLogs((prev) => [
          ...prev.slice(-99),
          { type: e.data.type, message: e.data.message, time: Date.now() },
        ]);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  useEffect(() => {
    setLogs([]);
  }, [reloadKey]);

  const filteredLogs = logs.filter((l) => filter === "all" || l.type === filter);
  const errorCount = logs.filter((l) => l.type === "error").length;
  const warnCount = logs.filter((l) => l.type === "warn").length;
  const width = DEVICES.find((d) => d.id === device)?.width ?? 0;

  if (!mainFile) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
        <div className="rounded-2xl bg-amber-100 p-6 dark:bg-amber-950">
          <AlertTriangle className="h-10 w-10 text-amber-600 dark:text-amber-400" />
        </div>
        <h2 className="text-xl font-bold">لا يوجد ملف HTML للمعاينة</h2>
        <p className="max-w-xs text-sm text-muted-foreground">
          أنشئ ملف HTML أو عيّن ملفًا رئيسيًا للمعاينة من قائمة الملفات.
        </p>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-slate-100 dark:bg-slate-950">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-2 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex gap-1">
          {DEVICES.map((d) => {
            const Icon = d.icon;
            return (
              <button
                key={d.id}
                onClick={() => setDevice(d.id)}
                className={cn(
                  "rounded-lg p-2 transition-colors",
                  device === d.id
                    ? "bg-sky-600 text-white"
                    : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                )}
                title={d.label}
              >
                <Icon className="h-4 w-4" />
              </button>
            );
          })}
        </div>

        <span className="truncate text-xs text-muted-foreground">{mainFile.name}</span>

        <div className="ms-auto flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setShowConsole((v) => !v)}
            className="relative h-8 w-8 p-0"
            title="وحدة التحكم"
          >
            <Terminal className="h-4 w-4" />
            {errorCount > 0 && (
              <span className="absolute -end-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-600 px-1 text-[9px] text-white">
                {errorCount}
              </span>
            )}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={async () => {
              await saveAll();
              setReloadKey((k) => k + 1);
            }}
            className="h-8 w-8 p-0"
            title="إعادة تحميل"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1 justify-center overflow-auto bg-slate-200 p-3 dark:bg-slate-950">
        <div
          className="h-full overflow-hidden rounded-2xl border border-slate-300 bg-white shadow-lg dark:border-slate-700"
          style={{ width: width ? `${width}px` : "100%", maxWidth: "100%" }}
        >
          <iframe
            key={reloadKey}
            ref={iframeRef}
            srcDoc={srcDoc}
            sandbox="allow-scripts allow-modals"
            title="preview"
            className="h-full w-full border-0"
          />
        </div>
      </div>

      {showConsole && (
        <div className="flex h-56 flex-col border-t border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2 border-b border-slate-800 px-3 py-1.5">
            <span className="text-xs font-semibold text-slate-300">Console</span>
            <span className="rounded bg-rose-900 px-1.5 text-[10px] text-rose-300">
              {errorCount} أخطاء
            </span>
            <span className="rounded bg-amber-900 px-1.5 text-[10px] text-amber-300">
              {warnCount} تحذيرات
            </span>
            <div className="ms-auto flex gap-1">
              {(["all", "error", "warn"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={cn(
                    "rounded px-2 py-0.5 text-[10px]",
                    filter === f ? "bg-sky-600 text-white" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  {f === "all" ? "الكل" : f === "error" ? "أخطاء" : "تحذيرات"}
                </button>
              ))}
              <button
                onClick={() => setLogs([])}
                className="rounded p-0.5 text-slate-400 hover:text-slate-200"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 font-mono text-xs">
            {filteredLogs.length === 0 ? (
              <p className="p-2 text-slate-600">لا توجد رسائل</p>
            ) : (
              filteredLogs.map((l, i) => (
                <div
                  key={i}
                  className={cn(
                    "border-b border-slate-900 px-2 py-1",
                    l.type === "error" && "text-rose-400",
                    l.type === "warn" && "text-amber-400",
                    l.type === "log" && "text-slate-300",
                    l.type === "info" && "text-sky-400"
                  )}
                >
                  <span className="text-slate-600">[{l.type}]</span> {l.message}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}