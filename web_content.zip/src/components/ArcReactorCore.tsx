import React from 'react';
import { 
  Mic, Zap, Sparkles, Volume2, ShieldAlert, 
  Scan, Fingerprint, Pause, AlertCircle, Eye 
} from 'lucide-react';
import { AssistantState } from '../types';

interface ArcReactorCoreProps {
  state: AssistantState;
  onToggleListening: () => void;
  statusLabel?: string;
}

export const ArcReactorCore: React.FC<ArcReactorCoreProps> = ({
  state,
  onToggleListening,
  statusLabel = 'JARVIS ONLINE',
}) => {
  const isListening = state === 'listening';
  const isThinking = state === 'thinking' || state === 'processing';
  const isSpeaking = state === 'speaking';
  const isScanning = state === 'scanning';
  const isAuthenticating = state === 'authenticating';
  const isInterrupted = state === 'interrupted';
  const isError = state === 'error';
  const isAlarm = state === 'alarm';

  return (
    <div className="relative flex flex-col items-center justify-center my-3 select-none">
      {/* Outer ambient glow reacting to real AssistantState */}
      <div className={`absolute w-64 h-64 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
        isAlarm
          ? 'bg-red-600/35'
          : isError
          ? 'bg-rose-600/30'
          : isInterrupted
          ? 'bg-amber-600/30'
          : isListening
          ? 'bg-cyan-500/35'
          : isThinking
          ? 'bg-amber-500/25'
          : isScanning
          ? 'bg-indigo-500/30'
          : isAuthenticating
          ? 'bg-emerald-500/30'
          : isSpeaking
          ? 'bg-cyan-400/25'
          : 'bg-cyan-600/15'
      }`} />

      {/* Interactive Main Round Eye Core Button */}
      <button
        onClick={onToggleListening}
        aria-label="Toggle JARVIS Round Eye Core"
        className="relative group w-48 h-48 md:w-56 md:h-56 rounded-full flex items-center justify-center cursor-pointer focus:outline-none transition-transform active:scale-95"
      >
        {/* Ring 1 - Outer segmented boundary with direction-specific rotation */}
        <div className={`absolute inset-0 rounded-full border-2 border-dashed transition-all duration-500 ${
          isAlarm
            ? 'border-red-500/80 animate-arc-spin-fast'
            : isError
            ? 'border-rose-500/80'
            : isInterrupted
            ? 'border-amber-400 border-solid animate-pulse'
            : isListening
            ? 'border-cyan-400 animate-arc-spin-fast shadow-[0_0_15px_rgba(6,182,212,0.4)]'
            : isThinking
            ? 'border-amber-400/80 animate-arc-spin'
            : isScanning
            ? 'border-indigo-400/80 animate-arc-spin-fast'
            : isAuthenticating
            ? 'border-emerald-400/80 animate-arc-spin'
            : isSpeaking
            ? 'border-cyan-400 animate-pulse'
            : 'border-cyan-600/30 animate-arc-spin'
        }`} />

        {/* Ring 2 - Reverse rotating geometric ring with ticks */}
        <div className={`absolute inset-3 rounded-full border transition-colors duration-500 ${
          isAlarm || isError
            ? 'border-red-500/50'
            : isInterrupted
            ? 'border-amber-500/50'
            : isScanning
            ? 'border-indigo-400/50 animate-arc-spin-reverse'
            : isAuthenticating
            ? 'border-emerald-400/50 animate-arc-spin-reverse'
            : 'border-cyan-400/40 animate-arc-spin-reverse'
        }`} />

        {/* Ring 3 - Circular tick marks & optical reticle */}
        <div className="absolute inset-6 rounded-full border border-dashed border-cyan-300/30" />

        {/* Special Scanning Radar Line for 'scanning' state */}
        {isScanning && (
          <div className="absolute inset-0 rounded-full overflow-hidden pointer-events-none">
            <div className="w-1/2 h-1/2 origin-bottom-right bg-gradient-to-br from-indigo-500/40 to-transparent animate-arc-spin" />
          </div>
        )}

        {/* Center Round Eye Iris / Arc Reactor Orb */}
        <div className={`relative w-28 h-28 md:w-32 md:h-32 rounded-full flex flex-col items-center justify-center transition-all duration-500 ${
          isAlarm
            ? 'bg-red-950/85 border-2 border-red-500 glow-red'
            : isError
            ? 'bg-rose-950/85 border-2 border-rose-500 glow-red'
            : isInterrupted
            ? 'bg-amber-950/85 border-2 border-amber-400 glow-gold'
            : isListening
            ? 'bg-cyan-950/90 border-2 border-cyan-300 glow-cyan scale-105'
            : isThinking
            ? 'bg-amber-950/75 border-2 border-amber-400 glow-gold animate-pulse'
            : isScanning
            ? 'bg-indigo-950/85 border-2 border-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.5)]'
            : isAuthenticating
            ? 'bg-emerald-950/85 border-2 border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.5)]'
            : isSpeaking
            ? 'bg-cyan-950/85 border-2 border-cyan-400 glow-cyan animate-pulse'
            : 'bg-gray-950/90 border border-cyan-500/50 hover:border-cyan-400 glow-cyan-sm'
        }`}>
          {/* Reactor Inner Concentric Aperture Lines */}
          <div className="absolute inset-1 rounded-full border border-cyan-400/20" />
          <div className="absolute inset-3 rounded-full border border-cyan-400/30" />

          {/* Central Eye / Reactor Dynamic Icon */}
          <div className="z-10 flex flex-col items-center justify-center">
            {isAlarm ? (
              <ShieldAlert className="w-9 h-9 text-red-400 animate-bounce" />
            ) : isError ? (
              <AlertCircle className="w-9 h-9 text-rose-400 animate-pulse" />
            ) : isInterrupted ? (
              <Pause className="w-9 h-9 text-amber-300 animate-pulse" />
            ) : isListening ? (
              <Mic className="w-9 h-9 text-cyan-200 animate-pulse" />
            ) : isThinking ? (
              <Sparkles className="w-8 h-8 text-amber-300 animate-spin" />
            ) : isScanning ? (
              <Scan className="w-8 h-8 text-indigo-300 animate-pulse" />
            ) : isAuthenticating ? (
              <Fingerprint className="w-8 h-8 text-emerald-300 animate-pulse" />
            ) : isSpeaking ? (
              <Volume2 className="w-8 h-8 text-cyan-300" />
            ) : (
              <Zap className="w-8 h-8 text-cyan-400 group-hover:scale-110 transition-transform" />
            )}

            {/* Real State Text Label */}
            <span className="text-[9px] font-tech font-bold tracking-widest uppercase mt-1 text-cyan-200/90">
              {isAlarm 
                ? 'ALERT' 
                : isError 
                ? 'ERROR' 
                : isInterrupted 
                ? 'PAUSED' 
                : isListening 
                ? 'LISTENING' 
                : isThinking 
                ? 'THINKING' 
                : isScanning 
                ? 'SCANNING' 
                : isAuthenticating 
                ? 'AUTH' 
                : isSpeaking 
                ? 'SPEAKING' 
                : 'READY'}
            </span>
          </div>
        </div>
      </button>

      {/* Status Bar Beneath Round Eye */}
      <div className="mt-3 flex items-center gap-2 px-3.5 py-1 rounded-full bg-gray-900/80 border border-cyan-500/25 backdrop-blur-sm">
        <span className={`w-2 h-2 rounded-full ${
          isAlarm
            ? 'bg-red-500 animate-ping'
            : isError
            ? 'bg-rose-500 animate-ping'
            : isInterrupted
            ? 'bg-amber-400 animate-ping'
            : isListening
            ? 'bg-cyan-400 animate-ping'
            : isThinking
            ? 'bg-amber-400 animate-pulse'
            : isScanning
            ? 'bg-indigo-400 animate-pulse'
            : isAuthenticating
            ? 'bg-emerald-400 animate-pulse'
            : isSpeaking
            ? 'bg-cyan-400 animate-pulse'
            : 'bg-cyan-400'
        }`} />
        <span className="text-xs font-mono-tech text-cyan-300/85 uppercase tracking-wider">
          {statusLabel}
        </span>
      </div>
    </div>
  );
};
