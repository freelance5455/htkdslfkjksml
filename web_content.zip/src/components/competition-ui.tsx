"use client";

import type { ReactNode } from "react";
import type { Fixture, FixtureStatus, Standing } from "@/lib/competition";
import { TeamLogo } from "./cricket";

/** Competition crest — generated from the name when no logo is supplied. */
export function CompetitionLogo({
  name,
  logo,
  size = 40,
}: {
  name: string;
  logo?: string;
  size?: number;
}) {
  return <TeamLogo name={name} logo={logo} size={size} />;
}

const STATUS: Record<FixtureStatus, { label: string; cls: string }> = {
  scheduled: { label: "SCHEDULED", cls: "bg-slate-800 text-slate-400" },
  live: { label: "LIVE", cls: "bg-red-500/15 text-red-400" },
  completed: { label: "COMPLETED", cls: "bg-emerald-500/15 text-emerald-300" },
  abandoned: { label: "ABANDONED", cls: "bg-amber-500/15 text-amber-300" },
  postponed: { label: "POSTPONED", cls: "bg-amber-500/15 text-amber-300" },
};

export function FixtureStatusBadge({ status }: { status: FixtureStatus }) {
  const s = STATUS[status];
  return (
    <span
      className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-black tracking-wider ${s.cls}`}
    >
      {s.label}
    </span>
  );
}

/** Horizontal-scroll wrapper so wide tables never overflow the page. */
export function TableScroll({ children }: { children: ReactNode }) {
  return <div className="mc-scroll overflow-x-auto">{children}</div>;
}

export function StandingsTable({ rows }: { rows: Standing[] }) {
  if (rows.length === 0) {
    return <p className="px-4 py-6 text-center text-sm text-slate-500">No teams yet.</p>;
  }
  const groups = [...new Set(rows.map((r) => r.group ?? ""))];

  return (
    <div className="space-y-4">
      {groups.map((g) => (
        <div key={g} className="mc-card overflow-hidden">
          {g && (
            <div className="border-b border-slate-800 px-4 py-2 text-xs font-black uppercase tracking-wider text-emerald-400">
              Group {g}
            </div>
          )}
          <TableScroll>
            <table className="w-full min-w-[460px] text-sm">
              <thead className="bg-slate-900/60 text-[11px] uppercase tracking-wider text-slate-400">
                <tr>
                  <th className="px-3 py-2 text-left font-bold">Team</th>
                  {["P", "W", "L", "T", "NR", "Pts"].map((h) => (
                    <th key={h} className="px-2 py-2 text-right font-bold">
                      {h}
                    </th>
                  ))}
                  <th className="px-3 py-2 text-right font-bold">NRR</th>
                </tr>
              </thead>
              <tbody>
                {rows
                  .filter((r) => (r.group ?? "") === g)
                  .map((r, i) => (
                    <tr key={r.teamId} className="border-t border-slate-800/70">
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2">
                          <span className="w-4 text-xs text-slate-600">{i + 1}</span>
                          <TeamLogo name={r.team} size={22} />
                          <span className="truncate font-semibold">{r.team}</span>
                        </div>
                      </td>
                      <td className="px-2 py-2 text-right text-slate-300">{r.played}</td>
                      <td className="px-2 py-2 text-right text-slate-300">{r.won}</td>
                      <td className="px-2 py-2 text-right text-slate-300">{r.lost}</td>
                      <td className="px-2 py-2 text-right text-slate-300">{r.tied}</td>
                      <td className="px-2 py-2 text-right text-slate-300">{r.noResult}</td>
                      <td className="px-2 py-2 text-right font-black text-emerald-400">
                        {r.points}
                      </td>
                      <td className="px-3 py-2 text-right text-slate-300">
                        {r.played > 0 ? (r.nrr >= 0 ? "+" : "") + r.nrr.toFixed(3) : "—"}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </TableScroll>
        </div>
      ))}
    </div>
  );
}

/** One fixture row: teams, meta, status and the action that opens scoring. */
export function FixtureRow({
  fixture,
  teamName,
  action,
}: {
  fixture: Fixture;
  teamName: (id: string | null, placeholder?: string) => string;
  action?: ReactNode;
}) {
  const a = teamName(fixture.teamAId, fixture.teamAPlaceholder);
  const b = teamName(fixture.teamBId, fixture.teamBPlaceholder);
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2 px-3 py-2.5 sm:px-4">
      <span className="w-8 shrink-0 text-[11px] font-black text-slate-600">
        #{fixture.number}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <TeamLogo name={a} size={20} />
          <span className="truncate text-sm font-bold">{a}</span>
          <span className="text-[10px] font-black text-slate-600">v</span>
          <TeamLogo name={b} size={20} />
          <span className="truncate text-sm font-bold">{b}</span>
        </div>
        <p className="mt-0.5 truncate text-[11px] text-slate-500">
          {fixture.round}
          {fixture.date ? ` · ${fixture.date}` : ""}
          {fixture.time ? ` ${fixture.time}` : ""}
          {fixture.venue ? ` · ${fixture.venue}` : ""}
          {fixture.resultText ? ` · ${fixture.resultText}` : ""}
        </p>
      </div>
      <FixtureStatusBadge status={fixture.status} />
      {action}
    </div>
  );
}

export function StatCard({
  label,
  name,
  detail,
}: {
  label: string;
  name?: string;
  detail?: string;
}) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 px-3 py-2.5">
      <p className="text-[10px] font-black uppercase tracking-wider text-slate-500">{label}</p>
      <p className="truncate text-sm font-black">{name ?? "—"}</p>
      {detail && <p className="truncate text-[11px] text-slate-400">{detail}</p>}
    </div>
  );
}
