import React from 'react';
import { AppConfig } from '../types/apk';
import { ShieldCheck, Smartphone, Globe, Layers, Settings, Sparkles, AlertCircle } from 'lucide-react';

interface AppConfigSectionProps {
  config: AppConfig;
  onChange: (updated: Partial<AppConfig>) => void;
}

export const AppConfigSection: React.FC<AppConfigSectionProps> = ({ config, onChange }) => {
  // Validate package name
  const isPackageValid = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(config.packageName);

  const handlePackageBlur = () => {
    // Sanitize package name if needed
    let sanitized = config.packageName.toLowerCase().replace(/[^a-z0-9_.]/g, '');
    if (!sanitized.includes('.')) {
      sanitized = `com.${config.companyName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'app'}.${sanitized || 'main'}`;
    }
    onChange({ packageName: sanitized });
  };

  const handlePermissionToggle = (key: keyof AppConfig['permissions']) => {
    onChange({
      permissions: {
        ...config.permissions,
        [key]: !config.permissions[key],
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* 1. App Identity Card */}
      <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-bold text-white">App Branding & Identity</h3>
          <span className="text-slate-500">·</span>
          <span className="text-xs text-slate-400">Android System Details</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Application Name
            </label>
            <input
              type="text"
              value={config.appName}
              onChange={(e) => {
                const name = e.target.value;
                const autoPkg = name
                  ? `com.${(config.companyName || 'company').toLowerCase().replace(/[^a-z0-9]/g, '')}.${name.toLowerCase().replace(/[^a-z0-9]/g, '')}`
                  : config.packageName;
                onChange({ appName: name, packageName: autoPkg });
              }}
              placeholder="e.g. Cyber Runner 2099"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Displayed on Android home screen and App Drawer</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>Package Name (Application ID)</span>
              {!isPackageValid && (
                <span className="text-[10px] text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Needs dot (com.x.y)
                </span>
              )}
            </label>
            <input
              type="text"
              value={config.packageName}
              onChange={(e) => onChange({ packageName: e.target.value })}
              onBlur={handlePackageBlur}
              placeholder="com.company.appname"
              className={`w-full px-3 py-2 bg-slate-950 border rounded-lg text-sm font-mono text-white focus:outline-none ${
                isPackageValid ? 'border-slate-800 focus:border-emerald-500' : 'border-rose-500'
              }`}
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Unique reverse-DNS identifier in Google Play</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Version Name
            </label>
            <input
              type="text"
              value={config.versionName}
              onChange={(e) => onChange({ versionName: e.target.value })}
              placeholder="1.0.0"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Visible release string</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Version Code
            </label>
            <input
              type="number"
              value={config.versionCode}
              onChange={(e) => onChange({ versionCode: parseInt(e.target.value, 10) || 1 })}
              min={1}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Integer incremented per build</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Screen Orientation
            </label>
            <select
              value={config.orientation}
              onChange={(e) => onChange({ orientation: e.target.value as any })}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="portrait">Portrait Only</option>
              <option value="landscape">Landscape (Games / Media)</option>
              <option value="sensor">Auto / Sensor Rotate</option>
            </select>
            <span className="text-[11px] text-slate-500 mt-1 block">Locked or auto-rotates</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Company / Developer Name
            </label>
            <input
              type="text"
              value={config.companyName}
              onChange={(e) => onChange({ companyName: e.target.value })}
              placeholder="e.g. Acme Interactive LLC"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Used in APK certificate signature & metadata</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Custom Deep Link Scheme
            </label>
            <input
              type="text"
              value={config.deepLinkScheme}
              onChange={(e) => onChange({ deepLinkScheme: e.target.value })}
              placeholder="e.g. myapp (allows myapp://path)"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">Allows launching this app from external web links</span>
          </div>
        </div>
      </div>

      {/* 2. WebView Engine Features */}
      <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
          <Settings className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-bold text-white">Native Android Engine Settings</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="flex items-start gap-3 p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg cursor-pointer hover:border-slate-700">
            <input
              type="checkbox"
              checked={config.fullscreen}
              onChange={(e) => onChange({ fullscreen: e.target.checked })}
              className="mt-0.5 rounded text-emerald-500 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-semibold text-white block">Immersive Fullscreen Mode</span>
              <span className="text-[11px] text-slate-400">Hides Android status bar and navigation buttons (ideal for games)</span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg cursor-pointer hover:border-slate-700">
            <input
              type="checkbox"
              checked={config.enableHardwareAcceleration}
              onChange={(e) => onChange({ enableHardwareAcceleration: e.target.checked })}
              className="mt-0.5 rounded text-emerald-500 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-semibold text-white block">Hardware Acceleration & WebGL</span>
              <span className="text-[11px] text-slate-400">GPU rendering enabled for high FPS Canvas 2D and 3D graphics</span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg cursor-pointer hover:border-slate-700">
            <input
              type="checkbox"
              checked={config.enablePullToRefresh}
              onChange={(e) => onChange({ enablePullToRefresh: e.target.checked })}
              className="mt-0.5 rounded text-emerald-500 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-semibold text-white block">Pull-to-Refresh Gesture</span>
              <span className="text-[11px] text-slate-400">Swipe down from top to reload the web application</span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg cursor-pointer hover:border-slate-700">
            <input
              type="checkbox"
              checked={config.enableCleartextTraffic}
              onChange={(e) => onChange({ enableCleartextTraffic: e.target.checked })}
              className="mt-0.5 rounded text-emerald-500 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-semibold text-white block">Permit Cleartext HTTP Traffic</span>
              <span className="text-[11px] text-slate-400">Allows loading non-HTTPS resources and local endpoints</span>
            </div>
          </label>
        </div>
      </div>

      {/* 3. Android Permissions Matrix */}
      <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Android Manifest Permissions</h3>
          </div>
          <span className="text-xs text-slate-400">
            {Object.values(config.permissions).filter(Boolean).length} enabled
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {[
            { key: 'internet', name: 'INTERNET', desc: 'Network & API calls' },
            { key: 'networkState', name: 'NETWORK_STATE', desc: 'Check online/offline' },
            { key: 'camera', name: 'CAMERA', desc: 'Barcode, webcam, photos' },
            { key: 'storage', name: 'STORAGE', desc: 'Save & read files' },
            { key: 'audio', name: 'RECORD_AUDIO', desc: 'Microphone & voice' },
            { key: 'location', name: 'LOCATION', desc: 'GPS geolocation' },
            { key: 'vibrate', name: 'VIBRATE', desc: 'Haptic feedback' },
            { key: 'wakeLock', name: 'WAKE_LOCK', desc: 'Keep screen awake' },
            { key: 'notifications', name: 'POST_NOTIFICATIONS', desc: 'Push notifications' },
          ].map((perm) => (
            <label
              key={perm.key}
              className={`flex items-start gap-2.5 p-2.5 rounded-lg border transition-all cursor-pointer ${
                config.permissions[perm.key as keyof AppConfig['permissions']]
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-slate-700'
              }`}
            >
              <input
                type="checkbox"
                checked={config.permissions[perm.key as keyof AppConfig['permissions']]}
                onChange={() => handlePermissionToggle(perm.key as keyof AppConfig['permissions'])}
                className="mt-0.5 rounded text-emerald-500 focus:ring-emerald-500"
              />
              <div className="min-w-0">
                <span className="font-mono text-xs font-semibold block text-slate-200 truncate">
                  {perm.name}
                </span>
                <span className="text-[11px] text-slate-400 block truncate">{perm.desc}</span>
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};
