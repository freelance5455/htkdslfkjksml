import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

export const MiningPerformanceChart: React.FC = () => {
  const chartRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    // Clear previous render
    d3.select(chartRef.current).selectAll('*').remove();

    const data = [
      { time: '00:00', hashRate: 120, power: 80, profit: 40 },
      { time: '04:00', hashRate: 140, power: 90, profit: 50 },
      { time: '08:00', hashRate: 160, power: 105, profit: 55 },
      { time: '12:00', hashRate: 155, power: 100, profit: 55 },
      { time: '16:00', hashRate: 180, power: 120, profit: 60 },
      { time: '20:00', hashRate: 210, power: 135, profit: 75 },
      { time: '24:00', hashRate: 250, power: 150, profit: 100 },
    ];

    const margin = { top: 20, right: 30, bottom: 30, left: 40 };
    const width = 600 - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const svg = d3.select(chartRef.current)
      .attr('viewBox', `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3.scalePoint()
      .domain(data.map(d => d.time))
      .range([0, width])
      .padding(0.5);

    const y = d3.scaleLinear()
      .domain([0, 300])
      .range([height, 0]);

    // X Axis
    svg.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .attr('color', '#94a3b8')
      .selectAll('text')
      .style('font-family', 'monospace')
      .style('font-size', '10px');

    // Y Axis
    svg.append('g')
      .call(d3.axisLeft(y).ticks(5))
      .attr('color', '#94a3b8')
      .selectAll('text')
      .style('font-family', 'monospace')
      .style('font-size', '10px');

    // Hash Rate Line (Amber)
    const lineHashRate = d3.line<any>()
      .x(d => x(d.time) as number)
      .y(d => y(d.hashRate))
      .curve(d3.curveMonotoneX);

    svg.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#f59e0b')
      .attr('stroke-width', 2)
      .attr('d', lineHashRate);

    // Power Line (Rose)
    const linePower = d3.line<any>()
      .x(d => x(d.time) as number)
      .y(d => y(d.power))
      .curve(d3.curveMonotoneX);

    svg.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#e11d48')
      .attr('stroke-width', 2)
      .attr('d', linePower);

    // Profit Line (Emerald)
    const lineProfit = d3.line<any>()
      .x(d => x(d.time) as number)
      .y(d => y(d.profit))
      .curve(d3.curveMonotoneX);

    svg.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#10b981')
      .attr('stroke-width', 3)
      .attr('d', lineProfit);

    // Legend
    const legend = svg.append('g').attr('transform', `translate(${width - 120}, 0)`);
    
    legend.append('circle').attr('cx', 0).attr('cy', 0).attr('r', 4).style('fill', '#f59e0b');
    legend.append('text').attr('x', 10).attr('y', 4).text('Hash Rate').style('font-size', '10px').attr('fill', '#f59e0b');

    legend.append('circle').attr('cx', 0).attr('cy', 15).attr('r', 4).style('fill', '#e11d48');
    legend.append('text').attr('x', 10).attr('y', 19).text('Power').style('font-size', '10px').attr('fill', '#e11d48');

    legend.append('circle').attr('cx', 0).attr('cy', 30).attr('r', 4).style('fill', '#10b981');
    legend.append('text').attr('x', 10).attr('y', 34).text('Profit Margin').style('font-size', '10px').attr('fill', '#10b981');

  }, []);

  return (
    <div className="bg-slate-900 border-2 border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-amber-200 uppercase tracking-wider">Mining Performance (D3.js)</h3>
        <span className="text-[10px] font-mono bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/40">
          Owner Metrics
        </span>
      </div>
      <p className="text-xs text-slate-400">
        Correlation between active hash rates (TH/s), power consumption (kW), and resulting net profit margins (%).
      </p>
      <div className="w-full overflow-hidden bg-slate-950 rounded-2xl border border-slate-800 p-2">
        <svg ref={chartRef} className="w-full h-auto" />
      </div>
    </div>
  );
};
