/**
 * GODEX AI STUDIO-STYLE CHAT EXPERIENCE
 * Ultra-smooth, responsive, calm, and intelligent motion design for GODEX Chat.
 * Features:
 * - Refined obsidian/graphite visual hierarchy with high-contrast typography
 * - Markdown & Code block renderer with copy feedback, line numbers, table support, and expand/collapse
 * - Grounded workspace context badge (only shown when genuine source references exist)
 * - Safe high-level thinking / processing indicator with truthful state transitions
 * - Real OperationManager & EventBus lifecycle phase transitions for engineering operations
 * - Intelligent auto-scroll with "Jump to latest" floating pill
 * - Multiline auto-resizing composer with Enter/Shift+Enter keyboard accessibility
 * - Error recovery & retry states
 * - Accessible prefers-reduced-motion support
 * - True multi-viewport responsiveness (390px mobile, 768px tablet, 1280px+ desktop)
 */

import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Check, 
  Copy, 
  ChevronDown, 
  Play, 
  Layers, 
  FileCode, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  ShieldCheck, 
  Zap, 
  Activity, 
  Code, 
  RotateCcw, 
  Cpu, 
  ArrowDown,
  RefreshCw,
  Terminal,
  FileText,
  Compass,
  CornerDownLeft,
  Paperclip,
  Image as ImageIcon,
  X,
  UploadCloud,
  File as FileIcon,
  Download,
  Square,
  Clock,
  Wrench,
  Search
} from 'lucide-react';
import { ChatMessage, ChatAttachment, TaskState, ExecutionMode, ActivityLogItem, VerificationReport } from '../types';
import { GodexControlPlane } from '../godex/godexControlPlane';
import { OperationState, OperationStatus } from '../godex/operationState';
import { GodexEventBus, GodexEvent } from '../godex/godexEventBus';
import { GodexLogo } from './GodexLogo';

export interface GodexChatViewProps {
  messages: ChatMessage[];
  taskState: TaskState;
  executionMode: ExecutionMode;
  activityLogs: ActivityLogItem[];
  verificationReport?: VerificationReport | null;
  isRunning?: boolean;
  onSendMessage: (prompt: string, attachments?: ChatAttachment[]) => void;
  onClearChat?: () => void;
  onToggleExecutionMode?: () => void;
  onSelectFile?: (path: string) => void;
  onCancelOperation?: () => void;
}

// -------------------------------------------------------------
// Safe Reduced Motion Hook (Works in any sandbox/iframe)
// -------------------------------------------------------------
function useSafeReducedMotion(): boolean {
  const [prefersReduced, setPrefersReduced] = useState(false);
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.matchMedia) {
        const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
        setPrefersReduced(mediaQuery.matches);
        const handler = (e: MediaQueryListEvent) => setPrefersReduced(e.matches);
        if (mediaQuery.addEventListener) {
          mediaQuery.addEventListener('change', handler);
          return () => mediaQuery.removeEventListener('change', handler);
        }
      }
    } catch {
      // Fallback
    }
  }, []);
  return prefersReduced;
}

// -------------------------------------------------------------
// Robust Clipboard Helper
// -------------------------------------------------------------
async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fallback to execCommand
  }
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch (err) {
    console.error('[GODEX] Copy fallback failed:', err);
    return false;
  }
}

// -------------------------------------------------------------
// Markdown & Code Block Formatter
// -------------------------------------------------------------
interface FormattedMessageProps {
  text: string;
  onSelectFile?: (path: string) => void;
  isStreaming?: boolean;
}

const CodeBlock: React.FC<{ code: string; language: string; onSelectFile?: (path: string) => void }> = ({
  code,
  language,
  onSelectFile
}) => {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const lines = code.trim().split('\n');
  const shouldTruncate = lines.length > 22;
  const displayedLines = shouldTruncate && !isExpanded ? lines.slice(0, 18) : lines;

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const success = await copyToClipboard(code);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="my-2.5 rounded-xl border border-[#1B2436] bg-[#07090F] overflow-hidden shadow-md text-xs font-mono select-text transition-all">
      {/* Code Block Header */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#0B0F19] border-b border-[#182030] text-[11px] text-neutral-400">
        <div className="flex items-center gap-1.5">
          <Code className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
          <span className="font-semibold uppercase tracking-wider text-neutral-300">
            {language || 'typescript'}
          </span>
          <span className="text-neutral-600">·</span>
          <span className="text-neutral-500">{lines.length} lines</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#121826] hover:bg-[#1A2336] text-neutral-300 hover:text-white border border-[#202C42] transition-all active:scale-95 focus:outline-none focus:ring-1 focus:ring-cyan-500/40 cursor-pointer"
            title="Copy code to clipboard"
            aria-label="Copy code to clipboard"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" aria-hidden="true" />
                <span className="text-emerald-300 font-semibold text-[10px]">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-neutral-400" aria-hidden="true" />
                <span className="text-[10px]">Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Code Stream with Line Numbers */}
      <div className="p-3 overflow-x-auto text-[11px] leading-relaxed text-neutral-200 font-mono no-scrollbar">
        <pre className="whitespace-pre">
          {displayedLines.map((line, idx) => (
            <div key={idx} className="table-row">
              <span className="table-cell select-none pr-3 text-right text-neutral-600 font-mono text-[10px] w-6">
                {idx + 1}
              </span>
              <span className="table-cell text-neutral-200">
                {line || ' '}
              </span>
            </div>
          ))}
        </pre>
      </div>

      {/* Expand/Collapse Toggle if very long */}
      {shouldTruncate && (
        <div className="px-3 py-1 bg-[#090C14] border-t border-[#141B2A] flex items-center justify-between text-[10px] text-neutral-400">
          <span>{isExpanded ? 'Showing full file' : `Hidden ${lines.length - 18} lines`}</span>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-cyan-400 hover:underline flex items-center gap-0.5 font-semibold focus:outline-none cursor-pointer"
          >
            <span>{isExpanded ? 'Show less' : 'Expand full block'}</span>
            <ChevronDown className={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`} aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  );
};

const FormattedMessage: React.FC<FormattedMessageProps> = ({ text, onSelectFile, isStreaming }) => {
  // Parse code blocks vs regular text
  const parts = useMemo(() => {
    if (!text) return [];
    const codeBlockRegex = /```([a-zA-Z0-9_\-\.\/]*)\n([\s\S]*?)```/g;
    const segments: Array<{ type: 'text' | 'code'; content: string; language?: string }> = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        segments.push({
          type: 'text',
          content: text.slice(lastIndex, match.index)
        });
      }
      segments.push({
        type: 'code',
        language: match[1] || 'typescript',
        content: match[2] || ''
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      segments.push({
        type: 'text',
        content: text.slice(lastIndex)
      });
    }

    return segments;
  }, [text]);

  const renderInlineTokens = (raw: string) => {
    // Process bold (**text**), inline code (`code`), and file paths
    const tokenRegex = /(\*\*.*?\*\*|`.*?`)/g;
    const tokens = raw.split(tokenRegex);

    return tokens.map((token, i) => {
      if (token.startsWith('**') && token.endsWith('**')) {
        return <strong key={i} className="font-bold text-white">{token.slice(2, -2)}</strong>;
      }
      if (token.startsWith('`') && token.endsWith('`')) {
        const snippet = token.slice(1, -1);
        const isFilePath = snippet.includes('/') || snippet.endsWith('.ts') || snippet.endsWith('.tsx') || snippet.endsWith('.json') || snippet.endsWith('.css');
        return (
          <code
            key={i}
            onClick={() => isFilePath && onSelectFile?.(snippet)}
            className={`font-mono text-[11px] px-1.5 py-0.5 rounded mx-0.5 font-medium transition-all ${
              isFilePath && onSelectFile
                ? 'bg-[#121B2B] text-cyan-300 border border-cyan-800/60 hover:border-cyan-400 hover:text-cyan-200 cursor-pointer shadow-xs'
                : 'bg-[#101420] text-amber-200 border border-[#1D2538]'
            }`}
          >
            {snippet}
          </code>
        );
      }
      return token;
    });
  };

  const renderInlineMarkdown = (content: string) => {
    const lines = content.split('\n');

    return lines.map((line, lIdx) => {
      // Heading 3: ### Title
      if (line.startsWith('### ')) {
        return (
          <h4 key={lIdx} className="text-xs font-bold text-cyan-300 mt-2.5 mb-1 flex items-center gap-1.5 tracking-wide">
            <Sparkles className="w-3 h-3 text-cyan-400" aria-hidden="true" />
            <span>{line.slice(4)}</span>
          </h4>
        );
      }
      // Heading 2: ## Title
      if (line.startsWith('## ')) {
        return (
          <h3 key={lIdx} className="text-sm font-bold text-white mt-3 mb-1.5 tracking-wide border-b border-[#182132] pb-1">
            {line.slice(3)}
          </h3>
        );
      }
      // Heading 1: # Title
      if (line.startsWith('# ')) {
        return (
          <h2 key={lIdx} className="text-sm font-extrabold text-white mt-3.5 mb-2 tracking-wide">
            {line.slice(2)}
          </h2>
        );
      }
      // Bullet list item: - Item or * Item
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const itemText = line.trim().slice(2);
        return (
          <div key={lIdx} className="flex items-start gap-2 my-1 ml-1 text-neutral-200 leading-relaxed">
            <span className="text-cyan-400 shrink-0 text-xs mt-0.5">•</span>
            <span className="flex-1">{renderInlineTokens(itemText)}</span>
          </div>
        );
      }
      // Numbered list item: 1. Item
      const numMatch = line.trim().match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        return (
          <div key={lIdx} className="flex items-start gap-2 my-1 ml-1 text-neutral-200 leading-relaxed">
            <span className="text-cyan-400 font-mono text-[11px] font-bold shrink-0">{numMatch[1]}.</span>
            <span className="flex-1">{renderInlineTokens(numMatch[2])}</span>
          </div>
        );
      }
      // Empty line spacer
      if (!line.trim()) {
        return <div key={lIdx} className="h-2" />;
      }
      // Regular paragraph line
      return (
        <div key={lIdx} className="leading-relaxed my-0.5">
          {renderInlineTokens(line)}
        </div>
      );
    });
  };

  return (
    <div className="space-y-1 text-xs leading-relaxed font-sans text-neutral-200">
      {parts.map((seg, idx) => {
        if (seg.type === 'code') {
          return (
            <CodeBlock
              key={idx}
              code={seg.content}
              language={seg.language || 'typescript'}
              onSelectFile={onSelectFile}
            />
          );
        }
        return <div key={idx}>{renderInlineMarkdown(seg.content)}</div>;
      })}
      {isStreaming && (
        <span className="inline-block w-1.5 h-3.5 ml-1 bg-cyan-400 animate-pulse align-middle" aria-hidden="true" />
      )}
    </div>
  );
};

// -------------------------------------------------------------
// Lifecycle Stages for Real Engineering Operations
// -------------------------------------------------------------
const LIFECYCLE_STAGES: Array<{ key: OperationStatus; label: string; icon: any }> = [
  { key: 'RECEIVING', label: 'Receiving Request', icon: Bot },
  { key: 'PLANNING', label: 'Planning Task Graph', icon: Layers },
  { key: 'INSPECTING', label: 'Inspecting AST Symbols', icon: FileCode },
  { key: 'GENERATING', label: 'Synthesizing Solution', icon: Cpu },
  { key: 'EDITING', label: 'Applying Surgical Edits', icon: Code },
  { key: 'TESTING', label: 'Running Test Assertions', icon: Activity },
  { key: 'VERIFYING', label: '6-Pillar Evidence Matrix', icon: ShieldCheck }
];

const messageVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2 } }
};

export const GodexChatView: React.FC<GodexChatViewProps> = ({
  messages,
  taskState,
  executionMode,
  activityLogs,
  verificationReport,
  isRunning,
  onSendMessage,
  onClearChat,
  onToggleExecutionMode,
  onSelectFile,
  onCancelOperation
}) => {
  const [inputText, setInputText] = useState('');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [controlState, setControlState] = useState<OperationState>(() => GodexControlPlane.getInstance().getState());
  const [recentEvents, setRecentEvents] = useState<GodexEvent[]>([]);
  const [showLatestPill, setShowLatestPill] = useState(false);
  const [isNearBottom, setIsNearBottom] = useState(true);
  const [thinkingPhase, setThinkingPhase] = useState<'Understanding request…' | 'Checking workspace context…' | 'Preparing response…'>('Understanding request…');
  const [elapsedSeconds, setElapsedSeconds] = useState('0.0');

  const prefersReducedMotion = useSafeReducedMotion();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Subscribe to real control plane & EventBus
  useEffect(() => {
    const unsubCP = GodexControlPlane.getInstance().subscribe(state => {
      setControlState({ ...state });
    });

    const unsubBus = GodexEventBus.getInstance().subscribe(evt => {
      setRecentEvents(prev => [evt, ...prev.slice(0, 19)]);
    });

    return () => {
      unsubCP();
      unsubBus();
    };
  }, []);

  // Cycle high-level thinking status during active conversational or processing states
  useEffect(() => {
    if (taskState === 'ANALYZING' || taskState === 'PLANNING') {
      const t1 = setTimeout(() => setThinkingPhase('Checking workspace context…'), 600);
      const t2 = setTimeout(() => setThinkingPhase('Preparing response…'), 1200);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    } else {
      setThinkingPhase('Understanding request…');
    }
  }, [taskState]);

  const isWorking = useMemo(() => {
    if (isRunning) return true;
    const taskWorking = (taskState as string) !== 'IDLE' && (taskState as string) !== 'COMPLETED' && (taskState as string) !== 'FAILED' && (taskState as string) !== 'CANCELLED';
    const controlWorking = controlState.status !== 'IDLE' && controlState.status !== 'COMPLETED' && controlState.status !== 'FAILED' && controlState.status !== 'CANCELLED';
    return taskWorking || controlWorking;
  }, [isRunning, taskState, controlState.status]);

  // Live stopwatch timer during execution
  useEffect(() => {
    if (isWorking) {
      const start = Date.now();
      const timer = setInterval(() => {
        const diff = (Date.now() - start) / 1000;
        setElapsedSeconds(diff.toFixed(1));
      }, 100);
      return () => clearInterval(timer);
    } else {
      setElapsedSeconds('0.0');
    }
  }, [isWorking]);

  // Current active stage computation for REAL engineering operations
  const currentStage = useMemo(() => {
    const s = (controlState.status && controlState.status !== 'IDLE') ? controlState.status : (taskState as unknown as OperationStatus);
    if (!s || s === 'IDLE' || s === 'COMPLETED' || s === 'FAILED' || s === 'CANCELLED') return null;
    return LIFECYCLE_STAGES.find(st => st.key === s) || { key: s as any, label: s, icon: Cpu };
  }, [controlState.status, taskState]);

  // Pipeline 5-stage progress calculation
  const pipelineProgress = useMemo(() => {
    const s = controlState.status;
    const order: OperationStatus[] = ['RECEIVING', 'INSPECTING', 'PLANNING', 'GENERATING', 'EDITING', 'TESTING', 'VERIFYING', 'COMPLETED'];
    const curIdx = order.indexOf(s);
    
    return [
      { id: 'context', label: 'Context', completed: curIdx > 1, active: curIdx <= 1 && curIdx >= 0 },
      { id: 'plan', label: 'Plan Graph', completed: curIdx > 2, active: curIdx === 2 },
      { id: 'code', label: 'Synthesis', completed: curIdx > 4, active: curIdx === 3 || curIdx === 4 },
      { id: 'test', label: 'Validation', completed: curIdx > 5, active: curIdx === 5 },
      { id: 'verify', label: '6-Pillar Proof', completed: curIdx >= 7, active: curIdx === 6 },
    ];
  }, [controlState.status]);

  // Scroll detection handler
  const handleScroll = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distanceFromBottom < 80;
    setIsNearBottom(nearBottom);
    if (nearBottom && showLatestPill) {
      setShowLatestPill(false);
    }
  }, [showLatestPill]);

  // Smooth scroll to bottom
  const scrollToBottom = useCallback((smooth = true) => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth && !prefersReducedMotion ? 'smooth' : 'auto'
    });
    setShowLatestPill(false);
  }, [prefersReducedMotion]);

  // Follow stream if user was already near bottom
  useEffect(() => {
    if (isNearBottom) {
      scrollToBottom(false);
    } else if (messages.length > 0) {
      setShowLatestPill(true);
    }
  }, [messages, controlState.status, isNearBottom, scrollToBottom]);

  // Handle Copy Message
  const handleCopyMessage = async (msgId: string, text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopiedMsgId(msgId);
      setTimeout(() => setCopiedMsgId(null), 2000);
    }
  };

  // Process File Selection
  const processFiles = useCallback(async (files: FileList | File[]) => {
    const newAttachments: ChatAttachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImg = file.type.startsWith('image/');
      const attId = `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

      if (isImg) {
        const dataUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
        newAttachments.push({
          id: attId,
          name: file.name,
          type: file.type || 'image/png',
          size: file.size,
          dataUrl,
          file,
          status: 'ready'
        });
      } else {
        const textContent = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsText(file);
        });
        newAttachments.push({
          id: attId,
          name: file.name,
          type: file.type || 'text/plain',
          size: file.size,
          textContent,
          file,
          status: 'ready'
        });
      }
    }
    setAttachments(prev => [...prev, ...newAttachments]);
  }, []);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  // Drag & drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  // Handle Form Submit
  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && attachments.length === 0) || isWorking) return;
    const promptToSend = inputText.trim();
    const attsToSend = attachments.length > 0 ? [...attachments] : undefined;
    onSendMessage(promptToSend, attsToSend);
    setInputText('');
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    setTimeout(() => scrollToBottom(true), 60);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);
    const target = e.target;
    target.style.height = 'auto';
    target.style.height = `${Math.min(Math.max(target.scrollHeight, 38), 160)}px`;
  };

  const handleSelectSamplePrompt = (text: string) => {
    if (isWorking) return;
    setInputText(text);
    if (textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(Math.max(textareaRef.current.scrollHeight, 38), 160)}px`;
    }
  };

  // Structured Empty State Categories
  const emptyStateCategories = [
    {
      title: 'Architecture & Context',
      icon: Compass,
      color: 'text-indigo-400',
      prompts: [
        { label: 'Explain ControlPlane architecture', text: 'What is GodexControlPlane and how does it work?' },
        { label: 'Locate Chat view implementation', text: 'Which file contains GodexChatView?' }
      ]
    },
    {
      title: 'Conversational & Advice',
      icon: Sparkles,
      color: 'text-cyan-400',
      prompts: [
        { label: 'Suggest Chat UI improvements', text: 'Suggest three ways to improve the Chat UI.' },
        { label: 'Advice on optimizing state', text: 'How could I improve the GODEX Chat UI?' }
      ]
    },
    {
      title: 'Engineering Directives',
      icon: Code,
      color: 'text-emerald-400',
      prompts: [
        { label: 'Polish Chat UI and composer', text: 'Improve the GODEX Chat UI. Make the composer smoother, improve message rendering, and make the overall chat experience more polished.' },
        { label: 'Fix empty state view', text: 'Fix the GODEX Chat empty state.' }
      ]
    }
  ];

  // Motion variants with reduced motion support
  const messageVariants = {
    hidden: { opacity: 0, y: prefersReducedMotion ? 0 : 6 },
    visible: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.2, ease: 'easeOut' } 
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div 
      id="godex-chat-shell"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="flex-1 h-full flex flex-col bg-[#07090D] border-l border-[#151B27] overflow-hidden select-none relative font-sans"
    >
      {/* Drag & Drop Visual Overlay */}
      <AnimatePresence>
        {isDraggingOver && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-[#07090D]/90 backdrop-blur-xs border-2 border-dashed border-cyan-500 flex flex-col items-center justify-center p-6 text-center"
          >
            <div className="p-4 rounded-2xl bg-[#0D1424] border border-cyan-500/50 shadow-2xl mb-3">
              <UploadCloud className="w-10 h-10 text-cyan-400 animate-bounce" aria-hidden="true" />
            </div>
            <h4 className="text-base font-bold text-white font-mono">Drop files or images here</h4>
            <p className="text-xs text-neutral-400 mt-1">Attachments will be included with your prompt for context</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Chat Bar */}
      <div className="h-11 border-b border-[#151B27] bg-[#090C12] px-3 sm:px-4 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-2">
          <GodexLogo size={20} showText={false} />
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-xs font-bold text-white tracking-wide">GODEX AI</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#0F1420] text-cyan-300 border border-[#1C2538] font-bold">
              STUDIO
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Autopilot toggle */}
          {onToggleExecutionMode && (
            <button
              onClick={onToggleExecutionMode}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-mono font-medium border transition-all active:scale-98 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 cursor-pointer ${
                executionMode === 'autopilot'
                  ? 'bg-[#151E2E] border-indigo-500/50 text-indigo-300 shadow-xs'
                  : 'bg-[#0A0D15] border-[#182132] text-neutral-400 hover:text-neutral-200'
              }`}
              title="Toggle Autopilot / Copilot"
              aria-label="Toggle Autopilot / Copilot"
            >
              <Zap className="w-3 h-3 text-indigo-400" aria-hidden="true" />
              <span>{executionMode === 'autopilot' ? 'AUTOPILOT' : 'COPILOT'}</span>
            </button>
          )}

          {onClearChat && (
            <button
              onClick={onClearChat}
              className="p-1.5 rounded-md hover:bg-[#121826] text-neutral-400 hover:text-neutral-200 transition-colors active:scale-95 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 cursor-pointer"
              title="New Chat Session"
              aria-label="Reset Chat Session"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          )}
        </div>
      </div>

      {/* Messages Scroll Container */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3.5 select-text relative scroll-smooth no-scrollbar"
      >
        {messages.length === 0 ? (
          <div 
            id="agent-chat-empty-state"
            role="status"
            aria-live="polite"
            className="h-full flex flex-col items-center justify-center text-center p-4 sm:p-6 space-y-4 max-w-2xl mx-auto"
          >
            <div className="p-3 rounded-2xl bg-[#0C1018] border border-[#1A2438] shadow-xl">
              <GodexLogo size={32} showText={false} />
            </div>

            <div className="space-y-1.5 flex flex-col items-center">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-800/70 text-emerald-300 text-[10px] font-mono font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" aria-hidden="true" />
                <span>AI Operating System Active</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white tracking-wide font-mono">
                GODEX Autonomous AI Engineering Studio
              </h3>
              <p className="text-xs text-neutral-400 max-w-md leading-relaxed font-sans">
                Grounded in AST codebase symbols with 6-pillar verification. Ask architecture questions, request engineering advice, or issue direct implementation instructions.
              </p>
            </div>

            {/* Categorized Quick Starters */}
            <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 text-left" role="region" aria-label="Sample Prompts">
              {emptyStateCategories.map((cat, catIdx) => {
                const CatIcon = cat.icon;
                return (
                  <div key={catIdx} className="p-3 rounded-xl bg-[#090C13] border border-[#151D2C] space-y-2">
                    <div className="flex items-center gap-1.5 font-mono text-[10px] font-bold text-neutral-300">
                      <CatIcon className={`w-3.5 h-3.5 ${cat.color}`} aria-hidden="true" />
                      <span>{cat.title}</span>
                    </div>
                    <div className="space-y-1.5">
                      {cat.prompts.map((p, pIdx) => (
                        <button
                          key={pIdx}
                          onClick={() => handleSelectSamplePrompt(p.text)}
                          className="w-full text-left p-2 rounded-lg bg-[#0D121D] hover:bg-[#141C2B] border border-[#1A2438] hover:border-cyan-500/50 text-neutral-300 hover:text-white text-[11px] leading-snug transition-all flex items-center justify-between group active:scale-98 font-sans focus:outline-none focus:ring-1 focus:ring-cyan-500/40 cursor-pointer"
                          aria-label={`Select prompt: ${p.label}`}
                        >
                          <span className="truncate pr-1">{p.label}</span>
                          <CornerDownLeft className="w-3 h-3 text-neutral-500 group-hover:text-cyan-400 transition-colors shrink-0" aria-hidden="true" />
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isUser = msg.sender === 'user';
            const isCopied = copiedMsgId === msg.id;

            return (
              <motion.div
                key={msg.id ? `${msg.id}-${idx}` : `msg-${idx}`}
                variants={messageVariants as any}
                initial="hidden"
                animate="visible"
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-6 h-6 rounded-lg bg-[#0C1018] border border-[#192234] flex items-center justify-center text-indigo-400 shrink-0 mt-0.5 shadow-xs">
                    <Bot className="w-3.5 h-3.5" aria-hidden="true" />
                  </div>
                )}

                <div className={`space-y-1.5 max-w-[92%] sm:max-w-[84%] ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`p-3.5 rounded-2xl text-xs leading-relaxed transition-all ${
                      isUser
                        ? 'bg-[#121927] border border-[#22314E] text-neutral-100 rounded-br-xs font-sans shadow-sm font-normal'
                        : 'bg-[#0B0E16] border border-[#172032] text-neutral-200 rounded-bl-xs shadow-sm font-sans'
                    }`}
                  >
                    {msg.isClarification && (
                      <div className="flex items-center gap-1.5 text-[10px] text-amber-400 font-mono mb-2 pb-1.5 border-b border-[#1C2538]">
                        <HelpCircle className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
                        <span className="font-bold tracking-wide">REQUIREMENT CLARIFICATION</span>
                      </div>
                    )}

                    {/* Attached files preview in User message */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="mb-2.5 pb-2 border-b border-[#1E293B] flex flex-wrap gap-2">
                        {msg.attachments.map((att) => (
                          <div
                            key={att.id}
                            className="p-1.5 rounded-lg bg-[#0A0E18] border border-[#1C273C] flex items-center gap-2 max-w-[200px]"
                          >
                            {att.dataUrl ? (
                              <img
                                src={att.dataUrl}
                                alt={att.name}
                                className="w-7 h-7 rounded object-cover border border-[#233148] shrink-0"
                              />
                            ) : (
                              <div className="w-7 h-7 rounded bg-[#101726] border border-[#1D2940] flex items-center justify-center shrink-0 text-cyan-400">
                                <FileText className="w-3.5 h-3.5" aria-hidden="true" />
                              </div>
                            )}
                            <div className="overflow-hidden text-[10px]">
                              <p className="font-medium text-neutral-200 truncate">{att.name}</p>
                              <p className="text-neutral-500 font-mono text-[9px]">{formatFileSize(att.size)}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    <FormattedMessage
                      text={msg.text}
                      onSelectFile={onSelectFile}
                      isStreaming={msg.status === 'thinking'}
                    />

                    {/* Sources / Grounded References (truthful indicator) */}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-[#151C2C] flex flex-wrap gap-1.5 items-center">
                        <span className="text-[9px] font-mono text-cyan-400/90 mr-1 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" aria-hidden="true" />
                          Grounded in workspace context:
                        </span>
                        {msg.sources.slice(0, 4).map((src, si) => (
                          <button
                            key={si}
                            onClick={() => onSelectFile?.(src.path)}
                            className="px-1.5 py-0.5 rounded bg-[#07090F] hover:bg-[#121826] text-cyan-300 text-[10px] font-mono border border-[#182132] hover:border-cyan-500/50 flex items-center gap-1 transition-all focus:outline-none focus:ring-1 focus:ring-cyan-500/40 cursor-pointer"
                          >
                            <span>{src.path.split('/').pop()}</span>
                            {src.line ? <span className="text-neutral-500">:{src.line}</span> : null}
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Message Timestamp & Action Bar */}
                    <div className="mt-2 flex items-center justify-between gap-2 text-[9px] text-neutral-500 font-mono pt-1.5 border-t border-[#121724]">
                      <div className="flex items-center gap-2">
                        {msg.status === 'done' && msg.responseType === 'engineering_action' && (
                          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                            <CheckCircle2 className="w-2.5 h-2.5" aria-hidden="true" />
                            <span>Verified</span>
                          </span>
                        )}
                        {msg.status === 'error' && (
                          <div className="flex items-center gap-2">
                            <span className="flex items-center gap-1 text-rose-400 font-semibold">
                              <AlertCircle className="w-2.5 h-2.5" aria-hidden="true" />
                              <span>Execution Stopped</span>
                            </span>
                            <button
                              onClick={() => {
                                const lastUserMsg = [...messages].reverse().find(m => m.sender === 'user');
                                if (lastUserMsg) onSendMessage(lastUserMsg.text);
                              }}
                              className="flex items-center gap-1 px-1.5 py-0.2 rounded bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/60 text-[9px] transition-colors focus:outline-none cursor-pointer"
                            >
                              <RefreshCw className="w-2.5 h-2.5" aria-hidden="true" />
                              <span>Retry</span>
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Regenerate Button */}
                        {!isUser && msg.status === 'done' && (
                          <button
                            onClick={() => {
                              const precedingUserMsg = [...messages.slice(0, idx)].reverse().find(m => m.sender === 'user');
                              if (precedingUserMsg) {
                                onSendMessage(precedingUserMsg.text);
                              }
                            }}
                            className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-[#141C2C] text-neutral-400 hover:text-neutral-200 transition-colors focus:outline-none cursor-pointer"
                            title="Regenerate response"
                            aria-label="Regenerate response"
                          >
                            <RefreshCw className="w-2.5 h-2.5" aria-hidden="true" />
                            <span className="text-[9px]">Regenerate</span>
                          </button>
                        )}

                        {/* Copy Full Message Button */}
                        {!isUser && msg.text && (
                          <button
                            onClick={() => handleCopyMessage(msg.id, msg.text)}
                            className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-[#141C2C] text-neutral-400 hover:text-neutral-200 transition-colors focus:outline-none cursor-pointer"
                            title="Copy response"
                            aria-label="Copy response text"
                          >
                            {isCopied ? (
                              <>
                                <Check className="w-2.5 h-2.5 text-emerald-400" aria-hidden="true" />
                                <span className="text-emerald-400 text-[9px]">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-2.5 h-2.5" aria-hidden="true" />
                                <span className="text-[9px]">Copy</span>
                              </>
                            )}
                          </button>
                        )}

                        <span>
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {isUser && (
                  <div className="w-6 h-6 rounded-lg bg-[#111726] border border-[#1F2A3E] flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                    <span className="font-mono font-bold text-[10px]">U</span>
                  </div>
                )}
              </motion.div>
            );
          })
        )}

        {/* Live Autonomous Working / Pipeline Execution State */}
        {isWorking && (
          <motion.div
            initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 6 }}
            animate={prefersReducedMotion ? { opacity: 1 } : { opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-2xl bg-[#090D17] border border-cyan-500/30 text-xs shadow-2xl p-3 sm:p-3.5 space-y-2.5 font-sans overflow-hidden relative"
          >
            {/* Ambient Glow */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

            {/* Header: Identity, Live Animated Working Indicator & Stop Button */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                {/* Subtle Animated 3-dot pulse indicator */}
                <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#0E1524] border border-[#1C273C]">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]" style={{ animationDelay: '180ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]" style={{ animationDelay: '360ms' }} />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white font-mono tracking-wider text-xs">
                    GODEX AGENT
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-950/80 text-indigo-300 border border-indigo-700/50 font-mono">
                    {controlState.currentAgentId ? `[${controlState.currentAgentId.toUpperCase()}]` : '[ORCHESTRATOR]'}
                  </span>
                </div>
              </div>

              {/* Right Controls: Elapsed Timer + Accessible Stop Button */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-[11px] font-mono text-neutral-300 bg-[#0C121F] px-2 py-1 rounded-md border border-[#192438]">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  <span>{elapsedSeconds}s</span>
                </div>

                {onCancelOperation && (
                  <button
                    type="button"
                    onClick={onCancelOperation}
                    className="min-h-[36px] sm:min-h-[32px] flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-950/70 hover:bg-rose-900/90 text-rose-300 border border-rose-700/70 font-mono text-[11px] font-semibold transition-all active:scale-95 cursor-pointer shadow-xs focus:outline-none focus:ring-1 focus:ring-rose-500/50"
                    title="Stop active execution"
                    aria-label="Stop agent execution"
                  >
                    <Square className="w-2.5 h-2.5 fill-rose-400 text-rose-400" />
                    <span>Stop</span>
                  </button>
                )}
              </div>
            </div>

            {/* Stage Description / Action Headline */}
            <div className="flex items-center gap-2 text-neutral-200">
              <div className="w-5 h-5 rounded-md bg-cyan-950/80 border border-cyan-700/60 flex items-center justify-center text-cyan-400 shrink-0">
                {currentStage ? <currentStage.icon className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 animate-pulse" />}
              </div>
              <div className="font-medium text-xs text-cyan-200 flex-1 truncate">
                {controlState.operationId 
                  ? (currentStage?.label ? `${currentStage.label}…` : 'Working on your request…')
                  : (thinkingPhase || 'Working on your request…')}
              </div>
            </div>

            {/* Real Pipeline Progression Step Tracker (if engineering action) */}
            {controlState.operationId && (
              <div className="grid grid-cols-5 gap-1 pt-1 border-t border-[#131C2D]">
                {pipelineProgress.map((step) => (
                  <div
                    key={step.id}
                    className={`flex flex-col items-center gap-1 p-1 sm:p-1.5 rounded-lg text-center transition-all ${
                      step.active
                        ? 'bg-cyan-950/60 border border-cyan-500/50 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.15)]'
                        : step.completed
                        ? 'bg-[#0E1524] border border-emerald-900/60 text-emerald-400'
                        : 'bg-[#0A0E18] border border-[#141B2A] text-neutral-600'
                    }`}
                  >
                    <div className="flex items-center justify-center w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full text-[9px] font-mono font-bold">
                      {step.completed ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : step.active ? (
                        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-neutral-700" />
                      )}
                    </div>
                    <span className="text-[8px] sm:text-[9px] font-mono leading-tight truncate w-full">
                      {step.label}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Live Granular Activity Feed from Real EventBus */}
            {recentEvents.length > 0 && (
              <div className="p-2 sm:p-2.5 rounded-xl bg-[#060910] border border-[#141D2D] font-mono text-[10px] space-y-1">
                <div className="flex items-center justify-between text-neutral-400 border-b border-[#121A28] pb-1">
                  <span className="text-cyan-400 font-semibold flex items-center gap-1">
                    <Activity className="w-3 h-3 text-cyan-400" />
                    <span>REAL ACTIVITY</span>
                  </span>
                  <span className="text-[9px] text-neutral-500">{recentEvents.length} events</span>
                </div>
                <div className="space-y-1 max-h-24 overflow-y-auto no-scrollbar">
                  {recentEvents.slice(0, 3).map((evt, eIdx) => {
                    const isSuccess = evt.severity === 'success' || evt.type.includes('COMPLETED') || evt.type === 'EDIT_APPLIED';
                    const isError = evt.severity === 'error' || evt.type.includes('FAILED');
                    return (
                      <div key={evt.eventId || eIdx} className="flex items-start gap-1.5 text-neutral-300">
                        <span className={`font-bold shrink-0 ${isSuccess ? 'text-emerald-400' : isError ? 'text-rose-400' : 'text-cyan-500'}`}>
                          {isSuccess ? '✓' : isError ? '✕' : '▸'}
                        </span>
                        <span className="text-neutral-400 font-semibold shrink-0">[{evt.subsystem || 'ENGINE'}]</span>
                        <span className="truncate flex-1 text-neutral-200">{evt.message}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </div>

      {/* "Jump to Latest" Floating Pill */}
      <AnimatePresence>
        {showLatestPill && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 pointer-events-auto"
          >
            <button
              onClick={() => scrollToBottom(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0E1422]/95 border border-cyan-500/50 text-cyan-300 text-xs font-mono font-semibold shadow-xl backdrop-blur-md hover:bg-[#141E30] transition-all active:scale-95 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 cursor-pointer"
            >
              <ArrowDown className="w-3.5 h-3.5 animate-bounce" aria-hidden="true" />
              <span>Jump to latest</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upgraded Multiline Chat Composer with File & Image Attachments */}
      <div className="p-3 border-t border-[#151B27] bg-[#080B10] shrink-0 z-20">
        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*,.ts,.tsx,.js,.jsx,.json,.md,.csv,.txt,.css,.html,.zip"
          onChange={handleFileInputChange}
          className="hidden"
          aria-label="Upload file attachment"
        />

        {/* Attachment Chips Strip */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-2 px-1">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-[#0E1422] border border-[#1F2B42] text-neutral-200 text-xs shadow-sm max-w-[220px]"
              >
                {att.dataUrl ? (
                  <img
                    src={att.dataUrl}
                    alt={att.name}
                    className="w-5 h-5 rounded object-cover border border-[#2A3B58] shrink-0"
                  />
                ) : (
                  <FileIcon className="w-3.5 h-3.5 text-cyan-400 shrink-0" aria-hidden="true" />
                )}
                <span className="truncate text-[11px] font-sans">{att.name}</span>
                <span className="text-[9px] text-neutral-500 font-mono shrink-0">({formatFileSize(att.size)})</span>
                <button
                  type="button"
                  onClick={() => handleRemoveAttachment(att.id)}
                  className="p-0.5 hover:bg-[#1A2538] text-neutral-400 hover:text-white rounded transition-colors ml-0.5 cursor-pointer"
                  aria-label={`Remove attachment ${att.name}`}
                >
                  <X className="w-3 h-3" aria-hidden="true" />
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-1.5">
          <div className="relative rounded-xl bg-[#0B0E17] border border-[#182234] focus-within:border-cyan-500/70 focus-within:ring-1 focus-within:ring-cyan-500/20 transition-all p-2.5 shadow-md">
            <textarea
              ref={textareaRef}
              value={inputText}
              onChange={handleTextareaInput}
              onKeyDown={handleKeyDown}
              disabled={isWorking}
              rows={1}
              placeholder={
                isWorking
                  ? 'Autonomous agent executing pipeline...'
                  : 'Ask a question, inspect code, or instruct GODEX (e.g., "Improve the GODEX Chat UI now")...'
              }
              className="w-full bg-transparent text-xs text-white placeholder-neutral-500 resize-none font-sans focus:outline-none disabled:opacity-50 min-h-[38px] max-h-[160px] leading-relaxed block select-text"
              aria-label="Direct message input"
            />

            <div className="flex items-center justify-between pt-1.5 border-t border-[#141B2A] mt-1">
              <div className="flex items-center gap-1 text-[10px] text-neutral-500 font-mono">
                {/* File Attachment Button */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isWorking}
                  className="p-1 rounded-md hover:bg-[#141C2C] text-neutral-400 hover:text-cyan-300 disabled:opacity-50 transition-colors focus:outline-none cursor-pointer flex items-center gap-1"
                  title="Attach files or images"
                  aria-label="Attach files or images"
                >
                  <Paperclip className="w-3.5 h-3.5" aria-hidden="true" />
                  <span className="hidden sm:inline text-[10px]">Attach</span>
                </button>

                <span className="hidden sm:inline text-neutral-600">·</span>
                <span className="hidden sm:inline text-neutral-500">Enter ↵ send</span>
                <span className="hidden sm:inline text-neutral-600">·</span>
                <span className="hidden sm:inline text-neutral-500">Shift+Enter newline</span>
              </div>

              <div className="flex items-center gap-1.5 ml-auto">
                {isWorking && onCancelOperation && (
                  <button
                    type="button"
                    onClick={onCancelOperation}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/80 text-xs font-mono font-semibold transition-all active:scale-95 cursor-pointer shadow-xs focus:outline-none focus:ring-1 focus:ring-rose-500/50"
                    title="Stop active execution"
                    aria-label="Stop active execution"
                  >
                    <Square className="w-2.5 h-2.5 fill-rose-400 text-rose-400" />
                    <span>Stop</span>
                  </button>
                )}

                <button
                  type="submit"
                  disabled={(!inputText.trim() && attachments.length === 0) || isWorking}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 disabled:bg-neutral-800 disabled:from-neutral-800 disabled:to-neutral-800 disabled:text-neutral-500 text-white font-semibold text-xs shadow-md shadow-indigo-950/40 transition-all font-sans cursor-pointer disabled:cursor-not-allowed active:scale-98 focus:outline-none focus:ring-1 focus:ring-indigo-500/50"
                  aria-label="Send message"
                >
                  <span>Send</span>
                  <Send className="w-3 h-3" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

