import React from 'react';
import { CharacterGender, SkinId, SkinDef } from '../types';
import {
  SKINS_DATA,
  saveGender,
  saveEquippedSkin,
  saveUnlockedSkin,
  deductPointsFromWallet,
} from '../data/skins';
import { sound } from '../utils/audio';
import { X, Check, Lock, Sparkles, User, Coins, Shirt } from 'lucide-react';

interface SkinStoreModalProps {
  gender: CharacterGender;
  setGender: (gender: CharacterGender) => void;
  equippedSkin: SkinId;
  setEquippedSkin: (skin: SkinId) => void;
  unlockedSkins: SkinId[];
  setUnlockedSkins: (skins: SkinId[]) => void;
  walletPoints: number;
  setWalletPoints: (pts: number) => void;
  onClose: () => void;
}

export const SkinStoreModal: React.FC<SkinStoreModalProps> = ({
  gender,
  setGender,
  equippedSkin,
  setEquippedSkin,
  unlockedSkins,
  setUnlockedSkins,
  walletPoints,
  setWalletPoints,
  onClose,
}) => {
  const handleGenderSelect = (newGender: CharacterGender) => {
    setGender(newGender);
    saveGender(newGender);
    sound.play('station');
  };

  const handleEquip = (skinId: SkinId) => {
    setEquippedSkin(skinId);
    saveEquippedSkin(skinId);
    sound.play('capsule');
  };

  const handleBuy = (skin: SkinDef) => {
    if (walletPoints >= skin.cost) {
      const success = deductPointsFromWallet(skin.cost);
      if (success) {
        setWalletPoints(walletPoints - skin.cost);
        saveUnlockedSkin(skin.id);
        const updated = [...unlockedSkins, skin.id];
        setUnlockedSkins(updated);
        setEquippedSkin(skin.id);
        saveEquippedSkin(skin.id);
        sound.play('victory');
      }
    } else {
      sound.play('wrong');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#030615e6] backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl bg-gradient-to-b from-[#131f49] to-[#070d24] border border-[#5d82db] shadow-[0_0_50px_rgba(76,245,255,0.25)] text-white overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#293d75]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#1b2b63] border border-[#4cf5ff60] flex items-center justify-center text-xl">
              <Shirt className="w-5 h-5 text-[#4cf5ff]" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[#4cf5ff]">
                خزانة الملابس واختيار الشخصية
              </h2>
              <p className="text-xs text-slate-400">
                اختر نوع الشخصية واستبدل نقاطك بأحدث أزياء المعمل الكيميائي
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Wallet badge */}
            <div className="bg-[#0b1536] border border-[#ffe18a66] rounded-xl px-3 py-1.5 flex items-center gap-1.5 text-xs font-bold text-[#ffe18a]">
              <Coins className="w-4 h-4 text-[#ffe18a]" />
              <span>{walletPoints} نقطة</span>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-[#14224e] hover:bg-[#1d316e] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Section 1: Gender Choice (دكتور / دكتورة) */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#ffe18a] flex items-center gap-1.5">
                <User className="w-4 h-4" />
                <span>اختر هوية الصيدلي:</span>
              </h3>
              <span className="text-xs text-slate-400">يمكنك التبديل في أي وقت</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Boy Doctor Card */}
              <button
                type="button"
                onClick={() => handleGenderSelect('boy')}
                className={`p-4 rounded-2xl border text-right transition-all flex items-center gap-3.5 cursor-pointer relative ${
                  gender === 'boy'
                    ? 'bg-[#18316c] border-[#4cf5ff] shadow-[0_0_20px_rgba(76,245,255,0.25)]'
                    : 'bg-[#0f193f] border-[#293c74] hover:border-[#4cf5ff60]'
                }`}
              >
                <div className="w-13 h-13 rounded-2xl bg-[#091129] border border-[#4cf5ff40] flex items-center justify-center text-3xl shrink-0">
                  🧑‍🔬
                </div>
                <div className="flex-1">
                  <div className="font-bold text-white text-base">دكتور صيدلي (ولد)</div>
                  <div className="text-xs text-slate-300 mt-0.5">
                    قصة شعر كلاسيكية، وسماعة طبية، ورابطة عنق كيميائية
                  </div>
                </div>
                {gender === 'boy' && (
                  <div className="w-6 h-6 rounded-full bg-[#4cf5ff] text-[#07112b] flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                )}
              </button>

              {/* Girl Doctor Card */}
              <button
                type="button"
                onClick={() => handleGenderSelect('girl')}
                className={`p-4 rounded-2xl border text-right transition-all flex items-center gap-3.5 cursor-pointer relative ${
                  gender === 'girl'
                    ? 'bg-[#18316c] border-[#4cf5ff] shadow-[0_0_20px_rgba(76,245,255,0.25)]'
                    : 'bg-[#0f193f] border-[#293c74] hover:border-[#4cf5ff60]'
                }`}
              >
                <div className="w-13 h-13 rounded-2xl bg-[#091129] border border-[#4cf5ff40] flex items-center justify-center text-3xl shrink-0">
                  👩‍🔬
                </div>
                <div className="flex-1">
                  <div className="font-bold text-white text-base">دكتورة صيدلانية (بنت)</div>
                  <div className="text-xs text-slate-300 mt-0.5">
                    شعر مرفوع أنيق، ووشاح وردي، ونظارات حماية معملية برّاقة
                  </div>
                </div>
                {gender === 'girl' && (
                  <div className="w-6 h-6 rounded-full bg-[#4cf5ff] text-[#07112b] flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Section 2: Outfits & Skins */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#ffe18a] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                <span>أزياء واسكنات الدكتور (تفتح بالنقاط):</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono-num">
                المفتوحة: {unlockedSkins.length} من {SKINS_DATA.length}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {SKINS_DATA.map((skin) => {
                const isUnlocked = unlockedSkins.includes(skin.id);
                const isEquipped = equippedSkin === skin.id;
                const canAfford = walletPoints >= skin.cost;

                return (
                  <div
                    key={skin.id}
                    className={`rounded-2xl p-4 border transition-all text-right flex flex-col justify-between ${
                      isEquipped
                        ? 'bg-[#122457] border-[#4cf5ff] shadow-[0_0_20px_rgba(76,245,255,0.2)]'
                        : isUnlocked
                        ? 'bg-[#0f193d] border-[#2c4078]'
                        : 'bg-[#0b122c] border-[#1d2b52] opacity-90'
                    }`}
                  >
                    <div>
                      {/* Top row */}
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {/* Color Palette swatches */}
                          <div className="flex -space-x-1">
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: skin.coatColor }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: skin.accentColor }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: skin.glowColor }}
                            />
                          </div>
                          <span className="text-xs font-bold text-white font-latin">
                            {skin.nameEn}
                          </span>
                        </div>

                        <span
                          className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                            isEquipped
                              ? 'bg-[#4cf5ff] text-[#07112b]'
                              : isUnlocked
                              ? 'bg-[#083b2a] text-[#47ffb7] border border-[#47ffb766]'
                              : 'bg-[#1e2a52] text-[#ffe18a] border border-[#ffe18a4d]'
                          }`}
                        >
                          {isEquipped ? 'مُرتدى الآن' : isUnlocked ? 'مملوك' : `${skin.cost} نقطة`}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-white text-base mb-1">{skin.nameAr}</h4>
                      <p className="text-xs text-slate-300 leading-relaxed mb-4">
                        {skin.description}
                      </p>
                    </div>

                    {/* Bottom action button */}
                    <div>
                      {isEquipped ? (
                        <button
                          disabled
                          className="w-full py-2.5 px-4 rounded-xl bg-[#091b3d] border border-[#4cf5ff] text-[#4cf5ff] text-xs font-bold flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-4 h-4" />
                          <span>الزي المختار حالياً</span>
                        </button>
                      ) : isUnlocked ? (
                        <button
                          onClick={() => handleEquip(skin.id)}
                          className="w-full py-2.5 px-4 rounded-xl bg-[#1b316c] hover:bg-[#254291] text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                        >
                          <Shirt className="w-4 h-4 text-[#4cf5ff]" />
                          <span>ارتداء هذا الزي</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleBuy(skin)}
                          disabled={!canAfford}
                          className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            canAfford
                              ? 'bg-gradient-to-r from-[#ffe18a] to-[#ffaa40] text-[#09122c] hover:opacity-95 shadow-md active:scale-95'
                              : 'bg-[#151c36] text-slate-500 border border-slate-700 cursor-not-allowed'
                          }`}
                        >
                          {canAfford ? (
                            <>
                              <Sparkles className="w-4 h-4 fill-current" />
                              <span>شراء بـ {skin.cost} نقطة وافتتاحه</span>
                            </>
                          ) : (
                            <>
                              <Lock className="w-4 h-4" />
                              <span>تحتاج {skin.cost - walletPoints} نقطة إضافية</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#293d75] bg-[#0a1230] flex items-center justify-between">
          <span className="text-xs text-slate-300">
            تلميح: كل إجابة صحيحة تمنحك <strong className="text-[#ffe18a]">100 نقطة</strong> وكل كبسولة{' '}
            <strong className="text-[#4cf5ff]">10 نقاط</strong> تُضاف لرصيدك!
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#071129] font-bold text-sm cursor-pointer hover:opacity-95"
          >
            حفظ وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
