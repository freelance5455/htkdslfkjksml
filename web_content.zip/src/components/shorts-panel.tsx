import { useEffect, useState } from "react";
import { Clapperboard, ExternalLink, Trash2, Video } from "lucide-react";
import { toast } from "sonner";
import { deleteShort, listShorts, saveShort, type ShortCard } from "@/lib/library-api";
import { ConfirmDialog, Field, Modal, errorText, readFileAsDataUrl } from "@/components/bits";

const MAX_MEDIA_BYTES = 1.1 * 1024 * 1024;

export function ShortsPanel({ onChange }: { onChange: () => void }) {
  const [shorts, setShorts] = useState<ShortCard[] | null>(null);
  const [open, setOpen] = useState(false);
  const [removing, setRemoving] = useState<ShortCard | null>(null);

  async function reload() {
    setShorts(await listShorts());
  }

  useEffect(() => {
    let cancelled = false;
    listShorts()
      .then((rows) => {
        if (!cancelled) setShorts(rows);
      })
      .catch((err: unknown) => {
        if (!cancelled) toast.error(errorText(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <section className="space-y-5">
      <div className="lift flex flex-col gap-4 p-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold tracking-widest text-accent uppercase">From the readers</p>
          <h2 className="mt-1 font-display text-3xl">Review shorts</h2>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Post a short written review, a still from your gallery, or a YouTube or Vimeo link.
          </p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
          <Video className="size-4" /> Add a review
        </button>
      </div>

      {shorts === null ? (
        <div className="grid gap-4 md:grid-cols-2">
          {[0, 1].map((item) => (
            <div key={item} className="h-64 animate-pulse rounded-2xl bg-paper-deep motion-reduce:animate-none" />
          ))}
        </div>
      ) : shorts.length === 0 ? (
        <div className="lift px-6 py-14 text-center">
          <Clapperboard className="mx-auto size-8 text-primary" />
          <p className="mt-3 font-display text-2xl">No reviews yet</p>
          <p className="mt-1 text-sm text-muted">Be the first to leave a note on something you read.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {shorts.map((short) => (
            <article key={short.id} className="lift overflow-hidden">
              <ShortMedia short={short} />
              <div className="space-y-2 p-5">
                <h3 className="font-display text-2xl">{short.title}</h3>
                <p className="text-xs text-muted">{short.authorName}</p>
                <p className="text-sm text-ink">{short.description}</p>
                {short.isMine && (
                  <div className="flex justify-end pt-2">
                    <button type="button" className="btn btn-ghost" onClick={() => setRemoving(short)}>
                      <Trash2 className="size-4" /> Delete
                    </button>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {open && (
        <ShortModal
          onClose={() => setOpen(false)}
          onSaved={async () => {
            setOpen(false);
            await reload();
            onChange();
            toast.success("Review posted");
          }}
        />
      )}
      {removing && (
        <ConfirmDialog
          title="Delete this review?"
          body="It will disappear from the shared feed."
          confirmLabel="Delete review"
          onClose={() => setRemoving(null)}
          onConfirm={() => {
            void (async () => {
              try {
                await deleteShort({ data: removing.id });
                setRemoving(null);
                await reload();
                onChange();
              } catch (err) {
                toast.error(errorText(err));
              }
            })();
          }}
        />
      )}
    </section>
  );
}

function ShortMedia({ short }: { short: ShortCard }) {
  if (short.mediaData && short.mediaKind === "video") {
    return <video src={short.mediaData} controls playsInline className="aspect-video w-full bg-ink object-cover" />;
  }
  if (short.mediaData && short.mediaKind === "image") {
    return <img src={short.mediaData} alt="" className="aspect-video w-full object-cover" />;
  }
  if (short.videoEmbed) {
    return (
      <iframe
        title={short.title}
        src={short.videoEmbed}
        className="aspect-video w-full bg-ink"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    );
  }
  if (short.videoHref) {
    return (
      <a
        href={short.videoHref}
        target="_blank"
        rel="noreferrer"
        className="flex aspect-video items-center justify-center gap-2 bg-primary-soft text-sm font-semibold text-primary"
      >
        <ExternalLink className="size-4" /> Watch the linked review
      </a>
    );
  }
  return (
    <div className="flex aspect-video items-center justify-center bg-primary-soft text-primary">
      <Clapperboard className="size-8" />
    </div>
  );
}

function ShortModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => Promise<void> }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (file && file.size > MAX_MEDIA_BYTES) {
      toast.error("That file is too large. Use an image under 1 MB, or paste a video link.");
      return;
    }
    setBusy(true);
    try {
      const mediaData = file ? await readFileAsDataUrl(file) : "";
      await saveShort({ data: { title, description, videoUrl, mediaData } });
      await onSaved();
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Add a book review" onClose={onClose}>
      <div className="space-y-4">
        <Field label="Title">
          <input id="short-title" className="field-input" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="What you read" />
        </Field>
        <Field label="Review">
          <textarea
            id="short-desc"
            className="field-input field-area"
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="A few sentences another reader could use"
          />
        </Field>
        <Field label="Gallery file, optional">
          <input
            id="short-file"
            className="block w-full text-sm"
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm"
            onChange={(event) => setFile(event.target.files?.[0] ?? null)}
          />
          <span className="mt-1 block text-xs text-muted">Images or short clips under 1 MB.</span>
        </Field>
        <Field label="Video link, optional">
          <input
            id="short-url"
            className="field-input"
            value={videoUrl}
            onChange={(event) => setVideoUrl(event.target.value)}
            placeholder="https://www.youtube.com/watch?v=…"
          />
        </Field>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="button" className="btn btn-primary" onClick={() => void submit()} disabled={busy}>
            {busy ? "Posting…" : "Publish"}
          </button>
        </div>
      </div>
    </Modal>
  );
}
