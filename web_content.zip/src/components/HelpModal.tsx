/**
 * SPR - Sahil Powerful Run
 * How To Play & Guide Modal
 */

import React from 'react';
import { X, ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Shield, Magnet, Rocket, Zap, Sparkles, Home } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  onClose: () => void;
}

export const HelpModal: React.FC<Props> = ({ onClose }) => {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-xl max-h-[88vh] overflow-y-auto bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-slate-700 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-xl font-black text-white uppercase tracking-wider font-display">
              HOW TO PLAY SPR
            </h2>
            <p className="text-xs text-slate-400">Master the horror jungle runner controls</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="help-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-4 h-4" />
              <span>HOME</span>
            </button>

            <button
              id="help-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Controls Section */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-black text-orange-400 tracking-wider uppercase font-display">
            CONTROLS (SWIPE / ARROWS / WASD)
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 text-center">
              <ArrowLeft className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-white font-display">SWIPE LEFT</div>
              <div className="text-[10px] text-slate-400">Move Left Lane</div>
            </div>
            <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 text-center">
              <ArrowRight className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-white font-display">SWIPE RIGHT</div>
              <div className="text-[10px] text-slate-400">Move Right Lane</div>
            </div>
            <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 text-center">
              <ArrowUp className="w-5 h-5 text-amber-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-white font-display">SWIPE UP</div>
              <div className="text-[10px] text-slate-400">Jump / Clear Traps</div>
            </div>
            <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 text-center">
              <ArrowDown className="w-5 h-5 text-orange-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-white font-display">SWIPE DOWN</div>
              <div className="text-[10px] text-slate-400">Slide Under Logs</div>
            </div>
          </div>
        </div>

        {/* Obstacles Section */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-black text-red-400 tracking-wider uppercase font-display">
            TRACK OBSTACLES & HAZARDS
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
            <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <strong className="text-red-400">🔥 Fire & Spikes:</strong> Swipe UP to leap over.
            </div>
            <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <strong className="text-amber-400">🚧 Timber Barriers:</strong> Jump low beams, slide under high beams.
            </div>
            <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <strong className="text-slate-200">🪨 Rolling Boulder:</strong> Dodge lane immediately!
            </div>
            <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <strong className="text-red-500">⚠️ Danger Zone:</strong> Watch for the swinging pendulum blade!
            </div>
          </div>
        </div>

        {/* Power-Ups Section */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-black text-emerald-400 tracking-wider uppercase font-display">
            LEGENDARY POWER-UPS
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <Shield className="w-5 h-5 text-blue-400 shrink-0" />
              <div>
                <strong className="text-blue-300">Shield:</strong> Absorbs 1 fatal obstacle hit.
              </div>
            </div>
            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <Magnet className="w-5 h-5 text-red-400 shrink-0" />
              <div>
                <strong className="text-red-300">Magnet:</strong> Draws all nearby coins to you.
              </div>
            </div>
            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <Rocket className="w-5 h-5 text-cyan-400 shrink-0" />
              <div>
                <strong className="text-cyan-300">Rocket Fly:</strong> Flies above all obstacles safely!
              </div>
            </div>
            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <Sparkles className="w-5 h-5 text-purple-400 shrink-0" />
              <div>
                <strong className="text-purple-300">Double Coins:</strong> Multiplies all coins by 2X.
              </div>
            </div>
            <div className="flex items-center gap-2.5 bg-slate-950/60 p-2 rounded-lg border border-slate-800 sm:col-span-2">
              <Zap className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <strong className="text-amber-300">Speed Boost:</strong> Hypersonic invincible sprint dash!
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
