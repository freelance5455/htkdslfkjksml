import React, { useState } from "react";
import { Achievement, RoadmapStage } from "../types";
import { ROADMAP_STAGES } from "../game/constants";
import { sound } from "../audio";
import {
  X,
  HelpCircle,
  Shield,
  Axe,
  Sprout,
  Store,
  Award,
  CheckCircle2,
  Sparkles,
  Gift,
  Compass,
  ArrowRight,
  Lock,
  ChevronRight,
} from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  achievements: Achievement[];
  roadmapStages?: RoadmapStage[];
  onClaimAchievement: (achId: string) => void;
  onClaimRoadmapStage?: (stageId: string) => void;
  defaultTab?: "roadmap" | "awards" | "guide";
}

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  achievements,
  roadmapStages = ROADMAP_STAGES,
  onClaimAchievement,
  onClaimRoadmapStage,
  defaultTab = "roadmap",
}) => {
  const [activeTab, setActiveTab] = useState<"roadmap" | "awards" | "guide">(defaultTab);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 select-none">
      <div className="relative w-full max-w-3xl bg-stone-900 border-2 border-yellow-600/70 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-yellow-950/70 to-stone-950 p-3 sm:p-4 border-b border-yellow-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-yellow-600/20 text-yellow-400 rounded-xl border border-yellow-500/40 text-xl shadow">
              {activeTab === "roadmap" ? "🗺️" : activeTab === "awards" ? "🏆" : "📖"}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-yellow-200 font-['Hind_Siliguri']">
                {activeTab === "roadmap"
                  ? "রোডম্যাপ: ওয়াইল্ড লাইফ থেকে গভীর কচুবন (Progression Roadmap)"
                  : activeTab === "awards"
                  ? "মাইলফলক ও পদক (Awards & Achievements)"
                  : "গেম খেলার নির্দেশিকা ও গাইড (Gameplay Guide)"}
              </h2>
              <p className="text-[11px] text-stone-300">
                Tojo Adventure • Wildlife Bonding to Advance Deep Kouchu Bon Exploration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center bg-stone-950 border-b border-stone-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab("roadmap")}
            className={`flex-1 py-3 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "roadmap"
                ? "border-yellow-400 text-yellow-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <Compass className="w-4 h-4 text-yellow-400" />
            <span className="flex items-center gap-1">
              <span>রোডম্যাপ (Roadmap)</span>
              <span className="bg-yellow-950 text-yellow-300 text-[10px] px-1.5 rounded font-mono border border-yellow-700/50">
                Wild Life &rarr; Deep Kouchu Bon
              </span>
            </span>
          </button>
          <button
            onClick={() => setActiveTab("awards")}
            className={`flex-1 py-3 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "awards"
                ? "border-yellow-400 text-yellow-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <Award className="w-4 h-4 text-yellow-400" />
            <span>মাইলফলক ট্রফি ({achievements.filter((a) => a.isUnlocked).length}/{achievements.length})</span>
          </button>
          <button
            onClick={() => setActiveTab("guide")}
            className={`flex-1 py-3 flex items-center justify-center gap-1.5 cursor-pointer transition border-b-2 ${
              activeTab === "guide"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>গেম গাইড (Guide)</span>
          </button>
        </div>

        {/* TAB 1: ROADMAP (Wildlife to Advance Deep Kouchu Bon) */}
        {activeTab === "roadmap" && (
          <div className="p-3 sm:p-4 overflow-y-auto space-y-3.5 flex-1 font-['Hind_Siliguri']">
            {/* Roadmap Banner */}
            <div className="p-3 bg-gradient-to-r from-emerald-950/70 via-stone-900 to-amber-950/70 rounded-xl border border-emerald-600/40 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-emerald-300 text-sm flex items-center gap-1.5">
                  <span>🌿 বন্য জীবন থেকে অগ্রসর গভীর কচুবন অভিযান</span>
                </h3>
                <p className="text-xs text-stone-300 mt-0.5">
                  তোজোর শান্ত মনোভাব, কালো কুকুরদের ভালোবাসা এবং বন সংরক্ষণের ৬-ধাপের মহাকাব্যিক পথরেখা।
                </p>
              </div>
              <div className="hidden sm:block text-right">
                <span className="text-[10px] text-stone-400 block font-mono">পরিকল্পনা</span>
                <span className="text-amber-300 font-bold text-xs">দেপলোপার মুস্তাকিম অনুমোদিত</span>
              </div>
            </div>

            {/* Stages List with Progression Tree Cards */}
            <div className="space-y-3 relative before:absolute before:left-6 before:top-4 before:bottom-4 before:w-0.5 before:bg-stone-800">
              {roadmapStages.map((stage, idx) => {
                const isComplete = stage.isCompleted;
                const isUnlocked = stage.isUnlocked;
                const progressPct = Math.min(
                  100,
                  Math.floor((stage.currentValue / stage.targetValue) * 100)
                );

                return (
                  <div
                    key={stage.id}
                    className={`relative ml-10 p-3 sm:p-4 rounded-xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                      isComplete
                        ? "bg-emerald-950/30 border-emerald-500/50 shadow"
                        : isUnlocked
                        ? "bg-stone-900/90 border-yellow-500/60 ring-1 ring-yellow-500/30 shadow-lg"
                        : "bg-stone-950/60 border-stone-800 opacity-65"
                    }`}
                  >
                    {/* Step Node Marker on vertical line */}
                    <div
                      className={`absolute -left-10 top-4 w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow-md border ${
                        isComplete
                          ? "bg-emerald-600 border-emerald-300 text-white"
                          : isUnlocked
                          ? "bg-yellow-500 border-yellow-200 text-stone-950 animate-pulse"
                          : "bg-stone-800 border-stone-700 text-stone-500"
                      }`}
                    >
                      {isComplete ? "✓" : stage.stageNumber}
                    </div>

                    {/* Stage Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-2xl">{stage.icon}</span>
                        <h4 className="font-bold text-stone-100 text-sm sm:text-base">
                          {stage.bengaliTitle}
                        </h4>

                        {isComplete ? (
                          <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-600/50 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> সম্পূর্ণ!
                          </span>
                        ) : isUnlocked ? (
                          <span className="text-[10px] bg-yellow-950 text-yellow-300 px-2 py-0.5 rounded-full font-bold border border-yellow-600/50 flex items-center gap-1">
                            <Sparkles className="w-3 h-3" /> চলমান লক্ষ্য
                          </span>
                        ) : (
                          <span className="text-[10px] bg-stone-800 text-stone-400 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                            <Lock className="w-3 h-3" /> লকড
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-stone-300 mt-1 leading-relaxed">
                        {stage.bengaliDescription}
                      </p>

                      {/* Perk badge */}
                      <div className="mt-2 flex items-center gap-1 text-[11px] text-amber-300 bg-amber-950/40 px-2 py-1 rounded-lg border border-amber-600/30">
                        <span className="font-bold">আনলক সুবিধা:</span>
                        <span>{stage.unlockedPerk}</span>
                      </div>

                      {/* Progress bar */}
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 bg-stone-950 h-2 rounded-full overflow-hidden border border-stone-800">
                          <div
                            className={`h-full transition-all duration-500 ${
                              isComplete
                                ? "bg-emerald-500"
                                : isUnlocked
                                ? "bg-yellow-400"
                                : "bg-stone-700"
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                        <span className="text-[11px] font-mono text-stone-300 font-bold shrink-0">
                          {stage.currentValue}/{stage.targetValue}
                        </span>
                      </div>
                    </div>

                    {/* Reward & Claim button */}
                    <div className="shrink-0 w-full sm:w-auto text-right">
                      {isComplete ? (
                        <div className="text-xs text-emerald-400 font-bold flex items-center justify-end gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>মাইলফলক অর্জিত</span>
                        </div>
                      ) : progressPct >= 100 && onClaimRoadmapStage ? (
                        <button
                          onClick={() => {
                            sound.playHarvest();
                            onClaimRoadmapStage(stage.id);
                          }}
                          className="w-full sm:w-auto px-4 py-2 bg-yellow-500 hover:bg-yellow-400 text-stone-950 font-bold text-xs rounded-xl shadow-lg cursor-pointer transition flex items-center justify-center gap-1.5 animate-bounce-subtle"
                        >
                          <Gift className="w-4 h-4" />
                          <span>দাবি করুন (+{stage.rewardCoins} Tk)</span>
                        </button>
                      ) : (
                        <div className="text-[11px] font-mono text-amber-300 bg-stone-950 px-2.5 py-1 rounded-lg border border-stone-800 inline-block">
                          পুরস্কার: {stage.rewardCoins} Tk
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: AWARDS & ACHIEVEMENTS */}
        {activeTab === "awards" && (
          <div className="p-3 sm:p-4 overflow-y-auto space-y-3 flex-1">
            {achievements.map((ach) => {
              const progressPct = Math.min(
                100,
                Math.floor((ach.currentCount / ach.targetCount) * 100)
              );

              return (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                    ach.isClaimed
                      ? "bg-stone-950/40 border-stone-800 opacity-75"
                      : ach.isUnlocked
                      ? "bg-yellow-950/40 border-yellow-500/70 shadow-lg shadow-yellow-900/20"
                      : "bg-stone-800/60 border-stone-700/80"
                  }`}
                >
                  <div className="flex items-start gap-3 flex-1">
                    <div className="w-12 h-12 rounded-xl bg-stone-900 border border-stone-700 flex items-center justify-center text-2xl shrink-0">
                      {ach.icon}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-stone-100 font-['Hind_Siliguri'] text-base">
                          {ach.bengaliTitle}
                        </span>
                        {ach.isUnlocked && (
                          <span className="text-[10px] bg-yellow-900/80 text-yellow-300 px-1.5 py-0.5 rounded font-bold border border-yellow-600/40 flex items-center gap-1">
                            <Sparkles className="w-3 h-3" /> অর্জিত!
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-stone-300 mt-0.5 font-['Hind_Siliguri']">
                        {ach.bengaliDescription}
                      </p>

                      {/* Progress bar */}
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 bg-stone-900 h-2 rounded-full overflow-hidden border border-stone-700">
                          <div
                            className={`h-full transition-all duration-500 ${
                              ach.isUnlocked ? "bg-yellow-400" : "bg-emerald-500"
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                        <span className="text-[11px] font-mono text-stone-400 shrink-0 font-bold">
                          {ach.currentCount}/{ach.targetCount}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Claim button */}
                  <div className="shrink-0 w-full sm:w-auto">
                    {ach.isClaimed ? (
                      <span className="text-xs text-stone-500 font-mono font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" /> পুরস্কৃত
                      </span>
                    ) : ach.isUnlocked ? (
                      <button
                        onClick={() => {
                          sound.playHarvest();
                          onClaimAchievement(ach.id);
                        }}
                        className="w-full sm:w-auto px-3.5 py-1.5 bg-yellow-500 hover:bg-yellow-400 text-stone-950 font-bold text-xs rounded-xl shadow-lg cursor-pointer transition flex items-center justify-center gap-1.5 animate-bounce-subtle"
                      >
                        <Gift className="w-4 h-4" />
                        <span>পুরস্কার গ্রহণ (+{ach.rewardCoins} Tk)</span>
                      </button>
                    ) : (
                      <span className="text-[11px] font-mono text-stone-400 bg-stone-900 px-2.5 py-1 rounded-lg border border-stone-800">
                        পুরস্কার: {ach.rewardCoins} Tk
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: GAMEPLAY GUIDE */}
        {activeTab === "guide" && (
          <div className="p-4 overflow-y-auto space-y-3 text-xs text-stone-200 font-['Hind_Siliguri'] flex-1">
            <div className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 flex items-start gap-3">
              <div className="p-2 bg-amber-600/20 text-amber-300 rounded-lg shrink-0 text-xl">
                ✋
              </div>
              <div>
                <h3 className="font-bold text-amber-300 text-sm">
                  ১. খালি হাত (Bare Hand ✋) ও কুকুরদের পরম শান্তি
                </h3>
                <p className="text-stone-300 mt-1 leading-relaxed">
                  তোজোর হাতে কোনো কুঠার বা লাঠি না থাকলে (খালি হাত ✋ মোড), কুকুররা তোজোকে আর ভয় পায় না। তারা আনন্দের সাথে দৌড়ে কাছে আসে, পেট দেখিয়ে গড়াগড়ি খায় এবং আদর গ্রহণ করে। হাত দিয়ে পাকা ফসলও মাটি না ভেঙে নিরাপদে তোলা যায়।
                </p>
              </div>
            </div>

            <div className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 flex items-start gap-3">
              <div className="p-2 bg-teal-950 text-teal-400 rounded-lg shrink-0 text-xl">
                👨‍💻
              </div>
              <div>
                <h3 className="font-bold text-teal-300 text-sm">
                  ২. দেপলোপার মুস্তাকিম (Developer Mustakim) - স্থায়ী দোকান
                </h3>
                <p className="text-stone-300 mt-1 leading-relaxed">
                  দেপলোপার মুস্তাকিম নদীর ঘাটের নিজস্ব দোকানে <strong>স্থায়ীভাবে (Permanently)</strong> অবস্থান করছেন। তিনি তোজোকে বীজ, হাতিয়ার, সার, এবং কুকুরদের সোনালী হাড়সহ গেমের সমস্ত আইটেম বিক্রি করেন এবং ফসল কিনে টাকা প্রদান করেন।
                </p>
              </div>
            </div>

            <div className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 flex items-start gap-3">
              <div className="p-2 bg-amber-950 text-amber-400 rounded-lg shrink-0">
                <Axe className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-amber-300 text-sm">
                  ৩. কুঠার, চার ঋতু ও গাছের স্বয়ংক্রিয় পুনর্জন্ম
                </h3>
                <p className="text-stone-300 mt-1 leading-relaxed">
                  বনের গাছ কাটলে কাঠ ও ফল পাওয়া যায়। গুঁড়ি কেটে ফেললেও কিছু সময়ের মধ্যে স্বয়ংক্রিয়ভাবে নতুন কচি চারা গজিয়ে উঠে পুনরায় পূর্ণ গাছে পরিণত হয়।
                </p>
              </div>
            </div>

            <div className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 flex items-start gap-3">
              <div className="p-2 bg-emerald-950 text-emerald-400 rounded-lg shrink-0">
                <Sprout className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-amber-300 text-sm">
                  ৪. কৃষি, ধান ও বৃষ্টির সুবিধা
                </h3>
                <p className="text-stone-300 mt-1 leading-relaxed">
                  কোদাল দিয়ে মাটি কুপিয়ে রাজকীয় কচু ও আমন ধান রোপণ করুন। বৃষ্টি হলে সব জমি নিজে নিজেই পানিতে সিক্ত হয়ে দ্রুত ফলে ভরে ওঠে।
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
          <span>🏆 বন্য জীবন থেকে গভীর কচুবনের শ্রেষ্ঠ পথরেখা সম্পন্ন করুন।</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-yellow-600 hover:bg-yellow-500 text-stone-950 font-bold text-xs rounded-lg cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
