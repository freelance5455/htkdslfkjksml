import React from 'react';
import { Moon, Sparkles, BatteryCharging, Check, Eye } from 'lucide-react';
import { DarkModeType, themeService } from '../utils/theme';
import { soundService } from '../utils/sound';

interface OledModeCardProps {
  darkMode: DarkModeType;
  onSetDarkMode: (mode: DarkModeType) => void;
  onQuickNightRed: () => void;
}

export const OledModeCard: React.FC<OledModeCardProps> = ({
  darkMode,
  onSetDarkMode,
  onQuickNightRed,
}) => {
  const isOled = darkMode === 'oled-true-black';

  const selectMode = (mode: DarkModeType) => {
    soundService.playTick();
    onSetDarkMode(mode);
  };

  return (
    <div
      className={`rounded-2xl p-4 sm:p-5 border transition-all ${
        isOled
          ? 'bg-black border-neutral-800 shadow-[0_0_20px_rgba(0,0,0,0.8)]'
          : 'bg-slate-900/60 border-slate-800 backdrop-blur-sm'
      }`}
    >
      <div className="flex items-center justify-between gap-4 mb-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
              isOled
                ? 'bg-neutral-950 border-cyan-500/50 text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.3)]'
                : 'bg-slate-800/40 border-slate-700 text-slate-300'
            }`}
          >
            <Moon className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
              <span>Režim displeje & OLED Dark Mode</span>
              {isOled && (
                <span className="text-[10px] font-bold text-cyan-400 border border-cyan-500/40 px-1.5 py-0.5 rounded bg-cyan-950/60 uppercase tracking-wider">
                  0% WATT (OLED)
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">
              OLED True Black vypíná černé pixely panelu a šetří baterii telefonu
            </p>
          </div>
        </div>
      </div>

      {/* Mode selection buttons */}
      <div className="grid grid-cols-2 gap-2.5 pt-1">
        {/* OLED True Black */}
        <button
          onClick={() => selectMode('oled-true-black')}
          className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all cursor-pointer ${
            isOled
              ? 'bg-black border-cyan-500 text-white shadow-[0_0_15px_rgba(0,240,255,0.2)]'
              : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-1">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-black border border-cyan-400 shadow-[0_0_6px_#00F0FF]" />
              OLED True Black
            </span>
            {isOled && <Check className="w-3.5 h-3.5 text-cyan-400" />}
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            100% čistá čerň #000000. Pixely na OLED displejích jsou zcela zhasnuté.
          </p>
        </button>

        {/* Cyber Slate */}
        <button
          onClick={() => selectMode('cyber-dark')}
          className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all cursor-pointer ${
            !isOled
              ? 'bg-slate-900 border-cyan-500 text-white shadow-[0_0_15px_rgba(0,240,255,0.15)]'
              : 'bg-neutral-950 border-neutral-900 text-slate-400 hover:border-neutral-800'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-1">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-600" />
              Cyber Slate Dark
            </span>
            {!isOled && <Check className="w-3.5 h-3.5 text-cyan-400" />}
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            Tmavomodrý ambientní podklad s jemnými prostorovými stíny.
          </p>
        </button>
      </div>

      {/* Quick OLED Red Mode action */}
      <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center justify-between">
        <span className="text-xs text-slate-400 flex items-center gap-1.5">
          <Eye className="w-3.5 h-3.5 text-red-400" />
          <span>Noční červené spektrum pro astronomii & kemp</span>
        </span>
        <button
          onClick={() => {
            soundService.playTick();
            onQuickNightRed();
          }}
          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-red-950/60 border border-red-700/60 text-red-300 hover:bg-red-900/60 cursor-pointer transition-colors"
        >
          Aktivovat červené
        </button>
      </div>
    </div>
  );
};
