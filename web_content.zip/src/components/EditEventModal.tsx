import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Plus,
  Trash2,
  Sparkles,
  Ticket,
  User,
  Users,
  Calendar,
  Clock,
  DollarSign,
  ShieldCheck,
  Loader2,
  Check,
} from 'lucide-react';
import { EventItem, CustomGroupTier } from '../types';

interface EditEventModalProps {
  event: EventItem;
  onClose: () => void;
}

export const EditEventModal: React.FC<EditEventModalProps> = ({ event, onClose }) => {
  const { updateEvent, showToast, formatKsh } = useApp();

  const [title, setTitle] = useState(event.title);
  const [personalPrice, setPersonalPrice] = useState(String(event.personalPrice || event.price || 2500));
  const [capacity, setCapacity] = useState(String(event.capacity || 1200));
  const [date, setDate] = useState(event.date);
  const [time, setTime] = useState(event.time);
  const [doorTime, setDoorTime] = useState(event.doorTime || '5:00 PM (1 hr prior)');
  const [venue, setVenue] = useState(event.venue);
  const [description, setDescription] = useState(event.description || '');

  // Socials
  const [instagram, setInstagram] = useState(event.instagram || '');
  const [tiktok, setTiktok] = useState(event.tiktok || '');
  const [gmail, setGmail] = useState(event.gmail || event.hostEmail || '');

  // Group Tiers manipulation
  const [groupTiers, setGroupTiers] = useState<CustomGroupTier[]>(
    event.groupTiers && event.groupTiers.length > 0
      ? event.groupTiers
      : [
          {
            id: `tier_${Date.now()}_1`,
            name: 'Squad Group Pass (4 Guests)',
            size: 4,
            price: Math.round((event.personalPrice || event.price || 2500) * 4 * 0.85),
            perks: '4 wristbands, 15% bundle discount, expedited gate entry',
          },
        ]
  );

  const [isSaving, setIsSaving] = useState(false);

  const handleAddGroupTier = () => {
    const newTier: CustomGroupTier = {
      id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `VIP Table Bundle (${groupTiers.length + 5} Guests)`,
      size: groupTiers.length + 5,
      price: Math.round(Number(personalPrice || 2500) * (groupTiers.length + 5) * 0.9),
      perks: 'VIP lounge access & table bottle service',
    };
    setGroupTiers([...groupTiers, newTier]);
  };

  const handleRemoveTier = (id: string) => {
    setGroupTiers(groupTiers.filter((t) => t.id !== id));
  };

  const handleUpdateTier = (id: string, updates: Partial<CustomGroupTier>) => {
    setGroupTiers(groupTiers.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const pPrice = Number(personalPrice) || 2500;
      await updateEvent(event.id, {
        title: title.trim(),
        price: pPrice,
        personalPrice: pPrice,
        capacity: Number(capacity) || 1000,
        date: date.trim(),
        time: time.trim(),
        doorTime: doorTime.trim(),
        venue: venue.trim(),
        description: description.trim(),
        instagram: instagram.trim(),
        tiktok: tiktok.trim(),
        gmail: gmail.trim(),
        groupTiers,
      });
      showToast('Live ticket tiers and event details updated successfully!');
      onClose();
    } catch {
      showToast('Failed to update event. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl my-6 bg-[#111317] rounded-[32px] shadow-2xl border border-[#1f2229] overflow-hidden text-[#f4f4f6]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 pb-4 border-b border-[#1f2229] bg-[#16181f]/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Ticket className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Live Event Configuration
                </span>
                <span className="text-xs text-[#9496a1]">Real-time Ticket Manipulation</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                Edit Tickets & Event Settings
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-[#1f2229] flex items-center justify-center text-[#9496a1] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Edit Form */}
        <form onSubmit={handleSave} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Section 1: Ticket Pricing & Quotas */}
          <div className="p-5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6] flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                  <span>Ticket Pricing & Capacity (Manipulate Live)</span>
                </h3>
                <p className="text-[11px] text-[#9496a1] mt-0.5">
                  Update admission prices, pass quantities, and group tiers before event day.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Individual Pass Price (KSh)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-xs text-[#646875] font-bold">
                    KSh
                  </span>
                  <input
                    type="number"
                    value={personalPrice}
                    onChange={(e) => setPersonalPrice(e.target.value)}
                    className="w-full h-12 pl-12 pr-4 text-sm font-mono font-bold bg-[#111317] border border-[#262934] focus:border-emerald-500 rounded-xl text-white focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">
                  Venue Guest Capacity / Quota
                </label>
                <input
                  type="number"
                  value={capacity}
                  onChange={(e) => setCapacity(e.target.value)}
                  className="w-full h-12 px-4 text-sm font-mono font-bold bg-[#111317] border border-[#262934] focus:border-emerald-500 rounded-xl text-white focus:outline-none"
                  required
                />
              </div>
            </div>

            {/* Custom Group Tiers Manipulation */}
            <div className="space-y-3 pt-3 border-t border-[#232733]">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Custom Group Bundles & VIP Tiers</span>
                  </h4>
                  <span className="text-[11px] text-[#646875]">Hosts can add/edit tiers for newer tickets</span>
                </div>

                <button
                  type="button"
                  onClick={handleAddGroupTier}
                  className="px-3 py-1.5 rounded-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Tier</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {groupTiers.map((tier) => (
                  <div
                    key={tier.id}
                    className="p-3.5 rounded-xl bg-[#111317] border border-[#262934] space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={tier.name}
                        onChange={(e) => handleUpdateTier(tier.id, { name: e.target.value })}
                        placeholder="Tier Name (e.g. Squad Pass)"
                        className="flex-1 h-10 px-3 text-xs font-bold bg-[#16181f] border border-[#262934] rounded-lg text-white focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveTier(tier.id)}
                        className="w-8 h-8 rounded-lg hover:bg-red-500/10 text-red-400 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label className="text-[10px] text-[#646875] font-semibold block mb-1">
                          Passes Count in Bundle
                        </label>
                        <input
                          type="number"
                          value={tier.size}
                          onChange={(e) => handleUpdateTier(tier.id, { size: Number(e.target.value) || 2 })}
                          className="w-full h-10 px-3 text-xs font-mono font-medium bg-[#16181f] border border-[#262934] rounded-lg text-white focus:outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-[#646875] font-semibold block mb-1">
                          Bundle Price (KSh)
                        </label>
                        <input
                          type="number"
                          value={tier.price}
                          onChange={(e) => handleUpdateTier(tier.id, { price: Number(e.target.value) || 5000 })}
                          className="w-full h-10 px-3 text-xs font-mono font-medium bg-[#16181f] border border-[#262934] rounded-lg text-white focus:outline-none focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div>
                      <input
                        type="text"
                        value={tier.perks || ''}
                        onChange={(e) => handleUpdateTier(tier.id, { perks: e.target.value })}
                        placeholder="Tier Perks (e.g. VIP line, free drink, reserved seating)"
                        className="w-full h-9 px-3 text-[11px] bg-[#16181f] border border-[#262934] rounded-lg text-[#9496a1] focus:text-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 2: Date, Time & Location */}
          <div className="p-5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6] flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span>Event Showtime & Venue Logistics</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">Date</label>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">Showtime</label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">Doors Open</label>
                <input
                  type="text"
                  value={doorTime}
                  onChange={(e) => setDoorTime(e.target.value)}
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2] block">Venue & Address</label>
              <input
                type="text"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          {/* Section 3: Official Socials (Instagram, TikTok, Gmail) */}
          <div className="p-5 rounded-2xl bg-[#16181f] border border-[#232733] space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#f4f4f6] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Official Social Handles & Inquiries (Displayed in Details)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">Instagram Handle</label>
                <input
                  type="text"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  placeholder="@eventhost"
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">TikTok Handle</label>
                <input
                  type="text"
                  value={tiktok}
                  onChange={(e) => setTiktok(e.target.value)}
                  placeholder="@eventhost"
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#b8b9c2] block">Gmail / Contact Email</label>
                <input
                  type="email"
                  value={gmail}
                  onChange={(e) => setGmail(e.target.value)}
                  placeholder="tickets@gmail.com"
                  className="w-full h-12 px-4 text-xs font-medium bg-[#111317] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Title & Description */}
          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2] block">Event Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full h-12 px-4 text-sm font-bold bg-[#16181f] border border-[#262934] rounded-xl text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#b8b9c2] block">Experience Description</label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-4 text-xs text-white bg-[#16181f] border border-[#262934] rounded-xl focus:outline-none focus:border-emerald-500 resize-none leading-relaxed"
              />
            </div>
          </div>

          {/* Save Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#1f2229]">
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-5 rounded-full border border-[#262934] text-xs font-semibold text-[#9496a1] hover:text-white cursor-pointer transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="py-3 px-6 rounded-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md active:scale-95 transition-all"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Updating Cloud...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Live Modifications</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
