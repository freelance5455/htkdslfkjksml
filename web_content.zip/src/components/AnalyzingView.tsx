import React, { useEffect, useState } from 'react';
import { ArrowLeft, Brain, Cpu, Activity, Zap, FastForward } from 'lucide-react';
import { Asset, Timeframe } from '../types/trading';
import { soundManager } from '../utils/soundEffects';

interface AnalyzingViewProps {
  asset: Asset;
  timeframe: Timeframe;
  isSniper99: boolean;
  onCancel: () => void;
  onComplete: () => void;
  isFastMode?: boolean;
}

export const AnalyzingView: React.FC<AnalyzingViewProps> = ({
  asset,
  timeframe,
  isSniper99,
  onCancel,
  onComplete,
  isFastMode = true,
}) => {
  const [progress, setProgress] = useState(25);
  const [stageText, setStageText] = useState('Mapping Support & Resistance Liquidity Zones...');
  const [dataPoints, setDataPoints] = useState(3120);

  useEffect(() => {
    // Ultra-fast transition pipeline (under 500ms total)
    const t1 = setTimeout(() => {
      setProgress(55);
      setStageText('Auditing Multi-Timeframe Alignment (5s, 1M, 5M)...');
      setDataPoints(3340);
    }, 100);

    const t2 = setTimeout(() => {
      setProgress(85);
      setStageText('Scanning Order Flow Volume Delta & Rejection Wicks...');
      setDataPoints(3678);
    }, 250);

    const t3 = setTimeout(() => {
      setProgress(100);
      setStageText(isSniper99 ? '99% Institutional Sniper Confluence Confirmed!' : 'Signal Confirmed!');
      setDataPoints(4150);
    }, 420);

    const t4 = setTimeout(() => {
      onComplete();
    }, 550);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [isSniper99, onComplete]);

  const handleInstantSignal = () => {
    soundManager.playPip();
    onComplete();
  };

  return (
    <div
      onClick={handleInstantSignal}
      className="w-full max-w-md mx-auto flex flex-col items-center px-4 py-4 min-h-[460px] cursor-pointer select-none"
    >
      {/* Quotex Broker Header Banner (Screenshot 2) */}
      <div className="flex items-center gap-2 mb-3">
        <div className="w-6 h-6 rounded bg-red-950 border border-red-500/40 flex items-center justify-center">
          <Activity className="w-3.5 h-3.5 text-red-500" />
        </div>
        <div className="text-left leading-tight">
          <span className="text-xs font-black text-slate-100 uppercase">Quotex</span>{' '}
          <span className="text-xs font-black text-red-500 uppercase">Broker</span>
          <div className="text-[9px] font-bold text-zinc-400 tracking-wider">
            SIGNALS OPTIMIZED ONLY
          </div>
        </div>
      </div>

      {/* Cancel button & Fast Mode Indicator */}
      <div className="w-full flex items-center justify-between mb-3">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onCancel();
          }}
          className="flex items-center gap-1 text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Cancel</span>
        </button>

        {/* Instant Skip Pill */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleInstantSignal();
          }}
          className="flex items-center gap-1 px-2.5 py-1 bg-red-600/90 hover:bg-red-500 text-white rounded-full text-[11px] font-extrabold shadow-[0_0_10px_rgba(239,68,68,0.5)] transition-all animate-pulse"
        >
          <Zap className="w-3 h-3 fill-amber-300 text-amber-300" />
          <span>INSTANT SIGNAL</span>
        </button>
      </div>

      {/* Title */}
      <div className="text-center mb-5">
        <h2 className="text-xl sm:text-2xl font-black text-slate-100">
          Analyzing Market... <span className="text-red-500">{asset.symbol}</span>
        </h2>
        <div className="text-xs text-zinc-400 font-mono mt-0.5">
          Timeframe: {timeframe}
        </div>
      </div>

      {/* Circular Rotating Progress Ring with Brain Icon (Screenshot 2) */}
      <div className="relative my-3 flex items-center justify-center">
        {/* Ambient red halo */}
        <div className="absolute w-44 h-44 rounded-full bg-red-600/25 blur-xl animate-pulse" />

        {/* SVG Circular Ring */}
        <div className="relative w-40 h-40 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            {/* Background Circle */}
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="#260b17"
              strokeWidth="6"
            />
            {/* Animated Stroke Ring */}
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="#ef4444"
              strokeWidth="6"
              strokeDasharray="264"
              strokeDashoffset={264 - (264 * progress) / 100}
              strokeLinecap="round"
              className="transition-all duration-300 ease-out"
            />
          </svg>

          {/* Central Brain Icon */}
          <div className="absolute flex flex-col items-center justify-center">
            <Brain className="w-12 h-12 text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.8)] animate-pulse" />
          </div>
        </div>
      </div>

      {/* Linear Progress Bar & Running text (Screenshot 2) */}
      <div className="w-full mt-3 bg-[#1a0711] border border-[#3b1223] rounded-2xl p-3 shadow-inner">
        <div className="w-full h-2 bg-[#2d0d1c] rounded-full overflow-hidden mb-2">
          <div
            className="h-full bg-gradient-to-r from-red-600 to-rose-500 rounded-full transition-all duration-200 shadow-[0_0_8px_rgba(239,68,68,0.6)]"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="text-center text-xs font-mono font-medium text-red-400 truncate">
          {stageText}
        </div>
      </div>

      {/* Quick Tap Hint */}
      <div className="text-[10px] text-zinc-500 font-mono mt-2 flex items-center gap-1">
        <Zap className="w-3 h-3 text-amber-400" />
        <span>Tap anywhere to view signal instantly</span>
      </div>

      {/* 3 Metric Cards: DATA POINTS, ACCURACY, CONFIDENCE (Screenshot 2) */}
      <div className="w-full grid grid-cols-3 gap-2 mt-5">
        {/* Data points */}
        <div className="bg-[#180710] border border-[#361121] rounded-xl p-2.5 flex flex-col items-center justify-center">
          <span className="text-[9px] sm:text-[10px] font-bold text-red-400 tracking-wider uppercase">
            DATA POINTS
          </span>
          <span className="text-sm sm:text-base font-black font-mono text-slate-100 tabular-nums mt-0.5">
            {dataPoints.toLocaleString()}
          </span>
        </div>

        {/* Accuracy */}
        <div className="bg-[#180710] border border-[#361121] rounded-xl p-2.5 flex flex-col items-center justify-center">
          <span className="text-[9px] sm:text-[10px] font-bold text-emerald-400 tracking-wider uppercase">
            ACCURACY
          </span>
          <span className="text-sm sm:text-base font-black font-mono text-slate-100 tabular-nums mt-0.5">
            {isSniper99 ? '99.1%' : '56.9%'}
          </span>
        </div>

        {/* Confidence */}
        <div className="bg-[#180710] border border-[#361121] rounded-xl p-2.5 flex flex-col items-center justify-center">
          <span className="text-[9px] sm:text-[10px] font-bold text-zinc-400 tracking-wider uppercase">
            CONFIDENCE
          </span>
          <span className="text-sm sm:text-base font-black font-mono text-slate-100 tabular-nums mt-0.5">
            {isSniper99 ? '99%' : '59%'}
          </span>
        </div>
      </div>
    </div>
  );
};
