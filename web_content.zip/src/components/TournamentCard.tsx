import React from 'react';
import { Tournament } from '../types';
import { useApp } from '../context/AppContext';
import { Users, Calendar, MapPin, ChevronRight, CheckCircle2, ShieldCheck, Key, Clock, AlertCircle } from 'lucide-react';

interface Props {
  tournament: Tournament;
}

export const TournamentCard: React.FC<Props> = ({ tournament }) => {
  const { user, setSelectedTournament, language, getSecureRoomCredentials } = useApp();

  const isUserRegistered = tournament.registeredSlots.some(s => s.userId === user.id);
  const userSlot = tournament.registeredSlots.find(s => s.userId === user.id);
  const slotsRemaining = tournament.totalSlots - tournament.bookedSlots;
  const progressPercent = Math.min((tournament.bookedSlots / tournament.totalSlots) * 100, 100);

  // Formatting date
  const matchDate = new Date(tournament.scheduleTime);
  const timeFormatted = matchDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateFormatted = matchDate.toLocaleDateString([], { month: 'short', day: 'numeric' });

  // Prize funding status styling
  const prizeStatusLabel = {
    guaranteed: language === 'bn' ? 'গ্যারান্টিযুক্ত প্রাইজ' : 'Guaranteed Prize',
    funded: language === 'bn' ? 'ফান্ডেড পুল' : 'Funded Pool',
    planned: language === 'bn' ? 'পরিকল্পিত পুল' : 'Planned Pool'
  }[tournament.prizePoolStatus || 'guaranteed'];

  const prizeStatusBadgeClass = {
    guaranteed: 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400',
    funded: 'bg-blue-500/10 border-blue-500/40 text-blue-400',
    planned: 'bg-amber-500/10 border-amber-500/40 text-amber-400'
  }[tournament.prizePoolStatus || 'guaranteed'];

  // Check room status
  const roomCreds = getSecureRoomCredentials(tournament.id);

  return (
    <div className="bg-[#10141d] border border-slate-800/80 hover:border-red-600/50 rounded-2xl overflow-hidden transition-all duration-200 shadow-lg shadow-black/40 flex flex-col group">
      {/* Banner & Overlay */}
      <div className="relative h-40 w-full overflow-hidden bg-slate-900">
        <img 
          src={tournament.bannerImage} 
          alt={tournament.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#10141d] via-[#10141d]/40 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-black/75 backdrop-blur-md rounded-lg border border-white/10 text-xs font-semibold text-white">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span className="uppercase tracking-wider">{tournament.category.replace('_', ' ')}</span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Prize pool funding status badge */}
            <div className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold tracking-wider backdrop-blur-md border flex items-center gap-1 ${prizeStatusBadgeClass}`}>
              <ShieldCheck className="w-3 h-3" />
              <span>{prizeStatusLabel}</span>
            </div>

            {/* Match Status */}
            <div className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold uppercase tracking-wider backdrop-blur-md border ${
              tournament.status === 'upcoming' 
                ? 'bg-blue-600/80 border-blue-400 text-white' 
                : tournament.status === 'ongoing' 
                ? 'bg-emerald-600/80 border-emerald-400 text-white animate-pulse'
                : tournament.status === 'cancelled'
                ? 'bg-red-600/80 border-red-400 text-white'
                : 'bg-slate-700/80 border-slate-600 text-slate-300'
            }`}>
              {tournament.status === 'upcoming' ? 'Upcoming' : tournament.status === 'ongoing' ? 'Live Now' : tournament.status === 'cancelled' ? 'Cancelled' : 'Completed'}
            </div>
          </div>
        </div>

        {/* Registered Indicator on Banner */}
        {isUserRegistered && (
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600/90 text-white text-xs font-bold rounded-lg border border-emerald-400 shadow-md">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Registered · Slot #{userSlot?.slotNumber}</span>
          </div>
        )}

        {/* Room Status Indicator (Exact 4 States) */}
        <div className="absolute bottom-3 right-3">
          {tournament.status === 'completed' || tournament.roomStatus === 'completed' ? (
            <div className="flex items-center gap-1 px-2 py-0.5 bg-black/80 border border-slate-700 rounded-lg text-[10px] font-medium text-slate-300 backdrop-blur-sm">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Match completed</span>
            </div>
          ) : tournament.roomStatus === 'available' ? (
            <div className="flex items-center gap-1 px-2 py-0.5 bg-black/80 border border-emerald-500/50 rounded-lg text-[10px] font-bold text-emerald-400 backdrop-blur-sm">
              <Key className="w-3 h-3" />
              <span>Room details available</span>
            </div>
          ) : tournament.roomStatus === 'scheduled' ? (
            <div className="flex items-center gap-1 px-2 py-0.5 bg-black/80 border border-amber-500/50 rounded-lg text-[10px] font-bold text-amber-400 backdrop-blur-sm">
              <Clock className="w-3 h-3" />
              <span>Waiting for room details</span>
            </div>
          ) : (
            <div className="flex items-center gap-1 px-2 py-0.5 bg-black/80 border border-slate-700 rounded-lg text-[10px] font-medium text-slate-400 backdrop-blur-sm">
              <span>Room details not added</span>
            </div>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata line: clean unboxed text with typographic separators */}
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1.5 flex-wrap">
            <span className="flex items-center gap-1 text-slate-300">
              <MapPin className="w-3 h-3 text-red-400" />
              {tournament.map}
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-slate-300">
              <Calendar className="w-3 h-3 text-red-400" />
              {dateFormatted}, {timeFormatted}
            </span>
            <span aria-hidden="true">·</span>
            <span>{tournament.version}</span>
          </div>

          {/* Title */}
          <h3 className="text-base font-bold text-white group-hover:text-red-400 transition-colors line-clamp-1 mb-1">
            {tournament.title}
          </h3>
          <p className="text-xs text-slate-400 line-clamp-1 mb-4">
            {tournament.subtitle}
          </p>

          {/* Actual Prize and Stats Matrix (Fully dynamic and customized) */}
          <div className="grid grid-cols-3 gap-2 bg-[#090b10] border border-slate-800/80 rounded-xl p-2.5 mb-4 text-center">
            <div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                {language === 'bn' ? 'মোট পুরস্কার' : 'Total Prize'}
              </div>
              <div className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
                ৳{tournament.totalPrize}
              </div>
            </div>

            <div className="border-x border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                {language === 'bn' ? 'প্রতি কিল' : 'Per Kill'}
              </div>
              <div className="text-sm font-bold font-mono text-amber-400 tabular-nums">
                ৳{tournament.perKill}
              </div>
            </div>

            <div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                {language === 'bn' ? 'এন্ট্রি ফি' : 'Entry Fee'}
              </div>
              <div className="text-sm font-bold font-mono text-red-400 tabular-nums">
                ৳{tournament.entryFee}
              </div>
            </div>
          </div>
        </div>

        {/* Slot Progress & CTA */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-400 flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              {tournament.bookedSlots} / {tournament.totalSlots} {language === 'bn' ? 'স্লট বুকড' : 'Slots Filled'}
            </span>
            <span className={`font-mono text-xs font-semibold ${slotsRemaining <= 5 ? 'text-red-400' : 'text-slate-300'}`}>
              {slotsRemaining} {language === 'bn' ? 'বাকি' : 'left'}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-4">
            <div 
              className="h-full bg-gradient-to-r from-red-600 to-amber-500 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Action Trigger */}
          <button
            onClick={() => setSelectedTournament(tournament)}
            className={`w-full py-2.5 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-transform active:scale-[0.98] ${
              isUserRegistered
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-600/30'
                : slotsRemaining === 0
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-md shadow-red-950/40'
            }`}
          >
            <span>
              {isUserRegistered 
                ? (language === 'bn' ? 'রেজিস্ট্রেশন স্লট ও রুম আইডি দেখুন' : 'View Room ID & Slot')
                : slotsRemaining === 0 
                ? (language === 'bn' ? 'ম্যাচ পূর্ণ হয়েছে' : 'Match Full')
                : (language === 'bn' ? 'অংশগ্রহণ করুন (৳' + tournament.entryFee + ')' : `Join Match (৳${tournament.entryFee})`)}
            </span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
