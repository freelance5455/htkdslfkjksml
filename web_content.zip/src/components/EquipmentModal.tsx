import React from 'react';
import { Shield, Swords, Sparkles, Heart, Zap, Footprints, X, Backpack } from 'lucide-react';
import { computePlayerStats, ITEMS, RARITY_META } from '../game/data/items';
import { EquipmentState, EquipSlot, InventoryEntry } from '../game/types';
import { ItemIcon } from './ItemIcon';

interface EquipmentModalProps {
  open: boolean;
  level: number;
  equipment: EquipmentState;
  inventory: InventoryEntry[];
  onClose: () => void;
  onUnequipSlot: (slot: EquipSlot) => void;
  onEquipFromInventory: (inventoryIndex: number) => void;
  onOpenInventory: () => void;
}

const SLOT_LABELS: Array<{ slot: EquipSlot; labelAr: string }> = [
  { slot: 'helmet', labelAr: 'الخوذة' },
  { slot: 'chest', labelAr: 'الدرع' },
  { slot: 'mainHand', labelAr: 'السلاح الأساسي' },
  { slot: 'offHand', labelAr: 'السلاح الثانوي' },
  { slot: 'gloves', labelAr: 'القفازات' },
  { slot: 'boots', labelAr: 'الحذاء' },
  { slot: 'accessory', labelAr: 'الإكسسوار' },
];

export const EquipmentModal: React.FC<EquipmentModalProps> = ({
  open,
  level,
  equipment,
  inventory,
  onClose,
  onUnequipSlot,
  onEquipFromInventory,
  onOpenInventory,
}) => {
  if (!open) return null;

  const stats = computePlayerStats(level, equipment);
  const equippableInBag = inventory
    .map((entry, idx) => ({ entry, idx, def: ITEMS[entry.itemId] }))
    .filter((x) => x.def?.equipSlot);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-2 sm:p-5"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="hud-scroll max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-amber-500/35 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <Shield className="h-5 w-5 text-amber-400" />
            <h2 className="text-lg font-bold text-amber-100">الشخصية والمعدات</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenInventory}
              className="flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/15 px-3 py-1.5 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
            >
              <Backpack className="h-3.5 w-3.5" />
              فتح المخزون
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-12 sm:p-5">
          {/* Left: Character Silhouette & Live Stats */}
          <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-950/70 p-4 sm:col-span-5">
            <div className="flex flex-col items-center">
              <div className="relative flex h-36 w-36 items-center justify-center rounded-2xl border border-amber-500/30 bg-slate-900">
                {/* Stylized Hero Preview SVG */}
                <svg viewBox="0 0 80 100" className="h-32 w-28">
                  <path d="M26 28 L54 28 L60 72 L20 72 Z" fill="#7a1f32" opacity="0.85" />
                  <circle cx="40" cy="20" r="10" fill="#9fb0c4" stroke="#e6b84c" strokeWidth="1.5" />
                  <rect x="34" y="18" width="12" height="4" rx="1.5" fill="#38bdf8" />
                  <rect x="27" y="31" width="26" height="28" rx="4" fill="#1e4d6b" stroke="#9fb0c4" strokeWidth="2" />
                  <rect x="27" y="54" width="26" height="5" fill="#4a3121" />
                  <rect x="37" y="53" width="6" height="6" fill="#e6b84c" />
                  <rect x="28" y="60" width="9" height="26" rx="2" fill="#4a3121" />
                  <rect x="43" y="60" width="9" height="26" rx="2" fill="#4a3121" />
                  <path d="M60 22 L64 62 L58 62 Z" fill="#cbd5e1" stroke="#38bdf8" strokeWidth="1" />
                </svg>
                <span className="absolute bottom-2 rounded bg-amber-500/20 px-2 py-0.5 text-[11px] font-bold text-amber-300">
                  المستوى {level}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Swords className="h-3.5 w-3.5 text-rose-400" />
                <span>الهجوم: <strong>{stats.attack}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Shield className="h-3.5 w-3.5 text-sky-400" />
                <span>الدفاع: <strong>{stats.defense}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Sparkles className="h-3.5 w-3.5 text-purple-400" />
                <span>السحر: <strong>{stats.magic}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Heart className="h-3.5 w-3.5 text-emerald-400" />
                <span>الصحة: <strong>{stats.maxHp}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Zap className="h-3.5 w-3.5 text-indigo-400" />
                <span>المانا: <strong>{stats.maxMana}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 p-2">
                <Footprints className="h-3.5 w-3.5 text-teal-400" />
                <span>السرعة: <strong>{Math.round(stats.speedMultiplier * 100)}%</strong></span>
              </div>
            </div>
          </div>

          {/* Right: 7 Equipment Slots + Quick Swap from Bag */}
          <div className="space-y-4 sm:col-span-7">
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-2">
              {SLOT_LABELS.map(({ slot, labelAr }) => {
                const itemId = equipment[slot];
                const def = itemId ? ITEMS[itemId] : null;
                const r = def ? RARITY_META[def.rarity] : null;
                return (
                  <div
                    key={slot}
                    className={`flex items-center justify-between gap-2 rounded-xl border-2 p-2.5 ${
                      r ? `${r.borderClass} ${r.bgClass}` : 'border-slate-800 bg-slate-950/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-700 bg-slate-900">
                        {def ? (
                          <ItemIcon kind={def.icon} tintHex={def.tintHex} className="h-8 w-8" />
                        ) : (
                          <span className="text-[10px] text-slate-500">فارغ</span>
                        )}
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">{labelAr}</div>
                        <div className="text-xs font-bold text-slate-100">
                          {def ? def.nameAr : 'غير مجهز'}
                        </div>
                      </div>
                    </div>
                    {def && (
                      <button
                        type="button"
                        onClick={() => onUnequipSlot(slot)}
                        className="rounded-lg border border-slate-600 bg-slate-800 px-2 py-1 text-[10px] font-bold text-slate-200 hover:bg-slate-700"
                      >
                        إزالة
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quick Equip from Bag */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="mb-2 text-xs font-bold text-amber-300">
                تبديل سريع من المخزون ({equippableInBag.length})
              </div>
              {equippableInBag.length === 0 ? (
                <div className="text-xs text-slate-400">لا توجد معدات إضافية في الحقيبة حالياً.</div>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {equippableInBag.map(({ idx, def }) => {
                    const r = RARITY_META[def.rarity];
                    return (
                      <button
                        key={`${def.id}_${idx}`}
                        type="button"
                        onClick={() => onEquipFromInventory(idx)}
                        className={`flex items-center justify-between gap-2 rounded-lg border p-2 text-right transition hover:brightness-110 ${r.borderClass} ${r.bgClass}`}
                      >
                        <div className="flex items-center gap-2">
                          <ItemIcon kind={def.icon} tintHex={def.tintHex} className="h-7 w-7 shrink-0" />
                          <div>
                            <div className="text-xs font-bold text-white">{def.nameAr}</div>
                            <div className={`text-[10px] ${r.textClass}`}>{r.labelAr}</div>
                          </div>
                        </div>
                        <span className="rounded bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-200">
                          تجهيز
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
