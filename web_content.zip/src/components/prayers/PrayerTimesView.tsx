import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Compass,
  Clock,
  CheckCircle2,
  MapPin,
  Settings,
  Bell,
  Calendar,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Sun,
} from 'lucide-react';
import {
  CALCULATION_METHOD_NAMES,
  POPULAR_CITIES,
  getTimeUntilNextPrayer,
  calculatePrayerTimes,
} from '../../utils/prayerCalculator';
import { PrayerSettings } from '../../types';

export const PrayerTimesView: React.FC = () => {
  const {
    currentTime,
    prayersToday,
    nextPrayer,
    togglePrayerCompleted,
    prayerSettings,
    updatePrayerSettings,
    completedPrayersRecord,
  } = useApp();

  const [countdown, setCountdown] = useState<{ hours: number; minutes: number; seconds: number } | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Selected date for viewing / logging (defaults to today)
  const [selectedDateOffset, setSelectedDateOffset] = useState<number>(0);

  // Prayer countdown tick
  useEffect(() => {
    if (!nextPrayer) return;

    const tick = () => {
      const res = getTimeUntilNextPrayer(nextPrayer);
      setCountdown(res);
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [nextPrayer]);

  // Active date object
  const activeDate = useMemo(() => {
    const d = new Date(currentTime);
    d.setDate(d.getDate() + selectedDateOffset);
    return d;
  }, [currentTime, selectedDateOffset]);

  const activeDateStr = useMemo(() => activeDate.toISOString().split('T')[0], [activeDate]);
  const isViewingToday = selectedDateOffset === 0;

  // Active date prayers
  const completedForActiveDate = completedPrayersRecord[activeDateStr] || [];
  const activePrayers = useMemo(() => {
    return calculatePrayerTimes(activeDate, prayerSettings, completedForActiveDate);
  }, [activeDate, prayerSettings, completedForActiveDate]);

  // Weekly compliance (past 7 days)
  const weeklyStats = useMemo(() => {
    let totalPrayersTarget = 7 * 5;
    let completedCount = 0;

    for (let i = 0; i < 7; i++) {
      const d = new Date(currentTime);
      d.setDate(d.getDate() - i);
      const str = d.toISOString().split('T')[0];
      const list = completedPrayersRecord[str] || [];
      completedCount += list.filter((p) => p !== 'sunrise').length;
    }

    const pct = Math.round((completedCount / totalPrayersTarget) * 100);
    return { completedCount, totalPrayersTarget, pct };
  }, [completedPrayersRecord, currentTime]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner with Next Prayer & City info */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden transition-all border border-rose-200/20"
        style={{
          background: `linear-gradient(135deg, rgba(159, 18, 57, 0.92) 0%, rgba(225, 29, 72, 0.88) 50%, rgba(136, 19, 55, 0.95) 100%), url('/public/assets/aistudio/images_5d51feea.jpg') center/cover no-repeat`,
        }}
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-rose-100 text-xs font-semibold">
              <Compass className="w-4 h-4 text-pink-200" />
              <span>مواقيت الصلاة المعتمدة</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {prayerSettings.cityName} ({CALCULATION_METHOD_NAMES[prayerSettings.method]})
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight drop-shadow-xs">
              {nextPrayer ? `الصلاة القادمة: صلاة ${nextPrayer.nameAr}` : 'صلوات اليوم'}
            </h2>

            {nextPrayer && (
              <div className="flex items-center gap-3 text-sm text-rose-100/90">
                <span>الموعد: {nextPrayer.formattedTime}</span>
                <span>·</span>
                <span className="font-mono tabular-nums text-white bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-white/20 font-bold">
                  الوقت المتبقي:{' '}
                  {countdown
                    ? `${String(countdown.hours).padStart(2, '0')}:${String(countdown.minutes).padStart(
                        2,
                        '0'
                      )}:${String(countdown.seconds).padStart(2, '0')}`
                    : '--:--:--'}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSettingsModal(true)}
              className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-md border border-white/30 transition-all flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              <span>تغيير المدينة وطريقة الحساب</span>
            </button>
          </div>
        </div>
      </div>

      {/* Date Navigator */}
      <div className="flex items-center justify-between bg-white dark:bg-[#1a0f18] p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
        <button
          onClick={() => setSelectedDateOffset(selectedDateOffset - 1)}
          className="p-2 rounded-lg border border-rose-200/60 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-rose-200"
          title="اليوم السابق"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-rose-100">
          <Calendar className="w-4 h-4 text-rose-600" />
          <span>
            {activeDate.toLocaleDateString('ar-EG', {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </span>
          {isViewingToday && (
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-200">
              اليوم
            </span>
          )}
        </div>

        <button
          onClick={() => setSelectedDateOffset(selectedDateOffset + 1)}
          className="p-2 rounded-lg border border-rose-200/60 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-rose-200"
          title="اليوم التالي"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Prayers Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {activePrayers.map((prayer) => {
          const isSunrise = prayer.id === 'sunrise';

          return (
            <div
              key={prayer.id}
              className={`p-4 rounded-2xl border text-center transition-all ${
                isSunrise
                  ? 'bg-gradient-to-b from-amber-50/50 to-rose-50/30 dark:from-amber-950/30 dark:to-[#1a0f18] border-amber-200/80 dark:border-amber-900/50 shadow-xs'
                  : prayer.isCompleted
                  ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800 shadow-xs'
                  : prayer.isNext && isViewingToday
                  ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 shadow-md ring-2 ring-rose-500/20'
                  : 'bg-white dark:bg-[#1a0f18] border-rose-100 dark:border-rose-950/60'
              }`}
            >
              <div className="flex items-center justify-center gap-1 text-xs font-bold text-slate-600 dark:text-rose-200/80 mb-1">
                {isSunrise ? <Sun className="w-3.5 h-3.5 text-amber-500" /> : null}
                <span>{isSunrise ? 'شروق الشمس' : prayer.nameAr}</span>
              </div>

              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-rose-100 mb-2">
                {prayer.formattedTime}
              </div>

              {!isSunrise ? (
                <button
                  onClick={() => togglePrayerCompleted(prayer.id, activeDateStr)}
                  className={`w-full py-1.5 px-2 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                    prayer.isCompleted
                      ? 'bg-rose-600 text-white hover:bg-rose-700'
                      : 'bg-rose-50/60 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-800 dark:text-rose-200 border border-rose-200/50 dark:border-rose-900/40'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{prayer.isCompleted ? 'تمت الصلاة' : 'سجّل الأداء'}</span>
                </button>
              ) : (
                <div className="text-[11px] font-semibold text-amber-700 dark:text-amber-300/80 bg-amber-100/60 dark:bg-amber-950/60 py-1 px-2 rounded-lg border border-amber-200/50 dark:border-amber-900/40">
                  خروج وقت الفجر
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Weekly Prayer Regularity Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Regularity Card */}
        <div className="bg-white dark:bg-[#1a0f18] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-rose-600" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-rose-100">
                معدل الانتظام الأسبوعي في الصلاة
              </h3>
            </div>
            <span className="font-mono tabular-nums font-bold text-sm text-rose-600 dark:text-rose-400">
              {weeklyStats.pct}%
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-rose-300/70 mb-3">
            سجلت أداء {weeklyStats.completedCount} صلاة من إجمالي 35 فريضة خلال الأيام السبعة الماضية.
          </p>

          <div className="w-full bg-rose-100/50 dark:bg-rose-950/40 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-rose-500 to-pink-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${weeklyStats.pct}%` }}
            />
          </div>
        </div>

        {/* Reminder Settings Info */}
        <div className="bg-white dark:bg-[#1a0f18] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
          <div className="flex items-center gap-2 mb-2">
            <Bell className="w-4 h-4 text-rose-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-rose-100">
              نظام التنبيهات المسبقة للصلوات
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-300/70 leading-relaxed mb-3">
            ينبهك التطبيق قبل موعد كل فريضة بـ {prayerSettings.reminderMinutesBefore} دقيقة،
            مع تفريغ أوتوماتيكي لجدول المذاكرة أثناء وقت الأذان والفرض.
          </p>
          <div className="text-xs text-rose-700 dark:text-rose-300 font-medium">
            ✓ التنبيه الصوتي مفعل | طريقة الحساب: {CALCULATION_METHOD_NAMES[prayerSettings.method]}
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                إعدادات مواقيت الصلاة والمدينة
              </h3>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg"
              >
                ×
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اختر المدينة
                </label>
                <select
                  value={prayerSettings.cityName}
                  onChange={(e) => updatePrayerSettings({ cityName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                >
                  {POPULAR_CITIES.map((c) => (
                    <option key={c.nameAr} value={c.nameAr}>
                      {c.nameAr} - {c.countryAr}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  طريقة الحساب الفلكي
                </label>
                <select
                  value={prayerSettings.method}
                  onChange={(e) =>
                    updatePrayerSettings({ method: e.target.value as PrayerSettings['method'] })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                >
                  <option value="Egypt">الهيئة المصرية العامة للمساحة</option>
                  <option value="Makkah">جامعة أم القرى - مكة المكرمة</option>
                  <option value="MWL">رابطة العالم الإسلامي</option>
                  <option value="Karachi">جامعة العلوم الإسلامية بكراتشي</option>
                  <option value="ISNA">الاتحاد الإسلامي لأمريكا الشمالية</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  حساب صلاة العصر (المذهب الفقهي)
                </label>
                <select
                  value={prayerSettings.asrJuristic}
                  onChange={(e) =>
                    updatePrayerSettings({ asrJuristic: e.target.value as 'Standard' | 'Hanafi' })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                >
                  <option value="Standard">الشافعي، المالكي، الحنبلي (طول الظل = مثل طول الشيء)</option>
                  <option value="Hanafi">المذهب الحنفي (طول الظل = مثلي طول الشيء)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  التذكير قبل موعد الصلاة
                </label>
                <select
                  value={prayerSettings.reminderMinutesBefore}
                  onChange={(e) =>
                    updatePrayerSettings({ reminderMinutesBefore: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                >
                  <option value={5}>5 دقائق قبل الأذان</option>
                  <option value={10}>10 دقائق قبل الأذان</option>
                  <option value={15}>15 دقيقة قبل الأذان (الموصى بها)</option>
                  <option value={30}>30 دقيقة قبل الأذان</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowSettingsModal(false)}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl"
              >
                حفظ الإعدادات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
