import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Code,
  Cpu,
  Layers,
  RefreshCw,
  Search,
  Shield,
  ShieldAlert,
  Terminal,
  Wrench,
} from 'lucide-react';
import { TaskItem, TaskStep } from '../types.ts';

interface TaskInspectorProps {
  tasks: TaskItem[];
  selectedTaskId: string | null;
  onSelectTask: (id: string) => void;
  onApproveTask: (id: string) => void;
  onRejectTask: (id: string, reason?: string) => void;
}

export const TaskInspector: React.FC<TaskInspectorProps> = ({
  tasks,
  selectedTaskId,
  onSelectTask,
  onApproveTask,
  onRejectTask,
}) => {
  const currentTask = tasks.find((t) => t.id === selectedTaskId) || tasks[0] || null;

  if (!currentTask) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-600 font-mono text-sm shadow-xs">
        <Terminal className="w-8 h-8 mx-auto mb-3 text-slate-400" />
        <p className="font-semibold text-slate-800">No autonomous tasks recorded yet.</p>
        <p className="text-xs text-slate-500 mt-1">
          Submit an objective in the Command Center to spawn an autonomous DAG task.
        </p>
      </div>
    );
  }

  return (
    <div id="task-inspector-panel" className="grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Left Column: Task List (4 cols) */}
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-3.5 flex flex-col h-[680px] shadow-xs">
        <div className="px-2 py-2 border-b border-slate-200 mb-2 flex items-center justify-between">
          <span className="text-xs font-mono font-bold text-slate-800 uppercase tracking-wide">
            Task Queue ({tasks.length})
          </span>
          <span className="text-[10px] font-mono text-slate-500 font-medium">LATEST FIRST</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 scrollbar-thin">
          {tasks.map((task) => {
            const isSelected = task.id === currentTask.id;
            const isWaiting = task.status === 'WAITING_PERMISSION';
            const isSuccess = task.status === 'COMPLETED';
            const isFailed = task.status === 'FAILED';

            return (
              <button
                key={task.id}
                onClick={() => onSelectTask(task.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs font-mono shadow-xs ${
                  isSelected
                    ? 'bg-sky-50 border-sky-300 text-sky-950 ring-1 ring-sky-300 shadow-xs'
                    : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:border-slate-300 hover:text-slate-900 hover:bg-slate-100/80'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-semibold text-slate-900 truncate pr-2">{task.title}</span>
                  {isWaiting && (
                    <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold animate-pulse">
                      GATE
                    </span>
                  )}
                  {isSuccess && (
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-300 text-[10px] font-bold">
                      DONE
                    </span>
                  )}
                  {isFailed && (
                    <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-900 border border-rose-300 text-[10px] font-bold">
                      FAIL
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>Steps: {task.plan?.steps.length || 0}</span>
                  <span>{new Date(task.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right Column: Task Detail & Step Execution Flow (8 cols) */}
      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col h-[680px] overflow-y-auto shadow-xs scrollbar-thin">
        {/* Header Information */}
        <div className="border-b border-slate-200 pb-3.5 mb-4">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-600 font-semibold">
                TASK ID: {currentTask.id}
              </span>
              <h2 className="text-base font-bold text-slate-900 mt-1.5 font-sans">{currentTask.title}</h2>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-slate-50 border border-slate-200 text-slate-700 shadow-xs">
                STATUS: <strong className="text-sky-700 font-bold">{currentTask.status}</strong>
              </span>
              <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-slate-50 border border-slate-200 text-slate-700 shadow-xs">
                STAGE: <strong className="text-slate-900 font-semibold">{currentTask.currentStage}</strong>
              </span>
            </div>
          </div>

          <div className="text-xs text-slate-700 font-mono bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
            <strong className="text-slate-900">Goal:</strong> {currentTask.rawPrompt}
          </div>

          {/* Plan Metadata */}
          {currentTask.plan && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-3 text-xs font-mono">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block text-[10px]">ROUTED MODEL</span>
                <span className="text-sky-800 font-bold">{currentTask.plan.primaryModel}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block text-[10px]">EFFORT ESTIMATE</span>
                <span className="text-slate-800 font-semibold uppercase">{currentTask.plan.estimatedEffort}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block text-[10px]">SKILLS BOUND</span>
                <span className="text-slate-800 font-semibold">{currentTask.plan.selectedSkills.length} active</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block text-[10px]">TOOLS BOUND</span>
                <span className="text-slate-800 font-semibold">{currentTask.plan.selectedTools.length} tools</span>
              </div>
            </div>
          )}
        </div>

        {/* Security Approval Challenge if Pending */}
        {currentTask.status === 'WAITING_PERMISSION' && currentTask.pendingPermissionStep && (
          <div className="bg-amber-50 border-2 border-amber-400 rounded-xl p-4 mb-4 shadow-xs">
            <div className="flex items-center gap-2 text-amber-900 font-mono text-xs font-bold mb-2">
              <ShieldAlert className="w-4 h-4 text-amber-700" />
              <span>SECURITY CLEARANCE CHALLENGE: OPERATOR APPROVAL REQUIRED</span>
            </div>
            <p className="text-xs text-slate-800 mb-3 leading-relaxed font-sans">
              Step #{currentTask.pendingPermissionStep.stepNumber} (
              <strong className="text-slate-900">{currentTask.pendingPermissionStep.title}</strong>) attempts to execute tool{' '}
              <span className="font-mono text-sky-800 font-bold">"{currentTask.pendingPermissionStep.toolName}"</span> under
              elevated boundary policy.
            </p>

            <div className="flex items-center gap-3">
              <button
                id="task-approve-btn"
                onClick={() => onApproveTask(currentTask.id)}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs font-mono transition-all shadow-xs"
              >
                GRANT CLEARANCE & EXECUTE
              </button>
              <button
                id="task-reject-btn"
                onClick={() => onRejectTask(currentTask.id, 'Declined by human operator')}
                className="px-4 py-2 rounded-lg bg-white hover:bg-rose-50 hover:text-rose-700 text-slate-700 font-mono text-xs transition-all border border-slate-300 font-medium"
              >
                DENY PERMISSION
              </button>
            </div>
          </div>
        )}

        {/* Execution Steps DAG / Tree */}
        <div className="flex-1 space-y-3">
          <span className="text-xs font-mono uppercase text-slate-700 font-bold block tracking-wide">
            Plan Execution Graph & Verification Status
          </span>

          {currentTask.plan?.steps.map((step) => {
            const isVerified = step.status === 'VERIFIED';
            const isRunning = step.status === 'RUNNING';
            const isWaiting = step.status === 'WAITING_PERMISSION';
            const isFailed = step.status === 'FAILED';

            return (
              <div
                key={step.id}
                className={`p-4 rounded-xl border transition-all text-xs font-mono shadow-xs ${
                  isVerified
                    ? 'bg-emerald-50/40 border-emerald-300 text-slate-900'
                    : isRunning
                    ? 'bg-sky-50 border-sky-400 text-sky-950 ring-1 ring-sky-300 font-semibold'
                    : isWaiting
                    ? 'bg-amber-50 border-amber-400 text-amber-950'
                    : isFailed
                    ? 'bg-rose-50 border-rose-300 text-rose-950'
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-white border border-slate-300 flex items-center justify-center font-bold text-[11px] text-sky-700">
                      {step.stepNumber}
                    </span>
                    <span className="font-bold text-slate-900">{step.title}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-white text-slate-700 border border-slate-200 text-[10px] font-medium">
                      AGENT: {step.assignedAgent}
                    </span>
                    {step.toolName && (
                      <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-900 border border-sky-200 text-[10px] font-semibold">
                        TOOL: {step.toolName}
                      </span>
                    )}
                    {step.toolResult?.executionState && (
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          step.toolResult.executionState === 'REAL'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : step.toolResult.executionState === 'SIMULATED'
                            ? 'bg-indigo-100 text-indigo-900 border-indigo-300'
                            : step.toolResult.executionState === 'UNAVAILABLE'
                            ? 'bg-rose-100 text-rose-900 border-rose-300'
                            : 'bg-amber-100 text-amber-900 border-amber-300'
                        }`}
                      >
                        MODE: {step.toolResult.executionState}
                      </span>
                    )}
                    {step.toolResult?.executionTimeMs !== undefined && (
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-mono">
                        {step.toolResult.executionTimeMs}ms
                      </span>
                    )}
                    <span className="font-bold text-[11px] uppercase">
                      {isVerified ? (
                        <span className="text-emerald-700 flex items-center gap-1 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" /> VERIFIED
                        </span>
                      ) : isRunning ? (
                        <span className="text-sky-700 flex items-center gap-1 animate-pulse font-bold">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> RUNNING
                        </span>
                      ) : isWaiting ? (
                        <span className="text-amber-800 flex items-center gap-1 font-bold">
                          <AlertTriangle className="w-3.5 h-3.5" /> GATED
                        </span>
                      ) : step.status === 'UNAVAILABLE' ? (
                        <span className="text-rose-700 flex items-center gap-1 font-bold">
                          <AlertCircle className="w-3.5 h-3.5" /> UNAVAILABLE
                        </span>
                      ) : (
                        <span className="text-slate-500">{step.status}</span>
                      )}
                    </span>
                  </div>
                </div>

                <p className="text-slate-600 mb-2.5 font-sans text-xs leading-relaxed">{step.description}</p>

                {/* Verification Criteria */}
                <div className="bg-white p-2.5 rounded-lg border border-slate-200 text-[11px] space-y-1">
                  <div className="text-slate-700">
                    <strong className="text-slate-900">Criteria:</strong> {step.verificationCriteria}
                  </div>
                  {step.verificationResult && (
                    <div className="text-emerald-800 flex items-center justify-between border-t border-slate-100 pt-1.5 mt-1 font-medium">
                      <span>Checks: {step.verificationResult.checksPerformed.join(' • ')}</span>
                      <span className="font-bold">Score: {Math.round(step.verificationResult.score * 100)}%</span>
                    </div>
                  )}
                </div>

                {/* Output toggle preview if present */}
                {step.toolOutput !== undefined && (
                  <details className="mt-2 text-[11px]">
                    <summary className="cursor-pointer text-sky-700 hover:text-sky-900 hover:underline font-semibold">
                      View Tool Execution Payload Output
                    </summary>
                    <pre className="bg-slate-900 text-slate-100 p-2.5 rounded-lg mt-1 max-h-40 overflow-auto text-[10px]">
                      {JSON.stringify(step.toolOutput, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            );
          })}
        </div>

        {/* Task Audit Logs */}
        <div className="mt-4 pt-3 border-t border-slate-200">
          <span className="text-xs font-mono uppercase text-slate-800 font-bold block mb-2 tracking-wide">
            Kernel Execution Telemetry Log
          </span>
          <div className="bg-slate-900 p-3 rounded-xl max-h-36 overflow-y-auto space-y-1 font-mono text-[11px] text-slate-200 scrollbar-thin shadow-xs">
            {currentTask.logs.map((line, i) => (
              <div key={i} className="flex items-start gap-1.5">
                <span className="text-sky-400 font-bold">&gt;</span>
                <span>{line}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
