import React, { useState, useEffect } from 'react';
import { Player } from '../types.ts';
import { PlayerHead } from './PlayerHead.tsx';
import { X, Copy, Check, MessageSquare, Terminal, ExternalLink } from 'lucide-react';
import { sounds } from '../utils/audio.ts';

interface PlayerDetailModalProps {
  player: Player | null;
  onClose: () => void;
  soundEnabled?: boolean;
}

export const PlayerDetailModal: React.FC<PlayerDetailModalProps> = ({
  player,
  onClose,
  soundEnabled = true
}) => {
  const [copiedName, setCopiedName] = useState(false);
  const [copiedMsg, setCopiedMsg] = useState(false);
  const [copiedTp, setCopiedTp] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!player) return null;

  const playerName = player.displayName || player.name || 'Unbekannt';
  const cleanName = playerName.replace(/^[.*_]/, '');
  const isBedrock = playerName.startsWith('.');
  const platform = isBedrock ? 'Bedrock' : 'Java';

  const copyText = (text: string, type: 'name' | 'msg' | 'tp') => {
    navigator.clipboard.writeText(text);
    if (soundEnabled) sounds.playClickSound();

    if (type === 'name') {
      setCopiedName(true);
      setTimeout(() => setCopiedName(false), 2000);
    } else if (type === 'msg') {
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 2000);
    } else if (type === 'tp') {
      setCopiedTp(true);
      setTimeout(() => setCopiedTp(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm rounded-2xl bg-zinc-900 border border-zinc-800 p-6 shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Player Avatar Display */}
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="relative group">
            <PlayerHead
              identifier={playerName}
              uuid={player.uuid}
              size="xl"
              className="w-24 h-24 sm:w-28 sm:h-28 shadow-xl ring-2 ring-emerald-500/40"
            />
            <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-zinc-900" />
            </span>
          </div>

          <div>
            <div className="flex items-center justify-center gap-2">
              <h3 className="text-xl sm:text-2xl font-bold text-zinc-100 tracking-wide">
                {playerName}
              </h3>
              <span
                className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] font-semibold tracking-wide shrink-0 ${
                  isBedrock
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                    : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                }`}
              >
                {platform}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-400 font-medium mt-0.5">
              ● Gerade aktiv auf dem Server
            </p>
          </div>
        </div>

        {/* Quick Action Commands */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => copyText(playerName, 'name')}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-sm font-medium text-zinc-200 transition-colors border border-zinc-700/50"
          >
            <span className="flex items-center gap-2.5">
              <Copy className="w-4 h-4 text-emerald-400" />
              <span>Spielername kopieren</span>
            </span>
            {copiedName ? (
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Kopiert!
              </span>
            ) : (
              <span className="text-xs text-zinc-400 font-mono">{playerName}</span>
            )}
          </button>

          <button
            onClick={() => copyText(`/msg ${playerName} `, 'msg')}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-sm font-medium text-zinc-200 transition-colors border border-zinc-700/50"
          >
            <span className="flex items-center gap-2.5">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <span>Flüster-Befehl kopieren</span>
            </span>
            {copiedMsg ? (
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Kopiert!
              </span>
            ) : (
              <span className="text-xs text-zinc-400 font-mono">/msg {cleanName}</span>
            )}
          </button>

          <button
            onClick={() => copyText(`/tp ${playerName}`, 'tp')}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 text-sm font-medium text-zinc-200 transition-colors border border-zinc-700/50"
          >
            <span className="flex items-center gap-2.5">
              <Terminal className="w-4 h-4 text-amber-400" />
              <span>Teleport-Befehl kopieren</span>
            </span>
            {copiedTp ? (
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Kopiert!
              </span>
            ) : (
              <span className="text-xs text-zinc-400 font-mono">/tp {cleanName}</span>
            )}
          </button>
        </div>

        {/* Footer info & NameMC external link */}
        <div className="pt-2 border-t border-zinc-800 text-center">
          <a
            href={`https://namemc.com/profile/${encodeURIComponent(cleanName)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-emerald-400 transition-colors"
          >
            <span>Skin & Profil auf NameMC ansehen</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
