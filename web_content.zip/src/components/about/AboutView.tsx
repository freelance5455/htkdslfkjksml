import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  UserCheck,
  BookOpen,
  Globe,
  Linkedin,
  FileText,
  Download,
  Terminal,
  ShieldCheck,
  Smartphone,
  CheckCircle,
  ExternalLink,
  HelpCircle,
  Layers,
} from 'lucide-react';
import { exportAndroidProjectZip } from '../../utils/androidProjectFiles';

export const AboutView: React.FC = () => {
  const { triggerHaptic, showToast, settings } = useApp();
  const [isExportingZip, setIsExportingZip] = useState<boolean>(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'build' | 'install' | 'permissions'>('build');

  const handleDownloadAndroidZip = async () => {
    triggerHaptic();
    setIsExportingZip(true);
    try {
      const blob = await exportAndroidProjectZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'PocketToolkit-Android-Studio-Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('Android Studio Project ZIP downloaded!', 'success');
    } catch (err) {
      console.error(err);
      showToast('Error generating Android ZIP', 'warning');
    } finally {
      setIsExportingZip(false);
    }
  };

  const isUr = settings.language === 'ur';

  const developerLinks = [
    {
      title: 'Read My Articles',
      sub: 'Muck Rack Portfolio',
      url: 'https://muckrack.com/syed-salman-mehdi/articles',
      icon: FileText,
      color: 'bg-emerald-50 dark:bg-emerald-950/40 text-[#006C4C] dark:text-[#89F8C7]',
    },
    {
      title: 'Visit My Substack',
      sub: 'Essays & Analysis',
      url: 'https://salmanmehdi.substack.com/',
      icon: Globe,
      color: 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400',
    },
    {
      title: 'Visit My WordPress Blog',
      sub: 'Multithinker Journal',
      url: 'https://multithinker.wordpress.com/',
      icon: Globe,
      color: 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400',
    },
    {
      title: 'Visit My Blogspot',
      sub: 'Syed Salman Mehdi Journal',
      url: 'https://salmanmehdijournal.blogspot.com/',
      icon: Globe,
      color: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
    },
    {
      title: 'Connect on LinkedIn',
      sub: 'Professional Network',
      url: 'https://www.linkedin.com/in/multithinker/',
      icon: Linkedin,
      color: 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400',
    },
    {
      title: 'View My Book',
      sub: 'Archive.org Digital Library',
      url: 'https://archive.org/details/ruthless-might-ssm',
      icon: BookOpen,
      color: 'bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400',
    },
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Developer Profile Header Card */}
      <div className="bg-white dark:bg-[#1B221E] p-5 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-xs space-y-3">
        <div className="flex items-center space-x-3.5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#004D36] to-[#006C4C] text-white flex items-center justify-center font-bold text-xl shadow-md">
            SM
          </div>
          <div>
            <h2 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
              {isUr ? 'سید سلمان مہدی' : 'Syed Salman Mehdi'}
            </h2>
            <p className="text-xs font-semibold text-[#006C4C] dark:text-[#89F8C7]">
              Independent Writer, IT Specialist & Freelance Consultant
            </p>
            <p className="text-[11px] text-neutral-500 mt-0.5">Application ID: com.salmanmehdi.pockettoolkit</p>
          </div>
        </div>

        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed pt-2 border-t border-neutral-100 dark:border-neutral-800">
          Independent writer, IT specialist, and freelance IT consultant. Interested in technology, governance, human rights, regional affairs, and digital tools. Pocket Toolkit was built as a clean, offline-first, native utility suite that puts user privacy first without ads, trackers, or subscription paywalls.
        </p>
      </div>

      {/* Verified Outbound Links Grid */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 px-1">
          {isUr ? 'مصنف اور مشیر کے روابط' : 'Publications & Profiles'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {developerLinks.map((link) => {
            const Icon = link.icon;
            return (
              <a
                key={link.url}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => triggerHaptic()}
                className="p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all flex items-center justify-between group shadow-xs"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${link.color}`}>
                    <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs text-neutral-900 dark:text-neutral-100">{link.title}</h4>
                    <span className="text-[10px] text-neutral-400">{link.sub}</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-neutral-400 group-hover:text-[#006C4C] dark:group-hover:text-[#89F8C7] shrink-0" />
              </a>
            );
          })}
        </div>
      </div>

      {/* ANDROID STUDIO DELIVERY & APK GENERATION SECTION (Requirement 22) */}
      <div className="bg-emerald-900/10 dark:bg-emerald-950/40 p-5 rounded-3xl border border-emerald-600/30 space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#006C4C] text-white flex items-center justify-center shadow-xs">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100">
                Native Android Studio Project Delivery
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Kotlin 2.0 • Jetpack Compose • Material 3 • Room SQLite
              </p>
            </div>
          </div>
        </div>

        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          The complete, standard, buildable Android Gradle project is generated and bundled. You can download the entire source code as a ZIP file right now, open it in Android Studio, run it on an emulator, or build an installable APK for your phone.
        </p>

        {/* 1-Click ZIP Download Button */}
        <button
          onClick={handleDownloadAndroidZip}
          disabled={isExportingZip}
          className="w-full py-3 rounded-2xl bg-[#006C4C] hover:bg-[#004D36] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all disabled:opacity-50"
        >
          <Download className={`w-4 h-4 ${isExportingZip ? 'animate-bounce' : ''}`} />
          <span>{isExportingZip ? 'Packaging Android ZIP...' : 'Download Android Studio Project (.ZIP)'}</span>
        </button>

        {/* Guide Subtabs */}
        <div className="flex space-x-2 pt-2 border-t border-emerald-600/20 text-xs">
          <button
            onClick={() => setActiveGuideTab('build')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              activeGuideTab === 'build' ? 'bg-[#006C4C] text-white' : 'text-neutral-600 dark:text-neutral-300'
            }`}
          >
            How to Build APK
          </button>
          <button
            onClick={() => setActiveGuideTab('install')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              activeGuideTab === 'install' ? 'bg-[#006C4C] text-white' : 'text-neutral-600 dark:text-neutral-300'
            }`}
          >
            Install on Phone
          </button>
          <button
            onClick={() => setActiveGuideTab('permissions')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              activeGuideTab === 'permissions' ? 'bg-[#006C4C] text-white' : 'text-neutral-600 dark:text-neutral-300'
            }`}
          >
            Permissions & Sandbox
          </button>
        </div>

        {/* Guide Content */}
        {activeGuideTab === 'build' && (
          <div className="bg-white dark:bg-[#1B221E] p-3.5 rounded-2xl text-xs space-y-2 border border-neutral-200 dark:border-neutral-800">
            <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Building with Free Android Tools:</h4>
            <ol className="list-decimal list-inside space-y-1 text-neutral-600 dark:text-neutral-400">
              <li>Unzip the downloaded project ZIP into a folder.</li>
              <li>Open <strong>Android Studio</strong> and select <em>Open Project</em>.</li>
              <li>Wait for Gradle sync to complete automatically (JDK 17 included).</li>
              <li>
                To build a debug APK via terminal:
                <div className="mt-1 p-2 bg-neutral-900 text-emerald-400 rounded-lg font-mono text-[11px]">
                  ./gradlew assembleDebug
                </div>
              </li>
              <li>The APK will be generated at: <code className="text-neutral-800 dark:text-neutral-200">app/build/outputs/apk/debug/app-debug.apk</code>.</li>
            </ol>
          </div>
        )}

        {activeGuideTab === 'install' && (
          <div className="bg-white dark:bg-[#1B221E] p-3.5 rounded-2xl text-xs space-y-2 border border-neutral-200 dark:border-neutral-800">
            <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Sideloading on Physical Device:</h4>
            <ul className="list-disc list-inside space-y-1 text-neutral-600 dark:text-neutral-400">
              <li>Enable Developer Options: Settings &gt; About Phone &gt; Tap "Build Number" 7 times.</li>
              <li>Transfer <code className="text-neutral-800 dark:text-neutral-200">app-debug.apk</code> to your phone via USB, Drive, or Bluetooth.</li>
              <li>Tap the file in your phone's File Manager and click <strong>Install</strong>.</li>
              <li>Alternatively, connect via USB and run: <code className="bg-neutral-100 dark:bg-neutral-800 px-1 py-0.5 rounded">adb install -r app-debug.apk</code>.</li>
            </ul>
          </div>
        )}

        {activeGuideTab === 'permissions' && (
          <div className="bg-white dark:bg-[#1B221E] p-3.5 rounded-2xl text-xs space-y-2 border border-neutral-200 dark:border-neutral-800">
            <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Permissions & Sandbox Compliance:</h4>
            <ul className="list-disc list-inside space-y-1 text-neutral-600 dark:text-neutral-400">
              <li><strong>Zero Unnecessary Permissions:</strong> No contacts, SMS, phone calls, or storage scraping.</li>
              <li><strong>Offline Security:</strong> Notes, tasks, shopping, and history stay inside the private Room SQLite database.</li>
              <li><strong>Camera Permission:</strong> Only requested if you explicitly choose to open the QR Code scanner.</li>
            </ul>
          </div>
        )}
      </div>

      {/* Privacy Policy Guarantee */}
      <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-2 text-xs">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-[#006C4C] dark:text-[#89F8C7]" />
          <h4 className="font-bold text-neutral-900 dark:text-neutral-100">Pocket Toolkit Privacy Commitment</h4>
        </div>
        <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed">
          Pocket Toolkit was engineered by Syed Salman Mehdi with privacy as a foundational principle. The application contains zero advertising SDKs, zero analytics trackers, and zero remote data harvesting. All personal memos, financial calculations, passwords, and to-do lists are processed purely offline on your local device.
        </p>
      </div>

      {/* Version Tag */}
      <div className="text-center text-[11px] text-neutral-400 font-medium">
        Pocket Toolkit Native Android Edition • Version 1.0.0 • Developed by Syed Salman Mehdi
      </div>
    </div>
  );
};
