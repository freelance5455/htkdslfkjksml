import { BookOpen, ChevronLeft, Feather, Hourglass, ScrollText, Send, Undo2, Users, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { applyNarration, markChronicleSeen, restoreUndo } from "@/lib/roleforge/apply";
import { narrateTurn } from "@/lib/roleforge/narrate";
import { useForge } from "@/lib/roleforge/store";
import { formatClock } from "@/lib/roleforge/text";
import type { Entry, Mode } from "@/lib/roleforge/types";
import { Dossier, type DossierTab } from "./dossier";
import { Button } from "./ui";

const TABS: Array<{ id: DossierTab; label: string; icon: typeof Users }> = [
  { id: "escena", label: "Escena", icon: Feather },
  { id: "gente", label: "Gente", icon: Users },
  { id: "memoria", label: "Memoria", icon: BookOpen },
  { id: "cronica", label: "Crónica", icon: ScrollText },
  { id: "mundo", label: "Mundo", icon: Hourglass },
];

export function Play({ id }: { id: string }) {
  const campaign = useForge((state) => state.campaigns.find((item) => item.id === id));
  const upsert = useForge((state) => state.upsert);
  const [tab, setTab] = useState<DossierTab>("escena");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [text, setText] = useState("");
  const [openingLine, setOpeningLine] = useState("");
  const [withLine, setWithLine] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const lock = useRef(false);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [campaign?.entries.length, pending]);

  if (!campaign) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center gap-3 px-5">
        <p className="font-serif text-3xl">Esta partida no está aquí</p>
        <p className="text-mist">Solo vive en el dispositivo donde se forjó.</p>
        <Link to="/" className="inline-flex min-h-11 items-center text-ember">
          Volver a la biblioteca
        </Link>
      </main>
    );
  }

  const unread = campaign.chronicle.filter((event) => !event.seen).length;
  const started = campaign.entries.length > 0;

  function selectTab(next: DossierTab) {
    setTab(next);
    setMobileOpen(true);
    if (next !== "cronica") return;
    const latest = useForge.getState().campaigns.find((item) => item.id === id);
    if (!latest) return;
    const seen = markChronicleSeen(latest);
    if (seen !== latest) upsert(seen);
  }

  async function run(mode: Mode, playerText: string) {
    if (lock.current) return;
    const latest = useForge.getState().campaigns.find((item) => item.id === id);
    if (!latest) return;
    if (mode === "turno" && !playerText.trim()) return;
    lock.current = true;
    setPending(true);
    setError(null);
    setNote(null);
    try {
      const response = await narrateTurn({
        data: {
          mode,
          playerText: playerText.trim(),
          campaign: { ...latest, undo: null },
        },
      });
      if (!response.ok) {
        setError(response.error);
        return;
      }
      upsert(applyNarration(latest, response.result, { mode, playerText: playerText.trim() }));
      if (mode === "turno") setText("");
      if (mode === "apertura") {
        setOpeningLine("");
        setWithLine(false);
      }
      if (mode === "aliento" && response.result.beats.length === 0) {
        setNote("Pasó algo fuera de la vista de tu personaje. Está en la crónica.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo contactar al narrador.");
    } finally {
      lock.current = false;
      setPending(false);
    }
  }

  return (
    <div className="flex h-dvh flex-col bg-ink">
      <header className="flex items-center gap-1 border-b border-line pr-4">
        <Link to="/" aria-label="Biblioteca" className="inline-flex size-11 items-center justify-center text-mist">
          <ChevronLeft className="size-5" aria-hidden="true" />
        </Link>
        <div className="min-w-0 flex-1 py-2">
          <p className="truncate font-medium">{campaign.title}</p>
          <p className="truncate text-sm text-mist tabular-nums">
            {campaign.scene.place ? `${campaign.scene.place} · ` : ""}
            {formatClock(campaign.clock)}
          </p>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 lg:grid lg:grid-cols-[minmax(0,1fr)_22rem]">
        <section className="flex min-h-0 min-w-0 flex-col">
          <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 py-6">
            <div className="mx-auto grid w-full max-w-2xl gap-6">
              {!started ? (
                <div className="grid gap-3 py-8">
                  <p className="font-serif text-3xl text-parchment">La historia aún no arde.</p>
                  <p className="max-w-prose text-mist">
                    Encender la escena llama al narrador una sola vez. Tu personaje no hablará por su cuenta.
                  </p>
                </div>
              ) : null}
              {campaign.entries.map((entry) => (
                <TranscriptLine key={entry.id} entry={entry} ocName={campaign.oc.name} />
              ))}
              {pending ? <p className="text-sm text-mist">El narrador escucha…</p> : null}
            </div>
          </div>

          <div className="rf-dock border-t border-line px-4 pt-3 lg:pb-4">
            <div className="mx-auto grid w-full max-w-2xl gap-2">
              {error ? (
                <p className="text-sm text-ember" role="alert">
                  {error}
                </p>
              ) : null}
              {note ? <p className="text-sm text-mist">{note}</p> : null}
              {!started ? (
                <div className="grid gap-2">
                  {withLine ? (
                    <textarea
                      className="rf-field"
                      maxLength={2000}
                      placeholder={`Primer gesto de ${campaign.oc.name}`}
                      value={openingLine}
                      onChange={(event) => setOpeningLine(event.target.value)}
                    />
                  ) : null}
                  <div className="flex flex-wrap gap-2">
                    <Button disabled={pending} onClick={() => void run("apertura", openingLine)}>
                      Encender la escena
                    </Button>
                    <Button variant="ghost" disabled={pending} onClick={() => setWithLine((value) => !value)}>
                      {withLine ? "Sin gesto inicial" : "Entrar con una acción"}
                    </Button>
                  </div>
                </div>
              ) : (
                <form
                  className="grid gap-2"
                  onSubmit={(event) => {
                    event.preventDefault();
                    void run("turno", text);
                  }}
                >
                  <label className="grid gap-1">
                    <span className="sr-only">Acción o diálogo de {campaign.oc.name}</span>
                    <textarea
                      className="rf-field"
                      rows={3}
                      maxLength={2000}
                      placeholder={`Qué hace o dice ${campaign.oc.name}`}
                      value={text}
                      disabled={pending}
                      onChange={(event) => setText(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" && !event.shiftKey) {
                          event.preventDefault();
                          void run("turno", text);
                        }
                      }}
                    />
                  </label>
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" disabled={pending || !text.trim()}>
                      <Send className="size-4" aria-hidden="true" />
                      Decirlo
                    </Button>
                    <Button variant="quiet" disabled={pending} onClick={() => void run("aliento", "")}>
                      El mundo sigue
                    </Button>
                    {campaign.undo ? (
                      <Button
                        variant="ghost"
                        disabled={pending}
                        onClick={() => {
                          const restored = restoreUndo(campaign);
                          if (restored) upsert(restored);
                        }}
                      >
                        <Undo2 className="size-4" aria-hidden="true" />
                        Deshacer latido
                      </Button>
                    ) : null}
                  </div>
                </form>
              )}
            </div>
          </div>
        </section>

        <aside className="hidden min-h-0 flex-col gap-4 overflow-y-auto border-l border-line px-4 py-4 lg:flex">
          <TabRow tab={tab} unread={unread} onSelect={selectTab} />
          <Dossier campaign={campaign} tab={tab} onChange={upsert} />
        </aside>
      </div>

      <nav className="rf-nav fixed inset-x-0 bottom-0 z-10 grid grid-cols-5 border-t border-line bg-ink lg:hidden">
        {TABS.map((item) => {
          const Icon = item.icon;
          const active = mobileOpen && tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              className={active ? "flex min-h-12 flex-col items-center justify-center text-ember" : "flex min-h-12 flex-col items-center justify-center text-mist"}
              onClick={() => (active ? setMobileOpen(false) : selectTab(item.id))}
            >
              <span className="relative">
                <Icon className="size-5" aria-hidden="true" />
                {item.id === "cronica" && unread > 0 ? (
                  <span className="absolute -top-1 -right-2 size-2 rounded-full bg-ember" />
                ) : null}
              </span>
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {mobileOpen ? (
        <div className="fixed inset-0 z-20 overflow-y-auto bg-ink px-4 pt-3 pb-8 lg:hidden" role="dialog" aria-modal="true" aria-label={tab}>
          <div className="mb-4 flex items-center justify-between">
            <p className="font-serif text-2xl capitalize">{tab}</p>
            <button type="button" className="inline-flex size-11 items-center justify-center" aria-label="Cerrar" onClick={() => setMobileOpen(false)}>
              <X className="size-5" />
            </button>
          </div>
          <Dossier campaign={campaign} tab={tab} onChange={upsert} />
        </div>
      ) : null}
    </div>
  );
}

function TabRow({
  tab,
  unread,
  onSelect,
}: {
  tab: DossierTab;
  unread: number;
  onSelect: (tab: DossierTab) => void;
}) {
  return (
    <div className="flex flex-wrap gap-1">
      {TABS.map((item) => (
        <button
          key={item.id}
          type="button"
          aria-pressed={tab === item.id}
          className={tab === item.id ? "min-h-11 rounded-full bg-panel-2 px-3 text-sm text-parchment" : "min-h-11 rounded-full px-3 text-sm text-mist"}
          onClick={() => onSelect(item.id)}
        >
          {item.label}
          {item.id === "cronica" && unread > 0 ? ` · ${unread}` : ""}
        </button>
      ))}
    </div>
  );
}

function TranscriptLine({ entry, ocName }: { entry: Entry; ocName: string }) {
  if (entry.kind === "jugador") {
    return (
      <article className="ml-auto max-w-[92%] text-right">
        <p className="text-sm text-ember">{ocName}</p>
        <p className="font-serif text-lg leading-relaxed text-parchment">{entry.text}</p>
      </article>
    );
  }
  if (entry.kind === "dialogo") {
    return (
      <article className="max-w-[92%]">
        <p className="text-sm text-ember">{entry.speaker}</p>
        <p className="font-serif text-lg leading-relaxed text-parchment">{entry.text}</p>
      </article>
    );
  }
  if (entry.kind === "aparte") {
    return (
      <article className="max-w-prose">
        <p className="text-sm text-mist">Llega de forma indirecta</p>
        <p className="font-serif text-lg leading-relaxed text-mist italic">{entry.text}</p>
      </article>
    );
  }
  return <p className="max-w-prose font-serif text-lg leading-relaxed text-parchment">{entry.text}</p>;
}
