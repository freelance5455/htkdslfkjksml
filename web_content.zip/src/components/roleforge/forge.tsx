import { useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { applyNarration, blankCharacter, createCampaign } from "@/lib/roleforge/apply";
import { narrateTurn, suggestCast } from "@/lib/roleforge/narrate";
import { useForge } from "@/lib/roleforge/store";
import { sameName, uid } from "@/lib/roleforge/text";
import {
  DEFAULT_BOUNDARIES,
  type Autonomy,
  type Character,
  type ForgeSuggestion,
  type Original,
  type Place,
  type ProseDensity,
} from "@/lib/roleforge/types";
import { Button, Field, PageHeader, Segmented } from "./ui";

type Draft = {
  title: string;
  universe: string;
  premise: string;
  tone: string;
  rules: string;
  boundaries: string;
  prose: ProseDensity;
  autonomy: Autonomy;
  oc: Original;
  places: Place[];
  cast: Character[];
  opening: string;
};

const TONES = [
  "Íntimo y contenido, con silencios que pesan.",
  "Aventura en la que cada favor cobra un precio.",
  "Intriga: nadie dice de primeras lo que quiere.",
];

const PROSE = [
  { id: "breve" as const, label: "Breve" },
  { id: "equilibrada" as const, label: "Media" },
  { id: "literaria" as const, label: "Literaria" },
];

const AUTONOMY = [
  { id: "contenida" as const, label: "Contenida" },
  { id: "viva" as const, label: "Viva" },
  { id: "impredecible" as const, label: "Abierta" },
];

function emptyDraft(): Draft {
  return {
    title: "",
    universe: "",
    premise: "",
    tone: "",
    rules: "",
    boundaries: DEFAULT_BOUNDARIES,
    prose: "equilibrada",
    autonomy: "viva",
    oc: { name: "", pronouns: "", appearance: "", voice: "", background: "", goal: "", trait: "" },
    places: [{ id: "lugar-inicial", name: "", note: "" }],
    cast: [],
    opening: "",
  };
}

export function Forge() {
  const navigate = useNavigate();
  const upsert = useForge((state) => state.upsert);
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<Draft>(emptyDraft);
  const [pending, setPending] = useState<"reparto" | "escena" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [confirmCast, setConfirmCast] = useState(false);
  const lock = useRef(false);

  const patch = (partial: Partial<Draft>) => setDraft((current) => ({ ...current, ...partial }));

  async function forgeCast(force = false) {
    if (!force && draft.cast.some((character) => character.name.trim())) {
      setConfirmCast(true);
      return;
    }
    if (lock.current) return;
    lock.current = true;
    setPending("reparto");
    setError(null);
    setConfirmCast(false);
    try {
      const response = await suggestCast({
        data: {
          universe: draft.universe,
          premise: draft.premise,
          tone: draft.tone,
          rules: draft.rules,
          ocName: draft.oc.name,
          boundaries: draft.boundaries,
        },
      });
      if (!response.ok) {
        setError(response.error);
        return;
      }
      applySuggestion(response.suggestion);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo forjar el reparto.");
    } finally {
      lock.current = false;
      setPending(null);
    }
  }

  function applySuggestion(suggestion: ForgeSuggestion) {
    if (suggestion.reparto.length === 0 && suggestion.lugares.length === 0) return;
    const places =
      suggestion.lugares.length > 0
        ? suggestion.lugares.map((place) => ({ id: uid(), name: place.nombre, note: place.nota }))
        : draft.places;
    const cast = suggestion.reparto
      .filter((person) => !sameName(person.nombre, draft.oc.name))
      .map((person) =>
        blankCharacter({
          name: person.nombre,
          role: person.rol,
          appearance: person.apariencia,
          personality: person.personalidad,
          voice: person.voz,
          knowledge: person.conocimientos,
          motivations: person.motivaciones,
          limits: person.limites,
          goal: person.objetivo,
          secret: person.secreto,
          place: person.lugar,
          agenda: "Sigue el objetivo de su ficha.",
        }),
      );
    patch({
      places,
      cast,
      title: draft.title.trim() || suggestion.titulo,
    });
  }

  function validate(index: number): string | null {
    if (index === 0 && draft.premise.trim().length < 12 && draft.universe.trim().length < 2) {
      return "Escribe el universo o una premisa de al menos una frase.";
    }
    if (index === 1 && draft.oc.name.trim().length < 2) return "Tu personaje necesita un nombre.";
    return null;
  }

  async function ignite() {
    if (lock.current) return;
    const problem = validate(0) || validate(1);
    if (problem) {
      setError(problem);
      return;
    }
    lock.current = true;
    const existing = savedId ? useForge.getState().campaigns.find((item) => item.id === savedId) : undefined;
    const fresh = createCampaign(draft);
    const campaign = existing
      ? { ...fresh, id: existing.id, createdAt: existing.createdAt, entries: existing.entries, memories: existing.memories, chronicle: existing.chronicle, undo: null }
      : fresh;
    upsert(campaign);
    setSavedId(campaign.id);
    setPending("escena");
    setError(null);
    try {
      const response = await narrateTurn({
        data: { mode: "apertura", playerText: draft.opening.trim(), campaign: { ...campaign, undo: null } },
      });
      if (!response.ok) {
        setError(response.error);
        return;
      }
      const next = applyNarration(campaign, response.result, { mode: "apertura", playerText: draft.opening.trim() });
      upsert(next);
      await navigate({ to: "/partida/$id", params: { id: campaign.id } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo encender la escena.");
    } finally {
      lock.current = false;
      setPending(null);
    }
  }

  async function saveOnly() {
    if (lock.current) return;
    const problem = validate(0) || validate(1);
    if (problem) {
      setError(problem);
      return;
    }
    lock.current = true;
    const existing = savedId ? useForge.getState().campaigns.find((item) => item.id === savedId) : undefined;
    const fresh = createCampaign(draft);
    const campaign = existing ? { ...fresh, id: existing.id, createdAt: existing.createdAt, undo: null } : fresh;
    upsert(campaign);
    try {
      await navigate({ to: "/partida/$id", params: { id: campaign.id } });
    } finally {
      lock.current = false;
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col gap-5 px-4 py-2 pb-12">
      <PageHeader back={{ to: "/", label: "Biblioteca" }} />
      <div className="grid gap-1">
        <p className="text-sm text-ember">Paso {step + 1} de 4</p>
        <h1 className="font-serif text-4xl">
          {step === 0 ? "El mundo" : step === 1 ? "Tu personaje" : step === 2 ? "Quiénes lo habitan" : "Cómo se cuenta"}
        </h1>
      </div>

      {step === 0 ? (
        <section className="grid gap-4">
          <Field label="Título de la partida" hint="Puede quedar vacío: se usa el universo.">
            <input className="rf-field" value={draft.title} onChange={(event) => patch({ title: event.target.value })} />
          </Field>
          <Field label="Universo">
            <input
              className="rf-field"
              value={draft.universe}
              placeholder="Una ciudad portuaria sin mapas fiables"
              onChange={(event) => patch({ universe: event.target.value })}
            />
          </Field>
          <Field label="Premisa" hint="Dónde empieza la presión. No es la escena todavía.">
            <textarea
              className="rf-field"
              value={draft.premise}
              onChange={(event) => patch({ premise: event.target.value })}
            />
          </Field>
          <Field label="Tono">
            <textarea className="rf-field" value={draft.tone} onChange={(event) => patch({ tone: event.target.value })} />
          </Field>
          <div className="flex flex-wrap gap-2">
            {TONES.map((tone) => (
              <button
                key={tone}
                type="button"
                className="min-h-11 rounded-full bg-panel px-3 text-left text-sm text-mist"
                onClick={() => patch({ tone })}
              >
                {tone}
              </button>
            ))}
          </div>
          <Field label="Reglas" hint="Qué es posible, qué cuesta caro, qué no existe.">
            <textarea className="rf-field" value={draft.rules} onChange={(event) => patch({ rules: event.target.value })} />
          </Field>
        </section>
      ) : null}

      {step === 1 ? (
        <section className="grid gap-4">
          <Field label="Nombre">
            <input
              className="rf-field"
              value={draft.oc.name}
              onChange={(event) => patch({ oc: { ...draft.oc, name: event.target.value } })}
            />
          </Field>
          <Field label="Pronombres">
            <input
              className="rf-field"
              value={draft.oc.pronouns}
              onChange={(event) => patch({ oc: { ...draft.oc, pronouns: event.target.value } })}
            />
          </Field>
          <Field label="Apariencia">
            <textarea
              className="rf-field"
              value={draft.oc.appearance}
              onChange={(event) => patch({ oc: { ...draft.oc, appearance: event.target.value } })}
            />
          </Field>
          <Field label="Manera de hablar">
            <input
              className="rf-field"
              value={draft.oc.voice}
              onChange={(event) => patch({ oc: { ...draft.oc, voice: event.target.value } })}
            />
          </Field>
          <Field label="De dónde viene">
            <textarea
              className="rf-field"
              value={draft.oc.background}
              onChange={(event) => patch({ oc: { ...draft.oc, background: event.target.value } })}
            />
          </Field>
          <Field label="Qué quiere ahora">
            <textarea
              className="rf-field"
              value={draft.oc.goal}
              onChange={(event) => patch({ oc: { ...draft.oc, goal: event.target.value } })}
            />
          </Field>
          <Field label="Un rasgo que no negocia">
            <input
              className="rf-field"
              value={draft.oc.trait}
              onChange={(event) => patch({ oc: { ...draft.oc, trait: event.target.value } })}
            />
          </Field>
        </section>
      ) : null}

      {step === 2 ? (
        <section className="grid gap-4">
          <p className="text-sm text-mist">
            Puedes dejar el reparto vacío y que alguien surja en la escena, o forjarlo desde la premisa. Eso llama al
            narrador una vez y puedes editarlo antes de empezar.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button variant="quiet" disabled={pending !== null || draft.premise.trim().length < 12} onClick={() => void forgeCast(false)}>
              {pending === "reparto" ? "Forjando…" : "Forjar reparto"}
            </Button>
            <Button
              variant="ghost"
              onClick={() => patch({ cast: [...draft.cast, blankCharacter({ place: draft.places[0]?.name ?? "" })] })}
            >
              Añadir a mano
            </Button>
          </div>
          {confirmCast ? (
            <div className="rf-card grid gap-2 p-3">
              <p className="text-sm">Ya hay nombres escritos. Forjar de nuevo los sustituye.</p>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    void forgeCast(true);
                  }}
                >
                  Sustituir
                </Button>
                <Button variant="ghost" onClick={() => setConfirmCast(false)}>
                  Conservar
                </Button>
              </div>
            </div>
          ) : null}
          {draft.places.map((place, index) => (
            <div key={place.id} className="grid gap-2">
              <Field label={index === 0 ? "Lugar" : `Lugar ${index + 1}`}>
                <input
                  className="rf-field"
                  value={place.name}
                  onChange={(event) =>
                    patch({
                      places: draft.places.map((item) => (item.id === place.id ? { ...item, name: event.target.value } : item)),
                    })
                  }
                />
              </Field>
              <input
                className="rf-field"
                aria-label="Nota del lugar"
                placeholder="Qué se nota al entrar"
                value={place.note}
                onChange={(event) =>
                  patch({
                    places: draft.places.map((item) => (item.id === place.id ? { ...item, note: event.target.value } : item)),
                  })
                }
              />
            </div>
          ))}
          <Button
            variant="ghost"
            className="w-fit"
            onClick={() => patch({ places: [...draft.places, { id: uid(), name: "", note: "" }] })}
          >
            Otro lugar
          </Button>
          <ul className="grid gap-3">
            {draft.cast.map((character) => (
              <li key={character.id} className="rf-card grid gap-3 p-3">
                <Field label="Nombre">
                  <input
                    className="rf-field"
                    value={character.name}
                    onChange={(event) => updateCast(draft, patch, character.id, { name: event.target.value })}
                  />
                </Field>
                <Field label="Rol">
                  <input
                    className="rf-field"
                    value={character.role}
                    onChange={(event) => updateCast(draft, patch, character.id, { role: event.target.value })}
                  />
                </Field>
                <Field label="Quiere">
                  <textarea
                    className="rf-field"
                    value={character.goal}
                    onChange={(event) => updateCast(draft, patch, character.id, { goal: event.target.value })}
                  />
                </Field>
                <Field label="Secreto">
                  <textarea
                    className="rf-field"
                    value={character.secret}
                    onChange={(event) => updateCast(draft, patch, character.id, { secret: event.target.value })}
                  />
                </Field>
                <Field label="Dónde está">
                  <input
                    className="rf-field"
                    value={character.place}
                    onChange={(event) => updateCast(draft, patch, character.id, { place: event.target.value })}
                  />
                </Field>
                <Button
                  variant="danger"
                  className="w-fit"
                  onClick={() => patch({ cast: draft.cast.filter((item) => item.id !== character.id) })}
                >
                  Quitar
                </Button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {step === 3 ? (
        <section className="grid gap-4">
          <Field label="Límites de la mesa">
            <textarea
              className="rf-field"
              value={draft.boundaries}
              onChange={(event) => patch({ boundaries: event.target.value })}
            />
          </Field>
          <Segmented label="Prosa" value={draft.prose} options={PROSE} onChange={(prose) => patch({ prose })} />
          <Segmented
            label="Autonomía del mundo"
            value={draft.autonomy}
            options={AUTONOMY}
            onChange={(autonomy) => patch({ autonomy })}
          />
          <Field label="Primer gesto, si quieres darlo ya" hint="Opcional. El narrador no añadirá palabras a tu personaje.">
            <textarea
              className="rf-field"
              maxLength={2000}
              value={draft.opening}
              onChange={(event) => patch({ opening: event.target.value })}
            />
          </Field>
          <p className="text-sm text-mist">
            Encender llama al narrador una vez. Si falla, la partida queda guardada para reintentar.
          </p>
        </section>
      ) : null}

      {error ? (
        <p className="text-sm text-ember" role="alert">
          {error}
        </p>
      ) : null}
      {savedId ? (
        <button
          type="button"
          className="min-h-11 text-left text-sm text-ember"
          onClick={() => void navigate({ to: "/partida/$id", params: { id: savedId } })}
        >
          Ir a la partida y reintentar
        </button>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {step > 0 ? (
          <Button variant="ghost" disabled={pending !== null} onClick={() => setStep((value) => value - 1)}>
            Atrás
          </Button>
        ) : null}
        {step < 3 ? (
          <Button
            disabled={pending !== null}
            onClick={() => {
              const problem = validate(step);
              if (problem) {
                setError(problem);
                return;
              }
              setError(null);
              setStep((value) => value + 1);
            }}
          >
            Seguir
          </Button>
        ) : (
          <>
            <Button disabled={pending !== null} onClick={() => void ignite()}>
              {pending === "escena" ? "Encendiendo…" : "Encender la historia"}
            </Button>
            <Button variant="quiet" disabled={pending !== null} onClick={() => void saveOnly()}>
              Solo guardar
            </Button>
          </>
        )}
      </div>
    </main>
  );
}

function updateCast(draft: Draft, patch: (partial: Partial<Draft>) => void, id: string, partial: Partial<Character>) {
  patch({
    cast: draft.cast.map((character) => (character.id === id ? { ...character, ...partial } : character)),
  });
}
