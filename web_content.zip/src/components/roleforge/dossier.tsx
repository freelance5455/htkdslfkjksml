import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { addManualMemory, blankCharacter } from "@/lib/roleforge/apply";
import { formatClock, opinionLabel } from "@/lib/roleforge/text";
import type { Campaign, Character } from "@/lib/roleforge/types";
import { Button, Field, Segmented } from "./ui";

export type DossierTab = "escena" | "gente" | "memoria" | "cronica" | "mundo";

const PROSE = [
  { id: "breve" as const, label: "Breve" },
  { id: "equilibrada" as const, label: "Media" },
  { id: "literaria" as const, label: "Literaria" },
];

const AUTONOMY = [
  { id: "contenida" as const, label: "Contenida" },
  { id: "viva" as const, label: "Viva" },
  { id: "impredecible" as const, label: "Abierta" },
];

export function Dossier({
  campaign,
  tab,
  onChange,
}: {
  campaign: Campaign;
  tab: DossierTab;
  onChange: (campaign: Campaign) => void;
}) {
  if (tab === "escena") return <SceneTab campaign={campaign} onChange={onChange} />;
  if (tab === "gente") return <PeopleTab campaign={campaign} onChange={onChange} />;
  if (tab === "memoria") return <MemoryTab campaign={campaign} onChange={onChange} />;
  if (tab === "cronica") return <ChronicleTab campaign={campaign} />;
  return <WorldTab campaign={campaign} onChange={onChange} />;
}

function SceneTab({ campaign, onChange }: { campaign: Campaign; onChange: (campaign: Campaign) => void }) {
  const [threads, setThreads] = useState(campaign.threads.join("\n"));
  return (
    <div className="grid gap-4">
      <p className="text-sm text-mist">{formatClock(campaign.clock)}</p>
      <Field label="Lugar de la escena">
        <input
          className="rf-field"
          value={campaign.scene.place}
          onChange={(event) =>
            onChange({ ...campaign, scene: { ...campaign.scene, place: event.target.value } })
          }
        />
      </Field>
      <Field label="Atmósfera">
        <input
          className="rf-field"
          value={campaign.scene.atmosphere}
          onChange={(event) =>
            onChange({ ...campaign, scene: { ...campaign.scene, atmosphere: event.target.value } })
          }
        />
      </Field>
      <Field label="Lo que está pasando" hint="El narrador lo usa como continuidad. Cámbialo si se desvió.">
        <textarea
          className="rf-field"
          value={campaign.scene.summary}
          onChange={(event) =>
            onChange({ ...campaign, scene: { ...campaign.scene, summary: event.target.value } })
          }
        />
      </Field>
      <div className="grid gap-2">
        <p className="text-sm font-medium">En este lugar</p>
        <ul className="flex flex-wrap gap-2">
          {campaign.scene.present.length === 0 ? <li className="text-sm text-mist">Nadie, todavía.</li> : null}
          {campaign.scene.present.map((name) => (
            <li key={name} className="rounded-full bg-soot px-3 py-1 text-sm text-parchment">
              {name}
            </li>
          ))}
        </ul>
      </div>
      <Field label="Hilos abiertos" hint="Uno por línea.">
        <textarea
          className="rf-field"
          value={threads}
          onChange={(event) => setThreads(event.target.value)}
          onBlur={() =>
            onChange({
              ...campaign,
              threads: threads
                .split("\n")
                .map((line) => line.trim())
                .filter(Boolean)
                .slice(0, 6),
            })
          }
        />
      </Field>
    </div>
  );
}

function PeopleTab({ campaign, onChange }: { campaign: Campaign; onChange: (campaign: Campaign) => void }) {
  const [openId, setOpenId] = useState<string | null>(null);
  const updateCast = (cast: Character[]) => onChange({ ...campaign, cast });

  return (
    <div className="grid gap-4">
      <section className="grid gap-3">
        <h3 className="font-serif text-xl">Tu personaje</h3>
        <p className="text-sm text-mist">Solo tú hablas y actúas por {campaign.oc.name || "tu OC"}.</p>
        <Field label="Nombre">
          <input
            className="rf-field"
            value={campaign.oc.name}
            onChange={(event) => onChange({ ...campaign, oc: { ...campaign.oc, name: event.target.value } })}
          />
        </Field>
        <Field label="Pronombres">
          <input
            className="rf-field"
            value={campaign.oc.pronouns}
            onChange={(event) => onChange({ ...campaign, oc: { ...campaign.oc, pronouns: event.target.value } })}
          />
        </Field>
        <Field label="Qué busca">
          <textarea
            className="rf-field"
            value={campaign.oc.goal}
            onChange={(event) => onChange({ ...campaign, oc: { ...campaign.oc, goal: event.target.value } })}
          />
        </Field>
      </section>
      <section className="grid gap-3">
        <div className="flex items-center justify-between gap-3">
          <h3 className="font-serif text-xl">Los demás</h3>
          <Button
            variant="quiet"
            onClick={() => {
              const next = blankCharacter({ place: campaign.scene.place });
              updateCast([...campaign.cast, next]);
              setOpenId(next.id);
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            Alguien más
          </Button>
        </div>
        <p className="text-sm text-mist">
          La ficha es de dirección. Tu personaje no sabe un secreto hasta que la escena lo revela.
        </p>
        {campaign.cast.length === 0 ? <p className="text-sm text-mist">Aún no hay nadie más en el mundo.</p> : null}
        <ul className="grid gap-2">
          {campaign.cast.map((character) => {
            const open = openId === character.id;
            return (
              <li key={character.id} className="rf-card p-3">
                <button
                  type="button"
                  className="flex min-h-11 w-full items-center justify-between gap-3 text-left"
                  aria-expanded={open}
                  onClick={() => setOpenId(open ? null : character.id)}
                >
                  <span>
                    <span className="block font-medium">{character.name || "Sin nombre"}</span>
                    <span className="text-sm text-mist">
                      {character.mood || "Sin ánimo"} · {opinionLabel(character.opinion)} · {character.place || "sin lugar"}
                    </span>
                  </span>
                  <span className="text-sm text-mist">{character.weight === "principal" ? "Principal" : "Menor"}</span>
                </button>
                {open ? (
                  <div className="mt-3 grid gap-3">
                    <SheetFields
                      character={character}
                      places={campaign.places.map((place) => place.name)}
                      onChange={(next) => updateCast(campaign.cast.map((item) => (item.id === character.id ? next : item)))}
                    />
                    <Button
                      variant="danger"
                      onClick={() => updateCast(campaign.cast.filter((item) => item.id !== character.id))}
                    >
                      <Trash2 className="size-4" aria-hidden="true" />
                      Quitar del mundo
                    </Button>
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}

function SheetFields({
  character,
  places,
  onChange,
}: {
  character: Character;
  places: string[];
  onChange: (character: Character) => void;
}) {
  const text = (
    key:
      | "name"
      | "role"
      | "mood"
      | "agenda"
      | "personality"
      | "voice"
      | "appearance"
      | "knowledge"
      | "motivations"
      | "goal"
      | "limits"
      | "secret"
      | "bondNote",
    label: string,
    long = false,
  ) => (
    <Field label={label}>
      {long ? (
        <textarea
          className="rf-field"
          value={String(character[key] ?? "")}
          onChange={(event) => onChange({ ...character, [key]: event.target.value })}
        />
      ) : (
        <input
          className="rf-field"
          value={String(character[key] ?? "")}
          onChange={(event) => onChange({ ...character, [key]: event.target.value })}
        />
      )}
    </Field>
  );

  return (
    <div className="grid gap-3">
      {text("name", "Nombre")}
      {text("role", "Rol")}
      <Field label="Peso en la historia">
        <div className="grid grid-cols-2 gap-1 rounded-xl bg-soot p-1">
          {(["principal", "menor"] as const).map((weight) => (
            <button
              key={weight}
              type="button"
              aria-pressed={character.weight === weight}
              className={
                character.weight === weight
                  ? "min-h-11 rounded-lg bg-panel-2 text-parchment"
                  : "min-h-11 rounded-lg text-mist"
              }
              onClick={() => onChange({ ...character, weight })}
            >
              {weight === "principal" ? "Principal" : "Menor"}
            </button>
          ))}
        </div>
      </Field>
      <Field label="Dónde está">
        <input
          className="rf-field"
          list={`places-${character.id}`}
          value={character.place}
          onChange={(event) => onChange({ ...character, place: event.target.value })}
        />
        <datalist id={`places-${character.id}`}>
          {places.map((place) => (
            <option key={place} value={place} />
          ))}
        </datalist>
      </Field>
      {text("mood", "Ánimo")}
      {text("agenda", "Qué hace cuando no estás", true)}
      {text("personality", "Personalidad", true)}
      {text("voice", "Voz")}
      {text("appearance", "Apariencia", true)}
      {text("knowledge", "Qué sabe", true)}
      {text("motivations", "Qué lo mueve", true)}
      {text("goal", "Objetivo ahora", true)}
      {text("limits", "Qué no hará", true)}
      {text("secret", "Secreto", true)}
      {text("bondNote", "Vínculo contigo", true)}
      <p className="text-sm text-mist">Opinión sobre ti: {opinionLabel(character.opinion)} ({character.opinion})</p>
    </div>
  );
}

function MemoryTab({ campaign, onChange }: { campaign: Campaign; onChange: (campaign: Campaign) => void }) {
  const [draft, setDraft] = useState("");
  const items = [...campaign.memories].reverse();
  return (
    <div className="grid gap-4">
      <p className="text-sm text-mist">Hechos que el narrador debe respetar. Puedes clavar uno sin llamar a la IA.</p>
      <form
        className="grid gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          onChange(addManualMemory(campaign, draft));
          setDraft("");
        }}
      >
        <Field label="Hecho para recordar">
          <textarea className="rf-field" value={draft} onChange={(event) => setDraft(event.target.value)} />
        </Field>
        <Button type="submit" disabled={!draft.trim()}>
          Clavar en la memoria
        </Button>
      </form>
      {items.length === 0 ? <p className="text-sm text-mist">La memoria está en blanco.</p> : null}
      <ul className="grid gap-2">
        {items.map((memory) => (
          <li key={memory.id} className="rf-card flex items-start justify-between gap-3 p-3">
            <p className="text-sm">
              <span className="text-mist">{memory.importance === 3 ? "Clave · " : ""}</span>
              {memory.summary}
            </p>
            <button
              type="button"
              className="inline-flex size-11 shrink-0 items-center justify-center text-mist"
              aria-label="Olvidar este hecho"
              onClick={() => onChange({ ...campaign, memories: campaign.memories.filter((item) => item.id !== memory.id) })}
            >
              <Trash2 className="size-4" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ChronicleTab({ campaign }: { campaign: Campaign }) {
  const items = [...campaign.chronicle].reverse();
  return (
    <div className="grid gap-3">
      <p className="text-sm text-mist">
        Lo que ocurre sin tu personaje. No es lo que tu OC sabe: es la vida del mundo cuando no mira.
      </p>
      {items.length === 0 ? <p className="text-sm text-mist">Todavía no se ha movido nada lejos de ti.</p> : null}
      <ul className="grid gap-2">
        {items.map((event) => (
          <li key={event.id} className="rf-card p-3">
            <p className="text-sm">{event.summary}</p>
            {event.who.length > 0 ? <p className="mt-1 text-sm text-mist">{event.who.join(", ")}</p> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

function WorldTab({ campaign, onChange }: { campaign: Campaign; onChange: (campaign: Campaign) => void }) {
  const set = (patch: Partial<Campaign>) => onChange({ ...campaign, ...patch });
  return (
    <div className="grid gap-4">
      <Field label="Título">
        <input className="rf-field" value={campaign.title} onChange={(event) => set({ title: event.target.value })} />
      </Field>
      <Field label="Universo">
        <input className="rf-field" value={campaign.universe} onChange={(event) => set({ universe: event.target.value })} />
      </Field>
      <Field label="Premisa">
        <textarea className="rf-field" value={campaign.premise} onChange={(event) => set({ premise: event.target.value })} />
      </Field>
      <Field label="Tono">
        <textarea className="rf-field" value={campaign.tone} onChange={(event) => set({ tone: event.target.value })} />
      </Field>
      <Field label="Reglas del mundo">
        <textarea className="rf-field" value={campaign.rules} onChange={(event) => set({ rules: event.target.value })} />
      </Field>
      <Field label="Límites">
        <textarea className="rf-field" value={campaign.boundaries} onChange={(event) => set({ boundaries: event.target.value })} />
      </Field>
      <Segmented label="Prosa" value={campaign.prose} options={PROSE} onChange={(prose) => set({ prose })} />
      <Segmented
        label="Autonomía del mundo"
        value={campaign.autonomy}
        options={AUTONOMY}
        onChange={(autonomy) => set({ autonomy })}
      />
      <div className="grid gap-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">Lugares</p>
          <Button
            variant="ghost"
            onClick={() => set({ places: [...campaign.places, { id: crypto.randomUUID(), name: "", note: "" }] })}
          >
            <Plus className="size-4" aria-hidden="true" />
            Lugar
          </Button>
        </div>
        {campaign.places.map((place) => (
          <div key={place.id} className="grid gap-2">
            <input
              className="rf-field"
              aria-label="Nombre del lugar"
              value={place.name}
              onChange={(event) =>
                set({
                  places: campaign.places.map((item) => (item.id === place.id ? { ...item, name: event.target.value } : item)),
                })
              }
            />
            <input
              className="rf-field"
              aria-label="Nota del lugar"
              placeholder="Qué se siente ahí"
              value={place.note}
              onChange={(event) =>
                set({
                  places: campaign.places.map((item) => (item.id === place.id ? { ...item, note: event.target.value } : item)),
                })
              }
            />
          </div>
        ))}
      </div>
      <Field label="Reloj" hint="Día y minuto del día, de 0 a 1439. No llama al narrador.">
        <div className="grid grid-cols-2 gap-2">
          <input
            className="rf-field tabular-nums"
            type="number"
            min={1}
            aria-label="Día"
            value={campaign.clock.day}
            onChange={(event) =>
              set({ clock: { ...campaign.clock, day: Math.max(1, Number(event.target.value) || 1) } })
            }
          />
          <input
            className="rf-field tabular-nums"
            type="number"
            min={0}
            max={1439}
            aria-label="Minuto del día"
            value={campaign.clock.minute}
            onChange={(event) =>
              set({
                clock: {
                  ...campaign.clock,
                  minute: Math.min(1439, Math.max(0, Number(event.target.value) || 0)),
                },
              })
            }
          />
        </div>
      </Field>
    </div>
  );
}
