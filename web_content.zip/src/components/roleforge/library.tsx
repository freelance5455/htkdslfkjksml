import { Link } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { useState } from "react";
import { useForge, useHydrated } from "@/lib/roleforge/store";
import { formatClock } from "@/lib/roleforge/text";
import { Button, InstallHint, PageHeader } from "./ui";

export function Library() {
  const hydrated = useHydrated();
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col gap-6 px-4 py-2 pb-10">
      <PageHeader
        action={
          <Link
            to="/nueva"
            className="inline-flex min-h-11 items-center rounded-xl bg-ember px-4 text-sm font-medium text-ink"
          >
            Nueva partida
          </Link>
        }
      />
      <section className="grid gap-3">
        <h1 className="max-w-xl font-serif text-4xl leading-tight text-parchment">
          Tú eres una sola voz. El mundo tiene las demás.
        </h1>
        <p className="max-w-xl text-mist">
          Interpretas a tu personaje. Los otros recuerdan, mienten y siguen con su vida cuando no estás.
        </p>
      </section>
      {hydrated ? <Shelf /> : <p className="text-mist">Abriendo la biblioteca…</p>}
      <InstallHint />
    </main>
  );
}

function Shelf() {
  const campaigns = useForge((state) => state.campaigns);
  const remove = useForge((state) => state.remove);
  const [armed, setArmed] = useState<string | null>(null);
  const ordered = [...campaigns].sort((a, b) => b.updatedAt - a.updatedAt);

  if (ordered.length === 0) {
    return (
      <section className="rf-card grid gap-3 p-5">
        <h2 className="font-serif text-2xl">Aún no hay partidas</h2>
        <p className="text-sm text-mist">Forja un mundo en este dispositivo. Cada partida se guarda aquí, no en una cuenta.</p>
        <Link to="/nueva" className="inline-flex min-h-11 w-fit items-center text-ember">
          Empezar una forja
        </Link>
      </section>
    );
  }

  return (
    <ul className="grid gap-3">
      {ordered.map((campaign) => (
        <li key={campaign.id} className="rf-card grid gap-3 p-4">
          <Link to="/partida/$id" params={{ id: campaign.id }} className="grid gap-1">
            <h2 className="font-serif text-2xl">{campaign.title}</h2>
            <p className="text-sm text-ember">{campaign.universe || "Sin universo"}</p>
            <p className="line-clamp-3 text-sm text-parchment">
              {campaign.scene.summary || "La primera escena todavía no se ha encendido."}
            </p>
            <p className="text-sm text-mist tabular-nums">
              {formatClock(campaign.clock)}
              {" · "}
              {formatDistanceToNow(campaign.updatedAt, { addSuffix: true, locale: es })}
            </p>
          </Link>
          {armed === campaign.id ? (
            <div className="flex flex-wrap gap-2">
              <Button variant="danger" onClick={() => remove(campaign.id)}>
                Borrar de este dispositivo
              </Button>
              <Button variant="ghost" onClick={() => setArmed(null)}>
                Conservar
              </Button>
            </div>
          ) : (
            <Button variant="ghost" className="w-fit px-0" onClick={() => setArmed(campaign.id)}>
              Borrar
            </Button>
          )}
        </li>
      ))}
    </ul>
  );
}
