import { Link } from "@tanstack/react-router";
import { ChevronLeft, Download, Flame } from "lucide-react";
import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/cn";

type BeforeInstall = Event & { prompt: () => Promise<void> };

export function Wordmark() {
  return (
    <span className="font-serif text-2xl tracking-tight text-parchment">
      Role<span className="text-ember">forge</span>
    </span>
  );
}

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "quiet" | "ghost" | "danger" }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium transition-colors duration-150",
        variant === "primary" && "bg-ember text-ink hover:bg-ember-deep",
        variant === "quiet" && "rf-ring bg-panel-2 text-parchment",
        variant === "ghost" && "bg-transparent text-parchment hover:bg-panel-2",
        variant === "danger" && "bg-transparent text-ember hover:bg-panel-2",
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="grid gap-1.5">
      <span className="text-sm font-medium text-parchment">{label}</span>
      {hint ? <span className="text-sm text-mist">{hint}</span> : null}
      {children}
    </label>
  );
}

export function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: Array<{ id: T; label: string }>;
  onChange: (value: T) => void;
}) {
  return (
    <div className="grid gap-1.5">
      <span className="text-sm font-medium text-parchment">{label}</span>
      <div className="grid grid-cols-3 gap-1 rounded-xl bg-soot p-1" role="group" aria-label={label}>
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            aria-pressed={value === option.id}
            onClick={() => onChange(option.id)}
            className={cn(
              "min-h-11 rounded-lg px-2 text-sm",
              value === option.id ? "bg-panel-2 text-parchment" : "text-mist",
            )}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function PageHeader({ back, action }: { back?: { to: "/" | "/nueva"; label: string }; action?: ReactNode }) {
  return (
    <header className="flex items-center justify-between gap-3 px-4 py-3">
      <div className="flex min-w-0 items-center gap-2">
        {back ? (
          <Link to={back.to} className="inline-flex min-h-11 items-center gap-1 text-sm text-mist" aria-label={back.label}>
            <ChevronLeft className="size-5" aria-hidden="true" />
            <span className="sr-only">{back.label}</span>
          </Link>
        ) : (
          <Flame className="size-5 text-ember" aria-hidden="true" />
        )}
        <Wordmark />
      </div>
      {action}
    </header>
  );
}

export function InstallHint() {
  const [prompt, setPrompt] = useState<BeforeInstall | null>(null);
  const [hidden, setHidden] = useState(false);
  const [ios, setIos] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const nav = navigator as Navigator & { standalone?: boolean };
    const standalone = window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
    if (standalone) {
      setInstalled(true);
      return;
    }
    const ua = navigator.userAgent;
    setIos(/iphone|ipad|ipod/i.test(ua));
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPrompt(event as BeforeInstall);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  if (installed || hidden) return null;

  return (
    <aside className="rf-card flex flex-col gap-3 p-4">
      <div className="flex items-start gap-3">
        <Download className="mt-0.5 size-5 shrink-0 text-ember" aria-hidden="true" />
        <div className="grid gap-1">
          <p className="font-medium">Llévala en el teléfono</p>
          <p className="text-sm text-mist">
            Se instala en la pantalla de inicio y se abre como una aplicación. En Android el navegador la añade
            directamente; un APK de tienda exige un empaquetado aparte que Roleforge no finge descargar.
          </p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {prompt ? (
          <Button
            onClick={() => {
              void prompt.prompt();
              setHidden(true);
            }}
          >
            Instalar
          </Button>
        ) : null}
        {ios ? (
          <p className="text-sm text-mist">En Safari: Compartir, luego Añadir a pantalla de inicio.</p>
        ) : null}
        <Button variant="ghost" onClick={() => setHidden(true)}>
          Ahora no
        </Button>
      </div>
    </aside>
  );
}
