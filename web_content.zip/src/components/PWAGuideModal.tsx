import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { 
  X, 
  Smartphone, 
  Globe, 
  DownloadCloud, 
  CheckCircle2, 
  Share2, 
  MoreVertical, 
  ArrowRight,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

export const PWAGuideModal: React.FC = () => {
  const { isPWAGuideOpen, setIsPWAGuideOpen, language } = useApp();
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'free_publish'>('android');

  if (!isPWAGuideOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-7 my-8">
        {/* Close Button */}
        <button
          onClick={() => setIsPWAGuideOpen(false)}
          className="absolute top-4 right-4 rounded-full p-2 text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              {language === 'hi' ? 'एंड्रॉइड ऐप और फ्री होस्टिंग गाइड' : 'Android App & Free Hosting Guide'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              {language === 'hi'
                ? 'अपने फोन पर ऐप लगाने और फ्री में इंटरनेट पर लाइव करने का आसान तरीका'
                : 'Simple step-by-step instructions to install and publish for free'}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex rounded-xl bg-slate-800 p-1 mb-6">
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition ${
              activeTab === 'android'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>{language === 'hi' ? '1. एंड्रॉइड फोन में ऐप लगाएं' : '1. Install on Android'}</span>
          </button>
          <button
            onClick={() => setActiveTab('free_publish')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition ${
              activeTab === 'free_publish'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>{language === 'hi' ? '2. फ्री में इंटरनेट पर लाइव करें' : '2. Publish Free Online'}</span>
          </button>
        </div>

        {/* Tab 1: Android PWA Installation */}
        {activeTab === 'android' && (
          <div className="space-y-4">
            {isInstallable && !isInstalled && (
              <div className="p-4 rounded-xl bg-blue-950/60 border border-blue-500/40 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-semibold text-white text-sm">
                    {language === 'hi' ? 'तुरंत 1-क्लिक इनस्टॉल' : 'Instant 1-Click Install'}
                  </h4>
                  <p className="text-xs text-blue-200">
                    {language === 'hi' ? 'आपका ब्राउज़र सीधा इनस्टॉल सपोर्ट करता है।' : 'Your browser supports instant installation.'}
                  </p>
                </div>
                <button
                  onClick={() => {
                    install();
                    setIsPWAGuideOpen(false);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow transition flex items-center gap-1.5 flex-shrink-0"
                >
                  <DownloadCloud className="w-4 h-4" />
                  <span>{language === 'hi' ? 'अभी इनस्टॉल करें' : 'Install Now'}</span>
                </button>
              </div>
            )}

            <div className="space-y-3">
              <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold">1</span>
                {language === 'hi' ? 'Chrome ब्राउज़र में वेबसाइट खोलें' : 'Open in Google Chrome on your Android phone'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 ml-8 leading-relaxed">
                {language === 'hi'
                  ? 'अपने मोबाइल में Google Chrome खोलें और दुकान की वेबसाइट लिंक पर जाएं।'
                  : 'Open Google Chrome on your Android smartphone and open your shop link.'}
              </p>

              <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold">2</span>
                {language === 'hi' ? 'ऊपर दाएँ कोने में 3 डॉट्स (⋮) पर क्लिक करें' : 'Tap the 3 dots (⋮) in the top-right corner'}
              </h3>
              <div className="ml-8 p-3 rounded-lg bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-slate-300 flex items-center gap-2">
                <MoreVertical className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <span>
                  {language === 'hi' 
                    ? 'क्रोम ब्राउज़र के मेनू में "Install App" या "Add to Home screen" (होम स्क्रीन पर जोड़ें) का विकल्प दिखाई देगा।' 
                    : 'In the menu, look for "Install app" or "Add to Home screen".'}
                </span>
              </div>

              <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold">3</span>
                {language === 'hi' ? '"Install" या "Add" पर दबाएं' : 'Tap "Install" or "Add"'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 ml-8 leading-relaxed">
                {language === 'hi'
                  ? 'बस 2 सेकंड में आपके मोबाइल स्क्रीन पर "AK Golu" का असली ऐप आइकॉन बन जाएगा। ग्राहक बिना इंटरनेट लिंक ढूंढे एक क्लिक में आपकी दुकान खोल सकेंगे और ऑफलाइन भी फोन नंबर व एड्रेस देख सकेंगे।'
                  : 'Within 2 seconds, the "AK Golu" app icon appears on your home screen like any native app.'}
              </p>

              <div className="mt-4 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>
                  {language === 'hi'
                    ? 'फायदा: यह PWA (Progressive Web App) है। इसके लिए Google Play Store को कोई सालाना फीस नहीं देनी पड़ती, और यह बहुत हल्का (1 MB से भी कम) है।'
                    : 'Zero Google Play Store developer fees, lightweight under 1MB, fast loading.'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Free Hosting & Publishing */}
        {activeTab === 'free_publish' && (
          <div className="space-y-4 text-xs sm:text-sm text-slate-300">
            <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-500/30 text-blue-200">
              <p className="font-semibold text-white mb-1">
                {language === 'hi' ? '100% मुफ़्त में वेबसाइट चलाने के 3 सबसे आसान तरीके:' : '3 100% Free Hosting Options:'}
              </p>
              <p className="text-xs text-blue-300 leading-relaxed">
                {language === 'hi'
                  ? 'इस वेबसाइट में कोई भारी डेटाबेस या पेड सर्वर की जरूरत नहीं है। सारा डेटा और ऑर्डर्स सुरक्षित लोकल स्टोरेज और सीधे आपके व्हाट्सएप (7054304313 / 8726356413) पर काम करते हैं।'
                  : 'No paid server needed. Data and WhatsApp orders run completely free.'}
              </p>
            </div>

            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-slate-800/90 border border-slate-700">
                <div className="flex items-center justify-between mb-1.5">
                  <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    विकल्प 1: Netlify Drop (सबसे आसान - 2 मिनट में लाइव)
                  </h4>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-semibold">अनुशंसित (Recommended)</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 pl-1">
                  <li>अपने कंप्यूटर में <code>npm run build</code> चलाएं जिससे <code>dist</code> फोल्डर बनेगा।</li>
                  <li>वेबसाइट <strong className="text-white">app.netlify.com/drop</strong> खोलें।</li>
                  <li>अपने <code>dist</code> फोल्डर को खींचकर (Drag & Drop) वहां छोड़ दें।</li>
                  <li>आपको तुरंत एक फ्री लिंक (उदा. <em>akgolucomputer.netlify.app</em>) मिल जाएगी!</li>
                </ol>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/90 border border-slate-700">
                <h4 className="font-bold text-white text-sm mb-1.5 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                  विकल्प 2: Vercel (सुपरफास्ट स्पीड)
                </h4>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 pl-1">
                  <li><strong className="text-white">vercel.com</strong> पर फ्री अकाउंट बनाएं।</li>
                  <li>इस प्रोजेक्ट को इंपोर्ट करें या Vercel CLI (<code>npx vercel</code>) चलाएं।</li>
                  <li>यह अपने आप वेबसाइट बना देगा और लाइफटाइम फ्री SSL सिक्योरिटी देगा।</li>
                </ol>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/90 border border-slate-700">
                <h4 className="font-bold text-white text-sm mb-1.5 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                  विकल्प 3: कस्टम .in / .com डोमेन जोड़ना (वैकल्पिक)
                </h4>
                <p className="leading-relaxed">
                  यदि आप भविष्य में <strong>www.akgolucomputer.in</strong> नाम लेना चाहें, तो GoDaddy या Hostinger से लगभग ₹400-₹500 में खरीदकर Netlify या Vercel में 1 क्लिक में फ्री में जोड़ सकते हैं।
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Footer actions */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => setIsPWAGuideOpen(false)}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold transition"
          >
            {language === 'hi' ? 'समझ गया / बंद करें' : 'Got it / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
