import React, { useState } from 'react';
import { Manhwa, Chapter, Team, WorkType, WORK_TYPE_LABELS, MANHWA_GENRES, AssignedMember, TeamMember, TEAM_ROLE_LABELS } from '../types';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { hartHost } from '../services/hartHostService';
import { SmartImage } from './SmartImage';
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc
} from 'firebase/firestore';
import {
  Plus,
  Trash2,
  Edit,
  Layers,
  Image as ImageIcon,
  Archive,
  CheckCircle,
  FileText,
  Upload,
  Eye,
  Server,
  Lock,
  X,
  Users,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  UserCheck
} from 'lucide-react';

interface ChapterPageItem {
  filename: string;
  blob: Blob;
  preview: string;
}

interface PublisherDashboardProps {
  manhwas: Manhwa[];
  chapters: Chapter[];
  teams: Team[];
  activeTeamContext?: Team | null;
  onRefresh: () => void;
}

export const PublisherDashboard: React.FC<PublisherDashboardProps> = ({
  manhwas,
  chapters,
  teams,
  activeTeamContext,
  onRefresh
}) => {
  const { user, profile, isPublisher, isOwner, signInWithGoogle } = useAuth();

  // Modals state
  const [showAddManhwaModal, setShowAddManhwaModal] = useState(false);
  const [editingManhwa, setEditingManhwa] = useState<Manhwa | null>(null);
  const [managingManhwa, setManagingManhwa] = useState<Manhwa | null>(null);

  // Add/Edit Work Form State
  const [workType, setWorkType] = useState<WorkType>('manhwa');
  const [workTitle, setWorkTitle] = useState('');
  const [workTitleOriginal, setWorkTitleOriginal] = useState('');
  const [workDescription, setWorkDescription] = useState('');
  const [workGenres, setWorkGenres] = useState<string[]>(['أكشن', 'فانتازيا']);
  const [workStatus, setWorkStatus] = useState<'ongoing' | 'completed' | 'hiatus'>('ongoing');
  const [workAuthor, setWorkAuthor] = useState('');
  const [workArtist, setWorkArtist] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState<string>(activeTeamContext?.id || '');
  const [assignedMembers, setAssignedMembers] = useState<AssignedMember[]>([]);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState<string>('');
  const [isSavingManhwa, setIsSavingManhwa] = useState(false);
  const [manhwaUploadProgress, setManhwaUploadProgress] = useState(0);
  const [saveWorkError, setSaveWorkError] = useState('');

  // Add Chapter Form State
  const [chapterNumber, setChapterNumber] = useState<number>(1);
  const [chapterTitle, setChapterTitle] = useState('');
  const [novelContent, setNovelContent] = useState('');
  const [chapterPages, setChapterPages] = useState<ChapterPageItem[]>([]);
  const [isProcessingPages, setIsProcessingPages] = useState(false);
  const [uploadStatusText, setUploadStatusText] = useState('');
  const [chapterUploadProgress, setChapterUploadProgress] = useState(0);
  const [chapterError, setChapterError] = useState('');

  // If user is not logged in
  if (!user) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 bg-[#101627] rounded-3xl border border-white/5 text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-900/30 border border-purple-500/30 flex items-center justify-center text-purple-400">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">لوحة النشر وإدارة الأعمال</h2>
        <p className="text-xs text-gray-400 mb-6">
          يرجى تسجيل الدخول بحسابك للوصول إلى أدوات نشر وإدارة المانهوا والمانجا والروايات.
        </p>
        <button
          onClick={signInWithGoogle}
          className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-purple-900/40 transition-transform hover:scale-105"
        >
          تسجيل الدخول الآن
        </button>
      </div>
    );
  }

  // User's teams where user is leader or member
  const userTeams = teams.filter(
    (t) => t.leaderId === user.uid || t.members?.some((m) => m.uid === user.uid) || isOwner
  );

  // Publisher's works
  const publisherWorks = isOwner
    ? manhwas
    : manhwas.filter(
        (m) =>
          m.publisherId === user.uid ||
          (m.teamId && userTeams.some((t) => t.id === m.teamId)) ||
          m.allowedEditors?.includes(user.uid) ||
          m.assignedMembers?.some((am) => am.uid === user.uid)
      );

  // Handle Cover Selection from Phone Gallery
  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCoverFile(file);
      setCoverPreview(URL.createObjectURL(file));
      setSaveWorkError('');
    }
  };

  // Open Add Work Modal
  const openNewWorkModal = () => {
    setEditingManhwa(null);
    setWorkType('manhwa');
    setWorkTitle('');
    setWorkTitleOriginal('');
    setWorkDescription('');
    setWorkGenres(['أكشن', 'فانتازيا']);
    setWorkStatus('ongoing');
    setWorkAuthor('');
    setWorkArtist('');
    setSelectedTeamId(activeTeamContext?.id || (userTeams[0]?.id || ''));
    setAssignedMembers([]);
    setCoverFile(null);
    setCoverPreview('');
    setSaveWorkError('');
    setShowAddManhwaModal(true);
  };

  // Open Edit Work Modal
  const openEditWorkModal = (m: Manhwa) => {
    setEditingManhwa(m);
    setWorkType(m.type || 'manhwa');
    setWorkTitle(m.title);
    setWorkTitleOriginal(m.titleOriginal || '');
    setWorkDescription(m.description);
    setWorkGenres(m.genres || []);
    setWorkStatus(m.status);
    setWorkAuthor(m.author || '');
    setWorkArtist(m.artist || '');
    setSelectedTeamId(m.teamId || '');
    setAssignedMembers(m.assignedMembers || []);
    setCoverPreview(m.coverUrl);
    setCoverFile(null);
    setSaveWorkError('');
    setShowAddManhwaModal(true);
  };

  const toggleAssignedMember = (member: TeamMember) => {
    if (assignedMembers.some((m: AssignedMember) => m.uid === member.uid)) {
      setAssignedMembers(assignedMembers.filter((m: AssignedMember) => m.uid !== member.uid));
    } else {
      setAssignedMembers([
        ...assignedMembers,
        { uid: member.uid, displayName: member.displayName, role: member.role }
      ]);
    }
  };

  // Save Work (Add / Update)
  const handleSaveWork = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveWorkError('');
    if (!workTitle.trim() || !workDescription.trim()) {
      setSaveWorkError('يرجى ملء جميع الحقول المطلوبة (العنوان والقصة)');
      return;
    }
    if (!editingManhwa && !coverFile && !coverPreview) {
      setSaveWorkError('يرجى اختيار صورة الغلاف للعمل من استوديو هاتفك أو جهازك');
      return;
    }

    setIsSavingManhwa(true);
    setManhwaUploadProgress(15);

    try {
      let finalCoverUrl = coverPreview;

      // Compress and upload cover to permanent server storage
      if (coverFile) {
        setManhwaUploadProgress(40);
        const optimizedCoverBlob = await hartHost.optimizeImage(coverFile, 800, 0.85);
        setManhwaUploadProgress(70);
        finalCoverUrl = await hartHost.uploadMedia(optimizedCoverBlob, 'covers', `${workTitle}_cover`);
        setManhwaUploadProgress(90);
      }

      const teamObj = teams.find((t) => t.id === selectedTeamId);
      const allowedEditors = Array.from(new Set([user.uid, ...assignedMembers.map((am: AssignedMember) => am.uid)]));

      if (editingManhwa) {
        const docRef = doc(db, 'manhwas', editingManhwa.id);
        await updateDoc(docRef, {
          title: workTitle.trim(),
          titleOriginal: workTitleOriginal.trim(),
          type: workType,
          description: workDescription.trim(),
          genres: workGenres,
          status: workStatus,
          author: workAuthor.trim(),
          artist: workArtist.trim(),
          teamId: selectedTeamId || '',
          teamName: teamObj ? teamObj.name : '',
          assignedMembers,
          allowedEditors,
          coverUrl: finalCoverUrl,
          updatedAt: new Date().toISOString()
        });
      } else {
        const newPayload: Omit<Manhwa, 'id'> = {
          title: workTitle.trim(),
          titleOriginal: workTitleOriginal.trim(),
          type: workType,
          description: workDescription.trim(),
          genres: workGenres,
          status: workStatus,
          author: workAuthor.trim(),
          artist: workArtist.trim(),
          teamId: selectedTeamId || '',
          teamName: teamObj ? teamObj.name : '',
          assignedMembers,
          allowedEditors,
          coverUrl: finalCoverUrl,
          views: 0,
          rating: 5.0,
          ratingCount: 1,
          publisherId: user.uid,
          publisherName: profile?.displayName || user.displayName || 'ناشر',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        await addDoc(collection(db, 'manhwas'), newPayload);
      }

      setShowAddManhwaModal(false);
      onRefresh();
    } catch (error: any) {
      console.error('Save work error:', error);
      setSaveWorkError(error.message || 'فشل حفظ العمل، يرجى المحاولة مرة أخرى');
    } finally {
      setIsSavingManhwa(false);
      setManhwaUploadProgress(0);
    }
  };

  // Delete Work
  const handleDeleteWork = async (manhwa: Manhwa) => {
    if (!window.confirm(`هل أنت متأكد من حذف "${manhwa.title}" وجميع فصولها نهائياً؟`)) {
      return;
    }

    try {
      await deleteDoc(doc(db, 'manhwas', manhwa.id));
      onRefresh();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `manhwas/${manhwa.id}`);
    }
  };

  // Open Chapter Manager
  const openChapterManager = (manhwa: Manhwa) => {
    setManagingManhwa(manhwa);
    const existingChs = chapters.filter((c) => c.manhwaId === manhwa.id);
    const maxNum = existingChs.reduce((max, c) => Math.max(max, c.chapterNumber), 0);
    setChapterNumber(maxNum + 1);
    setChapterTitle('');
    setNovelContent('');
    setChapterPages([]);
    setChapterUploadProgress(0);
    setUploadStatusText('');
    setChapterError('');
  };

  // Multi-Images Select for Chapter Pages
  const handleMultipleImagesSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsProcessingPages(true);
    setUploadStatusText('جاري فحص الصور من استوديو هاتفك...');
    setChapterError('');

    const files = Array.from(e.target.files);
    files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));

    const newPages = files.map((file) => ({
      filename: file.name,
      blob: file,
      preview: URL.createObjectURL(file)
    }));

    setChapterPages((prev: ChapterPageItem[]) => [...prev, ...newPages]);
    setIsProcessingPages(false);
    setUploadStatusText('');
  };

  // ZIP Upload for Chapter
  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const zipFile = e.target.files[0];
    setIsProcessingPages(true);
    setUploadStatusText('محرك Hart Host يفك ضغط ملف الـ ZIP ويرتب الصفحات رقمياً...');
    setChapterError('');

    try {
      const extracted = await hartHost.extractZipArchive(zipFile, (percent, curr, tot) => {
        setUploadStatusText(`جاري استخراج صفحات الفصل: ${curr} من ${tot} (${percent}%)`);
      });

      const pagesWithPreview = extracted.map((item) => ({
        filename: item.filename,
        blob: item.blob,
        preview: URL.createObjectURL(item.blob)
      }));

      setChapterPages(pagesWithPreview);
      setUploadStatusText(`تم استخراج ${pagesWithPreview.length} صفحة بنجاح!`);
    } catch (err) {
      setChapterError('فشل استخراج ملف الـ ZIP. تأكد من احتواء الملف على صور صالحة.');
    } finally {
      setIsProcessingPages(false);
    }
  };

  // Upload and Save Chapter
  const handleSaveChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!managingManhwa) return;
    setChapterError('');

    const isNovel = managingManhwa.type === 'novel';

    if (!isNovel && chapterPages.length === 0) {
      setChapterError('يرجى إضافة صفحة واحدة على الأقل للفصل من استوديو هاتفك أو عبر ملف ZIP');
      return;
    }
    if (isNovel && !novelContent.trim()) {
      setChapterError('يرجى كتابة أو لصق نص فصل الرواية');
      return;
    }

    setIsProcessingPages(true);
    setChapterUploadProgress(5);

    try {
      const uploadedUrls: string[] = [];

      if (!isNovel) {
        const total = chapterPages.length;
        for (let i = 0; i < total; i++) {
          const item = chapterPages[i];
          setUploadStatusText(`محرك Hart Host: تحسين ورفع الصفحة ${i + 1} من ${total}...`);
          
          const optimizedBlob = await hartHost.optimizeImage(item.blob, 1200, 0.82);
          const url = await hartHost.uploadMedia(
            optimizedBlob,
            'chapters',
            `ch_${chapterNumber}_p${i + 1}_${item.filename}`
          );
          uploadedUrls.push(url);

          const progressPercent = Math.round(((i + 1) / total) * 90);
          setChapterUploadProgress(progressPercent);
        }
      }

      setUploadStatusText('جاري تسجيل وتثبيت الفصل في قاعدة البيانات...');
      const chapterPayload: Omit<Chapter, 'id'> = {
        manhwaId: managingManhwa.id,
        chapterNumber: Number(chapterNumber),
        title: chapterTitle.trim(),
        pages: uploadedUrls,
        pagesCount: isNovel ? 1 : uploadedUrls.length,
        novelContent: isNovel ? novelContent.trim() : '',
        teamId: managingManhwa.teamId || '',
        publisherId: user.uid,
        views: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // 1. Create Chapter Document
      await addDoc(collection(db, 'chapters'), chapterPayload);

      // 2. Update parent Manhwa latest chapter info
      const manhwaRef = doc(db, 'manhwas', managingManhwa.id);
      await updateDoc(manhwaRef, {
        latestChapterNumber: Number(chapterNumber),
        latestChapterTitle: chapterTitle.trim(),
        updatedAt: new Date().toISOString()
      });

      setChapterNumber((prev: number) => prev + 1);
      setChapterTitle('');
      setNovelContent('');
      setChapterPages([]);
      setChapterUploadProgress(100);
      setUploadStatusText('تم نشر وتثبيت الفصل بنجاح!');
      setTimeout(() => setUploadStatusText(''), 3000);

      onRefresh();
    } catch (error: any) {
      console.error('Save chapter error:', error);
      setChapterError(error.message || 'فشل حفظ الفصل، يرجى إعادة المحاولة');
    } finally {
      setIsProcessingPages(false);
      setChapterUploadProgress(0);
    }
  };

  // Delete Chapter
  const handleDeleteChapter = async (chapterId: string, chNum: number) => {
    if (!window.confirm(`هل أنت متأكد من حذف الفصل رقم ${chNum}؟`)) return;
    try {
      await deleteDoc(doc(db, 'chapters', chapterId));
      onRefresh();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `chapters/${chapterId}`);
    }
  };

  const toggleGenre = (genre: string) => {
    if (workGenres.includes(genre)) {
      setWorkGenres(workGenres.filter((g: string) => g !== genre));
    } else {
      setWorkGenres([...workGenres, genre]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      
      {/* Dashboard Top Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 bg-[#101627] p-6 rounded-3xl border border-white/5 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-black text-white">لوحة النشر وإدارة الأعمال</h1>
            {activeTeamContext && (
              <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                فريق: {activeTeamContext.name}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400">
            إضافة وإدارة المانهوا، المانجا، المانها، الكوميكس، والروايات، مع رفع الفصول ومتابعة الإحصائيات.
          </p>
        </div>

        {/* Hart Host Engine Status Badge */}
        <div className="flex items-center gap-3 bg-[#151b2d] px-4 py-2.5 rounded-2xl border border-purple-900/30">
          <Server className="w-4 h-4 text-purple-400 animate-pulse" />
          <div className="text-right">
            <div className="text-[10px] font-semibold text-gray-400">محرك Hart Host التخزيني</div>
            <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>تخزين دائم وسريع مشترك 100%</span>
            </div>
          </div>
        </div>

        <button
          onClick={openNewWorkModal}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-purple-600/30 transition-all hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة عمل جديد</span>
        </button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="p-5 bg-[#101627] rounded-2xl border border-white/5 flex items-center justify-between">
          <div>
            <div className="text-xs text-gray-400 font-semibold mb-1">الأعمال المنشورة</div>
            <div className="text-2xl font-black text-white">{publisherWorks.length}</div>
          </div>
          <div className="p-3 rounded-xl bg-purple-900/20 text-purple-400">
            <Layers className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-[#101627] rounded-2xl border border-white/5 flex items-center justify-between">
          <div>
            <div className="text-xs text-gray-400 font-semibold mb-1">إجمالي الفصول المرفوعة</div>
            <div className="text-2xl font-black text-white">
              {chapters.filter((c) => publisherWorks.some((m) => m.id === c.manhwaId)).length}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-violet-900/20 text-violet-400">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-[#101627] rounded-2xl border border-white/5 flex items-center justify-between">
          <div>
            <div className="text-xs text-gray-400 font-semibold mb-1">إجمالي المشاهدات</div>
            <div className="text-2xl font-black text-white">
              {publisherWorks.reduce((acc, m) => acc + (m.views || 0), 0)}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-pink-900/20 text-pink-400">
            <Eye className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Publisher Works List */}
      <div className="bg-[#101627] rounded-3xl border border-white/5 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white">أعمالك المتاحة</h2>
          <span className="text-xs text-gray-400 font-mono">{publisherWorks.length} عمل</span>
        </div>

        {publisherWorks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {publisherWorks.map((work) => {
              const workChs = chapters.filter((c) => c.manhwaId === work.id);
              const typeInfo = WORK_TYPE_LABELS[work.type || 'manhwa'] || WORK_TYPE_LABELS.manhwa;

              return (
                <div
                  key={work.id}
                  className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 flex gap-4 items-center justify-between hover:border-purple-500/30 transition-all"
                >
                  <SmartImage
                    src={work.coverUrl}
                    alt={work.title}
                    fallbackText={work.title}
                    className="w-full h-full object-cover"
                    aspectRatio="aspect-[3/4]"
                    containerClassName="w-16 h-22 rounded-xl shadow-md border border-purple-500/20 shrink-0 bg-[#101627]"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-800/40">
                        {typeInfo.flag} {typeInfo.ar}
                      </span>
                      <h3 className="font-bold text-sm text-white truncate">{work.title}</h3>
                    </div>

                    <div className="text-[11px] text-gray-400 flex items-center gap-2 mb-2">
                      <span className="text-purple-300 font-semibold">{workChs.length} فصل</span>
                      <span>•</span>
                      <span>{work.views || 0} مشاهدة</span>
                      {work.teamName && (
                        <>
                          <span>•</span>
                          <span className="text-pink-400 truncate max-w-[80px]">{work.teamName}</span>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openChapterManager(work)}
                        className="px-2.5 py-1 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-[11px] font-bold rounded-lg transition-transform hover:scale-105"
                      >
                        إدارة الفصول
                      </button>

                      <button
                        onClick={() => openEditWorkModal(work)}
                        className="p-1.5 text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                        title="تعديل البيانات"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDeleteWork(work)}
                        className="p-1.5 text-gray-400 hover:text-red-400 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                        title="حذف العمل"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center">
            <Layers className="w-12 h-12 mx-auto text-gray-600 mb-3" />
            <h3 className="text-base font-bold text-white mb-1">لم تقم بإضافة أي عمل بعد</h3>
            <p className="text-xs text-gray-400 mb-4">
              ابدأ الآن بإضافة أول مانهوا أو مانجا أو رواية ورفع فصولها مباشرة من استوديو هاتفك.
            </p>
            <button
              onClick={openNewWorkModal}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl"
            >
              إضافة عمل الآن
            </button>
          </div>
        )}
      </div>

      {/* ADD / EDIT WORK MODAL */}
      {showAddManhwaModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl relative p-6 sm:p-8">
            <button
              onClick={() => setShowAddManhwaModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-6">
              {editingManhwa ? 'تعديل بيانات العمل' : 'إضافة عمل جديد (مانهوا / مانجا / رواية)'}
            </h2>

            {saveWorkError && (
              <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{saveWorkError}</span>
              </div>
            )}

            <form onSubmit={handleSaveWork} className="space-y-4">
              
              {/* Work Type Selection */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">نوع العمل</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {(Object.keys(WORK_TYPE_LABELS) as WorkType[]).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setWorkType(t)}
                      className={`p-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center gap-1 ${
                        workType === t
                          ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                          : 'bg-[#151b2d] text-gray-400 border-white/5 hover:text-white'
                      }`}
                    >
                      <span>{WORK_TYPE_LABELS[t].flag}</span>
                      <span>{WORK_TYPE_LABELS[t].ar}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Team Assignment */}
              {userTeams.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">فريق النشر والترجمة</label>
                  <select
                    value={selectedTeamId}
                    onChange={(e) => setSelectedTeamId(e.target.value)}
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                  >
                    <option value="">بدون فريق (نشر مستقل باسمك)</option>
                    {userTeams.map((team) => (
                      <option key={team.id} value={team.id}>
                        فريق: {team.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">عنوان العمل (بالعربية) *</label>
                  <input
                    type="text"
                    required
                    value={workTitle}
                    onChange={(e) => setWorkTitle(e.target.value)}
                    placeholder="مثال: بداية الماجي الساحر"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">الاسم الأصلي / الإنجليزي (اختياري)</label>
                  <input
                    type="text"
                    value={workTitleOriginal}
                    onChange={(e) => setWorkTitleOriginal(e.target.value)}
                    placeholder="The Beginning After The End"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">القصة والنبذة *</label>
                <textarea
                  required
                  rows={3}
                  value={workDescription}
                  onChange={(e) => setWorkDescription(e.target.value)}
                  placeholder="اكتب قصة مشوقة عن العمل لجذب القراء..."
                  className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-purple-500"
                />
              </div>

              {/* Cover Upload */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">صورة الغلاف (Cover) *</label>
                <div className="flex items-center gap-4">
                  {coverPreview ? (
                    <SmartImage
                      src={coverPreview}
                      alt="Preview"
                      className="w-full h-full object-cover"
                      aspectRatio="aspect-[3/4]"
                      containerClassName="w-20 h-28 rounded-xl border border-purple-500/40 shrink-0 bg-[#151b2d]"
                      fallbackText="غلاف"
                    />
                  ) : (
                    <div className="w-20 h-28 rounded-xl bg-[#151b2d] border border-dashed border-white/20 flex flex-col items-center justify-center text-gray-500 text-[10px] shrink-0">
                      <ImageIcon className="w-6 h-6 mb-1" />
                      <span>لا يوجد غلاف</span>
                    </div>
                  )}

                  <div className="flex-1">
                    <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#171f33] hover:bg-[#202b46] border border-white/10 rounded-xl text-xs font-bold text-purple-300 cursor-pointer transition-colors">
                      <Upload className="w-4 h-4" />
                      <span>اختر صورة الغلاف من هاتفك</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleCoverChange}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[11px] text-gray-500 mt-1">
                      يدعم استوديو الهاتف والكمبيوتر. يتم ضغط الغلاف تلقائياً وحفظه دائماً لجميع المستخدمين.
                    </p>
                  </div>
                </div>
              </div>

              {/* Genres Selection */}
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1.5">التصنيفات</label>
                <div className="flex flex-wrap gap-1.5">
                  {MANHWA_GENRES.map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => toggleGenre(g)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        workGenres.includes(g)
                          ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30'
                          : 'bg-[#151b2d] text-gray-400 hover:text-white'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status, Author, Artist */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">الحالة</label>
                  <select
                    value={workStatus}
                    onChange={(e) => setWorkStatus(e.target.value as any)}
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500"
                  >
                    <option value="ongoing">مستمرة</option>
                    <option value="completed">مكتملة</option>
                    <option value="hiatus">متوقفة مؤقتاً</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">المؤلف (Author)</label>
                  <input
                    type="text"
                    value={workAuthor}
                    onChange={(e) => setWorkAuthor(e.target.value)}
                    placeholder="اسم الكاتب"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">الرسام (Artist)</label>
                  <input
                    type="text"
                    value={workArtist}
                    onChange={(e) => setWorkArtist(e.target.value)}
                    placeholder="اسم الرسام"
                    className="w-full bg-[#151b2d] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {/* Team Assignment & Contributor Permissions (Requirement 2 & 3) */}
              <div className="p-4 bg-[#151b2d] rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-gray-300 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-purple-400" />
                    <span>فريق العمل والترجمة</span>
                  </label>
                  <span className="text-[10px] text-gray-400">يمكن ربط العمل بفريق وتعيين صلاحيات</span>
                </div>

                <select
                  value={selectedTeamId}
                  onChange={(e) => {
                    setSelectedTeamId(e.target.value);
                  }}
                  className="w-full bg-[#101627] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500"
                >
                  <option value="">نشر شخصي مستقل (بدون فريق)</option>
                  {userTeams.map((team) => (
                    <option key={team.id} value={team.id}>
                      فريق: {team.name} ({team.members?.length || 1} أعضاء)
                    </option>
                  ))}
                </select>

                {/* If a team is selected, show member assignment options */}
                {selectedTeamId && (
                  <div className="pt-2 border-t border-white/5">
                    <label className="block text-[11px] font-bold text-purple-300 mb-2 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-pink-400" />
                      <span>طاقم العمل المخصص لهذا العمل (صلاحيات التحرير والنشر):</span>
                    </label>

                    <div className="flex flex-wrap gap-2">
                      {teams.find((t) => t.id === selectedTeamId)?.members?.map((member) => {
                        const isAssigned = assignedMembers.some((m: AssignedMember) => m.uid === member.uid);
                        return (
                          <button
                            key={member.uid}
                            type="button"
                            onClick={() => toggleAssignedMember(member)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                              isAssigned
                                ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-sm shadow-purple-600/30 border border-purple-400/30'
                                : 'bg-[#101627] text-gray-400 hover:text-white border border-white/5'
                            }`}
                          >
                            <span>{member.displayName}</span>
                            <span className="text-[10px] opacity-75">
                              ({TEAM_ROLE_LABELS[member.role] || member.role})
                            </span>
                            {isAssigned && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                          </button>
                        );
                      })}
                    </div>
                    <p className="text-[10px] text-gray-500 mt-2">
                      الأعضاء المحددون يتم منحهم صلاحيات تحرير معلومات هذا العمل ورفع الفصول وإدارتها.
                    </p>
                  </div>
                )}
              </div>

              {/* Upload Progress Bar */}
              {isSavingManhwa && (
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-400">
                    <span>محرك Hart Host يعالج الغلاف ويرفعه لخادم التخزين الدائم...</span>
                    <span>{manhwaUploadProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-600 transition-all duration-300"
                      style={{ width: `${manhwaUploadProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddManhwaModal(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-gray-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSavingManhwa}
                  className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30"
                >
                  {isSavingManhwa ? 'جاري الحفظ...' : editingManhwa ? 'تحديث العمل' : 'نشر العمل'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CHAPTER MANAGER MODAL */}
      {managingManhwa && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101627] border border-purple-900/40 rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl relative p-6 sm:p-8">
            <button
              onClick={() => setManagingManhwa(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-white/5 text-gray-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-6 pb-4 border-b border-white/5">
              <SmartImage
                src={managingManhwa.coverUrl}
                alt={managingManhwa.title}
                fallbackText={managingManhwa.title}
                className="w-full h-full object-cover"
                aspectRatio="aspect-[3/4]"
                containerClassName="w-14 h-20 rounded-xl border border-purple-500/30 shrink-0 bg-[#151b2d]"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-500/40">
                    {WORK_TYPE_LABELS[(managingManhwa.type as WorkType) || 'manhwa']?.ar || 'مانهوا'}
                  </span>
                  <h2 className="text-xl font-bold text-white">إدارة فصول: {managingManhwa.title}</h2>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  {managingManhwa.type === 'novel'
                    ? 'كتابة ونشر نصوص فصول الرواية المنسقة.'
                    : 'رفع فصول مصورة عبر تحديد الصور المتعددة من استوديو هاتفك أو رفع ملف ZIP مباشرة.'}
                </p>
              </div>
            </div>

            {chapterError && (
              <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-500/40 text-xs text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{chapterError}</span>
              </div>
            )}

            {/* Form to Add New Chapter */}
            <div className="bg-[#151b2d] p-5 rounded-2xl border border-white/5 mb-8">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-purple-400" />
                <span>رفع وإضافة فصل جديد</span>
              </h3>

              <form onSubmit={handleSaveChapter} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5">رقم الفصل *</label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={chapterNumber}
                      onChange={(e) => setChapterNumber(parseFloat(e.target.value))}
                      className="w-full bg-[#101627] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5">عنوان الفصل (اختياري)</label>
                    <input
                      type="text"
                      value={chapterTitle}
                      onChange={(e) => setChapterTitle(e.target.value)}
                      placeholder="مثال: الاستيقاظ المفاجئ"
                      className="w-full bg-[#101627] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* If Novel -> Rich text area */}
                {managingManhwa.type === 'novel' ? (
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5">
                      نص فصل الرواية (اكتب أو الصق النص هنا) *
                    </label>
                    <textarea
                      required
                      rows={10}
                      value={novelContent}
                      onChange={(e) => setNovelContent(e.target.value)}
                      placeholder="كان الظلام يخيّم على الغابة العتيقة حينما استيقظ البطل..."
                      className="w-full bg-[#101627] border border-white/10 rounded-2xl p-4 text-xs sm:text-sm text-gray-100 leading-relaxed outline-none focus:border-purple-500 font-serif"
                    />
                  </div>
                ) : (
                  /* If Comic/Manga/Manhwa -> Dual Upload (Multi-image or ZIP) */
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <label className="p-4 bg-[#101627] hover:bg-[#1a2138] border border-dashed border-purple-500/30 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-colors group">
                        <ImageIcon className="w-6 h-6 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold text-white">اختيار صور من استوديو الهاتف / الكمبيوتر</span>
                        <span className="text-[10px] text-gray-400 mt-0.5">اختر صور متعددة وسيقوم المحرك بفرزها وضغطها</span>
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleMultipleImagesSelect}
                          className="hidden"
                        />
                      </label>

                      <label className="p-4 bg-[#101627] hover:bg-[#1a2138] border border-dashed border-pink-500/30 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-colors group">
                        <Archive className="w-6 h-6 text-pink-400 mb-2 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold text-white">رفع ملف أرشيف ZIP</span>
                        <span className="text-[10px] text-gray-400 mt-0.5">يفك الضغط ويرتب الصفحات رقمياً تلقائياً</span>
                        <input
                          type="file"
                          accept=".zip,application/zip"
                          onChange={handleZipUpload}
                          className="hidden"
                        />
                      </label>
                    </div>

                    {/* Chapter Pages Thumbnail Strip */}
                    {chapterPages.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-bold text-gray-300">
                            الصفحات المحددة ({chapterPages.length} صفحة بالترتيب)
                          </span>
                          <button
                            type="button"
                            onClick={() => setChapterPages([])}
                            className="text-[11px] text-red-400 hover:underline"
                          >
                            مسح جميع الصفحات
                          </button>
                        </div>

                        <div className="flex gap-2 overflow-x-auto no-scrollbar p-2 bg-[#101627] rounded-xl border border-white/5">
                          {chapterPages.map((page: ChapterPageItem, idx: number) => (
                            <div key={idx} className="relative w-16 h-24 shrink-0 rounded-lg overflow-hidden border border-white/10 group">
                              <img src={page.preview} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                              <span className="absolute bottom-0 inset-x-0 bg-black/70 text-[9px] font-mono text-center text-white py-0.5">
                                {idx + 1}
                              </span>
                              <button
                                type="button"
                                onClick={() => setChapterPages(chapterPages.filter((_: unknown, i: number) => i !== idx))}
                                className="absolute top-1 right-1 p-0.5 bg-red-600 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Upload Status text */}
                {uploadStatusText && (
                  <div className="p-3 bg-purple-950/40 border border-purple-800/40 rounded-xl text-xs text-purple-300 font-semibold flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping"></span>
                    <span>{uploadStatusText}</span>
                  </div>
                )}

                {/* Progress bar */}
                {chapterUploadProgress > 0 && (
                  <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-200"
                      style={{ width: `${chapterUploadProgress}%` }}
                    ></div>
                  </div>
                )}

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isProcessingPages}
                    className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30"
                  >
                    {isProcessingPages ? 'جاري الرفع والمعالجة...' : 'حفظ ونشر الفصل وتثبيته'}
                  </button>
                </div>
              </form>
            </div>

            {/* List of Existing Chapters */}
            <div>
              <h3 className="text-sm font-bold text-white mb-3">الفصول المنشورة حالياً</h3>
              {chapters.filter((c) => c.manhwaId === managingManhwa.id).length > 0 ? (
                <div className="space-y-2">
                  {chapters
                    .filter((c) => c.manhwaId === managingManhwa.id)
                    .sort((a, b) => b.chapterNumber - a.chapterNumber)
                    .map((chapter) => (
                      <div
                        key={chapter.id}
                        className="p-3 bg-[#151b2d] rounded-xl border border-white/5 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-purple-900/30 text-purple-300 font-bold text-xs flex items-center justify-center">
                            {chapter.chapterNumber}
                          </div>
                          <div>
                            <span className="text-xs font-bold text-white">الفصل {chapter.chapterNumber}</span>
                            {chapter.title && (
                              <span className="text-xs text-gray-400 mr-2">({chapter.title})</span>
                            )}
                            <div className="text-[11px] text-gray-500 font-mono">
                              {managingManhwa.type === 'novel' ? 'نص رواية' : `${chapter.pagesCount || chapter.pages?.length || 0} صفحة`} • {chapter.views || 0} مشاهدة
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => handleDeleteChapter(chapter.id, chapter.chapterNumber)}
                          className="p-2 text-gray-400 hover:text-red-400 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                          title="حذف الفصل"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                </div>
              ) : (
                <div className="py-6 text-center text-xs text-gray-500">
                  لا توجد فصول مرفوعة لهذا العمل بعد.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
