import { useState, useEffect } from 'react';
import { Student, Language, Currency, DayOfWeek } from '../types';
import { X, User, Phone, Mail, DollarSign, Calendar, Clock, BookOpen, Check } from 'lucide-react';

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (studentData: Partial<Student>) => void;
  initialStudent?: Student | null;
}

const DAYS: DayOfWeek[] = [
  'Pazartesi',
  'Salı',
  'Çarşamba',
  'Perşembe',
  'Cuma',
  'Cumartesi',
  'Pazar',
];

export const StudentModal = ({
  isOpen,
  onClose,
  onSave,
  initialStudent,
}: StudentModalProps) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState<Language>('english');
  const [hourlyRate, setHourlyRate] = useState<number>(850);
  const [currency, setCurrency] = useState<Currency>('TL');
  const [paymentFrequency, setPaymentFrequency] = useState<number>(4);
  const [notes, setNotes] = useState('');
  const [scheduledDay, setScheduledDay] = useState<DayOfWeek>('Salı');
  const [scheduledTime, setScheduledTime] = useState('17:00');

  useEffect(() => {
    if (initialStudent) {
      setName(initialStudent.name);
      setPhone(initialStudent.phone);
      setEmail(initialStudent.email || '');
      setSubject(initialStudent.subject);
      setHourlyRate(initialStudent.hourlyRate);
      setCurrency(initialStudent.currency);
      setPaymentFrequency(initialStudent.paymentFrequency);
      setNotes(initialStudent.notes || '');
      if (initialStudent.schedule && initialStudent.schedule[0]) {
        setScheduledDay(initialStudent.schedule[0].day);
        setScheduledTime(initialStudent.schedule[0].time);
      }
    } else {
      setName('');
      setPhone('');
      setEmail('');
      setSubject('english');
      setHourlyRate(850);
      setCurrency('TL');
      setPaymentFrequency(4);
      setNotes('');
      setScheduledDay('Salı');
      setScheduledTime('17:00');
    }
  }, [initialStudent, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSave({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      subject,
      hourlyRate: Number(hourlyRate),
      currency,
      paymentFrequency: Number(paymentFrequency),
      notes: notes.trim(),
      schedule: [
        {
          day: scheduledDay,
          time: scheduledTime,
          durationMinutes: 60,
        },
      ],
      status: 'active',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-lg w-full shadow-2xl border border-zinc-800 flex flex-col max-h-[90vh] sm:max-h-[85vh] overflow-hidden">
        
        {/* Sticky Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-[#121214] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-bold text-sm">
              👩‍🏫
            </div>
            <div>
              <h3 className="font-bold text-base font-serif text-white">
                {initialStudent ? 'Öğrenciyi Düzenle' : 'Yeni Öğrenci Ekle'}
              </h3>
              <p className="text-[11px] text-stone-400">
                Ders programı ve ödeme periyodu tanımlayın
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-4 sm:p-5 space-y-3.5 overflow-y-auto flex-1 text-xs">
            
            {/* Ad Soyad */}
            <div>
              <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                Öğrenci Adı Soyadı *
              </label>
              <input
                type="text"
                required
                placeholder="Örn: Selin Kaya"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl focus:bg-zinc-850 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 text-white placeholder:text-stone-500 font-medium"
              />
            </div>

            {/* Telefon & E-posta */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  Telefon
                </label>
                <input
                  type="text"
                  placeholder="+90 5XX XXX XX XX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-white placeholder:text-stone-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  E-posta (İsteğe bağlı)
                </label>
                <input
                  type="email"
                  placeholder="ornek@mail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-white placeholder:text-stone-500"
                />
              </div>
            </div>

            {/* Ders Alanı (İngilizce / Türkçe) */}
            <div>
              <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                Ders Alanı
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSubject('english')}
                  className={`py-1.5 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    subject === 'english'
                      ? 'bg-sky-950 border-sky-400 text-sky-300 ring-2 ring-sky-400/20'
                      : 'bg-zinc-900 border-zinc-800 text-stone-400 hover:bg-zinc-850'
                  }`}
                >
                  <span>🇬🇧</span>
                  <span>İngilizce</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSubject('turkish')}
                  className={`py-1.5 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    subject === 'turkish'
                      ? 'bg-rose-950 border-rose-400 text-rose-300 ring-2 ring-rose-400/20'
                      : 'bg-zinc-900 border-zinc-800 text-stone-400 hover:bg-zinc-850'
                  }`}
                >
                  <span>🇹🇷</span>
                  <span>Türkçe</span>
                </button>
              </div>
            </div>

            {/* Ücret ve Para Birimi ($ veya TL) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  Ders Başı Ücret *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/30 font-mono font-bold text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  Para Birimi
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCurrency('TL')}
                    className={`py-2 px-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      currency === 'TL'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                        : 'bg-zinc-900 border-zinc-800 text-stone-400'
                    }`}
                  >
                    ₺ (TL)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrency('USD')}
                    className={`py-2 px-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      currency === 'USD'
                        ? 'bg-sky-950 border-sky-500 text-sky-300'
                        : 'bg-zinc-900 border-zinc-800 text-stone-400'
                    }`}
                  >
                    $ (USD)
                  </button>
                </div>
              </div>
            </div>

            {/* Ödeme Periyodu */}
            <div className="bg-amber-950/30 border border-amber-500/40 p-3 rounded-2xl">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                  💰 Ödeme Periyodu
                </label>
                <span className="text-[11px] font-bold font-mono text-amber-300">
                  Paket: {(hourlyRate * paymentFrequency).toLocaleString('tr-TR')} {currency === 'USD' ? '$' : '₺'}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-1.5 mb-2">
                <button
                  type="button"
                  onClick={() => setPaymentFrequency(1)}
                  className={`py-1 px-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer ${
                    paymentFrequency === 1
                      ? 'bg-amber-500 text-stone-950 border-amber-400 font-bold'
                      : 'bg-zinc-900 border-zinc-800 text-stone-300'
                  }`}
                >
                  Her Ders (1)
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentFrequency(4)}
                  className={`py-1 px-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer ${
                    paymentFrequency === 4
                      ? 'bg-amber-500 text-stone-950 border-amber-400 font-bold'
                      : 'bg-zinc-900 border-zinc-800 text-stone-300'
                  }`}
                >
                  4 Derste Bir
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentFrequency(8)}
                  className={`py-1 px-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer ${
                    paymentFrequency === 8
                      ? 'bg-amber-500 text-stone-950 border-amber-400 font-bold'
                      : 'bg-zinc-900 border-zinc-800 text-stone-300'
                  }`}
                >
                  8 Derste Bir
                </button>
              </div>

              <div className="flex items-center gap-2 text-[11px]">
                <span className="text-amber-400/90">Özel Ders Adedi:</span>
                <input
                  type="number"
                  min="1"
                  max="24"
                  value={paymentFrequency}
                  onChange={(e) => setPaymentFrequency(Math.max(1, Number(e.target.value)))}
                  className="w-14 px-2 py-0.5 bg-zinc-900 border border-amber-500/50 rounded-lg text-center font-bold text-white text-xs"
                />
                <span className="text-stone-400 text-[10px]">derste bir para alınır</span>
              </div>
            </div>

            {/* Sabit Gün ve Saat */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  Sabit Ders Günü
                </label>
                <select
                  value={scheduledDay}
                  onChange={(e) => setScheduledDay(e.target.value as DayOfWeek)}
                  className="w-full px-2.5 py-2 bg-zinc-900 border border-zinc-800 rounded-xl font-semibold text-white text-xs"
                >
                  {DAYS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                  Ders Saati
                </label>
                <input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full px-2.5 py-2 bg-zinc-900 border border-zinc-800 rounded-xl font-mono font-bold text-white text-xs"
                />
              </div>
            </div>

            {/* Notlar */}
            <div>
              <label className="block text-[11px] font-bold text-stone-300 uppercase tracking-wider mb-1">
                Öğrenci Notları / Hedef Seviye
              </label>
              <textarea
                rows={2}
                placeholder="Örn: B1 Speaking ağırlıklı, YDS hazırlık..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-xl focus:bg-zinc-850 focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-white placeholder:text-stone-500 text-xs"
              />
            </div>
          </div>

          {/* Sticky Bottom Action Buttons (Always visible on mobile!) */}
          <div className="px-5 py-3 border-t border-zinc-800 bg-[#121214] flex items-center justify-end gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-stone-400 hover:text-white rounded-xl transition-all cursor-pointer"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-xl shadow-md shadow-rose-950/40 transition-all cursor-pointer active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{initialStudent ? 'Güncelle' : 'Öğrenciyi Kaydet'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
