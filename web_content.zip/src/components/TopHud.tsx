import React from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  Brain,
  Cpu,
  Database,
  Layers,
  Radio,
  Server,
  Shield,
  ShieldCheck,
  Volume2,
  VolumeX,
  Sliders,
} from 'lucide-react';
import { CoreLoopStage, SystemStatus } from '../types.ts';

interface TopHudProps {
  status: SystemStatus | null;
  currentStage: CoreLoopStage | null;
  isVoiceActive: boolean;
  onToggleVoice: () => void;
  onOpenVoiceSettings?: () => void;
  pendingApprovalsCount: number;
  onOpenSecurity: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  memoryCount?: number;
}

export const TopHud: React.FC<TopHudProps> = ({
  status,
  currentStage,
  isVoiceActive,
  onToggleVoice,
  onOpenVoiceSettings,
  pendingApprovalsCount,
  onOpenSecurity,
  activeTab,
  onSelectTab,
  memoryCount = 24,
}) => {
  return (
    <header
      id="jarvis-top-hud"
      className="bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 px-4 py-2.5 transition-colors shadow-xs"
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Kernel Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 text-sky-600 shadow-xs">
              <Radio className="w-4 h-4 text-sky-600" />
              <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 animate-ping opacity-75" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm tracking-wide text-slate-900 uppercase font-sans">
                  {status?.assistantIdentity || 'JARVIS 5.1'}
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-50 text-sky-700 border border-sky-200 font-mono font-medium">
                  {status?.version || 'v5.1.0'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-emerald-700 font-semibold">ONLINE / HEALTHY</span>
                <span className="text-slate-300">•</span>
                <span className="text-slate-600">{status?.operationalStatus || 'AUTONOMOUS ACTIVE'}</span>
              </div>
            </div>
          </div>

          {/* Current Loop Stage Badge */}
          {currentStage && (
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-sky-50 border border-sky-200 text-sky-800 text-xs font-mono shadow-xs">
              <Activity className="w-3.5 h-3.5 animate-spin text-sky-600" />
              <span>CORE LOOP: <strong>{currentStage}</strong></span>
            </div>
          )}
        </div>

        {/* Telemetry & Clean Status Indicators */}
        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap text-xs font-mono">
          {/* AI Model Status */}
          <button
            id="hud-model-btn"
            onClick={() => onSelectTab('models')}
            title="Open Model Routing & Architecture Console"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 shadow-xs transition-colors cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-sky-600" />
            <span className="text-slate-500">MODEL:</span>
            <span className="text-slate-900 font-semibold">
              {status?.hasGeminiApiKey ? 'Gemini 3.8 Flash' : 'Local Heuristic Edge'}
            </span>
          </button>

          {/* Memory Status */}
          <div
            title="Persistent Memory Bank State"
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 shadow-xs"
          >
            <Database className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-slate-500">MEMORY:</span>
            <span className="text-slate-900 font-semibold">{memoryCount} ENTRIES</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-600">{status?.memoryUsageRssMb || 42}MB RSS</span>
          </div>

          {/* Agent Status */}
          <div
            title="Specialized Sub-Agents Subsystem"
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 shadow-xs"
          >
            <Bot className="w-3.5 h-3.5 text-indigo-600" />
            <span className="text-slate-500">AGENTS:</span>
            <span className="text-slate-900 font-semibold">{status?.activeAgentsCount || 6} UNITS</span>
          </div>

          {/* Security Status Indicator */}
          {pendingApprovalsCount > 0 ? (
            <button
              id="pending-approvals-alert-btn"
              onClick={onOpenSecurity}
              aria-label={`${pendingApprovalsCount} pending authorization requests`}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 font-semibold animate-pulse hover:bg-amber-100 transition-all shadow-xs"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>{pendingApprovalsCount} PERMISSION NEEDED</span>
            </button>
          ) : (
            <button
              id="security-boundary-badge"
              onClick={onOpenSecurity}
              title="Security layer actively enforcing zero-trust boundaries"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 hover:bg-emerald-100/70 transition-all shadow-xs"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span className="font-semibold">SECURITY: ZERO-TRUST</span>
            </button>
          )}

          {/* Voice Status Toggle & Settings */}
          <div className="flex items-center gap-1">
            <button
              id="toggle-voice-btn"
              onClick={onToggleVoice}
              aria-label={isVoiceActive ? 'Disable voice synthesis' : 'Enable voice synthesis'}
              title={isVoiceActive ? 'Voice Synthesis Enabled' : 'Voice Synthesis Muted'}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all text-xs font-mono shadow-xs ${
                isVoiceActive
                  ? 'bg-sky-50 border-sky-300 text-sky-800 font-semibold hover:bg-sky-100'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {isVoiceActive ? <Volume2 className="w-3.5 h-3.5 text-sky-600" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
              <span className="font-medium">{isVoiceActive ? 'VOICE ON' : 'VOICE OFF'}</span>
            </button>

            {onOpenVoiceSettings && (
              <button
                id="open-voice-settings-btn"
                onClick={onOpenVoiceSettings}
                aria-label="Open voice settings modal"
                title="Voice Experience Settings (Rate, Pitch, Personality)"
                className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors shadow-xs"
              >
                <Sliders className="w-3.5 h-3.5 text-slate-600" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
