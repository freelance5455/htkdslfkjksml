import { ChipBar } from "@/components/chip-bar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useSentinel } from "@/hooks/use-sentinel";
import { POST_SORTS, sortComments, type PostSort } from "@/lib/sort";
import { formatCount } from "@/lib/utils";
import { getPostCommentsFn } from "@/lib/youtube/api";
import type { CommunityPost, YtComment } from "@/lib/youtube/types";
import { useInfiniteQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Heart, Loader2, ThumbsUp } from "lucide-react";
import { memo, useCallback, useMemo, useRef, useState } from "react";

function AuthorLink({
  comment,
}: {
  comment: YtComment;
}) {
  const inner = (
    <>
      {comment.authorThumbnail ? (
        <img
          src={comment.authorThumbnail}
          alt=""
          loading="lazy"
          decoding="async"
          className="size-8 shrink-0 rounded-full object-cover"
        />
      ) : (
        <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-xs">
          {comment.author.slice(0, 1) || "?"}
        </span>
      )}
    </>
  );
  if (!comment.authorChannelId) return inner;
  return (
    <Link
      to="/channel/$channelId"
      params={{ channelId: comment.authorChannelId }}
      className="shrink-0"
      aria-label={comment.author}
    >
      {inner}
    </Link>
  );
}

function CommentRow({
  comment,
  post,
  sort,
}: {
  comment: YtComment;
  post: CommunityPost;
  sort: PostSort;
}) {
  const [openReplies, setOpenReplies] = useState(false);
  const name = comment.authorChannelId ? (
    <Link
      to="/channel/$channelId"
      params={{ channelId: comment.authorChannelId }}
      className="truncate text-xs font-medium text-foreground"
    >
      {comment.author}
    </Link>
  ) : (
    <p className="truncate text-xs font-medium">{comment.author}</p>
  );

  return (
    <article className="flex gap-2.5">
      <AuthorLink comment={comment} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          {name}
          {comment.isCreator ? <Badge>Creator</Badge> : null}
          {comment.isVerified ? <Badge variant="outline">Verified</Badge> : null}
          {comment.hidden ? <Badge variant="outline">Hidden</Badge> : null}
          {comment.publishedText ? (
            <span className="text-[11px] text-muted-foreground">{comment.publishedText}</span>
          ) : null}
        </div>
        <p className="mt-1 whitespace-pre-wrap break-words text-sm leading-relaxed">{comment.text}</p>
        <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1 tabular-nums">
            <ThumbsUp className="size-3.5" />
            {comment.likeText || formatCount(comment.likeCount)}
          </span>
          {comment.hearted ? (
            <span
              className="inline-flex items-center gap-1 text-primary"
              title={comment.heartedBy ? `Hearted by ${comment.heartedBy}` : "Hearted by the creator"}
            >
              <Heart className="size-3.5 fill-current" />
              {comment.heartedBy ? `Hearted by ${comment.heartedBy}` : "Creator heart"}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1">
              <Heart className="size-3.5" />
              No heart
            </span>
          )}
        </div>
        {comment.repliesContinuation || comment.replyCount > 0 ? (
          <button
            type="button"
            className="mt-1.5 min-h-11 text-xs font-medium text-muted-foreground hover:text-foreground"
            onClick={() => setOpenReplies((v) => !v)}
          >
            {openReplies
              ? "Hide replies"
              : `Show ${comment.replyCount || ""} replies`.replace("  ", " ")}
          </button>
        ) : null}
        {openReplies && comment.repliesContinuation ? (
          <div className="mt-2 border-l border-border pl-3">
            <CommentList
              post={post}
              continuation={comment.repliesContinuation}
              nested
              sort={sort}
            />
          </div>
        ) : null}
      </div>
    </article>
  );
}

const MemoComment = memo(CommentRow);

function CommentList({
  post,
  continuation,
  nested = false,
  sort,
}: {
  post: CommunityPost;
  continuation?: string | null;
  nested?: boolean;
  sort: PostSort;
}) {
  const sentinel = useRef<HTMLDivElement>(null);
  const apiSort = sort === "popular" || sort === "unpopular" ? "top" : "newest";
  const query = useInfiniteQuery({
    queryKey: ["comments", post.id, continuation ?? "root", apiSort],
    initialPageParam: continuation ?? null,
    queryFn: async ({ pageParam }) =>
      getPostCommentsFn({
        data: {
          postId: post.id,
          channelId: post.channelId,
          commentParams: post.commentParams,
          continuation: pageParam,
          includeHidden: true,
          sort: pageParam ? undefined : apiSort,
        },
      }),
    getNextPageParam: (last, pages) => {
      const token = last.continuation ?? last.hiddenContinuation ?? undefined;
      if (!token) return undefined;
      const used = pages.some(
        (p, i) =>
          i < pages.length - 1 &&
          (p.continuation === token || p.hiddenContinuation === token),
      );
      if (used) return undefined;
      return token;
    },
    retry: 1,
  });

  const {
    data,
    isLoading,
    isError,
    refetch,
    hasNextPage,
    isFetchingNextPage,
    isFetching,
    fetchNextPage,
  } = query;

  const comments = useMemo(() => {
    const seen = new Set<string>();
    const list: YtComment[] = [];
    for (const page of data?.pages ?? []) {
      for (const c of page.comments) {
        if (seen.has(c.id)) continue;
        seen.add(c.id);
        list.push(c);
      }
    }
    return sortComments(list, sort);
  }, [data, sort]);

  const totalText = data?.pages[0]?.totalText ?? "";
  const loadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage && !isFetching) {
      void fetchNextPage();
    }
  }, [fetchNextPage, hasNextPage, isFetching, isFetchingNextPage]);

  useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore, "360px");

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 py-4 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" />
        Loading comments
      </div>
    );
  }

  if (isError) {
    return (
      <p className="py-3 text-sm text-muted-foreground">
        Couldn’t load comments.{" "}
        <button type="button" className="underline" onClick={() => refetch()}>
          Retry
        </button>
      </p>
    );
  }

  return (
    <div className={nested ? "space-y-3" : "space-y-4"}>
      {!nested && totalText ? (
        <p className="text-xs font-medium text-muted-foreground">{totalText}</p>
      ) : null}
      {comments.length === 0 ? (
        <p className="py-3 text-sm text-muted-foreground">No public comments yet.</p>
      ) : (
        comments.map((c) => <MemoComment key={c.id} comment={c} post={post} sort={sort} />)
      )}
      <div ref={sentinel} className="h-6" />
      {isFetchingNextPage ? (
        <div className="flex justify-center py-2 text-muted-foreground">
          <Loader2 className="size-4 animate-spin" />
        </div>
      ) : null}
    </div>
  );
}

export function CommentThread({ post }: { post: CommunityPost }) {
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState<PostSort>("newest");
  const count = post.replyText || formatCount(post.replyCount);
  return (
    <div className="mt-3 border-t border-border pt-3">
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="h-11 w-full justify-between px-1"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <span>Comments · {count}</span>
        <span className="text-muted-foreground">{open ? "Hide" : "Show all"}</span>
      </Button>
      {open ? (
        <div className="-mx-4 mt-2">
          <ChipBar ariaLabel="Comment sort" items={POST_SORTS} value={sort} onChange={setSort} />
          <div className="px-4">
            <CommentList post={post} sort={sort} />
          </div>
        </div>
      ) : null}
    </div>
  );
}
