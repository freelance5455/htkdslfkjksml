import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { CharacterModels } from '../game/models/CharacterModels';
import { WeaponModels } from '../game/models/WeaponModels';

interface Model3DPreviewProps {
  type: 'character' | 'weapon';
  id: string;
  skin?: string;
  attachments?: {
    optic?: string;
    barrel?: string;
    grip?: string;
    stock?: string;
    magazine?: string;
  };
}

export const Model3DPreview: React.FC<Model3DPreviewProps> = ({
  type,
  id,
  skin = 'tactical',
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rotYRef = useRef(0);
  const isDraggingRef = useRef(false);
  const lastXRef = useRef(0);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 300;
    const height = container.clientHeight || 300;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 50);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Lighting
    const hemi = new THREE.HemisphereLight(0xffffff, 0x334155, 1.2);
    scene.add(hemi);

    const dir = new THREE.DirectionalLight(0xfff7ed, 2.0);
    dir.position.set(5, 10, 8);
    scene.add(dir);

    const rim = new THREE.DirectionalLight(0xef4444, 1.8);
    rim.position.set(-5, 5, -6);
    scene.add(rim);

    // Model Root
    const modelRoot = new THREE.Group();
    scene.add(modelRoot);

    if (type === 'character') {
      const charMesh = CharacterModels.createCharacterMesh(id);
      charMesh.position.y = -0.9;
      modelRoot.add(charMesh);
      camera.position.set(0, 0.4, 3.2);
      camera.lookAt(0, 0, 0);
    } else {
      // Weapon with custom skin
      const built = WeaponModels.buildWeapon(id, (skin as any) || 'tactical');
      // Remove first-person arms from display preview
      const arms = built.model.getObjectByName('fps_arms');
      if (arms) arms.visible = false;

      built.model.position.set(0, 0, 0);
      built.model.rotation.y = -Math.PI / 4;
      modelRoot.add(built.model);
      camera.position.set(0, 0.1, 1.35);
      camera.lookAt(0, 0, 0);
    }

    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (!isDraggingRef.current) {
        rotYRef.current += 0.008; // Idle slow spin
      }
      modelRoot.rotation.y = rotYRef.current;
      renderer.render(scene, camera);
    };
    animate();

    const handlePointerDown = (e: PointerEvent) => {
      isDraggingRef.current = true;
      lastXRef.current = e.clientX;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (isDraggingRef.current) {
        const dx = e.clientX - lastXRef.current;
        lastXRef.current = e.clientX;
        rotYRef.current += dx * 0.015;
      }
    };

    const handlePointerUp = () => {
      isDraggingRef.current = false;
    };

    const dom = renderer.domElement;
    dom.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (dom.parentElement) dom.parentElement.removeChild(dom);
    };
  }, [type, id, skin]);

  return (
    <div className="relative w-full h-full cursor-grab active:cursor-grabbing flex items-center justify-center">
      <div ref={mountRef} className="w-full h-full touch-none" />
      <span className="absolute bottom-2 left-1/2 -translate-x-1/2 font-mono-tech text-[10px] text-zinc-400 bg-black/60 px-2 py-0.5 rounded-full pointer-events-none whitespace-nowrap">
        DRAG TO ROTATE 360°
      </span>
    </div>
  );
};
