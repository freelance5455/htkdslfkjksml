import React, { useState, useMemo } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  NICASLevelNumber,
  ChecklistCategory,
  ChecklistItem,
  NICAS_LEVEL_TITLES,
  CriterionStatus
} from '../types/climbing';
import {
  CheckCircle2,
  Clock,
  ShieldCheck,
  Award,
  Wrench,
  Activity,
  UserCheck,
  Edit3,
  CheckCheck,
  X,
  FileCheck
} from 'lucide-react';

export const NicasChecklist: React.FC = () => {
  const {
    checklist,
    updateChecklistItem,
    toggleChecklistItemStatus,
    signOffAllInLevel,
    climbs,
    profile
  } = useClimbing();

  const [activeLevel, setActiveLevel] = useState<NICASLevelNumber>(profile.currentLevel || 1);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [editingItem, setEditingItem] = useState<ChecklistItem | null>(null);
  const [showSignOffModal, setShowSignOffModal] = useState(false);
  const [instructorInput, setInstructorInput] = useState(profile.leadInstructor);
  const [signOffDateInput, setSignOffDateInput] = useState(() => new Date().toISOString().split('T')[0]);

  const totalClimbs = climbs.length;

  const levelThresholds: Record<NICASLevelNumber, number> = {
    1: 6,
    2: 20,
    3: 40,
    4: 60,
    5: 80
  };

  const levelItems = useMemo(() => {
    return checklist.filter(item => item.level === activeLevel);
  }, [checklist, activeLevel]);

  const filteredItems = useMemo(() => {
    if (activeCategory === 'All') return levelItems;
    return levelItems.filter(item => item.category === activeCategory);
  }, [levelItems, activeCategory]);

  const totalInLevel = levelItems.length;
  const completedInLevel = levelItems.filter(i => i.status === 'Completed').length;
  const inProgressInLevel = levelItems.filter(i => i.status === 'In Progress').length;
  const levelPercentage = totalInLevel > 0 ? Math.round((completedInLevel / totalInLevel) * 100) : 0;
  const isLevelCompleted = levelPercentage === 100;

  const categoryCounts = useMemo(() => {
    const counts: Record<string, { total: number; completed: number }> = {
      All: { total: levelItems.length, completed: completedInLevel },
      Safety: { total: 0, completed: 0 },
      Equipment: { total: 0, completed: 0 },
      Technique: { total: 0, completed: 0 },
      'Sign-Off': { total: 0, completed: 0 }
    };
    levelItems.forEach(i => {
      if (counts[i.category]) {
        counts[i.category].total++;
        if (i.status === 'Completed') counts[i.category].completed++;
      }
    });
    return counts;
  }, [levelItems, completedInLevel]);

  const handleSaveItemEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    updateChecklistItem(editingItem.id, {
      status: editingItem.status,
      signOffDate: editingItem.signOffDate,
      instructorName: editingItem.instructorName,
      instructorNotes: editingItem.instructorNotes,
      verified: editingItem.status === 'Completed'
    });
    setEditingItem(null);
  };

  const handleBatchSignOff = (e: React.FormEvent) => {
    e.preventDefault();
    signOffAllInLevel(activeLevel, instructorInput, signOffDateInput);
    setShowSignOffModal(false);
  };

  return (
    <div className="space-y-5 w-full max-w-full overflow-hidden">
      {/* 5-Level Progress Bar & Selector Strip */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 flex-wrap gap-2">
          <div>
            <span className="text-[11px] font-semibold text-orange-600 dark:text-orange-400 uppercase tracking-wider">NICAS Syllabus</span>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">National Indoor Climbing Awards</h2>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
            Candidate: <span className="font-semibold text-slate-800 dark:text-slate-200">{profile.candidateName || 'Candidate'}</span>
          </div>
        </div>

        {/* Level Tabs (Responsive scroll on 360px phones) */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-3">
          {([1, 2, 3, 4, 5] as NICASLevelNumber[]).map(lvl => {
            const items = checklist.filter(c => c.level === lvl);
            const comp = items.filter(c => c.status === 'Completed').length;
            const pct = items.length > 0 ? Math.round((comp / items.length) * 100) : 0;
            const isCurrent = activeLevel === lvl;
            const isDone = pct === 100;

            return (
              <button
                key={lvl}
                onClick={() => {
                  setActiveLevel(lvl);
                  setActiveCategory('All');
                }}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isCurrent
                    ? 'bg-slate-900 dark:bg-orange-600 text-white border-slate-900 dark:border-orange-500 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-bold ${isCurrent ? 'text-orange-400 dark:text-white' : 'text-orange-600 dark:text-orange-400'}`}>
                    Level {lvl}
                  </span>
                  {isDone ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <span className={`text-[10px] font-mono tabular-nums ${isCurrent ? 'text-slate-300 dark:text-orange-100' : 'text-slate-500 dark:text-slate-400'}`}>
                      {comp}/{items.length}
                    </span>
                  )}
                </div>
                <div className="text-[11px] font-semibold truncate">
                  {NICAS_LEVEL_TITLES[lvl].subtitle}
                </div>
                {/* Micro Bar */}
                <div className="w-full bg-slate-200/50 dark:bg-slate-700/50 h-1 rounded-full mt-1.5 overflow-hidden">
                  <div
                    style={{ width: `${pct}%` }}
                    className={`h-full rounded-full ${
                      isDone ? 'bg-emerald-500' : isCurrent ? 'bg-orange-500 dark:bg-white' : 'bg-slate-400'
                    }`}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Level Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-orange-800 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-800 px-2 py-0.5 rounded">
                Level {activeLevel} Criteria
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-slate-500 dark:text-slate-400">{NICAS_LEVEL_TITLES[activeLevel].subtitle}</span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">{NICAS_LEVEL_TITLES[activeLevel].title}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              {NICAS_LEVEL_TITLES[activeLevel].description}
            </p>
          </div>

          {/* Quick Level Status & Actions */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowSignOffModal(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs transition-colors shrink-0 cursor-pointer"
            >
              <FileCheck className="w-4 h-4" />
              <span>Sign Off Level {activeLevel}</span>
            </button>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 pt-3 overflow-x-auto pb-1 no-scrollbar">
          {(['All', 'Safety', 'Equipment', 'Technique', 'Sign-Off'] as const).map(cat => {
            const countInfo = categoryCounts[cat] || { total: 0, completed: 0 };
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-900 dark:bg-orange-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <span>{cat}</span>
                <span className={`text-[10px] font-mono px-1 py-0.2 rounded-full ${
                  isActive ? 'bg-slate-700 dark:bg-orange-700 text-slate-200 dark:text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}>
                  {countInfo.completed}/{countInfo.total}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Checklist Items List */}
      <div className="space-y-2.5">
        {filteredItems.map(item => {
          const isCompleted = item.status === 'Completed';
          const isInProgress = item.status === 'In Progress';

          return (
            <div
              key={item.id}
              className={`rounded-xl border transition-all p-3.5 sm:p-4 shadow-xs ${
                isCompleted
                  ? 'border-emerald-200 dark:border-emerald-800 bg-emerald-50/20 dark:bg-emerald-950/20'
                  : isInProgress
                  ? 'border-amber-200 dark:border-amber-800 bg-amber-50/10 dark:bg-amber-950/20'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                {/* Left: Checkbox & Info */}
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <button
                    type="button"
                    onClick={() => toggleChecklistItemStatus(item.id)}
                    title={`Click to toggle: ${item.status}`}
                    className={`mt-0.5 w-6 h-6 rounded-md flex items-center justify-center shrink-0 border transition-all ${
                      isCompleted
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : isInProgress
                        ? 'bg-amber-100 dark:bg-amber-950/40 border-amber-400 dark:border-amber-700 text-amber-700 dark:text-amber-300'
                        : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-400'
                    }`}
                  >
                    {isCompleted && <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />}
                    {isInProgress && <Clock className="w-3.5 h-3.5" />}
                  </button>

                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                        {item.category}
                      </span>
                      <span className="text-slate-300 dark:text-slate-600">·</span>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                        {item.title}
                      </h4>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                        isCompleted
                          ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300'
                          : isInProgress
                          ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}>
                        {item.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.description}
                    </p>

                    {(item.instructorName || item.signOffDate || item.instructorNotes) && (
                      <div className="mt-1.5 pt-1.5 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-0.5">
                        {item.instructorName && (
                          <span className="font-medium text-slate-700 dark:text-slate-300">
                            Instructor: {item.instructorName}
                          </span>
                        )}
                        {item.signOffDate && (
                          <span className="font-mono text-slate-500 dark:text-slate-400">
                            Signed: {item.signOffDate}
                          </span>
                        )}
                        {item.instructorNotes && (
                          <span className="italic text-slate-600 dark:text-slate-300">
                            "{item.instructorNotes}"
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Details / Edit button */}
                <div className="self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={() => setEditingItem(item)}
                    className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>Sign Off</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Single Item Sign-Off / Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-lg border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Sign Off Criterion</h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveItemEdit} className="p-4 sm:p-5 space-y-4">
              <div>
                <span className="text-[10px] text-orange-700 dark:text-orange-400 font-semibold uppercase tracking-wider">
                  Level {editingItem.level} · {editingItem.category}
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">{editingItem.title}</h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">{editingItem.description}</p>
              </div>

              {/* Status Selector */}
              <div className="space-y-1.5 pt-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Status</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['Not Started', 'In Progress', 'Completed'] as CriterionStatus[]).map(status => (
                    <button
                      key={status}
                      type="button"
                      onClick={() =>
                        setEditingItem({
                          ...editingItem,
                          status,
                          signOffDate:
                            status === 'Completed'
                              ? editingItem.signOffDate || new Date().toISOString().split('T')[0]
                              : undefined
                        })
                      }
                      className={`py-2 px-2 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                        editingItem.status === status
                          ? status === 'Completed'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : status === 'In Progress'
                            ? 'bg-amber-600 text-white border-amber-600'
                            : 'bg-slate-800 dark:bg-slate-700 text-white border-slate-800 dark:border-slate-600'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Instructor Name & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Sign-Off Instructor</label>
                  <input
                    type="text"
                    placeholder="Instructor name"
                    value={editingItem.instructorName || ''}
                    onChange={e => setEditingItem({ ...editingItem, instructorName: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Date</label>
                  <input
                    type="date"
                    value={editingItem.signOffDate || ''}
                    onChange={e => setEditingItem({ ...editingItem, signOffDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Assessor Feedback / Notes</label>
                <textarea
                  rows={2}
                  placeholder="Feedback notes..."
                  value={editingItem.instructorNotes || ''}
                  onChange={e => setEditingItem({ ...editingItem, instructorNotes: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch Sign-Off Modal */}
      {showSignOffModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-md border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Sign Off Level {activeLevel}</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSignOffModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleBatchSignOff} className="p-4 sm:p-5 space-y-3.5">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                This will sign off all Safety, Equipment, Technique, and Sign-Off criteria in <strong>Level {activeLevel}</strong> as Completed.
              </p>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Course Director / Instructor *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lead Instructor"
                  value={instructorInput}
                  onChange={e => setInstructorInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Date *</label>
                <input
                  type="date"
                  required
                  value={signOffDateInput}
                  onChange={e => setSignOffDateInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowSignOffModal(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs cursor-pointer"
                >
                  Confirm Sign-Off
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
