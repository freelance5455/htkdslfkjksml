"use client";

import { useMemo } from "react";
import { Candle } from "@/types";

interface Props {
  candles: Candle[];
  height?: number;
  livePrice?: number;
  showGrid?: boolean;
}

/** Lightweight SVG candlestick renderer (zero-dependency, RTL-safe). */
export default function CandleChart({ candles, height = 280, livePrice, showGrid = true }: Props) {
  const view = useMemo(() => {
    const data = candles.slice(-80);
    if (data.length === 0) return null;
    const highs = data.map((c) => c.high);
    const lows = data.map((c) => c.low);
    let max = Math.max(...highs, livePrice ?? -Infinity);
    let min = Math.min(...lows, livePrice ?? Infinity);
    const pad = (max - min) * 0.08 || max * 0.01;
    max += pad; min -= pad;
    return { data, max, min };
  }, [candles, livePrice]);

  if (!view) {
    return (
      <div className="flex items-center justify-center text-sm text-slate-500" style={{ height }}>
        טוען נתוני נרות…
      </div>
    );
  }

  const W = 1000;
  const H = 300;
  const { data, max, min } = view;
  const n = data.length;
  const cw = W / n;
  const y = (v: number) => H - ((v - min) / (max - min)) * H;

  const gridLines = [0.2, 0.4, 0.6, 0.8].map((f) => min + (max - min) * f);
  const liveY = livePrice !== undefined ? y(livePrice) : null;
  const lastUp = livePrice !== undefined && data.length > 1 ? livePrice >= data[n - 1].open : true;

  return (
    <div dir="ltr" className="relative w-full select-none">
      <svg viewBox={`0 0 ${W} ${H}`} style={{ height, width: "100%" }} preserveAspectRatio="none">
        {showGrid &&
          gridLines.map((g, i) => (
            <g key={i}>
              <line x1={0} x2={W} y1={y(g)} y2={y(g)} stroke="#1e293b" strokeWidth={1} />
            </g>
          ))}
        {data.map((c, i) => {
          const up = c.close >= c.open;
          const color = up ? "#22c55e" : "#ef4444";
          const x = i * cw + cw / 2;
          const bodyTop = y(Math.max(c.open, c.close));
          const bodyBot = y(Math.min(c.open, c.close));
          return (
            <g key={c.time}>
              <line x1={x} x2={x} y1={y(c.high)} y2={y(c.low)} stroke={color} strokeWidth={Math.max(1, cw * 0.12)} />
              <rect
                x={i * cw + cw * 0.18}
                width={cw * 0.64}
                y={bodyTop}
                height={Math.max(1.5, bodyBot - bodyTop)}
                fill={color}
                rx={1}
              />
            </g>
          );
        })}
        {liveY !== null && (
          <g>
            <line x1={0} x2={W} y1={liveY} y2={liveY} stroke={lastUp ? "#22c55e" : "#ef4444"} strokeWidth={1.2} strokeDasharray="6 4" />
          </g>
        )}
      </svg>
      {livePrice !== undefined && (
        <div
          className={`num absolute right-1 rounded px-1.5 py-0.5 text-[10px] font-bold text-slate-950 ${lastUp ? "bg-emerald-400" : "bg-red-400"}`}
          style={{ top: `${Math.min(95, Math.max(0, ((liveY ?? 0) / H) * 100))}%`, transform: "translateY(-50%)" }}
        >
          {livePrice.toLocaleString("en-US", { maximumFractionDigits: livePrice >= 1000 ? 1 : 3 })}
        </div>
      )}
      {/* grid price labels */}
      <div className="pointer-events-none absolute inset-0">
        {showGrid &&
          gridLines.map((g, i) => (
            <span
              key={i}
              className="num absolute left-1 text-[9px] text-slate-600"
              style={{ top: `${((y(g)) / H) * 100}%`, transform: "translateY(-50%)" }}
            >
              {g.toLocaleString("en-US", { maximumFractionDigits: g >= 1000 ? 0 : 2 })}
            </span>
          ))}
      </div>
    </div>
  );
}
