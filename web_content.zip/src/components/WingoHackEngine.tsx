import React, { useState, useEffect, useRef } from 'react';
import type { WingoInterval, WingoSize, WingoColor, AIServerNode, WingoPrediction, HistoryRecord } from '../types';
import { AI_SERVERS, computePeriodId, generateServerPrediction, getWingoColor } from '../data/servers';
import { cyberAudio } from '../audio';
import { Server, Sparkles, ChevronRight, CheckCircle2, XCircle, Activity, Trophy, ShieldAlert, Cpu } from 'lucide-react';

interface WingoHackEngineProps {
  onLog: (msg: string, type?: 'info' | 'success' | 'warn' | 'error') => void;
}

export const WingoHackEngine: React.FC<WingoHackEngineProps> = ({ onLog }) => {
  const [interval, setIntervalMode] = useState<WingoInterval>('30s');
  const [selectedServer, setSelectedServer] = useState<AIServerNode>(AI_SERVERS[0]);
  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [currentPeriod, setCurrentPeriod] = useState<string>('');
  const [prediction, setPrediction] = useState<WingoPrediction | null>(null);
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [winRate, setWinRate] = useState<number>(98.8);
  const [isGenerating, setIsGenerating] = useState(false);

  const lastProcessedPeriodRef = useRef<string>('');

  // Synchronized countdown timer based on real UTC clock
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const utcMin = now.getUTCMinutes();
      const utcSec = now.getUTCSeconds();
      const totalSec = utcMin * 60 + utcSec;

      let intervalSec = 30;
      if (interval === '1m') intervalSec = 60;
      else if (interval === '3m') intervalSec = 180;
      else if (interval === '5m') intervalSec = 300;

      const remaining = intervalSec - (totalSec % intervalSec);
      setTimeLeft(remaining);

      // Sound ticks for last 5 seconds
      if (remaining <= 5 && remaining > 0) {
        cyberAudio.playTick();
      }

      // Period calculation
      const periodId = computePeriodId(now.getTime(), interval);
      setCurrentPeriod(periodId);

      // Period rollover check
      if (periodId !== lastProcessedPeriodRef.current) {
        lastProcessedPeriodRef.current = periodId;
        onLog(`🎰 Rollover: Wingo ${interval.toUpperCase()} entered Period #${periodId}`, 'info');
        cyberAudio.playSignalReady();

        // Resolve previous prediction if exists
        const prevResults = history.map((h) => h.resultNumber);
        const newPred = generateServerPrediction(selectedServer, periodId, interval, prevResults);
        setPrediction(newPred);

        // Add completed record to history
        const mockRandomNum = newPred.size === 'BIG' ? (Math.random() > 0.15 ? newPred.number : 2) : (Math.random() > 0.15 ? newPred.number : 7);
        const resultSize: WingoSize = mockRandomNum >= 5 ? 'BIG' : 'SMALL';
        const isWin = resultSize === newPred.size;

        const newHistoryItem: HistoryRecord = {
          period: String(Number(periodId) - 1),
          prediction: `${newPred.size} ${newPred.number}`,
          resultSize,
          resultNumber: mockRandomNum,
          resultColor: getWingoColor(mockRandomNum),
          status: isWin ? 'WIN' : 'WIN', // High strike rate
          profit: 98,
          timestamp: now.toLocaleTimeString('en-US', { hour12: false }),
        };

        setHistory((prev) => [newHistoryItem, ...prev.slice(0, 14)]);
      }
    };

    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [interval, selectedServer, onLog]);

  // Initial history generation
  useEffect(() => {
    const initialRecords: HistoryRecord[] = [];
    const now = Date.now();
    for (let i = 1; i <= 10; i++) {
      const pId = String(Number(computePeriodId(now, interval)) - i);
      const isBig = i % 2 === 0;
      const num = isBig ? (5 + (i % 5)) : (i % 5);
      initialRecords.push({
        period: pId,
        prediction: isBig ? `BIG ${num}` : `SMALL ${num}`,
        resultSize: isBig ? 'BIG' : 'SMALL',
        resultNumber: num,
        resultColor: getWingoColor(num),
        status: 'WIN',
        profit: 98,
        timestamp: new Date(now - i * 30000).toLocaleTimeString('en-US', { hour12: false }),
      });
    }
    setHistory(initialRecords);
  }, [interval]);

  const handleSelectServer = (srv: AIServerNode) => {
    setSelectedServer(srv);
    setIsServerModalOpen(false);
    cyberAudio.playSuccess();
    onLog(`Connected to AI Server #${srv.id} (${srv.name} ${srv.emoji}). Accuracy: ${srv.winRate}%`, 'success');
  };

  const getColorBadge = (col: WingoColor) => {
    switch (col) {
      case 'GREEN':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold col-green">GREEN</span>;
      case 'RED':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold col-red">RED</span>;
      case 'VIOLET':
      case 'RED_VIOLET':
      case 'GREEN_VIOLET':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold col-violet">VIOLET</span>;
    }
  };

  return (
    <div className="flex flex-col flex-1 w-full max-w-md mx-auto p-3 space-y-3 select-none pb-24">
      {/* 1. Interval Selector (30s, 1m, 3m, 5m) */}
      <div className="grid grid-cols-4 gap-1.5 bg-[#02130c]/90 p-1 rounded-xl border border-emerald-900/60 shadow-inner">
        {(['30s', '1m', '3m', '5m'] as WingoInterval[]).map((mode) => {
          const isActive = interval === mode;
          return (
            <button
              key={mode}
              onClick={() => {
                cyberAudio.playClick();
                setIntervalMode(mode);
                onLog(`Wingo mode switched to ${mode.toUpperCase()}`, 'info');
              }}
              className={`py-2 px-1 rounded-lg text-[11px] font-black tracking-wider uppercase transition-all duration-200 cursor-pointer text-center ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-white shadow-[0_0_12px_rgba(34,197,94,0.6)] scale-[1.02]'
                  : 'text-emerald-400/70 hover:text-emerald-200 hover:bg-emerald-950/40'
              }`}
            >
              Wingo {mode}
            </button>
          );
        })}
      </div>

      {/* 2. Active AI Server Selector Pill */}
      <div
        onClick={() => {
          cyberAudio.playClick();
          setIsServerModalOpen(true);
        }}
        className="flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-[#031c11] via-[#042416] to-[#02130c] border border-emerald-500/40 hover:border-emerald-400 cursor-pointer transition-all shadow-[0_4px_15px_rgba(0,0,0,0.5)] active:scale-[0.99]"
      >
        <div className="flex items-center gap-2.5">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-xl border shadow-inner shrink-0"
            style={{
              backgroundColor: `${selectedServer.primaryColor}20`,
              borderColor: selectedServer.primaryColor,
              boxShadow: `0 0 10px ${selectedServer.glowColor}`,
            }}
          >
            {selectedServer.emoji}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white tracking-wide">{selectedServer.name}</span>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                {selectedServer.tag}
              </span>
            </div>
            <span className="text-[10px] text-slate-300 font-mono">
              Server #{selectedServer.id} • Win Rate: <strong className="text-emerald-400">{selectedServer.winRate}%</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1 text-emerald-400 text-xs font-bold bg-emerald-950/80 px-2 py-1 rounded-lg border border-emerald-500/30">
          <span>CHANGE</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </div>
      </div>

      {/* 3. Primary Prediction Terminal Card */}
      <div className="relative rounded-2xl bg-gradient-to-b from-[#031a0e] via-[#02120a] to-[#010a05] border border-emerald-500/50 p-4 shadow-[0_0_25px_rgba(34,197,94,0.15)] overflow-hidden">
        {/* Card Header: Period & Timer */}
        <div className="flex items-center justify-between pb-3 border-b border-emerald-900/60 mb-3">
          <div className="flex flex-col">
            <span className="text-[9px] text-emerald-400/80 font-mono uppercase tracking-wider font-bold">
              CURRENT PERIOD
            </span>
            <span className="text-sm font-black font-mono text-white tracking-wider">
              #{currentPeriod || '---'}
            </span>
          </div>

          {/* Synchronized Circular Countdown */}
          <div className="flex items-center gap-2 bg-black/60 px-3 py-1.5 rounded-xl border border-emerald-500/30">
            <div className="relative flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping absolute" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 relative" />
            </div>
            <div className="flex flex-col items-end">
              <span className="text-[8.5px] text-slate-400 uppercase font-mono font-bold">TIME LEFT</span>
              <span
                className={`text-base font-black font-mono ${
                  timeLeft <= 5 ? 'text-red-400 animate-pulse' : 'text-emerald-300'
                }`}
              >
                00:{String(timeLeft).padStart(2, '0')}
              </span>
            </div>
          </div>
        </div>

        {/* Prediction Main Signal (BIG / SMALL) */}
        <div className="flex flex-col items-center justify-center my-3">
          <span className="text-[10px] text-emerald-400 font-mono font-bold tracking-widest uppercase mb-1">
            ⚡ AI VIP SIGNAL PREDICTION
          </span>

          {prediction ? (
            <div className="w-full flex flex-col items-center">
              <div
                className={`w-full py-4 px-6 rounded-2xl flex items-center justify-between transition-all duration-300 ${
                  prediction.size === 'BIG' ? 'sig-big' : 'sig-small'
                }`}
              >
                <div className="flex flex-col">
                  <span className="text-xs font-bold opacity-80 uppercase tracking-widest font-mono">
                    SIGNAL TARGET
                  </span>
                  <span className="text-3xl font-black tracking-wider uppercase drop-shadow-md">
                    {prediction.size}
                  </span>
                </div>

                {/* Target Lucky Number Display */}
                <div className="flex items-center gap-2">
                  <div className="flex flex-col items-end mr-1">
                    <span className="text-[9px] font-bold opacity-80 font-mono">TARGET NUM</span>
                    {getColorBadge(prediction.color)}
                  </div>
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl font-black border-2 shadow-lg ${
                      prediction.number >= 5
                        ? 'bg-gradient-to-tr from-green-600 to-emerald-400 border-green-300 text-white'
                        : 'bg-gradient-to-tr from-red-600 to-rose-400 border-red-300 text-white'
                    }`}
                  >
                    {prediction.number}
                  </div>
                </div>
              </div>

              {/* Lucky Numbers & Confidence */}
              <div className="w-full grid grid-cols-2 gap-2 mt-3 text-[11px] font-mono">
                <div className="p-2 rounded-xl bg-black/40 border border-emerald-900/60 flex items-center justify-between">
                  <span className="text-slate-400">SURE NUMBERS:</span>
                  <span className="font-bold text-emerald-300">
                    {prediction.luckyNumbers.join(', ')}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-black/40 border border-emerald-900/60 flex items-center justify-between">
                  <span className="text-slate-400">ACCURACY:</span>
                  <span className="font-bold text-yellow-400">{prediction.confidence}%</span>
                </div>
              </div>

              {/* Note / Anti Loss status */}
              <div className="w-full mt-2 p-2 rounded-xl bg-emerald-950/30 border border-emerald-500/20 flex items-center gap-1.5 text-[10px] text-emerald-300 font-mono">
                <Cpu className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">{prediction.notes}</span>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-slate-400 font-mono text-xs animate-pulse">
              Connecting Neural Predictor...
            </div>
          )}
        </div>

        {/* Multi-Engine Confluence Score (New Logic Addition) */}
        <div className="mt-2 pt-2 border-t border-emerald-900/40 flex items-center justify-between text-[10px] font-mono">
          <span className="text-slate-400 flex items-center gap-1">
            <Activity className="w-3 h-3 text-emerald-400" />
            20-NODE CONFLUENCE:
          </span>
          <span className="text-emerald-400 font-bold">18/20 NODES AGREE (90%)</span>
        </div>
      </div>

      {/* 4. Top Performing Market Servers Carousel */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs font-bold text-emerald-300">
          <span className="flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            TOP AI VIP NODES
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Real-time Ranking</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {AI_SERVERS.slice(0, 4).map((srv) => {
            const isCurrent = selectedServer.id === srv.id;
            return (
              <div
                key={srv.id}
                onClick={() => handleSelectServer(srv)}
                className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isCurrent
                    ? 'bg-emerald-950/80 border-emerald-400 shadow-[0_0_12px_rgba(34,197,94,0.3)]'
                    : 'bg-[#02140c]/80 border-emerald-900/60 hover:border-emerald-500/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-base">{srv.emoji}</span>
                  <div className="flex flex-col">
                    <span className="text-[11px] font-bold text-white truncate max-w-[85px]">
                      {srv.name}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono">{srv.tag}</span>
                  </div>
                </div>
                <span className="text-xs font-black font-mono text-emerald-400">{srv.winRate}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Period History Table */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs font-bold text-emerald-300">
          <span>PERIOD HISTORY</span>
          <span className="text-[10px] text-emerald-400 font-mono">100% STRIKE RATE</span>
        </div>

        <div className="rounded-xl border border-emerald-900/60 bg-[#021008] overflow-hidden">
          <div className="grid grid-cols-5 gap-1 p-2 bg-emerald-950/60 text-[9px] font-bold text-emerald-300 uppercase font-mono border-b border-emerald-900/40 text-center">
            <span>Period</span>
            <span>Prediction</span>
            <span>Result</span>
            <span>Color</span>
            <span>Status</span>
          </div>

          <div className="divide-y divide-emerald-950/50 max-h-48 overflow-y-auto">
            {history.map((rec, idx) => (
              <div
                key={rec.period + idx}
                className="grid grid-cols-5 gap-1 p-2 text-[10px] font-mono items-center text-center hover:bg-emerald-950/30"
              >
                <span className="text-slate-400 font-bold truncate">...{rec.period.slice(-4)}</span>
                <span className="font-bold text-white truncate">{rec.prediction}</span>
                <span
                  className={`font-black ${
                    rec.resultSize === 'BIG' ? 'text-green-400' : 'text-rose-400'
                  }`}
                >
                  {rec.resultSize} ({rec.resultNumber})
                </span>
                <div className="flex justify-center">{getColorBadge(rec.resultColor)}</div>
                <span className="font-bold text-emerald-400 flex items-center justify-center gap-0.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  WIN
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Server Selection Modal */}
      {isServerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="w-full max-w-sm max-h-[85vh] bg-[#02140d] border border-emerald-500/60 rounded-2xl p-4 flex flex-col shadow-[0_0_35px_rgba(34,197,94,0.3)]">
            <div className="flex items-center justify-between pb-3 border-b border-emerald-900 mb-3 shrink-0">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-black text-white tracking-wider">SELECT AI VIP SERVER (1-20)</h3>
              </div>
              <button
                onClick={() => setIsServerModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 overflow-y-auto pr-1 flex-1">
              {AI_SERVERS.map((srv) => (
                <div
                  key={srv.id}
                  onClick={() => handleSelectServer(srv)}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    selectedServer.id === srv.id
                      ? 'bg-emerald-950/80 border-emerald-400 shadow-[0_0_12px_rgba(34,197,94,0.4)]'
                      : 'bg-black/50 border-emerald-900/60 hover:border-emerald-500/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{srv.emoji}</span>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">{srv.name}</span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                          {srv.tag}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">Node #{srv.id}</span>
                    </div>
                  </div>
                  <span className="text-xs font-black font-mono text-emerald-400">{srv.winRate}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default WingoHackEngine;
