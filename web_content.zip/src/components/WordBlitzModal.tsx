import React, { useState, useEffect } from 'react';
import { Zap, X, Trophy, RefreshCw, CheckCircle2 } from 'lucide-react';
import { WordData } from '../types';
import { sound } from '../services/sound';

interface WordBlitzModalProps {
  words: WordData[];
  onClose: () => void;
  onAddXp: (amount: number) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
}

interface TileItem {
  id: string;
  type: 'word' | 'meaning';
  text: string;
  wordKey: string;
  matched: boolean;
}

export const WordBlitzModal: React.FC<WordBlitzModalProps> = ({
  words,
  onClose,
  onAddXp,
  onSetStatus,
}) => {
  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [pairsSolved, setPairsSolved] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);

  const [selectedWordTile, setSelectedWordTile] = useState<TileItem | null>(null);
  const [selectedMeaningTile, setSelectedMeaningTile] = useState<TileItem | null>(null);
  const [wrongPairIds, setWrongPairIds] = useState<string[]>([]);

  const [wordTiles, setWordTiles] = useState<TileItem[]>([]);
  const [meaningTiles, setMeaningTiles] = useState<TileItem[]>([]);

  // Spawn a wave of 5 pairs
  const spawnWave = () => {
    const pool = [...words].sort(() => 0.5 - Math.random()).slice(0, 5);

    const wTiles: TileItem[] = pool.map((w, i) => ({
      id: `w_${w.word}_${i}`,
      type: 'word' as const,
      text: w.word,
      wordKey: w.word.toLowerCase(),
      matched: false,
    })).sort(() => 0.5 - Math.random());

    const mTiles: TileItem[] = pool.map((w, i) => ({
      id: `m_${w.word}_${i}`,
      type: 'meaning' as const,
      text: w.bengali ? w.bengali.split('(')[0].trim() : w.simpleDef,
      wordKey: w.word.toLowerCase(),
      matched: false,
    })).sort(() => 0.5 - Math.random());

    setWordTiles(wTiles);
    setMeaningTiles(mTiles);
    setSelectedWordTile(null);
    setSelectedMeaningTile(null);
  };

  useEffect(() => {
    spawnWave();
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsGameOver(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Handle tile selection
  const handleSelectTile = (tile: TileItem) => {
    if (tile.matched || isGameOver) return;
    sound.flip();

    if (tile.type === 'word') {
      setSelectedWordTile(tile);
      if (selectedMeaningTile) {
        checkMatch(tile, selectedMeaningTile);
      }
    } else {
      setSelectedMeaningTile(tile);
      if (selectedWordTile) {
        checkMatch(selectedWordTile, tile);
      }
    }
  };

  const checkMatch = (wTile: TileItem, mTile: TileItem) => {
    if (wTile.wordKey === mTile.wordKey) {
      // Correct Match!
      sound.correct();
      sound.triggerFloatingXp(10 * combo);
      onAddXp(10 * combo);
      onSetStatus(wTile.text, 'mastered');

      setWordTiles((prev) =>
        prev.map((t) => (t.id === wTile.id ? { ...t, matched: true } : t))
      );
      setMeaningTiles((prev) =>
        prev.map((t) => (t.id === mTile.id ? { ...t, matched: true } : t))
      );

      setSelectedWordTile(null);
      setSelectedMeaningTile(null);
      setScore((s) => s + 20 * combo);
      setCombo((c) => Math.min(4, c + 1));
      setPairsSolved((p) => p + 1);

      // Add extra 2 seconds for quick matches!
      setTimeLeft((t) => Math.min(45, t + 2));

      // Check if all 5 in this wave are matched
      const remainingUnmatched = wordTiles.filter(
        (t) => t.id !== wTile.id && !t.matched
      );
      if (remainingUnmatched.length === 0) {
        sound.triggerCelebration(40, 30);
        setTimeout(() => {
          spawnWave();
        }, 300);
      }
    } else {
      // Mismatch
      sound.wrong();
      setCombo(1);
      setWrongPairIds([wTile.id, mTile.id]);
      setTimeout(() => {
        setWrongPairIds([]);
        setSelectedWordTile(null);
        setSelectedMeaningTile(null);
      }, 500);
    }
  };

  const timerPercent = (timeLeft / 30) * 100;

  return (
    <div className="fixed inset-0 z-50 bg-[#070b14]/90 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in">
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 max-w-md w-full rounded-3xl p-5 shadow-2xl space-y-4">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center font-black">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white">Word Blitz Speed Match</h3>
              <p className="text-[10px] text-slate-400 font-medium">Match English with Bengali Meanings</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress & Combo Bar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold font-mono">
            <span className="text-amber-500 flex items-center gap-1">
              Time: {timeLeft}s
            </span>
            <span className="text-emerald-500 font-black">
              Combo: {combo}x {combo > 1 && '🔥'}
            </span>
            <span className="text-blue-500 font-black">
              Score: {score}
            </span>
          </div>

          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                timeLeft > 10 ? 'bg-emerald-500' : 'bg-rose-500 animate-pulse'
              }`}
              style={{ width: `${Math.min(100, timerPercent)}%` }}
            />
          </div>
        </div>

        {!isGameOver ? (
          /* Match Grid: 2 Columns (Words on left, Meanings on right) */
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            {/* Column 1: English Words */}
            <div className="space-y-2">
              <div className="text-[10px] uppercase font-bold text-slate-400 text-center">
                English Word
              </div>
              {wordTiles.map((tile) => {
                const isSelected = selectedWordTile?.id === tile.id;
                const isWrong = wrongPairIds.includes(tile.id);

                if (tile.matched) {
                  return (
                    <div
                      key={tile.id}
                      className="h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-500/40 text-emerald-600 dark:text-emerald-400 font-black text-xs flex items-center justify-center opacity-40 scale-95 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" /> Matched
                    </div>
                  );
                }

                return (
                  <button
                    key={tile.id}
                    onClick={() => handleSelectTile(tile)}
                    className={`w-full h-14 rounded-2xl font-black text-xs sm:text-sm p-2 flex items-center justify-center text-center shadow-sm active:scale-95 transition-all border-2 ${
                      isWrong
                        ? 'bg-rose-600 text-white border-rose-600 animate-shake'
                        : isSelected
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md scale-[1.02]'
                        : 'bg-white dark:bg-[#111827] border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white hover:border-indigo-400'
                    }`}
                  >
                    {tile.text}
                  </button>
                );
              })}
            </div>

            {/* Column 2: Bengali Meanings */}
            <div className="space-y-2">
              <div className="text-[10px] uppercase font-bold text-slate-400 text-center">
                বাংলা অর্থ (Meaning)
              </div>
              {meaningTiles.map((tile) => {
                const isSelected = selectedMeaningTile?.id === tile.id;
                const isWrong = wrongPairIds.includes(tile.id);

                if (tile.matched) {
                  return (
                    <div
                      key={tile.id}
                      className="h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-500/40 text-emerald-600 dark:text-emerald-400 font-bold text-xs flex items-center justify-center opacity-40 scale-95 transition-all font-bengali"
                    >
                      ✓ সঠিক
                    </div>
                  );
                }

                return (
                  <button
                    key={tile.id}
                    onClick={() => handleSelectTile(tile)}
                    className={`w-full h-14 rounded-2xl font-bold font-bengali text-xs sm:text-sm p-2 flex items-center justify-center text-center shadow-sm active:scale-95 transition-all border-2 leading-tight ${
                      isWrong
                        ? 'bg-rose-600 text-white border-rose-600 animate-shake'
                        : isSelected
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md scale-[1.02]'
                        : 'bg-white dark:bg-[#111827] border-slate-200 dark:border-slate-700 text-emerald-900 dark:text-emerald-300 hover:border-indigo-400'
                    }`}
                  >
                    {tile.text}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Game Over / Summary View */
          <div className="text-center space-y-4 py-4 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-orange-500 text-slate-950 flex items-center justify-center font-black text-3xl mx-auto shadow-md">
              <Trophy className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-black text-slate-900 dark:text-white">Blitz Challenge Concluded!</h3>
              <p className="text-xs text-slate-400 font-bengali mt-0.5">
                দারুণ গতি! আপনি সফলভাবে {pairsSolved}টি শব্দগুচ্ছ নির্ভুলভাবে ম্যাচ করেছেন।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800">
                <div className="font-mono text-xl font-black text-emerald-600 dark:text-emerald-400">{pairsSolved}</div>
                <div className="text-[10px] text-slate-400 font-bold">Pairs Matched</div>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800">
                <div className="font-mono text-xl font-black text-amber-500">+{score} XP</div>
                <div className="text-[10px] text-slate-400 font-bold">Points Earned</div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => {
                  setTimeLeft(30);
                  setScore(0);
                  setCombo(1);
                  setPairsSolved(0);
                  setIsGameOver(false);
                  spawnWave();
                }}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-2xl shadow-md flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-4 h-4" /> Play Again
              </button>

              <button
                onClick={onClose}
                className="px-4 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-2xl"
              >
                Done
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
