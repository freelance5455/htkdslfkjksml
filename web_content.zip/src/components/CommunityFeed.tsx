import React, { useState, useEffect } from 'react';
import { UserProfile, UserPost, PostComment } from '../types';
import { db } from '../firebase';
import {
  collection,
  doc,
  addDoc,
  setDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  getDocs
} from 'firebase/firestore';
import { VipName } from './VipName';
import { fileToBase64, formatTime } from '../utils/helpers';
import { playAppSound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Heart,
  MessageCircle,
  Share2,
  Image as ImageIcon,
  Send,
  Sparkles,
  X,
  MessageSquare,
  Clock,
  ThumbsUp
} from 'lucide-react';

interface CommunityFeedProps {
  currentUser: UserProfile;
  allUsersMap: Record<string, UserProfile>;
  onToast: (msg: string) => void;
  onOpenDirectChat?: (user: UserProfile) => void;
}

export const CommunityFeed: React.FC<CommunityFeedProps> = ({
  currentUser,
  allUsersMap,
  onToast,
  onOpenDirectChat
}) => {
  const [posts, setPosts] = useState<UserPost[]>([]);
  const [loading, setLoading] = useState(true);

  // New post composer
  const [postText, setPostText] = useState('');
  const [postImage, setPostImage] = useState<string | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);

  // Active comments drawer
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [commentsMap, setCommentsMap] = useState<Record<string, PostComment[]>>({});
  const [newCommentText, setNewCommentText] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);

  // Subscribe to public posts in real-time
  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: UserPost[] = [];
        snapshot.forEach((d) => {
          list.push({ ...(d.data() as UserPost), id: d.id });
        });
        setPosts(list);
        setLoading(false);
      },
      (err) => {
        console.error('Posts snapshot error:', err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Subscribe to comments for the currently opened post
  useEffect(() => {
    if (!activePostId) return;

    const commentsRef = collection(db, 'posts', activePostId, 'comments');
    const q = query(commentsRef, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const comms: PostComment[] = [];
        snapshot.forEach((d) => {
          comms.push({ ...(d.data() as PostComment), id: d.id });
        });
        setCommentsMap((prev) => ({ ...prev, [activePostId]: comms }));
      },
      (err) => {
        console.error('Comments snapshot error:', err);
      }
    );

    return () => unsubscribe();
  }, [activePostId]);

  // Handle Image Upload for new post
  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const base64 = await fileToBase64(file);
      setPostImage(base64);
      playAppSound('click');
    } catch {
      onToast('تعذر معالجة الصورة');
    }
  };

  // Publish new Post
  const handlePublishPost = async () => {
    const content = postText.trim();
    if (!content && !postImage) {
      onToast('يرجى كتابة نص أو إرفاق صورة للمنشور');
      return;
    }

    setIsPublishing(true);
    try {
      const newPost: Omit<UserPost, 'id'> = {
        authorId: currentUser.id,
        authorName: currentUser.name,
        authorVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
        authorAvatar: currentUser.avatar || '',
        content,
        imageUrl: postImage || undefined,
        createdAt: serverTimestamp(),
        likes: [],
        commentsCount: 0
      };

      await addDoc(collection(db, 'posts'), newPost);

      setPostText('');
      setPostImage(null);
      playAppSound('send');
      try {
        confetti({ particleCount: 80, spread: 60 });
      } catch {}
      onToast('تم نشر منشورك بنجاح في مجتمع عالم عاصف! 🌟');
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء نشر المنشور');
    } finally {
      setIsPublishing(false);
    }
  };

  // Toggle Like on Post
  const handleToggleLike = async (post: UserPost) => {
    playAppSound('click');
    const currentLikes = post.likes || [];
    const isLiked = currentLikes.includes(currentUser.id);
    const updatedLikes = isLiked
      ? currentLikes.filter((id) => id !== currentUser.id)
      : [...currentLikes, currentUser.id];

    // Optimistic update
    setPosts((prev) =>
      prev.map((p) => (p.id === post.id ? { ...p, likes: updatedLikes } : p))
    );

    try {
      await setDoc(doc(db, 'posts', post.id), { likes: updatedLikes }, { merge: true });
    } catch (err) {
      console.error(err);
    }
  };

  // Add Comment on Post
  const handleAddComment = async (postId: string) => {
    const text = newCommentText.trim();
    if (!text) return;

    setIsSubmittingComment(true);
    try {
      const commentDoc: Omit<PostComment, 'id'> = {
        userId: currentUser.id,
        userName: currentUser.name,
        userVip: currentUser.vipLevel || (currentUser.id === 'ASEF-777777' ? 20 : 0),
        userAvatar: currentUser.avatar || '',
        text,
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'posts', postId, 'comments'), commentDoc);

      const targetPost = posts.find((p) => p.id === postId);
      const nextCount = (targetPost?.commentsCount || 0) + 1;
      await setDoc(doc(db, 'posts', postId), { commentsCount: nextCount }, { merge: true });

      setNewCommentText('');
      playAppSound('send');
      onToast('تم إضافة تعليقك بنجاح 💬');
    } catch (err) {
      console.error(err);
      onToast('تعذر إرسال التعليق');
    } finally {
      setIsSubmittingComment(false);
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* 1. Header Banner */}
      <div className="flex items-center justify-between">
        <h2 className="text-base font-extrabold text-[#25d366] flex items-center gap-1.5">
          <Sparkles className="w-5 h-5 text-[#ffd700]" />
          <span>منشورات مجتمع عالم عاصف الملكي</span>
        </h2>
        <span className="text-[11px] bg-white/10 text-gray-300 px-2.5 py-1 rounded-full border border-white/5 font-semibold">
          عام للجميع 🌍
        </span>
      </div>

      {/* 2. New Post Composer */}
      <div className="glass-panel rounded-3xl p-4 border border-white/10 shadow-xl space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-sm shrink-0 overflow-hidden border border-white/10">
            {currentUser.avatar ? (
              <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
            ) : (
              (currentUser.name[0] || 'A').toUpperCase()
            )}
          </div>
          <div className="min-w-0 flex-1">
            <VipName
              name={currentUser.name}
              vipLevel={currentUser.vipLevel}
              isFounder={currentUser.id === 'ASEF-777777'}
              className="text-xs font-black"
            />
            <span className="text-[10px] text-gray-400 block">انشر فكرة أو صورة ليراها الجميع ويعلقوا عليها</span>
          </div>
        </div>

        <textarea
          rows={3}
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          placeholder="ماذا يدور في ذهنك اليوم يا صاحب السمو؟ شارك أعضاء عالم عاصف..."
          className="w-full glass-input rounded-2xl px-3.5 py-2.5 text-xs text-white placeholder-gray-400 outline-none focus:border-[#25d366] resize-none"
        />

        {/* Selected image preview */}
        {postImage && (
          <div className="relative rounded-2xl overflow-hidden border border-white/10 max-h-56">
            <img src={postImage} alt="معاينة" className="w-full h-full object-cover" />
            <button
              onClick={() => setPostImage(null)}
              className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 text-white hover:bg-black transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex items-center justify-between pt-1 border-t border-white/5">
          <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition cursor-pointer">
            <ImageIcon className="w-4 h-4 text-[#25d366]" />
            <span>إضافة صورة</span>
            <input type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
          </label>

          <button
            onClick={handlePublishPost}
            disabled={isPublishing || (!postText.trim() && !postImage)}
            className={`px-5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition shadow-lg ${
              postText.trim() || postImage
                ? 'bg-gradient-to-r from-[#25d366] to-[#00a884] text-black active:scale-95 shadow-[#25d366]/25 cursor-pointer'
                : 'bg-white/10 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isPublishing ? 'جارِ النشر...' : 'نشر المنشور 🚀'}</span>
          </button>
        </div>
      </div>

      {/* 3. Feed List */}
      <div className="space-y-3.5">
        {loading ? (
          <div className="text-center py-12 text-gray-400 text-xs">جارِ تحميل منشورات المجتمع...</div>
        ) : posts.length === 0 ? (
          <div className="glass-panel rounded-3xl p-8 text-center text-gray-400 space-y-2 border border-white/5">
            <div className="text-3xl">✨</div>
            <h4 className="text-sm font-bold text-white">لا توجد منشورات بعد</h4>
            <p className="text-xs">كن أول من ينشر في مجتمع عالم عاصف الملكي وشارك أفكارك مع الجميع!</p>
          </div>
        ) : (
          posts.map((post) => {
            const author = allUsersMap[post.authorId];
            const isLiked = (post.likes || []).includes(currentUser.id);
            const isMyPost = post.authorId === currentUser.id;
            const comments = commentsMap[post.id] || [];
            const isCommentsOpen = activePostId === post.id;

            return (
              <div
                key={post.id}
                className="glass-panel rounded-3xl p-4 border border-white/10 shadow-lg space-y-3 transition hover:border-white/20"
              >
                {/* Author row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      onClick={() => author && onOpenDirectChat && onOpenDirectChat(author)}
                      className="w-10 h-10 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs shrink-0 overflow-hidden relative border border-white/10 cursor-pointer"
                      title="مراسلة الكاتب"
                    >
                      {author?.avatar || post.authorAvatar ? (
                        <img
                          src={author?.avatar || post.authorAvatar}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        (post.authorName[0] || 'A').toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0">
                      <VipName
                        name={post.authorName}
                        vipLevel={author?.vipLevel ?? post.authorVip}
                        isFounder={post.authorId === 'ASEF-777777'}
                        className="text-xs font-black"
                      />
                      <div className="text-[10px] text-gray-400 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-gray-500" />
                        <span>{formatTime(post.createdAt)}</span>
                        {isMyPost && <span className="text-[#25d366] font-bold mr-1">(أنت)</span>}
                      </div>
                    </div>
                  </div>

                  {!isMyPost && author && onOpenDirectChat && (
                    <button
                      onClick={() => onOpenDirectChat(author)}
                      className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/15 text-xs text-[#25d366] font-bold transition cursor-pointer"
                    >
                      مراسلة 💬
                    </button>
                  )}
                </div>

                {/* Content text */}
                {post.content && (
                  <p className="text-xs sm:text-sm text-gray-100 whitespace-pre-wrap leading-relaxed selectable-text">
                    {post.content}
                  </p>
                )}

                {/* Content image */}
                {post.imageUrl && (
                  <div className="rounded-2xl overflow-hidden border border-white/10 max-h-96">
                    <img
                      src={post.imageUrl}
                      alt="صورة المنشور"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Actions: Likes, Comments, Share */}
                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                  {/* Like Button */}
                  <button
                    onClick={() => handleToggleLike(post)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer ${
                      isLiked
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30 font-bold'
                        : 'bg-white/5 hover:bg-white/10 text-gray-300'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-400 text-red-400' : ''}`} />
                    <span>{post.likes?.length || 0}</span>
                    <span className="hidden xs:inline">إعجاب</span>
                  </button>

                  {/* Comments Toggle */}
                  <button
                    onClick={() => {
                      playAppSound('click');
                      setActivePostId(isCommentsOpen ? null : post.id);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer ${
                      isCommentsOpen
                        ? 'bg-[#25d366]/20 text-[#25d366] border border-[#25d366]/30 font-bold'
                        : 'bg-white/5 hover:bg-white/10 text-gray-300'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.commentsCount || comments.length || 0}</span>
                    <span className="hidden xs:inline">تعليقات</span>
                  </button>

                  {/* Share button */}
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(post.content || 'منشور في عالم عاصف');
                      playAppSound('click');
                      onToast('تم نسخ نص المنشور 📋');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                    <span className="hidden xs:inline">مشاركة</span>
                  </button>
                </div>

                {/* Comments Section Drawer */}
                {isCommentsOpen && (
                  <div className="pt-3 border-t border-white/10 space-y-2.5 animate-in fade-in duration-200">
                    <h5 className="text-[11px] font-bold text-gray-300 flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5 text-[#25d366]" />
                      <span>التعليقات ({comments.length})</span>
                    </h5>

                    {/* Add comment input */}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="اكتب تعليقك..."
                        value={newCommentText}
                        onChange={(e) => setNewCommentText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddComment(post.id);
                          }
                        }}
                        className="flex-1 glass-input rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#25d366]"
                      />
                      <button
                        onClick={() => handleAddComment(post.id)}
                        disabled={isSubmittingComment || !newCommentText.trim()}
                        className="px-3.5 py-2 rounded-xl bg-[#25d366] hover:bg-[#20ba59] text-black font-extrabold text-xs transition cursor-pointer shrink-0 disabled:opacity-50"
                      >
                        إرسال
                      </button>
                    </div>

                    {/* Comments list */}
                    {comments.length === 0 ? (
                      <div className="text-center py-3 text-gray-400 text-[11px]">
                        لا توجد تعليقات بعد. كن أول المعلقين!
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                        {comments.map((cm) => (
                          <div
                            key={cm.id}
                            className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1"
                          >
                            <div className="flex items-center justify-between">
                              <VipName
                                name={cm.userName}
                                vipLevel={cm.userVip}
                                isFounder={cm.userId === 'ASEF-777777'}
                                className="text-[11px] font-bold"
                              />
                              <span className="text-[9px] text-gray-500">
                                {formatTime(cm.createdAt)}
                              </span>
                            </div>
                            <p className="text-xs text-gray-200 selectable-text">{cm.text}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
