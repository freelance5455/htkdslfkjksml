import React, { useState } from 'react';
import { 
  MessageSquare, 
  Heart, 
  Share2, 
  Bookmark, 
  Send, 
  PlusCircle, 
  BarChart2, 
  Sparkles, 
  Pin, 
  ShieldCheck, 
  Hash, 
  TrendingUp, 
  Search,
  CheckCircle2
} from 'lucide-react';
import { Post, Language, User } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface CommunityFeedProps {
  posts: Post[];
  language: Language;
  currentUser: User;
  onPostCreated: (newPost: Post) => void;
  onLikePost: (postId: string) => void;
  onVotePoll: (postId: string, optionId: string) => void;
}

export const CommunityFeed: React.FC<CommunityFeedProps> = ({
  posts,
  language,
  currentUser,
  onPostCreated,
  onLikePost,
  onVotePoll
}) => {
  const t = TRANSLATIONS[language];

  const [postContent, setPostContent] = useState('');
  const [showPollComposer, setShowPollComposer] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState(['', '']);
  const [activeTab, setActiveTab] = useState<'ALL' | 'ANNOUNCEMENTS' | 'POLLS'>('ALL');
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [postComments, setPostComments] = useState<Record<string, any[]>>({
    post_1: [
      { id: 'c1', authorName: 'Dilani Bandara', content: 'Thank you Sir for the A/L Physics tips!', time: '2 hours ago' },
      { id: 'c2', authorName: 'Sahan Wickrama', content: 'Is the marking scheme available in English medium as well?', time: '1 hour ago' }
    ]
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postContent.trim()) return;

    let pollData = undefined;
    if (showPollComposer && pollQuestion && pollOptions.filter((o) => o.trim()).length >= 2) {
      pollData = {
        question: pollQuestion,
        options: pollOptions
          .filter((o) => o.trim())
          .map((text, idx) => ({
            id: `opt_${Date.now()}_${idx}`,
            text,
            votes: 0,
            votedUserIds: []
          }))
      };
    }

    const newPost: Post = {
      id: `post_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorRole: currentUser.role,
      content: postContent,
      createdAt: new Date().toISOString(),
      likesCount: 0,
      likedUserIds: [],
      commentsCount: 0,
      hashtags: postContent.match(/#[a-zA-Z0-9_]+/g) || [],
      poll: pollData,
      isAnnouncement: currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN'
    };

    onPostCreated(newPost);
    setPostContent('');
    setPollQuestion('');
    setPollOptions(['', '']);
    setShowPollComposer(false);
  };

  const handleAddComment = (postId: string) => {
    const text = commentInputs[postId];
    if (!text?.trim()) return;

    const newComment = {
      id: `c_${Date.now()}`,
      authorName: currentUser.name,
      content: text,
      time: 'Just now'
    };

    setPostComments((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment]
    }));

    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  const filteredPosts = posts.filter((p) => {
    if (activeTab === 'ANNOUNCEMENTS') return p.isAnnouncement || p.isPinned;
    if (activeTab === 'POLLS') return Boolean(p.poll);
    return true;
  });

  const trendingHashtags = ['#ALPhysics', '#CombinedMaths', '#SriLankaExams', '#2025AL', '#OLMaths', '#StudyTips'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Main Feed Column (2 cols) */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Post Composer Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/40"
            />
            <div>
              <p className="text-xs font-bold text-white">{currentUser.name}</p>
              <p className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider">{currentUser.role}</p>
            </div>
          </div>

          <form onSubmit={handleCreatePost} className="space-y-3">
            <textarea
              rows={3}
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder={t.postPlaceholder}
              className="w-full bg-slate-950 text-xs text-white p-3.5 rounded-2xl border border-slate-800 focus:outline-none focus:border-amber-400 transition-all resize-none"
            />

            {/* Poll Composer Block */}
            {showPollComposer && (
              <div className="p-4 bg-slate-950 border border-amber-500/30 rounded-2xl space-y-3">
                <p className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <BarChart2 className="w-4 h-4" />
                  <span>Create Interactive Poll</span>
                </p>
                <input
                  type="text"
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  placeholder="Poll Question (e.g. Which subject requires more past paper practice?)"
                  className="w-full bg-slate-900 text-xs text-white p-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
                />
                <div className="space-y-2">
                  {pollOptions.map((opt, idx) => (
                    <input
                      key={idx}
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const newOpts = [...pollOptions];
                        newOpts[idx] = e.target.value;
                        setPollOptions(newOpts);
                      }}
                      placeholder={`Option ${idx + 1}`}
                      className="w-full bg-slate-900 text-xs text-white p-2 rounded-xl border border-slate-800 focus:outline-none"
                    />
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => setPollOptions((prev) => [...prev, ''])}
                  className="text-[11px] font-bold text-amber-400 hover:underline"
                >
                  + Add Choice
                </button>
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => setShowPollComposer(!showPollComposer)}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
                  showPollComposer ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" />
                <span>{t.addPoll}</span>
              </button>

              <button
                type="submit"
                disabled={!postContent.trim()}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Publish Post (+10 Pts)</span>
              </button>
            </div>
          </form>
        </div>

        {/* Feed Filter Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTab('ALL')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'ALL' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            All Discussions
          </button>
          <button
            onClick={() => setActiveTab('ANNOUNCEMENTS')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'ANNOUNCEMENTS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            Announcements
          </button>
          <button
            onClick={() => setActiveTab('POLLS')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'POLLS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            Student Polls
          </button>
        </div>

        {/* Post Items */}
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const isLiked = post.likedUserIds.includes(currentUser.id);
            const commentsList = postComments[post.id] || [];

            return (
              <div key={post.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
                
                {/* Author Info & Pin Badge */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/30"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold text-white">{post.authorName}</span>
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      </div>
                      <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                        {post.authorRole} • {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {post.isAnnouncement && (
                    <span className="flex items-center gap-1 text-[10px] font-black uppercase text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/30">
                      <Pin className="w-3 h-3" />
                      <span>Announcement</span>
                    </span>
                  )}
                </div>

                {/* Content */}
                <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">{post.content}</p>

                {/* Poll render if exists */}
                {post.poll && (
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3 my-2">
                    <p className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <BarChart2 className="w-4 h-4" />
                      <span>{post.poll.question}</span>
                    </p>
                    <div className="space-y-2">
                      {post.poll.options.map((opt) => {
                        const totalVotes = post.poll?.options.reduce((acc, o) => acc + o.votes, 0) || 1;
                        const percentage = Math.round((opt.votes / totalVotes) * 100) || 0;
                        const hasVoted = opt.votedUserIds.includes(currentUser.id);

                        return (
                          <div key={opt.id} className="space-y-1">
                            <button
                              onClick={() => onVotePoll(post.id, opt.id)}
                              className={`w-full p-2.5 text-xs font-semibold rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                                hasVoted
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                              }`}
                            >
                              <span>{opt.text}</span>
                              <span className="font-bold text-amber-400">{percentage}% ({opt.votes})</span>
                            </button>
                            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                              <div className="bg-amber-500 h-full transition-all" style={{ width: `${percentage}%` }}></div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Hashtags */}
                {post.hashtags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {post.hashtags.map((tag, idx) => (
                      <span key={idx} className="text-[11px] font-bold text-amber-400 hover:underline">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Actions (Like, Comment, Share) */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className={`flex items-center gap-1.5 font-bold transition-all cursor-pointer ${
                        isLiked ? 'text-rose-400' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                      <span>{post.likesCount}</span>
                    </button>

                    <div className="flex items-center gap-1.5 font-bold text-slate-400">
                      <MessageSquare className="w-4 h-4" />
                      <span>{commentsList.length}</span>
                    </div>
                  </div>

                  <button className="text-slate-400 hover:text-white transition-all cursor-pointer">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Comments List & Add Comment Input */}
                <div className="pt-3 border-t border-slate-800/50 space-y-3">
                  {commentsList.map((c) => (
                    <div key={c.id} className="bg-slate-950 p-3 rounded-2xl text-xs space-y-0.5">
                      <p className="font-bold text-amber-300">{c.authorName}</p>
                      <p className="text-slate-300">{c.content}</p>
                    </div>
                  ))}

                  <div className="flex gap-2 pt-1">
                    <input
                      type="text"
                      value={commentInputs[post.id] || ''}
                      onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                      placeholder="Write a comment or answer..."
                      className="flex-1 bg-slate-950 text-xs text-white p-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400"
                    />
                    <button
                      onClick={() => handleAddComment(post.id)}
                      className="px-3 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Comment
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Sidebar (Trending Hashtags & Top Contributor Widgets) */}
      <div className="space-y-6">
        
        {/* Trending Hashtags */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-3">
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span>Trending Exam Topics</span>
          </h3>
          <div className="space-y-2">
            {trendingHashtags.map((tag, i) => (
              <div key={i} className="flex items-center justify-between p-2 rounded-xl bg-slate-950 hover:bg-slate-800 transition-all cursor-pointer">
                <span className="text-xs font-bold text-amber-300">{tag}</span>
                <span className="text-[10px] text-slate-400 font-semibold">{120 + i * 45} posts</span>
              </div>
            ))}
          </div>
        </div>

        {/* Community Guidelines Card */}
        <div className="bg-gradient-to-br from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30 rounded-3xl p-5 space-y-2">
          <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider">🇱🇰 Community Standards</h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            Respect fellow Sri Lankan students & teachers. Share verified past papers, official marking schemes, and educational study questions.
          </p>
        </div>

      </div>

    </div>
  );
};
