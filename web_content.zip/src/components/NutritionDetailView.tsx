import React, { useState } from 'react';
import {
  X,
  Bookmark,
  Share2,
  Check,
  Globe,
  Utensils,
  CheckCircle2,
  XCircle,
  Apple,
  Carrot,
  GlassWater,
  Dumbbell,
  Clock,
  HeartPulse,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Sparkles,
  Info,
  Scale,
  Flame,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'motion/react';
import { NutritionItem, NutritionLanguage } from '../types/nutrition';

interface NutritionDetailViewProps {
  item: NutritionItem;
  currentLanguage: NutritionLanguage;
  onLanguageChange: (lang: NutritionLanguage) => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onClose: () => void;
}

export const NutritionDetailView: React.FC<NutritionDetailViewProps> = ({
  item,
  currentLanguage,
  onLanguageChange,
  isBookmarked,
  onToggleBookmark,
  onClose
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const content = item.content[currentLanguage] || item.content.English;

  // Handle Share
  const handleShare = async () => {
    const text = `🥗 ${content.title}\n${content.summary}\n\nLearn more on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.title,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch (err) {
      console.warn('Failed to copy:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        className="bg-white w-full sm:max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92vh] overflow-hidden my-auto"
      >
        {/* Sticky Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 shrink-0 flex flex-col space-y-3 relative">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/15 text-2xl">
                {item.categoryEmoji}
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-300">
                  {content.categoryName}
                </span>
                <h2 className="text-lg sm:text-xl font-black leading-snug">{content.title}</h2>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => onToggleBookmark(item.id)}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isBookmarked
                    ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
                title="Bookmark Nutrition Plan"
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-slate-950' : ''}`} />
              </button>

              <button
                onClick={handleShare}
                className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all cursor-pointer"
                title="Share Plan"
              >
                {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>

              <button
                onClick={onClose}
                className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Trilingual Selector Bar */}
          <div className="pt-2 border-t border-white/15 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-slate-300 font-bold text-[11px]">
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>Language:</span>
            </div>

            <div className="flex bg-black/40 p-1 rounded-xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as NutritionLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-3 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    currentLanguage === lang
                      ? 'bg-emerald-500 text-white shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-slate-800 text-xs sm:text-sm">
          {/* Summary Banner */}
          <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200/80 space-y-1">
            <div className="flex items-center gap-2 font-black text-emerald-900 text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Overview</span>
            </div>
            <p className="text-emerald-950 font-medium leading-relaxed">{content.summary}</p>
          </div>

          {/* RENDER DISEASE DIET SECTION */}
          {content.diseaseDiet && (
            <div className="space-y-6">
              {/* Foods to Eat & Foods to Avoid side-by-side */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Foods to Eat */}
                <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 space-y-2">
                  <h3 className="font-extrabold text-emerald-900 text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'खाने योग्य आहार (Foods to Eat)' : currentLanguage === 'Marathi' ? 'काय खावे (Foods to Eat)' : 'Foods to Eat'}
                    </span>
                  </h3>
                  <ul className="space-y-1.5 text-emerald-950 text-xs font-medium">
                    {content.diseaseDiet.foodsToEat.map((food, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-600 font-bold mt-0.5">•</span>
                        <span>{food}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Foods to Avoid */}
                <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-200 space-y-2">
                  <h3 className="font-extrabold text-rose-900 text-xs flex items-center gap-1.5">
                    <XCircle className="w-4 h-4 text-rose-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'किन चीजों से बचें (Foods to Avoid)' : currentLanguage === 'Marathi' ? 'काय टाळावे (Foods to Avoid)' : 'Foods to Avoid'}
                    </span>
                  </h3>
                  <ul className="space-y-1.5 text-rose-950 text-xs font-medium">
                    {content.diseaseDiet.foodsToAvoid.map((food, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-rose-600 font-bold mt-0.5">•</span>
                        <span>{food}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Recommended Fruits & Vegetables */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200 space-y-2">
                  <h3 className="font-extrabold text-amber-900 text-xs flex items-center gap-1.5">
                    <Apple className="w-4 h-4 text-amber-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'अनुशंसित फल (Recommended Fruits)' : currentLanguage === 'Marathi' ? 'योग्य फळे (Recommended Fruits)' : 'Recommended Fruits'}
                    </span>
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {content.diseaseDiet.recommendedFruits.map((item, idx) => (
                      <span key={idx} className="bg-white px-2.5 py-1 rounded-xl text-xs font-bold text-amber-950 border border-amber-200">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-200 space-y-2">
                  <h3 className="font-extrabold text-teal-900 text-xs flex items-center gap-1.5">
                    <Carrot className="w-4 h-4 text-teal-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'अनुशंसित सब्जियां (Vegetables)' : currentLanguage === 'Marathi' ? 'योग्य भाज्या (Vegetables)' : 'Recommended Vegetables'}
                    </span>
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {content.diseaseDiet.recommendedVegetables.map((item, idx) => (
                      <span key={idx} className="bg-white px-2.5 py-1 rounded-xl text-xs font-bold text-teal-950 border border-teal-200">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recommended Drinks & Protein Sources */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-sky-50/60 p-4 rounded-2xl border border-sky-200 space-y-2">
                  <h3 className="font-extrabold text-sky-900 text-xs flex items-center gap-1.5">
                    <GlassWater className="w-4 h-4 text-sky-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'पेय पदार्थ (Recommended Drinks)' : currentLanguage === 'Marathi' ? 'आरोग्यदायी पेय (Drinks)' : 'Recommended Drinks'}
                    </span>
                  </h3>
                  <ul className="space-y-1 text-sky-950 text-xs font-medium">
                    {content.diseaseDiet.recommendedDrinks.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-sky-600 font-bold">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-indigo-50/60 p-4 rounded-2xl border border-indigo-200 space-y-2">
                  <h3 className="font-extrabold text-indigo-900 text-xs flex items-center gap-1.5">
                    <Dumbbell className="w-4 h-4 text-indigo-600" />
                    <span>
                      {currentLanguage === 'Hindi' ? 'प्रोटीन के स्रोत (Protein Sources)' : currentLanguage === 'Marathi' ? 'प्रोटीन स्त्रोत (Protein)' : 'Protein Sources'}
                    </span>
                  </h3>
                  <ul className="space-y-1 text-indigo-950 text-xs font-medium">
                    {content.diseaseDiet.proteinSources.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-indigo-600 font-bold">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Healthy Snacks & Meal Timing */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5">
                  <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                    <Utensils className="w-3.5 h-3.5 text-slate-500" />
                    Healthy Snacks
                  </span>
                  <p className="text-slate-600 text-xs">{content.diseaseDiet.healthySnacks.join(', ')}</p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5">
                  <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    Meal Timing Tips
                  </span>
                  <ul className="space-y-1 text-slate-600 text-xs">
                    {content.diseaseDiet.mealTimingTips.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-1">
                        <span className="text-slate-400">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Lifestyle Advice */}
              <div className="bg-purple-50/60 p-4 rounded-2xl border border-purple-200 space-y-2">
                <h3 className="font-extrabold text-purple-900 text-xs flex items-center gap-1.5">
                  <HeartPulse className="w-4 h-4 text-purple-600" />
                  <span>Lifestyle Advice</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-purple-950 text-xs font-medium">
                  {content.diseaseDiet.lifestyleAdvice.map((adv, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span className="text-purple-600 font-bold">•</span>
                      <span>{adv}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* FAQs */}
              {content.diseaseDiet.faqs && content.diseaseDiet.faqs.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-emerald-600" />
                    <span>Frequently Asked Questions</span>
                  </h3>
                  <div className="space-y-2">
                    {content.diseaseDiet.faqs.map((faq, idx) => {
                      const isOpen = openFaqIndex === idx;
                      return (
                        <div key={idx} className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden">
                          <button
                            onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                            className="w-full p-3.5 text-left font-bold text-slate-800 text-xs flex items-center justify-between gap-2 cursor-pointer"
                          >
                            <span>{faq.question}</span>
                            {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />}
                          </button>
                          {isOpen && (
                            <div className="px-3.5 pb-3.5 pt-0 text-slate-600 text-xs leading-relaxed font-medium border-t border-slate-200/60 pt-2">
                              {faq.answer}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* RENDER VITAMIN & MINERAL SECTION */}
          {content.vitaminMineral && (
            <div className="space-y-4">
              <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 space-y-2">
                <span className="font-extrabold text-amber-900 text-xs flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  Key Health Benefits
                </span>
                <ul className="space-y-1.5 text-amber-950 text-xs font-medium">
                  {content.vitaminMineral.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-600 font-bold">•</span>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 space-y-2">
                  <span className="font-extrabold text-emerald-900 text-xs flex items-center gap-1.5">
                    <Apple className="w-4 h-4 text-emerald-600" />
                    Top Food Sources
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {content.vitaminMineral.foodSources.map((source, idx) => (
                      <span key={idx} className="bg-white px-2.5 py-1 rounded-xl text-xs font-bold text-emerald-950 border border-emerald-200">
                        {source}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-200 space-y-2">
                  <span className="font-extrabold text-rose-900 text-xs flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    Deficiency Symptoms
                  </span>
                  <ul className="space-y-1 text-rose-950 text-xs font-medium">
                    {content.vitaminMineral.deficiencySymptoms.map((symp, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-rose-600 font-bold">•</span>
                        <span>{symp}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-indigo-50/70 p-4 rounded-2xl border border-indigo-200 text-indigo-950 text-xs font-medium space-y-1">
                <span className="font-extrabold text-indigo-900 text-xs block">Daily Recommended Allowance</span>
                <p>{content.vitaminMineral.dailyRequirement}</p>
              </div>
            </div>
          )}

          {/* RENDER WEIGHT MANAGEMENT SECTION */}
          {content.weightManagement && (
            <div className="space-y-4">
              <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 space-y-1">
                <span className="font-extrabold text-blue-900 text-xs flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-blue-600" />
                  Healthy BMI Benchmark
                </span>
                <p className="text-blue-950 text-xs font-medium">{content.weightManagement.bmiInfo}</p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-600" />
                  Core Dietary Principles
                </span>
                <ul className="space-y-1.5 text-slate-700 text-xs font-medium">
                  {content.weightManagement.dietTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-500 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 space-y-2">
                  <span className="font-extrabold text-emerald-900 text-xs">Recommended Foods</span>
                  <ul className="space-y-1 text-emerald-950 text-xs font-medium">
                    {content.weightManagement.recommendedFoods.map((f, idx) => (
                      <li key={idx} className="flex items-start gap-1">
                        <span className="text-emerald-600">•</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-200 space-y-2">
                  <span className="font-extrabold text-rose-900 text-xs">Foods to Limit</span>
                  <ul className="space-y-1 text-rose-950 text-xs font-medium">
                    {content.weightManagement.foodsToLimit.map((f, idx) => (
                      <li key={idx} className="flex items-start gap-1">
                        <span className="text-rose-600">•</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* RENDER HYDRATION SECTION */}
          {content.hydration && (
            <div className="space-y-4">
              <div className="bg-cyan-50/70 p-4 rounded-2xl border border-cyan-200 space-y-1">
                <span className="font-extrabold text-cyan-900 text-xs flex items-center gap-1.5">
                  <GlassWater className="w-4 h-4 text-cyan-600" />
                  Daily Water Requirement
                </span>
                <p className="text-cyan-950 text-xs font-medium">{content.hydration.dailyWaterIntake}</p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-slate-800 text-xs">Hydration Best Practices</span>
                <ul className="space-y-1.5 text-slate-700 text-xs font-medium">
                  {content.hydration.hydrationTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-cyan-600 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 space-y-1.5">
                <span className="font-extrabold text-amber-900 text-xs block">Electrolytes & ORS Usage</span>
                <p className="text-amber-950 text-xs font-medium">{content.hydration.electrolytesAndOrs}</p>
              </div>

              <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-200 space-y-1.5">
                <span className="font-extrabold text-rose-900 text-xs block">Signs of Dehydration</span>
                <ul className="space-y-1 text-rose-950 text-xs font-medium">
                  {content.hydration.signsOfDehydration.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-1">
                      <span className="text-rose-600">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Educational Disclaimer */}
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-300 text-amber-950 space-y-1.5 mt-4">
            <div className="flex items-center gap-2 font-black text-xs text-amber-900 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Educational Disclaimer</span>
            </div>
            <p className="text-[11px] leading-relaxed font-medium text-amber-900">
              "This information is provided for educational purposes only and should not replace professional medical advice. Always consult a qualified nutritionist or healthcare provider before making significant dietary changes."
            </p>
          </div>
        </div>

        {/* Footer Close Button */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 shrink-0">
          <button
            onClick={onClose}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-2xl transition-colors cursor-pointer shadow-md"
          >
            Close Nutrition Guide
          </button>
        </div>
      </motion.div>
    </div>
  );
};
