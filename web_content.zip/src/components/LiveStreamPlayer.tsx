import React, { useState, useEffect, useRef } from 'react';
import { Match, SportsChannel, StreamServer, ChatMessage } from '../types';
import { INITIAL_CHAT_MESSAGES } from '../data/mockMatches';
import { LineupPitch } from './LineupPitch';
import { sounds } from '../utils/soundEffects';
import confetti from 'canvas-confetti';
import Hls from 'hls.js';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  RotateCw,
  Radio,
  Send,
  MessageSquare,
  ListOrdered,
  BarChart3,
  Users,
  Tv,
  Mic,
  MapPin,
  X,
  Sparkles,
  Server,
  Flame,
  ThumbsUp,
  Sliders,
  Headphones,
  CheckCircle,
} from 'lucide-react';

interface LiveStreamPlayerProps {
  item: Match | SportsChannel;
  type: 'match' | 'channel';
  onClose: () => void;
}

export const LiveStreamPlayer: React.FC<LiveStreamPlayerProps> = ({ item, type, onClose }) => {
  const match = type === 'match' ? (item as Match) : null;
  const channel = type === 'channel' ? (item as SportsChannel) : null;

  const servers: StreamServer[] = item.servers || [];
  const [selectedServer, setSelectedServer] = useState<StreamServer>(
    servers[0] || { id: 's1', name: 'سيرفر VIP 1', quality: '1080p FHD', url: item.videoUrl }
  );

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.85);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isAudioOnly, setIsAudioOnly] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'events' | 'lineups' | 'stats' | 'servers'>('chat');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [newComment, setNewComment] = useState('');
  const [selectedQuality, setSelectedQuality] = useState('1080p FHD');
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [streamError, setStreamError] = useState(false);
  const [viewersCount, setViewersCount] = useState(
    channel ? channel.viewers : '284.5K'
  );

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Load stream via Hls or direct HTML5
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    setStreamError(false);
    let hls: Hls | null = null;
    const streamUrl = selectedServer?.url || item.videoUrl;

    if (streamUrl.endsWith('.m3u8')) {
      if (Hls.isSupported()) {
        hls = new Hls({ enableWorker: true, lowLatencyMode: true });
        hls.loadSource(streamUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          video.play().catch(() => {});
        });
        hls.on(Hls.Events.ERROR, () => {
          setStreamError(true);
        });
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = streamUrl;
        video.play().catch(() => {});
      }
    } else {
      video.src = streamUrl;
      video.load();
      video.play().catch(() => {});
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
    };
  }, [selectedServer, item.videoUrl]);

  // Periodic random viewer updates for realistic live feel
  useEffect(() => {
    const interval = setInterval(() => {
      const base = 280 + Math.floor(Math.random() * 15);
      const dec = Math.floor(Math.random() * 9);
      setViewersCount(`${base}.${dec}K`);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // Periodic fan chat simulation
  useEffect(() => {
    const fanComments = [
      'يا عيني على التمريرة والسرعة!!',
      'فارس عوض مولعها بصوته الخرافي 🎙️🔥',
      'والله فرصة لا تضيع يا أخي!',
      'الدفاع اليوم حديدي، مستحيل يمرون منه',
      'بث IRAQI LIVE دائماً رقم 1 بدون ولا ثانية تقطيع ❤️',
      'جوووووووووووووووووووووول! ما شاء الله',
      'سيرفر VIP سرعته خرافية شكراً لكم',
      'الحكم لازم يرجع للفار اللقطة فيها ركلة جزاء',
    ];
    const fanNames = ['سالم الرياضي', 'مدريديستا حتى النخاع', 'عاشق الأخضر', 'كروي محايد', 'أبو سارة', 'المستشار الكروي'];

    const interval = setInterval(() => {
      const randomText = fanComments[Math.floor(Math.random() * fanComments.length)];
      const randomName = fanNames[Math.floor(Math.random() * fanNames.length)];
      const now = new Date();
      const timeStr = `${now.getHours()}:${now.getMinutes() < 10 ? '0' : ''}${now.getMinutes()}`;

      const newMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        user: randomName,
        avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${randomName}`,
        text: randomText,
        time: timeStr,
        likes: Math.floor(Math.random() * 5),
      };

      setChatMessages((prev) => [...prev.slice(-40), newMsg]);
    }, 7000);

    return () => clearInterval(interval);
  }, []);

  // Scroll chat down on message
  useEffect(() => {
    if (activeTab === 'chat' && chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, activeTab]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleFullscreen = () => {
    if (!playerContainerRef.current) return;
    if (!document.fullscreenElement) {
      playerContainerRef.current.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const handleGoalCelebration = () => {
    sounds.playGoalHorn();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#e11d48', '#fbbf24', '#ffffff', '#10b981'],
    });

    if (match) {
      const goalMsg: ChatMessage = {
        id: `goal-${Date.now()}`,
        user: 'احتفال الهدف ⚽🔥',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=GoalCelebration',
        text: `جوووووووووووووووووووول عالمي! ⚽🎉🔥 في شباك ${match.awayTeam.name}!`,
        time: 'الآن',
        isSuperfan: true,
        likes: 99,
      };
      setChatMessages((prev) => [...prev, goalMsg]);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const now = new Date();
    const timeStr = `${now.getHours()}:${now.getMinutes() < 10 ? '0' : ''}${now.getMinutes()}`;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      user: 'أنت (مشاهد VIP)',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=YouVIP',
      text: newComment.trim(),
      time: timeStr,
      isSuperfan: true,
      likes: 1,
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setNewComment('');
  };

  const handleLikeMessage = (msgId: string) => {
    setChatMessages((prev) =>
      prev.map((msg) => (msg.id === msgId ? { ...msg, likes: msg.likes + 1 } : msg))
    );
  };

  const reloadStream = () => {
    if (videoRef.current) {
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
    }
  };

  return (
    <div
      id="live-player-modal"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-5xl bg-[#0e1320] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col my-auto max-h-[96vh]">
        {/* Top Header Bar */}
        <div className="bg-[#090d16] px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping shrink-0" />
            <div className="truncate">
              <h2 className="text-sm sm:text-base font-black text-white truncate">
                {match ? `${match.homeTeam.name} ضد ${match.awayTeam.name}` : channel?.name}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>{match ? match.tournament.name : channel?.currentShow}</span>
                <span>•</span>
                <span className="text-rose-400 font-bold">{selectedServer.name}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Live Viewers count */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300 font-bold">
              <Users className="w-3.5 h-3.5 text-rose-500" />
              <span>{viewersCount} مشاهد</span>
            </div>

            {/* Close Button */}
            <button
              id="close-player-btn"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-rose-600 text-slate-300 hover:text-white transition-colors border border-slate-700"
              title="إغلاق البث"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Player Container */}
        <div
          ref={playerContainerRef}
          className="relative bg-black aspect-video w-full flex items-center justify-center overflow-hidden group select-none"
        >
          {/* Audio-only mode overlay */}
          {isAudioOnly ? (
            <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-[#131a2b] to-black flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-20 h-20 rounded-full bg-rose-600/20 border-2 border-rose-500/60 flex items-center justify-center animate-pulse shadow-lg shadow-rose-600/30">
                <Headphones className="w-10 h-10 text-rose-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">وضع البث الصوتي فقط (توفير البيانات)</h3>
                <p className="text-xs text-slate-400">
                  {match ? `صوت المعلق: ${match.commentator} - ${match.channel}` : channel?.name}
                </p>
              </div>
              {/* Sound wave bars */}
              <div className="flex items-center gap-1.5 h-12">
                {[40, 75, 55, 90, 60, 100, 70, 85, 45, 95, 65, 80].map((h, i) => (
                  <span
                    key={i}
                    style={{ height: `${h}%` }}
                    className="w-1.5 bg-rose-500 rounded-full animate-pulse"
                  />
                ))}
              </div>
              <button
                onClick={() => setIsAudioOnly(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 text-xs font-bold text-slate-200 hover:bg-rose-600 hover:text-white border border-slate-700 transition-colors"
              >
                الرجوع إلى بث الفيديو
              </button>
            </div>
          ) : (
            <video
              ref={videoRef}
              playsInline
              autoPlay
              loop
              muted={isMuted}
              className="w-full h-full object-contain bg-black"
              onError={() => setStreamError(true)}
            />
          )}

          {/* Stream Error Fallback Notice */}
          {streamError && (
            <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center text-center p-4 z-20 space-y-3">
              <span className="text-rose-500 font-bold text-sm">تم قطع الاتصال بالسيرفر الحالي</span>
              <p className="text-xs text-slate-300 max-w-sm">
                يمكنك التبديل إلى أحد السيرفرات البديلة أدناه للمتابعة بدون تقطيع
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                {servers.map((srv) => (
                  <button
                    key={srv.id}
                    onClick={() => {
                      setSelectedServer(srv);
                      setStreamError(false);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white shadow"
                  >
                    {srv.name}
                  </button>
                ))}
                <button
                  onClick={reloadStream}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-700"
                >
                  إعادة المحاولة
                </button>
              </div>
            </div>
          )}

          {/* Watermark Logo */}
          <div className="absolute top-4 right-4 z-10 pointer-events-none flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-white/10">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span className="text-xs font-black text-white font-['Changa']">
              IRAQI <span className="text-rose-400">LIVE</span>
            </span>
          </div>

          {/* Goal celebration floating button */}
          <button
            id="goal-celebrate-btn"
            onClick={handleGoalCelebration}
            className="absolute top-4 left-4 z-10 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-rose-900/50 transform hover:scale-105 active:scale-95 transition-all"
            title="انقر للاحتفال بهدف وإطلاق الألعاب النارية!"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>احتفل بالهدف! ⚽🎉</span>
          </button>

          {/* Match Score Overlay on Top Center */}
          {match && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 hidden sm:flex items-center gap-3 bg-black/70 backdrop-blur-md px-4 py-1 rounded-full border border-white/15 text-xs font-bold text-white">
              <span className="truncate max-w-[90px]">{match.homeTeam.name}</span>
              <span className="font-['Changa'] text-rose-400 font-black text-sm">
                {match.homeScore ?? 0} : {match.awayScore ?? 0}
              </span>
              <span className="truncate max-w-[90px]">{match.awayTeam.name}</span>
              <span className="text-[10px] bg-rose-600 px-1.5 py-0.2 rounded font-mono">
                {match.minute ? `${match.minute}'` : 'مباشر'}
              </span>
            </div>
          )}

          {/* Custom Player Controls Bar (appears on hover or active) */}
          <div className="absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black via-black/70 to-transparent p-3 sm:p-4 opacity-95 transition-opacity">
            <div className="flex items-center justify-between gap-3 text-white">
              {/* Left Controls: Play/Pause, Volume, Reload */}
              <div className="flex items-center gap-2 sm:gap-3">
                <button
                  id="player-play-btn"
                  onClick={togglePlay}
                  className="p-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white transition-colors"
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                </button>

                <button
                  id="player-mute-btn"
                  onClick={toggleMute}
                  className="p-1.5 rounded-lg hover:bg-white/15 transition-colors"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4 text-rose-400" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>

                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 sm:w-20 accent-rose-500 h-1 rounded-lg cursor-pointer bg-slate-700"
                />

                <button
                  id="player-refresh-btn"
                  onClick={reloadStream}
                  title="تحديث البث"
                  className="p-1.5 rounded-lg hover:bg-white/15 transition-colors text-slate-300 hover:text-white hidden sm:block"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </div>

              {/* Right Controls: Quality, Audio toggle, Fullscreen */}
              <div className="flex items-center gap-2">
                {/* Audio-only toggle */}
                <button
                  onClick={() => setIsAudioOnly(!isAudioOnly)}
                  title={isAudioOnly ? 'العودة للفيديو' : 'تشغيل البث الصوتي'}
                  className={`p-1.5 rounded-lg transition-colors text-xs flex items-center gap-1 font-semibold ${
                    isAudioOnly ? 'bg-rose-600 text-white' : 'hover:bg-white/15 text-slate-300'
                  }`}
                >
                  <Headphones className="w-4 h-4" />
                  <span className="hidden md:inline">صوتي</span>
                </button>

                {/* Quality Switcher Button */}
                <div className="relative">
                  <button
                    id="quality-menu-btn"
                    onClick={() => setShowQualityMenu(!showQualityMenu)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 flex items-center gap-1"
                  >
                    <Sliders className="w-3.5 h-3.5 text-rose-400" />
                    <span>{selectedQuality}</span>
                  </button>

                  {/* Quality Dropdown */}
                  {showQualityMenu && (
                    <div className="absolute bottom-full mb-2 left-0 w-36 bg-[#111726] border border-slate-700 rounded-xl shadow-2xl p-1.5 z-30 space-y-1">
                      {['1080p FHD', '720p HD', '480p SD', '360p ضعيف'].map((q) => (
                        <button
                          key={q}
                          onClick={() => {
                            setSelectedQuality(q);
                            setShowQualityMenu(false);
                          }}
                          className={`w-full text-right px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center justify-between transition-colors ${
                            selectedQuality === q
                              ? 'bg-rose-600 text-white'
                              : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                          }`}
                        >
                          <span>{q}</span>
                          {selectedQuality === q && <CheckCircle className="w-3.5 h-3.5" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Fullscreen Button */}
                <button
                  id="fullscreen-btn"
                  onClick={toggleFullscreen}
                  className="p-1.5 rounded-lg hover:bg-white/15 transition-colors text-slate-300 hover:text-white"
                >
                  {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Server Switcher Bar */}
        <div className="bg-[#0b0f19] px-4 py-2 border-b border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 shrink-0 pl-2">
            <Server className="w-3.5 h-3.5 text-rose-400" />
            <span className="font-bold">السيرفرات:</span>
          </div>

          {servers.map((srv) => (
            <button
              key={srv.id}
              onClick={() => setSelectedServer(srv)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shrink-0 flex items-center gap-1.5 border ${
                selectedServer.id === srv.id
                  ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-600/30'
                  : 'bg-[#141a29] text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <span>{srv.name}</span>
              <span className="text-[10px] bg-black/30 px-1.5 py-0.2 rounded font-mono">
                {srv.quality}
              </span>
            </button>
          ))}
        </div>

        {/* Content Tabs Under Player */}
        <div className="flex border-b border-slate-800 bg-[#0c101a] shrink-0 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'chat'
                ? 'border-rose-500 text-white bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-rose-400" />
            <span>شات البث المباشر</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          </button>

          {match && (
            <>
              <button
                onClick={() => setActiveTab('events')}
                className={`px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'events'
                    ? 'border-rose-500 text-white bg-slate-800/40'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <ListOrdered className="w-4 h-4 text-amber-400" />
                <span>أحداث ومجريات اللقاء</span>
              </button>

              <button
                onClick={() => setActiveTab('lineups')}
                className={`px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'lineups'
                    ? 'border-rose-500 text-white bg-slate-800/40'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Users className="w-4 h-4 text-blue-400" />
                <span>التشكيلة والملعب</span>
              </button>

              <button
                onClick={() => setActiveTab('stats')}
                className={`px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'stats'
                    ? 'border-rose-500 text-white bg-slate-800/40'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-emerald-400" />
                <span>إحصائيات المباراة</span>
              </button>
            </>
          )}

          <button
            onClick={() => setActiveTab('servers')}
            className={`px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'servers'
                ? 'border-rose-500 text-white bg-slate-800/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-4 h-4 text-purple-400" />
            <span>تفاصيل البث والقناة</span>
          </button>
        </div>

        {/* Tab Body Container */}
        <div className="p-4 overflow-y-auto flex-1 min-h-[220px] max-h-[380px] bg-[#0c101a]/50">
          {/* 1. Live Chat Tab */}
          {activeTab === 'chat' && (
            <div className="flex flex-col h-full space-y-3">
              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 p-2 rounded-xl text-xs ${
                      msg.isSuperfan
                        ? 'bg-rose-950/30 border border-rose-800/40'
                        : 'bg-[#141a29]/80 border border-slate-800/70'
                    }`}
                  >
                    <img
                      src={msg.avatar}
                      alt={msg.user}
                      className="w-7 h-7 rounded-full bg-slate-800 shrink-0 border border-slate-700"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-200 truncate">{msg.user}</span>
                          {msg.isSuperfan && (
                            <span className="text-[10px] bg-rose-600 text-white px-1.5 py-0.2 rounded font-extrabold">
                              VIP
                            </span>
                          )}
                          {msg.teamTag && (
                            <span className="text-[10px] bg-slate-800 text-amber-400 px-1.5 py-0.2 rounded font-mono font-bold">
                              {msg.teamTag}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">{msg.time}</span>
                      </div>
                      <p className="text-slate-300 mt-1 leading-relaxed break-words">{msg.text}</p>
                    </div>

                    <button
                      onClick={() => handleLikeMessage(msg.id)}
                      className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-rose-400 shrink-0 self-center px-1.5 py-1 rounded bg-slate-800/60 transition-colors"
                      title="إعجاب بالتعليق"
                    >
                      <ThumbsUp className="w-3 h-3" />
                      <span>{msg.likes}</span>
                    </button>
                  </div>
                ))}
                <div ref={chatBottomRef} />
              </div>

              {/* Chat Input Form */}
              <form onSubmit={handleSendMessage} className="flex items-center gap-2 pt-2 border-t border-slate-800 shrink-0">
                <input
                  type="text"
                  placeholder="اكتب تعليقك وتفاعل مع الجماهير الآن..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="flex-1 bg-[#141a29] border border-slate-700/70 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  disabled={!newComment.trim()}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md"
                >
                  <span>إرسال</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}

          {/* 2. Match Events Tab */}
          {activeTab === 'events' && match && (
            <div className="space-y-3">
              {match.events.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  لا توجد أحداث مسجلة بعد في هذا اللقاء، تبدأ فور صافرة البداية.
                </div>
              ) : (
                <div className="relative border-r-2 border-slate-800 mr-4 space-y-4 pr-4">
                  {match.events.map((ev) => (
                    <div key={ev.id} className="relative flex items-start gap-3">
                      {/* Timeline dot with event icon */}
                      <span className="absolute -right-[23px] top-0 w-6 h-6 rounded-full bg-[#192236] border-2 border-rose-500 flex items-center justify-center text-xs">
                        {ev.type === 'goal' ? '⚽' : ev.type === 'yellow_card' ? '🟨' : ev.type === 'red_card' ? '🟥' : '🔄'}
                      </span>

                      <div className="bg-[#141a29] p-3 rounded-xl border border-slate-800 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-white">{ev.player}</span>
                          <span className="font-mono text-rose-400 text-xs font-bold">{ev.minute}'</span>
                        </div>
                        {ev.assistPlayer && (
                          <span className="text-[11px] text-slate-400 block mt-0.5">
                            صناعة الهدف: {ev.assistPlayer}
                          </span>
                        )}
                        {ev.description && (
                          <span className="text-[11px] text-slate-400 block mt-0.5">
                            {ev.description}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 3. Lineup Pitch Tab */}
          {activeTab === 'lineups' && match && <LineupPitch match={match} />}

          {/* 4. Match Stats Tab */}
          {activeTab === 'stats' && match && (
            <div className="space-y-4 max-w-xl mx-auto py-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300 pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <img src={match.homeTeam.logo} alt="" className="w-5 h-5 object-contain" />
                  <span>{match.homeTeam.name}</span>
                </div>
                <span>مقارنة الأداء</span>
                <div className="flex items-center gap-2">
                  <span>{match.awayTeam.name}</span>
                  <img src={match.awayTeam.logo} alt="" className="w-5 h-5 object-contain" />
                </div>
              </div>

              {/* Stat Rows */}
              <StatRow label="الاستحواذ على الكرة" homeVal={`${match.stats.possession[0]}%`} awayVal={`${match.stats.possession[1]}%`} homePct={match.stats.possession[0]} />
              <StatRow label="إجمالي التسديدات" homeVal={match.stats.shots[0]} awayVal={match.stats.shots[1]} homePct={(match.stats.shots[0] / (match.stats.shots[0] + match.stats.shots[1] || 1)) * 100} />
              <StatRow label="تسديدات على المرمى" homeVal={match.stats.shotsOnTarget[0]} awayVal={match.stats.shotsOnTarget[1]} homePct={(match.stats.shotsOnTarget[0] / (match.stats.shotsOnTarget[0] + match.stats.shotsOnTarget[1] || 1)) * 100} />
              <StatRow label="الضربات الركنية" homeVal={match.stats.corners[0]} awayVal={match.stats.corners[1]} homePct={(match.stats.corners[0] / (match.stats.corners[0] + match.stats.corners[1] || 1)) * 100} />
              <StatRow label="الأخطاء المرتكبة" homeVal={match.stats.fouls[0]} awayVal={match.stats.fouls[1]} homePct={(match.stats.fouls[0] / (match.stats.fouls[0] + match.stats.fouls[1] || 1)) * 100} />
              <StatRow label="البطاقات الصفراء" homeVal={match.stats.yellowCards[0]} awayVal={match.stats.yellowCards[1]} homePct={(match.stats.yellowCards[0] / (match.stats.yellowCards[0] + match.stats.yellowCards[1] || 1)) * 100} />
              <StatRow label="دقة التمريرات" homeVal={`${match.stats.passesAccuracy[0]}%`} awayVal={`${match.stats.passesAccuracy[1]}%`} homePct={match.stats.passesAccuracy[0]} />
            </div>
          )}

          {/* 5. Broadcast & Server Info Tab */}
          {activeTab === 'servers' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-[#141a29] p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-white flex items-center gap-2">
                  <Tv className="w-4 h-4 text-rose-500" />
                  <span>بيانات القناة والناقل</span>
                </h4>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">القناة الناقلة:</span>
                    <strong className="text-white">{match ? match.channel : channel?.name}</strong>
                  </div>
                  {match && (
                    <>
                      <div className="flex justify-between py-1 border-b border-slate-800/80">
                        <span className="text-slate-400">معلق اللقاء:</span>
                        <strong className="text-white">{match.commentator}</strong>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-800/80">
                        <span className="text-slate-400">الملعب:</span>
                        <strong className="text-white">{match.stadium}</strong>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-800/80">
                        <span className="text-slate-400">البطولة والدور:</span>
                        <strong className="text-white">{match.tournament.name} - {match.round}</strong>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between py-1">
                    <span className="text-slate-400">جودة البث الحالية:</span>
                    <span className="text-emerald-400 font-bold">{selectedQuality}</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#141a29] p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-purple-400" />
                  <span>جميع سيرفرات البث المتوفرة</span>
                </h4>
                <div className="space-y-2">
                  {servers.map((srv) => (
                    <div
                      key={srv.id}
                      className={`flex items-center justify-between p-2 rounded-xl border transition-all ${
                        selectedServer.id === srv.id
                          ? 'bg-rose-600/20 border-rose-500/60 text-white'
                          : 'bg-[#192236] border-slate-800 text-slate-300'
                      }`}
                    >
                      <div>
                        <span className="font-bold block">{srv.name}</span>
                        <span className="text-[10px] text-slate-400">{srv.quality}</span>
                      </div>
                      <button
                        onClick={() => setSelectedServer(srv)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                          selectedServer.id === srv.id
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                      >
                        {selectedServer.id === srv.id ? 'قيد التشغيل' : 'تبديل'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const StatRow: React.FC<{
  label: string;
  homeVal: string | number;
  awayVal: string | number;
  homePct: number;
}> = ({ label, homeVal, awayVal, homePct }) => {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs font-bold text-slate-200">
        <span className="text-rose-400">{homeVal}</span>
        <span className="text-slate-400 font-normal">{label}</span>
        <span className="text-blue-400">{awayVal}</span>
      </div>
      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden flex">
        <div
          style={{ width: `${Math.min(Math.max(homePct, 5), 95)}%` }}
          className="bg-gradient-to-r from-rose-600 to-red-500 h-full transition-all duration-500"
        />
        <div
          style={{ width: `${100 - Math.min(Math.max(homePct, 5), 95)}%` }}
          className="bg-gradient-to-l from-blue-600 to-indigo-500 h-full transition-all duration-500"
        />
      </div>
    </div>
  );
};
