import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Printer,
  Trash2,
  X,
  Check,
  AlertTriangle
} from 'lucide-react';

export const BackupRestoreModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    transactions,
    categories,
    familyMembers,
    selectedMonth,
    exportBackup,
    restoreBackup,
    resetAllData,
    language,
    t
  } = useKhata();

  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  if (activeModal !== 'backup') return null;

  // 1. Export Excel-compatible CSV (with UTF-8 BOM so Excel displays Hindi properly)
  const handleExportCsv = () => {
    const headers = ['तारीख (Date)', 'प्रकार (Type)', 'श्रेणी (Category)', 'राशि (Amount ₹)', 'विवरण (Description)', 'सदस्य (Member)', 'माध्यम (Payment Mode)'];
    
    const rows = transactions.map(tx => {
      const cat = categories.find(c => c.id === tx.categoryId);
      const member = familyMembers.find(m => m.id === tx.familyMemberId);
      const typeLabel = tx.type === 'income' ? 'आय (Income)' : 'खर्च (Expense)';
      const catName = language === 'hi' ? cat?.nameHi : cat?.nameEn;
      const memberName = member?.name || 'स्वयं';
      
      return [
        `"${tx.date}"`,
        `"${typeLabel}"`,
        `"${catName || tx.categoryId}"`,
        tx.amount,
        `"${(tx.description || '').replace(/"/g, '""')}"`,
        `"${memberName}"`,
        `"${tx.paymentMode}"`
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Smart_Home_Khata_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // 2. Export / Print PDF Statement
  const handlePrintPdf = () => {
    window.print();
  };

  // 3. Download JSON Full Database Backup
  const handleDownloadJson = () => {
    const backupData = exportBackup();
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `smart-home-khata-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // 4. Restore from JSON
  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const success = restoreBackup(parsed);
        if (success) {
          setRestoreStatus(t.restoreSuccess);
          setTimeout(() => setRestoreStatus(null), 3000);
        } else {
          setRestoreStatus('अमान्य बैकअप फ़ाइल / Invalid backup file');
        }
      } catch (err) {
        setRestoreStatus('फ़ाइल पढ़ने में त्रुटि / Error reading file');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (window.confirm(t.clearDataConfirm)) {
      resetAllData();
      setActiveModal(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
            <h3 className="text-base font-bold text-slate-900">{t.backupRestoreTitle}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {restoreStatus && (
            <div className="p-3 bg-emerald-50 text-emerald-900 rounded-xl border border-emerald-200 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{restoreStatus}</span>
            </div>
          )}

          {/* Export CSV Button */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900">{t.exportCsv}</h4>
                <p className="text-[11px] text-slate-500">
                  Microsoft Excel या Google Sheets में खोलने योग्य .CSV फाइल
                </p>
              </div>
              <button
                onClick={handleExportCsv}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>डाउनलोड</span>
              </button>
            </div>
          </div>

          {/* Export Printable / PDF Statement */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900">{t.exportPdf}</h4>
                <p className="text-[11px] text-slate-500">
                  मासिक घरेलू हिसाब की प्रिंट कॉपी या PDF सुरक्षित करें
                </p>
              </div>
              <button
                onClick={handlePrintPdf}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>प्रिंट / PDF</span>
              </button>
            </div>
          </div>

          {/* Full JSON Backup Download */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900">{t.downloadJsonBackup}</h4>
                <p className="text-[11px] text-slate-500">
                  सभी खर्च, आय, बजट, कर्ज और लक्ष्यों का संपूर्ण बैकअप
                </p>
              </div>
              <button
                onClick={handleDownloadJson}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>बैकअप लें</span>
              </button>
            </div>
          </div>

          {/* Restore JSON Backup File */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div>
              <h4 className="text-sm font-bold text-slate-900">{t.restoreFromJson}</h4>
              <p className="text-[11px] text-slate-500">
                पहले डाउनलोड की गई बैकअप फ़ाइल (.json) चुनकर डेटा रीस्टोर करें
              </p>
            </div>
            <label className="w-full py-2.5 px-3 border border-dashed border-emerald-400 bg-emerald-50/50 hover:bg-emerald-50 rounded-xl text-xs font-bold text-emerald-800 cursor-pointer flex items-center justify-center gap-2 transition">
              <Upload className="w-4 h-4" />
              <span>बैकअप फ़ाइल चुनें (.json)</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileImport}
                className="hidden"
              />
            </label>
          </div>

          {/* Reset All Data (With Confirmation) */}
          <div className="pt-2">
            <button
              onClick={handleReset}
              className="w-full py-2.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition flex items-center justify-center gap-1.5"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.clearAllData}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
