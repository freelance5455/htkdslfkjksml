import React, { useEffect, useState } from 'react';
import { Coins, X, CheckCircle, Video, ShieldCheck } from 'lucide-react';
import { REWARDED_COINS_AMOUNT, ADMOB_REWARDED_AD_UNIT_ID } from '../admob';

interface RewardedAdModalProps {
  onReward: (coinsEarned: number) => void;
  onClose: () => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({ onReward, onClose }) => {
  const TOTAL_DURATION = 6;
  const [secondsLeft, setSecondsLeft] = useState(TOTAL_DURATION);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    if (secondsLeft > 0) {
      const timer = setTimeout(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setIsCompleted(true);
    }
  }, [secondsLeft]);

  const handleClaimReward = () => {
    if (!isCompleted) return;
    onReward(REWARDED_COINS_AMOUNT);
    onClose();
  };

  const progressPercent = Math.min(100, Math.max(0, ((TOTAL_DURATION - secondsLeft) / TOTAL_DURATION) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="relative flex w-full max-w-sm flex-col items-center rounded-3xl bg-slate-900 border border-slate-800 p-6 text-center shadow-2xl overflow-hidden">
        {/* AdMob Brand Header */}
        <div className="flex w-full items-center justify-between pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-1.5 text-left">
            <span className="flex h-5 w-5 items-center justify-center rounded-md bg-amber-500/20 text-amber-400">
              <Video className="h-3 w-3" />
            </span>
            <div className="flex flex-col">
              <span className="text-[11px] font-black text-white tracking-wide">
                Google AdMob Rewarded Ad
              </span>
              <span className="text-[9px] font-mono text-slate-500 truncate max-w-[170px]">
                {ADMOB_REWARDED_AD_UNIT_ID}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1 rounded-full bg-slate-800 px-2.5 py-0.5 text-[11px] font-mono font-bold text-slate-300">
              {isCompleted ? (
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3" /> Ready
                </span>
              ) : (
                <span>{secondsLeft}s</span>
              )}
            </div>

            {/* Close button only accessible when ad completes or closes */}
            {isCompleted && (
              <button
                onClick={onClose}
                className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
                aria-label="Close"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Ad Simulated Video Showcase */}
        <div className="relative my-4 flex h-48 w-full flex-col items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-950/40 via-slate-900 to-indigo-950/40 border border-slate-800 overflow-hidden shadow-inner">
          {/* Animated Coin Badge */}
          <div className="relative mb-2 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 shadow-lg shadow-amber-500/30 animate-pulse">
            <Coins className="h-8 w-8 fill-slate-950" />
          </div>

          <span className="text-sm font-black text-white">REWARDED SPONSOR</span>
          <span className="mt-0.5 text-xs text-amber-300 font-semibold">
            Watch to earn +{REWARDED_COINS_AMOUNT} Bonus Coins
          </span>

          {/* Smooth Bottom Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-1000 ease-linear"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Claim or Watching State */}
        {isCompleted ? (
          <button
            onClick={handleClaimReward}
            className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-sm shadow-[0_4px_25px_rgba(245,158,11,0.4)] active:scale-95 transition-all hover:brightness-110"
          >
            <CheckCircle className="h-4 w-4" />
            <span>COLLECT +{REWARDED_COINS_AMOUNT} COINS</span>
          </button>
        ) : (
          <div className="flex h-12 w-full flex-col items-center justify-center rounded-2xl bg-slate-800/50 border border-slate-800/80 text-[11px] font-bold text-slate-400">
            <span>Reward unlocks when ad completes</span>
            <span className="text-[10px] text-amber-400/80">Please do not close window</span>
          </div>
        )}
      </div>
    </div>
  );
};
