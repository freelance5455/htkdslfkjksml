import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type {
  DashboardCardConfig,
  DateFormatOption,
  Language,
  MetricKey,
  ThemePreset,
  ViewMode,
} from '../types';

const METRIC_OPTIONS: { value: MetricKey; label: string }[] = [
  { value: 'home_expenses', label: 'Home Expenses' },
  { value: 'purchase_total_amount', label: 'Atta / Purchase Total Amount' },
  { value: 'purchase_total_maund', label: 'Atta / Purchase Total Maund' },
  { value: 'purchase_avg_rate', label: 'Atta / Purchase Avg Rate / Maund' },
  { value: 'factory_leave_total', label: 'Factory Leave Balance (CL+SL+CPL)' },
  { value: 'factory_cpl_avail', label: 'Factory CPL Avail' },
  { value: 'factory_cpl_due', label: 'Factory CPL Due' },
  { value: 'office_tasks_open', label: 'Open Office Tasks' },
  { value: 'personal_loan_payable', label: 'Personal Loan Payable' },
  { value: 'committee_balance', label: 'Committee Remaining' },
  { value: 'total_records', label: 'Total Records' },
];

export const SettingsModule: React.FC = () => {
  const { state, updateSettings, notify, themeTokens, navigate } = useApp();
  const s = state.settings;

  const [appName, setAppName] = useState(s.appName);
  const [appSubtitle, setAppSubtitle] = useState(s.appSubtitle);
  const [viewMode, setViewMode] = useState<ViewMode>(s.viewMode);
  const [theme, setTheme] = useState<ThemePreset>(s.theme);
  const [language, setLanguage] = useState<Language>(s.language);
  const [dateFormat, setDateFormat] = useState<DateFormatOption>(s.dateFormat);
  const [currencyLabel, setCurrencyLabel] = useState(s.currencyLabel);
  const [maundToKg, setMaundToKg] = useState(String(s.maundToKg));
  const [allowNegativePurchase, setAllowNegativePurchase] = useState(s.allowNegativePurchase);
  const [defaultCL, setDefaultCL] = useState(String(s.defaultCL));
  const [defaultSL, setDefaultSL] = useState(String(s.defaultSL));
  const [cplExpiryDays, setCplExpiryDays] = useState(String(s.cplExpiryDays));
  const [allowNegativeLeaveOverride, setAllowNegativeLeaveOverride] = useState(
    s.allowNegativeLeaveOverride
  );
  const [confirmBeforeDelete, setConfirmBeforeDelete] = useState(s.confirmBeforeDelete);
  const [defaultEmployeeName, setDefaultEmployeeName] = useState(s.defaultEmployeeName);
  const [cards, setCards] = useState<DashboardCardConfig[]>(s.dashboardCards);

  const allMetricOptions: { value: MetricKey; label: string }[] = [
    ...METRIC_OPTIONS,
    ...state.customModules
      .filter((m) => !m.archived)
      .map((m) => ({ value: `custom:${m.id}` as MetricKey, label: `Custom: ${m.name}` })),
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(
      {
        appName: appName.trim() || 'Saif Ullah',
        appSubtitle: appSubtitle.trim() || 'Personal & Professional Manager',
        viewMode,
        theme,
        language,
        dateFormat,
        currencyLabel: currencyLabel.trim() || 'PKR',
        maundToKg: Math.max(1, parseFloat(maundToKg) || 40),
        allowNegativePurchase,
        defaultCL: Math.max(0, parseFloat(defaultCL) || 10),
        defaultSL: Math.max(0, parseFloat(defaultSL) || 8),
        cplExpiryDays: Math.max(1, parseInt(cplExpiryDays, 10) || 40),
        allowNegativeLeaveOverride,
        confirmBeforeDelete,
        defaultEmployeeName: defaultEmployeeName.trim() || 'Saif Ullah',
        dashboardCards: cards,
      },
      `Saved settings (View: ${viewMode}, Lang: ${language.toUpperCase()}, Theme: ${theme})`
    );
    notify('Settings saved.');
  };

  const updateCard = (index: number, patch: Partial<DashboardCardConfig>) => {
    setCards((prev) => prev.map((c, i) => (i === index ? { ...c, ...patch } : c)));
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* App Identity & Interface */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">General &amp; Interface Settings</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Customize branding, desktop/mobile view, theme, language (English / Urdu RTL), and formatting.
            </p>
          </div>
          <button
            type="submit"
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
          >
            <Save className="h-4 w-4" />
            <span>Save Settings</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          <div>
            <label htmlFor="set-appname" className="block text-xs font-medium text-slate-700 mb-1">
              App Name
            </label>
            <input
              id="set-appname"
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="set-subtitle" className="block text-xs font-medium text-slate-700 mb-1">
              App Subtitle
            </label>
            <input
              id="set-subtitle"
              type="text"
              value={appSubtitle}
              onChange={(e) => setAppSubtitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="set-emp" className="block text-xs font-medium text-slate-700 mb-1">
              Default Employee / User Name
            </label>
            <input
              id="set-emp"
              type="text"
              value={defaultEmployeeName}
              onChange={(e) => setDefaultEmployeeName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="set-view" className="block text-xs font-medium text-slate-700 mb-1">
              View Mode
            </label>
            <select
              id="set-view"
              value={viewMode}
              onChange={(e) => setViewMode(e.target.value as ViewMode)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="desktop">Desktop View (Default)</option>
              <option value="mobile">Mobile View</option>
            </select>
          </div>

          <div>
            <label htmlFor="set-theme" className="block text-xs font-medium text-slate-700 mb-1">
              Theme Palette
            </label>
            <select
              id="set-theme"
              value={theme}
              onChange={(e) => setTheme(e.target.value as ThemePreset)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="navy-emerald">Navy Blue &amp; Emerald Green (Default)</option>
              <option value="slate-teal">Slate &amp; Teal</option>
              <option value="charcoal-forest">Charcoal &amp; Forest Green</option>
            </select>
          </div>

          <div>
            <label htmlFor="set-lang" className="block text-xs font-medium text-slate-700 mb-1">
              Language &amp; Layout Direction
            </label>
            <select
              id="set-lang"
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="en">English (LTR)</option>
              <option value="ur">اردو — Urdu (RTL)</option>
            </select>
          </div>

          <div>
            <label htmlFor="set-datefmt" className="block text-xs font-medium text-slate-700 mb-1">
              Date Format
            </label>
            <select
              id="set-datefmt"
              value={dateFormat}
              onChange={(e) => setDateFormat(e.target.value as DateFormatOption)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="DD-MMM-YYYY">DD-MMM-YYYY (20-Nov-2026)</option>
              <option value="DD/MM/YYYY">DD/MM/YYYY (20/11/2026)</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD (2026-11-20)</option>
            </select>
          </div>

          <div>
            <label htmlFor="set-currency" className="block text-xs font-medium text-slate-700 mb-1">
              Currency Label
            </label>
            <input
              id="set-currency"
              type="text"
              value={currencyLabel}
              onChange={(e) => setCurrencyLabel(e.target.value)}
              placeholder="PKR or Rs"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>
      </section>

      {/* Module Rules (Purchase & Leave) */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <h2 className="text-base font-semibold text-slate-900">Purchase &amp; Leave Rules</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label htmlFor="set-maund" className="block text-xs font-medium text-slate-700 mb-1">
              1 Maund equals (KG)
            </label>
            <input
              id="set-maund"
              type="number"
              min="1"
              value={maundToKg}
              onChange={(e) => setMaundToKg(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label htmlFor="set-cl" className="block text-xs font-medium text-slate-700 mb-1">
              Default Annual Casual Leave (CL)
            </label>
            <input
              id="set-cl"
              type="number"
              step="0.5"
              value={defaultCL}
              onChange={(e) => setDefaultCL(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label htmlFor="set-sl" className="block text-xs font-medium text-slate-700 mb-1">
              Default Annual Sick Leave (SL)
            </label>
            <input
              id="set-sl"
              type="number"
              step="0.5"
              value={defaultSL}
              onChange={(e) => setDefaultSL(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div>
            <label htmlFor="set-cplexp" className="block text-xs font-medium text-slate-700 mb-1">
              CPL Lot Expiry (Days)
            </label>
            <input
              id="set-cplexp"
              type="number"
              min="1"
              value={cplExpiryDays}
              onChange={(e) => setCplExpiryDays(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-6 pt-2 text-sm text-slate-700">
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={confirmBeforeDelete}
              onChange={(e) => setConfirmBeforeDelete(e.target.checked)}
            />
            <span>Ask confirmation before deleting records</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={allowNegativeLeaveOverride}
              onChange={(e) => setAllowNegativeLeaveOverride(e.target.checked)}
            />
            <span>Allow admin negative leave balance override</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={allowNegativePurchase}
              onChange={(e) => setAllowNegativePurchase(e.target.checked)}
            />
            <span>Allow negative purchase adjustment entries</span>
          </label>
        </div>
      </section>

      {/* Dashboard 4-Card Dual-Metric Configurator */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900">Dashboard Summary Cards (Up to 2 Metrics per Card)</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure each of the four dashboard cards to display a primary metric and an optional secondary metric (for example, Loan Payable and Committee Remaining in the same card).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cards.map((card, idx) => (
            <div key={card.id} className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 space-y-3">
              <div className="text-xs font-semibold text-slate-700">Card {idx + 1}</div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Card Title</label>
                <input
                  type="text"
                  value={card.title}
                  onChange={(e) => updateCard(idx, { title: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Primary Metric</label>
                  <select
                    value={card.primaryMetric}
                    onChange={(e) => updateCard(idx, { primaryMetric: e.target.value as MetricKey })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                  >
                    {allMetricOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-600 mb-1">Secondary Metric (Optional)</label>
                  <select
                    value={card.secondaryMetric || ''}
                    onChange={(e) =>
                      updateCard(idx, { secondaryMetric: (e.target.value as MetricKey) || '' })
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                  >
                    <option value="">None</option>
                    {allMetricOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick links to Backup & Dynamic Settings */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl p-4">
        <div className="text-xs text-slate-600">
          Need to create new modules, custom fields, or formulas? Open Dynamic Settings. Need JSON Backup? Open Backup &amp; Restore.
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => navigate('dynamic_settings')}
            className="rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Open Dynamic Settings
          </button>
          <button
            type="button"
            onClick={() => navigate('backup')}
            className="rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Open Backup &amp; Restore
          </button>
        </div>
      </div>
    </form>
  );
};
