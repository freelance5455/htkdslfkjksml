import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, RefreshCw, Download, Camera, Check, Image as ImageIcon } from "lucide-react";

interface ImageStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSetAsHero?: (imageUrl: string) => void;
}

export const ImageStudioModal: React.FC<ImageStudioModalProps> = ({
  isOpen,
  onClose,
  onSetAsHero,
}) => {
  const [prompt, setPrompt] = useState(
    "Editorial food photography of a coastal sourdough avocado tartine on hand-thrown ceramic plate, warm morning sunlight, lime plaster background, natural textures, quiet luxury restaurant styling in Visakhapatnam."
  );
  const [aspectRatio, setAspectRatio] = useState<"1:1" | "4:3" | "16:9" | "3:4">("4:3");
  const [imageSize, setImageSize] = useState<"1K" | "2K" | "4K">("1K");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setErrorMsg(null);

    try {
      const res = await fetch("/api/images/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          aspectRatio,
          imageSize,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to generate image.");
      }

      setGeneratedImage(data.imageUrl);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An error occurred while generating culinary visual.");
    } finally {
      setIsGenerating(false);
    }
  };

  const PROMPT_TEMPLATES = [
    {
      label: "Artisanal Tartine",
      text: "Editorial food photography of a coastal sourdough avocado tartine on hand-thrown ceramic plate, warm morning sunlight, lime plaster background, quiet luxury styling.",
    },
    {
      label: "Araku Valley Coffee",
      text: "Steaming cortado in a matte stoneware cup beside whole roasted coffee cherries, soft window light, natural teak wood table, refined cafe ambiance in Vizag.",
    },
    {
      label: "Coastal Quinoa Bowl",
      text: "Warm tri-color quinoa bowl with charred pumpkin, shelled edamame, and citrus tahini dressing, overhead angled natural light, unbleached linen napkin.",
    },
    {
      label: "Dining Hall Sunlight",
      text: "Architectural interior photography of an airy wholesome eatery dining room, sunlight filtering through linen drapery onto solid teak tables, lime-washed plaster walls, leafy monstera plants.",
    },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[115] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#17201C]/75 backdrop-blur-xs"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          className="relative w-full max-w-3xl bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame overflow-hidden z-10 my-auto shadow-2xl flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-[#D8D0C2] flex items-center justify-between bg-[#F4F0E7]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#17201C] text-[#F4F0E7] flex items-center justify-center">
                <Camera className="w-4 h-4 text-[#9BAF82]" />
              </div>
              <div>
                <h3 className="font-serif text-xl text-[#17201C] leading-none">
                  Kaloreez Visual Dish Studio
                </h3>
                <span className="text-[10px] uppercase font-sans tracking-widest text-[#17201C]/60 mt-0.5 block">
                  Powered by gemini-3-pro-image-preview (1K / 2K / 4K)
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/80 border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-grow">
            {/* Presets */}
            <div>
              <div className="text-[11px] uppercase tracking-wider text-[#17201C]/60 font-semibold mb-2">
                Editorial Aesthetic Presets:
              </div>
              <div className="flex flex-wrap gap-2">
                {PROMPT_TEMPLATES.map((tpl, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setPrompt(tpl.text)}
                    className="px-3 py-1 rounded-full text-xs bg-[#F4F0E7] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer border border-[#D8D0C2]"
                  >
                    {tpl.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Prompt input */}
            <div>
              <label className="block text-xs uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1.5">
                Culinary Art Prompt
              </label>
              <textarea
                rows={3}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe dish, table setting, natural lighting, and ceramic styling..."
                className="w-full p-3.5 rounded-xs bg-white border border-[#D8D0C2] text-xs sm:text-sm font-sans text-[#17201C] focus:outline-none focus:border-[#9BAF82]"
              />
            </div>

            {/* Format Controls: Aspect Ratio & Size */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="block text-xs uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1.5">
                  Aspect Ratio
                </span>
                <div className="flex gap-2">
                  {(["4:3", "1:1", "16:9", "3:4"] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspectRatio(ratio)}
                      className={`px-3 py-1.5 text-xs rounded-xs border transition-colors cursor-pointer ${
                        aspectRatio === ratio
                          ? "bg-[#17201C] text-[#F4F0E7] border-[#17201C]"
                          : "bg-white text-[#17201C]/70 border-[#D8D0C2] hover:border-[#17201C]"
                      }`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-xs uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1.5">
                  Resolution Tier
                </span>
                <div className="flex gap-2">
                  {(["1K", "2K", "4K"] as const).map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setImageSize(size)}
                      className={`px-3 py-1.5 text-xs rounded-xs border transition-colors cursor-pointer ${
                        imageSize === size
                          ? "bg-[#17201C] text-[#F4F0E7] border-[#17201C]"
                          : "bg-white text-[#17201C]/70 border-[#D8D0C2] hover:border-[#17201C]"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 bg-[#B96D52]/10 border border-[#B96D52]/30 rounded-xs text-xs text-[#B96D52]">
                {errorMsg}
              </div>
            )}

            {/* Output Display */}
            {generatedImage ? (
              <div className="space-y-3 pt-2">
                <div className="relative aspect-[4/3] w-full bg-[#EAE4D7] rounded-sm overflow-hidden paper-frame border border-[#D8D0C2]">
                  <img
                    src={generatedImage}
                    alt="Generated Kaloreez food photography"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#17201C]/60">
                    Generated with Imagen 3 / Gemini Pro Image ({imageSize}, {aspectRatio})
                  </span>
                  <div className="flex items-center gap-2">
                    <a
                      href={generatedImage}
                      download="kaloreez_culinary.png"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border border-[#D8D0C2] bg-white text-[#17201C] hover:border-[#17201C]"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </a>
                  </div>
                </div>
              </div>
            ) : (
              <div className="border border-dashed border-[#D8D0C2] rounded-xs p-8 text-center bg-[#F4F0E7]/40 text-[#17201C]/50">
                <ImageIcon className="w-8 h-8 mx-auto mb-2 text-[#9BAF82] stroke-1" />
                <p className="text-xs">
                  Generated editorial food photography will appear here in high-resolution clarity.
                </p>
              </div>
            )}
          </div>

          {/* Action Footer */}
          <div className="px-6 py-4 border-t border-[#D8D0C2] bg-[#F4F0E7] flex items-center justify-between">
            <span className="text-xs text-[#17201C]/60 font-sans">
              Calibrated for quiet luxury styling & natural lighting
            </span>

            <button
              type="button"
              disabled={isGenerating || !prompt.trim()}
              onClick={handleGenerate}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-semibold uppercase tracking-widest hover:bg-[#9BAF82] hover:text-[#17201C] disabled:opacity-50 transition-colors cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing ({imageSize})...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-[#9BAF82]" />
                  <span>Render Photograph</span>
                </>
              )}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
