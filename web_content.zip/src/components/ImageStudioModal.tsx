import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Wand2,
  Image as ImageIcon,
  Sliders,
  Download,
  Check,
  X,
  RefreshCw,
  Upload,
  Eye,
  Flame,
  Layers,
  Palette,
  Maximize2,
  Sun,
  Contrast,
  Droplet,
  Shuffle,
  ArrowRight,
} from 'lucide-react';

interface ImageStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialImage?: string;
  onApplyBackground: (imageUrl: string) => void;
}

type StudioTab = 'generate' | 'edit';

interface StylePreset {
  id: string;
  name: string;
  promptSuffix: string;
  icon: string;
}

const STYLE_PRESETS: StylePreset[] = [
  { id: 'cinematic', name: 'Sinematik 4K', promptSuffix: ', cinematic lighting, ultra-detailed 8k photography, photorealistic, octane render, masterpiece', icon: '🎬' },
  { id: 'cyberpunk', name: 'Cyberpunk Neon', promptSuffix: ', cyberpunk aesthetic, glowing neon lights, futuristic city rain reflections, moody atmosphere', icon: '🌆' },
  { id: 'anime', name: 'Anime Studio Ghibli', promptSuffix: ', beautiful anime art style, makoto shinkai aesthetic, vibrant colors, scenic background, masterpiece', icon: '🍙' },
  { id: 'darkfantasy', name: 'Dark Fantasy', promptSuffix: ', dark epic fantasy art, ethereal lighting, mysterious moody mist, detailed digital illustration', icon: '🗡️' },
  { id: 'lofi', name: 'Lofi Pastel Chill', promptSuffix: ', cozy lofi room aesthetic, soft pastel colors, warm ambient lighting, peaceful mood', icon: '☕' },
  { id: 'scifi', name: 'Cosmic Galaxy', promptSuffix: ', deep space nebula, starlight cosmic dust, glowing vibrant celestial colors, astronomical view', icon: '🌌' },
];

const AI_EDIT_PRESETS = [
  { id: 'cyber_neon', name: 'Neon Cyberpunk', prompt: 'Add glowing neon reflections, rain soaked cyberpunk lighting, deep blue and magenta atmosphere' },
  { id: 'golden_sunset', name: 'Golden Hour', prompt: 'Bathe the scene in warm golden hour sunlight, dramatic soft evening shadows, atmospheric warmth' },
  { id: 'dark_noir', name: 'Moody Dark Noir', prompt: 'Dramatic high-contrast film noir, moody cinematic shadows, mysterious atmosphere' },
  { id: 'anime_paint', name: 'Anime Watercolor', prompt: 'Convert to vibrant anime illustration with soft hand-painted watercolor textures' },
  { id: 'retro_film', name: 'Vintage 35mm Film', prompt: 'Add vintage 1980s 35mm film grain, analog color grading, soft nostalgic glow' },
];

export const ImageStudioModal: React.FC<ImageStudioModalProps> = ({
  isOpen,
  onClose,
  initialImage,
  onApplyBackground,
}) => {
  const [activeTab, setActiveTab] = useState<StudioTab>('generate');
  
  // Generation State
  const [prompt, setPrompt] = useState('Cyberpunk neon city street with rain reflections, aesthetic wallpaper 4k');
  const [selectedStyle, setSelectedStyle] = useState('cyberpunk');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [sensorOff, setSensorOff] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [imageSeed, setImageSeed] = useState(Math.floor(Math.random() * 1000000));
  const [genError, setGenError] = useState<string | null>(null);

  // Edit State
  const [sourceImage, setSourceImage] = useState<string | null>(initialImage || null);
  const [aiEditPrompt, setAiEditPrompt] = useState('');
  const [isAiEditing, setIsAiEditing] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [sepia, setSepia] = useState(0);
  const [blur, setBlur] = useState(0);
  const [grayscale, setGrayscale] = useState(0);
  const [hueRotate, setHueRotate] = useState(0);
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    if (initialImage) {
      setSourceImage(initialImage);
    }
  }, [initialImage]);

  if (!isOpen) return null;

  // Handle in-app image generation
  const handleGenerateImage = () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setGenError(null);

    const styleObj = STYLE_PRESETS.find((s) => s.id === selectedStyle);
    const styleModifier = styleObj ? styleObj.promptSuffix : '';
    const fullPrompt = `${prompt.trim()}${styleModifier}`;

    let width = 1280;
    let height = 720;
    if (aspectRatio === '9:16') {
      width = 720;
      height = 1280;
    } else if (aspectRatio === '1:1') {
      width = 1024;
      height = 1024;
    }

    const newSeed = Math.floor(Math.random() * 10000000);
    setImageSeed(newSeed);

    // Direct in-app unrestricted generation URL with safe=false (Sensor Off) and nologo=true
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      fullPrompt
    )}?width=${width}&height=${height}&seed=${newSeed}&nologo=true${sensorOff ? '&safe=false' : ''}&model=flux`;

    // Preload image in memory to ensure it loads smoothly
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setGeneratedImageUrl(url);
      setIsGenerating(false);
    };
    img.onerror = () => {
      // Fallback without specific model parameter
      const fallbackUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
        fullPrompt
      )}?width=${width}&height=${height}&seed=${newSeed}&nologo=true`;
      setGeneratedImageUrl(fallbackUrl);
      setIsGenerating(false);
    };
    img.src = url;
  };

  // Switch to Edit tab with current generated image
  const handleSendToEditor = (imgUrl: string) => {
    setSourceImage(imgUrl);
    setActiveTab('edit');
    // Reset visual filter adjustments
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setSepia(0);
    setBlur(0);
    setGrayscale(0);
    setHueRotate(0);
  };

  // Perform AI Edit with prompt
  const handleAiEdit = (customInstruction?: string) => {
    const editInstruction = customInstruction || aiEditPrompt;
    if (!editInstruction.trim()) return;

    setIsAiEditing(true);

    const editSeed = Math.floor(Math.random() * 10000000);
    let width = 1280;
    let height = 720;
    if (aspectRatio === '9:16') {
      width = 720;
      height = 1280;
    }

    // AI Re-imagination based on edit instruction and prompt
    const enhancedPrompt = `${editInstruction.trim()}, based on ${prompt.trim()}, masterpiece quality, ultra-detailed, artistic transformation`;
    const editedUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      enhancedPrompt
    )}?width=${width}&height=${height}&seed=${editSeed}&nologo=true${sensorOff ? '&safe=false' : ''}&model=flux`;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setSourceImage(editedUrl);
      setIsAiEditing(false);
    };
    img.onerror = () => {
      setSourceImage(editedUrl);
      setIsAiEditing(false);
    };
    img.src = editedUrl;
  };

  // Render visual filter CSS string
  const getFilterStyle = () => {
    return `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) sepia(${sepia}%) blur(${blur}px) grayscale(${grayscale}%) hue-rotate(${hueRotate}deg)`;
  };

  // Export current edited image from canvas (bakes in all visual filters)
  const getProcessedImageDataUrl = (): Promise<string> => {
    return new Promise((resolve) => {
      if (!sourceImage) {
        resolve('');
        return;
      }

      // If no custom filters applied and image is valid, return directly
      if (
        brightness === 100 &&
        contrast === 100 &&
        saturation === 100 &&
        sepia === 0 &&
        blur === 0 &&
        grayscale === 0 &&
        hueRotate === 0
      ) {
        resolve(sourceImage);
        return;
      }

      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || 1280;
        canvas.height = img.naturalHeight || 720;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(sourceImage);
          return;
        }

        ctx.filter = getFilterStyle();
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        try {
          const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          resolve(dataUrl);
        } catch {
          resolve(sourceImage);
        }
      };
      img.onerror = () => resolve(sourceImage);
      img.src = sourceImage;
    });
  };

  // Apply to chat background
  const handleApplyToBackground = async (targetUrl?: string) => {
    let finalUrl = targetUrl;
    if (!finalUrl && activeTab === 'edit' && sourceImage) {
      finalUrl = await getProcessedImageDataUrl();
    } else if (!finalUrl && activeTab === 'generate' && generatedImageUrl) {
      finalUrl = generatedImageUrl;
    }

    if (finalUrl) {
      onApplyBackground(finalUrl);
      setAppliedSuccess(true);
      setTimeout(() => {
        setAppliedSuccess(false);
        onClose();
      }, 1200);
    }
  };

  // Upload image from computer into editor
  const handleUploadToEditor = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const res = event.target?.result as string;
      if (res) {
        setSourceImage(res);
        setActiveTab('edit');
      }
    };
    reader.readAsDataURL(file);
  };

  // Download image
  const handleDownload = async (imgUrl: string) => {
    try {
      let finalUrl = imgUrl;
      if (activeTab === 'edit') {
        finalUrl = await getProcessedImageDataUrl();
      }
      const a = document.createElement('a');
      a.href = finalUrl;
      a.download = `nexusai-background-${Date.now()}.jpg`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error('Gagal mengunduh gambar:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[94vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-sky-400 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <span>Studio Gambar &amp; Editor AI</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  Langsung di Aplikasi
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Generate gambar AI bebas tanpa sensor langsung di aplikasi, dan edit gambar dengan kecerdasan buatan.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-4">
          <button
            type="button"
            onClick={() => setActiveTab('generate')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'generate'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Gambar AI (Sensor Off)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('edit')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'edit'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wand2 className="w-4 h-4" />
            <span className="flex items-center gap-1.5">
              <span>Editor Gambar AI</span>
              {sourceImage && (
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </span>
          </button>
        </div>

        {/* Main Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs sm:text-sm">
          {/* TAB 1: GENERATE GAMBAR */}
          {activeTab === 'generate' && (
            <div className="space-y-4">
              {/* Prompt Controls */}
              <div className="p-4 rounded-xl bg-slate-850 border border-slate-750 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-200 text-xs flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Perintah / Prompt Gambar AI:</span>
                  </label>
                  
                  {/* Sensor Off Toggle */}
                  <label className="flex items-center gap-2 cursor-pointer bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-750">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-[11px] font-semibold text-amber-300">
                      Sensor Off (Mode Bebas)
                    </span>
                    <input
                      type="checkbox"
                      checked={sensorOff}
                      onChange={(e) => setSensorOff(e.target.checked)}
                      className="accent-amber-500 w-3.5 h-3.5 cursor-pointer"
                    />
                  </label>
                </div>

                <div className="relative">
                  <textarea
                    rows={3}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Ketik ide gambar yang ingin Anda buat... (Contoh: pemandangan kota cyberpunk dengan hujan neon, wallpaper aesthetic kamar lofi sore hari, naga fantasi di atas gunung es)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>

                {/* Quick Inspirations */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400 self-center">Inspirasi Cepat:</span>
                  {[
                    'Cyberpunk neon rain aesthetic',
                    'Anime cozy room sunset coffee',
                    'Ethereal deep galaxy nebula wallpaper',
                    'Dark fantasy dragon castle mist',
                    'Minimalist mountain lake reflection',
                  ].map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPrompt(p)}
                      className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 transition cursor-pointer"
                    >
                      {p}
                    </button>
                  ))}
                </div>

                {/* Style Presets */}
                <div className="space-y-1.5 pt-1">
                  <label className="block text-[11px] font-semibold text-slate-300">
                    Pilih Gaya Artistik (Preset):
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {STYLE_PRESETS.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => setSelectedStyle(st.id)}
                        className={`p-2.5 rounded-xl border cursor-pointer transition flex items-center gap-2 ${
                          selectedStyle === st.id
                            ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-xs'
                            : 'bg-slate-900 border-slate-750 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span className="text-base">{st.icon}</span>
                        <span className="text-xs font-medium">{st.name}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Aspect Ratio and Generate Button */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-medium">Aspek Rasio:</span>
                    {(['16:9', '9:16', '1:1'] as const).map((ratio) => (
                      <button
                        key={ratio}
                        type="button"
                        onClick={() => setAspectRatio(ratio)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono transition cursor-pointer border ${
                          aspectRatio === ratio
                            ? 'bg-indigo-600 text-white border-indigo-500'
                            : 'bg-slate-900 text-slate-400 border-slate-750 hover:text-white'
                        }`}
                      >
                        {ratio} {ratio === '16:9' ? '(Desktop)' : ratio === '9:16' ? '(HP)' : ''}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    disabled={isGenerating || !prompt.trim()}
                    onClick={handleGenerateImage}
                    className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 transition cursor-pointer active:scale-98"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-white" />
                        <span>Sedang Memproses Gambar AI...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        <span>Generate Gambar Sekarang</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Generated Image Result Display */}
              {isGenerating && (
                <div className="p-8 rounded-2xl bg-slate-950/80 border border-indigo-500/30 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-indigo-600/20 border border-indigo-500/50 flex items-center justify-center text-indigo-400 animate-pulse">
                    <RefreshCw className="w-6 h-6 animate-spin" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">
                      Membangun Gambar dengan AI...
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Menggunakan model AI visual tanpa sensor langsung di dalam aplikasi. Gambar akan muncul otomatis dalam beberapa detik.
                    </p>
                  </div>
                </div>
              )}

              {generatedImageUrl && !isGenerating && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in zoom-in-95 duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="font-bold text-xs sm:text-sm text-white">
                        Hasil Gambar AI (Langsung Tersedia)
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      Seed: #{imageSeed}
                    </span>
                  </div>

                  {/* Image Display */}
                  <div className="relative rounded-xl overflow-hidden border border-slate-700 bg-black flex items-center justify-center max-h-[420px]">
                    <img
                      src={generatedImageUrl}
                      alt="Hasil Generate AI"
                      className="w-full h-full object-contain max-h-[420px]"
                    />
                  </div>

                  {/* Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleGenerateImage}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-xs text-slate-300 hover:text-white transition cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Variasi Baru</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownload(generatedImageUrl)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-xs text-slate-300 hover:text-white transition cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Unduh</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSendToEditor(generatedImageUrl)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-300 border border-purple-500/40 text-xs font-semibold transition cursor-pointer"
                      >
                        <Wand2 className="w-3.5 h-3.5" />
                        <span>Buka di Editor AI</span>
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleApplyToBackground(generatedImageUrl)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 transition cursor-pointer"
                    >
                      {appliedSuccess ? (
                        <>
                          <Check className="w-4 h-4 text-white" />
                          <span>Berhasil Diterapkan!</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Terapkan sebagai Wallpaper Chat</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: AI EDITOR GAMBAR */}
          {activeTab === 'edit' && (
            <div className="space-y-4">
              {/* Select/Upload Source Image if none */}
              {!sourceImage ? (
                <div className="p-8 rounded-2xl bg-slate-950 border-2 border-dashed border-slate-750 text-center space-y-4">
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">
                      Belum Ada Gambar yang Dipilih untuk Diedit
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Generate gambar terlebih dahulu di tab sebelah, atau unggah foto dari komputer Anda untuk diedit dengan AI.
                    </p>
                  </div>
                  <div className="flex justify-center gap-3">
                    <label className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs cursor-pointer shadow-md transition">
                      <Upload className="w-4 h-4" />
                      <span>Unggah Foto dari Perangkat</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleUploadToEditor}
                        className="hidden"
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => setActiveTab('generate')}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold cursor-pointer transition"
                    >
                      Generate Gambar AI
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                  {/* Left Column: Image Canvas / Preview */}
                  <div className="lg:col-span-7 space-y-3">
                    <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 flex items-center justify-center min-h-[300px] max-h-[460px]">
                      <img
                        ref={imgRef}
                        src={sourceImage}
                        alt="Gambar untuk diedit"
                        className="w-full h-full object-contain max-h-[460px] transition-all duration-150"
                        style={{
                          filter: getFilterStyle(),
                        }}
                      />
                      {isAiEditing && (
                        <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center gap-2 text-white">
                          <RefreshCw className="w-8 h-8 animate-spin text-purple-400" />
                          <span className="text-xs font-bold">Sedang Mengedit dengan AI...</span>
                        </div>
                      )}
                    </div>

                    {/* Quick Image Controls */}
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <label className="flex items-center gap-1.5 hover:text-white cursor-pointer transition">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Ganti Gambar</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleUploadToEditor}
                          className="hidden"
                        />
                      </label>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setBrightness(100);
                            setContrast(100);
                            setSaturation(100);
                            setSepia(0);
                            setBlur(0);
                            setGrayscale(0);
                            setHueRotate(0);
                          }}
                          className="hover:text-amber-400 transition cursor-pointer"
                        >
                          Reset Filter
                        </button>
                        <span>•</span>
                        <button
                          type="button"
                          onClick={() => handleDownload(sourceImage)}
                          className="hover:text-sky-400 transition cursor-pointer"
                        >
                          Unduh Hasil
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: AI Edit & Filter Sliders */}
                  <div className="lg:col-span-5 space-y-4">
                    {/* SECTION: AI PROMPT EDITING */}
                    <div className="p-3.5 rounded-xl bg-slate-850 border border-slate-750 space-y-2.5">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                        <Wand2 className="w-4 h-4 text-purple-400" />
                        <span>Edit Gambar dengan Perintah AI:</span>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={aiEditPrompt}
                          onChange={(e) => setAiEditPrompt(e.target.value)}
                          placeholder="Contoh: tambahkan hujan neon, buat lebih gelap, ubah jadi gaya lukisan..."
                          className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-purple-500"
                        />
                        <button
                          type="button"
                          disabled={isAiEditing || !aiEditPrompt.trim()}
                          onClick={() => handleAiEdit()}
                          className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold text-xs transition cursor-pointer shrink-0"
                        >
                          Edit AI
                        </button>
                      </div>

                      {/* Quick AI Presets */}
                      <div className="space-y-1 pt-1">
                        <span className="text-[10px] text-slate-400">Filter Cerdas AI:</span>
                        <div className="flex flex-wrap gap-1">
                          {AI_EDIT_PRESETS.map((p) => (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => {
                                setAiEditPrompt(p.prompt);
                                handleAiEdit(p.prompt);
                              }}
                              className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-[10px] text-purple-200 transition cursor-pointer"
                            >
                              {p.name}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* SECTION: VISUAL SLIDERS */}
                    <div className="p-3.5 rounded-xl bg-slate-850 border border-slate-750 space-y-3">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                        <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Pengaturan Visual Langsung:</span>
                      </div>

                      {/* Brightness */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>Kecerahan (Brightness):</span>
                          <span className="font-mono text-indigo-400">{brightness}%</span>
                        </div>
                        <input
                          type="range"
                          min="40"
                          max="180"
                          value={brightness}
                          onChange={(e) => setBrightness(Number(e.target.value))}
                          className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Contrast */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>Kontras (Contrast):</span>
                          <span className="font-mono text-indigo-400">{contrast}%</span>
                        </div>
                        <input
                          type="range"
                          min="40"
                          max="180"
                          value={contrast}
                          onChange={(e) => setContrast(Number(e.target.value))}
                          className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Saturation */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>Saturasi Warna:</span>
                          <span className="font-mono text-indigo-400">{saturation}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="200"
                          value={saturation}
                          onChange={(e) => setSaturation(Number(e.target.value))}
                          className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Hue Rotate */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>Pergeseran Spektrum Warna (Hue):</span>
                          <span className="font-mono text-indigo-400">{hueRotate}°</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="360"
                          value={hueRotate}
                          onChange={(e) => setHueRotate(Number(e.target.value))}
                          className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Blur Effect */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>Efek Blur Gambar:</span>
                          <span className="font-mono text-indigo-400">{blur}px</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="10"
                          value={blur}
                          onChange={(e) => setBlur(Number(e.target.value))}
                          className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                        />
                      </div>
                    </div>

                    {/* Apply Button */}
                    <button
                      type="button"
                      onClick={() => handleApplyToBackground()}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 transition cursor-pointer"
                    >
                      {appliedSuccess ? (
                        <>
                          <Check className="w-4 h-4 text-white" />
                          <span>Berhasil Diterapkan ke Chat!</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Simpan &amp; Jadikan Wallpaper Chat</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
