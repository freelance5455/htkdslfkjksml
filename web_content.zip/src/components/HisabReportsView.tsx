import React, { useMemo } from 'react';
import { Download } from 'lucide-react';
import { Client, ExpenseItem, Payment, StudioSettings } from '../types';
import { downloadFinancialReportPDF } from '../utils/exports';
import { formatINR, getClientPending } from '../utils/formatters';

interface HisabReportsViewProps {
  clients: Client[];
  payments: Payment[];
  expenses: ExpenseItem[];
  settings: StudioSettings;
  onToast: (msg: string) => void;
}

export const HisabReportsView: React.FC<HisabReportsViewProps> = ({
  clients,
  payments,
  expenses,
  settings,
  onToast,
}) => {
  const summary = useMemo(() => {
    const totalBilled = clients.reduce((sum, c) => sum + c.totalAmount, 0);
    const pendingAmount = clients.reduce((sum, c) => sum + getClientPending(c), 0);
    const collectedAmount = Math.max(0, totalBilled - pendingAmount);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = collectedAmount - totalExpenses;

    return {
      totalBilled,
      collectedAmount,
      pendingAmount,
      totalExpenses,
      netProfit,
    };
  }, [clients, expenses]);

  const monthlySeries = useMemo(() => {
    const map = new Map<string, { label: string; income: number; expense: number }>();

    const addMonth = (dateStr: string) => {
      const d = new Date(dateStr);
      const key = Number.isNaN(d.getTime())
        ? 'Current'
        : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = Number.isNaN(d.getTime())
        ? 'Current'
        : d.toLocaleDateString('en-IN', { month: 'short' });
      if (!map.has(key)) {
        map.set(key, { label, income: 0, expense: 0 });
      }
      return key;
    };

    payments.forEach((p) => {
      const k = addMonth(p.date);
      const entry = map.get(k);
      if (entry) entry.income += p.amount;
    });

    expenses.forEach((e) => {
      const k = addMonth(e.date);
      const entry = map.get(k);
      if (entry) entry.expense += e.amount;
    });

    const items = Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6)
      .map(([, val]) => val);

    const maxVal = Math.max(1, ...items.map((m) => Math.max(m.income, m.expense)));
    return { items, maxVal };
  }, [payments, expenses]);

  const handleExportPDF = () => {
    downloadFinancialReportPDF({
      settings,
      ...summary,
      clients,
      expenses,
    });
    onToast(`Exported ${settings.companyName} Financial Report PDF`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">
            Financial Reports
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {settings.companyName} revenue, collections, expenses, and net profit ledger
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportPDF}
          className="btn-primary h-10 px-4 text-xs sm:text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <Download className="w-4 h-4" strokeWidth={1.75} />
          <span>Export Report PDF</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Profit & Loss Summary Surface */}
        <div className="lg:col-span-5 surface-card p-6 flex flex-col justify-between space-y-5">
          <div>
            <div className="pb-3 border-b border-slate-200 space-y-0.5">
              <h2 className="font-display text-base font-bold text-[#0F172A]">
                Profit &amp; Loss Summary
              </h2>
              <p className="text-xs text-slate-500">Solo owner account · {settings.adminName}</p>
            </div>

            <div className="divide-y divide-slate-200 text-sm">
              <div className="py-3.5 flex items-center justify-between">
                <span className="text-slate-600">Total Contract Revenue</span>
                <span className="font-display font-bold text-[#0F172A] tabular-nums">
                  {formatINR(summary.totalBilled)}
                </span>
              </div>

              <div className="py-3.5 flex items-center justify-between">
                <span className="text-slate-600">Collected Payments</span>
                <span className="font-display font-bold text-emerald-700 tabular-nums">
                  {formatINR(summary.collectedAmount)}
                </span>
              </div>

              <div className="py-3.5 flex items-center justify-between">
                <span className="text-slate-600">Pending Receivables</span>
                <span
                  className={`font-display font-bold tabular-nums ${
                    summary.pendingAmount > 0 ? 'text-red-600' : 'text-[#0F172A]'
                  }`}
                >
                  {formatINR(summary.pendingAmount)}
                </span>
              </div>

              <div className="py-3.5 flex items-center justify-between">
                <span className="text-slate-600">Business Expenses</span>
                <span className="font-display font-bold text-red-600 tabular-nums">
                  - {formatINR(summary.totalExpenses)}
                </span>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-xs font-semibold text-[#0F172A]">Net Profit</p>
                  <p className="text-[11px] text-slate-500">Collected minus expenses</p>
                </div>
                <span
                  className={`font-display text-2xl font-bold tabular-nums ${
                    summary.netProfit > 0
                      ? 'text-emerald-700'
                      : summary.netProfit < 0
                        ? 'text-red-600'
                        : 'text-[#0F172A]'
                  }`}
                >
                  {formatINR(summary.netProfit)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Cashflow Chart Surface */}
        <div className="lg:col-span-7 surface-card p-6 flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-200">
            <div className="space-y-0.5">
              <h2 className="font-display text-base font-bold text-[#0F172A]">Monthly Cashflow</h2>
              <p className="text-xs text-slate-500">Collected Payments vs Expenses (₹)</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="inline-flex items-center gap-1.5 text-[#0F172A] font-medium">
                <span className="w-2.5 h-2.5 rounded-[3px] bg-[#0F172A]" />
                Payments
              </span>
              <span className="inline-flex items-center gap-1.5 text-slate-600 font-medium">
                <span className="w-2.5 h-2.5 rounded-[3px] bg-slate-300" />
                Expenses
              </span>
            </div>
          </div>

          {monthlySeries.items.length === 0 ? (
            <div className="my-auto py-16 text-center space-y-1">
              <p className="text-sm text-slate-600">No payments or expenses recorded yet.</p>
              <p className="text-xs text-slate-400">
                Monthly bars appear automatically as you record transactions.
              </p>
            </div>
          ) : (
            <div className="mt-6 h-60 flex items-end justify-around gap-4 pt-6 border-b border-slate-200 pb-3">
              {monthlySeries.items.map((item) => {
                const incH =
                  item.income > 0
                    ? Math.max(8, Math.round((item.income / monthlySeries.maxVal) * 170))
                    : 3;
                const expH =
                  item.expense > 0
                    ? Math.max(8, Math.round((item.expense / monthlySeries.maxVal) * 170))
                    : 3;

                return (
                  <div key={item.label} className="flex flex-col items-center gap-2 min-w-[56px]">
                    <div className="flex items-end justify-center gap-2 h-44">
                      <div
                        title={`Payments: ${formatINR(item.income)}`}
                        className="w-5 sm:w-7 rounded-t-[6px] bg-[#0F172A] transition-all duration-200 ease-out"
                        style={{ height: `${incH}px` }}
                      />
                      <div
                        title={`Expenses: ${formatINR(item.expense)}`}
                        className="w-5 sm:w-7 rounded-t-[6px] bg-slate-300 transition-all duration-200 ease-out"
                        style={{ height: `${expH}px` }}
                      />
                    </div>
                    <div className="text-center space-y-0.5">
                      <p className="text-xs font-semibold text-[#0F172A]">{item.label}</p>
                      <p className="text-[10px] text-slate-500 tabular-nums">
                        {formatINR(item.income)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="pt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
            <span>
              Collected:{' '}
              <strong className="text-emerald-700 tabular-nums">
                {formatINR(summary.collectedAmount)}
              </strong>
            </span>
            <span>
              Receivable:{' '}
              <strong className="text-red-600 tabular-nums">
                {formatINR(summary.pendingAmount)}
              </strong>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
