/**
 * GODEX Phase 1 - Project Hub Dashboard with Live Intelligence Telemetry
 * Displays real project health, stack characteristics, symbol counts, AST verification, and quick actions.
 */

import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  ShieldCheck, 
  Code2, 
  Layers, 
  Play, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  Cpu,
  Boxes,
  Zap,
  Activity,
  FileCode,
  Search,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { ProjectTemplate, WorkspaceViewMode, VerificationReport, TaskState } from '../types';
import { STARTER_PROJECTS } from '../templates/starterProjects';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { ProjectIntelligenceState } from '../intelligence/types';

interface GodexDashboardViewProps {
  currentProjectTitle: string;
  files: Record<string, string>;
  taskState: TaskState;
  verificationReport: VerificationReport | null;
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  onOpenTemplates: () => void;
  onSelectTemplate: (template: ProjectTemplate) => void;
  onRunVerification: () => void;
  onPromptAgent: (prompt: string) => void;
}

export const GodexDashboardView: React.FC<GodexDashboardViewProps> = ({
  currentProjectTitle,
  files,
  taskState,
  verificationReport,
  onSelectWorkspaceView,
  onOpenTemplates,
  onSelectTemplate,
  onRunVerification,
  onPromptAgent
}) => {
  const [intelState, setIntelState] = useState<ProjectIntelligenceState>(ProjectIntelligence.getState());
  const [isRescanning, setIsRescanning] = useState(false);

  useEffect(() => {
    const unsub = ProjectIntelligence.subscribe(state => {
      setIntelState(state);
    });
    return unsub;
  }, []);

  const handleTriggerRescan = async () => {
    setIsRescanning(true);
    await ProjectIntelligence.scanProject(files);
    setIsRescanning(false);
  };

  const fileKeys = Object.keys(files);
  const { metadata, health, graph } = intelState;

  const subsystems = [
    {
      name: 'Project Intelligence Engine',
      status: intelState.status === 'READY' ? `${health.score}% HEALTH` : intelState.status,
      color: health.score >= 90 
        ? 'text-emerald-400 border-emerald-500/40 bg-emerald-950/20' 
        : (health.score >= 70 ? 'text-amber-400 border-amber-500/40 bg-amber-950/20' : 'text-rose-400 border-rose-500/40 bg-rose-950/20'),
      description: `${health.totalSymbols} symbols indexed across ${metadata.totalFiles} files. ${health.circularDependencyCount} cycles, ${health.brokenImportCount} broken imports.`
    },
    {
      name: 'Authoritative Workspace',
      status: 'SYNCHRONIZED',
      color: 'text-cyan-400 border-cyan-500/40 bg-cyan-950/20',
      description: `${fileKeys.length} files tracked (${(metadata.totalBytes / 1024).toFixed(1)} KB, ${metadata.totalLines} lines) with SHA verification.`
    },
    {
      name: 'Execution & Preview Sandbox',
      status: 'RUNNING',
      color: 'text-indigo-400 border-indigo-500/40 bg-indigo-950/20',
      description: `Isolated runtime with React 19, Tailwind CSS v4, and dynamic DOM verification.`
    },
    {
      name: 'Evidence Verification Gate',
      status: verificationReport?.passed ? '5/5 VERIFIED' : (verificationReport ? 'FAILED' : 'NOT RUN'),
      color: verificationReport?.passed ? 'text-emerald-400 border-emerald-500/40 bg-emerald-950/20' : 'text-neutral-400 border-neutral-700 bg-neutral-900',
      description: 'Zero fake verification: AST syntax, build outputs, DOM root assertion, and console error checks.'
    }
  ];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#08090D] overflow-y-auto select-none font-sans p-4 md:p-8 space-y-8">
      {/* Hero Banner */}
      <div className="relative p-6 md:p-8 rounded-2xl bg-gradient-to-br from-[#0D121D] via-[#090C13] to-[#07090F] border border-[#1E2638] overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Bot className="w-64 h-64 text-cyan-400" />
        </div>

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#141A28] border border-cyan-500/30 text-cyan-300 font-mono text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>GODEX PHASE 1 INTELLIGENCE ENGINE</span>
          </div>

          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-tight">
            Autonomous AI Software Engineering Workspace
          </h1>

          <p className="text-sm text-neutral-300 leading-relaxed font-sans">
            Deep project understanding through AST parsing, module graph indexing, and contextual AI grounding. 
            Build, iterate, and verify full applications with verified project intelligence.
          </p>

          {/* Primary Quick Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onSelectWorkspaceView('editor')}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs transition-all shadow-md flex items-center gap-2"
            >
              <Code2 className="w-4 h-4" />
              <span>Open Source Editor</span>
            </button>

            <button
              onClick={() => onSelectWorkspaceView('architecture')}
              className="px-4 py-2 rounded-lg bg-[#141A26] hover:bg-[#1C2538] border border-[#222E46] text-purple-300 font-semibold text-xs transition-all flex items-center gap-2"
            >
              <Layers className="w-4 h-4 text-purple-400" />
              <span>Module & Symbol Graph</span>
            </button>

            <button
              onClick={() => onSelectWorkspaceView('preview')}
              className="px-4 py-2 rounded-lg bg-[#141A26] hover:bg-[#1C2538] border border-[#222E46] text-cyan-300 font-semibold text-xs transition-all flex items-center gap-2"
            >
              <Play className="w-4 h-4 text-cyan-400" />
              <span>Open Live Preview</span>
            </button>

            <button
              onClick={handleTriggerRescan}
              disabled={isRescanning}
              className="px-3 py-2 rounded-lg bg-[#111624] hover:bg-[#182030] border border-[#1E2738] text-neutral-300 font-semibold text-xs transition-all flex items-center gap-1.5"
              title="Rescan and re-index project AST"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isRescanning ? 'animate-spin' : ''}`} />
              <span>{isRescanning ? 'Indexing...' : 'Re-index AST'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Project Characteristics & Intelligence Summary Card */}
      <div className="p-5 rounded-xl bg-[#0A0D15] border border-[#1B2232] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#161D2C] pb-3">
          <div className="flex items-center gap-2">
            <Boxes className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono font-bold text-neutral-200 uppercase tracking-wider">
              Discovered Project Characteristics & Health
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#121826] text-cyan-300 border border-cyan-800/40">
              FRAMEWORK: {metadata.framework.toUpperCase()}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#121826] text-purple-300 border border-purple-800/40">
              RUNTIME: {metadata.runtime.toUpperCase()}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#121826] text-emerald-300 border border-emerald-800/40">
              BUILD: {metadata.buildTool.toUpperCase()}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 font-mono text-xs">
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Health Score</div>
            <div className={`text-base font-bold ${health.score >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {health.score}% ({health.rating})
            </div>
          </div>
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Total Symbols</div>
            <div className="text-base font-bold text-cyan-300">{health.totalSymbols}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Components</div>
            <div className="text-base font-bold text-indigo-300">{health.totalComponents}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Graph Nodes</div>
            <div className="text-base font-bold text-purple-300">{graph.nodes.length}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Lines of Code</div>
            <div className="text-base font-bold text-neutral-200">{metadata.totalLines.toLocaleString()}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#0E121B] border border-[#1A2230]">
            <div className="text-[10px] text-neutral-500 uppercase">Secret Leaks</div>
            <div className={`text-base font-bold ${health.secretLeakCount === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {health.secretLeakCount === 0 ? '0 (Clean)' : `${health.secretLeakCount} DETECTED`}
            </div>
          </div>
        </div>

        {/* Health Issues & Diagnostics list if any */}
        {health.issues.length > 0 && (
          <div className="pt-2 border-t border-[#161D2C] space-y-2">
            <div className="text-[11px] font-mono text-neutral-400 uppercase font-bold flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>Static Diagnostic Alerts ({health.issues.length})</span>
            </div>
            <div className="space-y-1.5">
              {health.issues.slice(0, 3).map((issue) => (
                <div key={issue.id} className="p-2.5 rounded-lg bg-[#111622] border border-[#1E283A] flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <span className="font-semibold text-white">{issue.title}</span>
                    <p className="text-[11px] text-neutral-400">{issue.message}</p>
                  </div>
                  {issue.filePath && (
                    <span className="font-mono text-[10px] text-cyan-400 bg-[#161F2E] px-2 py-0.5 rounded border border-[#222E44]">
                      {issue.filePath}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Subsystems Telemetry Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
            Subsystem Operational Telemetry
          </span>
          <span className="text-[11px] font-mono text-neutral-500">
            Real State Monitoring
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {subsystems.map((sub, i) => (
            <div
              key={i}
              className="p-4 rounded-xl bg-[#0A0D15] border border-[#1A2232] space-y-2 flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-200">{sub.name}</span>
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border ${sub.color}`}>
                    {sub.status}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed font-sans">{sub.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Starter Applications Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
            Switch Application Blueprint
          </span>
          <button
            onClick={onOpenTemplates}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300"
          >
            View All Starters →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {STARTER_PROJECTS.slice(0, 3).map((tmpl) => {
            const isCurrent = currentProjectTitle === tmpl.title;
            return (
              <div
                key={tmpl.id}
                onClick={() => onSelectTemplate(tmpl)}
                className={`p-4 rounded-xl border transition-all cursor-pointer space-y-3 group ${
                  isCurrent
                    ? 'bg-[#101622] border-cyan-500/50 shadow-md shadow-cyan-950/40'
                    : 'bg-[#0A0D15] border-[#1A2232] hover:border-[#28354D]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#131926] text-cyan-300 border border-[#202B3F] font-semibold">
                    {tmpl.badge}
                  </span>
                  {isCurrent && (
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                      <CheckCircle2 className="w-3 h-3" />
                      ACTIVE
                    </span>
                  )}
                </div>

                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {tmpl.title}
                  </h3>
                  <p className="text-xs text-neutral-400 line-clamp-2">{tmpl.description}</p>
                </div>

                <div className="pt-2 border-t border-[#161C28] flex items-center justify-between text-[10px] font-mono text-neutral-500">
                  <span>{Object.keys(tmpl.files).length} files</span>
                  <span className="text-cyan-400 group-hover:underline">Load Blueprint →</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
