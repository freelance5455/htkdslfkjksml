import { useEffect } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ResetConfirmModalProps {
  open: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ResetConfirmModal({ open, onConfirm, onCancel }: ResetConfirmModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reset-modal-title"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-[#dce6e0] bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#fff0ef] text-[#b42318]">
              <AlertTriangle className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h3 id="reset-modal-title" className="text-base font-bold text-[#16221c]">
                تمام ڈیٹا ری سیٹ کریں
              </h3>
              <p className="mt-1 text-xs text-[#64736b]">
                یہ عمل واپس نہیں ہو سکتا
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="بند کریں"
            className="flex h-9 w-9 items-center justify-center rounded-lg text-[#64736b] transition-colors hover:bg-[#f2f6f4] hover:text-[#16221c] focus-visible:outline-2 focus-visible:outline-[#123b32]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-4 text-sm leading-7 text-[#37463e]">
          کیا آپ واقعی تمام پارٹنرز کے اکاؤنٹس، کل منافع، کٹا ہوا ٹیکس اور مکمل ٹرانزیکشن ہسٹری ختم کرنا چاہتے ہیں؟
        </p>

        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[40px] rounded-xl border border-[#d6e0da] bg-white px-4 py-2 text-sm font-semibold text-[#16221c] transition-colors hover:bg-[#f4f7f5] focus-visible:outline-2 focus-visible:outline-[#123b32] whitespace-nowrap shrink-0"
          >
            منسوخ کریں
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="min-h-[40px] rounded-xl bg-[#b42318] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#911d14] focus-visible:outline-2 focus-visible:outline-[#b42318] whitespace-nowrap shrink-0"
          >
            جی ہاں، ری سیٹ کریں
          </button>
        </div>
      </div>
    </div>
  );
}
