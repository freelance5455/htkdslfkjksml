import { useMemo } from 'react';
import {
  Award,
  BookOpen,
  Brain,
  CalendarDays,
  CheckCircle2,
  Download,
  Flame,
  LogIn,
  MessageSquareText,
  ShieldCheck,
  Snowflake,
  Sparkles,
  Target,
  Trophy,
  UserPlus,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import { BANDS, BAND_META } from '../data/constants';
import type { CefrBand, DailyPlanStepId, PersistedSettings, VocabStore } from '../types';
import {
  build30DayHeatmap,
  computeAchievementBadges,
  getUnlockedCertificateBands,
} from '../utils/learningFeaturesLogic';
import { getSrsStats } from '../utils/srsLogic';
import { todayStr } from '../utils/storage';
import { getBandDoneCount, getBandSubCount } from '../utils/vocabLogic';
import { DailyPlanCard } from './DailyPlanCard';

interface StatsViewProps {
  store: VocabStore;
  settings: PersistedSettings;
  onStartDueSrsReview: () => void;
  onReviewMistakes: () => void;
  onOpenMistakeFixer: () => void;
  onOpenCertificate: (band: CefrBand, reasonAr: string) => void;
  onStartDailyPlanStep: (stepId: DailyPlanStepId) => void;
  onOpenOnboarding: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
  onToast: (msg: string) => void;
}

export function StatsView({
  store,
  settings,
  onStartDueSrsReview,
  onReviewMistakes,
  onOpenMistakeFixer,
  onOpenCertificate,
  onStartDailyPlanStep,
  onOpenOnboarding,
  onOpenAuth,
  onOpenPlacement,
  onToast,
}: StatsViewProps) {
  const { user, signingIn, authError, signInWithGoogle } = useAuth();
  const { t } = useI18n();
  const today = todayStr();
  const placement = settings.placementResult;

  const doneAll = Object.values(settings.completed).filter((p) => p >= 80).length;
  const totalSubsAll = BANDS.reduce(
    (acc, b) => acc + getBandSubCount(store, b, settings.levelSize),
    0
  );
  const goalPct = Math.min(
    100,
    Math.round((settings.todayCount / Math.max(1, settings.dailyGoal)) * 100)
  );
  const srsStats = getSrsStats(settings.srsCards || {});
  const masteredSet = new Set(settings.mastered);

  const heatmapCells = useMemo(
    () => build30DayHeatmap(settings.studyHistory),
    [settings.studyHistory]
  );
  const activeDays30 = useMemo(
    () => heatmapCells.filter((c) => c.count > 0).length,
    [heatmapCells]
  );
  const badges = useMemo(() => computeAchievementBadges(settings), [settings]);
  const unlockedCerts = useMemo(
    () => getUnlockedCertificateBands(settings, store),
    [settings, store]
  );

  const handleSignIn = async () => {
    const ok = await signInWithGoogle();
    if (ok) onToast('تم ربط إحصائياتك بحسابك السحابي');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
            الإحصائيات وتقدمك الشخصي
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            متابعة شاملة لمستواك في الكلمات والجمل وبطاقات أنكي والشهادات
          </p>
        </div>

        {user ? (
          <div className="inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>متزامن مع حساب {user.displayName || 'Google'}</span>
          </div>
        ) : (
          <button
            type="button"
            disabled={signingIn}
            onClick={() => void handleSignIn()}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-50"
          >
            <LogIn className="h-4 w-4" aria-hidden="true" />
            <span>سجّل الدخول لحفظ إحصائياتك</span>
          </button>
        )}
      </div>

      {authError && !user && (
        <div
          role="alert"
          className="rounded-2xl border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-xs font-bold leading-relaxed text-rose-600 dark:text-rose-300"
        >
          {authError}
        </div>
      )}

      {/* Daily Goal Summary Card ("هدف اليوم") moved from Home */}
      <section data-testid="stats-daily-goal-card" className="tmn-card rounded-3xl p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h2 className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-slate-50 sm:text-xl">
                {t.dailyGoalTitle}:{' '}
                <span className="font-code tabular-nums text-indigo-600 dark:text-indigo-400">
                  {settings.todayCount}
                </span>{' '}
                / <span className="font-code tabular-nums">{settings.dailyGoal}</span>{' '}
                {t.wordsLabel}
              </h2>
              <div className="flex items-center gap-2.5 text-xs font-bold tabular-nums text-slate-500 dark:text-slate-400 sm:text-sm">
                <span className="text-amber-600 dark:text-amber-400">
                  {settings.xp.toLocaleString('en-US')} XP
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-600 dark:text-emerald-400">
                  {settings.mastered.length} {t.masteredLabel}
                </span>
                {settings.bestStreak > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-300">
                      <Trophy className="h-3.5 w-3.5 text-amber-500" aria-hidden="true" />
                      {settings.streak || settings.bestStreak}
                    </span>
                  </>
                )}
              </div>
            </div>

            <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 sm:text-sm">
              <span className="font-code tabular-nums">
                {store.words.length.toLocaleString('en-US')}
              </span>{' '}
              CEFR (A0–C2) · {t.appTagline}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {placement ? (
              <button
                type="button"
                data-testid="home-placement-badge"
                onClick={onOpenPlacement}
                className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 text-xs font-extrabold text-emerald-700 transition-colors hover:bg-emerald-500/15 dark:text-emerald-300"
              >
                <Award className="h-4 w-4" aria-hidden="true" />
                <span>
                  CEFR {placement.cefrBand}
                  {placement.nextBand
                    ? ` · +${placement.pointsToNext}% → ${placement.nextBand}`
                    : ' (MAX)'}
                </span>
              </button>
            ) : (
              <button
                type="button"
                data-testid="home-placement-cta"
                onClick={onOpenPlacement}
                className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-xl border border-indigo-500/25 bg-indigo-500/10 px-3 text-xs font-extrabold text-indigo-700 transition-colors hover:bg-indigo-500/15 dark:text-indigo-300"
              >
                <Award className="h-4 w-4" aria-hidden="true" />
                <span>{t.takePlacementBtn}</span>
              </button>
            )}

            {!user && (
              <button
                type="button"
                data-testid="home-signup-btn"
                onClick={() => onOpenAuth('signup')}
                className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-xl bg-sky-500 px-3 text-xs font-extrabold text-slate-950 transition-colors hover:bg-sky-400"
              >
                <UserPlus className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{t.signUp}</span>
              </button>
            )}
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>{t.dailyProgress}</span>
            <span className="font-code tabular-nums">{goalPct}%</span>
          </div>
          <div className="tmn-progress-track h-2 w-full">
            <div className="tmn-progress-fill h-full" style={{ width: `${goalPct}%` }} />
          </div>
        </div>
      </section>

      {/* Guided Daily Study Plan ("مهمتك اليوم") moved from Home */}
      <DailyPlanCard
        settings={settings}
        srsDueCount={srsStats.dueNow}
        todayKey={today}
        onStartStep={onStartDailyPlanStep}
        onEditPlan={onOpenOnboarding}
      />

      {/* Primary 4-Column KPI Strip */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="tmn-card rounded-2xl p-4 text-center">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
            <BookOpen className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {store.words.length.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            إجمالي الكلمات
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4 text-center">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
            <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
            {settings.mastered.length.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            كلمات متقنة
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4 text-center">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
            <Sparkles className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-amber-600 dark:text-amber-400">
            {settings.xp.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            نقاط XP
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4 text-center">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
            <Award className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
            {doneAll}/{totalSubsAll}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            مستويات مكتملة
          </div>
        </div>
      </section>

      {/* Secondary Activity, Streak Freeze & Anki SRS Metrics */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="tmn-card rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>هدف اليوم</span>
            <Target className="h-4 w-4 text-indigo-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {settings.todayCount} / {settings.dailyGoal}
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className="h-full rounded-full bg-indigo-600 dark:bg-indigo-500"
              style={{ width: `${goalPct}%` }}
            />
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>السلسلة والتجميد</span>
            <Snowflake className="h-4 w-4 text-sky-500" aria-hidden="true" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
              {settings.streak} يوم
            </span>
            <span className="text-[11px] font-bold text-sky-600 dark:text-sky-400">
              · تجميد: {settings.streakFreezes ?? 1}
            </span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            الأفضل: <span className="font-code font-bold tabular-nums">{settings.bestStreak}</span> · حماية تلقائية ليوم واحد أسبوعياً
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>بطاقات أنكي (SRS)</span>
            <Brain className="h-4 w-4 text-cyan-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {srsStats.totalTracked}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            مستحقة الآن:{' '}
            <span className="font-code font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
              {srsStats.dueNow}
            </span>{' '}
            · راسخة: <span className="font-code font-bold tabular-nums">{srsStats.mature}</span>
          </div>
        </div>

        <div className="tmn-card rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>الجمل والأخطاء</span>
            <MessageSquareText className="h-4 w-4 text-emerald-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {(settings.practicedSentences || []).length} جملة
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            بنك الأخطاء:{' '}
            <span className="font-code font-bold text-rose-600 dark:text-rose-400 tabular-nums">
              {settings.mistakes.length}
            </span>{' '}
            · المفضلة:{' '}
            <span className="font-code font-bold tabular-nums">{settings.favorites.length}</span>
          </div>
        </div>
      </section>

      {/* Quick Action Row */}
      {(srsStats.dueNow > 0 || settings.mistakes.length > 0) && (
        <div className="flex flex-wrap items-center gap-3">
          {srsStats.dueNow > 0 && (
            <button
              type="button"
              onClick={onStartDueSrsReview}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-700"
            >
              <Brain className="h-4 w-4" aria-hidden="true" />
              <span>راجع بطاقات أنكي المستحقة ({srsStats.dueNow})</span>
            </button>
          )}
          {settings.mistakes.length > 0 && (
            <>
              <button
                type="button"
                data-testid="stats-mistake-fixer-btn"
                onClick={onOpenMistakeFixer}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-bold text-white hover:bg-emerald-700"
              >
                <Sparkles className="h-4 w-4" aria-hidden="true" />
                <span>جلسة إصلاح أخطائي السريع ({settings.mistakes.length})</span>
              </button>
              <button
                type="button"
                onClick={onReviewMistakes}
                className="inline-flex h-11 items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-5 text-sm font-bold text-rose-700 hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300"
              >
                <Flame className="h-4 w-4" aria-hidden="true" />
                <span>تدرّب على بنك الأخطاء</span>
              </button>
            </>
          )}
        </div>
      )}

      {/* 30-Day Activity Heatmap */}
      <section
        data-testid="stats-heatmap-section"
        className="tmn-card rounded-2xl p-5"
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4.5 w-4.5 text-emerald-500" aria-hidden="true" />
            <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
              خريطة نشاط آخر 30 يوماً
            </h2>
          </div>
          <span className="text-xs font-bold text-slate-500 tabular-nums dark:text-slate-400">
            {activeDays30} / 30 يوماً نشطاً
          </span>
        </div>

        <div className="grid grid-cols-10 gap-1.5 sm:grid-cols-15">
          {heatmapCells.map((cell) => {
            const bgClass =
              cell.level === 0
                ? 'bg-slate-100 dark:bg-slate-800/80'
                : cell.level === 1
                  ? 'bg-emerald-200 dark:bg-emerald-900/70'
                  : cell.level === 2
                    ? 'bg-emerald-400 dark:bg-emerald-700'
                    : cell.level === 3
                      ? 'bg-emerald-500 dark:bg-emerald-500'
                      : 'bg-emerald-600 dark:bg-emerald-400';
            return (
              <div
                key={cell.isoDate}
                title={`${cell.dayNumber} ${cell.monthLabel}: ${cell.count} نشاط`}
                className={`flex aspect-square items-center justify-center rounded-lg font-code text-[10px] font-bold tabular-nums transition-colors ${bgClass} ${
                  cell.level >= 2 ? 'text-white dark:text-slate-950' : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {cell.dayNumber}
              </div>
            );
          })}
        </div>
      </section>

      {/* Shareable CEFR Achievement Certificates */}
      <section
        data-testid="stats-certificates-section"
        className="tmn-card rounded-2xl p-5"
      >
        <div className="mb-4 flex items-center gap-2">
          <Award className="h-4.5 w-4.5 text-amber-500" aria-hidden="true" />
          <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
            شهادات الإنجاز (CEFR)
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {unlockedCerts.map((cert) => {
            const meta = BAND_META[cert.band];
            return (
              <div
                key={cert.band}
                className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/50"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex h-6 w-9 items-center justify-center rounded-md font-en text-xs font-extrabold text-white ${meta.bgClass}`}
                    >
                      {cert.band}
                    </span>
                    <span className="truncate text-sm font-extrabold text-slate-900 dark:text-white">
                      شهادة مستوى {cert.band} ({meta.ar})
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    {cert.reasonAr}
                  </p>
                </div>

                <button
                  type="button"
                  data-testid={`stats-cert-btn-${cert.band}`}
                  onClick={() => onOpenCertificate(cert.band, cert.reasonAr)}
                  className="inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl bg-indigo-600 px-3.5 text-xs font-bold text-white hover:bg-indigo-700"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>عرض الشهادة</span>
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Achievement Badges */}
      <section
        data-testid="stats-badges-section"
        className="tmn-card rounded-2xl p-5"
      >
        <div className="mb-4 flex items-center gap-2">
          <Trophy className="h-4.5 w-4.5 text-amber-500" aria-hidden="true" />
          <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
            شارات الإنجاز
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`rounded-2xl border p-3.5 transition-colors ${
                badge.unlocked
                  ? 'border-amber-300/70 bg-amber-50/60 dark:border-amber-500/30 dark:bg-amber-500/10'
                  : 'border-slate-200/70 bg-slate-50/50 opacity-75 dark:border-slate-800 dark:bg-slate-900/40'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                  {badge.titleAr}
                </span>
                <span
                  className={`font-code text-[11px] font-bold tabular-nums ${
                    badge.unlocked
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-400'
                  }`}
                >
                  {badge.unlocked ? '✓ مكتمل' : badge.progressLabel}
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                {badge.descAr}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CEFR A0–C2 Band Progress Breakdown */}
      <section className="tmn-card rounded-2xl p-5">
        <h2 className="mb-4 text-base font-extrabold text-slate-900 dark:text-slate-100">
          تقدمك حسب مستويات الكلمات (CEFR A0–C2)
        </h2>
        <div className="space-y-4">
          {BANDS.map((band) => {
            const meta = BAND_META[band];
            const bandIndices = store.byBand[band];
            const masteredInBand = bandIndices.filter((id) => masteredSet.has(id)).length;
            const subTot = getBandSubCount(store, band, settings.levelSize);
            const subDone = getBandDoneCount(store, band, settings.levelSize, settings.completed);
            const wordPct = Math.round((masteredInBand / Math.max(1, bandIndices.length)) * 100);

            return (
              <div key={band} className="space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex h-6 w-9 items-center justify-center rounded-md font-en text-xs font-extrabold text-white ${meta.bgClass}`}
                    >
                      {band}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{meta.ar}</span>
                    <span className="text-slate-500 dark:text-slate-400">
                      ({masteredInBand.toLocaleString('en-US')} /{' '}
                      {bandIndices.length.toLocaleString('en-US')} كلمة متقنة)
                    </span>
                  </div>
                  <div className="font-code font-bold tabular-nums text-slate-600 dark:text-slate-300">
                    مستويات مكتملة: {subDone}/{subTot} ({wordPct}%)
                  </div>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${meta.bgClass}`}
                    style={{ width: `${wordPct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
