import React from "react";
import {
  ArrowLeft,
  BookOpen,
  Camera,
  CheckCircle2,
  Database,
  Globe,
  Info,
  Lock,
  Server,
  ShieldCheck,
} from "lucide-react";
import type { ServerHealth } from "../types/chat";
import { BrandLogo } from "./BrandLogo";

interface PrivacyAboutPageProps {
  health: ServerHealth | null;
  onBackToChat: () => void;
}

export const PrivacyAboutPage: React.FC<PrivacyAboutPageProps> = ({
  health,
  onBackToChat,
}) => {
  return (
    <div className="flex-1 overflow-y-auto mih-scroll">
      <div className="max-w-3xl mx-auto px-4 sm:px-8 py-6 sm:py-10 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <BrandLogo size="md" showSubtitle />
          <button
            type="button"
            onClick={onBackToChat}
            className="min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Chat</span>
          </button>
        </div>

        {/* About MIH.AI */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <Info className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              About MIH.AI
            </h1>
          </div>

          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            MIH.AI (“Your Personal AI Assistant”) is a multimodal text-and-photo
            assistant designed for students, educators, and everyday problem
            solving on mobile and desktop.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                <Camera className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Multimodal Vision</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Reads printed pages, handwritten questions, math problems, and
                diagrams from JPG, PNG, and WEBP images.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>English · বাংলা · हिन्दी</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Automatically detects the language of your prompt and responds in
                the same language, or uses your chosen language setting.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Step-by-Step Clarity</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Explains reasoning clearly with formatted headings, lists, and
                code blocks instead of giving bare answers.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Honest Boundaries</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Does not invent unclear image details and does not claim live web
                search when no search tool is connected.
              </p>
            </div>
          </div>
        </section>

        {/* Privacy Notice */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <Lock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Privacy &amp; Data Handling
            </h2>
          </div>

          <ul className="space-y-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            <li className="flex items-start gap-2.5">
              <Database className="w-4 h-4 text-slate-400 mt-1 shrink-0" />
              <span>
                <strong>Local Browser Storage:</strong> Your conversation
                history, chat titles, theme, and language preferences are stored
                locally in your browser’s storage. You can rename, delete, or
                clear all chats at any time.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <Server className="w-4 h-4 text-slate-400 mt-1 shrink-0" />
              <span>
                <strong>Server-Side AI Proxy:</strong> When you send a message or
                photo, it is transmitted to the application’s backend server,
                which calls the Gemini AI API securely using server-side
                credentials. API keys are never sent to or stored in the browser.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-slate-400 mt-1 shrink-0" />
              <span>
                <strong>Text &amp; Photo Only:</strong> MIH.AI does not include
                microphone access, voice recording, or audio playback features.
                Camera access is strictly video-only and only activates when you
                choose to take a photo.
              </span>
            </li>
          </ul>
        </section>

        {/* Deployment & API Configuration Info */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-3">
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
            Server Configuration Status
          </h2>
          <div className="text-sm text-slate-600 dark:text-slate-300 space-y-2 leading-relaxed">
            <p>
              <strong>Gemini Multimodal AI:</strong>{" "}
              {health?.aiConfigured
                ? `Configured and active (${health.model}).`
                : "Not configured yet. Set GEMINI_API_KEY in Settings > Secrets (or the server environment) to enable AI responses."}
            </p>
            <p>
              <strong>Google Sign-In:</strong>{" "}
              {health?.googleAuthConfigured
                ? "Configured via GOOGLE_CLIENT_ID. Available in Settings."
                : "Not configured (optional GOOGLE_CLIENT_ID is unset). The app runs in Local Demo Mode without requiring login."}
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};
