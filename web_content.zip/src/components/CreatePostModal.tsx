import React, { useState, useRef } from 'react';
import { X, Image, Video, Globe, Users, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { processGalleryUpload, ProcessedMedia } from '../utils/media';
import { SafeVideo } from './SafeVideo';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { createPost } = useSocial();

  const [content, setContent] = useState('');
  const [privacy, setPrivacy] = useState<'public' | 'friends'>('public');
  const [media, setMedia] = useState<ProcessedMedia | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    try {
      const processed = await processGalleryUpload(file);
      setMedia(processed);
    } catch (err) {
      console.error('Error processing gallery upload:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !media) return;

    setIsSubmitting(true);
    try {
      await createPost(
        content.trim(),
        media ? media.mediaType : 'none',
        media?.mediaUrl,
        privacy
      );
      // Reset & close
      setContent('');
      setMedia(null);
      onClose();
    } catch (err) {
      console.error('Failed to publish post:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="relative px-4 py-3.5 border-b border-slate-200 flex items-center justify-center">
          <h2 className="font-bold text-slate-900 text-base sm:text-lg">Create post</h2>
          <button
            onClick={onClose}
            className="absolute right-3.5 top-3 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4">
          
          {/* User info & privacy */}
          <div className="flex items-center gap-3 mb-3">
            <img
              src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
              alt={user?.displayName || 'Avatar'}
              className="w-11 h-11 rounded-full object-cover ring-1 ring-slate-200"
            />
            <div>
              <p className="font-bold text-sm text-slate-900">{user?.displayName}</p>
              
              {/* Privacy selector */}
              <div className="flex items-center gap-1 mt-0.5">
                <button
                  type="button"
                  onClick={() => setPrivacy(p => p === 'public' ? 'friends' : 'public')}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md cursor-pointer transition-colors"
                >
                  {privacy === 'public' ? (
                    <>
                      <Globe className="w-3 h-3 text-slate-500" />
                      <span>Public</span>
                    </>
                  ) : (
                    <>
                      <Users className="w-3 h-3 text-slate-500" />
                      <span>Friends</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Text Input */}
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`What's on your mind, ${user?.displayName?.split(' ')[0] || ''}?`}
            rows={4}
            className="w-full text-slate-800 placeholder-slate-400 text-base sm:text-lg resize-none focus:outline-hidden mb-3 border-none"
            autoFocus
          />

          {/* Media Preview Box */}
          {isProcessing && (
            <div className="w-full py-8 bg-slate-50 rounded-xl border border-slate-200 flex flex-col items-center justify-center gap-2 mb-3">
              <Loader2 className="w-6 h-6 animate-spin text-[#1877F2]" />
              <p className="text-xs font-medium text-slate-500">Processing media from phone gallery...</p>
            </div>
          )}

          {media && (
            <div className="relative mb-3 rounded-xl overflow-hidden bg-slate-900 border border-slate-200">
              {media.mediaType === 'video' ? (
                <div className="relative aspect-video max-h-64 flex items-center justify-center bg-black">
                  <SafeVideo
                    src={media.mediaUrl}
                    controls
                    playsInline
                    className="w-full h-full max-h-64 object-contain"
                  />
                  <span className="absolute bottom-2 left-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded-md font-mono">
                    VIDEO {media.duration ? `• ${media.duration}s` : ''}
                  </span>
                </div>
              ) : (
                <div className="relative max-h-72 flex items-center justify-center bg-black">
                  <img
                    src={media.mediaUrl}
                    alt="Upload preview"
                    className="w-full max-h-72 object-contain"
                  />
                  <span className="absolute bottom-2 left-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded-md font-mono">
                    PHOTO • {(media.fileSize / (1024 * 1024)).toFixed(1)} MB
                  </span>
                </div>
              )}

              {/* Remove media button */}
              <button
                type="button"
                onClick={() => setMedia(null)}
                className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Android Gallery Upload Button Box */}
          <div className="p-3 border border-slate-200 rounded-xl flex items-center justify-between mb-4 bg-slate-50/50">
            <span className="text-xs sm:text-sm font-semibold text-slate-700">Add to your post</span>
            
            <div className="flex items-center gap-1.5">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                className="hidden"
                onChange={handleFileChange}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1 bg-white hover:bg-slate-100 border border-slate-200 text-emerald-600 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-xs"
              >
                <Image className="w-4 h-4 text-emerald-500" />
                <span className="hidden xs:inline">Photo/Video</span>
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={(!content.trim() && !media) || isSubmitting || isProcessing}
            className="w-full py-2.5 rounded-xl bg-[#1877F2] hover:bg-blue-600 active:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-sm transition-all cursor-pointer shadow-sm flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Publishing to Feed...</span>
              </>
            ) : (
              <span>Post</span>
            )}
          </button>

        </form>

      </div>
    </div>
  );
};
