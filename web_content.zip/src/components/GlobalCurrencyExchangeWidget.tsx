import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRightLeft, 
  DollarSign, 
  RefreshCw, 
  Zap, 
  ShieldCheck, 
  ArrowUpRight, 
  Check, 
  Copy, 
  Sparkles, 
  TrendingUp, 
  CreditCard,
  Building2,
  ChevronDown,
  Info
} from 'lucide-react';
import { ImsiWalletBalances, imsiEngine } from '../lib/imsiEngine';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface GlobalCurrencyExchangeWidgetProps {
  wallet: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenWithdrawal?: () => void;
  onOpenBiometric?: () => void;
}

interface CurrencyMeta {
  code: string;
  name: string;
  symbol: string;
  category: 'FIAT' | 'CRYPTO' | 'PARITY';
  usdRate: number; // Base rate relative to 1 USD
  flagOrIcon: string;
  decimals: number;
}

export const GlobalCurrencyExchangeWidget: React.FC<GlobalCurrencyExchangeWidgetProps> = ({
  wallet,
  onShowToast,
  onOpenWithdrawal,
  onOpenBiometric
}) => {
  const [fromCode, setFromCode] = useState<string>('USD');
  const [toCode, setToCode] = useState<string>('NGN');
  const [fromAmount, setFromAmount] = useState<string>('100');
  const [isExecutingSwap, setIsExecutingSwap] = useState<boolean>(false);
  const [copiedQuote, setCopiedQuote] = useState<boolean>(false);

  // Comprehensive Currencies Catalog
  const currencies: CurrencyMeta[] = useMemo(() => [
    // FIAT
    { code: 'USD', name: 'US Dollar', symbol: '$', category: 'FIAT', usdRate: 1.0, flagOrIcon: '🇺🇸', decimals: 2 },
    { code: 'NGN', name: 'Nigerian Naira', symbol: '₦', category: 'FIAT', usdRate: 1580.0, flagOrIcon: '🇳🇬', decimals: 2 },
    { code: 'EUR', name: 'Eurozone Euro', symbol: '€', category: 'FIAT', usdRate: 0.92, flagOrIcon: '🇪🇺', decimals: 2 },
    { code: 'GBP', name: 'British Pound', symbol: '£', category: 'FIAT', usdRate: 0.78, flagOrIcon: '🇬🇧', decimals: 2 },
    { code: 'KES', name: 'Kenyan Shilling', symbol: 'KSh', category: 'FIAT', usdRate: 129.5, flagOrIcon: '🇰🇪', decimals: 2 },
    { code: 'GHS', name: 'Ghanaian Cedi', symbol: 'GH₵', category: 'FIAT', usdRate: 15.4, flagOrIcon: '🇬🇭', decimals: 2 },
    { code: 'ZAR', name: 'South African Rand', symbol: 'R', category: 'FIAT', usdRate: 18.2, flagOrIcon: '🇿🇦', decimals: 2 },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'CA$', category: 'FIAT', usdRate: 1.37, flagOrIcon: '🇨🇦', decimals: 2 },
    { code: 'AED', name: 'UAE Dirham', symbol: 'AED', category: 'FIAT', usdRate: 3.67, flagOrIcon: '🇦🇪', decimals: 2 },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥', category: 'FIAT', usdRate: 152.4, flagOrIcon: '🇯🇵', decimals: 0 },

    // CRYPTOCURRENCIES
    { code: 'BTC', name: 'Bitcoin Taproot', symbol: '₿', category: 'CRYPTO', usdRate: 1 / 94500, flagOrIcon: '₿', decimals: 8 },
    { code: 'ETH', name: 'Ethereum L1', symbol: 'Ξ', category: 'CRYPTO', usdRate: 1 / 2700, flagOrIcon: 'Ξ', decimals: 6 },
    { code: 'SOL', name: 'Solana High-Speed', symbol: '◎', category: 'CRYPTO', usdRate: 1 / 188, flagOrIcon: '◎', decimals: 4 },
    { code: 'USDT', name: 'Tether USD', symbol: '₮', category: 'CRYPTO', usdRate: 1.0, flagOrIcon: '₮', decimals: 2 },

    // PROPHETIC PARITY
    { code: 'CONVERTO', name: 'CONVERTO Altar Parity', symbol: '⚡', category: 'PARITY', usdRate: 1.0, flagOrIcon: '⚡', decimals: 2 },
  ], []);

  const fromMeta = useMemo(() => currencies.find(c => c.code === fromCode) || currencies[0], [currencies, fromCode]);
  const toMeta = useMemo(() => currencies.find(c => c.code === toCode) || currencies[1], [currencies, toCode]);

  // Conversion Calculation
  const convertedAmount = useMemo(() => {
    const inputVal = parseFloat(fromAmount) || 0;
    if (inputVal <= 0) return '0.00';

    // Step 1: Convert to USD base
    const valInUsd = inputVal / fromMeta.usdRate;
    // Step 2: Convert to target currency
    const targetVal = valInUsd * toMeta.usdRate;

    if (toMeta.category === 'CRYPTO') {
      return targetVal.toFixed(toMeta.decimals);
    }
    return targetVal.toLocaleString('en-US', {
      minimumFractionDigits: toMeta.decimals,
      maximumFractionDigits: toMeta.decimals
    });
  }, [fromAmount, fromMeta, toMeta]);

  // Direct Exchange Rate string
  const exchangeRateString = useMemo(() => {
    const unitInUsd = 1 / fromMeta.usdRate;
    const targetPerUnit = unitInUsd * toMeta.usdRate;
    if (toMeta.category === 'CRYPTO') {
      return `1 ${fromMeta.code} = ${targetPerUnit.toFixed(toMeta.decimals)} ${toMeta.code}`;
    }
    return `1 ${fromMeta.code} = ${targetPerUnit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} ${toMeta.code}`;
  }, [fromMeta, toMeta]);

  // Swap currencies
  const handleSwapCurrencies = () => {
    const temp = fromCode;
    setFromCode(toCode);
    setToCode(temp);
  };

  // Set quick preset amount
  const handleSetPreset = (amt: number) => {
    setFromAmount(amt.toString());
  };

  // Execute instantaneous conversion with biometric authentication fallback
  const handleExecuteConversion = async () => {
    const amt = parseFloat(fromAmount);
    if (isNaN(amt) || amt <= 0) {
      onShowToast?.('⚠️ Please enter a valid exchange amount.');
      return;
    }

    setIsExecutingSwap(true);
    onShowToast?.(`🔄 Converting ${amt} ${fromCode} to ${convertedAmount} ${toCode} via Sovereign Gateway...`);

    // Prompt Biometric verification if available
    try {
      await webAuthnBiometric.verifyBiometric(
        `Currency Exchange of ${amt} ${fromCode} to ${toCode}`,
        'fingerprint'
      );
    } catch {
      // ignore
    }

    setTimeout(() => {
      // If exchanging into NGN or BTC, optionally credit wallet
      if (toCode === 'NGN') {
        const ngnGain = parseFloat(convertedAmount.replace(/,/g, '')) || 0;
        imsiEngine.depositDirectCredit({
          cashNgn: Number(ngnGain.toFixed(2)),
          source: `FX Exchange (${fromCode} ➔ NGN)`,
          note: `Global Currency Exchange from ${amt} ${fromCode}`
        });
      } else if (toCode === 'BTC') {
        const btcGain = parseFloat(convertedAmount) || 0;
        const satsGain = Math.round(btcGain * 100000000);
        imsiEngine.depositDirectCredit({
          btcSats: satsGain,
          source: `FX Exchange (${fromCode} ➔ BTC)`,
          note: `Global Currency Exchange from ${amt} ${fromCode}`
        });
      }

      setIsExecutingSwap(false);
      onShowToast?.(`✓ Instant Currency Swap Complete! ${fromAmount} ${fromCode} ➔ ${convertedAmount} ${toCode} successfully credited.`);
    }, 1800);
  };

  return (
    <div className="bg-slate-950 border-2 border-cyan-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
      {/* Glow highlight */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-black uppercase tracking-wider">
            <DollarSign className="w-4 h-4 text-cyan-400" />
            <span>GLOBAL FIAT & CRYPTOCURRENCY EXCHANGE</span>
          </div>
          <h2 className="text-2xl font-black font-serif text-slate-100 tracking-tight">
            Universal Currency Converter & Instant Payment Calculator
          </h2>
          <p className="text-xs text-slate-400">
            Real-time interbank FX swapper supporting Nigerian Naira (₦), US Dollars ($), Euro (€), British Pounds (£), African currencies, Bitcoin (₿), Ethereum (Ξ), Solana (◎), and CONVERTO 1:1 parity.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-bold text-cyan-400 bg-slate-900 border border-cyan-500/30 px-3 py-1.5 rounded-xl">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
          <span>0.0% Ministry Spread Rate</span>
        </div>
      </div>

      {/* Interactive Conversion Box */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center">
          {/* FROM Input Box (5 cols) */}
          <div className="md:col-span-5 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400">
              <span>You Pay / Convert From:</span>
              <span className="text-amber-300">Balance: {fromCode === 'NGN' ? `₦${wallet.cashNgn.toLocaleString()}` : fromCode === 'BTC' ? `${wallet.bitcoinFormatted}` : 'Unlimited Liquidity'}</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 focus-within:border-cyan-400 rounded-2xl p-3 flex items-center justify-between space-x-3 transition-colors">
              <input
                type="number"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-transparent text-xl sm:text-2xl font-black text-slate-100 placeholder-slate-600 focus:outline-none font-mono"
              />

              <select
                value={fromCode}
                onChange={(e) => setFromCode(e.target.value)}
                className="bg-slate-900 border border-slate-700 text-cyan-300 font-black text-xs sm:text-sm rounded-xl px-3 py-2 focus:outline-none"
              >
                <optgroup label="Local & Global Fiat">
                  {currencies.filter(c => c.category === 'FIAT').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code} - {c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Cryptocurrencies">
                  {currencies.filter(c => c.category === 'CRYPTO').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code} - {c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Ministry Parity">
                  {currencies.filter(c => c.category === 'PARITY').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code}</option>
                  ))}
                </optgroup>
              </select>
            </div>
          </div>

          {/* SWAP ICON (1 col) */}
          <div className="md:col-span-1 flex justify-center">
            <button
              onClick={handleSwapCurrencies}
              className="w-11 h-11 rounded-2xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 flex items-center justify-center transition-all hover:rotate-180 hover:scale-105"
              title="Swap Currencies"
            >
              <ArrowRightLeft className="w-5 h-5" />
            </button>
          </div>

          {/* TO Output Box (5 cols) */}
          <div className="md:col-span-5 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400">
              <span>You Receive (Calculated Target):</span>
              <span className="text-emerald-400 font-bold">Instant 0.8s Settlement</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 flex items-center justify-between space-x-3">
              <div className="w-full text-xl sm:text-2xl font-black text-cyan-300 truncate font-mono">
                {convertedAmount}
              </div>

              <select
                value={toCode}
                onChange={(e) => setToCode(e.target.value)}
                className="bg-slate-900 border border-slate-700 text-cyan-300 font-black text-xs sm:text-sm rounded-xl px-3 py-2 focus:outline-none"
              >
                <optgroup label="Local & Global Fiat">
                  {currencies.filter(c => c.category === 'FIAT').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code} - {c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Cryptocurrencies">
                  {currencies.filter(c => c.category === 'CRYPTO').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code} - {c.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Ministry Parity">
                  {currencies.filter(c => c.category === 'PARITY').map(c => (
                    <option key={c.code} value={c.code}>{c.flagOrIcon} {c.code}</option>
                  ))}
                </optgroup>
              </select>
            </div>
          </div>
        </div>

        {/* Quick Amount Preset Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800/80">
          <span className="text-[11px] font-bold text-slate-400">Quick Presets:</span>
          {[50, 100, 500, 1000, 5000].map((val) => (
            <button
              key={val}
              onClick={() => handleSetPreset(val)}
              className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 border border-slate-800 text-[11px] font-mono transition-colors"
            >
              {fromMeta.symbol}{val.toLocaleString()}
            </button>
          ))}
          <button
            onClick={() => handleSetPreset(fromCode === 'NGN' ? wallet.cashNgn : 10000)}
            className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold"
          >
            Max Available
          </button>
        </div>

        {/* Quote Details Strip & Execute Button */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-3 border-t border-slate-800">
          <div className="space-y-1 text-xs">
            <div className="text-slate-300 font-mono font-bold">
              {exchangeRateString}
            </div>
            <div className="text-[11px] text-slate-500 flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Direct liquidity pool routing • Zero slippage guarantee</span>
            </div>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              disabled={isExecutingSwap}
              onClick={handleExecuteConversion}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-xl shadow-cyan-500/20 transition-all hover:scale-102 disabled:opacity-50"
            >
              {isExecutingSwap ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>EXECUTING SWAP & ROUTING...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-slate-950" />
                  <span>EXECUTE CONVERSION NOW</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
