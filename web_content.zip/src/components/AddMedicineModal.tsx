import React, { useState } from 'react';
import { X, Plus, Trash2, Pill, Clock, Calendar, AlertCircle, Stethoscope, FileText, Hash } from 'lucide-react';
import { MedicineItem, MedicineType, FrequencyType, ReminderLanguage } from '../types/reminder';
import { TRANSLATIONS } from '../data/reminderData';

interface AddMedicineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (medicine: Omit<MedicineItem, 'id' | 'createdAt'>) => void;
  language: ReminderLanguage;
}

const MEDICINE_TYPES: MedicineType[] = [
  'Tablet',
  'Capsule',
  'Syrup',
  'Injection',
  'Drops',
  'Cream',
  'Inhaler',
  'Others'
];

const FREQUENCIES: FrequencyType[] = [
  'Once Daily',
  'Twice Daily',
  'Three Times Daily',
  'Four Times Daily',
  'Custom Schedule'
];

export const AddMedicineModal: React.FC<AddMedicineModalProps> = ({
  isOpen,
  onClose,
  onSave,
  language
}) => {
  const t = TRANSLATIONS[language];

  // Form States
  const [name, setName] = useState('');
  const [type, setType] = useState<MedicineType>('Tablet');
  const [strength, setStrength] = useState('500mg');
  const [reason, setReason] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [frequency, setFrequency] = useState<FrequencyType>('Twice Daily');
  const [times, setTimes] = useState<string[]>(['08:00', '20:00']);

  // Course duration choice
  const [courseType, setCourseType] = useState<'dates' | 'days'>('days');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(
    new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
  );
  const [durationDays, setDurationDays] = useState('14');

  // Quantity
  const [totalQuantity, setTotalQuantity] = useState('30');
  const [dosePerTime, setDosePerTime] = useState('1');

  // Error messaging
  const [error, setError] = useState('');

  if (!isOpen) return null;

  // Auto-fill times based on frequency selection
  const handleFrequencyChange = (freq: FrequencyType) => {
    setFrequency(freq);
    if (freq === 'Once Daily') {
      setTimes(['08:00']);
    } else if (freq === 'Twice Daily') {
      setTimes(['08:00', '20:00']);
    } else if (freq === 'Three Times Daily') {
      setTimes(['08:00', '14:00', '20:00']);
    } else if (freq === 'Four Times Daily') {
      setTimes(['08:00', '12:00', '16:00', '20:00']);
    }
  };

  const addCustomTime = () => {
    setTimes([...times, '12:00']);
  };

  const removeCustomTime = (index: number) => {
    if (times.length <= 1) return;
    setTimes(times.filter((_, i) => i !== index));
  };

  const updateTimeValue = (index: number, val: string) => {
    const updated = [...times];
    updated[index] = val;
    setTimes(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError(language === 'Hindi' ? 'कृपया दवाई का नाम दर्ज करें' : language === 'Marathi' ? 'कृपया औषधाचे नाव प्रविष्ट करा' : 'Please enter medicine name');
      return;
    }

    let calculatedEndDate = endDate;
    if (courseType === 'days') {
      const days = parseInt(durationDays, 10) || 7;
      const start = new Date(startDate);
      start.setDate(start.getDate() + days);
      calculatedEndDate = start.toISOString().split('T')[0];
    }

    const totalQtyNum = Math.max(1, parseInt(totalQuantity, 10) || 30);
    const doseQtyNum = Math.max(1, parseInt(dosePerTime, 10) || 1);

    onSave({
      name: name.trim(),
      type,
      strength: strength.trim() || '500mg',
      reason: reason.trim(),
      doctorName: doctorName.trim(),
      frequency,
      times: times.length > 0 ? times : ['08:00'],
      startDate,
      endDate: calculatedEndDate,
      totalQuantity: totalQtyNum,
      dosePerTime: doseQtyNum,
      remainingQuantity: totalQtyNum, // Initial remaining equals total
      isActive: true,
    });

    // Reset Form
    setName('');
    setReason('');
    setDoctorName('');
    setError('');
    onClose();
  };

  // Remaining calculation helper preview
  const previewTotal = parseInt(totalQuantity, 10) || 0;
  const previewDose = parseInt(dosePerTime, 10) || 1;
  const previewTimesPerDay = times.length;
  const daysSupply = Math.floor(previewTotal / (previewDose * (previewTimesPerDay || 1)));

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-2xl backdrop-blur-md">
              <Pill className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg">{t.addMedicine}</h2>
              <p className="text-xs text-teal-100">Material Design 3 Medical Prescription Form</p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-xs text-red-700 font-semibold">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Medicine Name & Strength */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Pill className="w-3.5 h-3.5 text-teal-600" /> Medicine Name *
              </label>
              <input
                type="text"
                placeholder="e.g. Paracetamol, Lipitor, Metformin"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-teal-600" /> Strength
              </label>
              <input
                type="text"
                placeholder="500mg, 10ml"
                value={strength}
                onChange={(e) => setStrength(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none transition-all"
              />
            </div>
          </div>

          {/* Medicine Type selector pills */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Pill className="w-3.5 h-3.5 text-teal-600" /> {t.medicineType}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {MEDICINE_TYPES.map((tItem) => (
                <button
                  type="button"
                  key={tItem}
                  onClick={() => setType(tItem)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    type === tItem
                      ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                      : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                  }`}
                >
                  {tItem}
                </button>
              ))}
            </div>
          </div>

          {/* Optional Reason & Doctor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-teal-600" /> {t.reason} (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Blood Pressure, Fever, Infection"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5 text-teal-600" /> {t.doctor} (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Dr. R. K. Sharma"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-teal-600 focus:ring-2 focus:ring-teal-100 outline-none transition-all"
              />
            </div>
          </div>

          {/* Dosage & Frequency */}
          <div className="bg-teal-50/70 border border-teal-100 p-4 rounded-2xl space-y-3">
            <label className="text-xs font-bold text-teal-900 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-teal-700" /> Dosage & Frequency Schedule
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {FREQUENCIES.map((freq) => (
                <button
                  type="button"
                  key={freq}
                  onClick={() => handleFrequencyChange(freq)}
                  className={`px-2.5 py-2 rounded-xl text-[11px] font-bold border text-center transition-all ${
                    frequency === freq
                      ? 'bg-teal-700 text-white border-teal-800 shadow-xs'
                      : 'bg-white text-slate-700 border-teal-200/80 hover:bg-teal-100/50'
                  }`}
                >
                  {freq}
                </button>
              ))}
            </div>

            {/* Unlimited Reminder Times list */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-teal-800">Alarm / Reminder Times:</span>
                <button
                  type="button"
                  onClick={addCustomTime}
                  className="flex items-center gap-1 text-[11px] font-bold text-teal-700 hover:text-teal-900 bg-white border border-teal-200 px-2 py-0.5 rounded-lg shadow-2xs"
                >
                  <Plus className="w-3 h-3" /> Add Time
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {times.map((timeVal, idx) => (
                  <div key={idx} className="flex items-center gap-1 bg-white p-1.5 rounded-xl border border-teal-200 shadow-2xs">
                    <Clock className="w-3.5 h-3.5 text-teal-600 ml-1 shrink-0" />
                    <input
                      type="time"
                      value={timeVal}
                      onChange={(e) => updateTimeValue(idx, e.target.value)}
                      className="w-full text-xs font-mono font-bold text-slate-800 outline-none bg-transparent"
                    />
                    {times.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeCustomTime(idx)}
                        className="p-1 hover:text-red-600 text-slate-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Course Duration */}
          <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-teal-600" /> {t.courseDuration}
              </label>

              <div className="flex items-center bg-slate-200/80 p-0.5 rounded-xl text-[10px] font-bold">
                <button
                  type="button"
                  onClick={() => setCourseType('days')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    courseType === 'days' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  By Days
                </button>
                <button
                  type="button"
                  onClick={() => setCourseType('dates')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    courseType === 'dates' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  By Dates
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-600">{t.startDate}</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none"
                />
              </div>

              {courseType === 'days' ? (
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-600">Number of Days</span>
                  <input
                    type="number"
                    min="1"
                    max="365"
                    value={durationDays}
                    onChange={(e) => setDurationDays(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none"
                  />
                </div>
              ) : (
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-600">{t.endDate}</span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Medicine Quantity & Inventory Calculation */}
          <div className="bg-emerald-50/60 border border-emerald-200/80 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Hash className="w-4 h-4 text-emerald-700" /> Quantity & Inventory Calculation
              </label>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-lg border border-emerald-200">
                Auto Stock Tracker
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700">{t.totalTablets}</span>
                <input
                  type="number"
                  min="1"
                  placeholder="30"
                  value={totalQuantity}
                  onChange={(e) => setTotalQuantity(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none"
                />
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700">Dose Per Time</span>
                <input
                  type="number"
                  min="1"
                  placeholder="1"
                  value={dosePerTime}
                  onChange={(e) => setDosePerTime(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none"
                />
              </div>
            </div>

            {/* Automatic calculation preview */}
            <div className="p-2.5 bg-white rounded-xl border border-emerald-100 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-medium">Initial Remaining Stock:</span>
              <span className="font-extrabold text-emerald-700">
                {previewTotal} {type}s (~{daysSupply} days supply)
              </span>
            </div>
          </div>

          {/* Submit Footer */}
          <div className="pt-2 flex items-center justify-end gap-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              {t.cancel}
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-700/20 active:scale-98 transition-all"
            >
              {t.saveMedicine}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
