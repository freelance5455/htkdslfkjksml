import React, { useEffect, useRef } from "react";
import { StylusToolType } from "../types";
import { CanvasDrawingEngine } from "../utils/canvasDrawingEngine";

interface PenPreviewBadgeProps {
  tool: StylusToolType;
  color: string;
  size?: number;
  width?: number;
  height?: number;
  className?: string;
}

export const PenPreviewBadge: React.FC<PenPreviewBadgeProps> = ({
  tool,
  color,
  size = 5,
  width = 72,
  height = 28,
  className = "",
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      canvas.width = width;
      canvas.height = height;
      CanvasDrawingEngine.renderToolPreviewCanvas(canvas, tool, color, size);
    }
  }, [tool, color, size, width, height]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className={`rounded-lg bg-slate-950/40 border border-slate-700/50 block shrink-0 ${className}`}
    />
  );
};
