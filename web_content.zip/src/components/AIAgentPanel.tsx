/**
 * GODEX v0.0.1 - AI Agent Activity & Autonomous Brain Panel
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Sparkles, Bot, Shield, CheckCircle2, AlertCircle, 
  Terminal, RefreshCw, ChevronDown, ChevronRight, Globe, Layers, ArrowUpRight
} from 'lucide-react';
import { ActivityLogItem, ExecutionMode, TaskState } from '../types';

interface AIAgentPanelProps {
  activityLogs: ActivityLogItem[];
  taskState: TaskState;
  executionMode: ExecutionMode;
  onSendPrompt: (prompt: string) => void;
  isRunning: boolean;
}

export const AIAgentPanel: React.FC<AIAgentPanelProps> = ({
  activityLogs,
  taskState,
  executionMode,
  onSendPrompt,
  isRunning
}) => {
  const [inputPrompt, setInputPrompt] = useState('');
  const [expandedLogs, setExpandedLogs] = useState<Record<string, boolean>>({});
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activityLogs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputPrompt.trim() || isRunning) return;
    onSendPrompt(inputPrompt.trim());
    setInputPrompt('');
  };

  const toggleExpand = (id: string) => {
    setExpandedLogs(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const quickPrompts = [
    { label: '🇬🇧 Build Notes App', text: 'Build a responsive notes application with dashboard, notes list, create, edit, delete, search and categories.' },
    { label: '🇮🇳 Task Manager banao', text: 'Ek responsive task manager app banao jisme categories, search aur status filter ho.' },
    { label: '🚩 Responsive app banva', text: 'Mala ek clean dashboard ani notes application banvaychi ahe responsive design sobat.' },
    { label: '🇪🇸 App con métricas', text: 'Construir una aplicación interactiva con panel de métricas, filtros y creación de elementos.' },
  ];

  const getStateBadge = (state: TaskState) => {
    switch (state) {
      case 'COMPLETED': return <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 text-[9px] font-mono font-bold">READY</span>;
      case 'PLANNING': case 'ANALYZING': return <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-400 border border-amber-800/80 text-[9px] font-mono font-bold animate-pulse">PLAN</span>;
      case 'CODING': case 'BUILDING': return <span className="px-2 py-0.5 rounded bg-indigo-950/80 text-indigo-400 border border-indigo-800/80 text-[9px] font-mono font-bold animate-pulse">CODE</span>;
      case 'RUNNING': case 'TESTING': case 'VERIFYING': return <span className="px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/80 text-[9px] font-mono font-bold animate-pulse">VERIFY</span>;
      case 'DEBUGGING': return <span className="px-2 py-0.5 rounded bg-purple-950/80 text-purple-400 border border-purple-800/80 text-[9px] font-mono font-bold animate-pulse">DEBUG</span>;
      default: return <span className="px-2 py-0.5 rounded bg-[#151D2C] text-neutral-400 border border-[#232F46] text-[9px] font-mono font-bold">STANDBY</span>;
    }
  };

  return (
    <div className="w-full lg:w-80 xl:w-96 h-full border-l border-[#1C2230] bg-[#090B10] flex flex-col shrink-0 select-none font-mono">
      {/* Agent Activity Header */}
      <div className="h-9 px-3 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017]">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold tracking-wider text-neutral-200">AI_AGENT.TELEMETRY</span>
        </div>
        <div className="flex items-center gap-1.5">
          {getStateBadge(taskState)}
        </div>
      </div>

      {/* Multilingual Mode Info Banner */}
      <div className="px-3 py-1.5 bg-[#0C0F16] border-b border-[#1C2230] flex items-center gap-2 text-[10px] text-neutral-400">
        <Globe className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
        <span>Multilingual AI Engine: English, Hindi, Hinglish, Marathi, etc.</span>
      </div>

      {/* Activity Logs Stream */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-2 font-mono text-xs bg-[#07080D]">
        {activityLogs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500 space-y-2">
            <div className="w-10 h-10 rounded bg-[#10141E] border border-[#1E2638] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="font-semibold text-neutral-300 text-xs">Autonomous Agent Loop Ready</p>
              <p className="text-[10px] text-neutral-500 mt-1">
                Enter prompt in any language to start planning, coding, sandbox execution & verification.
              </p>
            </div>
          </div>
        ) : (
          activityLogs.map((log) => {
            const isExpanded = expandedLogs[log.id];
            const hasDetails = log.details || log.toolCall || log.diff;

            return (
              <div 
                key={log.id}
                className="p-2 rounded bg-[#0D1018] border border-[#1B2232] space-y-1.5 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#161E2E] text-cyan-300 font-semibold border border-[#232F46] uppercase">
                      {log.role}
                    </span>
                    <span className="text-[11px] font-semibold text-neutral-200 truncate">
                      {log.action}
                    </span>
                  </div>

                  <span className="text-[9px] text-neutral-500 shrink-0">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>

                {log.details && (
                  <p className="text-[11px] text-neutral-300 leading-relaxed font-sans pl-1.5 border-l border-[#242E44]">
                    {log.details}
                  </p>
                )}

                {/* Diff Metric Pill if files modified */}
                {log.diff && (
                  <div className="flex items-center gap-2 pt-0.5 text-[10px]">
                    <span className="text-neutral-400 truncate">{log.diff.file}</span>
                    <span className="text-emerald-400 font-bold">+{log.diff.additions}</span>
                    <span className="text-rose-400 font-bold">-{log.diff.deletions}</span>
                  </div>
                )}

                {/* Tool Call Output Details */}
                {log.toolCall && (
                  <div className="mt-1 pt-1 border-t border-[#1C2230] text-[10px]">
                    <button 
                      onClick={() => toggleExpand(log.id)}
                      className="flex items-center gap-1 text-cyan-400 hover:underline"
                    >
                      {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                      <span>TOOL: {log.toolCall.toolName}</span>
                    </button>

                    {isExpanded && (
                      <div className="mt-1 p-2 rounded bg-[#06070A] border border-[#1C2230] text-[10px] text-neutral-300 overflow-x-auto whitespace-pre">
                        {log.toolCall.result?.stdout || JSON.stringify(log.toolCall.args, null, 2)}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={logsEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="p-2 border-t border-[#1C2230] bg-[#0A0D14] space-y-1">
        <div className="text-[9px] text-neutral-500 font-semibold uppercase tracking-wider px-1">
          Multilingual Quick Prompts
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => setInputPrompt(p.text)}
              className="px-2 py-0.5 rounded bg-[#10141E] hover:bg-[#181F2E] border border-[#1E2738] text-[9px] text-neutral-300 whitespace-nowrap shrink-0 transition-colors"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Prompt Input Form */}
      <form onSubmit={handleSubmit} className="p-2.5 border-t border-[#1C2230] bg-[#0D1017]">
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            disabled={isRunning}
            placeholder="Ask AI to code, debug, or verify in any language..."
            className="w-full h-8 pl-2.5 pr-8 bg-[#07090E] border border-[#232F46] rounded text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-cyan-500 disabled:opacity-50 font-sans"
          />
          <button
            type="submit"
            disabled={isRunning || !inputPrompt.trim()}
            className="absolute right-1 p-1 rounded bg-cyan-600 hover:bg-cyan-500 disabled:opacity-30 text-white transition-all shadow-sm"
          >
            {isRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
          </button>
        </div>
      </form>
    </div>
  );
};
