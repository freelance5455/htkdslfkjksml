import React from "react";
import {
  Pin,
  Star,
  Clock,
  CheckSquare,
  Paperclip,
  Mic,
  Video,
  Trash2,
  Lock,
  Edit3,
  Sparkles,
  Send,
  Download,
  Binary
} from "lucide-react";
import { Note, ViewLayout } from "../types";

interface NoteCardProps {
  note: Note;
  viewLayout?: ViewLayout;
  categories?: string[];
  onChangeCategory?: (noteId: string, newCategory: string) => void;
  onAutoCategorizeNote?: (note: Note, e?: React.MouseEvent) => void;
  onOpen: (note: Note) => void;
  onTogglePin: (id: string, e: React.MouseEvent) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
  onToggleVault?: (id: string, e: React.MouseEvent) => void;
  onTagClick?: (tag: string, e: React.MouseEvent) => void;
  onOpenInfographic?: (note: Note, e: React.MouseEvent) => void;
  onSyncNote?: (note: Note, e: React.MouseEvent) => void;
  onExportNote?: (note: Note, e: React.MouseEvent) => void;
}

const COLOR_MAP: Record<string, { bg: string; border: string; accent: string; topStrip: string; badge: string }> = {
  amber: {
    bg: "bg-amber-50/70 dark:bg-amber-950/25",
    border: "border-amber-200/90 dark:border-amber-800/60",
    accent: "bg-amber-500",
    topStrip: "bg-amber-400",
    badge: "bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200",
  },
  blue: {
    bg: "bg-blue-50/70 dark:bg-blue-950/25",
    border: "border-blue-200/90 dark:border-blue-800/60",
    accent: "bg-blue-500",
    topStrip: "bg-blue-500",
    badge: "bg-blue-100 text-blue-900 dark:bg-blue-900/60 dark:text-blue-200",
  },
  rose: {
    bg: "bg-rose-50/70 dark:bg-rose-950/25",
    border: "border-rose-200/90 dark:border-rose-800/60",
    accent: "bg-rose-500",
    topStrip: "bg-rose-500",
    badge: "bg-rose-100 text-rose-900 dark:bg-rose-900/60 dark:text-rose-200",
  },
  emerald: {
    bg: "bg-emerald-50/70 dark:bg-emerald-950/25",
    border: "border-emerald-200/90 dark:border-emerald-800/60",
    accent: "bg-emerald-500",
    topStrip: "bg-emerald-500",
    badge: "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/60 dark:text-emerald-200",
  },
  teal: {
    bg: "bg-teal-50/70 dark:bg-teal-950/25",
    border: "border-teal-200/90 dark:border-teal-800/60",
    accent: "bg-teal-500",
    topStrip: "bg-teal-500",
    badge: "bg-teal-100 text-teal-900 dark:bg-teal-900/60 dark:text-teal-200",
  },
  purple: {
    bg: "bg-purple-50/70 dark:bg-purple-950/25",
    border: "border-purple-200/90 dark:border-purple-800/60",
    accent: "bg-purple-500",
    topStrip: "bg-purple-500",
    badge: "bg-purple-100 text-purple-900 dark:bg-purple-900/60 dark:text-purple-200",
  },
  slate: {
    bg: "bg-white dark:bg-slate-850",
    border: "border-slate-200 dark:border-slate-700/80",
    accent: "bg-slate-400 dark:bg-slate-500",
    topStrip: "bg-slate-400 dark:bg-slate-600",
    badge: "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200",
  },
};

const NoteCardComponent: React.FC<NoteCardProps> = ({
  note,
  viewLayout = "grid",
  categories = [],
  onChangeCategory,
  onAutoCategorizeNote,
  onOpen,
  onTogglePin,
  onToggleFavorite,
  onDelete,
  onToggleVault,
  onTagClick,
  onOpenInfographic,
  onSyncNote,
  onExportNote,
}) => {
  const [showCatMenu, setShowCatMenu] = React.useState(false);
  const colorStyle = COLOR_MAP[note.color || "slate"] || COLOR_MAP.slate;

  // Filter valid categories to switch to
  const availableCategories = categories.filter(
    (c) => c !== "Tümü" && c !== note.category
  );

  // Calculate task completion
  const tasksTotal = note.tasks?.length || 0;
  const tasksCompleted = note.tasks?.filter((t) => t.completed).length || 0;

  // Check for YouTube link inside content
  const hasYoutube = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/.test(
    note.content
  );

  // Format date
  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString("tr-TR", {
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "";
    }
  };

  // 1. LIST VIEW (Liste - Minimal Single Row)
  if (viewLayout === "list") {
    return (
      <div
        onClick={() => onOpen(note)}
        className={`group flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl border transition-all cursor-pointer hover:shadow-sm select-none will-change-transform ${colorStyle.bg} ${colorStyle.border}`}
      >
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className={`w-1.5 h-6 rounded-full shrink-0 ${colorStyle.accent}`} />

          <button
            onClick={(e) => onToggleFavorite(note.id, e)}
            className="text-slate-300 hover:text-amber-500 shrink-0 cursor-pointer"
            title={note.favorite ? "Favorilerden Çıkar" : "Favoriye Ekle"}
          >
            <Star className={`w-3.5 h-3.5 ${note.favorite ? "fill-amber-500 text-amber-500" : ""}`} />
          </button>

          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
            {note.title || "Başlıksız Not"}
          </span>

          <span className="hidden sm:inline-block text-[10px] font-semibold text-slate-500 dark:text-slate-400 bg-black/5 dark:bg-white/10 px-2 py-0.5 rounded shrink-0">
            {note.category || "Genel"}
          </span>

          {note.isVault && (
            <Lock className="w-3 h-3 text-rose-500 shrink-0" />
          )}

          {note.pinned && (
            <Pin className="w-3 h-3 text-teal-600 dark:text-teal-400 fill-current shrink-0" />
          )}

          {tasksTotal > 0 && (
            <span className="hidden md:inline-flex items-center gap-1 text-[10px] text-slate-500 shrink-0 font-medium">
              <CheckSquare className="w-3 h-3 text-teal-600" />
              {tasksCompleted}/{tasksTotal}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[11px] text-slate-400 hidden sm:inline font-mono">
            {formatDate(note.updatedAt)}
          </span>

          <div className="flex items-center opacity-70 group-hover:opacity-100 transition-opacity gap-1">
            {onExportNote && (
              <button
                onClick={(e) => onExportNote(note, e)}
                className="p-1 text-slate-400 hover:text-teal-600 rounded cursor-pointer"
                title="Dışa Aktar"
              >
                <Download className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={(e) => onTogglePin(note.id, e)}
              className="p-1 text-slate-400 hover:text-teal-600 rounded cursor-pointer"
              title="Sabitle"
            >
              <Pin className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={(e) => onDelete(note.id, e)}
              className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              title="Sil"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. DETAILS VIEW (Ayrıntılar - Single Row with Preview & Date)
  if (viewLayout === "details") {
    return (
      <article
        onClick={() => onOpen(note)}
        className={`group relative flex flex-col md:flex-row md:items-center justify-between gap-3 rounded-2xl p-3.5 transition-all duration-200 cursor-pointer border shadow-xs hover:shadow-md select-none will-change-transform ${colorStyle.bg} ${colorStyle.border}`}
      >
        <div className={`absolute left-0 top-3 bottom-3 w-1.5 rounded-r-full ${colorStyle.accent}`} />

        <div className="min-w-0 flex-1 pl-2.5 space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 bg-white/60 dark:bg-slate-800/60 px-2 py-0.5 rounded-md border border-slate-200/50 dark:border-slate-700/50">
              {note.category || "Genel"}
            </span>

            {note.pinned && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-teal-700 dark:text-teal-300 bg-teal-100/80 dark:bg-teal-950/80 px-2 py-0.5 rounded-full">
                <Pin className="w-3 h-3 fill-current" />
                Sabitli
              </span>
            )}

            {note.isVault && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-rose-700 dark:text-rose-300 bg-rose-100/80 dark:bg-rose-950/80 px-2 py-0.5 rounded-full">
                <Lock className="w-3 h-3" />
                Kasa
              </span>
            )}

            <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
              {note.title || "Başlıksız Not"}
            </h3>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
            {note.isVault ? "🔒 Görüntülemek için dokunun..." : note.content || "İçerik bulunmuyor..."}
          </p>

          {/* Tags */}
          {!note.isVault && note.tags && note.tags.length > 0 && (
            <div className="flex items-center gap-1 flex-wrap pt-0.5">
              {note.tags.slice(0, 4).map((tag, idx) => (
                <span
                  key={idx}
                  onClick={(e) => onTagClick && onTagClick(tag, e)}
                  className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-white/70 dark:bg-slate-800/70 text-teal-700 dark:text-teal-300 border border-teal-200/50"
                >
                  {tag.startsWith("#") ? tag : `#${tag}`}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Right Section / Controls */}
        <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-200/50 dark:border-slate-700/50 pl-2.5 md:pl-0">
          <div className="text-right text-xs text-slate-400">
            <span className="font-mono text-[11px]">{formatDate(note.updatedAt)}</span>
            {tasksTotal > 0 && (
              <p className="text-[11px] text-teal-600 dark:text-teal-400 font-semibold">
                {tasksCompleted}/{tasksTotal} görev
              </p>
            )}
          </div>

          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              onClick={(e) => onToggleFavorite(note.id, e)}
              className={`p-1.5 rounded-lg cursor-pointer ${
                note.favorite ? "text-amber-500" : "text-slate-400 hover:text-slate-600"
              }`}
            >
              <Star className={`w-4 h-4 ${note.favorite ? "fill-current" : ""}`} />
            </button>

            {onExportNote && (
              <button
                onClick={(e) => onExportNote(note, e)}
                title="Dışa Aktar"
                className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 cursor-pointer"
              >
                <Download className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={(e) => onTogglePin(note.id, e)}
              className={`p-1.5 rounded-lg cursor-pointer ${
                note.pinned ? "text-teal-600" : "text-slate-400 hover:text-slate-600"
              }`}
            >
              <Pin className={`w-4 h-4 ${note.pinned ? "fill-current" : ""}`} />
            </button>

            <button
              onClick={(e) => onDelete(note.id, e)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </article>
    );
  }

  // 3. LARGE GRID VIEW (Büyük Izgara - 2 Sütun Geniş Kartlar)
  if (viewLayout === "largeGrid") {
    return (
      <article
        onClick={() => onOpen(note)}
        className={`group relative flex flex-col justify-between rounded-3xl p-5 transition-all duration-200 cursor-pointer border shadow-sm hover:shadow-lg hover:-translate-y-0.5 select-none overflow-hidden will-change-transform ${colorStyle.bg} ${colorStyle.border}`}
      >
        <div className={`absolute top-0 left-0 right-0 h-2 ${colorStyle.topStrip || colorStyle.accent}`} />

        <div className="pt-1">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className={`text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg border border-black/5 dark:border-white/5 ${colorStyle.badge}`}>
                {note.category || "Genel"}
              </span>

              {note.isVault && (
                <span className="flex items-center gap-1 text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-100/80 dark:bg-rose-950/80 px-2.5 py-1 rounded-full border border-rose-200">
                  <Lock className="w-3.5 h-3.5" />
                  Kasa
                </span>
              )}

              {note.pinned && (
                <span className="flex items-center gap-1 text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-100/80 dark:bg-teal-950/80 px-2.5 py-1 rounded-full border border-teal-200">
                  <Pin className="w-3.5 h-3.5 fill-current" />
                  Sabitli
                </span>
              )}
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={(e) => onToggleFavorite(note.id, e)}
                className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                  note.favorite ? "text-amber-500 bg-amber-100/50" : "text-slate-400 hover:text-slate-600"
                }`}
              >
                <Star className={`w-4 h-4 ${note.favorite ? "fill-current" : ""}`} />
              </button>
              <button
                onClick={(e) => onTogglePin(note.id, e)}
                className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                  note.pinned ? "text-teal-600 bg-teal-100/50" : "text-slate-400 hover:text-slate-600"
                }`}
              >
                <Pin className={`w-4 h-4 ${note.pinned ? "fill-current" : ""}`} />
              </button>
            </div>
          </div>

          <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug line-clamp-2 mb-2">
            {note.title || "Başlıksız Not"}
          </h3>

          {note.isVault ? (
            <div className="my-3 p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center gap-2 text-xs font-semibold text-slate-500">
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Kilitli Not • Görüntülemek için dokunun</span>
            </div>
          ) : (
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 line-clamp-5 leading-relaxed whitespace-pre-line mb-4">
              {note.content || "İçerik bulunmuyor..."}
            </p>
          )}

          {/* Checklist preview in Large Grid */}
          {!note.isVault && note.tasks && note.tasks.length > 0 && (
            <div className="mb-4 p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
                <span className="flex items-center gap-1.5">
                  <CheckSquare className="w-4 h-4 text-teal-600" />
                  Yapılacaklar ({tasksCompleted}/{tasksTotal})
                </span>
                <span className="text-[11px] text-teal-600">%{Math.round((tasksCompleted / tasksTotal) * 100)}</span>
              </div>
              {note.tasks.slice(0, 3).map((t) => (
                <div key={t.id} className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${t.completed ? "bg-teal-600 border-teal-600 text-white" : "border-slate-300"}`}>
                    {t.completed && "✓"}
                  </span>
                  <span className={`truncate ${t.completed ? "line-through opacity-60" : ""}`}>{t.text}</span>
                </div>
              ))}
            </div>
          )}

          {/* Attachment image previews */}
          {!note.isVault && note.attachments && note.attachments.length > 0 && (
            <div className="flex items-center gap-2 overflow-hidden mb-4">
              {note.attachments.slice(0, 4).map((att) =>
                att.mime.startsWith("image/") ? (
                  <img
                    key={att.id}
                    src={att.data}
                    alt={att.name}
                    loading="lazy"
                    className="w-16 h-16 object-cover rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs"
                  />
                ) : null
              )}
            </div>
          )}

          {/* Tags */}
          {!note.isVault && note.tags && note.tags.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap mb-3">
              {note.tags.map((tag, idx) => (
                <span
                  key={idx}
                  onClick={(e) => onTagClick && onTagClick(tag, e)}
                  className="text-xs font-medium px-2.5 py-1 rounded-lg bg-white/80 dark:bg-slate-800/80 text-teal-700 dark:text-teal-300 border border-teal-200/60 cursor-pointer"
                >
                  {tag.startsWith("#") ? tag : `#${tag}`}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-200/60 dark:border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
          <span className="font-mono">{formatDate(note.updatedAt)}</span>
          <div className="flex items-center gap-1">
            {onExportNote && (
              <button onClick={(e) => onExportNote(note, e)} title="Dışa Aktar" className="p-1.5 text-slate-400 hover:text-teal-600 rounded-lg cursor-pointer">
                <Download className="w-4 h-4" />
              </button>
            )}
            <button onClick={(e) => onDelete(note.id, e)} title="Sil" className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </article>
    );
  }

  // 4. GRID (BENTO CARD) VIEW (Default)
  return (
    <article
      onClick={() => onOpen(note)}
      className={`group relative flex flex-col justify-between rounded-2xl p-4 transition-all duration-200 cursor-pointer border shadow-sm hover:shadow-md hover:-translate-y-0.5 select-none overflow-hidden ${colorStyle.bg} ${colorStyle.border}`}
    >
      {/* Accent Color Top Strip */}
      <div
        className={`absolute top-0 left-0 right-0 h-1.5 ${colorStyle.topStrip || colorStyle.accent}`}
      />

      {/* Card Header: Category, Date, and Pinned/Favorite Icons */}
      <div className="pt-1">
        <div className="flex items-center justify-between gap-2 mb-2 pl-0.5">
          <div className="flex items-center gap-1.5 flex-wrap relative">
            <div className="relative">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowCatMenu(!showCatMenu);
                }}
                title={note.aiCategoryReason || "Bölümü değiştir veya başka bölüme taşı"}
                className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border border-black/5 dark:border-white/5 hover:opacity-80 transition-all cursor-pointer flex items-center gap-1 ${colorStyle.badge}`}
              >
                {note.aiCategorized && (
                  <Sparkles className="w-2.5 h-2.5 text-amber-500 animate-pulse" />
                )}
                <span>{note.category || "Genel"}</span>
                <span className="text-[8px] opacity-60">▼</span>
              </button>

              {/* Quick Section Popover Menu */}
              {showCatMenu && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute left-0 top-full mt-1 z-30 w-48 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 px-1 animate-in fade-in zoom-in-95 text-xs select-none"
                >
                  {onAutoCategorizeNote && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAutoCategorizeNote(note, e);
                        setShowCatMenu(false);
                      }}
                      className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 text-amber-800 dark:text-amber-300 font-bold cursor-pointer text-[11px] mb-1.5 border border-amber-200 dark:border-amber-800"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>AI Semantik Kategorile</span>
                    </button>
                  )}

                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 px-2 py-0.5 uppercase tracking-wider">
                    Bölüme Taşı
                  </p>
                  <div className="max-h-36 overflow-y-auto no-scrollbar space-y-0.5 py-1">
                    {availableCategories.map((cat) => (
                      <button
                        key={cat}
                        onClick={(e) => {
                          e.stopPropagation();
                          onChangeCategory && onChangeCategory(note.id, cat);
                          setShowCatMenu(false);
                        }}
                        className="w-full text-left px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 truncate font-medium cursor-pointer"
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {onToggleVault && (
                    <div className="pt-1 mt-1 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleVault(note.id, e);
                          setShowCatMenu(false);
                        }}
                        className="w-full flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-semibold cursor-pointer"
                      >
                        <Lock className="w-3 h-3" />
                        <span>{note.isVault ? "Kasadan Çıkar" : "Kasaya Taşı (Kilitle)"}</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {note.isVault && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-rose-700 dark:text-rose-300 bg-rose-100/80 dark:bg-rose-950/80 px-2 py-0.5 rounded-full border border-rose-200 dark:border-rose-800">
                <Lock className="w-3 h-3" />
                Kilitli (Kasa)
              </span>
            )}

            {note.pinned && (
              <span className="flex items-center gap-1 text-[10px] font-bold text-teal-700 dark:text-teal-300 bg-teal-100/80 dark:bg-teal-950/80 px-2 py-0.5 rounded-full border border-teal-200 dark:border-teal-800">
                <Pin className="w-3 h-3 fill-current" />
                Sabitli
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              onClick={(e) => onToggleFavorite(note.id, e)}
              title={note.favorite ? "Favorilerden Çıkar" : "Favoriye Ekle"}
              className={`p-1.5 rounded-lg transition-colors ${
                note.favorite
                  ? "text-amber-500 hover:bg-amber-100/50 dark:hover:bg-amber-950/40"
                  : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-700/50"
              }`}
            >
              <Star className={`w-4 h-4 ${note.favorite ? "fill-current" : ""}`} />
            </button>

            <button
              onClick={(e) => onTogglePin(note.id, e)}
              title={note.pinned ? "Sabitlemeyi Kaldır" : "Başa Sabitle"}
              className={`p-1.5 rounded-lg transition-colors ${
                note.pinned
                  ? "text-teal-600 dark:text-teal-400 hover:bg-teal-100/50 dark:hover:bg-teal-950/40"
                  : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-700/50"
              }`}
            >
              <Pin className={`w-4 h-4 ${note.pinned ? "fill-current" : ""}`} />
            </button>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug line-clamp-2 pl-0.5 mb-1.5">
          {note.title || "Başlıksız Not"}
        </h3>

        {/* Content Preview / Vault Protection */}
        {note.isVault ? (
          <div className="my-2 p-3 rounded-xl bg-black/5 dark:bg-white/5 border border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <Lock className="w-4 h-4 text-slate-400" />
            <span>Kilitli Not • Görüntülemek için dokunun</span>
          </div>
        ) : (
          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-4 leading-relaxed pl-0.5 whitespace-pre-line mb-3">
            {note.content || "İçerik bulunmuyor..."}
          </p>
        )}

        {/* Task Progress Bar */}
        {!note.isVault && tasksTotal > 0 && (
          <div className="mb-3 pl-0.5">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <CheckSquare className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                Görevler
              </span>
              <span>
                {tasksCompleted}/{tasksTotal} (%{Math.round((tasksCompleted / tasksTotal) * 100)})
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-teal-600 h-full rounded-full transition-all duration-300"
                style={{ width: `${(tasksCompleted / tasksTotal) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Attached Images preview */}
        {!note.isVault && note.attachments && note.attachments.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-hidden mb-3 pl-0.5">
            {note.attachments.slice(0, 3).map((att) =>
              att.mime.startsWith("image/") ? (
                <img
                  key={att.id}
                  src={att.data}
                  alt={att.name}
                  className="w-12 h-12 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                />
              ) : null
            )}
            {note.attachments.length > 3 && (
              <div className="w-12 h-12 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold flex items-center justify-center">
                +{note.attachments.length - 3}
              </div>
            )}
          </div>
        )}

        {/* Tags */}
        {!note.isVault && note.tags && note.tags.length > 0 && (
          <div className="flex items-center gap-1 flex-wrap pl-0.5 mb-2">
            {note.tags.slice(0, 4).map((tag, idx) => (
              <span
                key={idx}
                onClick={(e) => onTagClick && onTagClick(tag, e)}
                className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-white/70 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 border border-slate-200/50 dark:border-slate-700/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                {tag.startsWith("#") ? tag : `#${tag}`}
              </span>
            ))}
            {note.tags.length > 4 && (
              <span className="text-[10px] text-slate-400">+{note.tags.length - 4}</span>
            )}
          </div>
        )}
      </div>

      {/* Card Footer */}
      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/50 flex items-center justify-between text-xs text-slate-400 dark:text-slate-500 pl-1 mt-1">
        <div className="flex items-center gap-1.5 flex-wrap max-w-[60%]">
          <span>{formatDate(note.updatedAt)}</span>

          {note.reminder && (
            <span
              title={`Hatırlatıcı: ${formatDate(note.reminder)}`}
              className="flex items-center gap-1 text-[10px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-1.5 py-0.5 rounded border border-blue-200 dark:border-blue-900"
            >
              <Clock className="w-3 h-3" />
              {new Date(note.reminder).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}
            </span>
          )}

          {hasYoutube && (
            <span title="YouTube Videosu" className="text-red-500">
              <Video className="w-3.5 h-3.5" />
            </span>
          )}

          {note.audioNotes && note.audioNotes.length > 0 && (
            <span title="Ses Kaydı" className="text-teal-600 dark:text-teal-400 flex items-center gap-0.5">
              <Mic className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold">{note.audioNotes.length}</span>
            </span>
          )}

          {note.attachments && note.attachments.length > 0 && (
            <span title="Dosya Eki" className="text-slate-500 flex items-center gap-0.5">
              <Paperclip className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold">{note.attachments.length}</span>
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
          {onOpenInfographic && (
            <button
              onClick={(e) => onOpenInfographic(note, e)}
              title="Yapay Zeka İnfografik Özet"
              className="p-1.5 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            </button>
          )}

          {onSyncNote && (
            <button
              onClick={(e) => onSyncNote(note, e)}
              title="Profil & Kanallara Senkronize Et"
              className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/30 transition-colors"
            >
              <Send className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            </button>
          )}

          {onToggleVault && (
            <button
              onClick={(e) => onToggleVault(note.id, e)}
              title={note.isVault ? "Kasadan Çıkar" : "Kasaya Taşı"}
              className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-colors"
            >
              <Lock className="w-3.5 h-3.5" />
            </button>
          )}

          {onExportNote && (
            <button
              onClick={(e) => onExportNote(note, e)}
              title="Belge Olarak Dışa Aktar (Word, PDF, Excel vb.)"
              className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/30 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={() => onOpen(note)}
            title="Düzenle"
            className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/30 transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={(e) => onDelete(note.id, e)}
            title="Çöpe Taşı"
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
};

export const NoteCard = React.memo(NoteCardComponent);
