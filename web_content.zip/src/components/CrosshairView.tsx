import React from 'react';
import { CrosshairConfig } from '../game/hud/HUDConfig';

interface CrosshairViewProps {
  config: CrosshairConfig;
  isAiming: boolean;
  isMoving: boolean;
  isFiring: boolean;
}

export const CrosshairView: React.FC<CrosshairViewProps> = ({
  config,
  isAiming,
  isMoving,
  isFiring,
}) => {
  const { style, size, opacity, dynamicSpread, color } = config;

  let spread = 0;
  if (dynamicSpread) {
    if (isMoving) spread += 8;
    if (isFiring) spread += 14;
  }
  if (isAiming) {
    spread = Math.max(0, spread - 6);
  }

  const baseSize = isAiming ? size * 0.75 : size;
  const currentSize = baseSize + spread;
  const center = currentSize / 2;

  return (
    <div
      className="pointer-events-none transition-all duration-75 flex items-center justify-center select-none"
      style={{
        width: `${currentSize}px`,
        height: `${currentSize}px`,
        opacity: isAiming ? opacity * 0.55 : opacity,
      }}
    >
      <svg
        width={currentSize}
        height={currentSize}
        viewBox={`0 0 ${currentSize} ${currentSize}`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Style 1: Classic (4 clean cross ticks with gap) */}
        {style === 'classic' && (
          <>
            <line x1={center} y1={center - 3 - spread * 0.4} x2={center} y2={center - 10 - spread * 0.4} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center} y1={center + 3 + spread * 0.4} x2={center} y2={center + 10 + spread * 0.4} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center - 3 - spread * 0.4} y1={center} x2={center - 10 - spread * 0.4} y2={center} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center + 3 + spread * 0.4} y1={center} x2={center + 10 + spread * 0.4} y2={center} stroke={color} strokeWidth={2} strokeLinecap="round" />
          </>
        )}

        {/* Style 2: Dot (Single sharp glowing dot) */}
        {style === 'dot' && (
          <circle cx={center} cy={center} r={2.2} fill={color} />
        )}

        {/* Style 3: Tactical (Center dot + 4 ticks + outer ring) */}
        {style === 'tactical' && (
          <>
            <circle cx={center} cy={center} r={1.5} fill={color} />
            <line x1={center} y1={center - 4 - spread * 0.5} x2={center} y2={center - 11 - spread * 0.5} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center} y1={center + 4 + spread * 0.5} x2={center} y2={center + 11 + spread * 0.5} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center - 4 - spread * 0.5} y1={center} x2={center - 11 - spread * 0.5} y2={center} stroke={color} strokeWidth={2} strokeLinecap="round" />
            <line x1={center + 4 + spread * 0.5} y1={center} x2={center + 11 + spread * 0.5} y2={center} stroke={color} strokeWidth={2} strokeLinecap="round" />
          </>
        )}

        {/* Style 4: Precision (Chevron + range ticks) */}
        {style === 'precision' && (
          <>
            <polyline
              points={`${center - 5} ${center + 4 + spread * 0.3}, ${center} ${center - 3}, ${center + 5} ${center + 4 + spread * 0.3}`}
              stroke={color}
              strokeWidth={2.2}
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
            <circle cx={center - 9 - spread * 0.4} cy={center} r={1.2} fill={color} />
            <circle cx={center + 9 + spread * 0.4} cy={center} r={1.2} fill={color} />
          </>
        )}

        {/* Style 5: Dynamic (Brackets that expand heavily on movement) */}
        {style === 'dynamic' && (
          <>
            <circle cx={center} cy={center} r={1.8} fill={color} />
            <path
              d={`M ${center - 7 - spread * 0.6} ${center - 7} Q ${center - 13 - spread * 0.6} ${center} ${center - 7 - spread * 0.6} ${center + 7}`}
              stroke={color}
              strokeWidth={2}
              strokeLinecap="round"
              fill="none"
            />
            <path
              d={`M ${center + 7 + spread * 0.6} ${center - 7} Q ${center + 13 + spread * 0.6} ${center} ${center + 7 + spread * 0.6} ${center + 7}`}
              stroke={color}
              strokeWidth={2}
              strokeLinecap="round"
              fill="none"
            />
          </>
        )}

        {/* Style 6: Minimal (Clean center dot with 2 subtle horizontal dashes) */}
        {style === 'minimal' && (
          <>
            <circle cx={center} cy={center} r={1.6} fill={color} />
            <line x1={center - 5 - spread * 0.3} y1={center} x2={center - 10 - spread * 0.3} y2={center} stroke={color} strokeWidth={1.5} />
            <line x1={center + 5 + spread * 0.3} y1={center} x2={center + 10 + spread * 0.3} y2={center} stroke={color} strokeWidth={1.5} />
          </>
        )}

        {/* Style 7: Custom (Original spec-ops diamond reticle) */}
        {style === 'custom' && (
          <>
            <polygon
              points={`${center} ${center - 6 - spread * 0.4}, ${center + 6 + spread * 0.4} ${center}, ${center} ${center + 6 + spread * 0.4}, ${center - 6 - spread * 0.4} ${center}`}
              stroke={color}
              strokeWidth={1.8}
              fill="none"
            />
            <circle cx={center} cy={center} r={1.4} fill={color} />
          </>
        )}
      </svg>
    </div>
  );
};
