import React, { useState } from 'react';
import { Copy, Check, Volume2, VolumeX, RotateCcw, User, Bot, Sparkles, Pencil } from 'lucide-react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { speakText, stopSpeech } from '../utils/speech';
import { playSound } from '../utils/soundEffects';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  model?: string;
  latencyMs?: number;
}

interface ChatMessageProps {
  message: Message;
  isStreaming?: boolean;
  soundMuted: boolean;
  onRegenerate?: () => void;
  onEdit?: (content: string) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  isStreaming,
  soundMuted,
  onRegenerate,
  onEdit,
}) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [isSpeakingMessage, setIsSpeakingMessage] = useState(false);

  const handleCopy = () => {
    playSound('click', soundMuted);
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    playSound('click', soundMuted);
    if (isSpeakingMessage) {
      stopSpeech();
      setIsSpeakingMessage(false);
    } else {
      setIsSpeakingMessage(true);
      speakText(
        message.content,
        () => setIsSpeakingMessage(true),
        () => setIsSpeakingMessage(false),
        () => setIsSpeakingMessage(false)
      );
    }
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      className={`group relative flex w-full gap-3 sm:gap-4 px-2 sm:px-4 py-3 transition-colors ${
        isUser ? 'justify-end' : 'justify-start'
      }`}
    >
      {/* Bot Avatar (Left) */}
      {!isUser && (
        <div className="shrink-0 mt-1">
          <div className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-500 to-indigo-600 shadow-md shadow-cyan-500/20 p-0.5">
            <div className="w-full h-full rounded-[10px] bg-[#0f172a] flex items-center justify-center text-cyan-300">
              <Bot className="w-4 h-4 text-cyan-400" />
            </div>
            {isStreaming && (
              <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
              </span>
            )}
          </div>
        </div>
      )}

      {/* Message Content Bubble */}
      <div
        className={`relative max-w-[88%] sm:max-w-[80%] md:max-w-[74%] rounded-2xl p-4 sm:p-5 shadow-lg ${
          isUser
            ? 'bg-gradient-to-br from-blue-600 via-blue-600 to-indigo-600 text-white rounded-tr-none border border-blue-400/30'
            : 'bg-[#1d293b]/95 text-slate-100 rounded-tl-none border border-cyan-500/20 shadow-cyan-950/40 backdrop-blur-sm'
        }`}
      >
        {/* Top metadata */}
        <div
          className={`flex items-center gap-2 mb-1.5 text-[11px] font-medium ${
            isUser ? 'text-blue-200 justify-end' : 'text-cyan-400/90'
          }`}
        >
          <span className="font-semibold">{isUser ? 'Vous' : 'GPT-6'}</span>
          <span className="opacity-60">•</span>
          <span className="opacity-60">{formattedTime}</span>
          {!isUser && message.latencyMs && (
            <>
              <span className="opacity-60">•</span>
              <span className="text-[10px] text-cyan-300/80 bg-cyan-950/60 border border-cyan-500/30 px-1.5 py-0.2 rounded">
                {(message.latencyMs / 1000).toFixed(2)}s
              </span>
            </>
          )}
        </div>

        {/* Body Text */}
        <div className="text-sm sm:text-base leading-relaxed break-words">
          {isUser ? (
            <p className="whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div>
              <MarkdownRenderer content={message.content} />
              {isStreaming && (
                <span className="inline-block w-2 h-4 ml-1 bg-cyan-400 animate-cursor align-middle rounded-sm" />
              )}
            </div>
          )}
        </div>

        {/* Message Action Bar */}
        <div
          className={`mt-3 pt-2 flex items-center gap-1 border-t opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity ${
            isUser ? 'border-blue-500/30 justify-end' : 'border-slate-700/50 justify-start'
          }`}
        >
          {/* Copy button */}
          <button
            onClick={handleCopy}
            className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition-colors ${
              isUser
                ? 'text-blue-100 hover:bg-blue-700/50'
                : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800'
            }`}
            title="Copier le message"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-300" />
                <span className="text-[11px] text-emerald-300">Copié</span>
              </>
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Text-To-Speech button */}
          <button
            onClick={handleSpeak}
            className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition-colors ${
              isSpeakingMessage
                ? 'text-cyan-300 bg-cyan-500/20'
                : isUser
                ? 'text-blue-100 hover:bg-blue-700/50'
                : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800'
            }`}
            title={isSpeakingMessage ? 'Arrêter la lecture' : 'Écouter le message'}
          >
            {isSpeakingMessage ? (
              <VolumeX className="w-3.5 h-3.5 animate-pulse text-cyan-300" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Regenerate (for bot) */}
          {!isUser && onRegenerate && !isStreaming && (
            <button
              onClick={() => {
                playSound('click', soundMuted);
                onRegenerate();
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 text-xs flex items-center gap-1 transition-colors"
              title="Régénérer la réponse"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="text-[11px] hidden sm:inline">Régénérer</span>
            </button>
          )}

          {/* Edit (for user) */}
          {isUser && onEdit && (
            <button
              onClick={() => {
                playSound('click', soundMuted);
                onEdit(message.content);
              }}
              className="p-1.5 rounded-lg text-blue-100 hover:bg-blue-700/50 text-xs flex items-center gap-1 transition-colors"
              title="Modifier ce message"
            >
              <Pencil className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* User Avatar (Right) */}
      {isUser && (
        <div className="shrink-0 mt-1">
          <div className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-blue-600 border border-blue-400/40 text-white shadow-md shadow-blue-600/30">
            <User className="w-4 h-4" />
          </div>
        </div>
      )}
    </div>
  );
};
