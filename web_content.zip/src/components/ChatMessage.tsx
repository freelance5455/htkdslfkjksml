import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Bot, User, Copy, Check, Volume2, VolumeX, RotateCcw, Radio } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../types/chat';

interface ChatMessageProps {
  message: ChatMessageType;
  onRetry?: (content: string) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onRetry }) => {
  const isAssistant = message.role === 'assistant';
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Copy full message content
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Clean Markdown formatting before sending to Web Speech API
  const cleanMarkdownForSpeech = (rawText: string): string => {
    return rawText
      .replace(/```[\s\S]*?```/g, 'كود برمجي') // replace long code blocks
      .replace(/`([^`]+)`/g, '$1') // inline code
      .replace(/#+\s*/g, '') // headers
      .replace(/[*_~]{1,3}([^*_~]+)[*_~]{1,3}/g, '$1') // bold / italic / strikethrough
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // links
      .replace(/^[*\-+]\s+/gm, '') // unordered lists
      .replace(/^\d+\.\s+/gm, '') // ordered lists
      .replace(/>\s*/g, '') // blockquotes
      .replace(/\|[^\n]+\|/g, '') // tables
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Web Speech API (Text-to-Speech)
  const handleToggleSpeak = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      console.warn('Web Speech API is not supported in this browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Stop any ongoing speech
    window.speechSynthesis.cancel();

    const cleanText = cleanMarkdownForSpeech(message.content);
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ar-SA';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    // Pick best Arabic voice
    const voices = window.speechSynthesis.getVoices();
    const arabicVoice =
      voices.find((v) => v.lang === 'ar-SA') ||
      voices.find((v) => v.lang.startsWith('ar')) ||
      voices.find((v) => v.name.toLowerCase().includes('arabic'));

    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      setIsSpeaking(false);
    };

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Cleanup speech on unmount
  useEffect(() => {
    return () => {
      if (isSpeaking && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isSpeaking]);

  return (
    <div
      className={`w-full py-3 px-3 sm:px-4 rounded-2xl transition-all duration-200 ${
        isAssistant
          ? 'bg-[#0E172E]/95 border border-blue-900/40 shadow-lg shadow-blue-950/20'
          : 'bg-[#152347] border border-blue-700/30'
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div
          className={`flex-shrink-0 w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center font-bold text-sm shadow-md ${
            isAssistant
              ? 'bg-gradient-to-tr from-blue-700 to-cyan-500 text-white shadow-blue-600/30 ring-1 ring-blue-400/40'
              : 'bg-gradient-to-tr from-slate-700 to-blue-900 text-slate-200 ring-1 ring-slate-600/40'
          }`}
        >
          {isAssistant ? <Bot className="w-4 h-4 sm:w-5 sm:h-5" /> : <User className="w-4 h-4 sm:w-5 sm:h-5" />}
        </div>

        {/* Message Content Container */}
        <div className="flex-1 min-w-0">
          {/* Header info with prominent TTS speaker icon */}
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-2">
              <span
                className={`text-xs font-bold ${
                  isAssistant ? 'text-blue-300' : 'text-slate-300'
                }`}
              >
                {isAssistant ? 'Mostafa AI' : 'أنت'}
              </span>

              {/* Speaker icon right next to AI name */}
              {isAssistant && !message.isStreaming && message.content.length > 0 && (
                <button
                  type="button"
                  onClick={handleToggleSpeak}
                  title={isSpeaking ? 'إيقاف القراءة الصوتية' : 'تشغيل القراءة الصوتية (Web Speech API)'}
                  aria-label={isSpeaking ? 'إيقاف القراءة' : 'استماع للرد'}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium transition-all active:scale-95 ${
                    isSpeaking
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm shadow-cyan-500/30 animate-pulse'
                      : 'bg-blue-950/70 hover:bg-blue-900/70 text-blue-400 hover:text-cyan-300 border border-blue-800/40'
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                      <span className="text-[10px]">إيقاف</span>
                      {/* Animated sound bars */}
                      <span className="flex items-center gap-0.5 mr-0.5">
                        <span className="w-0.5 h-2.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-0.5 h-3.5 bg-cyan-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-0.5 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="text-[10px]">استماع</span>
                    </>
                  )}
                </button>
              )}
            </div>

            <span className="text-[10px] text-slate-400/70 font-mono">
              {new Date(message.timestamp).toLocaleTimeString('ar-EG', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          </div>

          {/* Attached Image Preview if exists */}
          {message.image?.previewUrl && (
            <div className="mb-2 max-w-xs rounded-xl overflow-hidden border border-blue-500/30 shadow-md">
              <img
                src={message.image.previewUrl}
                alt="الصورة المرفقة"
                className="w-full h-auto object-cover max-h-56"
              />
            </div>
          )}

          {/* Text Content */}
          <div className="text-slate-100 text-sm sm:text-[15px] leading-relaxed break-words prose-arabic">
            {isAssistant ? (
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || '');
                    const codeString = String(children).replace(/\n$/, '');
                    const isInline = !match && !codeString.includes('\n');

                    if (isInline) {
                      return (
                        <code className="bg-blue-950/70 text-blue-200 px-1.5 py-0.5 rounded text-xs font-mono border border-blue-800/40" {...props}>
                          {children}
                        </code>
                      );
                    }

                    return (
                      <div className="my-3 rounded-xl overflow-hidden border border-blue-800/50 bg-[#070D1E] shadow-inner font-mono text-xs sm:text-sm">
                        <div className="flex items-center justify-between px-3 py-1.5 bg-blue-950/60 border-b border-blue-900/50 text-slate-300 text-xs">
                          <span className="text-cyan-400 font-semibold">{match ? match[1] : 'code'}</span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(codeString);
                            }}
                            className="flex items-center gap-1 text-[11px] hover:text-white text-slate-400 transition-colors"
                          >
                            <Copy className="w-3 h-3" />
                            <span>نسخ الكود</span>
                          </button>
                        </div>
                        <pre className="p-3 overflow-x-auto text-blue-100/90 leading-normal">
                          <code>{children}</code>
                        </pre>
                      </div>
                    );
                  },
                }}
              >
                {message.content}
              </ReactMarkdown>
            ) : (
              <p className="whitespace-pre-wrap">{message.content}</p>
            )}

            {/* Blinking indicator when streaming */}
            {message.isStreaming && (
              <span className="inline-block w-2 h-4 bg-cyan-400 ml-1 animate-pulse align-middle" />
            )}
          </div>

          {/* Action Toolbar for Assistant message */}
          {isAssistant && !message.isStreaming && message.content.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-blue-900/30">
              {/* Copy */}
              <button
                onClick={handleCopy}
                title="نسخ الرد"
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs text-slate-400 hover:text-blue-300 hover:bg-blue-900/30 transition-all active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px]">{copied ? 'تم النسخ' : 'نسخ النص'}</span>
              </button>

              {/* Text to Speech in toolbar */}
              <button
                onClick={handleToggleSpeak}
                title={isSpeaking ? 'إيقاف القراءة الصوتية' : 'قراءة صوتية (TTS)'}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all active:scale-95 ${
                  isSpeaking
                    ? 'text-cyan-300 bg-cyan-950/60 ring-1 ring-cyan-500/40 shadow-sm shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-cyan-300 hover:bg-blue-900/30'
                }`}
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-cyan-400" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
                <span className="text-[11px]">{isSpeaking ? 'إيقاف القراءة' : 'قراءة صوتية'}</span>
              </button>

              {/* Retry if callback provided */}
              {onRetry && (
                <button
                  onClick={() => onRetry(message.content)}
                  title="إعادة التوليد"
                  className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-slate-400 hover:text-amber-300 hover:bg-amber-950/20 transition-all active:scale-95 mr-auto"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="text-[11px]">إعادة</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
