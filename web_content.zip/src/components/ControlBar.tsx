import React, { useState } from 'react';
import { AssistantState } from '../types/jarvis';
import {
  Mic,
  MicOff,
  Square,
  Send,
  MessageSquare,
  Settings,
  Languages,
  Keyboard,
  X,
  Volume2,
  VolumeX,
  Power,
  PowerOff,
  Octagon,
} from 'lucide-react';

interface ControlBarProps {
  state: AssistantState;
  isHandsFreeActive: boolean;
  onToggleHandsFree: () => void;
  onToggleListen: () => void;
  onEmergencyStop: () => void;
  onSendMessage: (text: string) => void;
  onOpenConsole: () => void;
  onOpenSettings: () => void;
  onCycleLanguage: () => void;
  currentLanguage: string;
  isMicAvailable: boolean;
  voiceEnabled: boolean;
  onToggleVoiceMute: () => void;
}

export const ControlBar: React.FC<ControlBarProps> = ({
  state,
  isHandsFreeActive,
  onToggleHandsFree,
  onToggleListen,
  onEmergencyStop,
  onSendMessage,
  onOpenConsole,
  onOpenSettings,
  onCycleLanguage,
  currentLanguage,
  isMicAvailable,
  voiceEnabled,
  onToggleVoiceMute,
}) => {
  const [showTextInput, setShowTextInput] = useState(false);
  const [inputText, setInputText] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() && state !== 'thinking') {
      onSendMessage(inputText.trim());
      setInputText('');
    }
  };

  const getLanguageShortCode = (code: string) => {
    switch (code) {
      case 'bn':
        return 'বাংলা';
      case 'en':
        return 'EN';
      case 'hi':
        return 'हिन्दी';
      case 'es':
        return 'ES';
      case 'fr':
        return 'FR';
      case 'ar':
        return 'AR';
      case 'auto':
      default:
        return 'AUTO';
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto px-3 pb-3 sm:pb-6 pt-1 z-20 flex flex-col gap-2">
      {/* Top Quick Actions Row: Hands-Free Voice Mode toggle + Emergency Stop + Mute */}
      <div className="flex items-center justify-between gap-2 px-1">
        {/* Hands-Free Voice Mode Toggle Button */}
        <button
          onClick={onToggleHandsFree}
          title={isHandsFreeActive ? 'Stop Continuous Voice Mode' : 'Start Continuous Voice Mode'}
          className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-98 cursor-pointer ${
            isHandsFreeActive
              ? 'bg-cyan-950/90 border-cyan-400 text-cyan-200 shadow-cyan-900/40 ring-1 ring-cyan-400/50'
              : 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-cyan-500/50'
          }`}
        >
          {isHandsFreeActive ? (
            <>
              <Power className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>VOICE MODE: ON</span>
            </>
          ) : (
            <>
              <PowerOff className="w-3.5 h-3.5 text-slate-400" />
              <span>START VOICE MODE</span>
            </>
          )}
        </button>

        {/* Emergency Stop Button */}
        {(state === 'speaking' || state === 'listening' || state === 'thinking') && (
          <button
            onClick={onEmergencyStop}
            title="Emergency Stop: Halt speech & reset"
            className="py-1.5 px-3 rounded-xl bg-red-950/80 hover:bg-red-900/90 border border-red-500/80 text-red-200 text-xs font-mono font-bold flex items-center gap-1.5 transition-all active:scale-95 shadow-md shadow-red-950/50 cursor-pointer animate-fade-in"
          >
            <Octagon className="w-3.5 h-3.5 text-red-400 fill-red-500/20" />
            <span>HALT / STOP</span>
          </button>
        )}

        {/* TTS Mute Toggle */}
        <button
          onClick={onToggleVoiceMute}
          title={voiceEnabled ? 'Mute AI voice output' : 'Unmute AI voice output'}
          className={`py-1.5 px-2.5 rounded-xl border text-xs font-mono transition-colors flex items-center gap-1 cursor-pointer ${
            voiceEnabled
              ? 'bg-slate-900/80 border-cyan-500/30 text-cyan-300 hover:bg-cyan-950/40'
              : 'bg-amber-950/60 border-amber-500/50 text-amber-300'
          }`}
        >
          {voiceEnabled ? (
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
          ) : (
            <VolumeX className="w-3.5 h-3.5 text-amber-400" />
          )}
          <span className="hidden xs:inline">{voiceEnabled ? 'VOICE ON' : 'MUTED'}</span>
        </button>
      </div>

      {/* Expandable Text Input Bar (Voice-First Backup) */}
      {showTextInput && (
        <form
          onSubmit={handleSend}
          className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900/95 border border-cyan-500/40 shadow-xl shadow-cyan-950/60 backdrop-blur-md animate-fade-in"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              currentLanguage === 'bn'
                ? 'টাইপ করুন বা কমান্ড দিন...'
                : 'Type your command to JARVIS...'
            }
            className="flex-1 bg-transparent px-3 py-2 text-sm text-cyan-100 placeholder-cyan-500/50 focus:outline-none"
            autoFocus
          />
          <button
            type="submit"
            disabled={!inputText.trim() || state === 'thinking'}
            className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 disabled:hover:bg-cyan-500 text-slate-950 transition-all active:scale-95 flex items-center justify-center cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setShowTextInput(false)}
            className="p-2.5 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </form>
      )}

      {/* Main Bottom Control Navigation Bar */}
      <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-slate-950/85 border border-cyan-500/30 backdrop-blur-md shadow-xl shadow-cyan-950/30">
        {/* Left Side: Text Backup & Language Quick Switch */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowTextInput(!showTextInput)}
            title="Toggle text input keyboard"
            className={`p-2.5 rounded-xl transition-all cursor-pointer ${
              showTextInput
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-900'
            }`}
          >
            <Keyboard className="w-5 h-5" />
          </button>

          <button
            onClick={onCycleLanguage}
            title="Switch Language (AUTO / EN / বাংলা)"
            className="px-2.5 py-1.5 rounded-xl bg-slate-900/80 border border-cyan-500/30 text-cyan-300 hover:text-cyan-100 hover:bg-cyan-950/50 flex items-center gap-1 text-xs font-mono transition-colors cursor-pointer"
          >
            <Languages className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">{getLanguageShortCode(currentLanguage)}</span>
          </button>
        </div>

        {/* Center: Primary Voice Action Button */}
        <div className="relative -mt-6">
          {state === 'speaking' ? (
            <button
              onClick={onEmergencyStop}
              title="Interrupt & Stop Speaking"
              className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/50 border-2 border-red-400 animate-pulse active:scale-95 transition-transform cursor-pointer"
            >
              <Square className="w-6 h-6 fill-current" />
            </button>
          ) : (
            <button
              onClick={onToggleListen}
              title={
                state === 'listening'
                  ? 'Stop Listening'
                  : isHandsFreeActive
                  ? 'Hands-Free Active (Tap to force listen)'
                  : 'Speak to JARVIS'
              }
              disabled={!isMicAvailable && state !== 'listening'}
              className={`w-16 h-16 rounded-full flex items-center justify-center border-2 transition-all active:scale-95 cursor-pointer ${
                state === 'listening'
                  ? 'bg-cyan-400 text-slate-950 border-white shadow-[0_0_25px_rgba(0,240,255,0.8)] animate-pulse'
                  : state === 'thinking'
                  ? 'bg-sky-900 text-cyan-300 border-sky-400 animate-spin'
                  : state === 'sleeping'
                  ? 'bg-gradient-to-tr from-cyan-950 to-blue-950 text-cyan-300 border-cyan-600/60 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'bg-gradient-to-tr from-cyan-600 to-blue-600 text-white border-cyan-300/80 shadow-[0_0_20px_rgba(0,240,255,0.4)]'
              }`}
            >
              {state === 'listening' ? (
                <MicOff className="w-7 h-7" />
              ) : (
                <Mic className="w-7 h-7" />
              )}
            </button>
          )}
        </div>

        {/* Right Side: Conversation Console & Settings */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenConsole}
            title="Tactical Message Log"
            className="p-2.5 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <MessageSquare className="w-5 h-5" />
          </button>

          <button
            onClick={onOpenSettings}
            title="Settings & Browser Permissions"
            className="p-2.5 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
