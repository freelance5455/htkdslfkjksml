import type { ReactNode } from "react";

const W = "var(--color-sign-white)";
const K = "var(--color-sign-black)";
const R = "var(--color-sign-red)";
const B = "var(--color-sign-blue)";
const Y = "var(--color-sign-yellow)";
const G = "var(--color-sign-green)";
const O = "var(--color-sign-orange)";

const sans = "Arial, Helvetica, sans-serif";

function Tri({ children }: { children?: ReactNode }) {
  return (
    <g>
      <polygon points="60,5 115,112 5,112" fill={R} />
      <polygon points="60,22 100,104 20,104" fill={W} />
      {children}
    </g>
  );
}

function Ring({ children }: { children?: ReactNode }) {
  return (
    <g>
      <circle cx="60" cy="60" r="54" fill={W} stroke={R} strokeWidth="11" />
      {children}
    </g>
  );
}

function Blue({ children }: { children?: ReactNode }) {
  return (
    <g>
      <circle cx="60" cy="60" r="54" fill={B} />
      {children}
    </g>
  );
}

function stroke(d: string, color: string, width = 7) {
  return (
    <path
      d={d}
      fill="none"
      stroke={color}
      strokeWidth={width}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  );
}

function Person({ x, y, color }: { x: number; y: number; color: string }) {
  return (
    <g transform={`translate(${x} ${y})`} fill={color} stroke={color} strokeLinecap="round">
      <circle cx="0" cy="0" r="5" stroke="none" />
      <path d="M0 6 V22 M0 12 L-9 18 M0 12 L9 18 M0 22 L-7 34 M0 22 L7 34" fill="none" strokeWidth="4" />
    </g>
  );
}

function CarSide({ x, y, color, flip }: { x: number; y: number; color: string; flip?: boolean }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -1 : 1} 1)`} fill={color}>
      <path d="M-16 4 H6 L12 -4 H4 L-2 -12 H-14 Z" />
      <circle cx="-10" cy="6" r="3.2" fill={W} />
      <circle cx="6" cy="6" r="3.2" fill={W} />
    </g>
  );
}

function Arrow({ color, rotate = 0 }: { color: string; rotate?: number }) {
  return (
    <g transform={`rotate(${rotate} 60 60)`}>
      {stroke(`M34 60 H82 M66 44 L84 60 L66 76`, color, 9)}
    </g>
  );
}

function SpeedDisc({ n, end, min }: { n: string; end?: boolean; min?: boolean }) {
  if (min) {
    return (
      <Blue>
        <text x="60" y="70" textAnchor="middle" fontFamily={sans} fontSize="32" fontWeight="700" fill={W}>
          {n}
        </text>
      </Blue>
    );
  }
  return (
    <g>
      <circle cx="60" cy="60" r="54" fill={W} stroke={end ? K : R} strokeWidth={end ? 6 : 11} />
      <text
        x="60"
        y="72"
        textAnchor="middle"
        fontFamily={sans}
        fontSize="34"
        fontWeight="700"
        fill={end ? "#8a8a8a" : K}
      >
        {n}
      </text>
      {end ? <line x1="24" y1="96" x2="96" y2="24" stroke={K} strokeWidth="8" /> : null}
    </g>
  );
}

function renderBody(id: string): ReactNode {
  if (id.startsWith("limite-")) return <SpeedDisc n={id.slice(7)} />;
  if (id.startsWith("fine-limite-")) return <SpeedDisc n={id.slice(12)} end />;
  if (id.startsWith("vmin-")) return <SpeedDisc n={id.slice(5)} min />;

  switch (id) {
    case "curva-dx":
      return <Tri>{stroke("M40 86 V64 C40 46 58 42 76 42 H84 M68 30 L86 42 L68 54", K)}</Tri>;
    case "curva-sx":
      return (
        <Tri>
          <g transform="translate(120 0) scale(-1 1)">{stroke("M40 86 V64 C40 46 58 42 76 42 H84 M68 30 L86 42 L68 54", K)}</g>
        </Tri>
      );
    case "doppia-dx":
      return <Tri>{stroke("M34 88 C34 70 48 64 58 56 C68 48 70 40 78 34 M66 28 L82 32 L72 46", K, 6)}</Tri>;
    case "doppia-sx":
      return (
        <Tri>
          <g transform="translate(120 0) scale(-1 1)">
            {stroke("M34 88 C34 70 48 64 58 56 C68 48 70 40 78 34 M66 28 L82 32 L72 46", K, 6)}
          </g>
        </Tri>
      );
    case "dosso":
      return <Tri>{stroke("M30 80 H44 C50 80 52 58 60 52 C68 58 70 80 76 80 H90", K)}</Tri>;
    case "cunetta":
      return <Tri>{stroke("M30 58 H44 C52 58 54 80 60 84 C66 80 68 58 76 58 H90", K)}</Tri>;
    case "dissestata":
      return <Tri>{stroke("M28 70 H40 L48 56 L56 82 L66 50 L74 74 H92", K, 6)}</Tri>;
    case "strettoia":
      return (
        <Tri>
          {stroke("M34 40 L48 60 L34 80", K, 6)}
          {stroke("M86 40 L72 60 L86 80", K, 6)}
        </Tri>
      );
    case "strettoia-dx":
      return (
        <Tri>
          {stroke("M32 42 H78", K, 6)}
          {stroke("M32 86 H58 L78 60 L58 42", K, 6)}
        </Tri>
      );
    case "discesa":
      return (
        <Tri>
          {stroke("M32 48 H88", K, 5)}
          <polygon points="36,70 86,48 86,70" fill={K} />
        </Tri>
      );
    case "salita":
      return (
        <Tri>
          {stroke("M32 78 H88", K, 5)}
          <polygon points="36,78 86,56 86,78" fill={K} />
        </Tri>
      );
    case "sdrucciolevole":
      return (
        <Tri>
          <CarSide x={58} y={58} color={K} />
          {stroke("M36 86 C48 74 70 98 88 82", K, 5)}
        </Tri>
      );
    case "bambini":
      return (
        <Tri>
          <Person x={50} y={48} color={K} />
          <Person x={74} y={54} color={K} />
        </Tri>
      );
    case "pedoni":
      return (
        <Tri>
          <Person x={60} y={46} color={K} />
        </Tri>
      );
    case "bici-pericolo":
      return (
        <Tri>
          <circle cx="46" cy="78" r="9" fill="none" stroke={K} strokeWidth="4" />
          <circle cx="78" cy="78" r="9" fill="none" stroke={K} strokeWidth="4" />
          {stroke("M46 78 L60 58 L74 74 M60 58 L78 78 M60 58 L52 50", K, 4)}
        </Tri>
      );
    case "animali":
      return (
        <Tri>
          {stroke("M36 80 C40 62 50 66 54 54 C58 66 70 60 74 48", K, 5)}
          <circle cx="78" cy="44" r="5" fill={K} />
          {stroke("M40 80 L34 92 M58 80 L52 94 M70 78 L78 92", K, 4)}
        </Tri>
      );
    case "selvatici":
      return (
        <Tri>
          {stroke("M34 82 L48 60 L60 74 L78 46", K, 5)}
          <polygon points="78,40 88,48 74,50" fill={K} />
          {stroke("M46 82 L40 96 M62 82 L70 96", K, 4)}
        </Tri>
      );
    case "lavori":
      return (
        <Tri>
          <Person x={48} y={50} color={K} />
          <polygon points="70,52 92,52 84,88 62,88" fill={K} />
        </Tri>
      );
    case "massi":
      return (
        <Tri>
          <polygon points="78,36 96,70 60,70" fill={K} />
          <polygon points="40,78 70,78 58,96 34,96" fill={K} />
        </Tri>
      );
    case "ghiaia":
      return (
        <Tri>
          <circle cx="42" cy="70" r="4" fill={K} />
          <circle cx="56" cy="84" r="3.5" fill={K} />
          <circle cx="70" cy="68" r="4" fill={K} />
          <circle cx="82" cy="86" r="3" fill={K} />
          <CarSide x={58} y={52} color={K} />
        </Tri>
      );
    case "banchina":
      return (
        <Tri>
          {stroke("M36 42 V92 M84 42 V92", K, 5)}
          {stroke("M36 70 H58", K, 5)}
          <polygon points="58,62 78,70 58,78" fill={K} />
        </Tri>
      );
    case "passaggio-barriere":
      return (
        <Tri>
          {stroke("M32 70 H88", K, 6)}
          <rect x="36" y="58" width="6" height="28" fill={K} />
          <rect x="78" y="58" width="6" height="28" fill={K} />
          <rect x="46" y="64" width="10" height="8" fill={R} />
          <rect x="62" y="64" width="10" height="8" fill={W} stroke={K} />
        </Tri>
      );
    case "passaggio-senza":
      return (
        <Tri>
          {stroke("M34 86 H86 M48 86 V48 H72 V86", K, 5)}
          <polygon points="52,48 68,48 60,36" fill={K} />
        </Tri>
      );
    case "croce":
      return (
        <g>
          <g transform="translate(60 60) rotate(45)">
            <rect x="-50" y="-9" width="100" height="18" fill={W} stroke={R} strokeWidth="5" />
          </g>
          <g transform="translate(60 60) rotate(-45)">
            <rect x="-50" y="-9" width="100" height="18" fill={W} stroke={R} strokeWidth="5" />
          </g>
        </g>
      );
    case "semaforo-pericolo":
      return (
        <Tri>
          <rect x="50" y="40" width="20" height="48" rx="4" fill={K} />
          <circle cx="60" cy="50" r="4" fill={R} />
          <circle cx="60" cy="62" r="4" fill={Y} />
          <circle cx="60" cy="74" r="4" fill={G} />
        </Tri>
      );
    case "intersezione":
      return <Tri>{stroke("M60 40 V92 M36 66 H84", K, 7)}</Tri>;
    case "precedenza-incrocio":
      return (
        <Tri>
          {stroke("M60 38 V96", K, 10)}
          {stroke("M34 68 H86", K, 5)}
        </Tri>
      );
    case "confluenza-dx":
      return <Tri>{stroke("M60 38 V96 M60 62 L88 40", K, 6)}</Tri>;
    case "confluenza-sx":
      return <Tri>{stroke("M60 38 V96 M60 62 L32 40", K, 6)}</Tri>;
    case "vento":
      return (
        <Tri>
          {stroke("M36 78 C50 70 48 58 64 56 C78 54 80 44 92 40", K, 5)}
          <polygon points="30,70 18,84 40,80" fill={K} />
        </Tri>
      );
    case "doppio-senso":
      return (
        <Tri>
          {stroke("M46 40 V88 M46 40 L38 52 M46 40 L54 52", K, 5)}
          {stroke("M74 88 V40 M74 88 L66 76 M74 88 L82 76", K, 5)}
        </Tri>
      );
    case "altri":
      return (
        <Tri>
          <text x="60" y="78" textAnchor="middle" fontSize="42" fontWeight="700" fill={K} fontFamily={sans}>
            !
          </text>
        </Tri>
      );
    case "transito":
      return <Ring />;
    case "senso-vietato":
      return (
        <g>
          <circle cx="60" cy="60" r="54" fill={R} />
          <rect x="16" y="49" width="88" height="22" fill={W} />
        </g>
      );
    case "sorpasso":
      return (
        <Ring>
          <CarSide x={52} y={46} color={K} />
          <CarSide x={70} y={70} color={R} />
        </Ring>
      );
    case "fine-sorpasso":
      return (
        <g>
          <circle cx="60" cy="60" r="54" fill={W} stroke={K} strokeWidth="6" />
          <CarSide x={52} y={46} color="#9a9a9a" />
          <CarSide x={70} y={70} color="#9a9a9a" />
          <line x1="22" y1="98" x2="98" y2="22" stroke={K} strokeWidth="8" />
        </g>
      );
    case "sosta":
      return (
        <Ring>
          <line x1="28" y1="92" x2="92" y2="28" stroke={R} strokeWidth="10" />
          <line x1="28" y1="28" x2="92" y2="92" stroke={B} strokeWidth="10" />
        </Ring>
      );
    case "fermata":
      return (
        <Ring>
          <line x1="26" y1="94" x2="94" y2="26" stroke={R} strokeWidth="10" />
          <line x1="26" y1="26" x2="94" y2="94" stroke={R} strokeWidth="10" />
        </Ring>
      );
    case "clacson":
      return (
        <Ring>
          <path d="M40 70 H52 L70 82 V42 L52 54 H40 Z" fill={K} />
          <line x1="76" y1="48" x2="88" y2="36" stroke={R} strokeWidth="6" />
          <line x1="78" y1="62" x2="94" y2="62" stroke={R} strokeWidth="6" />
          <line x1="24" y1="96" x2="96" y2="24" stroke={R} strokeWidth="8" />
        </Ring>
      );
    case "inversione":
      return (
        <Ring>
          {stroke("M40 70 H78 C86 70 86 46 74 46 H48", K, 6)}
          <polygon points="40,60 28,70 40,80" fill={K} />
          <line x1="26" y1="96" x2="96" y2="24" stroke={R} strokeWidth="8" />
        </Ring>
      );
    case "divieto-auto":
      return (
        <Ring>
          <CarSide x={60} y={58} color={K} />
        </Ring>
      );
    case "divieto-camion":
      return (
        <Ring>
          <rect x="34" y="50" width="36" height="18" fill={K} />
          <rect x="70" y="56" width="16" height="12" fill={K} />
          <circle cx="44" cy="72" r="4" fill={K} />
          <circle cx="74" cy="72" r="4" fill={K} />
        </Ring>
      );
    case "divieto-pedoni":
      return (
        <Ring>
          <Person x={60} y={42} color={K} />
        </Ring>
      );
    case "divieto-bici":
      return (
        <Ring>
          <circle cx="46" cy="70" r="8" fill="none" stroke={K} strokeWidth="4" />
          <circle cx="76" cy="70" r="8" fill="none" stroke={K} strokeWidth="4" />
          {stroke("M46 70 L58 52 L72 68 M58 52 L76 70", K, 4)}
        </Ring>
      );
    case "fine-divieti":
      return (
        <g>
          <circle cx="60" cy="60" r="54" fill={W} stroke={K} strokeWidth="5" />
          <line x1="28" y1="92" x2="92" y2="28" stroke={K} strokeWidth="6" />
          <line x1="36" y1="100" x2="100" y2="36" stroke={K} strokeWidth="6" />
        </g>
      );
    case "dritto":
      return <Blue><Arrow color={W} rotate={-90} /></Blue>;
    case "destra":
      return <Blue><Arrow color={W} rotate={0} /></Blue>;
    case "sinistra":
      return <Blue><Arrow color={W} rotate={180} /></Blue>;
    case "dritto-destra":
      return (
        <Blue>
          {stroke("M60 86 V40 M60 40 L48 54 M60 40 L72 54 M60 62 H88 M76 50 L90 62 L76 74", W, 8)}
        </Blue>
      );
    case "passaggio-dx":
      return (
        <Blue>
          {stroke("M42 30 V90", W, 8)}
          <polygon points="58,36 90,60 58,84" fill={W} />
        </Blue>
      );
    case "rotatoria":
      return (
        <Blue>
          <circle cx="60" cy="60" r="22" fill="none" stroke={W} strokeWidth="7" />
          <polygon points="78,30 96,40 76,48" fill={W} />
          <polygon points="42,90 24,80 44,72" fill={W} />
          <polygon points="28,42 40,24 48,44" fill={W} />
        </Blue>
      );
    case "pedoni-obb":
      return (
        <Blue>
          <Person x={60} y={40} color={W} />
        </Blue>
      );
    case "bici-obb":
      return (
        <Blue>
          <circle cx="44" cy="72" r="10" fill="none" stroke={W} strokeWidth="4" />
          <circle cx="80" cy="72" r="10" fill="none" stroke={W} strokeWidth="4" />
          {stroke("M44 72 L58 50 L76 70 M58 50 L80 72 M58 50 L50 42", W, 4)}
        </Blue>
      );
    case "catene":
      return (
        <Blue>
          <circle cx="44" cy="60" r="10" fill="none" stroke={W} strokeWidth="5" />
          <circle cx="64" cy="60" r="10" fill="none" stroke={W} strokeWidth="5" />
          <circle cx="84" cy="60" r="10" fill="none" stroke={W} strokeWidth="5" />
        </Blue>
      );
    case "dare":
      return (
        <g>
          <polygon points="6,8 114,8 60,114" fill={R} />
          <polygon points="22,18 98,18 60,96" fill={W} />
        </g>
      );
    case "stop":
      return (
        <g>
          <polygon points="36,6 84,6 114,36 114,84 84,114 36,114 6,84 6,36" fill={R} />
          <text x="60" y="70" textAnchor="middle" fontFamily={sans} fontSize="26" fontWeight="700" fill={W}>
            STOP
          </text>
        </g>
      );
    case "diritto":
      return (
        <g>
          <polygon points="60,4 116,60 60,116 4,60" fill={Y} />
          <polygon points="60,18 102,60 60,102 18,60" fill={W} />
        </g>
      );
    case "fine-diritto":
      return (
        <g>
          <polygon points="60,4 116,60 60,116 4,60" fill={Y} />
          <polygon points="60,18 102,60 60,102 18,60" fill={W} />
          <line x1="24" y1="96" x2="96" y2="24" stroke={K} strokeWidth="8" />
        </g>
      );
    case "autostrada":
      return (
        <g>
          <rect x="8" y="28" width="104" height="64" rx="6" fill={G} />
          {stroke("M28 78 H92", W, 5)}
          {stroke("M40 78 V48 H80 V78", W, 4)}
          <polygon points="52,48 68,48 60,36" fill={W} />
        </g>
      );
    case "fine-autostrada":
      return (
        <g>
          <rect x="8" y="28" width="104" height="64" rx="6" fill={G} />
          {stroke("M28 78 H92", W, 5)}
          {stroke("M40 78 V48 H80 V78", W, 4)}
          <line x1="18" y1="84" x2="102" y2="36" stroke={R} strokeWidth="8" />
        </g>
      );
    case "ospedale":
      return (
        <g>
          <rect x="18" y="18" width="84" height="84" rx="6" fill={B} />
          <rect x="50" y="34" width="20" height="52" fill={W} />
          <rect x="34" y="50" width="52" height="20" fill={W} />
        </g>
      );
    case "soccorso":
      return (
        <g>
          <rect x="14" y="30" width="92" height="60" rx="6" fill={B} />
          <rect x="30" y="48" width="36" height="24" rx="3" fill={W} />
          <rect x="66" y="54" width="18" height="12" fill={W} />
          <rect x="42" y="42" width="8" height="8" fill={R} />
        </g>
      );
    case "benzina":
      return (
        <g>
          <rect x="18" y="18" width="84" height="84" rx="6" fill={B} />
          <rect x="42" y="36" width="28" height="40" rx="3" fill={W} />
          <rect x="70" y="46" width="12" height="8" fill={W} />
          {stroke("M76 54 V70", W, 3)}
        </g>
      );
    case "parcheggio":
      return (
        <g>
          <rect x="18" y="18" width="84" height="84" rx="6" fill={B} />
          <text x="60" y="80" textAnchor="middle" fontFamily={sans} fontSize="58" fontWeight="700" fill={W}>
            P
          </text>
        </g>
      );
    case "abitato":
      return (
        <g>
          <rect x="10" y="34" width="100" height="52" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="22" fontWeight="700" fill={K}>
            ROMA
          </text>
        </g>
      );
    case "fine-abitato":
      return (
        <g>
          <rect x="10" y="34" width="100" height="52" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="22" fontWeight="700" fill={K}>
            ROMA
          </text>
          <line x1="16" y1="78" x2="104" y2="40" stroke={R} strokeWidth="6" />
        </g>
      );
    case "senso-unico":
      return (
        <g>
          <rect x="28" y="10" width="64" height="100" rx="4" fill={B} />
          <polygon points="60,24 92,70 74,70 74,98 46,98 46,70 28,70" fill={W} />
        </g>
      );
    case "senza-uscita":
      return (
        <g>
          <rect x="18" y="18" width="84" height="84" rx="6" fill={B} />
          <rect x="52" y="32" width="16" height="56" fill={W} />
          <rect x="36" y="32" width="48" height="14" fill={R} />
        </g>
      );
    case "attraversamento":
      return (
        <g>
          <rect x="18" y="18" width="84" height="84" rx="6" fill={B} />
          <Person x={60} y={38} color={W} />
        </g>
      );
    case "preavviso":
      return (
        <g>
          <rect x="6" y="36" width="108" height="48" rx="4" fill={G} />
          <text x="18" y="66" fontFamily={sans} fontSize="16" fontWeight="700" fill={W}>
            A1 Milano
          </text>
        </g>
      );
    case "continua":
      return (
        <g>
          <rect x="8" y="28" width="104" height="64" fill="#5e6660" />
          <rect x="54" y="34" width="12" height="52" fill={W} />
        </g>
      );
    case "discontinua":
      return (
        <g>
          <rect x="8" y="28" width="104" height="64" fill="#5e6660" />
          <rect x="54" y="34" width="12" height="12" fill={W} />
          <rect x="54" y="54" width="12" height="12" fill={W} />
          <rect x="54" y="74" width="12" height="12" fill={W} />
        </g>
      );
    case "doppia-continua":
      return (
        <g>
          <rect x="8" y="28" width="104" height="64" fill="#5e6660" />
          <rect x="46" y="34" width="8" height="52" fill={W} />
          <rect x="66" y="34" width="8" height="52" fill={W} />
        </g>
      );
    case "zebrato":
      return (
        <g>
          <rect x="8" y="36" width="104" height="48" fill="#5e6660" />
          <rect x="20" y="42" width="12" height="36" fill={W} />
          <rect x="42" y="42" width="12" height="36" fill={W} />
          <rect x="64" y="42" width="12" height="36" fill={W} />
          <rect x="86" y="42" width="12" height="36" fill={W} />
        </g>
      );
    case "stop-terra":
      return (
        <g>
          <rect x="8" y="20" width="104" height="80" fill="#5e6660" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="22" fontWeight="700" fill={W}>
            STOP
          </text>
          <rect x="18" y="86" width="84" height="8" fill={W} />
        </g>
      );
    case "freccia-suolo":
      return (
        <g>
          <rect x="8" y="20" width="104" height="80" fill="#5e6660" />
          <polygon points="60,30 82,58 68,58 68,90 52,90 52,58 38,58" fill={W} />
        </g>
      );
    case "corsia-bus":
      return (
        <g>
          <rect x="8" y="20" width="104" height="80" fill="#5e6660" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="18" fontWeight="700" fill={Y}>
            BUS
          </text>
        </g>
      );
    case "rosso":
    case "giallo":
    case "verde":
      return (
        <g>
          <rect x="42" y="8" width="36" height="104" rx="8" fill={K} />
          <circle cx="60" cy="32" r="10" fill={id === "rosso" ? R : "#3a3a3a"} />
          <circle cx="60" cy="60" r="10" fill={id === "giallo" ? Y : "#3a3a3a"} />
          <circle cx="60" cy="88" r="10" fill={id === "verde" ? G : "#3a3a3a"} />
        </g>
      );
    case "lampeggiante":
      return (
        <g>
          <rect x="42" y="28" width="36" height="64" rx="8" fill={K} />
          <circle cx="60" cy="60" r="12" fill={Y} />
          <text x="60" y="112" textAnchor="middle" fontSize="12" fontFamily={sans} fill={K}>
            flash
          </text>
        </g>
      );
    case "freccia-verde":
      return (
        <g>
          <rect x="42" y="8" width="36" height="104" rx="8" fill={K} />
          <polygon points="60,70 78,92 66,92 66,104 54,104 54,92 42,92" fill={G} transform="rotate(180 60 86)" />
          <polygon points="60,28 76,50 66,50 66,64 54,64 54,50 44,50" fill={G} />
        </g>
      );
    case "corsia-x":
      return (
        <g>
          <rect x="36" y="28" width="48" height="64" rx="6" fill={K} />
          <line x1="48" y1="40" x2="72" y2="80" stroke={R} strokeWidth="8" />
          <line x1="72" y1="40" x2="48" y2="80" stroke={R} strokeWidth="8" />
        </g>
      );
    case "agente-alt":
      return (
        <g>
          <circle cx="60" cy="28" r="12" fill={K} />
          <rect x="48" y="42" width="24" height="36" rx="6" fill={B} />
          <rect x="56" y="18" width="8" height="16" fill={O} />
          <text x="60" y="108" textAnchor="middle" fontFamily={sans} fontSize="13" fontWeight="700" fill={K}>
            ALT
          </text>
        </g>
      );
    case "agente-fronte":
      return (
        <g>
          <circle cx="60" cy="26" r="10" fill={K} />
          <path d="M60 38 V72 M28 52 H92" stroke={B} strokeWidth="10" strokeLinecap="round" />
          <path d="M48 72 L40 100 M72 72 L80 100" stroke={K} strokeWidth="6" strokeLinecap="round" />
        </g>
      );
    case "agente-profilo":
      return (
        <g>
          <circle cx="78" cy="26" r="10" fill={K} />
          <path d="M70 40 H40 V78" stroke={B} strokeWidth="10" strokeLinecap="round" />
          <path d="M40 70 L28 96 M58 78 L62 102" stroke={K} strokeWidth="6" strokeLinecap="round" />
          <text x="60" y="116" textAnchor="middle" fontSize="11" fontFamily={sans} fill={K}>
            VIA
          </text>
        </g>
      );
    case "pannello-distanza":
      return (
        <g>
          <rect x="22" y="28" width="76" height="64" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="20" fontWeight="700" fill={K}>
            150 m
          </text>
        </g>
      );
    case "pannello-estesa":
      return (
        <g>
          <rect x="22" y="36" width="76" height="48" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="68" textAnchor="middle" fontFamily={sans} fontSize="22" fontWeight="700" fill={K}>
            3 km
          </text>
        </g>
      );
    case "pannello-ghiaccio":
      return (
        <g>
          <rect x="18" y="34" width="84" height="52" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="66" textAnchor="middle" fontFamily={sans} fontSize="16" fontWeight="700" fill={K}>
            ghiaccio
          </text>
        </g>
      );
    case "pannello-orario":
      return (
        <g>
          <rect x="16" y="32" width="88" height="56" fill={W} stroke={K} strokeWidth="4" />
          <text x="60" y="58" textAnchor="middle" fontFamily={sans} fontSize="14" fontWeight="700" fill={K}>
            8–20
          </text>
          <text x="60" y="76" textAnchor="middle" fontFamily={sans} fontSize="12" fill={K}>
            lun–ven
          </text>
        </g>
      );
    case "cantiere":
      return (
        <g>
          <polygon points="60,8 112,108 8,108" fill={Y} stroke={K} strokeWidth="4" />
          <Person x={46} y={48} color={K} />
          <polygon points="68,54 90,54 82,90 60,90" fill={K} />
        </g>
      );
    case "deviazione":
      return (
        <g>
          <rect x="10" y="28" width="100" height="64" rx="6" fill={Y} stroke={K} strokeWidth="3" />
          <polygon points="30,60 70,36 70,50 96,50 96,70 70,70 70,84" fill={K} />
        </g>
      );
    case "coni":
      return (
        <g>
          <polygon points="40,96 60,28 80,96" fill={O} />
          <rect x="46" y="58" width="28" height="8" fill={W} />
          <rect x="42" y="74" width="36" height="8" fill={W} />
        </g>
      );
    case "fig-destra":
      return <Cross kind="destra" />;
    case "fig-rotatoria":
      return <Cross kind="rotatoria" />;
    case "fig-strettoia":
      return <Cross kind="strettoia" />;
    case "fig-svolta":
      return <Cross kind="svolta" />;
    default:
      return (
        <g>
          <rect x="10" y="10" width="100" height="100" rx="8" fill={W} stroke={K} />
          <text x="60" y="66" textAnchor="middle" fontSize="14" fill={K} fontFamily={sans}>
            {id.slice(0, 10)}
          </text>
        </g>
      );
  }
}

function Cross({ kind }: { kind: "destra" | "rotatoria" | "strettoia" | "svolta" }) {
  return (
    <g>
      <rect width="120" height="120" fill="#d9d3c6" />
      <rect x="46" y="4" width="28" height="112" fill="#6d756f" />
      <rect x="4" y="46" width="112" height="28" fill="#6d756f" />
      {kind === "destra" ? (
        <>
          <rect x="54" y="78" width="12" height="22" fill={R} />
          <rect x="78" y="54" width="22" height="12" fill={B} />
        </>
      ) : null}
      {kind === "svolta" ? (
        <>
          <rect x="54" y="70" width="12" height="28" fill={R} />
          <polygon points="50,70 70,70 60,56" fill={R} />
          <rect x="54" y="18" width="12" height="24" fill={B} />
        </>
      ) : null}
      {kind === "rotatoria" ? (
        <>
          <circle cx="60" cy="60" r="18" fill="none" stroke={W} strokeWidth="6" />
          <rect x="86" y="54" width="16" height="10" fill={R} />
          <rect x="55" y="28" width="10" height="14" fill={B} />
        </>
      ) : null}
      {kind === "strettoia" ? (
        <>
          <rect x="18" y="40" width="20" height="40" fill="#9aa198" />
          <rect x="82" y="40" width="20" height="40" fill="#9aa198" />
          <rect x="54" y="78" width="12" height="18" fill={B} />
          <rect x="54" y="22" width="12" height="18" fill={R} />
        </>
      ) : null}
    </g>
  );
}

export function RoadSign({ id, className }: { id: string; className?: string }) {
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden>
      {renderBody(id)}
    </svg>
  );
}
