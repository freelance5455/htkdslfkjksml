import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { evaluate, formatNumber, type AngleMode } from "@/lib/calc";
import { cn } from "@/lib/utils";

type KeyDef = {
  label: string;
  value: string;
  kind?: "num" | "op" | "fn" | "action" | "equals";
};

const KEYS: KeyDef[] = [
  { label: "sin", value: "sin(", kind: "fn" },
  { label: "cos", value: "cos(", kind: "fn" },
  { label: "tan", value: "tan(", kind: "fn" },
  { label: "√", value: "√(", kind: "fn" },
  { label: "ln", value: "ln(", kind: "fn" },
  { label: "log", value: "log(", kind: "fn" },
  { label: "x²", value: "^2", kind: "fn" },
  { label: "xʸ", value: "^", kind: "fn" },
  { label: "π", value: "π", kind: "fn" },
  { label: "e", value: "e", kind: "fn" },
  { label: "n!", value: "!", kind: "fn" },
  { label: "|x|", value: "abs(", kind: "fn" },
  { label: "(", value: "(", kind: "fn" },
  { label: ")", value: ")", kind: "fn" },
  { label: "%", value: "%", kind: "op" },
  { label: "÷", value: "÷", kind: "op" },
  { label: "7", value: "7", kind: "num" },
  { label: "8", value: "8", kind: "num" },
  { label: "9", value: "9", kind: "num" },
  { label: "×", value: "×", kind: "op" },
  { label: "4", value: "4", kind: "num" },
  { label: "5", value: "5", kind: "num" },
  { label: "6", value: "6", kind: "num" },
  { label: "−", value: "−", kind: "op" },
  { label: "1", value: "1", kind: "num" },
  { label: "2", value: "2", kind: "num" },
  { label: "3", value: "3", kind: "num" },
  { label: "+", value: "+", kind: "op" },
  { label: "0", value: "0", kind: "num" },
  { label: ".", value: ".", kind: "num" },
  { label: "⌫", value: "DEL", kind: "action" },
  { label: "=", value: "=", kind: "equals" },
];

export function Calculator() {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState("0");
  const [mode, setMode] = useState<AngleMode>("deg");
  const [error, setError] = useState(false);
  const [flash, setFlash] = useState(false);
  const exprRef = useRef(expression);
  exprRef.current = expression;

  const compute = useCallback(
    (expr: string) => {
      if (!expr.trim()) return;
      const value = evaluate(expr, mode);
      if (Number.isNaN(value)) {
        setError(true);
        setResult("خطأ في الصيغة");
        return;
      }
      setError(false);
      setResult(formatNumber(value));
      setFlash(true);
      setTimeout(() => setFlash(false), 220);
    },
    [mode]
  );

  const handleKey = useCallback(
    (key: KeyDef) => {
      if (key.value === "DEL") {
        setExpression((prev) => prev.slice(0, -1));
        setError(false);
        return;
      }
      if (key.value === "=") {
        compute(exprRef.current);
        return;
      }
      setError(false);
      setExpression((prev) => prev + key.value);
    },
    [compute]
  );

  const clearAll = useCallback(() => {
    setExpression("");
    setResult("0");
    setError(false);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const k = e.key;
      if (/^[0-9.]$/.test(k)) {
        setExpression((p) => p + k);
        setError(false);
      } else if (k === "+" || k === "-" || k === "*" || k === "/") {
        const map: Record<string, string> = {
          "*": "×",
          "/": "÷",
          "-": "−",
          "+": "+",
        };
        setExpression((p) => p + map[k]);
        setError(false);
      } else if (k === "(" || k === ")") {
        setExpression((p) => p + k);
      } else if (k === "^") {
        setExpression((p) => p + "^");
      } else if (k === "Enter" || k === "=") {
        e.preventDefault();
        compute(exprRef.current);
      } else if (k === "Backspace") {
        setExpression((p) => p.slice(0, -1));
      } else if (k === "Escape") {
        clearAll();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [compute, clearAll]);

  return (
    <Card className="overflow-hidden rounded-2xl border-teal-100 bg-white shadow-lg">
      <CardContent className="p-0">
        <div className="flex items-center justify-between border-b border-teal-100 bg-teal-50/60 px-3 py-2">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-teal-700">
              الوضع
            </span>
            <div className="flex overflow-hidden rounded-md ring-1 ring-teal-200">
              {(["deg", "rad"] as AngleMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={cn(
                    "px-3 py-1 text-xs font-semibold uppercase transition-colors",
                    mode === m
                      ? "bg-teal-600 text-white"
                      : "bg-white text-teal-700 hover:bg-teal-100"
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAll}
            className="h-7 px-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 hover:text-rose-700"
          >
            مسح الكل
          </Button>
        </div>

        <div className="bg-gradient-to-br from-slate-800 to-slate-900 px-4 py-3.5">
          <div className="min-h-5 truncate text-right font-mono text-xs text-slate-400">
            {expression || "\u00A0"}
          </div>
          <div
            className={cn(
              "mt-1.5 truncate text-right font-mono text-3xl font-bold transition-colors",
              error ? "text-rose-400" : "text-emerald-300",
              flash && "text-white"
            )}
          >
            {result}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-1.5 p-2.5">
          {KEYS.map((key) => (
            <Button
              key={key.label}
              onClick={() => handleKey(key)}
              variant="ghost"
              className={cn(
                "h-11 rounded-xl text-sm font-semibold transition-all active:scale-95",
                key.kind === "num" &&
                  "bg-slate-100 text-slate-800 hover:bg-slate-200",
                key.kind === "fn" &&
                  "bg-teal-50 text-xs text-teal-700 hover:bg-teal-100",
                key.kind === "op" &&
                  "bg-amber-50 text-amber-700 hover:bg-amber-100",
                key.kind === "action" &&
                  "bg-rose-50 text-rose-600 hover:bg-rose-100",
                key.kind === "equals" &&
                  "bg-teal-600 text-white shadow-sm hover:bg-teal-700"
              )}
            >
              {key.label}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}