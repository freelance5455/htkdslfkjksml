import React, { useState, useEffect, useMemo } from 'react';
import { Settings, User, Delete } from 'lucide-react';
import {
  getMasterPin,
  setMasterPin,
  isFirstTimeOpen,
  markFirstTimeOpenCompleted,
  getUserSession,
} from '../lib/storage';
import {
  checkCalculatorTempPassword,
  invalidateTempPasswordAndSaveNewPin,
} from '../lib/supabase';
import { Toast } from './Toast';

export type PasswordChangeStep = 'idle' | 'enter_old' | 'enter_new' | 'confirm_new';

interface CalculatorProps {
  onOpenSettings: () => void;
  onOpenAccountSetting: () => void;
  onOpenVault: () => void;
  passwordChangeStep: PasswordChangeStep;
  setPasswordChangeStep: (step: PasswordChangeStep) => void;
  onPasswordChangeComplete: () => void;
  initialToastMessage?: string | null;
}

// Pure math expression evaluator
function evaluateMathExpression(expr: string): string | null {
  if (!expr) return null;
  // Replace visual operators
  const sanitized = expr.replace(/×/g, '*').replace(/÷/g, '/').trim();
  // If ends with an operator, cannot evaluate yet
  if (/[+\-*/]$/.test(sanitized)) return null;
  // Must contain at least one operator with operands on both sides
  if (!/[0-9.]+\s*[+\-*/]\s*[0-9.]+/.test(sanitized)) return null;
  // Validate characters
  if (!/^[\d.+\-*/\s]+$/.test(sanitized)) return null;

  try {
    const res = Function(`'use strict'; return (${sanitized})`)();
    if (typeof res === 'number' && isFinite(res)) {
      const rounded = Math.round(res * 100000000) / 100000000;
      return String(rounded);
    }
    return null;
  } catch {
    return null;
  }
}

export const Calculator: React.FC<CalculatorProps> = ({
  onOpenSettings,
  onOpenAccountSetting,
  onOpenVault,
  passwordChangeStep,
  setPasswordChangeStep,
  onPasswordChangeComplete,
  initialToastMessage = null,
}) => {
  // Main expression on upper line (e.g. '20-5' or calculated '15')
  const [display, setDisplay] = useState<string>('');
  // Tracks if the last action was pressing '='
  const [justCalculated, setJustCalculated] = useState<boolean>(false);

  const [newPinCandidate, setNewPinCandidate] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isBlackPatti, setIsBlackPatti] = useState<boolean>(false);
  const [developerSignature, setDeveloperSignature] = useState<string | null>(null);

  // Recovery temporary password session state
  const [recoveryEmail, setRecoveryEmail] = useState<string | null>(null);
  const [usedTempCode, setUsedTempCode] = useState<string | null>(null);
  const [recoveryStep, setRecoveryStep] = useState<'idle' | 'enter_new' | 'confirm_new'>('idle');

  // Setup mode: 'none' | 'set_pin' | 'confirm_pin'
  const [firstTimeMode, setFirstTimeMode] = useState<'none' | 'set_pin' | 'confirm_pin'>('none');

  const showToast = (msg: string, blackPatti = false) => {
    setIsBlackPatti(blackPatti);
    setToastMessage(msg);
  };

  useEffect(() => {
    const currentPin = getMasterPin();
    if (!currentPin) {
      setFirstTimeMode('set_pin');
      markFirstTimeOpenCompleted();
    }
  }, []);

  // Handle external toasts or step transitions
  useEffect(() => {
    if (initialToastMessage) {
      showToast(initialToastMessage, false);
    }
  }, [initialToastMessage]);

  useEffect(() => {
    if (passwordChangeStep === 'enter_old') {
      showToast('Enter Your Old Password', false);
    } else if (passwordChangeStep === 'enter_new') {
      showToast('Enter New Password', false);
    } else if (passwordChangeStep === 'confirm_new') {
      showToast('Confirm New Password', false);
    }
  }, [passwordChangeStep]);

  // Live calculation shown below the expression BEFORE pressing '=' (e.g. '20-5' -> '15')
  const liveEvaluation = useMemo(() => evaluateMathExpression(display), [display]);

  const handleNumber = (digit: string) => {
    setDeveloperSignature(null);
    if (justCalculated) {
      setJustCalculated(false);
      setDisplay(digit);
      return;
    }
    setDisplay((prev) => prev + digit);
  };

  const handleOperator = (op: string) => {
    setDeveloperSignature(null);
    setJustCalculated(false);
    if (!display) {
      if (op === '-') {
        setDisplay('-');
      }
      return;
    }
    const lastChar = display.slice(-1);
    if (['+', '-', '×', '÷'].includes(lastChar)) {
      setDisplay((prev) => prev.slice(0, -1) + op);
    } else {
      setDisplay((prev) => prev + op);
    }
  };

  const handleDot = () => {
    setDeveloperSignature(null);
    if (justCalculated) {
      setJustCalculated(false);
      setDisplay('0.');
      return;
    }
    const parts = display.split(/[+\-×÷]/);
    const currentPart = parts[parts.length - 1];
    if (!currentPart.includes('.')) {
      setDisplay((prev) => (prev === '' ? '0.' : prev + '.'));
    }
  };

  const handleClear = () => {
    setDisplay('');
    setJustCalculated(false);
    setDeveloperSignature(null);
  };

  const handleDelete = () => {
    setDeveloperSignature(null);
    setJustCalculated(false);
    setDisplay((prev) => (prev.length > 0 ? prev.slice(0, -1) : ''));
  };

  const handleDevName = () => {
    setDeveloperSignature('Saleem Zakhme');
    setDisplay('');
  };

  const handleEquals = async () => {
    const trimmedInput = display.trim();

    // 0. Recovery Mode Flow (after temp password from admin)
    if (recoveryStep === 'enter_new') {
      if (trimmedInput.length < 4) {
        showToast('Password must be at least 4 digits');
        return;
      }
      setNewPinCandidate(trimmedInput);
      setDisplay('');
      setRecoveryStep('confirm_new');
      showToast('Confirm password');
      return;
    }

    if (recoveryStep === 'confirm_new') {
      if (trimmedInput === newPinCandidate) {
        setMasterPin(trimmedInput);
        if (recoveryEmail && usedTempCode) {
          await invalidateTempPasswordAndSaveNewPin(recoveryEmail, trimmedInput, usedTempCode);
        }
        setRecoveryEmail(null);
        setUsedTempCode(null);
        setRecoveryStep('idle');
        setDisplay('');
        showToast('New password set successfully!');
        setTimeout(() => {
          onOpenVault();
        }, 1200);
      } else {
        showToast('Passwords do not match! Try again');
        setDisplay('');
        setRecoveryStep('enter_new');
      }
      return;
    }

    // 1. First-time Setup: Set Password flow
    if (firstTimeMode === 'set_pin') {
      if (!trimmedInput || trimmedInput.length < 4) {
        showToast('Password must be at least 4 digits');
        return;
      }
      setNewPinCandidate(trimmedInput);
      setDisplay('');
      setFirstTimeMode('confirm_pin');
      showToast('Confirm Password');
      return;
    }

    if (firstTimeMode === 'confirm_pin') {
      if (trimmedInput === newPinCandidate) {
        setMasterPin(trimmedInput);
        setFirstTimeMode('none');
        setDisplay('');
        showToast('Password Saved');
        setTimeout(() => {
          onOpenVault();
        }, 1200);
      } else {
        showToast('Passwords do not match! Try again');
        setDisplay('');
        setFirstTimeMode('set_pin');
      }
      return;
    }

    // 2. Change Password Flow (from settings)
    if (passwordChangeStep === 'enter_old') {
      const oldPin = getMasterPin();
      if (trimmedInput === oldPin) {
        setDisplay('');
        setPasswordChangeStep('enter_new');
        showToast('Enter New Password');
      } else {
        showToast('Incorrect Old Password');
        setDisplay('');
      }
      return;
    }

    if (passwordChangeStep === 'enter_new') {
      if (trimmedInput.length < 4) {
        showToast('Password must be at least 4 digits');
        return;
      }
      setNewPinCandidate(trimmedInput);
      setDisplay('');
      setPasswordChangeStep('confirm_new');
      showToast('Confirm New Password');
      return;
    }

    if (passwordChangeStep === 'confirm_new') {
      if (trimmedInput === newPinCandidate) {
        setMasterPin(trimmedInput);
        setDisplay('');
        setPasswordChangeStep('idle');
        onPasswordChangeComplete();
        showToast('Password changed successfully');
      } else {
        showToast('Passwords do not match! Try again');
        setDisplay('');
        setPasswordChangeStep('enter_new');
      }
      return;
    }

    // 3. Normal Unlock: Check local Master PIN
    const masterPin = getMasterPin();
    if (masterPin && trimmedInput === masterPin) {
      setDisplay('');
      onOpenVault();
      return;
    }

    // 4. Temporary Password check in Supabase
    if (trimmedInput.length >= 4 && /^\d+$/.test(trimmedInput)) {
      const currentEmail = getUserSession()?.email || localStorage.getItem('current_user_email') || '';
      try {
        const tempCheck = await checkCalculatorTempPassword(trimmedInput, currentEmail || undefined);
        if (tempCheck.alreadyUsed) {
          showToast('Temporary Password Already Used');
          setDisplay('');
          return;
        }
        if (tempCheck.expired) {
          showToast('Temporary Password Expired');
          setDisplay('');
          return;
        }
        if (tempCheck.valid) {
          setRecoveryEmail(tempCheck.email || currentEmail || null);
          setUsedTempCode(trimmedInput);
          setDisplay('');
          setNewPinCandidate('');
          setRecoveryStep('enter_new');
          showToast('Set new password');
          return;
        }
      } catch (err) {
        console.warn('Temp password check notice:', err);
      }
    }

    // 5. Math calculation:
    // When '=' is pressed, the bottom result moves to the top line (display becomes result)
    // and stays there without being removed, allowing further calculations.
    const calculated = liveEvaluation || evaluateMathExpression(display);
    if (calculated !== null) {
      setDisplay(calculated);
      setJustCalculated(true);
    }
    // If not a calculation and not a password (e.g. wrong password entered):
    // "ghlat password sy koi b react na dy original calculator ki thra"
    // No error or toast is shown.
  };

  return (
    <div className="w-full h-full max-w-xl mx-auto flex flex-col justify-between px-3 sm:px-6 py-2 sm:py-4 select-none bg-white text-slate-800 overflow-hidden relative">
      {/* 2-Second Toast */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
        isBlackPatti={isBlackPatti}
      />

      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-[#1c74e9] to-[#1562ca] rounded-2xl px-4 py-2 sm:py-2.5 flex items-center justify-between shadow-md mb-1 shrink-0">
        <div
          onClick={handleDevName}
          className="flex items-center gap-3 cursor-pointer group active:scale-95 transition"
        >
          <div className="w-10 h-10 rounded-full bg-[#22c55e] flex items-center justify-center font-bold text-white text-xl shadow-sm group-hover:scale-105 transition">
            S
          </div>
          <span className="text-white font-bold text-lg tracking-wide drop-shadow-sm">
            Saleem Zakhme
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenAccountSetting}
            className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-500 border border-blue-300/40 text-white flex items-center justify-center shadow-md active:scale-90 transition-transform duration-75 cursor-pointer"
            title="Account & Supabase Cloud Login"
          >
            <User className="w-5 h-5 text-white stroke-[2.3]" />
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full bg-[#ef4444] hover:bg-[#dc2626] active:scale-90 flex items-center justify-center text-white shadow-md transition-transform duration-75 hover:rotate-45 cursor-pointer"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Display Screen matching video: Top line is expression (20-5), bottom line is live result (15) */}
      <div className="flex-1 py-2 px-3 flex flex-col justify-end text-right min-h-[105px]">
        {/* Top Main Line: Shows active expression / numbers or Saleem Zakhme on 'S' click exactly at the same place */}
        <div className="text-4xl sm:text-6xl font-semibold text-slate-900 tracking-tight flex items-center justify-end overflow-x-auto whitespace-nowrap min-h-[46px] sm:min-h-[62px]">
          {developerSignature ? (
            <span className="text-3xl sm:text-5xl font-bold text-[#22c55e] tracking-wide animate-in fade-in select-none">
              {developerSignature}
            </span>
          ) : (
            <span>{display || '0'}</span>
          )}
          <span className="inline-block w-[3px] h-9 sm:h-12 bg-[#22c55e] ml-1.5 animate-pulse shrink-0" />
        </div>

        {/* Bottom Live Result Line: Shows live answer (e.g. '15') BEFORE clicking '=', clears once '=' moves it to top */}
        <div className="min-h-[30px] sm:min-h-[36px] flex items-center justify-end text-slate-500 font-medium text-2xl sm:text-3xl font-mono truncate px-1 mt-0.5">
          {!developerSignature && liveEvaluation ? (
            <span className="text-slate-500 tracking-tight">{liveEvaluation}</span>
          ) : null}
        </div>
      </div>

      {/* Keypad Buttons Grid */}
      <div className="h-[52%] sm:h-[55%] min-h-[340px] grid grid-cols-4 grid-rows-5 gap-2 sm:gap-3 pb-1 shrink-0 select-none">
        {/* Row 1 */}
        <button
          type="button"
          onClick={handleClear}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#ef4444] font-bold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          C
        </button>
        <button
          type="button"
          onClick={handleDevName}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-[#22c55e] hover:bg-[#16a34a] text-white font-bold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-md shadow-green-500/20 cursor-pointer select-none"
        >
          S
        </button>
        <button
          type="button"
          onClick={handleDelete}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-xl sm:text-2xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          <Delete className="w-6 h-6 sm:w-7 sm:h-7 text-[#22c55e]" />
        </button>
        <button
          type="button"
          onClick={() => handleOperator('÷')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-3xl sm:text-4xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          ÷
        </button>

        {/* Row 2 */}
        <button
          type="button"
          onClick={() => handleNumber('7')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          7
        </button>
        <button
          type="button"
          onClick={() => handleNumber('8')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          8
        </button>
        <button
          type="button"
          onClick={() => handleNumber('9')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          9
        </button>
        <button
          type="button"
          onClick={() => handleOperator('×')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          ×
        </button>

        {/* Row 3 */}
        <button
          type="button"
          onClick={() => handleNumber('4')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          4
        </button>
        <button
          type="button"
          onClick={() => handleNumber('5')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          5
        </button>
        <button
          type="button"
          onClick={() => handleNumber('6')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          6
        </button>
        <button
          type="button"
          onClick={() => handleOperator('-')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-3xl sm:text-4xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          -
        </button>

        {/* Row 4 */}
        <button
          type="button"
          onClick={() => handleNumber('1')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          1
        </button>
        <button
          type="button"
          onClick={() => handleNumber('2')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          2
        </button>
        <button
          type="button"
          onClick={() => handleNumber('3')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          3
        </button>
        <button
          type="button"
          onClick={() => handleOperator('+')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          +
        </button>

        {/* Row 5 */}
        <button
          type="button"
          onClick={() => handleNumber('0')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-2xl sm:text-3xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          0
        </button>
        <button
          type="button"
          onClick={() => handleNumber('00')}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xl sm:text-2xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          00
        </button>
        <button
          type="button"
          onClick={handleDot}
          style={{ touchAction: 'manipulation' }}
          className="w-full h-full rounded-2xl bg-white hover:bg-slate-50 text-[#22c55e] font-bold text-3xl sm:text-4xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-100 cursor-pointer select-none"
        >
          .
        </button>
        <button
          type="button"
          onClick={handleEquals}
          style={{ touchAction: 'manipulation' }}
          className={`w-full h-full rounded-2xl bg-[#22c55e] hover:bg-[#16a34a] text-white font-bold text-3xl sm:text-4xl flex items-center justify-center active:scale-[0.93] transition-transform duration-75 shadow-lg shadow-green-500/25 cursor-pointer select-none ${
            firstTimeMode !== 'none' || passwordChangeStep !== 'idle' || recoveryStep !== 'idle'
              ? 'ring-4 ring-green-300'
              : ''
          }`}
          title="Equals / Unlock Vault"
        >
          =
        </button>
      </div>
    </div>
  );
};
