import React, { useState } from 'react';
import {
  Shield,
  Layers,
  Calendar,
  History,
  Download,
  AlertTriangle,
  CheckCircle,
  Plus,
  RefreshCw,
  Archive,
} from 'lucide-react';
import type { Category, Season, AuditLog, Player } from '../types/index.ts';

interface GroupManagementViewProps {
  categories: Category[];
  currentSeason: Season;
  auditLogs: AuditLog[];
  activePlayer: Player;
  isAdmin: boolean;
  onAddCategory: (data: { name: string; weightGrams: number; safetyNotice?: string }) => Promise<boolean>;
  onToggleCategoryStatus: (id: string, status: 'active' | 'archived') => Promise<boolean>;
  onCloseCurrentSeason: (reason: string) => Promise<boolean>;
  onResetDemoData: () => Promise<void>;
}

export const GroupManagementView: React.FC<GroupManagementViewProps> = ({
  categories,
  currentSeason,
  auditLogs,
  activePlayer,
  isAdmin,
  onAddCategory,
  onToggleCategoryStatus,
  onCloseCurrentSeason,
  onResetDemoData,
}) => {
  const [newCatName, setNewCatName] = useState('');
  const [newCatWeight, setNewCatWeight] = useState<number>(300);
  const [catError, setCatError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [closeReason, setCloseReason] = useState('');
  const [isClosingSeason, setIsClosingSeason] = useState(false);

  const handleAddCatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim() || !newCatWeight) {
      setCatError('Preencha o nome e o peso em gramas da garrafa.');
      return;
    }

    setIsSubmitting(true);
    setCatError('');

    const ok = await onAddCategory({
      name: newCatName.trim(),
      weightGrams: Number(newCatWeight),
    });

    setIsSubmitting(false);
    if (ok) {
      setNewCatName('');
      setNewCatWeight(300);
    }
  };

  const handleCloseSeason = async () => {
    if (!window.confirm('Tem certeza de que deseja encerrar a temporada atual? Será gerado um snapshot oficial imutável com os campeões por categoria e uma nova semana limpa será iniciada.')) {
      return;
    }

    setIsClosingSeason(true);
    await onCloseCurrentSeason(closeReason || 'Encerramento regular de temporada');
    setIsClosingSeason(false);
    setCloseReason('');
  };

  const handleExportJson = () => {
    window.open('/api/backup/export', '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Admin Notice */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-6 h-6 text-emerald-400" />
          <h2 className="text-xl font-extrabold text-white">Painel de Gestão do Grupo</h2>
        </div>
        <p className="text-xs text-neutral-400 leading-relaxed">
          Área para gerenciamento de categorias de peso, fechamento oficial de temporadas, verificação da trilha de auditoria e exportação de backups.
        </p>
      </div>

      {/* Categories Management & Safety Constraint */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-extrabold text-white">Categorias de Peso da Garrafa</h3>
          </div>
          <span className="text-[10px] font-bold text-neutral-400 bg-neutral-950 px-2 py-1 rounded border border-neutral-800">
            Limite Seguro: até 500 g
          </span>
        </div>

        {/* Existing Categories */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {categories.map((cat) => {
            const isArchived = cat.status !== 'active';
            const isSafe = cat.weightGrams <= 500;

            return (
              <div
                key={cat.id}
                className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h4 className="font-bold text-white text-sm">{cat.name}</h4>
                    {isArchived ? (
                      <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800">
                        Arquivada
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                        Competição Ativa
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-neutral-400 mb-2">
                    Peso oficial: <strong className="text-neutral-200">{cat.weightGrams} gramas</strong>
                  </p>
                  {cat.safetyNotice && (
                    <p className="text-[11px] text-amber-300/80 bg-amber-950/20 p-2 rounded-lg border border-amber-800/40">
                      {cat.safetyNotice}
                    </p>
                  )}
                </div>

                {/* Status Toggle (Admin only) */}
                <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                  <span className="text-neutral-500 text-[11px]">
                    {isSafe ? 'Aprovável para disputa' : 'Bloqueada por segurança (>500g)'}
                  </span>
                  {isSafe ? (
                    <button
                      onClick={() => onToggleCategoryStatus(cat.id, isArchived ? 'active' : 'archived')}
                      className={`px-3 py-1 rounded font-bold transition-colors ${
                        isArchived
                          ? 'bg-emerald-500 text-neutral-950 hover:bg-emerald-400'
                          : 'bg-neutral-800 text-neutral-300 hover:text-white'
                      }`}
                    >
                      {isArchived ? 'Ativar Categoria' : 'Desativar'}
                    </button>
                  ) : (
                    <span className="text-[11px] text-neutral-600 font-semibold">
                      Desativação Obrigatória
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Propose new category */}
        <div className="pt-4 border-t border-neutral-800">
          <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider mb-2">
            Propor Nova Categoria
          </h4>
          {catError && (
            <div className="mb-3 p-2.5 rounded-lg bg-red-950/40 border border-red-800/60 text-xs text-red-300">
              {catError}
            </div>
          )}
          <form onSubmit={handleAddCatSubmit} className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder="Nome (ex: 350 g Mini)"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              className="flex-1 px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
              required
            />
            <input
              type="number"
              placeholder="Peso (g)"
              value={newCatWeight}
              onChange={(e) => setNewCatWeight(Number(e.target.value))}
              className="w-28 px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white font-mono-numbers focus:outline-none focus:border-emerald-500"
              min="50"
              max="5000"
              required
            />
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-bold bg-emerald-500 text-neutral-950 rounded-lg hover:bg-emerald-400 transition-colors cursor-pointer"
            >
              Adicionar
            </button>
          </form>
          <p className="text-[10px] text-neutral-500 mt-1">
            * Categorias acima de 500g serão automaticamente arquivadas para respeitar a proteção de segurança física do grupo.
          </p>
        </div>
      </div>

      {/* Week Rollover / Season Closing */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-amber-400" />
          <h3 className="text-base font-extrabold text-white">Encerramento de Temporada Semanal</h3>
        </div>
        <p className="text-xs text-neutral-400 leading-relaxed">
          Temporada ativa: <strong className="text-white">{currentSeason.name}</strong> ({currentSeason.startDate} a {currentSeason.endDate}).
          Ao encerrar, os resultados provisórios são congelados em um snapshot permanente, os campeões por categoria são condecorados e a próxima semana se inicia com a tabela de médias limpa.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 pt-2">
          <input
            type="text"
            placeholder="Observação ou motivo (opcional)"
            value={closeReason}
            onChange={(e) => setCloseReason(e.target.value)}
            className="flex-1 px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white"
          />
          <button
            onClick={handleCloseSeason}
            disabled={isClosingSeason}
            className="px-4 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg transition-colors cursor-pointer"
          >
            Encerrar Semana Oficial & Salvar Campeão
          </button>
        </div>
      </div>

      {/* Audit Trail */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-emerald-400" />
          <h3 className="text-base font-extrabold text-white">Trilha de Auditoria do Grupo</h3>
        </div>
        <p className="text-xs text-neutral-400">
          Histórico imutável de correções de registro, moderações e decisões administrativas.
        </p>

        {auditLogs.length === 0 ? (
          <p className="text-xs text-neutral-500 py-3 text-center">Nenhum evento registrado.</p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-1"
              >
                <div className="flex items-center justify-between text-[11px] text-neutral-500">
                  <span className="font-bold text-neutral-300">{log.userName}</span>
                  <span className="font-mono-numbers">{log.timestamp.slice(0, 16).replace('T', ' ')}</span>
                </div>
                <div className="text-white font-medium">
                  {log.recordTarget}: <span className="text-neutral-400">{log.previousValue}</span> → <span className="text-emerald-400 font-bold">{log.newValue}</span>
                </div>
                <div className="text-neutral-400 text-[11px] italic">
                  Motivo: {log.reason}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Backup and Demo Reset */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div>
          <h4 className="font-bold text-white text-sm">Backup e Integridade</h4>
          <p className="text-xs text-neutral-400">
            Exporte os dados completos do grupo em formato JSON para arquivamento ou migração.
          </p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleExportJson}
            className="flex-1 sm:flex-none px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors border border-neutral-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Exportar JSON</span>
          </button>
          <button
            onClick={onResetDemoData}
            className="flex-1 sm:flex-none px-3.5 py-2 rounded-lg bg-neutral-950 hover:bg-neutral-800 text-neutral-400 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-neutral-800"
            title="Restaurar dados de demonstração com histórico e 6 jogadores"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Restaurar Testes</span>
          </button>
        </div>
      </div>
    </div>
  );
};
