import Board from "./Board";
import { LESSONS, OPENINGS, PUZZLES } from "../data/content";
import type { TabId } from "../App";

const FEATURES: { icon: string; title: string; text: string; tab: TabId }[] = [
  {
    icon: "♞",
    title: "Guided lessons",
    text: "From how the knight jumps to opposition in king-and-pawn endings. Short, practical, no fluff.",
    tab: "learn",
  },
  {
    icon: "♜",
    title: "Tactics trainer",
    text: "Hand-picked puzzles with hints, full solutions and the idea behind every pattern.",
    tab: "puzzles",
  },
  {
    icon: "♝",
    title: "Opening explorer",
    text: "Step through the main lines of six classic openings with move-by-move commentary.",
    tab: "openings",
  },
  {
    icon: "♛",
    title: "Play the coach",
    text: "Three engine strengths, take-backs and legal-move highlighting — practise what you learn.",
    tab: "play",
  },
];

const PREVIEW_FEN = "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQK2R w KQkq - 0 1";

export default function Home({ onNavigate }: { onNavigate: (tab: TabId) => void }) {
  return (
    <div className="grid gap-16">
      <section className="relative overflow-hidden rounded-3xl border border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(40rem_30rem_at_75%_30%,rgba(16,185,129,0.25),transparent),linear-gradient(135deg,#0b1412,#111827_55%,#1c1917)]" />
        <img
          src="/images/hero.jpg"
          alt="Chess board"
          className="absolute inset-0 h-full w-full object-cover"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/90 to-neutral-950/30" />
        <div className="relative grid gap-8 px-6 py-14 sm:px-12 sm:py-20 lg:grid-cols-[1.1fr_minmax(0,0.9fr)] lg:items-center">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-emerald-300">
              ♔ Est. 1997 · Online since today
            </span>
            <h1 className="mt-5 text-4xl font-black leading-tight tracking-tight text-white sm:text-6xl">
              Learn chess the way
              <span className="block bg-gradient-to-r from-emerald-400 to-amber-300 bg-clip-text text-transparent">
                masters teach it.
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-neutral-300">
              Chess Academy turns the rules into real understanding: structured lessons, a tactics
              trainer that explains every pattern, an opening repertoire you can actually remember,
              and a built-in sparring partner.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={() => onNavigate("learn")}
                className="rounded-xl bg-emerald-500 px-6 py-3 font-semibold text-neutral-950 shadow-lg shadow-emerald-500/25 transition hover:bg-emerald-400"
              >
                Start learning — free
              </button>
              <button
                onClick={() => onNavigate("play")}
                className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 font-semibold text-white backdrop-blur transition hover:bg-white/10"
              >
                Play the coach ♟
              </button>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4">
              {[
                { k: `${LESSONS.length}`, v: "core lessons" },
                { k: `${PUZZLES.length}`, v: "tactics puzzles" },
                { k: `${OPENINGS.length}`, v: "opening lines" },
              ].map((s) => (
                <div key={s.v} className="rounded-2xl border border-white/10 bg-black/40 p-4">
                  <dt className="text-2xl font-bold text-emerald-400">{s.k}</dt>
                  <dd className="text-xs uppercase tracking-wider text-neutral-400">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="mx-auto hidden w-full max-w-sm lg:block">
            <Board fen={PREVIEW_FEN} lastMove={{ from: "f1", to: "c4" }} />
            <p className="mt-3 text-center text-sm text-neutral-400">
              Giuoco Piano — lesson 3 of the opening course
            </p>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-white sm:text-3xl">Everything in one board</h2>
        <p className="mt-2 max-w-2xl text-neutral-400">
          Four training rooms, one academy. Jump into any of them — your progress is saved locally.
        </p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <button
              key={f.title}
              onClick={() => onNavigate(f.tab)}
              className="group rounded-2xl border border-white/10 bg-white/5 p-6 text-left transition hover:-translate-y-1 hover:border-emerald-400/40 hover:bg-emerald-400/5"
            >
              <span className="text-4xl text-emerald-400">{f.icon}</span>
              <h3 className="mt-4 text-lg font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-neutral-400">{f.text}</p>
              <span className="mt-4 inline-block text-sm font-semibold text-emerald-400 opacity-0 transition group-hover:opacity-100">
                Open →
              </span>
            </button>
          ))}
        </div>
      </section>

      <section className="grid gap-6 rounded-3xl border border-white/10 bg-gradient-to-br from-white/5 to-transparent p-8 lg:grid-cols-3">
        {[
          {
            name: "GM Elena Varga",
            role: "Head coach · Openings",
            quote:
              "You don't memorise moves, you memorise ideas. Every line here comes with the plan behind it.",
          },
          {
            name: "IM Tom Beckett",
            role: "Tactics director",
            quote:
              "Solve 10 puzzles a day for a month and your rating moves. It really is that simple.",
          },
          {
            name: "FM Ada Nwosu",
            role: "Endgame & technique",
            quote:
              "Beginners study openings, masters study endings. Start with the four positions in lesson 4.",
          },
        ].map((c) => (
          <figure key={c.name} className="rounded-2xl bg-black/30 p-6">
            <blockquote className="text-sm leading-relaxed text-neutral-300">“{c.quote}”</blockquote>
            <figcaption className="mt-4">
              <span className="block font-semibold text-white">{c.name}</span>
              <span className="block text-xs uppercase tracking-wider text-emerald-400">
                {c.role}
              </span>
            </figcaption>
          </figure>
        ))}
      </section>

      <section className="rounded-3xl border border-emerald-500/30 bg-emerald-500/10 p-8 text-center sm:p-12">
        <h2 className="text-2xl font-bold text-white sm:text-3xl">Your first move is the easiest</h2>
        <p className="mx-auto mt-3 max-w-xl text-neutral-300">
          No sign-up, no paywall, no download. Open the board and start training.
        </p>
        <button
          onClick={() => onNavigate("puzzles")}
          className="mt-6 rounded-xl bg-emerald-500 px-8 py-3 font-semibold text-neutral-950 transition hover:bg-emerald-400"
        >
          Solve today's puzzle
        </button>
      </section>
    </div>
  );
}
