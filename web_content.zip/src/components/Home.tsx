import { useMemo, useRef, useState } from "react";
import { CATEGORIES, SHOPS, ZONES, zoneLabel } from "../data/shops";
import { IMG } from "../media";
import { useStore } from "../store";
import type { Shop } from "../types";
import {
  IconArrow,
  IconCheck,
  IconChevron,
  IconClock,
  IconPin,
  IconSearch,
  IconStar,
  IconTruck,
} from "./Icons";

function ShopCard({ shop }: { shop: Shop }) {
  const { openShop } = useStore();
  return (
    <button onClick={() => openShop(shop)} className="lift press w-full overflow-hidden rounded-2xl border border-black/6 bg-white text-left">
      <div className="zoom relative h-[148px] bg-[#6B2D1A]">
        <img src={shop.image} alt={shop.name} className="h-full w-full object-cover" />
      </div>
      <div className="px-3 pb-3 pt-2.5">
        <h3 className="truncate text-[15px] font-bold text-[#171717]">{shop.name}</h3>
        {shop.id === "burger-buzz" && (
          <p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#C56A14]">Juicy to the last bite</p>
        )}
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-[#6b6b6b]">
          <span className="inline-flex items-center gap-0.5 font-semibold text-[#171717]">
            <IconStar className="h-3.5 w-3.5 text-[#FF6A00]" />
            {shop.rating.toFixed(1)}
            <span className="font-medium text-[#8a8a8a]">({shop.reviews}+)</span>
          </span>
          <span className="inline-flex items-center gap-1">
            <IconClock className="h-3 w-3" /> {shop.eta}
          </span>
        </div>
        <p className="mt-1.5 text-[11px] font-semibold text-[#8a8a8a]">{zoneLabel(shop.zone)}</p>
      </div>
    </button>
  );
}

export function Hero() {
  const { setQuery, zone, setZone, setModal } = useStore();
  const [local, setLocal] = useState("");
  const z = ZONES.find((x) => x.id === zone)!;

  return (
    <section id="home" className="relative overflow-hidden bg-black pt-[88px]">
      <img src={IMG.heroBurger} alt="" className="absolute inset-0 h-full w-full object-cover object-[78%_center]" />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/78 to-black/10" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/35" />

      <div className="relative mx-auto grid max-w-[1240px] items-center gap-8 px-5 pb-48 pt-10 lg:grid-cols-[1fr_360px] lg:pb-56 lg:pt-14">
        <div>
          <h1 className="rise max-w-[640px] text-[40px] font-extrabold leading-[1.08] tracking-tight text-white md:text-[58px]">
            Your Favourite Meals,
            <br />
            Delivered <span className="text-[#FF6A00]">Fast</span>
          </h1>
          <p className="rise mt-4 max-w-md text-[15px] leading-relaxed text-white/70" style={{ animationDelay: "0.08s" }}>
            From Gate 1 to Gate 2 and beyond.
            <br />
            We deliver food, drinks, groceries and more.
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setQuery(local);
              document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="rise mt-8 flex max-w-[560px] items-center rounded-full bg-white p-1.5 shadow-[0_18px_50px_rgba(0,0,0,0.35)]"
            style={{ animationDelay: "0.14s" }}
          >
            <div className="flex min-w-0 flex-1 items-center gap-2 px-4 text-[#9a9a9a]">
              <IconSearch className="h-4 w-4 shrink-0" />
              <input
                value={local}
                onChange={(e) => setLocal(e.target.value)}
                placeholder="Enter delivery address"
                className="h-11 w-full bg-transparent text-[14px] font-medium text-black outline-none placeholder:text-[#b0b0b0]"
              />
            </div>
            <button className="flex h-11 shrink-0 items-center gap-1.5 rounded-full bg-[#FF6A00] px-5 text-[14px] font-bold text-white press">
              Order Now <IconArrow className="h-4 w-4" />
            </button>
          </form>

          <div className="rise mt-6 flex flex-wrap items-center gap-5 text-[13px] font-semibold text-white" style={{ animationDelay: "0.2s" }}>
            <span className="inline-flex items-center gap-2">
              <IconTruck className="h-5 w-5 text-[#FF6A00]" />
              Delivery from R35
            </span>
            <span className="h-5 w-px bg-white/20" />
            <span className="inline-flex items-center gap-2">
              <IconClock className="h-5 w-5 text-[#FF6A00]" />
              30–45 min delivery time
            </span>
          </div>
        </div>

        <div className="rise hidden justify-self-end lg:block" style={{ animationDelay: "0.16s" }}>
          <div className="w-[300px] rounded-[26px] bg-white p-5 text-[#171717] shadow-[0_24px_60px_rgba(0,0,0,0.35)]">
            <div className="flex items-center justify-between text-[13px] font-semibold text-[#555]">
              <span className="inline-flex items-center gap-1.5">
                <IconPin className="h-4 w-4 text-[#FF6A00]" /> Ordering From
              </span>
              <IconChevron className="h-4 w-4" />
            </div>
            <select
              value={zone}
              onChange={(e) => setZone(e.target.value as typeof zone)}
              className="mt-2 w-full appearance-none rounded-xl bg-[#f4f4f4] px-3 py-2.5 text-[13px] font-bold outline-none"
            >
              {ZONES.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.label}
                </option>
              ))}
            </select>
            <img src={IMG.rider} alt="" className="floaty mx-auto mt-5 h-[92px] w-auto rounded-2xl object-cover" />
            <p className="mt-4 text-center text-[13px] font-medium text-[#666]">Welcome to</p>
            <p className="text-center text-[26px] font-extrabold leading-none">
              Turf<span className="text-[#FF6A00]">Buddy</span>
            </p>
            <p className="mt-1.5 text-center text-[13px] text-[#888]">Good food, good mood.</p>
            <p className="mt-3 text-center text-[11px] font-semibold text-[#FF6A00]">
              {z.label} · {z.eta} · from R{z.fee}
            </p>
            <button
              onClick={() => setModal("splash")}
              className="mt-3 w-full text-[12px] font-bold text-[#FF6A00]"
            >
              Open app view
            </button>
          </div>
        </div>
      </div>

      <div id="categories" className="relative z-10 mx-auto max-w-[1240px] translate-y-1/2 px-5">
        <div className="rounded-[28px] bg-white px-5 py-5 shadow-[0_20px_60px_rgba(0,0,0,0.16)] md:px-7 md:py-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[20px] font-extrabold text-[#171717]">Browse Categories</h2>
            <button
              onClick={() => document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" })}
              className="text-[13px] font-semibold text-[#9a9a9a]"
            >
              View all
            </button>
          </div>
          <div className="hide-scroll flex gap-3 overflow-x-auto pb-1 md:grid md:grid-cols-9 md:overflow-visible">
            {CATEGORIES.map((c) => (
              <CategoryChip key={c.id} id={c.id} label={c.label} image={c.image} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function CategoryChip({ id, label, image }: { id: string; label: string; image: string }) {
  const { category, setCategory } = useStore();
  const on = category === id;
  return (
    <button
      onClick={() => {
        setCategory(on ? "all" : id);
        document.getElementById("restaurants")?.scrollIntoView({ behavior: "smooth" });
      }}
      className="flex min-w-[86px] flex-col items-center gap-2 press"
    >
      <span className={`grid h-[78px] w-[78px] overflow-hidden rounded-2xl bg-[#f3f3f3] ${on ? "ring-2 ring-[#FF6A00] ring-offset-2" : ""}`}>
        <img src={image} alt={label} className="h-full w-full object-cover" />
      </span>
      <span className={`text-[12px] font-bold ${on ? "text-[#FF6A00]" : "text-[#333]"}`}>{label}</span>
    </button>
  );
}

export function Featured() {
  const scroller = useRef<HTMLDivElement>(null);
  const featured = SHOPS.filter((s) => s.featured);
  const move = (dir: number) => scroller.current?.scrollBy({ left: dir * 280, behavior: "smooth" });

  return (
    <section className="bg-[#fafafa] px-5 pb-4 pt-40 md:pt-36">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-[22px] font-extrabold text-[#171717]">Featured Restaurants</h2>
          <a href="#restaurants" className="text-[13px] font-semibold text-[#9a9a9a]">
            View all
          </a>
        </div>
        <div className="relative">
          <button
            onClick={() => move(-1)}
            className="absolute -left-3 top-1/2 z-10 hidden h-9 w-9 -translate-y-1/2 place-items-center rounded-full border border-black/8 bg-white shadow md:grid"
          >
            <IconChevron className="h-4 w-4 rotate-180 text-[#171717]" />
          </button>
          <div ref={scroller} className="hide-scroll flex gap-4 overflow-x-auto pb-2">
            {featured.map((s) => (
              <div key={s.id} className="w-[228px] shrink-0">
                <ShopCard shop={s} />
              </div>
            ))}
          </div>
          <button
            onClick={() => move(1)}
            className="absolute -right-3 top-1/2 z-10 hidden h-9 w-9 -translate-y-1/2 place-items-center rounded-full border border-black/8 bg-white shadow md:grid"
          >
            <IconChevron className="h-4 w-4 text-[#171717]" />
          </button>
        </div>
      </div>
    </section>
  );
}

export function Restaurants() {
  const { category, query } = useStore();
  const [filterZone, setFilterZone] = useState<"all" | Shop["zone"]>("all");

  const list = useMemo(() => {
    return SHOPS.filter((s) => {
      if (filterZone !== "all" && s.zone !== filterZone) return false;
      if (category !== "all" && s.category !== category) return false;
      if (query.trim()) {
        const q = query.toLowerCase();
        return (
          s.name.toLowerCase().includes(q) ||
          s.tagline.toLowerCase().includes(q) ||
          s.menu?.some((m) => m.name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [category, query, filterZone]);

  const groups = [
    { title: "Gate 2 Shops", hint: "Full menus · tap to add", items: list.filter((s) => s.zone === "gate2") },
    { title: "Gate 1 Shops", hint: "Full menus · tap to add", items: list.filter((s) => s.zone === "gate1") },
    { title: "Mankweng", hint: "Tell us what you want", items: list.filter((s) => s.zone === "mankweng") },
    { title: "Paledi & Liquor", hint: "Official brands and liquor", items: list.filter((s) => s.zone === "paledi") },
  ].filter((g) => g.items.length);

  return (
    <section id="restaurants" className="bg-[#fafafa] px-5 py-16">
      <div className="mx-auto max-w-[1240px]">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-[28px] font-extrabold text-[#171717]">All Restaurants</h2>
            <p className="mt-1 text-sm text-[#888]">Menus for Gate 1 & Gate 2. Official brands open an order form.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {[{ id: "all" as const, label: "All" }, ...ZONES.map((z) => ({ id: z.id, label: z.label }))].map((z) => (
              <button
                key={z.id}
                onClick={() => setFilterZone(z.id)}
                className={`rounded-full px-3.5 py-1.5 text-xs font-bold ${
                  filterZone === z.id ? "bg-[#FF6A00] text-white" : "bg-white text-[#555] ring-1 ring-black/8"
                }`}
              >
                {z.label}
              </button>
            ))}
          </div>
        </div>

        {groups.map((g) => (
          <div key={g.title} className="mt-10">
            <div className="mb-4 flex items-baseline justify-between">
              <h3 className="text-[20px] font-extrabold text-[#171717]">{g.title}</h3>
              <span className="text-xs font-medium text-[#999]">{g.hint}</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {g.items.map((s) => (
                <ShopCard key={s.id} shop={s} />
              ))}
            </div>
          </div>
        ))}
        {!list.length && <p className="mt-16 text-center text-[#999]">No shops match that search.</p>}
      </div>
    </section>
  );
}

export function Services() {
  const items = [
    { t: "Pickup / Drop Off", d: "Send parcels between residences, campus and town." },
    { t: "Home Delivery", d: "Meals from Gate 1, Gate 2, Mankweng and Paledi to your door." },
    { t: "Personal Errands", d: "We queue, collect scripts, print and run campus errands." },
    { t: "Intra-City Delivery", d: "Same-day hops across Turfloop and surrounding areas." },
    { t: "Corporate Delivery", d: "Office lunches and bulk orders for residences." },
    { t: "Food Delivery", d: "Kotas, plates, braai boxes and official restaurant orders." },
  ];
  return (
    <section className="bg-white px-5 py-8">
      <div className="mx-auto max-w-[1240px] rounded-[32px] bg-[#111] p-8 text-white md:p-12">
        <h2 className="text-3xl font-extrabold">Everything we move</h2>
        <p className="mt-2 max-w-xl text-white/50">Six services. One WhatsApp. One rider network.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it, i) => (
            <div key={it.t} className="lift rounded-2xl border border-white/8 bg-white/4 p-5">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#FF6A00] text-sm font-extrabold">0{i + 1}</div>
              <h3 className="mt-4 text-lg font-bold">{it.t}</h3>
              <p className="mt-1 text-sm text-white/50">{it.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function HowItWorks() {
  const steps = [
    { n: "01", t: "Choose where you are ordering from", d: "Gate 1, Gate 2, Mankweng or Paledi Mall." },
    { n: "02", t: "Open a shop", d: "Gate shops show full menus. Official brands open a request form." },
    { n: "03", t: "Add to cart", d: "Build your order, add a note, pick cash or Capitec." },
    { n: "04", t: "Checkout on WhatsApp", d: "We confirm, collect and deliver in 30–45 minutes." },
  ];
  return (
    <section id="how" className="bg-[#fafafa] px-5 py-16">
      <div className="mx-auto max-w-[1240px]">
        <h2 className="text-3xl font-extrabold text-[#171717]">How it works</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-4">
          {steps.map((s) => (
            <div key={s.n} className="rounded-2xl border border-black/6 bg-white p-6">
              <span className="text-4xl font-extrabold text-[#FF6A00]/30">{s.n}</span>
              <h3 className="mt-3 text-lg font-bold text-[#171717]">{s.t}</h3>
              <p className="mt-1 text-sm text-[#777]">{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Pricing() {
  const tiers = [
    { name: "Mankweng / Gates", price: "R35", d: "Gate 1, Gate 2 and Mankweng campus area.", popular: true },
    { name: "Paledi Mall", price: "R55", d: "Restaurants and liquor from Paledi Mall." },
    { name: "Custom / Bulk", price: "Quote", d: "Residence events, office trays and multi-stop runs." },
  ];
  return (
    <section id="pricing" className="bg-[#fafafa] px-5 pb-8">
      <div className="mx-auto max-w-[1240px]">
        <h2 className="text-3xl font-extrabold text-[#171717]">Delivery fees</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {tiers.map((t) => (
            <div key={t.name} className={`rounded-3xl border p-7 ${t.popular ? "border-[#FF6A00] bg-[#FF6A00] text-white" : "border-black/6 bg-white text-[#171717]"}`}>
              {t.popular && <p className="text-xs font-bold uppercase tracking-widest text-white/80">Most popular</p>}
              <h3 className="mt-2 text-xl font-extrabold">{t.name}</h3>
              <p className="mt-4 text-4xl font-extrabold">{t.price}</p>
              <p className={`mt-3 text-sm ${t.popular ? "text-white/80" : "text-[#777]"}`}>{t.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Testimonials() {
  const [i, setI] = useState(0);
  const data = [
    { n: "Thabo M.", t: "Gate 2 kota landed hot. Rider pinged on WhatsApp the whole way." },
    { n: "Lerato K.", t: "Ordered Nando’s from Paledi for a res dinner. Clean handoff." },
    { n: "Kea P.", t: "Capitec payment was instant and the plate from Divine Girls was packed properly." },
    { n: "Sibusiso N.", t: "Thrive braai box for four people. Exactly as listed. Will use again." },
  ];
  const cur = data[i % data.length];
  return (
    <section className="bg-white px-5 py-16">
      <div className="mx-auto max-w-[720px] text-center">
        <h2 className="text-3xl font-extrabold text-[#171717]">Loved on campus</h2>
        <div className="mt-8 rounded-3xl border border-black/6 bg-[#fafafa] p-8">
          <div className="flex justify-center gap-1 text-[#FF6A00]">
            {Array.from({ length: 5 }).map((_, k) => (
              <IconStar key={k} className="h-4 w-4" />
            ))}
          </div>
          <p className="mt-5 text-lg font-medium leading-relaxed text-[#222]">“{cur.t}”</p>
          <p className="mt-4 text-sm font-bold text-[#171717]">{cur.n}</p>
          <div className="mt-6 flex justify-center gap-2">
            <button onClick={() => setI((v) => (v + data.length - 1) % data.length)} className="grid h-9 w-9 place-items-center rounded-full bg-white shadow">
              <IconChevron className="h-4 w-4 rotate-180" />
            </button>
            <button onClick={() => setI((v) => (v + 1) % data.length)} className="grid h-9 w-9 place-items-center rounded-full bg-white shadow">
              <IconChevron className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export function WhatsAppCTA() {
  return (
    <section id="about" className="bg-[#fafafa] px-5 pb-24">
      <div className="relative mx-auto max-w-[1240px] overflow-hidden rounded-[32px]">
        <img src={IMG.rider} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#ff6a00] via-[#ff6a00]/90 to-black/50" />
        <div className="relative grid gap-8 p-8 md:grid-cols-2 md:p-14">
          <div className="text-white">
            <p className="text-[11px] font-bold uppercase tracking-[0.28em]">Food. Drinks. Errands.</p>
            <h2 className="mt-3 text-5xl font-extrabold leading-[0.95]">TURF</h2>
            <p className="mt-6 text-2xl font-bold">
              Good food.
              <br />
              Good mood.
              <br />
              We deliver.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-white/85">
              {["WhatsApp booking in one tap", "Capitec or cash on delivery", "Live rider updates", "Menus for every Gate shop"].map((x) => (
                <li key={x} className="flex items-center gap-2">
                  <IconCheck className="h-4 w-4" /> {x}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl bg-white p-6 text-[#171717]">
            <p className="text-sm font-semibold text-[#888]">Chat or call</p>
            <p className="mt-1 text-2xl font-extrabold">076 823 0206</p>
            <a
              href="https://wa.me/27768230206?text=Hi%20TurfBuddy%2C%20I%20want%20to%20place%20an%20order."
              target="_blank"
              rel="noreferrer"
              className="mt-5 flex h-12 items-center justify-center rounded-full bg-[#FF6A00] text-sm font-bold text-white press"
            >
              Book on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
