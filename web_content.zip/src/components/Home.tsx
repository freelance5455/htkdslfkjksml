import { allFormulas } from "../data";
import type { Board, ClassLevel } from "../data/types";
import { useAppState } from "../state/AppState";

const classInfo: { level: ClassLevel; blurb: string; gradient: string }[] = [
  { level: 8, blurb: "Build strong foundations in algebra, mensuration and introductory science.", gradient: "from-sky-500 to-indigo-500" },
  { level: 9, blurb: "Motion, gravitation, atoms & molecules, polynomials and statistics.", gradient: "from-indigo-500 to-violet-500" },
  { level: 10, blurb: "Trigonometry, electricity, light, quadratics and board-exam essentials.", gradient: "from-violet-500 to-fuchsia-500" },
];

const BOARDS: { id: Board; label: string; blurb: string }[] = [
  { id: "CBSE", label: "CBSE", blurb: "NCERT textbooks · Physics & Chemistry taught as integrated Science" },
  { id: "ICSE", label: "ICSE / CISCE", blurb: "Separate Physics & Chemistry papers · Selina-style textbooks" },
];

export default function Home() {
  const { navigate, board, setBoard } = useAppState();
  const total = allFormulas.length;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="animate-fade-in text-center">
        <div className="mx-auto mb-4 inline-flex items-center gap-1.5 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-600 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300">
          <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" /> {total}+ interactive formulas · solver · quiz · AI tutor
        </div>
        <h1 className="bg-gradient-to-br from-slate-900 via-indigo-700 to-purple-700 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent dark:from-white dark:via-indigo-300 dark:to-purple-300 sm:text-5xl">
          FormulaVerse
        </h1>
        <p className="mt-2 text-lg font-medium text-slate-500 dark:text-slate-400">Class 8–10 Formula Library</p>
        <p className="mx-auto mt-4 max-w-xl text-sm text-slate-500 dark:text-slate-400">
          Don't just memorize formulas. <span className="font-semibold text-slate-700 dark:text-slate-200">See how they work.</span>
        </p>
      </div>

      <div className="mx-auto mt-8 max-w-xl">
        <p className="mb-2 text-center text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">Step 1 — Choose your board</p>
        <div className="grid grid-cols-2 gap-3">
          {BOARDS.map((b) => (
            <button
              key={b.id}
              onClick={() => setBoard(b.id)}
              className={`rounded-2xl border p-4 text-left shadow-sm transition ${
                board === b.id
                  ? "border-indigo-400 bg-indigo-50 ring-2 ring-indigo-400 dark:border-indigo-500/60 dark:bg-indigo-500/10"
                  : "border-slate-200 bg-white hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
              }`}
            >
              <span className={`block font-bold ${board === b.id ? "text-indigo-700 dark:text-indigo-300" : "text-slate-800 dark:text-slate-100"}`}>{b.label}</span>
              <span className="mt-0.5 block text-xs text-slate-500 dark:text-slate-400">{b.blurb}</span>
            </button>
          ))}
        </div>
      </div>

      <p className="mb-2 mt-8 text-center text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">Step 2 — Choose your class</p>
      <div className="grid gap-5 sm:grid-cols-3">
        {classInfo.map((c) => (
          <button
            key={c.level}
            onClick={() => navigate({ name: "class", classLevel: c.level })}
            className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900"
          >
            <div className={`absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br ${c.gradient} opacity-20 blur-xl transition group-hover:opacity-30`} />
            <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${c.gradient} text-xl font-bold text-white shadow-md`}>
              {c.level}
            </div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">Class {c.level}</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{c.blurb}</p>
            <div className="mt-4 flex gap-1.5">
              {["Mathematics", "Physics", "Chemistry"].map((s) => (
                <span key={s} className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                  {s}
                </span>
              ))}
            </div>
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <button
          onClick={() => navigate({ name: "solver" })}
          className="group flex flex-col items-start gap-3 overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-left text-white shadow-lg shadow-indigo-500/20 transition hover:-translate-y-0.5 hover:shadow-xl"
        >
          <span className="text-3xl">🧮</span>
          <span>
            <span className="block text-lg font-bold">Problem Solver</span>
            <span className="mt-1 block text-sm text-indigo-100">
              Algebra, geometry proofs, circle theorems and word problems — complete step-by-step, verified solutions.
            </span>
          </span>
          <span className="rounded-xl bg-white/15 px-4 py-2 text-sm font-semibold transition group-hover:bg-white/25">Try it →</span>
        </button>

        <button
          onClick={() => navigate({ name: "ai" })}
          className="group flex flex-col items-start gap-3 overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900"
        >
          <span className="text-3xl">🤖</span>
          <span>
            <span className="block text-lg font-bold text-slate-800 dark:text-slate-100">AI Tutor</span>
            <span className="mt-1 block text-sm text-slate-500 dark:text-slate-400">
              Ask follow-up questions in plain language and get concept explanations in simple, student-friendly language. Limited free
              messages per day.
            </span>
          </span>
          <span className="rounded-xl bg-indigo-50 px-4 py-2 text-sm font-semibold text-indigo-600 transition group-hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300">
            Ask a question →
          </span>
        </button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <QuickLink title="Quiz" desc="Test yourself with Class 8–10 MCQs across all three subjects." icon="📝" onClick={() => navigate({ name: "quiz" })} />
        <QuickLink
          title="Search Formula"
          desc="Find any formula instantly by name, symbol or keyword."
          icon="🔍"
          onClick={() => navigate({ name: "search" })}
        />
        <QuickLink title="Favorites" desc="Your bookmarked formulas, all in one place." icon="⭐" onClick={() => navigate({ name: "favorites" })} />
        <QuickLink title="Recently Viewed" desc="Pick up right where you left off this session." icon="🕒" onClick={() => navigate({ name: "recent" })} />
        <QuickLink title="Formula History" desc="Every formula the Solver or AI Tutor has used, saved automatically." icon="🧾" onClick={() => navigate({ name: "history" })} />
      </div>

      <div className="mt-12 rounded-2xl border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-500 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-400">
        Every formula includes interactive sliders, live calculations, a worked example, a common mistake to avoid, and quick practice questions —
        so you understand the <em>why</em>, not just the <em>what</em>.
      </div>
    </div>
  );
}

function QuickLink({ title, desc, icon, onClick }: { title: string; desc: string; icon: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
    >
      <span className="text-2xl">{icon}</span>
      <span>
        <span className="block font-semibold text-slate-800 dark:text-slate-100">{title}</span>
        <span className="block text-xs text-slate-500 dark:text-slate-400">{desc}</span>
      </span>
    </button>
  );
}
