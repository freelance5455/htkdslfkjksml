import { useEffect, useRef } from 'react';
import { Engine } from '@/game/engine';
import type { EngineEvent } from '@/game/types';

interface Props {
  onReady: (engine: Engine) => void;
  onEvent: (e: EngineEvent) => void;
}

export default function GameCanvas({ onReady, onEvent }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const onEventRef = useRef(onEvent);
  const onReadyRef = useRef(onReady);
  onEventRef.current = onEvent;
  onReadyRef.current = onReady;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const engine = new Engine(canvas);
    engine.onEvent = (e) => onEventRef.current(e);
    onReadyRef.current(engine);
    return () => engine.destroy();
  }, []);

  return (
    <canvas
      ref={ref}
      className="absolute inset-0 block h-full w-full touch-none select-none"
      style={{ touchAction: 'none' }}
      aria-label="Word Rush game"
    />
  );
}
