import React, { useEffect, useRef, useCallback } from "react";
import {
  Player,
  Dog,
  Tree,
  FarmTile,
  Item,
  GroundDrop,
  Particle,
  FloatingText,
  AmbientCritter,
  WeatherType,
  SeasonType,
  LandPlot,
} from "../types";
import { TileType } from "../game/world";
import {
  TILE_SIZE,
  MAP_COLS,
  MAP_ROWS,
  WORLD_WIDTH,
  WORLD_HEIGHT,
  SEASONS_DATA,
  CAMPFIRE_X,
  CAMPFIRE_Y,
  CAMPFIRE_DEFAULT_RADIUS,
  DEEP_KOCHUBON_MIN_COL,
} from "../game/constants";
import {
  CampfireData,
  BuildingStructure,
  MonsterDog,
} from "../types";
import { sound } from "../audio";

interface GameCanvasProps {
  tiles: TileType[][];
  trees: Tree[];
  farmTiles: Map<string, FarmTile>;
  player: Player;
  dogs: Dog[];
  groundDrops: GroundDrop[];
  landPlots: LandPlot[];
  campfire?: CampfireData;
  structures?: BuildingStructure[];
  monster?: MonsterDog | null;
  hotbar: Item[];
  activeSlot: number;
  mustakimArrived: boolean;
  weather: WeatherType;
  season: SeasonType;
  gameDay: number;
  dayTime: number;
  isMinimalMode?: boolean;
  onDogSit?: () => void;
  onUpdatePlayer: (updater: (prev: Player) => Player) => void;
  onUpdateDogs: (updater: (prev: Dog[]) => Dog[]) => void;
  onUpdateTrees: (updater: (prev: Tree[]) => Tree[]) => void;
  onUpdateFarmTiles: (
    updater: (prev: Map<string, FarmTile>) => Map<string, FarmTile>
  ) => void;
  onUpdateCampfire?: (updater: (prev: CampfireData) => CampfireData) => void;
  onUpdateStructures?: (updater: (prev: BuildingStructure[]) => BuildingStructure[]) => void;
  onCollectDrop: (drop: GroundDrop) => void;
  onOpenShop: () => void;
  onOpenCrafting: () => void;
  onOpenScience: () => void;
  onBuyLand: (plot: LandPlot) => void;
  onAddFloatingText: (text: string, x: number, y: number, color?: string) => void;
  onBefriendDog: (dogId: string) => void;
  onTreeCutCount: () => void;
  onNearDogChange?: (near: boolean) => void;
  onZoneChange?: (inDeep: boolean, inCamp: boolean) => void;
  onFpsUpdate?: (fps: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  tiles,
  trees,
  farmTiles,
  player,
  dogs,
  groundDrops,
  landPlots,
  campfire,
  structures,
  monster,
  hotbar,
  activeSlot,
  mustakimArrived,
  weather,
  season,
  gameDay = 1,
  dayTime = 0.3,
  isMinimalMode = false,
  onDogSit,
  onUpdatePlayer,
  onUpdateDogs,
  onUpdateTrees,
  onUpdateFarmTiles,
  onUpdateCampfire,
  onUpdateStructures,
  onCollectDrop,
  onOpenShop,
  onOpenCrafting,
  onBuyLand,
  onAddFloatingText,
  onBefriendDog,
  onTreeCutCount,
  onNearDogChange,
  onZoneChange,
  onFpsUpdate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const crittersRef = useRef<AmbientCritter[]>([]);
  const rainDropsRef = useRef<
    { x: number; y: number; length: number; speed: number }[]
  >([]);
  const fogOffsetsRef = useRef<number[]>([0, 100, 250]);
  const lastTimeRef = useRef<number>(performance.now());
  const cameraRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const walkCycleRef = useRef<number>(0);

  // --- 60 FPS ZERO-LAG ARCHITECTURE REFS ---
  const playerRef = useRef<Player>({ ...player });
  const dogsRef = useRef<Dog[]>(dogs.map((d) => ({ ...d })));
  const treesRef = useRef<Tree[]>([...trees]);
  const farmTilesRef = useRef<Map<string, FarmTile>>(new Map(farmTiles));
  const dropsRef = useRef<GroundDrop[]>([...groundDrops]);
  const hotbarRef = useRef<Item[]>([...hotbar]);
  const activeSlotRef = useRef<number>(activeSlot);
  const weatherRef = useRef<WeatherType>(weather);
  const seasonRef = useRef<SeasonType>(season);
  const landPlotsRef = useRef<LandPlot[]>([...landPlots]);
  const dayTimeRef = useRef<number>(dayTime);
  const mustakimArrivedRef = useRef<boolean>(mustakimArrived);
  const gameDayRef = useRef<number>(gameDay);

  // ROBLOX 99 NIGHTS IN THE FOREST & DEEP KOCHUBON REFS
  const campfireRef = useRef<CampfireData>(
    campfire || {
      x: CAMPFIRE_X,
      y: CAMPFIRE_Y,
      radius: CAMPFIRE_DEFAULT_RADIUS,
      level: 1,
      fuel: 100,
      maxRadius: 380,
    }
  );
  const structuresRef = useRef<BuildingStructure[]>(structures || []);
  const monsterRef = useRef<MonsterDog | null>(monster || null);
  const wasInDeepKochubonRef = useRef<boolean>(false);
  const deepTextBannerRef = useRef<{
    title: string;
    subtitle: string;
    timer: number;
    alpha: number;
  } | null>(null);
  const campfireWarningRingRef = useRef<number>(0);

  // Rolling FPS calculation
  const fpsRef = useRef<number>(60);
  const fpsLastTimeRef = useRef<number>(performance.now());
  const fpsFrameCountRef = useRef<number>(0);
  const lastSyncTimeRef = useRef<number>(performance.now());

  // Keep refs in sync with external state changes
  useEffect(() => {
    playerRef.current.coins = player.coins;
    playerRef.current.hp = player.hp;
    playerRef.current.equippedSlot = activeSlot;
    playerRef.current.isSprinting = player.isSprinting;
    if (player.stamina !== undefined) {
      playerRef.current.stamina = player.stamina;
    }
    if (player.isJumping && !playerRef.current.isJumping) {
      triggerJump();
    }
  }, [player.coins, player.hp, activeSlot, player.isSprinting, player.isJumping, player.stamina]);

  useEffect(() => {
    if (campfire) campfireRef.current = campfire;
  }, [campfire]);

  useEffect(() => {
    if (structures) structuresRef.current = structures;
  }, [structures]);

  useEffect(() => {
    if (monster) monsterRef.current = monster;
  }, [monster]);

  useEffect(() => {
    dayTimeRef.current = dayTime;
  }, [dayTime]);

  useEffect(() => {
    mustakimArrivedRef.current = mustakimArrived;
  }, [mustakimArrived]);

  useEffect(() => {
    gameDayRef.current = gameDay;
  }, [gameDay]);

  // Direct 0ms touch and button event listeners for Jump, Sprint & Dog Sit
  useEffect(() => {
    const handleGameJump = () => {
      triggerJump();
    };
    const handleGameSprint = () => {
      const p = playerRef.current;
      // Only sprint if player has enough stamina
      if (!p.isSprinting && (p.stamina <= 10 || p.isExhausted)) {
        addFloating("💨 স্ট্যামিনা শেষ! দৌড়ানো যাবে না!", p.x, p.y - 15, "#F87171");
        return;
      }
      const nextSprint = !p.isSprinting;
      p.isSprinting = nextSprint;
      onUpdatePlayer((prev) => ({ ...prev, isSprinting: nextSprint }));
    };

    const handleDogSitCommand = () => {
      toggleNearestDogSit();
    };

    window.addEventListener("game-jump", handleGameJump);
    window.addEventListener("game-sprint", handleGameSprint);
    window.addEventListener("game-dog-sit", handleDogSitCommand);
    return () => {
      window.removeEventListener("game-jump", handleGameJump);
      window.removeEventListener("game-sprint", handleGameSprint);
      window.removeEventListener("game-dog-sit", handleDogSitCommand);
    };
  }, [onUpdatePlayer]);

  useEffect(() => {
    hotbarRef.current = hotbar;
  }, [hotbar]);

  useEffect(() => {
    activeSlotRef.current = activeSlot;
  }, [activeSlot]);

  useEffect(() => {
    weatherRef.current = weather;
  }, [weather]);

  useEffect(() => {
    seasonRef.current = season;
  }, [season]);

  useEffect(() => {
    treesRef.current = trees;
  }, [trees]);

  useEffect(() => {
    farmTilesRef.current = farmTiles;
  }, [farmTiles]);

  useEffect(() => {
    dropsRef.current = groundDrops;
  }, [groundDrops]);

  useEffect(() => {
    landPlotsRef.current = landPlots;
  }, [landPlots]);

  // Initialize rain particles and ambient village critters
  useEffect(() => {
    rainDropsRef.current = Array.from({ length: 85 }).map(() => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      length: 14 + Math.random() * 12,
      speed: 18 + Math.random() * 8,
    }));

    crittersRef.current = Array.from({ length: 16 }).map(() => ({
      x: Math.random() * WORLD_WIDTH,
      y: Math.random() * WORLD_HEIGHT,
      vx: (Math.random() - 0.5) * 1.5,
      vy: (Math.random() - 0.5) * 1.5,
      type: Math.random() > 0.5 ? "butterfly" : "firefly",
      color: Math.random() > 0.5 ? "#FDE047" : "#38BDF8",
      size: 3 + Math.random() * 3,
    }));
  }, []);

  // Responsive Canvas Resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Helper to add particles (capped to avoid GC pressure)
  const addParticles = useCallback(
    (x: number, y: number, color: string, count = 6) => {
      if (particlesRef.current.length > 55) {
        particlesRef.current.splice(0, count);
      }
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 3.5;
        particlesRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color,
          size: 2 + Math.random() * 3,
          alpha: 1,
          life: 0,
          maxLife: 0.35 + Math.random() * 0.4,
        });
      }
    },
    []
  );

  // Helper for floating text
  const addFloating = useCallback(
    (text: string, x: number, y: number, color = "#FFFFFF") => {
      if (floatingTextsRef.current.length > 10) {
        floatingTextsRef.current.shift();
      }
      floatingTextsRef.current.push({
        id: Math.random().toString(),
        x,
        y,
        text,
        color,
        alpha: 1,
        vy: -1.2,
      });
      onAddFloatingText(text, x, y, color);
    },
    [onAddFloatingText]
  );

  const isHoldingThreateningWeapon = useCallback(() => {
    const equipped = hotbarRef.current[activeSlotRef.current];
    if (!equipped) return false;
    if (equipped.id === "hand_empty" || equipped.id.includes("hand")) return false;
    return equipped.id.includes("stick") || equipped.id.includes("axe");
  }, []);

  // Jump trigger
  const triggerJump = useCallback(() => {
    const p = playerRef.current;
    if (p.isJumping) return;
    sound.playJump();
    addParticles(p.x + 16, p.y + 36, "#CBD5E1", 6);
    p.isJumping = true;
    p.vz = 135;
    p.z = 2;
  }, [addParticles]);

  // TOGGLE NEAREST DOG SIT / STAND COMMAND (User feature: "when tojo go near the dogs there button appears name sit the dog sits")
  const toggleNearestDogSit = useCallback(() => {
    const p = playerRef.current;
    let closestDog: Dog | null = null;
    let minDist = 180;
    dogsRef.current.forEach((d) => {
      const dist = Math.hypot(d.x - p.x, d.y - p.y);
      if (dist < minDist) {
        minDist = dist;
        closestDog = d;
      }
    });

    if (closestDog) {
      const d: Dog = closestDog;
      if (d.state === "sitting" || d.isSitting) {
        // Stand up & follow
        d.state = d.isFriend ? "follow" : "wander";
        d.isSitting = false;
        d.speechBubble = "ঘেউ! দাঁড়ালাম তোজো ভাই! 🐾";
        d.bubbleTimer = 3.5;
        sound.playDogHappyBark();
        addFloating(`🐾 ${d.bengaliName} দাঁড়িয়েছে!`, d.x, d.y - 25, "#34D399");
        addParticles(d.x + 16, d.y + 16, "#34D399", 8);
      } else {
        // Sit down
        d.state = "sitting";
        d.isSitting = true;
        d.speechBubble = "🐶 তোজোর আদেশে বসলাম! (Sit) 🐾";
        d.bubbleTimer = 4.0;
        sound.playDogSit();
        addFloating(`🐾 ${d.bengaliName} বসেছে! (Sit)`, d.x, d.y - 25, "#10B981");
        addParticles(d.x + 16, d.y + 16, "#10B981", 10);
      }
      onUpdateDogs(() => [...dogsRef.current]);
    } else {
      addFloating("কাছে কোনো কুকুর নেই!", p.x, p.y - 20, "#F59E0B");
    }
  }, [addFloating, addParticles, onUpdateDogs]);

  // ROBLOX 99 NIGHTS IN THE FOREST BUILDING BOUNDARY RULE:
  // "under campfire we can build everything no across the line of campfire we can't build anything"
  const canBuildAt = useCallback(
    (targetX: number, targetY: number): boolean => {
      const camp = campfireRef.current;
      const dist = Math.hypot(targetX - camp.x, targetY - camp.y);
      if (dist <= camp.radius) {
        return true;
      }
      // Outside campfire perimeter: BLOCKED!
      sound.playBuildDenied();
      campfireWarningRingRef.current = 2.0;
      addParticles(targetX, targetY, "#EF4444", 10);
      addFloating("⚠️ ক্যাম্পফায়ারের সীমার বাইরে নির্মাণ নিষেধ! (Roblox 99 Nights)", targetX, targetY - 20, "#EF4444");
      return false;
    },
    [addFloating, addParticles]
  );

  // Key listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }
      keysPressed.current[e.key.toLowerCase()] = true;

      // Shift for Sprint
      if (e.key === "Shift") {
        const p = playerRef.current;
        if (p.stamina > 10 && !p.isExhausted) {
          playerRef.current.isSprinting = true;
        }
      }

      // J or Space for Jump
      if (e.key.toLowerCase() === "j") {
        triggerJump();
      }

      // T for Dog Sit Command
      if (e.key.toLowerCase() === "t") {
        toggleNearestDogSit();
      }

      // Hotbar slots 1 through 7
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 7) {
        activeSlotRef.current = num - 1;
        onUpdatePlayer((p) => ({ ...p, equippedSlot: num - 1 }));
      }
      // '0' or 'x' switches to bare hand (slot 0)
      if (e.key === "0" || e.key.toLowerCase() === "x") {
        activeSlotRef.current = 0;
        onUpdatePlayer((p) => ({ ...p, equippedSlot: 0 }));
      }

      if (e.code === "Space") {
        e.preventDefault();
        performAction();
      }

      if (e.key.toLowerCase() === "e") {
        checkInteractions();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = false;
      if (e.key === "Shift") {
        playerRef.current.isSprinting = false;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [triggerJump, toggleNearestDogSit]);

  const checkInteractions = () => {
    const p = playerRef.current;

    // Check interaction with Crafting Table
    const craftTable = structuresRef.current.find(
      (s) => s.type === "crafting_table"
    );
    if (craftTable) {
      const distToTable = Math.hypot(p.x - craftTable.x, p.y - craftTable.y);
      if (distToTable < 85) {
        sound.playCraftSuccess();
        onOpenCrafting();
        return;
      }
    }

    // Check interaction with Campfire status
    const camp = campfireRef.current;
    const distToCamp = Math.hypot(p.x - camp.x, p.y - camp.y);
    if (distToCamp < 85) {
      sound.playHarvest();
      addFloating(
        `🔥 ক্যাম্পফায়ার Lv.${camp.level} • ${camp.logsDeposited || 0}/${camp.logsNeededForNextLevel || 5} কাঠ জমা`,
        camp.x,
        camp.y - 25,
        "#FBBF24"
      );
      return;
    }

    // Check interaction with Mustakim Dock (Arrives every 2 days)
    const dockX = 30 * TILE_SIZE;
    const dockY = 14 * TILE_SIZE;
    const distToShop = Math.hypot(p.x - dockX, p.y - dockY);
    if (distToShop < 130) {
      if (mustakimArrivedRef.current) {
        sound.playMustakimBell();
        onOpenShop();
      } else {
        sound.playBuildDenied();
        addFloating(
          `⛵ মুস্তাকিম পণ্য সংগ্রহের জন্য নৌকায় আছেন! প্রতি ২ দিনে আসেন (দিন ${gameDayRef.current + 1}-এ আসবেন)`,
          p.x,
          p.y - 20,
          "#38BDF8"
        );
      }
      return;
    }
  };

  // Perform tool / hand action
  const performAction = useCallback(() => {
    const p = playerRef.current;
    const equipped = hotbarRef.current[activeSlotRef.current];
    if (!equipped) return;

    let targetX = p.x;
    let targetY = p.y;
    const reach = 48;
    if (p.facing === "up") targetY -= reach;
    else if (p.facing === "down") targetY += reach;
    else if (p.facing === "left") targetX -= reach;
    else if (p.facing === "right") targetX += reach;

    // 0. BARE HAND (খালি হাত ✋)
    if (equipped.id === "hand_empty" || equipped.id.includes("hand")) {
      sound.playHandWave();
      p.isActing = true;
      p.actionTimer = 0.3;
      p.actionType = "hand";
      p.handAnim = 1.0;
      addParticles(targetX, targetY, "#FEF08A", 8);

      // Check nearby dogs to pet with gentle hand
      let pettedDog = false;
      dogsRef.current.forEach((d) => {
        const dist = Math.hypot(d.x - p.x, d.y - p.y);
        if (dist < 130 && !pettedDog) {
          pettedDog = true;
          sound.playDogPetLove();
          if (d.id === "dog_chotu") sound.playPuppyYip();
          else sound.playDogHappyBark();
          onBefriendDog(d.id);
          addParticles(d.x + 16, d.y + 16, "#EC4899", 14);
          addFloating(
            `❤️ ${d.bengaliName} তোজোর খালি হাতে আদর পেলো!`,
            d.x,
            d.y - 25,
            "#F43F5E"
          );
          d.state = "pet";
          d.fearLevel = 0;
          d.loyalty = Math.min(100, d.loyalty + 30);
          d.isFriend = true;
          d.speed = 3.2;
          d.bellyRollTimer = 4.0;
          d.speechBubble = "তোজোর হাত কত নরম! ঘেউ ঘেউ! ❤️";
          d.bubbleTimer = 4.5;
        }
      });

      // Also harvest ripe farm crops cleanly by hand
      const tileC = Math.floor(targetX / TILE_SIZE);
      const tileR = Math.floor(targetY / TILE_SIZE);
      const key = `${tileC},${tileR}`;
      const farmTile = farmTilesRef.current.get(key);

      if (farmTile && farmTile.growthStage >= 4 && farmTile.cropType) {
        sound.playHarvest();
        const cropName =
          farmTile.cropType === "taro"
            ? "কচু (Colocasia)"
            : farmTile.cropType === "paddy"
            ? "ধান (Rice)"
            : "বেগুন (Eggplant)";

        addFloating(
          `✨ হাত দিয়ে ফসল সংগ্রহ: ${cropName}!`,
          farmTile.x + 16,
          farmTile.y - 15,
          "#FBBF24"
        );
        addParticles(farmTile.x + 24, farmTile.y + 24, "#10B981", 10);

        onCollectDrop({
          id: `harvest_${Date.now()}`,
          x: farmTile.x,
          y: farmTile.y,
          item: {
            id: `crop_${farmTile.cropType}`,
            name: `Harvested ${farmTile.cropType.toUpperCase()}`,
            bengaliName: cropName,
            type: "crop",
            description: "Freshly hand-picked organic village crop.",
            icon:
              farmTile.cropType === "taro"
                ? "🥔"
                : farmTile.cropType === "paddy"
                ? "🌾"
                : "🍆",
            count: 3,
            value: farmTile.cropType === "taro" ? 18 : 12,
          },
          lifespan: 9999,
        });

        farmTilesRef.current.set(key, {
          ...farmTile,
          cropType: null,
          growthStage: 0,
          growthTimer: 0,
          isWatered: weatherRef.current === "rain",
          waterLevel: weatherRef.current === "rain" ? 100 : 0,
        });
        onUpdateFarmTiles(
          (prev) => new Map(prev.set(key, farmTilesRef.current.get(key)!))
        );
      } else if (!pettedDog) {
        addFloating("✋ শান্ত হাত (Friendly Hand)", targetX, targetY - 15, "#FDE047");
      }
    }

    // 1. STICK (Defense & Monster Deterrent)
    else if (equipped.id.includes("stick")) {
      sound.playSwing();
      p.isActing = true;
      p.actionTimer = 0.25;
      p.actionType = "swing";
      p.handAnim = 1.0;
      addParticles(targetX, targetY, "#E0A96D", 5);

      // Fight Kochu Khor Kukur if nearby
      if (monsterRef.current) {
        const m = monsterRef.current;
        const distToM = Math.hypot(m.x + 20 - targetX, m.y + 20 - targetY);
        if (distToM < 85) {
          const dmg = (equipped.power || 15) + 10;
          m.hp = Math.max(0, m.hp - dmg);
          sound.playMonsterGrowl();
          addParticles(m.x + 20, m.y + 20, "#9333EA", 12);
          addFloating(`💥 -${dmg} HP (দানব আহত!)`, m.x + 10, m.y - 20, "#EF4444");
          if (m.hp === 0) {
            sound.playTreeFall();
            addFloating("🏆 কচু খোর কুকুর পরাজিত হয়ে পালিয়েছে!", m.x, m.y - 35, "#FBBF24");
            m.state = "howl";
            m.speechBubble = "🐺 আহহহ! তোজো... আমি হার মেনে পাতালে ফিরছি!";
            m.bubbleTimer = 4;
            onCollectDrop({
              id: `drop_monster_${Date.now()}`,
              x: m.x,
              y: m.y,
              item: {
                id: "seed_taro_golden",
                name: "Legendary Cursed Taro Corm",
                bengaliName: "দানবীয় সোনালী কচু বীজ",
                type: "seed",
                description: "Rare prize dropped from the defeated Kochu Khor Kukur!",
                icon: "✨🥔",
                count: 3,
                value: 50,
              },
              lifespan: 9999,
            });
          }
        }
      }

      dogsRef.current.forEach((d) => {
        const distToDog = Math.hypot(d.x - p.x, d.y - p.y);
        const fearRadius =
          equipped.tier === 3 ? 320 : equipped.tier === 2 ? 260 : 200;

        if (distToDog < fearRadius && !d.isFriend) {
          sound.playDogWhimper();
          addFloating("🐕 ঘেউ! লাঠি দেখে পালাও!", d.x, d.y - 20, "#EF4444");
          d.state = "flee";
          d.fearLevel = 100;
          d.speechBubble = "লাঠি! পালাও রে!";
          d.bubbleTimer = 2.5;
          d.speed = 4.8;
        }
      });
    }

    // 2. AXE (Woodcutting & Heavy Strike)
    else if (equipped.id.includes("axe")) {
      sound.playAxeChop();
      p.isActing = true;
      p.actionTimer = 0.3;
      p.actionType = "chop";
      p.handAnim = 1.0;

      // Strike Monster Dog with Axe
      if (monsterRef.current) {
        const m = monsterRef.current;
        const distToM = Math.hypot(m.x + 20 - targetX, m.y + 20 - targetY);
        if (distToM < 85) {
          const dmg = equipped.power || 35;
          m.hp = Math.max(0, m.hp - dmg);
          sound.playMonsterGrowl();
          addParticles(m.x + 20, m.y + 20, "#DC2626", 14);
          addFloating(`🪓 -${dmg} HP (কুঠারের আঘাত!)`, m.x + 10, m.y - 20, "#EF4444");
          if (m.hp === 0) {
            sound.playTreeFall();
            addFloating("🏆 কচু খোর কুকুর পরাজিত!", m.x, m.y - 35, "#FBBF24");
            m.state = "howl";
            m.speechBubble = "🐺 আহহহ! কুঠারের আঘাত... পালাচ্ছি!";
            m.bubbleTimer = 4;
            onCollectDrop({
              id: `drop_monster_${Date.now()}`,
              x: m.x,
              y: m.y,
              item: {
                id: "seed_taro_golden",
                name: "Legendary Cursed Taro Corm",
                bengaliName: "দানবীয় সোনালী কচু বীজ",
                type: "seed",
                description: "Prize dropped from the defeated Kochu Khor Kukur!",
                icon: "✨🥔",
                count: 3,
                value: 50,
              },
              lifespan: 9999,
            });
          }
        }
      }

      dogsRef.current.forEach((d) => {
        const dist = Math.hypot(d.x - p.x, d.y - p.y);
        if (dist < 150 && !d.isFriend) {
          d.state = "flee";
          d.fearLevel = Math.min(100, d.fearLevel + 20);
          d.speechBubble = "কুঠারের শব্দ!";
          d.bubbleTimer = 1.5;
        }
      });

      treesRef.current.forEach((tree) => {
        if (tree.state !== "mature" && tree.state !== "growing") return;
        const dist = Math.hypot(tree.x + 16 - targetX, tree.y + 16 - targetY);
        if (dist < 55) {
          const damage = equipped.power || 25;
          const newHp = Math.max(0, tree.hp - damage);
          addParticles(tree.x + 16, tree.y + 16, "#8D6E63", 8);
          addFloating(`-${damage} HP`, tree.x + 16, tree.y - 10, "#F59E0B");

          if (newHp === 0) {
            sound.playTreeFall();
            onTreeCutCount();

            const seasonBonus =
              SEASONS_DATA[seasonRef.current]?.woodYieldBonus || 0;
            const baseCount =
              equipped.tier === 3 ? 4 : equipped.tier === 2 ? 3 : 2;
            const finalLogCount = baseCount + seasonBonus;

            addFloating(
              `🪵 +${finalLogCount} কাঠ সংগ্রহ!`,
              tree.x,
              tree.y - 25,
              "#10B981"
            );

            onCollectDrop({
              id: `drop_${Date.now()}`,
              x: tree.x,
              y: tree.y,
              item: {
                id: "wood_log",
                name: "Wood Log",
                bengaliName: "কাঠের গুঁড়ি",
                type: "resource",
                description: "Chipped wood from felled tree.",
                icon: "🪵",
                count: finalLogCount,
                value: 4,
              },
              lifespan: 9999,
            });

            tree.hp = 0;
            tree.state = "stump";
            tree.regrowthTimer = 0;
            onUpdateTrees(() => [...treesRef.current]);
          } else {
            tree.hp = newHp;
          }
        }
      });
    }

    // 3. HOE (Farming: Restricted to Campfire Safe Radius in Roblox 99 Nights style)
    else if (equipped.id.includes("hoe")) {
      // Check campfire line!
      if (!canBuildAt(targetX, targetY)) {
        return;
      }

      const tileC = Math.floor(targetX / TILE_SIZE);
      const tileR = Math.floor(targetY / TILE_SIZE);
      const key = `${tileC},${tileR}`;

      if (
        tileC >= 0 &&
        tileC < MAP_COLS &&
        tileR >= 0 &&
        tileR < MAP_ROWS &&
        tiles[tileR][tileC] !== "water" &&
        tiles[tileR][tileC] !== "fence"
      ) {
        sound.playTillSoil();
        p.isActing = true;
        p.actionTimer = 0.25;
        p.actionType = "till";
        p.handAnim = 1.0;
        addParticles(targetX, targetY, "#78350F", 6);

        if (!farmTilesRef.current.has(key)) {
          farmTilesRef.current.set(key, {
            x: tileC * TILE_SIZE,
            y: tileR * TILE_SIZE,
            isTilled: true,
            isWatered: weatherRef.current === "rain",
            waterLevel: weatherRef.current === "rain" ? 100 : 0,
            cropType: null,
            growthStage: 0,
            growthTimer: 0,
            growthRequired: 30,
          });
          addFloating("মাটি প্রস্তুত!", targetX, targetY - 10, "#D97706");
          onUpdateFarmTiles(() => new Map(farmTilesRef.current));
        }
      }
    }

    // 4. WATERING CAN
    else if (equipped.id.includes("water")) {
      const tileC = Math.floor(targetX / TILE_SIZE);
      const tileR = Math.floor(targetY / TILE_SIZE);
      const key = `${tileC},${tileR}`;

      sound.playWater();
      p.isActing = true;
      p.actionTimer = 0.25;
      p.actionType = "water";
      p.handAnim = 1.0;
      addParticles(targetX, targetY, "#60A5FA", 8);

      const tile = farmTilesRef.current.get(key);
      if (tile && tile.isTilled) {
        tile.isWatered = true;
        tile.waterLevel = 100;
        addFloating("💧 পানি সিঞ্চিত!", targetX, targetY - 10, "#3B82F6");
        onUpdateFarmTiles(() => new Map(farmTilesRef.current));
      }
    }

    // 5. SEEDS (Restricted to Campfire Safe Radius in Roblox 99 Nights style)
    else if (equipped.type === "seed") {
      if (!canBuildAt(targetX, targetY)) {
        return;
      }

      const tileC = Math.floor(targetX / TILE_SIZE);
      const tileR = Math.floor(targetY / TILE_SIZE);
      const key = `${tileC},${tileR}`;

      const cropMap: Record<string, "taro" | "paddy" | "eggplant"> = {
        seed_taro: "taro",
        seed_taro_golden: "taro",
        seed_paddy: "paddy",
        seed_eggplant: "eggplant",
      };

      const cropType = cropMap[equipped.id] || "taro";
      const tile = farmTilesRef.current.get(key);

      if (tile && tile.isTilled && !tile.cropType) {
        tile.cropType = cropType;
        tile.growthStage = 1;
        tile.growthTimer = 0;
        tile.growthRequired =
          cropType === "taro" ? 22 : cropType === "paddy" ? 16 : 26;

        sound.playTillSoil();
        addParticles(targetX, targetY, "#10B981", 6);
        addFloating(`🌱 ${equipped.name} বপন!`, targetX, targetY - 10, "#34D399");
        onUpdateFarmTiles(() => new Map(farmTilesRef.current));
      }
    }

    // 6. ROBLOX 99 NIGHTS: BASE BUILDING STRUCTURES
    else if (equipped.id === "structure_fence") {
      if (!canBuildAt(targetX, targetY)) return;
      sound.playAxeChop();
      addParticles(targetX, targetY, "#854D0E", 10);
      structuresRef.current.push({
        id: `fence_${Date.now()}`,
        type: "fence",
        name: "Camp Defense Fence",
        bengaliName: "কাঠের প্রাচীর",
        x: targetX,
        y: targetY,
        hp: 100,
        maxHp: 100,
      });
      addFloating("🪵🛡️ কাঠের বেড়া নির্মাণ সম্পন্ন!", targetX, targetY - 15, "#10B981");
      if (onUpdateStructures) onUpdateStructures(() => [...structuresRef.current]);
    } else if (equipped.id === "structure_torch") {
      if (!canBuildAt(targetX, targetY)) return;
      sound.playAxeChop();
      addParticles(targetX, targetY, "#F59E0B", 10);
      structuresRef.current.push({
        id: `torch_${Date.now()}`,
        type: "torch",
        name: "Night Torch Pole",
        bengaliName: "আলোর মশাল",
        x: targetX,
        y: targetY,
        hp: 100,
        maxHp: 100,
      });
      addFloating("🏮 মশাল স্থাপন সম্পন্ন!", targetX, targetY - 15, "#FBBF24");
      if (onUpdateStructures) onUpdateStructures(() => [...structuresRef.current]);
    } else if (equipped.id === "structure_dog_bed") {
      if (!canBuildAt(targetX, targetY)) return;
      sound.playHarvest();
      addParticles(targetX, targetY, "#FACC15", 10);
      structuresRef.current.push({
        id: `bed_${Date.now()}`,
        type: "dog_bed",
        name: "Cozy Canine Bed",
        bengaliName: "কুকুরের শোবার মাদুর",
        x: targetX,
        y: targetY,
        hp: 100,
        maxHp: 100,
      });
      addFloating("🛏️🐶 কুকুরের বিছানা পাতা হয়েছে!", targetX, targetY - 15, "#34D399");
      if (onUpdateStructures) onUpdateStructures(() => [...structuresRef.current]);
    }

    // 7. CAMPFIRE FUEL & UPGRADE (Roblox 99 Nights style)
    else if (equipped.id === "campfire_fuel") {
      const camp = campfireRef.current;
      const distToCamp = Math.hypot(p.x - camp.x, p.y - camp.y);
      if (distToCamp < 160) {
        sound.playHarvest();
        camp.radius = Math.min(camp.maxRadius, camp.radius + 35);
        camp.fuel = 100;
        camp.level += 1;
        addParticles(camp.x, camp.y, "#F59E0B", 20);
        addFloating("🔥 ক্যাম্পফায়ার বৃদ্ধি ও নিরাপদ সীমা বিস্তার! (+35px)", camp.x, camp.y - 30, "#FBBF24");
        if (onUpdateCampfire) onUpdateCampfire((c) => ({ ...c, radius: camp.radius, level: camp.level }));
      } else {
        addFloating("ক্যাম্পফায়ারের কাছে গিয়ে কাঠ দিন!", p.x, p.y - 15, "#F87171");
      }
    }

    // 8. DOG TREAT & MISSING DOG RESCUE
    else if (equipped.id === "dog_treat") {
      let fedAny = false;
      dogsRef.current.forEach((d) => {
        const distToDog = Math.hypot(d.x - p.x, d.y - p.y);
        if (distToDog < 220 && !fedAny) {
          fedAny = true;
          sound.playHarvest();
          sound.playDogHappyBark();
          onBefriendDog(d.id);
          addParticles(d.x + 16, d.y + 16, "#F59E0B", 10);

          if (d.isMissing && !d.rescued) {
            d.rescued = true;
            d.isMissing = false;
            addFloating(
              `🎉 ${d.bengaliName} উদ্ধার হয়েছে ও বন্ধু হলো!`,
              d.x,
              d.y - 20,
              "#34D399"
            );
          } else {
            addFloating(
              `🍖 ${d.bengaliName} শান্ত হলো ও বন্ধু হলো!`,
              d.x,
              d.y - 20,
              "#FBBF24"
            );
          }

          d.state = "eating";
          d.fearLevel = 0;
          d.loyalty = 100;
          d.speechBubble = "তোজো প্রিয় বন্ধু! লেজ নাড়ছে!";
          d.bubbleTimer = 5;
          d.isFriend = true;
          d.speed = 3.0;
          d.bellyRollTimer = 3;
        }
      });
      if (!fedAny) {
        addFloating("কাছের কোনো কুকুর নেই!", targetX, targetY - 10, "#F87171");
      }
    }
  }, [
    tiles,
    addParticles,
    addFloating,
    canBuildAt,
    onCollectDrop,
    onTreeCutCount,
    onBefriendDog,
    onUpdateFarmTiles,
    onUpdateTrees,
    onUpdateCampfire,
    onUpdateStructures,
  ]);

  const petFriendlyDog = useCallback(
    (targetDog?: Dog) => {
      const p = playerRef.current;
      dogsRef.current.forEach((d) => {
        const isTarget = targetDog
          ? d.id === targetDog.id
          : Math.hypot(d.x - p.x, d.y - p.y) < 100;
        if (isTarget) {
          sound.playDogPetLove();
          if (d.id === "dog_chotu") sound.playPuppyYip();
          else sound.playDogHappyBark();

          onBefriendDog(d.id);
          addParticles(d.x + 16, d.y + 16, "#EC4899", 10);
          addFloating(`❤️ ${d.bengaliName} আদর গ্রহণ করলো!`, d.x, d.y - 25, "#F43F5E");
          d.state = "pet";
          d.fearLevel = 0;
          d.loyalty = Math.min(100, d.loyalty + 25);
          d.isFriend = true;
          d.bellyRollTimer = 3.5;
          d.speechBubble = "ঘেউ! তোজো আমার সেরা বন্ধু!";
          d.bubbleTimer = 4;
        }
      });
    },
    [onBefriendDog, addParticles, addFloating]
  );

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const worldX = mouseX + cameraRef.current.x;
    const worldY = mouseY + cameraRef.current.y;

    // Check click on Permanent Developer Mustakim Shop
    const dockX = 30 * TILE_SIZE;
    const dockY = 14 * TILE_SIZE;
    const distToShop = Math.hypot(worldX - (dockX + 24), worldY - (dockY + 24));
    if (distToShop < 85) {
      sound.playMustakimBell();
      onOpenShop();
      return;
    }

    let clickedSign = false;
    landPlotsRef.current.forEach((plot) => {
      if (!plot.isUnlocked) {
        const signX = plot.signCol * TILE_SIZE;
        const signY = plot.signRow * TILE_SIZE;
        const dist = Math.hypot(worldX - (signX + 24), worldY - (signY + 24));
        if (dist < 60) {
          clickedSign = true;
          onBuyLand(plot);
        }
      }
    });
    if (clickedSign) return;

    let clickedDog: Dog | null = null;
    dogsRef.current.forEach((d) => {
      const dist = Math.hypot(worldX - (d.x + 16), worldY - (d.y + 16));
      if (dist < 45) {
        clickedDog = d;
      }
    });

    if (clickedDog) {
      if (!isHoldingThreateningWeapon()) {
        petFriendlyDog(clickedDog);
        return;
      }
    }

    const tileC = Math.floor(worldX / TILE_SIZE);
    const tileR = Math.floor(worldY / TILE_SIZE);
    const key = `${tileC},${tileR}`;
    const farmTile = farmTilesRef.current.get(key);

    if (farmTile && farmTile.growthStage >= 4 && farmTile.cropType) {
      sound.playHarvest();
      const cropName =
        farmTile.cropType === "taro"
          ? "কচু (Colocasia)"
          : farmTile.cropType === "paddy"
          ? "ধান (Rice)"
          : "বেগুন (Eggplant)";

      addFloating(`✨ ফসল সংগ্রহ: ${cropName}!`, farmTile.x + 16, farmTile.y - 15, "#FBBF24");
      addParticles(farmTile.x + 24, farmTile.y + 24, "#F59E0B", 10);

      onCollectDrop({
        id: `harvest_${Date.now()}`,
        x: farmTile.x,
        y: farmTile.y,
        item: {
          id: `crop_${farmTile.cropType}`,
          name: `Harvested ${farmTile.cropType.toUpperCase()}`,
          bengaliName: cropName,
          type: "crop",
          description: "Freshly harvested organic village crop.",
          icon:
            farmTile.cropType === "taro"
              ? "🥔"
              : farmTile.cropType === "paddy"
              ? "🌾"
              : "🍆",
          count: 3,
          value: farmTile.cropType === "taro" ? 18 : 12,
        },
        lifespan: 9999,
      });

      farmTilesRef.current.set(key, {
        ...farmTile,
        cropType: null,
        growthStage: 0,
        growthTimer: 0,
        isWatered: weatherRef.current === "rain",
        waterLevel: weatherRef.current === "rain" ? 100 : 0,
      });
      onUpdateFarmTiles(() => new Map(farmTilesRef.current));
      return;
    }

    performAction();
  };

  // =========================================================================
  // MAIN 60FPS LOCKED RUNTIME ENGINE (REQUEST ANIMATION FRAME)
  // =========================================================================
  useEffect(() => {
    let animId: number;

    const gameLoop = (currentTime: number) => {
      // Delta time clamped between 1/120 and 1/20 to prevent physics glitch
      const rawDt = (currentTime - lastTimeRef.current) / 1000;
      const dt = Math.max(0.008, Math.min(rawDt, 0.05));
      lastTimeRef.current = currentTime;

      // 60 FPS Rolling Calculation
      fpsFrameCountRef.current++;
      if (currentTime - fpsLastTimeRef.current >= 400) {
        const computedFps = Math.round(
          (fpsFrameCountRef.current * 1000) / (currentTime - fpsLastTimeRef.current)
        );
        fpsRef.current = Math.min(60, Math.max(30, computedFps));
        fpsFrameCountRef.current = 0;
        fpsLastTimeRef.current = currentTime;
        if (onFpsUpdate) onFpsUpdate(fpsRef.current);
      }

      const p = playerRef.current;
      const currentWeather = weatherRef.current;
      const currentSeason = seasonRef.current;

      // 1. CRITTERS
      crittersRef.current.forEach((critter) => {
        critter.x += critter.vx;
        critter.y += critter.vy;
        if (Math.random() < 0.03) {
          critter.vx += (Math.random() - 0.5) * 0.4;
          critter.vy += (Math.random() - 0.5) * 0.4;
          critter.vx = Math.max(-1.5, Math.min(1.5, critter.vx));
          critter.vy = Math.max(-1.5, Math.min(1.5, critter.vy));
        }
        if (critter.x < 0) critter.x = WORLD_WIDTH;
        if (critter.x > WORLD_WIDTH) critter.x = 0;
        if (critter.y < 0) critter.y = WORLD_HEIGHT;
        if (critter.y > WORLD_HEIGHT) critter.y = 0;
      });

      // 2. WEATHER
      if (currentWeather === "rain") {
        rainDropsRef.current.forEach((r) => {
          r.y += r.speed;
          r.x += 1.6;
          if (r.y > (canvasRef.current?.height || 600)) {
            r.y = -20;
            r.x = Math.random() * (canvasRef.current?.width || 800);
          }
        });
      } else if (currentWeather === "fog") {
        fogOffsetsRef.current = fogOffsetsRef.current.map(
          (offset) => (offset + dt * 15) % 800
        );
      }

      // 3. JUMP PHYSICS (Parabolic vertical arc)
      if (p.isJumping) {
        p.z += p.vz * dt;
        p.vz -= 380 * dt; // Gravity
        if (p.z <= 0) {
          p.z = 0;
          p.vz = 0;
          p.isJumping = false;
          sound.playLand();
          addParticles(p.x + 16, p.y + 36, "#94A3B8", 5);
        }
      }

      // 4. PLAYER MOVEMENT & SPRINT
      let moveX = 0;
      let moveY = 0;
      const keys = keysPressed.current;

      if (keys["w"] || keys["arrowup"]) moveY -= 1;
      if (keys["s"] || keys["arrowdown"]) moveY += 1;
      if (keys["a"] || keys["arrowleft"]) moveX -= 1;
      if (keys["d"] || keys["arrowright"]) moveX += 1;

      const isMoving = moveX !== 0 || moveY !== 0;
      if (moveX > 0) p.facing = "right";
      else if (moveX < 0) p.facing = "left";
      else if (moveY > 0) p.facing = "down";
      else if (moveY < 0) p.facing = "up";

      // STAMINA DRAIN & AUTO-RECHARGE MECHANICS (User feature: "when I run the stamina runs out and recharge auto")
      if (p.isSprinting && isMoving) {
        p.stamina = Math.max(0, (p.stamina ?? 100) - 26 * dt);
        if (p.stamina <= 0) {
          p.isSprinting = false;
          p.isExhausted = true;
          addParticles(p.x + 16, p.y + 16, "#94A3B8", 4);
          addFloating("💨 স্ট্যামিনা শেষ! দম নিচ্ছে...", p.x, p.y - 15, "#F87171");
        }
      } else {
        const rechargeSpeed = isMoving ? 20 : 34;
        p.stamina = Math.min(p.maxStamina || 100, (p.stamina ?? 100) + rechargeSpeed * dt);
        if (p.isExhausted && p.stamina > 22) {
          p.isExhausted = false;
        }
      }

      // ZONE DETECTION (Roblox 99 Nights Campfire Safe Zone vs Deep Kochubon)
      const inDeep =
        p.x >= DEEP_KOCHUBON_MIN_COL * TILE_SIZE ||
        (p.y <= 6 * TILE_SIZE && p.x >= 28 * TILE_SIZE) ||
        (p.y >= 30 * TILE_SIZE && p.x >= 28 * TILE_SIZE);
      const inCamp =
        Math.hypot(p.x - campfireRef.current.x, p.y - campfireRef.current.y) <=
        campfireRef.current.radius;

      // ENTERING DEEP KOCHUBON TEXT POPUP (User feature: "when we go to Deep kouchubon there name text pop up entering kouchbon")
      if (inDeep && !wasInDeepKochubonRef.current) {
        deepTextBannerRef.current = {
          title: "🌲🐾 গভীর কচুবনে প্রবেশ করছেন (Entering Deep Kochubon)",
          subtitle: "⚠️ সাবধান! রাতের বেলা রহস্যময় কচু খোর কুকুর ও ৩টি হারিয়ে যাওয়া কুকুরদের রাজ্য!",
          timer: 4.8,
          alpha: 1.0,
        };
        sound.playDeepForestEnter();
      }
      wasInDeepKochubonRef.current = inDeep;
      if (onZoneChange) onZoneChange(inDeep, inCamp);

      // Banner & warning ring timers
      if (deepTextBannerRef.current) {
        deepTextBannerRef.current.timer -= dt;
        if (deepTextBannerRef.current.timer <= 0) {
          deepTextBannerRef.current = null;
        }
      }
      if (campfireWarningRingRef.current > 0) {
        campfireWarningRingRef.current = Math.max(0, campfireWarningRingRef.current - dt);
      }

      const sprintSpeedMult = p.isSprinting ? 1.7 : 1.0;
      const weatherSpeedMod =
        currentWeather === "rain" ? 0.88 : currentWeather === "fog" ? 0.92 : 1.0;

      if (isMoving) {
        walkCycleRef.current += dt * (p.isSprinting ? 18 : 10);
        p.walkFrame = walkCycleRef.current;
        p.isMoving = true;

        const length = Math.hypot(moveX, moveY);
        const normX = moveX / length;
        const normY = moveY / length;
        const effectiveSpeed = p.speed * sprintSpeedMult * weatherSpeedMod;

        let nextX = p.x + normX * effectiveSpeed;
        let nextY = p.y + normY * effectiveSpeed;

        nextX = Math.max(20, Math.min(WORLD_WIDTH - 50, nextX));
        nextY = Math.max(20, Math.min(WORLD_HEIGHT - 60, nextY));

        const canLeapObstacle = p.isJumping && p.z > 8;
        const targetTileC = Math.floor((nextX + 16) / TILE_SIZE);
        const targetTileR = Math.floor((nextY + 32) / TILE_SIZE);

        if (
          targetTileR >= 0 &&
          targetTileR < MAP_ROWS &&
          targetTileC >= 0 &&
          targetTileC < MAP_COLS
        ) {
          const tileType = tiles[targetTileR][targetTileC];
          if (canLeapObstacle || (tileType !== "water" && tileType !== "fence")) {
            if (p.isSprinting && Math.random() < 0.4) {
              addParticles(p.x + 16, p.y + 36, "#E2E8F0", 2);
            } else if (!p.isSprinting && Math.abs(Math.sin(p.walkFrame)) > 0.85 && Math.random() < 0.25) {
              addParticles(p.x + 16, p.y + 36, "#CBD5E1", 1);
            }
            p.x = nextX;
            p.y = nextY;
          }
        }
      } else {
        p.isMoving = false;
      }

      // Recover action timers
      if (p.actionTimer > 0) {
        p.actionTimer = Math.max(0, p.actionTimer - dt);
        p.isActing = p.actionTimer > 0;
        p.handAnim = Math.max(0, (p.handAnim || 0) - dt * 4);
      }

      // Pick up ground drops
      dropsRef.current.forEach((drop, idx) => {
        const dist = Math.hypot(drop.x - p.x, drop.y - p.y);
        if (dist < 36) {
          sound.playCoin();
          addFloating(
            `+${drop.item.count} ${drop.item.bengaliName}`,
            drop.x,
            drop.y - 15,
            "#34D399"
          );
          onCollectDrop(drop);
          dropsRef.current.splice(idx, 1);
        }
      });

      // 5. ENHANCED LIFELIKE CANINE AI (DOGS SYSTEM with SIT & MISSING DOGS)
      const playerArmed = isHoldingThreateningWeapon() || p.isActing;
      const isHoldingBareHand =
        hotbarRef.current[activeSlotRef.current]?.id === "hand_empty";
      let isNearAnyDog = false;

      dogsRef.current.forEach((d) => {
        const distToPlayer = Math.hypot(d.x - p.x, d.y - p.y);
        if (distToPlayer < 90 && !playerArmed) isNearAnyDog = true;

        d.bubbleTimer = Math.max(0, d.bubbleTimer - dt);
        d.bellyRollTimer = Math.max(0, d.bellyRollTimer - dt);
        d.digTimer += dt;
        if (d.bubbleTimer === 0) d.speechBubble = null;

        // Tail wagging physics
        d.tailWagSpeed =
          d.isFriend || isHoldingBareHand ? 10.0 : d.state === "flee" ? 2.0 : 4.0;

        // Puppy vertical bounce for Chotu
        if (d.id === "dog_chotu" && (d.state === "curious" || d.state === "follow")) {
          d.z = Math.abs(Math.sin(Date.now() / 140)) * 6;
        } else {
          d.z = 0;
        }

        // 5.1 SITTING STATE (Dog Sits Peacefully When Commanded)
        if (d.state === "sitting" || d.isSitting) {
          d.speed = 0;
          d.tailWagSpeed = 6.0;
          return;
        }

        // 5.2 MISSING DOGS IN DEEP KOCHUBON (Black, White, Yellow Dog)
        if (d.isMissing && !d.rescued) {
          if (!d.speechBubble && Math.random() < 0.03) {
            d.speechBubble =
              d.furType === "white"
                ? "🆘 সাদা কুকুর ভয় পাচ্ছে! উদ্ধার করো!"
                : d.furType === "yellow"
                ? "🆘 তোজো ভাই! আমাকে ক্যাম্পফায়ারে নিয়ে চলো!"
                : "🆘 আমি গভীর কচুবনে হারিয়ে গেছি! বাঁচাও!";
            d.bubbleTimer = 3.5;
          }
          // If Tojo comes close with bare hand, automatically rescue!
          if (distToPlayer < 75 && isHoldingBareHand) {
            d.rescued = true;
            d.isMissing = false;
            d.isFriend = true;
            d.state = "follow";
            d.loyalty = 100;
            d.fearLevel = 0;
            d.speechBubble = "🎉 উদ্ধার পেয়েছি! তোজো ভাইয়ের সঙ্গে ক্যাম্পফায়ারে যাবো! ❤️";
            d.bubbleTimer = 4.5;
            sound.playDogHappyBark();
            addParticles(d.x + 16, d.y + 16, "#F59E0B", 15);
            addFloating(`🎉 ${d.bengaliName} উদ্ধার হয়েছে!`, d.x, d.y - 25, "#34D399");
            onBefriendDog(d.id);
          }
        }

        // TREASURE DIGGING AI (Companion Dogs hunt buried treats)
        if (d.isFriend && d.digTimer > 25 && Math.random() < 0.006) {
          d.state = "digging";
          d.digTimer = 0;
          sound.playDogDig();
          addParticles(d.x + 16, d.y + 16, "#78350F", 12);
          d.speechBubble = "🐶 মাটিতে কিছু একটা গন্ধ পাচ্ছি! ঘেউ!";
          d.bubbleTimer = 4.0;

          const prizeItem: Item =
            Math.random() > 0.4
              ? {
                  id: "dog_gift_coin",
                  name: "Buried Village Coin",
                  bengaliName: "মাটির নিচে লুকানো রূপালী মুদ্রা",
                  type: "resource",
                  description: "Dug up by your loyal companion dog!",
                  icon: "🪙",
                  count: 15,
                  value: 15,
                }
              : {
                  id: "seed_taro_golden",
                  name: "Wild Golden Taro Corm",
                  bengaliName: "বুনো সোনালী কচুর চারা",
                  type: "seed",
                  description: "Rare aromatic taro discovered by the black dog.",
                  icon: "✨🌱",
                  count: 2,
                  value: 25,
                };

          onCollectDrop({
            id: `dug_treasure_${Date.now()}`,
            x: d.x + 12,
            y: d.y + 12,
            item: prizeItem,
            lifespan: 9999,
          });
          addFloating("✨ কুকুরের উপহার!", d.x, d.y - 25, "#FBBF24");
        }

        // FLEE AI (Armed Player)
        if (playerArmed && !d.isFriend) {
          d.fearLevel = Math.min(100, d.fearLevel + 40 * dt);
          if (distToPlayer < 240) {
            d.state = "flee";
            const awayX = d.x - p.x;
            const awayY = d.y - p.y;
            const mag = Math.hypot(awayX, awayY) || 1;
            d.x += (awayX / mag) * (d.speed * 1.35);
            d.y += (awayY / mag) * (d.speed * 1.35);
            d.facing = awayX > 0 ? "right" : "left";

            if (!d.speechBubble && Math.random() < 0.04) {
              d.speechBubble = "লাঠি! পালাও রে!";
              d.bubbleTimer = 2.0;
            }
          }
        }
        // FRIENDLY / CURIOUS / BARE HAND AI
        else {
          d.fearLevel = isHoldingBareHand ? 0 : Math.max(0, d.fearLevel - 25 * dt);

          if (d.bellyRollTimer > 0) {
            d.state = "pet";
          } else if (isHoldingBareHand && distToPlayer < 240) {
            if (distToPlayer > 42) {
              d.state = "curious";
              const toX = p.x - d.x;
              const toY = p.y - d.y;
              const mag = Math.hypot(toX, toY) || 1;

              d.x += (toX / mag) * (d.speed * 1.1);
              d.y += (toY / mag) * (d.speed * 1.1);
              d.facing = toX > 0 ? "right" : "left";

              if (!d.speechBubble && Math.random() < 0.04) {
                d.speechBubble = "তোজোর খালি হাত! 🐾 কোনো লাঠি নেই!";
                d.bubbleTimer = 2.5;
              }
            } else {
              d.state = "sitting";
              if (d.bellyRollTimer <= 0 && Math.random() < 0.05) {
                d.bellyRollTimer = 3.5;
                d.speechBubble = "ঘেউ! লেজ নাড়ছি! পেট চুলকে দাও! ❤️";
                d.bubbleTimer = 3.5;
              }
            }
          } else if (d.isFriend || (d.fearLevel < 40 && distToPlayer < 190)) {
            if (distToPlayer > 40) {
              d.state = d.isFriend ? "follow" : "curious";
              const toX = p.x - d.x;
              const toY = p.y - d.y;
              const mag = Math.hypot(toX, toY) || 1;

              d.x += (toX / mag) * (d.speed * 0.85);
              d.y += (toY / mag) * (d.speed * 0.85);
              d.facing = toX > 0 ? "right" : "left";

              if (!d.speechBubble && Math.random() < 0.02) {
                d.speechBubble = d.isFriend
                  ? "🐶 লেজ নাড়ছে! সঙ্গে আছি!"
                  : "তোজো বন্ধু! আদর দিন!";
                d.bubbleTimer = 3.0;
              }
            } else {
              d.state = "sitting";
            }
          } else {
            let wanderTimer = d.wanderTimer - dt;
            if (wanderTimer <= 0) {
              wanderTimer = 2 + Math.random() * 4;
              d.targetX = d.x + (Math.random() - 0.5) * 120;
              d.targetY = d.y + (Math.random() - 0.5) * 120;
            }
            d.wanderTimer = wanderTimer;
            const dx = d.targetX - d.x;
            const dy = d.targetY - d.y;
            const distToTarget = Math.hypot(dx, dy);
            if (distToTarget > 5) {
              d.x += (dx / distToTarget) * (d.speed * 0.4);
              d.y += (dy / distToTarget) * (d.speed * 0.4);
              d.facing = dx > 0 ? "right" : "left";
            }
          }
        }

        d.x = Math.max(50, Math.min(WORLD_WIDTH - 80, d.x));
        d.y = Math.max(50, Math.min(WORLD_HEIGHT - 80, d.y));
      });

      // 5.5 NIGHT MONSTER DOG AI: KOCHU KHOR KUKUR (কচু খোর কুকুর) in Deep Kochubon
      const isNightTime = dayTimeRef.current > 0.65 && dayTimeRef.current < 0.95;
      if (monsterRef.current) {
        const m = monsterRef.current;
        m.bubbleTimer = Math.max(0, m.bubbleTimer - dt);
        m.attackCooldown = Math.max(0, m.attackCooldown - dt);
        m.growlTimer = Math.max(0, m.growlTimer - dt);
        if (m.bubbleTimer <= 0) m.speechBubble = null;

        if (isNightTime && m.hp > 0) {
          const camp = campfireRef.current;
          const distToCamp = Math.hypot(m.x - camp.x, m.y - camp.y);
          const distToP = Math.hypot(m.x - p.x, m.y - p.y);

          // ROBLOX 99 NIGHTS RULE: MONSTER CANNOT CROSS CAMPFIRE LIGHT LINE!
          if (distToCamp < camp.radius + 35) {
            m.state = "flee_fire";
            const awayX = m.x - camp.x;
            const awayY = m.y - camp.y;
            const mag = Math.hypot(awayX, awayY) || 1;
            m.x += (awayX / mag) * (m.speed * 1.5);
            m.y += (awayY / mag) * (m.speed * 1.5);
            m.facing = awayX > 0 ? "right" : "left";
            if (!m.speechBubble && Math.random() < 0.05) {
              m.speechBubble = "🔥 ক্যাম্পফায়ারের আগুন! পুড়ে যাবো!";
              m.bubbleTimer = 2.5;
            }
          }
          // If Tojo is outside campfire, monster stalks or attacks!
          else if (distToP < 340) {
            m.state = distToP < 55 ? "attack" : "stalk";
            const toX = p.x - m.x;
            const toY = p.y - m.y;
            const mag = Math.hypot(toX, toY) || 1;
            m.x += (toX / mag) * (m.speed * 1.15);
            m.y += (toY / mag) * (m.speed * 1.15);
            m.facing = toX > 0 ? "right" : "left";

            if (distToP < 50 && m.attackCooldown <= 0) {
              m.attackCooldown = 1.3;
              p.hp = Math.max(10, p.hp - 8);
              sound.playMonsterGrowl();
              addParticles(p.x + 16, p.y + 16, "#991B1B", 8);
              addFloating("🩸 -8 HP (কচু খোর কুকুরের নখ!)", p.x, p.y - 25, "#EF4444");
              m.speechBubble = "🐺 কচুর রক্ত ও শক্তি আমার!";
              m.bubbleTimer = 2.0;
            } else if (m.growlTimer <= 0) {
              m.growlTimer = 4.5;
              sound.playMonsterGrowl();
              m.speechBubble = "🐺 গ্রররর! গভীর কচুবনের দানব!";
              m.bubbleTimer = 3.0;
            }
          } else {
            // Roam the deep arum shadows
            m.state = "roam";
            if (Math.random() < 0.02) {
              m.targetX = (DEEP_KOCHUBON_MIN_COL + Math.random() * 16) * TILE_SIZE;
              m.targetY = (6 + Math.random() * 22) * TILE_SIZE;
            }
            const dx = m.targetX - m.x;
            const dy = m.targetY - m.y;
            const dist = Math.hypot(dx, dy);
            if (dist > 10) {
              m.x += (dx / dist) * (m.speed * 0.6);
              m.y += (dy / dist) * (m.speed * 0.6);
              m.facing = dx > 0 ? "right" : "left";
            }
          }
        }
      }

      // 6. TREES REGROWTH
      treesRef.current.forEach((tree) => {
        if (tree.state === "stump") {
          tree.regrowthTimer += dt;
          if (tree.regrowthTimer >= tree.maxRegrowthTime) {
            tree.state = "sapling";
            tree.hp = 20;
            tree.regrowthTimer = 0;
          }
        } else if (tree.state === "sapling") {
          tree.regrowthTimer += dt;
          if (tree.regrowthTimer >= 20) {
            tree.state = "mature";
            tree.hp = tree.maxHp;
            tree.regrowthTimer = 0;
          }
        }
      });

      // 7. CROPS GROWTH
      const seasonGrowthMultiplier =
        SEASONS_DATA[currentSeason]?.cropGrowthMultiplier || 1.0;
      farmTilesRef.current.forEach((tile) => {
        if (currentWeather === "rain" && !tile.isWatered) {
          tile.isWatered = true;
          tile.waterLevel = 100;
        }
        if (tile.cropType && tile.growthStage < 4) {
          const waterBonus = tile.isWatered ? 2.0 : 0.8;
          const growthRate = dt * waterBonus * seasonGrowthMultiplier;
          tile.growthTimer += growthRate;
          const threshold = tile.growthRequired / 3;
          if (tile.growthTimer >= threshold * 3) tile.growthStage = 4;
          else if (tile.growthTimer >= threshold * 2) tile.growthStage = 3;
          else if (tile.growthTimer >= threshold) tile.growthStage = 2;
        }
      });

      // 8. PARTICLES & FLOATING TEXT
      particlesRef.current.forEach((part) => {
        part.x += part.vx;
        part.y += part.vy;
        part.life += dt;
        part.alpha = Math.max(0, 1 - part.life / part.maxLife);
      });
      particlesRef.current = particlesRef.current.filter(
        (part) => part.life < part.maxLife
      );

      floatingTextsRef.current.forEach((ft) => {
        ft.y += ft.vy;
        ft.alpha = Math.max(0, ft.alpha - dt * 0.8);
      });
      floatingTextsRef.current = floatingTextsRef.current.filter(
        (ft) => ft.alpha > 0
      );

      // Throttled sync to React (every 120ms) to keep main UI smooth without React re-rendering thrash
      if (currentTime - lastSyncTimeRef.current >= 120) {
        lastSyncTimeRef.current = currentTime;
        if (onNearDogChange) onNearDogChange(isNearAnyDog);
        onUpdatePlayer((prev) => ({
          ...prev,
          x: p.x,
          y: p.y,
          z: p.z,
          vz: p.vz,
          hp: p.hp,
          stamina: p.stamina,
          isExhausted: p.isExhausted,
          isJumping: p.isJumping,
          isSprinting: p.isSprinting,
          facing: p.facing,
          walkFrame: p.walkFrame,
        }));
      }

      // 9. RENDER CANVAS AT ROCK-SOLID 60 FPS
      renderCanvas();

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [tiles, onCollectDrop, onNearDogChange, onFpsUpdate, onUpdatePlayer]);

  // Main Render Canvas
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const viewW = canvas.width;
    const viewH = canvas.height;
    const p = playerRef.current;
    const currentWeather = weatherRef.current;
    const currentSeason = seasonRef.current;
    const isHoldingBareHand =
      hotbarRef.current[activeSlotRef.current]?.id === "hand_empty";

    // Camera tracks Tojo smoothly
    const targetCamX = Math.max(
      0,
      Math.min(WORLD_WIDTH - viewW, p.x - viewW / 2)
    );
    const targetCamY = Math.max(
      0,
      Math.min(WORLD_HEIGHT - viewH, p.y - viewH / 2)
    );
    cameraRef.current.x += (targetCamX - cameraRef.current.x) * 0.16;
    cameraRef.current.y += (targetCamY - cameraRef.current.y) * 0.16;
    const camX = cameraRef.current.x;
    const camY = cameraRef.current.y;

    ctx.clearRect(0, 0, viewW, viewH);

    // Camera Transform
    ctx.save();
    ctx.translate(-Math.round(camX), -Math.round(camY));

    // 1. TILE GRID
    const startCol = Math.max(0, Math.floor(camX / TILE_SIZE));
    const endCol = Math.min(MAP_COLS, Math.ceil((camX + viewW) / TILE_SIZE) + 1);
    const startRow = Math.max(0, Math.floor(camY / TILE_SIZE));
    const endRow = Math.min(MAP_ROWS, Math.ceil((camY + viewH) / TILE_SIZE) + 1);

    for (let r = startRow; r < endRow; r++) {
      for (let c = startCol; c < endCol; c++) {
        const tile = tiles[r][c];
        const tx = c * TILE_SIZE;
        const ty = r * TILE_SIZE;

        if (tile === "water") {
          ctx.fillStyle = "#1E40AF";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "#3B82F6";
          const wave = Math.sin(Date.now() / 320 + c * 0.8 + r * 0.5) * 4;
          ctx.fillRect(tx + 6, ty + 18 + wave, 28, 4);
        } else if (tile === "bridge") {
          ctx.fillStyle = "#78350F";
          ctx.fillRect(tx, ty + 6, TILE_SIZE, TILE_SIZE - 12);
          ctx.fillStyle = "#92400E";
          ctx.fillRect(tx + 4, ty + 8, TILE_SIZE - 8, 4);
          ctx.fillRect(tx + 4, ty + 24, TILE_SIZE - 8, 4);
        } else if (tile === "dirt_path") {
          ctx.fillStyle = "#A16207";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "#854D0E";
          ctx.fillRect(tx + 6, ty + 12, 6, 6);
        } else if (tile === "taro_patch") {
          ctx.fillStyle = "#166534";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "#15803D";
          ctx.beginPath();
          ctx.ellipse(tx + 24, ty + 24, 18, 12, 0, 0, Math.PI * 2);
          ctx.fill();
        } else if (tile === "shop_dock") {
          ctx.fillStyle = "#92400E";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "#B45309";
          ctx.fillRect(tx + 2, ty + 2, TILE_SIZE - 4, TILE_SIZE - 4);
        } else if (tile === "fence") {
          ctx.fillStyle = "#334155";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "#64748B";
          ctx.fillRect(tx + 4, ty + 14, TILE_SIZE - 8, 6);
          ctx.fillRect(tx + 18, ty + 4, 8, TILE_SIZE - 8);
        } else {
          // Lush grass with season tint
          ctx.fillStyle =
            currentSeason === "spring"
              ? "#15803D"
              : currentSeason === "summer"
              ? "#166534"
              : currentSeason === "monsoon"
              ? "#14532D"
              : "#3F6212";
          ctx.fillRect(tx, ty, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = "rgba(255, 255, 255, 0.05)";
          ctx.fillRect(tx + 4, ty + 4, 8, 4);
        }
      }
    }

    // =========================================================================
    // 1.5 ROBLOX 99 NIGHTS CAMPFIRE SAFE/BUILDING ZONE (WARM GLOW & PERIMETER)
    // =========================================================================
    const camp = campfireRef.current;
    if (camp) {
      // 1. Warm radial illumination gradient
      const glowGrad = ctx.createRadialGradient(
        camp.x,
        camp.y,
        15,
        camp.x,
        camp.y,
        camp.radius
      );
      glowGrad.addColorStop(0, "rgba(251, 146, 60, 0.35)");
      glowGrad.addColorStop(0.5, "rgba(245, 158, 11, 0.18)");
      glowGrad.addColorStop(0.85, "rgba(217, 119, 6, 0.08)");
      glowGrad.addColorStop(1, "rgba(180, 83, 9, 0)");
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(camp.x, camp.y, camp.radius, 0, Math.PI * 2);
      ctx.fill();

      // 2. Roblox 99 Nights Campfire Boundary Line (Inside = build safe; Outside = restricted)
      ctx.save();
      const isWarning = campfireWarningRingRef.current > 0;
      ctx.strokeStyle = isWarning
        ? "rgba(239, 68, 68, 0.95)"
        : "rgba(251, 191, 36, 0.8)";
      ctx.lineWidth = isWarning ? 4 : 2.5;
      ctx.setLineDash(isWarning ? [10, 6] : [8, 8]);
      ctx.lineDashOffset = -Date.now() / 60;
      ctx.beginPath();
      ctx.arc(camp.x, camp.y, camp.radius, 0, Math.PI * 2);
      ctx.stroke();

      // Flashing alert along ring if build outside boundary denied
      if (isWarning) {
        ctx.fillStyle = "rgba(239, 68, 68, 0.14)";
        ctx.beginPath();
        ctx.arc(camp.x, camp.y, camp.radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#EF4444";
        ctx.font = "bold 12px 'Hind Siliguri', sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(
          "⚠️ ক্যাম্পফায়ারের সীমার বাইরে নির্মাণ নিষেধ! (Cannot build outside campfire line!)",
          camp.x,
          camp.y - camp.radius - 12
        );
        ctx.textAlign = "start";
      }
      ctx.restore();

      // 3. Campfire Hearth Stones & Fire Animation
      for (let i = 0; i < 8; i++) {
        const ang = (i / 8) * Math.PI * 2;
        const sx = camp.x + Math.cos(ang) * 22;
        const sy = camp.y + Math.sin(ang) * 16;
        ctx.fillStyle = "#475569";
        ctx.beginPath();
        ctx.ellipse(sx, sy, 7, 5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#64748B";
        ctx.beginPath();
        ctx.ellipse(sx - 1, sy - 1, 4, 3, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Wooden logs arranged in cross
      ctx.fillStyle = "#78350F";
      ctx.fillRect(camp.x - 16, camp.y - 4, 32, 8);
      ctx.fillRect(camp.x - 4, camp.y - 14, 8, 28);
      ctx.fillStyle = "#92400E";
      ctx.fillRect(camp.x - 12, camp.y - 2, 24, 4);

      // Multi-layer Flickering Flame
      const flicker1 = Math.sin(Date.now() / 70) * 4;
      const flicker2 = Math.cos(Date.now() / 90) * 3;
      // Outer Red
      ctx.fillStyle = "#DC2626";
      ctx.beginPath();
      ctx.moveTo(camp.x - 14, camp.y + 4);
      ctx.quadraticCurveTo(camp.x - 16 + flicker1, camp.y - 18, camp.x + flicker2, camp.y - 34);
      ctx.quadraticCurveTo(camp.x + 16 + flicker1, camp.y - 18, camp.x + 14, camp.y + 4);
      ctx.fill();
      // Mid Orange
      ctx.fillStyle = "#F97316";
      ctx.beginPath();
      ctx.moveTo(camp.x - 10, camp.y + 3);
      ctx.quadraticCurveTo(camp.x - 10 + flicker2, camp.y - 12, camp.x + flicker1 * 0.5, camp.y - 26);
      ctx.quadraticCurveTo(camp.x + 10 + flicker2, camp.y - 12, camp.x + 10, camp.y + 3);
      ctx.fill();
      // Core Yellow-White
      ctx.fillStyle = "#FEF08A";
      ctx.beginPath();
      ctx.moveTo(camp.x - 6, camp.y + 2);
      ctx.quadraticCurveTo(camp.x - 4, camp.y - 8, camp.x, camp.y - 18);
      ctx.quadraticCurveTo(camp.x + 4, camp.y - 8, camp.x + 6, camp.y + 2);
      ctx.fill();

      // Campfire Badge / Fuel status
      ctx.fillStyle = "rgba(0,0,0,0.78)";
      ctx.roundRect?.(camp.x - 52, camp.y + 24, 104, 18, 5);
      ctx.fill();
      ctx.fillStyle = "#FBBF24";
      ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
      ctx.fillText(`🔥 ক্যাম্পফায়ার Lv.${camp.level} (নিরাপদ বলয়)`, camp.x - 46, camp.y + 36);
    }

    // =========================================================================
    // 1.8 PLACED STRUCTURES (ROBLOX 99 NIGHTS BASE BUILDINGS)
    // =========================================================================
    structuresRef.current.forEach((st) => {
      const sx = st.x;
      const sy = st.y;

      if (st.type === "fence") {
        // Wooden Defense Palisade
        ctx.fillStyle = "#5C3D2E";
        ctx.fillRect(sx - 16, sy - 14, 32, 28);
        ctx.fillStyle = "#78350F";
        ctx.fillRect(sx - 14, sy - 12, 8, 24);
        ctx.fillRect(sx + 6, sy - 12, 8, 24);
        // Pointed top stakes
        ctx.beginPath();
        ctx.moveTo(sx - 14, sy - 12);
        ctx.lineTo(sx - 10, sy - 22);
        ctx.lineTo(sx - 6, sy - 12);
        ctx.moveTo(sx + 6, sy - 12);
        ctx.lineTo(sx + 10, sy - 22);
        ctx.lineTo(sx + 14, sy - 12);
        ctx.fill();
        // Horizontal crossbars
        ctx.fillStyle = "#92400E";
        ctx.fillRect(sx - 18, sy - 6, 36, 5);
        ctx.fillRect(sx - 18, sy + 4, 36, 5);
        ctx.fillStyle = "#CBD5E1";
        ctx.fillRect(sx - 10, sy - 4, 2, 2);
        ctx.fillRect(sx + 10, sy - 4, 2, 2);
      } else if (st.type === "torch") {
        // Wooden torch pole with blazing ember
        ctx.fillStyle = "#78350F";
        ctx.fillRect(sx - 3, sy - 10, 6, 26);
        ctx.fillStyle = "#334155";
        ctx.fillRect(sx - 6, sy - 14, 12, 5);
        // Flame
        const tflick = Math.sin(Date.now() / 80) * 2;
        ctx.fillStyle = "#F59E0B";
        ctx.beginPath();
        ctx.arc(sx, sy - 18 + tflick, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#FEF08A";
        ctx.beginPath();
        ctx.arc(sx, sy - 18 + tflick, 3.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (st.type === "dog_bed") {
        // Cozy woven canine straw bed
        ctx.fillStyle = "#78350F";
        ctx.beginPath();
        ctx.ellipse(sx, sy, 22, 14, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#FACC15";
        ctx.beginPath();
        ctx.ellipse(sx, sy, 19, 11, 0, 0, Math.PI * 2);
        ctx.fill();
        // Red plaid cushion
        ctx.fillStyle = "#DC2626";
        ctx.beginPath();
        ctx.ellipse(sx, sy, 14, 8, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 9px sans-serif";
        ctx.fillText("🐾", sx - 5, sy + 3);
      }
    });

    // 2. LAND EXPANSION SIGNPOSTS
    landPlotsRef.current.forEach((plot) => {
      if (!plot.isUnlocked) {
        const sx = plot.signCol * TILE_SIZE;
        const sy = plot.signRow * TILE_SIZE;
        ctx.fillStyle = "#78350F";
        ctx.fillRect(sx + 20, sy + 18, 8, 28);
        ctx.fillStyle = "#F59E0B";
        ctx.fillRect(sx + 4, sy + 4, 40, 20);
        ctx.strokeStyle = "#B45309";
        ctx.lineWidth = 2;
        ctx.strokeRect(sx + 4, sy + 4, 40, 20);

        ctx.fillStyle = "#000000";
        ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
        ctx.fillText("FOR SALE", sx + 6, sy + 14);
        ctx.fillText(`${plot.cost} Tk`, sx + 10, sy + 22);
      }
    });

    // 3. FARM TILES & CROPS
    farmTilesRef.current.forEach((farm) => {
      if (farm.isTilled) {
        ctx.fillStyle = farm.isWatered ? "#451A03" : "#78350F";
        ctx.fillRect(farm.x + 2, farm.y + 2, TILE_SIZE - 4, TILE_SIZE - 4);

        if (farm.cropType && farm.growthStage > 0) {
          const cx = farm.x + 24;
          const cy = farm.y + 28;
          const stage = farm.growthStage;

          if (farm.cropType === "taro") {
            ctx.fillStyle = "#15803D";
            const leafRadius = stage * 3.5;
            ctx.beginPath();
            ctx.ellipse(cx, cy - stage * 2, leafRadius, leafRadius * 1.3, 0, 0, Math.PI * 2);
            ctx.fill();
          } else if (farm.cropType === "paddy") {
            ctx.fillStyle = stage === 4 ? "#FACC15" : "#65A30D";
            ctx.fillRect(cx - 3, cy - stage * 4, 6, stage * 5);
          } else {
            ctx.fillStyle = stage === 4 ? "#9333EA" : "#16A34A";
            ctx.beginPath();
            ctx.ellipse(cx, cy, 10, 14, 0, 0, Math.PI * 2);
            ctx.fill();
          }

          if (stage === 4) {
            ctx.fillStyle = "#FEF08A";
            ctx.font = "bold 10px sans-serif";
            ctx.fillText("READY!", farm.x + 6, farm.y + 12);
          }
        }
      }
    });

    // 3.5 PERMANENT DEVELOPER MUSTAKIM SHOP STALL (দেপলোপার মুস্তাকিম)
    const stallX = 29.5 * TILE_SIZE;
    const stallY = 13.5 * TILE_SIZE;
    const distToMustakim = Math.hypot(p.x - stallX, p.y - stallY);

    // Dock platform base shadow
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fillRect(stallX - 20, stallY + 34, 96, 16);

    // Wooden stall counter base
    ctx.fillStyle = "#78350F";
    ctx.fillRect(stallX - 16, stallY + 12, 86, 26);
    ctx.fillStyle = "#92400E";
    ctx.fillRect(stallX - 14, stallY + 14, 82, 3);
    ctx.fillRect(stallX - 14, stallY + 24, 82, 3);

    // Canopy posts
    ctx.fillStyle = "#451A03";
    ctx.fillRect(stallX - 14, stallY - 26, 6, 38);
    ctx.fillRect(stallX + 64, stallY - 26, 6, 38);

    // Striped Awning Canopy (Teal & Amber alternating)
    const canopyW = 90;
    const canopyH = 22;
    for (let s = 0; s < 6; s++) {
      ctx.fillStyle = s % 2 === 0 ? "#0D9488" : "#F59E0B";
      ctx.fillRect(stallX - 17 + s * 15, stallY - 26, 15, canopyH);
    }
    // Canopy scalloped fringe
    ctx.fillStyle = "#FEF08A";
    ctx.fillRect(stallX - 17, stallY - 7, canopyW, 3);

    // Developer Laptop on counter
    ctx.fillStyle = "#1E293B";
    ctx.fillRect(stallX + 6, stallY + 6, 22, 13); // Laptop Screen
    ctx.fillStyle = "#0F172A";
    ctx.fillRect(stallX + 4, stallY + 18, 26, 3); // Base
    // Glowing green matrix code screen
    ctx.fillStyle = "#10B981";
    ctx.fillRect(stallX + 8, stallY + 8, 18, 9);
    ctx.fillStyle = "#022C22";
    ctx.font = "bold 6px monospace";
    ctx.fillText("DEV AI", stallX + 9, stallY + 15);

    // Brass Lantern hanging from left post
    ctx.fillStyle = "#D97706";
    ctx.fillRect(stallX - 16, stallY - 14, 8, 10);
    ctx.fillStyle = "#FEF08A";
    const flicker = Math.sin(Date.now() / 150) * 1.5;
    ctx.beginPath();
    ctx.arc(stallX - 12, stallY - 9, 4 + flicker, 0, Math.PI * 2);
    ctx.fill();

    // Mustakim Character Sprite (standing proudly behind counter)
    const mustakimX = stallX + 40;
    const mustakimY = stallY + 2;

    // Body (Teal Developer Hoodie/Kurta)
    ctx.fillStyle = "#0F766E";
    ctx.fillRect(mustakimX - 10, mustakimY + 4, 20, 16);

    // Head
    ctx.fillStyle = "#FED7AA";
    ctx.beginPath();
    ctx.arc(mustakimX, mustakimY, 8.5, 0, Math.PI * 2);
    ctx.fill();

    // Short stylish black hair
    ctx.fillStyle = "#0F172A";
    ctx.beginPath();
    ctx.arc(mustakimX, mustakimY - 3, 8.5, Math.PI, Math.PI * 2);
    ctx.fill();

    // Developer Glasses
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(mustakimX - 6, mustakimY - 2, 5, 4);
    ctx.strokeRect(mustakimX + 1, mustakimY - 2, 5, 4);
    ctx.beginPath();
    ctx.moveTo(mustakimX - 1, mustakimY);
    ctx.lineTo(mustakimX + 1, mustakimY);
    ctx.stroke();

    // Smiling face
    ctx.fillStyle = "#991B1B";
    ctx.beginPath();
    ctx.arc(mustakimX, mustakimY + 3, 2.5, 0, Math.PI);
    ctx.fill();

    // Waving hand
    const waveHand = Math.sin(Date.now() / 200) * 4;
    ctx.fillStyle = "#FED7AA";
    ctx.beginPath();
    ctx.arc(mustakimX + 13, mustakimY + waveHand, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Permanent Developer Stall Sign
    ctx.fillStyle = "rgba(0,0,0,0.8)";
    ctx.roundRect?.(stallX - 14, stallY - 44, 86, 15, 3);
    ctx.fill();
    ctx.fillStyle = "#5EEAD4";
    ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
    ctx.fillText("👨‍💻 মুস্তাকিম স্টোর", stallX - 8, stallY - 33);

    // Interactive speech bubble when Tojo is nearby
    if (distToMustakim < 150) {
      ctx.fillStyle = "#134E4A";
      ctx.strokeStyle = "#2DD4BF";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect?.(stallX - 25, stallY - 72, 126, 22, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#F0FDFA";
      ctx.font = "bold 10px 'Hind Siliguri', sans-serif";
      ctx.fillText("💬 [Space/ট্যাপ] সব আইটেম নিন!", stallX - 18, stallY - 57);
    }

    // 4. DROPS
    dropsRef.current.forEach((drop) => {
      ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
      ctx.beginPath();
      ctx.arc(drop.x + 12, drop.y + 12, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = "16px sans-serif";
      ctx.fillText(drop.item.icon, drop.x + 2, drop.y + 16);
    });

    // 5. TREES
    treesRef.current.forEach((tree) => {
      const tx = tree.x;
      const ty = tree.y;

      if (tree.state === "stump") {
        ctx.fillStyle = "#5C3D2E";
        ctx.beginPath();
        ctx.ellipse(tx + 16, ty + 24, 14, 7, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (tree.state === "sapling") {
        ctx.fillStyle = "#78350F";
        ctx.fillRect(tx + 14, ty + 12, 4, 16);
        ctx.fillStyle = "#22C55E";
        ctx.beginPath();
        ctx.arc(tx + 16, ty + 10, 12, 0, Math.PI * 2);
        ctx.fill();
      } else {
        if (tree.type === "taro_giant") {
          ctx.fillStyle = "#3F2E18";
          ctx.fillRect(tx + 12, ty + 10, 8, 28);
          ctx.fillStyle = "#15803D";
          ctx.beginPath();
          ctx.ellipse(tx + 16, ty - 6, 26, 32, 0, 0, Math.PI * 2);
          ctx.fill();
        } else if (tree.type === "bamboo") {
          ctx.fillStyle = "#4D7C0F";
          ctx.fillRect(tx + 8, ty - 15, 4, 50);
          ctx.fillRect(tx + 18, ty - 22, 4, 57);
        } else {
          ctx.fillStyle = "#5C3D2E";
          ctx.fillRect(tx + 11, ty + 8, 10, 30);
          ctx.fillStyle = currentSeason === "spring" ? "#16A34A" : "#166534";
          ctx.beginPath();
          ctx.arc(tx + 16, ty - 4, 26, 0, Math.PI * 2);
          ctx.fill();
        }

        if (tree.hp < tree.maxHp) {
          const barW = 32;
          const barH = 4;
          const healthPct = tree.hp / tree.maxHp;
          ctx.fillStyle = "rgba(0,0,0,0.6)";
          ctx.fillRect(tx, ty - 38, barW, barH);
          ctx.fillStyle = "#EF4444";
          ctx.fillRect(tx, ty - 38, barW * healthPct, barH);
        }
      }
    });

    // =========================================================================
    // 6. 10X LIFELIKE DOGS (CANINE AI WITH SITTING & 3 MISSING DOGS)
    // =========================================================================
    dogsRef.current.forEach((dog) => {
      const dx = dog.x;
      const dy = dog.y;
      const scale = dog.sizeScale || 1.0;
      const isRolling = dog.bellyRollTimer > 0;
      const jumpHop = dog.z || 0;
      const isSitting = dog.isSitting || dog.state === "sitting";

      ctx.save();
      ctx.translate(dx + 16, dy + 16 - jumpHop);
      ctx.scale(scale, scale);
      if (isRolling) {
        ctx.rotate(Math.PI * 0.85);
      }
      ctx.translate(-16, -16);

      // Distinct Fur Colors for Dogs (Black Dog, White Dog, Yellow Dog)
      const dogBodyColor =
        dog.furType === "white"
          ? "#F8FAFC"
          : dog.furType === "yellow"
          ? "#D97706"
          : dog.color || "#0B1325";

      // Body (lowered and compact when sitting)
      ctx.fillStyle = dogBodyColor;
      ctx.beginPath();
      if (isSitting) {
        ctx.ellipse(18, 19, 14, 11, 0, 0, Math.PI * 2);
      } else {
        ctx.ellipse(18, 16, 17, 12, 0, 0, Math.PI * 2);
      }
      ctx.fill();

      // Fur gloss shine
      ctx.fillStyle =
        dog.furType === "white"
          ? "rgba(255, 255, 255, 0.4)"
          : dog.furType === "yellow"
          ? "rgba(254, 240, 138, 0.25)"
          : "rgba(255, 255, 255, 0.15)";
      ctx.beginPath();
      ctx.ellipse(18, isSitting ? 15 : 12, 12, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Head
      const headX = dog.facing === "left" ? 4 : 32;
      const headY = isSitting ? 11 : 10;
      ctx.fillStyle = dogBodyColor;
      ctx.beginPath();
      ctx.arc(headX, headY, 9.5, 0, Math.PI * 2);
      ctx.fill();

      // Snout
      const snoutX = dog.facing === "left" ? -3 : 39;
      ctx.fillStyle =
        dog.furType === "white"
          ? "#F1F5F9"
          : dog.furType === "yellow"
          ? "#92400E"
          : "#1E293B";
      ctx.beginPath();
      ctx.arc(snoutX, headY + 2, 4.5, 0, Math.PI * 2);
      ctx.fill();

      // Nose
      ctx.fillStyle = "#000000";
      ctx.beginPath();
      ctx.arc(snoutX + (dog.facing === "left" ? -2 : 2), headY + 1, 2, 0, Math.PI * 2);
      ctx.fill();

      // Floppy / Alert Ears
      const earFlop = Math.sin(Date.now() / 140) * 2;
      ctx.fillStyle = dogBodyColor;
      ctx.beginPath();
      ctx.moveTo(headX - 4, headY - 7);
      if (dog.state === "flee") {
        ctx.lineTo(headX - 2, headY);
      } else {
        ctx.lineTo(headX - 1, headY - 17 + earFlop);
      }
      ctx.lineTo(headX + 3, headY - 7);
      ctx.fill();

      // Paws (Folded when sitting, standing stride when walking)
      ctx.fillStyle =
        dog.furType === "white"
          ? "#E2E8F0"
          : dog.furType === "yellow"
          ? "#B45309"
          : "#0F172A";

      if (isSitting) {
        // Folded sitting paws
        ctx.beginPath();
        ctx.ellipse(12, 27, 5, 3.5, 0, 0, Math.PI * 2);
        ctx.ellipse(22, 27, 5, 3.5, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillRect(8, 22, 5, 10);
        ctx.fillRect(15, 22, 5, 10);
        ctx.fillRect(23, 22, 5, 10);
      }

      // Dynamic Wagging Tail
      ctx.strokeStyle = dogBodyColor;
      ctx.lineWidth = 3.5;
      const wagSpeed = dog.tailWagSpeed || 4;
      const tailSwing = Math.sin(Date.now() / (180 / wagSpeed)) * 14;
      const tailStartX = dog.facing === "left" ? 31 : 5;
      const tailTipX = dog.facing === "left" ? 42 + tailSwing : -8 + tailSwing;

      ctx.beginPath();
      ctx.moveTo(tailStartX, isSitting ? 20 : 15);
      ctx.quadraticCurveTo(
        tailStartX + (dog.facing === "left" ? 6 : -6),
        isSitting ? 8 : 4,
        tailTipX,
        dog.state === "flee" ? 22 : isSitting ? 12 : 6
      );
      ctx.stroke();

      // Sparkly Eyes
      const eyeX = dog.facing === "left" ? 3 : 33;
      ctx.fillStyle = "#FFFFFF";
      ctx.beginPath();
      ctx.arc(eyeX, headY - 2, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = dog.furType === "white" ? "#0284C7" : "#0F172A";
      ctx.beginPath();
      ctx.arc(eyeX, headY - 2, 1.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // MISSING DOG SOS BEACON BADGE IN DEEP KOCHUBON
      if (dog.isMissing && !dog.rescued) {
        const sosBlink = Math.sin(Date.now() / 140) > 0;
        ctx.fillStyle = sosBlink ? "#EF4444" : "#F59E0B";
        ctx.beginPath();
        ctx.roundRect?.(dx - 18, dy - 34, 68, 16, 4);
        ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
        ctx.fillText(`🆘 ${dog.bengaliName}`, dx - 14, dy - 22);
      }

      // SITTING INDICATOR BADGE
      if (isSitting && !dog.isMissing) {
        ctx.fillStyle = "rgba(16, 185, 129, 0.85)";
        ctx.beginPath();
        ctx.roundRect?.(dx + 2, dy - 26, 32, 13, 3);
        ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 8px 'Hind Siliguri', sans-serif";
        ctx.fillText("বসা (Sit)", dx + 5, dy - 17);
      }

      // Dog dialogue bubble or heart
      if (dog.speechBubble) {
        ctx.fillStyle = "rgba(0, 0, 0, 0.88)";
        ctx.roundRect?.(dx - 22, dy - 36, 155, 23, 6);
        ctx.fill();
        ctx.fillStyle = dog.state === "flee" ? "#F87171" : "#34D399";
        ctx.font = "bold 11px 'Hind Siliguri', sans-serif";
        ctx.fillText(dog.speechBubble, dx - 16, dy - 20);
      } else if (dog.isFriend || isHoldingBareHand) {
        ctx.fillStyle = "#F43F5E";
        ctx.font = "bold 12px sans-serif";
        ctx.fillText("❤️", dx + 8, dy - 8);
      }
    });

    // =========================================================================
    // 6.5 NIGHT MONSTER DOG: KOCHU KHOR KUKUR (কচু খোর কুকুর) in Deep Kochubon
    // =========================================================================
    const isNightTime = dayTimeRef.current > 0.65 && dayTimeRef.current < 0.95;
    if (monsterRef.current && monsterRef.current.hp > 0 && isNightTime) {
      const m = monsterRef.current;
      const mx = m.x;
      const my = m.y;

      ctx.save();
      ctx.translate(mx + 20, my + 20);
      ctx.scale(1.75, 1.75); // Huge Boss scale
      ctx.translate(-20, -20);

      // Dark shadowy mist / curse aura
      const mistGrad = ctx.createRadialGradient(20, 20, 8, 20, 20, 36);
      mistGrad.addColorStop(0, "rgba(88, 28, 135, 0.45)");
      mistGrad.addColorStop(0.6, "rgba(59, 7, 100, 0.25)");
      mistGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = mistGrad;
      ctx.beginPath();
      ctx.arc(20, 20, 34, 0, Math.PI * 2);
      ctx.fill();

      // Spiky dark monstrous canine body
      ctx.fillStyle = "#180D2B";
      ctx.beginPath();
      ctx.ellipse(20, 22, 20, 14, 0, 0, Math.PI * 2);
      ctx.fill();

      // Jagged shadow spine spikes
      ctx.fillStyle = "#581C87";
      ctx.beginPath();
      ctx.moveTo(12, 10);
      ctx.lineTo(15, 2);
      ctx.lineTo(18, 10);
      ctx.moveTo(18, 10);
      ctx.lineTo(22, 0);
      ctx.lineTo(25, 10);
      ctx.moveTo(25, 10);
      ctx.lineTo(28, 4);
      ctx.lineTo(31, 10);
      ctx.fill();

      // Ferocious Head
      const mHeadX = m.facing === "left" ? 6 : 34;
      ctx.fillStyle = "#180D2B";
      ctx.beginPath();
      ctx.arc(mHeadX, 14, 12, 0, Math.PI * 2);
      ctx.fill();

      // Curved Demonic Horns
      ctx.fillStyle = "#991B1B";
      ctx.beginPath();
      if (m.facing === "left") {
        ctx.moveTo(mHeadX - 2, 6);
        ctx.quadraticCurveTo(mHeadX - 10, -4, mHeadX - 6, -10);
        ctx.lineTo(mHeadX + 1, 4);
        ctx.moveTo(mHeadX + 4, 6);
        ctx.quadraticCurveTo(mHeadX + 2, -2, mHeadX + 6, -8);
        ctx.lineTo(mHeadX + 7, 5);
      } else {
        ctx.moveTo(mHeadX + 2, 6);
        ctx.quadraticCurveTo(mHeadX + 10, -4, mHeadX + 6, -10);
        ctx.lineTo(mHeadX - 1, 4);
        ctx.moveTo(mHeadX - 4, 6);
        ctx.quadraticCurveTo(mHeadX - 2, -2, mHeadX - 6, -8);
        ctx.lineTo(mHeadX - 7, 5);
      }
      ctx.fill();

      // Menacing Crimson Glowing Eyes
      const mEyeX = m.facing === "left" ? 3 : 37;
      ctx.fillStyle = "#EF4444";
      ctx.beginPath();
      ctx.arc(mEyeX, 12, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#FCA5A5";
      ctx.beginPath();
      ctx.arc(mEyeX, 12, 1.2, 0, Math.PI * 2);
      ctx.fill();

      // Razor Fangs & Snarl
      const mSnoutX = m.facing === "left" ? -2 : 42;
      ctx.fillStyle = "#0F071D";
      ctx.fillRect(mSnoutX - 2, 16, 8, 7);
      ctx.fillStyle = "#FEF08A";
      ctx.beginPath();
      ctx.moveTo(mSnoutX, 17);
      ctx.lineTo(mSnoutX + 2, 22);
      ctx.lineTo(mSnoutX + 4, 17);
      ctx.fill();

      // Claws
      ctx.fillStyle = "#2E1065";
      ctx.fillRect(8, 28, 7, 11);
      ctx.fillRect(17, 28, 7, 11);
      ctx.fillRect(26, 28, 7, 11);

      ctx.restore();

      // Boss Health Bar Overhead
      const barW = 86;
      const barH = 7;
      const hpPct = Math.max(0, m.hp / m.maxHp);
      ctx.fillStyle = "rgba(0,0,0,0.88)";
      ctx.roundRect?.(mx - 24, my - 30, barW + 12, 24, 4);
      ctx.fill();
      ctx.strokeStyle = "#991B1B";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = "#450A0A";
      ctx.fillRect(mx - 18, my - 13, barW, barH);
      ctx.fillStyle = "#DC2626";
      ctx.fillRect(mx - 18, my - 13, barW * hpPct, barH);

      ctx.fillStyle = "#FCA5A5";
      ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
      ctx.fillText(`🐺 কচু খোর কুকুর [${m.hp}/${m.maxHp}]`, mx - 16, my - 17);

      // Monster speech bubble if active
      if (m.speechBubble) {
        ctx.fillStyle = "rgba(15, 23, 42, 0.95)";
        ctx.strokeStyle = "#DC2626";
        ctx.lineWidth = 1.5;
        ctx.roundRect?.(mx - 24, my - 56, 165, 22, 5);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#F87171";
        ctx.font = "bold 11px 'Hind Siliguri', sans-serif";
        ctx.fillText(m.speechBubble, mx - 18, my - 41);
      }
    }

    // 7. CRITTERS
    crittersRef.current.forEach((critter) => {
      ctx.fillStyle = critter.color;
      ctx.beginPath();
      ctx.arc(critter.x, critter.y, critter.size, 0, Math.PI * 2);
      ctx.fill();
    });

    // 8. TOJO (HERO SPRITE) WITH 60FPS SPEED TRAILS & BARE HAND
    const px = p.x;
    const py = p.y;
    const jumpOffset = p.z || 0;

    // Ground Shadow
    const shadowScale = Math.max(0.4, 1 - jumpOffset / 40);
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(
      px + 16,
      py + 36,
      14 * shadowScale,
      6 * shadowScale,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Speed Trail Ghosts when Sprinting (1-Trillion Times Cooler!)
    if (p.isSprinting && p.isMoving) {
      for (let i = 1; i <= 2; i++) {
        const trailOffset =
          i * (p.facing === "left" ? 10 : p.facing === "right" ? -10 : 0);
        const trailOffsetY =
          i * (p.facing === "up" ? 10 : p.facing === "down" ? -10 : 0);
        ctx.save();
        ctx.translate(px + trailOffset, py + trailOffsetY - jumpOffset);
        ctx.globalAlpha = 0.22 / i;
        ctx.fillStyle = "#F59E0B";
        ctx.fillRect(7, 12, 18, 12);
        ctx.beginPath();
        ctx.arc(16, 8, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    // Draw Tojo shifted up by -jumpOffset with dynamic bounce & tilt
    ctx.save();
    const walkFrame = p.walkFrame || 0;
    const isMoving = p.isMoving;
    const bobY = isMoving ? Math.abs(Math.sin(walkFrame * 2)) * 2.5 : Math.sin(Date.now() / 450) * 0.8;
    const leanAngle = isMoving
      ? (p.facing === "right" ? 0.08 : p.facing === "left" ? -0.08 : 0) * (p.isSprinting ? 1.6 : 1)
      : 0;

    ctx.translate(px + 16, py + 20 - jumpOffset + bobY);
    ctx.rotate(leanAngle);

    // Jump Squash & Stretch
    if (p.isJumping) {
      ctx.scale(0.92, 1.14);
    }
    ctx.translate(-16, -20);

    // 1. BACKPACK (Rendered on back when facing up, left, or right)
    if (p.facing === "up") {
      // Full rear view of adventurer backpack
      ctx.fillStyle = "#78350F"; // Dark leather straps
      ctx.fillRect(8, 11, 3, 13);
      ctx.fillRect(21, 11, 3, 13);

      ctx.fillStyle = "#92400E"; // Backpack main leather pouch
      ctx.beginPath();
      ctx.roundRect?.(7, 12, 18, 14, 3);
      ctx.fill();

      ctx.fillStyle = "#B45309"; // Flap
      ctx.fillRect(7, 12, 18, 5);
      ctx.fillStyle = "#FACC15"; // Golden buckle
      ctx.fillRect(14, 15, 4, 3);

      // Green rolled explorer bedroll on top
      ctx.fillStyle = "#065F46";
      ctx.beginPath();
      ctx.roundRect?.(6, 8, 20, 5, 2);
      ctx.fill();
      ctx.fillStyle = "#F59E0B"; // Straps on bedroll
      ctx.fillRect(10, 8, 2, 5);
      ctx.fillRect(20, 8, 2, 5);
    } else if (p.facing === "left") {
      // Side profile backpack on back (right side of torso)
      ctx.fillStyle = "#92400E";
      ctx.beginPath();
      ctx.roundRect?.(19, 11, 9, 13, 3);
      ctx.fill();
      ctx.fillStyle = "#FACC15"; // Buckle
      ctx.fillRect(24, 15, 3, 3);
      ctx.fillStyle = "#065F46"; // Rolled bedroll
      ctx.beginPath();
      ctx.roundRect?.(18, 7, 10, 5, 2);
      ctx.fill();
    } else if (p.facing === "right") {
      // Side profile backpack on back (left side of torso)
      ctx.fillStyle = "#92400E";
      ctx.beginPath();
      ctx.roundRect?.(4, 11, 9, 13, 3);
      ctx.fill();
      ctx.fillStyle = "#FACC15"; // Buckle
      ctx.fillRect(5, 15, 3, 3);
      ctx.fillStyle = "#065F46"; // Rolled bedroll
      ctx.beginPath();
      ctx.roundRect?.(4, 7, 10, 5, 2);
      ctx.fill();
    }

    // 2. LEGS & WALKING CYCLE
    const legSwing1 = isMoving ? Math.sin(walkFrame) * 6 : 0;
    const legSwing2 = isMoving ? -Math.sin(walkFrame) * 6 : 0;
    const footLift1 = isMoving ? Math.max(0, -Math.cos(walkFrame) * 3) : 0;
    const footLift2 = isMoving ? Math.max(0, Math.cos(walkFrame) * 3) : 0;

    // Blue Bengali Dhoti / Trousers
    ctx.fillStyle = "#1E3A8A";
    if (p.facing === "left" || p.facing === "right") {
      // Profile legs stride
      ctx.fillRect(11 + legSwing1, 23 - footLift1, 6, 13);
      ctx.fillRect(15 + legSwing2, 23 - footLift2, 6, 13);

      // Leather Sandals
      ctx.fillStyle = "#78350F";
      ctx.fillRect(9 + legSwing1, 35 - footLift1, 9, 3.5);
      ctx.fillRect(13 + legSwing2, 35 - footLift2, 9, 3.5);
    } else {
      // Front / Back legs
      ctx.fillRect(8, 23 + legSwing1 * 0.5 - footLift1, 7, 13);
      ctx.fillRect(17, 23 + legSwing2 * 0.5 - footLift2, 7, 13);

      // Leather Sandals
      ctx.fillStyle = "#78350F";
      ctx.fillRect(7, 35 + legSwing1 * 0.5 - footLift1, 8, 3.5);
      ctx.fillRect(17, 35 + legSwing2 * 0.5 - footLift2, 8, 3.5);
    }

    // 3. TORSO (Orange Kurta Vest)
    ctx.fillStyle = "#EA580C";
    ctx.fillRect(7, 12, 18, 12);
    // Brown waist belt & golden buckle
    ctx.fillStyle = "#854D0E";
    ctx.fillRect(7, 21, 18, 3);
    ctx.fillStyle = "#FACC15";
    ctx.fillRect(14, 21, 4, 3);

    // Front View: Backpack straps over chest
    if (p.facing === "down") {
      ctx.fillStyle = "#78350F";
      ctx.fillRect(9, 12, 2.5, 9);
      ctx.fillRect(20, 12, 2.5, 9);
      // Kurta collar buttons
      ctx.fillStyle = "#FACC15";
      ctx.beginPath();
      ctx.arc(16, 15, 1, 0, Math.PI * 2);
      ctx.arc(16, 18, 1, 0, Math.PI * 2);
      ctx.fill();
    }

    // 4. HEAD, HAIR & RED HERO BANDANA
    ctx.fillStyle = "#FDBA74"; // Skin tone
    ctx.beginPath();
    ctx.arc(16, 8, 9, 0, Math.PI * 2);
    ctx.fill();

    // Curly dark hair
    ctx.fillStyle = "#0F172A";
    if (p.facing === "up") {
      // Full hair on back of head
      ctx.beginPath();
      ctx.arc(16, 7, 9.5, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.arc(16, 5, 8.5, Math.PI, Math.PI * 2);
      ctx.fill();
      // Side curls
      ctx.beginPath();
      ctx.arc(8, 8, 3, 0, Math.PI * 2);
      ctx.arc(24, 8, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // Red Hero Bandana
    ctx.fillStyle = "#DC2626";
    ctx.fillRect(8, 3.5, 16, 3.5);
    const flutterSpeed = p.isSprinting ? 40 : 80;
    const bandanaFlutter = Math.sin(Date.now() / flutterSpeed) * (p.isSprinting ? 5 : 2.5);

    ctx.beginPath();
    if (p.facing === "left") {
      ctx.moveTo(23, 5);
      ctx.lineTo(29 + bandanaFlutter, 3);
      ctx.lineTo(27 + bandanaFlutter, 8);
    } else if (p.facing === "right") {
      ctx.moveTo(9, 5);
      ctx.lineTo(3 - bandanaFlutter, 3);
      ctx.lineTo(5 - bandanaFlutter, 8);
    } else if (p.facing === "up") {
      // Two bandana tails flutter behind when facing up
      ctx.moveTo(14, 5);
      ctx.lineTo(12 - bandanaFlutter, 11);
      ctx.lineTo(15, 7);
      ctx.lineTo(18 + bandanaFlutter, 11);
    } else {
      // Facing down: knot on right
      ctx.moveTo(23, 5);
      ctx.lineTo(27 + bandanaFlutter, 4);
      ctx.lineTo(26, 7);
    }
    ctx.fill();

    // Expressive Eyes (Front and Side Profiles)
    if (p.facing !== "up") {
      ctx.fillStyle = "#000000";
      if (p.facing === "down") {
        ctx.beginPath();
        ctx.arc(13, 8, 1.4, 0, Math.PI * 2);
        ctx.arc(19, 8, 1.4, 0, Math.PI * 2);
        ctx.fill();
        // Eye reflections
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(13.4, 7.6, 0.5, 0, Math.PI * 2);
        ctx.arc(19.4, 7.6, 0.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.facing === "left") {
        ctx.beginPath();
        ctx.arc(11, 8, 1.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(10.6, 7.6, 0.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.facing === "right") {
        ctx.beginPath();
        ctx.arc(21, 8, 1.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(21.4, 7.6, 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 5. ARMS & TOOL / BARE HAND HOLDING
    const equipped = hotbarRef.current[activeSlotRef.current];
    const handSwing = (p.handAnim || 0) * 14;

    // Left Arm / Hand
    const armSwingL = isMoving ? -Math.sin(walkFrame) * 5 : 0;
    ctx.fillStyle = "#FDBA74";
    ctx.beginPath();
    ctx.arc(4, 18 + armSwingL, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Right Arm / Action Hand
    let rightHandX = 26;
    let rightHandY = 18 + (isMoving ? Math.sin(walkFrame) * 5 : 0);
    if (p.isActing) {
      rightHandX += p.facing === "left" ? -handSwing : handSwing;
      rightHandY -= handSwing * 0.6;
    }

    ctx.fillStyle = "#FDBA74";
    ctx.beginPath();
    ctx.arc(rightHandX, rightHandY, 4, 0, Math.PI * 2);
    ctx.fill();

    // Equipped Tool or Bare Hand rendering
    if (equipped) {
      ctx.save();
      ctx.translate(rightHandX, rightHandY);

      if (equipped.id === "hand_empty" || equipped.id.includes("hand")) {
        // Open gentle bare hand with golden peace aura
        const waveAngle = Math.sin(Date.now() / 90) * 0.28;
        ctx.rotate(waveAngle);

        ctx.fillStyle = "rgba(250, 204, 21, 0.4)";
        ctx.beginPath();
        ctx.arc(0, 0, 10, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#FDBA74";
        ctx.beginPath();
        ctx.ellipse(0, 0, 3.8, 4.8, 0, 0, Math.PI * 2);
        ctx.fill();

        // 5 open fingers
        ctx.fillRect(-4.5, -1, 2, 2.5);
        ctx.fillRect(-2.5, -6.5, 1.8, 4.5);
        ctx.fillRect(-0.5, -8, 1.8, 6);
        ctx.fillRect(1.5, -6.5, 1.8, 4.5);
        ctx.fillRect(3.2, -4.5, 1.6, 3.5);
      } else if (equipped.id.includes("stick")) {
        ctx.strokeStyle =
          equipped.tier === 3
            ? "#94A3B8"
            : equipped.tier === 2
            ? "#84CC16"
            : "#854D0E";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(-5, -16);
        ctx.lineTo(8, 12);
        ctx.stroke();

        ctx.fillStyle = "#FDBA74";
        ctx.beginPath();
        ctx.arc(1, 0, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (equipped.id.includes("axe")) {
        ctx.strokeStyle = "#854D0E";
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(0, 12);
        ctx.lineTo(0, -14);
        ctx.stroke();

        ctx.fillStyle = equipped.tier === 3 ? "#FACC15" : equipped.tier === 2 ? "#64748B" : "#475569";
        ctx.beginPath();
        ctx.moveTo(-8, -14);
        ctx.lineTo(9, -12);
        ctx.lineTo(7, -4);
        ctx.fill();

        ctx.fillStyle = "#FDBA74";
        ctx.beginPath();
        ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (equipped.id.includes("hoe")) {
        ctx.strokeStyle = "#854D0E";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, 10);
        ctx.lineTo(0, -10);
        ctx.stroke();
        ctx.fillStyle = "#64748B";
        ctx.fillRect(-6, -12, 12, 4);
      } else if (equipped.id.includes("water")) {
        ctx.fillStyle = "#38BDF8";
        ctx.beginPath();
        ctx.arc(4, 2, 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Name tag & Overhead Stamina Gauge
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.roundRect?.(2, -16, 28, 13, 3);
    ctx.fill();
    ctx.fillStyle = "#FEF08A";
    ctx.font = "bold 9px sans-serif";
    ctx.fillText("TOJO", 6, -6);

    // Dynamic Overhead Stamina Gauge (Appears when sprinting, low stamina, or exhausted)
    const maxStam = p.maxStamina || 100;
    const currStam = p.stamina ?? 100;
    if (currStam < maxStam - 2 || p.isSprinting || p.isExhausted) {
      const stamPct = Math.max(0, Math.min(1, currStam / maxStam));
      const sBarW = 28;
      const sBarH = 4;
      ctx.fillStyle = "rgba(0,0,0,0.75)";
      ctx.fillRect(2, -23, sBarW, sBarH);
      ctx.fillStyle = p.isExhausted
        ? "#EF4444"
        : stamPct < 0.35
        ? "#F59E0B"
        : "#06B6D4";
      ctx.fillRect(2, -23, sBarW * stamPct, sBarH);
      ctx.fillStyle = "#FEF08A";
      ctx.font = "bold 7px sans-serif";
      ctx.fillText("⚡", -4, -19);
    }

    ctx.restore();

    // 10. PARTICLES & FLOATING TEXTS
    particlesRef.current.forEach((part) => {
      ctx.fillStyle = part.color;
      ctx.globalAlpha = part.alpha;
      ctx.beginPath();
      ctx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1.0;

    floatingTextsRef.current.forEach((ft) => {
      ctx.fillStyle = ft.color;
      ctx.globalAlpha = ft.alpha;
      ctx.font = "bold 13px 'Hind Siliguri', sans-serif";
      ctx.fillText(ft.text, ft.x, ft.y);
    });
    ctx.globalAlpha = 1.0;

    ctx.restore(); // Restore camera

    // 11. WEATHER OVERLAYS (Screen Space)
    if (currentWeather === "rain") {
      ctx.strokeStyle = "rgba(186, 230, 253, 0.65)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      rainDropsRef.current.forEach((r) => {
        ctx.moveTo(r.x, r.y);
        ctx.lineTo(r.x + 3, r.y + r.length);
      });
      ctx.stroke();
    } else if (currentWeather === "fog") {
      ctx.fillStyle = "rgba(226, 232, 240, 0.18)";
      ctx.fillRect(0, 0, viewW, viewH);
    }

    // =========================================================================
    // 11.5 ENTERING DEEP KOCHUBON CINEMATIC TEXT BANNER (SCREEN SPACE)
    // =========================================================================
    if (deepTextBannerRef.current && deepTextBannerRef.current.timer > 0) {
      const banner = deepTextBannerRef.current;
      const bAlpha = Math.min(1.0, banner.timer / 0.6);
      ctx.save();
      ctx.globalAlpha = bAlpha;
      const bW = Math.min(520, viewW - 32);
      const bH = 64;
      const bX = (viewW - bW) / 2;
      const bY = 46;

      // Banner background
      const bgGrad = ctx.createLinearGradient(bX, bY, bX + bW, bY + bH);
      bgGrad.addColorStop(0, "rgba(5, 46, 22, 0.95)");
      bgGrad.addColorStop(0.5, "rgba(15, 23, 42, 0.98)");
      bgGrad.addColorStop(1, "rgba(69, 10, 10, 0.95)");
      ctx.fillStyle = bgGrad;
      ctx.beginPath();
      ctx.roundRect?.(bX, bY, bW, bH, 12);
      ctx.fill();

      ctx.strokeStyle = "#F59E0B";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Banner Title & Subtitle
      ctx.fillStyle = "#FEF08A";
      ctx.font = "bold 14px 'Hind Siliguri', sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(banner.title, viewW / 2, bY + 26);

      ctx.fillStyle = "#A7F3D0";
      ctx.font = "bold 11px 'Hind Siliguri', sans-serif";
      ctx.fillText(banner.subtitle, viewW / 2, bY + 47);
      ctx.textAlign = "start";
      ctx.restore();
    }

    // 12. 60 FPS SCREEN BADGE (Top-Right on canvas)
    if (!isMinimalMode) {
      ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
      ctx.roundRect?.(viewW - 85, 8, 75, 20, 6);
      ctx.fill();
      ctx.fillStyle = "#34D399";
      ctx.font = "bold 10px monospace";
      ctx.fillText(`🟢 ${fpsRef.current} FPS`, viewW - 77, 22);
    }
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative overflow-hidden bg-stone-950 cursor-crosshair select-none"
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="block w-full h-full"
      />
    </div>
  );
};
