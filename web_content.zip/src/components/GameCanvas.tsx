import React, { useEffect, useRef, useCallback } from 'react';
import {
  CellState,
  ColorId,
  Coordinate,
  LevelConfig,
  Particle,
  SpecialTile,
  ThemeConfig
} from '../types/game';
import { soundEngine } from '../utils/audio';

interface GameCanvasProps {
  level: LevelConfig;
  grid: CellState[][];
  paths: Map<ColorId, Coordinate[]>;
  activeColor: ColorId | null;
  activePath: Coordinate[];
  theme: ThemeConfig;
  skinId: string;
  colorblindMode: boolean;
  reducedMotion: boolean;
  hintPath: Coordinate[] | null;
  onCellPointerDown: (cell: Coordinate) => void;
  onCellPointerEnter: (cell: Coordinate) => void;
  onPointerUpGlobal: () => void;
  onTriggerSpecialTile?: (tile: SpecialTile) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  level,
  grid,
  paths,
  activeColor,
  activePath,
  theme,
  skinId,
  colorblindMode,
  reducedMotion,
  hintPath,
  onCellPointerDown,
  onCellPointerEnter,
  onPointerUpGlobal,
  onTriggerSpecialTile
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Simulation & particle states
  const particlesRef = useRef<Particle[]>([]);
  const screenShakeRef = useRef<number>(0);
  const animationFrameIdRef = useRef<number | null>(null);
  const pointerPosRef = useRef<{ x: number; y: number } | null>(null);
  const isPointerDownRef = useRef<boolean>(false);
  const lastActiveCellRef = useRef<Coordinate | null>(null);
  const prevCompletedCountRef = useRef<number>(0);

  // Layout cache
  const layoutRef = useRef({
    width: 0,
    height: 0,
    cellSize: 0,
    offsetX: 0,
    offsetY: 0,
    rows: level.rows,
    cols: level.cols
  });

  // Check if a cell coordinate is in grid bounds
  const isValidCoord = (r: number, c: number) => {
    return r >= 0 && r < level.rows && c >= 0 && c < level.cols;
  };

  // Convert pixel coordinates on canvas to grid cell
  const getCellFromPixels = (px: number, py: number): Coordinate | null => {
    const { cellSize, offsetX, offsetY, rows, cols } = layoutRef.current;
    if (cellSize <= 0) return null;

    const c = Math.floor((px - offsetX) / cellSize);
    const r = Math.floor((py - offsetY) / cellSize);

    if (isValidCoord(r, c)) {
      return { r, c };
    }
    return null;
  };

  // Convert grid cell to center pixel coordinates
  const getCellCenter = (r: number, c: number) => {
    const { cellSize, offsetX, offsetY } = layoutRef.current;
    return {
      x: offsetX + c * cellSize + cellSize / 2,
      y: offsetY + r * cellSize + cellSize / 2
    };
  };

  // Trigger celebration explosion of neon particles
  const spawnBurst = useCallback((center: { x: number; y: number }, colorHex: string, count: number = 32) => {
    if (reducedMotion) return;
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
      const speed = Math.random() * 5 + 2.5;
      particlesRef.current.push({
        x: center.x,
        y: center.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: Math.random() * 3.5 + 2,
        color: colorHex,
        alpha: 1,
        decay: Math.random() * 0.025 + 0.015,
        shape: Math.random() > 0.4 ? 'circle' : 'star'
      });
    }
    screenShakeRef.current = Math.min(screenShakeRef.current + 3.5, 8);
  }, [reducedMotion]);

  // Check if a path just completed to spawn particles
  useEffect(() => {
    let completedCount = 0;
    paths.forEach((p, color) => {
      const pair = level.pairs.find(item => item.color === color);
      if (pair && p.length >= 2) {
        const first = p[0];
        const last = p[p.length - 1];
        const isConnected =
          (first.r === pair.start.r && first.c === pair.start.c && last.r === pair.end.r && last.c === pair.end.c) ||
          (first.r === pair.end.r && first.c === pair.end.c && last.r === pair.start.r && last.c === pair.start.c);
        if (isConnected) completedCount++;
      }
    });

    if (completedCount > prevCompletedCountRef.current) {
      // Find the last completed path to burst at its endpoint
      paths.forEach((p, color) => {
        if (p.length >= 2) {
          const endpoint = p[p.length - 1];
          const center = getCellCenter(endpoint.r, endpoint.c);
          const colorDef = theme.colors[color];
          if (colorDef) {
            spawnBurst(center, colorDef.hex, 28);
          }
        }
      });
    }
    prevCompletedCountRef.current = completedCount;
  }, [paths, level.pairs, theme, spawnBurst]);

  // Pointer event handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.setPointerCapture(e.pointerId);
    isPointerDownRef.current = true;

    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    pointerPosRef.current = { x: px, y: py };

    const cell = getCellFromPixels(px, py);
    if (cell) {
      lastActiveCellRef.current = cell;
      onCellPointerDown(cell);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    pointerPosRef.current = { x: px, y: py };

    if (!isPointerDownRef.current) return;

    const cell = getCellFromPixels(px, py);
    if (cell) {
      if (
        !lastActiveCellRef.current ||
        lastActiveCellRef.current.r !== cell.r ||
        lastActiveCellRef.current.c !== cell.c
      ) {
        lastActiveCellRef.current = cell;
        onCellPointerEnter(cell);

        // Optional tiny drag particle spark
        if (!reducedMotion && activeColor) {
          const center = getCellCenter(cell.r, cell.c);
          const colorDef = theme.colors[activeColor];
          if (colorDef && Math.random() > 0.4) {
            particlesRef.current.push({
              x: center.x,
              y: center.y,
              vx: (Math.random() - 0.5) * 2,
              vy: (Math.random() - 0.5) * 2,
              radius: Math.random() * 2 + 1,
              color: colorDef.hex,
              alpha: 0.8,
              decay: 0.05
            });
          }
        }
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    isPointerDownRef.current = false;
    lastActiveCellRef.current = null;
    pointerPosRef.current = null;
    onPointerUpGlobal();
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}
  };

  // Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();

    const render = (time: number) => {
      const rawDt = (time - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = time;

      // Handle screen resize & DPR
      const dpr = window.devicePixelRatio || 1;
      const container = containerRef.current;
      if (container) {
        const rect = container.getBoundingClientRect();
        const displayWidth = Math.floor(rect.width);
        const displayHeight = Math.floor(rect.height);

        if (canvas.width !== displayWidth * dpr || canvas.height !== displayHeight * dpr) {
          canvas.width = displayWidth * dpr;
          canvas.height = displayHeight * dpr;
          canvas.style.width = `${displayWidth}px`;
          canvas.style.height = `${displayHeight}px`;
        }

        // Calculate responsive grid layout
        const padding = 20;
        const availW = Math.max(100, displayWidth - padding * 2);
        const availH = Math.max(100, displayHeight - padding * 2);

        const cellSize = Math.min(
          Math.floor(availW / level.cols),
          Math.floor(availH / level.rows),
          78 // Maximum cell size for crispness
        );

        const totalGridW = cellSize * level.cols;
        const totalGridH = cellSize * level.rows;
        const offsetX = Math.floor((displayWidth - totalGridW) / 2);
        const offsetY = Math.floor((displayHeight - totalGridH) / 2);

        layoutRef.current = {
          width: displayWidth,
          height: displayHeight,
          cellSize,
          offsetX,
          offsetY,
          rows: level.rows,
          cols: level.cols
        };
      }

      const { width, height, cellSize, offsetX, offsetY, rows, cols } = layoutRef.current;

      // Apply screen shake
      let shakeX = 0;
      let shakeY = 0;
      if (screenShakeRef.current > 0.05) {
        shakeX = (Math.random() - 0.5) * screenShakeRef.current * 3;
        shakeY = (Math.random() - 0.5) * screenShakeRef.current * 3;
        screenShakeRef.current = Math.max(0, screenShakeRef.current - dt * 14);
      } else {
        screenShakeRef.current = 0;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      ctx.translate(shakeX, shakeY);

      // 1. Draw Grid Board Background Card
      if (cellSize > 0) {
        const boardPadding = 12;
        const boardRadius = 18;
        const bx = offsetX - boardPadding;
        const by = offsetY - boardPadding;
        const bw = cols * cellSize + boardPadding * 2;
        const bh = rows * cellSize + boardPadding * 2;

        // Board outer shadow & background
        ctx.fillStyle = theme.boardBg || '#080c1d';
        ctx.beginPath();
        ctx.roundRect(bx, by, bw, bh, boardRadius);
        ctx.fill();

        // Subtle glowing outer stroke
        ctx.strokeStyle = theme.gridLineColor || 'rgba(56, 189, 248, 0.15)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // 2. Draw Grid Cells
        const cellGap = Math.max(3, Math.floor(cellSize * 0.07));
        const cellRadius = Math.max(4, Math.floor(cellSize * 0.16));

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const cx = offsetX + c * cellSize + cellGap / 2;
            const cy = offsetY + r * cellSize + cellGap / 2;
            const cw = cellSize - cellGap;
            const ch = cellSize - cellGap;

            ctx.fillStyle = theme.cellBg || 'rgba(15, 23, 42, 0.7)';
            ctx.beginPath();
            ctx.roundRect(cx, cy, cw, ch, cellRadius);
            ctx.fill();

            // Inner cell border
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Render special tile background glyphs (bomb, multiplier, ice, portal)
            const cellState = grid[r]?.[c];
            if (cellState?.specialTile) {
              const center = getCellCenter(r, c);
              const st = cellState.specialTile;

              if (st.type === 'multiplier') {
                ctx.fillStyle = '#f59e0b';
                ctx.font = `bold ${Math.floor(cellSize * 0.32)}px JetBrains Mono`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(`${st.value || 2}X`, center.x, center.y);

                ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(center.x, center.y, cellSize * 0.38, 0, Math.PI * 2);
                ctx.stroke();
              } else if (st.type === 'bomb') {
                ctx.fillStyle = '#ef4444';
                ctx.font = `${Math.floor(cellSize * 0.4)}px Outfit`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('💣', center.x, center.y);
              } else if (st.type === 'portal') {
                // Rotating portal vortex
                const angle = time * 0.003;
                ctx.save();
                ctx.translate(center.x, center.y);
                ctx.rotate(angle);
                ctx.strokeStyle = '#a855f7';
                ctx.lineWidth = 2.5;
                ctx.setLineDash([4, 4]);
                ctx.beginPath();
                ctx.arc(0, 0, cellSize * 0.32, 0, Math.PI * 2);
                ctx.stroke();
                ctx.restore();
              } else if (st.type === 'ice') {
                // Ice crystal frame
                ctx.fillStyle = 'rgba(147, 197, 253, 0.25)';
                ctx.beginPath();
                ctx.roundRect(cx, cy, cw, ch, cellRadius);
                ctx.fill();
                ctx.strokeStyle = 'rgba(186, 230, 253, 0.6)';
                ctx.lineWidth = 1.5;
                ctx.stroke();
              }
            }
          }
        }

        // 3. Draw Hint Path (if active)
        if (hintPath && hintPath.length >= 2) {
          ctx.save();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
          ctx.lineWidth = Math.max(3, cellSize * 0.15);
          ctx.setLineDash([6, 6]);
          ctx.beginPath();
          hintPath.forEach((pt, i) => {
            const ptCenter = getCellCenter(pt.r, pt.c);
            if (i === 0) ctx.moveTo(ptCenter.x, ptCenter.y);
            else ctx.lineTo(ptCenter.x, ptCenter.y);
          });
          ctx.stroke();
          ctx.restore();
        }

        // 4. Draw Completed and Active Connecting Paths
        const drawSinglePath = (path: Coordinate[], color: ColorId, isActive: boolean) => {
          if (!path || path.length < 2) return;
          const colorDef = theme.colors[color];
          if (!colorDef) return;

          const baseWidth = Math.max(8, cellSize * 0.32);

          // Path vertices
          const pts = path.map(coord => getCellCenter(coord.r, coord.c));

          // A. Outer Radiant Glow
          ctx.save();
          ctx.strokeStyle = colorDef.hex;
          ctx.lineWidth = baseWidth + 8;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.globalAlpha = isActive ? 0.3 : 0.22;
          ctx.beginPath();
          pts.forEach((p, idx) => {
            if (idx === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          });
          ctx.stroke();
          ctx.restore();

          // B. Vibrant Neon Body
          ctx.save();
          ctx.strokeStyle = colorDef.hex;
          ctx.lineWidth = baseWidth;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          pts.forEach((p, idx) => {
            if (idx === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          });
          ctx.stroke();
          ctx.restore();

          // C. Inner Laser White Core
          ctx.save();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
          ctx.lineWidth = Math.max(2, baseWidth * 0.28);
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          pts.forEach((p, idx) => {
            if (idx === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          });
          ctx.stroke();
          ctx.restore();
        };

        // Render completed paths from paths map
        paths.forEach((p, color) => {
          if (color !== activeColor) {
            drawSinglePath(p, color, false);
          }
        });

        // Render active drawing path
        if (activeColor && activePath.length > 0) {
          drawSinglePath(activePath, activeColor, true);

          // Elastic line to pointer position if pointer is dragging
          if (pointerPosRef.current && isPointerDownRef.current) {
            const lastCell = activePath[activePath.length - 1];
            const lastPos = getCellCenter(lastCell.r, lastCell.c);
            const colorDef = theme.colors[activeColor];

            if (colorDef) {
              ctx.save();
              ctx.strokeStyle = colorDef.hex;
              ctx.lineWidth = Math.max(4, cellSize * 0.2);
              ctx.lineCap = 'round';
              ctx.globalAlpha = 0.6;
              ctx.beginPath();
              ctx.moveTo(lastPos.x, lastPos.y);
              ctx.lineTo(pointerPosRef.current.x, pointerPosRef.current.y);
              ctx.stroke();
              ctx.restore();
            }
          }
        }

        // 5. Draw Endpoints (Color Nodes)
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const cell = grid[r]?.[c];
            if (!cell || !cell.isEndpoint || !cell.color) continue;

            const colorDef = theme.colors[cell.color];
            if (!colorDef) continue;

            const center = getCellCenter(r, c);
            const nodeRadius = Math.max(10, cellSize * 0.34);

            // Check if this endpoint pair is completed
            const currentConnectedPath = paths.get(cell.color);
            const pair = level.pairs.find(p => p.color === cell.color);
            let isConnected = false;
            if (pair && currentConnectedPath && currentConnectedPath.length >= 2) {
              const first = currentConnectedPath[0];
              const last = currentConnectedPath[currentConnectedPath.length - 1];
              isConnected =
                (first.r === pair.start.r && first.c === pair.start.c && last.r === pair.end.r && last.c === pair.end.c) ||
                (first.r === pair.end.r && first.c === pair.end.c && last.r === pair.start.r && last.c === pair.start.c);
            }

            const isCurrentActive = activeColor === cell.color;

            // Concentric outer pulse ring
            const pulse = Math.sin(time * 0.005 + (r * cols + c)) * 2;
            const ringRadius = nodeRadius + (isCurrentActive ? 6 + pulse : isConnected ? 4 : 2);

            ctx.save();
            ctx.strokeStyle = colorDef.hex;
            ctx.lineWidth = isCurrentActive ? 2.5 : 1.5;
            ctx.globalAlpha = isConnected ? 0.9 : 0.45;
            ctx.beginPath();
            ctx.arc(center.x, center.y, ringRadius, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();

            // Main Node Body according to Skin Style
            ctx.save();
            if (skinId === 'gemstone') {
              // Faceted diamond shape
              ctx.fillStyle = colorDef.hex;
              ctx.beginPath();
              ctx.moveTo(center.x, center.y - nodeRadius);
              ctx.lineTo(center.x + nodeRadius, center.y);
              ctx.lineTo(center.x, center.y + nodeRadius);
              ctx.lineTo(center.x - nodeRadius, center.y);
              ctx.closePath();
              ctx.fill();

              // Facet highlight
              ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
              ctx.beginPath();
              ctx.moveTo(center.x, center.y - nodeRadius);
              ctx.lineTo(center.x + nodeRadius * 0.5, center.y - nodeRadius * 0.5);
              ctx.lineTo(center.x, center.y);
              ctx.closePath();
              ctx.fill();
            } else if (skinId === 'minimal') {
              // Ultra-sharp flat circle with dark core
              ctx.fillStyle = colorDef.hex;
              ctx.beginPath();
              ctx.arc(center.x, center.y, nodeRadius, 0, Math.PI * 2);
              ctx.fill();

              ctx.fillStyle = '#060814';
              ctx.beginPath();
              ctx.arc(center.x, center.y, nodeRadius * 0.45, 0, Math.PI * 2);
              ctx.fill();
            } else {
              // Default Neon Orb & Cyber Glyph
              const grad = ctx.createRadialGradient(
                center.x - nodeRadius * 0.25,
                center.y - nodeRadius * 0.25,
                nodeRadius * 0.1,
                center.x,
                center.y,
                nodeRadius
              );
              grad.addColorStop(0, '#ffffff');
              grad.addColorStop(0.3, colorDef.hex);
              grad.addColorStop(1, `rgba(${colorDef.rgb}, 0.8)`);

              ctx.fillStyle = grad;
              ctx.beginPath();
              ctx.arc(center.x, center.y, nodeRadius, 0, Math.PI * 2);
              ctx.fill();

              // Glow ring
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 1.2;
              ctx.globalAlpha = 0.6;
              ctx.stroke();
            }
            ctx.restore();

            // Colorblind symbol overlay (or when skin is glyph or mode enabled)
            if (colorblindMode || skinId === 'cyber_glyph') {
              ctx.save();
              ctx.fillStyle = '#ffffff';
              ctx.font = `900 ${Math.floor(nodeRadius * 0.9)}px Outfit, sans-serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.shadowColor = 'rgba(0,0,0,0.8)';
              ctx.shadowBlur = 4;
              ctx.fillText(colorDef.symbol, center.x, center.y + 1);
              ctx.restore();
            }
          }
        }

        // 6. Particle Rendering & Updating
        const particles = particlesRef.current;
        for (let i = particles.length - 1; i >= 0; i--) {
          const p = particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 0.96;
          p.vy *= 0.96;
          p.alpha -= p.decay;

          if (p.alpha <= 0) {
            particles.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.fillStyle = p.color;

          if (p.shape === 'star') {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius * 0.8, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
      }

      ctx.restore();
      animationFrameIdRef.current = requestAnimationFrame(render);
    };

    animationFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, [
    level,
    grid,
    paths,
    activeColor,
    activePath,
    theme,
    skinId,
    colorblindMode,
    reducedMotion,
    hintPath
  ]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full flex items-center justify-center overflow-hidden touch-none select-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="block cursor-crosshair touch-none"
      />
    </div>
  );
};
