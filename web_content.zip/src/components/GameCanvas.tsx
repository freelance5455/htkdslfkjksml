import React, { useRef, useEffect, useState } from 'react';
import { GameEngine } from '../game/engine';
import { sprites } from '../game/sprites';
import { lighting } from '../game/lighting';
import { particles } from '../game/particles';
import { ITEMS } from '../game/items';
import { TILE_SIZE, WORLD_WIDTH, WORLD_HEIGHT } from '../game/procedural';

interface GameCanvasProps {
  engine: GameEngine;
  onSelectBuildingSlot?: (tileX: number, tileY: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ engine, onSelectBuildingSlot }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoverTile, setHoverTile] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    void sprites.loadProvidedAssets();

    let animId: number;
    let tick = 0;

    const resize = () => {
      if (!canvas) return;
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
      ctx.imageSmoothingEnabled = false;
    };

    window.addEventListener('resize', resize);
    resize();

    // Game rendering loop
    const renderLoop = () => {
      tick++;
      engine.update();

      const viewW = canvas.width;
      const viewH = canvas.height;

      // Smooth camera follow target with dynamic Look-Ahead when running
      let targetCamX = engine.player.x - viewW / 2;
      let targetCamY = engine.player.y - viewH / 2;
      if (engine.player.isRunning && (engine.player.vx !== 0 || engine.player.vy !== 0)) {
        targetCamX += engine.player.vx * 16;
        targetCamY += engine.player.vy * 14;
      }

      // Add screen shake
      const shakeX = (Math.random() - 0.5) * engine.screenShake;
      const shakeY = (Math.random() - 0.5) * engine.screenShake;

      engine.cameraX += (targetCamX - engine.cameraX) * 0.15;
      engine.cameraY += (targetCamY - engine.cameraY) * 0.15;

      const camX = Math.round(engine.cameraX + shakeX);
      const camY = Math.round(engine.cameraY + shakeY);

      ctx.clearRect(0, 0, viewW, viewH);

      // Determine visible tile range
      const startTileX = Math.max(0, Math.floor(camX / TILE_SIZE));
      const endTileX = Math.min(WORLD_WIDTH - 1, Math.ceil((camX + viewW) / TILE_SIZE));
      const startTileY = Math.max(0, Math.floor(camY / TILE_SIZE));
      const endTileY = Math.min(WORLD_HEIGHT - 1, Math.ceil((camY + viewH) / TILE_SIZE));

      // 1. Render Ground Tiles
      const waterAnimFrame = Math.floor(tick / 15) % 4;
      for (let ty = startTileY; ty <= endTileY; ty++) {
        for (let tx = startTileX; tx <= endTileX; tx++) {
          const tile = engine.world.tiles[ty]?.[tx];
          if (!tile) continue;

          const screenX = tx * TILE_SIZE - camX;
          const screenY = ty * TILE_SIZE - camY;

          if (tile.type === 'water') {
            const wSprite = sprites.get('tile_water');
            if (wSprite) {
              ctx.drawImage(wSprite, waterAnimFrame * 32, 0, 32, 32, screenX, screenY, 32, 32);
            }
          } else {
            const tSprite = sprites.get(`tile_${tile.type}`);
            if (tSprite) {
              ctx.drawImage(tSprite, screenX, screenY, 32, 32);
            }
          }
        }
      }

      // 2. Render Wood Floors (placed beneath entities)
      engine.buildings.forEach((b) => {
        if (b.type === 'wood_floor') {
          const sx = b.tileX * TILE_SIZE - camX;
          const sy = b.tileY * TILE_SIZE - camY;
          if (sx >= -32 && sx <= viewW && sy >= -32 && sy <= viewH) {
            const fSprite = sprites.get('structure_wood_floor');
            if (fSprite) ctx.drawImage(fSprite, sx, sy, 32, 32);
          }
        }
      });

      // 3. Collect Depth-Sorted Entities (Y-sorting)
      interface Drawable {
        y: number;
        draw: (ctx: CanvasRenderingContext2D) => void;
      }
      const drawables: Drawable[] = [];

      // A0. Points of Interest (POIs)
      if (engine.world.pois) {
        engine.world.pois.forEach((poi) => {
          const sx = poi.x - camX;
          const sy = poi.y - camY;
          if (sx >= -64 && sx <= viewW + 64 && sy >= -64 && sy <= viewH + 64) {
            drawables.push({
              y: poi.y + 10,
              draw: (c) => {
                c.save();
                if (poi.type === 'ancient_ruins') {
                  // Weathered stone pillar ruin
                  c.fillStyle = 'rgba(0,0,0,0.3)';
                  c.beginPath();
                  c.ellipse(sx, sy + 10, 16, 6, 0, 0, Math.PI * 2);
                  c.fill();
                  // Pillar 1
                  c.fillStyle = '#64748b';
                  c.fillRect(sx - 16, sy - 24, 10, 32);
                  c.fillStyle = '#94a3b8';
                  c.fillRect(sx - 16, sy - 28, 10, 4);
                  // Pillar 2 (broken)
                  c.fillStyle = '#475569';
                  c.fillRect(sx + 6, sy - 12, 10, 20);
                  // Ancient Rune glow
                  c.fillStyle = '#38bdf8';
                  c.fillRect(sx - 12, sy - 14, 2, 4);
                  c.fillRect(sx - 14, sy - 12, 6, 2);
                } else if (poi.type === 'hidden_spring') {
                  // Spring sacred pond
                  c.fillStyle = '#0284c7';
                  c.beginPath();
                  c.ellipse(sx, sy, 22, 14, 0, 0, Math.PI * 2);
                  c.fill();
                  c.fillStyle = '#38bdf8';
                  c.beginPath();
                  c.ellipse(sx, sy - 2, 16, 9, 0, 0, Math.PI * 2);
                  c.fill();
                  // Lotus
                  c.fillStyle = '#f43f5e';
                  c.beginPath();
                  c.arc(sx, sy - 2, 4, 0, Math.PI * 2);
                  c.fill();
                } else if (poi.type === 'ancient_campfire') {
                  c.fillStyle = '#334155';
                  c.beginPath();
                  c.arc(sx, sy + 4, 12, 0, Math.PI * 2);
                  c.fill();
                  c.fillStyle = '#0f172a';
                  c.beginPath();
                  c.arc(sx, sy + 4, 8, 0, Math.PI * 2);
                  c.fill();
                  // Blue ancient ember
                  c.fillStyle = '#60a5fa';
                  c.fillRect(sx - 2, sy + 2, 4, 4);
                } else if (poi.type === 'golden_vein') {
                  c.fillStyle = '#475569';
                  c.beginPath();
                  c.ellipse(sx, sy + 4, 18, 12, 0, 0, Math.PI * 2);
                  c.fill();
                  // Gold nuggets
                  c.fillStyle = '#f59e0b';
                  c.fillRect(sx - 8, sy - 4, 5, 5);
                  c.fillRect(sx + 2, sy - 1, 6, 6);
                  c.fillRect(sx - 3, sy + 5, 5, 4);
                  c.fillStyle = '#fef08a';
                  c.fillRect(sx - 7, sy - 3, 2, 2);
                }

                // Discovered label badge
                if (poi.discovered && Math.hypot(engine.player.x - poi.x, engine.player.y - poi.y) < 140) {
                  c.font = 'bold 9px "Press Start 2P", monospace';
                  c.fillStyle = '#fef08a';
                  c.strokeStyle = '#000000';
                  c.lineWidth = 2;
                  const text = poi.nameAr;
                  const tw = c.measureText(text).width;
                  c.strokeText(text, sx - tw / 2, sy - 34);
                  c.fillText(text, sx - tw / 2, sy - 34);
                }
                c.restore();
              },
            });
          }
        });
      }

      // A. Resource Nodes
      engine.world.resources.forEach((res) => {
        if (res.harvested) return;
        const sx = res.x - camX;
        const sy = res.y - camY;

        if (sx >= -64 && sx <= viewW + 64 && sy >= -64 && sy <= viewH + 64) {
          drawables.push({
            y: res.y,
            draw: (c) => {
              const sprite = sprites.get(res.type);
              if (!sprite) return;

              // Tree canopy gentle wind sway
              let sway = 0;
              if (res.type.startsWith('tree')) {
                sway = Math.sin(tick * 0.04 + res.x) * 1.5;
              }
              // Shake on hit
              let shakeOffset = 0;
              if (res.shakeTimer && res.shakeTimer > 0) {
                res.shakeTimer--;
                shakeOffset = (Math.random() - 0.5) * 4;
              }

              const drawX = Math.round(sx - res.width / 2 + sway + shakeOffset);
              const drawY = Math.round(sy - res.height + 14);

              c.drawImage(sprite, drawX, drawY, res.width, res.height);

              // Draw subtle health bar if damaged
              if (res.health < res.maxHealth) {
                const barW = 28;
                const barH = 3;
                const bx = sx - barW / 2;
                const by = sy - res.height + 8;
                c.fillStyle = 'rgba(0,0,0,0.6)';
                c.fillRect(bx - 1, by - 1, barW + 2, barH + 2);
                c.fillStyle = '#22c55e';
                c.fillRect(bx, by, (res.health / res.maxHealth) * barW, barH);
              }
            },
          });
        }
      });

      // B. Buildings (Campfires, Walls, Doors, Chests)
      const fireAnimFrame = Math.floor(tick / 10) % 4;
      engine.buildings.forEach((b) => {
        if (b.type === 'wood_floor') return; // already drawn on floor layer

        const sx = b.tileX * TILE_SIZE - camX;
        const sy = b.tileY * TILE_SIZE - camY;
        const entityY = b.tileY * TILE_SIZE + 24;

        if (sx >= -64 && sx <= viewW + 64 && sy >= -64 && sy <= viewH + 64) {
          drawables.push({
            y: entityY,
            draw: (c) => {
              if (b.type === 'campfire') {
                const cfSprite = sprites.get('structure_campfire');
                if (cfSprite) {
                  c.drawImage(cfSprite, fireAnimFrame * 32, 0, 32, 32, sx, sy, 32, 32);
                }
              } else if (b.type === 'chest') {
                const chSprite = sprites.get('structure_chest');
                if (chSprite) {
                  const frame = b.storage ? 0 : 0; // closed by default
                  c.drawImage(chSprite, frame * 32, 0, 32, 32, sx, sy, 32, 32);
                }
              } else if (b.type === 'wood_wall') {
                const wSprite = sprites.get('structure_wood_wall');
                if (wSprite) c.drawImage(wSprite, sx, sy, 32, 32);
              } else if (b.type === 'wood_door') {
                const dSprite = sprites.get('structure_wood_door');
                if (dSprite) {
                  const frame = b.isOpen ? 1 : 0;
                  c.drawImage(dSprite, frame * 32, 0, 32, 32, sx, sy, 32, 32);
                }
              }
            },
          });
        }
      });

      // C. Dropped Items
      engine.droppedItems.forEach((di) => {
        const sx = di.x - camX;
        const sy = di.y - camY;
        if (sx >= -32 && sx <= viewW + 32 && sy >= -32 && sy <= viewH + 32) {
          drawables.push({
            y: di.y,
            draw: (c) => {
              const itemSprite = sprites.get(`item_${di.item}`);
              if (!itemSprite) return;

              // Floating bobbing motion
              const bob = Math.sin((tick + di.spawnTime % 1000) * 0.1) * 2.5;

              // Small ground shadow
              c.fillStyle = 'rgba(0,0,0,0.2)';
              c.beginPath();
              c.ellipse(sx, sy + 6, 6, 2.5, 0, 0, Math.PI * 2);
              c.fill();

              c.drawImage(itemSprite, Math.round(sx - 10), Math.round(sy - 10 + bob), 20, 20);

              // Quantity label if > 1
              if (di.count > 1) {
                c.font = 'bold 9px "Press Start 2P", monospace';
                c.fillStyle = '#fff';
                c.strokeStyle = '#000';
                c.lineWidth = 2;
                c.strokeText(`${di.count}`, sx + 4, sy + 6);
                c.fillText(`${di.count}`, sx + 4, sy + 6);
              }
            },
          });
        }
      });

      // D. Enemies
      engine.enemies.forEach((e) => {
        if (e.health <= 0) return;
        const sx = e.x - camX;
        const sy = e.y - camY;

        if (sx >= -64 && sx <= viewW + 64 && sy >= -64 && sy <= viewH + 64) {
          drawables.push({
            y: e.y,
            draw: (c) => {
              const eSprite = sprites.get(`enemy_${e.type}`);
              if (!eSprite) return;

              const drawX = Math.round(sx - e.width / 2);
              const drawY = Math.round(sy - e.height / 2);

              c.save();
              // Hurt flashing
              if (e.hurtTimer > 0) {
                c.filter = 'brightness(1.8) saturate(2)';
              }

              // Flip sprite horizontally if moving or facing left
              const isFacingLeft = e.direction === 'left' || e.vx < -0.1;
              if (isFacingLeft) {
                c.translate(sx, sy);
                c.scale(-1, 1);
                c.translate(-sx, -sy);
              }

              if (e.type === 'slime') {
                c.drawImage(eSprite, e.animFrame * 24, 0, 24, 24, drawX, drawY, 24, 24);
              } else {
                c.drawImage(eSprite, drawX, drawY, e.width, e.height);
              }
              c.restore();

              // State indicators
              if (e.state === 'sleep') {
                c.font = 'bold 10px monospace';
                c.fillStyle = '#93c5fd';
                c.fillText('zZ', sx + 4, drawY - 4);
              } else if (e.state === 'detect') {
                const alertSprite = sprites.get('enemy_alert');
                if (alertSprite) {
                  c.drawImage(alertSprite, Math.round(sx - 8), Math.round(drawY - 18), 16, 16);
                }
              }

              // Enemy health bar
              if (e.health < e.maxHealth) {
                const barW = 24;
                const barH = 2.5;
                const bx = sx - barW / 2;
                const by = drawY - 6;
                c.fillStyle = 'rgba(0,0,0,0.6)';
                c.fillRect(bx - 1, by - 1, barW + 2, barH + 2);
                c.fillStyle = '#ef4444';
                c.fillRect(bx, by, (e.health / e.maxHealth) * barW, barH);
              }
            },
          });
        }
      });

      // E. Player Character
      drawables.push({
        y: engine.player.y + 12,
        draw: (c) => {
          const px = Math.round(engine.player.x - camX);
          const py = Math.round(engine.player.y - camY);

          c.save();
          // Hurt flash
          if (engine.player.hurtFlashTimer > 0) {
            c.filter = 'brightness(1.5) sepia(1) hue-rotate(-50deg) saturate(3)';
          }

          if (engine.player.isDead) {
            const deathSprite = sprites.get('player_death');
            if (deathSprite) c.drawImage(deathSprite, px - 16, py - 8, 32, 24);
          } else if (engine.player.action === 'dodge' || engine.player.isDodging) {
            const dodgeSprite = sprites.get(`player_${engine.player.direction}_dodge`);
            if (dodgeSprite) {
              c.drawImage(dodgeSprite, px - 16, py - 16, 32, 32);
            }
          } else if (engine.player.action === 'attack') {
            const atkSprite = sprites.get(`player_${engine.player.direction}_attack`);
            if (atkSprite) c.drawImage(atkSprite, px - 16, py - 16, 32, 32);
          } else if (engine.player.action === 'swim') {
            const swimSprite = sprites.get(`player_${engine.player.direction}_swim`);
            if (swimSprite) {
              c.drawImage(swimSprite, engine.player.animFrame * 24, 0, 24, 32, px - 12, py - 16, 24, 32);
            }
          } else if (engine.player.isSwimming) {
            // Idle in water: floating with water ripples
            const swimIdleSprite = sprites.get(`player_${engine.player.direction}_swim_idle`);
            if (swimIdleSprite) c.drawImage(swimIdleSprite, px - 12, py - 16, 24, 32);
          } else if (engine.player.action === 'run') {
            const runSprite = sprites.get(`player_${engine.player.direction}_run`);
            if (runSprite) {
              c.drawImage(runSprite, engine.player.animFrame * 24, 0, 24, 32, px - 12, py - 16, 24, 32);
            }
          } else if (engine.player.action === 'walk') {
            const walkSprite = sprites.get(`player_${engine.player.direction}_walk`);
            if (walkSprite) {
              c.drawImage(walkSprite, engine.player.animFrame * 24, 0, 24, 32, px - 12, py - 16, 24, 32);
            }
          } else {
            const idleSprite = sprites.get(`player_${engine.player.direction}_idle`);
            if (idleSprite) c.drawImage(idleSprite, px - 12, py - 16, 24, 32);
          }
          c.restore();

          // Render held active tool icon near hand if walking or idle
          if (!engine.player.isDead && engine.player.activeTool && engine.player.action !== 'attack') {
            const toolSprite = sprites.get(`item_${engine.player.activeTool}`);
            if (toolSprite) {
              const offX = engine.player.direction === 'left' ? -14 : 6;
              c.drawImage(toolSprite, px + offX, py - 4, 14, 14);
            }
          }
        },
      });

      // Sort entities by Y coordinate and draw in order
      drawables.sort((a, b) => a.y - b.y);
      drawables.forEach((d) => d.draw(ctx));

      // 4. Render Particles System
      ctx.save();
      ctx.translate(-camX, -camY);
      particles.render(ctx);
      ctx.restore();

      // 5. Render Building Ghost Preview if active
      if (engine.activeBuildingGhost && hoverTile) {
        const hTileX = hoverTile.x;
        const hTileY = hoverTile.y;
        const screenGX = hTileX * TILE_SIZE - camX;
        const screenGY = hTileY * TILE_SIZE - camY;
        const isValid = engine.isValidBuildingLocation(engine.activeBuildingGhost, hTileX, hTileY);

        ctx.save();
        ctx.globalAlpha = 0.65;
        // Draw valid (green) or invalid (red) tile grid indicator
        ctx.fillStyle = isValid ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';
        ctx.strokeStyle = isValid ? '#22c55e' : '#ef4444';
        ctx.lineWidth = 2;
        ctx.fillRect(screenGX, screenGY, 32, 32);
        ctx.strokeRect(screenGX, screenGY, 32, 32);

        // Draw ghost building icon
        const ghostSprite = sprites.get(
          engine.activeBuildingGhost === 'wood_floor'
            ? 'structure_wood_floor'
            : engine.activeBuildingGhost === 'wood_wall'
            ? 'structure_wood_wall'
            : engine.activeBuildingGhost === 'wood_door'
            ? 'structure_wood_door'
            : engine.activeBuildingGhost === 'campfire'
            ? 'structure_campfire'
            : 'structure_chest'
        );
        if (ghostSprite) {
          ctx.drawImage(ghostSprite, 0, 0, 32, 32, screenGX, screenGY, 32, 32);
        }
        ctx.restore();
      }

      // 6. Dynamic Day/Night Lighting Layer
      lighting.renderLighting(
        ctx,
        viewW,
        viewH,
        camX,
        camY,
        engine.timeOfDay,
        engine.player,
        engine.buildings,
        tick
      );

      // 7. Dynamic Weather & Atmospheric Fog / Rain / Lightning
      engine.weather.render(ctx, viewW, viewH);

      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [engine, hoverTile]);

  // Pointer move for building ghost preview
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!engine.activeBuildingGhost) {
      if (hoverTile !== null) setHoverTile(null);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left + engine.cameraX;
    const clickY = e.clientY - rect.top + engine.cameraY;
    const tX = Math.floor(clickX / TILE_SIZE);
    const tY = Math.floor(clickY / TILE_SIZE);
    if (!hoverTile || hoverTile.x !== tX || hoverTile.y !== tY) {
      setHoverTile({ x: tX, y: tY });
    }
  };

  // Pointer click on canvas for building or interaction
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const worldX = e.clientX - rect.left + engine.cameraX;
    const worldY = e.clientY - rect.top + engine.cameraY;
    const tileX = Math.floor(worldX / TILE_SIZE);
    const tileY = Math.floor(worldY / TILE_SIZE);

    if (engine.activeBuildingGhost) {
      const placed = engine.placeBuilding(engine.activeBuildingGhost, tileX, tileY);
      if (placed && onSelectBuildingSlot) {
        onSelectBuildingSlot(tileX, tileY);
      }
    } else {
      // Direct attack / action towards clicked point
      engine.attack();
    }
  };

  return (
    <canvas
      ref={canvasRef}
      id="game-canvas"
      onPointerMove={handlePointerMove}
      onPointerDown={handlePointerDown}
      className="w-full h-full block select-none touch-none cursor-crosshair"
      style={{ imageRendering: 'pixelated' }}
    />
  );
};
