import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AvatarConfig, CameraMode, EmoteId, FriendProfile, GameStats, LightingPreset, StudioPart, StudioScript, WorldId } from '../types/game';
import { CustomStudioMeta, getWorldById } from '../engine/worlds';
import { createAvatarRig, AvatarRig } from '../engine/avatar';
import { createCheckerTexture, createLavaTexture, createStudTexture } from '../engine/textures';
import { soundEngine } from '../engine/audio';
import {
  CompiledScriptRunner,
  ScriptApi,
  ScriptPartState,
  compileStudioScript,
} from '../engine/studioModelsAndScripts';
import { voiceEngine } from '../engine/voice';

interface GameCanvasProps {
  worldId: WorldId;
  customParts: StudioPart[];
  customMeta?: CustomStudioMeta;
  customScripts?: StudioScript[];
  partyMembers?: FriendProfile[];
  lighting: LightingPreset;
  cameraMode: CameraMode;
  avatarConfig: AvatarConfig;
  playerName: string;
  isPlus?: boolean;
  voiceActive?: boolean;
  chatBubble?: { id: number; text: string } | null;
  activeEmote: EmoteId | null;
  cameraSensitivity: number;
  resetSignal: number;
  touchInputRef: React.MutableRefObject<{ moveX: number; moveZ: number; jump: boolean; sprint: boolean }>;
  onClearEmote: () => void;
  onScriptSay?: (text: string) => void;
  onStatsUpdate: (stats: GameStats) => void;
}

interface RuntimePlatform {
  def: ReturnType<typeof getWorldById>['platforms'][number];
  mesh: THREE.Mesh;
  prevX: number;
  prevY: number;
  prevZ: number;
}

interface RuntimeSweeper {
  def: ReturnType<typeof getWorldById>['sweepers'][number];
  pivot: THREE.Group;
  angle: number;
}

interface RuntimeCoin {
  id: string;
  mesh: THREE.Group;
  collected: boolean;
  baseY: number;
}

interface RuntimeNpc {
  rig: AvatarRig;
  homeX: number;
  homeY: number;
  homeZ: number;
  radius: number;
  phase: number;
  speed: number;
  emote: EmoteId;
  walkStyle: AvatarConfig['walkAnim'];
}

const NPC_PRESETS: { name: string; avatar: AvatarConfig; emote: EmoteId; phase: number }[] = [
  {
    name: 'rusia4644',
    emote: 'wave',
    phase: 0.4,
    avatar: {
      skinColor: '#fde047',
      shirtColor: '#2563eb',
      pantsColor: '#1e293b',
      hairStyle: 'spiky',
      hairColor: '#18181b',
      shoeColor: '#ffffff',
      shoeStyle: 'sneakers',
      hatColor: '#ef4444',
      hatStyle: 'cap',
      hasWings: false,
      hasSword: false,
      headless: false,
      effect: 'none',
      makeup: 'none',
      bodyScale: 1.0,
      bgStyle: 'studio',
      idleAnim: 'cool',
      walkAnim: 'hero',
      jumpAnim: 'default',
    },
  },
  {
    name: 'AIM',
    emote: 'dance',
    phase: 2.1,
    avatar: {
      skinColor: '#fed7aa',
      shirtColor: '#dc2626',
      pantsColor: '#0f172a',
      hairStyle: 'messy',
      hairColor: '#7c2d12',
      shoeColor: '#eab308',
      shoeStyle: 'gold',
      hatColor: '#eab308',
      hatStyle: 'crown',
      hasWings: true,
      hasSword: false,
      headless: false,
      effect: 'sparkle',
      makeup: 'stars',
      bodyScale: 1.0,
      bgStyle: 'studio',
      idleAnim: 'hero',
      walkAnim: 'bouncy',
      jumpAnim: 'default',
    },
  },
  {
    name: '111',
    emote: 'clap',
    phase: 4.0,
    avatar: {
      skinColor: '#d97706',
      shirtColor: '#16a34a',
      pantsColor: '#1e293b',
      hairStyle: 'bob',
      hairColor: '#18181b',
      shoeColor: '#09090b',
      shoeStyle: 'boots',
      hatColor: '#1e293b',
      hatStyle: 'domino',
      hasWings: false,
      hasSword: true,
      headless: false,
      effect: 'none',
      makeup: 'kawaii',
      bodyScale: 0.78,
      bgStyle: 'studio',
      idleAnim: 'bounce',
      walkAnim: 'ninja',
      jumpAnim: 'default',
    },
  },
];

const _camDesired = new THREE.Vector3();
const _camLookTarget = new THREE.Vector3();
const _playerCenter = new THREE.Vector3();

const LIGHTING_CONFIGS: Record<
  LightingPreset,
  {
    skyDay: string;
    skyLava: string;
    hemiSky: number;
    hemiGround: number;
    hemiIntensity: number;
    keyColor: number;
    keyIntensity: number;
  }
> = {
  day: {
    skyDay: '#7dd3fc',
    skyLava: '#451a03',
    hemiSky: 0xe0f2fe,
    hemiGround: 0x334155,
    hemiIntensity: 0.9,
    keyColor: 0xfff7ed,
    keyIntensity: 1.65,
  },
  sunset: {
    skyDay: '#fb923c',
    skyLava: '#3b0764',
    hemiSky: 0xfed7aa,
    hemiGround: 0x312e81,
    hemiIntensity: 0.85,
    keyColor: 0xfdba74,
    keyIntensity: 1.7,
  },
  night: {
    skyDay: '#0f172a',
    skyLava: '#1e1b4b',
    hemiSky: 0x60a5fa,
    hemiGround: 0x0f172a,
    hemiIntensity: 0.65,
    keyColor: 0xc7d2fe,
    keyIntensity: 1.35,
  },
};

function buildCompositeTree(x: number, y: number, z: number, scale: number, leafColor: string): THREE.Group {
  const group = new THREE.Group();
  group.position.set(x, y, z);
  group.scale.setScalar(scale);

  const barkMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.85, metalness: 0.02 });
  const leafMat = new THREE.MeshStandardMaterial({ color: leafColor, roughness: 0.55, metalness: 0.04 });

  const rootBase = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.35, 1.1), barkMat);
  rootBase.position.y = 0.175;
  rootBase.castShadow = true;
  rootBase.receiveShadow = true;

  const trunk = new THREE.Mesh(new THREE.BoxGeometry(0.65, 2.2, 0.65), barkMat);
  trunk.position.y = 1.25;
  trunk.castShadow = true;

  const c1 = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.1, 2.4), leafMat);
  c1.position.y = 2.6;
  c1.castShadow = true;

  const c2 = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.95, 1.8), leafMat);
  c2.position.y = 3.5;
  c2.castShadow = true;

  const c3 = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.7, 1.05), leafMat);
  c3.position.y = 4.2;
  c3.castShadow = true;

  group.add(rootBase, trunk, c1, c2, c3);
  return group;
}

function buildCompositeBuilding(b: ReturnType<typeof getWorldById>['buildings'][number]): THREE.Group {
  const group = new THREE.Group();
  group.position.set(b.x, b.y, b.z);

  const wallMat = new THREE.MeshStandardMaterial({ color: b.wallColor, roughness: 0.55, metalness: 0.05 });
  const roofMat = new THREE.MeshStandardMaterial({ color: b.roofColor, roughness: 0.4, metalness: 0.1 });
  const glassMat = new THREE.MeshStandardMaterial({ color: '#38bdf8', roughness: 0.12, metalness: 0.35 });
  const doorMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.45, metalness: 0.25 });

  const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat);
  body.position.y = b.h / 2;
  body.castShadow = true;
  body.receiveShadow = true;

  const roof = new THREE.Mesh(new THREE.BoxGeometry(b.w + 0.5, 0.7, b.d + 0.5), roofMat);
  roof.position.y = b.h + 0.35;
  roof.castShadow = true;

  const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.2, 0.2), doorMat);
  door.position.set(0, 1.1, b.d / 2 + 0.05);

  const win1 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.1, 0.2), glassMat);
  win1.position.set(-1.5, 3.3, b.d / 2 + 0.05);
  const win2 = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.1, 0.2), glassMat);
  win2.position.set(1.5, 3.3, b.d / 2 + 0.05);

  group.add(body, roof, door, win1, win2);
  return group;
}

function buildCompositeFinishTrophy(x: number, y: number, z: number): THREE.Group {
  const group = new THREE.Group();
  group.position.set(x, y, z);

  const baseMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.35, metalness: 0.5 });
  const goldMat = new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.18, metalness: 0.88 });
  const glowMat = new THREE.MeshStandardMaterial({
    color: '#38bdf8',
    emissive: '#38bdf8',
    emissiveIntensity: 0.7,
    roughness: 0.2,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.45, 2.6), baseMat);
  base.position.y = 0.225;
  base.castShadow = true;

  const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.65, 1.2, 8), baseMat);
  pillar.position.y = 1.05;

  const cupGroup = new THREE.Group();
  cupGroup.position.y = 2.35;
  const cupStem = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.32, 0.55, 12), goldMat);
  cupStem.position.y = -0.35;
  const cupBowl = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.36, 0.85, 12), goldMat);
  cupBowl.position.y = 0.25;
  const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.32, 0), glowMat);
  gem.position.y = 0.95;
  cupGroup.add(cupStem, cupBowl, gem);
  cupGroup.userData.spin = true;

  group.add(base, pillar, cupGroup);
  return group;
}

function buildCompositeCoin(x: number, y: number, z: number): THREE.Group {
  const group = new THREE.Group();
  group.position.set(x, y, z);

  const goldMat = new THREE.MeshStandardMaterial({ color: '#facc15', roughness: 0.16, metalness: 0.88 });
  const rimMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.3, metalness: 0.75 });

  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.56, 0.56, 0.18, 20), goldMat);
  disc.rotation.z = Math.PI / 2;
  disc.castShadow = true;

  const inner = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.42, 0.42), rimMat);
  group.add(disc, inner);
  return group;
}

interface RuntimeScriptInstance {
  platform: RuntimePlatform | null;
  partProxy: ScriptPartState;
  baseState: ScriptPartState;
  lastColor: string;
  runner: CompiledScriptRunner;
  lastTouchAt: number;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  worldId,
  customParts,
  customMeta,
  customScripts = [],
  partyMembers = [],
  lighting,
  cameraMode,
  avatarConfig,
  playerName,
  isPlus = false,
  voiceActive = false,
  chatBubble,
  activeEmote,
  cameraSensitivity,
  resetSignal,
  touchInputRef,
  onClearEmote,
  onScriptSay,
  onStatsUpdate,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [contextLost, setContextLost] = useState(false);

  const avatarConfigRef = useRef(avatarConfig);
  const playerNameRef = useRef(playerName);
  const isPlusRef = useRef(isPlus);
  const activeEmoteRef = useRef(activeEmote);
  const emoteElapsedRef = useRef(0);
  const lightingRef = useRef(lighting);
  const cameraModeRef = useRef(cameraMode);
  const worldIdRef = useRef(worldId);
  const customPartsRef = useRef(customParts);
  const customMetaRef = useRef(customMeta);
  const customScriptsRef = useRef(customScripts);
  const partyMembersRef = useRef(partyMembers);
  const voiceActiveRef = useRef(voiceActive);
  const sensitivityRef = useRef(cameraSensitivity);
  const onClearEmoteRef = useRef(onClearEmote);
  const onScriptSayRef = useRef(onScriptSay);
  const onStatsRef = useRef(onStatsUpdate);

  avatarConfigRef.current = avatarConfig;
  playerNameRef.current = playerName;
  isPlusRef.current = isPlus;
  lightingRef.current = lighting;
  cameraModeRef.current = cameraMode;
  worldIdRef.current = worldId;
  customPartsRef.current = customParts;
  customMetaRef.current = customMeta;
  customScriptsRef.current = customScripts;
  partyMembersRef.current = partyMembers;
  voiceActiveRef.current = voiceActive;
  sensitivityRef.current = cameraSensitivity;
  onClearEmoteRef.current = onClearEmote;
  onScriptSayRef.current = onScriptSay;
  onStatsRef.current = onStatsUpdate;

  if (activeEmoteRef.current !== activeEmote) {
    activeEmoteRef.current = activeEmote;
    emoteElapsedRef.current = 0;
  }

  const sceneActionsRef = useRef<{
    loadWorld: (id: WorldId) => void;
    updateAvatar: (cfg: AvatarConfig) => void;
    updateNameTag: (name: string, plus?: boolean) => void;
    showChatBubble: (text: string | null) => void;
    updateLighting: (preset: LightingPreset) => void;
    resetPlayer: () => void;
  } | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probeCanvas = document.createElement('canvas');
        const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const handleContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      60,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.1,
      420
    );

    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x334155, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff7ed, 1.65);
    keyLight.position.set(35, 65, 30);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1536, 1536);
    keyLight.shadow.camera.near = 5;
    keyLight.shadow.camera.far = 190;
    const d = 55;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);
    scene.add(keyLight.target);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.55);
    rimLight.position.set(-40, 30, -50);
    scene.add(rimLight);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const studTex = createStudTexture(maxAniso);
    const checkerTex = createCheckerTexture(maxAniso);
    const lavaTex = createLavaTexture(maxAniso);

    const avatar: AvatarRig = createAvatarRig(avatarConfigRef.current, playerNameRef.current);
    avatar.setNameTag(playerNameRef.current, isPlusRef.current);
    scene.add(avatar.root);

    const contactShadowGeo = new THREE.CircleGeometry(0.68, 24);
    const contactShadowMat = new THREE.MeshBasicMaterial({
      color: 0x020617,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    });
    const contactShadow = new THREE.Mesh(contactShadowGeo, contactShadowMat);
    contactShadow.rotation.x = -Math.PI / 2;
    scene.add(contactShadow);

    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0.0 });
    const cloudGeo = new THREE.BoxGeometry(1, 1, 1);
    const cloudCount = 32;
    const cloudInst = new THREE.InstancedMesh(cloudGeo, cloudMat, cloudCount);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < cloudCount; i++) {
      const cx = Math.sin(i * 2.13) * 140;
      const cy = 28 + (i % 5) * 4.5;
      const cz = -i * 6 + 30;
      dummy.position.set(cx, cy, cz);
      dummy.scale.set(9 + (i % 4) * 3, 2.2 + (i % 2), 6 + (i % 3) * 2);
      dummy.updateMatrix();
      cloudInst.setMatrixAt(i, dummy.matrix);
    }
    cloudInst.computeBoundingSphere();
    scene.add(cloudInst);

    let currentWorld = getWorldById(worldIdRef.current, customPartsRef.current, customMetaRef.current);
    let runtimePlatforms: RuntimePlatform[] = [];
    let runtimeSweepers: RuntimeSweeper[] = [];
    let runtimeCoins: RuntimeCoin[] = [];
    let runtimeNpcs: RuntimeNpc[] = [];
    let runtimeScripts: RuntimeScriptInstance[] = [];
    let runtimeMoveSpeed: number | null = null;
    let runtimeJumpVel: number | null = null;
    let runtimeGravity: number | null = null;
    const scriptPlayerRef = { x: 0, y: 0, z: 0 };
    let finishGroup: THREE.Group | null = null;
    let seaMesh: THREE.Mesh | null = null;

    const playerPos = new THREE.Vector3(...currentWorld.spawn);
    const checkpointPos = new THREE.Vector3(...currentWorld.spawn);
    let velY = 0;
    let isGrounded = false;
    let coyoteTimer = 0;
    let jumpBuffer = 0;
    let stage = 1;
    let totalStages = 1;
    let collectedCoins = 0;
    let falls = 0;
    let health = 100;
    let elapsedSeconds = 0;
    let completed = false;
    let lastStatsEmit = 0;

    let camYaw = 0;
    let camPitch = 0.42;
    let camDist = 12.5;
    let isDragging = false;
    let lastPtrX = 0;
    let lastPtrY = 0;

    const keys: Record<string, boolean> = {};

    const emitStats = (force = false) => {
      const now = performance.now();
      if (!force && now - lastStatsEmit < 120) return;
      lastStatsEmit = now;
      onStatsRef.current({
        stage,
        totalStages,
        coins: collectedCoins,
        totalCoins: runtimeCoins.length,
        elapsedSeconds,
        falls,
        completed,
        health,
      });
    };

    const applyLighting = (preset: LightingPreset) => {
      const cfg = LIGHTING_CONFIGS[preset];
      const bgHex = currentWorld.isLavaSea ? cfg.skyLava : cfg.skyDay;
      scene.background = new THREE.Color(bgHex);
      scene.fog = new THREE.Fog(bgHex, 55, 220);
      hemiLight.color.setHex(cfg.hemiSky);
      hemiLight.groundColor.setHex(cfg.hemiGround);
      hemiLight.intensity = cfg.hemiIntensity;
      keyLight.color.setHex(cfg.keyColor);
      keyLight.intensity = cfg.keyIntensity;
    };

    const clearWorldGroup = () => {
      for (const npc of runtimeNpcs) {
        worldGroup.remove(npc.rig.root);
        npc.rig.dispose();
      }
      runtimeNpcs = [];
      while (worldGroup.children.length > 0) {
        const child = worldGroup.children[0];
        worldGroup.remove(child);
        child.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            const m = obj as THREE.Mesh;
            m.geometry?.dispose();
            if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
            else if (m.material) m.material.dispose();
          }
        });
      }
      runtimePlatforms = [];
      runtimeSweepers = [];
      runtimeCoins = [];
      runtimeScripts = [];
      runtimeMoveSpeed = null;
      runtimeJumpVel = null;
      runtimeGravity = null;
      finishGroup = null;
      seaMesh = null;
    };

    const buildWorld = (id: WorldId) => {
      clearWorldGroup();
      currentWorld = getWorldById(id, customPartsRef.current, customMetaRef.current);
      applyLighting(lightingRef.current);

      const seaGeo = new THREE.PlaneGeometry(650, 650);
      const seaMat = currentWorld.isLavaSea
        ? new THREE.MeshStandardMaterial({
            map: lavaTex,
            emissive: '#ea580c',
            emissiveMap: lavaTex,
            emissiveIntensity: 0.75,
            roughness: 0.45,
          })
        : new THREE.MeshStandardMaterial({
            color: currentWorld.seaColor,
            emissive: currentWorld.seaEmissive,
            emissiveIntensity: 0.12,
            roughness: 0.22,
            metalness: 0.15,
          });
      seaMesh = new THREE.Mesh(seaGeo, seaMat);
      seaMesh.rotation.x = -Math.PI / 2;
      seaMesh.position.y = currentWorld.seaY;
      seaMesh.receiveShadow = true;
      worldGroup.add(seaMesh);

      const spireCount = 24;
      const spireGeo = new THREE.BoxGeometry(1, 1, 1);
      const spireMat = new THREE.MeshStandardMaterial({
        color: currentWorld.isLavaSea ? '#1e293b' : '#38bdf8',
        roughness: 0.8,
      });
      const spireInst = new THREE.InstancedMesh(spireGeo, spireMat, spireCount);
      for (let i = 0; i < spireCount; i++) {
        const angle = (i / spireCount) * Math.PI * 2;
        const rad = 115 + (i % 3) * 28;
        const sx = Math.cos(angle) * rad;
        const sz = Math.sin(angle) * rad - 55;
        const sh = 12 + (i % 5) * 7;
        dummy.position.set(sx, currentWorld.seaY + sh / 2 - 1, sz);
        dummy.scale.set(12 + (i % 4) * 5, sh, 12 + ((i + 1) % 4) * 5);
        dummy.updateMatrix();
        spireInst.setMatrixAt(i, dummy.matrix);
      }
      spireInst.computeBoundingSphere();
      worldGroup.add(spireInst);

      let maxStage = 1;
      for (const p of currentWorld.platforms) {
        if (p.stageIndex && p.stageIndex > maxStage) maxStage = p.stageIndex;

        const geo = new THREE.BoxGeometry(p.w, p.h, p.d);
        let mat: THREE.MeshStandardMaterial;

        if (p.kind === 'finish') {
          const tex = checkerTex.clone();
          tex.needsUpdate = true;
          tex.repeat.set(Math.max(1, Math.round(p.w / 2)), Math.max(1, Math.round(p.d / 2)));
          mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.3, metalness: 0.1 });
        } else if (p.kind === 'hazard') {
          mat = new THREE.MeshStandardMaterial({
            color: p.color,
            emissive: p.color,
            emissiveIntensity: 0.65,
            roughness: 0.35,
          });
        } else {
          const tex = studTex.clone();
          tex.needsUpdate = true;
          tex.repeat.set(Math.max(1, Math.round(p.w / 2)), Math.max(1, Math.round(p.d / 2)));
          mat = new THREE.MeshStandardMaterial({
            color: p.color,
            map: tex,
            roughness: p.kind === 'grass' ? 0.72 : 0.36,
            metalness: p.kind === 'bounce' ? 0.3 : 0.05,
            emissive: p.kind === 'bounce' ? p.color : '#000000',
            emissiveIntensity: p.kind === 'bounce' ? 0.25 : 0,
          });
        }

        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(p.x, p.y, p.z);
        mesh.rotation.set(
          THREE.MathUtils.degToRad(p.rx ?? 0),
          THREE.MathUtils.degToRad(p.ry ?? 0),
          THREE.MathUtils.degToRad(p.rz ?? 0)
        );
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        worldGroup.add(mesh);

        if (p.kind === 'checkpoint') {
          const ringMesh = new THREE.Mesh(
            new THREE.BoxGeometry(p.w * 0.48, 0.14, p.d * 0.48),
            new THREE.MeshStandardMaterial({
              color: '#4ade80',
              emissive: '#22c55e',
              emissiveIntensity: 0.55,
              roughness: 0.25,
            })
          );
          ringMesh.position.set(p.x, p.y + p.h / 2 + 0.07, p.z);
          worldGroup.add(ringMesh);
        }

        if (p.kind === 'bounce') {
          const padMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(p.w * 0.36, p.w * 0.4, 0.18, 20),
            new THREE.MeshStandardMaterial({
              color: '#e0f2fe',
              emissive: '#38bdf8',
              emissiveIntensity: 0.6,
              roughness: 0.2,
            })
          );
          padMesh.position.set(p.x, p.y + p.h / 2 + 0.09, p.z);
          worldGroup.add(padMesh);
        }

        if (p.kind === 'finish') {
          finishGroup = buildCompositeFinishTrophy(p.x, p.y + p.h / 2, p.z);
          worldGroup.add(finishGroup);
        }

        runtimePlatforms.push({ def: p, mesh, prevX: p.x, prevY: p.y, prevZ: p.z });
      }

      for (const s of currentWorld.sweepers) {
        const pivot = new THREE.Group();
        pivot.position.set(s.x, s.y, s.z);
        const hub = new THREE.Mesh(
          new THREE.CylinderGeometry(0.55, 0.65, 0.9, 14),
          new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.35, metalness: 0.6 })
        );
        const bar = new THREE.Mesh(
          new THREE.BoxGeometry(s.length, s.thickness, s.thickness),
          new THREE.MeshStandardMaterial({
            color: s.color,
            emissive: s.color,
            emissiveIntensity: 0.35,
            roughness: 0.3,
          })
        );
        bar.castShadow = true;
        pivot.add(hub, bar);
        worldGroup.add(pivot);
        runtimeSweepers.push({ def: s, pivot, angle: 0 });
      }

      for (const c of currentWorld.coins) {
        const coinGroup = buildCompositeCoin(c.x, c.y, c.z);
        worldGroup.add(coinGroup);
        runtimeCoins.push({ id: c.id, mesh: coinGroup, collected: false, baseY: c.y });
      }

      for (const t of currentWorld.trees) {
        worldGroup.add(buildCompositeTree(t.x, t.y, t.z, t.scale, t.leafColor));
      }
      for (const b of currentWorld.buildings) {
        worldGroup.add(buildCompositeBuilding(b));
      }

      // Spawn party members (up to 12+) or default 3 animated NPC players with floating nametags
      const startPlat = currentWorld.platforms[0];
      if (startPlat) {
        const floorY = startPlat.y + startPlat.h / 2;
        const activeParty = partyMembersRef.current || [];
        if (activeParty.length > 0) {
          const maxSpan = Math.max(1.8, Math.min(startPlat.w, startPlat.d) * 0.42);
          const emotes: EmoteId[] = ['wave', 'dance', 'clap', 'spin', 'salute', 'sit'];
          activeParty.forEach((pm, idx) => {
            const rig = createAvatarRig(pm.avatar, pm.name);
            const ring = idx < 6 ? 0.62 : 0.98;
            const totalInRing = idx < 6 ? Math.min(6, activeParty.length) : Math.max(1, activeParty.length - 6);
            const idxInRing = idx < 6 ? idx : idx - 6;
            const angle = (idxInRing / totalInRing) * Math.PI * 2 + (idx < 6 ? 0.2 : 0.65);
            const rad = maxSpan * ring;
            const hx = startPlat.x + Math.cos(angle) * rad;
            const hz = startPlat.z + Math.sin(angle) * rad;
            rig.root.position.set(hx, floorY, hz);
            rig.root.rotation.y = Math.atan2(startPlat.x - hx, startPlat.z - hz);
            worldGroup.add(rig.root);
            runtimeNpcs.push({
              rig,
              homeX: hx,
              homeY: floorY,
              homeZ: hz,
              radius: Math.min(0.65, maxSpan * 0.16),
              phase: idx * 0.75,
              speed: 0.7 + (idx % 4) * 0.15,
              emote: emotes[idx % emotes.length],
              walkStyle: pm.avatar.walkAnim,
            });
          });
        } else {
          const safeRad = Math.min(2.6, Math.max(1.1, Math.min(startPlat.w, startPlat.d) * 0.25));
          const offsets: [number, number][] = [
            [-safeRad, -safeRad * 0.65],
            [safeRad, -safeRad * 0.65],
            [safeRad * 0.75, safeRad * 0.6],
          ];
          NPC_PRESETS.forEach((npc, idx) => {
            const rig = createAvatarRig(npc.avatar, npc.name);
            const [ox, oz] = offsets[idx % offsets.length];
            const hx = startPlat.x + ox;
            const hz = startPlat.z + oz;
            rig.root.position.set(hx, floorY, hz);
            rig.root.rotation.y = idx === 0 ? 0.5 : idx === 1 ? -0.6 : Math.PI * 0.85;
            worldGroup.add(rig.root);
            runtimeNpcs.push({
              rig,
              homeX: hx,
              homeY: floorY,
              homeZ: hz,
              radius: Math.min(1.0, safeRad * 0.45),
              phase: npc.phase,
              speed: 0.8 + idx * 0.18,
              emote: npc.emote,
              walkStyle: npc.avatar.walkAnim,
            });
          });
        }
      }

      // Compile Studio Scripts when running custom studio map
      if (id === 'custom' && customScriptsRef.current.length > 0) {
        for (const sc of customScriptsRef.current) {
          if (!sc.enabled) continue;
          const targets =
            sc.targetPartId === 'all'
              ? runtimePlatforms.filter((rp) => rp.def.id !== 'baseplate')
              : runtimePlatforms.filter((rp) => rp.def.id === sc.targetPartId);
          const effectiveTargets: (RuntimePlatform | null)[] =
            targets.length > 0 ? targets : [null];

          for (const rp of effectiveTargets) {
            const baseState: ScriptPartState = rp
              ? {
                  x: rp.def.x,
                  y: rp.def.y,
                  z: rp.def.z,
                  rx: rp.def.rx ?? 0,
                  ry: rp.def.ry ?? 0,
                  rz: rp.def.rz ?? 0,
                  color: rp.def.color,
                }
              : { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, color: '#ffffff' };
            const partProxy: ScriptPartState = { ...baseState };

            const api: ScriptApi = {
              setSpeed: (speed) => {
                if (Number.isFinite(speed)) runtimeMoveSpeed = Math.max(2, Math.min(40, speed));
              },
              setJumpPower: (vel) => {
                if (Number.isFinite(vel)) runtimeJumpVel = Math.max(4, Math.min(45, vel));
              },
              setGravity: (g) => {
                if (Number.isFinite(g)) runtimeGravity = Math.max(5, Math.min(70, g));
              },
              giveCoins: (count) => {
                const n = Math.round(count || 1);
                if (n > 0) {
                  collectedCoins += n;
                  soundEngine.playCoin();
                  emitStats(true);
                }
              },
              teleport: (tx, ty, tz) => {
                if (Number.isFinite(tx) && Number.isFinite(ty) && Number.isFinite(tz)) {
                  playerPos.set(tx, ty, tz);
                  velY = 0;
                }
              },
              heal: (hp) => {
                if (Number.isFinite(hp)) {
                  health = Math.max(1, Math.min(100, hp));
                  emitStats(true);
                }
              },
              respawn: () => {
                respawnAtCheckpoint(false);
              },
              say: (text) => {
                const clean = String(text || '').slice(0, 80);
                if (clean) {
                  avatar.setChatBubble(clean);
                  onScriptSayRef.current?.(clean);
                }
              },
              setColor: (hex) => {
                partProxy.color = hex;
              },
              setRainbow: (hueOffset) => {
                const c = new THREE.Color().setHSL(((hueOffset % 1) + 1) % 1, 0.85, 0.55);
                partProxy.color = `#${c.getHexString()}`;
              },
              log: () => {},
            };

            const compiled = compileStudioScript(sc, partProxy, { ...baseState }, api, scriptPlayerRef);
            if (compiled.runner) {
              runtimeScripts.push({
                platform: rp,
                partProxy,
                baseState,
                lastColor: baseState.color,
                runner: compiled.runner,
                lastTouchAt: -10,
              });
            }
          }
        }
      }

      totalStages = maxStage;
      stage = 1;
      collectedCoins = 0;
      falls = 0;
      health = 100;
      elapsedSeconds = 0;
      completed = false;
      checkpointPos.set(...currentWorld.spawn);
      playerPos.set(...currentWorld.spawn);
      avatar.root.position.copy(playerPos);
      avatar.root.rotation.y = Math.PI;
      velY = 0;
      isGrounded = false;
      camYaw = 0;
      camPitch = 0.42;
      emitStats(true);
    };

    buildWorld(worldIdRef.current);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    sceneActionsRef.current = {
      loadWorld: (id: WorldId) => buildWorld(id),
      updateAvatar: (cfg: AvatarConfig) => avatar.updateAppearance(cfg),
      updateNameTag: (name: string, plus?: boolean) => avatar.setNameTag(name, plus),
      showChatBubble: (text: string | null) => avatar.setChatBubble(text),
      updateLighting: (preset: LightingPreset) => applyLighting(preset),
      resetPlayer: () => {
        checkpointPos.set(...currentWorld.spawn);
        playerPos.copy(checkpointPos);
        velY = 0;
        stage = 1;
        falls = 0;
        health = 100;
        elapsedSeconds = 0;
        completed = false;
        collectedCoins = 0;
        for (const c of runtimeCoins) {
          c.collected = false;
          c.mesh.visible = true;
        }
        emitStats(true);
      },
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      soundEngine.unlock();
      keys[e.code] = true;
      if (e.code === 'Space') {
        jumpBuffer = 0.14;
        e.preventDefault();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    const canvas = renderer.domElement;
    const onPointerDown = (e: PointerEvent) => {
      soundEngine.unlock();
      isDragging = true;
      lastPtrX = e.clientX;
      lastPtrY = e.clientY;
    };
    const onPointerUp = () => {
      isDragging = false;
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const sens = sensitivityRef.current * 0.0055;
      camYaw -= (e.clientX - lastPtrX) * sens;
      camPitch = THREE.MathUtils.clamp(camPitch + (e.clientY - lastPtrY) * sens * 0.85, -0.35, 1.25);
      lastPtrX = e.clientX;
      lastPtrY = e.clientY;
    };
    const onWheel = (e: WheelEvent) => {
      camDist = THREE.MathUtils.clamp(camDist + e.deltaY * 0.01, 5, 26);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    canvas.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('wheel', onWheel, { passive: true });

    const onResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const status = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (status === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const respawnAtCheckpoint = (isFall: boolean) => {
      soundEngine.playOof();
      if (isFall) falls += 1;
      health = Math.max(0, health - 25);
      if (health <= 0) health = 100;
      playerPos.copy(checkpointPos);
      velY = 0;
      isGrounded = false;
      emitStats(true);
    };

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;

      if (!completed) elapsedSeconds += dt;

      if (currentWorld.isLavaSea) {
        lavaTex.offset.x = t * 0.03;
        lavaTex.offset.y = t * 0.02;
      }

      scriptPlayerRef.x = playerPos.x;
      scriptPlayerRef.y = playerPos.y;
      scriptPlayerRef.z = playerPos.z;

      for (const p of runtimePlatforms) {
        p.prevX = p.mesh.position.x;
        p.prevY = p.mesh.position.y;
        p.prevZ = p.mesh.position.z;
        if (p.def.kind === 'moving' && p.def.moveRange) {
          const offset = Math.sin(t * (p.def.moveSpeed || 1.5) + (p.def.movePhase || 0)) * p.def.moveRange;
          if (p.def.moveAxis === 'x') p.mesh.position.x = p.def.x + offset;
          if (p.def.moveAxis === 'y') p.mesh.position.y = p.def.y + offset;
          if (p.def.moveAxis === 'z') p.mesh.position.z = p.def.z + offset;
        }
      }

      // Run Studio onTick scripts
      for (const rs of runtimeScripts) {
        if (rs.runner.onTick) {
          try {
            rs.runner.onTick(dt, t);
          } catch {
            // Ignore runtime script errors during frame tick
          }
        }
        if (rs.platform) {
          rs.platform.mesh.position.set(rs.partProxy.x, rs.partProxy.y, rs.partProxy.z);
          rs.platform.mesh.rotation.set(
            THREE.MathUtils.degToRad(rs.partProxy.rx),
            THREE.MathUtils.degToRad(rs.partProxy.ry),
            THREE.MathUtils.degToRad(rs.partProxy.rz)
          );
          if (rs.partProxy.color !== rs.lastColor) {
            rs.lastColor = rs.partProxy.color;
            const mat = rs.platform.mesh.material;
            if (mat instanceof THREE.MeshStandardMaterial) {
              mat.color.set(rs.partProxy.color);
            }
          }
        }
      }

      for (const s of runtimeSweepers) {
        s.angle += s.def.speed * dt;
        s.pivot.rotation.y = s.angle;
      }

      if (finishGroup) {
        for (const child of finishGroup.children) {
          if (child.userData.spin) child.rotation.y += dt * 1.8;
        }
      }

      // Animate NPC companions with floating nametags
      for (const npc of runtimeNpcs) {
        const cycle = (t * npc.speed + npc.phase) % 9.0;
        if (cycle < 4.5) {
          const ang = t * npc.speed + npc.phase;
          const nx = npc.homeX + Math.cos(ang) * npc.radius;
          const nz = npc.homeZ + Math.sin(ang) * npc.radius;
          const dx = nx - npc.rig.root.position.x;
          const dz = nz - npc.rig.root.position.z;
          npc.rig.root.position.set(nx, npc.homeY, nz);
          if (Math.hypot(dx, dz) > 0.001) {
            npc.rig.root.rotation.y = Math.atan2(dx, dz);
          }
          npc.rig.updateAnimation(dt, 0.55, true, 0, npc.walkStyle, 'default', null, 0);
        } else {
          npc.rig.updateAnimation(dt, 0, true, 0, npc.walkStyle, 'default', npc.emote, cycle - 4.5);
        }
      }

      const touch = touchInputRef.current;
      if (touch.jump) {
        jumpBuffer = 0.14;
        touch.jump = false;
      }

      let mx = (keys['KeyD'] || keys['ArrowRight'] ? 1 : 0) - (keys['KeyA'] || keys['ArrowLeft'] ? 1 : 0) + touch.moveX;
      let mz = (keys['KeyS'] || keys['ArrowDown'] ? 1 : 0) - (keys['KeyW'] || keys['ArrowUp'] ? 1 : 0) + touch.moveZ;
      const mag = Math.hypot(mx, mz);
      if (mag > 1) {
        mx /= mag;
        mz /= mag;
      }

      const isSprinting = !!(keys['ShiftLeft'] || keys['ShiftRight'] || touch.sprint);
      const baseSpeed = runtimeMoveSpeed ?? 10.2;
      const moveSpeed = isSprinting ? baseSpeed * 1.37 : baseSpeed;
      const horizontalMag = Math.min(1, mag);

      if (horizontalMag > 0.02) {
        const moveAngle = Math.atan2(mx, mz) + camYaw;
        playerPos.x += Math.sin(moveAngle) * moveSpeed * horizontalMag * dt;
        playerPos.z += Math.cos(moveAngle) * moveSpeed * horizontalMag * dt;

        let diff = moveAngle - avatar.root.rotation.y;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        avatar.root.rotation.y += diff * Math.min(1, dt * 14);
      }

      if (isGrounded) coyoteTimer = 0.12;
      else coyoteTimer = Math.max(0, coyoteTimer - dt);

      if (jumpBuffer > 0) jumpBuffer = Math.max(0, jumpBuffer - dt);

      if (jumpBuffer > 0 && coyoteTimer > 0) {
        velY = runtimeJumpVel ?? 14.8;
        isGrounded = false;
        coyoteTimer = 0;
        jumpBuffer = 0;
        soundEngine.playJump();
      }

      velY -= (runtimeGravity ?? 32.0) * dt;
      playerPos.y += velY * dt;

      const prevGrounded = isGrounded;
      isGrounded = false;
      let shadowFloorY = -999;

      const bodyScale = Math.max(0.5, Math.min(1.3, avatarConfigRef.current.bodyScale ?? 1));
      const playerRadius = 0.46 * bodyScale;
      const playerHeight = 2.6 * bodyScale;

      for (const p of runtimePlatforms) {
        const px = p.mesh.position.x;
        const py = p.mesh.position.y;
        const pz = p.mesh.position.z;
        const halfW = p.def.w / 2;
        const halfD = p.def.d / 2;
        const topY = py + p.def.h / 2;
        const botY = py - p.def.h / 2;

        const dx = playerPos.x - px;
        const dz = playerPos.z - pz;
        const withinXZ = Math.abs(dx) < halfW + playerRadius && Math.abs(dz) < halfD + playerRadius;

        if (withinXZ && topY <= playerPos.y + 0.3 && topY > shadowFloorY) {
          shadowFloorY = topY;
        }

        if (withinXZ) {
          if (velY <= 0 && playerPos.y <= topY + 0.25 && playerPos.y >= topY - 1.15) {
            if (p.def.kind === 'hazard') {
              respawnAtCheckpoint(true);
              break;
            }
            playerPos.y = topY;
            playerPos.x += px - p.prevX;
            playerPos.z += pz - p.prevZ;
            velY = 0;
            isGrounded = true;

            if (p.def.kind === 'bounce') {
              velY = p.def.bounceVelocity || 22.5;
              isGrounded = false;
              coyoteTimer = 0;
              soundEngine.playBounce();
            } else if (p.def.kind === 'checkpoint' && p.def.stageIndex && p.def.stageIndex > stage) {
              stage = p.def.stageIndex;
              checkpointPos.set(px, topY + 0.5, pz);
              soundEngine.playCheckpoint();
              emitStats(true);
            } else if (p.def.kind === 'finish' && !completed) {
              completed = true;
              stage = totalStages;
              soundEngine.playVictory();
              emitStats(true);
            }

            // Trigger onTouch scripts attached to this platform
            for (const rs of runtimeScripts) {
              if (rs.platform === p && rs.runner.onTouch && t - rs.lastTouchAt > 0.45) {
                rs.lastTouchAt = t;
                try {
                  rs.runner.onTouch();
                } catch {
                  // Ignore script runtime errors
                }
              }
            }
          } else if (playerPos.y < topY - 0.25 && playerPos.y + playerHeight > botY) {
            if (p.def.kind === 'hazard') {
              respawnAtCheckpoint(true);
              break;
            }
            const overlapX = halfW + playerRadius - Math.abs(dx);
            const overlapZ = halfD + playerRadius - Math.abs(dz);
            if (overlapX > 0 && overlapZ > 0) {
              if (overlapX < overlapZ) playerPos.x += dx > 0 ? overlapX : -overlapX;
              else playerPos.z += dz > 0 ? overlapZ : -overlapZ;
            }
          }
        }
      }

      for (const s of runtimeSweepers) {
        const sy = s.def.y;
        if (playerPos.y < sy + 0.55 && playerPos.y + 1.8 > sy - 0.35) {
          const cosA = Math.cos(-s.angle);
          const sinA = Math.sin(-s.angle);
          const relX = playerPos.x - s.def.x;
          const relZ = playerPos.z - s.def.z;
          const localX = relX * cosA - relZ * sinA;
          const localZ = relX * sinA + relZ * cosA;
          if (Math.abs(localX) < s.def.length / 2 + 0.3 && Math.abs(localZ) < s.def.thickness / 2 + 0.35) {
            respawnAtCheckpoint(true);
            break;
          }
        }
      }

      if (playerPos.y < currentWorld.fallY) {
        respawnAtCheckpoint(true);
      }

      _playerCenter.set(playerPos.x, playerPos.y + 1.2, playerPos.z);
      for (const c of runtimeCoins) {
        if (c.collected) continue;
        c.mesh.rotation.y += dt * 2.8;
        c.mesh.position.y = c.baseY + Math.sin(t * 3 + c.mesh.position.x) * 0.18;
        if (_playerCenter.distanceTo(c.mesh.position) < 1.65) {
          c.collected = true;
          c.mesh.visible = false;
          collectedCoins += 1;
          soundEngine.playCoin();
          emitStats(true);
        }
      }

      // Emote auto-cancel on movement/jump or timeout (except 'sit')
      if (activeEmoteRef.current) {
        emoteElapsedRef.current += dt;
        const movedOrJumped = horizontalMag > 0.08 || !isGrounded;
        const timedOut = activeEmoteRef.current !== 'sit' && emoteElapsedRef.current > 3.8;
        if (movedOrJumped || timedOut) {
          activeEmoteRef.current = null;
          emoteElapsedRef.current = 0;
          onClearEmoteRef.current();
        }
      }

      const isFirstPerson = cameraModeRef.current === 'first';
      avatar.root.visible = !isFirstPerson;
      avatar.root.position.copy(playerPos);

      if (voiceActiveRef.current) {
        const vs = voiceEngine.sample(dt);
        avatar.setVoiceState(true, vs.bars);
      } else {
        avatar.setVoiceState(false, [0, 0, 0, 0, 0]);
      }

      avatar.updateAnimation(
        dt,
        horizontalMag * (isSprinting ? 1.35 : 1.0),
        isGrounded || prevGrounded,
        velY,
        avatarConfigRef.current.walkAnim,
        avatarConfigRef.current.jumpAnim,
        activeEmoteRef.current,
        emoteElapsedRef.current,
        avatarConfigRef.current.idleAnim
      );

      if (shadowFloorY > -900 && !isFirstPerson) {
        contactShadow.visible = true;
        contactShadow.position.set(playerPos.x, shadowFloorY + 0.025, playerPos.z);
        const heightAbove = Math.max(0, playerPos.y - shadowFloorY);
        contactShadow.scale.setScalar(Math.max(0.35, (1 - heightAbove * 0.08) * bodyScale));
        contactShadowMat.opacity = Math.max(0.1, 0.42 - heightAbove * 0.04);
      } else {
        contactShadow.visible = false;
      }

      keyLight.position.set(playerPos.x + 30, playerPos.y + 52, playerPos.z + 28);
      keyLight.target.position.copy(playerPos);

      if (isFirstPerson) {
        camera.position.set(playerPos.x, playerPos.y + 2.4 * bodyScale, playerPos.z);
        _camLookTarget.set(
          playerPos.x - Math.sin(camYaw) * Math.cos(camPitch) * 6,
          playerPos.y + 2.4 * bodyScale - Math.sin(camPitch) * 6,
          playerPos.z - Math.cos(camYaw) * Math.cos(camPitch) * 6
        );
        camera.lookAt(_camLookTarget);
      } else {
        const clampedPitch = Math.max(0.08, camPitch);
        _camDesired.set(
          playerPos.x + Math.sin(camYaw) * Math.cos(clampedPitch) * camDist,
          playerPos.y + 1.8 * bodyScale + Math.sin(clampedPitch) * camDist,
          playerPos.z + Math.cos(camYaw) * Math.cos(clampedPitch) * camDist
        );
        camera.position.lerp(_camDesired, 1 - Math.exp(-12 * dt));
        _camLookTarget.set(playerPos.x, playerPos.y + 1.65 * bodyScale, playerPos.z);
        camera.lookAt(_camLookTarget);
      }

      emitStats(false);

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      canvas.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      clearWorldGroup();
      avatar.dispose();
      studTex.dispose();
      checkerTex.dispose();
      lavaTex.dispose();
      contactShadowGeo.dispose();
      contactShadowMat.dispose();
      cloudGeo.dispose();
      cloudMat.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [touchInputRef]);

  useEffect(() => {
    sceneActionsRef.current?.loadWorld(worldId);
  }, [worldId, customParts, customMeta, customScripts, partyMembers]);

  useEffect(() => {
    sceneActionsRef.current?.updateAvatar(avatarConfig);
  }, [avatarConfig]);

  useEffect(() => {
    sceneActionsRef.current?.updateNameTag(playerName, isPlus);
  }, [playerName, isPlus]);

  useEffect(() => {
    if (chatBubble) {
      sceneActionsRef.current?.showChatBubble(chatBubble.text);
    }
  }, [chatBubble]);

  useEffect(() => {
    sceneActionsRef.current?.updateLighting(lighting);
  }, [lighting]);

  useEffect(() => {
    if (resetSignal > 0) {
      sceneActionsRef.current?.resetPlayer();
    }
  }, [resetSignal]);

  return (
    <div className="relative w-full h-full">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      {contextLost && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/95 text-center p-6 z-30">
          <div className="max-w-md space-y-3">
            <h2 className="font-display text-2xl font-bold text-white">Koneksi Grafis 3D Terputus</h2>
            <p className="text-sm text-slate-300">
              WebGL sedang memulihkan konteks grafis. Muat ulang halaman jika tampilan tidak segera kembali.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
