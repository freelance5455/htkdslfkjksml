import React, { useRef, useEffect, useState } from 'react';
import { GameEngine } from '../game/gameEngine';
import { GameRenderer } from '../game/renderer2D';
import { ClimbableWall, GameDifficulty, GameStats } from '../types/game';
import { sounds } from '../audio/soundManager';
import { GameHUD } from './GameHUD';
import { TILE_SIZE } from '../game/mazeGenerator';

interface GameCanvasProps {
  difficulty: GameDifficulty;
  isPaused: boolean;
  onGameOver: (stats: GameStats) => void;
  onVictory: (stats: GameStats) => void;
  onTogglePause: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  difficulty,
  isPaused,
  onGameOver,
  onVictory,
  onTogglePause,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const rendererRef = useRef<GameRenderer | null>(null);

  const [stats, setStats] = useState<GameStats>({
    timeElapsed: 0,
    chaseCount: 0,
    hidesUsed: 0,
    laddersUsed: 0,
    crystalsCollected: 0,
    totalCrystals: 3,
    difficulty,
    score: 0,
  });
  const [isChased, setIsChased] = useState(false);
  const [nearbyLadderWall, setNearbyLadderWall] = useState<ClimbableWall | null>(null);
  const [portalWarning, setPortalWarning] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(sounds.getMuted());
  const [playerState, setPlayerState] = useState(engineRef.current?.player);
  const [portalAngle, setPortalAngle] = useState(0);

  // Initialize engine & renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High-DPI Full-Screen Portrait 9:16 setup
    const baseW = 720;
    const baseH = 1280;
    canvas.width = baseW;
    canvas.height = baseH;

    const renderer = new GameRenderer(ctx, baseW, baseH);
    rendererRef.current = renderer;

    const engine = new GameEngine(
      {
        onGameOver,
        onVictory,
        onChaseChange: (chasing) => setIsChased(chasing),
        onStatsUpdate: (newStats) => setStats({ ...newStats }),
        onLadderAvailableChange: (wall) => setNearbyLadderWall(wall),
        onPortalLockedWarning: (warning) => setPortalWarning(warning),
      },
      difficulty
    );

    engineRef.current = engine;
    engine.startRun(difficulty);
    setPlayerState({ ...engine.player });

    let lastTimestamp = performance.now();
    let animationFrameId: number;

    const loop = (timestamp: number) => {
      const dt = (timestamp - lastTimestamp) / 1000;
      lastTimestamp = timestamp;

      if (!isPaused && engine.state === 'playing') {
        engine.update(dt);
      }

      // Compute angle to portal from player
      if (engine.player && engine.maze.portalGrid) {
        const ppx = engine.player.x;
        const ppy = engine.player.y;
        const portX = engine.maze.portalGrid.x * TILE_SIZE + TILE_SIZE / 2;
        const portY = engine.maze.portalGrid.y * TILE_SIZE + TILE_SIZE / 2;
        setPortalAngle(Math.atan2(portY - ppy, portX - ppx));
      }

      renderer.render(
        engine.maze,
        engine.player,
        engine.chickens,
        engine.particles,
        engine.camera,
        engine.getAnyChickenChasing(),
        engine.getNearestChickenDistance()
      );

      // Periodically update player state for UI
      setPlayerState({ ...engine.player });

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animationFrameId);
      engine.destroy();
    };
  }, [difficulty, isPaused, onGameOver, onVictory]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        onTogglePause();
        return;
      }

      if (e.key === ' ' || e.key.toLowerCase() === 'e') {
        // Space / E can trigger ladder if available or exit hiding
        const engine = engineRef.current;
        if (engine) {
          if (engine.player.isHiding) {
            engine.exitHiding();
            return;
          }
          if (nearbyLadderWall && engine.player.laddersAvailable > 0) {
            engine.startLadderPlacement(nearbyLadderWall);
            return;
          }
        }
      }

      engineRef.current?.setKeyboard(e.key, true);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      engineRef.current?.setKeyboard(e.key, false);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [nearbyLadderWall, onTogglePause]);

  // Screen click or tap converted to world coordinates
  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const engine = engineRef.current;
    if (!canvas || !engine) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const canvasX = (e.clientX - rect.left) * scaleX;
    const canvasY = (e.clientY - rect.top) * scaleY;

    // Convert from canvas screen space to world space:
    const cw = canvas.width;
    const ch = canvas.height;
    const worldX = engine.camera.x + (canvasX - cw / 2) / engine.camera.zoom;
    const worldY = engine.camera.y + (canvasY - ch / 2) / engine.camera.zoom;

    engine.handleWorldClick(worldX, worldY);
  };

  const handleUseLadder = (wall: ClimbableWall) => {
    engineRef.current?.startLadderPlacement(wall);
  };

  const handleExitHiding = () => {
    engineRef.current?.exitHiding();
  };

  const handleToggleMute = () => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full aspect-[9/16] bg-black overflow-hidden flex items-center justify-center select-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handleCanvasPointerDown}
        className="w-full h-full block cursor-crosshair touch-none"
      />

      {/* Game HUD Overlay */}
      {playerState && (
        <GameHUD
          stats={stats}
          isChased={isChased}
          player={playerState}
          nearbyClimbableWall={nearbyLadderWall}
          portalLockedWarning={portalWarning}
          onUseLadder={handleUseLadder}
          onExitHiding={handleExitHiding}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          isPaused={isPaused}
          onTogglePause={onTogglePause}
          portalAngleRad={portalAngle}
        />
      )}
    </div>
  );
};
