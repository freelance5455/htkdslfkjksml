import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { MotoAudioEngine } from '../game/audio';
import { createMoto160, createOnFootPlayer, type MotoRig, type OnFootPlayerRig } from '../game/motoModel';
import { RemotePlayers3DManager } from '../game/multiplayer';
import { MotoPhysicsEngine } from '../game/physics';
import { MissionDirector } from '../game/missions';
import { DynamicWeatherSystem } from '../game/weather';
import {
  HOUSE_DOOR_POS,
  HOUSE_FLOOR_Y,
  buildOpenWorld,
  getZoneInfo,
  groundNormalAt,
  isInsideMainHouse,
  type WorldHandles,
} from '../game/world';
import type {
  BikeCustomization,
  ControlInputs,
  DayTimePhase,
  GameSettings,
  GameTelemetry,
  MissionDefinition,
  RemotePlayerState,
  WeatherCondition,
} from '../game/types';

export interface GameBridge {
  setControl: (key: keyof ControlInputs, active: boolean) => void;
  toggleIgnition: () => void;
  toggleMount: () => void;
  interactHouseDoor: () => void;
  resetToHouse: () => void;
  cycleCamera: () => void;
  setCameraMode: (mode: 'chase' | 'hood' | 'far') => void;
  playHorn: () => void;
  setWeather: (w: WeatherCondition) => void;
  setTimePhase: (p: DayTimePhase) => void;
  toggleAutoCycle: () => void;
  applyCustomization: (c: BikeCustomization) => void;
  applySettings: (s: GameSettings) => void;
  startMission: (def: MissionDefinition) => void;
  cancelMission: () => void;
  unlockAudio: () => void;
  setMuted: (muted: boolean) => void;
  upsertRemotePlayerState: (state: RemotePlayerState) => void;
  removeRemotePlayer: (playerId: string) => void;
  clearRemotePlayers: () => void;
  syncDoorState: (open: boolean) => void;
}

interface GameCanvasProps {
  initialCustomization: BikeCustomization;
  initialSettings: GameSettings;
  showcaseMode?: boolean;
  inRoom?: boolean;
  onTelemetry: (t: GameTelemetry) => void;
  onMissionComplete: (def: MissionDefinition) => void;
  onMissionFail: (def: MissionDefinition, reason: string) => void;
  onSendPlayerState?: (state: Omit<RemotePlayerState, 'playerId' | 'name' | 'updatedAt'>) => void;
  onDoorStateChanged?: (open: boolean) => void;
}

const _camDesired = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _fpEyeLocal = new THREE.Vector3(0, 1.12, -0.50);
const _fpLookLocal = new THREE.Vector3(0, 0.88, -11.0);
const _slopeNorm = new THREE.Vector3();
const _upVec = new THREE.Vector3(0, 1, 0);
const _slopeQuat = new THREE.Quaternion();
const _yawQuat = new THREE.Quaternion();
const _leanQuat = new THREE.Quaternion();
const _yawAxis = new THREE.Vector3(0, 1, 0);
const _rollAxis = new THREE.Vector3(0, 0, 1);

export const GameCanvas = forwardRef<GameBridge, GameCanvasProps>(function GameCanvas(
  {
    initialCustomization,
    initialSettings,
    showcaseMode = false,
    inRoom = false,
    onTelemetry,
    onMissionComplete,
    onMissionFail,
    onSendPlayerState,
    onDoorStateChanged,
  },
  ref
) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const inputsRef = useRef<ControlInputs>({
    throttle: false,
    brake: false,
    wheelie: false,
    left: false,
    right: false,
  });
  const customRef = useRef<BikeCustomization>(initialCustomization);
  const settingsRef = useRef<GameSettings>(initialSettings);
  const showcaseRef = useRef<boolean>(showcaseMode);
  showcaseRef.current = showcaseMode;
  const inRoomRef = useRef<boolean>(inRoom);
  inRoomRef.current = inRoom;
  const cameraModeRef = useRef<'chase' | 'hood' | 'far'>('chase');

  const audioRef = useRef<MotoAudioEngine | null>(null);
  const physicsRef = useRef<MotoPhysicsEngine | null>(null);
  const weatherRef = useRef<DynamicWeatherSystem | null>(null);
  const worldRef = useRef<WorldHandles | null>(null);
  const motoRef = useRef<MotoRig | null>(null);
  const onFootRef = useRef<OnFootPlayerRig | null>(null);
  const missionRef = useRef<MissionDirector | null>(null);
  const remoteMgrRef = useRef<RemotePlayers3DManager | null>(null);

  const callbacksRef = useRef({
    onTelemetry,
    onMissionComplete,
    onMissionFail,
    onSendPlayerState,
    onDoorStateChanged,
  });
  callbacksRef.current = {
    onTelemetry,
    onMissionComplete,
    onMissionFail,
    onSendPlayerState,
    onDoorStateChanged,
  };

  const handleToggleMount = () => {
    const phys = physicsRef.current;
    if (!phys) return;
    if (phys.isOnFoot) {
      phys.mountMoto();
    } else {
      phys.dismountMoto();
    }
  };

  const handleInteractHouseDoor = () => {
    const phys = physicsRef.current;
    const world = worldRef.current;
    if (!phys || !world || !phys.isOnFoot) return;
    const dist = Math.hypot(phys.playerX - HOUSE_DOOR_POS.x, phys.playerZ - HOUSE_DOOR_POS.z);
    if (dist > 4.2) return;

    if (!isInsideMainHouse(phys.playerX, phys.playerZ)) {
      world.setDoorOpen(true);
      phys.playerX = HOUSE_DOOR_POS.x;
      phys.playerZ = -24.15;
      phys.playerY = HOUSE_FLOOR_Y;
      phys.playerHeading = 0;
      phys.playerSpeed = 0;
    } else {
      world.toggleDoor();
    }
    callbacksRef.current.onDoorStateChanged?.(world.isDoorOpen());
  };

  useImperativeHandle(ref, () => ({
    setControl: (key, active) => {
      inputsRef.current[key] = active;
      if (active) audioRef.current?.init();
    },
    toggleIgnition: () => {
      audioRef.current?.init();
      const res = physicsRef.current?.toggleIgnition();
      if (res === 'cranking') {
        audioRef.current?.playStarterCrank();
      }
    },
    toggleMount: () => {
      handleToggleMount();
    },
    interactHouseDoor: () => {
      handleInteractHouseDoor();
    },
    resetToHouse: () => {
      physicsRef.current?.resetToHouse();
    },
    cycleCamera: () => {
      const order: Array<'chase' | 'hood' | 'far'> = ['chase', 'hood', 'far'];
      const idx = (order.indexOf(cameraModeRef.current) + 1) % order.length;
      cameraModeRef.current = order[idx];
    },
    setCameraMode: (mode) => {
      cameraModeRef.current = mode;
    },
    playHorn: () => {
      audioRef.current?.playHorn();
    },
    setWeather: (w) => {
      weatherRef.current?.setWeather(w, true);
    },
    setTimePhase: (p) => {
      weatherRef.current?.setTimePhase(p);
    },
    toggleAutoCycle: () => {
      if (weatherRef.current) {
        const next = !weatherRef.current.autoWeather;
        weatherRef.current.autoWeather = next;
        weatherRef.current.autoDayNight = next;
      }
    },
    applyCustomization: (c) => {
      customRef.current = c;
      motoRef.current?.applyCustomization(c);
      audioRef.current?.setExhaustType(c.exhaust);
    },
    applySettings: (s) => {
      settingsRef.current = s;
    },
    startMission: (def) => {
      const phys = physicsRef.current;
      if (!phys) return;
      if (def.type === 'racha' && def.racerStart) {
        phys.x = 18;
        phys.z = 0;
        phys.heading = -Math.PI / 2;
        phys.speedMs = 0;
        phys.wheelieRad = 0;
      } else if (def.id === 'entrega_centro') {
        phys.resetToHouse();
      }
      missionRef.current?.startMission(def, phys.x, phys.z, customRef.current);
    },
    cancelMission: () => {
      missionRef.current?.cancelMission();
    },
    unlockAudio: () => {
      audioRef.current?.init();
    },
    setMuted: (muted) => {
      audioRef.current?.setMuted(muted);
    },
    upsertRemotePlayerState: (state) => {
      remoteMgrRef.current?.upsertState(state);
    },
    removeRemotePlayer: (playerId) => {
      remoteMgrRef.current?.removePlayer(playerId);
    },
    clearRemotePlayers: () => {
      remoteMgrRef.current?.clearAll();
    },
    syncDoorState: (open) => {
      worldRef.current?.setDoorOpen(open);
    },
  }));

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.25));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      62,
      (container.clientWidth || window.innerWidth) / Math.max(1, container.clientHeight || window.innerHeight),
      0.2,
      950
    );

    // Mandatory studio environment reflection for PBR chrome/paint/glass
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const world = buildOpenWorld(scene, maxAniso, isSoftwareGl);
    const weather = new DynamicWeatherSystem(scene, isSoftwareGl);
    const physics = new MotoPhysicsEngine();
    const moto = createMoto160(customRef.current);
    const onFootPlayer = createOnFootPlayer();
    const audio = new MotoAudioEngine();
    const missions = new MissionDirector(scene, customRef.current);
    const remoteMgr = new RemotePlayers3DManager(scene);

    onFootPlayer.group.visible = false;
    scene.add(moto.root);
    scene.add(onFootPlayer.group);

    // Tail scrape spark burst points
    const sparkCount = 24;
    const sparkPos = new Float32Array(sparkCount * 3);
    const sparkGeo = new THREE.BufferGeometry();
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3));
    const sparkMat = new THREE.PointsMaterial({ color: 0xfbbf24, size: 0.18, transparent: true, opacity: 0.9 });
    const sparks = new THREE.Points(sparkGeo, sparkMat);
    sparks.visible = false;
    sparks.frustumCulled = false;
    scene.add(sparks);

    audioRef.current = audio;
    physicsRef.current = physics;
    weatherRef.current = weather;
    worldRef.current = world;
    motoRef.current = moto;
    onFootRef.current = onFootPlayer;
    missionRef.current = missions;
    remoteMgrRef.current = remoteMgr;
    audio.setExhaustType(customRef.current.exhaust);

    // Set initial camera right behind bike facing Casa Principal & Avenida Central
    camera.position.set(physics.x + Math.sin(physics.heading) * 6, physics.y + 3.2, physics.z + Math.cos(physics.heading) * 6);
    camera.lookAt(physics.x, physics.y + 1.2, physics.z);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const onResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = Math.max(1, container.clientHeight || window.innerHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);
    const resizeObserver =
      typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => onResize()) : null;
    resizeObserver?.observe(container);

    const onContextLost = (e: Event) => {
      e.preventDefault();
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);

    // Keyboard Controls
    const onKeyDown = (e: KeyboardEvent) => {
      if (showcaseRef.current) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
        return;
      }
      audio.init();
      const k = e.key.toLowerCase();
      if (k === 'w' || e.key === 'ArrowUp') inputsRef.current.throttle = true;
      if (k === 's' || e.key === 'ArrowDown') inputsRef.current.brake = true;
      if (k === 'a' || e.key === 'ArrowLeft') inputsRef.current.left = true;
      if (k === 'd' || e.key === 'ArrowRight') inputsRef.current.right = true;
      if (e.code === 'Space' || k === 'shift') {
        e.preventDefault();
        inputsRef.current.wheelie = true;
      }
      if (k === 'e' && !e.repeat && !physics.isOnFoot) {
        const res = physics.toggleIgnition();
        if (res === 'cranking') audio.playStarterCrank();
      }
      if (k === 'f' && !e.repeat) {
        handleToggleMount();
      }
      if ((k === 'g' || e.key === 'Enter') && !e.repeat) {
        handleInteractHouseDoor();
      }
      if (k === 'c' && !e.repeat) {
        const order: Array<'chase' | 'hood' | 'far'> = ['chase', 'hood', 'far'];
        const idx = (order.indexOf(cameraModeRef.current) + 1) % order.length;
        cameraModeRef.current = order[idx];
      }
      if (k === 'b' && !e.repeat) {
        audio.playHorn();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || e.key === 'ArrowUp') inputsRef.current.throttle = false;
      if (k === 's' || e.key === 'ArrowDown') inputsRef.current.brake = false;
      if (k === 'a' || e.key === 'ArrowLeft') inputsRef.current.left = false;
      if (k === 'd' || e.key === 'ArrowRight') inputsRef.current.right = false;
      if (e.code === 'Space' || k === 'shift') inputsRef.current.wheelie = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    let frameId = 0;
    let disposed = false;
    const clock = new THREE.Clock();
    let hudAccumulator = 0;
    let netAccumulator = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.elapsedTime;

      const activeX = physics.isOnFoot ? physics.playerX : physics.x;
      const activeY = physics.isOnFoot ? physics.playerY : physics.y;
      const activeZ = physics.isOnFoot ? physics.playerZ : physics.z;

      const weatherMod = weather.update(dt, activeX, activeY, activeZ);
      world.setNightAndRain(weatherMod.nightFactor, weatherMod.rainFactor);
      world.updatePedestrians(dt, elapsed);
      world.updateHouseDoor(dt);

      let wheelSpinDelta = 0;
      if (physics.isOnFoot) {
        physics.stepOnFoot(
          dt,
          inputsRef.current,
          world.colliders,
          world.trees,
          world.doorCollider,
          world.isDoorOpen(),
          settingsRef.current
        );
      } else {
        const stepRes = physics.step(
          dt,
          inputsRef.current,
          customRef.current,
          weatherMod,
          world.colliders,
          world.trees,
          () => audio.playCrash(),
          (treeIdx, dirX, dirZ, speedMs, isTrunkHit) => {
            world.triggerTreeImpact(treeIdx, dirX, dirZ, speedMs, isTrunkHit);
          },
          world.doorCollider,
          world.isDoorOpen(),
          settingsRef.current
        );
        wheelSpinDelta = stepRes.wheelSpinDelta;
      }

      world.updateTrees(dt, elapsed, weatherMod.rainFactor, activeX, activeZ);

      // Align bike with terrain slope + heading + lean
      groundNormalAt(physics.x, physics.z, _slopeNorm);
      _slopeQuat.setFromUnitVectors(_upVec, _slopeNorm);
      _yawQuat.setFromAxisAngle(_yawAxis, physics.heading);
      _leanQuat.setFromAxisAngle(_rollAxis, physics.crashed ? 1.15 : physics.leanAngle);

      moto.root.position.set(physics.x, physics.y, physics.z);
      moto.root.quaternion.copy(_slopeQuat).multiply(_yawQuat).multiply(_leanQuat);

      const speedKmh = physics.isOnFoot ? 0 : Math.abs(physics.speedMs) * 3.6;
      moto.rider.root.visible = !physics.isOnFoot;
      // During a crash, the rider is thrown off the seat and lies beside the
      // fallen motorcycle. Smoothly return the rider to the riding pose when
      // the automatic recovery timer finishes.
      const riderFall = physics.crashed ? 1 : 0;
      moto.rider.root.position.x = THREE.MathUtils.damp(
        moto.rider.root.position.x, riderFall * 0.42, 7, dt
      );
      moto.rider.root.position.y = THREE.MathUtils.damp(
        moto.rider.root.position.y, 0.46 - riderFall * 0.34, 7, dt
      );
      moto.rider.root.position.z = THREE.MathUtils.damp(
        moto.rider.root.position.z, -0.34 + riderFall * 0.28, 7, dt
      );
      moto.rider.root.rotation.z = THREE.MathUtils.damp(
        moto.rider.root.rotation.z, riderFall * 1.18, 7, dt
      );
      moto.updateAnimation({
        wheelSpinDelta,
        steerAngle: physics.steerAngle,
        wheelieRad: physics.wheelieRad,
        speedKmh,
        throttle: !physics.isOnFoot && inputsRef.current.throttle,
        braking: !physics.isOnFoot && inputsRef.current.brake,
        nightFactor: weatherMod.nightFactor,
        timeSec: elapsed,
      });

      onFootPlayer.group.visible = physics.isOnFoot;
      if (physics.isOnFoot) {
        onFootPlayer.group.position.set(physics.playerX, physics.playerY, physics.playerZ);
        onFootPlayer.group.rotation.y = physics.playerHeading;
        onFootPlayer.updateWalkAnimation(physics.playerSpeed, elapsed, cameraModeRef.current === 'hood');
      }

      // Tail-scrape sparks
      sparks.visible = !physics.isOnFoot && physics.isScraping;
      if (sparks.visible) {
        const backX = physics.x + Math.sin(physics.heading) * 0.9;
        const backZ = physics.z + Math.cos(physics.heading) * 0.9;
        for (let i = 0; i < sparkCount; i++) {
          sparkPos[i * 3] = backX + (Math.random() - 0.5) * 0.35;
          sparkPos[i * 3 + 1] = physics.y + 0.08 + Math.random() * 0.25;
          sparkPos[i * 3 + 2] = backZ + (Math.random() - 0.5) * 0.35;
        }
        (sparkGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      }

      audio.update(
        physics.isOnFoot ? (physics.engineOn ? 1450 : 0) : physics.rpm,
        physics.engineOn,
        !physics.isOnFoot && inputsRef.current.throttle,
        speedKmh,
        weather.weather,
        !physics.isOnFoot && physics.isScraping
      );

      const missionInfo = missions.update(
        dt,
        activeX,
        activeZ,
        physics.isOnFoot ? physics.playerSpeed : physics.speedMs,
        !physics.isOnFoot && physics.isWheelieing,
        physics.crashed,
        weatherMod.nightFactor,
        elapsed,
        (def) => {
          audio.playMissionSuccess();
          callbacksRef.current.onMissionComplete(def);
        },
        (def, reason) => {
          callbacksRef.current.onMissionFail(def, reason);
        }
      );

      const remoteMarkers = remoteMgr.update(dt, elapsed, weatherMod.nightFactor);

      // Broadcast state to friends in room (~16 Hz)
      netAccumulator += dt;
      if (inRoomRef.current && !showcaseRef.current && netAccumulator >= 0.062) {
        netAccumulator = 0;
        callbacksRef.current.onSendPlayerState?.({
          x: physics.x,
          y: physics.y,
          z: physics.z,
          heading: physics.heading,
          wheelieRad: physics.wheelieRad,
          leanAngle: physics.crashed ? 1.15 : physics.leanAngle,
          steerAngle: physics.steerAngle,
          speedMs: physics.speedMs,
          isOnFoot: physics.isOnFoot,
          playerX: physics.playerX,
          playerY: physics.playerY,
          playerZ: physics.playerZ,
          playerHeading: physics.playerHeading,
          playerSpeed: physics.playerSpeed,
          engineOn: physics.engineOn,
          braking: inputsRef.current.brake,
          customization: customRef.current,
        });
      }

      // Smoothly damped camera choreography + dynamic FOV speed cue
      const camMode = cameraModeRef.current;
      const targetFov = showcaseRef.current ? 46 : camMode === 'hood' ? 72 : 60 + (speedKmh / 140) * 11;
      if (Math.abs(camera.fov - targetFov) > 0.1) {
        camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 5, dt);
        camera.updateProjectionMatrix();
      }

      // Hide rider helmet in 1ª Pessoa so camera never clips inside helmet
      moto.rider.head.visible = showcaseRef.current || camMode !== 'hood';

      const insideHouse = isInsideMainHouse(activeX, activeZ);

      if (showcaseRef.current) {
        const orbitAngle = elapsed * 0.22 + 0.55;
        _camDesired.set(
          physics.x + Math.sin(orbitAngle) * 3.8,
          physics.y + 1.55,
          physics.z + Math.cos(orbitAngle) * 3.8
        );
        _camTarget.set(physics.x - 0.55, physics.y + 0.85, physics.z);
        camera.position.lerp(_camDesired, 1 - Math.exp(-5 * dt));
      } else if (physics.isOnFoot) {
        const sinP = Math.sin(physics.playerHeading);
        const cosP = Math.cos(physics.playerHeading);
        if (camMode === 'hood') {
          _camDesired.set(
            physics.playerX - sinP * 0.08,
            physics.playerY + 1.56,
            physics.playerZ - cosP * 0.08
          );
          _camTarget.set(
            physics.playerX - sinP * 8.0,
            physics.playerY + 1.46,
            physics.playerZ - cosP * 8.0
          );
          camera.position.copy(_camDesired);
        } else {
          const distBack = insideHouse ? 2.45 : camMode === 'far' ? 5.2 : 3.4;
          const heightUp = insideHouse ? 1.85 : camMode === 'far' ? 2.4 : 1.9;
          _camDesired.set(
            physics.playerX + sinP * distBack,
            physics.playerY + heightUp,
            physics.playerZ + cosP * distBack
          );
          _camTarget.set(
            physics.playerX - sinP * 2.5,
            physics.playerY + 1.25,
            physics.playerZ - cosP * 2.5
          );
          camera.position.lerp(_camDesired, 1 - Math.exp(-9.5 * dt));
        }
      } else {
        const sinH = Math.sin(physics.heading);
        const cosH = Math.cos(physics.heading);
        if (camMode === 'hood') {
          moto.root.updateMatrixWorld(true);
          _camDesired.copy(_fpEyeLocal);
          moto.chassisGroup.localToWorld(_camDesired);
          _camTarget.copy(_fpLookLocal);
          moto.chassisGroup.localToWorld(_camTarget);
          camera.position.copy(_camDesired);
        } else {
          const distBack = camMode === 'far' ? 7.4 : 5.0;
          const heightUp = camMode === 'far' ? 3.2 : 2.35;
          _camDesired.set(
            physics.x + sinH * distBack,
            physics.y + heightUp + physics.wheelieRad * 0.3,
            physics.z + cosH * distBack
          );
          _camTarget.set(
            physics.x - sinH * 3.5,
            physics.y + 1.15 + physics.wheelieRad * 0.4,
            physics.z - cosH * 3.5
          );
          camera.position.lerp(_camDesired, 1 - Math.exp(-8.5 * dt));
        }
      }
      camera.lookAt(_camTarget);

      renderer.render(scene, camera);

      // Throttle React HUD state updates (~11 Hz) for smoother mobile & browser FPS
      hudAccumulator += dt;
      if (hudAccumulator >= 0.09) {
        hudAccumulator = 0;
        const zone = getZoneInfo(activeX, activeZ);
        const distToDoor = Math.hypot(activeX - HOUSE_DOOR_POS.x, activeZ - HOUSE_DOOR_POS.z);
        callbacksRef.current.onTelemetry({
          x: activeX,
          y: activeY,
          z: activeZ,
          heading: physics.isOnFoot ? physics.playerHeading : physics.heading,
          speedKmh: Math.min(140, speedKmh),
          rpm: physics.rpm,
          gear: physics.gear,
          engineOn: physics.engineOn,
          cranking: physics.cranking,
          wheelieDeg: THREE.MathUtils.radToDeg(physics.wheelieRad),
          leanDeg: THREE.MathUtils.radToDeg(physics.leanAngle),
          isWheelieing: !physics.isOnFoot && physics.isWheelieing,
          isScraping: !physics.isOnFoot && physics.isScraping,
          crashed: physics.crashed,
          currentGrauScore: physics.currentGrauScore,
          bestGrauScore: physics.bestGrauScore,
          totalGrauDistM: physics.totalGrauDistM,
          zone: insideHouse ? 'Dentro da Casa Principal' : zone.name,
          weather: weather.weather,
          timeOfDay: weather.timeOfDay,
          timePhase: weather.getTimePhase(),
          clockLabel: weather.getClockLabel(),
          gripFactor: weatherMod.gripMultiplier,
          cameraMode: cameraModeRef.current,
          isOnFoot: physics.isOnFoot,
          nearMoto: physics.isNearMoto(),
          nearHouseDoor: physics.isOnFoot && distToDoor < 3.9,
          houseDoorOpen: world.isDoorOpen(),
          insideHouse,
          activeMission: missions.active ? { ...missions.active } : null,
          missionTargetPos: missionInfo.targetPos,
          enemyPositions: missionInfo.enemies,
          remotePlayers: remoteMarkers.slice(),
        });
      }

      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    if (isSoftwareGl) {
      renderer.render(scene, camera);
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      resizeObserver?.disconnect();
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      audio.dispose();
      missions.dispose();
      remoteMgr.dispose();
      weather.dispose();
      world.dispose();
      sparkGeo.dispose();
      sparkMat.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full bg-neutral-950" />;
});
