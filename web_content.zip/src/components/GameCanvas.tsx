import { useEffect, useRef } from 'react';
import type { Game } from '../game/engine';

interface GameCanvasProps {
  game: Game;
}

/** Mounts the 3D renderer into a full-size container and drives the frame loop. */
export function GameCanvas({ game }: GameCanvasProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    game.attach(el);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      game.frame(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      game.detach();
    };
  }, [game]);

  return <div ref={ref} className="absolute inset-0 overflow-hidden" />;
}
