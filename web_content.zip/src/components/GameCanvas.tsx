import React, { useEffect, useRef } from 'react';
import { CarModel, DecorItem, FloatingText, Obstacle, Particle, Pedestrian, PowerupItem, PowerupType, RoadHazard, SkidMark, TimeOfDay, TrackConfig } from '../types.ts';
import { CAR_LIST, CARS } from '../data/cars.ts';
import { retroAudio } from '../audio/retroAudio.ts';
import { drawDecor, drawDetailedCar, drawFloatingTexts, drawHazard, drawHorizon, drawObstacleVehicle, drawPedestrian, drawPowerup, drawSkidMarks } from '../utils/pixelRenderer.ts';

interface GameCanvasProps {
  playerCar: CarModel;
  track: TrackConfig;
  isRunning: boolean;
  isPaused: boolean;
  onGameOver: (finalScore: number, distanceKm: number, topSpeedKmh: number, powerupsCount: number) => void;
  onUpdateHUD: (data: { score: number; speed: number; health: number; nitro: number; isNitroActive: boolean }) => void;
  activeKeysRef: React.MutableRefObject<Record<string, boolean>>;
  hornTriggerRef: React.MutableRefObject<number>;
  tiltAngleRef?: React.MutableRefObject<number>;
  isTiltEnabled?: boolean;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  playerCar,
  track,
  isRunning,
  isPaused,
  onGameOver,
  onUpdateHUD,
  activeKeysRef,
  hornTriggerRef,
  tiltAngleRef,
  isTiltEnabled = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Logical game resolution
  const W = 420;
  const H = 640;

  const trackRef = useRef(track);
  trackRef.current = track;

  const playerCarRef = useRef(playerCar);
  playerCarRef.current = playerCar;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleResize = () => {
      const container = containerRef.current;
      if (!container || !canvas) return;
      const rect = container.getBoundingClientRect();
      const ratio = W / H;
      let displayW = rect.width;
      let displayH = rect.height;

      if (displayW / displayH > ratio) {
        displayW = displayH * ratio;
      } else {
        displayH = displayW / ratio;
      }

      canvas.style.width = `${Math.floor(displayW)}px`;
      canvas.style.height = `${Math.floor(displayH)}px`;
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Main Game Loop Effect
  useEffect(() => {
    if (!isRunning) {
      retroAudio.stopEngine();
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = W;
    canvas.height = H;

    // Algerian Road Checkpoints
    const CITIES = [
      { name: 'البليدة (Blida)', dist: 60 },
      { name: 'المدية والشفة (Médéa)', dist: 160 },
      { name: 'الجلفة (Djelfa)', dist: 320 },
      { name: 'غرداية الواحات (Ghardaïa)', dist: 520 },
      { name: 'تمنراست الهقار (Tamanrasset)', dist: 800 }
    ];

    // Game state variables
    const state = {
      player: {
        x: W / 2,
        y: H - 140,
        vx: 0,
        vy: 0,
        speed: 0,
        health: playerCarRef.current.health,
        maxHealth: playerCarRef.current.health,
        shieldTime: 0
      },
      roadOffset: 0,
      roadCurve: 0,
      targetCurve: 0,
      curveTimer: 0,
      nitro: 50,
      isNitroActive: false,
      nitroDuration: 0,
      distance: 0,
      score: 0,
      topSpeed: 0,
      powerupsCollectedCount: 0,
      shakeIntensity: 0,
      timeOfDay: 'day' as TimeOfDay,
      lastCheckpointIdx: -1,
      obstacles: [] as (Obstacle & { overtaken?: boolean })[],
      pedestrians: [] as Pedestrian[],
      hazards: [] as RoadHazard[],
      decor: [] as DecorItem[],
      powerups: [] as PowerupItem[],
      particles: [] as Particle[],
      skidMarks: [] as SkidMark[],
      floatingTexts: [] as FloatingText[],
      nextEntityId: 1,
      lastSpawnTime: 0,
      lastPedSpawnTime: 0,
      lastDecorSpawnTime: 0,
      lastHazardSpawnTime: 0,
      lastPowerupSpawnTime: 0,
      lastHornTrigger: hornTriggerRef.current
    };

    let animationFrameId: number;
    let lastTime = performance.now();

    // Spawning helpers
    const spawnObstacle = () => {
      const allCars = CAR_LIST.filter((c) => c.id !== playerCarRef.current.id);
      const chosenCar = allCars[Math.floor(Math.random() * allCars.length)];
      const laneX = W * 0.22 + Math.random() * (W * 0.56);
      const isTaxi = Math.random() < 0.3;
      const isTruck = !isTaxi && Math.random() < 0.25;

      state.obstacles.push({
        id: state.nextEntityId++,
        x: laneX,
        y: -100,
        carId: chosenCar.id,
        speed: 2 + Math.random() * 3.5,
        lane: Math.random() < 0.5 ? -1 : 1,
        vx: (Math.random() - 0.5) * 0.5,
        width: 46,
        height: 72,
        type: isTaxi ? 'taxi' : isTruck ? 'truck' : 'car',
        overtaken: false
      });
    };

    const spawnPedestrian = () => {
      const side = Math.random() < 0.5 ? 'left' : 'right';
      const x = side === 'left' ? 25 + Math.random() * 40 : W - 65 + Math.random() * 40;
      state.pedestrians.push({
        id: state.nextEntityId++,
        x,
        y: -40,
        dir: side === 'left' ? 0.3 : -0.3,
        frame: 0,
        color: ['#e67e22', '#2980b9', '#8e44ad', '#16a085', '#d35400'][Math.floor(Math.random() * 5)],
        clothing: Math.random() < 0.6 ? 'djellaba' : 'casual'
      });
    };

    const spawnDecor = () => {
      const currentTrack = trackRef.current;
      const side = Math.random() < 0.5 ? 'left' : 'right';
      const x = side === 'left' ? 10 + Math.random() * 50 : W - 60 + Math.random() * 50;
      const types = currentTrack.decorTypes;
      const type = types[Math.floor(Math.random() * types.length)];

      state.decor.push({
        id: state.nextEntityId++,
        x,
        y: -40,
        type,
        size: 1
      });
    };

    const spawnHazard = () => {
      const x = W * 0.25 + Math.random() * (W * 0.5);
      const types: ('pothole' | 'sand' | 'oil')[] = ['pothole', 'pothole', 'sand', 'oil'];
      const type = types[Math.floor(Math.random() * types.length)];
      state.hazards.push({
        id: state.nextEntityId++,
        x,
        y: -40,
        type,
        width: type === 'pothole' ? 32 : 44,
        height: type === 'pothole' ? 20 : 26
      });
    };

    const spawnPowerup = () => {
      const x = W * 0.24 + Math.random() * (W * 0.52);
      const types: PowerupType[] = ['coin', 'coin', 'nitro', 'couscous', 'repair'];
      const type = types[Math.floor(Math.random() * types.length)];
      state.powerups.push({
        id: state.nextEntityId++,
        x,
        y: -40,
        type,
        collected: false
      });
    };

    const createDustParticle = (x: number, y: number, color: string) => {
      state.particles.push({
        x: x + (Math.random() - 0.5) * 12,
        y: y + (Math.random() - 0.5) * 6,
        vx: (Math.random() - 0.5) * 1.5,
        vy: 2 + Math.random() * 3,
        color,
        size: 3 + Math.random() * 4,
        alpha: 0.7,
        life: 1
      });
    };

    // Main Update & Render
    const tick = (now: number) => {
      const dt = Math.min(50, now - lastTime);
      lastTime = now;

      if (!isPaused) {
        const keys = activeKeysRef.current;
        const p = state.player;
        const currentCar = playerCarRef.current;
        const currentTrack = trackRef.current;

        // --- HORN KLAXON (CLEARS TRAFFIC IN FRONT) ---
        if (hornTriggerRef.current !== state.lastHornTrigger) {
          state.lastHornTrigger = hornTriggerRef.current;
          retroAudio.playHorn();

          // Obstacles ahead swerve to the side of the road!
          state.obstacles.forEach((obs) => {
            if (obs.y > -80 && obs.y < p.y) {
              obs.vx = obs.x < W / 2 ? -2.4 : 2.4;
            }
          });
        }

        // Nitro activation
        if (keys.nitro && state.nitro >= 20 && !state.isNitroActive) {
          state.isNitroActive = true;
          state.nitroDuration = 2400; // ms
          retroAudio.playNitro();
        }

        if (state.isNitroActive) {
          state.nitroDuration -= dt;
          state.nitro = Math.max(0, state.nitro - (dt / 2400) * 35);
          if (state.nitroDuration <= 0 || state.nitro <= 0) {
            state.isNitroActive = false;
          }
        } else {
          // Slow passive nitro gain
          state.nitro = Math.min(100, state.nitro + (dt / 1000) * 1.6);
        }

        // Acceleration & Braking
        const accelRate = (currentCar.acceleration || 0.16) * (state.isNitroActive ? 2.3 : 1.0);
        const maxCarSpeed = currentCar.maxSpeed * (state.isNitroActive ? 1.35 : 1.0);

        const isAccelerating = keys.gas || keys.up;
        const isBraking = keys.brake || keys.down;

        if (isAccelerating) {
          p.speed += accelRate;
        } else if (isBraking) {
          p.speed -= 0.35;
          if (p.speed > 4) {
            retroAudio.playScreech();
            // Record tire skid marks
            state.skidMarks.push({
              x1: p.x - 24,
              y1: p.y + 20,
              x2: p.x - 24,
              y2: p.y + 28,
              alpha: 0.8
            });
            state.skidMarks.push({
              x1: p.x + 24,
              y1: p.y + 20,
              x2: p.x + 24,
              y2: p.y + 28,
              alpha: 0.8
            });
          }
        }

        // Friction & terminal velocity
        p.speed *= 0.985;
        p.speed = Math.max(0, Math.min(maxCarSpeed, p.speed));

        if (p.speed * 18 > state.topSpeed) {
          state.topSpeed = Math.floor(p.speed * 18);
        }

        // Update synthesized audio engine revs
        retroAudio.updateEngine(p.speed / currentCar.maxSpeed, isAccelerating, isBraking);

        // Steering & inertia (Keyboard, On-Screen D-Pad, and Phone Tilt)
        const steerPower = currentCar.handling * (0.85 + p.speed * 0.12);
        let steerInput = 0;

        if (keys.left) {
          steerInput -= 1.0;
        }
        if (keys.right) {
          steerInput += 1.0;
        }

        // Add phone tilt motion if enabled
        if (isTiltEnabled && tiltAngleRef) {
          const angle = tiltAngleRef.current;
          if (Math.abs(angle) > 2.5) {
            const tiltNorm = Math.max(-1.0, Math.min(1.0, angle / 20));
            steerInput += tiltNorm;
          }
        }

        steerInput = Math.max(-1.2, Math.min(1.2, steerInput));

        if (Math.abs(steerInput) > 0.05) {
          p.vx = steerInput * steerPower;
        } else {
          p.vx *= 0.82;
        }

        p.x += p.vx;

        // Dynamic road curvature
        state.curveTimer += dt;
        if (state.curveTimer > 3500) {
          state.curveTimer = 0;
          state.targetCurve = (Math.random() - 0.5) * 45;
        }
        state.roadCurve += (state.targetCurve - state.roadCurve) * 0.02;

        // Road bounds check
        const horizonY = 160;
        const t = Math.max(0, Math.min(1, (p.y - horizonY) / (H - horizonY)));
        const roadTopW = 140;
        const roadBottomW = 340;
        const currentRoadW = roadTopW + (roadBottomW - roadTopW) * t;
        const roadCenterX = W / 2 + state.roadCurve * t;
        const leftBound = roadCenterX - currentRoadW / 2 + 28;
        const rightBound = roadCenterX + currentRoadW / 2 - 28;

        if (p.x < leftBound) {
          p.x = leftBound;
          p.speed *= 0.94; // Road shoulder friction
          createDustParticle(p.x, p.y + 30, currentTrack.groundTextureColor);
        } else if (p.x > rightBound) {
          p.x = rightBound;
          p.speed *= 0.94;
          createDustParticle(p.x, p.y + 30, currentTrack.groundTextureColor);
        }

        // Distance & score tracking
        state.roadOffset += p.speed * 3.5;
        state.distance += p.speed * 0.08;
        state.score = Math.floor(state.distance * 10);

        // --- DYNAMIC DAY / SUNSET / NIGHT CYCLE ---
        const cycleProgress = (state.distance % 2400);
        if (cycleProgress < 1000) {
          state.timeOfDay = 'day';
        } else if (cycleProgress < 1700) {
          state.timeOfDay = 'sunset';
        } else {
          state.timeOfDay = 'night';
        }

        // --- CHECKPOINTS PROGRESS ---
        CITIES.forEach((city, idx) => {
          if (state.distance >= city.dist && state.lastCheckpointIdx < idx) {
            state.lastCheckpointIdx = idx;
            state.score += 500;
            state.floatingTexts.push({
              id: state.nextEntityId++,
              x: W / 2,
              y: H * 0.38,
              text: `📍 ${city.name} +500!`,
              color: '#ffd700',
              alpha: 1.0,
              life: 2.5
            });
            retroAudio.playCollect('coin');
          }
        });

        // Shield countdown
        if (p.shieldTime > 0) {
          p.shieldTime -= dt;
        }

        // Spawning updates
        state.lastSpawnTime += dt;
        if (state.lastSpawnTime > Math.max(750, 2100 - p.speed * 110) && p.speed > 1.5) {
          spawnObstacle();
          state.lastSpawnTime = 0;
        }

        state.lastPedSpawnTime += dt;
        if (state.lastPedSpawnTime > 2600) {
          spawnPedestrian();
          state.lastPedSpawnTime = 0;
        }

        state.lastDecorSpawnTime += dt;
        if (state.lastDecorSpawnTime > 350) {
          spawnDecor();
          state.lastDecorSpawnTime = 0;
        }

        state.lastHazardSpawnTime += dt;
        if (state.lastHazardSpawnTime > Math.max(1600, 3200 - p.speed * 80) && p.speed > 2) {
          spawnHazard();
          state.lastHazardSpawnTime = 0;
        }

        state.lastPowerupSpawnTime += dt;
        if (state.lastPowerupSpawnTime > 3000) {
          spawnPowerup();
          state.lastPowerupSpawnTime = 0;
        }

        // Dust generation behind wheels
        if (p.speed > 3) {
          createDustParticle(p.x - 22, p.y + 30, currentTrack.groundTextureColor);
          createDustParticle(p.x + 22, p.y + 30, currentTrack.groundTextureColor);
        }

        // Update obstacles & Check Close-Pass bonus
        state.obstacles.forEach((obs) => {
          obs.y += (p.speed - obs.speed) * 3.2;
          obs.x += obs.vx;
          if (obs.x < leftBound + 10 || obs.x > rightBound - 10) {
            obs.vx *= -1;
          }

          // Close Pass / Near Miss detection (when passing close without crashing!)
          if (!obs.overtaken && p.speed > 4 && Math.abs(obs.y - p.y) < 25) {
            const dx = Math.abs(obs.x - p.x);
            if (dx >= 34 && dx <= 54) {
              obs.overtaken = true;
              state.score += 100;
              state.nitro = Math.min(100, state.nitro + 15);
              state.floatingTexts.push({
                id: state.nextEntityId++,
                x: p.x,
                y: p.y - 45,
                text: 'CLOSE PASS! +100',
                color: '#00d2d3',
                alpha: 1.0,
                life: 1.2
              });
            }
          }
        });
        state.obstacles = state.obstacles.filter((obs) => obs.y < H + 100 && obs.y > -150);

        // Update pedestrians
        state.pedestrians.forEach((ped) => {
          ped.y += p.speed * 2.8;
          ped.x += ped.dir * 0.4;
          ped.frame += 0.12;
        });
        state.pedestrians = state.pedestrians.filter((ped) => ped.y < H + 50);

        // Update decor
        state.decor.forEach((d) => {
          d.y += p.speed * 3.4;
        });
        state.decor = state.decor.filter((d) => d.y < H + 60);

        // Update hazards
        state.hazards.forEach((h) => {
          h.y += p.speed * 3.5;
        });
        state.hazards = state.hazards.filter((h) => h.y < H + 60);

        // Update powerups
        state.powerups.forEach((pu) => {
          pu.y += p.speed * 3.5;
        });
        state.powerups = state.powerups.filter((pu) => pu.y < H + 60 && !pu.collected);

        // Update particles
        state.particles.forEach((pt) => {
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.alpha -= 0.04;
          pt.life -= 0.04;
        });
        state.particles = state.particles.filter((pt) => pt.life > 0 && pt.alpha > 0);

        // Update skid marks (scroll down with road & fade out)
        state.skidMarks.forEach((m) => {
          m.y1 += p.speed * 3.5;
          m.y2 += p.speed * 3.5;
          m.alpha -= 0.008;
        });
        state.skidMarks = state.skidMarks.filter((m) => m.y1 < H + 50 && m.alpha > 0);

        // Update floating texts (rise and fade)
        state.floatingTexts.forEach((ft) => {
          ft.y -= 1.0;
          ft.alpha -= 0.02;
          ft.life -= 0.02;
        });
        state.floatingTexts = state.floatingTexts.filter((ft) => ft.life > 0 && ft.alpha > 0);

        // Decay screen shake
        if (state.shakeIntensity > 0) {
          state.shakeIntensity *= 0.88;
          if (state.shakeIntensity < 0.2) state.shakeIntensity = 0;
        }

        // --- COLLISIONS ---

        // 1. Hazards (Potholes, Sand, Oil)
        state.hazards.forEach((h) => {
          const dx = Math.abs(h.x - p.x);
          const dy = Math.abs(h.y - p.y);
          if (dx < h.width / 2 + 16 && dy < h.height / 2 + 25) {
            if (p.shieldTime <= 0) {
              retroAudio.playBump();
              state.shakeIntensity = 8;
              p.speed *= 0.7; // Speed penalty
              p.health -= h.type === 'pothole' ? 12 : 6;
              h.y = H + 200; // prevent multi-hit
            }
          }
        });

        // 2. Powerups Collectibles
        state.powerups.forEach((pu) => {
          if (pu.collected) return;
          const dx = Math.abs(pu.x - p.x);
          const dy = Math.abs(pu.y - p.y);
          if (dx < 26 && dy < 36) {
            pu.collected = true;
            state.powerupsCollectedCount++;
            retroAudio.playCollect(pu.type);

            if (pu.type === 'coin') {
              state.score += 150;
              state.floatingTexts.push({
                id: state.nextEntityId++,
                x: pu.x,
                y: pu.y - 15,
                text: '+150 DZ',
                color: '#f1c40f',
                alpha: 1.0,
                life: 1.0
              });
            } else if (pu.type === 'nitro') {
              state.nitro = Math.min(100, state.nitro + 45);
              state.floatingTexts.push({
                id: state.nextEntityId++,
                x: pu.x,
                y: pu.y - 15,
                text: 'NITRO BOOST!',
                color: '#00d2d3',
                alpha: 1.0,
                life: 1.0
              });
            } else if (pu.type === 'couscous') {
              p.health = Math.min(p.maxHealth, p.health + 30);
              p.shieldTime = 4000;
              state.floatingTexts.push({
                id: state.nextEntityId++,
                x: pu.x,
                y: pu.y - 15,
                text: 'COUSCOUS SHIELD!',
                color: '#e67e22',
                alpha: 1.0,
                life: 1.2
              });
            } else if (pu.type === 'repair') {
              p.health = Math.min(p.maxHealth, p.health + 45);
              state.floatingTexts.push({
                id: state.nextEntityId++,
                x: pu.x,
                y: pu.y - 15,
                text: 'REPAIRED +45',
                color: '#2ecc71',
                alpha: 1.0,
                life: 1.0
              });
            }
          }
        });

        // 3. Obstacle Vehicles Collisions
        for (const obs of state.obstacles) {
          const dx = Math.abs(obs.x - p.x);
          const dy = Math.abs(obs.y - p.y);
          if (dx < 33 && dy < 54) {
            if (p.shieldTime > 0) {
              p.shieldTime = 0;
              retroAudio.playBump();
              obs.y = H + 200;
              state.shakeIntensity = 10;
            } else {
              retroAudio.playCrash();
              onGameOver(
                state.score,
                state.distance / 100,
                state.topSpeed,
                state.powerupsCollectedCount
              );
              return;
            }
          }
        }

        // 4. Pedestrian Collision
        for (const ped of state.pedestrians) {
          const dx = Math.abs(ped.x - p.x);
          const dy = Math.abs(ped.y - p.y);
          if (dx < 24 && dy < 38) {
            retroAudio.playCrash();
            onGameOver(
              state.score,
              state.distance / 100,
              state.topSpeed,
              state.powerupsCollectedCount
            );
            return;
          }
        }

        // Health check
        if (p.health <= 0) {
          retroAudio.playCrash();
          onGameOver(
            state.score,
            state.distance / 100,
            state.topSpeed,
            state.powerupsCollectedCount
          );
          return;
        }

        // Report to HUD
        onUpdateHUD({
          score: state.score,
          speed: p.speed,
          health: (p.health / p.maxHealth) * 100,
          nitro: state.nitro,
          isNitroActive: state.isNitroActive
        });
      }

      // --- RENDERING ---
      ctx.save();

      // Screen shake translation
      if (state.shakeIntensity > 0) {
        const shakeX = (Math.random() - 0.5) * state.shakeIntensity;
        const shakeY = (Math.random() - 0.5) * state.shakeIntensity;
        ctx.translate(shakeX, shakeY);
      }

      ctx.clearRect(0, 0, W, H);

      const currentTrack = trackRef.current;
      const horizonY = 160;

      // 1. Sky Gradient based on Time of Day
      const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY);
      if (state.timeOfDay === 'sunset') {
        skyGrad.addColorStop(0, '#3e093b');
        skyGrad.addColorStop(0.6, '#d35400');
        skyGrad.addColorStop(1, '#f39c12');
      } else if (state.timeOfDay === 'night') {
        skyGrad.addColorStop(0, '#050711');
        skyGrad.addColorStop(0.8, '#13192d');
        skyGrad.addColorStop(1, '#1b2845');
      } else {
        skyGrad.addColorStop(0, currentTrack.skyGradient[0]);
        skyGrad.addColorStop(1, currentTrack.skyGradient[1]);
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, W, horizonY);

      // Stars in Night mode
      if (state.timeOfDay === 'night') {
        ctx.fillStyle = '#ffffff';
        for (let i = 0; i < 25; i++) {
          const sx = (i * 37 + state.roadOffset * 0.05) % W;
          const sy = (i * 19) % (horizonY - 20);
          ctx.fillRect(sx, sy, 2, 2);
        }
      }

      // Distant landmark silhouette (Maqam Echahid, Atlas peaks, or dunes)
      drawHorizon(ctx, W, horizonY, currentTrack.bgSilhouette, state.roadOffset);

      // 2. Ground / Terrain
      const groundCol = state.timeOfDay === 'night' ? '#1a1816' : currentTrack.groundColor;
      ctx.fillStyle = groundCol;
      ctx.fillRect(0, horizonY, W, H - horizonY);

      // Ground speckled texture for speed motion
      ctx.fillStyle = currentTrack.groundTextureColor;
      for (let i = 0; i < 45; i++) {
        const gx = (i * 47 + state.roadCurve * 0.4) % W;
        const gy = horizonY + ((i * 31 + state.roadOffset * 0.9) % (H - horizonY));
        ctx.fillRect(gx, gy, 3, 3);
      }

      // 3. Perspective Road Geometry with Curvature
      const roadTopW = 140;
      const roadBottomW = 340;
      const topCenterX = W / 2;
      const bottomCenterX = W / 2 + state.roadCurve;

      const roadCol = state.timeOfDay === 'night' ? '#202226' : currentTrack.roadColor;
      ctx.fillStyle = roadCol;
      ctx.beginPath();
      ctx.moveTo(topCenterX - roadTopW / 2, horizonY);
      ctx.lineTo(topCenterX + roadTopW / 2, horizonY);
      ctx.lineTo(bottomCenterX + roadBottomW / 2, H);
      ctx.lineTo(bottomCenterX - roadBottomW / 2, H);
      ctx.closePath();
      ctx.fill();

      // Curbs / Rumble strips on road edges
      const curbSegments = 16;
      for (let i = 0; i < curbSegments; i++) {
        const t1 = ((i * 45 + state.roadOffset) % (H - horizonY)) / (H - horizonY);
        const t2 = Math.min(1, t1 + 0.04);
        const y1 = horizonY + t1 * (H - horizonY);
        const y2 = horizonY + t2 * (H - horizonY);

        const cx1 = W / 2 + state.roadCurve * t1;
        const cx2 = W / 2 + state.roadCurve * t2;
        const rw1 = roadTopW + (roadBottomW - roadTopW) * t1;
        const rw2 = roadTopW + (roadBottomW - roadTopW) * t2;

        const isEven = i % 2 === 0;
        ctx.fillStyle = isEven ? currentTrack.curbColor1 : currentTrack.curbColor2;

        // Left curb
        ctx.beginPath();
        ctx.moveTo(cx1 - rw1 / 2, y1);
        ctx.lineTo(cx1 - rw1 / 2 - 8 * (1 + t1), y1);
        ctx.lineTo(cx2 - rw2 / 2 - 8 * (1 + t2), y2);
        ctx.lineTo(cx2 - rw2 / 2, y2);
        ctx.closePath();
        ctx.fill();

        // Right curb
        ctx.beginPath();
        ctx.moveTo(cx1 + rw1 / 2, y1);
        ctx.lineTo(cx1 + rw1 / 2 + 8 * (1 + t1), y1);
        ctx.lineTo(cx2 + rw2 / 2 + 8 * (1 + t2), y2);
        ctx.lineTo(cx2 + rw2 / 2, y2);
        ctx.closePath();
        ctx.fill();
      }

      // Dashed lane lines down the center
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 9; i++) {
        const t = ((i * 70 + state.roadOffset * 1.5) % (H - horizonY)) / (H - horizonY);
        const y = horizonY + t * (H - horizonY);
        const cx = W / 2 + state.roadCurve * t;
        const lw = 4 + t * 4;
        const lh = 12 + t * 18;
        ctx.fillRect(cx - lw / 2, y, lw, lh);
      }

      // 4. Tire Skid Marks
      drawSkidMarks(ctx, state.skidMarks);

      // 5. Road Hazards
      state.hazards.forEach((hz) => drawHazard(ctx, hz));

      // 6. Roadside Decor
      state.decor.forEach((d) => drawDecor(ctx, d));

      // 7. Powerups Collectibles
      state.powerups.forEach((pu) => drawPowerup(ctx, pu, now));

      // 8. Pedestrians
      state.pedestrians.forEach((ped) => drawPedestrian(ctx, ped));

      // 9. Obstacles with Visible Wheels & Details
      state.obstacles.forEach((obs) => {
        const obsCar = CARS[obs.carId] || CAR_LIST[0];
        drawObstacleVehicle(ctx, obs, obsCar, state.timeOfDay);
      });

      // 10. Dust & Smoke Particles
      state.particles.forEach((pt) => {
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = pt.alpha;
        ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
      });
      ctx.globalAlpha = 1.0;

      // 11. Player Car with Detailed 4 Wheels, Rims, Mirrors, Lights & Reflections!
      const p = state.player;
      const isBraking = activeKeysRef.current.brake || activeKeysRef.current.down;
      const steerRatio = Math.max(-1, Math.min(1, p.vx / (playerCarRef.current.handling * 1.3)));

      drawDetailedCar(
        ctx,
        playerCarRef.current,
        p.x,
        p.y,
        steerRatio,
        isBraking,
        true,
        state.timeOfDay
      );

      // Invulnerability Shield Aura
      if (p.shieldTime > 0) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.strokeStyle = `rgba(241, 196, 15, ${0.5 + Math.sin(now * 0.02) * 0.3})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.ellipse(0, 0, 34, 46, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Nitro Flames from exhaust!
      if (state.isNitroActive) {
        ctx.save();
        ctx.translate(p.x, p.y);
        const flameLength = 18 + Math.random() * 14;
        ctx.fillStyle = '#00d2d3';
        ctx.fillRect(-15, 34, 6, flameLength);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-14, 34, 4, flameLength * 0.6);

        ctx.fillStyle = '#00d2d3';
        ctx.fillRect(9, 34, 6, flameLength);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(10, 34, 4, flameLength * 0.6);
        ctx.restore();
      }

      // 12. Floating Arcade Texts ("CLOSE PASS! +100", "📍 GHARDAÏA!")
      drawFloatingTexts(ctx, state.floatingTexts);

      ctx.restore();

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(animationFrameId);
      retroAudio.stopEngine();
    };
  }, [isRunning, isPaused, onGameOver, onUpdateHUD, activeKeysRef, hornTriggerRef, tiltAngleRef, isTiltEnabled]);

  return (
    <div ref={containerRef} className="w-full h-full flex items-center justify-center overflow-hidden">
      <canvas
        ref={canvasRef}
        className="block bg-black shadow-2xl rounded-lg image-pixelated cursor-none"
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
};
