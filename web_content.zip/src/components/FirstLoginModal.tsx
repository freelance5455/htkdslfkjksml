import React, { useState } from 'react';
import { KeyRound, ShieldCheck, ArrowRight, AlertTriangle } from 'lucide-react';
import { api } from '../services/api.ts';

interface FirstLoginModalProps {
  isOpen: boolean;
  userId: string;
  username: string;
  onSuccess: () => void;
  onSkip?: () => void;
}

export const FirstLoginModal: React.FC<FirstLoginModalProps> = ({
  isOpen,
  userId,
  username,
  onSuccess,
  onSkip,
}) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      setError('Please fill all fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }
    if (newPassword.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.changePassword(userId, currentPassword, newPassword);
      if (res.success) {
        onSuccess();
      } else {
        setError(res.error || 'Failed to update password');
      }
    } catch {
      setError('Server error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-cyan-500/40 p-6 shadow-2xl text-slate-100">
        <div className="flex flex-col items-center text-center mb-4">
          <div className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400 mb-2">
            <ShieldCheck size={24} />
          </div>
          <h3 className="text-base font-bold text-white font-display">Update Temporary Password</h3>
          <p className="text-xs text-slate-400 mt-1">
            Welcome @{username}! Set a personal password for your Unknown Gamer account.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <AlertTriangle size={15} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="block text-slate-300 mb-1">Temporary Password</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Enter current temporary password"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-1">New Permanent Password</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter new secure password"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Confirm New Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Re-enter new password"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
            />
          </div>

          <div className="pt-2 space-y-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>{loading ? 'Updating...' : 'Save New Password'}</span>
              <ArrowRight size={15} />
            </button>

            {onSkip && (
              <button
                type="button"
                onClick={onSkip}
                className="w-full py-2 rounded-xl text-slate-400 hover:text-slate-200 text-xs transition-colors"
              >
                Skip for now
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
