import React from "react";
import {
  FileText,
  FolderPlus,
  Table,
  Network,
  Image,
  Stamp,
  Mic,
  Lock,
  Sparkles,
  BookOpen,
  CheckSquare,
  Zap,
  X,
  Plus,
  SlidersHorizontal,
  ChevronRight,
  Binary
} from "lucide-react";
import { ThemeAccent, UserProfile } from "../types";
import { THEME_ACCENTS } from "../utils/theme";

interface CreateMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (actionKey: string) => void;
  themeAccent?: ThemeAccent;
  profile?: UserProfile;
}

interface ActionItem {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badge?: string;
  isAi?: boolean;
}

export const CreateMenuModal: React.FC<CreateMenuModalProps> = ({
  isOpen,
  onClose,
  onSelectAction,
  themeAccent = "teal",
  profile,
}) => {
  if (!isOpen) return null;

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;
  const isAiActive = profile?.isLoggedIn && profile?.aiModeEnabled;

  const actionCategories: Array<{
    categoryTitle: string;
    items: ActionItem[];
  }> = [
    {
      categoryTitle: "Not & Yazım",
      items: [
        {
          id: "new_note",
          title: "Zengin Metin Notu",
          description: "Başlık, etiketler, listeler ve biçimlendirme ile not yaz",
          icon: FileText,
          color: "text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-800",
        },
        {
          id: "new_task_note",
          title: "Görev & Kontrol Listesi",
          description: "İşaretlenebilir yapılacaklar ve eylem maddeleri oluştur",
          icon: CheckSquare,
          color: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800",
          badge: "Görev",
        },
        {
          id: "new_audio",
          title: "Sesli Not Kaydı",
          description: "Konuşarak ses kaydı al ve not içeriğine dönüştür",
          icon: Mic,
          color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800",
          badge: "Ses",
        },
      ],
    },
    {
      categoryTitle: "Yapay Zeka & Asistan",
      items: [
        {
          id: "ai_chat",
          title: "NoteFlow AI Soru & Sohbet",
          description: "Gemini ile notların üzerinde beyin fırtınası yap ve soru sor",
          icon: Sparkles,
          color: "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800",
          badge: isAiActive ? "✦ Pro AI" : "✦ AI",
          isAi: true,
        },
        {
          id: "ai_mindmap",
          title: "Zihin Haritası & Bilgi Ağı",
          description: "Notlar arasındaki anlamsal ilişkileri görsel grafik olarak çiz",
          icon: Network,
          color: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-800",
          badge: "Görsel",
        },
      ],
    },
    {
      categoryTitle: "Organizasyon & Stüdyo",
      items: [
        {
          id: "new_section",
          title: "Yeni Bölüm & Klasör",
          description: "Notlarını konularına göre gruplandırmak için özel bölüm oluştur",
          icon: FolderPlus,
          color: "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800",
        },
        {
          id: "document_hub",
          title: "Belge & Veri Tabanı",
          description: "PDF, Word, TXT içe aktar veya notları dışa aktar",
          icon: Table,
          color: "text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 border-sky-200 dark:border-sky-800",
          badge: "Word/PDF",
        },
        {
          id: "colornote_import",
          title: "ColorNote (.BIN) Yedek Çözücü",
          description: "Şifreli veya şifresiz ColorNote yedeklerini otomatik çöz ve kartlara aktar",
          icon: Binary,
          color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800",
          badge: "AES-128",
        },
        {
          id: "frame_studio",
          title: "Öğeler & Çıkartma Kütüphanesi",
          description: "Goodnotes & Notability tarzı çıkartmalar, damgalar ve kement kırpıntıları",
          icon: Stamp,
          color: "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800",
          badge: "Öğeler",
        },
        {
          id: "new_flashcard",
          title: "Ezber & Çalışma Kartı",
          description: "Soru-cevap kartları oluştur ve sınav modunda tekrar et",
          icon: BookOpen,
          color: "text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 border-cyan-200 dark:border-cyan-800",
          badge: "Öğren",
        },
        {
          id: "open_vault",
          title: "Şifreli Güvenli Kasa",
          description: "Parola korumalı gizli ve hassas notlar alanı",
          icon: Lock,
          color: "text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800",
          badge: "Şifreli",
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Background click to dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Main Modal Card */}
      <div className="relative w-full sm:max-w-xl max-h-[85vh] sm:max-h-[80vh] flex flex-col bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden z-10 animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${themeDef.gradient} flex items-center justify-center text-white font-bold text-sm shadow-sm`}
            >
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white tracking-tight">
                Yeni Oluştur
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Eklemek istediğiniz içerik veya aracı seçin
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Content Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 no-scrollbar">
          {actionCategories.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1.5">
              <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-1">
                {group.categoryTitle}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectAction(item.id);
                        onClose();
                      }}
                      className="group flex items-start gap-3 p-3 rounded-2xl bg-slate-50/70 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 hover:border-teal-400/80 dark:hover:border-teal-500 hover:shadow-md transition-all text-left cursor-pointer active:scale-[0.98]"
                    >
                      <div className={`p-2.5 rounded-xl border shrink-0 ${item.color} group-hover:scale-110 transition-transform`}>
                        <Icon className="w-4 h-4" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                            {item.title}
                          </span>
                          {item.badge && (
                            <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-md bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                          {item.description}
                        </p>
                      </div>

                      <ChevronRight className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600 group-hover:text-teal-500 transition-colors shrink-0 self-center" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer Quick Tip */}
        <div className="px-5 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            İpucu: Klavyeden <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 font-mono text-[10px] font-bold">⌘K</kbd> ile hızlı komut menüsünü açabilirsiniz
          </span>
          <button
            onClick={onClose}
            className="text-xs font-bold text-slate-600 dark:text-slate-300 hover:underline"
          >
            Kapat
          </button>
        </div>

      </div>
    </div>
  );
};
