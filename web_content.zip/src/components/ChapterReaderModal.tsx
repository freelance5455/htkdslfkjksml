import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  Share2,
  Bookmark,
  Download,
  BookOpen,
  PenTool,
  CheckCircle2,
  HelpCircle,
  FileCheck,
  Brain,
  Minus,
  Plus,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { ChapterData, BIOLOGY_CHAPTERS, ALL_19_CHAPTER_TITLES } from '../data/biologyData';

interface ChapterReaderModalProps {
  chapter: ChapterData;
  initialSubTab?: 'premium' | 'handwritten' | 'ncert' | 'solutions' | 'mcq' | 'important' | 'mindmap';
  onClose: () => void;
  onSelectChapter: (ch: ChapterData) => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: number) => void;
  themeMode: 'teal' | 'sepia' | 'dark';
}

export const ChapterReaderModal: React.FC<ChapterReaderModalProps> = ({
  chapter,
  initialSubTab = 'premium',
  onClose,
  onSelectChapter,
  isBookmarked,
  onToggleBookmark,
  themeMode,
}) => {
  const [activeTab, setActiveTab] = useState<'premium' | 'handwritten' | 'ncert' | 'solutions' | 'mcq' | 'important' | 'mindmap'>(initialSubTab);
  const [fontSize, setFontSize] = useState<number>(15);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [activeHighlighter, setActiveHighlighter] = useState<'yellow' | 'green' | 'pink' | null>(null);

  // Stop speech synthesis when closing or changing chapter
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [chapter.id]);

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) {
      alert('आपके ब्राउज़र में स्पीच फीचर समर्थित नहीं है।');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    let textToRead = `${chapter.title}. ${chapter.premiumNotes.summary} `;
    chapter.premiumNotes.sections.forEach((sec) => {
      textToRead += `${sec.heading}. ${sec.content.join(' ')}. `;
    });

    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.95;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleDownloadPdf = () => {
    window.print();
  };

  const currentIdx = ALL_19_CHAPTER_TITLES.findIndex((c) => c.no === chapter.chapterNumber);
  const prevChapterItem = currentIdx > 0 ? ALL_19_CHAPTER_TITLES[currentIdx - 1] : null;
  const nextChapterItem = currentIdx < ALL_19_CHAPTER_TITLES.length - 1 ? ALL_19_CHAPTER_TITLES[currentIdx + 1] : null;

  const navigateToChapter = (chNo: number) => {
    const nextCh = BIOLOGY_CHAPTERS.find((c) => c.chapterNumber === chNo) || {
      ...BIOLOGY_CHAPTERS[0],
      id: chNo,
      chapterNumber: chNo,
      title: ALL_19_CHAPTER_TITLES.find((c) => c.no === chNo)?.title || 'अध्याय',
      englishTitle: ALL_19_CHAPTER_TITLES.find((c) => c.no === chNo)?.eng || '',
      unit: ALL_19_CHAPTER_TITLES.find((c) => c.no === chNo)?.unit || '',
    };
    onSelectChapter(nextCh);
  };

  const themeClasses = {
    teal: 'bg-slate-50 text-slate-800',
    sepia: 'bg-[#fbf7ee] text-[#433422]',
    dark: 'bg-slate-900 text-slate-100',
  }[themeMode];

  const cardThemeClasses = {
    teal: 'bg-white border-slate-200 text-slate-800 shadow-sm',
    sepia: 'bg-[#f4ebd9] border-[#e6dac5] text-[#3d2f20] shadow-sm',
    dark: 'bg-slate-800 border-slate-700 text-slate-100 shadow-sm',
  }[themeMode];

  return (
    <div className={`fixed inset-0 z-50 overflow-y-auto flex flex-col ${themeClasses} transition-colors duration-200`}>
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-[#00838f] text-white shadow-md">
        <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="w-10 h-10 -ml-2 flex items-center justify-center rounded-full hover:bg-white/20 active:bg-white/30"
              title="वापस जाएँ"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="leading-tight">
              <span className="text-[11px] text-teal-100 block">अध्याय {chapter.chapterNumber}</span>
              <h2 className="text-sm font-bold truncate max-w-[170px] sm:max-w-xs font-devanagari">
                {chapter.title}
              </h2>
            </div>
          </div>

          {/* Action icons */}
          <div className="flex items-center gap-1">
            {/* Audio Reader */}
            <button
              onClick={handleSpeak}
              className={`w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/20 transition-colors ${
                isSpeaking ? 'bg-amber-400 text-slate-900' : 'text-white'
              }`}
              title={isSpeaking ? 'ऑडियो बंद करें' : 'नोट्स सुनें (हिंदी में)'}
            >
              {isSpeaking ? <VolumeX className="w-5 h-5 animate-pulse" /> : <Volume2 className="w-5 h-5" />}
            </button>

            {/* Bookmark */}
            <button
              onClick={() => onToggleBookmark(chapter.chapterNumber)}
              className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/20 transition-colors"
              title={isBookmarked ? 'बुकमार्क हटाया गया' : 'बुकमार्क करें'}
            >
              <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-amber-400 text-amber-400' : 'text-white'}`} />
            </button>

            {/* Print/Download */}
            <button
              onClick={handleDownloadPdf}
              className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/20 transition-colors"
              title="PDF डाउनलोड / प्रिंट"
            >
              <Download className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        {/* Sub-Tabs Scroller */}
        <div className="bg-[#00707c] px-3 py-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('premium')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'premium' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            प्रीमियम नोट्स
          </button>
          <button
            onClick={() => setActiveTab('handwritten')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'handwritten' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            ✍️ हस्तलिखित
          </button>
          <button
            onClick={() => setActiveTab('solutions')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'solutions' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            अभ्यास समाधान
          </button>
          <button
            onClick={() => setActiveTab('mcq')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'mcq' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            MCQ टेस्ट
          </button>
          <button
            onClick={() => setActiveTab('important')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'important' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            महत्वपूर्ण प्रश्न
          </button>
          <button
            onClick={() => setActiveTab('mindmap')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'mindmap' ? 'bg-white text-[#00838f]' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            माइंड मैप
          </button>
        </div>
      </header>

      {/* Floating Font Size & Tool Bar */}
      <div className="max-w-md mx-auto w-full px-4 pt-2.5 flex items-center justify-between text-xs text-slate-500">
        <span className="font-medium">
          {chapter.englishTitle} · {chapter.unit}
        </span>
        <div className="flex items-center gap-1 bg-white/70 backdrop-blur-sm border border-slate-200 rounded-lg px-2 py-0.5 shadow-xs">
          <button
            onClick={() => setFontSize((s) => Math.max(13, s - 1))}
            className="p-1 hover:text-slate-900"
            title="फ़ॉन्ट छोटा करें"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-bold px-1">{fontSize}px</span>
          <button
            onClick={() => setFontSize((s) => Math.min(22, s + 1))}
            className="p-1 hover:text-slate-900"
            title="फ़ॉन्ट बड़ा करें"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tab Content Body */}
      <main className="max-w-md mx-auto w-full px-4 py-3 flex-1 space-y-4">
        {/* 1. PREMIUM NOTES TAB */}
        {activeTab === 'premium' && (
          <div className="space-y-4" style={{ fontSize: `${fontSize}px` }}>
            {/* Chapter Summary Box */}
            <div className={`p-4 rounded-2xl border ${cardThemeClasses}`}>
              <span className="text-[11px] font-bold uppercase tracking-wider text-teal-600 block mb-1">
                अध्याय का सार (Chapter Summary)
              </span>
              <p className="leading-relaxed font-devanagari font-medium">
                {chapter.premiumNotes.summary}
              </p>
            </div>

            {/* Structured Sections */}
            {chapter.premiumNotes.sections.map((section, idx) => (
              <div key={idx} className={`p-4 rounded-2xl border ${cardThemeClasses} space-y-3`}>
                <div>
                  <h3 className="text-base font-bold text-[#00838f] font-devanagari leading-snug">
                    {section.heading}
                  </h3>
                  {section.subheading && (
                    <span className="text-xs text-slate-500 block font-medium mt-0.5">
                      {section.subheading}
                    </span>
                  )}
                </div>

                <div className="space-y-2.5">
                  {section.content.map((p, pIdx) => (
                    <p key={pIdx} className="leading-relaxed font-devanagari">
                      {p}
                    </p>
                  ))}
                </div>

                {/* Diagram Callout if present */}
                {section.diagramTitle && (
                  <div className="mt-3 p-3 bg-teal-50/70 border border-teal-200 rounded-xl">
                    <span className="text-xs font-bold text-teal-900 block mb-1">
                      📊 {section.diagramTitle}
                    </span>
                    <div className="bg-white p-3 rounded-lg border border-teal-100 flex flex-col items-center justify-center text-xs text-slate-600 font-devanagari space-y-1">
                      <div className="w-full flex items-center justify-center gap-1 font-semibold text-slate-800 text-[11px]">
                        <span>जगत</span> → <span>संघ/भाग</span> → <span>वर्ग</span> → <span>गण</span> → <span>कुल</span> → <span>वंश</span> → <span>जाति</span>
                      </div>
                      <p className="text-[10px] text-teal-700 italic">
                        नीचे से ऊपर जाने पर समानताएँ घटती हैं तथा भिन्नताएँ बढ़ती हैं।
                      </p>
                    </div>
                  </div>
                )}

                {/* Key Terms */}
                {section.keyTerms && section.keyTerms.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-200/60 space-y-1.5">
                    <span className="text-xs font-bold text-slate-700">प्रमुख शब्दावली:</span>
                    {section.keyTerms.map((t, tIdx) => (
                      <div key={tIdx} className="text-xs bg-slate-100/70 p-2 rounded-lg">
                        <strong className="text-slate-900">{t.term}:</strong>{' '}
                        <span className="text-slate-700">{t.meaning}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* NEET/Board Golden Note */}
                {section.importantNote && (
                  <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs">
                    <strong>⭐ मुख्य परीक्षा बिंदु:</strong> {section.importantNote}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* 2. HANDWRITTEN NOTES TAB (Ruled paper, Kalam font, authentic styling) */}
        {activeTab === 'handwritten' && (
          <div className="space-y-4">
            {/* Highlighter selector */}
            <div className="flex items-center justify-between p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs">
              <span className="font-semibold text-amber-900">✍️ हस्तलिखित नोट्स रीडर</span>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-amber-700">हाइलाइटर:</span>
                <button
                  onClick={() => setActiveHighlighter(activeHighlighter === 'yellow' ? null : 'yellow')}
                  className={`w-5 h-5 rounded-full bg-yellow-300 ring-2 ${activeHighlighter === 'yellow' ? 'ring-slate-900' : 'ring-transparent'}`}
                  title="पीला हाइलाइटर"
                />
                <button
                  onClick={() => setActiveHighlighter(activeHighlighter === 'green' ? null : 'green')}
                  className={`w-5 h-5 rounded-full bg-green-300 ring-2 ${activeHighlighter === 'green' ? 'ring-slate-900' : 'ring-transparent'}`}
                  title="हरा हाइलाइटर"
                />
                <button
                  onClick={() => setActiveHighlighter(activeHighlighter === 'pink' ? null : 'pink')}
                  className={`w-5 h-5 rounded-full bg-pink-300 ring-2 ${activeHighlighter === 'pink' ? 'ring-slate-900' : 'ring-transparent'}`}
                  title="गुलाबी हाइलाइटर"
                />
              </div>
            </div>

            {/* Notebook Paper View */}
            <div className="paper-ruled rounded-2xl border border-stone-300 p-5 shadow-md relative overflow-hidden text-slate-900">
              {/* Left red margin line */}
              <div className="paper-margin-line space-y-6">
                <div>
                  <h3 className="text-xl font-bold font-handwritten text-indigo-900 underline decoration-indigo-300 decoration-2">
                    {chapter.handwrittenNotes.title}
                  </h3>
                  <p className="text-xs font-handwritten text-stone-500 mt-1">
                    अध्याय {chapter.chapterNumber} · टॉपर्स हैंडराइटिंग कॉपी · सचित्र आरेख
                  </p>
                </div>

                {chapter.handwrittenNotes.notePoints.map((grp, gIdx) => (
                  <div
                    key={gIdx}
                    className={`p-4 rounded-xl border-2 ${grp.color} font-handwritten text-base space-y-2`}
                  >
                    <h4 className="font-bold text-lg text-slate-900">{grp.category}</h4>
                    <ul className="space-y-2">
                      {grp.points.map((pt, pIdx) => (
                        <li
                          key={pIdx}
                          className={`leading-relaxed ${
                            activeHighlighter === 'yellow'
                              ? 'bg-yellow-200/60 px-1 rounded'
                              : activeHighlighter === 'green'
                              ? 'bg-emerald-200/60 px-1 rounded'
                              : activeHighlighter === 'pink'
                              ? 'bg-pink-200/60 px-1 rounded'
                              : ''
                          }`}
                        >
                          {pt}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}

                {/* Hand-drawn styled diagram card */}
                <div className="p-3 bg-amber-50/80 border border-dashed border-amber-400 rounded-xl font-handwritten text-sm">
                  <div className="font-bold text-stone-800 mb-1">
                    📝 हस्तलिखित परीक्षा मंत्र:
                  </div>
                  <p className="text-stone-700">
                    "जीव विज्ञान में 360/360 अंक लाने का नियम: प्रतिदिन 1 चित्र हाथ से बनाकर नामांकित करें, और NCERT के उदाहरणों का अलग चार्ट बनाएँ!"
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. NCERT SOLUTIONS TAB */}
        {activeTab === 'solutions' && (
          <div className="space-y-4">
            <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl text-xs text-sky-900">
              <strong>पाठ्यपुस्तक अभ्यास प्रश्नोत्तर:</strong> NCERT द्वारा दिए गए सभी प्रश्नों के सटीक एवं मॉडल उत्तर।
            </div>

            {chapter.ncertSolutions.map((sol, idx) => (
              <div key={sol.id} className={`p-4 rounded-2xl border ${cardThemeClasses} space-y-2.5`}>
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900 font-devanagari leading-snug">
                    प्रश्न {idx + 1}: {sol.question}
                  </h4>
                  <span className="text-[11px] font-bold text-sky-700 bg-sky-100 px-2 py-0.5 rounded-full shrink-0">
                    {sol.marks} अंक
                  </span>
                </div>
                <div className="p-3 bg-slate-50/80 border border-slate-200/60 rounded-xl text-xs text-slate-800 leading-relaxed font-devanagari whitespace-pre-line">
                  {sol.answer}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 4. MCQ QUIZ TAB */}
        {activeTab === 'mcq' && (
          <div className="space-y-4">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center justify-between">
              <div>
                <strong>ऑब्जेक्टिव MCQs टेस्ट:</strong> NCERT एवं NEET के अभ्यास प्रश्न
              </div>
              <span className="font-bold text-emerald-800">{chapter.mcqs.length} प्रश्न</span>
            </div>

            {chapter.mcqs.map((q, idx) => (
              <MCQCard key={q.id} mcq={q} questionIndex={idx} />
            ))}
          </div>
        )}

        {/* 5. IMPORTANT QUESTIONS TAB */}
        {activeTab === 'important' && (
          <div className="space-y-4">
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-900">
              <strong>बोर्ड एवं NEET के अति महत्वपूर्ण प्रश्नोत्तर:</strong> पिछले वर्षों में बार-बार पूछे गए प्रश्न।
            </div>

            {chapter.importantQuestions.map((q, idx) => (
              <div key={q.id} className={`p-4 rounded-2xl border ${cardThemeClasses} space-y-2`}>
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900 font-devanagari">
                    प्रश्न {idx + 1}: {q.question}
                  </h4>
                  <span className="text-[11px] font-bold text-orange-700 bg-orange-100 px-2 py-0.5 rounded-full shrink-0">
                    {q.marks} अंक
                  </span>
                </div>
                <div className="p-3 bg-amber-50/40 border border-amber-200/60 rounded-xl text-xs text-slate-800 leading-relaxed font-devanagari whitespace-pre-line">
                  {q.answer}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 6. MIND MAP TAB */}
        {activeTab === 'mindmap' && (
          <div className="space-y-4">
            <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl text-purple-950 space-y-3">
              <div>
                <h3 className="text-base font-bold font-devanagari flex items-center gap-2 text-purple-900">
                  <Brain className="w-5 h-5 text-purple-600" />
                  {chapter.mindMap.title} — माइंड मैप
                </h3>
                <p className="text-xs text-purple-700 mt-0.5">
                  5 मिनट में संपूर्ण अध्याय का दृश्य रिवीजन
                </p>
              </div>

              {/* Concept nodes tree */}
              <div className="space-y-2.5 pt-2">
                {chapter.mindMap.subNodes?.map((node, nIdx) => (
                  <div key={nIdx} className="bg-white p-3 rounded-xl border border-purple-100 shadow-xs space-y-1">
                    <span className="text-xs font-bold text-purple-900 block font-devanagari">
                      {node.title}
                    </span>
                    <p className="text-[11px] text-slate-600 leading-relaxed font-devanagari">
                      {node.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Previous / Next Chapter Footer Controls */}
        <div className="pt-4 pb-6 flex items-center justify-between border-t border-slate-200 gap-2">
          {prevChapterItem ? (
            <button
              onClick={() => navigateToChapter(prevChapterItem.no)}
              className="flex-1 p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-left text-xs transition-colors flex items-center gap-2 group cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-slate-800 shrink-0" />
              <div className="truncate">
                <span className="text-[10px] text-slate-400 block">पिछला</span>
                <span className="font-bold text-slate-800 truncate block font-devanagari">
                  अध्याय {prevChapterItem.no}: {prevChapterItem.title}
                </span>
              </div>
            </button>
          ) : (
            <div className="flex-1" />
          )}

          {nextChapterItem && (
            <button
              onClick={() => navigateToChapter(nextChapterItem.no)}
              className="flex-1 p-2.5 rounded-xl border border-teal-200 bg-teal-50/60 hover:bg-teal-100 text-right text-xs transition-colors flex items-center justify-end gap-2 group cursor-pointer"
            >
              <div className="truncate">
                <span className="text-[10px] text-teal-600 block">अगला</span>
                <span className="font-bold text-teal-900 truncate block font-devanagari">
                  अध्याय {nextChapterItem.no}: {nextChapterItem.title}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-teal-600 group-hover:text-teal-800 shrink-0" />
            </button>
          )}
        </div>
      </main>
    </div>
  );
};

// Sub-component for interactive MCQ with instant answer reveal
const MCQCard: React.FC<{ mcq: any; questionIndex: number }> = ({ mcq, questionIndex }) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  return (
    <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-sm space-y-3">
      <div className="flex items-start justify-between gap-2">
        <h4 className="text-sm font-bold text-slate-900 font-devanagari leading-snug">
          Q{questionIndex + 1}. {mcq.question}
        </h4>
        {mcq.examTag && (
          <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full shrink-0">
            {mcq.examTag}
          </span>
        )}
      </div>

      <div className="space-y-1.5">
        {mcq.options.map((opt: string, oIdx: number) => {
          const isSelected = selectedOption === oIdx;
          const isCorrect = oIdx === mcq.correctAnswer;
          const hasAnswered = selectedOption !== null;

          let btnClass = 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100';
          if (hasAnswered) {
            if (isCorrect) {
              btnClass = 'bg-emerald-50 border-emerald-400 text-emerald-900 font-semibold';
            } else if (isSelected) {
              btnClass = 'bg-rose-50 border-rose-300 text-rose-800 font-semibold';
            } else {
              btnClass = 'bg-slate-50 border-slate-200 text-slate-400 opacity-70';
            }
          }

          return (
            <button
              key={oIdx}
              onClick={() => setSelectedOption(oIdx)}
              className={`w-full text-left p-2.5 rounded-xl border text-xs transition-colors flex items-center justify-between font-devanagari ${btnClass}`}
            >
              <span>
                <strong className="mr-1.5">{['A', 'B', 'C', 'D'][oIdx]}.</strong> {opt}
              </span>
              {hasAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
            </button>
          );
        })}
      </div>

      {selectedOption !== null && (
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1 font-devanagari">
          <span className="font-bold text-slate-900">
            {selectedOption === mcq.correctAnswer ? '🎉 सही उत्तर!' : '❌ गलत उत्तर।'}
          </span>
          <p className="text-slate-600">{mcq.explanation}</p>
        </div>
      )}
    </div>
  );
};
