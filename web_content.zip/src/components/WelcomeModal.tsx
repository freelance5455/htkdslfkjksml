import React, { useState } from 'react';
import { Users, Shield, Check, Plus, Edit2 } from 'lucide-react';
import type { Player } from '../types/index.ts';

interface WelcomeModalProps {
  isOpen: boolean;
  players: Player[];
  activePlayerId: string | null;
  onSelectPlayer: (player: Player) => void;
  onClose?: () => void;
  onUpdatePlayerPhoto?: (playerId: string, avatarUrl: string) => void;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({
  isOpen,
  players,
  activePlayerId,
  onSelectPlayer,
  onClose,
  onUpdatePlayerPhoto,
}) => {
  const [editingPhotoFor, setEditingPhotoFor] = useState<string | null>(null);
  const [newPhotoUrl, setNewPhotoUrl] = useState('');

  if (!isOpen) return null;

  const handleSavePhoto = (playerId: string) => {
    if (onUpdatePlayerPhoto && newPhotoUrl.trim()) {
      onUpdatePlayerPhoto(playerId, newPhotoUrl.trim());
    }
    setEditingPhotoFor(null);
    setNewPhotoUrl('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mb-3">
            <Users className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            Quem é você?
          </h2>
          <p className="text-sm text-neutral-400 mt-1">
            Selecione seu perfil no grupo Garrafões para registrar tentativas, acumular médias e competir no ranking semanal.
          </p>
        </div>

        {/* Players Grid (6 initial profiles) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          {players.map((player) => {
            const isSelected = player.id === activePlayerId;
            return (
              <div
                key={player.id}
                className={`relative group flex flex-col items-center p-4 rounded-xl border text-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-md shadow-emerald-950/40'
                    : 'bg-neutral-800/60 border-neutral-700 hover:border-neutral-500 hover:bg-neutral-800'
                }`}
                onClick={() => onSelectPlayer(player)}
                role="button"
                tabIndex={0}
                aria-label={`Selecionar jogador ${player.name}`}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onSelectPlayer(player);
                  }
                }}
              >
                {/* Active check indicator */}
                {isSelected && (
                  <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-emerald-500 text-neutral-950 flex items-center justify-center text-xs font-bold">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                )}

                {/* Avatar / Photo */}
                <div className="relative mb-3">
                  {player.avatarUrl ? (
                    <img
                      src={player.avatarUrl}
                      alt={player.name}
                      className="w-16 h-16 rounded-full object-cover border-2 border-neutral-700 shadow"
                    />
                  ) : (
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-extrabold text-white shadow"
                      style={{ backgroundColor: player.color || '#10b981' }}
                    >
                      {player.name.charAt(0).toUpperCase()}
                    </div>
                  )}

                  {/* Edit photo button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingPhotoFor(player.id);
                      setNewPhotoUrl(player.avatarUrl || '');
                    }}
                    title="Editar link da foto"
                    aria-label={`Editar foto de ${player.name}`}
                    className="absolute -bottom-1 -right-1 p-1 rounded-full bg-neutral-900 border border-neutral-700 text-neutral-400 hover:text-white transition-colors"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>

                <span className="font-bold text-white text-sm group-hover:text-emerald-400 transition-colors">
                  {player.name}
                </span>

                <span className="text-[10px] text-neutral-400 mt-0.5">
                  {player.role === 'admin' ? 'Organizador' : 'Competidor'}
                </span>
              </div>
            );
          })}
        </div>

        {/* Modal for photo URL editing */}
        {editingPhotoFor && (
          <div className="mb-6 p-4 rounded-xl bg-neutral-950 border border-neutral-700">
            <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider mb-2">
              Editar Foto do Jogador
            </h4>
            <div className="flex gap-2">
              <input
                type="url"
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="https://exemplo.com/foto.jpg"
                className="flex-1 px-3 py-2 text-xs bg-neutral-900 border border-neutral-700 rounded-lg text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={() => handleSavePhoto(editingPhotoFor)}
                className="px-3 py-2 text-xs font-bold bg-emerald-500 text-neutral-950 rounded-lg hover:bg-emerald-400 transition-colors"
              >
                Salvar
              </button>
              <button
                onClick={() => setEditingPhotoFor(null)}
                className="px-3 py-2 text-xs font-bold bg-neutral-800 text-neutral-400 rounded-lg hover:bg-neutral-700 transition-colors"
              >
                Cancelar
              </button>
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Cole o link de uma imagem pública para usar como foto de perfil.
            </p>
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-neutral-400 pt-4 border-t border-neutral-800">
          <span>Sua escolha fica salva no celular.</span>
          {onClose && activePlayerId && (
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
            >
              Continuar
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
