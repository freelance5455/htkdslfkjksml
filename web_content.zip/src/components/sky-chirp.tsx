import { useEffect, useRef, useState } from "react";
import { House, Music, Pause, Play, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { ChirpAudio } from "@/game/audio";
import { SkyGame, type Phase, type UiSnapshot } from "@/game/engine";
import { loadSettings, saveSettings, type Settings } from "@/game/save";

export function SkyChirp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<ChirpAudio | null>(null);
  const gameRef = useRef<SkyGame | null>(null);
  const settingsRef = useRef<Settings>({ best: 0, soundOn: true, musicOn: true, volume: 0.85 });

  const [phase, setPhase] = useState<Phase>("menu");
  const [score, setScore] = useState(0);
  const [best, setBest] = useState<number | null>(null);
  const [newRecord, setNewRecord] = useState(false);
  const [pop, setPop] = useState(0);
  const [soundOn, setSoundOn] = useState(true);
  const [musicOn, setMusicOn] = useState(true);
  const [volume, setVolume] = useState(0.85);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const saved = loadSettings();
    settingsRef.current = saved;
    setBest(saved.best);
    setSoundOn(saved.soundOn);
    setMusicOn(saved.musicOn);
    setVolume(saved.volume);

    const audio = new ChirpAudio();
    audio.apply(saved);
    const game = new SkyGame(
      canvas,
      audio,
      {
        onUi: (ui: UiSnapshot) => {
          setPhase(ui.phase);
          setScore(ui.score);
          setPop(ui.pop);
          setNewRecord(ui.newRecord);
          setBest(ui.best);
          if (ui.best !== settingsRef.current.best) {
            settingsRef.current = { ...settingsRef.current, best: ui.best };
            saveSettings(settingsRef.current);
          }
        },
      },
      saved.best,
    );
    audioRef.current = audio;
    gameRef.current = game;
    game.start();
    return () => game.stop();
  }, []);

  function persist(partial: Partial<Settings>) {
    settingsRef.current = { ...settingsRef.current, ...partial };
    saveSettings(settingsRef.current);
  }

  function press(fn: () => void) {
    const audio = audioRef.current;
    audio?.unlock();
    audio?.click();
    fn();
  }

  function onPlay() {
    press(() => gameRef.current?.beginReady());
  }

  function onPause() {
    press(() => gameRef.current?.pause());
  }

  function onResume() {
    press(() => gameRef.current?.resume());
  }

  function onRestart() {
    press(() => gameRef.current?.restart());
  }

  function onHome() {
    press(() => gameRef.current?.home());
  }

  function toggleSound() {
    const next = !soundOn;
    const audio = audioRef.current;
    audio?.unlock();
    if (next) {
      audio?.setSoundOn(true);
      audio?.click();
    } else {
      audio?.click();
      audio?.setSoundOn(false);
    }
    setSoundOn(next);
    persist({ soundOn: next });
  }

  function toggleMusic() {
    const next = !musicOn;
    const audio = audioRef.current;
    audio?.unlock();
    audio?.click();
    audio?.setMusicOn(next);
    setMusicOn(next);
    persist({ musicOn: next });
  }

  function onVolume(value: number) {
    setVolume(value);
    audioRef.current?.unlock();
    audioRef.current?.setVolume(value);
    persist({ volume: value });
  }

  const showHud = phase === "play" || phase === "pause" || phase === "dying";

  return (
    <main className="game-root">
      <canvas ref={canvasRef} className="game-canvas" aria-label="Sky Chirp sky" />
      <p className="sr-only" aria-live="polite">
        {phase === "play" ? `Score ${score}` : phase === "over" ? `Game over. Score ${score}` : "Sky Chirp"}
      </p>

      {showHud && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between px-4 pt-[max(0.75rem,env(safe-area-inset-top))]">
          <div className="w-12" />
          <div key={pop} className="score-pop rounded-full bg-ink/40 px-5 py-1 backdrop-blur-md">
            <span className="font-display text-5xl font-semibold text-cream tabular-nums">{score}</span>
          </div>
          {phase === "play" ? (
            <button
              type="button"
              aria-label="Pause"
              onClick={onPause}
              className="pointer-events-auto flex size-12 items-center justify-center rounded-full bg-ink/40 text-cream backdrop-blur-md"
            >
              <Pause className="size-6" />
            </button>
          ) : (
            <div className="w-12" />
          )}
        </div>
      )}

      {phase === "menu" && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-end justify-center px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
          <section className="card-in pointer-events-auto w-full max-w-sm rounded-3xl border border-line bg-cream/95 p-6 text-ink shadow-xl backdrop-blur-md">
            <p className="text-center text-sm font-semibold tracking-wide text-coral">A morning flight</p>
            <h1 className="mt-1 text-center font-display text-5xl font-semibold leading-tight">Sky Chirp</h1>
            <p className="mt-1 text-center text-mist">Tap to flap. Slip through the gates.</p>
            <p className="mt-4 text-center font-display text-lg">Best {best ?? "—"}</p>
            <button
              type="button"
              onClick={onPlay}
              className="mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-xl font-semibold text-cream transition active:scale-95"
            >
              <Play className="size-6" />
              Play
            </button>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Toggle on={soundOn} onClick={toggleSound} label="Sound" icon={soundOn ? "on" : "off"} />
              <Toggle on={musicOn} onClick={toggleMusic} label="Music" icon="music" />
            </div>
            <label htmlFor="volume" className="mt-3 block text-sm font-medium text-mist">
              Volume
            </label>
            <input
              id="volume"
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              aria-valuetext={`${Math.round(volume * 100)} percent`}
              onChange={(e) => onVolume(Number(e.target.value))}
            />
            <p className="hidden text-center text-sm text-mist sm:block">Space or click also starts</p>
          </section>
        </div>
      )}

      {phase === "ready" && (
        <div className="pointer-events-none absolute inset-x-0 top-1/2 z-20 flex -translate-y-1/2 justify-center px-4">
          <div className="card-in rounded-full bg-cream/95 px-6 py-3 text-center text-ink shadow-lg">
            <p className="font-display text-2xl font-semibold leading-tight">Get ready</p>
            <p className="text-sm text-mist">Tap anywhere to flap</p>
          </div>
        </div>
      )}

      {phase === "pause" && (
        <Modal title="Paused">
          <button
            type="button"
            onClick={onResume}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-lg font-semibold text-cream transition active:scale-95"
          >
            <Play className="size-5" />
            Resume
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95"
          >
            <RotateCcw className="size-5" />
            Restart
          </button>
          <button
            type="button"
            onClick={onHome}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95"
          >
            <House className="size-5" />
            Home
          </button>
        </Modal>
      )}

      {phase === "over" && (
        <Modal title="Game over">
          {newRecord && score > 0 && (
            <p className="record-in text-center font-display text-lg font-semibold text-coral">New record</p>
          )}
          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="rounded-2xl bg-foam px-3 py-2">
              <p className="text-xs font-semibold tracking-wide text-mist">Score</p>
              <p className="font-display text-4xl font-semibold tabular-nums">{score}</p>
            </div>
            <div className="rounded-2xl bg-foam px-3 py-2">
              <p className="text-xs font-semibold tracking-wide text-mist">Best</p>
              <p className="font-display text-4xl font-semibold tabular-nums">{best ?? 0}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onRestart}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-coral font-display text-lg font-semibold text-cream transition active:scale-95"
          >
            <RotateCcw className="size-5" />
            Restart
          </button>
          <button
            type="button"
            onClick={onHome}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-foam font-display text-lg font-semibold text-ink transition active:scale-95"
          >
            <House className="size-5" />
            Home
          </button>
        </Modal>
      )}
    </main>
  );
}

function Toggle({
  on,
  onClick,
  label,
  icon,
}: {
  on: boolean;
  onClick: () => void;
  label: string;
  icon: "on" | "off" | "music";
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={`flex h-12 items-center justify-center gap-2 rounded-2xl font-display text-base font-semibold transition active:scale-95 ${
        on ? "bg-jade text-cream" : "bg-foam text-mist"
      }`}
    >
      {icon === "music" ? <Music className="size-5" /> : icon === "on" ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
      {label}
    </button>
  );
}

function Modal({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-ink/45" data-no-flap />
      <section className="card-in relative w-full max-w-sm space-y-3 rounded-3xl border border-line bg-cream p-6 text-ink shadow-xl">
        <h2 className="text-center font-display text-4xl font-semibold leading-tight">{title}</h2>
        {children}
      </section>
    </div>
  );
}
