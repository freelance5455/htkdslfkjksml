import { useCallback, useEffect, useRef, useState } from "react";
import { clearOcr, getFile, getOcr, putOcr, type OcrCacheEntry } from "@/lib/store";
import { ocrStatusFa, recognizeCanvas } from "@/lib/ocr";
import { PdfEngine, acquireEngine, releaseEngine } from "@/lib/pdf";
import { clamp, fa, faPercent, timeAgo } from "@/lib/format";
import {
  createLineMeasurer,
  composeOcrPages,
  findReadingPage,
  paginateSource,
  type ExtractedPage,
  type ReadingPage,
  type Stage,
} from "@/lib/reflow";
import type { Book, Settings, TextPosition, TocItem } from "@/lib/types";
import { cn } from "@/utils/cn";
import { FullscreenButton } from "./FullscreenButton";
import { Pager, type GoFn } from "./Pager";
import { SettingsSheet } from "./SettingsSheet";
import {
  IconBookmark,
  IconChevronLeft,
  IconChevronRight,
  IconClose,
  IconGear,
  IconLayers,
  IconLeaf,
  IconMoon,
  IconSun,
  IconSwipe,
  IconToc,
} from "./Icons";
import { Btn, Segmented, Sheet } from "./ui";

interface OcrStatus {
  page: number;
  status: string;
  progress: number;
}

interface Props {
  book: Book;
  settings: Settings;
  onSettings: (s: Settings) => void;
  onBookPatch: (id: string, patch: Partial<Book>) => void;
  onClose: () => void;
  onDelete: (id: string) => void;
}

const CHROME = {
  paper: {
    bar: "bg-[#f2eee4]/96 border-[#ddd4c2]",
    text: "text-[#2b2620]",
    sub: "text-[#7d7263]",
    btn: "border-[#ddd4c2] bg-[#fbf9f4] hover:bg-[#efe9dc]",
    fill: "#b8842c",
  },
  sepia: {
    bar: "bg-[#e8dabd]/96 border-[#d2bfa0]",
    text: "text-[#3d3325]",
    sub: "text-[#85745c]",
    btn: "border-[#d2bfa0] bg-[#f1e6cf] hover:bg-[#e6d8bb]",
    fill: "#9a6a1c",
  },
  night: {
    bar: "bg-[#0d1116]/96 border-[#1e2733]",
    text: "text-[#dfe6ee]",
    sub: "text-[#8b98a9]",
    btn: "border-[#263140] bg-[#151b24] hover:bg-[#1d2531]",
    fill: "#e8b04b",
  },
};

export function Reader({ book, settings, onSettings, onBookPatch, onClose, onDelete }: Props) {
  const [engine, setEngine] = useState<PdfEngine | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>({ w: 0, h: 0 });
  const [pages, setPages] = useState<ReadingPage[]>([]);
  const [processed, setProcessed] = useState(0);
  const [complete, setComplete] = useState(false);
  const [noText, setNoText] = useState(false);
  const [restoring, setRestoring] = useState(true);
  const [index, setIndex] = useState(0);
  const [pendingNext, setPendingNext] = useState(false);
  const [pendingJump, setPendingJump] = useState<TextPosition | null>(null);
  const [chrome, setChrome] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [marksOpen, setMarksOpen] = useState(false);
  const [marksTab, setMarksTab] = useState<"toc" | "marks">("toc");
  const [toc, setToc] = useState<TocItem[] | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [hint, setHint] = useState(!settings.hintShown);
  const [fontVersion, setFontVersion] = useState(0);
  const [ocrStatus, setOcrStatus] = useState<OcrStatus | null>(null);
  const [ocrRun, setOcrRun] = useState(0);
  const statusSink = useRef<((s: OcrStatus) => void) | null>(null);
  const ocrMem = useRef(new Map<string, OcrCacheEntry>());
  const inflight = useRef(new Map<string, Promise<OcrCacheEntry>>());

  const stageRef = useRef<HTMLDivElement | null>(null);
  const goRef = useRef<GoFn | null>(null);
  const anchorRef = useRef<TextPosition>({
    page: book.progress?.page || 1,
    offset: book.progress?.offset || 0,
  });
  const pagesRef = useRef(pages);
  const indexRef = useRef(index);
  const restoringRef = useRef(true);
  const toastTimer = useRef<number | null>(null);
  pagesRef.current = pages;
  indexRef.current = index;

  const say = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2200);
  }, []);

  // Opening uses the local PDF Blob. No PDF page image enters the reading view.
  useEffect(() => {
    let alive = true;
    let acquired = false;
    (async () => {
      try {
        const pdf = await acquireEngine(book.id, async () => {
          const blob = await getFile(book.id);
          if (!blob) throw new Error("file-missing");
          return PdfEngine.open(new Uint8Array(await blob.arrayBuffer()));
        });
        acquired = true;
        if (!alive) {
          releaseEngine(book.id);
          acquired = false;
          return;
        }
        setEngine(pdf);
        pdf.outline().then((items) => {
          if (alive) setToc(items.length ? items : null);
        });
      } catch (error) {
        if (acquired) {
          releaseEngine(book.id);
          acquired = false;
        }
        if (alive) {
          setErr(
            (error as Error)?.message === "file-missing"
              ? "فایل این کتاب در حافظهٔ دستگاه پیدا نشد."
              : "این PDF باز نشد. ممکن است فایل رمز داشته باشد یا آسیب دیده باشد.",
          );
        }
      }
    })();
    return () => {
      alive = false;
      if (acquired) releaseEngine(book.id);
    };
  }, [book.id]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      setStage((prev) =>
        Math.abs(prev.w - width) > 1 || Math.abs(prev.h - height) > 1
          ? { w: width, h: height }
          : prev,
      );
    });
    observer.observe(el);
    setStage({ w: el.clientWidth, h: el.clientHeight });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!document.fonts?.addEventListener) return;
    const onFonts = () => setFontVersion((version) => version + 1);
    document.fonts.addEventListener("loadingdone", onFonts);
    return () => document.fonts.removeEventListener("loadingdone", onFonts);
  }, []);

  // Every source page starts as a placeholder so the book opens immediately.
  // A priority loop then processes the page being read first: it uses the PDF
  // text layer when present, otherwise renders the page image and runs OCR.
  useEffect(() => {
    if (!engine || stage.w < 160) return;
    let cancelled = false;
    const total = engine.pageCount;
    const forced = settings.direction === "auto" ? undefined : settings.direction;
    const lang = settings.ocrLang;
    const placeholder = (page: number): ReadingPage => ({
      page, offset: 0, end: 0, text: "", lines: 0, part: 1, parts: 1,
      direction: forced ?? "rtl", pending: true,
    });
    const perPage: ReadingPage[][] = Array.from({ length: total }, (_, i) => [placeholder(i + 1)]);
    const done = new Uint8Array(total);
    let doneCount = 0;
    let lastCommit = 0;

    const commit = () => {
      lastCommit = performance.now();
      const flat = perPage.flat();
      pagesRef.current = flat;
      setPages(flat);
      setIndex(findReadingPage(flat, anchorRef.current));
    };

    restoringRef.current = true;
    setRestoring(true);
    setComplete(false);
    setNoText(false);
    setPendingNext(false);
    setProcessed(0);
    setOcrStatus(null);
    statusSink.current = (status) => { if (!cancelled) setOcrStatus(status); };
    commit();

    const nextPage = (): number => {
      const cur = clamp(anchorRef.current.page, 1, total);
      // the page on screen, then a short read-ahead, then onwards, then earlier pages
      for (let p = cur; p <= total; p++) if (!done[p - 1]) return p;
      for (let p = cur - 1; p >= 1; p--) if (!done[p - 1]) return p;
      return 0;
    };

    const ocrPage = async (page: number) => {
      const key = `${lang}:${page}`;
      const mem = ocrMem.current.get(key);
      if (mem) return mem;
      let job = inflight.current.get(key);
      if (!job) {
        job = (async () => {
          const cached = await getOcr(book.id, page, lang);
          if (cached) return cached;
          statusSink.current?.({ page, status: "rendering", progress: 0 });
          const canvas = await engine.renderForOcr(page);
          const result = await recognizeCanvas(canvas, lang, (prog) =>
            statusSink.current?.({ page, status: prog.status, progress: prog.progress }),
          );
          await putOcr(book.id, page, lang, result);
          return result;
        })().finally(() => inflight.current.delete(key));
        inflight.current.set(key, job);
      }
      const result = await job;
      ocrMem.current.set(key, result);
      return result;
    };

    (async () => {
      let measurer: ReturnType<typeof createLineMeasurer> | null = null;
      try {
        if (document.fonts?.load) {
          // An unavailable web font must not block an offline PDF from opening.
          await Promise.race([
            document.fonts.load(`${settings.fontSize}px Vazirmatn`).catch(() => undefined),
            new Promise<void>((resolve) => window.setTimeout(resolve, 1800)),
          ]);
        }
        if (cancelled) return;
        measurer = createLineMeasurer({
          fontSize: settings.fontSize,
          lineHeight: settings.lineHeight,
          linesPerPage: settings.linesPerPage,
          width: Math.min(stage.w, 720) - 52,
          direction: settings.direction,
        });
        restoringRef.current = false;
        setRestoring(false);

        for (let page = nextPage(); page && !cancelled; page = nextPage()) {
          let source: ExtractedPage = await engine.extractPage(page, forced);
          let confidence: number | undefined;
          let failed = false;
          const letters = source.text.replace(/[^\p{L}]/gu, "").length;
          const needsOcr = settings.ocr && (settings.ocrForce || letters < 20);
          if (needsOcr) {
            try {
              const result = await ocrPage(page);
              const hasImage = result.blocks?.some((block) => block.type === "image" && block.src);
              if (result.text.trim() || hasImage || letters < 20) {
                const direction = forced ?? result.direction;
                measurer.setDirection(direction);
                perPage[page - 1] = composeOcrPages(
                  page,
                  result.blocks?.length ? result.blocks : [{ type: "text", text: result.text }],
                  direction,
                  settings.linesPerPage,
                  measurer.measure,
                ).map((rp) => ({ ...rp, confidence: result.confidence }));
                done[page - 1] = 1;
                doneCount++;
                setProcessed(doneCount);
                if (Math.abs(page - anchorRef.current.page) <= 2 || performance.now() - lastCommit > 160) commit();
                if (doneCount % 6 === 0) await new Promise<void>((r) => window.setTimeout(r, 0));
                continue;
              }
            } catch {
              failed = letters < 20;
            }
          }
          if (cancelled) break;
          const direction = forced ?? source.direction;
          measurer.setDirection(direction);
          perPage[page - 1] = paginateSource({ ...source, direction }, settings.linesPerPage, measurer.measure)
            .map((rp) => ({ ...rp, confidence, failed }));
          done[page - 1] = 1;
          doneCount++;
          setProcessed(doneCount);
          const near = Math.abs(page - anchorRef.current.page) <= 2;
          if (near || source.ocr || performance.now() - lastCommit > 160) commit();
          if (doneCount % 6 === 0) await new Promise<void>((r) => window.setTimeout(r, 0));
        }
        if (!cancelled) {
          commit();
          setOcrStatus(null);
          setComplete(true);
          setNoText(perPage.every((list) => list.every((rp) => !rp.text.trim() && !rp.image && !rp.failed)));
        }
      } catch {
        if (!cancelled) setErr("استخراج متن از این PDF ممکن نشد. فایل دیگری را امتحان کنید.");
      } finally {
        measurer?.dispose();
      }
    })();
    return () => {
      cancelled = true;
      statusSink.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine, stage.w, settings.fontSize, settings.linesPerPage, settings.lineHeight, settings.direction,
      settings.ocr, settings.ocrForce, settings.ocrLang, fontVersion, ocrRun]);

  const current = pages[index] ?? null;
  const percent = current && engine
    ? ((current.page - 1 + current.part / current.parts) / engine.pageCount) * 100
    : 0;

  const savePosition = useCallback(() => {
    const p = pagesRef.current[indexRef.current];
    if (!p || p.pending || !engine || !settings.autoSave || restoringRef.current) return;
    onBookPatch(book.id, {
      progress: {
        page: p.page,
        offset: p.offset,
        displayPage: indexRef.current + 1,
        displayTotal: pagesRef.current.length,
        percent: ((p.page - 1 + p.part / p.parts) / engine.pageCount) * 100,
        at: Date.now(),
      },
    });
  }, [book.id, engine, onBookPatch, settings.autoSave]);

  useEffect(() => {
    if (restoring || !current || !settings.autoSave) return;
    const timer = window.setTimeout(savePosition, 380);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, current?.page, current?.offset, restoring, settings.autoSave]);

  useEffect(() => {
    const saveOnHide = () => {
      if (document.visibilityState === "hidden") savePosition();
    };
    window.addEventListener("pagehide", savePosition);
    document.addEventListener("visibilitychange", saveOnHide);
    return () => {
      window.removeEventListener("pagehide", savePosition);
      document.removeEventListener("visibilitychange", saveOnHide);
    };
  }, [savePosition]);

  useEffect(() => {
    if (!pendingNext || restoring || pages.length <= index + 1) return;
    setPendingNext(false);
    setIndex(index + 1);
  }, [pages.length, pendingNext, index, restoring]);

  useEffect(() => {
    if (!pendingJump || processed < pendingJump.page || restoring) return;
    setIndex(findReadingPage(pages, pendingJump));
    setPendingJump(null);
  }, [pendingJump, processed, pages, restoring]);

  const navigate = (i: number) => {
    if (!pages.length) return;
    const safe = clamp(i, 0, pages.length - 1);
    setIndex(safe);
    const p = pages[safe];
    anchorRef.current = { page: p.page, offset: p.offset };
  };

  const jumpTo = (position: TextPosition) => {
    setMarksOpen(false);
    anchorRef.current = { ...position };
    if (pages.length) setIndex(findReadingPage(pages, position));
  };

  const redoOcr = async () => {
    await clearOcr(book.id);
    ocrMem.current.clear();
    setSettingsOpen(false);
    setOcrRun((n) => n + 1);
    say("تشخیص متن صفحه‌ها از نو انجام می‌شود");
  };

  const changeSettings = (patch: Partial<Settings>) => {
    if (current) anchorRef.current = { page: current.page, offset: current.offset };
    onSettings({ ...settings, ...patch });
  };

  const dismissHint = () => {
    if (!hint) return;
    setHint(false);
    if (!settings.hintShown) changeSettings({ hintShown: true });
  };

  const toggleBookmark = () => {
    if (!current) return;
    const existing = book.bookmarks.some(
      (mark) => mark.page === current.page && mark.offset === current.offset,
    );
    const marks = existing
      ? book.bookmarks.filter(
          (mark) => !(mark.page === current.page && mark.offset === current.offset),
        )
      : [...book.bookmarks, { page: current.page, offset: current.offset, at: Date.now() }]
          .sort((a, b) => a.page - b.page || a.offset - b.offset);
    onBookPatch(book.id, { bookmarks: marks });
    say(existing ? "نشانک برداشته شد" : "این صفحه نشانک‌گذاری شد");
  };

  const c = CHROME[settings.theme];
  const navRTL = settings.direction === "rtl" ||
    (settings.direction === "auto" && (pages.find((p) => p.text && !p.pending)?.direction ?? "rtl") === "rtl");
  const bookmarked = !!current && book.bookmarks.some(
    (mark) => mark.page === current.page && mark.offset === current.offset,
  );
  const loading = !engine || restoring || !pages.length;

  const renderPage = (i: number) => {
    const p = pages[i];
    if (!p) return null;
    const direction = settings.direction === "auto" ? p.direction : settings.direction;
    return (
      <article
        className={cn(
          "reader-leaf box-border flex min-h-full max-w-[720px] flex-col px-[26px] pb-9 pt-6",
          settings.theme === "paper" && "text-[#27241f]",
          settings.theme === "sepia" && "text-[#3d3023]",
          settings.theme === "night" && "text-[#dce4e9]",
        )}
        style={{ width: `${stage.w}px`, minHeight: `${stage.h}px` }}
      >
        <div className="mb-6 flex flex-wrap items-center gap-2 text-[10px] tracking-wide">
          <span className="h-[1px] w-5 bg-current opacity-30" />
          <span className="opacity-55">
            {p.image && !p.text ? "تصویر" : "متن"} صفحهٔ {fa(p.page)} از PDF
          </span>
          {!p.pending && (
            <>
              <span className="opacity-55">·</span>
              <span className="opacity-55">بخش {fa(p.part)} از {fa(p.parts)}</span>
            </>
          )}
          {p.ocr && (
            <span className="rounded-full border border-current/20 bg-[#e8b04b]/20 px-2 py-[1px] font-medium opacity-80">
              تشخیص از تصویر (OCR){p.confidence ? ` · دقت ${fa(Math.round(p.confidence))}٪` : ""}
            </span>
          )}
        </div>
        {p.image && (
          <img
            src={p.image}
            alt="تصویر"
            draggable={false}
            className="pointer-events-none mb-4 block w-full select-none"
          />
        )}
        {p.pending ? (
          <div className="my-auto flex flex-col items-center gap-4 px-2 text-center">
            <div className="ocr-scan relative h-[132px] w-[100px] overflow-hidden rounded-md border border-current/20 bg-current/[0.04]">
              {Array.from({ length: 9 }).map((_, k) => (
                <span
                  key={k}
                  className="absolute right-3 h-[4px] rounded-full bg-current opacity-25"
                  style={{ top: 16 + k * 12, width: `${62 - ((k * 17) % 26)}%` }}
                />
              ))}
              <span className="ocr-beam absolute inset-x-0 h-8" />
            </div>
            {ocrStatus?.page === p.page ? (
              <>
                <p className="text-[15px] font-medium leading-7">
                  {ocrStatus.status === "rendering"
                    ? "در حال آماده کردن تصویر صفحه…"
                    : `${ocrStatusFa(ocrStatus.status)}…`}
                </p>
                <div className="h-1.5 w-48 overflow-hidden rounded-full bg-current/10">
                  <div
                    className="h-full rounded-full bg-[#e8b04b] transition-[width] duration-300"
                    style={{ width: `${Math.round((ocrStatus.status === "recognizing text" ? ocrStatus.progress : 0.04) * 100)}%` }}
                  />
                </div>
                <p className="max-w-[30ch] text-[11.5px] leading-6 opacity-60">
                  این صفحه تصویری است؛ نوشته‌های آن با OCR شناسایی و سپس درشت بازچینی می‌شود.
                </p>
              </>
            ) : (
              <p className="text-[14px] leading-7 opacity-70">در صف پردازش متن…</p>
            )}
          </div>
        ) : p.text ? (
          <div
            dir={direction}
            lang={direction === "rtl" ? "fa" : "en"}
            className="reflow-text font-body font-normal"
            style={{ fontSize: `${settings.fontSize}px`, lineHeight: settings.lineHeight }}
          >
            {p.text}
          </div>
        ) : p.failed && !p.image ? (
          <div className="my-auto flex flex-col items-center gap-3 text-center">
            <p className="text-[15px] font-medium leading-8">تشخیص متن این صفحه انجام نشد</p>
            <p className="max-w-[32ch] text-[12px] leading-6 opacity-65">
              بار اول، دادهٔ زبان OCR (چند مگابایت) از اینترنت دریافت می‌شود. اتصال را بررسی کنید و دوباره امتحان کنید.
            </p>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onPointerUp={(e) => e.stopPropagation()}
              onClick={() => setOcrRun((n) => n + 1)}
              className="press mt-1 rounded-xl border border-current/25 px-4 py-2 text-[13px] font-bold"
            >
              تلاش دوباره
            </button>
          </div>
        ) : !p.image ? (
          <div className="my-auto text-center text-[15px] leading-8 opacity-65">
            {settings.ocr
              ? "در این صفحه نوشته‌ای پیدا نشد (احتمالاً صفحهٔ تصویر یا سفید)."
              : "این صفحه متن قابل استخراج ندارد. برای خواندن صفحه‌های تصویری، OCR را در تنظیمات روشن کنید."}
          </div>
        ) : null}
        <div className="mt-auto flex items-center justify-between gap-2 pt-9 text-[10px] opacity-50">
          <span>درشت‌نما · {p.image && !p.text ? "تصویر اصلی" : p.ocr ? "متن تشخیص‌داده‌شده" : "متن بازچینی‌شده"}</span>
          <span>{fa(i + 1)} / {complete ? fa(pages.length) : "…"}</span>
        </div>
      </article>
    );
  };

  if (err) {
    return (
      <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-ink px-8 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-2xl border border-ember/40 bg-ember/10 text-ember">
          <IconClose size={26} />
        </span>
        <p className="max-w-[36ch] text-sm leading-7 text-mist">{err}</p>
        <Btn variant="outline" onClick={onClose}>بازگشت به کتابخانه</Btn>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-40 flex flex-col overflow-hidden bg-ink">
      <header
        className={cn(
          "relative z-30 flex shrink-0 items-center gap-1.5 border-b px-2 transition-opacity duration-300",
          c.bar, c.text,
          chrome ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        style={{ paddingTop: "max(env(safe-area-inset-top),6px)" }}
      >
        <button
          onClick={() => { savePosition(); onClose(); }}
          aria-label="بازگشت به کتابخانه"
          className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
        >
          <IconChevronRight size={20} />
        </button>
        <div className="min-w-0 flex-1 px-1">
          <h1 className="truncate font-display text-[16px] leading-tight">{book.title}</h1>
          <p className={cn("mt-0.5 truncate text-[10.5px]", c.sub)}>
            {!current
              ? "در حال استخراج متن…"
              : current.pending
                ? `صفحهٔ ${fa(current.page)} PDF · در حال تشخیص متن…`
                : `صفحهٔ ${fa(current.page)} PDF · بخش ${fa(current.part)} از ${fa(current.parts)}${current.ocr ? " · OCR" : ""}`}
          </p>
        </div>
        <button
          onClick={toggleBookmark}
          aria-label="نشانک‌گذاری"
          className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
        >
          <IconBookmark size={19} filled={bookmarked} className={bookmarked ? "text-gold" : undefined} />
        </button>
        <button
          onClick={() => {
            setMarksTab(toc?.length ? "toc" : "marks");
            setMarksOpen(true);
          }}
          aria-label="فهرست و نشانک‌ها"
          className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
        >
          <IconToc size={19} />
        </button>
        <button
          onClick={() => {
            const order: Settings["theme"][] = ["paper", "sepia", "night"];
            changeSettings({ theme: order[(order.indexOf(settings.theme) + 1) % order.length] });
          }}
          aria-label="تغییر رنگ صفحه"
          className={cn("press hidden h-10 w-10 shrink-0 place-items-center rounded-xl border min-[420px]:grid", c.btn)}
        >
          {settings.theme === "paper" ? <IconSun size={19} />
            : settings.theme === "sepia" ? <IconLeaf size={19} /> : <IconMoon size={19} />}
        </button>
        <FullscreenButton
          className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
        />
        <button
          onClick={() => setSettingsOpen(true)}
          aria-label="تنظیمات نوشته"
          className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border text-gold", c.btn)}
        >
          <IconGear size={19} />
        </button>
      </header>

      <main
        ref={stageRef}
        className={cn(
          "paper-stage relative flex-1 overflow-hidden",
          settings.theme === "paper" && "stage-paper",
          settings.theme === "sepia" && "stage-sepia",
          settings.theme === "night" && "stage-night",
        )}
      >
        {pages.length > 0 && stage.w > 0 && !restoring && !noText && (
          <Pager
            total={pages.length}
            index={clamp(index, 0, pages.length - 1)}
            onIndex={navigate}
            rtl={navRTL}
            stage={stage}
            tapZones={settings.tapZones}
            allowScrollY
            goRef={goRef}
            onFirstGesture={dismissHint}
            onCenterTap={() => setChrome((visible) => !visible)}
            onReachEnd={() => {
              if (!complete) {
                setPendingNext(true);
                say("صفحهٔ بعد در حال آماده شدن است…");
              }
            }}
            renderPage={renderPage}
          />
        )}

        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-7 text-center">
            <div className="relative grid h-12 w-12 place-items-center text-gold2">
              <span className="absolute inset-0 animate-spin rounded-full border-2 border-gold/25 border-t-gold" />
              <IconLayers size={19} />
            </div>
            <div>
              <p className={cn("text-[13px]", settings.theme === "night" ? "text-chalk" : "text-[#383129]")}>در حال استخراج و بازچینی متن…</p>
              <p className="mt-1 text-[11px] text-mist">
                {engine ? `صفحهٔ ${fa(processed)} از ${fa(engine.pageCount)} PDF` : book.title}
              </p>
            </div>
            {engine && (
              <div className="h-1.5 w-40 overflow-hidden rounded-full bg-gold/15">
                <div className="h-full rounded-full bg-gold transition-[width] duration-300" style={{ width: `${(processed / engine.pageCount) * 100}%` }} />
              </div>
            )}
          </div>
        )}

        {noText && (
          <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
            <span className="grid h-14 w-14 place-items-center rounded-2xl border border-ember/30 bg-ember/10 text-ember">
              <IconClose size={26} />
            </span>
            <h2 className="mt-4 font-display text-[21px] text-chalk">متنی برای بازچینی پیدا نشد</h2>
            <p className="mt-2 max-w-[38ch] text-[12px] leading-7 text-mist">
              {settings.ocr
                ? "حتی با تشخیص نوری (OCR) نوشته‌ای در صفحه‌ها پیدا نشد. اگر زبان کتاب فارسی/عربی/انگلیسی نیست یا تصویرها بسیار کم‌کیفیت‌اند، زبان OCR را در تنظیمات عوض کنید."
                : "این PDF تصویری است و لایهٔ متن ندارد. با روشن کردن OCR، نوشته‌های تصویر شناسایی و به متن درشت تبدیل می‌شوند."}
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-2">
              {!settings.ocr && (
                <Btn onClick={() => changeSettings({ ocr: true })}>روشن کردن OCR و تبدیل به متن</Btn>
              )}
              {settings.ocr && <Btn onClick={() => setSettingsOpen(true)}>تنظیمات OCR</Btn>}
              <Btn variant="outline" onClick={onClose}>بازگشت به کتابخانه</Btn>
            </div>
          </div>
        )}

        {hint && !loading && !noText && !current?.pending && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center bg-ink/45">
            <div className="popin pointer-events-auto flex flex-col items-center gap-3 rounded-2xl border border-white/12 bg-ink2/95 px-6 py-5 text-center shadow-2xl">
              <span className="text-gold2" style={{ animation: "swipehint 1.9s ease-in-out infinite" }}>
                <IconSwipe size={39} />
              </span>
              <p className="max-w-[250px] text-[12px] leading-6 text-chalk">
                این‌ها نوشته‌های استخراج‌شده از PDF هستند؛ با کشیدن انگشت به چپ یا راست، صفحه‌های بازچینی‌شده را ورق بزنید.
              </p>
              <p className="text-[10.5px] text-mist">برای دیدن بقیهٔ خط‌ها، عمودی اسکرول کنید.</p>
              <Btn className="!py-2" onClick={dismissHint}>فهمیدم</Btn>
            </div>
          </div>
        )}

        {toast && (
          <div className="pointer-events-none absolute inset-x-0 bottom-4 z-20 flex justify-center">
            <span className="rounded-full bg-ink/85 px-4 py-1.5 text-[11px] text-chalk shadow-lg">{toast}</span>
          </div>
        )}
      </main>

      <footer
        className={cn(
          "relative z-30 shrink-0 border-t px-3 pb-[max(env(safe-area-inset-bottom),8px)] pt-2 transition-opacity duration-300",
          c.bar, c.text,
          chrome ? "opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <div className="flex items-center gap-2">
          <button
            onClick={() => goRef.current?.(-1)}
            aria-label="صفحهٔ قبل"
            className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
          >
            {navRTL ? <IconChevronRight size={19} /> : <IconChevronLeft size={19} />}
          </button>
          <div className="min-w-0 flex-1">
            <input
              className="slider"
              type="range"
              min={0}
              max={Math.max(0, pages.length - 1)}
              value={clamp(index, 0, Math.max(0, pages.length - 1))}
              dir="rtl"
              onChange={(event) => navigate(Number(event.target.value))}
              style={{
                ["--pct" as string]: `${pages.length > 1 ? (index / (pages.length - 1)) * 100 : 0}%`,
                ["--fill-a" as string]: c.fill,
              }}
            />
            <div className={cn("-mt-1 flex items-center justify-between gap-2 text-[10px]", c.sub)}>
              <span>
                صفحهٔ خواندنی {fa(index + 1)} از {complete ? fa(pages.length) : `${fa(pages.length)}+`}
              </span>
              <span className="font-display text-[12px]" style={{ color: c.fill }}>
                {faPercent(percent)}
              </span>
            </div>
          </div>
          <button
            onClick={() => goRef.current?.(1)}
            aria-label="صفحهٔ بعد"
            className={cn("press grid h-10 w-10 shrink-0 place-items-center rounded-xl border", c.btn)}
          >
            {navRTL ? <IconChevronLeft size={19} /> : <IconChevronRight size={19} />}
          </button>
        </div>
        {!complete && engine && !loading && (
          <p className={cn("pt-1 text-center text-[9.5px]", c.sub)}>
            {ocrStatus
              ? `OCR صفحهٔ ${fa(ocrStatus.page)} · ${ocrStatusFa(ocrStatus.status)}${ocrStatus.status === "recognizing text" ? ` ${fa(Math.round(ocrStatus.progress * 100))}٪` : ""}`
              : "در حال آماده‌سازی متن"}{" "}
            · {fa(processed)} / {fa(engine.pageCount)} صفحه
          </p>
        )}
      </footer>

      <SettingsSheet
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        update={changeSettings}
        book={book}
        readingPageCount={complete ? pages.length : undefined}
        ocrPages={new Set(pages.filter((p) => p.ocr).map((p) => p.page)).size}
        onRedoOcr={redoOcr}
        onResetProgress={() => {
          anchorRef.current = { page: 1, offset: 0 };
          navigate(0);
          onBookPatch(book.id, { progress: null });
          setSettingsOpen(false);
          say("از آغاز کتاب باز می‌شود");
        }}
        onDeleteBook={() => {
          setSettingsOpen(false);
          onDelete(book.id);
        }}
      />

      <Sheet
        open={marksOpen}
        onClose={() => setMarksOpen(false)}
        title="فهرست و نشانک‌ها"
        subtitle={book.title}
      >
        <Segmented
          value={marksTab}
          onChange={setMarksTab}
          options={[
            { value: "toc", label: "فهرست کتاب" },
            { value: "marks", label: `نشانک‌ها (${fa(book.bookmarks.length)})` },
          ]}
        />
        <div className="mt-3 space-y-1.5">
          {marksTab === "toc" && (
            toc?.length ? toc.map((entry, i) => (
              <button
                key={i}
                onClick={() => jumpTo({ page: entry.page, offset: 0 })}
                className="press flex w-full items-center gap-3 rounded-xl border border-line/70 bg-ink2/50 px-3 py-2.5 text-start hover:border-gold/40"
                style={{ paddingInlineStart: `${12 + entry.depth * 14}px` }}
              >
                <span className="min-w-0 flex-1 truncate text-[12.5px] text-chalk/90">{entry.title}</span>
                <span className="shrink-0 rounded-md bg-panel2 px-1.5 py-0.5 text-[10px] text-mist">{fa(entry.page)}</span>
              </button>
            )) : (
              <div className="rounded-xl border border-dashed border-line px-4 py-6 text-center">
                <p className="text-[12px] leading-6 text-mist">این PDF فهرست ندارد. شمارهٔ صفحهٔ اصلی را وارد کنید:</p>
                <div className="mt-3 flex items-center justify-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={book.pageCount}
                    defaultValue={current?.page ?? 1}
                    id="jump-source-page"
                    className="w-20 rounded-lg border border-line bg-ink2 px-2 py-2 text-center text-[13px] text-chalk outline-none focus:border-gold"
                    dir="ltr"
                  />
                  <Btn onClick={() => {
                    const input = document.getElementById("jump-source-page") as HTMLInputElement | null;
                    jumpTo({ page: clamp(Number(input?.value) || 1, 1, book.pageCount), offset: 0 });
                  }}>برو به صفحه</Btn>
                </div>
              </div>
            )
          )}
          {marksTab === "marks" && (
            book.bookmarks.length ? book.bookmarks.map((mark, i) => (
              <div key={`${mark.page}-${mark.offset}-${i}`} className="flex items-center gap-2 rounded-xl border border-line/70 bg-ink2/50 px-3 py-2">
                <button
                  onClick={() => jumpTo(mark)}
                  className="press min-w-0 flex-1 text-start"
                >
                  <span className="block text-[12.5px] font-medium text-chalk/90">
                    صفحهٔ {fa(mark.page)} PDF · جایگاه {fa(mark.offset)}
                  </span>
                  <span className="text-[10px] text-mist">{timeAgo(mark.at)}</span>
                </button>
                <button
                  onClick={() => onBookPatch(book.id, { bookmarks: book.bookmarks.filter((_, j) => j !== i) })}
                  aria-label="حذف نشانک"
                  className="press grid h-8 w-8 place-items-center rounded-lg border border-line text-mist hover:border-ember/50 hover:text-ember"
                >
                  <IconClose size={15} />
                </button>
              </div>
            )) : (
              <div className="rounded-xl border border-dashed border-line px-4 py-8 text-center text-[12px] leading-6 text-mist">
                هنوز نشانکی ندارید. با دکمهٔ نشانک در بالای صفحه، جای دلخواه را نگه دارید.
              </div>
            )
          )}
        </div>
      </Sheet>
    </div>
  );
}
