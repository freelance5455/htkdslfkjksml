import React, { useState } from 'react';
import { SportsChannel } from '../types';
import { Radio, Users, Play, Tv, Sparkles, Filter } from 'lucide-react';

interface ChannelsGridProps {
  channels: SportsChannel[];
  onSelectChannel: (channel: SportsChannel) => void;
}

export const ChannelsGrid: React.FC<ChannelsGridProps> = ({ channels, onSelectChannel }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', name: 'جميع القنوات الرياضية' },
    { id: 'beIN Sports', name: 'باقة beIN Sports' },
    { id: 'SSC', name: 'باقة SSC السعودية' },
    { id: 'Alkass', name: 'قنوات الكأس' },
    { id: 'Open', name: 'القنوات المفتوحة المجانية' },
  ];

  const filteredChannels = selectedCategory === 'all'
    ? channels
    : channels.filter((c) => c.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* Category Filter bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        <span className="text-xs text-slate-500 dark:text-slate-400 font-bold shrink-0 flex items-center gap-1 pl-1">
          <Filter className="w-3.5 h-3.5 text-rose-500" />
          الباقات:
        </span>
        {categories.map((cat) => (
          <button
            key={cat.id}
            id={`filter-cat-${cat.id}`}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap border cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-rose-600 text-white border-rose-500 shadow-sm'
                : 'bg-white dark:bg-[#141a29] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:text-slate-900 dark:hover:text-white shadow-xs'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Channels Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredChannels.map((channel) => (
          <div
            key={channel.id}
            id={`channel-card-${channel.id}`}
            onClick={() => onSelectChannel(channel)}
            className="group relative bg-white dark:bg-[#111624] hover:bg-slate-50/90 dark:hover:bg-[#161d30] border border-slate-200 dark:border-slate-800 hover:border-rose-400 dark:hover:border-rose-500/50 rounded-2xl p-4 shadow-sm dark:shadow-xl transition-all duration-300 hover:shadow-md dark:hover:shadow-2xl hover:shadow-rose-950/10 cursor-pointer flex flex-col justify-between"
          >
            {/* Top Bar: Quality badge & live ping */}
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-600 text-white shadow-sm">
                {channel.quality}
              </span>

              <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                <Users className="w-3 h-3 text-rose-500 dark:text-rose-400" />
                <span>{channel.viewers} مشاهد</span>
              </div>
            </div>

            {/* Channel Logo & Name */}
            <div className="flex flex-col items-center text-center my-2">
              <div className="w-20 h-20 rounded-2xl bg-slate-100 dark:bg-[#192236] p-3 flex items-center justify-center border border-slate-200 dark:border-slate-700/60 shadow-xs group-hover:scale-105 transition-transform mb-3">
                <img
                  src={channel.logo}
                  alt={channel.name}
                  referrerPolicy="no-referrer"
                  className="max-h-full max-w-full object-contain filter drop-shadow"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://upload.wikimedia.org/wikipedia/commons/d/d3/Soccerball.svg';
                  }}
                />
              </div>

              <h3 className="text-base font-black text-slate-900 dark:text-white group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
                {channel.name}
              </h3>

              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-1 font-medium">
                {channel.currentShow}
              </p>
            </div>

            {/* Bottom Stream Action Button */}
            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80">
              <div className="w-full py-2 px-3 rounded-xl bg-slate-100 group-hover:bg-rose-600 dark:bg-[#192236] text-slate-700 group-hover:text-white dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition-all">
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>تشغيل القناة الآن</span>
                <span className="mr-auto text-[10px] bg-black/10 dark:bg-black/30 px-1.5 py-0.2 rounded font-mono">
                  {channel.servers.length} سيرفرات
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
