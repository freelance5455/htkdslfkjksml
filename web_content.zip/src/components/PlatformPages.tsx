import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Check,
  ChevronDown,
  ChevronRight,
  Coins,
  Copy,
  Plus,
  Send,
  ThumbsUp,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  AvatarConfig,
  CameraMode,
  CatalogItem,
  CommunityItem,
  FriendProfile,
  NotificationItem,
  WorldConfig,
  WorldId,
} from '../types/game';
import { CATALOG_ITEMS, SLAPBUX_PACKAGES } from '../data/pickareData';
import { GameThumbnail, MiniAvatarIcon } from './GameThumbnail';

const GameCard: React.FC<{
  world: WorldConfig;
  compact?: boolean;
  onSelect: (world: WorldConfig) => void;
}> = ({ world, compact = false, onSelect }) => (
  <motion.button
    whileHover={{ y: -3 }}
    whileTap={{ scale: 0.98 }}
    type="button"
    onClick={() => onSelect(world)}
    className="text-left group cursor-pointer focus-visible:outline-2 focus-visible:outline-white rounded-xl"
  >
    <div
      className={`${
        compact ? 'h-28' : 'h-32 md:h-36'
      } w-full rounded-xl overflow-hidden border border-white/15 group-hover:border-white/50 transition-colors`}
    >
      <GameThumbnail theme={world.thumbTheme} />
    </div>
    <div className="mt-2 font-semibold text-sm text-white truncate">{world.name}</div>
    <div className="mt-1 flex items-center gap-2 text-xs text-zinc-400">
      <span className="w-5 h-5 rounded-full bg-zinc-900 border border-white/15 text-[10px] font-bold text-white flex items-center justify-center shrink-0">
        {world.creator.charAt(0).toUpperCase()}
      </span>
      <span className="truncate">{world.creator}</span>
    </div>
  </motion.button>
);

export const HomePage: React.FC<{
  displayName: string;
  isPlus?: boolean;
  avatar: AvatarConfig;
  worlds: WorldConfig[];
  recentIds: WorldId[];
  searchQuery: string;
  partyCount: number;
  onSelectGame: (w: WorldConfig) => void;
  onGoFriends: () => void;
  onOpenParty: () => void;
}> = ({
  displayName,
  isPlus = false,
  avatar,
  worlds,
  recentIds,
  searchQuery,
  partyCount,
  onSelectGame,
  onGoFriends,
  onOpenParty,
}) => {
  const filtered = searchQuery.trim()
    ? worlds.filter(
        (w) =>
          w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.creator.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : worlds;

  const recentWorlds = recentIds
    .map((id) => worlds.find((w) => w.id === id))
    .filter((w): w is WorldConfig => !!w);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22 }}
      className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto w-full"
    >
      {/* User Greeting Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-2xl bg-zinc-950 border border-white/15">
        <div className="flex items-center gap-3">
          <MiniAvatarIcon avatar={avatar} size={42} />
          <div className="flex items-center gap-2">
            <span className="font-display text-base font-bold text-white">{displayName}</span>
            {isPlus && (
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-amber-300 text-black text-[10px] font-black tracking-wide">
                <Plus className="w-3 h-3 stroke-[3]" />
                SLAPBOX+
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onOpenParty}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-white hover:bg-zinc-200 text-black text-xs font-bold cursor-pointer whitespace-nowrap"
          >
            <Users className="w-4 h-4" />
            <span>Party Mabar ({partyCount}/12)</span>
          </button>
          <button
            type="button"
            onClick={onGoFriends}
            className="flex items-center gap-2 text-xs font-semibold text-zinc-200 hover:text-white cursor-pointer"
          >
            <span className="w-9 h-9 rounded-full bg-zinc-900 border border-white/15 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </span>
            <span className="hidden sm:inline">Tambah Teman</span>
          </button>
        </div>
      </div>

      {recentWorlds.length > 0 && !searchQuery.trim() && (
        <section>
          <h2 className="font-display text-base font-bold text-white mb-3">Lanjutkan Bermain</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {recentWorlds.slice(0, 4).map((w) => (
              <GameCard key={w.id} world={w} compact onSelect={onSelectGame} />
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="font-display text-base font-bold text-white mb-3">
          {searchQuery.trim() ? `Hasil Pencarian: "${searchQuery}"` : 'Direkomendasikan untukmu'}
        </h2>
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-sm text-zinc-400">
            Tidak ada game yang cocok dengan pencarianmu.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filtered.map((w) => (
              <GameCard key={w.id} world={w} onSelect={onSelectGame} />
            ))}
          </div>
        )}
      </section>
    </motion.div>
  );
};

export const TopChartsPage: React.FC<{
  worlds: WorldConfig[];
  onSelectGame: (w: WorldConfig) => void;
}> = ({ worlds, onSelectGame }) => {
  const sections = [
    { title: 'Tren Teratas', items: worlds.filter((w) => w.category === 'trending' || w.id === 'pickbux-gratis') },
    { title: 'Baru Dirilis', items: worlds.filter((w) => w.category === 'new' || w.id === 'santai') },
    { title: 'Paling Banyak Dimainkan Sekarang', items: [...worlds].sort((a, b) => b.activePlayers - a.activePlayers).slice(0, 4) },
    { title: 'Lebih Seru Bersama Teman', items: worlds.filter((w) => w.category === 'hangout' || w.id === 'plaza') },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto w-full"
    >
      <h1 className="font-display text-2xl font-extrabold text-white">Teratas</h1>

      {sections.map((sec) => (
        <section key={sec.title} className="space-y-3">
          <div className="flex items-center gap-1.5 font-display text-base font-bold text-white">
            <span>{sec.title}</span>
            <ChevronRight className="w-4 h-4 text-zinc-400" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {sec.items.map((w) => (
              <motion.button
                whileHover={{ y: -2 }}
                key={`${sec.title}-${w.id}`}
                type="button"
                onClick={() => onSelectGame(w)}
                className="text-left group cursor-pointer"
              >
                <div className="h-28 rounded-xl overflow-hidden border border-white/15 group-hover:border-white/45">
                  <GameThumbnail theme={w.thumbTheme} />
                </div>
                <div className="mt-2 font-semibold text-sm text-white truncate">{w.name}</div>
                <div className="mt-1 flex items-center gap-3 text-xs text-zinc-400 font-mono-num">
                  <span className="inline-flex items-center gap-1">
                    <ThumbsUp className="w-3 h-3" /> {w.likes}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Users className="w-3 h-3" /> {w.activePlayers}
                  </span>
                </div>
              </motion.button>
            ))}
          </div>
        </section>
      ))}
    </motion.div>
  );
};

export const ChatFriendsPage: React.FC<{
  players: FriendProfile[];
  friendIds: string[];
  pendingRequestIds: string[];
  incomingRequestIds: string[];
  partyMemberIds: string[];
  onSendFriendRequest: (id: string) => void;
  onCancelFriendRequest: (id: string) => void;
  onAcceptIncomingRequest: (id: string) => void;
  onDeclineIncomingRequest: (id: string) => void;
  onInspectPlayer: (p: FriendProfile) => void;
  onOpenTrade: (p: FriendProfile) => void;
  onInviteParty: (id: string) => void;
  onSendMessage: (playerId: string, text: string) => void;
}> = ({
  players,
  friendIds,
  pendingRequestIds,
  incomingRequestIds,
  partyMemberIds,
  onSendFriendRequest,
  onCancelFriendRequest,
  onAcceptIncomingRequest,
  onDeclineIncomingRequest,
  onInspectPlayer,
  onOpenTrade,
  onInviteParty,
  onSendMessage,
}) => {
  const [tab, setTab] = useState<'add' | 'friends' | 'requests'>('friends');
  const [search, setSearch] = useState('');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  const filtered = players.filter((p) => {
    const matchSearch =
      !search.trim() ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.username.toLowerCase().includes(search.toLowerCase());
    if (!matchSearch) return false;
    if (tab === 'friends') return friendIds.includes(p.id);
    if (tab === 'requests') return incomingRequestIds.includes(p.id) || pendingRequestIds.includes(p.id);
    return true;
  });

  const activePlayer = players.find((p) => p.id === activeChatId) ?? null;

  const submitMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePlayer || !draft.trim()) return;
    onSendMessage(activePlayer.id, draft.trim());
    setDraft('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-5 max-w-4xl mx-auto w-full"
    >
      <div className="flex items-center gap-3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Cari nama pemain atau @username..."
          className="w-full px-4 py-2.5 rounded-full bg-zinc-950 border border-white/15 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white"
        />
      </div>

      <div className="grid grid-cols-3 border-b border-white/15">
        <button
          type="button"
          onClick={() => setTab('friends')}
          className={`py-2.5 text-xs sm:text-sm font-semibold border-b-2 cursor-pointer ${
            tab === 'friends' ? 'text-white border-white' : 'text-zinc-500 border-transparent'
          }`}
        >
          Teman ({friendIds.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('add')}
          className={`py-2.5 text-xs sm:text-sm font-semibold border-b-2 cursor-pointer ${
            tab === 'add' ? 'text-white border-white' : 'text-zinc-500 border-transparent'
          }`}
        >
          Tambah Teman ({players.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('requests')}
          className={`py-2.5 text-xs sm:text-sm font-semibold border-b-2 cursor-pointer ${
            tab === 'requests' ? 'text-white border-white' : 'text-zinc-500 border-transparent'
          }`}
        >
          Permintaan ({incomingRequestIds.length + pendingRequestIds.length})
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="py-12 text-center space-y-3">
          <p className="text-sm text-zinc-300">
            {tab === 'requests' ? 'Tidak ada permintaan pertemanan yang menunggu.' : 'Belum ada teman di daftar ini.'}
          </p>
          <button
            type="button"
            onClick={() => setTab('add')}
            className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
          >
            Cari Pemain Lain
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((p) => {
            const isFriend = friendIds.includes(p.id);
            const isPending = pendingRequestIds.includes(p.id);
            const isIncoming = incomingRequestIds.includes(p.id);
            const inParty = partyMemberIds.includes(p.id);
            return (
              <div
                key={p.id}
                className="flex flex-col gap-3 p-3.5 rounded-2xl bg-zinc-950 border border-white/15"
              >
                <div className="flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => onInspectPlayer(p)}
                    className="flex items-center gap-3 text-left min-w-0 cursor-pointer group"
                  >
                    <MiniAvatarIcon avatar={p.avatar} size={42} />
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-white truncate group-hover:underline">
                        {p.name}
                      </div>
                      <div className="text-xs text-zinc-400 truncate">
                        {p.username} · {p.online ? 'Online' : 'Offline'} · Ketuk lihat profil
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {isFriend ? (
                      <button
                        type="button"
                        onClick={() => setActiveChatId(p.id)}
                        className="px-3 py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
                      >
                        Chat
                      </button>
                    ) : isIncoming ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onAcceptIncomingRequest(p.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
                        >
                          Terima
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeclineIncomingRequest(p.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300 cursor-pointer"
                        >
                          Tolak
                        </button>
                      </>
                    ) : isPending ? (
                      <button
                        type="button"
                        onClick={() => onCancelFriendRequest(p.id)}
                        title="Klik untuk membatalkan permintaan"
                        className="px-3 py-1.5 rounded-lg bg-zinc-800 border border-amber-400/50 text-amber-300 text-xs font-bold cursor-pointer"
                      >
                        Pending (Menunggu)
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onSendFriendRequest(p.id)}
                        className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-white hover:text-black text-xs font-bold text-white cursor-pointer"
                      >
                        Tambah Teman
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 border-t border-white/10 pt-2">
                  <button
                    type="button"
                    onClick={() => onInspectPlayer(p)}
                    className="flex-1 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-[11px] font-semibold text-zinc-200 cursor-pointer"
                  >
                    Lihat Profil
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenTrade(p)}
                    className="flex-1 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-[11px] font-semibold text-zinc-200 cursor-pointer"
                  >
                    Trade Aksesoris
                  </button>
                  <button
                    type="button"
                    onClick={() => onInviteParty(p.id)}
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer ${
                      inParty ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40' : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200'
                    }`}
                  >
                    {inParty ? 'Di Party ✓' : '+ Party'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activePlayer && (
        <div className="rounded-2xl bg-zinc-950 border border-white/20 p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2.5">
              <MiniAvatarIcon avatar={activePlayer.avatar} size={30} />
              <span className="text-sm font-bold text-white">Chat dengan {activePlayer.name}</span>
            </div>
            <button
              type="button"
              onClick={() => setActiveChatId(null)}
              className="text-xs text-zinc-400 hover:text-white cursor-pointer"
            >
              Tutup
            </button>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {activePlayer.messages.length === 0 ? (
              <div className="text-xs text-zinc-400 py-4 text-center">Mulai obrolan dengan {activePlayer.name}.</div>
            ) : (
              activePlayer.messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`px-3 py-2 rounded-xl text-xs max-w-[75%] ${
                      m.sender === 'me' ? 'bg-white text-black font-semibold' : 'bg-zinc-900 border border-white/10 text-zinc-100'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))
            )}
          </div>
          <form onSubmit={submitMsg} className="flex gap-2">
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Tulis pesan..."
              className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white focus:outline-none focus:border-white"
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-black cursor-pointer"
              aria-label="Kirim pesan"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </motion.div>
  );
};

export const FavoritesPage: React.FC<{
  worlds: WorldConfig[];
  favoriteIds: WorldId[];
  onSelectGame: (w: WorldConfig) => void;
}> = ({ worlds, favoriteIds, onSelectGame }) => {
  const favWorlds = worlds.filter((w) => favoriteIds.includes(w.id));
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-5 max-w-6xl mx-auto w-full"
    >
      <h1 className="font-display text-2xl font-extrabold text-white">Favorit</h1>
      {favWorlds.length === 0 ? (
        <div className="py-16 text-center text-sm text-zinc-300 space-y-1">
          <div className="font-semibold text-white">Belum ada favorit.</div>
          <div className="text-zinc-400">Buka sebuah game lalu ketuk ★ Favorit.</div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {favWorlds.map((w) => (
            <GameCard key={w.id} world={w} onSelect={onSelectGame} />
          ))}
        </div>
      )}
    </motion.div>
  );
};

export const NotificationsPage: React.FC<{
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
}> = ({ notifications, onMarkAllRead }) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    className="p-4 md:p-6 space-y-4 max-w-3xl mx-auto w-full"
  >
    <h1 className="font-display text-2xl font-extrabold text-white">Notifikasi</h1>
    <button
      type="button"
      onClick={onMarkAllRead}
      className="px-4 py-2 rounded-full bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
    >
      Tandai dibaca
    </button>
    <div className="space-y-2.5">
      {notifications.map((n) => (
        <div
          key={n.id}
          className={`px-4 py-3.5 rounded-xl bg-zinc-950 border ${
            n.read ? 'border-white/10 text-zinc-400' : 'border-white/50 text-white'
          } text-sm font-medium flex items-center justify-between gap-3`}
        >
          <span>{n.text}</span>
          <span className="text-[11px] text-zinc-500 shrink-0">{n.time}</span>
        </div>
      ))}
    </div>
  </motion.div>
);

export const BuySlapbuxPage: React.FC<{
  slapbux: number;
  isPlus?: boolean;
  dailyClaimed: boolean;
  onActivatePlus?: () => void;
  onClaimDaily: () => void;
  onOpenRedeem: () => void;
  onBuyPackage: (amount: number, price: string) => void;
}> = ({ slapbux, isPlus = false, dailyClaimed, onActivatePlus, onClaimDaily, onOpenRedeem, onBuyPackage }) => {
  const [faqOpen, setFaqOpen] = useState<number | null>(null);
  const faqs = [
    {
      q: 'Apa itu Slapbux?',
      a: 'Slapbux adalah mata uang virtual di Slapbox untuk membeli baju, celana, sepatu, aksesoris berefek, trail kaki, ekspresi wajah, emote, animasi, dan latar belakang.',
    },
    {
      q: 'Apa keuntungan Slapbox+?',
      a: 'Member Slapbox+ mendapat lencana [+] eksklusif di profil & atas kepala dalam map, Bonus Harian 2x lipat (10.000 Slapbux), bonus +10.000 Slapbux langsung, serta Trail Kaki Pelangi & Ekspresi Mata Cinta.',
    },
    {
      q: 'Di mana Slapbux-ku?',
      a: 'Saldo Slapbux kamu selalu tampil di pojok kanan atas dan di menu samping akunmu.',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-6 max-w-3xl mx-auto w-full"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-white">Paket Slapbux & Slapbox+</h1>
          <p className="text-xs text-zinc-400 mt-1">
            Dengan membeli Slapbux atau berlangganan Slapbox+, kamu menyetujui aturan komunitas Slapbox.
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-950 border border-white/20 text-sm font-bold text-white font-mono-num">
          <Coins className="w-4 h-4 text-white" />
          {slapbux.toLocaleString('id-ID')}
        </div>
      </div>

      {/* Slapbox+ Membership Card */}
      <div className="rounded-2xl bg-gradient-to-br from-zinc-900 via-zinc-950 to-black border border-amber-300/45 p-5 space-y-3 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-300 text-black flex items-center justify-center font-black text-xl">
              +
            </div>
            <div>
              <div className="font-display text-lg font-black text-white flex items-center gap-2">
                <span>SLAPBOX+</span>
                {isPlus && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-300 text-black text-[10px] font-black">
                    <Check className="w-3 h-3" /> AKTIF
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-300">
                Badge [+] di atas kepala, Bonus Harian 2x (10.000), +10.000 Slapbux & Trail Pelangi + Ekspresi Cinta!
              </p>
            </div>
          </div>
          {onActivatePlus && (
            <button
              type="button"
              disabled={isPlus}
              onClick={onActivatePlus}
              className="px-4 py-2.5 rounded-xl bg-amber-300 hover:bg-amber-200 disabled:opacity-60 text-black text-xs font-black cursor-pointer whitespace-nowrap"
            >
              {isPlus ? 'Slapbox+ Sudah Aktif' : 'Aktifkan + (5.000 SB)'}
            </button>
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-zinc-950 border border-white/15 p-4 space-y-2.5">
        {SLAPBUX_PACKAGES.map((pkg) => (
          <div key={pkg.amount} className="flex items-center justify-between py-1.5">
            <div className="inline-flex items-center gap-2 font-display text-lg font-bold text-white font-mono-num">
              <Coins className="w-4 h-4 text-white" />
              {pkg.amount.toLocaleString('id-ID')}
            </div>
            <button
              type="button"
              onClick={() => onBuyPackage(pkg.amount, pkg.price)}
              className={`min-w-28 py-2 px-4 rounded-xl text-xs font-bold cursor-pointer ${
                pkg.highlight
                  ? 'bg-white hover:bg-zinc-200 text-black'
                  : 'bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-white'
              }`}
            >
              {pkg.price}
            </button>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold text-white">
          Cara lain untuk mendapatkan Slapbux
        </h2>

        <div className="rounded-2xl bg-zinc-950 border border-white/15 p-4 space-y-2">
          <div className="font-bold text-sm text-white">Bonus Harian {isPlus ? '(2x Slapbox+)' : ''}</div>
          <p className="text-xs text-zinc-400">
            Ambil +{isPlus ? '10.000' : '5.000'} Slapbux gratis setiap hari.
          </p>
          <button
            type="button"
            disabled={dailyClaimed}
            onClick={onClaimDaily}
            className="w-full py-2.5 rounded-xl bg-white hover:bg-zinc-200 disabled:opacity-40 text-xs font-bold text-black cursor-pointer"
          >
            {dailyClaimed ? 'Bonus Hari Ini Sudah Diambil' : 'Ambil Bonus'}
          </button>
        </div>

        <div className="rounded-2xl bg-zinc-950 border border-white/15 p-4 space-y-2">
          <div className="font-bold text-sm text-white">Kode Redeem</div>
          <p className="text-xs text-zinc-400">Punya kode dari Owner atau staf? Tukarkan dengan Slapbux.</p>
          <button
            type="button"
            onClick={onOpenRedeem}
            className="w-full py-2.5 rounded-xl bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-xs font-bold text-white cursor-pointer"
          >
            Tukar Kode
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <h2 className="font-display text-lg font-bold text-white">FAQ</h2>
        {faqs.map((f, i) => (
          <div key={f.q} className="rounded-xl bg-zinc-950 border border-white/15 overflow-hidden">
            <button
              type="button"
              onClick={() => setFaqOpen(faqOpen === i ? null : i)}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-white cursor-pointer"
            >
              <span>{f.q}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${faqOpen === i ? 'rotate-180' : ''}`} />
            </button>
            {faqOpen === i && <div className="px-4 pb-3 text-xs text-zinc-300">{f.a}</div>}
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export const SettingsPage: React.FC<{
  sensitivity: number;
  cameraMode: CameraMode;
  hdGraphics: boolean;
  showTouchControls: boolean;
  userId: string;
  onChangeSensitivity: (v: number) => void;
  onChangeCameraMode: (m: CameraMode) => void;
  onToggleHd: () => void;
  onToggleTouch: () => void;
  onLogout: () => void;
  onCopyId: () => void;
}> = ({
  sensitivity,
  cameraMode,
  hdGraphics,
  showTouchControls,
  userId,
  onChangeSensitivity,
  onChangeCameraMode,
  onToggleHd,
  onToggleTouch,
  onLogout,
  onCopyId,
}) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    className="p-4 md:p-6 space-y-5 max-w-2xl mx-auto w-full"
  >
    <h1 className="font-display text-2xl font-extrabold text-white">Pengaturan</h1>

    <div className="rounded-2xl bg-zinc-950 border border-white/15 p-5 space-y-5">
      <div>
        <div className="flex justify-between text-xs font-medium text-zinc-300 mb-2">
          <span>Sensitivitas Kamera</span>
          <span className="font-mono-num">{sensitivity.toFixed(1)}x</span>
        </div>
        <input
          type="range"
          min="0.4"
          max="2.2"
          step="0.1"
          value={sensitivity}
          onChange={(e) => onChangeSensitivity(parseFloat(e.target.value))}
          className="w-full accent-white cursor-pointer"
        />
      </div>

      <div>
        <div className="text-xs font-medium text-zinc-300 mb-2">Kamera Awal</div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => onChangeCameraMode('third')}
            className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer ${
              cameraMode === 'third' ? 'bg-white text-black' : 'bg-zinc-900 border border-white/15 text-zinc-300'
            }`}
          >
            Orang Ketiga
          </button>
          <button
            type="button"
            onClick={() => onChangeCameraMode('first')}
            className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer ${
              cameraMode === 'first' ? 'bg-white text-black' : 'bg-zinc-900 border border-white/15 text-zinc-300'
            }`}
          >
            Orang Pertama
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <div>
          <div className="text-xs font-medium text-zinc-300 mb-2">Grafis HD</div>
          <button
            type="button"
            onClick={onToggleHd}
            className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer ${
              hdGraphics ? 'bg-white text-black' : 'bg-zinc-900 border border-white/15 text-zinc-300'
            }`}
          >
            {hdGraphics ? 'AKTIF' : 'HEMAT'}
          </button>
        </div>

        <div>
          <div className="text-xs font-medium text-zinc-300 mb-2">Joystick Layar Sentuh</div>
          <button
            type="button"
            onClick={onToggleTouch}
            className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer ${
              showTouchControls ? 'bg-white text-black' : 'bg-zinc-900 border border-white/15 text-zinc-300'
            }`}
          >
            {showTouchControls ? 'AKTIF' : 'NONAKTIF'}
          </button>
        </div>
      </div>
    </div>

    <button
      type="button"
      onClick={onLogout}
      className="w-full py-3 rounded-xl bg-white hover:bg-zinc-200 text-sm font-bold text-black cursor-pointer"
    >
      Keluar Akun
    </button>

    <div className="rounded-2xl bg-zinc-950 border border-white/15 p-5 space-y-2.5">
      <div className="font-display text-base font-bold text-white">User ID</div>
      <p className="text-xs text-zinc-400">
        ID unik akunmu. Di script: <code className="font-mono text-zinc-200">player.UserId</code>
      </p>
      <div className="flex gap-2">
        <div className="flex-1 px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/10 font-mono text-sm text-white">
          {userId}
        </div>
        <button
          type="button"
          onClick={onCopyId}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
        >
          <Copy className="w-3.5 h-3.5" />
          Salin
        </button>
      </div>
    </div>
  </motion.div>
);

const PRESET_COMMUNITY_LOGOS = [
  {
    label: 'Perisai Slap',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="18" fill="#18181b"/><path d="M40 12 L64 22 V42 C64 56 40 68 40 68 C40 68 16 56 16 42 V22 Z" fill="#ffffff"/><text x="40" y="48" font-family="sans-serif" font-weight="900" font-size="22" text-anchor="middle" fill="#09090b">SB</text></svg>'
    )}`,
  },
  {
    label: 'Mahkota Emas',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="18" fill="#0f172a"/><path d="M16 56 L22 24 L40 40 L58 24 L64 56 Z" fill="#facc15"/><rect x="16" y="58" width="48" height="7" rx="3" fill="#eab308"/></svg>'
    )}`,
  },
  {
    label: 'Petir Arena',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="18" fill="#1e1b4b"/><polygon points="46,12 20,44 38,44 32,68 60,36 42,36" fill="#38bdf8"/></svg>'
    )}`,
  },
];

export const CommunitiesPage: React.FC<{
  communities: CommunityItem[];
  onCreateCommunity: (payload: { name: string; description: string; logoUrl: string }) => void;
  onToggleJoin: (id: string) => void;
}> = ({ communities, onCreateCommunity, onToggleJoin }) => {
  const [search, setSearch] = useState('');
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const visible = communities.filter((c) =>
    !search.trim() || c.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setLogoUrl(reader.result);
        setFormError(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const submitCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logoUrl.trim()) {
      setFormError('Pilih atau unggah gambar untuk logo komunitas terlebih dahulu.');
      return;
    }
    if (newName.trim().length < 3) {
      setFormError('Nama komunitas minimal 3 karakter.');
      return;
    }
    if (newDesc.trim().length < 5) {
      setFormError('Deskripsi komunitas minimal 5 karakter.');
      return;
    }
    onCreateCommunity({
      name: newName.trim(),
      description: newDesc.trim(),
      logoUrl,
    });
    setNewName('');
    setNewDesc('');
    setLogoUrl('');
    setFormError(null);
    setCreating(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-4 max-w-3xl mx-auto w-full"
    >
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-extrabold text-white">Komunitas</h1>
      </div>

      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Cari Komunitas Saya"
        className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/15 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white"
      />

      <button
        type="button"
        onClick={() => {
          setCreating((v) => !v);
          setFormError(null);
        }}
        className="w-full py-3 rounded-xl bg-zinc-900 border border-white/15 hover:bg-white hover:text-black text-xs font-bold text-white cursor-pointer transition-colors"
      >
        {creating ? 'Tutup Form Komunitas' : 'Buat Komunitas Baru (Butuh Logo, Nama & Deskripsi)'}
      </button>

      {creating && (
        <form onSubmit={submitCreate} className="rounded-2xl bg-zinc-950 border border-white/20 p-4 space-y-4">
          <div className="text-sm font-bold text-white">Buat Komunitas Slapbox</div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-2">
              1. Gambar Logo Komunitas <span className="text-rose-400">*</span>
            </label>
            <div className="flex flex-wrap items-center gap-3">
              <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-white/15 overflow-hidden flex items-center justify-center shrink-0">
                {logoUrl ? (
                  <img src={logoUrl} alt="Preview Logo Komunitas" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-[10px] text-zinc-500 text-center px-1">Belum ada logo</span>
                )}
              </div>
              <div className="flex-1 min-w-[200px] space-y-2">
                <label className="inline-block px-3.5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer">
                  Unggah Gambar Logo
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {PRESET_COMMUNITY_LOGOS.map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setLogoUrl(preset.url);
                        setFormError(null);
                      }}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer ${
                        logoUrl === preset.url
                          ? 'bg-white text-black border-white'
                          : 'bg-zinc-900 text-zinc-300 border-white/10 hover:bg-zinc-800'
                      }`}
                    >
                      <img src={preset.url} alt="" className="w-4 h-4 rounded" />
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">
              2. Nama Komunitas <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              minLength={3}
              maxLength={40}
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Contoh: Slapbox Indo Squad"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">
              3. Deskripsi Komunitas <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={2}
              minLength={5}
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              placeholder="Jelaskan aturan, jadwal mabar, atau info komunitas ini..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white focus:outline-none focus:border-white resize-none"
            />
          </div>

          {formError && (
            <div className="px-3 py-2 rounded-xl bg-rose-500/15 border border-rose-400/40 text-xs text-rose-200">
              {formError}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
          >
            Buat Komunitas Sekarang
          </button>
        </form>
      )}

      <div className="space-y-3">
        {visible.map((c) => (
          <div
            key={c.id}
            className="flex items-center justify-between gap-4 p-4 rounded-2xl bg-zinc-950 border border-white/15"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-white/15 overflow-hidden flex items-center justify-center shrink-0">
                {c.logoUrl ? (
                  <img src={c.logoUrl} alt={c.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="font-display font-black text-base text-white">
                    {c.name.slice(0, 2).toUpperCase()}
                  </span>
                )}
              </div>
              <div className="min-w-0">
                <div className="font-bold text-sm text-white truncate">{c.name}</div>
                <div className="text-[11px] text-zinc-400">
                  {c.members} anggota {c.creator ? `· Oleh ${c.creator}` : ''}
                </div>
                <div className="text-xs text-zinc-300 mt-0.5 line-clamp-2">{c.description}</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onToggleJoin(c.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold cursor-pointer shrink-0 ${
                c.joined ? 'bg-zinc-800 text-white' : 'bg-white hover:bg-zinc-200 text-black'
              }`}
            >
              {c.joined ? 'Bergabung' : 'Gabung'}
            </button>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export const InventoryPage: React.FC<{
  ownedIds: string[];
  catalogItems?: CatalogItem[];
  onEquipItem: (item: CatalogItem) => void;
  onGoMarketplace: () => void;
}> = ({ ownedIds, catalogItems = CATALOG_ITEMS, onEquipItem, onGoMarketplace }) => {
  const ownedItems = catalogItems.filter((it) => ownedIds.includes(it.id));

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 md:p-6 space-y-5 max-w-4xl mx-auto w-full"
    >
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-extrabold text-white">Inventaris</h1>
        <button
          type="button"
          onClick={onGoMarketplace}
          className="px-3.5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
        >
          Ke Marketplace
        </button>
      </div>

      {ownedItems.length === 0 ? (
        <div className="py-16 text-center text-sm text-zinc-400">
          Belum ada item di inventaris. Beli item di halaman Avatar!
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {ownedItems.map((it) => (
            <div key={it.id} className="rounded-2xl bg-zinc-950 border border-white/15 p-3 space-y-2">
              <div
                style={{ backgroundColor: `${it.accentColor}28` }}
                className="h-24 rounded-xl border border-white/10 flex items-center justify-center font-display text-2xl font-black text-white"
              >
                {it.letter}
              </div>
              <div className="text-sm font-bold text-white truncate">{it.name}</div>
              <div className="text-[11px] text-zinc-400 truncate">Oleh {it.creator}</div>
              <button
                type="button"
                onClick={() => onEquipItem(it)}
                className="w-full py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
              >
                {it.category === 'emote' ? 'Terbuka di Map' : 'Pakai'}
              </button>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
};
