import React, { useState } from 'react';
import {
  BatteryLow,
  Sparkles,
  ZapOff,
  Sun,
  Shield,
  Snowflake,
  AlertCircle,
  CheckCircle,
  HelpCircle,
  Cpu,
  Power,
} from 'lucide-react';
import { getBatteryConsumptionProfile } from '../utils/thermal';

interface BatterySavingGuideProps {
  batteryTemp: number;
}

export const BatterySavingGuide: React.FC<BatterySavingGuideProps> = ({
  batteryTemp,
}) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'cooling'>('cooling');
  const profile = getBatteryConsumptionProfile(true);

  return (
    <div className="rounded-2xl bg-neutral-950 border border-neutral-800 p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-400">
            <BatteryLow className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
              Risparmio Batteria & Guida Termica
              <span className="text-[10px] font-mono uppercase bg-emerald-950 border border-emerald-800 text-emerald-400 px-1.5 py-0.5 rounded">
                Consumo: ~0%
              </span>
            </h2>
            <p className="text-xs text-neutral-400">
              Architettura AMOLED ultra-leggera e zero drain in background
            </p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex rounded-xl bg-neutral-900 p-1 border border-neutral-800 text-xs">
          <button
            onClick={() => setActiveTab('cooling')}
            className={`px-3 py-1 rounded-lg transition font-medium cursor-pointer ${
              activeTab === 'cooling'
                ? 'bg-neutral-800 text-neutral-100 shadow'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Raffreddamento Rapido
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3 py-1 rounded-lg transition font-medium cursor-pointer ${
              activeTab === 'architecture'
                ? 'bg-neutral-800 text-neutral-100 shadow'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Come Risparmia Batteria
          </button>
        </div>
      </div>

      {activeTab === 'cooling' ? (
        <div className="space-y-3">
          <p className="text-xs text-neutral-300">
            {batteryTemp >= 37 ? (
              <span className="text-amber-400 font-semibold flex items-center gap-1.5 mb-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                La batteria ha superato i 37°C! Applica subito queste azioni per abbassare la temperatura:
              </span>
            ) : (
              'Consigli pratici per mantenere il telefono fresco ed evitare usura irreversibile della batteria:'
            )}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-2.5">
              <ZapOff className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-200 block">
                  Stacca la ricarica rapida
                </span>
                <span className="text-neutral-400 text-[11px] leading-tight block mt-0.5">
                  I caricatori da 33W-120W spingono la batteria a oltre 39°C. Lascialo riposare 5 minuti.
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-200 block">
                  Rimuovi la custodia / cover
                </span>
                <span className="text-neutral-400 text-[11px] leading-tight block mt-0.5">
                  Le cover spesse in silicone intrappolano il calore radiante. Toglila per dissipare subito 2-3°C.
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-2.5">
              <Sun className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-200 block">
                  Abbassa la luminosità schermo
                </span>
                <span className="text-neutral-400 text-[11px] leading-tight block mt-0.5">
                  Il pannello a 1200+ nit genera tantissimo calore sul vetro anteriore a contatto con la cella.
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-2.5">
              <Snowflake className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-200 block">
                  Appoggia su superficie dura
                </span>
                <span className="text-neutral-400 text-[11px] leading-tight block mt-0.5">
                  Usa un tavolo in metallo o marmo. Non metterlo MAI in frigo/freezer: la condensa distrugge i circuiti!
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-3 text-xs">
          <div className="p-3 rounded-xl bg-neutral-900/70 border border-neutral-800 space-y-2">
            <div className="flex items-center justify-between text-neutral-200 font-medium">
              <span className="flex items-center gap-2">
                <Power className="w-4 h-4 text-emerald-400" />
                Risparmio energetico attivo:
              </span>
              <span className="font-mono text-emerald-400 font-bold">
                -{profile.screenPowerReductionPercent}% consumo display
              </span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              Questa applicazione è stata sviluppata specificamente per non consumare batteria:
            </p>
            <ul className="space-y-1.5 list-disc list-inside text-neutral-300 text-[11px]">
              {profile.tips.map((tip, idx) => (
                <li key={idx} className="leading-snug">
                  {tip}
                </li>
              ))}
            </ul>
          </div>

          <div className="p-3 rounded-xl bg-black border border-neutral-800 flex items-center justify-between text-[11px]">
            <span className="text-neutral-400">
              CPU in background quando minimizzata:
            </span>
            <span className="font-mono font-bold text-emerald-400">
              0.0% (Sospensione Page Visibility API)
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
