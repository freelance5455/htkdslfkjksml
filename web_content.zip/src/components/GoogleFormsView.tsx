import React, { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  RefreshCw,
  ExternalLink,
  Sparkles,
  BarChart2,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Users,
  Copy,
  Check,
  Send,
  Loader2,
  FolderOpen,
  Eye,
  Trash2,
  ListFilter,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  signInWithGoogle,
  getGoogleAccessToken,
  firebaseSignOut,
  saveFormToFirestore,
  fetchFormsFromFirestore,
  FirestoreFormRecord
} from '../lib/firebase';
import {
  listUserGoogleForms,
  getGoogleFormDetails,
  getGoogleFormResponses,
  createGoogleForm,
  GoogleDriveFormItem,
  GoogleFormDetails,
  GoogleFormResponsesResult
} from '../lib/googleForms';
import { User } from '../types/auth';

interface GoogleFormsViewProps {
  user: User | null;
  isLight?: boolean;
}

export const GoogleFormsView: React.FC<GoogleFormsViewProps> = ({ user, isLight = false }) => {
  const [hasGoogleAuth, setHasGoogleAuth] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [googleUserEmail, setGoogleUserEmail] = useState<string | null>(null);

  // Forms state
  const [formsList, setFormsList] = useState<GoogleDriveFormItem[]>([]);
  const [isLoadingForms, setIsLoadingForms] = useState(false);
  const [selectedFormId, setSelectedFormId] = useState<string | null>(null);
  const [selectedFormDetails, setSelectedFormDetails] = useState<GoogleFormDetails | null>(null);
  const [formResponses, setFormResponses] = useState<GoogleFormResponsesResult | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  // Create Form Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [isSubmittingForm, setIsSubmittingForm] = useState(false);
  const [templateType, setTemplateType] = useState<'feedback' | 'quiz' | 'event' | 'custom'>('feedback');

  // AI Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<string | null>(null);

  // Copied alert
  const [copiedLink, setCopiedLink] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showStatus = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 4000);
  };

  // Check if we have an active Google access token
  useEffect(() => {
    getGoogleAccessToken().then((token) => {
      setHasGoogleAuth(Boolean(token));
    });
  }, []);

  // Fetch user's Google Forms from Drive API
  const handleLoadForms = async () => {
    setIsLoadingForms(true);
    try {
      const forms = await listUserGoogleForms();
      setFormsList(forms);
      if (forms.length > 0 && !selectedFormId) {
        handleSelectForm(forms[0].id);
      }
      showStatus(`تم العثور على ${forms.length} نموذج من حساب Google`);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('تسجيل الدخول')) {
        setHasGoogleAuth(false);
      }
      showStatus(err.message || 'فشل في تحميل النماذج', 'error');
    } finally {
      setIsLoadingForms(false);
    }
  };

  // On Google Auth success, load forms
  useEffect(() => {
    if (hasGoogleAuth) {
      handleLoadForms();
    }
  }, [hasGoogleAuth]);

  // Google Sign-In with official OAuth scopes
  const handleGoogleSignIn = async () => {
    setIsAuthenticating(true);
    try {
      const res = await signInWithGoogle();
      if (res.accessToken) {
        setHasGoogleAuth(true);
        setGoogleUserEmail(res.user.email || 'مستخدم Google');
        showStatus('تم تسجيل الدخول وربط Google Forms بنجاح!');
      }
    } catch (err: any) {
      console.error('Sign-in error:', err);
      showStatus('فشل في تسجيل الدخول إلى Google: ' + err.message, 'error');
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Inspect form and its responses
  const handleSelectForm = async (formId: string) => {
    setSelectedFormId(formId);
    setIsLoadingDetails(true);
    setSelectedFormDetails(null);
    setFormResponses(null);
    setAiAnalysisResult(null);

    try {
      const [details, responses] = await Promise.all([
        getGoogleFormDetails(formId),
        getGoogleFormResponses(formId).catch(() => ({ responses: [] })),
      ]);
      setSelectedFormDetails(details);
      setFormResponses(responses);

      // Save form reference to Firestore
      if (user?.id) {
        const formRecord: FirestoreFormRecord = {
          id: details.formId,
          userId: user.id,
          title: details.info.title,
          responderUri: details.responderUri,
          responseCount: responses.responses?.length || 0,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        saveFormToFirestore(user.id, formRecord).catch(console.warn);
      }
    } catch (err: any) {
      console.error('Fetch details error:', err);
      showStatus(err.message || 'فشل في جلب تفاصيل النموذج', 'error');
    } finally {
      setIsLoadingDetails(false);
    }
  };

  // Handle Form Creation
  const handleCreateFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    setIsSubmittingForm(true);

    let defaultQuestions: Array<{ title: string; type: 'RADIO' | 'CHECKBOX' | 'TEXT'; options?: string[] }> = [];

    if (templateType === 'feedback') {
      defaultQuestions = [
        { title: 'ما مدى رضاك عن الخدمة؟', type: 'RADIO', options: ['ممتاز جدًا', 'جيد', 'مقبول', 'غير راضٍ'] },
        { title: 'ما هي الميزات الأكثر فائدة بالنسبة لك؟', type: 'CHECKBOX', options: ['السرعة', 'دقة الإجابات', 'المحادثة الصوتية', 'التصميم'] },
        { title: 'أي ملاحظات أو اقتراحات إضافية لتحسين الخدمة؟', type: 'TEXT' },
      ];
    } else if (templateType === 'event') {
      defaultQuestions = [
        { title: 'الاسم الكامل', type: 'TEXT' },
        { title: 'البريد الإلكتروني للتواصل', type: 'TEXT' },
        { title: 'هل ستحضر شخصياً أم عن بعد؟', type: 'RADIO', options: ['حضور شخصي', 'حضور افتراضي (عن بعد)'] },
      ];
    } else if (templateType === 'quiz') {
      defaultQuestions = [
        { title: 'ما هو نموذج الذكاء الاصطناعي الأسرع في معالجة الأوامر الفورية؟', type: 'RADIO', options: ['Gemini 3.8 Flash', 'نماذج قديمة أخرى'] },
        { title: 'شاركنا برأيك حول أهمية الدعم الصوتي الفوري:', type: 'TEXT' },
      ];
    }

    try {
      const created = await createGoogleForm(newTitle.trim(), newDesc.trim(), defaultQuestions);
      setIsCreateModalOpen(false);
      setNewTitle('');
      setNewDesc('');
      showStatus('تم إنشاء النموذج الجديد في Google Forms بنجاح!');
      await handleLoadForms();
      handleSelectForm(created.formId);
    } catch (err: any) {
      console.error(err);
      showStatus('فشل في إنشاء النموذج: ' + err.message, 'error');
    } finally {
      setIsSubmittingForm(false);
    }
  };

  // Gemini AI Analysis on Form Responses
  const handleAnalyzeResponses = async () => {
    if (!selectedFormDetails || !formResponses?.responses) return;
    const count = formResponses.responses.length;
    if (count === 0) {
      showStatus('لا توجد ردود مسجلة بعد في هذا النموذج لتحليلها.', 'error');
      return;
    }

    setIsAnalyzing(true);
    setAiAnalysisResult(null);

    try {
      // Collect summary of answers
      const questionsMap: Record<string, string> = {};
      selectedFormDetails.items?.forEach((item) => {
        if (item.questionItem?.question.questionId) {
          questionsMap[item.questionItem.question.questionId] = item.title;
        }
      });

      const responseSummaries = formResponses.responses.slice(0, 30).map((r, i) => {
        const answersStr = Object.entries(r.answers || {})
          .map(([qId, ans]) => {
            const qTitle = questionsMap[qId] || 'سؤال';
            const val = ans.textAnswers?.answers?.map((a) => a.value).join(', ') || '';
            return `${qTitle}: ${val}`;
          })
          .join(' | ');
        return `رد ${i + 1}: ${answersStr}`;
      }).join('\n');

      const prompt = `أنت خبير تحليل بيانات واستبيانات في منصة OnyxMind AI.
حلل ردود استبيان Google Form التالي بدقة وقدم تقريراً تنفيذياً باللغة العربية:
عنوان النموذج: ${selectedFormDetails.info.title}
عدد الردود: ${count}

عينة من الردود:
${responseSummaries}

المطلوب:
1. ملخص تنفيذي لأبرز النتائج والميول العامة.
2. نسبة الرضا العام ومشاعر المشاركين (Sentiment Analysis).
3. أبرز نقاط القوة والفرص المقترحة للتحسين.
4. توصيات عملية قابلة للتنفيذ الفوري.`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ id: 'req-1', role: 'user', content: prompt }],
          model: 'gemini-3.8-flash',
        }),
      });

      if (!res.ok) throw new Error('فشل في استدعاء نموذج التحليل');
      const data = await res.json();
      setAiAnalysisResult(data.reply || data.text || 'تم اكتمال التحليل بنجاح.');
      showStatus('تم توليد التقرير الذكي بواسطة Gemini 3.8 Flash!');
    } catch (err: any) {
      console.error(err);
      showStatus('فشل في تحليل الردود: ' + err.message, 'error');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Copy link handler
  const handleCopyResponderLink = () => {
    if (selectedFormDetails?.responderUri) {
      navigator.clipboard.writeText(selectedFormDetails.responderUri);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
      showStatus('تم نسخ رابط المشاركة إلى الحافظة!');
    }
  };

  return (
    <div className={`flex flex-col h-full w-full relative overflow-hidden ${isLight ? 'bg-slate-50 text-slate-800' : 'bg-slate-950 text-slate-100'}`}>
      {/* Alert Status Banner */}
      {statusMessage && (
        <div className={`absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full shadow-xl text-sm font-medium flex items-center gap-2 animate-in fade-in slide-in-from-top duration-200 ${
          statusMessage.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {statusMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Top Header */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-3 z-10 ${isLight ? 'bg-white/80 border-slate-200' : 'bg-slate-900/80 border-slate-800'} backdrop-blur-md`}>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-purple-600/10 text-purple-500">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2">
              نماذج Google (Google Forms)
              <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 font-medium">
                Google Workspace API
              </span>
            </h1>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              أنشئ الاستبيانات، وتصفح النماذج والردود مع التحليل الذكي الفوري عبر Gemini AI
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasGoogleAuth ? (
            <>
              <button
                onClick={handleLoadForms}
                disabled={isLoadingForms}
                className={`p-2 rounded-xl border transition flex items-center gap-1.5 text-xs font-medium ${
                  isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                }`}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingForms ? 'animate-spin text-purple-500' : ''}`} />
                <span>تحديث</span>
              </button>

              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء نموذج جديد</span>
              </button>
            </>
          ) : (
            <button
              onClick={handleGoogleSignIn}
              disabled={isAuthenticating}
              className="px-4 py-2 bg-white text-slate-800 hover:bg-slate-100 rounded-xl text-xs font-bold flex items-center gap-2 border border-slate-300 shadow-sm transition"
            >
              <svg className="w-4 h-4" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
              </svg>
              {isAuthenticating ? 'جاري الاتصال...' : 'ربط Google Forms'}
            </button>
          )}
        </div>
      </div>

      {/* Main Content Layout */}
      {!hasGoogleAuth ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-lg mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-4">
            <FileText className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold mb-2">استخدم نماذج Google داخل OnyxMind</h2>
          <p className={`text-sm mb-6 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            قم بتسجيل الدخول بحساب Google للوصول إلى نماذجك واستبياناتك، جمع الردود، وتوليد تقارير ذكية مدعومة بالذكاء الاصطناعي مع الحفظ الآمن في Firebase.
          </p>
          <button
            onClick={handleGoogleSignIn}
            disabled={isAuthenticating}
            className="px-6 py-3 bg-white text-slate-900 hover:bg-slate-100 rounded-xl font-semibold flex items-center gap-3 border border-slate-300 shadow-md transition"
          >
            <svg className="w-5 h-5" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
            </svg>
            {isAuthenticating ? 'جاري الاتصال بـ Google...' : 'تسجيل الدخول باستخدام Google'}
          </button>
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* Forms List Sidebar */}
          <div className={`w-80 border-l flex flex-col ${isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
            <div className="p-3 border-b flex items-center justify-between">
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                نماذجك في Google Drive ({formsList.length})
              </h2>
              {isLoadingForms && <Loader2 className="w-3.5 h-3.5 animate-spin text-purple-500" />}
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
              {formsList.length === 0 ? (
                <div className="text-center py-12 px-4">
                  <FolderOpen className="w-8 h-8 text-slate-500 mx-auto mb-2 opacity-50" />
                  <p className="text-xs text-slate-400">لا توجد نماذج حالية في حسابك.</p>
                  <button
                    onClick={() => setIsCreateModalOpen(true)}
                    className="mt-3 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-medium"
                  >
                    إنشاء نموذج الآن
                  </button>
                </div>
              ) : (
                formsList.map((form) => (
                  <button
                    key={form.id}
                    onClick={() => handleSelectForm(form.id)}
                    className={`w-full p-2.5 rounded-xl border text-right transition flex items-start gap-2.5 ${
                      selectedFormId === form.id
                        ? 'border-purple-500 bg-purple-500/10'
                        : isLight
                        ? 'border-slate-200 hover:bg-slate-50'
                        : 'border-slate-800 hover:bg-slate-800/60'
                    }`}
                  >
                    <FileText className={`w-4 h-4 mt-0.5 shrink-0 ${selectedFormId === form.id ? 'text-purple-400' : 'text-slate-400'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold truncate">{form.name}</div>
                      <p className="text-[10px] text-slate-500 truncate mt-0.5">
                        {form.modifiedTime ? new Date(form.modifiedTime).toLocaleDateString('ar-SA') : 'Google Form'}
                      </p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Form Detail & Response Inspection Area */}
          <div className="flex-1 flex flex-col overflow-y-auto p-4 lg:p-6">
            {isLoadingDetails ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin text-purple-500 mb-2" />
                <p className="text-xs">جاري جلب بيانات النموذج والردود من Google Forms...</p>
              </div>
            ) : selectedFormDetails ? (
              <div className="max-w-4xl w-full mx-auto space-y-6">
                {/* Form Card */}
                <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'}`}>
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[11px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 font-semibold">
                          Google Form
                        </span>
                        <span className="text-xs text-slate-400">
                          ID: {selectedFormDetails.formId}
                        </span>
                      </div>
                      <h2 className="text-xl font-bold">{selectedFormDetails.info.title}</h2>
                      {selectedFormDetails.info.description && (
                        <p className={`text-sm mt-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                          {selectedFormDetails.info.description}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleCopyResponderLink}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition ${
                          isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                        }`}
                      >
                        {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink ? 'تم النسخ!' : 'رابط المشاركة'}</span>
                      </button>

                      <a
                        href={`https://docs.google.com/forms/d/${selectedFormDetails.formId}/edit`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>فتح في Google Forms</span>
                      </a>
                    </div>
                  </div>

                  {/* Metrics Banner */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6 pt-6 border-t border-slate-800/60">
                    <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700/50'}`}>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                        <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                        عدد الأسئلة
                      </div>
                      <div className="text-xl font-black">{selectedFormDetails.items?.length || 0}</div>
                    </div>

                    <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700/50'}`}>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                        <Users className="w-3.5 h-3.5 text-emerald-400" />
                        الردود المسجلة
                      </div>
                      <div className="text-xl font-black">{formResponses?.responses?.length || 0}</div>
                    </div>

                    <div className={`p-3 rounded-xl border col-span-2 sm:col-span-1 ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700/50'}`}>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                        <BarChart2 className="w-3.5 h-3.5 text-amber-400" />
                        مزامنة Firebase
                      </div>
                      <div className="text-sm font-bold text-emerald-400">متصل وآمن</div>
                    </div>
                  </div>
                </div>

                {/* AI Analysis Card */}
                <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'}`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <h3 className="font-bold text-sm">تحليل الردود الذكي بواسطة Gemini 3.8 Flash</h3>
                    </div>

                    <button
                      onClick={handleAnalyzeResponses}
                      disabled={isAnalyzing}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>جاري التحليل...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>تحليل الردود الآن</span>
                        </>
                      )}
                    </button>
                  </div>

                  {aiAnalysisResult ? (
                    <div className={`p-4 rounded-xl border whitespace-pre-wrap text-sm leading-relaxed ${
                      isLight ? 'bg-slate-50 border-slate-200 text-slate-800' : 'bg-slate-800/50 border-slate-700/60 text-slate-200'
                    }`}>
                      {aiAnalysisResult}
                    </div>
                  ) : (
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      انقر على "تحليل الردود الآن" ليقوم نموذج Gemini 3.8 Flash بتحليل إجابات المشاركين واستخلاص مشاعرهم وأهم التوصيات التنفيذية.
                    </p>
                  )}
                </div>

                {/* Form Questions Overview */}
                <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'}`}>
                  <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-purple-400" />
                    أسئلة النموذج ({selectedFormDetails.items?.length || 0})
                  </h3>

                  <div className="space-y-3">
                    {selectedFormDetails.items?.map((item, idx) => (
                      <div
                        key={item.itemId || idx}
                        className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/30 border-slate-800'}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">{idx + 1}. {item.title}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-700/40 text-slate-400">
                            {item.questionItem?.question.choiceQuestion ? 'اختيار من متعدد' : 'إجابة نصية'}
                          </span>
                        </div>
                        {item.questionItem?.question.choiceQuestion?.options && (
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {item.questionItem.question.choiceQuestion.options.map((opt, oIdx) => (
                              <span key={oIdx} className="text-[11px] px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20">
                                {opt.value}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500">
                <FileText className="w-12 h-12 mb-3 opacity-30" />
                <p className="text-sm">اختر نموذجاً من القائمة الجانبية أو أنشئ نموذجاً جديداً للبدء</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create New Form Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className={`w-full max-w-md p-6 rounded-2xl border shadow-2xl animate-in zoom-in-95 duration-150 ${
            isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-slate-900 border-slate-800 text-slate-100'
          }`}>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-purple-500" />
              إنشاء نموذج Google جديد
            </h3>

            <form onSubmit={handleCreateFormSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold block mb-1">عنوان النموذج</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: استبيان رضا العملاء 2026"
                  className={`w-full px-3 py-2 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-slate-50 border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">وصف النموذج (اختياري)</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="اكتب نبذة عن أهداف هذا الاستبيان..."
                  className={`w-full px-3 py-2 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-slate-50 border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">نوع القالب والأسئلة المقترحة</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'feedback', label: 'رضا وتقييم', icon: '⭐' },
                    { id: 'event', label: 'تسجيل فعالية', icon: '🎟️' },
                    { id: 'quiz', label: 'اختبار سريع', icon: '📝' },
                    { id: 'custom', label: 'نموذج فارغ', icon: '📄' },
                  ].map((tpl) => (
                    <button
                      key={tpl.id}
                      type="button"
                      onClick={() => setTemplateType(tpl.id as any)}
                      className={`p-2.5 rounded-xl border text-xs font-medium text-right flex items-center gap-2 transition ${
                        templateType === tpl.id
                          ? 'border-purple-500 bg-purple-500/10 text-purple-400 font-bold'
                          : isLight ? 'border-slate-200 hover:bg-slate-100' : 'border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      <span>{tpl.icon}</span>
                      <span>{tpl.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  disabled={isSubmittingForm || !newTitle.trim()}
                  className="flex-1 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow transition"
                >
                  {isSubmittingForm ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>إنشاء وحفظ في Google</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className={`px-4 py-2 rounded-xl text-xs border font-medium ${
                    isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
