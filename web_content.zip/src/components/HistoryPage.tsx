import React, { useMemo, useState } from "react";
import {
  Check,
  Image as ImageIcon,
  MessageSquare,
  Pencil,
  Plus,
  Search,
  Shield,
  Trash2,
  X,
} from "lucide-react";
import type { ChatSession } from "../types/chat";

interface HistoryPageProps {
  chats: ChatSession[];
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
  onRenameChat: (chatId: string, newTitle: string) => void;
  onRequestDeleteChat: (chat: ChatSession) => void;
  onOpenPrivacy: () => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  chats,
  onSelectChat,
  onNewChat,
  onRenameChat,
  onRequestDeleteChat,
  onOpenPrivacy,
}) => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "photos">("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return chats.filter((chat) => {
      const hasPhoto = chat.messages.some((m) => Boolean(m.image));
      if (filter === "photos" && !hasPhoto) return false;
      if (!q) return true;
      return (
        chat.title.toLowerCase().includes(q) ||
        chat.messages.some((m) => m.text.toLowerCase().includes(q))
      );
    });
  }, [chats, search, filter]);

  const startRename = (chat: ChatSession) => {
    setEditingId(chat.id);
    setDraftTitle(chat.title);
  };

  const commitRename = (chatId: string) => {
    const trimmed = draftTitle.trim();
    if (trimmed) onRenameChat(chatId, trimmed);
    setEditingId(null);
  };

  return (
    <div className="flex-1 overflow-y-auto mih-scroll">
      <div className="max-w-4xl mx-auto px-4 sm:px-8 py-6 sm:py-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Chat History
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Reopen, rename, or remove your saved conversations.
            </p>
          </div>
          <button
            type="button"
            onClick={onNewChat}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>
        </div>

        {/* Privacy Notice */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex items-start gap-3 text-sm">
          <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
          <div className="text-slate-600 dark:text-slate-300 leading-relaxed">
            Conversations are saved locally in this browser for your convenience
            and are never shared publicly. You can delete individual chats or
            clear all history anytime.{" "}
            <button
              type="button"
              onClick={onOpenPrivacy}
              className="font-medium text-blue-600 dark:text-blue-400 hover:underline"
            >
              Read Privacy Notice
            </button>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search titles or messages…"
              aria-label="Search chat history"
              className="w-full min-h-[44px] pl-10 pr-9 py-2 rounded-xl text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setFilter("all")}
              className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                filter === "all"
                  ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              All ({chats.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter("photos")}
              className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                filter === "photos"
                  ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              With Photos
            </button>
          </div>
        </div>

        {/* Conversations List */}
        {filtered.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-10 text-center space-y-3">
            <div className="w-11 h-11 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 mx-auto flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div className="text-base font-semibold text-slate-900 dark:text-slate-100">
              {chats.length === 0
                ? "No saved conversations yet"
                : "No conversations match your filter"}
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
              {chats.length === 0
                ? "Start a new chat with a text question or photo to save your conversation history here."
                : "Try clearing your search term or switching back to All chats."}
            </p>
            {chats.length === 0 && (
              <button
                type="button"
                onClick={onNewChat}
                className="mt-2 min-h-[44px] px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Start First Chat</span>
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-2.5">
            {filtered.map((chat) => {
              const lastMsg = chat.messages[chat.messages.length - 1];
              const photoCount = chat.messages.filter((m) => Boolean(m.image)).length;
              const isEditing = editingId === chat.id;

              return (
                <div
                  key={chat.id}
                  className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 p-4 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => {
                        if (!isEditing) onSelectChat(chat.id);
                      }}
                    >
                      {isEditing ? (
                        <div
                          className="flex items-center gap-2"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={draftTitle}
                            onChange={(e) => setDraftTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") commitRename(chat.id);
                              if (e.key === "Escape") setEditingId(null);
                            }}
                            autoFocus
                            className="flex-1 min-w-0 px-3 py-1.5 rounded-lg text-sm bg-slate-50 dark:bg-slate-950 border border-blue-500 text-slate-900 dark:text-slate-100 focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => commitRename(chat.id)}
                            className="min-h-[36px] min-w-[36px] rounded-lg bg-emerald-600 text-white flex items-center justify-center"
                            aria-label="Save title"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="min-h-[36px] min-w-[36px] rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center"
                            aria-label="Cancel rename"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
                            {chat.title}
                          </h2>
                          {lastMsg?.text && (
                            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                              {lastMsg.text}
                            </p>
                          )}
                          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                            <span>
                              {chat.messages.length}{" "}
                              {chat.messages.length === 1 ? "message" : "messages"}
                            </span>
                            {photoCount > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="inline-flex items-center gap-1">
                                  <ImageIcon className="w-3.5 h-3.5" />
                                  {photoCount}{" "}
                                  {photoCount === 1 ? "photo" : "photos"}
                                </span>
                              </>
                            )}
                            <span aria-hidden="true">·</span>
                            <span>
                              {new Date(chat.updatedAt).toLocaleDateString([], {
                                month: "short",
                                day: "numeric",
                                year: "numeric",
                              })}
                            </span>
                          </div>
                        </>
                      )}
                    </div>

                    {!isEditing && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => startRename(chat)}
                          className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          aria-label={`Rename ${chat.title}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onRequestDeleteChat(chat)}
                          className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                          aria-label={`Delete ${chat.title}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
