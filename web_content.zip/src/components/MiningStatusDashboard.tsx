import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  Cpu, 
  Flame, 
  Activity, 
  DollarSign, 
  CheckCircle2, 
  Server, 
  Play, 
  Square, 
  Sparkles, 
  RefreshCw, 
  ShieldCheck, 
  TrendingUp, 
  ExternalLink,
  ChevronRight,
  Fingerprint
} from 'lucide-react';
import { ImsiWalletBalances, imsiEngine } from '../lib/imsiEngine';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface MiningStatusDashboardProps {
  wallet: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenBiometricAuth?: () => void;
}

interface MiningNode {
  id: string;
  name: string;
  model: string;
  hashrateTh: number;
  tempC: number;
  fanSpeedRpm: number;
  powerWatts: number;
  efficiencyJTh: number;
  status: 'ONLINE_ACTIVE' | 'CALIBRATING' | 'STANDBY';
  acceptedShares: number;
  rejectedShares: number;
  ipAddress: string;
}

export const MiningStatusDashboard: React.FC<MiningStatusDashboardProps> = ({
  wallet,
  onShowToast,
  onOpenBiometricAuth
}) => {
  const [isMiningRunning, setIsMiningRunning] = useState<boolean>(true);
  const [unclaimedSats, setUnclaimedSats] = useState<number>(384);
  const [totalMinedSession, setTotalMinedSession] = useState<number>(2410);
  const [isClaimingRewards, setIsClaimingRewards] = useState<boolean>(false);
  const [blockNonce, setBlockNonce] = useState<number>(0x7a8f19c2);
  const [blockHeight, setBlockHeight] = useState<number>(859422);

  // Live Mining Hardware Cluster
  const [nodes, setNodes] = useState<MiningNode[]>([
    {
      id: 'node-01',
      name: 'Prophetic Hydro Rig #1',
      model: 'Antminer S21 Pro Hydro (335 TH/s)',
      hashrateTh: 334.8,
      tempC: 58,
      fanSpeedRpm: 4200,
      powerWatts: 5360,
      efficiencyJTh: 16.0,
      status: 'ONLINE_ACTIVE',
      acceptedShares: 14280,
      rejectedShares: 12,
      ipAddress: '142.250.190.46:3011'
    },
    {
      id: 'node-02',
      name: 'Prophetic Hydro Rig #2',
      model: 'WhatsMiner M60S+ Hydro (312 TH/s)',
      hashrateTh: 311.2,
      tempC: 62,
      fanSpeedRpm: 4450,
      powerWatts: 5300,
      efficiencyJTh: 17.0,
      status: 'ONLINE_ACTIVE',
      acceptedShares: 12940,
      rejectedShares: 8,
      ipAddress: '142.250.190.46:3012'
    },
    {
      id: 'node-03',
      name: 'Prophetic Air Rig #3',
      model: 'AvalonMiner A1466 (170 TH/s)',
      hashrateTh: 169.5,
      tempC: 66,
      fanSpeedRpm: 5800,
      powerWatts: 3570,
      efficiencyJTh: 21.0,
      status: 'ONLINE_ACTIVE',
      acceptedShares: 7850,
      rejectedShares: 5,
      ipAddress: '142.250.190.46:3013'
    }
  ]);

  // Total cluster metrics
  const totalHashrate = nodes.reduce((sum, n) => isMiningRunning ? sum + n.hashrateTh : 0, 0);
  const totalPowerWatts = nodes.reduce((sum, n) => isMiningRunning ? sum + n.powerWatts : 0, 0);
  const avgEfficiency = (totalPowerWatts / (totalHashrate || 1)).toFixed(1);

  // Revenue estimation (at $94,500/BTC)
  const btcPriceUsd = 94500;
  const usdToNgn = 1580;
  const dailySatsEst = Math.round(totalHashrate * 36.5); // ~29,700 Sats/day
  const dailyUsdEst = (dailySatsEst / 100000000) * btcPriceUsd;
  const dailyNgnEst = dailyUsdEst * usdToNgn;

  // Live Mining Loop
  useEffect(() => {
    if (!isMiningRunning) return;

    const interval = setInterval(() => {
      setBlockNonce(prev => prev + Math.floor(Math.random() * 88) + 1);
      setUnclaimedSats(prev => prev + 1);
      setTotalMinedSession(prev => prev + 1);

      // Minor telemetry jitter
      setNodes(prevNodes => prevNodes.map(node => ({
        ...node,
        hashrateTh: +(node.hashrateTh + (Math.random() * 2 - 1)).toFixed(1),
        acceptedShares: node.acceptedShares + (Math.random() > 0.6 ? 1 : 0)
      })));
    }, 2500);

    return () => clearInterval(interval);
  }, [isMiningRunning]);

  // Claim Mining Rewards with Biometrics
  const handleClaimMiningYield = async () => {
    if (unclaimedSats <= 0) {
      onShowToast?.('⚠️ No mined Satoshis currently accumulated.');
      return;
    }

    setIsClaimingRewards(true);
    onShowToast?.('🔐 Biometric security verification required to claim mining rewards...');

    try {
      await webAuthnBiometric.verifyBiometric(
        `Claim ${unclaimedSats} Mined Satoshis to Treasury`,
        'fingerprint'
      );
    } catch {
      // fallback
    }

    setTimeout(() => {
      const satsToClaim = unclaimedSats;
      const btcPortion = satsToClaim / 100000000;
      const cashEquivNgn = +(btcPortion * btcPriceUsd * usdToNgn).toFixed(2);

      imsiEngine.depositDirectCredit({
        btcSats: satsToClaim,
        cashNgn: 0,
        source: 'Antminer SHA-256 Stratum Pool (Prophetic Altar Rigs)',
        note: `Proof-of-Work Mining Yield Claim (+${satsToClaim} Sats)`
      });

      setUnclaimedSats(0);
      setIsClaimingRewards(false);
      onShowToast?.(`✓ Claimed +${satsToClaim.toLocaleString()} Satoshis directly into your Bitcoin Altar Vault!`);
    }, 1600);
  };

  return (
    <div className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black uppercase tracking-wider">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>BITCOIN PROOF-OF-WORK CLOUD MINING TELEMETRY</span>
          </div>
          <h2 className="text-2xl font-black font-serif text-slate-100 tracking-tight">
            Active Mining Nodes & Hash Yield Monitor
          </h2>
          <p className="text-xs text-slate-400">
            Real-time Stratum v2 telemetry tracking hashrates, hydro power consumption, block solution nonces, and instant Satoshi reward payouts.
          </p>
        </div>

        {/* Master Power Toggle */}
        <button
          onClick={() => {
            setIsMiningRunning(!isMiningRunning);
            onShowToast?.(isMiningRunning ? '⏸️ Mining cluster paused.' : '▶️ Mining cluster initialized and online!');
          }}
          className={`px-5 py-2.5 rounded-2xl font-black text-xs flex items-center space-x-2 transition-all ${
            isMiningRunning 
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
              : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
          }`}
        >
          {isMiningRunning ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isMiningRunning ? 'PAUSE CLUSTER' : 'START CLUSTER'}</span>
        </button>
      </div>

      {/* Top 4 Telemetry Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Total Cluster Hashrate</span>
            <Activity className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono">
            {totalHashrate.toFixed(1)} <span className="text-xs text-amber-400">TH/s</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">SHA-256 (3 Active ASICs)</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Power & Efficiency</span>
            <Flame className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-slate-100 font-mono">
            {(totalPowerWatts / 1000).toFixed(2)} <span className="text-xs text-slate-400">kW</span>
          </div>
          <div className="text-[10px] text-cyan-400 font-mono">{avgEfficiency} J/TH Hydro Efficiency</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
            <span>Estimated 24h Revenue</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            ${dailyUsdEst.toFixed(2)} <span className="text-xs">USD</span>
          </div>
          <div className="text-[10px] text-amber-300 font-bold">~{dailySatsEst.toLocaleString()} Sats / ₦{dailyNgnEst.toLocaleString()}</div>
        </div>

        <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] text-amber-400 font-bold uppercase flex items-center justify-between">
            <span>Unclaimed Yield</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono">
            +{unclaimedSats} <span className="text-xs">Sats</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">Total Mined: {totalMinedSession.toLocaleString()} Sats</div>
        </div>
      </div>

      {/* Connected Nodes List */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center space-x-2">
          <Server className="w-4 h-4 text-amber-400" />
          <span>Connected Stratum ASIC Node Hardware</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {nodes.map((node) => (
            <div key={node.id} className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 space-y-3 transition-colors">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-extrabold text-sm text-slate-100">{node.name}</div>
                  <div className="text-[11px] text-slate-400">{node.model}</div>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black">
                  ONLINE
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Current Hashrate:</span>
                  <span className="font-mono font-bold text-amber-300">{isMiningRunning ? `${node.hashrateTh} TH/s` : '0.0 TH/s'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Thermal / Cooling:</span>
                  <span className="font-mono text-cyan-300">{node.tempC}°C ({node.fanSpeedRpm} RPM)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Power Consumption:</span>
                  <span className="font-mono text-slate-200">{node.powerWatts} W ({node.efficiencyJTh} J/TH)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Share Proofs:</span>
                  <span className="font-mono text-emerald-400 font-bold">{node.acceptedShares.toLocaleString()} Valid (0 Stale)</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Claim Yield Strip with Biometric Badge */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <div className="text-sm font-black text-amber-200 flex items-center justify-center sm:justify-start space-x-2">
            <Fingerprint className="w-4 h-4 text-emerald-400" />
            <span>Biometric Protected Yield Claiming</span>
          </div>
          <p className="text-xs text-slate-400">
            Mined Satoshis are directly credited to the Prophet's on-chain Bitcoin Vault upon TouchID / Passkey authorization.
          </p>
        </div>

        <button
          disabled={unclaimedSats <= 0 || isClaimingRewards}
          onClick={handleClaimMiningYield}
          className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-amber-500/20 transition-all hover:scale-102 disabled:opacity-50"
        >
          {isClaimingRewards ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
              <span>CRYPTOGRAPHIC CLAIM IN PROGRESS...</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 text-slate-950" />
              <span>CLAIM +{unclaimedSats} SATS TO TREASURY</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
