import React from 'react';
import { X, CheckSquare, Flame, Target, MoonStar } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTask: () => void;
  onSelectHabit: () => void;
  onSelectGoal: () => void;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onSelectTask,
  onSelectHabit,
  onSelectGoal,
}) => {
  const { t, setActiveTab } = useApp();

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-t-3xl sm:rounded-3xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200/80 dark:border-slate-800 p-6 shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {t.quickAdd}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-2.5">
          <button
            onClick={() => {
              onClose();
              onSelectTask();
            }}
            className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-violet-50 dark:hover:bg-violet-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-all text-left group"
          >
            <div className="p-2.5 rounded-xl bg-violet-100 dark:bg-violet-900/50 text-violet-600 dark:text-violet-300 group-hover:scale-105 transition-transform">
              <CheckSquare size={20} />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 dark:text-white block">
                {t.addTask}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 block">
                Organize today or plan an upcoming milestone
              </span>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onSelectHabit();
            }}
            className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-amber-50 dark:hover:bg-amber-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-all text-left group"
          >
            <div className="p-2.5 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-300 group-hover:scale-105 transition-transform">
              <Flame size={20} />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 dark:text-white block">
                {t.addHabit}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 block">
                Track daily disciplines & streak momentum
              </span>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              onSelectGoal();
            }}
            className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-sky-50 dark:hover:bg-sky-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-all text-left group"
          >
            <div className="p-2.5 rounded-xl bg-sky-100 dark:bg-sky-900/50 text-sky-600 dark:text-sky-300 group-hover:scale-105 transition-transform">
              <Target size={20} />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 dark:text-white block">
                {t.addGoal}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 block">
                Set ambitious targets with actionable milestones
              </span>
            </div>
          </button>

          <button
            onClick={() => {
              onClose();
              setActiveTab('prayer');
            }}
            className="w-full flex items-center gap-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-all text-left group"
          >
            <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-300 group-hover:scale-105 transition-transform">
              <MoonStar size={20} />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 dark:text-white block">
                {t.recordPrayerTime}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 block">
                Track 5 daily prayers, Quran & Dhikr
              </span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
