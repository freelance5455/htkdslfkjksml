import { useState } from 'react'
import Products from './Products'
import Stock from './Stock'
import Reports from './Reports'
import Ledger from './Ledger'
import Settings from './Settings'

const TABS = [
  { id: 'products', label: 'Products' },
  { id: 'stock', label: 'Stock' },
  { id: 'reports', label: 'Reports' },
  { id: 'ledger', label: 'Udhar' },
  { id: 'settings', label: 'Settings' },
]

export default function AdminDashboard({ tab, setTab, onBack }) {
  const [refreshTick, setRefreshTick] = useState(0)
  const bump = () => setRefreshTick((t) => t + 1)

  return (
    <div className="admin">
      <header className="topbar">
        <button className="btn btn-ghost" onClick={onBack}>
          ←
        </button>
        <strong>Admin</strong>
      </header>

      <nav className="tabbar">
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="admin-body">
        {tab === 'products' && <Products refreshTick={refreshTick} onChange={bump} />}
        {tab === 'stock' && <Stock refreshTick={refreshTick} onChange={bump} />}
        {tab === 'reports' && (
          <Reports refreshTick={refreshTick} onChange={bump} />
        )}
        {tab === 'ledger' && <Ledger />}
        {tab === 'settings' && <Settings />}
      </div>
    </div>
  )
}