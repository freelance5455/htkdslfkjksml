import React, { useEffect, useRef } from 'react';
import {
  Camera,
  CloudRain,
  Moon,
  Pause,
  Smartphone,
  Square,
  Star,
  Sun,
  Users,
  Video,
  Volume2,
  VolumeX,
  Youtube,
} from 'lucide-react';
import { CharacterId, HudSnapshot } from '../types/game';
import { CHARACTER_PROFILES } from '../data/karachiWorldData';

interface GameHUDProps {
  hud: HudSnapshot;
  activeChar: CharacterId;
  muted: boolean;
  mobileControlsEnabled: boolean;
  onToggleMute: () => void;
  onCycleCamera: () => void;
  onOpenPhone: () => void;
  onOpenYouTube: () => void;
  onStopRecording: () => void;
  onSwitchCharacter: (id: CharacterId) => void;
  onPause: () => void;
  onToggleMobileControls: () => void;
  onActionInteract: () => void;
  onActionEnterExit: () => void;
}

function formatGameTime(hourFloat: number): string {
  const h = Math.floor(hourFloat) % 24;
  const m = Math.floor((hourFloat - Math.floor(hourFloat)) * 60);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${m.toString().padStart(2, '0')} ${ampm}`;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hud,
  activeChar,
  muted,
  mobileControlsEnabled,
  onToggleMute,
  onCycleCamera,
  onOpenPhone,
  onOpenYouTube,
  onStopRecording,
  onSwitchCharacter,
  onPause,
  onToggleMobileControls,
  onActionInteract,
  onActionEnterExit,
}) => {
  const radarRef = useRef<HTMLCanvasElement | null>(null);

  // Draw crisp live Karachi radar minimap
  useEffect(() => {
    const canvas = radarRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 128;
    const cx = size / 2;
    const cy = size / 2;
    const scale = 0.24;

    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = '#0b1220';
    ctx.fillRect(0, 0, size, size);

    // Arabian sea south band on minimap
    const seaY = cy + (365 - hud.playerZ) * scale;
    if (seaY < size) {
      ctx.fillStyle = '#075985';
      ctx.fillRect(0, Math.max(0, seaY), size, size - Math.max(0, seaY));
    }

    // Major Karachi avenue grid lines
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2.5;
    const roadXs = [-560, -380, -190, 0, 190, 380, 560];
    const roadZs = [-560, -420, -280, -140, 0, 120, 225, 320];
    roadXs.forEach((rx) => {
      const px = cx + (rx - hud.playerX) * scale;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, size);
      ctx.stroke();
    });
    roadZs.forEach((rz) => {
      const py = cy + (rz - hud.playerZ) * scale;
      ctx.beginPath();
      ctx.moveTo(0, py);
      ctx.lineTo(size, py);
      ctx.stroke();
    });

    // Radar blips
    hud.radarBlips.forEach((b) => {
      const bx = cx + (b.x - hud.playerX) * scale;
      const by = cy + (b.z - hud.playerZ) * scale;
      if (bx < 2 || bx > size - 2 || by < 2 || by > size - 2) return;
      ctx.fillStyle =
        b.kind === 'police'
          ? '#ef4444'
          : b.kind === 'mission'
            ? '#facc15'
            : b.kind === 'place'
              ? '#10b981'
              : '#94a3b8';
      ctx.beginPath();
      ctx.arc(bx, by, b.kind === 'mission' ? 4.5 : 2.8, 0, Math.PI * 2);
      ctx.fill();
    });

    // Custom GPS waypoint
    if (hud.waypoint) {
      const wx = THREE_CLAMP(cx + (hud.waypoint.x - hud.playerX) * scale, 6, size - 6);
      const wy = THREE_CLAMP(cy + (hud.waypoint.z - hud.playerZ) * scale, 6, size - 6);
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(wx, wy, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Player heading arrow
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-hud.playerYaw + Math.PI);
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4.5, 5);
    ctx.lineTo(0, 2.5);
    ctx.lineTo(-4.5, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }, [hud]);

  const charOrder: CharacterId[] = ['zain', 'ayesha', 'bilal', 'tariq', 'sana'];
  const nextChar = charOrder[(charOrder.indexOf(activeChar) + 1) % charOrder.length];

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 md:p-4">
      {/* TOP BAR */}
      <div className="flex items-start justify-between gap-2">
        {/* Top-Left: Radar Minimap & Current Karachi District */}
        <div className="flex items-start gap-2.5 pointer-events-auto">
          <div className="relative rounded-xl overflow-hidden border-2 border-slate-700/90 bg-slate-950 shadow-lg w-28 h-28 md:w-32 md:h-32 shrink-0">
            <canvas ref={radarRef} width={128} height={128} className="w-full h-full block" />
            <div className="absolute bottom-1 left-1.5 right-1.5 flex items-center justify-between text-[10px] font-bold text-slate-200 bg-slate-950/85 px-1.5 py-0.5 rounded">
              <span className="truncate">{hud.district.name}</span>
            </div>
          </div>

          <div className="hidden sm:flex flex-col gap-1.5 bg-slate-950/85 border border-slate-800 rounded-lg px-3 py-2 text-xs">
            <div className="flex items-center gap-2 font-bold text-slate-100">
              {hud.weather === 'rain' ? (
                <CloudRain className="w-3.5 h-3.5 text-sky-400" />
              ) : hud.timeOfDay > 19 || hud.timeOfDay < 6 ? (
                <Moon className="w-3.5 h-3.5 text-indigo-300" />
              ) : (
                <Sun className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span className="tabular-nums">{formatGameTime(hud.timeOfDay)}</span>
              <span className="text-slate-500">·</span>
              <span className="capitalize text-slate-300">{hud.weather}</span>
            </div>
            <div className="text-[11px] text-slate-400">{hud.district.tagline}</div>
          </div>
        </div>

        {/* Top-Center: Active Mission Banner */}
        {hud.activeMission && (
          <div className="bg-slate-950/90 border border-amber-400/60 rounded-lg px-3.5 py-2 text-center max-w-xs md:max-w-md shadow-lg">
            <div className="text-[10px] font-black uppercase tracking-widest text-amber-400">
              Mission · {hud.activeMission.waypointIndex + 1}/{hud.activeMission.totalWaypoints}
              {hud.activeMission.timeLeft !== null && (
                <span className="ml-2 text-rose-400 tabular-nums">
                  {Math.ceil(hud.activeMission.timeLeft)}s
                </span>
              )}
            </div>
            <div className="text-xs md:text-sm font-bold text-white truncate">
              {hud.activeMission.objective}
            </div>
          </div>
        )}

        {/* Top-Right: Cash, Wanted Stars, Health/Stamina, Quick Buttons */}
        <div className="flex flex-col items-end gap-1.5 pointer-events-auto">
          <div className="flex items-center gap-2 bg-slate-950/90 border border-slate-800 rounded-lg px-3 py-1.5 shadow">
            <span className="text-emerald-400 font-black text-sm md:text-base tabular-nums">
              Rs. {hud.cash.toLocaleString()}
            </span>
            {hud.wantedLevel > 0 && (
              <div className="flex items-center gap-0.5 pl-2 border-l border-slate-700">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star
                    key={s}
                    className={`w-3.5 h-3.5 ${
                      s <= hud.wantedLevel
                        ? 'text-amber-400 fill-amber-400'
                        : 'text-slate-700'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Health & Stamina Bars */}
          <div className="flex flex-col gap-1 w-36 md:w-44 bg-slate-950/85 border border-slate-800 rounded-lg p-1.5">
            <div className="h-2 w-full bg-slate-800 rounded overflow-hidden">
              <div
                className="h-full bg-emerald-500 transition-all duration-150"
                style={{ width: `${Math.max(0, hud.health)}%` }}
              />
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded overflow-hidden">
              <div
                className="h-full bg-sky-400 transition-all duration-150"
                style={{ width: `${Math.max(0, hud.stamina)}%` }}
              />
            </div>
          </div>

          {/* Utility Toolbar */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onSwitchCharacter(nextChar)}
              title={`Switch to ${CHARACTER_PROFILES[nextChar].name}`}
              className="flex items-center gap-1 px-2 py-1.5 rounded bg-slate-950/90 hover:bg-slate-800 border border-slate-700 text-[11px] font-bold text-slate-200 cursor-pointer"
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{CHARACTER_PROFILES[activeChar].name.split(' ')[0]}</span>
            </button>

            <button
              type="button"
              onClick={onCycleCamera}
              title="Switch Camera (C)"
              className="flex items-center gap-1 px-2 py-1.5 rounded bg-slate-950/90 hover:bg-slate-800 border border-slate-700 text-[11px] font-bold text-slate-200 cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden md:inline uppercase">
                {hud.cameraMode === 'first_person'
                  ? '1st'
                  : hud.cameraMode === 'cinematic'
                    ? 'Cine'
                    : '3rd'}
              </span>
            </button>

            {hud.isRecordingVideo ? (
              <button
                type="button"
                onClick={onStopRecording}
                title="Stop Recording & Publish to YouTube"
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-red-600 hover:bg-red-500 border border-red-300 text-[11px] font-black text-white cursor-pointer"
              >
                <Square className="w-3 h-3 fill-white" />
                <span className="tabular-nums">REC {hud.recordingSeconds}s</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenYouTube}
                title="Open YouTube Studio"
                className="flex items-center gap-1 px-2 py-1.5 rounded bg-red-600 hover:bg-red-500 border border-red-400 text-[11px] font-bold text-white cursor-pointer"
              >
                <Youtube className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">YouTube</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenPhone}
              title="Open K-Phone (P)"
              className="flex items-center gap-1 px-2 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 border border-emerald-400 text-[11px] font-bold text-white cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Phone</span>
            </button>
            <span className="sr-only">
              <Video />
            </span>

            <button
              type="button"
              onClick={onToggleMobileControls}
              title="Toggle Touch Controls"
              className={`px-2 py-1.5 rounded border text-[11px] font-bold cursor-pointer ${
                mobileControlsEnabled
                  ? 'bg-amber-400 text-slate-950 border-amber-300'
                  : 'bg-slate-950/90 text-slate-300 border-slate-700'
              }`}
            >
              Touch
            </button>

            <button
              type="button"
              onClick={onToggleMute}
              title={muted ? 'Unmute' : 'Mute'}
              className="p-1.5 rounded bg-slate-950/90 hover:bg-slate-800 border border-slate-700 text-slate-200 cursor-pointer"
            >
              {muted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            <button
              type="button"
              onClick={onPause}
              title="Pause (Esc)"
              className="p-1.5 rounded bg-slate-950/90 hover:bg-slate-800 border border-slate-700 text-slate-200 cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* BOTTOM CONTEXT PROMPT & SPEEDOMETER */}
      <div className="flex items-end justify-between gap-4">
        <div />

        {/* Interactive Contextual Prompt (Clickable for mobile/mouse too!) */}
        {hud.nearbyPrompt && (
          <button
            type="button"
            onClick={() =>
              hud.nearbyPrompt?.kind === 'place' ? onActionInteract() : onActionEnterExit()
            }
            className="pointer-events-auto mb-2 px-4 py-2 rounded-lg bg-slate-950/95 border border-amber-400 text-white text-xs md:text-sm font-bold shadow-lg flex items-center gap-2 cursor-pointer hover:bg-slate-900"
          >
            <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-black">
              {hud.nearbyPrompt.action}
            </span>
            <span>{hud.nearbyPrompt.label}</span>
          </button>
        )}

        {/* Vehicle Speedometer */}
        {hud.inVehicle ? (
          <div className="bg-slate-950/90 border border-slate-700 rounded-xl px-4 py-2.5 text-right shadow-lg min-w-[130px]">
            <div className="text-[10px] font-bold uppercase tracking-wider text-sky-400">
              {hud.vehicleName}
            </div>
            <div className="text-2xl md:text-3xl font-black text-white tabular-nums leading-none mt-0.5">
              {hud.speedKmh} <span className="text-xs font-bold text-slate-400">KM/H</span>
            </div>
          </div>
        ) : (
          <div className="text-[11px] font-bold text-slate-300/80 bg-slate-950/70 px-2.5 py-1 rounded">
            {hud.isSwimming ? 'Swimming · Arabian Sea' : 'On Foot'}
          </div>
        )}
      </div>
    </div>
  );
};

function THREE_CLAMP(val: number, min: number, max: number) {
  return Math.max(min, Math.min(max, val));
}
