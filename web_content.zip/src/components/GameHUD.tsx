/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ObjectiveStep, WeaponStats } from '../types/game';
import {
  Heart,
  Shield,
  Crosshair,
  Compass,
  Pause,
  Volume2,
  VolumeX,
  Skull,
  Radio,
  RefreshCw,
} from 'lucide-react';

interface GameHUDProps {
  health: number;
  maxHealth: number;
  armor: number;
  weapon: WeaponStats | null;
  currentMag: number;
  reserveAmmo: number;
  currentObjective: ObjectiveStep | null;
  score: number;
  kills: number;
  wave: number;
  isEndless: boolean;
  compassAngle: number;
  compassDistance: number;
  isPlayerHit: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onReload: () => void;
  onSwitchWeapon: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  health,
  maxHealth,
  armor,
  weapon,
  currentMag,
  reserveAmmo,
  currentObjective,
  score,
  kills,
  wave,
  isEndless,
  compassAngle,
  compassDistance,
  isPlayerHit,
  isMuted,
  onToggleMute,
  onPause,
  onReload,
  onSwitchWeapon,
}) => {
  const hpPercent = Math.max(0, Math.min(100, (health / maxHealth) * 100));
  const armorPercent = Math.max(0, Math.min(100, (armor / 50) * 100));

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden z-30 flex flex-col justify-between p-3 sm:p-5 font-mono">
      {/* Red Hurt Damage Screen Vignette */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-150 ${
          isPlayerHit ? 'opacity-85' : 'opacity-0'
        }`}
        style={{
          boxShadow: 'inset 0 0 100px 35px rgba(220, 38, 38, 0.75)',
        }}
      />

      {/* TOP STATUS PERIMETER CLUSTER */}
      <div className="flex items-start justify-between w-full">
        {/* Left: Health & Armor Indicators */}
        <div className="flex flex-col gap-2 bg-[#090d14]/90 border border-slate-700/80 rounded-xl p-3 shadow-lg max-w-[240px] pointer-events-auto">
          {/* Health Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="flex items-center gap-1.5 text-red-400 font-bold">
                <Heart className="w-3.5 h-3.5 fill-red-500 text-red-500" />
                <span>VITALITY</span>
              </span>
              <span className="text-white font-bold tabular-nums">
                {health}/{maxHealth}
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-900 rounded overflow-hidden">
              <div
                className={`h-full transition-all duration-200 ${
                  hpPercent > 50
                    ? 'bg-gradient-to-r from-emerald-500 to-green-400'
                    : hpPercent > 25
                    ? 'bg-gradient-to-r from-yellow-500 to-amber-400'
                    : 'bg-gradient-to-r from-red-600 to-rose-500 animate-pulse'
                }`}
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          {/* Armor Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="flex items-center gap-1.5 text-cyan-400 font-bold">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>KEVLAR</span>
              </span>
              <span className="text-white font-bold tabular-nums">{armor}/50</span>
            </div>
            <div className="w-full h-1.5 bg-slate-900 rounded overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 transition-all duration-200"
                style={{ width: `${armorPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Center: Objective & Dynamic Nav Compass */}
        {currentObjective && (
          <div className="hidden sm:flex flex-col items-center max-w-md bg-[#090d14]/90 border border-slate-700/80 rounded-xl px-4 py-2.5 shadow-lg text-center pointer-events-auto">
            <div className="flex items-center gap-2 text-xs font-bold text-red-400 tracking-wider uppercase mb-0.5">
              <Radio className="w-3.5 h-3.5 animate-pulse text-red-500" />
              <span>CURRENT DIRECTIVE</span>
            </div>
            <div className="text-sm font-bold text-white tracking-wide">
              {currentObjective.title}
            </div>
            <div className="text-[11px] text-slate-400 line-clamp-1 mb-1">
              {currentObjective.description}
            </div>

            {/* Compass Vector & Range */}
            <div className="flex items-center gap-2 text-xs text-amber-400 bg-slate-900/90 px-3 py-1 rounded-full border border-slate-800">
              <div
                className="transition-transform duration-100"
                style={{ transform: `rotate(${compassAngle}rad)` }}
              >
                <Compass className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <span className="tabular-nums font-bold">{compassDistance}m to objective</span>
            </div>
          </div>
        )}

        {/* Right: Kills, Score, Controls */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Stats Box */}
          <div className="bg-[#090d14]/90 border border-slate-700/80 rounded-xl px-3 py-2 flex items-center gap-3 text-xs shadow-lg">
            <div className="flex items-center gap-1.5 text-red-400">
              <Skull className="w-4 h-4" />
              <span className="font-bold tabular-nums text-white">{kills}</span>
            </div>
            {isEndless && (
              <div className="text-amber-400 border-l border-slate-700 pl-3">
                WAVE <span className="font-bold text-white tabular-nums">{wave}</span>
              </div>
            )}
            <div className="text-slate-400 border-l border-slate-700 pl-3">
              SCORE <span className="font-bold text-white tabular-nums">{score}</span>
            </div>
          </div>

          {/* Mute and Pause Buttons */}
          <button
            onClick={onToggleMute}
            className="p-2.5 rounded-xl bg-[#090d14]/90 border border-slate-700/80 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Mute"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          <button
            onClick={onPause}
            className="p-2.5 rounded-xl bg-[#090d14]/90 border border-slate-700/80 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Pause"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CENTER RETICLE / CROSSHAIR */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-6 h-6 flex items-center justify-center">
          <Crosshair className="w-6 h-6 text-red-400/80 stroke-1" />
          <div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.9)]" />
        </div>
      </div>

      {/* Mobile Top Objective Bar (Visible on phones) */}
      {currentObjective && (
        <div className="sm:hidden self-center bg-[#090d14]/95 border border-slate-700/80 rounded-xl px-3 py-1.5 shadow-lg text-center pointer-events-auto max-w-[280px]">
          <div className="text-xs font-bold text-red-400 tracking-wide line-clamp-1">
            {currentObjective.title}
          </div>
          <div className="text-[10px] text-amber-400 tabular-nums font-bold">
            {compassDistance}m to target
          </div>
        </div>
      )}

      {/* BOTTOM STATUS PERIMETER CLUSTER */}
      <div className="flex items-end justify-between w-full">
        {/* Creator Watermark */}
        <div className="hidden sm:block text-[11px] text-slate-400 bg-slate-950/70 border border-slate-800 px-3 py-1 rounded-md">
          DEADZONE: OUTBREAK · <span className="text-yellow-400 font-bold">MADE BY REHANX</span>
        </div>

        {/* Weapon & Ammunition Status Card */}
        <div className="flex items-center gap-3 bg-[#090d14]/90 border border-slate-700/80 rounded-xl p-3 shadow-lg pointer-events-auto ml-auto">
          {/* Weapon Name & Switch Button */}
          <button
            onClick={onSwitchWeapon}
            className="flex flex-col text-left group hover:opacity-80 transition-opacity"
            title="Tap to switch weapon"
          >
            <div className="text-[10px] text-slate-400 uppercase tracking-widest flex items-center gap-1">
              <span>FIREARM</span>
              <RefreshCw className="w-2.5 h-2.5 text-cyan-400" />
            </div>
            <div className="text-sm font-bold text-white tracking-wide">
              {weapon?.name || 'Tactical 9mm'}
            </div>
          </button>

          {/* Ammo Numbers readout */}
          <div className="border-l border-slate-700 pl-3 flex items-baseline gap-1">
            <span
              className={`text-2xl font-black tabular-nums ${
                currentMag <= 3 ? 'text-red-500 animate-pulse' : 'text-white'
              }`}
            >
              {currentMag}
            </span>
            <span className="text-xs text-slate-400 font-bold tabular-nums">
              / {reserveAmmo}
            </span>
          </div>

          {/* Quick Reload Button */}
          <button
            onClick={onReload}
            className="px-2.5 py-1.5 rounded-lg bg-red-950/60 border border-red-500/50 hover:bg-red-900/60 text-red-300 text-xs font-bold uppercase transition-colors"
          >
            [R]
          </button>
        </div>
      </div>
    </div>
  );
};
