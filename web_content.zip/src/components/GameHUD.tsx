import React from 'react';
import { Volume2, VolumeX, Pause, Play } from 'lucide-react';
import { ClimbableWall, GameStats, Player } from '../types/game';

interface GameHUDProps {
  stats: GameStats;
  isChased: boolean;
  player: Player;
  nearbyClimbableWall: ClimbableWall | null;
  portalLockedWarning: string | null;
  onUseLadder: (wall: ClimbableWall) => void;
  onExitHiding: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isPaused: boolean;
  onTogglePause: () => void;
  portalAngleRad: number; // Angle from player to portal
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  isChased,
  player,
  nearbyClimbableWall,
  portalLockedWarning,
  onUseLadder,
  onExitHiding,
  isMuted,
  onToggleMute,
  isPaused,
  onTogglePause,
  portalAngleRad,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms}`;
  };

  const allCrystalsCollected = stats.crystalsCollected >= stats.totalCrystals;

  return (
    <div className="absolute inset-0 pointer-events-none p-3 sm:p-4 flex flex-col justify-between select-none">
      {/* Top Bar: Timer, Crystal Counter & Quick Controls */}
      <div className="flex flex-col w-full space-y-2">
        <div className="flex items-center justify-between w-full">
          {/* Survival Timer */}
          <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/80 shadow-lg flex items-center space-x-1.5">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">TIME</span>
            <span className="font-mono-num font-bold text-amber-400 text-sm sm:text-base">
              {formatTime(stats.timeElapsed)}
            </span>
          </div>

          {/* Crystals Counter Badge */}
          <div
            className={`px-3 py-1.5 rounded-xl shadow-lg flex items-center space-x-1.5 transition-all duration-300 ${
              allCrystalsCollected
                ? 'bg-emerald-950/90 border-2 border-emerald-400 text-emerald-200 animate-pulse shadow-emerald-900/50'
                : 'bg-slate-900/85 border border-slate-700/80 text-white'
            }`}
          >
            <span className="text-sm">💎</span>
            <span className="text-[11px] font-black uppercase tracking-wider">
              {allCrystalsCollected ? 'PORTAL READY' : 'CRYSTALS:'}
            </span>
            <span
              className={`font-mono-num font-extrabold text-sm ${
                allCrystalsCollected ? 'text-emerald-300' : 'text-amber-300'
              }`}
            >
              {stats.crystalsCollected}/{stats.totalCrystals}
            </span>
          </div>

          {/* Top-Right Controls: Portal Compass + Audio + Pause */}
          <div className="flex items-center space-x-1.5 pointer-events-auto">
            {/* Compass to Portal */}
            <div
              className={`backdrop-blur-md px-2 py-1.5 rounded-xl border shadow-lg flex items-center space-x-1 ${
                allCrystalsCollected
                  ? 'bg-emerald-950/85 border-emerald-500 text-emerald-300'
                  : 'bg-slate-900/85 border-slate-700/80 text-cyan-300'
              }`}
              title="Direction to Central Portal"
            >
              <div
                className={`transition-transform duration-200 text-xs font-bold ${
                  allCrystalsCollected ? 'text-emerald-400' : 'text-cyan-400'
                }`}
                style={{ transform: `rotate(${portalAngleRad}rad)` }}
              >
                ➔
              </div>
              <span className="text-[10px] font-extrabold">
                {allCrystalsCollected ? 'EXIT' : 'PORTAL'}
              </span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={onToggleMute}
              className="w-8 h-8 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition active:scale-95 shadow-lg"
              title="Toggle Sound"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            {/* Pause Button */}
            <button
              onClick={onTogglePause}
              className="w-8 h-8 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition active:scale-95 shadow-lg"
              title="Pause Game"
            >
              {isPaused ? <Play className="w-4 h-4 fill-amber-400 text-amber-400" /> : <Pause className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Portal Locked Alert Banner */}
        {portalLockedWarning && (
          <div className="flex justify-center w-full animate-bounce">
            <div className="bg-linear-to-r from-purple-800 to-pink-700 text-white font-black px-4 py-2 rounded-2xl shadow-xl shadow-purple-950/70 border-2 border-yellow-300 flex items-center space-x-2 text-xs sm:text-sm tracking-wide">
              <span className="text-base animate-pulse">🔒</span>
              <span>{portalLockedWarning}</span>
            </div>
          </div>
        )}

        {/* Center Chase Warning Badge beneath top bar */}
        {isChased && !portalLockedWarning && (
          <div className="flex justify-center w-full">
            <div className="animate-bounce bg-red-600/95 text-white font-black px-4 py-1.5 rounded-full shadow-lg shadow-red-600/50 border-2 border-white flex items-center space-x-2 text-xs sm:text-sm tracking-wide">
              <span className="text-base animate-pulse">⚠️</span>
              <span>CHICKEN CHASING YOU!</span>
            </div>
          </div>
        )}
      </div>

      {/* Middle/Bottom Area: Exit Bush / Hiding Action (Centered above controls) */}
      {player.isHiding && (
        <div className="flex justify-center w-full mb-3 pointer-events-auto">
          <button
            onClick={onExitHiding}
            className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black px-5 py-3 rounded-2xl shadow-2xl shadow-emerald-950/80 border-2 border-emerald-200 flex items-center space-x-2 text-sm sm:text-base transition animate-pulse"
          >
            <span className="text-lg">🌿</span>
            <span>SAFE BUSH (HIDDEN) • EXIT</span>
          </button>
        </div>
      )}

      {player.isAtFakeBush && (
        <div className="flex justify-center w-full mb-3 pointer-events-auto animate-bounce">
          <button
            onClick={onExitHiding}
            className="bg-red-600 hover:bg-red-500 active:scale-95 text-white font-black px-5 py-3 rounded-2xl shadow-2xl shadow-red-950/80 border-2 border-yellow-300 flex items-center space-x-2 text-sm sm:text-base transition"
          >
            <span className="text-lg">⚠️</span>
            <span>FAKE BUSH! NO COVER! RUN!</span>
          </button>
        </div>
      )}

      {/* Bottom Area: Action Buttons (Ladder) */}
      <div className="flex items-end justify-end w-full pb-1">

        {/* Right: Ladder Action Button (shown when available or countdown active) */}
        <div className="pointer-events-auto flex flex-col items-end space-y-2">
          {player.isPlacingLadder ? (
            <div className="bg-amber-600 text-white font-black px-4 py-3 rounded-2xl border-2 border-amber-300 shadow-2xl flex items-center space-x-2 animate-pulse">
              <span className="text-xl">🪜</span>
              <div>
                <div className="text-xs uppercase tracking-wider text-amber-200">SECURING LADDER</div>
                <div className="font-mono-num text-lg">{player.ladderTimeRemaining.toFixed(1)}s</div>
              </div>
            </div>
          ) : nearbyClimbableWall && player.laddersAvailable > 0 ? (
            <button
              onClick={() => onUseLadder(nearbyClimbableWall)}
              className="bg-linear-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-slate-950 font-black px-4 py-3 rounded-2xl shadow-2xl shadow-amber-600/50 border-2 border-white flex items-center space-x-2.5 transition"
            >
              <span className="text-2xl">🪜</span>
              <div className="text-left">
                <div className="text-xs font-black uppercase text-amber-950">CLIMB WALL</div>
                <div className="text-[11px] text-amber-900 font-semibold">
                  Takes 5s ({player.laddersAvailable} left)
                </div>
              </div>
            </button>
          ) : (
            // Small badge showing remaining ladders in reserve
            <div className="bg-slate-900/70 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-slate-700/60 text-slate-300 text-xs font-semibold flex items-center space-x-1.5 shadow-md">
              <span>🪜 Ladders:</span>
              <span className="text-amber-400 font-bold">{player.laddersAvailable}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
