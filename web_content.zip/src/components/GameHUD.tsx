import React, { useState } from 'react';
import {
  Compass,
  Flame,
  HelpCircle,
  Package,
  Shield,
  Sparkles,
  Swords,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { soundManager } from '../audio/soundManager';
import { FRUITS } from '../game/worldData';
import { MinimapData, PlayerStats, Quest } from '../types/game';
import { Minimap } from './Minimap';

interface GameHUDProps {
  stats: PlayerStats;
  activeQuest: Quest | null;
  minimapData: MinimapData | null;
  interactPrompt: string | null;
  skillCooldowns: Record<string, number>;
  onTriggerAttack: () => void;
  onTriggerJump: () => void;
  onTriggerSkill: (key: 'Z' | 'X' | 'C' | 'V' | 'F') => void;
  onTriggerFlashStep: () => void;
  onToggleHaki: () => void;
  onToggleObservation: () => void;
  onOpenStats: () => void;
  onOpenInventory: () => void;
  onOpenFruitDealer: () => void;
  onOpenQuests: () => void;
  onOpenHelp: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  activeQuest,
  minimapData,
  interactPrompt,
  skillCooldowns,
  onTriggerAttack,
  onTriggerJump,
  onTriggerSkill,
  onTriggerFlashStep,
  onToggleHaki,
  onToggleObservation,
  onOpenStats,
  onOpenInventory,
  onOpenFruitDealer,
  onOpenQuests,
  onOpenHelp,
}) => {
  const [isMuted, setIsMuted] = useState(soundManager.getMuted());
  const [hudCollapsed, setHudCollapsed] = useState(typeof window !== 'undefined' && window.innerWidth < 768);

  const toggleSound = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
  };

  const fruitData = stats.equippedFruit !== 'none' ? FRUITS[stats.equippedFruit] : null;

  const healthPct = Math.max(0, Math.min(100, (stats.health / stats.maxHealth) * 100));
  const energyPct = Math.max(0, Math.min(100, (stats.energy / stats.maxEnergy) * 100));
  const expPct = Math.max(0, Math.min(100, (stats.exp / stats.maxExp) * 100));

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden font-sans">
      {/* 1. TOP-LEFT: Character Profile & Status Bars */}
      <div className="absolute top-3 left-3 md:top-4 md:left-4 flex items-start gap-3 pointer-events-auto">
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-2.5 md:p-3 shadow-xl backdrop-blur-md w-[165px] sm:w-[200px] md:min-w-[280px]">
          {/* Header Row */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-amber-400 font-extrabold text-sm uppercase tracking-wider">Pirate</span>
              <span className="text-slate-400 text-xs">·</span>
              <span className="text-white font-bold text-sm">Lv. {stats.level}</span>
            </div>
            {stats.statPoints > 0 && (
              <button
                onClick={onOpenStats}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] px-2 py-0.5 rounded shadow cursor-pointer transition-transform active:scale-95 animate-bounce"
              >
                +{stats.statPoints} PTS
              </button>
            )}
          </div>

          {/* Health Bar (Red/Green) */}
          <div className="mb-2">
            <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-0.5">
              <span className="font-semibold text-emerald-400">HEALTH</span>
              <span>{Math.round(stats.health)} / {stats.maxHealth}</span>
            </div>
            <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-gradient-to-r from-emerald-600 to-emerald-400 h-full rounded-full transition-all duration-200"
                style={{ width: `${healthPct}%` }}
              />
            </div>
          </div>

          {/* Energy / Stamina Bar (Cyan) */}
          <div className="mb-2">
            <div className="flex justify-between text-[11px] text-slate-300 font-mono mb-0.5">
              <span className="font-semibold text-cyan-400">ENERGY</span>
              <span>{Math.round(stats.energy)} / {stats.maxEnergy}</span>
            </div>
            <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-gradient-to-r from-cyan-600 to-cyan-400 h-full rounded-full transition-all duration-200"
                style={{ width: `${energyPct}%` }}
              />
            </div>
          </div>

          {/* EXP Bar (Amber) */}
          <div>
            <div className="flex justify-between text-[10px] text-slate-400 font-mono mb-0.5">
              <span>EXP</span>
              <span>{stats.exp} / {stats.maxExp}</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-amber-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${expPct}%` }}
              />
            </div>
          </div>

          {/* Fruit & Weapon indicator */}
          <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span className="truncate max-w-[130px] font-medium text-slate-200">
                {fruitData ? fruitData.name.split(' ')[0] : 'No Fruit'}
              </span>
              {fruitData && (
                <span className="text-[10px] text-purple-400 font-mono bg-purple-950/70 border border-purple-800/60 px-1 rounded">
                  M.{stats.fruitMastery}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              <Swords className="w-3.5 h-3.5 text-sky-400" />
              <span className="capitalize font-medium text-slate-200">
                {stats.equippedWeapon.replace('_', ' ')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. TOP-RIGHT: Beli / Gems & Action Navigation */}
      <div className="absolute top-4 right-4 flex flex-col items-end gap-2 pointer-events-auto">
        {/* Currencies Pill Container */}
        <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-700/80 rounded-xl px-4 py-2 shadow-xl backdrop-blur-md">
          {/* Beli */}
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 font-black text-xs">
              $
            </div>
            <span className="font-mono font-bold text-sm text-emerald-300 tabular-nums">
              {stats.beli.toLocaleString()}
            </span>
            <span className="text-[11px] text-slate-400 font-semibold">Beli</span>
          </div>

          <div className="w-px h-4 bg-slate-700" />

          {/* Gems */}
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded-full bg-purple-500/20 border border-purple-500/50 flex items-center justify-center text-purple-400">
              <Sparkles className="w-3 h-3" />
            </div>
            <span className="font-mono font-bold text-sm text-purple-300 tabular-nums">
              {stats.gems}
            </span>
            <span className="text-[11px] text-slate-400 font-semibold">Gems</span>
          </div>
        </div>

        {/* Quick Action Navigation Buttons */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-700/80 rounded-xl p-1.5 shadow-xl backdrop-blur-md">
          <button
            onClick={onOpenStats}
            title="Character Stats [C]"
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Stats</span>
            {stats.statPoints > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-400" />
            )}
          </button>

          <button
            onClick={onOpenFruitDealer}
            title="Blox Fruit Dealer"
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Spin Fruit</span>
          </button>

          <button
            onClick={onOpenInventory}
            title="Inventory & Fruits"
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Package className="w-3.5 h-3.5 text-sky-400" />
            <span>Bag</span>
          </button>

          <button
            onClick={onOpenQuests}
            title="Quest Log"
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            <span>Quests</span>
          </button>

          <button
            onClick={toggleSound}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={onOpenHelp}
            title="Controls & Guide"
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        {/* 2D Nautical Radar Minimap */}
        <Minimap data={minimapData} className="mt-1" />

        {/* Active Quest Pinned Card */}
        {activeQuest && (
          <div className="bg-slate-900/95 border border-amber-500/50 rounded-xl p-2.5 md:p-3 shadow-xl backdrop-blur-md w-[190px] md:w-[210px] mt-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] md:text-[11px] font-bold text-amber-400 uppercase tracking-wider">Quest</span>
              <span className="text-[11px] font-mono font-bold text-emerald-400">
                +{activeQuest.rewardBeli.toLocaleString()}
              </span>
            </div>
            <div className="font-bold text-xs md:text-sm text-white truncate">{activeQuest.title}</div>
            <div className="text-[11px] text-slate-300 mt-0.5 truncate">
              {activeQuest.targetEnemyType.replace('_', ' ')}s:
            </div>
            <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1">
              <span>Progress</span>
              <span className="text-white font-bold">{activeQuest.currentCount} / {activeQuest.targetCount}</span>
            </div>
            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-amber-400 h-full rounded-full transition-all duration-200"
                style={{ width: `${(activeQuest.currentCount / activeQuest.targetCount) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* 3. INTERACTION PROMPT (Center Screen Alert) */}
      {interactPrompt && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 bg-slate-950/90 border border-amber-500/60 text-white px-5 py-2.5 rounded-full shadow-2xl backdrop-blur-md flex items-center gap-2 pointer-events-auto animate-fade-in">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
          <span className="text-sm font-semibold tracking-wide">{interactPrompt}</span>
        </div>
      )}

      {/* 4. BOTTOM COLLAPSIBLE COMBAT DOCK (Zero Viewport Occlusion per Three.js Skill) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 max-w-[940px] w-[95%] pointer-events-auto flex flex-col items-center">
        {/* Toggle Collapse Button */}
        <button
          onClick={() => setHudCollapsed(!hudCollapsed)}
          className="mb-1 bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white text-[11px] font-semibold px-3 py-1 rounded-full border border-slate-700/60 shadow-lg cursor-pointer transition-colors"
        >
          {hudCollapsed ? '▴ Show Ability Dock' : '▾ Hide Controls'}
        </button>

        {!hudCollapsed && (
          <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-2.5 shadow-2xl backdrop-blur-md w-full flex items-center justify-between gap-2 overflow-x-auto">
            {/* Primary Combat / Weapon Attacks */}
            <div className="flex items-center gap-2 shrink-0">
              {/* M1: Normal Attack */}
              <button
                onClick={onTriggerAttack}
                className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-600 text-white cursor-pointer active:scale-95 transition-all shadow-md group"
              >
                <Swords className="w-5 h-5 text-sky-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-bold mt-1 text-slate-300">ATTACK</span>
                <span className="text-[9px] font-mono text-slate-400">M1 / Click</span>
              </button>

              {/* Soru / Flash Step [Q] */}
              <div className="relative">
                <button
                  onClick={onTriggerFlashStep}
                  disabled={skillCooldowns['Q'] > 0}
                  className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-600 text-white cursor-pointer active:scale-95 transition-all shadow-md disabled:opacity-50"
                >
                  <Zap className="w-5 h-5 text-cyan-400" />
                  <span className="text-[10px] font-bold mt-1 text-slate-300">FLASH STEP</span>
                  <span className="text-[9px] font-mono text-cyan-300">[Q]</span>
                </button>
                {skillCooldowns['Q'] > 0 && (
                  <div className="absolute inset-0 bg-slate-950/80 rounded-xl flex items-center justify-center font-mono font-bold text-sm text-cyan-300">
                    {skillCooldowns['Q'].toFixed(1)}s
                  </div>
                )}
              </div>

              {/* Haki / Aura [J] */}
              <button
                onClick={onToggleHaki}
                className={`flex flex-col items-center justify-center w-16 h-16 rounded-xl border text-white cursor-pointer active:scale-95 transition-all shadow-md ${
                  stats.hakiActive
                    ? 'bg-purple-900/80 border-purple-400 shadow-purple-500/20'
                    : 'bg-slate-800/90 hover:bg-slate-700 border-slate-600'
                }`}
              >
                <Shield className="w-5 h-5 text-purple-400" />
                <span className="text-[10px] font-bold mt-1 text-slate-300">AURA HAKI</span>
                <span className="text-[9px] font-mono text-purple-300">[J]</span>
              </button>

              {/* Kenbunshoku / Observation [E] */}
              <button
                onClick={onToggleObservation}
                className={`flex flex-col items-center justify-center w-16 h-16 rounded-xl border text-white cursor-pointer active:scale-95 transition-all shadow-md ${
                  stats.observationActive
                    ? 'bg-sky-900/80 border-sky-400 shadow-sky-500/20'
                    : 'bg-slate-800/90 hover:bg-slate-700 border-slate-600'
                }`}
              >
                <Zap className="w-5 h-5 text-sky-400" />
                <span className="text-[10px] font-bold mt-1 text-slate-300">OBSERVE</span>
                <span className="text-[9px] font-mono text-sky-300">[E]</span>
              </button>
            </div>

            <div className="w-px h-12 bg-slate-700/80 shrink-0 mx-1" />

            {/* Devil Fruit Abilities (Z, X, C, V, F) */}
            <div className="flex items-center gap-2 shrink-0">
              {(['Z', 'X', 'C', 'V', 'F'] as const).map((key) => {
                const skill = fruitData?.skills.find((s) => s.key === key);
                const isLocked = !skill || stats.fruitMastery < skill.requiredMastery;
                const cd = skillCooldowns[key] || 0;

                return (
                  <div key={key} className="relative">
                    <button
                      onClick={() => onTriggerSkill(key)}
                      disabled={isLocked || cd > 0}
                      title={skill ? `${skill.name} - ${skill.description}` : 'No skill bound'}
                      className={`flex flex-col items-center justify-center w-16 h-16 rounded-xl border text-white cursor-pointer active:scale-95 transition-all shadow-md ${
                        isLocked
                          ? 'bg-slate-900/60 border-slate-800 opacity-40 cursor-not-allowed'
                          : 'bg-slate-800/90 hover:bg-slate-700 border-amber-500/40 hover:border-amber-400'
                      }`}
                    >
                      <Flame className={`w-5 h-5 ${isLocked ? 'text-slate-600' : 'text-orange-400'}`} />
                      <span className="text-[9px] font-bold mt-1 text-slate-200 truncate max-w-[56px]">
                        {skill ? skill.name.split(' ')[0] : 'EMPTY'}
                      </span>
                      <span className="text-[9px] font-mono text-amber-300">[{key}]</span>
                    </button>

                    {/* Cooldown Overlay */}
                    {cd > 0 && (
                      <div className="absolute inset-0 bg-slate-950/85 rounded-xl flex items-center justify-center font-mono font-bold text-xs text-amber-300">
                        {cd.toFixed(1)}s
                      </div>
                    )}

                    {/* Mastery Requirement Tag */}
                    {skill && isLocked && (
                      <div className="absolute -top-1.5 -right-1 bg-purple-950 border border-purple-800 text-purple-300 text-[9px] font-mono px-1 rounded">
                        M.{skill.requiredMastery}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
