import React, { useRef } from 'react';
import { sound } from '../game/audio';
import { ITEMS, MONSTERS, REGIONS, WEAPONS } from '../game/constants';
import { ActiveMonsterState, PlayerStats, RegionId } from '../game/types';

interface GameHUDProps {
  stats: PlayerStats;
  currentRegion: RegionId;
  targetMonster: ActiveMonsterState | null;
  notification: string | null;
  onOpenModal: (modal: 'forge' | 'camp' | 'quest' | 'bestiary' | 'inventory' | 'settings' | 'pause') => void;
  onUseItem: () => void;
  onCycleItem: (dir: number) => void;
  onToggleLockOn: () => void;
  onInteract: () => void;
  // Mobile virtual button triggers
  onTouchAction: (action: string, isDown: boolean) => void;
  onJoystickTouch: (active: boolean, dx: number, dy: number) => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  currentRegion,
  targetMonster,
  notification,
  onOpenModal,
  onUseItem,
  onCycleItem,
  onToggleLockOn,
  onInteract,
  onTouchAction,
  onJoystickTouch,
}) => {
  const regionCfg = REGIONS[currentRegion];
  const weapon = WEAPONS[stats.equippedWeaponId] || WEAPONS['iron_greatsword'];
  const currentItemSlot = stats.pouch[stats.selectedPouchIndex];
  const currentItemDef = currentItemSlot ? ITEMS[currentItemSlot.itemId] : null;

  // Joystick touch tracking
  const joystickRef = useRef<HTMLDivElement>(null);
  const touchOriginRef = useRef<{ x: number; y: number } | null>(null);

  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchOriginRef.current = { x: touch.clientX, y: touch.clientY };
    onJoystickTouch(true, 0, 0);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    if (!touchOriginRef.current) return;
    const touch = e.touches[0];
    const dx = touch.clientX - touchOriginRef.current.x;
    const dy = touch.clientY - touchOriginRef.current.y;
    const dist = Math.hypot(dx, dy);
    const maxDist = 45;
    const clampedDist = Math.min(dist, maxDist);
    const angle = Math.atan2(dy, dx);
    const normX = (Math.cos(angle) * clampedDist) / maxDist;
    const normY = (Math.sin(angle) * clampedDist) / maxDist;
    onJoystickTouch(true, normX, normY);
  };

  const handleJoystickTouchEnd = () => {
    touchOriginRef.current = null;
    onJoystickTouch(false, 0, 0);
  };

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-30 flex flex-col justify-between p-3 sm:p-5 font-mono">
      {/* ========================================================= */}
      {/* TOP BAR CLUSTER */}
      {/* ========================================================= */}
      <div className="flex flex-col sm:flex-row justify-between items-start gap-2 w-full">
        <div className="flex justify-between items-start w-full sm:w-auto gap-2">
          {/* TOP-LEFT: Hunter Vitality & Weapon Status */}
          <div className="flex flex-col gap-1 bg-stone-950/85 p-2 rounded border border-stone-800 text-stone-100 min-w-[160px] sm:min-w-[240px] shadow-md pointer-events-auto text-[10px]">
            {/* Header row: Hunter Rank & Region */}
            <div className="flex justify-between items-center text-[9px] sm:text-[10px] tracking-wider text-stone-400 border-b border-stone-800/80 pb-0.5">
              <span className="text-amber-400 font-bold">HR {stats.hunterRank}</span>
              <span className="truncate max-w-[90px] sm:max-w-[120px] text-stone-300">{regionCfg.name}</span>
              <span className="text-stone-400">{stats.zenny.toLocaleString()}z</span>
            </div>

            {/* Health Bar (HP) */}
            <div className="flex flex-col gap-0.5">
              <div className="flex justify-between text-[9px] leading-none">
                <span className="text-emerald-400 font-bold">HP</span>
                <span className="text-stone-300 tabular-nums">
                  {Math.round(stats.hp)} / {stats.maxHp}
                </span>
              </div>
              <div className="w-full h-2.5 bg-stone-900 rounded-xs overflow-hidden border border-stone-800 relative">
                <div
                  className="h-full bg-emerald-500 transition-all duration-75"
                  style={{ width: `${Math.max(0, Math.min(100, (stats.hp / stats.maxHp) * 100))}%` }}
                />
              </div>
            </div>

            {/* Stamina Bar (STA) */}
            <div className="flex flex-col gap-0.5">
              <div className="flex justify-between text-[9px] leading-none">
                <span className="text-yellow-400 font-bold">STA</span>
                <span className="text-stone-300 tabular-nums">
                  {Math.round(stats.stamina)} / {stats.maxStamina}
                </span>
              </div>
              <div className="w-full h-1.5 sm:h-2 bg-stone-900 rounded-xs overflow-hidden border border-stone-800">
                <div
                  className="h-full bg-amber-400 transition-all duration-75"
                  style={{
                    width: `${Math.max(0, Math.min(100, (stats.stamina / stats.maxStamina) * 100))}%`,
                  }}
                />
              </div>
            </div>

            {/* Weapon Specific Meter */}
            <div className="flex items-center justify-between text-[9px] sm:text-[10px] pt-0.5 border-t border-stone-800/80">
              <span className="font-bold text-stone-200 uppercase truncate max-w-[85px] sm:max-w-none">{weapon.name}</span>

              {/* Class specific gauge indicator */}
              {weapon.weaponClass === 'longsword' && (
                <span
                  className={`text-[8px] sm:text-[9px] px-1 py-0.2 rounded font-bold ${
                    stats.spiritLevel === 3
                      ? 'bg-red-500 text-white animate-pulse'
                      : stats.spiritLevel === 2
                      ? 'bg-amber-500 text-stone-950'
                      : stats.spiritLevel === 1
                      ? 'bg-stone-300 text-stone-950'
                      : 'text-stone-500'
                  }`}
                >
                  SP.LV.{stats.spiritLevel} ({Math.round(stats.spiritGauge)}%)
                </span>
              )}

              {weapon.weaponClass === 'dualblades' && (
                <span
                  className={`text-[8px] sm:text-[9px] px-1 py-0.2 rounded font-bold ${
                    stats.demonMode
                      ? 'bg-red-600 text-white animate-pulse'
                      : 'text-stone-400'
                  }`}
                >
                  {stats.demonMode ? 'DEMON' : `${Math.round(stats.demonGauge)}%`}
                </span>
              )}

              {weapon.weaponClass === 'greatsword' && (
                <span className="text-[8px] sm:text-[9px] text-amber-400 font-bold">
                  CHARGE [K]
                </span>
              )}

              {weapon.weaponClass === 'bow' && (
                <span className="text-[8px] sm:text-[9px] text-cyan-400 font-bold">
                  COAT: {stats.bowCoating.toUpperCase()}
                </span>
              )}

              {weapon.weaponClass === 'lance' && (
                <span className="text-[8px] sm:text-[9px] text-sky-400 font-bold">
                  GUARD [L]
                </span>
              )}

              {weapon.weaponClass === 'hammer' && (
                <span className="text-[8px] sm:text-[9px] text-orange-400 font-bold">
                  BLUNT KO
                </span>
              )}
            </div>
          </div>

          {/* TOP-RIGHT: Utility Controls Dock */}
          <div className="flex items-center gap-1 pointer-events-auto">
            <button
              onClick={() => {
                sound.play('ui_click');
                onToggleLockOn();
              }}
              title="Lock-On Target [Q]"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              LOCK
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onOpenModal('camp');
              }}
              title="Fast Travel & Camps"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              MAP
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onOpenModal('forge');
              }}
              title="Blacksmith & Forge"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              FORGE
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onOpenModal('quest');
              }}
              title="Quest Board"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              QUESTS
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onOpenModal('bestiary');
              }}
              title="Hunter Bestiary"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              BOOK
            </button>
            <button
              onClick={() => {
                sound.play('ui_click');
                onOpenModal('pause');
              }}
              title="Pause Menu [Esc]"
              className="px-2 h-7 sm:w-10 sm:h-10 bg-stone-950/85 hover:bg-stone-900 text-stone-300 hover:text-amber-400 border border-stone-800 rounded flex items-center justify-center cursor-pointer transition-colors shadow-md text-[9px] sm:text-xs font-bold"
            >
              MENU
            </button>
          </div>
        </div>

        {/* TOP-CENTER: Active Target Monster Boss Bar */}
        {targetMonster && targetMonster.state !== 'dead' && (
          <div className="w-full sm:max-w-md bg-stone-950/85 p-1.5 sm:p-2 rounded border border-stone-800 text-stone-100 shadow-lg pointer-events-auto flex flex-col gap-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1.5">
                <span className="text-red-500 font-bold text-[11px] sm:text-xs uppercase">
                  {MONSTERS[targetMonster.defId]?.name || targetMonster.defId}
                </span>
                {targetMonster.enraged && (
                  <span className="text-[8px] bg-red-600 text-white px-1 rounded uppercase tracking-wider font-bold animate-pulse">
                    ENRAGED
                  </span>
                )}
                {targetMonster.state === 'exhausted' && (
                  <span className="text-[8px] bg-sky-600 text-white px-1 rounded uppercase tracking-wider font-bold">
                    EXHAUSTED
                  </span>
                )}
              </div>
              <span className="text-[9px] sm:text-[10px] text-stone-400 tabular-nums">
                {Math.round(targetMonster.hp)} / {targetMonster.maxHp}
              </span>
            </div>

            {/* Boss Health Bar */}
            <div className="w-full h-2 sm:h-2.5 bg-stone-900 rounded-xs overflow-hidden border border-stone-800">
              <div
                className={`h-full transition-all duration-75 ${
                  targetMonster.enraged ? 'bg-red-500' : 'bg-red-600'
                }`}
                style={{
                  width: `${Math.max(0, Math.min(100, (targetMonster.hp / targetMonster.maxHp) * 100))}%`,
                }}
              />
            </div>

            {/* Breakable Parts Status */}
            <div className="flex items-center gap-1.5 text-[8px] sm:text-[9px] text-stone-400 overflow-x-auto pt-0.5">
              <span>PARTS:</span>
              {targetMonster.parts.map((p) => (
                <span
                  key={p.id}
                  className={`px-1 py-0.2 rounded border ${
                    p.broken
                      ? 'border-red-500/60 text-red-400 bg-red-950/30 line-through'
                      : 'border-stone-800 text-stone-300'
                  }`}
                >
                  {p.name}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>


      {/* ========================================================= */}
      {/* NOTIFICATION BANNER (CENTER) */}
      {/* ========================================================= */}
      {notification && (
        <div className="mx-auto bg-stone-950/90 border border-amber-500/80 text-amber-300 px-4 py-1.5 rounded shadow-xl text-xs sm:text-sm font-bold tracking-wider uppercase animate-fade-in pointer-events-none">
          {notification}
        </div>
      )}

      {/* ========================================================= */}
      {/* BOTTOM CONTROLS & MOBILE COMBAT CLUSTER */}
      {/* ========================================================= */}
      <div className="flex justify-between items-end gap-3 w-full">
        {/* BOTTOM-LEFT: Virtual Joystick on Mobile Touch & Region Label */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          {/* Virtual Joystick Touch Base */}
          <div
            ref={joystickRef}
            onTouchStart={handleJoystickTouchStart}
            onTouchMove={handleJoystickTouchMove}
            onTouchEnd={handleJoystickTouchEnd}
            className="w-28 h-28 sm:w-32 sm:h-32 rounded-full border-2 border-stone-700/60 bg-stone-950/40 relative flex items-center justify-center touch-none select-none"
          >
            <div className="w-12 h-12 rounded-full bg-amber-500/60 border border-amber-400 shadow-md" />
            <span className="absolute bottom-1 text-[9px] text-stone-400 uppercase tracking-widest font-mono">
              MOVE
            </span>
          </div>
        </div>

        {/* BOTTOM-RIGHT: Quick Item Pouch & Mobile Action Buttons */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          {/* Item Pouch Bar */}
          <div className="flex items-center gap-2 bg-stone-950/85 p-2 rounded border border-stone-800 text-stone-200 shadow-md">
            <button
              onClick={() => onCycleItem(-1)}
              className="w-7 h-7 bg-stone-900 hover:bg-stone-800 border border-stone-800 rounded text-xs cursor-pointer flex items-center justify-center"
            >
              ◀
            </button>
            <div className="flex items-center gap-2 min-w-[130px] justify-between">
              <span className="text-xs font-bold text-amber-400 uppercase truncate">
                {currentItemDef ? currentItemDef.name : 'EMPTY'}
              </span>
              <span className="text-xs text-stone-300 tabular-nums">
                x{currentItemSlot ? currentItemSlot.count : 0}
              </span>
            </div>
            <button
              onClick={() => onCycleItem(1)}
              className="w-7 h-7 bg-stone-900 hover:bg-stone-800 border border-stone-800 rounded text-xs cursor-pointer flex items-center justify-center"
            >
              ▶
            </button>
            <button
              onClick={onUseItem}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs uppercase rounded cursor-pointer shadow"
            >
              USE [H]
            </button>
          </div>

          {/* Mobile & Pointer Action Buttons Grid */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                onTouchAction('interact', true);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                onTouchAction('interact', false);
              }}
              onClick={onInteract}
              className="w-12 h-12 bg-stone-900 active:bg-stone-700 border border-stone-700 rounded-full text-stone-200 text-[10px] font-bold uppercase flex flex-col items-center justify-center shadow cursor-pointer active:scale-90 transition-transform"
            >
              <span>ACTION</span>
              <span className="text-[8px] text-stone-400">[E]</span>
            </button>

            <button
              onPointerDown={(e) => {
                e.preventDefault();
                onTouchAction('guard', true);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                onTouchAction('guard', false);
              }}
              className="w-12 h-12 bg-sky-950 active:bg-sky-800 border border-sky-600 rounded-full text-sky-200 text-[10px] font-bold uppercase flex flex-col items-center justify-center shadow cursor-pointer active:scale-90 transition-transform"
            >
              <span>GUARD</span>
              <span className="text-[8px] text-sky-300">[L]</span>
            </button>

            <button
              onPointerDown={(e) => {
                e.preventDefault();
                onTouchAction('roll', true);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                onTouchAction('roll', false);
              }}
              className="w-12 h-12 bg-amber-950 active:bg-amber-800 border border-amber-600 rounded-full text-amber-200 text-[10px] font-bold uppercase flex flex-col items-center justify-center shadow cursor-pointer active:scale-90 transition-transform"
            >
              <span>ROLL</span>
              <span className="text-[8px] text-amber-300">[SPACE]</span>
            </button>

            <button
              onPointerDown={(e) => {
                e.preventDefault();
                onTouchAction('special', true);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                onTouchAction('special', false);
              }}
              className="w-12 h-12 bg-purple-950 active:bg-purple-800 border border-purple-600 rounded-full text-purple-200 text-[10px] font-bold uppercase flex flex-col items-center justify-center shadow cursor-pointer active:scale-90 transition-transform"
            >
              <span>SPECIAL</span>
              <span className="text-[8px] text-purple-300">[K]</span>
            </button>

            <button
              onPointerDown={(e) => {
                e.preventDefault();
                onTouchAction('attack', true);
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                onTouchAction('attack', false);
              }}
              className="w-14 h-14 col-span-2 bg-red-700 active:bg-red-500 border border-red-500 rounded-full text-white text-xs font-black uppercase flex flex-col items-center justify-center shadow-lg cursor-pointer active:scale-95 transition-transform"
            >
              <span>ATTACK</span>
              <span className="text-[9px] text-red-200">[J / CLICK]</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
