/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Pause, Zap, Magnet, Sparkles, Shield, Footprints, ArrowLeft, ArrowRight, ArrowUp, ArrowDown } from 'lucide-react';
import { PowerUpType } from '../types/game';

interface GameHUDProps {
  score: number;
  coins: number;
  distance: number;
  multiplier: number;
  activePowerUps: { type: PowerUpType; remaining: number; duration: number }[];
  showTouchControls: boolean;
  onPause: () => void;
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onJump: () => void;
  onSlide: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  coins,
  distance,
  multiplier,
  activePowerUps,
  showTouchControls,
  onPause,
  onMoveLeft,
  onMoveRight,
  onJump,
  onSlide,
}) => {
  const getPowerUpIcon = (type: PowerUpType) => {
    switch (type) {
      case 'jetpack':
        return <Zap className="w-4 h-4 text-cyan-400" />;
      case 'magnet':
        return <Magnet className="w-4 h-4 text-red-400" />;
      case 'sneakers':
        return <Footprints className="w-4 h-4 text-amber-400" />;
      case 'multiplier':
        return <Sparkles className="w-4 h-4 text-purple-400" />;
      case 'shield':
        return <Shield className="w-4 h-4 text-sky-400" />;
    }
  };

  const getPowerUpColor = (type: PowerUpType) => {
    switch (type) {
      case 'jetpack':
        return 'from-cyan-500 to-blue-600';
      case 'magnet':
        return 'from-red-500 to-rose-600';
      case 'sneakers':
        return 'from-amber-400 to-yellow-500';
      case 'multiplier':
        return 'from-purple-500 to-pink-500';
      case 'shield':
        return 'from-sky-400 to-indigo-500';
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-4 sm:p-6 overflow-hidden">
      {/* Top Bar: Coins, Multiplier, Score, Pause */}
      <div className="flex items-start justify-between w-full">
        {/* Left: Coins & Distance */}
        <div className="flex flex-col gap-2">
          {/* Coins badge */}
          <div className="flex items-center gap-2 bg-slate-900/85 border border-amber-500/40 px-3.5 py-1.5 rounded-full shadow-lg">
            <div className="w-6 h-6 rounded-full bg-amber-400 border-2 border-yellow-200 flex items-center justify-center font-black text-amber-950 text-xs shadow-inner">
              $
            </div>
            <span className="font-extrabold text-amber-300 text-lg sm:text-xl tracking-wider tabular-nums text-shadow-arcade">
              {coins}
            </span>
          </div>

          {/* Distance */}
          <div className="flex items-center gap-1.5 bg-slate-900/80 border border-slate-700/60 px-3 py-1 rounded-full text-xs font-semibold text-slate-300">
            <span className="text-slate-400 uppercase tracking-wider text-[10px]">Track</span>
            <span className="font-mono text-cyan-400 tabular-nums">{distance}m</span>
          </div>
        </div>

        {/* Center: Score & Multiplier */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2 bg-slate-900/90 border border-indigo-500/40 px-5 py-2 rounded-2xl shadow-xl">
            <div className="flex flex-col items-end">
              <span className="text-[10px] tracking-widest uppercase font-bold text-slate-400">SCORE</span>
              <span className="font-black text-2xl sm:text-3xl text-white tracking-wider tabular-nums font-mono">
                {score.toLocaleString()}
              </span>
            </div>
            {multiplier > 1 && (
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-black text-xs px-2.5 py-1 rounded-lg shadow-md border border-purple-300/40 animate-bounce">
                x{multiplier}
              </div>
            )}
          </div>
        </div>

        {/* Right: Pause Button */}
        <div>
          <button
            onClick={onPause}
            className="pointer-events-auto w-11 h-11 bg-slate-900/85 hover:bg-slate-800 active:scale-95 border border-slate-700 rounded-xl flex items-center justify-center text-white shadow-lg transition-transform cursor-pointer"
            title="Pause Game (Esc)"
          >
            <Pause className="w-5 h-5 fill-current" />
          </button>
        </div>
      </div>

      {/* Middle-Left: Active Power-Up Timers */}
      <div className="flex flex-col gap-2.5 max-w-[190px] my-auto">
        {activePowerUps.map((pu) => {
          const percent = pu.type === 'shield' ? 100 : Math.max(0, Math.min(100, (pu.remaining / pu.duration) * 100));
          return (
            <div
              key={pu.type}
              className="bg-slate-900/90 border border-slate-700/70 p-2 rounded-xl shadow-lg flex items-center gap-2.5"
            >
              <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center">
                {getPowerUpIcon(pu.type)}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center text-[10px] uppercase font-bold text-slate-300 mb-1">
                  <span>{pu.type}</span>
                  {pu.type !== 'shield' && (
                    <span className="font-mono text-cyan-400">{Math.ceil(pu.remaining)}s</span>
                  )}
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${getPowerUpColor(pu.type)} transition-all duration-100 rounded-full`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Area: Controls Bar (Touch Buttons on Mobile) */}
      {showTouchControls && (
        <div className="w-full flex items-center justify-between pb-2 pointer-events-auto max-w-lg mx-auto">
          {/* Left / Right lateral movement */}
          <div className="flex gap-3">
            <button
              onClick={onMoveLeft}
              className="w-16 h-16 bg-slate-900/90 active:bg-cyan-600 border border-cyan-500/40 rounded-2xl flex items-center justify-center text-cyan-300 shadow-xl active:scale-90 transition-transform cursor-pointer"
            >
              <ArrowLeft className="w-8 h-8" />
            </button>
            <button
              onClick={onMoveRight}
              className="w-16 h-16 bg-slate-900/90 active:bg-cyan-600 border border-cyan-500/40 rounded-2xl flex items-center justify-center text-cyan-300 shadow-xl active:scale-90 transition-transform cursor-pointer"
            >
              <ArrowRight className="w-8 h-8" />
            </button>
          </div>

          {/* Jump / Slide vertical actions */}
          <div className="flex gap-3">
            <button
              onClick={onSlide}
              className="w-16 h-16 bg-slate-900/90 active:bg-amber-600 border border-amber-500/40 rounded-2xl flex items-center justify-center text-amber-300 shadow-xl active:scale-90 transition-transform cursor-pointer"
            >
              <ArrowDown className="w-8 h-8" />
            </button>
            <button
              onClick={onJump}
              className="w-16 h-16 bg-gradient-to-t from-emerald-600 to-teal-500 active:from-emerald-700 active:to-teal-600 border border-emerald-400/40 rounded-2xl flex items-center justify-center text-white shadow-xl active:scale-90 transition-transform cursor-pointer"
            >
              <ArrowUp className="w-8 h-8 font-black" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
