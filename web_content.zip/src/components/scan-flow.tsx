import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Camera, ImagePlus, RotateCcw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScoreRing } from "@/components/score-ring";
import { fileToDataUrl, makeThumbnail, videoToDataUrl } from "@/lib/image";
import { scorePsl } from "@/lib/score-psl";
import { confidenceLabel, formatPsl, type HistoryItem, type PslResult } from "@/lib/psl";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const SCAN_STEPS = [
  "Đọc 468 điểm landmark",
  "Harmony — tỷ lệ & đối xứng",
  "Dimorphism — nét nam/nữ",
  "Angularity — góc hàm & gò má",
  "Miscellaneous — mắt, da, tóc",
  "Xếp rank trên thang PSL",
];

export function ScanFlow() {
  const screen = useAppStore((s) => s.screen);
  if (screen === "result") return <ResultStage />;
  if (screen === "analyzing") return <AnalyzingStage />;
  return <CaptureStage />;
}

function CaptureStage() {
  const fileRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const error = useAppStore((s) => s.error);
  const setError = useAppStore((s) => s.setError);
  const go = useAppStore((s) => s.go);
  const scoreFn = useServerFn(scorePsl);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  function stopCamera() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOn(false);
  }

  async function startCamera() {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1080 }, height: { ideal: 1440 } },
        audio: false,
      });
      streamRef.current = stream;
      setCameraOn(true);
      requestAnimationFrame(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play();
        }
      });
    } catch {
      setError("Không mở được camera. Hãy tải ảnh lên từ thư viện.");
      fileRef.current?.click();
    }
  }

  async function capture() {
    if (!videoRef.current) return;
    setBusy(true);
    try {
      const dataUrl = await videoToDataUrl(videoRef.current);
      stopCamera();
      await runScore(dataUrl, scoreFn);
    } catch {
      setError("Không chụp được ảnh. Thử tải ảnh lên.");
      setBusy(false);
    }
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const dataUrl = await fileToDataUrl(file);
      await runScore(dataUrl, scoreFn);
    } catch {
      setError("Không đọc được ảnh. Dùng JPEG hoặc PNG, mặt nhìn rõ.");
      useAppStore.getState().go("scan");
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center justify-between px-5 pt-4 pb-2">
        <button
          type="button"
          className="tap text-sm text-muted"
          onClick={() => {
            stopCamera();
            go("home");
          }}
        >
          Đóng
        </button>
        <p className="font-display text-sm font-semibold tracking-wide">Quét mặt</p>
        <span className="w-10" />
      </header>

      <div className="relative mx-5 overflow-hidden rounded-2xl bg-surface aspect-portrait">
        {cameraOn ? (
          <>
            <video
              ref={videoRef}
              className="absolute inset-0 size-full object-cover mirror-x"
              playsInline
              muted
              autoPlay
            />
            <div className="pointer-events-none absolute inset-0 grid place-items-center">
              <div className="scan-oval scan-guide border border-accent/50" />
            </div>
          </>
        ) : (
          <div className="absolute inset-0 grid place-items-center px-8 text-center">
            <div>
              <div className="mx-auto mb-4 grid size-14 place-items-center rounded-xl bg-surface-2 text-accent">
                <Camera className="size-6" strokeWidth={1.6} />
              </div>
              <p className="font-display text-lg font-semibold">Chính diện, đủ sáng</p>
              <p className="mt-2 text-sm text-muted">
                Ngang tầm mắt, không kính, không filter. Ảnh gửi sang công cụ PSL để chấm rank.
              </p>
            </div>
          </div>
        )}
      </div>

      {error ? (
        <p className="mx-5 mt-3 rounded-lg border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-fg">
          {error}
        </p>
      ) : (
        <ul className="mx-5 mt-3 grid grid-cols-3 gap-2 text-center text-2xs uppercase tracking-wider text-subtle">
          <li className="rounded-md bg-surface px-2 py-2">Chính diện</li>
          <li className="rounded-md bg-surface px-2 py-2">Ánh sáng đều</li>
          <li className="rounded-md bg-surface px-2 py-2">Không filter</li>
        </ul>
      )}

      <div className="mt-auto flex flex-col gap-3 px-5 pb-4 pt-5">
        {cameraOn ? (
          <div className="flex gap-3">
            <Button variant="ghost" className="flex-1" onClick={stopCamera} disabled={busy}>
              <X className="size-4" />
              Hủy camera
            </Button>
            <Button className="flex-1" onClick={() => void capture()} disabled={busy}>
              <Camera className="size-4" />
              Chụp
            </Button>
          </div>
        ) : (
          <>
            <Button size="xl" onClick={() => void startCamera()} disabled={busy}>
              <Camera className="size-5" />
              Mở camera
            </Button>
            <Button
              variant="ghost"
              size="lg"
              onClick={() => fileRef.current?.click()}
              disabled={busy}
            >
              <ImagePlus className="size-4" />
              Tải ảnh lên
            </Button>
          </>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => void onFile(e.target.files?.[0])}
        />
      </div>
    </div>
  );
}

async function runScore(
  photo: string,
  scoreFn: (input: { data: { imageBase64: string } }) => Promise<
    Awaited<ReturnType<typeof scorePsl>>
  >,
) {
  const store = useAppStore.getState();
  store.setPhoto(photo);
  store.setError(null);
  store.go("analyzing");
  store.setAnalyzingLabel(SCAN_STEPS[0]);

  let step = 0;
  const tick = window.setInterval(() => {
    step = Math.min(step + 1, SCAN_STEPS.length - 1);
    useAppStore.getState().setAnalyzingLabel(SCAN_STEPS[step]);
  }, 700);

  try {
    const res = await scoreFn({ data: { imageBase64: photo } });
    window.clearInterval(tick);
    if (!res.ok) {
      store.setError(res.message);
      store.go("scan");
      return;
    }
    const result: PslResult = { ...res, photo };
    const thumbnail = await makeThumbnail(photo);
    const item: HistoryItem = {
      id: `${Date.now()}`,
      createdAt: Date.now(),
      thumbnail,
      tier: result.tier,
      rank: result.rank,
      psl: result.psl,
      mogScore: result.mogScore,
      confidence: result.confidence,
      markers: result.markers,
    };
    store.setResult(result, item);
  } catch {
    window.clearInterval(tick);
    store.setError("Không chấm được điểm. Thử lại.");
    store.go("scan");
  }
}

function AnalyzingStage() {
  const photo = useAppStore((s) => s.photo);
  const label = useAppStore((s) => s.analyzingLabel);
  const [pct, setPct] = useState(8);

  useEffect(() => {
    const id = window.setInterval(() => {
      setPct((p) => (p >= 94 ? p : Math.min(94, p + (p < 30 ? 2.4 : p > 70 ? 0.6 : 1.2))));
    }, 90);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col px-5 pt-4 pb-6">
      <p className="mb-3 text-center font-display text-sm font-semibold tracking-wide">
        Đang chấm PSL
      </p>
      <div className="relative overflow-hidden rounded-2xl bg-surface aspect-portrait">
        {photo ? (
          <img src={photo} alt="Đang phân tích" className="absolute inset-0 size-full object-cover" />
        ) : (
          <div className="absolute inset-0 bg-surface-2" />
        )}
        <div className="absolute inset-0 bg-bg/35" />
        <div className="scan-sweep pointer-events-none absolute inset-x-0 h-1/5 bg-gradient-to-b from-transparent via-accent/35 to-transparent" />
        <div className="pointer-events-none absolute inset-6 border border-accent/25 rounded-xl" />
      </div>
      <div className="mt-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-fg">{label}</span>
          <span className="tabular-nums text-muted">{Math.round(pct)}%</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="bar-fill h-full rounded-full bg-accent"
            style={{ width: `${pct}%` }}
          />
        </div>
        <p className="mt-3 text-xs text-subtle">
          Điểm và rank lấy từ công cụ PSL Score trên moggedupapp.com — không lưu ảnh phía LUME.
        </p>
      </div>
    </div>
  );
}

function ResultStage() {
  const result = useAppStore((s) => s.result);
  const go = useAppStore((s) => s.go);
  const clearResult = useAppStore((s) => s.clearResult);
  if (!result) return null;

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-5 pb-6 pt-4">
      <header className="mb-4 flex items-center justify-between">
        <p className="font-display text-sm font-semibold tracking-wide">Kết quả PSL</p>
        <button
          type="button"
          className="tap text-sm text-muted"
          onClick={() => {
            clearResult();
            go("home");
          }}
        >
          Xong
        </button>
      </header>

      <div className="relative overflow-hidden rounded-2xl bg-surface p-5">
        <div className="flex items-center gap-4">
          <div className="size-20 shrink-0 overflow-hidden rounded-xl bg-surface-2">
            <img src={result.photo} alt="Ảnh đã chấm" className="size-full object-cover" />
          </div>
          <div className="min-w-0">
            <p className="text-2xs uppercase tracking-label text-subtle">Rank</p>
            <h2 className="font-display text-2xl font-bold leading-tight">{result.rank}</h2>
            <p className="mt-1 text-sm text-muted">
              PSL {formatPsl(result.psl)} · {result.rarity}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-5 grid place-items-center">
        <ScoreRing value={result.psl} size="lg" />
      </div>

      <dl className="mt-6 grid grid-cols-3 gap-2">
        <Stat label="PSL" value={formatPsl(result.psl)} />
        <Stat label="Khoảng" value={`${formatPsl(result.pslMin)}–${formatPsl(result.pslMax)}`} />
        <Stat label="Tin cậy" value={confidenceLabel(result.confidence)} />
      </dl>

      <section className="mt-6">
        <h3 className="text-2xs uppercase tracking-label text-subtle">Marker từ web</h3>
        {result.markers.length === 0 ? (
          <p className="mt-2 text-sm text-muted">Không có marker chi tiết cho lần quét này.</p>
        ) : (
          <ul className="mt-3 flex flex-wrap gap-2">
            {result.markers.map((m) => (
              <li
                key={m}
                className="rounded-full border border-border bg-surface px-3 py-1.5 text-sm text-fg"
              >
                {m}
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="mt-6 text-xs leading-relaxed text-subtle">
        Rank và điểm PSL được lấy từ kết quả công cụ PSL Score (moggedupapp.com/tools/psl-score).
        Đây là ước lượng thẩm mỹ cộng đồng, không phải đánh giá y khoa.
      </p>

      <div className="mt-6 flex flex-col gap-3">
        <Button
          size="lg"
          onClick={() => {
            clearResult();
            go("scan");
          }}
        >
          <RotateCcw className="size-4" />
          Quét lại
        </Button>
        <Button variant="ghost" size="lg" onClick={() => go("history")}>
          Xem lịch sử
        </Button>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3">
      <dt className="text-2xs uppercase tracking-label text-subtle">{label}</dt>
      <dd className={cn("mt-1 font-display text-base font-semibold tabular-nums")}>{value}</dd>
    </div>
  );
}
