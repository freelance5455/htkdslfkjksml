interface TeacherAvatarProps {
  className?: string;
  size?: number;
}

export const TeacherAvatar = ({ className = 'w-10 h-10', size }: TeacherAvatarProps) => {
  return (
    <svg
      viewBox="0 0 120 120"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Glow effect */}
        <filter id="teacherGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        {/* Gradients */}
        <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#f43f5e" />
          <stop offset="50%" stop-color="#be123c" />
          <stop offset="100%" stop-color="#881337" />
        </linearGradient>
        <linearGradient id="hairGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#5a2e1d" />
          <stop offset="100%" stop-color="#361a0f" />
        </linearGradient>
        <linearGradient id="glassesGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#fbbf24" />
          <stop offset="100%" stop-color="#f59e0b" />
        </linearGradient>
      </defs>

      {/* Circle Background with delicate gold border */}
      <circle cx="60" cy="60" r="56" fill="url(#bgGrad)" />
      <circle cx="60" cy="60" r="54" stroke="#fbbf24" stroke-width="2.5" stroke-dasharray="4 2" opacity="0.6" />

      {/* Little sparkle background stars */}
      <path d="M22 26 Q24 26 24 24 Q24 26 26 26 Q24 26 24 28 Q24 26 22 26 Z" fill="#fde047" />
      <path d="M96 28 Q98 28 98 26 Q98 28 100 28 Q98 28 98 30 Q98 28 96 28 Z" fill="#fde047" />

      {/* Hair Behind / Back Bun */}
      <circle cx="60" cy="28" r="16" fill="url(#hairGrad)" />
      <circle cx="60" cy="27" r="13" fill="#6d3923" />
      {/* Hair Bun Pin / Pencil */}
      <line x1="48" y1="34" x2="72" y2="20" stroke="#f43f5e" stroke-width="3" stroke-linecap="round" />
      <circle cx="48" cy="34" r="2.5" fill="#fbbf24" />

      {/* Teacher Body / Cardigan */}
      <path d="M30 114 C30 88 42 84 60 84 C78 84 90 88 90 114 Z" fill="#1e1b4b" />
      {/* Inner White Blouse Collar */}
      <path d="M50 84 L60 98 L70 84 Z" fill="#ffffff" />
      <path d="M58 84 L60 93 L62 84 Z" fill="#f43f5e" />
      {/* Cardigan Collar Fold */}
      <path d="M42 85 L56 102 L48 114" stroke="#e11d48" stroke-width="2.5" stroke-linecap="round" />
      <path d="M78 85 L64 102 L72 114" stroke="#e11d48" stroke-width="2.5" stroke-linecap="round" />

      {/* Neck */}
      <rect x="54" y="74" width="12" height="13" rx="4" fill="#fcd3b8" />
      <path d="M54 81 Q60 84 66 81" fill="#fbc7a4" />

      {/* Face */}
      <path d="M38 48 C38 34 82 34 82 48 C82 68 76 78 60 78 C44 78 38 68 38 48 Z" fill="#fedec9" />

      {/* Rosy Blushing Cheeks */}
      <circle cx="46" cy="62" r="5" fill="#f43f5e" opacity="0.35" />
      <circle cx="74" cy="62" r="5" fill="#f43f5e" opacity="0.35" />

      {/* Front Hair Bangs */}
      <path d="M37 46 C42 34 54 36 60 41 C66 36 78 34 83 46 C79 43 72 40 60 44 C48 40 41 43 37 46 Z" fill="url(#hairGrad)" />
      {/* Side hair strands framing face */}
      <path d="M37 44 C36 56 38 66 41 72 C39 63 38 52 39 44 Z" fill="url(#hairGrad)" />
      <path d="M83 44 C84 56 82 66 79 72 C81 63 82 52 81 44 Z" fill="url(#hairGrad)" />

      {/* Cute Eyebrows */}
      <path d="M46 47 Q51 45 54 48" stroke="#4a2517" stroke-width="1.8" stroke-linecap="round" fill="none" />
      <path d="M66 48 Q69 45 74 47" stroke="#4a2517" stroke-width="1.8" stroke-linecap="round" fill="none" />

      {/* Teacher Glasses (Golden Frames) */}
      {/* Left Frame */}
      <rect x="43" y="49" width="13" height="11" rx="4" fill="#ffffff" fill-opacity="0.2" stroke="url(#glassesGrad)" stroke-width="2.2" />
      {/* Right Frame */}
      <rect x="64" y="49" width="13" height="11" rx="4" fill="#ffffff" fill-opacity="0.2" stroke="url(#glassesGrad)" stroke-width="2.2" />
      {/* Bridge */}
      <path d="M56 53 Q60 51 64 53" stroke="url(#glassesGrad)" stroke-width="2.2" fill="none" />
      {/* Temples */}
      <line x1="43" y1="53" x2="38" y2="50" stroke="url(#glassesGrad)" stroke-width="1.8" stroke-linecap="round" />
      <line x1="77" y1="53" x2="82" y2="50" stroke="url(#glassesGrad)" stroke-width="1.8" stroke-linecap="round" />

      {/* Happy Big Eyes */}
      <circle cx="50" cy="54" r="3.2" fill="#291811" />
      <circle cx="70" cy="54" r="3.2" fill="#291811" />
      {/* Eye catchlights (sparkles) */}
      <circle cx="49" cy="53" r="1.1" fill="#ffffff" />
      <circle cx="69" cy="53" r="1.1" fill="#ffffff" />
      <circle cx="51.2" cy="55.2" r="0.6" fill="#ffffff" />
      <circle cx="71.2" cy="55.2" r="0.6" fill="#ffffff" />

      {/* Cute Nose */}
      <circle cx="60" cy="59" r="1.2" fill="#d97757" />

      {/* Cheerful Teacher Smile */}
      <path d="M55 64 Q60 69 65 64" stroke="#c02643" stroke-width="2" stroke-linecap="round" fill="#ffe4e6" />

      {/* Small notebook / book peek at bottom corner */}
      <g transform="translate(74, 88) rotate(-15)">
        <rect x="0" y="0" width="18" height="24" rx="2" fill="#3b82f6" stroke="#1d4ed8" stroke-width="1.5" />
        <rect x="0" y="0" width="4" height="24" rx="1" fill="#1e40af" />
        <line x1="7" y1="6" x2="15" y2="6" stroke="#ffffff" stroke-width="1" />
        <line x1="7" y1="10" x2="15" y2="10" stroke="#ffffff" stroke-width="1" />
        <line x1="7" y1="14" x2="13" y2="14" stroke="#ffffff" stroke-width="1" />
      </g>
    </svg>
  );
};
