import React, { useState } from 'react';
import { Volume2, MessageCircle, Sparkles, Award, Video } from 'lucide-react';
import { sound } from '../utils/sound';

interface TeacherAvatarProps {
  childName: string;
  onOpenChat: () => void;
  onOpenQuiz: () => void;
  onOpenVideo: () => void;
  onOpenCertificate: () => void;
  starsCount: number;
}

export const TeacherAvatar: React.FC<TeacherAvatarProps> = ({
  childName,
  onOpenChat,
  onOpenQuiz,
  onOpenVideo,
  onOpenCertificate,
  starsCount,
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const teacherImage = '/src/assets/images/teacher_character_1790357459776.jpg';

  const defaultGreeting = `السلام علیکم ${childName} بیٹا! میں آپ کا دوست اور استاد میاں بھالو ہوں۔ آئیں مل کر الف بے تے، اے بی سی اور گنتی پڑھیں! 🌟`;

  const handleSpeakGreeting = async () => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    sound.playPopSound();
    await sound.speakWithGeminiOrLocal(
      `السلام علیکم ${childName} بیٹا! میں آپ کا استاد میاں بھالو ہوں۔ آپ میرے بہت پیارے اور ذہین شاگرد ہیں! کیا آپ آج مزے سے پڑھنے کے لیے تیار ہیں؟`,
      'ur'
    );
    setIsSpeaking(false);
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 p-4 sm:p-6 shadow-xl text-white border-4 border-amber-300">
      {/* Background playful floating shapes */}
      <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-yellow-300/20 rounded-full blur-xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-center gap-5 sm:gap-6">
        {/* Animated Avatar Mascot */}
        <div className="relative group shrink-0">
          <div
            className={`relative w-28 h-28 sm:w-36 sm:h-36 rounded-full p-1.5 bg-gradient-to-tr from-yellow-200 via-white to-amber-200 shadow-2xl transition-transform duration-300 ${
              isSpeaking ? 'scale-105 ring-8 ring-white/60 animate-pulse' : 'hover:scale-105'
            }`}
          >
            <img
              src={teacherImage}
              alt="استاد میاں بھالو"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-full shadow-inner"
            />

            {/* Speaking wave badge */}
            {isSpeaking && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white p-2 rounded-full shadow-lg animate-bounce">
                <Volume2 className="w-5 h-5" />
              </span>
            )}

            {/* Teacher Tag */}
            <span className="absolute -bottom-2 inset-x-0 mx-auto w-max px-3 py-0.5 bg-amber-900 text-amber-100 text-xs sm:text-sm font-bold rounded-full shadow-md border border-amber-400">
              استاد میاں بھالو 🧸
            </span>
          </div>
        </div>

        {/* Speech Bubble & Greeting */}
        <div className="flex-1 text-center md:text-right space-y-3">
          <div className="inline-flex items-center gap-2 bg-amber-900/30 backdrop-blur-sm px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold text-amber-100">
            <Sparkles className="w-4 h-4 text-yellow-300 animate-spin" />
            <span>خصوصی کلاس برائے پیارے {childName} 🎓</span>
          </div>

          <div className="bg-white/95 text-slate-800 p-4 sm:p-5 rounded-2xl shadow-lg relative border-2 border-amber-200">
            {/* Triangular pointer */}
            <div className="hidden md:block absolute -right-3 top-6 w-0 h-0 border-y-8 border-y-transparent border-l-8 border-l-white" />

            <p className="font-urdu text-base sm:text-lg text-slate-800 leading-relaxed font-semibold">
              {defaultGreeting}
            </p>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-amber-100">
              <button
                onClick={handleSpeakGreeting}
                disabled={isSpeaking}
                className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white rounded-full font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50"
              >
                <Volume2 className={`w-4 h-4 ${isSpeaking ? 'animate-bounce' : ''}`} />
                <span>{isSpeaking ? 'بول رہے ہیں...' : 'سنیں (Listen)'}</span>
              </button>

              <div className="flex items-center gap-1.5 text-xs text-amber-700 font-bold bg-amber-50 px-3 py-1 rounded-full">
                <span>⭐ کل ستارے:</span>
                <span className="text-base text-amber-600 font-extrabold">{starsCount}</span>
              </div>
            </div>
          </div>

          {/* Quick interactive action buttons for Arhan */}
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1">
            <button
              onClick={onOpenChat}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white text-amber-900 hover:bg-amber-50 active:scale-95 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer border border-amber-200"
            >
              <MessageCircle className="w-4 h-4 text-amber-600" />
              <span>مجھ سے بات کرو ({childName}'s AI Chat)</span>
            </button>

            <button
              onClick={onOpenQuiz}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white active:scale-95 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>مزے دار کوئز کھیلیں 🎯</span>
            </button>

            <button
              onClick={onOpenVideo}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white active:scale-95 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
            >
              <Video className="w-4 h-4 text-pink-300" />
              <span>جادوئی ویڈیو (Veo Video) 🎬</span>
            </button>

            {starsCount >= 5 && (
              <button
                onClick={onOpenCertificate}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-yellow-400 hover:bg-yellow-500 text-yellow-950 active:scale-95 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer animate-bounce"
              >
                <Award className="w-4 h-4 text-yellow-800" />
                <span>شہزادہ {childName} کی سند 🏆</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
