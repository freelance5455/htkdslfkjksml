import React from 'react';
import { X, Table, FileSpreadsheet, Download, ExternalLink } from 'lucide-react';
import { Attachment } from '../types/chat';

interface FileViewerModalProps {
  attachment: Attachment | null;
  onClose: () => void;
}

export const FileViewerModal: React.FC<FileViewerModalProps> = ({ attachment, onClose }) => {
  if (!attachment) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl max-h-[85vh] bg-neutral-900 border border-neutral-800 rounded-2xl flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              {attachment.type === 'excel' || attachment.type === 'csv' ? (
                <FileSpreadsheet className="w-5 h-5" />
              ) : (
                <Table className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-semibold text-neutral-100 text-sm md:text-base">
                {attachment.name}
              </h3>
              <p className="text-xs text-neutral-400">
                {attachment.sheetData ? (
                  <span>
                    {attachment.sheetData.totalRows} صف · {attachment.sheetData.totalColumns} عمود · {attachment.sheetData.sheetNames.join(', ')}
                  </span>
                ) : (
                  <span>{attachment.type} · {(attachment.size / 1024).toFixed(1)} KB</span>
                )}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {attachment.type === 'image' && attachment.dataUrl && (
            <div className="flex items-center justify-center">
              <img
                src={attachment.dataUrl}
                alt={attachment.name}
                className="max-h-[70vh] object-contain rounded-lg"
              />
            </div>
          )}

          {(attachment.type === 'excel' || attachment.type === 'csv') && attachment.sheetData && (
            <div className="space-y-4">
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-sm text-neutral-300">
                <span className="font-medium text-emerald-400">ملخص المستند: </span>
                {attachment.sheetData.summary.split('\n\n')[0]}
              </div>

              {attachment.sheetData.sampleRows.length > 0 && (
                <div className="overflow-x-auto border border-neutral-800 rounded-xl">
                  <table className="w-full text-sm text-right">
                    <thead className="bg-neutral-950 text-neutral-400 border-b border-neutral-800">
                      <tr>
                        {Object.keys(attachment.sheetData.sampleRows[0]).map((key, i) => (
                          <th key={i} className="px-4 py-3 font-medium text-xs text-neutral-300 uppercase tracking-wider">
                            {key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800">
                      {attachment.sheetData.sampleRows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-neutral-800/40 transition-colors">
                          {Object.values(row).map((val: any, cellIdx) => (
                            <td key={cellIdx} className="px-4 py-2.5 text-neutral-300 whitespace-nowrap text-xs">
                              {String(val ?? '-')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
