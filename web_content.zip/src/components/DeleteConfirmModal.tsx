import React from 'react';
import { Trash2 } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title?: string;
  isPermanent?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  title,
  isPermanent = false,
  onCancel,
  onConfirm,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in select-none"
      onClick={onCancel}
    >
      <div
        className="bg-[#152033] border border-[#2b3e5e] w-full max-w-xs rounded-2xl p-5 shadow-2xl text-white space-y-4 animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-center space-y-1.5">
          <div className="w-12 h-12 rounded-full bg-red-500/15 border border-red-500/30 text-red-500 flex items-center justify-center mx-auto mb-2">
            <Trash2 className="w-6 h-6 stroke-[2.2]" />
          </div>
          <h3 className="text-base font-bold text-white tracking-wide">
            {isPermanent ? 'Permanently Delete?' : 'Delete Item?'}
          </h3>
          {title && (
            <p className="text-xs text-slate-300 truncate max-w-[220px] mx-auto font-medium">
              {title}
            </p>
          )}
          <p className="text-[11px] text-slate-400">
            {isPermanent
              ? 'This item will be deleted permanently and cannot be recovered.'
              : 'Item will be moved to Recycle Bin (stays safe in Cloud).'}
          </p>
        </div>

        {/* Exactly 2 buttons: Cancel and Delete */}
        <div className="flex items-center gap-2.5 pt-1">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-semibold text-xs rounded-xl transition cursor-pointer border border-slate-700 text-center"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-lg shadow-red-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer text-center"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>
    </div>
  );
};
