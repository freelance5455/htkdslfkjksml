import type { DiagramSpec } from "../solver/types";
import { fmt } from "../utils/format";

/**
 * Renders a deliberately schematic, NEVER-to-scale geometry diagram built
 * only from the labels/values actually present in the solved question.
 * This helps students visualise which points/angles are being discussed —
 * it is not a precise scale drawing of the original figure.
 */
export default function GeometryDiagram({ spec }: { spec: DiagramSpec }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-900/40">
      <svg viewBox="0 0 300 220" className="mx-auto h-48 w-full max-w-sm">
        {spec.kind === "triangle" ? <TriangleDiagram spec={spec} /> : <CircleDiagram spec={spec} />}
      </svg>
      <p className="mt-1 text-center text-[11px] text-slate-400 dark:text-slate-500">
        Schematic diagram (not drawn to scale){spec.note ? ` — ${spec.note}` : ""}
      </p>
    </div>
  );
}

function TriangleDiagram({ spec }: { spec: DiagramSpec }) {
  const verts = spec.vertices ?? ["A", "B", "C"];
  const [P1, P2, P3] = [
    { x: 60, y: 170 },
    { x: 220, y: 170 },
    { x: 130, y: 40 },
  ];
  const coords: Record<string, { x: number; y: number }> = {
    [verts[0]]: P1,
    [verts[1]]: P2,
    [verts[2]]: P3,
  };

  const angleValue = (vertex: string) => spec.angleLabels?.find((a) => a.at === vertex)?.value;

  // Extension point, if any (exterior angle questions): extend the side
  // from `producedFrom` through `producedThrough` to `producedTo`.
  let extensionPoint: { x: number; y: number } | null = null;
  if (spec.producedFrom && spec.producedThrough && coords[spec.producedFrom] && coords[spec.producedThrough]) {
    const from = coords[spec.producedFrom];
    const through = coords[spec.producedThrough];
    const dx = through.x - from.x;
    const dy = through.y - from.y;
    extensionPoint = { x: through.x + dx * 0.6, y: through.y + dy * 0.6 };
  }

  return (
    <g fontFamily="ui-sans-serif, system-ui" fontSize={12} stroke="#6366f1" strokeWidth={2} fill="none">
      <polygon points={`${P1.x},${P1.y} ${P2.x},${P2.y} ${P3.x},${P3.y}`} fill="rgba(99,102,241,0.12)" />
      {extensionPoint && spec.producedThrough && (
        <line x1={coords[spec.producedThrough].x} y1={coords[spec.producedThrough].y} x2={extensionPoint.x} y2={extensionPoint.y} strokeDasharray="4 3" />
      )}
      {Object.entries(coords).map(([label, pt]) => (
        <g key={label}>
          <circle cx={pt.x} cy={pt.y} r={3} fill="#4338ca" stroke="none" />
          <text
            x={pt.x + (pt.y > 100 ? (pt.x < 140 ? -14 : 8) : 0)}
            y={pt.y > 100 ? pt.y + 14 : pt.y - 10}
            fill="#312e81"
            stroke="none"
            fontWeight={600}
          >
            {label}
          </text>
          {angleValue(label) !== undefined && (
            <text x={pt.x + (pt.y > 100 ? (pt.x < 140 ? -30 : 4) : 6)} y={pt.y > 100 ? pt.y + 28 : pt.y + 16} fill="#9333ea" stroke="none" fontSize={11}>
              {fmt(angleValue(label)!)}°
            </text>
          )}
        </g>
      ))}
      {extensionPoint && spec.producedTo && (
        <g>
          <circle cx={extensionPoint.x} cy={extensionPoint.y} r={3} fill="#4338ca" stroke="none" />
          <text x={extensionPoint.x + 6} y={extensionPoint.y + 4} fill="#312e81" stroke="none" fontWeight={600}>
            {spec.producedTo}
          </text>
        </g>
      )}
    </g>
  );
}

function CircleDiagram({ spec }: { spec: DiagramSpec }) {
  const cx = 150,
    cy = 110,
    r = 70;
  const centreLabel = spec.centre ?? "O";
  const onCircle = spec.pointsOnCircle ?? [];
  const tangentPts = spec.tangentPoints ?? [];
  const allLabeled = [...onCircle, ...tangentPts];
  const n = Math.max(allLabeled.length, 1);

  const pointCoords = allLabeled.map((label, i) => {
    const angle = -Math.PI / 2 + (i * 2 * Math.PI) / n + Math.PI / n;
    return { label, x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
  });

  const external = spec.externalPoint
    ? { x: cx + (r + 70) * Math.cos(Math.PI / 4), y: cy + (r + 70) * Math.sin(Math.PI / 4) }
    : null;

  return (
    <g fontFamily="ui-sans-serif, system-ui" fontSize={12} stroke="#6366f1" strokeWidth={2} fill="none">
      <circle cx={cx} cy={cy} r={r} fill="rgba(99,102,241,0.08)" />
      <circle cx={cx} cy={cy} r={2.5} fill="#4338ca" stroke="none" />
      <text x={cx + 6} y={cy - 4} fill="#312e81" stroke="none" fontWeight={600}>
        {centreLabel}
      </text>

      {pointCoords.map((p) => (
        <g key={p.label}>
          <circle cx={p.x} cy={p.y} r={3} fill="#4338ca" stroke="none" />
          <text x={p.x + (p.x > cx ? 8 : -16)} y={p.y + (p.y > cy ? 14 : -6)} fill="#312e81" stroke="none" fontWeight={600}>
            {p.label}
          </text>
          {tangentPts.includes(p.label) && external && <line x1={p.x} y1={p.y} x2={external.x} y2={external.y} />}
          {tangentPts.includes(p.label) && <line x1={cx} y1={cy} x2={p.x} y2={p.y} strokeDasharray="3 3" />}
        </g>
      ))}

      {external && (
        <g>
          <circle cx={external.x} cy={external.y} r={3} fill="#9333ea" stroke="none" />
          <text x={external.x + 6} y={external.y + 4} fill="#6b21a8" stroke="none" fontWeight={600}>
            {spec.externalPoint}
          </text>
        </g>
      )}
    </g>
  );
}
