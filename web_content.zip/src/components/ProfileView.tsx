import React, { useState } from "react";
import {
  User,
  Mail,
  Cloud,
  Share2,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  RefreshCw,
  Edit3,
  Trash2,
  FileText,
  Search,
  Filter,
  Check,
  ExternalLink,
  Send,
  Sparkles,
  Download,
  LogIn,
  LogOut,
  Zap,
  Shield,
  HelpCircle,
  Laptop,
  CheckSquare,
  Flame,
  KeyRound,
  Lock,
  Unlock,
  Key,
  Eye,
  EyeOff,
  AlertTriangle,
  Copy,
  RotateCw,
  ChevronRight,
  ChevronDown,
  Sliders,
  CheckCircle,
  Hash,
  Palette,
  Layout,
  Terminal,
  Cpu,
  Layers,
  Building2,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  StickyNote,
  Network,
  BookOpen,
  Plus,
  Mic,
  Moon,
  Sun,
  LayoutGrid,
  Feather,
  PenTool,
  Database,
  Wifi,
  WifiOff,
  SlidersHorizontal,
  Wrench,
  Compass,
} from "lucide-react";
import { UserProfile, SyncedNoteRecord, Note, VaultMetadata, ActiveTab, ThemeAccent, UIThemeStyle, SectionItem, Flashcard, TrashItem } from "../types";
import { UI_THEME_STYLE_CONFIGS, THEME_ACCENTS } from "../utils/theme";
import { DEFAULT_MENU_ORDER, getStoredSections, saveStoredSections } from "../utils/storage";
import { OfflineSyncBadge } from "./OfflineSyncBadge";
import { RadialMenuSettings } from "./RadialMenuSettings";
import { MenuSectionsManager } from "./MenuSectionsManager";
import { CanvasThemeSelector } from "./CanvasThemeSelector";
import { StylusSettingsHub } from "./StylusSettingsHub";
import { DisplaySettingsView } from "./DisplaySettingsView";
import { TroubleshootingCenter } from "./TroubleshootingCenter";
import { NavigationSettingsView } from "./NavigationSettingsView";
import { DocumentCenterView } from "./DocumentCenterView";
import { StudyView } from "./StudyView";
import { SettingsView } from "./SettingsView";
import { ProfileInterfaceSettings } from "./ProfileInterfaceSettings";
import { MindMapSettingsPanel } from "./MindMapSettingsPanel";
import {
  initializeVault,
  unlockVault,
  changeVaultPin,
  resetVaultPinWithRawKey,
  rawKeyToMnemonic,
  bytesToHex,
  MNEMONIC_WORDS,
} from "../utils/crypto";
import { AuthModal } from "./AuthModal";
import { clearActiveSession } from "../utils/authService";

interface ProfileViewProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  syncLogs: SyncedNoteRecord[];
  onAddSyncLog: (log: Omit<SyncedNoteRecord, "id">) => void;
  onClearSyncLogs: () => void;
  notes: Note[];
  onOpenNote: (note: Note) => void;
  vaultRecord?: VaultMetadata | null;
  setVaultRecord?: (record: VaultMetadata | null) => void;
  vaultNotes?: Note[];
  isVaultUnlocked?: boolean;
  onOpenVault?: () => void;
  rawVaultKey?: Uint8Array | null;
  onNavigateToVaultTab?: () => void;
  themeAccent?: ThemeAccent;
  onChangeThemeAccent?: (accent: ThemeAccent) => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
  uiThemeStyle?: UIThemeStyle;
  onChangeUiThemeStyle?: (style: UIThemeStyle) => void;
  menuOrder?: ActiveTab[];
  onUpdateMenuOrder?: (order: ActiveTab[]) => void;
  onImportNotes?: (newNotes: Array<Omit<Note, "id" | "createdAt" | "updatedAt">>) => void;
  flashcards?: Flashcard[];
  onUpdateFlashcards?: (cards: Flashcard[]) => void;
  onOpenNewCardModal?: () => void;
  trash?: TrashItem[];
  onOpenTrash?: () => void;
  onResetAllData?: () => void;
  onImportBackup?: (importedData: any) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  onUpdateProfile,
  syncLogs,
  onAddSyncLog,
  onClearSyncLogs,
  notes,
  onOpenNote,
  vaultRecord,
  setVaultRecord,
  vaultNotes = [],
  isVaultUnlocked = false,
  onOpenVault,
  rawVaultKey,
  onNavigateToVaultTab,
  themeAccent = "teal",
  onChangeThemeAccent,
  darkMode = false,
  onToggleDarkMode,
  uiThemeStyle = "minimalist",
  onChangeUiThemeStyle,
  menuOrder = DEFAULT_MENU_ORDER,
  onUpdateMenuOrder,
  onImportNotes,
  flashcards = [],
  onUpdateFlashcards = () => {},
  onOpenNewCardModal = () => {},
  trash = [],
  onOpenTrash = () => {},
  onResetAllData = () => {},
  onImportBackup = () => {},
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [title, setTitle] = useState(profile.title);
  const [xHandle, setXHandle] = useState(profile.xHandle || "@eneserdm");
  const [autoSync, setAutoSync] = useState(profile.autoSync);
  const [syncFrequency, setSyncFrequency] = useState(profile.syncFrequency);
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [searchLogQuery, setSearchLogQuery] = useState("");
  const [selectedChannelFilter, setSelectedChannelFilter] = useState<string>("all");
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);
  const [activeProfileTab, setActiveProfileTab] = useState<
    | "themes"
    | "display"
    | "navigation"
    | "canvas"
    | "stylus"
    | "sections"
    | "menu_order"
    | "radial"
    | "troubleshooting"
    | "account"
    | "vault"
    | "sync"
    | "docs"
    | "study"
    | "settings"
    | "mindmap"
    | "all"
  >("themes");
  const [sectionsList, setSectionsList] = useState<SectionItem[]>(() => getStoredSections());
  const [newSecNameInput, setNewSecNameInput] = useState("");
  const [newSecDescInput, setNewSecDescInput] = useState("");
  const [editingSecId, setEditingSecId] = useState<string | null>(null);
  const [editingSecName, setEditingSecName] = useState("");
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    themes: true,
    display: true,
    canvas: true,
    menu_order: true,
    radial: true,
    account: true,
    vault: true,
    sync: true,
  });

  const toggleSection = (secKey: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [secKey]: prev[secKey] === undefined ? false : !prev[secKey],
    }));
  };

  const handleExpandAllSections = () => {
    setOpenSections({
      themes: true,
      menu_order: true,
      radial: true,
      account: true,
      vault: true,
      sync: true,
    });
    setActiveProfileTab("all");
  };

  const handleCollapseAllSections = () => {
    setOpenSections({
      themes: false,
      menu_order: false,
      radial: false,
      account: false,
      vault: false,
      sync: false,
    });
  };

  const MENU_SECTION_INFO: Record<ActiveTab, { title: string; desc: string; icon: React.ReactNode }> = {
    plus_action: { title: "Hızlı Ekleme Butonu (+)", desc: "Yeni not, görev veya zihin haritası başlatan ana eylem", icon: <Plus className="w-4 h-4 text-teal-500 stroke-[3]" /> },
    home: { title: "Tüm Notlar", desc: "Tüm zengin metin notları, etiketler ve süzgeçler", icon: <StickyNote className="w-4 h-4 text-teal-500" /> },
    docs: { title: "Belge İnceleyici Hub", desc: "PDF, Word ve Markdown belge yönetimi", icon: <FileText className="w-4 h-4 text-blue-500" /> },
    mindmap: { title: "Zihin Haritası & Tuval", desc: "PKM zihin düğümleri ve görsel bilgi ağacı", icon: <Network className="w-4 h-4 text-purple-500" /> },
    vault: { title: "Şifreli Kasa", desc: "AES-256-GCM ile korunan gizli veriler", icon: <Shield className="w-4 h-4 text-emerald-500" /> },
    study: { title: "Öğrenme & Çalışma Kartları", desc: "Flashcard ve aralıklı tekrar modülleri", icon: <BookOpen className="w-4 h-4 text-amber-500" /> },
    profile: { title: "Profil & Arayüz Ayarları", desc: "Tema, menü sıralaması ve e-posta senkronizasyonu", icon: <User className="w-4 h-4 text-indigo-500" /> },
    tips: { title: "İpuçları Rehberi", desc: "Uygulama kullanım kısayolları ve tüyolar", icon: <Sparkles className="w-4 h-4 text-rose-500" /> },
    settings: { title: "Sistem Ayarları", desc: "Yerel depolama, dışa aktarma ve sıfırlama", icon: <Sliders className="w-4 h-4 text-slate-500" /> },
    ai_chat: { title: "AI Asistan & Sohbet", desc: "Yapay zeka analiz ve soru-cevap", icon: <Sparkles className="w-4 h-4 text-teal-400" /> },
    quick_search: { title: "Hızlı Arama & Komutlar", desc: "Uygulama genelinde arama çubuğu", icon: <Search className="w-4 h-4 text-blue-400" /> },
    voice_memo: { title: "Hızlı Sesli Not", desc: "Tek tıkla ses kaydı ve transkripsiyon", icon: <Mic className="w-4 h-4 text-rose-400" /> },
  };

  const handleMoveSectionUp = (index: number) => {
    if (index <= 0 || !menuOrder || !onUpdateMenuOrder) return;
    const newOrder = [...menuOrder];
    const temp = newOrder[index - 1];
    newOrder[index - 1] = newOrder[index];
    newOrder[index] = temp;
    onUpdateMenuOrder(newOrder);
  };

  const handleMoveSectionDown = (index: number) => {
    if (!menuOrder || index >= menuOrder.length - 1 || !onUpdateMenuOrder) return;
    const newOrder = [...menuOrder];
    const temp = newOrder[index + 1];
    newOrder[index + 1] = newOrder[index];
    newOrder[index] = temp;
    onUpdateMenuOrder(newOrder);
  };

  const handleResetMenuOrder = () => {
    if (onUpdateMenuOrder) {
      onUpdateMenuOrder(DEFAULT_MENU_ORDER);
    }
  };

  // Sign In / Auth state inside profile
  const [loginEmailInput, setLoginEmailInput] = useState("");
  const [loginNameInput, setLoginNameInput] = useState("");
  const [showEmailLoginForm, setShowEmailLoginForm] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<"login" | "register" | "forgot">("login");

  // =========================================================================
  // VAULT & PRE-PREPARED REGISTRATION MANAGEMENT STATE ("Tüm İşler" Merkezi)
  // =========================================================================
  const [activeVaultTask, setActiveVaultTask] = useState<
    "setup" | "change_pin" | "decoy" | "security" | "recovery" | "overview"
  >(vaultRecord ? "overview" : "setup");

  // Pre-prepared Vault Registration State (Daha Önceden Hazırlanmış)
  const [setupPinType, setSetupPinType] = useState<"pin" | "alphanumeric">("pin");
  const [setupPin, setSetupPin] = useState("123456");
  const [setupPinConfirm, setSetupPinConfirm] = useState("123456");
  const [showSetupPin, setShowSetupPin] = useState(false);
  const [showSetupPinConfirm, setShowSetupPinConfirm] = useState(false);
  const [setupQuestion, setSetupQuestion] = useState(
    "İlk evcil hayvanınızın adı veya en sevdiğiniz şehir?"
  );
  const [setupCustomQuestion, setSetupCustomQuestion] = useState("");
  const [setupAnswer, setSetupAnswer] = useState("İstanbul");
  const [showSetupAnswer, setShowSetupAnswer] = useState(false);
  const [setupHint, setSetupHint] = useState("Şehir veya Hatıra");
  const [setupDecoyPin, setSetupDecoyPin] = useState("9999");
  const [setupAutoLock, setSetupAutoLock] = useState<number>(5);
  const [isProcessingSetup, setIsProcessingSetup] = useState(false);
  const [vaultFeedback, setVaultFeedback] = useState<{
    type: "success" | "error" | "info";
    message: string;
  } | null>(null);

  // 12-Word Seed preview (Önceden hazır tutulan kurtarma kelimeleri)
  const [prePreparedWords, setPrePreparedWords] = useState<string[]>(() => {
    const list: string[] = [];
    for (let i = 0; i < 12; i++) {
      const w = MNEMONIC_WORDS[(i * 19 + 7) % MNEMONIC_WORDS.length];
      list.push(w);
    }
    return list;
  });
  const [hasCopiedMnemonic, setHasCopiedMnemonic] = useState(false);

  // Change PIN state
  const [currentPinInput, setCurrentPinInput] = useState("");
  const [newPinInput, setNewPinInput] = useState("");
  const [newPinConfirmInput, setNewPinConfirmInput] = useState("");
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [showNewPin, setShowNewPin] = useState(false);
  const [isChangingPin, setIsChangingPin] = useState(false);

  // Decoy PIN state
  const [customDecoyPin, setCustomDecoyPin] = useState(
    () => localStorage.getItem("smart_notes_vault_decoy_pin") || "9999"
  );
  const [isSavingDecoy, setIsSavingDecoy] = useState(false);

  // Security Question Update state
  const [updateQuestion, setUpdateQuestion] = useState(
    vaultRecord?.securityQuestion || "İlk evcil hayvanınızın adı veya en sevdiğiniz şehir?"
  );
  const [updateAnswer, setUpdateAnswer] = useState("");
  const [updateHint, setUpdateHint] = useState(vaultRecord?.hint || "");
  const [isUpdatingSecurity, setIsUpdatingSecurity] = useState(false);

  // Reset confirmation state
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // =========================================================================
  // VAULT & NEW REGISTRATION HANDLERS ("Tüm İşler" Yöneticileri)
  // =========================================================================
  const handleCompleteSetup = async (isQuickPrepared: boolean = false) => {
    setIsProcessingSetup(true);
    setVaultFeedback(null);
    try {
      const pinToUse = isQuickPrepared ? setupPin : setupPin.trim();
      const confirmToUse = isQuickPrepared ? setupPinConfirm : setupPinConfirm.trim();

      if (!pinToUse) {
        setVaultFeedback({ type: "error", message: "Lütfen bir şifre veya PIN belirleyin." });
        setIsProcessingSetup(false);
        return;
      }
      if (pinToUse.length < 4) {
        setVaultFeedback({ type: "error", message: "Şifre en az 4 karakter veya hane olmalıdır." });
        setIsProcessingSetup(false);
        return;
      }
      if (pinToUse !== confirmToUse) {
        setVaultFeedback({ type: "error", message: "Şifre ve tekrarı birbiriyle eşleşmiyor!" });
        setIsProcessingSetup(false);
        return;
      }

      const finalQuestion =
        setupQuestion === "custom"
          ? setupCustomQuestion.trim() || "Özel Güvenlik Sorusu"
          : setupQuestion;

      const finalAnswer = setupAnswer.trim() || undefined;

      const { record, mnemonicPhrase } = await initializeVault(
        pinToUse,
        finalQuestion,
        finalAnswer,
        setupHint.trim() || undefined,
        setupAutoLock
      );

      // Save custom decoy PIN
      if (setupDecoyPin.trim()) {
        localStorage.setItem("smart_notes_vault_decoy_pin", setupDecoyPin.trim());
        setCustomDecoyPin(setupDecoyPin.trim());
      }

      if (setVaultRecord) {
        setVaultRecord(record);
      }

      // Update pre-prepared words with the actual cryptographic mnemonic phrase
      setPrePreparedWords(mnemonicPhrase.split(" "));

      setVaultFeedback({
        type: "success",
        message:
          "✓ Yeni Kasa Kaydı Başarıyla Tamamlandı! Askeri AES-256-GCM ile şifrelendi. Üst menüdeki veya alttaki 'Kasa' butonuna tıklayarak açabilirsiniz.",
      });

      onAddSyncLog({
        noteId: "vault-setup",
        noteTitle: "Yeni Kasa Kaydı Oluşturuldu",
        destination: "Akıllı Kasa (AES-256-GCM)",
        channelType: "webhook",
        status: "success",
        timestamp: new Date().toISOString(),
        details: `Sıfır bilgi AES-256 şifreleme ve 120.000 iterasyonlu PBKDF2 ile kasa kaydı aktif edildi. Otomatik kilit: ${
          setupAutoLock > 0 ? setupAutoLock + " dk" : "Devre dışı"
        }.`,
      });

      setActiveVaultTask("overview");
    } catch (err: any) {
      setVaultFeedback({
        type: "error",
        message: "Kasa oluşturulurken bir hata oluştu: " + (err?.message || "Bilinmeyen hata"),
      });
    } finally {
      setIsProcessingSetup(false);
    }
  };

  const handleChangePin = async () => {
    if (!vaultRecord) return;
    if (!currentPinInput) {
      setVaultFeedback({ type: "error", message: "Mevcut şifrenizi giriniz." });
      return;
    }
    if (!newPinInput || newPinInput.length < 4) {
      setVaultFeedback({ type: "error", message: "Yeni şifre en az 4 karakter olmalıdır." });
      return;
    }
    if (newPinInput !== newPinConfirmInput) {
      setVaultFeedback({ type: "error", message: "Yeni şifreler eşleşmiyor!" });
      return;
    }

    setIsChangingPin(true);
    setVaultFeedback(null);
    try {
      const { newRecord, mnemonicPhrase } = await changeVaultPin(
        vaultRecord,
        currentPinInput,
        newPinInput,
        vaultNotes,
        updateQuestion,
        updateAnswer || undefined,
        updateHint || undefined
      );

      if (setVaultRecord) {
        setVaultRecord(newRecord);
      }
      setPrePreparedWords(mnemonicPhrase.split(" "));
      setCurrentPinInput("");
      setNewPinInput("");
      setNewPinConfirmInput("");
      setVaultFeedback({
        type: "success",
        message: "✓ Kasa şifreniz başarıyla değiştirildi ve tüm kasa verileri yeni anahtarla yeniden şifrelendi.",
      });

      onAddSyncLog({
        noteId: "vault-pin-change",
        noteTitle: "Kasa Şifresi Değiştirildi",
        destination: "Akıllı Kasa (PBKDF2 Salt)",
        channelType: "webhook",
        status: "success",
        timestamp: new Date().toISOString(),
        details: "Kasa anahtarı yeni PBKDF2 salt ile başarıyla güncellendi.",
      });
    } catch (err: any) {
      setVaultFeedback({
        type: "error",
        message: "Şifre değiştirilemedi: Mevcut şifreniz hatalı olabilir. (" + (err?.message || "Hata") + ")",
      });
    } finally {
      setIsChangingPin(false);
    }
  };

  const handleSaveDecoy = () => {
    if (!customDecoyPin.trim() || customDecoyPin.trim().length < 4) {
      setVaultFeedback({ type: "error", message: "Tuzak PIN en az 4 haneli olmalıdır." });
      return;
    }
    setIsSavingDecoy(true);
    localStorage.setItem("smart_notes_vault_decoy_pin", customDecoyPin.trim());
    setTimeout(() => {
      setIsSavingDecoy(false);
      setVaultFeedback({
        type: "success",
        message: `✓ Tuzak Kasa (Decoy PIN) '${customDecoyPin.trim()}' olarak ayarlandı. Bu PIN girildiğinde sahte boş kasa açılır.`,
      });
    }, 300);
  };

  const handleCopyMnemonic = () => {
    const text = prePreparedWords.join(" ");
    navigator.clipboard.writeText(text);
    setHasCopiedMnemonic(true);
    setTimeout(() => setHasCopiedMnemonic(false), 3000);
  };

  const handleDownloadRecoveryKit = () => {
    const content = `AKILLI GÜVENLİ KASA - ACİL DURUM KURTARMA KİTİ
Tarih: ${new Date().toLocaleString("tr-TR")}
Algoritma: AES-256-GCM Zero-Knowledge & PBKDF2 (120,000 iterasyon)

12 KELİMELİK ACİL KURTARMA CÜMLESİ:
${prePreparedWords.map((w, idx) => `${idx + 1}. ${w}`).join("\n")}

GÜVENLİK TALİMATLARI:
1. Bu kelimeleri güvenli, çevrimdışı ve yalnızca sizin erişebileceğiniz bir yerde saklayınız.
2. Şifrenizi unutmanız durumunda kilit ekranındaki "Acil Durum Kurtarma" seçeneğine bu kelimeleri girerek kasanızı kurtarabilirsiniz.
3. Kasa şifreleriniz sunucularda saklanmaz, tamamen istemci taraflı korunur.
`;
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `kasa-kurtarma-kiti-${new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSyncVaultStatsToProfile = () => {
    onAddSyncLog({
      noteId: "vault-health",
      noteTitle: "Kasa Durumu Doğrulandı",
      destination: "Akıllı Kasa (AES-256-GCM)",
      channelType: "webhook",
      status: "success",
      timestamp: new Date().toISOString(),
      details: `Kasa kayıtlı: ${vaultRecord ? "Aktif" : "Bekliyor"}. Korumalı Not: ${vaultNotes.length} adet. Algoritma: AES-256-GCM. Doğrulama: Başarılı.`,
    });
    setVaultFeedback({
      type: "success",
      message: "✓ Kasa güvenlik raporu profil senkronizasyon günlüğüne kaydedildi.",
    });
  };

  const handleResetVault = () => {
    if (setVaultRecord) {
      setVaultRecord(null);
    }
    localStorage.removeItem("smart_notes_vault_meta");
    localStorage.removeItem("smart_notes_vault_data");
    setShowResetConfirm(false);
    setActiveVaultTask("setup");
    setVaultFeedback({
      type: "info",
      message: "Kasa başarıyla sıfırlandı. Aşağıdaki önceden hazırlanmış panelden dilediğiniz zaman yeni kasa kaydı oluşturabilirsiniz.",
    });
    onAddSyncLog({
      noteId: "vault-reset",
      noteTitle: "Kasa Sıfırlandı",
      destination: "Akıllı Kasa Yönetimi",
      channelType: "webhook",
      status: "pending",
      timestamp: new Date().toISOString(),
      details: "Kullanıcı isteğiyle kasa sıfırlandı ve yeni kurulum moduna alındı.",
    });
  };

  const handleGenerateRandomPin = () => {
    if (setupPinType === "pin") {
      const rnd = Math.floor(100000 + Math.random() * 900000).toString();
      setSetupPin(rnd);
      setSetupPinConfirm(rnd);
    } else {
      const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*";
      let res = "";
      for (let i = 0; i < 10; i++) {
        res += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      setSetupPin(res);
      setSetupPinConfirm(res);
    }
  };

  // Quick Google Sign-In Simulation / Real Profile Connect
  const handleGoogleSignIn = () => {
    setIsAuthenticating(true);
    setTimeout(() => {
      const updated: UserProfile = {
        ...profile,
        name: profile.name || "Enes Erdem",
        email: "enes02erdm@gmail.com",
        isLoggedIn: true,
        authProvider: "google",
        aiModeEnabled: true,
        joinedDate: profile.joinedDate || new Date().toISOString(),
      };
      onUpdateProfile(updated);
      setIsAuthenticating(false);
      setSaveSuccessNotice("Google / Gmail hesabınızla başarıyla giriş yapıldı! Tüm yapay zeka araçları ve soru sorma özellikleri aktif edildi.");
      setTimeout(() => setSaveSuccessNotice(null), 4000);
    }, 600);
  };

  // Custom Email Sign-In
  const handleEmailSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmailInput.trim()) return;

    setIsAuthenticating(true);
    setTimeout(() => {
      const derivedName = loginNameInput.trim() || loginEmailInput.split("@")[0] || "Kullanıcı";
      const updated: UserProfile = {
        ...profile,
        name: derivedName,
        email: loginEmailInput.trim(),
        isLoggedIn: true,
        authProvider: "email",
        aiModeEnabled: true,
        joinedDate: profile.joinedDate || new Date().toISOString(),
      };
      onUpdateProfile(updated);
      setIsAuthenticating(false);
      setShowEmailLoginForm(false);
      setSaveSuccessNotice(`${loginEmailInput.trim()} adresiyle giriş yapıldı! Yapay zeka araçları kullanıma hazır.`);
      setTimeout(() => setSaveSuccessNotice(null), 4000);
    }, 500);
  };

  // Log Out / Switch to Guest / Classic Mode
  const handleSignOut = () => {
    clearActiveSession();
    const updated: UserProfile = {
      ...profile,
      isLoggedIn: false,
      authProvider: "guest",
      // Leave aiModeEnabled as preference, but login required for query
    };
    onUpdateProfile(updated);
    setSaveSuccessNotice("Oturum kapatıldı. Uygulamayı klasik modda yapay zekasız veya misafir olarak sınırsızca kullanabilirsiniz.");
    setTimeout(() => setSaveSuccessNotice(null), 3500);
  };

  // Toggle AI Mode on/off
  const handleToggleAiMode = (enabled: boolean) => {
    const updated: UserProfile = {
      ...profile,
      aiModeEnabled: enabled,
    };
    onUpdateProfile(updated);
    setSaveSuccessNotice(
      enabled
        ? "🤖 Yapay Zeka modu etkinleştirildi! Soru sorma, özetleme ve akıllı araçlar aktif."
        : "🍃 Sade ve Klasik Not Defteri moduna geçildi. Yapay zeka araçları gizlendi/duraklatıldı."
    );
    setTimeout(() => setSaveSuccessNotice(null), 3500);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || "Kullanıcı",
      email: email.trim() || "enes02erdm@gmail.com",
      title: title.trim() || "Not Yöneticisi",
      xHandle: xHandle.trim(),
      autoSync,
      syncFrequency,
    };
    onUpdateProfile(updated);
    setIsEditing(false);
    setSaveSuccessNotice("Profil bilgileriniz ve senkronizasyon tercihleriniz başarıyla güncellendi.");
    setTimeout(() => setSaveSuccessNotice(null), 3000);
  };

  // Trigger manual sync of all public notes to profile email
  const handleSyncAllNotes = async () => {
    if (notes.length === 0) {
      alert("Senkronize edilecek not bulunamadı.");
      return;
    }

    setIsSyncingAll(true);
    try {
      const targetEmail = profile.email || "enes02erdm@gmail.com";
      const res = await fetch("/api/sync/dispatch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          note: {
            title: `NoteFlow Toplu Yedek (${notes.length} Not)`,
            content: `Kullanıcı ${profile.name} tarafından ${new Date().toLocaleString("tr-TR")} tarihinde başlatılan toplu senkronizasyon paketi.`,
          },
          destination: `Gmail (${targetEmail})`,
          recipientEmail: targetEmail,
          channelType: "email",
        }),
      });

      if (res.ok) {
        onAddSyncLog({
          noteId: "all-notes-batch",
          noteTitle: `Toplu Arşiv: ${notes.length} Not Paketi`,
          destination: `Gmail (${targetEmail})`,
          channelType: "email",
          status: "success",
          timestamp: new Date().toISOString(),
          details: `Tüm notlar başarıyla ${targetEmail} adresine iletildi ve bulut arşivine işlendi.`,
        });

        notes.slice(0, 3).forEach((n) => {
          onAddSyncLog({
            noteId: n.id,
            noteTitle: n.title || "Başlıksız Not",
            destination: `Gmail (${targetEmail})`,
            channelType: "email",
            status: "success",
            timestamp: new Date().toISOString(),
            details: `Otomatik profil yedeklemesi tamamlandı.`,
          });
        });

        alert(`Tüm notlarınız (${notes.length} adet) başarıyla ${targetEmail} adresine ve bulut sistemine kaydedildi!`);
      }
    } catch (err) {
      console.error("Sync error:", err);
      alert("Senkronizasyon sırasında bir bağlantı hatası oluştu.");
    } finally {
      setIsSyncingAll(false);
    }
  };

  // Filter synced logs
  const filteredLogs = syncLogs.filter((log) => {
    if (selectedChannelFilter !== "all" && log.channelType !== selectedChannelFilter) {
      return false;
    }
    if (searchLogQuery.trim()) {
      const q = searchLogQuery.toLowerCase();
      return (
        log.noteTitle.toLowerCase().includes(q) ||
        log.destination.toLowerCase().includes(q) ||
        (log.details && log.details.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-4 sm:space-y-6 px-1 sm:px-2 pb-28 sm:pb-24 animate-in fade-in duration-200">
      {/* Save Notice Toast */}
      {saveSuccessNotice && (
        <div className="p-3 sm:p-4 rounded-2xl bg-emerald-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{saveSuccessNotice}</span>
          </div>
          <button
            onClick={() => setSaveSuccessNotice(null)}
            className="p-1 text-emerald-200 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {/* 0. ACTIVE THEME & QUICK STYLE SWITCHER BANNER */}
      <div className="p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl bg-gradient-to-r from-teal-500/10 via-slate-100 to-rose-500/10 dark:from-teal-950/40 dark:via-slate-900 dark:to-rose-950/40 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 shadow-sm">
        <div className="flex items-start sm:items-center gap-2.5 sm:gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-teal-600 dark:text-teal-400 shrink-0 shadow-xs">
            <Palette className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Aktif Arayüz Stili:</span>
              <span className="text-xs font-black text-slate-900 dark:text-white px-2.5 py-0.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
                {UI_THEME_STYLE_CONFIGS[uiThemeStyle]?.name || uiThemeStyle}
              </span>
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                (Eski & Yeni Stiller Korunuyor)
              </span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">
              Tek tıkla Klasik NoteFlow ile Sirkadiyen PKM veya diğer stiller arasında geçiş yapabilirsiniz.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          <button
            onClick={() => {
              if (onChangeUiThemeStyle) onChangeUiThemeStyle("minimalist");
              setSaveSuccessNotice("Klasik NoteFlow stili etkinleştirildi.");
              setTimeout(() => setSaveSuccessNotice(null), 3000);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              uiThemeStyle === "minimalist"
                ? "bg-teal-600 text-white shadow-xs"
                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50"
            }`}
          >
            <Layout className="w-3.5 h-3.5" />
            <span>Klasik Stil</span>
          </button>

          <button
            onClick={() => {
              if (onChangeUiThemeStyle) onChangeUiThemeStyle("circadian_pkm");
              setSaveSuccessNotice("Sirkadiyen Stratejik PKM (Görseldeki İkili Mod) etkinleştirildi.");
              setTimeout(() => setSaveSuccessNotice(null), 3000);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              uiThemeStyle === "circadian_pkm"
                ? "bg-gradient-to-r from-[#E0533C] to-[#E11D48] text-white shadow-xs"
                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Sirkadiyen Stil</span>
          </button>
        </div>
      </div>

      {/* CATEGORY TABS NAVIGATION BAR (Sekmeli / Akordeon Kategori Seçimi) */}
      <div className="flex items-center gap-1.5 overflow-x-auto p-1.5 bg-slate-100/90 dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 scrollbar-none shadow-2xs">
        <button
          type="button"
          onClick={() => setActiveProfileTab("themes")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "themes"
              ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Palette className="w-3.5 h-3.5 text-teal-500" />
          <span>Görsel Temalar</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 font-extrabold">6</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("display")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "display"
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-500" />
          <span>Ekran & Ölçek</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-extrabold">%75-%175</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("navigation")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "navigation"
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-indigo-500" />
          <span>Navigasyon & Dok</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-extrabold">Dinamik</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("docs")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "docs"
              ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <FileText className="w-3.5 h-3.5 text-blue-500" />
          <span>Dijital Belge & Format Merkezi</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-extrabold">15+ Format</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("study")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "study"
              ? "bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-500" />
          <span>Öğrenme & Hafıza Kartları</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 font-extrabold">{flashcards.length} Kart</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("settings")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "settings"
              ? "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-slate-500" />
          <span>Sistem Tercihleri & Depolama</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-extrabold">Yedek/Sıfırla</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("mindmap")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "mindmap"
              ? "bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Network className="w-3.5 h-3.5 text-purple-500" />
          <span>Zihin Haritası & Tuval Ayarları</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 font-extrabold">PKM Ağacı</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("canvas")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "canvas"
              ? "bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <PenTool className="w-3.5 h-3.5 text-amber-500" />
          <span>Yazı Tahtası (Kanvas)</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 font-extrabold">4 Tema</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("stylus")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "stylus"
              ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Feather className="w-3.5 h-3.5 text-teal-500" />
          <span>KALEM & Stylus</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 font-extrabold">GMS/HMS</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("sections")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "sections"
              ? "bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-rose-500" />
          <span>Bölüm & Kategori Yönetimi</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-extrabold">Kişisel</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("menu_order")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "menu_order"
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5 text-indigo-500" />
          <span>Menü Sıralaması & Görünürlük</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-extrabold">{menuOrder.length}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("radial")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "radial"
              ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <RotateCw className="w-3.5 h-3.5 text-teal-500" />
          <span>Radyal Menü (Çark)</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 font-extrabold">Özelleştir</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("troubleshooting")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "troubleshooting"
              ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Wrench className="w-3.5 h-3.5 text-teal-500" />
          <span>Sorun Çözme Merkezi</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 font-extrabold">Auto-Heal</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("account")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "account"
              ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <User className="w-3.5 h-3.5 text-teal-500" />
          <span>Kullanıcı & Yapay Zeka Hesabı</span>
          {profile.isLoggedIn && (
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("vault")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "vault"
              ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Shield className="w-3.5 h-3.5 text-emerald-500" />
          <span>Sistem & Güvenlik (Kasa)</span>
          {vaultRecord && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-extrabold">{vaultNotes.length}</span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("sync")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeProfileTab === "sync"
              ? "bg-white dark:bg-slate-900 text-cyan-600 dark:text-cyan-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
          }`}
        >
          <Cloud className="w-3.5 h-3.5 text-cyan-500" />
          <span>Senkronizasyon & Veri</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 font-extrabold">{notes.length}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveProfileTab("all")}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ml-auto ${
            activeProfileTab === "all"
              ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
          title="Tüm ayarları tek sayfada alt alta görüntüle"
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Tümünü Göster</span>
        </button>

        <div className="flex items-center gap-1 shrink-0 pl-1 border-l border-slate-200 dark:border-slate-700">
          <button
            type="button"
            onClick={handleExpandAllSections}
            className="px-2 py-1 rounded-lg text-[10px] font-bold bg-white/70 dark:bg-slate-900/70 hover:bg-white dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
            title="Tüm akordeon bölümlerini aç"
          >
            Hepsini Aç
          </button>
          <button
            type="button"
            onClick={handleCollapseAllSections}
            className="px-2 py-1 rounded-lg text-[10px] font-bold bg-white/70 dark:bg-slate-900/70 hover:bg-white dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
            title="Tüm akordeon bölümlerini kapat"
          >
            Hepsini Kapat
          </button>
        </div>
      </div>

      {/* 1. AUTHENTICATION & AI ACTIVATION CARD */}
      {(activeProfileTab === "account" || activeProfileTab === "all") && (
      <div className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-md">
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-teal-500/10 via-emerald-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="p-6 sm:p-8">
          {profile.isLoggedIn ? (
            /* --- LOGGED IN VIEW --- */
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5 pb-6 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-600 via-emerald-600 to-cyan-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-teal-500/20">
                      {profile.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .slice(0, 2)
                        .toUpperCase() || "NF"}
                    </div>
                    <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center text-[10px] text-white font-bold" title="Aktif ve Doğrulanmış">
                      ✓
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                        {profile.name}
                      </h2>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center gap-1 border border-teal-200 dark:border-teal-800">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        <span>{profile.authProvider === "google" ? "Gmail ile Doğrulandı" : "E-posta ile Bağlı"}</span>
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                      {profile.title}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-400 mt-2 flex-wrap">
                      <span className="flex items-center gap-1 font-medium">
                        <Mail className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                        <strong className="text-slate-800 dark:text-slate-200">{profile.email}</strong>
                      </span>
                      {profile.xHandle && (
                        <span className="flex items-center gap-1 text-slate-500">
                          <span>𝕏</span>
                          <span>{profile.xHandle}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Top Action Buttons */}
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => setIsEditing(!isEditing)}
                    className="flex-1 sm:flex-initial px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isEditing ? "Vazgeç" : "Düzenle"}</span>
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="px-3 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                    title="Oturumu Kapat (Klasik moda geç)"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Çıkış</span>
                  </button>
                  <button
                    onClick={handleSyncAllNotes}
                    disabled={isSyncingAll}
                    className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all active:scale-95 flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    <Send className={`w-3.5 h-3.5 ${isSyncingAll ? "animate-spin" : ""}`} />
                    <span>Tümünü Gmail'e Yedekle</span>
                  </button>
                </div>
              </div>

              {/* AI Access & Preferences Mode Switch */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-teal-50 via-emerald-50 to-cyan-50 dark:from-slate-800/80 dark:via-slate-800/60 dark:to-slate-800/80 border border-teal-200/80 dark:border-teal-900/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-sm shrink-0">
                    <Sparkles className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                        Yapay Zeka Soru Sor & Akıllı Asistan
                      </h4>
                      <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-500 text-white">
                        Gemini 2.5 / 3.8 Flash
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      Gmail hesabınızla bağlısınız. Notlarınızla ilgili sorular sorabilir, zihin haritası ve flashcard üretebilirsiniz.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                  <button
                    onClick={() => handleToggleAiMode(!profile.aiModeEnabled)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      profile.aiModeEnabled
                        ? "bg-teal-600 text-white shadow-xs"
                        : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>{profile.aiModeEnabled ? "Yapay Zeka: Açık" : "Klasik Mod (Kapalı)"}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* --- NOT LOGGED IN / GUEST & AI GATEWAY VIEW --- */
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-xs font-bold border border-amber-200 dark:border-amber-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Yapay Zeka Araçları & Soru-Cevap Erişimi</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                    Gmail veya E-posta ile Bağlanın
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
                    Yapay zeka asistanı, soru-cevap özelliği, otomatik özetleme ve akıllı analizlerden faydalanmak için profilinizi Gmail veya E-posta adresinizle bağlayın.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto shrink-0">
                  {/* Google OAuth Button */}
                  <button
                    onClick={() => {
                      setAuthModalMode("login");
                      setIsAuthModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-extrabold text-xs border border-slate-300 dark:border-slate-700 shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer hover:border-teal-500"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>Google ile Giriş</span>
                  </button>

                  {/* Apple ID OAuth Button */}
                  <button
                    onClick={() => {
                      setAuthModalMode("login");
                      setIsAuthModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-extrabold text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                  >
                    <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 170 170">
                      <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.74 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.7-3.04-7.65-7.79-11.86-14.24-7.51-11.53-13.08-24.66-16.71-39.38-3.63-14.73-5.45-28.53-5.45-41.42 0-16.14 3.8-29.58 11.41-40.32 7.6-10.74 17.54-16.2 29.82-16.39 4.8 0 10.37 1.34 16.71 4.02 6.34 2.68 10.38 4.07 12.13 4.18 1.45 0 5.75-1.5 12.89-4.5 7.15-3 13.01-4.32 17.58-3.96 13.62.77 24.52 5.72 32.7 14.86-11.96 7.27-17.84 17.2-17.65 29.8.19 9.87 3.99 18.06 11.38 24.57 7.4 6.51 16.12 10.2 26.17 11.07-2.6 7.82-5.75 16.03-9.47 24.62zm-35.34-106.6c.13-5.11 2.05-10.25 5.76-15.42 3.71-5.17 8.3-8.88 13.78-11.13.39 1.13.58 2.22.58 3.27 0 5.48-2.07 10.9-6.2 16.27-4.13 5.37-9.39 8.87-15.77 10.51-.13-.98-.22-2.14-.22-3.5z" />
                    </svg>
                    <span>Apple ile Giriş</span>
                  </button>

                  {/* Email & Password Direct Dialog */}
                  <button
                    onClick={() => {
                      setAuthModalMode("login");
                      setIsAuthModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs shadow-md shadow-teal-600/20 flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                  >
                    <Mail className="w-4 h-4" />
                    <span>E-posta & Şifre ile Giriş</span>
                  </button>

                  {/* Register New Account Direct */}
                  <button
                    onClick={() => {
                      setAuthModalMode("register");
                      setIsAuthModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-2xl border border-teal-500/40 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Kayıt Ol</span>
                  </button>
                </div>
              </div>


              {/* Clarification for Non-AI users */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>
                    <strong>Giriş yapmadan kullanmak isteyenler:</strong> Not alma, zengin metin düzenleyici, 30 çerçeve şablonu, ses kaydı, şifreli kasa ve belge merkezini hiçbir kısıtlama olmadan özgürce ve offline kullanmaya devam edebilirsiniz!
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                  Klasik Mod Sınırsız
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Inline Profile Edit Form */}
        {isEditing && (
          <form
            onSubmit={handleSaveProfile}
            className="p-6 sm:p-8 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 grid grid-cols-1 sm:grid-cols-2 gap-4 animate-in slide-in-from-top-3 duration-200"
          >
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Ad Soyad
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                E-Posta / Gmail Adresi (Notların Kaydedileceği Hedef)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="enes02erdm@gmail.com"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Unvan / Başlık
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Sosyal Medya / X (Twitter) Kullanıcı Adı
              </label>
              <input
                type="text"
                value={xHandle}
                onChange={(e) => setXHandle(e.target.value)}
                placeholder="@kullanici"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div className="sm:col-span-2 flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="profile-autosync-toggle"
                  checked={autoSync}
                  onChange={(e) => setAutoSync(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500"
                />
                <label
                  htmlFor="profile-autosync-toggle"
                  className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  Yeni ve düzenlenen notlar otomatik olarak e-postaya/buluta kaydedilsin
                </label>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 text-xs font-semibold rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold rounded-xl bg-teal-600 hover:bg-teal-500 text-white shadow-xs"
                >
                  Değişiklikleri Kaydet
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
      )}

      {/* ========================================================================= */}
      {/* 2. DYNAMIC THEME & LAYOUT ENGINE (6 CORE THEME STYLES)                    */}
      {/* ========================================================================= */}
      {(activeProfileTab === "themes" || activeProfileTab === "all") && (
      <div id="theme-settings-section" className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 border border-teal-200/80 dark:border-teal-800 flex items-center justify-center shrink-0 shadow-xs">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base font-black text-slate-900 dark:text-white">
                  Theme & Style Settings (Görsel Temalar & Stiller)
                </h2>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-800">
                  6 Özel Stil & Mimari
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
                Eski ve yeni tüm arayüz stilleri korunmaktadır. <strong>Klasik NoteFlow (Minimalist)</strong>, <strong>Sirkadiyen PKM</strong>, <strong>Entegre PKM</strong>, <strong>Terminal</strong>, <strong>Siberpunk</strong> ve <strong>Zihin Mimarisi</strong> arasında dilediğiniz an geçiş yapabilirsiniz.
              </p>
            </div>
          </div>

          {/* Dark Mode Quick Switch */}
          {onToggleDarkMode && (
            <button
              onClick={onToggleDarkMode}
              className="px-4 py-2 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-2 transition-all cursor-pointer border border-slate-200 dark:border-slate-700 shrink-0"
              title="Aydınlık ve Koyu mod arasında geçiş yap"
            >
              {darkMode ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span>Aydınlık Moda Geç</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-500 fill-indigo-500" />
                  <span>Koyu Moda Geç</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* QUICK STYLE SWITCHER BAR */}
        <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold text-slate-700 dark:text-slate-300">
              Hızlı Stil Geçişi:
            </span>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-teal-600 text-white">
              {UI_THEME_STYLE_CONFIGS[uiThemeStyle]?.name || uiThemeStyle}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => {
                if (onChangeUiThemeStyle) onChangeUiThemeStyle("minimalist");
                setSaveSuccessNotice("Klasik NoteFlow stili etkinleştirildi.");
                setTimeout(() => setSaveSuccessNotice(null), 3000);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                uiThemeStyle === "minimalist"
                  ? "bg-teal-600 text-white shadow-xs"
                  : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100"
              }`}
            >
              <Layout className="w-3.5 h-3.5" />
              <span>Klasik Stil</span>
            </button>

            <button
              onClick={() => {
                if (onChangeUiThemeStyle) onChangeUiThemeStyle("circadian_pkm");
                setSaveSuccessNotice("Sirkadiyen Stratejik PKM (Görseldeki İkili Mod) etkinleştirildi.");
                setTimeout(() => setSaveSuccessNotice(null), 3000);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                uiThemeStyle === "circadian_pkm"
                  ? "bg-gradient-to-r from-[#E0533C] to-[#E11D48] text-white shadow-xs"
                  : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Sirkadiyen PKM</span>
            </button>

            <button
              onClick={() => {
                if (onChangeUiThemeStyle) onChangeUiThemeStyle("enterprise_pkm");
                setSaveSuccessNotice("Entegre Stratejik PKM (Kurumsal 4 Bölge) etkinleştirildi.");
                setTimeout(() => setSaveSuccessNotice(null), 3000);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                uiThemeStyle === "enterprise_pkm"
                  ? "bg-blue-600 text-white shadow-xs"
                  : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100"
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Entegre PKM</span>
            </button>
          </div>
        </div>

        {/* 6 THEME STYLES COMPACT GRID */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
            Tüm Arayüz Stilleri ve Mimari Seçenekleri
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {(Object.keys(UI_THEME_STYLE_CONFIGS) as UIThemeStyle[]).map((styleKey) => {
              const def = UI_THEME_STYLE_CONFIGS[styleKey];
              const isSelected = uiThemeStyle === styleKey;

              return (
                <div
                  key={styleKey}
                  onClick={() => {
                    if (onChangeUiThemeStyle) onChangeUiThemeStyle(styleKey);
                    setSaveSuccessNotice(`Arayüz stili değiştirildi: ${def.name}`);
                    setTimeout(() => setSaveSuccessNotice(null), 3000);
                  }}
                  className={`relative p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    isSelected
                      ? "border-teal-500 dark:border-teal-400 bg-teal-50/40 dark:bg-teal-950/20 shadow-md shadow-teal-500/10 ring-2 ring-teal-500/20"
                      : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
                  }`}
                >
                  <div className="space-y-2">
                    {/* Header line with badge */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {styleKey === "minimalist" && <Layout className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />}
                        {styleKey === "circadian_pkm" && <Sparkles className="w-4 h-4 text-rose-500 shrink-0" />}
                        {styleKey === "terminal" && <Terminal className="w-4 h-4 text-emerald-500 shrink-0" />}
                        {styleKey === "cyberpunk" && <Cpu className="w-4 h-4 text-cyan-400 shrink-0" />}
                        {styleKey === "mental_canvas" && <Layers className="w-4 h-4 text-indigo-400 shrink-0" />}
                        {styleKey === "enterprise_pkm" && <Building2 className="w-4 h-4 text-amber-500 shrink-0" />}
                        <h4 className="text-xs font-black text-slate-900 dark:text-white truncate">
                          {def.name}
                        </h4>
                      </div>
                      <span
                        className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full shrink-0 ${
                          isSelected
                            ? "bg-teal-600 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        {def.badge}
                      </span>
                    </div>

                    <p className="text-[11px] font-semibold text-teal-700 dark:text-teal-300 truncate">
                      {def.tagline}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {def.description}
                    </p>

                    {/* Features checklist chips */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap gap-1">
                      {def.features.map((feat, i) => (
                        <span key={i} className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          <Check className="w-2.5 h-2.5 text-teal-500 shrink-0" />
                          <span>{feat}</span>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Active selection button indicator */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onChangeUiThemeStyle) onChangeUiThemeStyle(styleKey);
                      setSaveSuccessNotice(`Arayüz stili değiştirildi: ${def.name}`);
                      setTimeout(() => setSaveSuccessNotice(null), 3000);
                    }}
                    className={`w-full py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      isSelected
                        ? "bg-teal-600 text-white shadow-xs"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Aktif Stil</span>
                      </>
                    ) : (
                      <span>Stili Etkinleştir</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* ACCENT COLOR SELECTOR COMPACT GRID */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
              Vurgu Rengi Paleti
            </h3>
            <span className="text-[11px] font-semibold text-teal-600 dark:text-teal-400">
              Seçili: {THEME_ACCENTS[themeAccent]?.name || themeAccent}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {(Object.keys(THEME_ACCENTS) as ThemeAccent[]).map((accKey) => {
              const acc = THEME_ACCENTS[accKey];
              const isAccSelected = themeAccent === accKey;
              return (
                <button
                  key={accKey}
                  type="button"
                  onClick={() => onChangeThemeAccent && onChangeThemeAccent(accKey)}
                  className={`group relative flex items-center gap-2.5 p-2.5 rounded-2xl border transition-all cursor-pointer ${
                    isAccSelected
                      ? "border-teal-500 dark:border-teal-400 bg-teal-50/70 dark:bg-teal-950/60 text-teal-900 dark:text-teal-100 shadow-xs ring-1 ring-teal-500/30"
                      : "border-slate-200/90 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-white dark:hover:bg-slate-800"
                  }`}
                >
                  <div
                    className="w-5 h-5 rounded-full shrink-0 shadow-xs ring-2 ring-white dark:ring-slate-900 flex items-center justify-center text-white"
                    style={{ backgroundColor: acc.preview }}
                  >
                    {isAccSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div className="text-left truncate min-w-0">
                    <span className="text-xs font-bold block truncate">{acc.name}</span>
                    <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">{acc.preview}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.5 KATEGORİK EKRAN & ÖLÇEKLENDİRME AYARLARI (DISPLAY SETTINGS)           */}
      {/* ========================================================================= */}
      {(activeProfileTab === "display" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <DisplaySettingsView onNotify={(msg) => setSaveSuccessNotice(msg)} />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.8 DİNAMİK NAVİGASYON ÇUBUĞU & ARAYÜZ DENEYİMİ (PROFILE SETTINGS)        */}
      {/* ========================================================================= */}
      {(activeProfileTab === "navigation" || activeProfileTab === "all") && (
      <div className="space-y-6">
        <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
          <ProfileInterfaceSettings onNotify={(msg) => {
            setSaveSuccessNotice(msg);
            setTimeout(() => setSaveSuccessNotice(null), 3000);
          }} />
        </div>

        <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
          <NavigationSettingsView onNotify={(msg) => {
            setSaveSuccessNotice(msg);
            setTimeout(() => setSaveSuccessNotice(null), 3000);
          }} />
        </div>
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.9 DİJİTAL BELGE VE FORMAT MERKEZİ (DOCUMENT CENTER & EXPORTS)           */}
      {/* ========================================================================= */}
      {(activeProfileTab === "docs" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <DocumentCenterView
          notes={notes}
          sections={sectionsList}
          themeAccent={themeAccent}
          onImportNotes={(newNotes) => {
            if (onImportNotes) {
              onImportNotes(newNotes);
            }
            setSaveSuccessNotice(`✓ ${newNotes.length} adet yeni belge başarıyla içe aktarıldı!`);
            setTimeout(() => setSaveSuccessNotice(null), 3500);
          }}
          onOpenNote={onOpenNote}
        />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.95 ÖĞRENME & HAFIZA KARTLARI YÖNETİMİ & AYARLARI (STUDY & FLASHCARDS)    */}
      {/* ========================================================================= */}
      {(activeProfileTab === "study" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200/80 dark:border-amber-800 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Öğrenme & Hafıza Kartları Merkezi
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Aralıklı tekrar (Spaced Repetition) ve test kartlarınızı Profil üzerinden yönetin.
              </p>
            </div>
          </div>
        </div>
        <StudyView
          flashcards={flashcards}
          notes={notes}
          onUpdateFlashcards={onUpdateFlashcards}
          onOpenNewCardModal={onOpenNewCardModal}
        />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.98 SİSTEM TERCİHLERİ & DEPOLAMA AYARLARI (SETTINGS & SYSTEM BACKUP)     */}
      {/* ========================================================================= */}
      {(activeProfileTab === "settings" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <SettingsView
          notes={notes}
          trash={trash}
          flashcards={flashcards}
          darkMode={darkMode}
          setDarkMode={() => onToggleDarkMode && onToggleDarkMode()}
          themeAccent={themeAccent}
          setThemeAccent={(acc) => onChangeThemeAccent && onChangeThemeAccent(acc)}
          onOpenTrash={onOpenTrash}
          onImportBackup={onImportBackup}
          onResetAllData={onResetAllData}
        />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 1.99 ZİHİN HARİTASI & İLİŞKİ AĞI AYARLARI (MINDMAP CONFIG)                */}
      {/* ========================================================================= */}
      {(activeProfileTab === "mindmap" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <MindMapSettingsPanel
          onNotify={(msg) => {
            setSaveSuccessNotice(msg);
            setTimeout(() => setSaveSuccessNotice(null), 3000);
          }}
        />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 2. YAZI TAHTASI (CANVAS THEME SELECTOR - 4 ÖZEL TEMA)                     */}
      {/* ========================================================================= */}
      {(activeProfileTab === "canvas" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <CanvasThemeSelector />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 2.5 DİJİTAL KALEM & STYLUS MERKEZİ (PALM REJECTION, BEZIER, ML KIT OCR) */}
      {/* ========================================================================= */}
      {(activeProfileTab === "stylus" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5 transition-all duration-300">
        <StylusSettingsHub />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 2.8 BÖLÜM & KATEGORİ YÖNETİMİ (KİŞİSEL, İŞ, FİKİRLER, PROJELER, EĞİTİM)   */}
      {/* ========================================================================= */}
      {(activeProfileTab === "sections" || activeProfileTab === "all") && (
      <div className="p-5 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border border-rose-200/80 dark:border-rose-800 flex items-center justify-center shrink-0 shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base font-black text-slate-900 dark:text-white">
                  Kişisel & Özelleştirilebilir Bölüm Yönetimi
                </h2>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                  {sectionsList.length} Aktif Bölüm
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
                Notlarınızı <strong>Kişisel</strong>, <strong>İş</strong>, <strong>Fikirler</strong>, <strong>Projeler</strong>, <strong>Eğitim</strong> veya kendi oluşturacağınız özel bölümlere ayırın.
              </p>
            </div>
          </div>
        </div>

        {/* Existing Sections Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {sectionsList.map((sec) => (
            <div
              key={sec.id}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex flex-col justify-between gap-3 group hover:border-rose-300 transition-all"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  {editingSecId === sec.id ? (
                    <input
                      type="text"
                      value={editingSecName}
                      onChange={(e) => setEditingSecName(e.target.value)}
                      className="text-xs font-black bg-white dark:bg-slate-900 border border-teal-500 rounded-lg px-2 py-1 w-full"
                      autoFocus
                    />
                  ) : (
                    <span className="text-xs font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-rose-500" />
                      {sec.name}
                    </span>
                  )}

                  <div className="flex items-center gap-1 opacity-90 group-hover:opacity-100">
                    {editingSecId === sec.id ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (editingSecName.trim()) {
                            const updated = sectionsList.map((s) =>
                              s.id === sec.id ? { ...s, name: editingSecName.trim() } : s
                            );
                            setSectionsList(updated);
                            saveStoredSections(updated);
                          }
                          setEditingSecId(null);
                        }}
                        className="px-2 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-bold"
                      >
                        Kaydet
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingSecId(sec.id);
                          setEditingSecName(sec.name);
                        }}
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-500"
                        title="Yeniden Adlandır"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {!sec.isDefault && (
                      <button
                        type="button"
                        onClick={() => {
                          const updated = sectionsList.filter((s) => s.id !== sec.id);
                          setSectionsList(updated);
                          saveStoredSections(updated);
                        }}
                        className="p-1 hover:bg-rose-100 dark:hover:bg-rose-950/60 rounded text-rose-500"
                        title="Bölümü Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                  {sec.description || "Özel not alanı"}
                </p>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-200/50 dark:border-slate-700/50 pt-2">
                <span>Not Sayısı: {notes.filter((n) => n.category === sec.name).length}</span>
                <span className="font-semibold text-teal-600 dark:text-teal-400">
                  {sec.isDefault ? "Sistem Tanımlı" : "Özel Bölüm"}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Add New Section Form */}
        <div className="p-4 rounded-2xl bg-slate-100/70 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
          <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-rose-500" />
            <span>Yeni Özel Bölüm / Kategori Ekle</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <input
              type="text"
              value={newSecNameInput}
              onChange={(e) => setNewSecNameInput(e.target.value)}
              placeholder="Bölüm Adı (Örn: Finans & Bütçe)"
              className="px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
            />
            <input
              type="text"
              value={newSecDescInput}
              onChange={(e) => setNewSecDescInput(e.target.value)}
              placeholder="Açıklama (Opsiyonel)"
              className="px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
            />
            <button
              type="button"
              onClick={() => {
                if (newSecNameInput.trim()) {
                  const newSec: SectionItem = {
                    id: `sec-${Date.now()}`,
                    name: newSecNameInput.trim(),
                    description: newSecDescInput.trim() || "Özel not alanı",
                    icon: "Folder",
                    color: "teal",
                  };
                  const updated = [...sectionsList, newSec];
                  setSectionsList(updated);
                  saveStoredSections(updated);
                  setNewSecNameInput("");
                  setNewSecDescInput("");
                  setSaveSuccessNotice(`Yeni bölüm eklendi: ${newSec.name}`);
                  setTimeout(() => setSaveSuccessNotice(null), 3000);
                }
              }}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Bölümü Oluştur</span>
            </button>
          </div>
        </div>
      </div>
      )}

      {/* ========================================================================= */}
      {/* 3. CUSTOMIZABLE MENU SECTIONS ORDERING                                    */}
      {/* ========================================================================= */}
      {(activeProfileTab === "menu_order" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
        <MenuSectionsManager
          menuOrder={menuOrder}
          onUpdateMenuOrder={onUpdateMenuOrder || (() => {})}
          themeAccent={themeAccent}
        />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 4. RADYAL MENÜ & ÇARKIFELEK ÖZELLEŞTİRME MERKEZİ                          */}
      {/* ========================================================================= */}
      {(activeProfileTab === "radial" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
        <RadialMenuSettings />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 4.5 SORUN ÇÖZME & OTOMATİK İYİLEŞTİRME MERKEZİ (TROUBLESHOOTING CENTER)   */}
      {/* ========================================================================= */}
      {(activeProfileTab === "troubleshooting" || activeProfileTab === "all") && (
      <div className="p-4 sm:p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
        <TroubleshootingCenter onNotify={(msg) => {
          setSaveSuccessNotice(msg);
          setTimeout(() => setSaveSuccessNotice(null), 3500);
        }} />
      </div>
      )}

      {/* ========================================================================= */}
      {/* 2. AKILLI KASA GÜVENLİK MERKEZİ & YENİ KASA KAYDI (TÜM İŞLER BÖLÜMÜ)   */}
      {/* ========================================================================= */}
      {(activeProfileTab === "vault" || activeProfileTab === "all") && (
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
        {/* Header & Quick Launch to Vault */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200/80 dark:border-emerald-800 flex items-center justify-center shrink-0 shadow-xs">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base font-black text-slate-900 dark:text-white">
                  Akıllı Kasa Güvenlik Merkezi & Yeni Kasa Kaydı
                </h2>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300/50 dark:border-emerald-800 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {vaultRecord ? `Kasa Kurulu (${vaultNotes.length} Güvenli Not)` : "Önceden Hazırlanmış Kurulum"}
                </span>
                {isVaultUnlocked && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                    🔓 Kilit Açık
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
                Askeri standart AES-256-GCM sıfır bilgi şifreleme ve PBKDF2 (120.000 döngü) ile korunan gizli notlarınız için tüm kasa işlemleri ve yeni kasa kaydı yönetimi.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-center shrink-0">
            <button
              type="button"
              onClick={() => {
                if (onNavigateToVaultTab) {
                  onNavigateToVaultTab();
                } else if (onOpenVault) {
                  onOpenVault();
                }
              }}
              className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-all cursor-pointer hover:shadow-md active:scale-95"
              title="Kasayı menüden veya modal olarak doğrudan aç"
            >
              <Shield className="w-4 h-4" />
              <span>Kasayı Menüden Aç</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80" />
            </button>
          </div>
        </div>

        {/* Feedback Alert if present */}
        {vaultFeedback && (
          <div
            className={`p-3.5 rounded-2xl text-xs font-semibold flex items-center justify-between gap-3 animate-in fade-in duration-150 ${
              vaultFeedback.type === "success"
                ? "bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200"
                : vaultFeedback.type === "error"
                ? "bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200"
                : "bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-200"
            }`}
          >
            <div className="flex items-center gap-2">
              {vaultFeedback.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : vaultFeedback.type === "error" ? (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              ) : (
                <Shield className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span>{vaultFeedback.message}</span>
            </div>
            <button
              onClick={() => setVaultFeedback(null)}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs font-bold px-1.5 py-0.5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* TÜM İŞLER TAB BAR (Kasa Yönetim Seçenekleri) */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80 overflow-x-auto text-xs font-bold scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveVaultTask("setup")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "setup"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Yeni Kasa Kaydı</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-extrabold">
              Önceden Hazır
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveVaultTask("change_pin")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "change_pin"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Şifre / PIN Değiştir</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveVaultTask("decoy")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "decoy"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Tuzak Kasa (Decoy PIN)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveVaultTask("security")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "security"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Güvenlik Sorusu & İpucu</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveVaultTask("recovery")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "recovery"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>12 Kelimelik Kurtarma Kiti</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveVaultTask("overview")}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeVaultTask === "overview"
                ? "bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Kasa Durumu & Rapor</span>
          </button>
        </div>

        {/* TAB 1: YENİ KASA KAYDI (ÖNCEDEN HAZIRLANMIŞ & SIFIRDAN KURULUM) */}
        {activeVaultTask === "setup" && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* Önceden Hazırlanmış Bilgi ve Tek Tıkla Kayıt Panosu */}
            <div className="p-4.5 rounded-2xl bg-linear-to-r from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-300/40 dark:border-emerald-800/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                    Daha Önceden Hazırlanmış Kasa Kaydı
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                  Yeni kasa kaydınız için güvenli parametreler (6 haneli PIN, güvenlik sorusu, tuzak PIN ve 12 kelimelik kurtarma tohumu) aşağıda hazırlandı. Dilerseniz hemen <strong>"Önceden Hazırlanmış Kasayı Kaydet"</strong> butonuna basabilir veya bilgileri özelleştirebilirsiniz.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={isProcessingSetup}
                  onClick={() => handleCompleteSetup(true)}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-all cursor-pointer hover:shadow-md"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{isProcessingSetup ? "Kaydediliyor..." : "Önceden Hazırlanmış Kasayı Kaydet"}</span>
                </button>
                <button
                  type="button"
                  onClick={handleGenerateRandomPin}
                  title="Rastgele yeni güvenli şifre / PIN üret"
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Rastgele Üret</span>
                </button>
              </div>
            </div>

            {/* Customization Form Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
              {/* 1. Şifre Tipi ve Ana Şifre Belirleme */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Kasa Şifresi / PIN Kodu</span>
                  </label>
                  <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[10px] font-bold">
                    <button
                      type="button"
                      onClick={() => setSetupPinType("pin")}
                      className={`px-2 py-0.5 rounded-md cursor-pointer ${
                        setupPinType === "pin"
                          ? "bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 shadow-2xs"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      Sayısal PIN
                    </button>
                    <button
                      type="button"
                      onClick={() => setSetupPinType("alphanumeric")}
                      className={`px-2 py-0.5 rounded-md cursor-pointer ${
                        setupPinType === "alphanumeric"
                          ? "bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 shadow-2xs"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      Parola
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <input
                    type={showSetupPin ? "text" : "password"}
                    value={setupPin}
                    onChange={(e) => setSetupPin(e.target.value)}
                    placeholder={setupPinType === "pin" ? "Örn. 123456" : "Güçlü şifrenizi girin"}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSetupPin(!showSetupPin)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showSetupPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Şifre Tekrarı */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                      Şifreyi Tekrar Doğrulayın
                    </label>
                    {setupPin && setupPin === setupPinConfirm ? (
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Eşleşiyor
                      </span>
                    ) : (
                      setupPinConfirm && (
                        <span className="text-[10px] font-bold text-rose-500">
                          Eşleşmiyor
                        </span>
                      )
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type={showSetupPinConfirm ? "text" : "password"}
                      value={setupPinConfirm}
                      onChange={(e) => setSetupPinConfirm(e.target.value)}
                      placeholder="Şifreyi tekrar yazın"
                      className={`w-full px-3.5 py-2.5 text-xs rounded-xl border bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 focus:ring-2 focus:ring-emerald-500 font-mono ${
                        setupPinConfirm && setupPin === setupPinConfirm
                          ? "border-emerald-400 dark:border-emerald-600"
                          : "border-slate-300 dark:border-slate-700"
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowSetupPinConfirm(!showSetupPinConfirm)}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    >
                      {showSetupPinConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Tuzak Kasa PIN (Stealth Decoy) */}
                <div className="pt-1">
                  <label className="text-[11px] font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                    <span>Tuzak Kasa PIN Kodu (Stealth Decoy)</span>
                    <span className="text-[10px] text-slate-400 font-normal">Zorlama durumunda</span>
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={setupDecoyPin}
                    onChange={(e) => setSetupDecoyPin(e.target.value)}
                    placeholder="9999"
                    className="w-full mt-1 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono"
                  />
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Birisi kasanızı zorla açtırmak isterse bu PIN girildiğinde tamamen boş bir sahte kasa açılır.
                  </p>
                </div>
              </div>

              {/* 2. Güvenlik Sorusu ve Kurtarma Ayarları */}
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5 mb-1">
                    <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Güvenlik Sorusu Seçimi</span>
                  </label>
                  <select
                    value={setupQuestion}
                    onChange={(e) => setSetupQuestion(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="İlk evcil hayvanınızın adı veya en sevdiğiniz şehir?">
                      İlk evcil hayvanınızın adı veya en sevdiğiniz şehir?
                    </option>
                    <option value="Çocukluk en yakın arkadaşınızın adı nedir?">
                      Çocukluk en yakın arkadaşınızın adı nedir?
                    </option>
                    <option value="İlk gittiğiniz ilkokulun adı nedir?">
                      İlk gittiğiniz ilkokulun adı nedir?
                    </option>
                    <option value="En sevdiğiniz film veya kitap nedir?">
                      En sevdiğiniz film veya kitap nedir?
                    </option>
                    <option value="custom">Özel Güvenlik Sorusu Belirle...</option>
                  </select>

                  {setupQuestion === "custom" && (
                    <input
                      type="text"
                      value={setupCustomQuestion}
                      onChange={(e) => setSetupCustomQuestion(e.target.value)}
                      placeholder="Özel güvenlik sorunuzu yazın"
                      className="w-full mt-2 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  )}
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
                    Güvenlik Sorusu Cevabı
                  </label>
                  <div className="relative">
                    <input
                      type={showSetupAnswer ? "text" : "password"}
                      value={setupAnswer}
                      onChange={(e) => setSetupAnswer(e.target.value)}
                      placeholder="Cevabınız (şifre unutulduğunda kurtarma sağlar)"
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 focus:ring-2 focus:ring-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSetupAnswer(!showSetupAnswer)}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    >
                      {showSetupAnswer ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
                      Şifre İpucu
                    </label>
                    <input
                      type="text"
                      value={setupHint}
                      onChange={(e) => setSetupHint(e.target.value)}
                      placeholder="Örn. Şehir adı"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
                      Otomatik Kilit
                    </label>
                    <select
                      value={setupAutoLock}
                      onChange={(e) => setSetupAutoLock(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    >
                      <option value={1}>1 Dakika</option>
                      <option value={5}>5 Dakika (Önerilen)</option>
                      <option value={15}>15 Dakika</option>
                      <option value={30}>30 Dakika</option>
                      <option value={0}>Kapalı (Manuel Kilit)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* 12 Kelimelik Acil Kurtarma Kiti Canlı Önizleme */}
            <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Önceden Hazırlanmış 12 Kelimelik Acil Kurtarma Tohumu (Mnemonic)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyMnemonic}
                    className="px-2.5 py-1 text-[11px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                  >
                    {hasCopiedMnemonic ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Kopyalandı</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Kopyala</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadRecoveryKit}
                    className="px-2.5 py-1 text-[11px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>.TXT İndir</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                {prePreparedWords.map((word, idx) => (
                  <div
                    key={idx}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-1.5 text-xs font-mono select-all"
                  >
                    <span className="text-[10px] font-extrabold text-slate-400 w-4">{idx + 1}.</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{word}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Submit & Activation Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Kaydet butonuna tıkladığınızda anahtarınız anında PBKDF2 ve AES-256 ile üretilir.
              </span>
              <button
                type="button"
                disabled={isProcessingSetup}
                onClick={() => handleCompleteSetup(false)}
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-black rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white shadow-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
              >
                <CheckCircle className="w-4 h-4" />
                <span>{isProcessingSetup ? "Kasa Kuruluyor..." : "Kasa Kaydını Tamamla ve Menüde Etkinleştir"}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: ŞİFRE / PIN DEĞİŞTİR */}
        {activeVaultTask === "change_pin" && (
          <div className="space-y-4 max-w-xl animate-in fade-in duration-150">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-emerald-600" />
                <span>Mevcut Şifreyi Doğrula ve Yeni Şifre Belirle</span>
              </h3>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Mevcut Kasa Şifreniz / PIN
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPin ? "text" : "password"}
                    value={currentPinInput}
                    onChange={(e) => setCurrentPinInput(e.target.value)}
                    placeholder="Mevcut şifrenizi girin"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPin(!showCurrentPin)}
                    className="absolute right-2.5 top-2.5 text-slate-400 cursor-pointer"
                  >
                    {showCurrentPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Yeni Şifre / PIN
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPin ? "text" : "password"}
                      value={newPinInput}
                      onChange={(e) => setNewPinInput(e.target.value)}
                      placeholder="En az 4 hane"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white pr-10 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPin(!showNewPin)}
                      className="absolute right-2.5 top-2.5 text-slate-400 cursor-pointer"
                    >
                      {showNewPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Yeni Şifre Tekrar
                  </label>
                  <input
                    type="password"
                    value={newPinConfirmInput}
                    onChange={(e) => setNewPinConfirmInput(e.target.value)}
                    placeholder="Tekrar yazın"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono"
                  />
                </div>
              </div>

              <button
                type="button"
                disabled={isChangingPin}
                onClick={handleChangePin}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <RotateCw className={`w-3.5 h-3.5 ${isChangingPin ? "animate-spin" : ""}`} />
                <span>{isChangingPin ? "Yeniden Şifreleniyor..." : "Şifreyi Değiştir ve Kasayı Yeniden Şifrele"}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: TUZAK KASA (DECOY PIN) */}
        {activeVaultTask === "decoy" && (
          <div className="space-y-4 max-w-xl animate-in fade-in duration-150">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-600" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                  Tuzak Kasa (Stealth Decoy PIN) Yapılandırması
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Tuzak Kasa, zorlama altında kasanızı açmanız istendiğinde girilebilecek ikinci bir sahte şifredir. Bu şifre girildiğinde sistem normal şekilde kilit açar ancak içinde hiçbir gerçek veri olmayan tamamen boş bir sahte kasa görüntüler.
              </p>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Tanımlı Tuzak PIN
                </label>
                <input
                  type="text"
                  maxLength={8}
                  value={customDecoyPin}
                  onChange={(e) => setCustomDecoyPin(e.target.value)}
                  className="w-full sm:w-60 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono font-bold"
                  placeholder="9999"
                />
              </div>

              <button
                type="button"
                disabled={isSavingDecoy}
                onClick={handleSaveDecoy}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{isSavingDecoy ? "Kaydediliyor..." : "Tuzak PIN'i Kaydet"}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: GÜVENLİK SORUSU & İPUCU */}
        {activeVaultTask === "security" && (
          <div className="space-y-4 max-w-xl animate-in fade-in duration-150">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-emerald-600" />
                <span>Kurtarma Sorusu ve Şifre İpucu Ayarları</span>
              </h3>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Güvenlik Sorusu
                </label>
                <input
                  type="text"
                  value={updateQuestion}
                  onChange={(e) => setUpdateQuestion(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Güvenlik Cevabı (Büyük/küçük harf duyarsız normalize edilir)
                </label>
                <input
                  type="text"
                  value={updateAnswer}
                  onChange={(e) => setUpdateAnswer(e.target.value)}
                  placeholder="Yeni cevabınızı giriniz"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Şifre İpucu
                </label>
                <input
                  type="text"
                  value={updateHint}
                  onChange={(e) => setUpdateHint(e.target.value)}
                  placeholder="Kilit ekranında gösterilecek ipucu"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setVaultFeedback({
                      type: "info",
                      message: "Güvenlik sorusu ve cevabını güncellemek için 'Şifre Değiştir' sekmesinden mevcut şifrenizi doğrulayarak kaydedebilirsiniz.",
                    });
                    setActiveVaultTask("change_pin");
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer flex items-center gap-1.5"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Şifre ile Birlikte Güncelle</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: 12 KELİMELİK KURTARMA KİTİ */}
        {activeVaultTask === "recovery" && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <span>Acil Durum 12 Kelimelik Tohum Anahtarı (Mnemonic Seed)</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Şifrenizi ve güvenlik sorunuzu tamamen unutsanız bile bu 12 kelime ile kasanızı kurtarabilirsiniz.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyMnemonic}
                    className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center gap-1.5 cursor-pointer"
                  >
                    {hasCopiedMnemonic ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{hasCopiedMnemonic ? "Kopyalandı" : "Panoya Kopyala"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadRecoveryKit}
                    className="px-3 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>.TXT Olarak İndir</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 pt-2">
                {prePreparedWords.map((word, idx) => (
                  <div
                    key={idx}
                    className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center gap-2 text-xs font-mono select-all"
                  >
                    <span className="text-[10px] font-extrabold text-slate-400 w-4">{idx + 1}.</span>
                    <span className="font-bold text-slate-800 dark:text-slate-100">{word}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: KASA DURUMU & KRİPTOGRAFİK RAPOR */}
        {activeVaultTask === "overview" && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Şifreleme Standardı</span>
                <p className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>AES-256-GCM</span>
                </p>
                <p className="text-[10px] text-slate-500">Sıfır bilgi & istemci taraflı WebCrypto</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Anahtar Türetme (KDF)</span>
                <p className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Hash className="w-4 h-4 text-teal-600" />
                  <span>PBKDF2 SHA-256</span>
                </p>
                <p className="text-[10px] text-slate-500">120.000 iterasyon & 16-byte kripto salt</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Kasa İçi Notlar</span>
                <p className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>{vaultNotes.length} Şifreli Not</span>
                </p>
                <p className="text-[10px] text-slate-500">{isVaultUnlocked ? "Kilit Açık (Görüntülenebilir)" : "Kilitli (Korumalı)"}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSyncVaultStatsToProfile}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Kasa Raporunu Senkronizasyon Günlüğüne Ekle</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                {showResetConfirm ? (
                  <div className="flex items-center gap-2 p-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800">
                    <span className="text-xs font-bold text-rose-700 dark:text-rose-300 px-2">
                      Emin misiniz?
                    </span>
                    <button
                      type="button"
                      onClick={handleResetVault}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg bg-rose-600 text-white hover:bg-rose-700 cursor-pointer"
                    >
                      Evet, Sıfırla
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowResetConfirm(false)}
                      className="px-2 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded cursor-pointer"
                    >
                      Vazgeç
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowResetConfirm(true)}
                    className="px-3 py-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Kasayı Sıfırla / Sıfırdan Yeni Kurulum Başlat</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      )}

      {/* ========================================================================= */}
      {/* 5. HİBRİT SENKRONİZASYON, BULUT & VERİ GÜNLÜĞÜ                           */}
      {/* ========================================================================= */}
      {(activeProfileTab === "sync" || activeProfileTab === "all") && (
      <>
      {/* 2.5. HİBRİT SENKRONİZASYON & VERİ TABANI MERKEZİ */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  Hibrit Senkronizasyon & Veri Durumu
                </h3>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  IndexedDB + Bulut
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Notlarınız yerel cihazınızda sıfır gecikmeyle saklanır, internete bağlanıldığında bulut ile çift yönlü eşitlenir.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
            <OfflineSyncBadge />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ağ Bağlantısı</span>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Wifi className="w-4 h-4 text-emerald-500" />
              <span>{typeof navigator !== "undefined" && navigator.onLine ? "Çevrim içi (Online)" : "Çevrim dışı (Offline)"}</span>
            </p>
            <p className="text-[10px] text-slate-500">Otomatik ağ geçişi aktif</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Yerel Depolama</span>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Database className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>IndexedDB + LocalStorage</span>
            </p>
            <p className="text-[10px] text-slate-500">{notes.length} not cihazda güvende</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Eşitleme Modu</span>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <RefreshCw className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>Otomatik Arka Plan</span>
            </p>
            <p className="text-[10px] text-slate-500">Kesintisiz hibrit mimari</p>
          </div>
        </div>
      </div>

      {/* 3. CONNECTED CHANNELS & AUTO-SYNC HUB */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Gmail / E-Posta Card */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Mail className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              {profile.isLoggedIn ? "Aktif & Bağlı" : "Hazır"}
            </span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Gmail & E-Posta Arşivi
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 break-all">
              {profile.email || "enes02erdm@gmail.com"}
            </p>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
            Notlarınızı doğrudan e-posta kutunuza formatlanmış HTML ve özet olarak yedekler.
          </p>
          <a
            href={`mailto:${profile.email}?subject=NoteFlow%20Yedekleme&body=NoteFlow%20hesab%C4%B1mdan%20al%C4%B1nan%20notlar.`}
            className="block text-center py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
          >
            E-Posta İstemcisinde Aç
          </a>
        </div>

        {/* Google Drive / Cloud Card */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Cloud className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
              Bulut Yedek Açık
            </span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Google Drive / Bulut Depolama
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Klasör: NoteFlow Notlarım
            </p>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
            Notlarınız yerel güvenli depolama ve bulut senkronizasyon havuzunda korunur.
          </p>
          <button
            onClick={() => alert("Bulut yedekleme dizini senkronize edildi.")}
            className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
          >
            Bulut Durumunu Doğrula
          </button>
        </div>

        {/* Social Media & Sharing Card */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
              𝕏
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              Paylaşım Hazır
            </span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Sosyal Medya & X (Twitter)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Bağlantı: {profile.xHandle || "@eneserdm"}
            </p>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
            Seçili notlarınızı tek dokunuşla sosyal ağlarda infografik veya özet olarak paylaşın.
          </p>
          <a
            href={`https://twitter.com/intent/tweet?text=NoteFlow%20ile%20notlar%C4%B1m%C4%B1%20ve%20bilgi%20haritalar%C4%B1m%C4%B1%20d%C3%BCzenliyorum!`}
            target="_blank"
            rel="noreferrer"
            className="block text-center py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
          >
            X Üzerinde Paylaş
          </a>
        </div>
      </div>

      {/* 3. SYNCED NOTES HISTORY / KAYDOLUNAN NOTLAR LİSTESİ */}
      <div className="p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Kaydolunan ve Senkronize Edilen Notlar</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                {filteredLogs.length} Kayıt
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              E-postaya, buluta veya sosyal medya kanallarına aktarılan notların anlık geçmişi
            </p>
          </div>

          <div className="flex items-center gap-2">
            {syncLogs.length > 0 && (
              <button
                onClick={() => {
                  if (window.confirm("Senkronizasyon geçmişini temizlemek istiyor musunuz?")) {
                    onClearSyncLogs();
                  }
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
              >
                Geçmişi Temizle
              </button>
            )}
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchLogQuery}
              onChange={(e) => setSearchLogQuery(e.target.value)}
              placeholder="Senkronize edilen notlarda ara..."
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
            <button
              onClick={() => setSelectedChannelFilter("all")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedChannelFilter === "all"
                  ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 font-bold shadow-xs"
                  : "text-slate-600 dark:text-slate-400"
              }`}
            >
              Tüm Kanallar
            </button>
            <button
              onClick={() => setSelectedChannelFilter("email")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedChannelFilter === "email"
                  ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 font-bold shadow-xs"
                  : "text-slate-600 dark:text-slate-400"
              }`}
            >
              Gmail
            </button>
            <button
              onClick={() => setSelectedChannelFilter("gdrive")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedChannelFilter === "gdrive"
                  ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-300 font-bold shadow-xs"
                  : "text-slate-600 dark:text-slate-400"
              }`}
            >
              Google Drive
            </button>
          </div>
        </div>

        {/* Synced Records List */}
        {filteredLogs.length === 0 ? (
          <div className="text-center py-16 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
            <Cloud className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              Henüz Senkronizasyon Kaydı Yok
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
              Notlarınızı "E-postaya / Profile Senkronize Et" butonuyla veya yukarıdaki "Tümünü E-Postaya Yedekle" butonuyla aktarabilirsiniz.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredLogs.map((log) => {
              const matchedNote = notes.find((n) => n.id === log.noteId);
              return (
                <div
                  key={log.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-teal-300 dark:hover:border-teal-800 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                      {log.channelType === "email" ? (
                        <Mail className="w-4 h-4" />
                      ) : log.channelType === "gdrive" ? (
                        <Cloud className="w-4 h-4" />
                      ) : (
                        <Share2 className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {log.noteTitle}
                        </h4>
                        <span className="text-[10px] font-bold px-2 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>Kaydedildi</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        <span>Hedef: <strong>{log.destination}</strong></span>
                        <span>•</span>
                        <span>{new Date(log.timestamp).toLocaleString("tr-TR")}</span>
                      </div>
                      {log.details && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 line-clamp-1">
                          {log.details}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {matchedNote && (
                      <button
                        onClick={() => onOpenNote(matchedNote)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Notu Aç</span>
                      </button>
                    )}
                    <a
                      href={`mailto:${profile.email}?subject=${encodeURIComponent(log.noteTitle)}&body=${encodeURIComponent(log.details || log.noteTitle)}`}
                      title="E-postada Görüntüle"
                      className="p-2 rounded-xl text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      </>
      )}

      {/* Global & Profile Auth Modal (Email/Password, Google, Apple) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentProfile={profile}
        initialMode={authModalMode}
        onSuccess={(updatedProfile) => {
          onUpdateProfile(updatedProfile);
          setSaveSuccessNotice(`✓ Hoş geldiniz, ${updatedProfile.name}! Tüm yapay zeka araçları kullanıma açıldı.`);
          setTimeout(() => setSaveSuccessNotice(null), 4000);
        }}
      />
    </div>
  );
};
