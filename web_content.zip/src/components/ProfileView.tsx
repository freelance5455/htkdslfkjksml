import React, { useState } from 'react';
import { 
  Camera, 
  MapPin, 
  Link as LinkIcon, 
  Calendar, 
  Edit3, 
  Share2, 
  UserPlus, 
  UserCheck, 
  Grid, 
  Film, 
  Image as ImageIcon, 
  Info,
  ShieldCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { UserProfile } from '../types';
import { PostCard } from './PostCard';
import { EditProfileModal } from './EditProfileModal';
import { SafeVideo } from './SafeVideo';

interface ProfileViewProps {
  targetUserId?: string;
  onOpenCreatePost: () => void;
  onSelectReel?: (reelId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ 
  targetUserId, 
  onOpenCreatePost 
}) => {
  const { user: currentUser, allUsers } = useAuth();
  const { posts, reels } = useSocial();

  const [activeTab, setActiveTab] = useState<'posts' | 'reels' | 'photos' | 'about'>('posts');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  // Find user or default to current user
  const profileUser: UserProfile = (targetUserId 
    ? allUsers.find(u => u.id === targetUserId) 
    : currentUser) || currentUser || allUsers[0];

  const isSelf = currentUser?.id === profileUser.id;

  const userPosts = posts.filter(p => p.authorId === profileUser.id || p.authorUsername === profileUser.username);
  const userReels = reels.filter(r => r.authorId === profileUser.id || r.authorUsername === profileUser.username);
  const userPhotos = posts.filter(p => (p.authorId === profileUser.id || p.authorUsername === profileUser.username) && p.mediaType === 'image' && p.mediaUrl);

  const handleShareProfile = () => {
    const url = window.location.origin + '/#profile-' + profileUser.id;
    if (navigator.share) {
      navigator.share({
        title: `${profileUser.displayName} on FaceLook`,
        url,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url);
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-16">
      
      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden mb-4">
        
        {/* Cover Photo */}
        <div className="relative h-44 sm:h-64 bg-slate-200">
          <img
            src={profileUser.coverURL || 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80'}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          {isSelf && (
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="absolute bottom-3 right-3 bg-white/90 hover:bg-white text-slate-800 text-xs font-bold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1.5 cursor-pointer backdrop-blur-xs transition-colors"
            >
              <Camera className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Edit cover photo</span>
            </button>
          )}
        </div>

        {/* Profile Details Section */}
        <div className="px-4 sm:px-6 pb-4">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-16 sm:-mt-20 gap-4 mb-4">
            
            {/* Avatar & Names */}
            <div className="flex flex-col sm:flex-row sm:items-end gap-3.5">
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-full overflow-hidden ring-4 ring-white shadow-xl bg-white shrink-0">
                <img
                  src={profileUser.photoURL}
                  alt={profileUser.displayName}
                  className="w-full h-full object-cover"
                />
                {isSelf && (
                  <button
                    onClick={() => setIsEditModalOpen(true)}
                    className="absolute bottom-1 right-1 w-8 h-8 rounded-full bg-[#1877F2] text-white flex items-center justify-center ring-2 ring-white shadow-sm hover:scale-105 transition-transform cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="mt-1 sm:mt-0">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {profileUser.displayName}
                  </h1>
                  {profileUser.isVerified && (
                    <span className="text-blue-500 text-sm font-bold" title="Verified Creator">✓</span>
                  )}
                  {profileUser.role === 'admin' && (
                    <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-200">
                      <ShieldCheck className="w-3 h-3 text-amber-600" />
                      Admin
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">@{profileUser.username}</p>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-600 font-medium">
                  <span><strong className="text-slate-900">{profileUser.followersCount + (isFollowing ? 1 : 0)}</strong> followers</span>
                  <span>•</span>
                  <span><strong className="text-slate-900">{profileUser.followingCount}</strong> following</span>
                </div>
              </div>
            </div>

            {/* Profile Action Buttons */}
            <div className="flex items-center gap-2">
              {isSelf ? (
                <>
                  <button
                    onClick={() => setIsEditModalOpen(true)}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm px-4 py-2 rounded-xl transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>Edit Profile</span>
                  </button>
                  <button
                    onClick={handleShareProfile}
                    className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsFollowing(!isFollowing)}
                    className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 font-bold text-xs sm:text-sm px-5 py-2 rounded-xl transition-all cursor-pointer shadow-sm ${
                      isFollowing 
                        ? 'bg-slate-100 text-slate-800 hover:bg-slate-200' 
                        : 'bg-[#1877F2] text-white hover:bg-blue-600'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleShareProfile}
                    className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>

          </div>

          {/* Bio & Metadata */}
          {profileUser.bio && (
            <p className="text-sm text-slate-700 leading-relaxed mb-3 max-w-2xl whitespace-pre-line">
              {profileUser.bio}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-slate-500 pt-1">
            {profileUser.location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {profileUser.location}
              </span>
            )}
            {profileUser.website && (
              <a 
                href={profileUser.website}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-[#1877F2] hover:underline"
              >
                <LinkIcon className="w-3.5 h-3.5" />
                {profileUser.website.replace(/^https?:\/\//, '')}
              </a>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Joined {new Date(profileUser.createdAt).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </span>
          </div>

        </div>

        {/* Navigation Tabs */}
        <div className="border-t border-slate-100 flex items-center justify-around sm:justify-start sm:gap-8 px-4 sm:px-6">
          <button
            onClick={() => setActiveTab('posts')}
            className={`py-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'posts' 
                ? 'border-[#1877F2] text-[#1877F2]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Grid className="w-4 h-4" />
            <span>Posts ({userPosts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reels')}
            className={`py-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'reels' 
                ? 'border-[#1877F2] text-[#1877F2]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Reels ({userReels.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('photos')}
            className={`py-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'photos' 
                ? 'border-[#1877F2] text-[#1877F2]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Photos ({userPhotos.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`py-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'about' 
                ? 'border-[#1877F2] text-[#1877F2]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>About</span>
          </button>
        </div>

      </div>

      {/* Tab Contents */}
      {activeTab === 'posts' && (
        <div>
          {isSelf && (
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 mb-4 flex items-center justify-between">
              <span className="text-sm font-bold text-slate-800">Share with followers</span>
              <button
                onClick={onOpenCreatePost}
                className="bg-[#1877F2] hover:bg-blue-600 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors cursor-pointer"
              >
                Create Post
              </button>
            </div>
          )}

          {userPosts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
              No posts published yet.
            </div>
          ) : (
            userPosts.map(p => (
              <PostCard key={p.id} post={p} />
            ))
          )}
        </div>
      )}

      {activeTab === 'reels' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {userReels.length === 0 ? (
            <div className="col-span-full bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
              No short-form video reels uploaded yet.
            </div>
          ) : (
            userReels.map(r => (
              <div 
                key={r.id}
                className="relative aspect-9/16 rounded-2xl overflow-hidden bg-black shadow-xs group"
              >
                <SafeVideo
                  src={r.videoUrl}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  muted
                  playsInline
                />
                <div className="absolute inset-0 bg-linear-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-3">
                  <p className="text-white text-xs font-semibold line-clamp-2">{r.caption}</p>
                  <span className="text-[10px] text-white/70 mt-1">❤️ {r.likesCount}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'photos' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {userPhotos.length === 0 ? (
            <div className="col-span-full bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
              No gallery photos uploaded yet.
            </div>
          ) : (
            userPhotos.map(p => (
              <div 
                key={p.id}
                className="aspect-square rounded-2xl overflow-hidden bg-slate-100 shadow-xs group"
              >
                <img
                  src={p.mediaUrl}
                  alt="Gallery"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'about' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <h3 className="font-bold text-base text-slate-900 border-b border-slate-100 pb-2">About {profileUser.displayName}</h3>
          
          <div className="space-y-3 text-sm">
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Email</p>
              <p className="font-medium text-slate-800">{profileUser.email}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Account Role</p>
              <p className="font-medium text-slate-800 capitalize">{profileUser.role}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Location</p>
              <p className="font-medium text-slate-800">{profileUser.location || 'Not specified'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold uppercase">Bio</p>
              <p className="font-medium text-slate-800">{profileUser.bio || 'No bio provided'}</p>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />

    </div>
  );
};
