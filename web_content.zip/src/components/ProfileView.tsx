import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ConfessionCard } from './ConfessionCard';
import { 
  ShieldCheck, 
  Key, 
  Dices, 
  Calendar, 
  Sparkles, 
  Crown, 
  Lock, 
  LogOut, 
  Bookmark, 
  Award, 
  Clock, 
  CheckCircle2, 
  HelpCircle,
  ArrowLeft,
  ArrowUpCircle,
  RefreshCw 
} from 'lucide-react';
import { CURRENT_APP_VERSION, fetchLatestVersion } from '../utils/versionCheck';
import { AppUpdateModal } from './AppUpdateModal';

export const ProfileView: React.FC = () => {
  const { 
    user, 
    rerollPersona, 
    logoutUser, 
    confessions, 
    setIsPremiumModalOpen,
    setIsCollegeModalOpen,
    setActiveTab 
  } = useApp();

  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<string | null>(null);

  const handleManualCheckUpdate = async () => {
    setIsCheckingUpdate(true);
    setUpdateMessage(null);
    const info = await fetchLatestVersion();
    setIsCheckingUpdate(false);
    if (info) {
      setShowUpdateModal(true);
    } else {
      setUpdateMessage('Secret Gossip is up to date!');
      setTimeout(() => setUpdateMessage(null), 3000);
    }
  };

  const savedConfessions = confessions.filter(c => user.savedPostIds.includes(c.id));
  const myPostedConfessions = confessions.filter(c => c.authorHash === user.secretHashId);

  return (
    <div className="space-y-4 pb-20">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>

      {/* Profile ID Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-[#0d1222] to-slate-950 border border-cyan-500/30 p-5 sm:p-6 shadow-xl neon-glow-cyan">
        
        {/* Glow orb */}
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-cyan-950/70 border-2 border-cyan-400 flex items-center justify-center text-3xl shadow-lg">
                {user.avatarEmoji}
              </div>
              <button
                onClick={rerollPersona}
                title="Reroll Anonymous Mask"
                className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-slate-900 border border-cyan-400 flex items-center justify-center text-cyan-300 hover:scale-110 active:scale-95 transition-transform"
              >
                <Dices className="w-3.5 h-3.5" />
              </button>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-lg text-slate-100">
                  {user.avatarName}
                </h2>
                {user.isPremium && (
                  <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-bold">
                    <Crown className="w-3 h-3" /> VIP
                  </span>
                )}
              </div>

              {/* Cryptographic Hidden ID */}
              <div className="flex items-center gap-1.5 mt-0.5">
                <Lock className="w-3 h-3 text-cyan-400" />
                <span className="font-mono text-xs text-cyan-300 tracking-wider font-semibold">
                  {user.secretHashId}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">(Zero-Leak Hash)</span>
              </div>

              {/* College & Class */}
              <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                <span className="text-slate-300 font-medium">🏛️ {user.collegeName}</span>
                <span aria-hidden="true">·</span>
                <span>{user.classInfo}</span>
              </div>
            </div>
          </div>

          {/* Quick Karma & Coins Stat */}
          <div className="sm:text-right flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-800 gap-2">
            <div className="flex sm:flex-col items-baseline sm:items-end gap-3 sm:gap-0">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Karma
                </span>
                <span className="font-mono text-xl sm:text-2xl font-black text-cyan-400 tabular-nums">
                  {user.karma}
                </span>
              </div>
              <div className="sm:mt-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                  Secret Coins
                </span>
                <span className="font-mono text-xl sm:text-2xl font-black text-amber-300 tabular-nums flex items-center sm:justify-end gap-1">
                  <span>🪙</span>
                  <span>{user.secretCoins}</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-1">
              <button
                onClick={() => setActiveTab('referral')}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs transition-all flex items-center gap-1"
              >
                <span>Invite & Earn</span>
              </button>
              <button
                onClick={() => setIsPremiumModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>VIP</span>
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Security Architecture & Cooldown Status Card */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Campus Verification & Lock Status</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">Class Info Lock</span>
            <div className="flex items-center gap-1.5 font-semibold text-slate-200">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{user.classInfo}</span>
            </div>
            <p className="text-[10px] text-slate-500">
              Locked until next academic cycle ({user.cooldownDaysRemaining} days remaining).
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
            <span className="text-slate-400 block text-[11px]">Server Mask Protection</span>
            <div className="flex items-center gap-1.5 font-semibold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Admins Cannot See Real Email/Phone</span>
            </div>
            <p className="text-[10px] text-slate-500">
              Your real contact details are strictly one-way salted and hashed.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <button
            onClick={() => setIsCollegeModalOpen(true)}
            className="text-xs text-cyan-400 hover:underline font-medium"
          >
            Update College Campus Token →
          </button>
          <button
            onClick={logoutUser}
            className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 font-medium"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Switch / Logout</span>
          </button>
        </div>
      </div>

      {/* In-App Live Update & Version Center */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900/90 to-slate-950/90 border border-cyan-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <ArrowUpCircle className="w-4 h-4 text-cyan-400" />
              <span>Secret Gossip App Version</span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-mono font-bold">
              v{CURRENT_APP_VERSION}
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            {updateMessage || 'OTA Live Sync enabled · In-app updates supported'}
          </p>
        </div>

        <button
          onClick={handleManualCheckUpdate}
          disabled={isCheckingUpdate}
          className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isCheckingUpdate ? 'animate-spin' : ''}`} />
          <span>{isCheckingUpdate ? 'Checking...' : 'Check for Updates'}</span>
        </button>
      </div>

      {showUpdateModal && (
        <AppUpdateModal 
          forceOpen={true} 
          onClose={() => setShowUpdateModal(false)} 
        />
      )}

      {/* Badges Earned */}
      <div className="space-y-2.5">
        <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-1.5">
          <Award className="w-4 h-4 text-purple-400" />
          <span>Earned Badges</span>
        </h3>
        <div className="flex flex-wrap gap-2">
          {user.badges.map((badge, i) => (
            <div 
              key={i}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-purple-500/40 text-xs font-medium text-purple-200 shadow-sm"
            >
              <Sparkles className="w-3 h-3 text-purple-400" />
              <span>{badge}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Saved Bookmarks */}
      <div className="space-y-3 pt-2">
        <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-1.5">
          <Bookmark className="w-4 h-4 text-amber-400" />
          <span>Saved Whispers ({savedConfessions.length})</span>
        </h3>

        {savedConfessions.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-slate-400 text-xs">
            No saved whispers yet. Tap the bookmark icon on any confession card to save it here.
          </div>
        ) : (
          <div className="space-y-3">
            {savedConfessions.map(c => (
              <ConfessionCard key={c.id} confession={c} />
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
