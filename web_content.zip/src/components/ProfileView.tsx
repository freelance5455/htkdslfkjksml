import React, { useState } from 'react';
import { 
  User as UserIcon, 
  ShieldCheck, 
  Award, 
  FileText, 
  Bookmark, 
  Heart, 
  MapPin, 
  School, 
  Calendar, 
  Lock, 
  Key, 
  CheckCircle2, 
  Sparkles, 
  Upload, 
  Users
} from 'lucide-react';
import { User, Paper, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';
import { PaperCard } from './PaperCard';

interface ProfileViewProps {
  user: User;
  language: Language;
  papers: Paper[];
  onSelectPaper: (paper: Paper) => void;
  onBookmarkToggle: (paperId: string) => void;
  onLikeToggle: (paperId: string) => void;
  onDownloadPaper: (paper: Paper) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  language,
  papers,
  onSelectPaper,
  onBookmarkToggle,
  onLikeToggle,
  onDownloadPaper
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'UPLOADS' | 'SAVED' | 'LIKED' | 'SECURITY'>('UPLOADS');
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(user.isTwoFactorEnabled);

  const myUploadedPapers = papers.filter((p) => p.uploaderId === user.id || p.uploaderName === user.name);
  const mySavedPapers = papers.filter((p) => user.savedPaperIds.includes(p.id));
  const myLikedPapers = papers.filter((p) => user.likedPaperIds.includes(p.id));

  // Calculate level progress
  const nextLevelPoints = user.level * 500;
  const levelProgress = Math.min(100, Math.round((user.points / nextLevelPoints) * 100));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner & Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative">
        
        {/* Cover Photo */}
        <div className="h-48 sm:h-64 bg-slate-800 relative">
          {user.coverImage ? (
            <img src={user.coverImage} alt="Cover" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 opacity-80" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
        </div>

        {/* Profile Info Overlay */}
        <div className="px-6 pb-6 relative -mt-16 sm:-mt-20 flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-24 h-24 sm:w-32 sm:h-32 rounded-3xl object-cover ring-4 ring-slate-900 shadow-2xl bg-slate-800"
            />
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-white">{user.name}</h1>
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <span className="px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider rounded-full bg-amber-500 text-slate-950">
                  {user.role}
                </span>
              </div>
              <p className="text-xs text-slate-300 max-w-xl">{user.bio}</p>
              <div className="flex items-center gap-4 text-xs text-slate-400 pt-1 flex-wrap">
                <span className="flex items-center gap-1">
                  <School className="w-3.5 h-3.5 text-amber-400" />
                  <span>{user.school || 'National School'}</span>
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>{user.province} Province</span>
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>Joined {user.joinedDate}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Gamification Level & Stats Widget */}
          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-2xl w-full md:w-64 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-300">Gamification Level {user.level}</span>
              <span className="font-black text-amber-400">{user.points} Pts</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-gradient-to-r from-amber-500 to-amber-400 h-full" style={{ width: `${levelProgress}%` }}></div>
            </div>
            <p className="text-[10px] text-slate-400 text-right">{levelProgress}% to Level {user.level + 1}</p>
          </div>
        </div>

        {/* Badges Bar */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
          <span className="text-xs font-bold text-slate-400 shrink-0">Achievements:</span>
          {user.badges.map((badge, idx) => (
            <span key={idx} className="px-3 py-1 text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-xl flex items-center gap-1 shrink-0">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>{badge}</span>
            </span>
          ))}
        </div>

      </div>

      {/* Tabs Row */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto">
        <button
          onClick={() => setActiveTab('UPLOADS')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'UPLOADS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Uploaded Papers ({myUploadedPapers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('SAVED')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'SAVED' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Saved Papers ({mySavedPapers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('LIKED')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'LIKED' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Liked Papers ({myLikedPapers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('SECURITY')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'SECURITY' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Lock className="w-4 h-4" />
          <span>Security & 2FA</span>
        </button>
      </div>

      {/* Tab Content Display */}
      {activeTab === 'UPLOADS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {myUploadedPapers.map((paper) => (
            <PaperCard
              key={paper.id}
              paper={paper}
              language={language}
              onSelect={onSelectPaper}
              onBookmarkToggle={onBookmarkToggle}
              isBookmarked={user.savedPaperIds.includes(paper.id)}
              onLikeToggle={onLikeToggle}
              isLiked={user.likedPaperIds.includes(paper.id)}
              onDownload={onDownloadPaper}
            />
          ))}
        </div>
      )}

      {activeTab === 'SAVED' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {mySavedPapers.map((paper) => (
            <PaperCard
              key={paper.id}
              paper={paper}
              language={language}
              onSelect={onSelectPaper}
              onBookmarkToggle={onBookmarkToggle}
              isBookmarked={true}
              onLikeToggle={onLikeToggle}
              isLiked={user.likedPaperIds.includes(paper.id)}
              onDownload={onDownloadPaper}
            />
          ))}
        </div>
      )}

      {activeTab === 'LIKED' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {myLikedPapers.map((paper) => (
            <PaperCard
              key={paper.id}
              paper={paper}
              language={language}
              onSelect={onSelectPaper}
              onBookmarkToggle={onBookmarkToggle}
              isBookmarked={user.savedPaperIds.includes(paper.id)}
              onLikeToggle={onLikeToggle}
              isLiked={true}
              onDownload={onDownloadPaper}
            />
          ))}
        </div>
      )}

      {activeTab === 'SECURITY' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-2xl space-y-6 shadow-2xl">
          <h3 className="text-base font-extrabold text-white flex items-center gap-2">
            <Lock className="w-5 h-5 text-amber-400" />
            <span>Account Security & Verification</span>
          </h3>

          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-white">Email Verification</p>
              <p className="text-[11px] text-slate-400">{user.email}</p>
            </div>
            <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-xs font-bold rounded-full border border-emerald-500/20 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Verified</span>
            </span>
          </div>

          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-white">Two-Factor Authentication (2FA)</p>
              <p className="text-[11px] text-slate-400">Protects your LankaPaperHub account with authenticator codes</p>
            </div>
            <button
              onClick={() => setTwoFactorEnabled(!twoFactorEnabled)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                twoFactorEnabled
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {twoFactorEnabled ? '2FA Active' : 'Enable 2FA'}
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
