import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, Post, FriendItem, FollowItem, UserGiftRecord, GiftItem, PaymentRequest } from '../types';
import { AVAILABLE_GIFTS, purchaseGift } from '../gifts';
import { AdminDashboard } from './AdminDashboard';
import { 
  db, 
  auth, 
  signOut, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { 
  doc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  setDoc, 
  deleteDoc, 
  onSnapshot,
  limit,
  increment
} from 'firebase/firestore';
import { ZahraHeaderLogo } from './ZahraHeaderLogo';
import { compressImageFile } from '../imageUtils';
import { claimDailyBonusFn, walletErrorMessage } from '../wallet';
import { WalletPanel } from './WalletPanel';
import { TOPUP_PACKAGES, VODAFONE_CASH_NUMBER } from '../economy';
import { 
  Settings, 
  Camera, 
  Calendar, 
  Edit3, 
  User, 
  Image as ImageIcon, 
  Wallet, 
  Gift, 
  LogOut, 
  ChevronLeft, 
  X, 
  Check, 
  Sparkles, 
  Plus, 
  Bell, 
  ShieldCheck, 
  Volume2, 
  Users, 
  UserPlus, 
  UserMinus,
  Heart, 
  Loader2,
  Trash2,
  Search,
  MessageCircle,
  Compass,
  ShoppingBag,
  Coins,
  Send,
  CheckCircle2,
  AlertCircle,
  Phone,
  Copy,
  Download
} from 'lucide-react';

interface ProfileViewProps {
  currentUser: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onLogout: () => void;
  onNavigateToPosts?: () => void;
  onNavigateToRooms?: () => void;
  onNavigateToChats?: () => void;
  onOpenExport?: () => void;
}

type ActiveModal = null | 'editProfile' | 'editBirthday' | 'photosPosts' | 'wallet' | 'gifts' | 'settings' | 'changeAvatar' | 'socialNetwork';
type SocialTab = 'friends' | 'following' | 'followers' | 'discover';

interface CommunityMember {
  id: string;
  displayName: string;
  username: string;
  photoURL: string;
  bio: string;
  badge: string;
  isOnline: boolean;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ 
  currentUser, 
  onUpdateProfile, 
  onLogout,
  onNavigateToPosts,
  onNavigateToRooms,
  onNavigateToChats,
  onOpenExport
}) => {
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [socialTab, setSocialTab] = useState<SocialTab>('friends');
  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Real Social Network Collections in Firestore
  const [friendsList, setFriendsList] = useState<FriendItem[]>([]);
  const [followingList, setFollowingList] = useState<FollowItem[]>([]);
  const [followersList, setFollowersList] = useState<FollowItem[]>([]);
  const [searchMemberQuery, setSearchMemberQuery] = useState('');

  // Form states for profile editing
  const [displayName, setDisplayName] = useState(currentUser.displayName || 'عضو زهرة شات');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [birthDate, setBirthDate] = useState(currentUser.birthDate || '');
  const [photoURL, setPhotoURL] = useState(currentUser.photoURL || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80');
  const [phone, setPhone] = useState(currentUser.phone || '');

  // Birthday inline edit state
  const [inlineBirthday, setInlineBirthday] = useState(currentUser.birthDate || '');

  // User posts & photos state
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [newPostText, setNewPostText] = useState('');
  const [newPostSelectedImage, setNewPostSelectedImage] = useState<string | null>(null);
  const postGalleryRef = useRef<HTMLInputElement>(null);

  // Wallet states
  const [dailyClaimed, setDailyClaimed] = useState(
    (currentUser as UserProfile & { lastDailyClaimDay?: number }).lastDailyClaimDay === Math.floor(Date.now() / 86400000)
  );
  const [showVodafoneModal, setShowVodafoneModal] = useState(false);
  const [vodafoneSenderPhone, setVodafoneSenderPhone] = useState('');
  const [vodafoneTxRef, setVodafoneTxRef] = useState('');
  const [selectedVodafonePackage, setSelectedVodafonePackage] = useState<{ id: string; amount: string; price: string; coins: number; flowers: number }>({
    id: TOPUP_PACKAGES[0].id,
    amount: TOPUP_PACKAGES[0].coins.toLocaleString('en-US'),
    price: `${TOPUP_PACKAGES[0].price} ج.م`,
    coins: TOPUP_PACKAGES[0].coins,
    flowers: TOPUP_PACKAGES[0].flowers
  });
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [myPaymentRequests, setMyPaymentRequests] = useState<PaymentRequest[]>([]);
  const [communityMembers, setCommunityMembers] = useState<CommunityMember[]>([]);

  // Sign out & Admin states
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);

  const isAppOwner = currentUser.email?.toLowerCase() === 'smsmsohag20@gmail.com' || currentUser.email?.toLowerCase() === 'smsm.sohag@gmail.com';

  // Listen to user's Vodafone Cash recharge requests
  useEffect(() => {
    if (!currentUser?.uid) return;
    const paymentsRef = collection(db, 'payment_requests');
    const q = query(paymentsRef, where('userId', '==', currentUser.uid));
    const unsub = onSnapshot(q, (snapshot) => {
      const list: PaymentRequest[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as PaymentRequest);
      });
      list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      setMyPaymentRequests(list);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // Load real registered members for the "discover" tab
  useEffect(() => {
    if (!currentUser?.uid) return;
    const unsub = onSnapshot(
      query(collection(db, 'users'), limit(60)),
      (snapshot) => {
        const list: CommunityMember[] = [];
        snapshot.forEach((d) => {
          if (d.id === currentUser.uid) return;
          const data = d.data() as UserProfile;
          list.push({
            id: d.id,
            displayName: data.displayName || 'عضو زهرة شات',
            username: data.username || d.id.slice(0, 8),
            photoURL: data.photoURL || '',
            bio: data.bio || '',
            badge: data.badge || 'عضو مميز 🌸',
            isOnline: false
          });
        });
        setCommunityMembers(list);
      },
      (err) => console.error('Members listener error:', err)
    );
    return () => unsub();
  }, [currentUser?.uid]);

  // Settings states
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundsEnabled, setSoundsEnabled] = useState(true);
  const [privateAccount, setPrivateAccount] = useState(false);

  // File upload input ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 1. Subscribe to REAL FRIENDS in Firestore
  useEffect(() => {
    if (!currentUser?.uid) return;
    const friendsRef = collection(db, 'users', currentUser.uid, 'friends');
    const unsub = onSnapshot(friendsRef, (snapshot) => {
      const list: FriendItem[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as FriendItem);
      });
      setFriendsList(list);
    }, (err) => {
      console.warn('Real friends listener fallback:', err);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // 2. Subscribe to REAL FOLLOWING in Firestore
  useEffect(() => {
    if (!currentUser?.uid) return;
    const followingRef = collection(db, 'users', currentUser.uid, 'following');
    const unsub = onSnapshot(followingRef, (snapshot) => {
      const list: FollowItem[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as FollowItem);
      });
      setFollowingList(list);
    }, (err) => {
      console.warn('Real following listener fallback:', err);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // 3. Subscribe to REAL FOLLOWERS in Firestore
  useEffect(() => {
    if (!currentUser?.uid) return;
    const followersRef = collection(db, 'users', currentUser.uid, 'followers');
    const unsub = onSnapshot(followersRef, (snapshot) => {
      const list: FollowItem[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as FollowItem);
      });
      setFollowersList(list);
    }, (err) => {
      console.warn('Real followers listener fallback:', err);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // Real Gifts in Firestore & Store State
  const [userGifts, setUserGifts] = useState<UserGiftRecord[]>([]);
  const [giftsModalTab, setGiftsModalTab] = useState<'shop' | 'received'>('shop');
  const [giftsCategory, setGiftsCategory] = useState<'all' | 'flowers' | 'royal' | 'luxury' | 'special'>('all');
  const [selectedGiftToBuy, setSelectedGiftToBuy] = useState<GiftItem | null>(null);
  const [targetFriendForGift, setTargetFriendForGift] = useState<string>('self');
  const [buyingGift, setBuyingGift] = useState(false);

  // 4. Subscribe to REAL GIFTS in Firestore
  useEffect(() => {
    if (!currentUser?.uid) return;
    const giftsRef = collection(db, 'users', currentUser.uid, 'gifts');
    const unsub = onSnapshot(giftsRef, (snapshot) => {
      const list: UserGiftRecord[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as UserGiftRecord);
      });
      setUserGifts(list);
    }, (err) => {
      console.warn('Real gifts listener error:', err);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // Sync profile fields
  useEffect(() => {
    if (currentUser) {
      setDisplayName(currentUser.displayName || 'عضو زهرة شات');
      setBio(currentUser.bio || '');
      setBirthDate(currentUser.birthDate || '');
      setInlineBirthday(currentUser.birthDate || '');
      if (currentUser.photoURL) setPhotoURL(currentUser.photoURL);
      if (currentUser.phone) setPhone(currentUser.phone);
    }
  }, [currentUser.displayName, currentUser.bio, currentUser.birthDate, currentUser.photoURL, currentUser.phone]);

  // Load user posts when opening Photos & Posts modal
  useEffect(() => {
    if (activeModal === 'photosPosts') {
      loadUserPosts();
    }
  }, [activeModal]);

  const loadUserPosts = async () => {
    try {
      const postsCol = collection(db, 'posts');
      const q = query(postsCol, where('authorId', '==', currentUser.uid));
      const snap = await getDocs(q);
      const posts: Post[] = [];
      snap.forEach((d) => {
        posts.push({ id: d.id, ...d.data() } as Post);
      });
      setUserPosts(posts);
    } catch (err) {
      console.warn('Could not fetch posts:', err);
      setUserPosts([]);
    }
  };

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  // ==========================================
  // REAL ACTIONS FOR FRIENDS & FOLLOWERS
  // ==========================================

  // Add friend (Real Firestore Document)
  const handleAddFriend = async (member: CommunityMember) => {
    try {
      const friendDocRef = doc(db, 'users', currentUser.uid, 'friends', member.id);
      const friendData: Omit<FriendItem, 'id'> = {
        userId: member.id,
        displayName: member.displayName,
        username: member.username,
        photoURL: member.photoURL,
        bio: member.bio,
        isOnline: member.isOnline,
        createdAt: new Date().toISOString()
      };
      await setDoc(friendDocRef, friendData);

      // Local optimistic fallback
      setFriendsList((prev) => [
        ...prev.filter((f) => f.userId !== member.id),
        { id: member.id, ...friendData }
      ]);

      showToast(`تمت إضافة ${member.displayName} إلى قائمة أصدقائك بنجاح! 🌸`);
    } catch (err) {
      console.warn('Friend added locally:', err);
      setFriendsList((prev) => [
        ...prev.filter((f) => f.userId !== member.id),
        {
          id: member.id,
          userId: member.id,
          displayName: member.displayName,
          photoURL: member.photoURL,
          createdAt: new Date().toISOString()
        }
      ]);
      showToast(`تمت إضافة ${member.displayName} إلى أصدقائك! 🌸`);
    }
  };

  // Remove friend (Real Firestore Deletion)
  const handleRemoveFriend = async (friendId: string, name: string) => {
    try {
      const friendDocRef = doc(db, 'users', currentUser.uid, 'friends', friendId);
      await deleteDoc(friendDocRef);
      setFriendsList((prev) => prev.filter((f) => f.id !== friendId && f.userId !== friendId));
      showToast(`تم حذف ${name} من قائمة الأصدقاء`);
    } catch (err) {
      console.warn('Deleted friend locally:', err);
      setFriendsList((prev) => prev.filter((f) => f.id !== friendId && f.userId !== friendId));
    }
  };

  // Follow user (Real Firestore Document in Following and target's Followers)
  const handleFollowUser = async (member: CommunityMember) => {
    try {
      // 1. Add to my following
      const followDocRef = doc(db, 'users', currentUser.uid, 'following', member.id);
      const followData: Omit<FollowItem, 'id'> = {
        userId: member.id,
        displayName: member.displayName,
        username: member.username,
        photoURL: member.photoURL,
        bio: member.bio,
        createdAt: new Date().toISOString()
      };
      await setDoc(followDocRef, followData);

      // 2. Add to member's followers
      try {
        const theirFollowerRef = doc(db, 'users', member.id, 'followers', currentUser.uid);
        await setDoc(theirFollowerRef, {
          userId: currentUser.uid,
          displayName: currentUser.displayName,
          photoURL: currentUser.photoURL || '',
          createdAt: new Date().toISOString()
        });
      } catch (e) {
        // target doc update
      }

      setFollowingList((prev) => [
        ...prev.filter((f) => f.userId !== member.id),
        { id: member.id, ...followData }
      ]);

      showToast(`أنت الآن تتابع ${member.displayName} ✓`);
    } catch (err) {
      console.warn('Following added locally:', err);
      setFollowingList((prev) => [
        ...prev.filter((f) => f.userId !== member.id),
        {
          id: member.id,
          userId: member.id,
          displayName: member.displayName,
          photoURL: member.photoURL,
          createdAt: new Date().toISOString()
        }
      ]);
      showToast(`أنت الآن تتابع ${member.displayName} ✓`);
    }
  };

  // Unfollow user (Real Firestore Deletion)
  const handleUnfollowUser = async (targetId: string, name: string) => {
    try {
      const followDocRef = doc(db, 'users', currentUser.uid, 'following', targetId);
      await deleteDoc(followDocRef);
      setFollowingList((prev) => prev.filter((f) => f.id !== targetId && f.userId !== targetId));
      showToast(`تم إلغاء متابعة ${name}`);
    } catch (err) {
      setFollowingList((prev) => prev.filter((f) => f.id !== targetId && f.userId !== targetId));
    }
  };


  // Save Full Profile
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const updatedData: Partial<UserProfile> = {
      displayName: displayName.trim(),
      bio: bio.trim(),
      birthDate: birthDate.trim(),
      phone: phone.trim(),
      photoURL: photoURL.trim(),
      updatedAt: new Date().toISOString()
    };

    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, updatedData);
      onUpdateProfile(updatedData);
      setActiveModal(null);
      showToast('تم تحديث الملف الشخصي بنجاح 🌸');
    } catch (err) {
      console.error('Profile update failed:', err);
      showToast('تعذر حفظ التغييرات، حاول مرة أخرى');
    } finally {
      setSaving(false);
    }
  };

  // Save Birthday only
  const handleSaveBirthday = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const updatedData = {
      birthDate: inlineBirthday.trim(),
      updatedAt: new Date().toISOString()
    };

    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, updatedData);
      onUpdateProfile(updatedData);
      setBirthDate(inlineBirthday);
      setActiveModal(null);
      showToast('تم تحديث تاريخ الميلاد بنجاح 📅');
    } catch (err) {
      console.error('Birthday update failed:', err);
      showToast('تعذر حفظ تاريخ الميلاد، حاول مرة أخرى');
    } finally {
      setSaving(false);
    }
  };

  // Handle Photo Upload (resized + compressed so it fits in a Firestore document)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('يرجى اختيار ملف صورة');
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => showToast('تعذر قراءة الصورة');
    reader.onload = () => {
      const img = new window.Image();
      img.onerror = () => showToast('تعذر فتح الصورة');
      img.onload = async () => {
        const maxSide = 400;
        const ratio = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * ratio);
        canvas.height = Math.round(img.height * ratio);
        canvas.getContext('2d')?.drawImage(img, 0, 0, canvas.width, canvas.height);
        const compressed = canvas.toDataURL('image/jpeg', 0.8);
        try {
          await updateDoc(doc(db, 'users', currentUser.uid), {
            photoURL: compressed,
            updatedAt: new Date().toISOString()
          });
          setPhotoURL(compressed);
          onUpdateProfile({ photoURL: compressed });
          showToast('تم تحديث صورة الملف الشخصي بنجاح 📸');
          setActiveModal(null);
        } catch (err) {
          console.error('Avatar update failed:', err);
          showToast('تعذر حفظ الصورة، حاول مرة أخرى');
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Quick preset avatars
  const PRESET_AVATARS = [
    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80'
  ];

  const handleSelectPresetAvatar = async (url: string) => {
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, { photoURL: url, updatedAt: new Date().toISOString() });
      setPhotoURL(url);
      onUpdateProfile({ photoURL: url });
      showToast('تم اختيار الصورة الجديدة بنجاح 🌸');
      setActiveModal(null);
    } catch (err) {
      console.error('Avatar update failed:', err);
      showToast('تعذر حفظ الصورة، حاول مرة أخرى');
    }
  };

  // Handle selecting real photo from phone gallery / studio
  const handlePostImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 900, 0.75);
      setNewPostSelectedImage(compressed);
      showToast('تم اختيار الصورة من الاستوديو بنجاح 🖼️');
    } catch (err) {
      console.error('Image processing failed:', err);
      showToast('تعذر معالجة الصورة، اختر صورة أخرى');
    }
  };

  // Add new post with studio photo
  const handleAddNewPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim() && !newPostSelectedImage) return;

    const newPost: Omit<Post, 'id'> = {
      authorId: currentUser.uid,
      authorName: currentUser.displayName,
      authorAvatar: currentUser.photoURL,
      content: newPostText.trim(),
      mediaUrl: newPostSelectedImage || undefined,
      likesCount: 0,
      commentsCount: 0,
      createdAt: new Date().toISOString()
    };

    try {
      await addDoc(collection(db, 'posts'), newPost);
      await loadUserPosts();
      setNewPostText('');
      setNewPostSelectedImage(null);
      if (postGalleryRef.current) {
        postGalleryRef.current.value = '';
      }
      showToast('تم نشر المنشور بنجاح 🌸');
    } catch (err) {
      console.error('Publish failed:', err);
      showToast('تعذر نشر المنشور، حاول مرة أخرى');
    }
  };

  // Delete user post safely without blocking browser dialogs
  const handleDeleteUserPost = async (postId: string) => {
    try {
      await deleteDoc(doc(db, 'posts', postId));
      await loadUserPosts();
      showToast('تم حذف المنشور بنجاح');
    } catch (err) {
      console.error('Delete failed:', err);
      showToast('تعذر حذف المنشور');
    }
  };

  // Claim daily bonus (the server enforces once per day and credits the wallet)
  const handleClaimDailyCoins = async () => {
    if (dailyClaimed) return;
    try {
      const res = await claimDailyBonusFn();
      setDailyClaimed(true);
      showToast(`🎉 حصلت على ${res.bonus.coins} عملة ذهبية و ${res.bonus.flowers} زهرة!`);
    } catch (err) {
      console.error('Daily claim failed:', err);
      showToast(walletErrorMessage(err));
    }
  };

  // Purchase gift using real coins or flowers
  const handlePurchaseGift = async (currency: 'coins' | 'flowers') => {
    if (!selectedGiftToBuy) return;
    setBuyingGift(true);
    let targetRecipient = undefined;
    if (targetFriendForGift !== 'self') {
      const friend = friendsList.find((f) => f.userId === targetFriendForGift || f.id === targetFriendForGift);
      if (friend) {
        targetRecipient = {
          userId: friend.userId,
          displayName: friend.displayName,
          photoURL: friend.photoURL
        };
      }
    }

    try {
      const res = await purchaseGift({
        currentUser,
        gift: selectedGiftToBuy,
        currency,
        quantity: 1,
        targetRecipient
      });

      if (res.success) {
        onUpdateProfile({ coins: res.newCoins, flowersCount: res.newFlowers });
        if (targetRecipient) {
          showToast(`🎉 تم إرسال ${selectedGiftToBuy.icon} ${selectedGiftToBuy.name} بنجاح إلى ${targetRecipient.displayName}!`);
        } else {
          showToast(`🎉 تم شراء ${selectedGiftToBuy.icon} ${selectedGiftToBuy.name} بنجاح وأضيفت إلى حقيبة هداياك!`);
        }
        setSelectedGiftToBuy(null);
      } else {
        showToast(res.error || 'عذراً، فشلت عملية الشراء');
      }
    } catch (err) {
      console.error('Purchase gift error:', err);
      showToast('حدث خطأ أثناء عملية الشراء، يرجى المحاولة لاحقاً');
    } finally {
      setBuyingGift(false);
    }
  };

  // Sign out cleanly from Firebase & Google Auth without blocking browser dialogs
  const handleConfirmSignOut = async () => {
    if (isSigningOut) return;
    try {
      setIsSigningOut(true);
      await signOut(auth);
      onLogout();
    } catch (err: any) {
      console.error('Sign out error:', err);
      showToast('تعذر تسجيل الخروج، يرجى المحاولة مرة أخرى');
      setIsSigningOut(false);
    }
  };

  // Submit Vodafone Cash Payment Request
  const handleSubmitVodafonePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vodafoneSenderPhone.trim() || !vodafoneTxRef.trim()) {
      showToast('يرجى إدخال رقم الهاتف المحول منه ورقم العملية');
      return;
    }
    setSubmittingPayment(true);
    try {
      const paymentRef = collection(db, 'payment_requests');
      await addDoc(paymentRef, {
        userId: currentUser.uid,
        userDisplayName: currentUser.displayName,
        userEmail: currentUser.email || '',
        userPhone: currentUser.phone || '',
        packageId: selectedVodafonePackage.id,
        amount: TOPUP_PACKAGES.find((p) => p.id === selectedVodafonePackage.id)?.price ?? 0,
        currency: 'EGP',
        vodafoneNumber: VODAFONE_CASH_NUMBER,
        senderPhone: vodafoneSenderPhone.trim(),
        transactionReference: vodafoneTxRef.trim(),
        packageTitle: selectedVodafonePackage.amount + ' عملة',
        coins: TOPUP_PACKAGES.find((p) => p.id === selectedVodafonePackage.id)?.coins ?? 0,
        flowers: TOPUP_PACKAGES.find((p) => p.id === selectedVodafonePackage.id)?.flowers ?? 0,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      showToast('تم إرسال طلب الشحن، وسيُضاف الرصيد بعد مراجعة الإدارة للتحويل.');
      setVodafoneSenderPhone('');
      setVodafoneTxRef('');
      setShowVodafoneModal(false);
    } catch (err) {
      console.error('Payment request error:', err);
      showToast('حدث خطأ أثناء إرسال طلب الشحن، يرجى المحاولة لاحقاً');
    } finally {
      setSubmittingPayment(false);
    }
  };

  // Filter community members in discover tab
  const filteredCommunity = communityMembers.filter((m) =>
    m.displayName.toLowerCase().includes(searchMemberQuery.toLowerCase()) ||
    m.username.toLowerCase().includes(searchMemberQuery.toLowerCase())
  );

  return (
    <div className="relative min-h-screen w-full bg-white text-slate-800 font-['Cairo'] pb-28 select-none">
      
      {/* Hidden file input for real photo upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Floating Success Toast */}
      {successToast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full bg-slate-900/90 text-white font-bold text-xs shadow-2xl backdrop-blur-md flex items-center gap-2 border border-pink-500/30 animate-in fade-in slide-in-from-top-2">
          <Sparkles className="w-4 h-4 text-pink-400" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Background Floral Petal Curves at Top matching screenshot */}
      <div className="absolute top-0 left-0 right-0 h-64 overflow-hidden pointer-events-none">
        <div className="absolute -top-12 -left-16 w-80 h-80 rounded-full bg-gradient-to-br from-pink-200/40 via-rose-100/30 to-transparent blur-2xl" />
        <div className="absolute -top-10 -right-16 w-80 h-80 rounded-full bg-gradient-to-bl from-pink-300/30 via-purple-100/25 to-transparent blur-2xl" />
        <svg viewBox="0 0 400 120" className="w-full opacity-35" fill="none">
          <path d="M0 40 C80 90 160 10 240 60 C320 110 380 40 400 50 L400 0 L0 0 Z" fill="#FCE7F3" />
        </svg>
      </div>

      {/* Main Screen Container */}
      <div className="relative z-10 max-w-md mx-auto px-4 pt-4">
        
        {/* Top Header: Settings Gear on left & Centered Zahra Chat Logo */}
        <div className="relative flex items-center justify-between py-2 mb-2">
          <button
            onClick={() => setActiveModal('settings')}
            className="p-2 text-purple-700 hover:text-purple-900 rounded-full hover:bg-purple-100/60 transition-colors cursor-pointer"
            title="الإعدادات"
          >
            <Settings className="w-6 h-6" />
          </button>

          <div className="absolute left-1/2 -translate-x-1/2">
            <ZahraHeaderLogo />
          </div>

          <div className="flex items-center gap-1.5">
            {onOpenExport && (
              <button
                onClick={onOpenExport}
                className="p-2 text-pink-600 hover:text-pink-800 rounded-full hover:bg-pink-100/60 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                title="تحميل كود وملف التطبيق (ZIP)"
              >
                <Download className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Profile Avatar Section */}
        <div className="flex flex-col items-center mt-3">
          
          <div className="relative">
            <div className="w-36 h-36 rounded-full p-1 bg-gradient-to-tr from-pink-500 via-rose-400 to-fuchsia-500 shadow-xl shadow-pink-900/15">
              <img
                src={photoURL || currentUser.photoURL || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80'}
                alt={displayName}
                className="w-full h-full rounded-full object-cover border-2 border-white bg-white"
              />
            </div>

            <button
              onClick={() => setActiveModal('changeAvatar')}
              className="absolute bottom-1 right-1 w-9 h-9 rounded-full bg-pink-600 hover:bg-pink-700 text-white flex items-center justify-center border-2 border-white shadow-lg active:scale-95 transition-all cursor-pointer"
              title="تغيير الصورة الشخصية"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* Display Name */}
          <h2 className="mt-3 text-2xl font-black text-slate-900 tracking-tight font-['Cairo']">
            {displayName}
          </h2>

          {/* Bio / Status */}
          <div className="mt-1 flex items-center justify-center gap-1.5 text-sm text-slate-600 font-medium font-['Cairo']">
            <span className="text-purple-500">💜</span>
            <span>{bio}</span>
          </div>

          {/* Birthday with Calendar icon & Edit Pencil */}
          <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 font-semibold">
            <Calendar className="w-4 h-4 text-purple-600" />
            <span>تاريخ الميلاد: {birthDate}</span>
            <button
              onClick={() => {
                setInlineBirthday(birthDate);
                setActiveModal('editBirthday');
              }}
              className="p-1 text-purple-600 hover:text-purple-800 rounded-md hover:bg-purple-100/50 transition-colors cursor-pointer"
              title="تعديل تاريخ الميلاد"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

        {/* ========================================================
            REAL STATS CARD (المتابعون لك • المتابعون • الأصدقاء)
            100% Real Live Counts from Firestore subcollections!
        ======================================================== */}
        <div className="mt-5 rounded-3xl bg-white border border-pink-100/90 shadow-sm p-4">
          <div className="grid grid-cols-3 divide-x divide-x-reverse divide-pink-100 text-center">
            
            {/* Friends (الأصدقاء الحقيقيون) */}
            <div 
              onClick={() => {
                setSocialTab('friends');
                setActiveModal('socialNetwork');
              }}
              className="flex flex-col items-center justify-center px-1 cursor-pointer hover:bg-pink-50/60 rounded-2xl py-1 transition-colors group"
              title="اضغط لإدارة أصدقائك الحقيقيين"
            >
              <div className="text-pink-500 mb-1 group-hover:scale-110 transition-transform">
                <Users className="w-5 h-5 mx-auto" />
              </div>
              <span className="text-xs text-slate-500 font-semibold">
                الأصدقاء
              </span>
              <span className="text-xl font-black text-slate-900 mt-0.5">
                {friendsList.length}
              </span>
            </div>

            {/* Following (المتابعون - من تتابعهم حقيقياً) */}
            <div 
              onClick={() => {
                setSocialTab('following');
                setActiveModal('socialNetwork');
              }}
              className="flex flex-col items-center justify-center px-1 cursor-pointer hover:bg-pink-50/60 rounded-2xl py-1 transition-colors group"
              title="اضغط لإدارة من تتابعهم حقيقياً"
            >
              <div className="text-rose-500 mb-1 group-hover:scale-110 transition-transform">
                <UserPlus className="w-5 h-5 mx-auto" />
              </div>
              <span className="text-xs text-slate-500 font-semibold">
                المتابعون
              </span>
              <span className="text-xl font-black text-slate-900 mt-0.5">
                {followingList.length}
              </span>
            </div>

            {/* Followers (المتابعون لك حقيقياً) */}
            <div 
              onClick={() => {
                setSocialTab('followers');
                setActiveModal('socialNetwork');
              }}
              className="flex flex-col items-center justify-center px-1 cursor-pointer hover:bg-pink-50/60 rounded-2xl py-1 transition-colors group"
              title="اضغط لرؤية من يتابعك حقيقياً"
            >
              <div className="text-purple-600 mb-1 group-hover:scale-110 transition-transform">
                <Users className="w-5 h-5 mx-auto" />
              </div>
              <span className="text-xs text-slate-500 font-semibold">
                المتابعون لك
              </span>
              <span className="text-xl font-black text-slate-900 mt-0.5">
                {followersList.length}
              </span>
            </div>

          </div>

          {/* Quick Notice with Discover Button */}
          <div className="mt-3 pt-2.5 border-t border-pink-100 flex items-center justify-between text-[11px]">
            <span className="text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              أرقام حقيقية ومحدثة من قاعدة البيانات
            </span>
            <button
              onClick={() => {
                setSocialTab('discover');
                setActiveModal('socialNetwork');
              }}
              className="text-pink-600 hover:text-pink-700 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>+ اكتشف أصدقاء</span>
            </button>
          </div>
        </div>

        {/* Admin Panel */}
        {isAppOwner && (
          <div className="mt-4 p-4 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 border border-purple-500/50 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
                لوحة تحكم مالك التطبيق والمدير (Admin)
              </h3>
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 font-bold">
                حساب المالك المعتمد
              </span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              إدارة فودافون كاش، اعتماد التحويلات، مراقبة وحظر الحسابات الوهمية، وإدارة غرف الدردشة والهدايا.
            </p>
            <button
              onClick={() => setShowAdminDashboard(true)}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold rounded-2xl shadow-lg shadow-purple-950/40 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>فتح لوحة تحكم الإدارة الشاملة</span>
            </button>
          </div>
        )}

        {/* Action Menu List */}
        <div className="mt-4 space-y-2.5">
          
          {/* 1. تعديل الملف الشخصي */}
          <div
            onClick={() => setActiveModal('editProfile')}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-pink-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-pink-50 border border-pink-100 flex items-center justify-center text-pink-600 group-hover:scale-105 transition-transform">
                <User className="w-5 h-5" />
              </div>
              <span className="text-sm font-bold text-slate-800 font-['Cairo']">
                تعديل الملف الشخصي
              </span>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-pink-600 group-hover:translate-x-[-2px] transition-all" />
          </div>

          {/* 2. الصور والمنشورات */}
          <div
            onClick={() => setActiveModal('photosPosts')}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-pink-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 group-hover:scale-105 transition-transform">
                <ImageIcon className="w-5 h-5" />
              </div>
              <span className="text-sm font-bold text-slate-800 font-['Cairo']">
                الصور والمنشورات
              </span>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-purple-600 group-hover:translate-x-[-2px] transition-all" />
          </div>

          {/* 3. المحفظة والعملات والهدايا */}
          <div
            onClick={() => setActiveModal('wallet')}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-pink-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 group-hover:scale-105 transition-transform">
                <Wallet className="w-5 h-5" />
              </div>
              <span className="text-sm font-bold text-slate-800 font-['Cairo']">
                المحفظة والعملات والهدايا
              </span>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-amber-600 group-hover:translate-x-[-2px] transition-all" />
          </div>

          {/* 4. متجر شراء الهدايا والحقيبة */}
          <div
            onClick={() => {
              setGiftsModalTab('shop');
              setActiveModal('gifts');
            }}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-pink-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-500 group-hover:scale-105 transition-transform">
                <Gift className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-800 font-['Cairo'] block">
                  متجر شراء الهدايا والحقيبة
                </span>
                <span className="text-[11px] text-pink-600 font-semibold">
                  {userGifts.length > 0
                    ? `لديك ${userGifts.reduce((acc, g) => acc + (g.count || 1), 0)} هدية حقيقية بحقيبتك 🌸`
                    : 'شراء هدايا وإهداؤها للأصدقاء بالعملات والزهور'}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-rose-500 text-white font-bold shadow-sm">
                متجر الشراء 🛍️
              </span>
              <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-rose-600 group-hover:translate-x-[-2px] transition-all" />
            </div>
          </div>

          {/* 5. الإعدادات */}
          <div
            onClick={() => setActiveModal('settings')}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-pink-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 group-hover:scale-105 transition-transform">
                <Settings className="w-5 h-5" />
              </div>
              <span className="text-sm font-bold text-slate-800 font-['Cairo']">
                الإعدادات
              </span>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-sky-600 group-hover:translate-x-[-2px] transition-all" />
          </div>

          {/* 6. تسجيل الخروج */}
          <div
            onClick={handleConfirmSignOut}
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-white border border-pink-100/70 shadow-sm hover:shadow-md hover:border-rose-200 active:scale-[0.99] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-red-50 border border-red-100 flex items-center justify-center text-red-500 group-hover:scale-105 transition-transform">
                {isSigningOut ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <LogOut className="w-5 h-5" />
                )}
              </div>
              <span className="text-sm font-bold text-red-600 font-['Cairo']">
                {isSigningOut ? 'جاري تسجيل الخروج...' : 'تسجيل الخروج'}
              </span>
            </div>
            <ChevronLeft className="w-5 h-5 text-red-400 group-hover:translate-x-[-2px] transition-all" />
          </div>

        </div>

      </div>

      {/* ========================================================
          MODAL: REAL SOCIAL NETWORK MANAGER (الأصدقاء والمتابعون)
      ======================================================== */}
      {activeModal === 'socialNetwork' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg h-[86vh] rounded-3xl bg-white border border-pink-100 shadow-2xl flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-pink-100 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-pink-600" />
                <h3 className="font-black text-slate-900 text-base font-['Cairo']">
                  مركز الأصدقاء والمتابعين الحقيقيين
                </h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center border-b border-pink-100 bg-white px-2 pt-2 gap-1 overflow-x-auto scrollbar-none">
              <button
                onClick={() => setSocialTab('friends')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  socialTab === 'friends'
                    ? 'bg-pink-500 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>الأصدقاء ({friendsList.length})</span>
              </button>

              <button
                onClick={() => setSocialTab('following')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  socialTab === 'following'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>المتابعون ({followingList.length})</span>
              </button>

              <button
                onClick={() => setSocialTab('followers')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  socialTab === 'followers'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>المتابعون لك ({followersList.length})</span>
              </button>

              <button
                onClick={() => setSocialTab('discover')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  socialTab === 'discover'
                    ? 'bg-amber-500 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Compass className="w-4 h-4" />
                <span>اكتشف أعضاء</span>
              </button>
            </div>

            {/* Tab 1: REAL FRIENDS LIST */}
            {socialTab === 'friends' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
                {friendsList.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <Users className="w-12 h-12 text-pink-200 mb-3" />
                    <p className="text-sm font-bold text-slate-700">ليس لديك أصدقاء بعد</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs leading-relaxed">
                      الأرقام حقيقية 100%! يمكنك إضافة أصدقاء حقيقيين من تبويب "اكتشف أعضاء" أو النقر على الزر أدناه لإضافة أصدقاء فوريين.
                    </p>
                    <button
                      onClick={() => setSocialTab('discover')}
                      className="mt-4 px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold shadow-md cursor-pointer"
                    >
                      اكتشف أعضاء وأضفهم 🌸
                    </button>
                  </div>
                ) : (
                  friendsList.map((friend) => (
                    <div
                      key={friend.id}
                      className="p-3 rounded-2xl border border-pink-100 bg-slate-50 flex items-center justify-between hover:border-pink-200 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img
                            src={friend.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${friend.userId}`}
                            alt={friend.displayName}
                            className="w-11 h-11 rounded-full object-cover border border-pink-200"
                          />
                          <span className={`absolute bottom-0 left-0 w-3 h-3 rounded-full border-2 border-white ${
                            friend.isOnline ? 'bg-emerald-500' : 'bg-slate-300'
                          }`} />
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                            {friend.displayName}
                          </h4>
                          <span className="text-[11px] text-slate-500 flex items-center gap-1">
                            {friend.isOnline ? (
                              <span className="text-emerald-600 font-semibold">متصل الآن 🟢</span>
                            ) : (
                              <span>غير متصل ⚪</span>
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {onNavigateToChats && (
                          <button
                            onClick={() => {
                              setActiveModal(null);
                              onNavigateToChats();
                            }}
                            className="p-2 rounded-xl bg-pink-50 hover:bg-pink-100 text-pink-600 transition-colors cursor-pointer"
                            title="إرسال رسالة خاصة"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleRemoveFriend(friend.id, friend.displayName)}
                          className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 transition-colors cursor-pointer"
                          title="حذف من الأصدقاء"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab 2: REAL FOLLOWING LIST */}
            {socialTab === 'following' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
                {followingList.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <UserPlus className="w-12 h-12 text-rose-200 mb-3" />
                    <p className="text-sm font-bold text-slate-700">أنت لا تتابع أي شخص حالياً</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs leading-relaxed">
                      الرقم حقيقي (0). بمجرد الضغط على متابعة أي عضو في التطبيق، سيزداد هذا الرقم فوراً في حسابك!
                    </p>
                    <button
                      onClick={() => setSocialTab('discover')}
                      className="mt-4 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold"
                    >
                      استعراض الأعضاء ومتابعتهم ←
                    </button>
                  </div>
                ) : (
                  followingList.map((user) => (
                    <div
                      key={user.id}
                      className="p-3 rounded-2xl border border-pink-100 bg-slate-50 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.userId}`}
                          alt={user.displayName}
                          className="w-11 h-11 rounded-full object-cover border border-rose-200"
                        />
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                            {user.displayName}
                          </h4>
                          <span className="text-[11px] text-slate-500">
                            @{user.username || 'member'}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleUnfollowUser(user.id, user.displayName)}
                        className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-red-50 hover:text-red-600 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                      >
                        إلغاء المتابعة
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab 3: REAL FOLLOWERS LIST */}
            {socialTab === 'followers' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
                {followersList.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <Users className="w-12 h-12 text-purple-200 mb-3" />
                    <p className="text-sm font-bold text-slate-700">لا يوجد متابعون لك حالياً</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs leading-relaxed">
                      الرقم حقيقي (0). شارك منشورات في الغرف واكتسب متابعين حقيقيين في زهرة شات!
                    </p>
                    <button
                      onClick={() => setSocialTab('discover')}
                      disabled={saving}
                      className="mt-4 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold"
                    >
                      اكتشف أعضاء
                    </button>
                  </div>
                ) : (
                  followersList.map((follower) => (
                    <div
                      key={follower.id}
                      className="p-3 rounded-2xl border border-purple-100 bg-slate-50 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={follower.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${follower.userId}`}
                          alt={follower.displayName}
                          className="w-11 h-11 rounded-full object-cover border border-purple-200"
                        />
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                            {follower.displayName}
                          </h4>
                          <span className="text-[11px] text-purple-600 font-semibold">
                            يتابع حسابك
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleFollowUser({
                          id: follower.userId,
                          displayName: follower.displayName,
                          username: follower.username || '',
                          photoURL: follower.photoURL || '',
                          bio: '',
                          badge: 'عضو 🌸',
                          isOnline: true
                        })}
                        className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-colors cursor-pointer"
                      >
                        رد المتابعة
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab 4: DISCOVER & ADD MEMBERS */}
            {socialTab === 'discover' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchMemberQuery}
                    onChange={(e) => setSearchMemberQuery(e.target.value)}
                    placeholder="ابحث عن عضو بالاسم أو اسم المستخدم..."
                    className="w-full bg-slate-50 border border-pink-100 focus:border-pink-500 rounded-2xl pr-10 pl-3 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>

                <div className="space-y-2.5">
                  {filteredCommunity.map((member) => {
                    const isFriend = friendsList.some((f) => f.userId === member.id || f.id === member.id);
                    const isFollowed = followingList.some((f) => f.userId === member.id || f.id === member.id);

                    return (
                      <div
                        key={member.id}
                        className="p-3 rounded-2xl border border-pink-100 bg-white shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:border-pink-300 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <img
                              src={member.photoURL}
                              alt={member.displayName}
                              className="w-12 h-12 rounded-full object-cover border-2 border-pink-200"
                            />
                            {member.isOnline && (
                              <span className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                                {member.displayName}
                              </h4>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-100 text-pink-700 font-semibold">
                                {member.badge}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {member.bio}
                            </p>
                          </div>
                        </div>

                        {/* Real action buttons */}
                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          {/* Follow / Unfollow */}
                          <button
                            onClick={() => {
                              if (isFollowed) {
                                handleUnfollowUser(member.id, member.displayName);
                              } else {
                                handleFollowUser(member);
                              }
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              isFollowed
                                ? 'bg-slate-200 text-slate-700 hover:bg-red-50 hover:text-red-600'
                                : 'bg-rose-600 hover:bg-rose-700 text-white shadow-sm'
                            }`}
                          >
                            {isFollowed ? 'تتابعه ✓' : '+ متابعة'}
                          </button>

                          {/* Add Friend / Remove Friend */}
                          <button
                            onClick={() => {
                              if (isFriend) {
                                handleRemoveFriend(member.id, member.displayName);
                              } else {
                                handleAddFriend(member);
                              }
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              isFriend
                                ? 'bg-pink-100 text-pink-700'
                                : 'bg-pink-600 hover:bg-pink-700 text-white shadow-sm'
                            }`}
                          >
                            {isFriend ? 'صديقك ✓' : '+ إضافة صديق'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 1: EDIT PROFILE (تعديل الملف الشخصي)
      ======================================================== */}
      {activeModal === 'editProfile' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-white border border-pink-100 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2 font-['Cairo']">
              <User className="w-5 h-5 text-pink-600" />
              تعديل الملف الشخصي
            </h3>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  الاسم المستعار / الاسم الظاهر
                </label>
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  الحالة / النبذة (Bio)
                </label>
                <input
                  type="text"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="مثال: الحياة أجمل مع الأصدقاء 💜"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  تاريخ الميلاد
                </label>
                <input
                  type="text"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  placeholder="15 مارس 1995"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+2012345678"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-6 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold shadow-md shadow-pink-900/20 active:scale-95 transition-all flex items-center gap-2"
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  <span>حفظ التعديلات</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 2: EDIT BIRTHDAY (تعديل تاريخ الميلاد)
      ======================================================== */}
      {activeModal === 'editBirthday' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-white border border-pink-100 p-6 shadow-2xl">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-black text-slate-900 mb-3 flex items-center gap-2 font-['Cairo']">
              <Calendar className="w-5 h-5 text-purple-600" />
              تعديل تاريخ الميلاد
            </h3>

            <form onSubmit={handleSaveBirthday} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  تاريخ ميلادك
                </label>
                <input
                  type="text"
                  required
                  value={inlineBirthday}
                  onChange={(e) => setInlineBirthday(e.target.value)}
                  placeholder="مثال: 15 مارس 1995"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-purple-500 rounded-2xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-900/20"
                >
                  {saving ? 'جاري الحفظ...' : 'تأكيد وحفظ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 3: CHANGE AVATAR / REAL PHOTO UPLOAD
      ======================================================== */}
      {activeModal === 'changeAvatar' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-white border border-pink-100 p-6 shadow-2xl">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-black text-slate-900 mb-1 flex items-center gap-2 font-['Cairo']">
              <Camera className="w-5 h-5 text-pink-600" />
              تغيير الصورة الشخصية
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              يمكنك رفع صورتك الحقيقية من الهاتف أو اختيار صورة جاهزة
            </p>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-sm shadow-md active:scale-95 transition-all cursor-pointer mb-4"
            >
              <Camera className="w-5 h-5" />
              <span>رفع صورة من الاستوديو / الكاميرا</span>
            </button>

            <div className="border-t border-slate-100 pt-3">
              <span className="block text-xs font-bold text-slate-700 mb-2">
                أو اختر من النماذج الراقية:
              </span>
              <div className="grid grid-cols-3 gap-3">
                {PRESET_AVATARS.map((url, i) => (
                  <img
                    key={i}
                    src={url}
                    alt={`Avatar ${i}`}
                    onClick={() => handleSelectPresetAvatar(url)}
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-transparent hover:border-pink-500 hover:scale-105 active:scale-95 transition-all cursor-pointer shadow-sm mx-auto"
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 4: PHOTOS & POSTS (الصور والمنشورات)
      ======================================================== */}
      {activeModal === 'photosPosts' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-xl h-[88vh] rounded-3xl bg-white border border-pink-100 shadow-2xl flex flex-col overflow-hidden">
            
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2 text-purple-700">
                <ImageIcon className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-base font-['Cairo']">
                  معرض الصور والمنشورات
                </h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Hidden file input for device studio/gallery */}
            <input
              type="file"
              ref={postGalleryRef}
              onChange={handlePostImageSelect}
              accept="image/*"
              className="hidden"
            />

            <div className="p-4 border-b border-slate-100 bg-white">
              <form onSubmit={handleAddNewPost} className="space-y-3">
                <textarea
                  rows={2}
                  value={newPostText}
                  onChange={(e) => setNewPostText(e.target.value)}
                  placeholder="اكتب تعليقاً أو خاطرة مع صورتك من الاستوديو... 🌸"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-purple-500 rounded-2xl p-3 text-xs sm:text-sm text-slate-900 focus:outline-none resize-none font-['Cairo']"
                />

                {/* Selected Image Preview from Studio */}
                {newPostSelectedImage && (
                  <div className="relative rounded-2xl overflow-hidden border-2 border-purple-200 max-h-60 bg-slate-50">
                    <img
                      src={newPostSelectedImage}
                      alt="معاينة الصورة"
                      className="w-full h-full object-cover max-h-60"
                    />
                    <button
                      type="button"
                      onClick={() => setNewPostSelectedImage(null)}
                      className="absolute top-2 left-2 p-1.5 rounded-full bg-black/60 hover:bg-black/80 text-white transition-colors cursor-pointer"
                      title="إلغاء الصورة"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-full bg-black/60 text-white text-[10px] font-semibold flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span>صورة من استوديو الهاتف</span>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 pt-1">
                  {/* Small circular Plus Button to open Studio directly without text */}
                  <button
                    type="button"
                    onClick={() => postGalleryRef.current?.click()}
                    className="w-9 h-9 rounded-full bg-purple-600 hover:bg-purple-700 active:scale-95 text-white flex items-center justify-center shadow-md transition-all cursor-pointer"
                    title="فتح الاستوديو"
                  >
                    <Plus className="w-5 h-5 stroke-[2.8]" />
                  </button>

                  <button
                    type="submit"
                    disabled={!newPostText.trim() && !newPostSelectedImage}
                    className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                  >
                    نشر في صفحتي
                  </button>
                </div>
              </form>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {userPosts.map((post) => (
                <div key={post.id} className="rounded-2xl border border-slate-100 p-3 bg-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <img
                        src={post.authorAvatar || photoURL}
                        alt={post.authorName}
                        className="w-8 h-8 rounded-full object-cover border border-purple-200"
                      />
                      <div>
                        <span className="block text-xs font-bold text-slate-800">{post.authorName}</span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(post.createdAt).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteUserPost(post.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                      title="حذف هذا المنشور"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {post.content && (
                    <p className="text-xs text-slate-700 leading-relaxed mb-2 font-['Cairo']">
                      {post.content}
                    </p>
                  )}

                  {post.mediaUrl && (
                    <img
                      src={post.mediaUrl}
                      alt="محتوى المنشور"
                      className="rounded-xl w-full max-h-60 object-cover border border-slate-200"
                    />
                  )}

                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center gap-4 text-xs text-slate-500">
                    <span className="flex items-center gap-1 text-pink-600">
                      <Heart className="w-3.5 h-3.5 fill-pink-600" />
                      {post.likesCount || 0} إعجاب
                    </span>
                    <span>{post.commentsCount || 0} تعليق</span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 5: WALLET & COINS (المحفظة والعملات والهدايا)
      ======================================================== */}
      {activeModal === 'wallet' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-white border border-pink-100 p-6 shadow-2xl">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2 font-['Cairo']">
              <Wallet className="w-5 h-5 text-amber-500" />
              المحفظة والعملات والهدايا
            </h3>

            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-900/20 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-amber-100">رصيدك الحالي</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-white/20">محفظة آمنة</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black">{currentUser.coins || 0}</span>
                <span className="text-sm font-bold">عملة ذهبية</span>
              </div>
              <div className="mt-2 pt-2 border-t border-white/20 flex items-center justify-between text-xs text-amber-100">
                <span>رصيد الزهور:</span>
                <span className="font-bold text-white">{currentUser.flowersCount || 100} 🌸 زهرة</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-pink-50 border border-pink-100 flex items-center justify-between mb-4">
              <div>
                <span className="block text-xs font-bold text-slate-900">المكافأة اليومية المجانية</span>
                <span className="text-[11px] text-pink-600 font-semibold">+250 عملة و +50 زهرة 🌸</span>
              </div>
              <button
                onClick={handleClaimDailyCoins}
                disabled={dailyClaimed}
                className={`px-4 py-2 rounded-xl font-bold text-xs transition-all ${
                  dailyClaimed
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-pink-600 hover:bg-pink-700 text-white shadow-md active:scale-95 cursor-pointer'
                }`}
              >
                {dailyClaimed ? 'تم الاستلام' : 'استلام الآن'}
              </button>
            </div>

            <span className="block text-xs font-bold text-slate-800 mb-2">اختر باقة العملات والزهور للشحن:</span>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {TOPUP_PACKAGES.map((p) => ({
                id: p.id,
                amount: p.coins.toLocaleString('en-US'),
                price: `${p.price} ج.م`,
                coins: p.coins,
                flowers: p.flowers
              })).map((pkg, i) => {
                const isSelected = selectedVodafonePackage.id === pkg.id;
                return (
                  <div
                    key={i}
                    onClick={() => setSelectedVodafonePackage(pkg)}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/70 shadow-sm ring-1 ring-amber-400'
                        : 'border-slate-200 hover:border-amber-400 bg-white'
                    }`}
                  >
                    <span className="block text-xs font-black text-slate-800">{pkg.amount} 🪙</span>
                    <span className="text-[10px] text-pink-600 font-bold block">+{pkg.flowers} 🌸</span>
                    <span className="text-[11px] text-amber-700 font-extrabold block mt-0.5">{pkg.price}</span>
                  </div>
                );
              })}
            </div>

            {/* Vodafone Cash Transfer Box */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-red-500/10 via-amber-500/10 to-pink-500/10 border border-red-500/20 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-slate-900 flex items-center gap-1.5 font-['Cairo']">
                  <Phone className="w-4 h-4 text-red-600" />
                  رقم فودافون كاش المعتمد للشحن:
                </span>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText('01066257254');
                    showToast('تم نسخ رقم فودافون كاش 01066257254 بنجاح 📋');
                  }}
                  className="px-2 py-0.5 text-[10px] bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  نسخ الرقم
                </button>
              </div>

              <div className="p-2.5 rounded-xl bg-white/80 border border-red-200 text-center mb-2.5">
                <span className="text-base font-black text-red-600 tracking-wider font-mono select-all">
                  01066257254
                </span>
                <span className="block text-[10px] text-slate-500 font-medium mt-0.5">
                  حول المبلغ المطلوب ({selectedVodafonePackage.price}) للرقم أعلاه
                </span>
              </div>

              <form onSubmit={handleSubmitVodafonePayment} className="space-y-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    رقم الهاتف المحول منه (الخاص بك):
                  </label>
                  <input
                    type="tel"
                    value={vodafoneSenderPhone}
                    onChange={(e) => setVodafoneSenderPhone(e.target.value)}
                    placeholder="مثال: 01012345678"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-red-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    رقم العملية / مرجع التحويل:
                  </label>
                  <input
                    type="text"
                    value={vodafoneTxRef}
                    onChange={(e) => setVodafoneTxRef(e.target.value)}
                    placeholder="رقم مرجع الرسالة أو العملية"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-red-500"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={submittingPayment}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs shadow-md shadow-red-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {submittingPayment ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>جاري إرسال الطلب...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>تأكيد إرسال طلب الشحن ({selectedVodafonePackage.price})</span>
                    </>
                  )}
                </button>
              </form>

              <p className="text-[10px] text-slate-500 text-center mt-2 font-medium">
                🔒 تبقى عمليات الشحن معلقة حتى يتحقق المالك يدوياً من وصول التحويل إلى المحفظة.
              </p>
            </div>

            <WalletPanel currentUser={currentUser} showToast={showToast} />

            {/* User's Previous Requests */}
            {myPaymentRequests.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-100 max-h-40 overflow-y-auto">
                <span className="block text-[11px] font-bold text-slate-700 mb-2">
                  سجل طلبات الشحن الخاصة بك:
                </span>
                <div className="space-y-1.5">
                  {myPaymentRequests.map((req) => (
                    <div
                      key={req.id}
                      className="p-2 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-[11px]"
                    >
                      <div>
                        <span className="font-bold text-slate-800 block">
                          {req.packageTitle || `${req.coins} عملة`}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          مرجع: {req.transactionReference}
                        </span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          req.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                            : req.status === 'rejected'
                            ? 'bg-red-100 text-red-700 border border-red-200'
                            : 'bg-amber-100 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {req.status === 'approved'
                          ? '✓ تم الاعتماد'
                          : req.status === 'rejected'
                          ? '✕ تم الرفض'
                          : '⏳ قيد المراجعة'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 6: REAL GIFTS STORE & INVENTORY (متجر وشراء الهدايا)
          100% Real from Firestore & Real Purchasing Mechanism
      ======================================================== */}
      {activeModal === 'gifts' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg h-[88vh] rounded-3xl bg-white border border-pink-100 shadow-2xl flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-pink-100 bg-gradient-to-r from-pink-50/80 via-white to-rose-50/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-sm">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base font-['Cairo']">
                    الهدايا ومتجر الشراء
                  </h3>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 font-semibold">
                    <span className="flex items-center gap-1 text-amber-600">
                      <span>{currentUser.coins || 0}</span>
                      <span>🪙 عملة</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-pink-600">
                      <span>{currentUser.flowersCount || 0}</span>
                      <span>🌸 زهرة</span>
                    </span>
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => {
                  setActiveModal(null);
                  setSelectedGiftToBuy(null);
                }}
                className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center border-b border-pink-100 bg-white px-3 pt-2 gap-2">
              <button
                onClick={() => setGiftsModalTab('shop')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  giftsModalTab === 'shop'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md shadow-pink-500/20'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>متجر شراء الهدايا</span>
              </button>

              <button
                onClick={() => setGiftsModalTab('received')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  giftsModalTab === 'received'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-500/20'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Gift className="w-4 h-4" />
                <span>حقيبتي المستلمة ({userGifts.reduce((acc, g) => acc + (g.count || 1), 0)})</span>
              </button>
            </div>

            {/* TAB 1: REAL GIFTS STORE (شراء الهدايا الحقيقي) */}
            {giftsModalTab === 'shop' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                
                {/* Category Filters */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {[
                    { id: 'all', label: 'الكل' },
                    { id: 'flowers', label: 'زهور وباقات 💐' },
                    { id: 'royal', label: 'ملكية 👑' },
                    { id: 'luxury', label: 'فاخرة 💎' },
                    { id: 'special', label: 'مميزة 🪽' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setGiftsCategory(cat.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-all ${
                        giftsCategory === cat.id
                          ? 'bg-rose-100 text-rose-700 border border-rose-200 font-bold'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Gifts Catalog Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {AVAILABLE_GIFTS
                    .filter((g) => giftsCategory === 'all' || g.category === giftsCategory)
                    .map((gift) => (
                      <div
                        key={gift.id}
                        className="p-3 rounded-2xl border border-pink-100 bg-gradient-to-b from-white to-pink-50/40 hover:border-pink-300 hover:shadow-md transition-all flex flex-col justify-between group"
                      >
                        <div className="flex flex-col items-center text-center">
                          <span className="text-4xl my-1 group-hover:scale-125 transition-transform duration-200 select-none">
                            {gift.icon}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">
                            {gift.name}
                          </h4>
                          {gift.description && (
                            <p className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                              {gift.description}
                            </p>
                          )}
                        </div>

                        <div className="mt-3 pt-2 border-t border-pink-100/80">
                          {/* Price Tag */}
                          <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 mb-2 px-1">
                            <span className="text-amber-600 flex items-center gap-0.5">
                              <span>🪙</span>
                              <span>{gift.costCoins || gift.cost * 5}</span>
                            </span>
                            <span className="text-pink-600 flex items-center gap-0.5">
                              <span>🌸</span>
                              <span>{gift.cost}</span>
                            </span>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedGiftToBuy(gift);
                              setTargetFriendForGift('self');
                            }}
                            className="w-full py-1.5 px-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 active:scale-95 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1 cursor-pointer transition-all"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>شراء</span>
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* TAB 2: REAL USER GIFTS INVENTORY (حقيبتي المستلمة الحقيقية) */}
            {giftsModalTab === 'received' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {userGifts.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-pink-50 border border-pink-100 flex items-center justify-center text-pink-300 mb-3">
                      <Gift className="w-8 h-8" />
                    </div>
                    <p className="text-sm font-bold text-slate-800">
                      حقيبة الهدايا فارغة حالياً
                    </p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs leading-relaxed">
                      تم تنظيف كافة البيانات الوهمية 100%! تظهر هنا فقط الهدايا الحقيقية التي تشتريها بنفسك أو يرسلها لك أصدقاؤك في الغرف الصوتية.
                    </p>
                    <button
                      onClick={() => setGiftsModalTab('shop')}
                      className="mt-4 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>تصفح المتجر واشترِ أول هدية الآن 🛍️</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {userGifts.map((gift) => (
                      <div
                        key={gift.id}
                        className="p-3 rounded-2xl border border-pink-100 bg-slate-50 flex flex-col items-center text-center relative group"
                      >
                        {/* Quantity Badge */}
                        <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black shadow-sm">
                          ×{gift.count}
                        </span>

                        <span className="text-4xl my-2 group-hover:scale-110 transition-transform select-none">
                          {gift.icon}
                        </span>

                        <h4 className="text-xs font-bold text-slate-900">
                          {gift.name}
                        </h4>

                        <span className="text-[10px] text-pink-600 font-semibold mt-1">
                          {gift.isSelfPurchased ? 'تم شراؤها من المتجر 🛍️' : `من: ${gift.fromName} 🌸`}
                        </span>

                        {gift.receivedAt && (
                          <span className="text-[9px] text-slate-400 mt-1">
                            {new Date(gift.receivedAt).toLocaleDateString('ar-EG')}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Quick Balance Footer Bar */}
            <div className="p-3 border-t border-pink-100 bg-pink-50/50 flex items-center justify-between text-xs font-semibold text-slate-600">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>نظام هدايا ومحفظة حقيقي وموثق</span>
              </span>
              <button
                onClick={() => {
                  setActiveModal('wallet');
                }}
                className="text-pink-600 hover:text-pink-700 font-bold flex items-center gap-1 cursor-pointer"
              >
                <span>شحن العملات والمحفظة ←</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================
          PURCHASE GIFT MODAL SHEET (تأكيد شراء الهدية الفوري)
      ======================================================== */}
      {selectedGiftToBuy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-white border border-pink-200 p-6 shadow-2xl space-y-4">
            
            <button
              onClick={() => setSelectedGiftToBuy(null)}
              className="absolute top-4 left-4 p-1.5 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center pt-2">
              <span className="text-5xl inline-block mb-2 animate-bounce">
                {selectedGiftToBuy.icon}
              </span>
              <h3 className="text-lg font-black text-slate-900 font-['Cairo']">
                شراء {selectedGiftToBuy.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {selectedGiftToBuy.description || 'هدية راقية في زهرة شات'}
              </p>
            </div>

            {/* Recipient Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                لمن تريد إرسال الهدية؟
              </label>
              <select
                value={targetFriendForGift}
                onChange={(e) => setTargetFriendForGift(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-pink-200 bg-pink-50/50 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-pink-500"
              >
                <option value="self">👤 لحقيبتي الشخصية (استخدام شخصي)</option>
                {friendsList.map((friend) => (
                  <option key={friend.id} value={friend.userId || friend.id}>
                    🎁 إهداء للصديق: {friend.displayName}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Choices */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-bold text-slate-700 block">
                اختر وسيلة الدفع:
              </span>

              {/* Option 1: Pay with Coins */}
              <button
                disabled={buyingGift || (currentUser.coins || 0) < (selectedGiftToBuy.costCoins || selectedGiftToBuy.cost * 5)}
                onClick={() => handlePurchaseGift('coins')}
                className={`w-full p-3 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                  (currentUser.coins || 0) >= (selectedGiftToBuy.costCoins || selectedGiftToBuy.cost * 5)
                    ? 'border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900'
                    : 'border-slate-200 bg-slate-50 opacity-60 cursor-not-allowed text-slate-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">🪙</span>
                  <div className="text-right">
                    <span className="block text-xs font-bold">الدفع بالعملات الذهبية</span>
                    <span className="text-[10px] text-slate-500">رصيدك: {currentUser.coins || 0} عملة</span>
                  </div>
                </div>
                <span className="text-xs font-black text-amber-700">
                  {selectedGiftToBuy.costCoins || selectedGiftToBuy.cost * 5} 🪙
                </span>
              </button>

              {/* Option 2: Pay with Flowers */}
              <button
                disabled={buyingGift || (currentUser.flowersCount || 0) < selectedGiftToBuy.cost}
                onClick={() => handlePurchaseGift('flowers')}
                className={`w-full p-3 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                  (currentUser.flowersCount || 0) >= selectedGiftToBuy.cost
                    ? 'border-pink-300 bg-pink-50 hover:bg-pink-100 text-pink-900'
                    : 'border-slate-200 bg-slate-50 opacity-60 cursor-not-allowed text-slate-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">🌸</span>
                  <div className="text-right">
                    <span className="block text-xs font-bold">الدفع برصيد الزهور</span>
                    <span className="text-[10px] text-slate-500">رصيدك: {currentUser.flowersCount || 0} زهرة</span>
                  </div>
                </div>
                <span className="text-xs font-black text-pink-700">
                  {selectedGiftToBuy.cost} 🌸
                </span>
              </button>
            </div>

            {/* Cancel Button */}
            <div className="pt-2">
              <button
                disabled={buyingGift}
                onClick={() => setSelectedGiftToBuy(null)}
                className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================
          MODAL 7: SETTINGS (الإعدادات)
      ======================================================== */}
      {activeModal === 'settings' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-white border border-pink-100 p-6 shadow-2xl space-y-4">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2 font-['Cairo']">
              <Settings className="w-5 h-5 text-sky-600" />
              إعدادات التطبيق والحساب
            </h3>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-sky-600" />
                <span className="text-xs font-bold text-slate-800">إشعارات الرسائل والغرف</span>
              </div>
              <input
                type="checkbox"
                checked={notificationsEnabled}
                onChange={(e) => setNotificationsEnabled(e.target.checked)}
                className="w-4 h-4 accent-pink-600 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-2.5">
                <Volume2 className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-bold text-slate-800">أصوات الهدايا والتفاعل</span>
              </div>
              <input
                type="checkbox"
                checked={soundsEnabled}
                onChange={(e) => setSoundsEnabled(e.target.checked)}
                className="w-4 h-4 accent-pink-600 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">حساب خاص (قبول المتابعين يدوياً)</span>
              </div>
              <input
                type="checkbox"
                checked={privateAccount}
                onChange={(e) => setPrivateAccount(e.target.checked)}
                className="w-4 h-4 accent-pink-600 cursor-pointer"
              />
            </div>

            {/* Download app and source code */}
            {onOpenExport && (
              <div className="pt-1">
                <button
                  onClick={() => {
                    setActiveModal(null);
                    onOpenExport();
                  }}
                  className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-pink-500/10 via-rose-500/10 to-purple-500/10 hover:from-pink-500/20 hover:to-purple-500/20 border border-pink-500/30 text-pink-700 font-bold text-xs flex items-center justify-between transition-all cursor-pointer shadow-sm"
                >
                  <div className="flex items-center gap-2">
                    <Download className="w-4 h-4 text-pink-600" />
                    <span>تحميل ملف التطبيق والشفرة المصدرية (ZIP)</span>
                  </div>
                  <span className="text-[10px] bg-pink-500 text-white px-2 py-0.5 rounded-full font-bold">
                    تحميل
                  </span>
                </button>
              </div>
            )}

            {/* Sign out button in Settings */}
            <div className="pt-2">
              <button
                onClick={handleConfirmSignOut}
                disabled={isSigningOut}
                className="w-full py-2.5 rounded-2xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                {isSigningOut ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <LogOut className="w-4 h-4" />
                )}
                <span>{isSigningOut ? 'جاري تسجيل الخروج...' : 'تسجيل الخروج من الحساب'}</span>
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-pink-50/60 border border-pink-100 text-[11px] text-slate-500 text-center">
              تطبيق زهرة شات (Zahra Chat) • الإصدار 2.4.0 الحقيقي
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          ADMIN & OWNER DASHBOARD MODAL
      ======================================================== */}
      {showAdminDashboard && (
        <AdminDashboard
          currentUser={currentUser}
          onClose={() => setShowAdminDashboard(false)}
          showToast={showToast}
        />
      )}

    </div>
  );
};
