import React, { useState } from 'react';
import { 
  User, 
  Settings, 
  Globe, 
  Bell, 
  Target, 
  Award, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  TrendingUp,
  Sparkles,
  Crown,
  Edit2,
  Edit3,
  ShieldCheck,
  Lock,
  Key,
  LogOut,
  Sliders,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Database,
  ListOrdered,
  Users,
  Gift,
  Camera,
  Upload,
  BookOpen,
  GraduationCap,
  Flame,
  Zap,
  BarChart3,
  Bookmark,
  History,
  AlertTriangle,
  Heart,
  HelpCircle,
  Info,
  FileText,
  Mail,
  Phone,
  Trophy,
  Star,
  CheckSquare,
  XCircle,
  Check,
  X,
  RefreshCw,
  Download,
  Trash2,
  Layers,
  Search,
  Laptop,
  Smartphone,
  MessageSquare,
  Calendar,
  Share2,
  BadgeCheck,
  Copy,
  Send,
  ExternalLink,
  MessageCircle
} from 'lucide-react';
import { UserProfile, ProgressReport, Language } from '../types';
import { EXAM_CATEGORIES } from '../presets';
import AdminWeeklyQuizModal from './AdminWeeklyQuizModal';
import ProfilePhotoModal from './ProfilePhotoModal';
import AdminLoginModal from './admin/AdminLoginModal';
import LanguageSelectionModal from './LanguageSelectionModal';
import EduMindProPaymentModal from './EduMindProPaymentModal';

interface ProfileViewProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  progress: ProgressReport;
  onOpenOnboarding: () => void;
  onNavigateToTab?: (tab: string) => void;
}

export default function ProfileView({
  language,
  setLanguage,
  userProfile,
  setUserProfile,
  progress,
  onOpenOnboarding,
  onNavigateToTab
}: ProfileViewProps) {
  // Modals state
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [showCancelProModal, setShowCancelProModal] = useState<boolean>(false);
  const [showPhotoModal, setShowPhotoModal] = useState<boolean>(false);
  const [showQuickEditModal, setShowQuickEditModal] = useState<boolean>(false);
  const [showTargetGoalsModal, setShowTargetGoalsModal] = useState<boolean>(false);
  const [showStudyPrefModal, setShowStudyPrefModal] = useState<boolean>(false);
  const [showLangVoiceModal, setShowLangVoiceModal] = useState<boolean>(false);
  const [showNotifModal, setShowNotifModal] = useState<boolean>(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState<boolean>(false);
  const [showDevicesModal, setShowDevicesModal] = useState<boolean>(false);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState<boolean>(false);
  const [showRateModal, setShowRateModal] = useState<boolean>(false);
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);
  const [showLogoutModal, setShowLogoutModal] = useState<boolean>(false);
  const [showPasswordModal, setShowPasswordModal] = useState<boolean>(false);
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedMessage, setCopiedMessage] = useState<boolean>(false);
  const [shareLanguage, setShareLanguage] = useState<'bn' | 'en'>(language === 'bn' ? 'bn' : 'en');

  // Rating state
  const [ratingStars, setRatingStars] = useState<number>(5);
  const [ratingFeedback, setRatingFeedback] = useState<string>('');

  // Feedback state
  const [feedbackType, setFeedbackType] = useState<'suggestion' | 'bug' | 'question'>('suggestion');
  const [feedbackText, setFeedbackText] = useState<string>('');

  // Quick Edit Form State
  const [editForm, setEditForm] = useState({
    name: userProfile.name || 'Sudip দাস',
    email: userProfile.email || 'sudipdas22061999@gmail.com',
    phone: userProfile.phone || '+91 98765 43210',
    qualification: userProfile.qualification || 'Higher Secondary',
    boardOrUniversity: userProfile.boardOrUniversity || 'WBBSE / West Bengal Board',
    targetExam: userProfile.targetExam || 'RRB NTPC',
    currentLevel: userProfile.currentLevel || 'Intermediate',
    dailyQuestionTarget: userProfile.dailyQuestionTarget || 100,
    dailyStudyTimeMinutes: userProfile.dailyStudyTimeMinutes || 60
  });

  // Toast Message
  const [toastMessage, setToastMessage] = useState<string>('');

  // Password modal states
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // FAQ Accordion State
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  // AI Learning Preferences State
  const [aiDifficulty, setAiDifficulty] = useState<'Easy' | 'Medium' | 'Hard' | 'Adaptive'>('Adaptive');

  // Notification Toggles
  const [notifState, setNotifState] = useState({
    dailyStudyReminder: true,
    newQuestionsAvailable: true,
    examReminder: true,
    weeklyPerformanceReport: true,
    achievementNotification: true
  });

  const languagesList: { code: Language; name: string }[] = [
    { code: 'en', name: 'English (Global Language)' },
    { code: 'bn', name: 'ভারতীয় বাংলা (Indian Bengali)' },
    { code: 'hi', name: 'हिन्दी (Hindi)' },
  ];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3200);
  };

  const handleAdminLogout = async () => {
    const token = localStorage.getItem('edumind_admin_token');
    if (token) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { 'x-admin-token': token }
        });
      } catch (e) {}
    }
    localStorage.removeItem('edumind_admin_token');
    setUserProfile(prev => ({
      ...prev,
      role: 'user'
    }));
    setShowAdminModal(false);
    showToast(language === 'bn' ? 'অ্যাডমিন মোড থেকে সফলভাবে লগআউট করা হয়েছে।' : 'Admin logged out securely.');
  };

  const handleSavePhoto = (photoUrl: string) => {
    const updated = {
      ...userProfile,
      photoUrl
    };
    setUserProfile(updated);
    try {
      localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      showToast(language === 'bn' ? 'প্রোফাইল ছবি সফলভাবে আপডেট হয়েছে! 🎉' : 'Profile photo updated successfully!');
    } catch (e) {
      console.error('Failed to save profile to localStorage:', e);
    }
  };

  const handleRemovePhoto = () => {
    const updated = {
      ...userProfile,
      photoUrl: undefined
    };
    setUserProfile(updated);
    try {
      localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      showToast(language === 'bn' ? 'প্রোফাইল ছবি সরানো হয়েছে।' : 'Profile photo removed.');
    } catch (e) {
      console.error('Failed to save profile to localStorage:', e);
    }
  };

  const handleSaveQuickEdit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...userProfile,
      name: editForm.name.trim() || userProfile.name,
      email: editForm.email.trim(),
      phone: editForm.phone.trim(),
      qualification: editForm.qualification,
      boardOrUniversity: editForm.boardOrUniversity,
      targetExam: editForm.targetExam,
      currentLevel: editForm.currentLevel as any,
      dailyQuestionTarget: editForm.dailyQuestionTarget,
      dailyStudyTimeMinutes: editForm.dailyStudyTimeMinutes
    };
    setUserProfile(updated);
    try {
      localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      showToast(language === 'bn' ? 'প্রোফাইল তথ্য সফলভাবে সেভ হয়েছে! ✅' : 'Profile information saved successfully!');
    } catch (err) {
      console.error('Save error:', err);
    }
    setShowQuickEditModal(false);
  };

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showToast(language === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast(language === 'bn' ? 'পাসওয়ার্ড দুটি মেলেনি!' : 'Passwords do not match!');
      return;
    }
    setPasswordSuccess(true);
    setTimeout(() => {
      setPasswordSuccess(false);
      setShowPasswordModal(false);
      setNewPassword('');
      setConfirmPassword('');
      showToast(language === 'bn' ? 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে! 🔒' : 'Password changed successfully!');
    }, 1200);
  };

  const handleDeleteAccount = () => {
    localStorage.removeItem('edumind_user_profile');
    localStorage.removeItem('edumind_progress');
    localStorage.removeItem('edumind_admin_token');
    showToast(language === 'bn' ? 'অ্যাকাউন্ট ডেটা সফলভাবে রিসেট করা হয়েছে।' : 'Account data reset successfully.');
    setShowDeleteModal(false);
    setTimeout(() => {
      window.location.reload();
    }, 800);
  };

  const getShareUrl = () => {
    if (typeof window !== 'undefined' && window.location && window.location.origin) {
      return window.location.origin;
    }
    return 'https://ais-pre-drg3qi3qsambfidnto6sxw-658083028999.asia-east1.run.app';
  };

  const getShareText = (lang: 'bn' | 'en') => {
    const url = getShareUrl();
    if (lang === 'bn') {
      return `🎓 StudySkill AI - সেরা স্মার্ট স্টাডি ও সরকারি চাকরির পরীক্ষার প্রস্তুতি প্ল্যাটফর্ম!\n\n✨ AI ডাউট সলভার, অধ্যায়ভিত্তিক প্র্যাকটিস ও ১০০ নম্বরের ফুল মক টেস্ট\n🏆 প্রতি রবিবার সাপ্তাহিক মেগা প্রাইজ কুইজে অংশ নিয়ে জিতে নিন আকর্ষণীয় পুরস্কার!\n\n👉 এখনই বিনামূল্যে প্রস্তুতি শুরু করুন:\n${url}`;
    }
    return `🎓 StudySkill AI - Smart AI Study & Exam Preparation Platform for WBCS, RRB NTPC, SSC, Police & TET!\n\n✨ Instant AI Doubt Solver, Chapter Practice & 100-Mark Full Mock Tests\n🏆 Weekly Sunday Mega Prize Quiz with verified certificates & prizes!\n\n👉 Start learning for free today:\n${url}`;
  };

  const handleNativeShare = async () => {
    const shareUrl = getShareUrl();
    const shareText = getShareText(shareLanguage);
    const shareTitle = 'StudySkill AI - Smart Study & Exam Companion';

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
        showToast(language === 'bn' ? 'অ্যাপ সফলভাবে শেয়ার করা হয়েছে! 🎉' : 'Shared successfully! 🎉');
        return;
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setShowShareModal(true);
        }
        return;
      }
    }
    setShowShareModal(true);
  };

  const handleCopyShareLink = () => {
    const url = getShareUrl();
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedLink(true);
      showToast(language === 'bn' ? 'অ্যাপ লিংক ক্লিপবোর্ডে কপি করা হয়েছে! 📋' : 'App link copied to clipboard! 📋');
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleCopyFullMessage = () => {
    const text = getShareText(shareLanguage);
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedMessage(true);
      showToast(language === 'bn' ? 'সম্পূর্ণ আমন্ত্রণ বার্তা কপি করা হয়েছে! 📋' : 'Full invitation text copied! 📋');
      setTimeout(() => setCopiedMessage(false), 2500);
    }
  };

  const openSocialShare = (platform: 'whatsapp' | 'telegram' | 'facebook' | 'twitter' | 'mail') => {
    const url = getShareUrl();
    const text = getShareText(shareLanguage);
    let shareLink = '';

    switch (platform) {
      case 'whatsapp':
        shareLink = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
        break;
      case 'telegram':
        shareLink = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
        break;
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
        break;
      case 'mail':
        shareLink = `mailto:?subject=${encodeURIComponent(shareLanguage === 'bn' ? 'StudySkill AI - সেরা স্মার্ট স্টাডি প্ল্যাটফর্ম' : 'StudySkill AI - Smart Study Companion')}&body=${encodeURIComponent(text)}`;
        break;
    }

    if (shareLink && typeof window !== 'undefined') {
      window.open(shareLink, '_blank', 'noopener,noreferrer');
    }
  };

  const isAdmin = userProfile.role === 'admin';

  // Learning Metrics Calculation
  const totalQuestions = progress.totalQuestions || 3250;
  const accuracy = progress.accuracy || 87;
  const streakDays = userProfile.streakDays || 120;
  const totalBadges = 15;

  const faqs = [
    {
      q: language === 'bn' ? 'এআই অ্যাডাপ্টিভ লার্নিং কীভাবে কাজ করে?' : 'How does AI Adaptive Learning work?',
      a: language === 'bn' ? 'StudySkill AI আপনার পূর্ববর্তী সঠিক ও ভুল উত্তরের উপর ভিত্তি করে স্বয়ংক্রিয়ভাবে প্রশ্নের কাঠিন্যের মাত্রা (Difficulty) এবং দুর্বল বিষয়ের ওপর বেশি ফোকাস তৈরি করে।' : 'StudySkill AI monitors your answering speed and accuracy in real-time, automatically tailoring the difficulty level and reinforcing your weak topics.'
    },
    {
      q: language === 'bn' ? 'ডেইলি টার্গেট কীভাবে পরিবর্তন করব?' : 'How can I change my Daily Question Target?',
      a: language === 'bn' ? 'প্রোফাইলের "Target & Goals" বাটনটিতে ট্যাপ করে ৫০, ১০০, ১৫০ বা ২০০টি প্রশ্ন নির্বাচন করতে পারেন।' : 'Click on "Target & Goals" to configure 50, 100, 150, or 200 daily questions.'
    },
    {
      q: language === 'bn' ? 'ভুল উত্তরের প্রশ্নগুলো কীভাবে রিভিশন দেব?' : 'How can I practice my mistake questions?',
      a: language === 'bn' ? 'হোম বা এক্সাম পেজে "Mistake Questions" অপশনে ক্লিক করে যেকোনো সময় আপনার ভুল হওয়া প্রশ্নগুলো পুনরায় অনুশীলন করতে পারেন।' : 'Visit the Exam or Home page and click Mistake Bank to review and retake questions you got wrong.'
    },
    {
      q: language === 'bn' ? 'আমার ডেটা কি অফলাইনে সংরক্ষিত থাকে?' : 'Is my data securely stored?',
      a: language === 'bn' ? 'হ্যাঁ, আপনার প্রোফাইল, ফটো ও প্রগ্রেস রিপোর্ট আপনার ডিভাইসে সুরক্ষিতভাবে লোকাল স্টোরেজে সেভ থাকে এবং ক্লাউডেও সিঙ্ক হতে পারে।' : 'Yes, your profile, photo, and learning metrics are securely saved in local storage with instant offline-ready access.'
    }
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 sm:p-5 md:p-6 space-y-4 max-w-md sm:max-w-xl md:max-w-2xl mx-auto w-full pb-24 md:pb-12 text-slate-100 font-sans">
      
      {/* Toast Notification Popup */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-gradient-to-r from-indigo-600 to-purple-600 border border-indigo-400 text-white px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. HERO PROFILE CARD (Matching User's Provided Design) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900/95 via-[#0d1224] to-[#0a0e1c] border border-slate-800/80 p-6 shadow-2xl text-center space-y-4">
        
        {/* Subtle Ambient Radial Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Large Circular Profile Photo with Camera Icon */}
        <div className="relative inline-block mx-auto group">
          {/* Glowing Gradient Border Ring */}
          <div className="w-32 h-32 sm:w-36 sm:h-36 rounded-full p-[3px] bg-gradient-to-b from-indigo-500 via-purple-500 to-pink-500 shadow-xl shadow-indigo-500/20">
            <div className="w-full h-full rounded-full overflow-hidden bg-slate-950 relative">
              {userProfile.photoUrl ? (
                <img
                  src={userProfile.photoUrl}
                  alt={userProfile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-900/60 to-purple-900/60 text-white text-4xl font-black">
                  {userProfile.name ? userProfile.name.charAt(0).toUpperCase() : 'S'}
                </div>
              )}
            </div>
          </div>

          {/* Camera Icon Button on Bottom Right */}
          <button
            type="button"
            onClick={() => setShowPhotoModal(true)}
            title={language === 'bn' ? 'ফটো পরিবর্তন বা আপলোড করুন' : 'Change profile photo'}
            className="absolute bottom-1 right-1 p-2.5 bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-full border-2 border-[#0d1224] shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-transform"
          >
            <Camera className="w-4 h-4" />
          </button>
        </div>

        {/* User Name with Verified Tick Badge */}
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-1.5">
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {userProfile.name || 'Sudip দাস'}
            </h1>
            <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-xs">
              <Check className="w-3 h-3 stroke-[3]" />
            </div>
          </div>

          {/* Motivational Tagline */}
          <p className="text-xs text-slate-400 font-medium">
            Stay focused, Keep learning, Achieve more! ✨
          </p>
        </div>

        {/* 3 Pills: Target Exam, Board, Level */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
          {/* Target Exam Pill */}
          <span className="px-3 py-1 bg-rose-950/40 border border-rose-600/30 text-rose-300 text-xs font-semibold rounded-full flex items-center gap-1.5 shadow-sm">
            <Target className="w-3.5 h-3.5 text-rose-400" />
            <span>{userProfile.targetExam || 'RRB NTPC'}</span>
          </span>

          {/* Board Pill */}
          <span className="px-3 py-1 bg-slate-800/80 border border-slate-700 text-slate-300 text-xs font-semibold rounded-full flex items-center gap-1.5">
            <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
            <span>{userProfile.boardOrUniversity || 'WBBSE / West Bengal Board'}</span>
          </span>

          {/* Level Pill */}
          <span className="px-3 py-1 bg-emerald-950/40 border border-emerald-500/40 text-emerald-400 text-xs font-bold rounded-full flex items-center gap-1">
            <span>{userProfile.currentLevel || 'Intermediate'}</span>
          </span>
        </div>
      </div>

      {/* 👑 STUDYSKILL PRO VIP MEMBERSHIP CARD (৳৯৯ / ₹৯৯ প্রতি মাসে) */}
      <div className={`rounded-3xl border p-4 sm:p-5 transition-all shadow-xl ${
        userProfile.isPro 
          ? 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border-amber-500/50 shadow-amber-500/10' 
          : 'bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/60 border-indigo-500/40 hover:border-amber-500/50'
      }`}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl border ${
              userProfile.isPro 
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' 
                : 'bg-indigo-600/20 border-indigo-500/30 text-amber-400'
            }`}>
              <Crown className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">
                  StudySkill Pro {userProfile.isPro ? '(Active)' : ''}
                </h3>
                <span className={`px-2 py-0.5 text-[9px] font-black rounded uppercase tracking-wider ${
                  userProfile.isPro ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {userProfile.isPro ? 'VIP Active' : '₹৯৯/মাস'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                {userProfile.isPro 
                  ? (language === 'bn' ? '✓ আনলিমিটেড AI স্ক্যান এবং সম্পূর্ণ বিজ্ঞাপন-মুক্ত পড়াশোনা চালু আছে।' : '✓ Unlimited AI scans & 100% ad-free experience is active.')
                  : (language === 'bn' ? 'আনলিমিটেড বই স্ক্যান, টার্বো স্পিড ও ১০০% অ্যাড-ফ্রি সাবস্ক্রিপশন।' : 'Unlimited daily scans, turbo speed & ad-free subscription.')}
              </p>
            </div>
          </div>

          {!userProfile.isPro ? (
            <button
              onClick={() => setShowPaymentModal(true)}
              className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              <Crown className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'Pro কিনুন (₹৯৯/মাস)' : 'Upgrade to Pro (₹99)'}</span>
            </button>
          ) : (
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'bn' ? 'রসিদ ও বিবরণ' : 'Invoice Details'}</span>
              </button>
              
              <button
                onClick={() => setShowCancelProModal(true)}
                className="px-3 py-1.5 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
              >
                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>{language === 'bn' ? 'আনঅ্যাক্টিভ করুন' : 'Deactivate Pro'}</span>
              </button>

              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{language === 'bn' ? 'প্রো সক্রিয়' : 'Pro Active'}</span>
              </div>
            </div>
          )}
        </div>

        {/* Subscription details if active */}
        {userProfile.isPro && userProfile.proExpiryDate && (
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="text-amber-400 font-bold">
                {language === 'bn' ? 'মেয়াদ উত্তীর্ণ:' : 'Valid Until:'} {new Date(userProfile.proExpiryDate).toLocaleDateString()}
              </span>
              {userProfile.proOrderId && (
                <span className="font-mono text-slate-500">
                  (ID: {userProfile.proOrderId})
                </span>
              )}
            </div>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              <span>{language === 'bn' ? 'ভেরিফাইড প্রিমিয়াম লাইসেন্স' : 'Verified Premium License'}</span>
            </span>
          </div>
        )}
      </div>

      {/* 2. PERFORMANCE METRICS CARD (পারফরম্যান্স সারাংশ - 4 Column Layout) */}
      <div className="rounded-3xl bg-[#0e1428] border border-slate-800/90 p-4 shadow-xl">
        <div className="grid grid-cols-4 divide-x divide-slate-800/80 text-center">
          
          {/* Days Active */}
          <div className="px-1 space-y-1">
            <div className="flex items-center justify-center text-emerald-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div className="text-base sm:text-lg font-black text-white font-mono">
              {streakDays}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              Days Active
            </div>
          </div>

          {/* Questions Solved */}
          <div className="px-1 space-y-1">
            <div className="flex items-center justify-center text-sky-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="text-base sm:text-lg font-black text-white font-mono">
              {totalQuestions}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              Questions Solved
            </div>
          </div>

          {/* Accuracy */}
          <div className="px-1 space-y-1">
            <div className="flex items-center justify-center text-amber-400">
              <Target className="w-5 h-5" />
            </div>
            <div className="text-base sm:text-lg font-black text-white font-mono">
              {accuracy}%
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              Accuracy
            </div>
          </div>

          {/* Badges */}
          <div className="px-1 space-y-1">
            <div className="flex items-center justify-center text-purple-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div className="text-base sm:text-lg font-black text-white font-mono">
              {totalBadges}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              Badges
            </div>
          </div>

        </div>
      </div>

      {/* 3. QUICK ACTIONS: EDIT PROFILE & SHARE APP */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => setShowQuickEditModal(true)}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-between shadow-xl shadow-indigo-600/25 cursor-pointer active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-2.5">
            <Edit3 className="w-4 h-4 text-white" />
            <span>{language === 'bn' ? 'প্রোফাইল তথ্য সম্পাদন' : 'Edit Profile'}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-white/90" />
        </button>

        <button
          type="button"
          onClick={handleNativeShare}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-2xl font-black text-xs sm:text-sm flex items-center justify-between shadow-xl shadow-emerald-600/25 cursor-pointer active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-white" />
            <span>{language === 'bn' ? 'অ্যাপটি শেয়ার করুন' : 'Share App'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">
              {language === 'bn' ? 'ইনভাইট' : 'Invite'}
            </span>
            <ChevronRight className="w-4 h-4 text-white/90" />
          </div>
        </button>
      </div>

      {/* 4. ADMIN CONSOLE ACTIVE BANNER (If user is in Admin role) */}
      {isAdmin && (
        <div className="rounded-2xl bg-gradient-to-r from-amber-950/50 via-slate-900 to-amber-950/50 border border-amber-500/50 p-4 space-y-3 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                  অ্যাডমিনিস্ট্রেটর কন্ট্রোল হাব
                  <span className="px-1.5 py-0.2 text-[9px] bg-emerald-500 text-black font-black rounded">ACTIVE</span>
                </h4>
                <p className="text-[10px] text-amber-200/80">কুইজ, প্রশ্নব্যাংক ও মেগা পরীক্ষা পরিচালনা করুন</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShowAdminModal(true)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl cursor-pointer"
              >
                ওপেন হাব
              </button>
              <button
                type="button"
                onClick={handleAdminLogout}
                className="p-1.5 bg-slate-800 hover:bg-rose-900 text-slate-300 hover:text-rose-200 rounded-xl cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. SECTION: ACCOUNT & SETTINGS */}
      <div className="space-y-2 pt-1">
        <h3 className="text-sm font-black text-white px-1 tracking-tight">
          Account & Settings
        </h3>

        <div className="rounded-3xl bg-[#0e1428] border border-slate-800/90 overflow-hidden divide-y divide-slate-800/60 shadow-lg">
          
          {/* 1. Personal Information */}
          <button
            type="button"
            onClick={() => setShowQuickEditModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-sky-400">
                <User className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Personal Information</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 2. Target & Goals */}
          <button
            type="button"
            onClick={() => setShowTargetGoalsModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-rose-400">
                <Target className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Target & Goals</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 3. Study Preferences */}
          <button
            type="button"
            onClick={() => setShowStudyPrefModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-purple-400">
                <Settings className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Study Preferences</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 4. Language & Voice */}
          <button
            type="button"
            onClick={() => setShowLangVoiceModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-blue-400">
                <Globe className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Language & Voice</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 5. Notifications */}
          <button
            type="button"
            onClick={() => setShowNotifModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-sky-400">
                <Bell className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Notifications</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 6. Privacy & Security */}
          <button
            type="button"
            onClick={() => setShowPrivacyModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-cyan-400">
                <Lock className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Privacy & Security</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 7. Connected Devices */}
          <button
            type="button"
            onClick={() => setShowDevicesModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-indigo-400">
                <Laptop className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Connected Devices</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

        </div>
      </div>

      {/* 6. SECTION: SUPPORT & OTHERS */}
      <div className="space-y-2 pt-2">
        <h3 className="text-sm font-black text-white px-1 tracking-tight">
          Support & Others
        </h3>

        <div className="rounded-3xl bg-[#0e1428] border border-slate-800/90 overflow-hidden divide-y divide-slate-800/60 shadow-lg">
          
          {/* 1. Help Center */}
          <button
            type="button"
            onClick={() => setShowHelpModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-indigo-400">
                <HelpCircle className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Help Center</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 2. Feedback & Suggestions */}
          <button
            type="button"
            onClick={() => setShowFeedbackModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-blue-400">
                <MessageSquare className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Feedback & Suggestions</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 3. Rate Us */}
          <button
            type="button"
            onClick={() => setShowRateModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-amber-400">
                <Star className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">Rate Us</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 4. About StudySkill AI */}
          <button
            type="button"
            onClick={() => setShowAboutModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-cyan-400">
                <Info className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-200">About StudySkill AI</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* 5. Logout */}
          <button
            type="button"
            onClick={() => setShowLogoutModal(true)}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-800/50 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="text-rose-400">
                <LogOut className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-rose-400">Logout</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

        </div>
      </div>

      {/* 7. MANDATED: ADMINISTRATOR SECURITY LOGIN BUTTON (UNCHANGED & PRESERVED) */}
      <div className="pt-3 pb-2 text-center">
        {!isAdmin ? (
          <button
            type="button"
            onClick={() => setShowAdminLoginModal(true)}
            className="inline-flex items-center gap-2 text-xs text-slate-400 hover:text-indigo-300 font-semibold cursor-pointer transition-colors p-2.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800"
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'bn' ? 'অ্যাডমিনিস্ট্রেটর সিকিউরিটি লগইন' : 'Administrator Security Login'}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowAdminModal(true)}
            className="inline-flex items-center gap-2 text-xs text-amber-400 hover:text-amber-300 font-black cursor-pointer transition-colors p-2.5 rounded-2xl bg-amber-950/40 border border-amber-500/40"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{language === 'bn' ? 'অ্যাডমিন কনসোল সক্রিয় (ম্যানেজ করুন)' : 'Admin Console Active (Manage)'}</span>
          </button>
        )}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* ALL MODALS FOR SEAMLESS SUB-NAVIGATION */}
      {/* ------------------------------------------------------------- */}

      {/* MODAL 1: QUICK EDIT PROFILE */}
      {showQuickEditModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg p-5 sm:p-7 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 my-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {language === 'bn' ? 'প্রোফাইল তথ্য সম্পাদন' : 'Edit Personal Information'}
                  </h3>
                  <p className="text-xs text-slate-400">{language === 'bn' ? 'নাম, যোগ্যতা ও লক্ষ্য আপডেট করুন' : 'Update personal & academic goals'}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowQuickEditModal(false)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickEdit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'পূর্ণ নাম:' : 'Full Name:'}</label>
                  <input
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'ইমেইল:' : 'Email Address:'}</label>
                  <input
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'মোবাইল নম্বর:' : 'Phone Number:'}</label>
                  <input
                    type="text"
                    value={editForm.phone}
                    onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'টার্গেট পরীক্ষা:' : 'Target Exam:'}</label>
                  <input
                    type="text"
                    value={editForm.targetExam}
                    onChange={(e) => setEditForm(prev => ({ ...prev, targetExam: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'শিক্ষাগত যোগ্যতা:' : 'Qualification:'}</label>
                  <input
                    type="text"
                    value={editForm.qualification}
                    onChange={(e) => setEditForm(prev => ({ ...prev, qualification: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">{language === 'bn' ? 'বোর্ড / বিশ্ববিদ্যালয়:' : 'Board / Institution:'}</label>
                  <input
                    type="text"
                    value={editForm.boardOrUniversity}
                    onChange={(e) => setEditForm(prev => ({ ...prev, boardOrUniversity: e.target.value }))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowQuickEditModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 text-white text-xs font-black rounded-xl shadow-lg cursor-pointer"
                >
                  {language === 'bn' ? 'সংরক্ষণ করুন' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: TARGET & GOALS */}
      {showTargetGoalsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Target & Goals</h3>
                  <p className="text-xs text-slate-400">Manage exam focus and daily milestones</p>
                </div>
              </div>
              <button onClick={() => setShowTargetGoalsModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Primary Target Exam:</label>
                <div className="grid grid-cols-2 gap-2">
                  {['RRB NTPC', 'WBCS', 'SSC CGL', 'Railway Group D', 'WB Police', 'Primary TET'].map(ex => (
                    <button
                      key={ex}
                      type="button"
                      onClick={() => {
                        const updated = { ...userProfile, targetExam: ex };
                        setUserProfile(updated);
                        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
                        showToast(`Target set to ${ex}`);
                      }}
                      className={`p-2.5 rounded-xl border text-left font-bold ${
                        userProfile.targetExam === ex 
                          ? 'bg-rose-600/30 border-rose-500 text-rose-200' 
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      {ex}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Daily Question Target:</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[50, 100, 150, 200].map(q => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => {
                        const updated = { ...userProfile, dailyQuestionTarget: q };
                        setUserProfile(updated);
                        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
                        showToast(`Daily question target set to ${q}`);
                      }}
                      className={`py-2 rounded-xl border font-bold text-center ${
                        (userProfile.dailyQuestionTarget || 100) === q
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      {q} Qs
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
              <button
                type="button"
                onClick={() => {
                  setShowTargetGoalsModal(false);
                  onOpenOnboarding();
                }}
                className="text-xs font-bold text-indigo-400 hover:underline"
              >
                Open Full Goal Wizard →
              </button>
              <button
                type="button"
                onClick={() => setShowTargetGoalsModal(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: STUDY PREFERENCES */}
      {showStudyPrefModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-purple-500/20 text-purple-400 rounded-xl">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Study Preferences</h3>
                  <p className="text-xs text-slate-400">AI Difficulty & Daily Study Time</p>
                </div>
              </div>
              <button onClick={() => setShowStudyPrefModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">AI Difficulty Level:</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Easy', 'Medium', 'Hard', 'Adaptive'].map(diff => (
                    <button
                      key={diff}
                      type="button"
                      onClick={() => {
                        setAiDifficulty(diff as any);
                        showToast(`Difficulty set to ${diff}`);
                      }}
                      className={`p-2.5 rounded-xl border text-left font-bold ${
                        aiDifficulty === diff
                          ? 'bg-purple-600/30 border-purple-500 text-purple-200'
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      {diff === 'Adaptive' ? '⚡ Adaptive (AI)' : diff}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Daily Study Duration:</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[15, 30, 60, 120].map(mins => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => {
                        const updated = { ...userProfile, dailyStudyTimeMinutes: mins };
                        setUserProfile(updated);
                        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
                        showToast(`Daily study goal set to ${mins} mins`);
                      }}
                      className={`py-2 rounded-xl border font-bold text-center ${
                        (userProfile.dailyStudyTimeMinutes || 60) === mins
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      {mins}m
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 text-right">
              <button
                type="button"
                onClick={() => setShowStudyPrefModal(false)}
                className="px-5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs rounded-xl"
              >
                Save Preferences
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: LANGUAGE & VOICE */}
      <LanguageSelectionModal
        isOpen={showLangVoiceModal}
        onClose={() => setShowLangVoiceModal(false)}
        currentLanguage={language}
        onSelectLanguage={(lang) => {
          setLanguage(lang);
          if (setUserProfile) {
            setUserProfile(prev => ({ ...prev, preferredLanguage: lang }));
          }
          showToast(language === 'bn' ? 'ভাষা সফলভাবে আপডেট হয়েছে!' : 'Language updated successfully!');
        }}
        userProfile={userProfile}
        setUserProfile={setUserProfile}
      />

      {/* MODAL 5: NOTIFICATIONS */}
      {showNotifModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Notifications</h3>
                  <p className="text-xs text-slate-400">Configure alert reminders</p>
                </div>
              </div>
              <button onClick={() => setShowNotifModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              {[
                { key: 'dailyStudyReminder', label: 'Daily Study Reminders' },
                { key: 'newQuestionsAvailable', label: 'New Question Bank Alerts' },
                { key: 'examReminder', label: 'Exam & Weekly Quiz Live Alerts' },
                { key: 'weeklyPerformanceReport', label: 'Weekly Performance Digest' },
                { key: 'achievementNotification', label: 'Streak & Badge Celebrations' }
              ].map(item => (
                <div key={item.key} className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="font-semibold text-slate-200">{item.label}</span>
                  <input
                    type="checkbox"
                    checked={(notifState as any)[item.key]}
                    onChange={(e) => {
                      setNotifState(prev => ({ ...prev, [item.key]: e.target.checked }));
                      showToast('Notification settings saved');
                    }}
                    className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                  />
                </div>
              ))}
            </div>

            <div className="pt-2 text-right">
              <button
                type="button"
                onClick={() => setShowNotifModal(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: PRIVACY & SECURITY */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded-xl">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Privacy & Security</h3>
                  <p className="text-xs text-slate-400">Security credentials & data protection</p>
                </div>
              </div>
              <button onClick={() => setShowPrivacyModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5">
              {/* Change Password */}
              <button
                type="button"
                onClick={() => {
                  setShowPrivacyModal(false);
                  setShowPasswordModal(true);
                }}
                className="w-full flex items-center justify-between p-3.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl text-left cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Key className="w-4 h-4 text-amber-400" />
                  <div>
                    <div className="text-xs font-bold text-white">Change Account Password</div>
                    <div className="text-[10px] text-slate-400">Update security passcode</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>

              {/* Administrator Security Login Entry */}
              <button
                type="button"
                onClick={() => {
                  setShowPrivacyModal(false);
                  if (isAdmin) {
                    setShowAdminModal(true);
                  } else {
                    setShowAdminLoginModal(true);
                  }
                }}
                className="w-full flex items-center justify-between p-3.5 bg-slate-950 hover:bg-amber-950/40 border border-slate-800 hover:border-amber-500/40 rounded-2xl text-left cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <div>
                    <div className="text-xs font-bold text-amber-300">Administrator Security Login</div>
                    <div className="text-[10px] text-slate-400">Authorized staff console & quiz management</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-amber-500" />
              </button>

              {/* Data Backup */}
              <button
                type="button"
                onClick={() => {
                  const dataStr = JSON.stringify({ userProfile, progress }, null, 2);
                  const blob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `edumind_backup_${userProfile.name || 'student'}.json`;
                  a.click();
                  showToast('Progress backup downloaded! 💾');
                }}
                className="w-full flex items-center justify-between p-3.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl text-left cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Download className="w-4 h-4 text-indigo-400" />
                  <div>
                    <div className="text-xs font-bold text-white">Export Learning Data (JSON)</div>
                    <div className="text-[10px] text-slate-400">Save offline copy of progress</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>

              {/* Reset Data */}
              <button
                type="button"
                onClick={() => {
                  setShowPrivacyModal(false);
                  setShowDeleteModal(true);
                }}
                className="w-full flex items-center justify-between p-3.5 bg-rose-950/30 hover:bg-rose-950/60 border border-rose-900/40 rounded-2xl text-left cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Trash2 className="w-4 h-4 text-rose-400" />
                  <div>
                    <div className="text-xs font-bold text-rose-300">Delete Account & Reset Data</div>
                    <div className="text-[10px] text-rose-400/70">Wipe local database and profile</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-rose-500" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 7: CONNECTED DEVICES */}
      {showDevicesModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Connected Devices</h3>
                  <p className="text-xs text-slate-400">Active login sessions</p>
                </div>
              </div>
              <button onClick={() => setShowDevicesModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 bg-slate-950 rounded-2xl border border-emerald-500/40 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  <div>
                    <div className="font-bold text-white flex items-center gap-1.5">
                      Current Browser / Device
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-black">THIS DEVICE</span>
                    </div>
                    <div className="text-[10px] text-slate-400">Active Now • Kolkata, India</div>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between opacity-80">
                <div className="flex items-center gap-3">
                  <Laptop className="w-5 h-5 text-indigo-400" />
                  <div>
                    <div className="font-bold text-white">Chrome on Windows 11</div>
                    <div className="text-[10px] text-slate-400">Last active 2 days ago</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
              <button
                type="button"
                onClick={() => {
                  showToast('Logged out of other devices');
                  setShowDevicesModal(false);
                }}
                className="text-xs font-bold text-rose-400 hover:underline cursor-pointer"
              >
                Log out other sessions
              </button>
              <button
                type="button"
                onClick={() => setShowDevicesModal(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 8: HELP CENTER */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Help Center & FAQ</h3>
                  <p className="text-xs text-slate-400">Answers to common queries</p>
                </div>
              </div>
              <button onClick={() => setShowHelpModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 text-xs pr-1">
              {faqs.map((faq, idx) => {
                const isOpen = expandedFaq === idx;
                return (
                  <div key={idx} className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setExpandedFaq(isOpen ? null : idx)}
                      className="w-full flex items-center justify-between p-3.5 text-left text-xs font-bold text-white cursor-pointer hover:bg-slate-800/40"
                    >
                      <span>{faq.q}</span>
                      {isOpen ? <ChevronUp className="w-4 h-4 text-indigo-400" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                    </button>
                    {isOpen && (
                      <div className="px-3.5 pb-3.5 text-xs text-slate-300 border-t border-slate-800/80 pt-2 leading-relaxed">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}

              <div className="p-3.5 bg-indigo-950/30 border border-indigo-500/30 rounded-2xl mt-3 space-y-1">
                <div className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <Mail className="w-4 h-4" /> Need Direct Assistance?
                </div>
                <p className="text-[11px] text-slate-400">Contact our academic team at <span className="text-white font-mono">support@studyskill.ai</span></p>
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                type="button"
                onClick={() => setShowHelpModal(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 9: FEEDBACK & SUGGESTIONS */}
      {showFeedbackModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-500/20 text-blue-400 rounded-xl">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Feedback & Suggestions</h3>
                  <p className="text-xs text-slate-400">Help us improve StudySkill AI</p>
                </div>
              </div>
              <button onClick={() => setShowFeedbackModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Feedback Type:</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'suggestion', label: 'Feature Idea' },
                    { id: 'bug', label: 'Report Issue' },
                    { id: 'question', label: 'General' }
                  ].map(t => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setFeedbackType(t.id as any)}
                      className={`py-2 rounded-xl border font-bold text-center ${
                        feedbackType === t.id
                          ? 'bg-blue-600 border-blue-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-300'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Your Message:</label>
                <textarea
                  rows={4}
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Tell us your feedback or questions..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowFeedbackModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  showToast('Thank you! Your feedback was received. 💌');
                  setFeedbackText('');
                  setShowFeedbackModal(false);
                }}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg"
              >
                Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 10: RATE US */}
      {showRateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 text-center">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 mx-auto flex items-center justify-center">
              <Star className="w-6 h-6 fill-amber-400" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-black text-white">Rate StudySkill AI</h3>
              <p className="text-xs text-slate-400">How is your exam preparation experience?</p>
            </div>

            {/* Stars */}
            <div className="flex items-center justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setRatingStars(s)}
                  className="p-1 transition-transform hover:scale-125 cursor-pointer"
                >
                  <Star className={`w-8 h-8 ${s <= ratingStars ? 'text-amber-400 fill-amber-400' : 'text-slate-700'}`} />
                </button>
              ))}
            </div>

            <textarea
              rows={2}
              value={ratingFeedback}
              onChange={(e) => setRatingFeedback(e.target.value)}
              placeholder="Leave a short review (optional)..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />

            <div className="flex justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowRateModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 font-bold text-xs rounded-xl"
              >
                Maybe Later
              </button>
              <button
                type="button"
                onClick={() => {
                  showToast('Thank you for your 5-star rating! ⭐');
                  setShowRateModal(false);
                }}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 11: ABOUT STUDYSKILL AI */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 text-center">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 mx-auto flex items-center justify-center text-white text-xl font-black shadow-lg shadow-purple-600/30">
              S
            </div>

            <div>
              <h3 className="text-base font-black text-white">StudySkill AI</h3>
              <p className="text-xs text-indigo-300 font-mono">v2.6.4 Pro Edition</p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed text-left bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              Next-generation AI tutor & exam preparation platform for Indian competitive exams (RRB NTPC, WBCS, SSC, Police, TET) powered by Gemini AI with bilingual support.
            </p>

            <div className="text-[11px] text-slate-400 flex items-center justify-center gap-3 pt-1">
              <span>© 2026 StudySkill AI</span>
              <span>•</span>
              <span>All rights reserved</span>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setShowAboutModal(false)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 12: LOGOUT CONFIRMATION */}
      {showLogoutModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/60 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center">
              <LogOut className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-black text-white">Log Out?</h3>
              <p className="text-xs text-slate-400">Are you sure you want to log out of this account session?</p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  showToast('Logged out successfully');
                  setShowLogoutModal(false);
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl shadow-lg"
              >
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 13: CHANGE PASSWORD */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                  <Key className="w-5 h-5" />
                </div>
                <h3 className="text-base font-black text-white">Change Password</h3>
              </div>
              <button onClick={() => setShowPasswordModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {passwordSuccess ? (
              <div className="p-4 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="text-xs font-bold text-emerald-300">Password updated successfully!</div>
              </div>
            ) : (
              <form onSubmit={handleSavePassword} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">New Password:</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Confirm Password:</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition-all"
                >
                  Update Password
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* MODAL 14: DELETE ACCOUNT */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-700/60 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 text-center">
            <div className="p-3 bg-rose-500/20 text-rose-400 rounded-full w-12 h-12 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-white">
              {language === 'bn' ? 'আপনি কি নিশ্চিত ডেটা মুছতে চান?' : 'Are you sure you want to reset data?'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'bn' 
                ? 'এটি আপনার সমস্ত সংরক্ষিত প্রশ্ন, টেস্ট স্কোর, কুইজ হিস্ট্রি ও প্রোফাইল ফটো মুছে ফেলবে।' 
                : 'This will erase all your local study progress, streak records, saved bookmarks, and custom photo.'}
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteAccount}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-lg cursor-pointer"
              >
                Yes, Delete Everything
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SHARE APP MODAL */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 my-6 text-left">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30 shadow-inner">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    {language === 'bn' ? 'StudySkill AI শেয়ার করুন' : 'Share StudySkill AI'}
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-bold">
                      Invite
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'বন্ধুদের সাথে অ্যাপটি শেয়ার করে একসাথে প্রস্তুতি নিন' : 'Invite your friends to study & compete together'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* App Preview Card */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/30 flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-teal-400 flex items-center justify-center text-white font-black text-xl shadow-lg shrink-0">
                S
              </div>
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="text-sm font-black text-white truncate">StudySkill AI</h4>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 bg-indigo-500/30 text-indigo-300 rounded border border-indigo-500/40">
                    Smart Study
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 line-clamp-1">
                  AI Doubt Solver • Mock Tests • Sunday Mega Quiz
                </p>
                <p className="text-[10px] text-emerald-400 font-mono font-medium truncate">
                  {getShareUrl()}
                </p>
              </div>
            </div>

            {/* Language Selection for Invitation Message */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'আমন্ত্রণ বার্তার ভাষা:' : 'Invitation Message Language:'}
                </label>
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShareLanguage('bn')}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      shareLanguage === 'bn'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    বাংলা
                  </button>
                  <button
                    type="button"
                    onClick={() => setShareLanguage('en')}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      shareLanguage === 'en'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Message Box with Copy option */}
              <div className="relative">
                <div className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs text-slate-300 font-sans leading-relaxed whitespace-pre-line max-h-32 overflow-y-auto">
                  {getShareText(shareLanguage)}
                </div>
                <button
                  type="button"
                  onClick={handleCopyFullMessage}
                  className="absolute top-2 right-2 px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-[10px] font-bold flex items-center gap-1 border border-slate-700 backdrop-blur-sm cursor-pointer shadow transition-all"
                >
                  {copiedMessage ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-300">{language === 'bn' ? 'কপি হয়েছে' : 'Copied'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3 text-slate-400" />
                      <span>{language === 'bn' ? 'টেক্সট কপি' : 'Copy Text'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Direct Social Channels */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">
                {language === 'bn' ? 'সরাসরি শেয়ার করুন:' : 'Share Directly Via:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* WhatsApp */}
                <button
                  type="button"
                  onClick={() => openSocialShare('whatsapp')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm group"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <span>WhatsApp</span>
                </button>

                {/* Telegram */}
                <button
                  type="button"
                  onClick={() => openSocialShare('telegram')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-sky-950/60 hover:bg-sky-900/80 border border-sky-500/40 text-sky-300 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm group"
                >
                  <Send className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
                  <span>Telegram</span>
                </button>

                {/* Facebook */}
                <button
                  type="button"
                  onClick={() => openSocialShare('facebook')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-blue-950/60 hover:bg-blue-900/80 border border-blue-500/40 text-blue-300 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm group"
                >
                  <Globe className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
                  <span>Facebook</span>
                </button>

                {/* Twitter / X */}
                <button
                  type="button"
                  onClick={() => openSocialShare('twitter')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm group"
                >
                  <Sparkles className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span>X / Tweet</span>
                </button>
              </div>
            </div>

            {/* Link Copy Box */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs font-bold text-slate-300 block">
                {language === 'bn' ? 'অ্যাপ শেয়ার লিংক:' : 'Direct App Share Link:'}
              </label>
              <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-2xl p-1.5 pl-3">
                <input
                  type="text"
                  readOnly
                  value={getShareUrl()}
                  className="w-full bg-transparent text-xs text-indigo-300 font-mono focus:outline-none select-all truncate"
                />
                <button
                  type="button"
                  onClick={handleCopyShareLink}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer shadow-md ${
                    copiedLink
                      ? 'bg-emerald-600 text-white'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'কপি হয়েছে' : 'Copied!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'লিংক কপি' : 'Copy Link'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Native Mobile Share Button (if supported) */}
            {typeof navigator !== 'undefined' && navigator.share && (
              <button
                type="button"
                onClick={handleNativeShare}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-black text-xs sm:text-sm rounded-2xl shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99]"
              >
                <Smartphone className="w-4 h-4" />
                <span>{language === 'bn' ? 'ডিভাইসের অন্যান্য অ্যাপে শেয়ার করুন 📲' : 'Share via Device Apps (WhatsApp, SMS, etc.) 📲'}</span>
              </button>
            )}

            {/* Footer Note */}
            <div className="text-center pt-1">
              <p className="text-[11px] text-slate-400">
                {language === 'bn'
                  ? '💡 আপনার বন্ধুদের সাথে শেয়ার করে মেগা কুইজ ও স্টাডি লিডারবোর্ডে একসাথে প্রতিযোগিতা করুন।'
                  : '💡 Share with friends and compete together in weekly quizzes and leaderboards.'}
              </p>
            </div>

          </div>
        </div>
      )}

      {/* MODAL 15: MANDATED DEDICATED ADMINISTRATOR LOGIN MODAL */}
      {showAdminLoginModal && (
        <AdminLoginModal
          language={language}
          onClose={() => setShowAdminLoginModal(false)}
          onSuccess={(token, adminUser) => {
            localStorage.setItem('edumind_admin_token', token);
            setUserProfile(prev => ({
              ...prev,
              role: 'admin'
            }));
            setShowAdminLoginModal(false);
            setShowAdminModal(true);
            showToast(
              language === 'bn' 
                ? `অ্যাডমিন হিসেবে লগইন সফল: ${adminUser.email} 🛡️` 
                : `Admin session verified: ${adminUser.email} 🛡️`
            );
          }}
        />
      )}

      {/* Admin Weekly Quiz & Question Bank Modal */}
      {showAdminModal && (
        <AdminWeeklyQuizModal
          language={language}
          onClose={() => setShowAdminModal(false)}
          onQuizUpdated={() => {}}
          onLogoutAdmin={handleAdminLogout}
        />
      )}

      {/* User Profile Photo Upload / Change Modal */}
      {showPhotoModal && (
        <ProfilePhotoModal
          language={language}
          currentPhotoUrl={userProfile.photoUrl}
          userName={userProfile.name}
          onSave={handleSavePhoto}
          onRemove={handleRemovePhoto}
          onClose={() => setShowPhotoModal(false)}
        />
      )}

      {/* 👑 StudySkill Pro Payment Gateway Checkout Modal */}
      {showPaymentModal && (
        <EduMindProPaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          language={language}
          userProfile={userProfile}
          setUserProfile={setUserProfile}
          onPaymentSuccess={(subscription) => {
            showToast(
              language === 'bn'
                ? '👑 অভিনন্দন! StudySkill Pro সাবস্ক্রিপশন সফলভাবে সক্রিয় করা হয়েছে।'
                : '👑 Congratulations! StudySkill Pro subscription activated successfully.'
            );
          }}
        />
      )}

      {/* 🛑 StudySkill Pro Deactivation / Cancellation Confirmation Modal */}
      {showCancelProModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-black text-white">
                {language === 'bn' ? 'StudySkill Pro সাবস্ক্রিপশন আনঅ্যাক্টিভ করতে চান?' : 'Deactivate StudySkill Pro Subscription?'}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {language === 'bn'
                  ? 'সাবস্ক্রিপশন আনঅ্যাক্টিভ করলে আপনি আনলিমিটেড AI স্ক্যান সুবিধা থেকে স্ট্যান্ডার্ড দৈনিক ফ্রি ৩টি স্ক্যান লিমিটে ফিরে যাবেন।'
                  : 'By deactivating, your VIP status will be removed and you will return to standard 3 daily free scans.'}
              </p>
            </div>

            {userProfile.proExpiryDate && (
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-left text-xs space-y-1">
                <div className="text-slate-400 flex justify-between">
                  <span>{language === 'bn' ? 'বর্তমান প্ল্যান:' : 'Current Plan:'}</span>
                  <span className="font-bold text-white uppercase">{userProfile.proPlan || 'Monthly'}</span>
                </div>
                <div className="text-slate-400 flex justify-between">
                  <span>{language === 'bn' ? 'মেয়াদ:' : 'Valid Until:'}</span>
                  <span className="font-bold text-amber-300">{new Date(userProfile.proExpiryDate).toLocaleDateString()}</span>
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCancelProModal(false)}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                {language === 'bn' ? 'ফিরে যান' : 'Keep Active'}
              </button>

              <button
                type="button"
                onClick={async () => {
                  try {
                    // Call backend deactivation
                    fetch('/api/payment/deactivate', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        userId: userProfile.id,
                        orderId: userProfile.proOrderId
                      })
                    }).catch(() => {});

                    // Reset local profile
                    const updated: UserProfile = {
                      ...userProfile,
                      isPro: false,
                      proPlan: undefined,
                      proExpiryDate: undefined,
                      proOrderId: undefined,
                      proPaymentMethod: undefined,
                      proPaidAmount: undefined,
                      proTransactionId: undefined
                    };
                    setUserProfile(updated);

                    // Clear local storage
                    try {
                      localStorage.removeItem('edumind_is_pro');
                      localStorage.removeItem('edumind_pro_expiry');
                      localStorage.removeItem('edumind_last_payment');
                      localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
                    } catch (e) {}

                    setShowCancelProModal(false);
                    showToast(
                      language === 'bn'
                        ? '✓ StudySkill Pro সাবস্ক্রিপশন সফলভাবে আনঅ্যাক্টিভ করা হয়েছে।'
                        : '✓ StudySkill Pro subscription has been deactivated.'
                    );
                  } catch (e) {
                    setShowCancelProModal(false);
                  }
                }}
                className="flex-1 py-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs rounded-xl shadow-lg shadow-rose-600/20 active:scale-95 transition-all cursor-pointer"
              >
                {language === 'bn' ? 'হ্যাঁ, আনঅ্যাক্টিভ করুন' : 'Yes, Deactivate'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
