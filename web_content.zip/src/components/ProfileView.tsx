import React from 'react';
import { User, Wallet, RotateCcw, TrendingUp, Award, Download, ShieldCheck, CheckCircle2, XCircle } from 'lucide-react';
import { TradeOrder, BotSettings } from '../types/trading';
import { soundManager } from '../utils/soundEffects';

interface ProfileViewProps {
  balance: number;
  onResetBalance: () => void;
  tradeHistory: TradeOrder[];
  botSettings: BotSettings;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  balance,
  onResetBalance,
  tradeHistory,
  botSettings,
}) => {
  const totalTrades = tradeHistory.length;
  const wonTrades = tradeHistory.filter((t) => t.status === 'WON').length;
  const winRate = totalTrades > 0 ? ((wonTrades / totalTrades) * 100).toFixed(1) : '100.0';
  const totalProfit = tradeHistory.reduce((acc, t) => acc + (t.actualProfit || 0), 0);

  const exportCSV = () => {
    soundManager.playPip();
    if (tradeHistory.length === 0) return;
    const headers = 'ID,Pair,Direction,Stake,Payout,Status,Profit,OpenedAt\n';
    const rows = tradeHistory
      .map(
        (t) =>
          `${t.id},${t.pair},${t.direction},${t.stake},${t.payoutPercent}%,${t.status},${t.actualProfit || 0},${new Date(
            t.openedAt
          ).toISOString()}`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `quotex_bot_trades_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col items-center px-3 py-3 space-y-4">
      {/* Trader Profile Banner */}
      <div className="w-full bg-[#180710] border border-[#3b1223] rounded-2xl p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-600 to-rose-950 p-0.5 border border-red-500/40 flex items-center justify-center text-white font-black text-lg shadow-md">
            QX
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-slate-100">ELITE QUOTEX TRADER</h2>
              <span className="text-[10px] font-bold px-1.5 py-0.2 bg-emerald-950 text-emerald-400 border border-emerald-800/40 rounded font-mono">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] font-mono text-zinc-400 mt-0.5">
              Account ID: {botSettings.quotexAccountId || 'QX-DEMO-99BOT'}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            soundManager.playPip();
            onResetBalance();
          }}
          className="p-2 rounded-xl bg-[#230916] hover:bg-[#300e1f] text-zinc-400 hover:text-white border border-[#3b1223] transition-colors"
          title="Reset Demo Balance to $10,000"
        >
          <RotateCcw className="w-4 h-4 text-red-400" />
        </button>
      </div>

      {/* Balance Card */}
      <div className="w-full bg-gradient-to-r from-[#1f0914] via-[#290c1a] to-[#1a0711] border border-[#44142a] rounded-2xl p-4 shadow-lg flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">
            DEMO ACCOUNT BALANCE
          </span>
          <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400 tabular-nums mt-0.5">
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] font-medium text-zinc-400">
            PnL Today:{' '}
            <strong className={totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}>
              {totalProfit >= 0 ? `+$${totalProfit.toFixed(2)}` : `-$${Math.abs(totalProfit).toFixed(2)}`}
            </strong>
          </span>
        </div>

        <button
          onClick={() => {
            soundManager.playPip();
            onResetBalance();
          }}
          className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition-all shadow-md active:scale-95"
        >
          Reset $10,000
        </button>
      </div>

      {/* 4 Stats Grid */}
      <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="bg-[#16060f] border border-[#2d0d1a] rounded-xl p-2.5 text-center">
          <span className="text-[10px] font-bold text-zinc-400 uppercase">Total Trades</span>
          <div className="text-lg font-black font-mono text-slate-100 mt-0.5">{totalTrades}</div>
        </div>

        <div className="bg-[#16060f] border border-[#2d0d1a] rounded-xl p-2.5 text-center">
          <span className="text-[10px] font-bold text-zinc-400 uppercase">Win Rate</span>
          <div className="text-lg font-black font-mono text-emerald-400 mt-0.5">{winRate}%</div>
        </div>

        <div className="bg-[#16060f] border border-[#2d0d1a] rounded-xl p-2.5 text-center">
          <span className="text-[10px] font-bold text-zinc-400 uppercase">Won / Lost</span>
          <div className="text-lg font-black font-mono text-zinc-200 mt-0.5">
            <span className="text-emerald-400">{wonTrades}</span> /{' '}
            <span className="text-red-400">{totalTrades - wonTrades}</span>
          </div>
        </div>

        <div className="bg-[#16060f] border border-[#2d0d1a] rounded-xl p-2.5 text-center">
          <span className="text-[10px] font-bold text-zinc-400 uppercase">99% Sniper Mode</span>
          <div className="text-xs font-black font-mono text-amber-300 mt-1.5">
            {botSettings.strongSniperMode99 ? 'ACTIVE' : 'OFF'}
          </div>
        </div>
      </div>

      {/* Trade History Section */}
      <div className="w-full space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Trade Execution Log
          </span>
          <button
            onClick={exportCSV}
            disabled={tradeHistory.length === 0}
            className="flex items-center gap-1 text-[11px] font-bold text-red-400 hover:text-red-300 disabled:opacity-40 transition-colors"
          >
            <Download className="w-3 h-3" />
            <span>Export CSV</span>
          </button>
        </div>

        {tradeHistory.length === 0 ? (
          <div className="w-full bg-[#14050d] border border-[#2b0d19] rounded-xl p-6 text-center text-xs text-zinc-500">
            No trades executed yet. Enter a signal from the Trade tab to record performance.
          </div>
        ) : (
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-0.5 custom-scrollbar">
            {tradeHistory.map((trade) => {
              const isWon = trade.status === 'WON';
              return (
                <div
                  key={trade.id}
                  className="w-full bg-[#16060f] border border-[#2c0d1a] rounded-xl p-2.5 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    {isWon ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                    )}
                    <div>
                      <div className="flex items-center gap-1.5 font-bold font-mono text-slate-100">
                        <span>{trade.pair}</span>
                        <span
                          className={`text-[9px] px-1 rounded ${
                            trade.direction === 'UP'
                              ? 'bg-emerald-950 text-emerald-400'
                              : 'bg-red-950 text-red-400'
                          }`}
                        >
                          {trade.direction}
                        </span>
                        {trade.isSniper99 && (
                          <span className="text-[9px] text-amber-300 font-extrabold font-mono">
                            ★99%
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-zinc-500 font-mono">
                        Stake: ${trade.stake} · Entry: {trade.entryPrice.toFixed(4)}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`font-black font-mono text-sm tabular-nums ${
                        isWon ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {isWon ? `+$${(trade.actualProfit || 0).toFixed(2)}` : `-$${trade.stake.toFixed(2)}`}
                    </div>
                    <span className="text-[9px] font-bold text-zinc-500 uppercase font-mono">
                      {trade.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
