import React, { useState, useEffect } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import { NICASLevelNumber, CandidateProfile } from '../types/climbing';
import {
  User,
  Shield,
  Award,
  Building,
  Phone,
  HeartPulse,
  Save,
  CheckCircle2
} from 'lucide-react';

interface ProfileViewProps {
  onSaved?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onSaved }) => {
  const { profile, updateProfile, clubs } = useClimbing();

  const [formData, setFormData] = useState<CandidateProfile>(profile);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  useEffect(() => {
    setFormData(profile);
  }, [profile]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 3000);
    if (onSaved) onSaved();
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5 text-slate-900 dark:text-slate-100">
      {/* Toast Alert */}
      {showSuccessToast && (
        <div className="p-3.5 sm:p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-between shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <p className="text-xs sm:text-sm font-bold text-emerald-900 dark:text-emerald-200">
              Climber profile details updated successfully!
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowSuccessToast(false)}
            className="text-xs text-emerald-700 dark:text-emerald-400 hover:underline font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Profile Card */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        {/* Header */}
        <div className="px-5 py-5 sm:px-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-950/80 border border-orange-200 dark:border-orange-800 flex items-center justify-center text-orange-600 dark:text-orange-400 font-bold shrink-0">
              <User className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-semibold text-orange-600 uppercase tracking-wider">Candidate Registry</span>
              <h2 className="text-lg sm:text-xl font-bold">Climber Profile & Credentials</h2>
            </div>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
            Track: <span className="font-semibold text-slate-700 dark:text-slate-300">{formData.schemeTrack}</span>
          </div>
        </div>

        {/* Profile Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-6">
          {/* Section 1: Personal & Identification */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-orange-600" />
              <span>Personal Details</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Name */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Climber Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Morgan"
                  value={formData.candidateName}
                  onChange={e => setFormData({ ...formData, candidateName: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                />
              </div>

              {/* NICAS Number */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">NICAS Registration Number *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. NICAS-UK-2026-8841"
                  value={formData.candidateNumber}
                  onChange={e => setFormData({ ...formData, candidateNumber: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
                />
              </div>

              {/* Age */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Age</label>
                <input
                  type="number"
                  min="4"
                  max="99"
                  placeholder="e.g. 15"
                  value={formData.age ?? ''}
                  onChange={e => setFormData({ ...formData, age: e.target.value === '' ? '' : parseInt(e.target.value, 10) })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono tabular-nums text-slate-900 dark:text-white"
                />
              </div>

              {/* Date of Birth */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Date of Birth</label>
                <input
                  type="date"
                  value={formData.dateOfBirth || ''}
                  onChange={e => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 2: NICAS Scheme Progression & Centre */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-orange-600" />
              <span>NICAS Scheme & Course Details</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Scheme Track */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Scheme Track</label>
                <select
                  value={formData.schemeTrack}
                  onChange={e => setFormData({ ...formData, schemeTrack: e.target.value as any })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium text-slate-900 dark:text-white"
                >
                  <option value="NICAS Roped Climbing">NICAS Roped Climbing</option>
                  <option value="NICAS Bouldering">NICAS Bouldering</option>
                  <option value="Combined">Combined (Roped & Bouldering)</option>
                </select>
              </div>

              {/* Current Level */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Current Active Level</label>
                <select
                  value={formData.currentLevel}
                  onChange={e => setFormData({ ...formData, currentLevel: parseInt(e.target.value, 10) as NICASLevelNumber })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-bold font-mono text-orange-600 dark:text-orange-400"
                >
                  <option value={1}>Level 1: New Climber</option>
                  <option value={2}>Level 2: Foundation</option>
                  <option value={3}>Level 3: Technical</option>
                  <option value={4}>Level 4: Lead Climber</option>
                  <option value={5}>Level 5: Advanced & Performance</option>
                </select>
              </div>

              {/* Target Level */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Target Level</label>
                <select
                  value={formData.targetLevel}
                  onChange={e => setFormData({ ...formData, targetLevel: parseInt(e.target.value, 10) as NICASLevelNumber })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-bold font-mono text-slate-900 dark:text-white"
                >
                  <option value={1}>Level 1: New Climber</option>
                  <option value={2}>Level 2: Foundation</option>
                  <option value={3}>Level 3: Technical</option>
                  <option value={4}>Level 4: Lead Climber</option>
                  <option value={5}>Level 5: Advanced & Performance</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              {/* Home Club */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Building className="w-3 h-3 text-slate-400" />
                  <span>Home Climbing Centre / Wall</span>
                </label>
                <select
                  value={formData.homeClubId}
                  onChange={e => setFormData({ ...formData, homeClubId: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                >
                  {clubs.map(club => (
                    <option key={club.id} value={club.id}>
                      {club.name} {club.isOfficialNicasCentre ? '(NICAS Centre)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Lead Instructor */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Shield className="w-3 h-3 text-slate-400" />
                  <span>Lead Instructor / Course Director</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Dave Macleod (MCI)"
                  value={formData.leadInstructor}
                  onChange={e => setFormData({ ...formData, leadInstructor: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Safety & Emergency Contacts */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-orange-600" />
              <span>Emergency Contact & Medical Details</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Emergency Contact Name</label>
                <input
                  type="text"
                  placeholder="Parent / Guardian / Partner name"
                  value={formData.emergencyContactName || ''}
                  onChange={e => setFormData({ ...formData, emergencyContactName: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Emergency Contact Telephone</label>
                <input
                  type="tel"
                  placeholder="+44 7... or 07..."
                  value={formData.emergencyContactPhone || ''}
                  onChange={e => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="space-y-1 mt-4">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                <HeartPulse className="w-3.5 h-3.5 text-red-500" />
                <span>Medical Notes, Allergies or Considerations</span>
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Asthma inhaler kept in chalk bag, mild shoulder impingement, tape needed for wrists..."
                value={formData.medicalNotes || ''}
                onChange={e => setFormData({ ...formData, medicalNotes: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Credentials are included on all PDF logbook reports.
            </span>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Climber Profile</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
