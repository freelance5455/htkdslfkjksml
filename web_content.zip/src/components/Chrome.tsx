import { useEffect, useState } from "react";
import { CALL_NUMBER, WA_NUMBER, waLink } from "../data/shops";
import { IMG } from "../media";
import { useStore } from "../store";
import {
  IconBag,
  IconCart,
  IconDownload,
  IconHome,
  IconMenu,
  IconPhone,
  IconSearch,
  IconUser,
  IconWA,
  IconX,
} from "./Icons";

const NAV = [
  { id: "home", label: "Home" },
  { id: "restaurants", label: "Restaurants" },
  { id: "categories", label: "Categories" },
  { id: "about", label: "About Us" },
];

export function Navbar() {
  const { scrolled, count, setModal, user } = useStore();
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const ids = NAV.map((n) => n.id);
    const onScroll = () => {
      for (const id of [...ids].reverse()) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= 120) {
          setActive(id);
          return;
        }
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "ios-blur-light border-b border-black/6 py-2.5" : "bg-transparent py-4"
      }`}
    >
      <div className="mx-auto flex max-w-[1240px] items-center justify-between px-5">
        <a href="#home" className="flex items-center gap-2 press">
          <span className="leading-none">
            <span className="block text-[20px] font-extrabold tracking-tight">
              <span className="text-[#FF6A00]">TURF</span>
              <span className={scrolled ? "text-[#171717]" : "text-white"}>BUDDY</span>
            </span>
            <span className={`text-[8px] font-semibold tracking-[0.22em] ${scrolled ? "text-black/40" : "text-white/50"}`}>
              FOOD. DRINKS. ERRANDS.
            </span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => go(n.id)}
              className={`rounded-full px-4 py-2 text-[13px] font-semibold transition-all ${
                active === n.id
                  ? "bg-[#FF6A00] text-white"
                  : scrolled
                    ? "text-[#444] hover:bg-black/5"
                    : "text-white/75 hover:bg-white/8 hover:text-white"
              }`}
            >
              {n.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setModal("cart")}
            className={`relative grid h-10 w-10 place-items-center rounded-full border press ${
              scrolled ? "border-black/10 text-[#171717]" : "border-white/14 text-white"
            }`}
            aria-label="Cart"
          >
            <IconCart className="h-[18px] w-[18px]" />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#FF6A00] px-1 text-[10px] font-bold text-white">
                {count}
              </span>
            )}
          </button>
          <button
            onClick={() => setModal("auth")}
            className={`hidden h-10 items-center rounded-full border px-5 text-[13px] font-semibold press md:flex ${
              scrolled ? "border-black/12 text-[#171717]" : "border-white/20 text-white"
            }`}
          >
            {user ? user.name.split(" ")[0] : "Login"}
          </button>
          <button
            onClick={() => setModal("auth")}
            className="hidden h-10 items-center rounded-full bg-[#FF6A00] px-5 text-[13px] font-bold text-white press sm:flex"
          >
            Sign Up
          </button>
          <button
            className={`grid h-10 w-10 place-items-center rounded-full border lg:hidden ${
              scrolled ? "border-black/10 text-[#171717]" : "border-white/20 text-white"
            }`}
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <IconX /> : <IconMenu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="ios-blur mx-4 mt-3 rounded-2xl border border-white/10 p-3 text-white lg:hidden fade">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => go(n.id)}
              className="block w-full rounded-xl px-3 py-3 text-left text-sm font-semibold text-white/85 hover:bg-white/6"
            >
              {n.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}

export function MobileDock() {
  const { count, setModal } = useStore();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-black/6 bg-white/95 px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 text-[#111] backdrop-blur-xl md:hidden">
      <div className="mx-auto grid max-w-md grid-cols-4">
        <a href="#home" className="flex flex-col items-center gap-0.5 py-1 text-[10px] font-bold text-[#FF6A00]">
          <IconHome className="h-5 w-5" /> Home
        </a>
        <button onClick={() => setModal("search")} className="flex flex-col items-center gap-0.5 py-1 text-[10px] font-bold text-white/45">
          <IconSearch className="h-5 w-5" /> Search
        </button>
        <button onClick={() => setModal("cart")} className="relative flex flex-col items-center gap-0.5 py-1 text-[10px] font-bold text-white/45">
          <IconBag className="h-5 w-5" />
          {count > 0 && (
            <span className="absolute right-5 top-0 grid h-4 min-w-4 place-items-center rounded-full bg-[#FF6A00] px-1 text-[9px] text-white">
              {count}
            </span>
          )}
          Orders
        </button>
        <button onClick={() => setModal("auth")} className="flex flex-col items-center gap-0.5 py-1 text-[10px] font-bold text-[#888]">
          <IconUser className="h-5 w-5" /> Profile
        </button>
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/8 bg-[#0a0a0a] pt-16 pb-8 text-white">
      <div className="mx-auto grid max-w-[1280px] gap-10 px-4 md:grid-cols-4 md:px-6">
        <div>
          <div className="text-[22px] font-extrabold">
            <span className="text-[#FF6A00]">TURF</span>
            <span className="text-white">BUDDY</span>
          </div>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-white/55">
            Food, drinks and errands from Gate 1, Gate 2, Mankweng and Paledi. Delivered in 30–45 minutes.
          </p>
          <div className="mt-5 flex gap-2">
            <a href={`tel:${CALL_NUMBER}`} className="grid h-10 w-10 place-items-center rounded-full bg-white/8">
              <IconPhone />
            </a>
            <a
              href={waLink("Hi TurfBuddy")}
              target="_blank"
              rel="noreferrer"
              className="grid h-10 w-10 place-items-center rounded-full bg-[#25D366] text-white"
            >
              <IconWA />
            </a>
          </div>
        </div>
        <div>
          <h4 className="text-sm font-bold text-white">Quick links</h4>
          <ul className="mt-4 space-y-2 text-sm text-white/55">
            <li><a href="#home" className="hover:text-white">Home</a></li>
            <li><a href="#restaurants" className="hover:text-white">Restaurants</a></li>
            <li><a href="#how" className="hover:text-white">How it works</a></li>
            <li><a href="#pricing" className="hover:text-white">Delivery fees</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-bold text-white">Services</h4>
          <ul className="mt-4 space-y-2 text-sm text-white/55">
            <li>Food delivery</li>
            <li>Pickup & drop off</li>
            <li>Personal errands</li>
            <li>Corporate delivery</li>
            <li>Liquor & groceries</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-bold text-white">Contact</h4>
          <ul className="mt-4 space-y-2 text-sm text-white/55">
            <li>WhatsApp {WA_NUMBER.replace("27", "0")}</li>
            <li>Call {CALL_NUMBER}</li>
            <li>Capitec 2581414703 · TURFBUDDY</li>
            <li>Gate 1 · Gate 2 · Mankweng · Paledi</li>
          </ul>
        </div>
      </div>
      <p className="mx-auto mt-12 max-w-[1280px] px-4 text-center text-xs text-white/35 md:px-6">
        © {new Date().getFullYear()} TurfBuddy. All rights reserved.
      </p>
    </footer>
  );
}

export function Floating() {
  const { scrolled, setModal, count } = useStore();
  const [chat, setChat] = useState(false);
  if (!scrolled) return null;
  return (
    <div className="fixed bottom-20 right-5 z-40 flex flex-col items-end gap-3 md:bottom-5">
      {chat && (
        <div className="slide-up w-[300px] overflow-hidden rounded-3xl border border-white/10 bg-[#161616] text-white shadow-2xl">
          <div className="flex items-center justify-between bg-[#075E54] px-4 py-3">
            <div className="flex items-center gap-2">
              <img src={IMG.appIcon} className="h-8 w-8 rounded-full" alt="" />
              <div>
                <p className="text-sm font-bold">TurfBuddy</p>
                <p className="text-[11px] text-white/70">Typically replies instantly</p>
              </div>
            </div>
            <button onClick={() => setChat(false)}><IconX className="h-4 w-4" /></button>
          </div>
          <div className="space-y-2 bg-[#0b1410] p-4 text-sm">
            <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-[#1f2c26] px-3 py-2 text-white/90">
              Sawubona. Ready to order from Gate 1, Gate 2, Mankweng or Paledi?
            </div>
            <a
              href={waLink("Hi TurfBuddy, I want to place an order.")}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] py-2.5 text-sm font-bold text-[#052e16]"
            >
              <IconWA /> Chat on WhatsApp
            </a>
          </div>
        </div>
      )}
      <div className="flex items-center gap-2">
        {count > 0 && (
          <button
            onClick={() => setModal("cart")}
            className="grid h-12 w-12 place-items-center rounded-full bg-white text-black shadow-xl press"
          >
            <span className="relative">
              <IconCart />
              <span className="absolute -right-2 -top-2 grid h-4 w-4 place-items-center rounded-full bg-[#FF6A00] text-[9px] font-bold text-white">
                {count}
              </span>
            </span>
          </button>
        )}
        <button
          onClick={() => setChat((v) => !v)}
          className="pulse-glow grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-xl press"
          aria-label="WhatsApp"
        >
          <IconWA className="h-7 w-7" />
        </button>
      </div>
    </div>
  );
}

export function Toast() {
  const { toast } = useStore();
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed bottom-24 left-1/2 z-50 -translate-x-1/2 pop rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-black shadow-2xl">
      {toast}
    </div>
  );
}

export function InstallPrompt() {
  const [show, setShow] = useState(false);
  const [deferred, setDeferred] = useState<{ prompt: () => Promise<void> } | null>(null);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("tb-install-hide");
    const onBIP = (e: Event) => {
      e.preventDefault();
      setDeferred(e as unknown as { prompt: () => Promise<void> });
      if (!dismissed) setShow(true);
    };
    window.addEventListener("beforeinstallprompt", onBIP);
    const t = window.setTimeout(() => {
      if (!dismissed) setShow(true);
    }, 4200);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBIP);
      window.clearTimeout(t);
    };
  }, []);

  if (!show) return null;
  return (
    <div className="fixed bottom-20 left-4 z-40 w-[min(92vw,380px)] slide-up rounded-2xl border border-white/10 bg-[#161616] p-4 text-white shadow-2xl md:bottom-5">
      <div className="flex items-start gap-3">
        <img src={IMG.appIcon} alt="" className="h-12 w-12 rounded-xl" />
        <div className="flex-1">
          <p className="text-sm font-bold">Install TurfBuddy</p>
          <p className="mt-0.5 text-xs text-white/55">Add to your home screen for faster ordering.</p>
          <div className="mt-3 flex gap-2">
            <button
              onClick={async () => {
                if (deferred) await deferred.prompt();
                setShow(false);
                sessionStorage.setItem("tb-install-hide", "1");
              }}
              className="flex items-center gap-1.5 rounded-full bg-[#FF6A00] px-3 py-1.5 text-xs font-bold"
            >
              <IconDownload className="h-3.5 w-3.5" /> Install
            </button>
            <button
              onClick={() => {
                setShow(false);
                sessionStorage.setItem("tb-install-hide", "1");
              }}
              className="rounded-full px-3 py-1.5 text-xs font-semibold text-white/60"
            >
              Not now
            </button>
          </div>
        </div>
        <button
          onClick={() => {
            setShow(false);
            sessionStorage.setItem("tb-install-hide", "1");
          }}
        >
          <IconX className="h-4 w-4 text-white/50" />
        </button>
      </div>
    </div>
  );
}
