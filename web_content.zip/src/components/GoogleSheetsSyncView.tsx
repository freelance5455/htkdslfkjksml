import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  UploadCloud, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw, 
  FileText, 
  Layers, 
  Check, 
  Database,
  ArrowRight,
  ExternalLink,
  HelpCircle
} from 'lucide-react';
import { ImportPreviewRow, Language } from '../types';
import { translations } from '../translations';
import { excelService } from '../services/excelService';
import { receiptService } from '../services/receiptService';

interface GoogleSheetsSyncViewProps {
  language: Language;
  onImportSuccess: (count: { added: number; updated: number }) => void;
  onExportCustomersExcel: () => void;
  onExportBillingExcel: () => void;
}

export const GoogleSheetsSyncView: React.FC<GoogleSheetsSyncViewProps> = ({
  language,
  onImportSuccess,
  onExportCustomersExcel,
  onExportBillingExcel,
}) => {
  const t = translations[language];
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [previewRows, setPreviewRows] = useState<ImportPreviewRow[] | null>(null);
  const [duplicateAction, setDuplicateAction] = useState<'skip' | 'overwrite'>('overwrite');
  const [importStats, setImportStats] = useState<{ added: number; updated: number } | null>(null);

  // Webhook / Live Sync config
  const [sheetsWebhookUrl, setSheetsWebhookUrl] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setErrorMsg(null);
    setImportStats(null);

    try {
      const rows = await excelService.parseCustomerFile(file);
      setPreviewRows(rows);
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmImport = () => {
    if (!previewRows) return;
    setIsLoading(true);
    try {
      const result = excelService.importPreviewRows(previewRows, duplicateAction);
      setImportStats(result);
      onImportSuccess(result);
      setPreviewRows(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleManualSync = () => {
    setIsSyncing(true);
    setSyncStatus('Connecting to Google Sheets endpoint...');
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('Google Sheets synchronization active. Data reconciled with CCTV Network master database.');
    }, 1500);
  };

  const validCount = previewRows?.filter(r => r.isValid).length || 0;
  const duplicateCount = previewRows?.filter(r => r.isDuplicate).length || 0;
  const errorCount = previewRows?.filter(r => !r.isValid).length || 0;

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
            <span>{t.googleSheetsTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Import existing customer spreadsheets, detect duplicates, export master lists and monthly billing registers.
          </p>
        </div>

        <button
          onClick={() => excelService.downloadTemplateExcel()}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow-sm transition self-start md:self-auto"
        >
          <Download className="w-4 h-4 text-cyan-400" />
          <span>Download Sample Template (.xlsx)</span>
        </button>
      </div>

      {/* Success Notification if imported */}
      {importStats && (
        <div className="p-4 rounded-xl bg-emerald-950/70 border border-emerald-800 text-emerald-300 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <div className="text-xs sm:text-sm">
            <span className="font-bold">Spreadsheet imported successfully! </span>
            <span>Added {importStats.added} new customer(s), updated {importStats.updated} existing record(s).</span>
          </div>
        </div>
      )}

      {/* Error Notification */}
      {errorMsg && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-800 text-rose-300 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <div className="text-xs sm:text-sm">{errorMsg}</div>
        </div>
      )}

      {/* Upload Zone & Export Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Upload File Card (2 cols) */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <UploadCloud className="w-4 h-4 text-cyan-400" />
            <span>{t.uploadSheet}</span>
          </h3>

          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-700 hover:border-cyan-500/70 rounded-2xl p-8 text-center cursor-pointer bg-slate-850/50 hover:bg-slate-850 transition group"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".xlsx,.xls,.csv"
              className="hidden"
            />
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
              <UploadCloud className="w-7 h-7" />
            </div>
            <p className="text-sm font-bold text-slate-200">
              {t.dragDropText}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Supports Microsoft Excel (.xlsx, .xls) and Google Sheets (.csv)
            </p>
            <span className="inline-block mt-3 px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-[11px] font-semibold">
              Browse Computer or Phone Files
            </span>
          </div>
        </div>

        {/* Quick Export Cards (1 col) */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Export Reports</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Download clean formatted Excel workbooks for record-keeping and accounts.
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={onExportCustomersExcel}
              className="w-full p-3 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group"
            >
              <div>
                <span className="text-xs font-bold text-slate-200 block">Customer Master List</span>
                <span className="text-[11px] text-slate-400">All subscriber details &amp; dues</span>
              </div>
              <Download className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition" />
            </button>

            <button
              onClick={onExportBillingExcel}
              className="w-full p-3 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group"
            >
              <div>
                <span className="text-xs font-bold text-slate-200 block">Monthly Collection Register</span>
                <span className="text-[11px] text-slate-400">Cash &amp; UPI receipt statements</span>
              </div>
              <Download className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition" />
            </button>
          </div>

          <div className="p-3 rounded-xl bg-slate-850/60 border border-slate-800 text-[11px] text-slate-400">
            💡 Excel files include formatted currency amounts, telephone codes, and connection dates.
          </div>
        </div>

      </div>

      {/* Import Preview Modal / Table */}
      {previewRows && (
        <div className="p-6 rounded-2xl bg-slate-900/95 border border-cyan-800 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>{t.importPreview}</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {previewRows.length} Rows Found
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Review data verification, column mapping, and duplicate detection before saving.
              </p>
            </div>

            {/* Stats badges */}
            <div className="flex items-center gap-2 text-xs">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                {validCount} Valid
              </span>
              {duplicateCount > 0 && (
                <span className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-400 border border-amber-800 font-bold">
                  {duplicateCount} Duplicates
                </span>
              )}
              {errorCount > 0 && (
                <span className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-400 border border-rose-800 font-bold">
                  {errorCount} Errors
                </span>
              )}
            </div>
          </div>

          {/* Duplicate handling strategy */}
          {duplicateCount > 0 && (
            <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-amber-300">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Existing customers matched by phone number or ID:</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={() => setDuplicateAction('overwrite')}
                  className={`px-3 py-1 rounded-lg font-bold transition ${
                    duplicateAction === 'overwrite' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {t.overwriteDuplicates}
                </button>
                <button
                  onClick={() => setDuplicateAction('skip')}
                  className={`px-3 py-1 rounded-lg font-bold transition ${
                    duplicateAction === 'skip' ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {t.skipDuplicates}
                </button>
              </div>
            </div>
          )}

          {/* Preview Rows Table */}
          <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850 sticky top-0 text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Row</th>
                  <th className="py-2.5 px-3">ID / Code</th>
                  <th className="py-2.5 px-3">Name</th>
                  <th className="py-2.5 px-3">Mobile</th>
                  <th className="py-2.5 px-3">Area</th>
                  <th className="py-2.5 px-3">Service</th>
                  <th className="py-2.5 px-3 text-right">Plan (₹)</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {previewRows.map((r) => (
                  <tr key={r.rowNumber} className="hover:bg-slate-850/40">
                    <td className="py-2 px-3 font-mono text-slate-500">#{r.rowNumber}</td>
                    <td className="py-2 px-3 font-mono text-cyan-300">{r.customerCode}</td>
                    <td className="py-2 px-3 font-bold text-slate-200">{r.name}</td>
                    <td className="py-2 px-3 font-mono text-slate-300">{r.mobile}</td>
                    <td className="py-2 px-3 text-slate-300">{r.area}</td>
                    <td className="py-2 px-3 text-slate-300">{r.serviceType}</td>
                    <td className="py-2 px-3 text-right font-mono-num text-slate-200">
                      {receiptService.formatCurrency(r.monthlyAmount)}
                    </td>
                    <td className="py-2 px-3 text-center">
                      {r.isDuplicate ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">
                          Duplicate
                        </span>
                      ) : r.isValid ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                          New
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-400 border border-rose-800">
                          Error
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => {
                setPreviewRows(null);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmImport}
              disabled={validCount === 0}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-cyan-900/30 disabled:opacity-50"
            >
              {t.saveImportedData} ({validCount})
            </button>
          </div>

        </div>
      )}

      {/* Two-Way Google Sheets Auto-Sync Webhook Setup */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-cyan-400" />
            <span>{t.twoWaySync}</span>
          </h3>
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
            Real-Time Bridge
          </span>
        </div>

        <p className="text-xs text-slate-300">
          Sync payments and collections directly with your Google Sheets spreadsheet in the cloud. You can paste a Google Apps Script Web App URL or Published Google Sheet link.
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="url"
            value={sheetsWebhookUrl}
            onChange={(e) => setSheetsWebhookUrl(e.target.value)}
            placeholder="https://script.google.com/macros/s/.../exec or Google Sheets URL"
            className="flex-1 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{t.syncWithSheets}</span>
          </button>
        </div>

        {syncStatus && (
          <p className="text-xs text-emerald-400 font-medium">
            ✓ {syncStatus}
          </p>
        )}

      </div>

    </div>
  );
};
