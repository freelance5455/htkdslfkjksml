import React, { useState, useRef } from "react";
import {
  Download,
  Upload,
  FileText,
  FileSpreadsheet,
  Presentation,
  Image,
  Volume2,
  Video,
  Archive,
  Code,
  Check,
  Sparkles,
  Layers,
  RefreshCw,
  CheckCircle2,
  FolderKanban,
  FileCode,
  FileCheck,
  Table,
  Shapes,
  Film,
  Binary,
  ShieldCheck,
  Database,
  ExternalLink,
  Trash2,
  KeyRound,
  Lock,
  ArrowRight,
  Eye,
  AlertCircle,
  FileArchive
} from "lucide-react";
import { Note, SectionItem, ThemeAccent, ArchivedDocument } from "../types";
import {
  SUPPORTED_DOCUMENT_FORMATS,
  DocumentCategory,
  DocumentFormatInfo,
  exportToWordDocx,
  exportToPDF,
  exportToTXT,
  exportToRTF,
  exportToODT,
  exportToExcelXLSX,
  exportToCSV,
  exportToODS,
  exportToPowerPointPPTX,
  exportToHTML,
  exportToXML,
  exportToSVGCard,
  exportToZIPArchive,
  exportToBIN,
  parseUploadedDocument,
  ParsedImportResult,
  decryptColorNoteBackupApi
} from "../utils/documentHub";
import { isColorNoteFile } from "../utils/colorNoteParser";
import { THEME_ACCENTS } from "../utils/theme";

interface DocumentCenterViewProps {
  notes: Note[];
  sections: SectionItem[];
  themeAccent: ThemeAccent;
  archivedDocuments?: ArchivedDocument[];
  onImportNotes: (newNotes: Array<Omit<Note, "id" | "createdAt" | "updatedAt">>) => void;
  onArchiveDocument?: (doc: ArchivedDocument) => void;
  onDeleteArchivedDocument?: (id: string) => void;
  onOpenNote?: (note: Note) => void;
  onNavigateToNotes?: () => void;
  onOpenColorNoteDecoder?: (fileData?: { name: string; size: number; base64: string }) => void;
}

export const DocumentCenterView: React.FC<DocumentCenterViewProps> = ({
  notes,
  sections,
  themeAccent,
  archivedDocuments = [],
  onImportNotes,
  onArchiveDocument,
  onDeleteArchivedDocument,
  onOpenNote,
  onNavigateToNotes,
  onOpenColorNoteDecoder,
}) => {
  const [activeCategory, setActiveCategory] = useState<DocumentCategory | "all">("all");
  const [exportScope, setExportScope] = useState<"all" | "single" | "section">("all");
  const [selectedNoteId, setSelectedNoteId] = useState<string>(notes[0]?.id || "");
  const [selectedSectionName, setSelectedSectionName] = useState<string>(sections[0]?.name || "Genel");
  const [isExporting, setIsExporting] = useState<string | null>(null);

  // Import states
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parsedItems, setParsedItems] = useState<ParsedImportResult[]>([]);
  const [importTargetCategory, setImportTargetCategory] = useState<string>(sections[0]?.name || "Genel");
  const [importNotification, setImportNotification] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Dedicated ColorNote / SQLite Restore states
  const [backupFilePending, setBackupFilePending] = useState<{ file: File; name: string; size: number; base64: string } | null>(null);
  const [backupPassword, setBackupPassword] = useState<string>("0000");
  const [isDecodingBackup, setIsDecodingBackup] = useState<boolean>(false);
  const [backupRestoreSuccess, setBackupRestoreSuccess] = useState<{ count: number; name: string } | null>(null);
  const [backupError, setBackupError] = useState<string | null>(null);
  const backupInputRef = useRef<HTMLInputElement | null>(null);

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  const getNotesToExport = (): Note[] => {
    if (exportScope === "single") {
      const found = notes.find((n) => n.id === selectedNoteId);
      return found ? [found] : notes.slice(0, 1);
    }
    if (exportScope === "section") {
      const filtered = notes.filter((n) => n.category === selectedSectionName);
      return filtered.length > 0 ? filtered : notes;
    }
    return notes;
  };

  const handleExport = async (format: DocumentFormatInfo) => {
    const targetNotes = getNotesToExport();
    if (targetNotes.length === 0) {
      alert("Dışa aktarılacak not bulunamadı.");
      return;
    }

    setIsExporting(format.id);
    try {
      const title =
        exportScope === "single"
          ? targetNotes[0].title || "Not_Belgesi"
          : exportScope === "section"
          ? `${selectedSectionName}_Notlari`
          : "NoteFlow_Tum_Notlar";

      switch (format.id) {
        case "docx":
          exportToWordDocx(targetNotes, title);
          break;
        case "pdf":
          exportToPDF(targetNotes, title);
          break;
        case "txt":
          exportToTXT(targetNotes, title);
          break;
        case "rtf":
          exportToRTF(targetNotes, title);
          break;
        case "odt":
          exportToODT(targetNotes, title);
          break;
        case "xlsx":
          exportToExcelXLSX(targetNotes, title);
          break;
        case "csv":
          exportToCSV(targetNotes, title);
          break;
        case "ods":
          exportToODS(targetNotes, title);
          break;
        case "pptx":
        case "odp":
          exportToPowerPointPPTX(targetNotes, title);
          break;
        case "html":
        case "json":
          exportToHTML(targetNotes, title);
          break;
        case "xml":
          exportToXML(targetNotes, title);
          break;
        case "bin":
          exportToBIN(targetNotes, title);
          break;
        case "zip":
          await exportToZIPArchive(targetNotes, title);
          break;
        case "svg":
        case "png":
          if (targetNotes.length > 0) exportToSVGCard(targetNotes[0]);
          break;
        default:
          exportToTXT(targetNotes, title);
          break;
      }
    } catch (err) {
      console.error("Export error:", err);
      alert("Dışa aktarım sırasında bir sorun oluştu.");
    } finally {
      setTimeout(() => setIsExporting(null), 600);
    }
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsParsing(true);
    setImportNotification(null);

    const allParsed: ParsedImportResult[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];

        // 1. Storage Layer: Archive physical file in Document Center
        const base64Data = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });

        // 2. Extraction Pipeline: Sift and extract individual note entities
        const res = await parseUploadedDocument(file);
        allParsed.push(...res);

        const newArchivedDoc: ArchivedDocument = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          name: file.name,
          size: file.size,
          mime: file.type || "application/octet-stream",
          uploadedAt: new Date().toISOString(),
          sourceType: file.name.split(".").pop()?.toLowerCase() || "file",
          extractedCount: res.length,
          data: base64Data,
          status: "extracted",
        };

        if (onArchiveDocument) {
          onArchiveDocument(newArchivedDoc);
        }
      }
      setParsedItems(allParsed);

      if (allParsed.length > 0) {
        // 3. Populating Notes UI with Decoupled Entities
        const toImport = allParsed.map((p) => ({
          title: p.title || "İçe Aktarılan Not",
          content: p.content,
          htmlContent: p.htmlContent,
          category: importTargetCategory || p.category || "Genel",
          tags: p.tags && p.tags.length > 0 ? p.tags : ["#aktarim"],
          pinned: false,
          favorite: false,
          tasks: p.tasks || [],
          color: p.color || "amber",
          isVault: Boolean(p.isVault),
          sourceDocument: p.sourceDocument || (files.length === 1 ? files[0].name : undefined),
          createdAt: p.createdAt || new Date().toISOString(),
          updatedAt: p.updatedAt || new Date().toISOString(),
          attachments: p.attachment
            ? [
                {
                  id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                  name: p.attachment.name,
                  mime: p.attachment.mime,
                  size: p.attachment.size,
                  data: p.attachment.data,
                },
              ]
            : [],
        }));

        onImportNotes(toImport);
        setImportNotification(
          `✓ ${toImport.length} adet bağımsız not kartı Notlar (Ana Ekran) ızgarasına eklendi ve kaynak dosya Dijital Belge Merkezi'nde arşivlendi!`
        );
      }
    } catch (err) {
      console.error("Import parse failed:", err);
      alert("Dosyalar ayrıştırılırken bir sorun oluştu.");
    } finally {
      setIsParsing(false);
    }
  };

  const handleSaveImported = () => {
    if (parsedItems.length === 0) return;

    const toImport = parsedItems.map((p) => ({
      title: p.title || "İçe Aktarılan Not",
      content: p.content,
      htmlContent: p.htmlContent,
      category: importTargetCategory || p.category || "Genel",
      tags: p.tags && p.tags.length > 0 ? p.tags : ["#aktarim"],
      pinned: false,
      favorite: false,
      tasks: p.tasks || [],
      color: p.color || "amber",
      isVault: Boolean(p.isVault),
      sourceDocument: p.sourceDocument,
      createdAt: p.createdAt || new Date().toISOString(),
      updatedAt: p.updatedAt || new Date().toISOString(),
      attachments: p.attachment ? [
        {
          id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name: p.attachment.name,
          mime: p.attachment.mime,
          size: p.attachment.size,
          data: p.attachment.data,
        }
      ] : [],
    }));

    setImportNotification(`✓ ${toImport.length} adet bağımsız not başarıyla çalışma alanınıza eklendi!`);
    setParsedItems([]);
  };

  // Dedicated ColorNote / SQLite Backup Handlers
  const handleSelectBackupFile = (file: File) => {
    setBackupError(null);
    setBackupRestoreSuccess(null);
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setBackupFilePending({
        file,
        name: file.name,
        size: file.size,
        base64,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRunBackupRestore = async (passOverride?: string) => {
    if (!backupFilePending) {
      backupInputRef.current?.click();
      return;
    }

    const passwordToUse = passOverride !== undefined ? passOverride : backupPassword;
    setIsDecodingBackup(true);
    setBackupError(null);
    setBackupRestoreSuccess(null);

    try {
      const res = await decryptColorNoteBackupApi(backupFilePending.base64, passwordToUse);

      if (res.success && res.notes && res.notes.length > 0) {
        // 1. Convert each decoded entry to individual pure note
        const toImport = res.notes.map((cn: any) => {
          let contentWithTasks = cn.content;
          if (cn.isChecklist && cn.tasks && cn.tasks.length > 0 && !contentWithTasks.includes("- [ ]")) {
            contentWithTasks =
              `${contentWithTasks ? contentWithTasks + "\n\n" : ""}### Görev Listesi:\n` +
              cn.tasks.map((t: any) => `- [${t.completed ? "x" : " "}] ${t.text}`).join("\n");
          }

          return {
            title: cn.title || "ColorNote Notu",
            content: contentWithTasks,
            category: "ColorNote Notları",
            tags: cn.tags && cn.tags.length > 0 ? cn.tags : ["#ColorNote"],
            pinned: false,
            favorite: false,
            tasks: cn.tasks || [],
            color: cn.themeColor || "amber",
            isVault: Boolean(cn.isLocked),
            createdAt: cn.createdDate || new Date().toISOString(),
            updatedAt: cn.modifiedDate || new Date().toISOString(),
          };
        });

        // 2. Archive source in Document Center
        if (onArchiveDocument) {
          onArchiveDocument({
            id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            name: backupFilePending.name,
            size: backupFilePending.size,
            mime: "application/x-colornote-backup",
            uploadedAt: new Date().toISOString(),
            sourceType: backupFilePending.name.split(".").pop()?.toLowerCase() || "bin",
            extractedCount: toImport.length,
            data: backupFilePending.base64,
            status: "extracted",
          });
        }

        // 3. Ingest into Notes State
        onImportNotes(toImport);

        setBackupRestoreSuccess({
          count: toImport.length,
          name: backupFilePending.name,
        });
      } else {
        setBackupError(
          res.message ||
            "Bu yedek dosyası şifreli olabilir veya belirtilen şifre (" +
              passwordToUse +
              ") uyuşmadı. Lütfen ColorNote şifrenizi girin veya Gelişmiş Çözücü Modalını açın."
        );
      }
    } catch (err: any) {
      setBackupError("Şifre çözme işlemi sırasında bir hata oluştu: " + (err.message || String(err)));
    } finally {
      setIsDecodingBackup(false);
    }
  };

  const handleDownloadArchived = (doc: ArchivedDocument) => {
    if (doc.data) {
      const a = document.createElement("a");
      a.href = doc.data;
      a.download = doc.name;
      a.click();
    } else {
      exportToBIN(notes, doc.name.replace(/\.[^/.]+$/, ""));
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const filteredFormats = SUPPORTED_DOCUMENT_FORMATS.filter((fmt) => {
    if (activeCategory === "all") return fmt.canExport;
    return fmt.category === activeCategory && fmt.canExport;
  });

  const categories = [
    { id: "all", label: "Tüm Formatlar", icon: Layers, count: SUPPORTED_DOCUMENT_FORMATS.filter((f) => f.canExport).length },
    { id: "office", label: "Metin & Ofis", icon: FileText, count: 5 },
    { id: "table", label: "Tablo & Veri", icon: FileSpreadsheet, count: 3 },
    { id: "presentation", label: "Sunum", icon: Presentation, count: 2 },
    { id: "binary", label: "İkili & Sistem (.BIN)", icon: Binary, count: SUPPORTED_DOCUMENT_FORMATS.filter((f) => f.category === "binary" && f.canExport).length },
    { id: "media", label: "Görsel & Grafik", icon: Image, count: 2 },
    { id: "archive", label: "Arşiv (ZIP)", icon: Archive, count: 1 },
    { id: "code_web", label: "Kod & Web", icon: Code, count: 4 },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Top Banner Card */}
      <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-br ${themeDef.gradient} text-white shadow-xl relative overflow-hidden`}>
        <div className="absolute right-0 bottom-0 translate-x-8 translate-y-8 opacity-10 text-9xl pointer-events-none">
          📁
        </div>
        
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold uppercase tracking-wider">
            <span>✦ Dijital Belge ve Format Merkezi</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Çift Katmanlı Dosya Yönetimi: Arşivleme ve İçerik Dağıtımı
          </h2>
          <p className="text-white/90 text-sm leading-relaxed">
            Yüklediğiniz .BIN ve arşiv dosyaları burada fiziksel olarak güvenle saklanır; içlerindeki tüm notlar ve içerikler otomatik olarak süzülüp Notlar (Ana Ekran) bölümüne bağımsız 3'lü ızgara kartları olarak dağıtılır.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white text-slate-900 font-bold text-xs shadow-lg hover:bg-slate-100 active:scale-95 transition-all"
            >
              <Upload className="w-4 h-4 text-teal-600" />
              <span>Dosya / .BIN Yükle ve Ayrıştır</span>
            </button>

            <button
              onClick={() => handleExport(SUPPORTED_DOCUMENT_FORMATS.find((f) => f.id === "zip")!)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-black/20 hover:bg-black/30 text-white font-bold text-xs border border-white/20 backdrop-blur-sm active:scale-95 transition-all"
            >
              <Archive className="w-4 h-4" />
              <span>Tüm Havuzu ZIP Arşivle</span>
            </button>
          </div>
        </div>
      </div>

      {/* Double-Layered Architecture Status Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-lg">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold flex items-center gap-2 text-white">
                <span>Çift Katmanlı Ayrıştırma Mimarisi Aktif</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                  Veri Bağımsızlığı Garantisi
                </span>
              </h4>
              <p className="text-xs text-slate-400">
                1. Katman (Depolama): Kaynak dosyalar arşivde korunur • 2. Katman (Dağıtım): Süzülen notlar ana ekranda bağımsız yaşar.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300">
              Arşivdeki Kaynaklar: <strong className="text-white">{archivedDocuments.length} Dosya</strong>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300">
              Toplam Not Havuzu: <strong className="text-teal-400">{notes.length} Kart</strong>
            </div>
          </div>
        </div>
      </div>

      {/* DEDICATED BACKUP RESTORE CARD (.BIN / .IDX / .DOC) */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-amber-500/5 dark:from-amber-950/40 dark:via-orange-950/30 dark:to-amber-950/20 border border-amber-300/80 dark:border-amber-800/60 shadow-sm space-y-5">
        
        {/* Hidden dedicated backup file input */}
        <input
          type="file"
          ref={backupInputRef}
          onChange={(e) => {
            const files = e.target.files;
            if (files && files.length > 0) {
              handleSelectBackupFile(files[0]);
            }
            e.target.value = "";
          }}
          accept=".bin,.idx,.doc,.backup,.dat,application/octet-stream,*"
          className="hidden"
        />

        {/* Section Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-2xl font-bold shadow-md shrink-0">
              📂
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  ColorNote &amp; SQLite Yedek Çözücü (.BIN / .IDX / .DOC) Geri Yükleme (Restore)
                </h3>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-900 dark:bg-amber-900 dark:text-amber-200 uppercase font-mono">
                  AES-128 / SQLite Format 3
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                Dışarıdan yüklenen <strong>.bin / .idx / .doc / .backup</strong> yedekleri asla düz metin belgesi olarak açılmaz. İçindeki şifreli SQLite veritabanı çözülür; her bir kayıt <strong>orijinal ColorNote rengi (0-8), kontrol listesi ve tarihiyle doğrudan Ana Sayfaya</strong> bağımsız kartlar olarak dağıtılır.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
            <button
              onClick={() => backupInputRef.current?.click()}
              className="px-4 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-2 whitespace-nowrap"
            >
              <Upload className="w-4 h-4" />
              <span>Yedek Dosyası Seç (.BIN / .DOC)</span>
            </button>
          </div>
        </div>

        {/* Interactive File Drop & Password Decoding Console */}
        <div className="p-5 rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-amber-200/70 dark:border-amber-800/40 shadow-xs space-y-4">
          
          {/* File Selected Indicator / Drop area */}
          {backupFilePending ? (
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/70">
              <div className="flex items-center gap-3 min-w-0">
                <FileArchive className="w-8 h-8 text-amber-600 dark:text-amber-400 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {backupFilePending.name}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Boyut: {formatFileSize(backupFilePending.size)} • Format: {backupFilePending.name.split(".").pop()?.toUpperCase()}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setBackupFilePending(null)}
                  className="text-xs text-slate-500 hover:text-rose-600 px-2 py-1 rounded transition-colors"
                >
                  Değiştir
                </button>
                {onOpenColorNoteDecoder && (
                  <button
                    onClick={() => onOpenColorNoteDecoder(backupFilePending)}
                    className="text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-200/60 dark:bg-amber-900/60 px-3 py-1.5 rounded-xl hover:bg-amber-300/60 transition-colors flex items-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Önizlemeli Aç</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div
              onClick={() => backupInputRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                  handleSelectBackupFile(e.dataTransfer.files[0]);
                }
              }}
              className="p-6 rounded-2xl border-2 border-dashed border-amber-300 dark:border-amber-800/80 hover:border-amber-500 dark:hover:border-amber-600 bg-amber-50/40 dark:bg-amber-950/20 text-center cursor-pointer transition-all hover:bg-amber-50/70"
            >
              <div className="w-10 h-10 mx-auto rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-2">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                ColorNote veya SQLite Yedek Dosyanızı Buraya Sürükleyin veya Seçin
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Desteklenenler: <code>.bin</code>, <code>.idx</code>, <code>.doc</code>, <code>.backup</code>, <code>.dat</code>
              </p>
            </div>
          )}

          {/* Password Input & One-Click Restore Trigger */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
            <div className="flex items-center gap-2 flex-1">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="w-4 h-4 text-amber-600" />
                </div>
                <input
                  type="text"
                  value={backupPassword}
                  onChange={(e) => setBackupPassword(e.target.value)}
                  placeholder="Yedek Şifresi (Varsayılan: 0000)"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Quick Password Presets */}
              <div className="hidden md:flex items-center gap-1 shrink-0">
                {["0000", "Yok", "1234"].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setBackupPassword(preset === "Yok" ? "" : preset)}
                    className="px-2 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[10px] font-mono text-slate-600 dark:text-slate-300 transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => handleRunBackupRestore()}
              disabled={isDecodingBackup}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 ${
                isDecodingBackup
                  ? "bg-slate-400 text-white cursor-not-allowed"
                  : "bg-amber-600 hover:bg-amber-700 active:scale-95 text-white"
              }`}
            >
              {isDecodingBackup ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Şifre Çözülüyor &amp; Ayrıştırılıyor...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Şifreli SQLite Çöz &amp; Notları Geri Yükle</span>
                </>
              )}
            </button>
          </div>

          {/* Error Message */}
          {backupError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/70 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div className="flex-1 space-y-1.5">
                <p>{backupError}</p>
                {backupFilePending && onOpenColorNoteDecoder && (
                  <button
                    onClick={() => onOpenColorNoteDecoder(backupFilePending)}
                    className="underline font-bold text-rose-800 dark:text-rose-200 hover:opacity-80"
                  >
                    Gelişmiş Çözücü Modalını açarak farklı şifreleri deneyin ➔
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Success Notification with Direct Link to Home Grid */}
          {backupRestoreSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in duration-200">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                  <Check className="w-5 h-5 stroke-[3]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-100">
                    Geri Yükleme Başarılı! {backupRestoreSuccess.count} Adet ColorNote Notu Aktarıldı
                  </h4>
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                    Notlar orijinal renkleri ve kontrol listeleriyle Ana Sayfadaki 3'lü ızgaraya yerleştirildi.
                  </p>
                </div>
              </div>

              {onNavigateToNotes && (
                <button
                  onClick={onNavigateToNotes}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5 shrink-0"
                >
                  <span>Ana Sayfaya Git ve Notları Gör</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

        </div>
      </div>

      {/* ARCHIVED PHYSICAL FILES (STORAGE LAYER) */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Archive className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>1. Katman: Fiziksel Dosya ve Yedek Arşivi (Storage Layer)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bu bölümde saklanan orijinal dosyalar açılmaz veya bozulmaz; üzerlerine yapılan not düzenlemelerinden etkilenmez.
            </p>
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Yeni Kaynak Arşivle</span>
          </button>
        </div>

        {archivedDocuments.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-850/50 border border-dashed border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
            Henüz arşivlenmiş fiziksel dosya bulunmuyor. .BIN veya veri dosyanızı yüklediğinizde burada güvenle saklanacaktır.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {archivedDocuments.map((doc) => (
              <div
                key={doc.id}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850/70 border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-3 group hover:border-teal-500/50 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 uppercase">
                      .{doc.sourceType}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formatFileSize(doc.size)}
                    </span>
                  </div>

                  <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate" title={doc.name}>
                    {doc.name}
                  </h5>

                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    {doc.extractedCount > 0 ? (
                      <span className="text-teal-600 dark:text-teal-400 font-semibold">
                        ✓ {doc.extractedCount} adet bağımsız not süzüldü
                      </span>
                    ) : (
                      "Depolama Katmanı • Arşivli"
                    )}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800 text-xs">
                  <span className="text-[10px] text-slate-400">
                    {new Date(doc.uploadedAt).toLocaleDateString("tr-TR")}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDownloadArchived(doc)}
                      title="Orijinal Dosyayı İndir"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-teal-600 hover:bg-slate-200/60 dark:hover:bg-slate-750 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    {onDeleteArchivedDocument && (
                      <button
                        onClick={() => onDeleteArchivedDocument(doc.id)}
                        title="Arşivden Kaldır"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Scope and Filter Bar */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Dışa Aktarma Kapsamı:
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setExportScope("all")}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  exportScope === "all"
                    ? `${themeDef.buttonBg} shadow-xs font-bold`
                    : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Tüm Notlar ({notes.length})
              </button>
              <button
                onClick={() => setExportScope("single")}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  exportScope === "single"
                    ? `${themeDef.buttonBg} shadow-xs font-bold`
                    : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Tek Bir Not
              </button>
              <button
                onClick={() => setExportScope("section")}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  exportScope === "section"
                    ? `${themeDef.buttonBg} shadow-xs font-bold`
                    : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Bölüme Göre
              </button>
            </div>
          </div>

          {exportScope === "single" && (
            <select
              value={selectedNoteId}
              onChange={(e) => setSelectedNoteId(e.target.value)}
              className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 max-w-sm"
            >
              {notes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.title || "Başlıksız Not"} ({n.category})
                </option>
              ))}
            </select>
          )}

          {exportScope === "section" && (
            <select
              value={selectedSectionName}
              onChange={(e) => setSelectedSectionName(e.target.value)}
              className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2"
            >
              {sections.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name} ({notes.filter((n) => n.category === s.name).length} not)
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-slate-100 dark:border-slate-800">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? `${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.text} ${themeDef.textDark} border ${themeDef.border} font-bold`
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
                <span className="text-[10px] opacity-75">({cat.count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Formats Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Kullanılabilir İndirme Formatları
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {filteredFormats.length} Farklı Biçim
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFormats.map((fmt) => {
            const isExportingThis = isExporting === fmt.id;
            return (
              <div
                key={fmt.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/50 hover:shadow-lg transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg uppercase ${fmt.badgeColor}`}>
                      {fmt.extension}
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium">
                      {fmt.categoryLabel}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                    {fmt.name}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                    {fmt.description}
                  </p>
                </div>

                <button
                  onClick={() => handleExport(fmt)}
                  disabled={isExportingThis}
                  className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl text-xs font-bold border transition-all ${
                    isExportingThis
                      ? "bg-teal-50 text-teal-700 border-teal-300 dark:bg-teal-950 dark:text-teal-300 animate-pulse"
                      : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-teal-600 hover:text-white hover:border-teal-600 dark:hover:bg-teal-600 dark:hover:text-white active:scale-95"
                  }`}
                >
                  {isExportingThis ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Belge Üretiliyor...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>{fmt.extension} Olarak İndir</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Universal Drag & Drop Importer Section */}
      <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Evrensel Belge ve Dosya İçe Aktarma (Extraction Pipeline)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              ColorNote .BIN, Word, Excel, PDF, Resim, Ses, ZIP, Kod ve Metin belgelerinizi yükleyin. Kaynak arşivlenirken içindeki her kayıt bağımsız renkli not kartı olarak Ana Ekran'a dağıtılır.
            </p>
          </div>
        </div>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            handleFiles(e.dataTransfer.files);
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`p-10 rounded-3xl border-2 border-dashed text-center cursor-pointer transition-all ${
            isDragging
              ? "border-teal-500 bg-teal-50/50 dark:bg-teal-950/30 scale-[1.01]"
              : "border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-850/60"
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => handleFiles(e.target.files)}
            multiple
            accept="*"
            className="hidden"
          />

          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center text-3xl shadow-inner">
            📥
          </div>
          <h4 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1">
            Belgeleri Buraya Sürükleyin veya Tıklayıp Seçin (.BIN Dahil Tüm Dosyalar)
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-lg mx-auto mb-4">
            İkili sistem (.BIN), Word, PDF, Excel, Kod, Medya veya ZIP dosyalarını yükleyin. Orijinal dosya arşive kaydedilirken, içindeki her not bağımsız 3'lü ızgara kartı olarak Ana Sayfaya eklenir.
          </p>

          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md transition-colors">
            <Upload className="w-4 h-4" />
            <span>Dosya Gezgininden Seç (.bin dahil)</span>
          </div>
        </div>

        {/* Parsing Progress */}
        {isParsing && (
          <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex items-center justify-center gap-3 text-teal-700 dark:text-teal-300 text-sm font-semibold animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Belgeler taranıyor, arşivleniyor ve bağımsız notlar süzülüyor...</span>
          </div>
        )}

        {/* Success Alert */}
        {importNotification && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 flex flex-wrap items-center justify-between gap-3 text-emerald-800 dark:text-emerald-300 text-sm font-bold">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-600" />
              <span>{importNotification}</span>
            </div>
            {onNavigateToNotes && (
              <button
                type="button"
                onClick={onNavigateToNotes}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition-transform active:scale-95"
              >
                Notlar Bölümüne Git ve Gör →
              </button>
            )}
          </div>
        )}

        {/* Parsed Items Preview */}
        {parsedItems.length > 0 && (
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Süzülen Bağımsız Notlar ({parsedItems.length} Adet)
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Aşağıdaki her kayıt ayrı bir kart olarak çalışma alanınıza aktarılacaktır:
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                    Eklenecek Bölüm:
                  </span>
                  <select
                    value={importTargetCategory}
                    onChange={(e) => setImportTargetCategory(e.target.value)}
                    className="text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1.5"
                  >
                    {sections.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={handleSaveImported}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r ${themeDef.gradient} shadow-md active:scale-95 transition-all`}
                >
                  <Check className="w-4 h-4" />
                  <span>Tümünü Notlarıma Ekle</span>
                </button>
              </div>
            </div>

            <div className="max-h-72 overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-800">
              {parsedItems.map((item, idx) => (
                <div key={idx} className="p-3.5 bg-slate-50/50 dark:bg-slate-850/50 flex items-center justify-between gap-4 text-xs">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 uppercase">
                      .{item.rawFormat}
                    </span>
                    <div className="truncate">
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {item.title}
                      </span>
                      <span className="text-slate-400 text-[11px] truncate block">
                        {item.content.slice(0, 100)}...
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">
                    {item.category}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
