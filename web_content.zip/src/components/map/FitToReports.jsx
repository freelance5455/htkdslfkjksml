import { useEffect } from "react";
import { useMap } from "react-leaflet";

export default function FitToReports({ points }) {
  const map = useMap();
  const key = points.map((point) => point.join(",")).join("|");

  useEffect(() => {
    const size = map.getSize();
    if (size.x && size.y) map.invalidateSize();
  }, [map]);

  useEffect(() => {
    if (!key) return;
    const coords = key.split("|").map((pair) => pair.split(",").map(Number));
    map.fitBounds(coords, { padding: [40, 40], maxZoom: 14 });
  }, [key, map]);

  return null;
}