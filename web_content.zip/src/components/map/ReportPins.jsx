import { CircleMarker, Tooltip } from "react-leaflet";
import { useNavigate } from "react-router-dom";
import { statusMeta } from "@/lib/reportStats";

export default function ReportPins({ reports }) {
  const navigate = useNavigate();

  return reports.map((report) => {
    const meta = statusMeta(report.status);
    return (
      <CircleMarker
        key={report.id}
        center={[report.lat, report.lng]}
        radius={report.status === "resolved" ? 7 : 9}
        eventHandlers={{ click: () => navigate(`/issues/${report.id}`) }}
        pathOptions={{
          color: "#ffffff",
          weight: 2,
          fillColor: meta.color,
          fillOpacity: 0.95,
          cursor: "pointer",
        }}
      >
        <Tooltip direction="top" offset={[0, -6]} opacity={1}>
          <span className="text-[11px] font-medium">{report.title}</span>
        </Tooltip>
      </CircleMarker>
    );
  });
}