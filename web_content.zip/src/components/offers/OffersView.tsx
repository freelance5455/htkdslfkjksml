import React, { useState } from 'react';
import { Gift, Tag, Sparkles, Copy, Check, ArrowRight, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface OffersViewProps {
  onBackToDashboard: () => void;
  onOpenInvestments: () => void;
  onOpenTasks: () => void;
  onOpenVip: () => void;
}

export const OffersView: React.FC<OffersViewProps> = ({
  onBackToDashboard,
  onOpenInvestments,
  onOpenTasks,
  onOpenVip,
}) => {
  const { investmentCoupons } = useApp();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    confetti({ particleCount: 30, spread: 40 });
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300 max-w-xl mx-auto">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToDashboard}
          className="px-3.5 py-2 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white cursor-pointer"
        >
          ← Back to Home
        </button>
        <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
          🎁 Special Offers & Coupons
        </span>
      </div>

      {/* Hero Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-purple-950/80 via-slate-950 to-indigo-950/80 border border-purple-500/40 shadow-2xl relative overflow-hidden space-y-3">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="space-y-1 relative z-10">
          <span className="text-xl">🔥</span>
          <h1 className="text-lg font-black text-white tracking-tight">
            Exclusive Rewards & Investment Promos
          </h1>
          <p className="text-xs text-slate-300 leading-relaxed">
            Use verified promotional discount codes on Digital Gold & Silver investments, complete VIP tasks, and multiply your daily earnings.
          </p>
        </div>
      </div>

      {/* Active Investment Coupons */}
      <div className="space-y-3">
        <h2 className="text-xs font-black text-slate-300 uppercase tracking-wider px-1">
          Active Investment Coupons (Silver Only — Gold Coupons Discontinued)
        </h2>

        <div className="space-y-3">
          {investmentCoupons.map((coupon) => (
            <div
              key={coupon.id}
              className="p-5 rounded-3xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/40 shadow-xl space-y-3 relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />

              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-black">
                    <Tag className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white font-mono tracking-wider">
                      {coupon.code}
                    </h3>
                    <span className="text-[10px] text-amber-400 font-bold">
                      Flat ₹{coupon.flatDiscountINR || 60} OFF on Silver (Gold Coupon Removed)
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(coupon.code)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  {copiedCode === coupon.code ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-xs relative z-10">
                <div>
                  <span className="text-slate-500 text-[10px] block">Minimum Investment</span>
                  <span className="font-bold text-slate-200">₹{coupon.minInvestmentINR}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Usage Limit</span>
                  <span className="font-bold text-emerald-400">{coupon.timesUsed} / {coupon.usageLimit} Redeemed</span>
                </div>
              </div>

              <button
                onClick={onOpenInvestments}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition-all relative z-10"
              >
                <span>Apply on Gold & Silver Investment</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Special Task & VIP Offers */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h2 className="text-xs font-black text-slate-300 uppercase tracking-wider">
          More Earning Opportunities
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div 
            onClick={onOpenTasks}
            className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/40 cursor-pointer transition-all space-y-2 group"
          >
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold">
              📋
            </div>
            <h3 className="text-xs font-black text-white group-hover:text-indigo-400 transition-colors">
              High-Paying Daily Tasks
            </h3>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Complete app install offers, watch videos, and solve surveys to earn instant coins.
            </p>
          </div>

          <div 
            onClick={onOpenVip}
            className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 cursor-pointer transition-all space-y-2 group"
          >
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-bold">
              👑
            </div>
            <h3 className="text-xs font-black text-white group-hover:text-purple-400 transition-colors">
              VIP Merchant Partnership
            </h3>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Upgrade to VIP tiers (VIP 1 to VIP 4) and unlock daily earnings up to ₹4,000.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
