import React, { useState } from "react";
import { CategoryItem } from "../types";
import { INITIAL_RATES, INITIAL_LABOUR_RATES } from "../data/categories";
import { X, Save, RotateCcw, Check, AlertCircle, Wrench, Package } from "lucide-react";

interface RateManagerModalProps {
  categories: CategoryItem[];
  rates: Record<string, number | null>;
  labourRates?: Record<string, number>;
  isOpen: boolean;
  onClose: () => void;
  onSaveRates: (newRates: Record<string, number | null>, newLabourRates?: Record<string, number>) => void;
  onResetDefaults: () => void;
}

export const RateManagerModal: React.FC<RateManagerModalProps> = ({
  categories,
  rates,
  labourRates = INITIAL_LABOUR_RATES,
  isOpen,
  onClose,
  onSaveRates,
  onResetDefaults,
}) => {
  const [localRates, setLocalRates] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const cat of categories) {
      const val = rates[cat.id];
      initial[cat.id] = val !== null && val !== undefined ? String(val) : "";
    }
    return initial;
  });

  const [localLabourRates, setLocalLabourRates] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const cat of categories) {
      const val = labourRates[cat.id] ?? cat.defaultLabourRate ?? 20;
      initial[cat.id] = String(val);
    }
    return initial;
  });

  const [activeTab, setActiveTab] = useState<"material" | "labour">("material");
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleRateChange = (catId: string, value: string) => {
    setLocalRates((prev) => ({
      ...prev,
      [catId]: value,
    }));
  };

  const handleLabourRateChange = (catId: string, value: string) => {
    setLocalLabourRates((prev) => ({
      ...prev,
      [catId]: value,
    }));
  };

  const handleSave = () => {
    const parsedMat: Record<string, number | null> = {};
    const parsedLab: Record<string, number> = {};

    for (const cat of categories) {
      const rawMat = localRates[cat.id]?.trim();
      if (!rawMat || isNaN(Number(rawMat)) || Number(rawMat) <= 0) {
        parsedMat[cat.id] = null;
      } else {
        parsedMat[cat.id] = parseFloat(rawMat);
      }

      const rawLab = localLabourRates[cat.id]?.trim();
      if (!rawLab || isNaN(Number(rawLab)) || Number(rawLab) < 0) {
        parsedLab[cat.id] = cat.defaultLabourRate ?? 20;
      } else {
        parsedLab[cat.id] = parseFloat(rawLab);
      }
    }

    onSaveRates(parsedMat, parsedLab);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  const handleResetToDefaults = () => {
    const defMat: Record<string, string> = {};
    const defLab: Record<string, string> = {};

    for (const cat of categories) {
      const valMat = INITIAL_RATES[cat.id];
      defMat[cat.id] = valMat !== null && valMat !== undefined ? String(valMat) : "";
      const valLab = INITIAL_LABOUR_RATES[cat.id] ?? cat.defaultLabourRate ?? 20;
      defLab[cat.id] = String(valLab);
    }

    setLocalRates(defMat);
    setLocalLabourRates(defLab);
    onResetDefaults();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
        {/* Modal Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-base text-white">Rate Management</h3>
            <p className="text-xs text-slate-400">
              Configure Material Rates & Labour Rates separately
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50 p-1.5 gap-1.5">
          <button
            onClick={() => setActiveTab("material")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === "material"
                ? "bg-white text-indigo-600 shadow-sm border border-slate-200/80"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Material Rates (₹/unit)</span>
          </button>
          <button
            onClick={() => setActiveTab("labour")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === "labour"
                ? "bg-white text-indigo-600 shadow-sm border border-slate-200/80"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Labour Rates (₹/unit)</span>
          </button>
        </div>

        {/* Rate List */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 divide-y divide-slate-100">
          <div className="bg-indigo-50/70 p-3.5 rounded-2xl border border-indigo-100 text-xs text-indigo-950 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <span>
              {activeTab === "material"
                ? "Material rates are in Indian Rupees (₹). Unset rates will prompt for custom input during calculation."
                : "Labour rates are applied per square foot (or per roll for Wallpaper) during installation."}
            </span>
          </div>

          <div className="pt-2 space-y-3">
            {categories.map((cat) => {
              const currentMatVal = localRates[cat.id] ?? "";
              const currentLabVal = localLabourRates[cat.id] ?? String(cat.defaultLabourRate ?? 20);
              const isDefaultNull = INITIAL_RATES[cat.id] === null;

              return (
                <div
                  key={cat.id}
                  className="flex items-center justify-between gap-3 pt-2"
                >
                  <div className="flex-1">
                    <div className="font-bold text-xs sm:text-sm text-slate-900">
                      {cat.name}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {cat.hindiName}
                      {cat.rateNote && ` • ${cat.rateNote}`}
                    </div>
                  </div>

                  <div className="w-32 shrink-0 relative">
                    {activeTab === "material" ? (
                      <>
                        <input
                          type="number"
                          inputMode="decimal"
                          min="0"
                          step="1"
                          placeholder={isDefaultNull ? "Not set" : "Rate"}
                          value={currentMatVal}
                          onChange={(e) => handleRateChange(cat.id, e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-medium pointer-events-none">
                          ₹/{cat.unit}
                        </span>
                      </>
                    ) : (
                      <>
                        <input
                          type="number"
                          inputMode="decimal"
                          min="0"
                          step="1"
                          placeholder="Labour"
                          value={currentLabVal}
                          onChange={(e) => handleLabourRateChange(cat.id, e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-medium pointer-events-none">
                          ₹/{cat.labourUnit}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={handleResetToDefaults}
            className="flex items-center gap-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-white border border-rose-200 px-3.5 py-2 rounded-xl transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="text-xs font-semibold text-slate-600 px-3.5 py-2 rounded-xl hover:bg-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm px-5 py-2 rounded-xl flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all active:scale-95"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Saved!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Rates</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
