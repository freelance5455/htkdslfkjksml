import React, { useState, useEffect, useMemo } from 'react';
import { BoardTile, Direction } from '../types';
import { TILE_COLOR_CONFIGS } from './ArrowTile';
import { getDirectionDelta } from '../game/pathSolver';

interface LongArrowPieceProps {
  tile: BoardTile;
  tileSize: number;
  gap: number;
  padding?: number;
  arrowSkin: string;
  isBlockedShaking: boolean;
  onTap: (tile: BoardTile) => void;
  gridWidth?: number;
  gridHeight?: number;
}

interface Point {
  x: number;
  y: number;
}

interface Segment {
  p1: Point;
  p2: Point;
  len: number;
  angle: number; // in degrees: 0=RIGHT, 90=DOWN, 180=LEFT, 270=UP
}

export const LongArrowPiece: React.FC<LongArrowPieceProps> = ({
  tile,
  tileSize,
  gap,
  padding = 16,
  arrowSkin,
  isBlockedShaking,
  onTap,
  gridWidth = 8,
  gridHeight = 8,
}) => {
  const [escapeProgress, setEscapeProgress] = useState(0);

  // Palette from equipped skin
  const paletteKey =
    arrowSkin && TILE_COLOR_CONFIGS[arrowSkin] ? arrowSkin : 'black';
  const palette = TILE_COLOR_CONFIGS[paletteKey] || TILE_COLOR_CONFIGS.black;

  // Grid coordinates from tail to head
  const points = useMemo(() => {
    return tile.points && tile.points.length > 0
      ? tile.points
      : [{ x: tile.x, y: tile.y }];
  }, [tile.points, tile.x, tile.y]);

  const headIndex = points.length - 1;
  const headGrid = points[headIndex];

  // Convert grid coordinates to pixel centers
  const toPixel = (gx: number, gy: number): Point => ({
    x: padding + gx * (tileSize + gap) + tileSize / 2,
    y: padding + gy * (tileSize + gap) + tileSize / 2,
  });

  // Build the complete predefined railway track:
  // Starts at tail, passes through all right-angle segments to the head,
  // then follows exitWaypoints (or steps forward in direction off the board)
  const fullPixelTrack = useMemo(() => {
    let exitGridPoints: Point[] = [];

    if (tile.exitWaypoints && tile.exitWaypoints.length > 0) {
      exitGridPoints = tile.exitWaypoints;
    } else {
      const { dx, dy } = getDirectionDelta(tile.direction || 'UP');
      // Extend far enough past the edge so the entire tail exits off board
      const extraSteps = Math.max(gridWidth, gridHeight) + points.length + 5;
      exitGridPoints = [
        {
          x: headGrid.x + dx * extraSteps,
          y: headGrid.y + dy * extraSteps,
        },
      ];
    }

    const fullTrack = [...points, ...exitGridPoints];
    return fullTrack.map((pt) => toPixel(pt.x, pt.y));
  }, [points, tile.exitWaypoints, tile.direction, headGrid, gridWidth, gridHeight, tileSize, gap, padding]);

  // Precompute right-angle segments along the railway track
  const { segments, cumDist, totalDist, bodyLength } = useMemo(() => {
    const segs: Segment[] = [];
    const distances: number[] = [0];

    for (let i = 0; i < fullPixelTrack.length - 1; i++) {
      const p1 = fullPixelTrack[i];
      const p2 = fullPixelTrack[i + 1];
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;
      const len = Math.hypot(dx, dy);

      let angle = 0;
      if (Math.abs(dx) > Math.abs(dy)) {
        angle = dx > 0 ? 0 : 180;
      } else {
        angle = dy > 0 ? 90 : 270;
      }

      segs.push({ p1, p2, len, angle });
      distances.push(distances[i] + len);
    }

    const bodyDist = distances[points.length - 1] || tileSize;
    const totDist = distances[distances.length - 1] || bodyDist;

    return {
      segments: segs,
      cumDist: distances,
      totalDist: totDist,
      bodyLength: bodyDist,
    };
  }, [fullPixelTrack, points.length, tileSize]);

  // Railway Path Slicing: finds point and angle at any distance s along the track
  const getPointAtDist = (dist: number) => {
    if (segments.length === 0) {
      return { pt: { x: 0, y: 0 }, segIndex: 0, angle: 0 };
    }
    if (dist <= 0) {
      const seg = segments[0];
      return { pt: seg.p1, segIndex: 0, angle: seg.angle };
    }
    if (dist >= totalDist) {
      const seg = segments[segments.length - 1];
      return { pt: seg.p2, segIndex: segments.length - 1, angle: seg.angle };
    }

    for (let i = 0; i < segments.length; i++) {
      const s1 = cumDist[i];
      const s2 = cumDist[i + 1];
      if (dist >= s1 && dist <= s2) {
        const seg = segments[i];
        const u = seg.len > 0 ? (dist - s1) / seg.len : 0;
        const pt = {
          x: seg.p1.x + u * (seg.p2.x - seg.p1.x),
          y: seg.p1.y + u * (seg.p2.y - seg.p1.y),
        };
        return { pt, segIndex: i, angle: seg.angle };
      }
    }

    const lastSeg = segments[segments.length - 1];
    return { pt: lastSeg.p2, segIndex: segments.length - 1, angle: lastSeg.angle };
  };

  // Animate the arrow traveling along its railway path when escaping
  useEffect(() => {
    if (!tile.isEscaping) {
      setEscapeProgress(0);
      return;
    }

    let start: number | null = null;
    let animId: number;
    const duration = 380; // ms

    const step = (now: number) => {
      if (start === null) start = now;
      const elapsed = now - start;
      const raw = Math.min(1, elapsed / duration);
      // Clean acceleration along railway track
      const eased = raw * raw;
      setEscapeProgress(eased);
      if (raw < 1) {
        animId = requestAnimationFrame(step);
      }
    };

    animId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animId);
  }, [tile.isEscaping]);

  // Head distance and tail distance along the predefined track
  const sHead = tile.isEscaping
    ? bodyLength + escapeProgress * (totalDist - bodyLength)
    : bodyLength;
  const sTail = tile.isEscaping ? Math.max(0, sHead - bodyLength) : 0;

  // Slice the railway track between sTail and sHead
  const { pathD, headPt, headAngle } = useMemo(() => {
    if (segments.length === 0) {
      return { pathD: '', headPt: { x: 0, y: 0 }, headAngle: 0 };
    }

    const tailInfo = getPointAtDist(sTail);
    const headInfo = getPointAtDist(sHead);

    const pts: Point[] = [tailInfo.pt];
    if (tailInfo.segIndex < headInfo.segIndex) {
      for (let j = tailInfo.segIndex; j < headInfo.segIndex; j++) {
        // Retain exact 90-degree corner vertex
        pts.push(segments[j].p2);
      }
    }
    pts.push(headInfo.pt);

    const d = pts
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
      .join(' ');

    return {
      pathD: d,
      headPt: headInfo.pt,
      headAngle: headInfo.angle,
    };
  }, [sTail, sHead, segments, cumDist, totalDist]);

  // Blocked shake displacement
  const dirDelta = getDirectionDelta(tile.direction || 'UP');
  const shakeX = isBlockedShaking ? dirDelta.dx * 5 : 0;
  const shakeY = isBlockedShaking ? dirDelta.dy * 5 : 0;

  const isRainbow = arrowSkin === 'rainbow';
  const strokeColor = isRainbow ? `url(#rainbow-grad-${tile.id})` : palette.arrowStroke;
  const headFill = isRainbow ? '#06b6d4' : palette.arrowFill;
  const headStroke = isRainbow ? '#ffffff' : palette.arrowStroke;

  const isInteractive = !tile.isEscaping;

  return (
    <div
      id={`long-arrow-${tile.id}`}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{
        zIndex: tile.isEscaping ? 50 : tile.isHinted ? 40 : 20,
      }}
    >
      <svg className="w-full h-full overflow-visible pointer-events-none">
        <defs>
          {isRainbow && (
            <linearGradient
              id={`rainbow-grad-${tile.id}`}
              x1="0%"
              y1="0%"
              x2="100%"
              y2="100%"
            >
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="25%" stopColor="#f59e0b" />
              <stop offset="50%" stopColor="#10b981" />
              <stop offset="75%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#8b5cf6" />
            </linearGradient>
          )}
        </defs>

        <g
          style={{
            transform: `translate(${shakeX}px, ${shakeY}px)`,
            transition: isBlockedShaking ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          {/* Hint Glow Pulse */}
          {tile.isHinted && pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="#facc15"
              strokeWidth="9"
              strokeLinecap="square"
              strokeLinejoin="miter"
              strokeOpacity="0.75"
              className="animate-pulse"
            />
          )}

          {/* Under-shadow line for contrast against all board themes */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="rgba(0, 0, 0, 0.45)"
              strokeWidth="6.5"
              strokeLinecap="square"
              strokeLinejoin="miter"
            />
          )}

          {/* Core thin pen-line body (Strictly right-angle segments, clean 90-degree corners) */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke={strokeColor}
              strokeWidth="4.5"
              strokeLinecap="square"
              strokeLinejoin="miter"
            />
          )}

          {/* Fine interior highlight for metallic/neon pen feel */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="rgba(255, 255, 255, 0.45)"
              strokeWidth="1.5"
              strokeLinecap="square"
              strokeLinejoin="miter"
            />
          )}

          {/* Sharp, clean architectural arrowhead at the front */}
          <g
            transform={`translate(${headPt.x}, ${headPt.y}) rotate(${headAngle})`}
            className="pointer-events-none"
          >
            {/* Arrowhead drop shadow */}
            <polygon
              points="-14,-8 3,0 -14,8 -9,0"
              fill="rgba(0,0,0,0.4)"
              transform="translate(1, 1)"
            />
            {/* Arrowhead body */}
            <polygon
              points="-14,-8 3,0 -14,8 -9,0"
              fill={headFill}
              stroke={headStroke}
              strokeWidth="1.8"
              strokeLinejoin="miter"
            />
          </g>

          {/* Invisible wide hit area for effortless clicking/tapping along the thin path */}
          {isInteractive && pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="transparent"
              strokeWidth={Math.max(36, tileSize * 0.85)}
              strokeLinecap="square"
              strokeLinejoin="miter"
              className="pointer-events-auto cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                onTap(tile);
              }}
            />
          )}

          {/* Invisible wide hit target at the arrowhead */}
          {isInteractive && (
            <circle
              cx={headPt.x}
              cy={headPt.y}
              r={Math.max(22, tileSize * 0.6)}
              fill="transparent"
              className="pointer-events-auto cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                onTap(tile);
              }}
            />
          )}
        </g>
      </svg>
    </div>
  );
};
