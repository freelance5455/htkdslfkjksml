import React, { useState } from 'react';
import { AlertTriangle, Radio, ShieldAlert, Zap, Play, Square, Activity } from 'lucide-react';
import { soundService } from '../utils/sound';

interface StrobeSosModeProps {
  isStrobeActive: boolean;
  onToggleStrobe: () => void;
  strobeFrequency: number;
  onFrequencyChange: (freq: number) => void;
  isSosActive: boolean;
  onToggleSos: () => void;
  isHazardActive: boolean;
  onToggleHazard: () => void;
  onMomentaryPressStart: () => void;
  onMomentaryPressEnd: () => void;
  isOled: boolean;
}

export const StrobeSosMode: React.FC<StrobeSosModeProps> = ({
  isStrobeActive,
  onToggleStrobe,
  strobeFrequency,
  onFrequencyChange,
  isSosActive,
  onToggleSos,
  isHazardActive,
  onToggleHazard,
  onMomentaryPressStart,
  onMomentaryPressEnd,
  isOled,
}) => {
  const [momentaryActive, setMomentaryActive] = useState(false);

  const handleMomentaryDown = () => {
    setMomentaryActive(true);
    soundService.playSwitchOn();
    onMomentaryPressStart();
  };

  const handleMomentaryUp = () => {
    if (momentaryActive) {
      setMomentaryActive(false);
      soundService.playSwitchOff();
      onMomentaryPressEnd();
    }
  };

  return (
    <div className="space-y-5">
      {/* Photosensitivity Warning Banner */}
      <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-amber-950/30 border border-amber-600/40 text-amber-200">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs">
          <span className="font-semibold block text-amber-300">
            Upozornění: Rychlé záblesky světla
          </span>
          <span className="text-amber-200/80">
            Stroboskop vytváří intenzivní pulsy světla. Nepoužívejte v blízkosti osob s fotosenzitivní epilepsií.
          </span>
        </div>
      </div>

      {/* Strobe Controller Card */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                isStrobeActive
                  ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                  : 'bg-slate-800/40 border-slate-700 text-slate-400'
              }`}
            >
              <Zap className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Stroboskop (Nastavitelná frekvence)
              </h3>
              <p className="text-xs text-slate-400">
                Pravidelné záblesky s přesným časováním
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundService.playTick();
              onToggleStrobe();
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isStrobeActive
                ? 'bg-cyan-400 text-slate-950 shadow-[0_0_15px_#00F0FF]'
                : 'bg-slate-950 border border-slate-700 text-slate-200 hover:border-slate-500'
            }`}
          >
            {isStrobeActive ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Zastavit</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Spustit</span>
              </>
            )}
          </button>
        </div>

        {/* Frequency Slider */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
            <span className="flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Rychlost blikání</span>
            </span>
            <span className="font-mono text-cyan-400 text-sm tabular-nums">
              {strobeFrequency} Hz ({strobeFrequency}× za sekundu)
            </span>
          </div>

          <input
            type="range"
            min="1"
            max="20"
            step="1"
            value={strobeFrequency}
            onChange={(e) => onFrequencyChange(Number(e.target.value))}
            className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            aria-label="Frekvence stroboskopu"
          />

          <div className="flex justify-between text-[10px] text-slate-500 font-mono tabular-nums">
            <span>1 Hz (Pomalé)</span>
            <span>10 Hz (Střední)</span>
            <span>20 Hz (Ultra rychlé)</span>
          </div>
        </div>
      </div>

      {/* Emergency SOS & Police/Hazard Mode */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* SOS Morse Signal */}
        <div
          className={`rounded-2xl p-4 border flex flex-col justify-between ${
            isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Radio className="w-4 h-4 text-red-500" />
              <h4 className="text-sm font-bold text-white">Nouzový signál SOS</h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Mezinárodní morseovka <span className="font-mono text-red-400 font-bold">··· ——— ···</span> se zvukovým tónem a záblesky pro záchranu a lokalizaci.
            </p>
          </div>
          <button
            onClick={() => {
              soundService.playTick();
              onToggleSos();
            }}
            className={`w-full py-2.5 rounded-xl font-bold text-xs tracking-wider uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isSosActive
                ? 'bg-red-500 text-white shadow-[0_0_20px_#ff0033] animate-pulse'
                : 'bg-red-950/40 border border-red-700/60 text-red-300 hover:bg-red-900/50'
            }`}
          >
            {isSosActive ? 'Zastavit SOS' : 'Aktivovat SOS signál'}
          </button>
        </div>

        {/* Hazard / Police Flasher */}
        <div
          className={`rounded-2xl p-4 border flex flex-col justify-between ${
            isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-4 h-4 text-blue-400" />
              <h4 className="text-sm font-bold text-white">Výstražný maják</h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Střídavé dvoubarevné pulsy (červená & modrá) pro označení překážky, nehody nebo nebezpečí na silnici.
            </p>
          </div>
          <button
            onClick={() => {
              soundService.playTick();
              onToggleHazard();
            }}
            className={`w-full py-2.5 rounded-xl font-bold text-xs tracking-wider uppercase transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isHazardActive
                ? 'bg-blue-500 text-white shadow-[0_0_20px_#0088ff] animate-pulse'
                : 'bg-blue-950/40 border border-blue-700/60 text-blue-300 hover:bg-blue-900/50'
            }`}
          >
            {isHazardActive ? 'Zastavit maják' : 'Spustit maják'}
          </button>
        </div>
      </div>

      {/* Momentary Tactical Flash (Push to illuminate) */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border text-center ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <h4 className="text-sm font-semibold text-white mb-1">
          Taktické momentální rozsvícení
        </h4>
        <p className="text-xs text-slate-400 mb-4">
          Svítilna svítí pouze po dobu, kdy držíte prst nebo tlačítko myši stisknuté.
        </p>

        <button
          onMouseDown={handleMomentaryDown}
          onMouseUp={handleMomentaryUp}
          onMouseLeave={handleMomentaryUp}
          onTouchStart={handleMomentaryDown}
          onTouchEnd={handleMomentaryUp}
          className={`w-full max-w-xs mx-auto py-4 px-6 rounded-2xl font-extrabold text-sm uppercase tracking-widest transition-all cursor-pointer select-none active:scale-95 ${
            momentaryActive
              ? 'bg-cyan-400 text-slate-950 shadow-[0_0_35px_#00F0FF] scale-98'
              : isOled
              ? 'bg-neutral-950 border-2 border-neutral-800 text-slate-300 hover:border-cyan-500/60'
              : 'bg-slate-950 border-2 border-slate-800 text-slate-300 hover:border-cyan-500/60'
          }`}
        >
          {momentaryActive ? 'SVÍTÍ (DRŽÍTE)' : 'STISKNĚTE A DRŽTE'}
        </button>
      </div>
    </div>
  );
};
