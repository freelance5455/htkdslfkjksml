import React from 'react';
import { FloatingText, TapRipple } from '../types';

interface TapFeedbackProps {
  floatingTexts: FloatingText[];
  ripples: TapRipple[];
}

export const TapFeedback: React.FC<TapFeedbackProps> = ({ floatingTexts, ripples }) => {
  return (
    <div className="pointer-events-none fixed inset-0 z-20 overflow-hidden">
      {/* Expanding ripples */}
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          className="animate-ripple absolute rounded-full border-2"
          style={{
            left: ripple.x - 28,
            top: ripple.y - 28,
            width: 56,
            height: 56,
            borderColor: ripple.color,
            boxShadow: `0 0 16px ${ripple.color}`,
          }}
        />
      ))}

      {/* Floating score & combo indicators */}
      {floatingTexts.map((item) => (
        <div
          key={item.id}
          className="animate-float-up absolute flex flex-col items-center justify-center font-black tracking-wider drop-shadow-lg"
          style={{
            left: item.x,
            top: item.y,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <span
            className={`text-2xl font-black ${
              item.isGolden
                ? 'bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(251,191,36,0.8)]'
                : 'text-white'
            }`}
            style={{
              textShadow: item.isGolden
                ? '0 0 12px rgba(251,191,36,0.9)'
                : `0 0 12px ${item.color}, 0 2px 4px rgba(0,0,0,0.8)`,
            }}
          >
            {item.text}
          </span>
        </div>
      ))}
    </div>
  );
};
