import React from 'react';
import type { KanjiItem } from '../types';

interface KanjiVisualArtworkProps {
  type: KanjiItem['visualIllustration'];
  kanji: string;
}

export const KanjiVisualArtwork: React.FC<KanjiVisualArtworkProps> = ({ type, kanji }) => {
  switch (type) {
    case 'mountain':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#081236] to-[#0B1948] border border-cyan-500/30" role="img" aria-label={`Visual illustration for ${kanji} (Mountain)`}>
          <circle cx="175" cy="30" r="14" fill="#FDE047" opacity="0.9" />
          <path d="M 15 125 L 62 62 L 95 102 L 135 28 L 198 125 Z" fill="#1E293B" stroke="#38BDF8" strokeWidth="2.5" />
          <path d="M 135 28 L 118 56 L 130 52 L 138 60 L 152 54 Z" fill="#F8FAFC" />
          <path d="M 62 62 L 50 78 L 62 74 L 74 79 Z" fill="#E2E8F0" opacity="0.85" />
          {/* Ghost 山 overlay showing pictograph origin */}
          <path d="M 110 38 V 112 M 64 68 V 114 H 158 M 158 66 V 114" stroke="#00F0FF" strokeWidth="4" strokeLinecap="round" strokeDasharray="5 4" fill="none" opacity="0.7" />
        </svg>
      );
    case 'sun':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#1A103D] to-[#2B124C] border border-amber-400/30" role="img" aria-label={`Visual illustration for ${kanji} (Sun)`}>
          <circle cx="110" cy="68" r="36" fill="#F59E0B" opacity="0.25" />
          <circle cx="110" cy="68" r="24" fill="#FBBF24" />
          <line x1="20" y1="112" x2="200" y2="112" stroke="#38BDF8" strokeWidth="2" opacity="0.5" />
          <rect x="86" y="42" width="48" height="52" rx="4" fill="none" stroke="#FDE047" strokeWidth="3.5" strokeDasharray="4 3" />
          <line x1="86" y1="68" x2="134" y2="68" stroke="#FDE047" strokeWidth="3.5" strokeDasharray="4 3" />
        </svg>
      );
    case 'moon':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#060919] to-[#111944] border border-indigo-400/30" role="img" aria-label={`Visual illustration for ${kanji} (Moon)`}>
          <circle cx="48" cy="28" r="2" fill="#E2E8F0" />
          <circle cx="172" cy="40" r="2.5" fill="#E2E8F0" />
          <circle cx="150" cy="22" r="1.5" fill="#38BDF8" />
          <path d="M 118 28 A 40 40 0 1 0 118 110 A 30 34 0 1 1 118 28 Z" fill="#FDE047" opacity="0.88" />
        </svg>
      );
    case 'fire':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#1F0B1E] to-[#3B0D18] border border-rose-500/30" role="img" aria-label={`Visual illustration for ${kanji} (Fire)`}>
          <path d="M 110 20 C 136 52, 152 80, 134 114 C 122 122, 98 122, 86 114 C 66 82, 84 48, 110 20 Z" fill="#EF4444" opacity="0.8" />
          <path d="M 110 48 C 124 68, 130 88, 120 110 C 114 116, 106 116, 100 110 C 90 90, 96 68, 110 48 Z" fill="#FBBF24" />
          <circle cx="72" cy="52" r="4" fill="#FDE047" />
          <circle cx="148" cy="46" r="4" fill="#FDE047" />
        </svg>
      );
    case 'water':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#071936] to-[#082B4B] border border-cyan-400/30" role="img" aria-label={`Visual illustration for ${kanji} (Water)`}>
          <path d="M 110 22 V 118" stroke="#38BDF8" strokeWidth="6" strokeLinecap="round" />
          <path d="M 35 64 Q 65 48 85 72 T 135 66 T 185 74" fill="none" stroke="#00F0FF" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M 35 94 Q 65 78 85 102 T 135 96 T 185 104" fill="none" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" opacity="0.7" />
        </svg>
      );
    case 'tree':
    case 'forest':
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#061F1E] to-[#082A24] border border-emerald-400/30" role="img" aria-label={`Visual illustration for ${kanji}`}>
          {type === 'forest' ? (
            <>
              <polygon points="110,16 80,62 140,62" fill="#10B981" opacity="0.85" />
              <rect x="106" y="62" width="8" height="22" fill="#92400E" />
              <polygon points="65,58 35,108 95,108" fill="#059669" />
              <rect x="61" y="108" width="8" height="18" fill="#78350F" />
              <polygon points="155,58 125,108 185,108" fill="#059669" />
              <rect x="151" y="108" width="8" height="18" fill="#78350F" />
            </>
          ) : (
            <>
              <circle cx="110" cy="48" r="28" fill="#10B981" opacity="0.85" />
              <rect x="104" y="54" width="12" height="58" rx="3" fill="#92400E" />
              <path d="M 70 72 H 150 M 110 72 L 76 116 M 110 72 L 144 116" stroke="#34D399" strokeWidth="3" strokeLinecap="round" />
            </>
          )}
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 220 140" className="w-full h-36 rounded-xl bg-gradient-to-b from-[#0B1033] to-[#141748] border border-purple-400/30" role="img" aria-label={`Visual illustration for ${kanji}`}>
          <circle cx="110" cy="70" r="46" fill="none" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="4 4" />
          <circle cx="110" cy="70" r="34" fill="#1E1B4B" stroke="#A855F7" strokeWidth="2" />
          <text x="110" y="84" textAnchor="middle" fill="#F8FAFC" fontSize="42" fontWeight="bold">
            {kanji}
          </text>
        </svg>
      );
  }
};
