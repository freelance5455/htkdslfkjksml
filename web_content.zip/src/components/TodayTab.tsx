/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Check,
  Ban,
  CornerDownRight,
  ArrowUp,
  ArrowDown,
  GripVertical,
  Calendar,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { TaskStatus, ToDoGroup, ToDoTask } from '../types.ts';
import {
  addDays,
  formatDateToBengali,
  getMissedDaysInPast100Days,
  getTaskStatusOnDate,
  getTodayDateString,
  isDateScheduled,
  toBengaliNum,
} from '../utils/dateUtils.ts';
import { EmptyState } from './EmptyState.tsx';

type TodaySubTab = 'pending' | 'completed' | 'history100';

interface TodayTabProps {
  todoGroups: ToDoGroup[];
  todayCustomOrder: string[];
  isEditMode: boolean;
  onUpdateTaskReport: (
    groupId: string,
    taskId: string,
    dateStr: string,
    status: TaskStatus | null,
    postponedTo?: string
  ) => void;
  onUpdateCustomOrder: (newOrder: string[]) => void;
}

export const TodayTab: React.FC<TodayTabProps> = ({
  todoGroups,
  todayCustomOrder,
  isEditMode,
  onUpdateTaskReport,
  onUpdateCustomOrder,
}) => {
  const today = getTodayDateString();
  const [subTab, setSubTab] = useState<TodaySubTab>('pending');

  // "পরে করবো" Modal state
  const [postponeTask, setPostponeTask] = useState<{
    groupId: string;
    taskId: string;
    name: string;
  } | null>(null);
  const [postponeDate, setPostponeDate] = useState<string>(addDays(today, 1));
  const [postponeError, setPostponeError] = useState<string | null>(null);

  // Accordion state for expanded tasks in 100 days history
  const [expandedMissedTasks, setExpandedMissedTasks] = useState<Record<string, boolean>>({});

  // 1. Gather all tasks scheduled for TODAY from To Do groups
  const allScheduledToday: Array<{ task: ToDoTask; group: ToDoGroup; defaultIndex: number }> = [];
  let defaultCounter = 0;

  todoGroups.forEach((group) => {
    group.tasks.forEach((task) => {
      if (isDateScheduled(task, today)) {
        allScheduledToday.push({
          task,
          group,
          defaultIndex: defaultCounter++,
        });
      }
    });
  });

  // Sorting helper according to custom order (or default group+task order)
  const getTaskOrderIndex = (taskId: string, defaultIdx: number): number => {
    const customIdx = todayCustomOrder.indexOf(taskId);
    if (customIdx !== -1) {
      return customIdx;
    }
    // If not in custom list yet, put after custom items in default order
    return 100000 + defaultIdx;
  };

  const sortByCustomOrder = (
    a: { task: ToDoTask; defaultIndex: number },
    b: { task: ToDoTask; defaultIndex: number }
  ) => {
    const orderA = getTaskOrderIndex(a.task.id, a.defaultIndex);
    const orderB = getTaskOrderIndex(b.task.id, b.defaultIndex);
    return orderA - orderB;
  };

  // Sort all today's tasks
  const sortedTodayTasks = [...allScheduledToday].sort(sortByCustomOrder);

  // 6.1: বাকি আছে (Pending: scheduled today and no report)
  const pendingTasks = sortedTodayTasks.filter(
    (item) => getTaskStatusOnDate(item.task, today, today) === 'pending'
  );

  // 6.2: করেছি / করবো না / পরে করবো (today with reports)
  // Strict order: first all 'done', then all 'wont_do', then all 'postponed'
  const doneTasks = sortedTodayTasks.filter(
    (item) => getTaskStatusOnDate(item.task, today, today) === 'done'
  );
  const wontDoTasks = sortedTodayTasks.filter(
    (item) => getTaskStatusOnDate(item.task, today, today) === 'wont_do'
  );
  const postponedTasks = sortedTodayTasks.filter(
    (item) => getTaskStatusOnDate(item.task, today, today) === 'postponed'
  );

  const completedSectionTasks = [...doneTasks, ...wontDoTasks, ...postponedTasks];

  // 6.3: অতীতে করিনি (শেষ ১০০ দিন)
  // Check all tasks across all groups
  const tasksWithMissedDays: Array<{
    task: ToDoTask;
    group: ToDoGroup;
    missedDates: string[];
    defaultIndex: number;
  }> = [];

  let histCounter = 0;
  todoGroups.forEach((group) => {
    group.tasks.forEach((task) => {
      const missed = getMissedDaysInPast100Days(task, today);
      if (missed.length > 0) {
        tasksWithMissedDays.push({
          task,
          group,
          missedDates: missed,
          defaultIndex: histCounter++,
        });
      }
    });
  });

  tasksWithMissedDays.sort(sortByCustomOrder);

  // Handler for reordering in Today Tab
  const handleMoveTodayTask = (taskId: string, direction: 'up' | 'down') => {
    // Current visible list IDs depending on active sub-tab (or all scheduled tasks)
    const currentList = sortedTodayTasks.map((i) => i.task.id);
    const index = currentList.indexOf(taskId);
    if (index === -1) return;

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= currentList.length) return;

    // Swap
    const newCustomOrder = [...currentList];
    const temp = newCustomOrder[index];
    newCustomOrder[index] = newCustomOrder[targetIndex];
    newCustomOrder[targetIndex] = temp;

    onUpdateCustomOrder(newCustomOrder);
  };

  // Handlers for 6.1 Actions
  const handleMarkDone = (groupId: string, taskId: string) => {
    onUpdateTaskReport(groupId, taskId, today, 'done');
  };

  const handleMarkWontDo = (groupId: string, taskId: string) => {
    onUpdateTaskReport(groupId, taskId, today, 'wont_do');
  };

  const handleOpenPostpone = (groupId: string, taskId: string, name: string) => {
    setPostponeTask({ groupId, taskId, name });
    setPostponeDate(addDays(today, 1));
    setPostponeError(null);
  };

  const handleConfirmPostpone = () => {
    if (!postponeTask) return;
    if (!postponeDate || postponeDate <= today) {
      setPostponeError('বাছা তারিখটি অবশ্যই আজকের পরের কোনো দিন হতে হবে।');
      return;
    }
    onUpdateTaskReport(postponeTask.groupId, postponeTask.taskId, today, 'postponed', postponeDate);
    setPostponeTask(null);
  };

  // Handler for 6.2 Undo/Restore to Pending
  const handleRestoreToPending = (groupId: string, taskId: string) => {
    // Removing the report on today returns it to pending;
    // and if it was postponed, onUpdateTaskReport clears postponedDates[today] too!
    onUpdateTaskReport(groupId, taskId, today, null);
  };

  const toggleMissedDetails = (taskId: string) => {
    setExpandedMissedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  return (
    <div className="pb-28 max-w-md mx-auto px-4 pt-3">
      {/* Date Header Card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs mb-3 flex items-center justify-between">
        <div>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            আজকের তারিখ
          </span>
          <h2 className="text-lg font-bold text-slate-900 mt-0.5">
            {formatDateToBengali(today, true)}
          </h2>
        </div>
        <div className="text-right">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">
            {toBengaliNum(pendingTasks.length)}টি বাকি
          </span>
        </div>
      </div>

      {/* 3 Sub-Tabs Navigation */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-2xl mb-4">
        {/* Tab 1: বাকি আছে */}
        <button
          type="button"
          onClick={() => setSubTab('pending')}
          className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            subTab === 'pending'
              ? 'bg-white text-emerald-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>বাকি আছে</span>
          <span
            className={`text-[11px] px-1.5 rounded-full font-bold ${
              subTab === 'pending' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-300/60'
            }`}
          >
            {toBengaliNum(pendingTasks.length)}
          </span>
        </button>

        {/* Tab 2: করেছি / করবো না / পরে করবো */}
        <button
          type="button"
          onClick={() => setSubTab('completed')}
          className={`flex-1 py-2 px-1 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            subTab === 'completed'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>রিপোর্ট করা</span>
          <span
            className={`text-[11px] px-1.5 rounded-full font-bold ${
              subTab === 'completed' ? 'bg-slate-200 text-slate-800' : 'bg-slate-300/60'
            }`}
          >
            {toBengaliNum(completedSectionTasks.length)}
          </span>
        </button>

        {/* Tab 3: অতীতে করিনি (শেষ ১০০ দিন) */}
        <button
          type="button"
          onClick={() => setSubTab('history100')}
          className={`flex-1 py-2 px-1 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            subTab === 'history100'
              ? 'bg-white text-rose-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>অতীতে করিনি</span>
          <span
            className={`text-[11px] px-1.5 rounded-full font-bold ${
              subTab === 'history100' ? 'bg-rose-100 text-rose-800' : 'bg-slate-300/60'
            }`}
          >
            {toBengaliNum(tasksWithMissedDays.length)}
          </span>
        </button>
      </div>

      {/* ================= SUB-TAB 1: বাকি আছে (6.1) ================= */}
      {subTab === 'pending' && (
        <>
          {pendingTasks.length === 0 ? (
            <EmptyState
              message="আজকের কোনো কাজ বাকি নেই!"
              subMessage="সব কাজ সম্পন্ন করেছেন অথবা নির্ধারিত কাজ ছিল না।"
            />
          ) : (
            <div className="space-y-2.5">
              {pendingTasks.map((item, index) => {
                const { task, group } = item;

                return (
                  <div
                    key={task.id}
                    className={`p-3.5 rounded-2xl border transition-all duration-200 ${
                      isEditMode
                        ? 'bg-amber-50/70 border-amber-200/80 shadow-xs'
                        : 'bg-white border-slate-200/80 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      {/* Left: Reorder Controls OR Task Info */}
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        {isEditMode ? (
                          <div className="flex items-center gap-1 shrink-0 text-slate-500">
                            <GripVertical className="w-5 h-5 text-amber-600" />
                            <div className="flex flex-col gap-0.5">
                              <button
                                type="button"
                                disabled={index === 0}
                                onClick={() => handleMoveTodayTask(task.id, 'up')}
                                aria-label="উপরে নিন"
                                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                disabled={index === pendingTasks.length - 1}
                                onClick={() => handleMoveTodayTask(task.id, 'down')}
                                aria-label="নিচে নিন"
                                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="w-7 h-7 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0 border border-slate-200">
                            {toBengaliNum(index + 1)}
                          </div>
                        )}

                        <div className="min-w-0 flex-1">
                          <span className="text-[11px] font-semibold text-slate-400 block truncate">
                            {group.name}
                          </span>
                          <h4 className="text-base font-bold text-slate-900 leading-snug break-words">
                            {task.name}
                          </h4>
                          {task.details && (
                            <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 break-words">
                              {task.details}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right: 3 side-by-side action buttons (unless edit mode) */}
                      {!isEditMode && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          {/* 1. করেছি (✔) */}
                          <button
                            type="button"
                            onClick={() => handleMarkDone(group.id, task.id)}
                            className="flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 active:scale-95 transition-all w-14"
                          >
                            <Check className="w-4 h-4 stroke-[3] text-emerald-600 mb-0.5" />
                            <span className="text-[10px] font-bold leading-tight">করেছি</span>
                          </button>

                          {/* 2. আজ করবো না (⊘) */}
                          <button
                            type="button"
                            onClick={() => handleMarkWontDo(group.id, task.id)}
                            className="flex flex-col items-center justify-center py-1.5 px-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 active:scale-95 transition-all w-16"
                          >
                            <Ban className="w-4 h-4 stroke-[2.5] text-amber-600 mb-0.5" />
                            <span className="text-[10px] font-bold leading-tight text-center">
                              করবো না
                            </span>
                          </button>

                          {/* 3. পরে করবো (↪) */}
                          <button
                            type="button"
                            onClick={() => handleOpenPostpone(group.id, task.id, task.name)}
                            className="flex flex-col items-center justify-center py-1.5 px-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 active:scale-95 transition-all w-16"
                          >
                            <CornerDownRight className="w-4 h-4 stroke-[2.5] text-blue-600 mb-0.5" />
                            <span className="text-[10px] font-bold leading-tight text-center">
                              পরে করবো
                            </span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ================= SUB-TAB 2: করেছি / করবো না / পরে করবো (6.2) ================= */}
      {subTab === 'completed' && (
        <>
          {completedSectionTasks.length === 0 ? (
            <EmptyState
              message="আজকে এখনও কোনো কাজে রিপোর্ট দেওয়া হয়নি।"
              subMessage="'বাকি আছে' ট্যাব থেকে কাজের অবস্থা বেছে নিন।"
            />
          ) : (
            <div className="space-y-2.5">
              <p className="text-xs text-slate-500 mb-2 px-1">
                ভুল হলে যেকোনো কাজে চাপুন; সেটি আবার "বাকি" অবস্থায় ফিরে যাবে।
              </p>

              {completedSectionTasks.map((item, index) => {
                const { task, group } = item;
                const status = getTaskStatusOnDate(task, today, today);
                const postponedTargetDate = task.postponedDates?.[today];

                let statusBadge = null;
                let borderClass = 'border-slate-200';
                let bgClass = 'bg-white';

                if (status === 'done') {
                  borderClass = 'border-emerald-200';
                  bgClass = 'bg-emerald-50/40';
                  statusBadge = (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>করেছি</span>
                    </span>
                  );
                } else if (status === 'wont_do') {
                  borderClass = 'border-amber-200';
                  bgClass = 'bg-amber-50/40';
                  statusBadge = (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800 text-xs font-bold">
                      <Ban className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>করবো না</span>
                    </span>
                  );
                } else if (status === 'postponed') {
                  borderClass = 'border-blue-200';
                  bgClass = 'bg-blue-50/40';
                  statusBadge = (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-100 text-blue-800 text-xs font-bold">
                      <CornerDownRight className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>পরে করবো</span>
                    </span>
                  );
                }

                return (
                  <div
                    key={task.id}
                    onClick={() => {
                      if (!isEditMode) {
                        handleRestoreToPending(group.id, task.id);
                      }
                    }}
                    className={`p-3.5 rounded-2xl border shadow-xs transition-all duration-200 select-none ${bgClass} ${borderClass} ${
                      isEditMode
                        ? 'bg-amber-50/70 border-amber-200/80'
                        : 'hover:border-emerald-300 active:scale-[0.99] cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        {isEditMode ? (
                          <div className="flex items-center gap-1 shrink-0 text-slate-500">
                            <GripVertical className="w-5 h-5 text-amber-600" />
                            <div className="flex flex-col gap-0.5">
                              <button
                                type="button"
                                disabled={index === 0}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMoveTodayTask(task.id, 'up');
                                }}
                                aria-label="উপরে নিন"
                                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                disabled={index === completedSectionTasks.length - 1}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMoveTodayTask(task.id, 'down');
                                }}
                                aria-label="নিচে নিন"
                                className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="w-7 h-7 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0 border border-slate-200">
                            {toBengaliNum(index + 1)}
                          </div>
                        )}

                        <div className="min-w-0 flex-1">
                          <span className="text-[11px] font-semibold text-slate-400 block truncate">
                            {group.name}
                          </span>
                          <h4 className="text-base font-bold text-slate-900 leading-snug break-words">
                            {task.name}
                          </h4>
                          {status === 'postponed' && postponedTargetDate && (
                            <p className="text-xs font-bold text-blue-700 mt-0.5 flex items-center gap-1">
                              <ArrowRight className="w-3 h-3 text-blue-500" />
                              <span>→ {formatDateToBengali(postponedTargetDate, false)}</span>
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right badge / Undo prompt */}
                      <div className="text-right shrink-0">
                        {statusBadge}
                        {!isEditMode && (
                          <span className="block text-[10px] text-slate-400 mt-1 flex items-center justify-end gap-0.5">
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>বাকি করুন</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ================= SUB-TAB 3: অতীতে করিনি (শেষ ১০০ দিন - 6.3) ================= */}
      {subTab === 'history100' && (
        <>
          {tasksWithMissedDays.length === 0 ? (
            <EmptyState
              message="শেষ ১০০ দিনে কোনো 'করিনি' কাজ নেই!"
              subMessage="অসাধারণ! আপনি নিয়মিতভাবে আপনার রুটিন পালন করছেন।"
            />
          ) : (
            <div className="space-y-2.5">
              <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-2xl text-xs text-rose-900">
                <p className="font-semibold">
                  গত ১০০ দিনের চলমান হিসাব (আজ বাদে গতকাল থেকে পেছনের ১০০ দিন):
                </p>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  দিনের সংখ্যায় ট্যাপ করলে কোন কোন তারিখে কাজটি করা হয়নি তা দেখতে পাবেন।
                </p>
              </div>

              {tasksWithMissedDays.map((item) => {
                const { task, group, missedDates } = item;
                const isExpanded = !!expandedMissedTasks[task.id];

                return (
                  <div
                    key={task.id}
                    className="rounded-2xl border border-rose-200/80 bg-white shadow-xs overflow-hidden transition-all duration-200"
                  >
                    <div
                      onClick={() => toggleMissedDetails(task.id)}
                      className="p-3.5 flex items-center justify-between gap-2 cursor-pointer hover:bg-rose-50/30 transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <span className="text-[11px] font-semibold text-slate-400 block truncate">
                          {group.name}
                        </span>
                        <h4 className="text-base font-bold text-slate-900 leading-snug break-words">
                          {task.name}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-3 py-1.5 rounded-xl bg-rose-100 text-rose-800 font-bold text-xs border border-rose-200 shadow-2xs">
                          {toBengaliNum(missedDates.length)} দিন
                        </span>
                        <div className="text-slate-400">
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Expanded list of missed dates (Newest to Oldest) */}
                    {isExpanded && (
                      <div className="border-t border-rose-100 bg-rose-50/30 p-3.5 space-y-1.5 animate-in slide-in-from-top-2 duration-150">
                        <span className="text-xs font-bold text-rose-900 block mb-2">
                          যেসব তারিখে করা হয়নি ({toBengaliNum(missedDates.length)}টি তারিখ):
                        </span>
                        <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
                          {missedDates.map((d) => (
                            <div
                              key={d}
                              className="px-2.5 py-1.5 rounded-lg bg-white border border-rose-200 text-xs font-semibold text-slate-700 flex items-center justify-between"
                            >
                              <span>{formatDateToBengali(d, true)}</span>
                              <span className="text-rose-600 font-bold">✖</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* "পরে করবো" Modal: Choosing a target date after today */}
      {postponeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="p-5">
              <div className="flex items-center gap-2 text-blue-900 font-bold mb-2">
                <CornerDownRight className="w-5 h-5 text-blue-600" />
                <span>কাজটি পরে করবেন</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">{postponeTask.name}</h3>
              <p className="text-xs text-slate-500 mb-4">
                আজকের কাজটি স্থগিত রেখে কোন তারিখে করতে চান তা বাছুন (আজকের পরের যেকোনো দিন)।
              </p>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  পরবর্তী কাজের তারিখ <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  min={addDays(today, 1)}
                  value={postponeDate}
                  onChange={(e) => {
                    setPostponeDate(e.target.value);
                    setPostponeError(null);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                {postponeError && (
                  <p className="text-xs text-rose-600 font-medium mt-1.5">{postponeError}</p>
                )}
              </div>
            </div>

            <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
              <button
                type="button"
                onClick={() => setPostponeTask(null)}
                className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleConfirmPostpone}
                className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all shadow-sm"
              >
                নিশ্চিত করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
