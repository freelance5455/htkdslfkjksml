import { useEffect, useState } from 'react';
import { Terminal, ShieldCheck, Cpu, Radio, Sparkles } from 'lucide-react';
import { cyberAudio } from '../audio';
import CyberLogo from './CyberLogo';

interface Props {
  onComplete: () => void;
  customLogoUrl?: string | null;
}

export default function HackerBootSequence({ onComplete, customLogoUrl }: Props) {
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  const bootMessages = [
    'INITIATING GX-CORE SECURE KERNEL v4.5.2...',
    'CONNECTING TO CLOUD BROKER NODES [QUOTEX / 1XBET / 1WIN / POCKET OPTION]...',
    'CALCULATING ALGORITHMIC RSI & STOCHASTIC MOMENTUM MATRICES...',
    'DEPLOYING QUANTUM CRASH & MINES PROBABILITY NETWORK...',
    'DECRYPTING ACCESS PROTOCOL KEY: [MEHEDIVAI115]...',
    'SECURITY VERIFIED: ACCESS PRIVILEGES ELEVATED TO ROOT VIP...',
    'MEHEDI VAI CYBER TERMINAL ONLINE - WELCOME OPERATOR.',
  ];

  useEffect(() => {
    cyberAudio.playScanSweep();

    // Stream logs line by line
    let step = 0;
    const logInterval = setInterval(() => {
      if (step < bootMessages.length) {
        cyberAudio.playKeyBlip();
        setLogs((prev) => [...prev, bootMessages[step]]);
        setCurrentStep(step);
        step++;
      } else {
        clearInterval(logInterval);
      }
    }, 450);

    // Progress counter
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => {
            cyberAudio.playAccessGranted();
            onComplete();
          }, 600);
          return 100;
        }
        return prev + Math.floor(Math.random() * 8) + 2;
      });
    }, 120);

    return () => {
      clearInterval(logInterval);
      clearInterval(progressInterval);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-[#040608] flex flex-col items-center justify-center p-4 sm:p-6 text-emerald-400 select-none scanlines">
      {/* Background Cyber Grid */}
      <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />

      {/* Main Container Card */}
      <div className="relative z-10 w-full max-w-2xl bg-black/90 border border-emerald-500/50 rounded-2xl p-6 md:p-8 shadow-[0_0_50px_rgba(0,255,136,0.25)] box-glow-green">
        {/* Terminal Header Bar */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-emerald-500/30">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block animate-pulse" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            <span className="ml-2 text-xs font-mono text-emerald-500/80 font-bold uppercase tracking-widest">
              SECURE BOOT // TERMINAL PROTOCOL
            </span>
          </div>
          <button
            onClick={() => {
              cyberAudio.playClick();
              onComplete();
            }}
            className="text-xs text-emerald-400/70 hover:text-emerald-300 font-mono underline cursor-pointer hover:bg-emerald-950/40 px-2 py-1 rounded transition-all"
          >
            [SKIP BOOT &gt;&gt;]
          </button>
        </div>

        {/* Center Cyber Emblem / Logo */}
        <div className="flex flex-col items-center justify-center my-6">
          <CyberLogo size="lg" customLogoUrl={customLogoUrl} />
          <div className="mt-4 flex items-center gap-2 text-xs text-cyan-400 font-mono">
            <Radio className="w-4 h-4 animate-spin text-emerald-400" />
            <span>AI SIGNAL ENGINE INITIALIZING</span>
          </div>
        </div>

        {/* Console Log Screen */}
        <div className="bg-black/95 rounded-xl border border-emerald-500/30 p-4 font-mono text-xs text-emerald-400/90 h-44 overflow-y-auto space-y-1.5 shadow-inner">
          <div className="text-emerald-500/60 pb-1 border-b border-emerald-500/20 flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" /> GX-SHELL v4.5.2
            </span>
            <span>SYSTEM ENCRYPTED: AES-256</span>
          </div>
          {logs.map((log, index) => (
            <div key={index} className="flex items-start gap-2 leading-relaxed">
              <span className="text-cyan-400 select-none">&gt;&gt;</span>
              <span className={index === currentStep ? 'text-emerald-200 font-bold' : 'text-emerald-400/80'}>
                {log}
              </span>
            </div>
          ))}
          <div className="flex items-center gap-1 text-emerald-300 animate-pulse">
            <span>&gt;&gt;</span>
            <span className="w-2 h-4 bg-emerald-400 inline-block" />
          </div>
        </div>

        {/* Progress Bar & Percentage */}
        <div className="mt-6 space-y-2">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-emerald-300/80 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" /> SYSTEM DECRYPTION PROGRESS
            </span>
            <span className="text-emerald-300 font-bold tracking-widest text-sm neon-glow-green">
              {Math.min(progress, 100)}%
            </span>
          </div>
          <div className="w-full h-2.5 bg-emerald-950/60 rounded-full overflow-hidden border border-emerald-500/40 p-0.5">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-cyan-400 to-emerald-300 rounded-full transition-all duration-100 ease-out shadow-[0_0_12px_#00ff88]"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
        </div>

        {/* Footer Sub-badges */}
        <div className="mt-6 pt-4 border-t border-emerald-500/20 flex flex-wrap items-center justify-between gap-2 text-[11px] text-emerald-500/70 font-mono">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> MEHEDI VAI VERIFIED
          </span>
          <span className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> ALGO CONFLUENCE: ACTIVE
          </span>
        </div>
      </div>
    </div>
  );
}
