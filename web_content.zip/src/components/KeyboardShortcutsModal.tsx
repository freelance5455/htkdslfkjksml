import React from 'react';
import { Keyboard, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const KeyboardShortcutsModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'F1', desc: 'فاتورة بيع جديدة / تفريغ السلة', action: 'New Invoice' },
    { key: 'F2', desc: 'الدفع السريع وإنهاء الفاتورة', action: 'Quick Checkout' },
    { key: 'F3', desc: 'التركيز على شريط البحث والباركود', action: 'Focus Search / Barcode' },
    { key: 'F4', desc: 'فتح نافذة الخصم العام', action: 'Apply Discount' },
    { key: 'F9', desc: 'طباعة الفاتورة الحالية مباشرة', action: 'Print Invoice' },
    { key: 'Enter', desc: 'إضافة الصنف المحدد مباشرة عند مسح الباركود', action: 'Add Scanned Item' },
    { key: 'Esc', desc: 'إلغاء النافذة الحالية / إغلاق المودال', action: 'Close Modal' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-lg rounded-2xl bg-slate-800 border border-slate-700 shadow-2xl p-6 text-slate-100">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">اختصارات لوحة المفاتيح لنظام Windows</h3>
              <p className="text-xs text-slate-400">لزيادة سرعة الكاشير وإتمام عمليات البيع دون استخدام الماوس</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-2.5">
          {shortcuts.map((sc, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-750 hover:border-slate-600 transition"
            >
              <div className="text-sm font-medium text-slate-200">
                {sc.desc}
              </div>
              <kbd className="px-2.5 py-1 text-xs font-mono font-bold text-blue-300 bg-slate-800 border border-slate-600 rounded-md shadow-xs">
                {sc.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-750 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition shadow-lg shadow-blue-600/20"
          >
            فهمت، عودة للبرنامج
          </button>
        </div>
      </div>
    </div>
  );
};
