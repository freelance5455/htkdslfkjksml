import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Users, MapPin } from 'lucide-react';
import { CnicBatchStats } from '../types/cnic';

interface SummaryCardsProps {
  stats: CnicBatchStats;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({ stats }) => {
  if (stats.total === 0) {
    return null;
  }

  const validPct = stats.total > 0 ? Math.round((stats.valid / stats.total) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* 4 KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total */}
        <div className="bg-white rounded-xl p-4 border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Entered
          </span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
              {stats.total.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400 font-medium">100%</span>
          </div>
        </div>

        {/* Valid Format */}
        <div className="bg-white rounded-xl p-4 border border-emerald-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              Valid Format
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-700 font-mono">
              {stats.valid.toLocaleString()}
            </span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
              {validPct}%
            </span>
          </div>
        </div>

        {/* Duplicates */}
        <div className="bg-white rounded-xl p-4 border border-amber-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
              Duplicates
            </span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-700 font-mono">
              {stats.duplicate.toLocaleString()}
            </span>
            <span className="text-xs text-amber-700 font-medium">
              {stats.total > 0 ? Math.round((stats.duplicate / stats.total) * 100) : 0}%
            </span>
          </div>
        </div>

        {/* Invalid */}
        <div className="bg-white rounded-xl p-4 border border-red-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-red-800 uppercase tracking-wider">
              Invalid Format
            </span>
            <XCircle className="w-4 h-4 text-red-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-red-700 font-mono">
              {stats.invalid.toLocaleString()}
            </span>
            <span className="text-xs text-red-700 font-medium">
              {stats.total > 0 ? Math.round((stats.invalid / stats.total) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* Secondary Demographics Bar (Gender & Provinces) */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Gender Breakdown */}
        <div className="flex items-center gap-4 text-xs sm:text-sm">
          <div className="flex items-center gap-1.5 text-slate-500 font-medium">
            <Users className="w-4 h-4 text-slate-400" />
            <span>Gender (Valid):</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-700">
              Male: <strong className="text-slate-900 font-mono">{stats.maleCount}</strong>
            </span>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <span className="text-slate-700">
              Female: <strong className="text-slate-900 font-mono">{stats.femaleCount}</strong>
            </span>
          </div>
        </div>

        {/* Provinces summary */}
        {Object.keys(stats.provinceDistribution).length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto text-xs text-slate-600">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <div className="flex items-center gap-2 shrink-0">
              {Object.entries(stats.provinceDistribution).map(([prov, count]) => (
                <span key={prov} className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-slate-700">
                  {prov.split('(')[0].trim()}: <strong className="font-mono text-slate-900">{count}</strong>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
