/**
 * GODEX Phase 1 - Artifacts View
 * Real artifacts viewer utilizing OperationManager and ArtifactRegistry
 * Displaying plans, patches, reports, dossiers, and generated apps with one-click preview.
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  FileCode, 
  Eye, 
  CheckCircle2, 
  Layers, 
  Clock, 
  Code2, 
  ShieldCheck, 
  ExternalLink,
  Download,
  Copy,
  Check
} from 'lucide-react';
import { OperationManager } from '../godex/operationManager';
import { GeneratedArtifact, OperationState } from '../godex/operationState';
import { GodexOrchestrator } from '../orchestration/orchestrator';
import { AgentArtifact } from '../orchestration/orchestrationTypes';

interface GodexArtifactsViewProps {
  onSelectFile?: (path: string) => void;
  onOpenPreview?: () => void;
}

export const GodexArtifactsView: React.FC<GodexArtifactsViewProps> = ({
  onSelectFile,
  onOpenPreview
}) => {
  const [activeOperation, setActiveOperation] = useState<OperationState | null>(() => {
    return OperationManager.getInstance().getActiveOperation();
  });
  const [orchestratorArtifacts, setOrchestratorArtifacts] = useState<AgentArtifact[]>([]);
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const unsub = OperationManager.getInstance().subscribe(op => {
      setActiveOperation({ ...op });
    });
    const orch = GodexOrchestrator.getInstance();
    setOrchestratorArtifacts(orch.artifactRegistry.getAllArtifacts());
    const unsubOrch = orch.subscribe(session => {
      setOrchestratorArtifacts(orch.artifactRegistry.getAllArtifacts());
    });
    return () => {
      unsub();
      unsubOrch();
    };
  }, []);

  const generatedArtifact = activeOperation?.artifact || (activeOperation as any)?.generatedArtifact || null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="flex-1 h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#08090D] select-text">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#182030]">
        <div>
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Generated Project Artifacts</span>
          </h3>
          <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
            Verifiable code modules, architecture blueprints, dossiers, and application builds
          </p>
        </div>
        {generatedArtifact && (
          <button
            onClick={onOpenPreview}
            className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Launch Live Preview</span>
          </button>
        )}
      </div>

      {/* Primary Application Artifact Card */}
      {generatedArtifact ? (
        <div className="p-4 rounded-xl bg-[#0D121F] border border-[#1E2840] space-y-3 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                ACTIVE APPLICATION ARTIFACT
              </span>
              <h4 className="font-bold text-white text-sm">{generatedArtifact.name}</h4>
            </div>
            <span className="text-[10px] font-mono text-neutral-500">
              {new Date(generatedArtifact.createdAt).toLocaleTimeString()}
            </span>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed font-sans">
            {generatedArtifact.description}
          </p>

          <div className="p-3 rounded-lg bg-[#080B12] border border-[#161F30] flex items-center justify-between font-mono text-xs">
            <div className="space-y-1">
              <div className="text-neutral-400 text-[10px]">ENTRY POINT</div>
              <button 
                onClick={() => onSelectFile?.(generatedArtifact.entryFile)}
                className="font-bold text-cyan-300 hover:underline flex items-center gap-1"
              >
                <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                <span>{generatedArtifact.entryFile}</span>
              </button>
            </div>
            <div className="text-right">
              <div className="text-neutral-400 text-[10px]">TOTAL FILES</div>
              <span className="text-white font-bold">{Object.keys(generatedArtifact.files || {}).length} files</span>
            </div>
          </div>

          {/* Code snippet preview if reactCode exists */}
          {generatedArtifact.reactCode && (
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400">
                <span>Code Preview ({generatedArtifact.entryFile})</span>
                <button
                  onClick={() => handleCopy(generatedArtifact.reactCode!)}
                  className="text-cyan-400 hover:underline flex items-center gap-1"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy Source'}</span>
                </button>
              </div>
              <pre className="p-3 rounded-lg bg-[#06080E] border border-[#141C2C] text-[10px] font-mono text-neutral-300 max-h-40 overflow-y-auto whitespace-pre leading-relaxed">
                {generatedArtifact.reactCode.slice(0, 1500)}...
              </pre>
            </div>
          )}
        </div>
      ) : (
        <div className="p-8 text-center space-y-3 rounded-xl border border-dashed border-[#1A2234] bg-[#0A0D15]">
          <Sparkles className="w-8 h-8 text-neutral-600 mx-auto" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-neutral-300">No Application Artifact Generated Yet</h4>
            <p className="text-[11px] text-neutral-500 max-w-sm mx-auto">
              Execute a feature or application prompt in Chat to synthesize full production-ready React artifacts.
            </p>
          </div>
        </div>
      )}

      {/* Multi-Agent Artifacts Registry Stream */}
      {orchestratorArtifacts.length > 0 && (
        <div className="space-y-2 pt-3 border-t border-[#182030]">
          <div className="flex items-center justify-between font-mono text-xs">
            <span className="font-bold text-neutral-200 uppercase tracking-wider">
              Specialized Agent Artifacts ({orchestratorArtifacts.length})
            </span>
          </div>

          <div className="space-y-2">
            {orchestratorArtifacts.map((art) => (
              <div
                key={art.id}
                onClick={() => setSelectedArtifactId(selectedArtifactId === art.id ? null : art.id)}
                className="p-3 rounded-xl bg-[#0A0D15] hover:bg-[#101522] border border-[#182234] transition-colors cursor-pointer space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-[#141A28] text-cyan-300 border border-[#20293D]">
                      {art.type}
                    </span>
                    <h5 className="font-bold text-white text-xs">{art.title}</h5>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-[10px] text-neutral-500">
                    <span>By: <strong className="text-cyan-400">{art.createdBy}</strong></span>
                    <span>{new Date(art.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>

                {selectedArtifactId === art.id ? (
                  <pre className="p-3 rounded-lg bg-[#06080E] border border-[#141C2C] text-[10px] font-mono text-neutral-300 max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                    {art.content}
                  </pre>
                ) : (
                  <p className="text-[11px] text-neutral-400 line-clamp-2 font-sans">
                    {art.content.replace(/[#*`]/g, '')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
