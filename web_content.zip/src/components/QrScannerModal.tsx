import React, { useState, useEffect, useRef } from 'react';
import jsQR from 'jsqr';
import { 
  X, Camera, Image as ImageIcon, Sparkles, AlertCircle, 
  CheckCircle2, RefreshCw, KeyRound, Smartphone, ShieldCheck
} from 'lucide-react';
import { useParentControl } from '../context/ParentControlContext';
import { playScanChime } from '../lib/audioAlert';

interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPairSuccess?: (device: any) => void;
  defaultCode?: string;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  isOpen,
  onClose,
  onPairSuccess,
  defaultCode
}) => {
  const { pairDeviceFromQr, pairDeviceByCode, activeDevice, language } = useParentControl();
  const isAr = language === 'ar';

  const [scanMode, setScanMode] = useState<'camera' | 'upload' | 'manual'>('camera');
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState(defaultCode || '');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successInfo, setSuccessInfo] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Initialize camera stream when mode is 'camera' and modal is open
  useEffect(() => {
    if (!isOpen || scanMode !== 'camera' || successInfo) {
      stopCamera();
      return;
    }

    let isMounted = true;

    async function initCamera() {
      setCameraError(null);
      setErrorMessage(null);
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error(isAr ? 'الكاميرا غير مدعومة في هذا المتصفح' : 'Camera not supported in this browser');
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: cameraFacing,
            width: { ideal: 640 },
            height: { ideal: 480 }
          }
        });

        if (!isMounted) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true'); // Required for iOS Safari
          await videoRef.current.play().catch(() => {});
          requestAnimationFrame(scanVideoFrame);
        }
      } catch (err: any) {
        console.warn('Camera access error:', err);
        setCameraError(
          isAr 
            ? 'تعذر الوصول إلى الكاميرا (يمكنك استخدام رفع صورة الباركود أو الإدخال اليدوي).'
            : 'Camera access denied or unavailable. You can upload a QR image or enter code manually.'
        );
        setScanMode('upload');
      }
    }

    initCamera();

    return () => {
      isMounted = false;
      stopCamera();
    };
  }, [isOpen, scanMode, cameraFacing, successInfo, isAr]);

  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  // Continuous frame scanner using jsQR
  const scanVideoFrame = () => {
    if (!videoRef.current || !canvasRef.current || isProcessing || successInfo) {
      return;
    }

    const video = videoRef.current;
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        });

        if (code && code.data) {
          handleDecodedPayload(code.data);
          return;
        }
      }
    }

    animationFrameRef.current = requestAnimationFrame(scanVideoFrame);
  };

  // Handle successful decoded payload
  const handleDecodedPayload = (rawData: string) => {
    setIsProcessing(true);
    stopCamera();

    // Haptic & Chime feedback
    playScanChime();
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100]);
    }

    const result = pairDeviceFromQr(rawData);

    if (result.success && result.device) {
      setSuccessInfo(result.message);
      setErrorMessage(null);

      setTimeout(() => {
        if (onPairSuccess) onPairSuccess(result.device);
        onClose();
      }, 1500);
    } else {
      setErrorMessage(result.message || (isAr ? 'رمز QR غير صالح' : 'Invalid QR Code'));
      setIsProcessing(false);
      // Resume camera after 2 seconds
      setTimeout(() => {
        if (scanMode === 'camera') {
          animationFrameRef.current = requestAnimationFrame(scanVideoFrame);
        }
      }, 2000);
    }
  };

  // Upload QR Image from File Input
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setErrorMessage(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setErrorMessage(isAr ? 'فشلت معالجة الصورة' : 'Failed to process image');
          setIsProcessing(false);
          return;
        }

        ctx.drawImage(img, 0, 0, img.width, img.height);
        const imageData = ctx.getImageData(0, 0, img.width, img.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code && code.data) {
          handleDecodedPayload(code.data);
        } else {
          setErrorMessage(
            isAr 
              ? 'لم يتم العثور على رمز QR صالح في هذه الصورة. يرجى التأكد من وضوح الباركود.'
              : 'No valid QR code found in this image. Please ensure the QR is clear and well-lit.'
          );
          setIsProcessing(false);
        }
      };
      img.onerror = () => {
        setErrorMessage(isAr ? 'فشل تحميل ملف الصورة' : 'Failed to load image file');
        setIsProcessing(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // One-click Instant Test Scan Simulation
  const handleInstantDemoScan = () => {
    const code = defaultCode || activeDevice.pairingCode || 'PG-8421';
    const simulatedQr = JSON.stringify({
      type: 'PARENTGUARD_PAIR',
      code: code,
      deviceId: activeDevice.id,
      childName: activeDevice.childNameAr,
      deviceName: activeDevice.deviceName,
      platform: activeDevice.platform,
      timestamp: Date.now()
    });

    handleDecodedPayload(simulatedQr);
  };

  // Manual code submission
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;

    setIsProcessing(true);
    playScanChime();

    const result = pairDeviceByCode(manualCode.trim());
    if (result.success && result.device) {
      setSuccessInfo(
        isAr 
          ? `تم إقران هاتف (${result.device.childNameAr}) بنجاح!` 
          : `Device (${result.device.childName}) paired successfully!`
      );
      setErrorMessage(null);
      setTimeout(() => {
        if (onPairSuccess) onPairSuccess(result.device);
        onClose();
      }, 1400);
    } else {
      setErrorMessage(isAr ? 'رمز غير صالح أو لم يتم العثور على الجهاز' : 'Invalid code or device not found');
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      id="qr-scanner-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
    >
      <div 
        id="qr-scanner-card"
        className="relative w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col my-auto transition-colors"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'مسح رمز QR للإقران الفوري' : 'Scan QR for Instant Pairing'}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {isAr ? 'وجّه كاميرا الهاتف نحو باركود ولي الأمر' : 'Point camera at parent QR code'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl mb-4 text-xs font-semibold">
          <button
            onClick={() => setScanMode('camera')}
            className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              scanMode === 'camera'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{isAr ? 'الكاميرا' : 'Camera'}</span>
          </button>

          <button
            onClick={() => {
              stopCamera();
              setScanMode('upload');
            }}
            className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              scanMode === 'upload'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>{isAr ? 'رفع صورة' : 'Upload'}</span>
          </button>

          <button
            onClick={() => {
              stopCamera();
              setScanMode('manual');
            }}
            className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              scanMode === 'manual'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{isAr ? 'إدخال رمز' : 'Manual'}</span>
          </button>
        </div>

        {/* Success Banner */}
        {successInfo && (
          <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-center space-y-2 mb-4 animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-sm font-bold text-emerald-800 dark:text-emerald-200">
              {isAr ? 'تم الإقران بنجاح!' : 'Pairing Successful!'}
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">
              {successInfo}
            </p>
          </div>
        )}

        {/* Error Banner */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300 mb-3 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* MODE 1: LIVE CAMERA SCANNER */}
        {scanMode === 'camera' && !successInfo && (
          <div className="space-y-3">
            <div className="relative aspect-square w-full max-w-[280px] mx-auto rounded-3xl overflow-hidden bg-slate-950 border-2 border-indigo-500 shadow-xl flex items-center justify-center">
              {/* Actual Video */}
              <video
                ref={videoRef}
                className="absolute inset-0 w-full h-full object-cover"
                muted
                autoPlay
                playsInline
              />

              {/* Hidden Canvas for Decoding */}
              <canvas ref={canvasRef} className="hidden" />

              {/* Animated HUD Targeting Reticle */}
              <div className="absolute inset-6 border border-white/20 rounded-2xl pointer-events-none flex flex-col justify-between p-2">
                {/* 4 Corner Markers */}
                <div className="flex justify-between">
                  <div className="w-5 h-5 border-t-3 border-l-3 border-indigo-400 rounded-tl-lg" />
                  <div className="w-5 h-5 border-t-3 border-r-3 border-indigo-400 rounded-tr-lg" />
                </div>

                {/* Laser scan line moving up and down */}
                <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_10px_#34d399] animate-pulse" />

                <div className="flex justify-between">
                  <div className="w-5 h-5 border-b-3 border-l-3 border-indigo-400 rounded-bl-lg" />
                  <div className="w-5 h-5 border-b-3 border-r-3 border-indigo-400 rounded-br-lg" />
                </div>
              </div>

              {/* Camera Flip Button */}
              <button
                type="button"
                onClick={() => setCameraFacing(prev => prev === 'environment' ? 'user' : 'environment')}
                className="absolute bottom-3 end-3 p-2 bg-slate-900/80 hover:bg-slate-900 text-white rounded-xl backdrop-blur-sm border border-white/20 transition-transform active:scale-90"
                title={isAr ? 'تبديل الكاميرا' : 'Switch Camera'}
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              {cameraError && (
                <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-4 text-center">
                  <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
                  <p className="text-xs text-slate-300 mb-3">{cameraError}</p>
                  <button
                    onClick={() => setScanMode('upload')}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl"
                  >
                    {isAr ? 'استخدام صورة من المعرض' : 'Upload Image Instead'}
                  </button>
                </div>
              )}
            </div>

            <p className="text-center text-[11px] text-slate-500 dark:text-slate-400">
              {isAr ? 'ضع رمز QR الخاص بولي الأمر داخل الإطار ليتم المسح تلقائياً' : 'Align parent QR code inside frame to scan'}
            </p>
          </div>
        )}

        {/* MODE 2: UPLOAD IMAGE SCAN */}
        {scanMode === 'upload' && !successInfo && (
          <div className="space-y-4 text-center py-2">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />

            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-500 rounded-3xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer bg-slate-50/50 dark:bg-slate-800/30 transition-all group"
            >
              <div className="w-14 h-14 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ImageIcon className="w-7 h-7" />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                  {isAr ? 'انقر لاختيار لقطة شاشة أو صورة لرمز QR' : 'Click to select QR screenshot or photo'}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  PNG, JPG, WebP {isAr ? 'حتى 10 ميجابايت' : 'up to 10MB'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* MODE 3: MANUAL 6-DIGIT CODE */}
        {scanMode === 'manual' && !successInfo && (
          <form onSubmit={handleManualSubmit} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                {isAr ? 'أدخل رمز الإقران (الموضح في هاتف ولي الأمر):' : 'Enter 6-character Pairing Code:'}
              </label>
              <input
                type="text"
                required
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value.toUpperCase())}
                placeholder="PG-8421"
                className="w-full text-center font-mono text-2xl font-black uppercase tracking-widest bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl py-3 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              type="submit"
              disabled={isProcessing || !manualCode.trim()}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{isAr ? 'تأكيد والاقتران الآن' : 'Verify & Connect Now'}</span>
            </button>
          </form>
        )}

        {/* Quick Simulator Test Action */}
        {!successInfo && (
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{isAr ? 'تجربة سريعة بدون كاميرا:' : 'Instant test:'}</span>
            </span>

            <button
              type="button"
              onClick={handleInstantDemoScan}
              disabled={isProcessing}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>{isAr ? 'محاكاة المسح الفوري بنقرة' : 'Simulate Instant Scan'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
