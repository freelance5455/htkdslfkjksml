import React, { useState, useEffect } from 'react';
import { X, Compass, Navigation } from 'lucide-react';
import qiblaMedallion from '../assets/images/qibla_rosette_medallion_1791472551030.jpg';

interface QiblaCompassModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QiblaCompassModal: React.FC<QiblaCompassModalProps> = ({ isOpen, onClose }) => {
  const [deviceHeading, setDeviceHeading] = useState<number>(0);
  const [hasCompassSupport, setHasCompassSupport] = useState<boolean>(false);

  // Exact Qibla bearing from Dhaka, Bangladesh (23.8103° N, 90.4125° E) towards Kaaba (21.4225° N, 39.8262° E)
  const qiblaAngleFromDhaka = 268.4; // Degrees clockwise from North (approx WNW)

  useEffect(() => {
    if (!isOpen) return;

    const handleOrientation = (e: DeviceOrientationEvent) => {
      let heading = 0;
      if ('webkitCompassHeading' in e && typeof (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading === 'number') {
        // iOS
        heading = (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading;
        setHasCompassSupport(true);
      } else if (e.alpha !== null) {
        // Android
        heading = 360 - e.alpha;
        setHasCompassSupport(true);
      }
      setDeviceHeading(heading);
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation, true);
    }

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Rotation needed so compass points to Qibla
  const needleRotation = qiblaAngleFromDhaka - deviceHeading;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-md rounded-3xl border border-emerald-900/60 bg-slate-900 shadow-2xl text-slate-100 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <Compass className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Qibla Direction (কিবলা দিক)</h2>
              <p className="text-xs text-slate-400">Dhaka, Bangladesh · 268° West-North-West</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-800 bg-slate-950 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Compass Visual Container */}
        <div className="p-6 flex flex-col items-center">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
            {/* Medallion Background */}
            <img
              src={qiblaMedallion}
              alt="Islamic geometric rosette astrolabe medallion"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover rounded-full shadow-2xl border-2 border-amber-600/60"
            />

            {/* Compass Dial markings */}
            <div className="absolute inset-0 rounded-full border-4 border-emerald-900/40 pointer-events-none" />

            {/* Qibla Needle */}
            <div
              className="absolute w-full h-full flex items-center justify-center transition-transform duration-300 pointer-events-none"
              style={{ transform: `rotate(${needleRotation}deg)` }}
            >
              <div className="relative h-44 w-8 flex flex-col items-center justify-between">
                {/* Kaaba Arrow Head */}
                <div className="flex flex-col items-center">
                  <div className="bg-amber-400 text-slate-950 text-[10px] font-extrabold px-1.5 py-0.5 rounded shadow">
                    KAABA
                  </div>
                  <Navigation className="w-7 h-7 text-amber-400 fill-amber-400 -mt-1 drop-shadow-lg" />
                </div>
                {/* Center Pivot */}
                <div className="w-4 h-4 rounded-full bg-amber-300 border-2 border-slate-900 shadow-md" />
                {/* Tail */}
                <div className="w-1.5 h-10 bg-slate-400/80 rounded-full" />
              </div>
            </div>
          </div>

          {/* Direction Stats */}
          <div className="mt-6 w-full rounded-2xl border border-slate-800 bg-slate-950/70 p-4 text-center">
            <div className="font-mono text-3xl font-extrabold text-amber-400 tabular-nums">
              268.4° WNW
            </div>
            <div className="mt-1 text-xs text-slate-300 font-medium">
              Calculated Azimuth from Dhaka to Makkah Al-Mukarramah
            </div>
            <div className="mt-2 text-[11px] text-slate-400">
              {hasCompassSupport
                ? 'Device gyro active: Align the Kaaba arrow directly facing you to face the Qibla.'
                : 'Turn your body towards West (slightly North of West) towards Mecca.'}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-950/80 px-6 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
