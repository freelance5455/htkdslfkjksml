import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Check } from 'lucide-react';
import { Language } from '../types';
import { playKeyTap } from '../utils/audio';

interface OnboardingViewProps {
  language: Language;
  onFinish: () => void;
}

export default function OnboardingView({ language, onFinish }: OnboardingViewProps) {
  const isSw = language === 'sw';
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      titleSw: 'Jua muda sahihi wa kupanda',
      titleEn: 'Know the right time to plant',
      descSw:
        'Kalenda ya mazao na hali ya hewa ya eneo lako vinakuambia lini hasa upande na lini uvune kwa tija kubwa.',
      descEn:
        'The crop calendar and hyper-local weather forecast tell you exactly when to plant and harvest for peak yield.',
      color: 'from-[#E7D2A0] to-[#C89B3C]',
      icon: (
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <circle cx="60" cy="60" r="50" fill="#E7D2A0" opacity="0.6" />
          <path
            d="M35 70 L52 52 L68 64 L86 38"
            fill="none"
            stroke="var(--forest)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="86" cy="38" r="6" fill="var(--soil)" />
          {/* Sprout emerging */}
          <path d="M60 90 L60 72" stroke="var(--forest)" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M60 76 Q50 68 45 74" fill="none" stroke="var(--forest)" strokeWidth="3" strokeLinecap="round" />
          <path d="M60 72 Q70 64 75 70" fill="none" stroke="var(--forest)" strokeWidth="3" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      titleSw: 'Fuatilia bei kila siku',
      titleEn: 'Track prices every day',
      descSw:
        'Ona bei za mazao yako kwenye masoko makuu ya Kariakoo, Kibaigwa, na soko la kimataifa pamoja na thamani ya fedha.',
      descEn:
        'Monitor crop prices across major hubs like Kariakoo, Kibaigwa, and global exchanges with daily currency conversions.',
      color: 'from-[#C89B3C] to-[#A15C3E]',
      icon: (
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <circle cx="60" cy="60" r="50" fill="#E7D2A0" opacity="0.6" />
          {/* Market bar chart */}
          <rect x="32" y="65" width="10" height="25" rx="3" fill="var(--forest-dark)" opacity="0.7" />
          <rect x="47" y="52" width="10" height="38" rx="3" fill="var(--forest)" />
          <rect x="62" y="42" width="10" height="48" rx="3" fill="var(--forest)" />
          <rect x="77" y="32" width="10" height="58" rx="3" fill="var(--soil)" />
          {/* Trending up arrow */}
          <path d="M 32 55 L 50 42 L 65 48 L 86 24" fill="none" stroke="#E7C273" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="86" cy="24" r="4.5" fill="#E7C273" />
        </svg>
      ),
    },
    {
      titleSw: 'Uza moja kwa moja, salama',
      titleEn: 'Sell direct, safely',
      descSw:
        'Wasiliana na wanunuzi, viwanda vya kusindika na madalali walioidhinishwa wenye uhakika wa malipo kwa bei ya haki.',
      descEn:
        'Connect directly with trusted mills, processing factories, and verified brokers offering guaranteed payment terms.',
      color: 'from-[#8FBF6B] to-[#2C4A3B]',
      icon: (
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <circle cx="60" cy="60" r="50" fill="#E7D2A0" opacity="0.6" />
          {/* Handshake / Partnership motif */}
          <circle cx="42" cy="50" r="8" fill="var(--soil)" />
          <circle cx="78" cy="50" r="8" fill="var(--forest)" />
          <path
            d="M34 78 Q42 64 52 70 L60 76 L68 70 Q78 64 86 78"
            fill="none"
            stroke="var(--forest-dark)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path d="M52 72 Q60 62 68 72" fill="none" stroke="var(--gold)" strokeWidth="3" />
        </svg>
      ),
    },
    {
      titleSw: 'Inafanya kazi hata bila mtandao',
      titleEn: 'Works even without internet',
      descSw:
        'Taarifa zako zote muhimu zinahifadhiwa kwenye simu yako, na unaweza kutumia amri za sauti kwa urahisi ukiwa shambani.',
      descEn:
        'All your crop notes, calendar, and cached market prices remain accessible offline, with hands-free voice assistant.',
      color: 'from-[#3D7A4E] to-[#1D332A]',
      icon: (
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <circle cx="60" cy="60" r="50" fill="#E7D2A0" opacity="0.6" />
          {/* Offline check & mobile device */}
          <rect x="42" y="28" width="36" height="64" rx="8" fill="none" stroke="var(--forest)" strokeWidth="3.5" />
          <circle cx="60" cy="82" r="3" fill="var(--forest)" />
          {/* Offline wireless lightning checkmark */}
          <path d="M50 56 L57 63 L72 47" fill="none" stroke="var(--soil)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
    },
  ];

  const handleNext = () => {
    playKeyTap();
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onFinish();
    }
  };

  const isLast = currentSlide === slides.length - 1;

  return (
    <div id="onboarding-container" className="relative w-full h-full flex flex-col justify-between p-6 bg-[var(--paper)] select-none">
      {/* Top bar with Skip button */}
      <div className="flex items-center justify-between pt-2">
        <span className="text-[11px] font-semibold tracking-wider text-[var(--forest)] uppercase">
          Ardhi Onboarding
        </span>
        <button
          id="onboarding-skip-btn"
          onClick={onFinish}
          className="text-xs font-semibold text-[var(--ink-soft)] hover:text-[var(--ink)] px-2 py-1 transition-colors"
        >
          {isSw ? 'Ruka' : 'Skip'}
        </button>
      </div>

      {/* Main Slide Carousel Area */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-4 my-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 25 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -25 }}
            transition={{ duration: 0.35 }}
            className="flex flex-col items-center"
          >
            {/* Slide Artwork Icon */}
            <div className="w-36 h-36 mb-8 rounded-3xl p-4 flex items-center justify-center">
              {slides[currentSlide].icon}
            </div>

            <h2 className="font-display text-2xl font-bold text-[var(--ink)] mb-3 leading-snug">
              {isSw ? slides[currentSlide].titleSw : slides[currentSlide].titleEn}
            </h2>

            <p className="text-xs md:text-sm text-[var(--ink-soft)] leading-relaxed max-w-[290px]">
              {isSw ? slides[currentSlide].descSw : slides[currentSlide].descEn}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom controls: pagination dots & Next / Finish button */}
      <div className="flex flex-col items-center gap-4 pb-2">
        {/* Pagination Dots */}
        <div className="flex items-center gap-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              id={`onboarding-dot-${idx}`}
              onClick={() => {
                playKeyTap();
                setCurrentSlide(idx);
              }}
              className={`h-2 rounded-full transition-all duration-300 ${
                idx === currentSlide
                  ? 'w-7 bg-[var(--forest)]'
                  : 'w-2 bg-[var(--line)] hover:bg-[var(--ink-soft)]'
              }`}
              aria-label={`Slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Action Button */}
        <button
          id="onboarding-next-btn"
          onClick={handleNext}
          className="w-full py-3.5 px-6 rounded-2xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-semibold text-sm shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-all cursor-pointer"
        >
          <span>
            {isLast
              ? (isSw ? 'Anza Sasa (Kuingia)' : 'Get Started (Sign in)')
              : (isSw ? 'Endelea' : 'Next')}
          </span>
          {isLast ? <Check className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}
