import React from 'react';
import { BotVoiceState, CharacterGender } from '../types';

interface BotAvatarProps {
  gender: CharacterGender;
  state: BotVoiceState;
  size?: number;
  liveVolume?: number;
  onClick?: () => void;
}

export const BotAvatar: React.FC<BotAvatarProps> = ({
  gender,
  state,
  size = 140,
  liveVolume = 0,
  onClick,
}) => {
  const isListening = state === 'listening';
  const isSpeaking = state === 'speaking';
  const isThinking = state === 'thinking';

  // Dynamic glow colors based on state
  const ringColor = isListening
    ? 'rgba(239, 68, 68, 0.85)' // Listening: vibrant red
    : isSpeaking
    ? 'rgba(226, 192, 103, 0.95)' // Speaking: rich gold
    : isThinking
    ? 'rgba(59, 130, 246, 0.85)' // Thinking: electric cyan/blue
    : 'rgba(226, 192, 103, 0.4)'; // Idle: soft gold

  return (
    <div
      onClick={onClick}
      style={{ width: size, height: size }}
      className="relative flex items-center justify-center cursor-pointer select-none group"
    >
      {/* Ripple ring 1 */}
      {(isSpeaking || isListening) && (
        <div
          className={`absolute inset-0 rounded-full animate-ping opacity-30 pointer-events-none`}
          style={{
            backgroundColor: ringColor,
            animationDuration: isListening ? '1.2s' : '1.8s',
          }}
        />
      )}

      {/* Ripple ring 2 (delayed) */}
      {(isSpeaking || isListening) && (
        <div
          className="absolute -inset-3 rounded-full animate-pulse opacity-20 pointer-events-none"
          style={{
            backgroundColor: ringColor,
            animationDuration: '2.2s',
          }}
        />
      )}

      {/* Ambient background blur */}
      <div
        className="absolute inset-1 rounded-full blur-xl transition-all duration-150 opacity-60"
        style={{
          background: isListening
            ? `radial-gradient(circle, rgba(239,68,68,${0.4 + liveVolume * 0.5}) 0%, transparent 70%)`
            : 'radial-gradient(circle, rgba(226,192,103,0.5) 0%, transparent 70%)',
          transform: isListening && liveVolume > 0.05 ? `scale(${1 + liveVolume * 0.25})` : undefined,
        }}
      />

      {/* Main Avatar Container */}
      <div
        className="relative z-10 w-full h-full rounded-full overflow-hidden border-3 transition-transform duration-100 flex items-center justify-center shadow-2xl bg-[#0d1c3a]"
        style={{
          borderColor: isListening ? '#EF4444' : isThinking ? '#38BDF8' : '#E2C067',
          transform: isListening && liveVolume > 0.05 ? `scale(${1 + liveVolume * 0.08})` : undefined,
          boxShadow: isListening
            ? `0 0 ${25 + liveVolume * 45}px rgba(239, 68, 68, ${0.5 + liveVolume * 0.4})`
            : isSpeaking
            ? '0 0 35px rgba(226, 192, 103, 0.7)'
            : '0 0 20px rgba(226, 192, 103, 0.3)',
        }}
      >
        {/* Subtle radial background inside avatar */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#162a52] to-[#070e1c]" />

        {/* Character Illustration SVG */}
        {gender === 'Male' ? (
          // Male Character (Hamza)
          <svg viewBox="0 0 100 100" className="w-[85%] h-[85%] relative z-10">
            <defs>
              <linearGradient id="maleHair" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2c3e50" />
                <stop offset="100%" stopColor="#1a252f" />
              </linearGradient>
              <linearGradient id="maleSkin" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f3c299" />
                <stop offset="100%" stopColor="#e0a370" />
              </linearGradient>
              <linearGradient id="maleShirt" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1e3a8a" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
            </defs>
            {/* Shoulders / Shirt */}
            <path d="M 20 95 Q 50 78 80 95 L 85 100 L 15 100 Z" fill="url(#maleShirt)" />
            <path d="M 42 78 L 50 88 L 58 78 Z" fill="#E2C067" />
            {/* Neck */}
            <rect x="44" y="66" width="12" height="15" rx="3" fill="url(#maleSkin)" />
            {/* Head */}
            <ellipse cx="50" cy="50" rx="20" ry="22" fill="url(#maleSkin)" />
            {/* Ears */}
            <ellipse cx="29" cy="51" rx="4" ry="6" fill="#e0a370" />
            <ellipse cx="71" cy="51" rx="4" ry="6" fill="#e0a370" />
            {/* Modern Hair */}
            <path
              d="M 28 46 C 26 30 38 20 50 20 C 64 20 74 30 72 46 C 68 34 58 32 46 33 C 38 34 32 38 28 46 Z"
              fill="url(#maleHair)"
            />
            {/* Eyebrows */}
            <path d="M 36 43 Q 42 41 46 44" stroke="#1f2937" strokeWidth="2" strokeLinecap="round" fill="none" />
            <path d="M 54 44 Q 58 41 64 43" stroke="#1f2937" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Eyes */}
            <circle cx="41" cy="49" r="3" fill="#1e293b" />
            <circle cx="42" cy="48" r="1" fill="#fff" />
            <circle cx="59" cy="49" r="3" fill="#1e293b" />
            <circle cx="60" cy="48" r="1" fill="#fff" />
            {/* Nose */}
            <path d="M 50 49 L 48 55 L 52 55" stroke="#c48a58" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            {/* Mouth (Animates when speaking) */}
            {isSpeaking ? (
              <ellipse cx="50" cy="62" rx="4.5" ry="3.5" fill="#881337" className="animate-pulse" />
            ) : (
              <path d="M 45 61 Q 50 65 55 61" stroke="#a16207" strokeWidth="2" strokeLinecap="round" fill="none" />
            )}
            {/* Subtle Futuristic Headset Mic */}
            <path d="M 30 52 C 26 62 34 72 44 71" stroke="#E2C067" strokeWidth="1.5" fill="none" strokeLinecap="round" />
            <circle cx="44" cy="71" r="2.5" fill={isListening ? '#ef4444' : '#E2C067'} />
          </svg>
        ) : (
          // Female Character (Ayesha)
          <svg viewBox="0 0 100 100" className="w-[85%] h-[85%] relative z-10">
            <defs>
              <linearGradient id="femaleHair" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3d2314" />
                <stop offset="100%" stopColor="#1a0f08" />
              </linearGradient>
              <linearGradient id="femaleSkin" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#fed7aa" />
                <stop offset="100%" stopColor="#fba76a" />
              </linearGradient>
              <linearGradient id="femaleDress" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#7c2d12" />
                <stop offset="100%" stopColor="#431407" />
              </linearGradient>
            </defs>
            {/* Dress */}
            <path d="M 20 95 Q 50 80 80 95 L 85 100 L 15 100 Z" fill="url(#femaleDress)" />
            {/* Gold Pendant */}
            <circle cx="50" cy="85" r="2.5" fill="#E2C067" />
            {/* Neck */}
            <rect x="45" y="65" width="10" height="15" rx="3" fill="url(#femaleSkin)" />
            {/* Head */}
            <ellipse cx="50" cy="51" rx="19" ry="21" fill="url(#femaleSkin)" />
            {/* Hair Flow */}
            <path
              d="M 27 50 C 24 30 36 18 50 18 C 64 18 76 30 73 50 C 76 65 72 75 70 82 C 67 62 67 40 50 34 C 33 40 33 62 30 82 C 28 75 24 65 27 50 Z"
              fill="url(#femaleHair)"
            />
            {/* Eyes */}
            <circle cx="41" cy="50" r="2.8" fill="#1e293b" />
            <circle cx="42" cy="49" r="1" fill="#fff" />
            <circle cx="59" cy="50" r="2.8" fill="#1e293b" />
            <circle cx="60" cy="49" r="1" fill="#fff" />
            {/* Eyelashes */}
            <path d="M 37 46 Q 41 44 45 47" stroke="#1f2937" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            <path d="M 55 47 Q 59 44 63 46" stroke="#1f2937" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            {/* Soft Blush */}
            <circle cx="37" cy="56" r="3" fill="#f43f5e" opacity="0.3" />
            <circle cx="63" cy="56" r="3" fill="#f43f5e" opacity="0.3" />
            {/* Nose */}
            <path d="M 50 51 L 49 55 L 51 55" stroke="#d97706" strokeWidth="1.2" strokeLinecap="round" fill="none" />
            {/* Mouth */}
            {isSpeaking ? (
              <ellipse cx="50" cy="62" rx="4" ry="3" fill="#be123c" className="animate-pulse" />
            ) : (
              <path d="M 46 61 Q 50 64 54 61" stroke="#e11d48" strokeWidth="1.8" strokeLinecap="round" fill="none" />
            )}
            {/* Headset Mic */}
            <path d="M 31 53 C 27 63 35 72 44 71" stroke="#E2C067" strokeWidth="1.5" fill="none" strokeLinecap="round" />
            <circle cx="44" cy="71" r="2.5" fill={isListening ? '#ef4444' : '#E2C067'} />
          </svg>
        )}

        {/* Ambient Ring overlay */}
        <div className="absolute inset-0 rounded-full border border-white/10 pointer-events-none" />
      </div>

      {/* Floating State Badge */}
      <div
        className="absolute -bottom-2 z-20 px-3 py-1 rounded-full text-xs font-semibold tracking-wider flex items-center gap-1.5 shadow-md border"
        style={{
          backgroundColor: isListening ? '#7F1D1D' : isThinking ? '#0C4A6E' : isSpeaking ? '#78350F' : '#111E38',
          borderColor: isListening ? '#EF4444' : isThinking ? '#38BDF8' : '#E2C067',
          color: isListening ? '#FCA5A5' : isThinking ? '#BAE6FD' : '#E2C067',
        }}
      >
        <span
          className={`w-2 h-2 rounded-full ${
            isListening
              ? 'bg-red-400 animate-ping'
              : isThinking
              ? 'bg-cyan-400 animate-spin'
              : isSpeaking
              ? 'bg-amber-300 animate-pulse'
              : 'bg-emerald-400'
          }`}
        />
        <span>
          {isListening
            ? 'سن رہا ہوں...'
            : isThinking
            ? 'سوچ رہا ہوں...'
            : isSpeaking
            ? 'بول رہا ہوں...'
            : 'آن لائن (Online)'}
        </span>
      </div>
    </div>
  );
};
