import React, { useState, useEffect } from "react";
import {
  X,
  Sparkles,
  Download,
  Copy,
  Check,
  Printer,
  RefreshCw,
  Zap,
  Target,
  Activity,
  Award,
  Shield,
  Star,
  ChevronRight,
  Lightbulb,
  CheckCircle2,
  FileText,
  Share2
} from "lucide-react";
import { Note, InfographicData, InfographicMetric, InfographicStep, InfographicPillar } from "../types";

interface InfographicModalProps {
  note: Note;
  onClose: () => void;
  onInsertIntoNote?: (infographicText: string) => void;
}

export const InfographicModal: React.FC<InfographicModalProps> = ({
  note,
  onClose,
  onInsertIntoNote,
}) => {
  const [loading, setLoading] = useState(true);
  const [infographic, setInfographic] = useState<InfographicData | null>(null);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchInfographic = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch("/api/gemini/infographic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: note.title,
          content: note.content || note.htmlContent || "İçerik bulunamadı.",
        }),
      });

      if (!res.ok) {
        throw new Error("Yapay zeka yanıt veremedi");
      }

      const data: InfographicData = await res.json();
      setInfographic(data);
    } catch (err: any) {
      console.warn("AI generation failed, generating fallback infographic structure", err);
      // Construct an intelligent fallback infographic from note data
      const words = (note.content || "").split(/\s+/).filter(Boolean);
      const lines = (note.content || "").split("\n").filter((l) => l.trim().length > 0);

      const fallback: InfographicData = {
        title: note.title || "Not İnfografiği",
        subtitle: `${note.category} kategorisinde temel çıkarımlar ve aksiyon haritası`,
        quote: lines[0] || "Düşüncelerin somut eylemlere ve net sonuçlara dönüşümü.",
        metrics: [
          { label: "Toplam Kelime", value: `${words.length}`, icon: "activity", color: "teal" },
          { label: "Kategori", value: note.category, icon: "target", color: "blue" },
          { label: "Önem Derecesi", value: note.pinned || note.favorite ? "Yüksek" : "Standart", icon: "zap", color: "amber" },
          { label: "Görev Sayısı", value: `${note.tasks?.length || 0}`, icon: "award", color: "rose" },
        ],
        steps: [
          { stepNumber: 1, title: "Keşif ve Giriş", description: lines.slice(0, 2).join(" ") || "Konunun temel çerçevesi belirlendi.", tag: "Aşama 1" },
          { stepNumber: 2, title: "Analiz ve Geliştirme", description: lines.slice(2, 4).join(" ") || "Detaylar ve alt kavramlar incelendi.", tag: "Aşama 2" },
          { stepNumber: 3, title: "Uygulama ve Sonuç", description: lines.slice(4, 6).join(" ") || "Kalıcı aksiyonlar ve pratik çıktılar sağlandı.", tag: "Aşama 3" },
        ],
        pillars: [
          {
            title: "Anahtar Kavramlar",
            points: note.tags?.length ? note.tags.map((t) => t.replace("#", "")) : ["Odaklanma", "Uygulama", "Gelişim"],
            icon: "star",
            color: "emerald",
          },
          {
            title: "Öne Çıkan Değerler",
            points: (note.tasks || []).map((t) => t.text).slice(0, 3).length > 0 ? (note.tasks || []).map((t) => t.text).slice(0, 3) : ["Verimlilik", "Sürdürülebilirlik"],
            icon: "shield",
            color: "blue",
          },
        ],
        actionItems: (note.tasks || []).map((t) => t.text).length > 0
          ? (note.tasks || []).map((t) => t.text)
          : [
              "Notun anahtar noktalarını çalışma kartı olarak kaydet",
              "İş takvimine veya haftalık plana dahil et",
              "İlgili bölüme ekleyip düzenli gözden geçir",
            ],
      };
      setInfographic(fallback);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInfographic();
  }, [note.id]);

  const handleCopyText = () => {
    if (!infographic) return;
    const text = `📊 İNFOGRAFİK ÖZET: ${infographic.title}\n${infographic.subtitle}\n\n💡 Ana Fikir: "${infographic.quote}"\n\n📈 METRİKLER:\n${infographic.metrics.map((m) => `• ${m.label}: ${m.value}`).join("\n")}\n\n🔄 AŞAMALAR:\n${infographic.steps.map((s) => `${s.stepNumber}. ${s.title}: ${s.description}`).join("\n")}\n\n✅ AKSİYONLAR:\n${infographic.actionItems.map((a) => `[ ] ${a}`).join("\n")}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const renderMetricIcon = (iconName?: string) => {
    switch (iconName) {
      case "zap":
        return <Zap className="w-5 h-5 text-amber-500" />;
      case "target":
        return <Target className="w-5 h-5 text-rose-500" />;
      case "award":
        return <Award className="w-5 h-5 text-emerald-500" />;
      case "shield":
        return <Shield className="w-5 h-5 text-blue-500" />;
      default:
        return <Activity className="w-5 h-5 text-teal-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-md overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-teal-500 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>İnfografik Özet Görünümü</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-semibold">
                  AI Görselleştirici
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Not içeriğinin yüksek etkili grafiksel ve maddesel sunumu
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchInfographic}
              disabled={loading}
              title="Yeniden Analiz Et ve Üret"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={handleCopyText}
              title="Özeti Kopyala"
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Kopyalandı" : "Metni Kopyala"}</span>
            </button>
            <button
              onClick={handlePrint}
              title="Yazdır veya PDF Kaydet"
              className="px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Yazdır / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Infographic Main Canvas */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-100/60 dark:bg-slate-950/60">
          {loading ? (
            <div className="py-24 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 mx-auto flex items-center justify-center animate-bounce">
                <Sparkles className="w-7 h-7" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-800 dark:text-slate-200">
                  İnfografik Özet Oluşturuluyor...
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                  Yapay zeka nottaki temel metrikleri, aşamaları ve içgörüleri grafiksel bloklara ayrıştırıyor.
                </p>
              </div>
            </div>
          ) : infographic ? (
            <div className="space-y-6 max-w-3xl mx-auto bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl shadow-lg border border-slate-200 dark:border-slate-800">
              {/* 1. Hero Header Banner */}
              <div className="relative overflow-hidden p-6 rounded-2xl bg-gradient-to-r from-teal-700 via-emerald-600 to-teal-800 text-white shadow-md">
                <div className="relative z-10 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-xs tracking-wider">
                      {note.category || "Genel"}
                    </span>
                    <span className="text-[11px] text-white/80">
                      {new Date(note.updatedAt).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" })}
                    </span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                    {infographic.title}
                  </h1>
                  <p className="text-sm text-teal-100 leading-relaxed max-w-2xl">
                    {infographic.subtitle}
                  </p>
                </div>
              </div>

              {/* 2. Key Quote / Core Essence */}
              {infographic.quote && (
                <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 shrink-0">
                    <Lightbulb className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
                      Temel İçgörü & Ana Fikir
                    </span>
                    <p className="text-sm font-semibold italic text-slate-800 dark:text-slate-200 mt-0.5 leading-snug">
                      "{infographic.quote}"
                    </p>
                  </div>
                </div>
              )}

              {/* 3. Metrics Grid */}
              {infographic.metrics?.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-teal-500" />
                    <span>Temel Metrikler ve Sayısal Göstergeler</span>
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {infographic.metrics.map((m, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-800 flex flex-col items-center text-center shadow-xs"
                      >
                        <div className="mb-2 p-2 rounded-xl bg-white dark:bg-slate-700 shadow-xs">
                          {renderMetricIcon(m.icon)}
                        </div>
                        <span className="text-xl font-extrabold text-slate-900 dark:text-white">
                          {m.value}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                          {m.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Chronological Step-by-Step Flow */}
              {infographic.steps?.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-blue-500" />
                    <span>Süreç ve Uygulama Aşamaları</span>
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {infographic.steps.map((step, idx) => (
                      <div
                        key={idx}
                        className="relative p-4 rounded-2xl bg-gradient-to-b from-blue-50/50 to-white dark:from-blue-950/20 dark:to-slate-900 border border-blue-100 dark:border-blue-900/40 space-y-1.5 shadow-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
                            {step.stepNumber}
                          </span>
                          {step.tag && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                              {step.tag}
                            </span>
                          )}
                        </div>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-1">
                          {step.title}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                          {step.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 5. Core Pillars & Concept Breakdown */}
              {infographic.pillars?.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Temel Yapı Taşları ve Sütunlar</span>
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {infographic.pillars.map((pillar, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs"
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                            <Star className="w-4 h-4" />
                          </div>
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                            {pillar.title}
                          </h4>
                        </div>
                        <ul className="space-y-1.5 pt-1">
                          {pillar.points.map((p, pIdx) => (
                            <li key={pIdx} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                              <span>{p}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 6. Action Checklist */}
              {infographic.actionItems?.length > 0 && (
                <div className="p-5 rounded-2xl bg-slate-900 text-white dark:bg-slate-800 space-y-3 shadow-md">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Uygulanacak Aksiyonlar ve Çıkarımlar</span>
                  </h3>
                  <div className="space-y-2">
                    {infographic.actionItems.map((action, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                        <span className="text-teal-400 font-bold">✓</span>
                        <span className="leading-relaxed">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Card Footer branding */}
              <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500 border-t border-slate-200 dark:border-slate-800">
                <span>NoteFlow Akıllı İnfografik Modülü</span>
                <span>{new Date().toLocaleString("tr-TR")}</span>
              </div>
            </div>
          ) : null}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between print:hidden">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {infographic ? "İnfografik hazır. Kopyalayabilir veya yazdırabilirsiniz." : ""}
          </div>
          <div className="flex items-center gap-2">
            {onInsertIntoNote && infographic && (
              <button
                onClick={() => {
                  const summaryText = `\n\n--- 📊 İNFOGRAFİK ÖZET ---\n${infographic.title}: "${infographic.quote || ''}"\n${infographic.actionItems.map((a) => `• ${a}`).join('\n')}`;
                  onInsertIntoNote(summaryText);
                  onClose();
                }}
                className="px-4 py-2 rounded-xl border border-teal-500 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-xs font-bold transition-colors"
              >
                Notun Sonuna Ekle
              </button>
            )}
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white text-xs font-bold transition-colors"
            >
              Kapat
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
