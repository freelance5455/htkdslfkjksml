import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ShoppingBag, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  Phone, 
  CreditCard, 
  Building2, 
  Info,
  Clock,
  Sparkles,
  Download,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PaymentMethod, Order } from '../types';

interface CheckoutPageProps {
  onBack: () => void;
  onSuccessOrder: (order: Order) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onBack, onSuccessOrder }) => {
  const { 
    cart, 
    checkoutItem, 
    cartSubtotal, 
    customerData, 
    setCustomerData, 
    processPayment,
    products
  } = useStore();

  const items = checkoutItem 
    ? [{ product: checkoutItem, quantity: 1 }] 
    : cart;

  const totalAmount = checkoutItem 
    ? checkoutItem.price 
    : cartSubtotal;

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('mpesa');
  const [phoneNumber, setPhoneNumber] = useState<string>(customerData.phone || '841634528');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState<string>('');
  const [validationError, setValidationError] = useState<string>('');

  // Card specific state
  const [cardNumber, setCardNumber] = useState('4111 2222 3333 4444');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvv, setCardCvv] = useState('821');

  // Completed order view state
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  if (items.length === 0 && !completedOrder) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Nenhum item selecionado</h2>
        <p className="text-sm text-slate-500">
          O teu carrinho está vazio. Escolhe um produto ou plano para continuar com o checkout.
        </p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg transition-colors inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Catálogo</span>
        </button>
      </div>
    );
  }

  // Handle final checkout submit
  const handleFinalize = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    if (!customerData.fullName.trim()) {
      setValidationError('Por favor, digite o seu nome completo.');
      return;
    }
    if (!customerData.email.trim() || !customerData.email.includes('@')) {
      setValidationError('Por favor, informe um endereço de email válido.');
      return;
    }

    if ((paymentMethod === 'mpesa' || paymentMethod === 'emola') && !phoneNumber.trim()) {
      setValidationError('Por favor, insira o número de telemóvel para autorização.');
      return;
    }

    setIsProcessing(true);

    if (paymentMethod === 'mpesa') {
      setProcessStep('A contactar servidor M-Pesa Vodacom Moçambique...');
      await new Promise(r => setTimeout(r, 900));
      setProcessStep(`Pedido USSD STK Push enviado para +258 ${phoneNumber}. Confirma o PIN no telemóvel...`);
      await new Promise(r => setTimeout(r, 1400));
      setProcessStep('Transação autorizada com sucesso pelo M-Pesa!');
      await new Promise(r => setTimeout(r, 700));
    } else if (paymentMethod === 'emola') {
      setProcessStep('A validar carteira móvel e-Mola Movitel...');
      await new Promise(r => setTimeout(r, 1100));
      setProcessStep('Débito efetuado com sucesso!');
      await new Promise(r => setTimeout(r, 600));
    } else if (paymentMethod === 'card') {
      setProcessStep('A validar credenciais Visa/Mastercard com 3D Secure...');
      await new Promise(r => setTimeout(r, 1200));
      setProcessStep('Pagamento aprovado pelo emissor bancário!');
      await new Promise(r => setTimeout(r, 600));
    } else {
      setProcessStep('A gerar referência bancária Ponto 24...');
      await new Promise(r => setTimeout(r, 900));
    }

    const payloadDetail = paymentMethod === 'card' 
      ? `Cartão final ${cardNumber.slice(-4)}`
      : `+258 ${phoneNumber}`;

    await processPayment(paymentMethod, payloadDetail, (newOrder) => {
      setCompletedOrder(newOrder);
      setIsProcessing(false);
      onSuccessOrder(newOrder);
    });
  };

  // If completed, show invoice receipt
  if (completedOrder) {
    return (
      <div className="max-w-2xl mx-auto py-8 px-4">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden p-6 sm:p-8 space-y-6">
          
          <div className="text-center space-y-2">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">
              Pagamento Confirmado!
            </h2>
            <p className="text-xs text-slate-500 font-mono">
              Código de Transação: {completedOrder.transactionRef}
            </p>
          </div>

          {/* Receipt Breakdown */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3 text-xs">
            <div className="flex justify-between items-center text-slate-600">
              <span>Cliente:</span>
              <span className="font-semibold text-slate-900">{completedOrder.customer.fullName}</span>
            </div>
            <div className="flex justify-between items-center text-slate-600">
              <span>Email:</span>
              <span className="font-mono text-slate-900">{completedOrder.customer.email}</span>
            </div>
            <div className="flex justify-between items-center text-slate-600">
              <span>Método:</span>
              <span className="font-semibold text-emerald-700 uppercase">{completedOrder.paymentMethod}</span>
            </div>
            <div className="flex justify-between items-center text-slate-600">
              <span>Total Pago:</span>
              <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                Mt {completedOrder.total.toLocaleString('pt-MZ')},00 MZN
              </span>
            </div>
          </div>

          {/* Items Purchased & Real-time stock confirmation */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Itens Adquiridos & Baixa de Estoque Realizada
            </h3>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {completedOrder.items.map((item, idx) => {
                const liveProd = products.find(p => p.id === item.productId);
                return (
                  <div key={idx} className="p-3.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{item.productName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span>Qtd: {item.quantity}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400">SKU: {item.sku}</span>
                        <span>·</span>
                        <span className="text-emerald-700 font-medium">
                          Estoque Atual: {liveProd ? `${liveProd.stock} un.` : 'Atualizado'}
                        </span>
                      </div>
                    </div>
                    <div className="font-mono font-bold text-slate-900 tabular-nums">
                      Mt {(item.price * item.quantity).toLocaleString('pt-MZ')},00
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Instant Access Download Buttons */}
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Acesso Imediato ao Produto Digital</span>
            </div>
            <p className="text-xs text-emerald-800 leading-relaxed">
              Os teus links de download e credenciais foram ativados e enviados para o email <strong>{completedOrder.customer.email}</strong>.
            </p>
            <div className="pt-2 flex flex-wrap gap-2">
              <a
                href="#download"
                onClick={(e) => {
                  e.preventDefault();
                  alert(`Download do produto iniciado com sucesso! Licença vinculada ao email: ${completedOrder.customer.email}`);
                }}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar Ficheiros Agora (PDF / Pack)</span>
              </a>
              <button
                onClick={onBack}
                className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold border border-slate-300 transition-colors"
              >
                Voltar à Loja
              </button>
            </div>
          </div>

        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-4 sm:py-8 px-3 sm:px-4">
      
      {/* Top Bar for Checkout (matching checkout.escalepay.com screenshot) */}
      <div className="mb-4 flex items-center justify-between">
        <button
          onClick={onBack}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar</span>
        </button>
        <span className="text-[11px] font-mono text-slate-400">
          checkout.escalepay.com/815391
        </span>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
        
        {/* Header Block with Logo & Total (Exact layout of screenshot 4 & 5) */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded-lg bg-purple-50 border border-purple-200 text-purple-700 font-bold text-xs tracking-tight flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-600 inline-block" />
              <span>EscaleBuilder</span>
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-700 tabular-nums">
            Mt {totalAmount.toLocaleString('pt-MZ')},00 MZN
          </div>
        </div>

        {/* Pricing Summary (Subtotal, Taxas: Grátis, Total) */}
        <div className="p-6 bg-slate-50/70 border-b border-slate-100 space-y-2 text-xs">
          <div className="flex justify-between items-center text-slate-600">
            <span>Subtotal:</span>
            <span className="font-mono text-slate-800 tabular-nums">
              Mt {totalAmount.toLocaleString('pt-MZ')},00 MZN
            </span>
          </div>
          <div className="flex justify-between items-center text-slate-600">
            <span>Taxas:</span>
            <span className="font-semibold text-emerald-600">Grátis</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-slate-200 text-sm font-bold text-slate-900">
            <span>Total:</span>
            <span className="font-mono text-emerald-700 tabular-nums">
              Mt {totalAmount.toLocaleString('pt-MZ')},00 MZN
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleFinalize} className="p-6 space-y-5">
          
          {/* Validation Error banner */}
          {validationError && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Nome completo */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Nome completo <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={customerData.fullName}
                onChange={(e) => setCustomerData(prev => ({ ...prev, fullName: e.target.value }))}
                placeholder="Nome completo"
                className="w-full px-3.5 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Email <span className="text-rose-500">*</span>
            </label>
            <input
              type="email"
              required
              value={customerData.email}
              onChange={(e) => setCustomerData(prev => ({ ...prev, email: e.target.value }))}
              placeholder="seu@email.com"
              className="w-full px-3.5 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
            />
          </div>

          {/* WhatsApp (opcional) com DDI Moçambique +258 */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              WhatsApp <span className="text-slate-400 font-normal">(opcional)</span>
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-300 focus-within:ring-2 focus-within:ring-emerald-500 focus-within:border-transparent">
              <div className="px-3 py-2.5 bg-slate-100 text-slate-700 text-xs font-semibold border-r border-slate-300 flex items-center">
                +258
              </div>
              <input
                type="tel"
                value={customerData.whatsapp}
                onChange={(e) => setCustomerData(prev => ({ ...prev, whatsapp: e.target.value }))}
                placeholder="84 123 4567"
                className="flex-1 px-3.5 py-2.5 text-xs bg-white text-slate-900 focus:outline-none"
              />
            </div>
          </div>

          {/* Selecione o método de pagamento * */}
          <div className="space-y-3 pt-2">
            <label className="block text-xs font-semibold text-slate-700">
              Selecione o método de pagamento <span className="text-rose-500">*</span>
            </label>

            {/* Informative Blue Callout Box matching screenshots */}
            <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-900 text-xs flex gap-2.5 leading-relaxed">
              <Info className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
              <div>
                Os métodos de pagamento aparecem automaticamente para clientes localizados em Moçambique. O teu produto está activo — nada está avariado.
              </div>
            </div>

            {/* Payment Method Selector Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              
              {/* M-Pesa */}
              <button
                type="button"
                onClick={() => setPaymentMethod('mpesa')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                  paymentMethod === 'mpesa'
                    ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-red-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 shadow-xs">
                  M
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">M-Pesa</div>
                  <div className="text-[10px] text-slate-500">Vodacom MZ</div>
                </div>
              </button>

              {/* e-Mola */}
              <button
                type="button"
                onClick={() => setPaymentMethod('emola')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                  paymentMethod === 'emola'
                    ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-orange-500 text-white font-bold text-[11px] flex items-center justify-center shrink-0 shadow-xs">
                  e
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">e-Mola</div>
                  <div className="text-[10px] text-slate-500">Movitel MZ</div>
                </div>
              </button>

              {/* Cartão Visa/Mastercard */}
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                  paymentMethod === 'card'
                    ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white font-bold text-[11px] flex items-center justify-center shrink-0 shadow-xs">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Cartão Bancário</div>
                  <div className="text-[10px] text-slate-500">Visa / Mastercard</div>
                </div>
              </button>

              {/* Ponto 24 / Referência */}
              <button
                type="button"
                onClick={() => setPaymentMethod('bank_reference')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                  paymentMethod === 'bank_reference'
                    ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 shadow-xs">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Ponto 24</div>
                  <div className="text-[10px] text-slate-500">BIM / BCI / Standard</div>
                </div>
              </button>

            </div>

            {/* Mobile Money Prompt Input */}
            {(paymentMethod === 'mpesa' || paymentMethod === 'emola') && (
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    Número de Telemóvel {paymentMethod === 'mpesa' ? 'Vodacom (84/85)' : 'Movitel (86/87)'}
                  </span>
                </div>
                <div className="flex rounded-lg overflow-hidden border border-slate-300 bg-white">
                  <span className="px-2.5 py-2 text-xs font-semibold text-slate-600 bg-slate-100 border-r border-slate-300">
                    +258
                  </span>
                  <input
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder={paymentMethod === 'mpesa' ? '84 163 4528' : '86 123 4567'}
                    className="flex-1 px-3 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-500">
                  Ao clicar em finalizar, receberás um pedido de PIN no telemóvel para autorizar o valor de Mt {totalAmount.toLocaleString('pt-MZ')},00 MZN.
                </p>
              </div>
            )}

            {/* Card Inputs */}
            {paymentMethod === 'card' && (
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600">Número do Cartão</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600">Validade</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600">CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Bank reference Info */}
            {paymentMethod === 'bank_reference' && (
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Entidade:</span>
                  <span className="font-mono font-bold text-slate-900">00142</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Referência:</span>
                  <span className="font-mono font-bold text-slate-900">815 391 024</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Montante:</span>
                  <span className="font-mono font-bold text-slate-900">Mt {totalAmount.toLocaleString('pt-MZ')},00 MZN</span>
                </div>
              </div>
            )}
          </div>

          {/* Processing status spinner */}
          {isProcessing && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center gap-3 animate-pulse">
              <div className="w-5 h-5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin shrink-0" />
              <div className="font-medium">{processStep}</div>
            </div>
          )}

          {/* Submit Button (matching screenshot 4 & 5: slate button with shopping cart icon) */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3.5 px-4 bg-slate-600 hover:bg-slate-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>
              {isProcessing 
                ? 'Processando transação...' 
                : `Finalizar Compra - Mt ${totalAmount.toLocaleString('pt-MZ')},00 MZN`}
            </span>
          </button>

          {/* Security & Delivery Badges */}
          <div className="pt-2 flex items-center justify-center gap-4 text-xs text-slate-500 font-medium">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Compra 100% segura</span>
            </div>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-emerald-600" />
              <span>Entrega imediata</span>
            </div>
          </div>

          {/* Legal Terms Box matching bottom of screenshot 4 & 5 */}
          <div className="p-3 bg-sky-50/60 border border-sky-200/60 rounded-xl text-center text-[11px] text-slate-600">
            Ao clicar em <span className="font-semibold text-slate-800">"Finalizar Compra"</span>, você concorda com nossos{' '}
            <a href="#termos" className="text-sky-700 underline hover:text-sky-800">Termos de Uso</a> e{' '}
            <a href="#privacidade" className="text-sky-700 underline hover:text-sky-800">Política de Privacidade</a>.
          </div>

        </form>

      </div>
    </div>
  );
};
