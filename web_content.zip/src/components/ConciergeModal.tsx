import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Send, Sparkles, RefreshCw, MessageSquare, Bot, User, Utensils } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { ChatMessage, MenuCategory } from "../types";

interface ConciergeModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: MenuCategory[];
}

export const ConciergeModal: React.FC<ConciergeModalProps> = ({
  isOpen,
  onClose,
  categories,
}) => {
  const [role, setRole] = useState<"host" | "nutritionist" | "quick">("host");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "initial-1",
      role: "assistant",
      text:
        "Welcome to Kaloreez in Visakhapatnam. I am your table concierge. How may I assist your dining choices or answer questions about our wholesome kitchen today?",
      content:
        "Welcome to Kaloreez in Visakhapatnam. I am your table concierge. How may I assist your dining choices or answer questions about our wholesome kitchen today?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (userPromptText?: string) => {
    const textToSend = userPromptText || inputMessage.trim();
    if (!textToSend || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      text: textToSend,
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage("");
    setIsLoading(true);

    try {
      // Build conversation history for the endpoint
      const history = messages.map((m) => ({
        role: m.role,
        parts: [{ text: m.text || m.content || "" }],
      }));

      // Gather verified menu context to ground the assistant
      const menuContext = categories
        .map((cat) => {
          const dishSummaries = cat.dishes
            .map(
              (d) =>
                `${d.name} (${d.price || "N/A"}): ${d.description}. Nutrition: ${d.calories || "N/A"}, Protein: ${d.protein || "N/A"}, Carbs: ${d.carbs || "N/A"}, Fat: ${d.fat || "N/A"}. Ingredients: ${d.ingredients?.join(", ") || "N/A"}`
            )
            .join("; ");
          return `Category "${cat.name}": ${dishSummaries}`;
        })
        .join("\n");

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          role,
          conversationHistory: history,
          menuContext,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to communicate with Kaloreez Concierge.");
      }

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        text: data.reply,
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: `error-${Date.now()}`,
        role: "assistant",
        text:
          "I apologize, our table system encountered a momentary pause. Please rest assured all our dishes are prepared fresh in Daspalla Hills. May I answer anything else?",
        content:
          "I apologize, our table system encountered a momentary pause. Please rest assured all our dishes are prepared fresh in Daspalla Hills. May I answer anything else?",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRoleChange = (newRole: "host" | "nutritionist" | "quick") => {
    setRole(newRole);
    let introText = "";
    if (newRole === "nutritionist") {
      introText =
        "Greetings. As the Kaloreez Nutritionist, I can guide you through our macronutrient splits, seed oil alternatives, diabetic-friendly dishes, and protein pairings.";
    } else if (newRole === "quick") {
      introText =
        "Quick Assistant ready. Need dish prices, opening hours, or fast directions to our eatery in Daspalla Hills?";
    } else {
      introText =
        "Welcome to Kaloreez. I am your dining host. How may I introduce you to our eatery atmosphere or philosophy?";
    }

    setMessages([
      {
        id: `role-intro-${Date.now()}`,
        role: "assistant",
        text: introText,
        content: introText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
  };

  const SUGGESTIONS = [
    "What are your highest-protein dishes?",
    "Are dishes cooked in seed oils?",
    "Tell me about the Araku Valley coffee",
    "Recommend a light breakfast in Vizag",
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[115] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#17201C]/75 backdrop-blur-xs"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          className="relative w-full max-w-2xl bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame overflow-hidden z-10 my-auto shadow-2xl flex flex-col h-[650px] max-h-[92vh]"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-[#D8D0C2] flex items-center justify-between bg-[#F4F0E7]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#17201C] text-[#F4F0E7] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-[#9BAF82]" />
              </div>
              <div>
                <h3 className="font-serif text-xl text-[#17201C] leading-none">
                  Kaloreez Table Concierge
                </h3>
                <span className="text-[10px] uppercase font-sans tracking-widest text-[#17201C]/60 mt-0.5 block">
                  Grounding: Verified Eatery Menu & Kitchen Ledger
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/80 border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Role Selector Tabs */}
          <div className="px-6 py-2.5 bg-[#FDFBF7] border-b border-[#D8D0C2]/60 flex items-center justify-between text-xs">
            <span className="text-[11px] uppercase tracking-wider text-[#17201C]/50 font-semibold">
              Advisory Role:
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleRoleChange("host")}
                className={`px-3 py-1 rounded-full text-xs transition-colors cursor-pointer ${
                  role === "host"
                    ? "bg-[#17201C] text-[#F4F0E7] font-medium"
                    : "text-[#17201C]/70 hover:text-[#17201C] bg-[#F4F0E7]"
                }`}
              >
                Dining Host
              </button>
              <button
                type="button"
                onClick={() => handleRoleChange("nutritionist")}
                className={`px-3 py-1 rounded-full text-xs transition-colors cursor-pointer ${
                  role === "nutritionist"
                    ? "bg-[#17201C] text-[#F4F0E7] font-medium"
                    : "text-[#17201C]/70 hover:text-[#17201C] bg-[#F4F0E7]"
                }`}
              >
                Nutritionist
              </button>
              <button
                type="button"
                onClick={() => handleRoleChange("quick")}
                className={`px-3 py-1 rounded-full text-xs transition-colors cursor-pointer ${
                  role === "quick"
                    ? "bg-[#17201C] text-[#F4F0E7] font-medium"
                    : "text-[#17201C]/70 hover:text-[#17201C] bg-[#F4F0E7]"
                }`}
              >
                Quick Info
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-grow p-6 overflow-y-auto space-y-4 bg-[#FDFBF7]">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-3 ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {m.role === "assistant" && (
                  <div className="w-7 h-7 rounded-full bg-[#17201C] text-[#9BAF82] flex items-center justify-center flex-shrink-0 mt-1">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] rounded-sm p-4 text-xs sm:text-sm font-sans leading-relaxed ${
                    m.role === "user"
                      ? "bg-[#17201C] text-[#F4F0E7] rounded-tr-none"
                      : "bg-[#F4F0E7] text-[#17201C] border border-[#D8D0C2]/80 rounded-tl-none"
                  }`}
                >
                  <div className="markdown-body">
                    <ReactMarkdown>{m.text || m.content || ""}</ReactMarkdown>
                  </div>
                  <div
                    className={`text-[10px] mt-2 font-mono ${
                      m.role === "user" ? "text-[#F4F0E7]/60 text-right" : "text-[#17201C]/40"
                    }`}
                  >
                    {m.timestamp}
                  </div>
                </div>
                {m.role === "user" && (
                  <div className="w-7 h-7 rounded-full bg-[#9BAF82] text-[#17201C] flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-3 text-xs text-[#17201C]/60 font-sans">
                <div className="w-7 h-7 rounded-full bg-[#17201C] text-[#9BAF82] flex items-center justify-center">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                </div>
                <span>Consulting kitchen ledger and recipes...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Preset Prompts Chips */}
          <div className="px-6 py-2 bg-[#F4F0E7]/60 border-t border-[#D8D0C2]/50 flex items-center gap-2 overflow-x-auto scrollbar-none">
            {SUGGESTIONS.map((s, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(s)}
                className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-full bg-white border border-[#D8D0C2] text-[#17201C]/80 hover:border-[#17201C] hover:text-[#17201C] transition-colors cursor-pointer"
              >
                {s}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-4 border-t border-[#D8D0C2] bg-[#FDFBF7] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask about dishes, nutrition, cold oils, or reservations..."
              className="flex-grow px-4 py-2.5 rounded-full bg-white border border-[#D8D0C2] text-xs font-sans text-[#17201C] placeholder:text-[#17201C]/40 focus:outline-none focus:border-[#9BAF82]"
            />
            <button
              type="submit"
              disabled={isLoading || !inputMessage.trim()}
              className="w-10 h-10 rounded-full bg-[#17201C] text-[#F4F0E7] flex items-center justify-center hover:bg-[#9BAF82] hover:text-[#17201C] disabled:opacity-40 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
