import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Heart, Calendar, MapPin, Ticket, Sparkles } from 'lucide-react';
import { EventItem } from '../types';
import { SearchBar } from './ui/SearchBar';
import { EmptyState } from './ui/EmptyState';
import { EventDetailsModal } from './EventDetailsModal';

export const EventListingsPage: React.FC = () => {
  const {
    events,
    searchQuery,
    setSearchQuery,
    openPurchaseModal,
    isFavorite,
    toggleFavorite,
    formatKsh,
  } = useApp();

  const [inspectingEvent, setInspectingEvent] = useState<EventItem | null>(null);

  // Clean direct search discovery across titles, venues, descriptions, and hosts
  const filteredEvents = useMemo(() => {
    if (!searchQuery.trim()) return events;
    const q = searchQuery.toLowerCase().trim();
    return events.filter((event) => {
      return (
        event.title.toLowerCase().includes(q) ||
        event.subtitle.toLowerCase().includes(q) ||
        event.venue.toLowerCase().includes(q) ||
        event.city.toLowerCase().includes(q) ||
        event.description.toLowerCase().includes(q) ||
        (event.organizer && event.organizer.toLowerCase().includes(q)) ||
        (event.hostName && event.hostName.toLowerCase().includes(q))
      );
    });
  }, [events, searchQuery]);

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-24 pb-28 transition-colors">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 space-y-8">
        {/* Header with Title and Search Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1f2229]">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#9496a1] block">
              Eventra Catalog
            </span>
            <div className="flex items-center gap-2.5 mt-0.5">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#f4f4f6]">
                All Live Experiences
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-[#17191f] border border-[#1f2229] text-[#9496a1] text-xs font-bold font-mono">
                {filteredEvents.length}
              </span>
            </div>
          </div>

          {/* Unified Search Bar */}
          <div className="w-full sm:w-80">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Search experiences..."
              resultCount={filteredEvents.length}
            />
          </div>
        </div>

        {/* Listings Grid */}
        {filteredEvents.length === 0 ? (
          <EmptyState
            icon={<Calendar className="w-6 h-6 text-[#9496a1]" />}
            title="No events found"
            description={`We couldn't find any live experiences matching "${searchQuery}". Try a different keyword.`}
            actionText="Clear Search"
            onAction={() => setSearchQuery('')}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((evt) => {
              const isFav = isFavorite(evt.id);
              const price = evt.personalPrice || evt.price;
              return (
                <div
                  key={evt.id}
                  className="group rounded-3xl bg-[#111317] border border-[#1f2229] hover:border-emerald-500/40 transition-all flex flex-col overflow-hidden shadow-xs"
                >
                  {/* Event Cover Image */}
                  <div
                    className="relative aspect-16/10 w-full overflow-hidden bg-[#17191f] cursor-pointer"
                    onClick={() => setInspectingEvent(evt)}
                  >
                    <img
                      src={evt.image}
                      alt={evt.title}
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#111317] via-transparent to-transparent" />

                    {/* Category Label */}
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-[#111317]/90 border border-[#1f2229] text-[10px] font-bold uppercase tracking-wider text-[#f4f4f6]">
                      {evt.categoryLabel || evt.category}
                    </span>

                    {/* Favorite Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(evt.id);
                      }}
                      className={`absolute top-3 right-3 w-8 h-8 rounded-full border border-[#1f2229] flex items-center justify-center transition-all cursor-pointer ${
                        isFav
                          ? 'bg-red-500 text-white border-red-500'
                          : 'bg-[#111317]/80 text-[#9496a1] hover:text-[#f4f4f6]'
                      }`}
                      aria-label="Save to favorites"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                    </button>

                    {/* Price Badge */}
                    <div className="absolute bottom-3 left-3 text-white">
                      <span className="text-[10px] uppercase font-bold text-[#9496a1] block">From</span>
                      <span className="text-sm font-extrabold font-mono text-emerald-400">
                        {formatKsh(price)}
                      </span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
                        <Calendar className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{evt.date}</span>
                      </div>

                      <h3
                        onClick={() => setInspectingEvent(evt)}
                        className="text-sm sm:text-base font-bold text-[#f4f4f6] leading-snug hover:text-emerald-400 transition-colors cursor-pointer line-clamp-2"
                      >
                        {evt.title}
                      </h3>

                      <div className="flex items-center gap-1 text-[11px] text-[#9496a1]">
                        <MapPin className="w-3 h-3 shrink-0 text-[#646875]" />
                        <span className="truncate">{evt.venue} · {evt.city}</span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-2 border-t border-[#1f2229] flex items-center justify-between gap-2">
                      <button
                        onClick={() => setInspectingEvent(evt)}
                        className="text-xs font-semibold text-[#9496a1] hover:text-[#f4f4f6] cursor-pointer transition-colors"
                      >
                        View Details
                      </button>

                      <button
                        onClick={() => openPurchaseModal(evt)}
                        className="py-1.5 px-3.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer shadow-xs flex items-center gap-1"
                      >
                        <Ticket className="w-3 h-3" />
                        <span>Book</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Event Details Modal */}
      <EventDetailsModal
        event={inspectingEvent}
        onClose={() => setInspectingEvent(null)}
        onBookNow={(evt) => openPurchaseModal(evt)}
      />
    </div>
  );
};
