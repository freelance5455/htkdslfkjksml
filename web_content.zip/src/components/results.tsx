"use client";

import { useState } from "react";
import { CopyButton, Pill, Spinner } from "./ui";
import type { ToolId } from "@/lib/ai/tools";
import type {
  AnalysisOutput,
  CalendarOutput,
  CaptionsOutput,
  HashtagsOutput,
  HooksOutput,
  IdeasOutput,
  ScriptOutput,
  ThumbnailOutput,
  TitlesOutput,
  ToolOutput,
} from "@/lib/ai/types";
import { apiPost } from "@/lib/client/api";

export function outputToText(tool: ToolId, output: ToolOutput): string {
  switch (tool) {
    case "titles":
      return (output as TitlesOutput).variants.join("\n");
    case "captions":
      return (output as CaptionsOutput).variants.join("\n");
    case "hooks":
      return (output as HooksOutput).variants.map((v) => `${v.style.replace(/_/g, " ")}: ${v.text}`).join("\n");
    case "scripts": {
      const o = output as ScriptOutput;
      return [o.title, ...o.sections.map((s) => `${s.label}\n${s.text}`), o.cta && `CTA: ${o.cta}`]
        .filter(Boolean)
        .join("\n\n");
    }
    case "hashtags":
      return (output as HashtagsOutput).copyAll;
    case "thumbnail":
      return (output as ThumbnailOutput).variants.map((v) => `${v.text}${v.pairing ? ` — ${v.pairing}` : ""}`).join("\n");
    case "ideas": {
      const o = output as IdeasOutput;
      return o.ideas
        .map((i) => `${i.title}\n${[i.angle, i.format].filter(Boolean).join(" • ")}\n${i.hook}`)
        .join("\n\n");
    }
    case "calendar": {
      const o = output as CalendarOutput;
      return o.days.map((d) => `Day ${d.day}: ${d.topic}\n${d.platform} • ${d.contentType} • ${d.postTime}`).join("\n\n");
    }
    case "analyze": {
      const o = output as AnalysisOutput;
      return [
        `Score: ${o.score}/100`,
        o.summary,
        `Strengths:\n- ${o.strengths.join("\n- ")}`,
        `Weaknesses:\n- ${o.weaknesses.join("\n- ")}`,
        o.clarity.length ? `Clarity:\n- ${o.clarity.join("\n- ")}` : "",
        o.engagement.length ? `Engagement:\n- ${o.engagement.join("\n- ")}` : "",
        o.alternatives.length ? `Alternatives:\n- ${o.alternatives.join("\n- ")}` : "",
      ]
        .filter(Boolean)
        .join("\n\n");
    }
    default:
      return JSON.stringify(output, null, 2);
  }
}

function SaveButton({
  tool: saveTool,
  text,
  title,
  meta,
  compact = true,
}: {
  tool: ToolId;
  text: string;
  title: string;
  meta?: Record<string, unknown>;
  compact?: boolean;
}) {
  const [state, setState] = useState<"idle" | "saving" | "done">("idle");
  return (
    <button
      type="button"
      disabled={state !== "idle"}
      className="btn btn-ghost btn-sm"
      onClick={async () => {
        setState("saving");
        try {
          await apiPost("/api/library", { tool: saveTool, title, text, meta });
          setState("done");
        } catch {
          setState("idle");
        }
      }}
    >
      {state === "saving" ? <Spinner /> : state === "done" ? "★ Saved" : `☆ ${compact ? "Save" : "Save to library"}`}
    </button>
  );
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-wrap items-center gap-2">{children}</div>;
}

function Block({ title, items }: { title: string; items: string[] }) {
  if (!items?.length) return null;
  return (
    <div>
      <p className="mb-1 text-[0.7rem] font-semibold uppercase tracking-wider text-[color:var(--muted)]">{title}</p>
      <ul className="space-y-1 text-sm text-white/85">
        {items.map((item, i) => (
          <li key={`${title}-${i}`} className="flex gap-2">
            <span className="text-violet-300">•</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function ResultView({
  tool,
  output,
  generationId,
}: {
  tool: ToolId;
  output: ToolOutput;
  generationId: number | null;
}) {
  const full = outputToText(tool, output);

  return (
    <div className="space-y-3 rise">
      <Row>
        <CopyButton value={full} label="Copy all" />
        <button
          type="button"
          className="btn btn-primary btn-sm"
          onClick={async () => {
            await apiPost("/api/library", {
              tool,
              title: full.split("\n")[0]?.slice(0, 120) ?? "Saved result",
              text: full,
              meta: { generationId },
            });
          }}
        >
          ★ Save to library
        </button>
        <Pill tone="brand">{tool}</Pill>
      </Row>

      {tool === "titles"
        ? (() => {
            const o = output as TitlesOutput;
            return (
              <ol className="space-y-2">
                {o.variants.map((v, i) => (
                  <li key={i} className="card flex items-start justify-between gap-3 p-3">
                    <div className="min-w-0">
                      <p className="text-[0.65rem] text-[color:var(--muted)]">#{i + 1}</p>
                      <p className="text-sm font-medium">{v}</p>
                    </div>
                    <Row>
                      <CopyButton value={v} label="" />
                      <SaveButton tool={tool} text={v} title={v} meta={{ generationId, variant: i + 1 }} />
                    </Row>
                  </li>
                ))}
              </ol>
            );
          })()
        : null}

      {tool === "hooks"
        ? (() => {
            const o = output as HooksOutput;
            return (
              <ul className="space-y-2">
                {o.variants.map((v, i) => (
                  <li key={i} className="card p-3">
                    <Row>
                      <Pill tone="brand">{v.style.replace(/_/g, " ")}</Pill>
                      <CopyButton value={v.text} label="" />
                      <SaveButton tool={tool} text={v.text} title={v.text} meta={{ generationId }} />
                    </Row>
                    <p className="mt-2 text-sm">{v.text}</p>
                  </li>
                ))}
                {o.notes ? <li className="text-xs text-[color:var(--muted)]">{o.notes}</li> : null}
              </ul>
            );
          })()
        : null}

      {tool === "captions"
        ? (() => {
            const o = output as CaptionsOutput;
            return (
              <ul className="space-y-2">
                {o.variants.map((v, i) => (
                  <li key={i} className="card p-3">
                    <Row>
                      <CopyButton value={v} label="" />
                      <SaveButton tool={tool} text={v} title={v.slice(0, 80)} meta={{ generationId }} />
                    </Row>
                    <p className="mt-2 whitespace-pre-line text-sm">{v}</p>
                  </li>
                ))}
                {o.notes ? <li className="text-xs text-[color:var(--muted)]">{o.notes}</li> : null}
              </ul>
            );
          })()
        : null}

      {tool === "scripts"
        ? (() => {
            const o = output as ScriptOutput;
            return (
              <div className="card space-y-3 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold">{o.title}</h3>
                    <p className="text-xs text-[color:var(--muted)]">
                      {o.duration} • ~{o.wordCount} words
                    </p>
                  </div>
                  <Row>
                    <CopyButton value={full} label="Copy script" />
                    <SaveButton tool={tool} text={full} title={o.title} compact={false} meta={{ generationId }} />
                  </Row>
                </div>
                <div className="space-y-3">
                  {o.sections.map((s, i) => (
                    <div key={i} className="rounded-xl border border-white/10 bg-black/25 p-3">
                      <div className="mb-1 flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold uppercase tracking-wider text-violet-200">{s.label}</p>
                        <CopyButton value={s.text} label="" />
                      </div>
                      <p className="whitespace-pre-line text-sm">{s.text}</p>
                    </div>
                  ))}
                </div>
                {o.cta ? (
                  <p className="rounded-xl border border-cyan-400/20 bg-cyan-500/10 p-3 text-sm text-cyan-100">CTA: {o.cta}</p>
                ) : null}
              </div>
            );
          })()
        : null}

      {tool === "hashtags"
        ? (() => {
            const o = output as HashtagsOutput;
            const groups: [string, string[]][] = [
              ["Broad", o.broad],
              ["Niche", o.niche],
              ["Long tail", o.longTail],
            ];
            return (
              <div className="card space-y-4 p-4">
                {groups.map(([label, tags]) => (
                  <div key={label}>
                    <p className="mb-2 text-[0.7rem] font-semibold uppercase tracking-wider text-[color:var(--muted)]">{label}</p>
                    <div className="flex flex-wrap gap-2">
                      {tags.map((t) => (
                        <span key={t} className="chip text-white/90">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
                <Row>
                  <CopyButton value={o.copyAll} label="Copy all hashtags" />
                  <SaveButton tool={tool} text={o.copyAll} title="Hashtag set" compact={false} meta={{ generationId }} />
                </Row>
              </div>
            );
          })()
        : null}

      {tool === "thumbnail"
        ? (() => {
            const o = output as ThumbnailOutput;
            return (
              <ul className="grid gap-2 sm:grid-cols-2">
                {o.variants.map((v, i) => (
                  <li key={i} className="card p-3">
                    <p className="text-lg font-black uppercase leading-tight tracking-tight">{v.text}</p>
                    {v.pairing ? <p className="mt-1 text-xs text-[color:var(--muted)]">{v.pairing}</p> : null}
                    <Row>
                      <CopyButton value={v.text} label="" />
                      <SaveButton tool={tool} text={`${v.text}${v.pairing ? ` — ${v.pairing}` : ""}`} title={v.text} meta={{ generationId }} />
                    </Row>
                  </li>
                ))}
              </ul>
            );
          })()
        : null}

      {tool === "ideas"
        ? (() => {
            const o = output as IdeasOutput;
            return (
              <ul className="grid gap-2 sm:grid-cols-2">
                {o.ideas.map((i, idx) => {
                  const text = `${i.title}\n${[i.angle, i.format].filter(Boolean).join(" • ")}\n${i.hook}`;
                  return (
                    <li key={idx} className="card flex flex-col gap-2 p-3">
                      <p className="text-sm font-semibold">{i.title}</p>
                      {i.angle ? <p className="text-xs text-[color:var(--muted)]">Angle: {i.angle}</p> : null}
                      {i.format ? <Pill>{i.format}</Pill> : null}
                      {i.hook ? <p className="text-sm text-white/80">“{i.hook}”</p> : null}
                      <Row>
                        <CopyButton value={text} label="" />
                        <SaveButton tool={tool} text={text} title={i.title} meta={{ generationId }} />
                      </Row>
                    </li>
                  );
                })}
              </ul>
            );
          })()
        : null}

      {tool === "calendar"
        ? (() => {
            const o = output as CalendarOutput;
            return (
              <div className="card space-y-3 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold">{o.name}</h3>
                    <p className="text-xs text-[color:var(--muted)]">{o.days.length} planned posts</p>
                  </div>
                  <Row>
                    <CopyButton value={full} label="Copy plan" />
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={async () => {
                        try {
                          await apiPost("/api/calendar", { name: o.name, planLength: o.days.length, days: o.days });
                        } catch {
                          /* handled by parent toast */
                        }
                      }}
                    >
                      🗓️ Save plan
                    </button>
                  </Row>
                </div>
                <ul className="grid gap-2 sm:grid-cols-2">
                  {o.days.map((d) => (
                    <li key={d.day} className="rounded-xl border border-white/10 bg-black/25 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-violet-200">Day {d.day}</p>
                        <Pill>{d.postTime}</Pill>
                      </div>
                      <p className="mt-1 text-sm font-medium">{d.topic}</p>
                      <p className="text-xs text-[color:var(--muted)]">
                        {d.platform} • {d.contentType}
                      </p>
                    </li>
                  ))}
                </ul>
                {o.notes ? <p className="text-xs text-[color:var(--muted)]">{o.notes}</p> : null}
              </div>
            );
          })()
        : null}

      {tool === "analyze"
        ? (() => {
            const o = output as AnalysisOutput;
            return (
              <div className="card space-y-4 p-4">
                <div className="flex items-center gap-3">
                  <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/40 to-cyan-400/30 text-lg font-bold">
                    {o.score}
                  </div>
                  <p className="text-sm text-white/85">{o.summary}</p>
                </div>
                <Block title="Strengths" items={o.strengths} />
                <Block title="Weaknesses" items={o.weaknesses} />
                <Block title="Clarity improvements" items={o.clarity} />
                <Block title="Engagement ideas" items={o.engagement} />
                <Block title="Alternative versions" items={o.alternatives} />
                <Row>
                  <CopyButton value={full} label="Copy report" />
                  <SaveButton tool={tool} text={full} title="Content analysis" compact={false} meta={{ generationId }} />
                </Row>
              </div>
            );
          })()
        : null}
    </div>
  );
}
