import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Shield,
  Radio,
  Sparkles,
  AlertCircle,
  Send,
  User,
  Bot,
  RefreshCw,
} from 'lucide-react';
import { JarvisSettings } from '../types';
import {
  startCallRingtone,
  playCallConnectedTone,
  playCallEndedTone,
  speakJarvis,
  stopSpeaking,
  playTone,
} from '../utils/audioSynthesizer';
import { generateJarvisResponse } from '../utils/jarvisBrain';
import {
  generateNotificationBriefing,
  answerNotificationQuery,
  generateNormalIncomingGreeting,
} from '../utils/notificationBriefing';

interface JarvisCallViewProps {
  settings: JarvisSettings;
  onEndCall: () => void;
  onCompleteBriefing?: (timestamp: number) => void;
  isMorningBriefing?: boolean;
}

type AssistantVoiceState = 'greeting' | 'listening' | 'processing' | 'speaking';

interface ConversationTurn {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
}

export const JarvisCallView: React.FC<JarvisCallViewProps> = ({
  settings,
  onEndCall,
  onCompleteBriefing,
  isMorningBriefing = true,
}) => {
  const [callState, setCallState] = useState<'incoming' | 'active'>('incoming');
  const [voiceState, setVoiceState] = useState<AssistantVoiceState>('greeting');
  const [durationSeconds, setDurationSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);

  // Live Speech & Dialogue
  const [userTranscript, setUserTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [jarvisDialogue, setJarvisDialogue] = useState(
    `Establishing voice interface for ${settings.userName}...`
  );
  const [conversationHistory, setConversationHistory] = useState<ConversationTurn[]>([]);

  // Permissions & Support status
  const [speechRecognitionSupported, setSpeechRecognitionSupported] = useState(true);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [manualInput, setManualInput] = useState('');

  // Refs for tracking active lifecycle across speech callbacks
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);
  const isCallActiveRef = useRef(false);
  const isMutedRef = useRef(false);
  const voiceStateRef = useRef<AssistantVoiceState>('greeting');
  const transcriptScrollRef = useRef<HTMLDivElement>(null);

  // Synchronize refs with state
  isCallActiveRef.current = callState === 'active';
  isMutedRef.current = isMuted;
  voiceStateRef.current = voiceState;

  // Auto-scroll transcript log when turns are added
  useEffect(() => {
    if (transcriptScrollRef.current) {
      transcriptScrollRef.current.scrollTop = transcriptScrollRef.current.scrollHeight;
    }
  }, [conversationHistory, interimTranscript]);

  // Ringtone during incoming state
  useEffect(() => {
    let stopRingtone: (() => void) | null = null;
    if (callState === 'incoming') {
      stopRingtone = startCallRingtone();
    }
    return () => {
      stopRingtone?.();
      stopSpeaking();
    };
  }, [callState]);

  // Duration timer during active call
  useEffect(() => {
    let interval: number | null = null;
    if (callState === 'active') {
      interval = window.setInterval(() => {
        setDurationSeconds(s => s + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [callState]);

  /**
   * Safe clean-up of speech recognizer
   */
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onresult = null;
        recognitionRef.current.stop();
      } catch {
        // Ignore stop error
      }
      recognitionRef.current = null;
    }
  }, []);

  /**
   * Continuous Hands-Free Speech Recognition Loop
   */
  const startListening = useCallback(() => {
    if (!isCallActiveRef.current || isMutedRef.current) {
      return;
    }

    // Stop any existing recognition instance
    stopListening();

    const SpeechRecognitionClass =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
        .SpeechRecognition ||
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
        .webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setSpeechRecognitionSupported(false);
      setSpeechError(
        'Speech recognition is not supported in this browser. You can use the quick prompt buttons or text input below.'
      );
      setVoiceState('listening');
      return;
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognizer = new (SpeechRecognitionClass as any)();
      recognizer.continuous = false; // We use utterance chunks so we detect when user finishes speaking
      recognizer.interimResults = true;
      recognizer.lang = settings.voiceLanguage || 'en-US';
      recognizer.maxAlternatives = 1;

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognizer.onstart = () => {
        setSpeechError(null);
        setVoiceState('listening');
        setInterimTranscript('');
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognizer.onresult = (event: any) => {
        if (!isCallActiveRef.current || isMutedRef.current) return;

        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            final += transcript;
          } else {
            interim += transcript;
          }
        }

        if (interim) {
          setInterimTranscript(interim);
        }

        if (final.trim()) {
          setInterimTranscript('');
          handleUserUtterance(final.trim());
        }
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognizer.onerror = (event: any) => {
        const err = event.error;

        // "no-speech" is normal when user is quiet; automatically keep listening hands-free
        if (err === 'no-speech') {
          if (isCallActiveRef.current && !isMutedRef.current && voiceStateRef.current === 'listening') {
            try {
              recognizer.start();
            } catch {
              // Ignore restart error
            }
          }
          return;
        }

        if (err === 'not-allowed' || err === 'service-not-allowed') {
          setSpeechError(
            'Microphone access was denied or is blocked in this window. You can continue the hands-free dialogue using the quick voice prompts below.'
          );
          setVoiceState('listening');
          return;
        }

        // For other recoverable errors, if active, retry gracefully
        if (isCallActiveRef.current && !isMutedRef.current && voiceStateRef.current === 'listening') {
          setTimeout(() => {
            if (isCallActiveRef.current && !isMutedRef.current) {
              startListening();
            }
          }, 800);
        }
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognizer.onend = () => {
        // If we are still in listening state and not speaking/processing, restart to keep loop hands-free
        if (
          isCallActiveRef.current &&
          !isMutedRef.current &&
          voiceStateRef.current === 'listening'
        ) {
          try {
            recognizer.start();
          } catch {
            // Wait brief moment and restart
            setTimeout(() => {
              if (isCallActiveRef.current && !isMutedRef.current && voiceStateRef.current === 'listening') {
                startListening();
              }
            }, 500);
          }
        }
      };

      recognitionRef.current = recognizer;
      recognizer.start();
    } catch {
      setSpeechRecognitionSupported(false);
      setSpeechError('Speech recognition could not be initialized.');
      setVoiceState('listening');
    }
  }, [settings.voiceLanguage, stopListening]);

  /**
   * Handles user's recognized speech, generates natural response, vocalizes,
   * and automatically loops back to listening hands-free!
   */
  const handleUserUtterance = useCallback(
    (spokenText: string) => {
      if (!isCallActiveRef.current || !spokenText.trim()) return;

      stopListening();
      setUserTranscript(spokenText);
      setVoiceState('processing');

      // Add to conversation turn history
      const userTurn: ConversationTurn = {
        id: `user-${Date.now()}`,
        sender: 'user',
        text: spokenText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversationHistory(prev => [...prev, userTurn]);

      // Check if user is asking a follow-up question regarding notifications or calendar
      const notifAnswer = answerNotificationQuery(spokenText, settings.capturedNotifications, settings);
      const jarvisReply = notifAnswer
        ? { spokenText: notifAnswer, isExitCommand: false }
        : generateJarvisResponse(spokenText, settings);

      setTimeout(() => {
        if (!isCallActiveRef.current) return;

        setJarvisDialogue(jarvisReply.spokenText);
        setVoiceState('speaking');

        const jarvisTurn: ConversationTurn = {
          id: `jarvis-${Date.now()}`,
          sender: 'jarvis',
          text: jarvisReply.spokenText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setConversationHistory(prev => [...prev, jarvisTurn]);

        // Speak response using on-device Text-to-Speech
        speakJarvis(
          jarvisReply.spokenText,
          settings.voicePitch,
          settings.voiceSpeed,
          settings.voicePersonality,
          () => {
            // Utterance finished callback
            if (!isCallActiveRef.current) return;

            // If user commanded exit/hang-up, end call cleanly
            if (jarvisReply.isExitCommand) {
              handleEndCall();
              return;
            }

            // CRITICAL REQUIREMENT:
            // "After responding, automatically listen again so the conversation can continue hands-free."
            if (!isMutedRef.current) {
              setVoiceState('listening');
              startListening();
            } else {
              setVoiceState('listening');
            }
          }
        );
      }, 350);
    },
    [settings, startListening, stopListening]
  );

  /**
   * Initial greeting when Answer is pressed
   */
  const beginVoiceSession = useCallback(() => {
    stopSpeaking();
    stopListening();
    playCallConnectedTone();
    setCallState('active');
    setVoiceState('greeting');

    let greetingText: string;
    if (isMorningBriefing) {
      const briefing = generateNotificationBriefing(
        settings.capturedNotifications,
        settings,
        isMorningBriefing
      );
      greetingText = briefing.speechScript;
    } else {
      greetingText = generateNormalIncomingGreeting(settings);
    }
    setJarvisDialogue(greetingText);

    const initialGreetingTurn: ConversationTurn = {
      id: `jarvis-greeting-${Date.now()}`,
      sender: 'jarvis',
      text: greetingText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setConversationHistory([initialGreetingTurn]);

    // Vocalize greeting with Android / Web TTS, then start listening hands-free
    speakJarvis(
      greetingText,
      settings.voicePitch,
      settings.voiceSpeed,
      settings.voicePersonality,
      () => {
        if (isCallActiveRef.current && !isMutedRef.current) {
          startListening();
        }
      }
    );
  }, [isMorningBriefing, settings, startListening, stopListening]);

  /**
   * Handle Mute / Unmute
   */
  const handleToggleMute = () => {
    const newMute = !isMuted;
    setIsMuted(newMute);
    isMutedRef.current = newMute;

    if (newMute) {
      stopListening();
      playTone(330, 0.1, 'sine');
    } else {
      playTone(660, 0.1, 'sine');
      if (callState === 'active' && voiceState !== 'speaking' && voiceState !== 'greeting') {
        startListening();
      }
    }
  };

  /**
   * Handle Call Disconnect / End
   */
  const handleEndCall = () => {
    isCallActiveRef.current = false;
    stopSpeaking();
    stopListening();
    playCallEndedTone();
    if (isMorningBriefing && onCompleteBriefing) {
      onCompleteBriefing(Date.now());
    }
    onEndCall();
  };

  const handleDecline = () => {
    stopSpeaking();
    stopListening();
    playCallEndedTone();
    onEndCall();
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    const text = manualInput.trim();
    setManualInput('');
    handleUserUtterance(text);
  };

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full h-full bg-gradient-to-b from-[#03060B] via-[#0A0E17] to-[#03060B] text-white flex flex-col justify-between p-4 sm:p-5 select-none relative overflow-hidden">
      {/* Background Tech Rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <div
          className={`w-72 h-72 sm:w-80 sm:h-80 rounded-full border border-[#00E5FF] transition-transform duration-700 ${
            callState === 'incoming'
              ? 'animate-ping'
              : voiceState === 'listening'
              ? 'animate-pulse scale-105 border-[#00E5FF]'
              : voiceState === 'speaking'
              ? 'animate-spin border-[#00E5FF]/60'
              : 'scale-100 border-slate-700'
          }`}
          style={{ animationDuration: voiceState === 'speaking' ? '20s' : '4s' }}
        />
        <div
          className="absolute w-96 h-96 rounded-full border border-[#00E5FF]/20 border-dashed animate-spin"
          style={{ animationDuration: '40s' }}
        />
      </div>

      {/* Top Header Information */}
      <div className="text-center pt-1 z-10 flex flex-col items-center">
        {/* Anti-Cellular Disclaimer Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#131B2E]/95 border border-[#00E5FF]/40 text-slate-200 text-[10px] font-mono tracking-wide mb-1.5 shadow-sm">
          <Shield className="w-3.5 h-3.5 text-[#00E5FF]" />
          <span className="font-semibold text-white">IN-APP AI VOICE SESSION</span>
          <span className="text-slate-500">•</span>
          <span className="text-[#00E5FF] font-bold">NOT A CELLULAR CALL</span>
        </div>

        {/* Morning Briefing Scheduled Indicator */}
        {isMorningBriefing && (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-[9px] font-mono tracking-wider uppercase mb-1">
            <Sparkles className="w-2.5 h-2.5 text-amber-400" />
            <span>SCHEDULED MORNING BRIEFING ({settings.morningBriefingTime})</span>
          </div>
        )}

        {/* Title: JARVIS */}
        <h1 className="text-2xl sm:text-3xl font-bold tracking-[0.18em] text-white font-sans text-center drop-shadow-[0_0_20px_rgba(0,229,255,0.6)]">
          {callState === 'incoming' ? 'JARVIS — INCOMING VOICE CONNECTION' : 'JARVIS'}
        </h1>

        {/* Subtitle Status */}
        {callState === 'incoming' ? (
          <div className="mt-1 flex flex-col items-center">
            <p className="text-xs font-mono tracking-widest text-[#00E5FF] font-semibold uppercase animate-pulse">
              {isMorningBriefing ? 'SCHEDULED MORNING EVENT READY' : 'VOICE INTERFACE ONLINE'}
            </p>
            <p className="text-[11px] font-mono text-slate-400 mt-0.5 flex items-center gap-1.5">
              <Radio className="w-3 h-3 text-[#00E5FF] animate-spin" />
              {isMorningBriefing
                ? 'Android AlarmManager Trigger • In-App Voice Session'
                : 'Hands-Free Assistant Trigger • Direct Audio'}
            </p>
          </div>
        ) : (
          <div className="mt-1 flex flex-col items-center">
            <p className="text-xs sm:text-sm font-mono tracking-widest text-[#00E5FF] font-semibold uppercase">
              ACTIVE VOICE CONVERSATION
            </p>
            <div className="flex items-center gap-2 text-[11px] font-mono text-slate-300 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-[#00E676] animate-ping" />
              <span className="font-bold text-white tracking-widest">{formatTimer(durationSeconds)}</span>
              <span className="text-slate-600">•</span>
              <span className="text-[#00E5FF]/90 font-mono">
                {isMuted
                  ? 'MIC MUTED'
                  : voiceState === 'listening'
                  ? 'LISTENING TO YOU...'
                  : voiceState === 'speaking'
                  ? 'JARVIS SPEAKING'
                  : voiceState === 'processing'
                  ? 'PROCESSING INTENT...'
                  : 'INITIALIZING...'}
              </span>
            </div>
          </div>
        )}

        {/* Missing Permissions Warning (Non-crashing Graceful Fallback) */}
        {(!settings.isNotificationAccessGranted || !settings.isMicrophonePermissionGranted || !settings.isCalendarPermissionGranted) && (
          <div className="mt-2 px-2.5 py-1 rounded-md bg-amber-950/40 border border-amber-500/30 text-amber-300 text-[10px] font-mono flex items-center gap-1.5 max-w-[340px] text-center">
            <AlertCircle className="w-3 h-3 text-amber-400 shrink-0" />
            <span className="truncate">
              Missing:{' '}
              {[
                !settings.isNotificationAccessGranted && 'Notification Access',
                !settings.isMicrophonePermissionGranted && 'Microphone',
                !settings.isCalendarPermissionGranted && 'Calendar',
              ]
                .filter(Boolean)
                .join(', ')}{' '}
              (Fallback Active)
            </span>
          </div>
        )}
      </div>

      {/* Center Section: Futuristic Arc Reactor & Conversation Visualizer */}
      <div className="flex-1 flex flex-col items-center justify-center z-10 my-auto py-2 w-full max-w-[380px] mx-auto">
        {/* Arc Reactor Centerpiece */}
        <div className="relative flex items-center justify-center mb-3">
          <div
            className={`w-36 h-36 sm:w-44 sm:h-44 rounded-full border-2 transition-all duration-500 ${
              callState === 'incoming'
                ? 'border-[#00E5FF] animate-pulse scale-105'
                : voiceState === 'listening'
                ? 'border-[#00E5FF] ring-4 ring-[#00E5FF]/20 scale-105'
                : voiceState === 'speaking'
                ? 'border-[#00E676] ring-4 ring-[#00E676]/20'
                : 'border-[#00E5FF]/40'
            }`}
          />

          {/* Inner Core */}
          <div className="absolute w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gradient-to-b from-[#131B2E] via-[#0D1525] to-[#0A0E17] border border-[#00E5FF]/70 flex items-center justify-center shadow-[0_0_24px_rgba(0,229,255,0.25)]">
            <div
              className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full border flex flex-col items-center justify-center transition-all ${
                callState === 'incoming'
                  ? 'bg-[#00E5FF]/20 border-[#00E5FF] animate-bounce'
                  : isMuted
                  ? 'bg-red-500/20 border-red-500/80 text-red-400'
                  : voiceState === 'listening'
                  ? 'bg-[#00E5FF]/30 border-[#00E5FF] animate-pulse'
                  : voiceState === 'speaking'
                  ? 'bg-[#00E676]/25 border-[#00E676]'
                  : 'bg-[#00E5FF]/10 border-[#00E5FF]/40'
              }`}
            >
              {callState === 'incoming' ? (
                <Radio className="w-7 h-7 text-[#00E5FF] animate-pulse" />
              ) : isMuted ? (
                <MicOff className="w-7 h-7 text-red-400" />
              ) : voiceState === 'listening' ? (
                <Mic className="w-7 h-7 text-[#00E5FF] animate-bounce" />
              ) : (
                <Sparkles className="w-7 h-7 text-[#00E676]" />
              )}
              <span className="text-[8px] font-mono font-bold tracking-widest mt-1 uppercase text-[#00E5FF]">
                {callState === 'incoming'
                  ? 'INCOMING'
                  : isMuted
                  ? 'MUTED'
                  : voiceState === 'listening'
                  ? 'HEARING'
                  : voiceState === 'speaking'
                  ? 'TALKING'
                  : 'READY'}
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic Voice Waveform */}
        {callState === 'active' && (
          <div className="flex items-center justify-center gap-1 h-5 mb-2.5">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className={`w-1 rounded-full transition-all duration-100 ${
                  isMuted
                    ? 'bg-slate-700 h-1.5'
                    : voiceState === 'speaking'
                    ? 'bg-[#00E676]'
                    : voiceState === 'listening'
                    ? 'bg-[#00E5FF]'
                    : 'bg-slate-600'
                }`}
                style={{
                  height: isMuted
                    ? '3px'
                    : voiceState === 'speaking' || voiceState === 'listening'
                    ? `${Math.sin(i * 0.6 + durationSeconds * 4) * 8 + 10}px`
                    : '4px',
                }}
              />
            ))}
          </div>
        )}

        {/* Live Conversation Transcript HUD */}
        {callState === 'active' && (
          <div className="w-full flex flex-col gap-2">
            {/* Scrollable Chat History Container */}
            <div
              ref={transcriptScrollRef}
              className="w-full bg-[#101726]/90 border border-slate-800/90 rounded-xl p-3 max-h-36 sm:max-h-40 overflow-y-auto space-y-2 shadow-inner text-left backdrop-blur-sm"
            >
              {conversationHistory.map(turn => (
                <div
                  key={turn.id}
                  className={`flex gap-2 text-xs leading-relaxed ${
                    turn.sender === 'user' ? 'text-cyan-200' : 'text-slate-200'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {turn.sender === 'user' ? (
                      <span className="inline-flex p-1 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-400">
                        <User className="w-2.5 h-2.5" />
                      </span>
                    ) : (
                      <span className="inline-flex p-1 rounded-full bg-slate-800/80 border border-[#00E5FF]/40 text-[#00E5FF]">
                        <Bot className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 mb-0.5">
                      <span className="font-semibold text-slate-300">
                        {turn.sender === 'user' ? settings.userName : 'JARVIS'}
                      </span>
                      <span>{turn.timestamp}</span>
                    </div>
                    <p className="font-sans text-[11px]">{turn.text}</p>
                  </div>
                </div>
              ))}

              {/* Real-time Interim Speech Bubble (shows as the user speaks) */}
              {interimTranscript && (
                <div className="flex gap-2 text-xs text-emerald-300 animate-pulse">
                  <span className="mt-0.5 inline-flex p-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 shrink-0">
                    <Mic className="w-2.5 h-2.5" />
                  </span>
                  <div className="flex-1">
                    <p className="text-[9px] font-mono text-emerald-400 mb-0.5">Hearing you...</p>
                    <p className="font-sans text-[11px] italic">&quot;{interimTranscript}&quot;</p>
                  </div>
                </div>
              )}
            </div>

            {/* Permission or Speech-Recognition Fallback Notice (Graceful non-crash UX) */}
            {speechError && (
              <div className="w-full bg-[#1F1914] border border-amber-500/40 rounded-lg p-2 flex items-start gap-2 text-[10px] text-amber-300">
                <AlertCircle className="w-3.5 h-3.5 shrink-0 text-amber-400 mt-0.5" />
                <div className="flex-1 text-left">
                  <p className="font-mono font-semibold">Speech Recognition Notice</p>
                  <p className="text-amber-200/90 text-[10px] leading-tight mt-0.5">
                    {speechError}
                  </p>
                </div>
              </div>
            )}

            {/* Hands-free Quick Conversation Chips */}
            <div className="flex items-center gap-1.5 flex-wrap justify-center pt-1">
              {[
                { label: 'Morning Briefing', prompt: 'Give me my morning briefing' },
                { label: 'Subsystems Status', prompt: 'Run a system diagnostic status' },
                { label: 'Weather Forecast', prompt: 'What is today\'s weather forecast?' },
                { label: 'VIP Alerts', prompt: 'Read my high priority notifications' },
                { label: 'Who are you?', prompt: 'Who are you and what can you do?' },
              ].map(item => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => handleUserUtterance(item.prompt)}
                  className="px-2 py-1 rounded-md bg-[#162035] hover:bg-[#1E2C48] border border-[#00E5FF]/25 text-slate-300 hover:text-white text-[10px] font-mono transition-colors active:scale-95"
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Hands-free simulation input bar (Fallback if microphone blocked in iframe) */}
            <form onSubmit={handleManualSubmit} className="flex items-center gap-1.5 mt-0.5">
              <input
                type="text"
                value={manualInput}
                onChange={e => setManualInput(e.target.value)}
                placeholder="Or type a voice command..."
                className="flex-1 bg-[#131B2E] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 font-sans focus:outline-none focus:border-[#00E5FF]"
              />
              <button
                type="submit"
                className="px-2.5 py-1.5 bg-[#00E5FF] hover:bg-[#00c4db] text-[#0A0E17] rounded-lg font-bold text-xs flex items-center gap-1 active:scale-95 transition-transform"
                title="Send Command"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}

        {/* Incoming Ringing State Info */}
        {callState === 'incoming' && (
          <div className="mt-4 text-center max-w-[280px]">
            <p className="text-xs font-mono text-slate-300 leading-relaxed">
              Scheduled morning briefing is ready.{' '}
              <span className="text-[#00E676] font-bold">Answer</span> to connect to hands-free
              two-way AI speech.
            </p>
          </div>
        )}
      </div>

      {/* Bottom Controls: Answer/Decline or Mute/End/Speaker */}
      <div className="z-10 pb-2">
        {callState === 'incoming' ? (
          /* Incoming Call Buttons */
          <div className="flex items-center justify-around max-w-[280px] mx-auto">
            {/* Decline */}
            <div className="flex flex-col items-center gap-2">
              <button
                id="btn-decline-call"
                onClick={handleDecline}
                className="w-16 h-16 rounded-full bg-[#FF3B30] text-white flex items-center justify-center shadow-lg shadow-red-900/40 hover:bg-red-600 active:scale-95 transition-all"
                title="Decline"
                aria-label="Decline"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
              <span className="text-xs font-mono font-bold tracking-wider text-red-400">
                DECLINE
              </span>
            </div>

            {/* Answer */}
            <div className="flex flex-col items-center gap-2">
              <button
                id="btn-accept-call"
                onClick={beginVoiceSession}
                className="w-16 h-16 rounded-full bg-[#00E676] text-[#0A0E17] flex items-center justify-center shadow-lg shadow-emerald-900/40 hover:bg-emerald-400 active:scale-95 transition-all animate-bounce"
                title="Answer"
                aria-label="Answer"
              >
                <Phone className="w-7 h-7 fill-current" />
              </button>
              <span className="text-xs font-mono font-bold tracking-wider text-[#00E676]">
                ANSWER
              </span>
            </div>
          </div>
        ) : (
          /* Active Voice Call Controls */
          <div className="flex flex-col items-center gap-2.5">
            <div className="flex items-center justify-around w-full max-w-[300px]">
              {/* Mute Microphone */}
              <div className="flex flex-col items-center gap-1">
                <button
                  id="btn-call-mute"
                  onClick={handleToggleMute}
                  className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all ${
                    isMuted
                      ? 'bg-red-500/20 border-red-500 text-red-400 shadow-md shadow-red-900/30'
                      : 'bg-[#131B2E] border-slate-700 text-slate-200 hover:bg-[#1C2640] hover:text-[#00E5FF]'
                  }`}
                  title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>
                <span className="text-[10px] font-mono text-slate-400">
                  {isMuted ? 'UNMUTE' : 'MUTE'}
                </span>
              </div>

              {/* End Call Button */}
              <div className="flex flex-col items-center gap-1">
                <button
                  id="btn-end-call"
                  onClick={handleEndCall}
                  className="w-16 h-16 rounded-full bg-[#FF3B30] text-white flex items-center justify-center shadow-lg shadow-red-900/50 hover:bg-red-600 active:scale-95 transition-all"
                  title="Disconnect Voice Session"
                >
                  <PhoneOff className="w-7 h-7" />
                </button>
                <span className="text-[10px] font-mono font-bold text-red-400 tracking-wider">
                  END CALL
                </span>
              </div>

              {/* Speakerphone Toggle */}
              <div className="flex flex-col items-center gap-1">
                <button
                  id="btn-call-speaker"
                  onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all ${
                    isSpeakerOn
                      ? 'bg-[#131B2E] border-[#00E5FF]/40 text-[#00E5FF]'
                      : 'bg-[#131B2E] border-slate-700 text-slate-400'
                  }`}
                  title={isSpeakerOn ? 'Speaker Active' : 'Earpiece Mode'}
                >
                  {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                </button>
                <span className="text-[10px] font-mono text-slate-400">
                  {isSpeakerOn ? 'SPEAKER' : 'EARPIECE'}
                </span>
              </div>
            </div>

            {/* Micro Audio Status Indicator */}
            <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isMuted ? 'bg-red-500' : 'bg-[#00E676] animate-pulse'
                }`}
              />
              <span>
                {isMuted
                  ? 'INPUT MUTED • JARVIS WAITING'
                  : voiceState === 'listening'
                  ? 'SPEECH-TO-TEXT ACTIVE • HANDS-FREE READY'
                  : voiceState === 'speaking'
                  ? 'ANDROID TTS VOCALIZING'
                  : 'ON-DEVICE VOICE PIPELINE ACTIVE'}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
