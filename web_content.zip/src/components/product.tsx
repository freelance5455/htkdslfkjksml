import { useEffect, useState, type ReactElement, type ReactNode } from "react";
import { cities, memoryQueries, pulsePeople, reviewNotes, standup } from "@/content";
import type { TabId } from "@/context";
import { cn } from "@/utils/cn";

function useNow(interval = 1000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), interval);
    return () => window.clearInterval(id);
  }, [interval]);
  return now;
}

function clockParts(date: Date, tz: string) {
  const time = new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
    timeZone: tz,
  }).format(date);
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hourCycle: "h23", timeZone: tz })
      .formatToParts(date)
      .find((part) => part.type === "hour")?.value ?? "0",
  );
  return { time, working: hour >= 9 && hour < 18 };
}

export function CityRibbon() {
  const now = useNow(1000);
  return (
    <div className="relative z-10 -mt-5 px-1 sm:-mt-7">
      <div className="glass no-scrollbar flex gap-2 overflow-x-auto rounded-2xl p-2 sm:gap-1 sm:rounded-full">
        <p className="sr-only">Local time and working hours for a distributed engineering team.</p>
        {cities.map((city) => {
          const { time, working } = clockParts(now, city.tz);
          return (
            <div
              key={city.city}
              className="flex min-w-[8.5rem] items-center gap-2 rounded-full px-3 py-2 sm:min-w-0 sm:flex-1"
              aria-hidden="true"
            >
              <span className={cn("size-1.5 shrink-0 rounded-full", working ? "bg-teal shadow-[0_0_10px_#7ee0c8]" : "bg-white/25")} />
              <span className="min-w-0">
                <span className="block truncate text-[11px] text-faint">{city.city}</span>
                <span className="block font-mono text-xs tabular-nums text-paper">{time}</span>
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function WindowChrome({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-[1.2rem] bg-gradient-to-br from-copper/70 via-white/15 to-teal/50 p-px shadow-[0_40px_120px_-48px_rgba(0,0,0,0.9),0_0_80px_-28px_rgba(228,161,91,0.45)]">
      <div className="overflow-hidden rounded-[1.15rem] bg-[#100e0c]">
      <div className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
        <span className="flex gap-1.5" aria-hidden="true">
          <span className="size-2.5 rounded-full bg-[#3a342e]" />
          <span className="size-2.5 rounded-full bg-[#3a342e]" />
          <span className="size-2.5 rounded-full bg-[#3a342e]" />
        </span>
        <p className="truncate font-mono text-[11px] text-faint">{title}</p>
      </div>
      {children}
      </div>
    </div>
  );
}

export function HeroStage() {
  const [decision, setDecision] = useState<"pending" | "accepted" | "dismissed">("pending");

  return (
    <div className="stage relative">
      <div className="pointer-events-none absolute -inset-8 -z-10 rounded-[2rem] bg-[radial-gradient(ellipse_at_center,rgba(228,161,91,0.16),transparent_62%)]" />
      <WindowChrome title="nexus · billing-monorepo · packages/billing/retry.ts">
        <div className="grid lg:grid-cols-[180px_1fr_280px]">
          <aside className="hidden border-r border-white/8 p-4 lg:block">
            <p className="mb-3 text-[10px] uppercase tracking-[0.16em] text-faint">Indexed</p>
            {["retry.ts", "backoff.ts", "ADR-014.md", "CODEOWNERS", "incident-1102"].map((file, index) => (
              <p key={file} className={cn("truncate py-1 font-mono text-[11px]", index === 0 ? "text-copper" : "text-mist/80")}>
                {file}
              </p>
            ))}
          </aside>
          <div className="overflow-x-auto border-white/10 p-4 font-mono text-[12px] leading-6 sm:p-5 lg:border-r">
            <p className="text-faint">
              <span className="text-iris">export async function</span> <span className="text-paper">scheduleRetry</span>
              <span className="text-mist">(invoice: Invoice) {"{"}</span>
            </p>
            <p className="text-mist">
              {"  "}const delay = <span className="text-paper">backoff</span>(invoice.attempts);
            </p>
            <p className="text-faint">{"  "}{"// queue contract lives in workers/billing.ts"}</p>
            <div className="my-3 rounded-xl border border-copper/30 bg-copper/8 px-3 py-2 text-paper">
              <p>
                <span className="text-teal">+</span> return queue.add("invoice.retry", {"{"}
              </p>
              <p>
                <span className="text-teal">+</span> {"  "}id: invoice.id,
              </p>
              <p>
                <span className="text-teal">+</span> {"  "}key: idempotencyKey(invoice),
              </p>
              <p>
                <span className="text-teal">+</span> {"}"}, {"{"} delay, attempts: 5 {"}"});
              </p>
            </div>
            <p className="text-mist">{"}"}</p>
            <p className="mt-4 text-[10px] uppercase tracking-[0.16em] text-faint">
              12,482 symbols · 4 ADRs linked · private index
            </p>
          </div>
          <div className="border-t border-white/8 p-4 lg:border-t-0">
            <div className="mb-3 flex items-center justify-between">
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-copper">Nexus</p>
              <span className="rounded-full bg-teal/15 px-2 py-0.5 text-[10px] text-teal">Lisbon online</span>
            </div>
            {decision === "pending" ? (
              <>
                <p className="text-sm leading-relaxed text-mist">
                  I matched <span className="text-paper">backoff()</span> and the queue contract. The idempotency key is the same helper from the November incident.
                </p>
                <ul className="mt-3 space-y-1.5">
                  {["packages/jobs/backoff.ts", "workers/billing.ts", "ADR-014"].map((cite) => (
                    <li key={cite} className="truncate rounded-lg bg-white/[0.04] px-2 py-1 font-mono text-[10px] text-faint">
                      {cite}
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setDecision("accepted")}
                    className="h-8 flex-1 rounded-full bg-paper text-xs font-medium text-ink transition hover:bg-white"
                  >
                    Accept draft
                  </button>
                  <button
                    type="button"
                    onClick={() => setDecision("dismissed")}
                    className="h-8 flex-1 rounded-full border border-white/10 text-xs text-mist transition hover:text-paper"
                  >
                    Dismiss
                  </button>
                </div>
              </>
            ) : (
              <p className="rise text-sm leading-relaxed text-paper" role="status">
                {decision === "accepted"
                  ? "Queued on your branch. Maya will see a pre-review when Lisbon’s afternoon starts — not a surprise in her morning."
                  : "Noted. I won’t introduce a new retry helper in this repo. The preference stays here, not in a global model."}
              </p>
            )}
          </div>
        </div>
      </WindowChrome>
      <div className="pointer-events-none absolute -left-3 top-16 hidden rounded-2xl border border-white/10 bg-ink/80 px-3 py-2 text-xs text-mist shadow-xl backdrop-blur-md xl:block">
        <span className="text-copper">PR #482</span> · 3 notes · 1 risk
      </div>
      <div className="pointer-events-none absolute -right-2 bottom-16 hidden rounded-2xl border border-white/10 bg-ink/80 px-3 py-2 text-xs text-mist shadow-xl backdrop-blur-md xl:block">
        Cited 3 files · no training
      </div>
    </div>
  );
}

function ComposerPanel() {
  return (
    <WindowChrome title="composer · ask nexus">
      <div className="space-y-4 p-4 sm:p-5">
        <div className="ml-auto max-w-md rounded-2xl rounded-br-md bg-white/[0.06] px-4 py-3 text-sm text-paper">
          Add idempotency to invoice retry without changing the queue contract.
        </div>
        <div className="max-w-lg rounded-2xl rounded-bl-md border border-copper/25 bg-copper/8 px-4 py-3 text-sm leading-relaxed text-mist">
          I’ll reuse <span className="text-paper">withIdempotency</span> from <span className="font-mono text-xs text-copper">packages/jobs</span>. Draft touches two files and keeps the existing queue signature.
        </div>
        <div className="overflow-hidden rounded-xl border border-white/10 font-mono text-[12px] leading-6">
          <div className="flex items-center justify-between border-b border-white/8 px-3 py-2 text-[10px] uppercase tracking-[0.14em] text-faint">
            <span>retry.ts</span>
            <span className="text-teal">+8 −1</span>
          </div>
          <div className="space-y-0.5 px-3 py-3">
            <p className="text-teal/90">+ key: idempotencyKey(invoice),</p>
            <p className="text-teal/90">+ attempts: 5,</p>
            <p className="text-white/30">- attempts: invoice.attempts + 1,</p>
          </div>
        </div>
      </div>
    </WindowChrome>
  );
}

function ReviewPanel() {
  const [risksOnly, setRisksOnly] = useState(false);
  const notes = reviewNotes.filter((note) => (risksOnly ? note.risk : true));
  return (
    <WindowChrome title="review · PR #482 · feat: idempotent invoice retry">
      <div className="p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-mist">
            <span className="text-paper">6 files</span> · +214 −38 · opened by Jonah while Lisbon slept
          </p>
          <button
            type="button"
            aria-pressed={risksOnly}
            onClick={() => setRisksOnly((value) => !value)}
            className={cn(
              "h-8 rounded-full border px-3 text-xs transition",
              risksOnly ? "border-copper/50 bg-copper/15 text-copper" : "border-white/10 text-mist hover:text-paper",
            )}
          >
            {risksOnly ? "Showing risks" : "Show only risks"}
          </button>
        </div>
        <ul className="mt-4 space-y-3">
          {notes.map((note) => (
            <li key={note.cite} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center justify-between gap-3">
                <span className={cn("text-[11px] font-semibold uppercase tracking-[0.16em]", note.risk ? "text-copper" : "text-teal")}>
                  {note.kind}
                </span>
                <span className="truncate font-mono text-[10px] text-faint">{note.cite}</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-mist">{note.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </WindowChrome>
  );
}

function PulsePanel() {
  const [active, setActive] = useState(0);
  const person = pulsePeople[active];
  return (
    <WindowChrome title="pulse · overnight digest · 06:12 UTC">
      <div className="grid gap-4 p-4 sm:grid-cols-[200px_1fr] sm:p-5">
        <div className="flex gap-2 overflow-x-auto sm:flex-col sm:overflow-visible">
          {pulsePeople.map((item, index) => (
            <button
              key={item.name}
              type="button"
              onClick={() => setActive(index)}
              className={cn(
                "min-w-[9rem] rounded-2xl border px-3 py-2 text-left transition sm:min-w-0",
                index === active ? "border-copper/40 bg-copper/10" : "border-white/10 hover:border-white/20",
              )}
              aria-pressed={index === active}
            >
              <span className="flex items-center gap-2 text-sm text-paper">
                <span className={cn("size-1.5 rounded-full", item.on ? "bg-teal" : "bg-white/25")} />
                {item.name}
              </span>
              <span className="mt-0.5 block text-[11px] text-faint">{item.city}</span>
            </button>
          ))}
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.16em] text-copper">{person.hours}</p>
          <p className="mt-2 font-serif text-2xl tracking-[-0.03em]">{person.status}</p>
          <p className="mt-4 text-[11px] uppercase tracking-[0.16em] text-faint">Async standup</p>
          <ul className="mt-2 space-y-2">
            {standup.map((item) => (
              <li key={item} className="text-sm leading-relaxed text-mist">
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </WindowChrome>
  );
}

function MemoryPanel() {
  const [active, setActive] = useState(0);
  const item = memoryQueries[active];
  return (
    <WindowChrome title="memory · billing-monorepo">
      <div className="p-4 sm:p-5">
        <p className="text-[11px] uppercase tracking-[0.16em] text-faint">Ask the repo</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {memoryQueries.map((query, index) => (
            <button
              key={query.q}
              type="button"
              onClick={() => setActive(index)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-left text-xs transition",
                index === active ? "border-copper/50 bg-copper/12 text-paper" : "border-white/10 text-mist hover:text-paper",
              )}
              aria-pressed={index === active}
            >
              {query.q}
            </button>
          ))}
        </div>
        <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4" aria-live="polite">
          <p className="text-sm leading-relaxed text-paper">{item.a}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {item.cites.map((cite) => (
              <span key={cite} className="rounded-full bg-white/[0.05] px-2.5 py-1 font-mono text-[10px] text-teal">
                {cite}
              </span>
            ))}
          </div>
        </div>
      </div>
    </WindowChrome>
  );
}

const panels: Record<TabId, () => ReactElement> = {
  composer: ComposerPanel,
  review: ReviewPanel,
  pulse: PulsePanel,
  memory: MemoryPanel,
};

export function ShowcaseVisual({ tab }: { tab: TabId }) {
  const Panel = panels[tab];
  return (
    <div key={tab} className="rise">
      <Panel />
    </div>
  );
}

export const showcaseTabs: { id: TabId; label: string; text: string }[] = [
  {
    id: "composer",
    label: "Composer",
    text: "Ask for the change the way you’d ask a teammate who already read the file. The draft follows your helpers, not a generic style guide.",
  },
  {
    id: "review",
    label: "Review",
    text: "Risk, context, and routing — before a human spends their morning reconstructing the PR. A person still merges.",
  },
  {
    id: "pulse",
    label: "Pulse",
    text: "See who is actually at their desk. Digests replace the standup. Deep-work status holds the pings.",
  },
  {
    id: "memory",
    label: "Memory",
    text: "The why, cited. Query decisions, incidents, and ownership without waking the only person who remembers.",
  },
];
