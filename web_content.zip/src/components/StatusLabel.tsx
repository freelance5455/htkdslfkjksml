import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Loader2,
  RotateCcw,
  ShieldCheck,
  XCircle,
} from 'lucide-react';

interface StatusLabelProps {
  status: string;
  compact?: boolean;
}

export function StatusLabel({ status, compact = false }: StatusLabelProps) {
  const sizeClass = compact ? 'text-xs' : 'text-xs font-medium';

  switch (status) {
    case 'completed':
    case 'captured':
    case 'resolved':
    case 'active':
      return (
        <span className={`inline-flex items-center gap-1.5 text-emerald-400 ${sizeClass}`}>
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          <span className="capitalize whitespace-nowrap">{status}</span>
        </span>
      );
    case 'in_progress':
    case 'in_review':
      return (
        <span className={`inline-flex items-center gap-1.5 text-blue-400 ${sizeClass}`}>
          <Loader2 className="h-3.5 w-3.5 shrink-0" />
          <span className="whitespace-nowrap">{status === 'in_progress' ? 'In Progress' : 'In Review'}</span>
        </span>
      );
    case 'queued':
      return (
        <span className={`inline-flex items-center gap-1.5 text-violet-400 ${sizeClass}`}>
          <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
          <span className="whitespace-nowrap">Verified & Queued</span>
        </span>
      );
    case 'awaiting_payment':
    case 'pending':
    case 'created':
    case 'open':
      return (
        <span className={`inline-flex items-center gap-1.5 text-amber-400 ${sizeClass}`}>
          <Clock className="h-3.5 w-3.5 shrink-0" />
          <span className="whitespace-nowrap">
            {status === 'awaiting_payment'
              ? 'Awaiting Payment'
              : status === 'open'
                ? 'Open'
                : status === 'created'
                  ? 'Initiated'
                  : 'Pending'}
          </span>
        </span>
      );
    case 'payment_failed':
    case 'failed':
    case 'suspended':
      return (
        <span className={`inline-flex items-center gap-1.5 text-rose-400 ${sizeClass}`}>
          <XCircle className="h-3.5 w-3.5 shrink-0" />
          <span className="whitespace-nowrap">
            {status === 'payment_failed' ? 'Payment Failed' : status === 'suspended' ? 'Suspended' : 'Failed'}
          </span>
        </span>
      );
    case 'refunded':
    case 'processed':
      return (
        <span className={`inline-flex items-center gap-1.5 text-slate-300 ${sizeClass}`}>
          <RotateCcw className="h-3.5 w-3.5 shrink-0" />
          <span className="capitalize whitespace-nowrap">{status}</span>
        </span>
      );
    default:
      return (
        <span className={`inline-flex items-center gap-1.5 text-slate-400 ${sizeClass}`}>
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span className="capitalize whitespace-nowrap">{status.replace(/_/g, ' ')}</span>
        </span>
      );
  }
}
