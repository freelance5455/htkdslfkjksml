import React, { useState } from 'react';
import { useGeolocationTracker } from '../hooks/useGeolocationTracker';
import { RunMap } from './RunMap';
import { Workout, WorkoutType, UserProfile } from '../types';
import {
  Play,
  Pause,
  Square,
  RotateCcw,
  Flag,
  Volume2,
  VolumeX,
  Gauge,
  Navigation as NavigationIcon,
  AlertTriangle,
  HeartPulse,
  Save,
  CheckCircle,
} from 'lucide-react';

interface LiveRunTrackerProps {
  onSaveWorkout: (workout: Workout) => void;
  userProfile: UserProfile;
  initialWorkoutType?: WorkoutType;
  onOpenSafetyModal: () => void;
}

export const LiveRunTracker: React.FC<LiveRunTrackerProps> = ({
  onSaveWorkout,
  userProfile,
  initialWorkoutType = 'easy',
  onOpenSafetyModal,
}) => {
  const [autoPause, setAutoPause] = useState(false);
  const [voiceVoiceEnabled, setVoiceEnabled] = useState(true);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [selectedType, setSelectedType] = useState<WorkoutType>(initialWorkoutType);
  const [rpe, setRpe] = useState(6);
  const [sleepHours, setSleepHours] = useState(7.5);
  const [energyLevel, setEnergyLevel] = useState(4);
  const [sorenessScore, setSorenessScore] = useState(2);
  const [notes, setNotes] = useState('');
  const [weatherNotes, setWeatherNotes] = useState('Clear, 22°C');

  const tracker = useGeolocationTracker({
    autoPauseEnabled: autoPause,
    voiceAnnouncementsEnabled: voiceVoiceEnabled,
    lapIntervalMeters: selectedType === 'intervals' || selectedType === 'track_reps' ? 400 : 1000,
  });

  const {
    trackingState,
    permissionStatus,
    gpsAccuracy,
    lastPosition,
    routeCoordinates,
    distanceMeters,
    distanceKm,
    elapsedFormatted,
    elapsedSeconds,
    currentPace,
    averagePace,
    currentSpeedKmh,
    splits,
    isSimulated,
    errorMessage,
    setIsSimulated,
    requestGPSPermission,
    startTracking,
    pauseTracking,
    resumeTracking,
    manualLap,
    stopTracking,
    resetTracker,
  } = tracker;

  const handleFinishRun = () => {
    stopTracking();
    setShowSaveModal(true);
  };

  const handleConfirmSave = () => {
    const is1600mTimeTrial = selectedType === 'time_trial' || (distanceMeters >= 1580 && distanceMeters <= 1650);

    const workout: Workout = {
      id: 'run-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      startTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      workoutType: selectedType,
      title: `${selectedType.toUpperCase().replace('_', ' ')} Run`,
      distanceKm,
      distanceMeters: Math.round(distanceMeters),
      durationSeconds: elapsedSeconds,
      durationFormatted: elapsedFormatted,
      avgPace: averagePace,
      avgSpeedKmh: currentSpeedKmh,
      rpe,
      sleepHours,
      energyLevel,
      sorenessScore,
      notes,
      weather: weatherNotes,
      splits,
      routeCoordinates,
      isTimeTrial: is1600mTimeTrial,
      timeTrialTimeFormatted: is1600mTimeTrial ? elapsedFormatted : undefined,
    };

    onSaveWorkout(workout);
    setShowSaveModal(false);
    resetTracker();
  };

  const handleDiscard = () => {
    if (window.confirm('Discard this run recording? This cannot be undone.')) {
      resetTracker();
      setShowSaveModal(false);
    }
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Header telemetry / status card */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                trackingState === 'running'
                  ? 'bg-[#00FF66] animate-ping'
                  : trackingState === 'paused'
                  ? 'bg-amber-400'
                  : 'bg-zinc-500'
              }`}
            />
            <span className="font-athletic text-sm uppercase tracking-wider font-bold text-zinc-300">
              {trackingState === 'running'
                ? 'Tracking Active'
                : trackingState === 'paused'
                ? 'Session Paused'
                : 'Ready to Run'}
            </span>
          </div>

          {/* GPS Accuracy Pill */}
          <div className="flex items-center gap-1.5 text-xs">
            <Gauge className="w-3.5 h-3.5 text-zinc-400" />
            <span
              className={`font-semibold ${
                isSimulated
                  ? 'text-cyan-400'
                  : gpsAccuracy && gpsAccuracy < 10
                  ? 'text-[#00FF66]'
                  : gpsAccuracy && gpsAccuracy < 25
                  ? 'text-amber-400'
                  : 'text-zinc-400'
              }`}
            >
              {isSimulated
                ? 'Simulation Mode'
                : gpsAccuracy
                ? `GPS ±${Math.round(gpsAccuracy)}m`
                : 'GPS Standby'}
            </span>
          </div>
        </div>

        {/* Big StopWatch Timer */}
        <div className="text-center py-2">
          <p className="text-xs font-semibold uppercase tracking-widest text-zinc-400">Duration</p>
          <h1 className="font-mono-numbers text-5xl sm:text-6xl font-black tracking-tight text-white mt-1">
            {elapsedFormatted}
          </h1>
        </div>

        {/* Primary Metric Grid: Distance, Current Pace, Avg Pace, Speed */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-zinc-800/80">
          <div className="bg-black/50 border border-zinc-800/60 rounded-xl p-3 text-center">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
              Distance
            </span>
            <div className="flex items-baseline justify-center gap-1 mt-0.5">
              <span className="font-mono-numbers text-3xl font-extrabold text-[#00FF66]">
                {distanceKm.toFixed(2)}
              </span>
              <span className="text-xs font-bold text-zinc-400">KM</span>
            </div>
            <span className="text-[10px] text-zinc-400">({Math.round(distanceMeters)}m)</span>
          </div>

          <div className="bg-black/50 border border-zinc-800/60 rounded-xl p-3 text-center">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
              Current Pace
            </span>
            <div className="flex items-baseline justify-center gap-1 mt-0.5">
              <span className="font-mono-numbers text-3xl font-extrabold text-white">
                {currentPace}
              </span>
              <span className="text-xs font-bold text-zinc-400">/KM</span>
            </div>
            <span className="text-[10px] text-zinc-400">Target 4:50 Pace</span>
          </div>

          <div className="bg-black/50 border border-zinc-800/60 rounded-xl p-3 text-center">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
              Average Pace
            </span>
            <div className="flex items-baseline justify-center gap-1 mt-0.5">
              <span className="font-mono-numbers text-2xl font-bold text-zinc-200">
                {averagePace}
              </span>
              <span className="text-xs font-semibold text-zinc-400">/KM</span>
            </div>
          </div>

          <div className="bg-black/50 border border-zinc-800/60 rounded-xl p-3 text-center">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
              Speed
            </span>
            <div className="flex items-baseline justify-center gap-1 mt-0.5">
              <span className="font-mono-numbers text-2xl font-bold text-zinc-200">
                {currentSpeedKmh.toFixed(1)}
              </span>
              <span className="text-xs font-semibold text-zinc-400">KM/H</span>
            </div>
          </div>
        </div>

        {/* 1600m Target Gauge Indicator */}
        <div className="mt-4 p-3 bg-zinc-950/70 border border-zinc-800/90 rounded-xl flex items-center justify-between text-xs">
          <div>
            <span className="text-zinc-400 font-medium">1600m Target Split:</span>
            <span className="font-bold text-[#00FF66] ml-1.5 font-mono-numbers">1:12.5 / 400m</span>
          </div>
          <div className="text-right">
            <span className="text-zinc-400">Target Time:</span>
            <span className="font-bold text-white ml-1.5 font-mono-numbers">4:50.0</span>
          </div>
        </div>
      </div>

      {/* Map View */}
      <div className="h-60 sm:h-72 w-full">
        <RunMap
          coordinates={routeCoordinates}
          currentPosition={lastPosition}
          accuracy={gpsAccuracy}
          isLive={trackingState === 'running'}
        />
      </div>

      {/* Permission / Error Banner */}
      {errorMessage && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-2.5 text-xs text-amber-300">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
          <div className="flex-1">
            <p className="font-medium">{errorMessage}</p>
            {permissionStatus === 'denied' && (
              <p className="mt-1 text-zinc-400">
                You can toggle on "Simulation Mode" below to test the workout tracker without device GPS.
              </p>
            )}
          </div>
        </div>
      )}

      {/* Quick Controls & Toggles */}
      <div className="flex items-center justify-between px-1 text-xs text-zinc-400">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setVoiceEnabled(!voiceVoiceEnabled)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition ${
              voiceVoiceEnabled
                ? 'bg-zinc-800 text-[#00FF66] border-[#00FF66]/30'
                : 'bg-zinc-900 text-zinc-500 border-zinc-800'
            }`}
          >
            {voiceVoiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>Voice Cues</span>
          </button>

          <button
            onClick={() => setAutoPause(!autoPause)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition ${
              autoPause
                ? 'bg-zinc-800 text-[#00FF66] border-[#00FF66]/30'
                : 'bg-zinc-900 text-zinc-500 border-zinc-800'
            }`}
          >
            <span>Auto-Pause: {autoPause ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Simulation Mode Toggle (for test environments) */}
        <button
          onClick={() => {
            if (trackingState === 'running') {
              alert('Cannot toggle simulation while run is in progress.');
              return;
            }
            setIsSimulated(!isSimulated);
          }}
          className={`px-2.5 py-1 rounded-lg border text-[11px] font-semibold transition ${
            isSimulated
              ? 'bg-cyan-950/80 text-cyan-400 border-cyan-500/40'
              : 'bg-zinc-900 text-zinc-500 border-zinc-800'
          }`}
        >
          {isSimulated ? '✓ Demo GPS On' : 'Simulate GPS'}
        </button>
      </div>

      {/* Main Action Control Buttons */}
      <div className="space-y-3">
        {trackingState === 'idle' && (
          <button
            onClick={() => {
              if (permissionStatus === 'prompt') {
                requestGPSPermission();
              }
              startTracking();
            }}
            className="w-full py-4 rounded-2xl bg-[#00FF66] text-black font-athletic font-black text-xl tracking-wider uppercase flex items-center justify-center gap-2 hover:bg-[#10B981] active:scale-[0.98] transition shadow-lg glow-neon"
          >
            <Play className="w-6 h-6 fill-current" />
            <span>START {selectedType.replace('_', ' ')} RUN</span>
          </button>
        )}

        {trackingState === 'running' && (
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={manualLap}
              className="py-3.5 rounded-xl bg-zinc-800 border border-zinc-700 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 hover:bg-zinc-700 active:scale-95 transition"
            >
              <Flag className="w-4 h-4 text-[#00FF66]" />
              <span>SPLIT / LAP</span>
            </button>

            <button
              onClick={pauseTracking}
              className="py-3.5 rounded-xl bg-amber-500 text-black font-bold text-sm tracking-wide flex items-center justify-center gap-2 hover:bg-amber-400 active:scale-95 transition"
            >
              <Pause className="w-4 h-4 fill-current" />
              <span>PAUSE</span>
            </button>
          </div>
        )}

        {trackingState === 'paused' && (
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={resumeTracking}
              className="py-3.5 rounded-xl bg-[#00FF66] text-black font-bold text-sm flex items-center justify-center gap-1.5 hover:bg-[#10B981] active:scale-95 transition glow-neon-sm"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>RESUME</span>
            </button>

            <button
              onClick={handleFinishRun}
              className="py-3.5 rounded-xl bg-zinc-100 text-black font-bold text-sm flex items-center justify-center gap-1.5 hover:bg-white active:scale-95 transition"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>FINISH</span>
            </button>

            <button
              onClick={handleDiscard}
              className="py-3.5 rounded-xl bg-zinc-800 text-rose-400 font-semibold text-xs flex items-center justify-center gap-1 hover:bg-zinc-700 active:scale-95 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>DISCARD</span>
            </button>
          </div>
        )}

        {/* Safety & Red Flag Stop Trigger */}
        {trackingState === 'running' && (
          <button
            onClick={() => {
              pauseTracking();
              onOpenSafetyModal();
            }}
            className="w-full py-2 rounded-xl bg-rose-950/40 border border-rose-900/60 text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-rose-900/40 transition"
          >
            <HeartPulse className="w-4 h-4 text-rose-400" />
            <span>Experiencing Sharp Pain or Breathing Distress? Tap Here</span>
          </button>
        )}
      </div>

      {/* Lap Splits History Table */}
      {splits.length > 0 && (
        <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white">
              Lap Splits ({splits.length})
            </h3>
            <span className="text-[11px] text-zinc-400">Interval: 1600m Target = 1:12.5</span>
          </div>
          <div className="divide-y divide-zinc-800/80">
            {splits.map((s) => (
              <div key={s.lapNumber} className="py-2 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-black border border-zinc-700 flex items-center justify-center font-bold text-[10px] text-zinc-300">
                    {s.lapNumber}
                  </span>
                  <span className="text-zinc-300 font-medium">{s.distanceMeters}m</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono-numbers text-zinc-400">{s.durationSeconds}s</span>
                  <span className="font-mono-numbers font-bold text-[#00FF66]">{s.pace}/km</span>
                  <span className="text-zinc-400 font-mono-numbers">{s.speedKmh} km/h</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Save Workout Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-2xl p-5 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-[#00FF66]" />
                <h2 className="font-athletic text-lg font-black uppercase text-white">
                  Save Workout Session
                </h2>
              </div>
              <span className="text-xs font-mono-numbers text-[#00FF66] font-bold">
                {distanceKm} KM · {elapsedFormatted}
              </span>
            </div>

            {/* Workout Type Selector */}
            <div>
              <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider block mb-1.5">
                Workout Category
              </label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as WorkoutType)}
                className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#00FF66]"
              >
                <option value="easy">Easy Aerobic Base Run</option>
                <option value="intervals">1600m Intervals (400m Reps)</option>
                <option value="tempo">Tempo / Lactate Threshold</option>
                <option value="track_reps">Track Repetitions (200m Speed)</option>
                <option value="time_trial">1600m Time Trial (PB Test)</option>
                <option value="recovery">Active Recovery Run</option>
                <option value="treadmill">Treadmill Run</option>
                <option value="walk_cross">Walk / Cross-Training</option>
              </select>
            </div>

            {/* Perceived Exertion (RPE 1-10) */}
            <div>
              <div className="flex justify-between items-center mb-1 text-xs">
                <span className="font-semibold text-zinc-300">Rate of Perceived Exertion (RPE):</span>
                <span className="font-bold text-[#00FF66] text-sm">{rpe} / 10</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={rpe}
                onChange={(e) => setRpe(parseInt(e.target.value))}
                className="w-full accent-[#00FF66] bg-zinc-800 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-zinc-500 mt-1">
                <span>1 - Very Easy</span>
                <span>5 - Moderate</span>
                <span>8 - Hard Intervals</span>
                <span>10 - Maximum PB Test</span>
              </div>
            </div>

            {/* Sleep and Energy Check */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-zinc-300 block mb-1">
                  Last Night's Sleep (hrs)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="3"
                  max="12"
                  value={Number.isNaN(sleepHours) || sleepHours === 0 ? '' : sleepHours}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setSleepHours(Number.isNaN(val) ? 0 : val);
                  }}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-1.5 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-zinc-300 block mb-1">
                  Energy Level (1-5)
                </label>
                <select
                  value={energyLevel}
                  onChange={(e) => setEnergyLevel(parseInt(e.target.value))}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-1.5 text-sm text-white"
                >
                  <option value={5}>5 - High & Fresh</option>
                  <option value={4}>4 - Good</option>
                  <option value={3}>3 - Average</option>
                  <option value={2}>2 - Fatigued</option>
                  <option value={1}>1 - Exhausted</option>
                </select>
              </div>
            </div>

            {/* Soreness Slider */}
            <div>
              <div className="flex justify-between items-center mb-1 text-xs">
                <span className="text-zinc-300">Muscle Soreness Score:</span>
                <span className="font-bold text-amber-400">{sorenessScore} / 10</span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                value={sorenessScore}
                onChange={(e) => setSorenessScore(parseInt(e.target.value))}
                className="w-full accent-amber-400 bg-zinc-800 h-2 rounded-lg cursor-pointer"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="text-xs font-medium text-zinc-300 block mb-1">
                Session Notes & Running Form Feedback
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="How did lap splits, cadence, and breathing feel?"
                className="w-full bg-black border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#00FF66]"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleConfirmSave}
                className="flex-1 py-3 rounded-xl bg-[#00FF66] text-black font-athletic font-bold text-sm uppercase tracking-wide flex items-center justify-center gap-1.5 hover:bg-[#10B981] transition shadow-md glow-neon-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save to History</span>
              </button>
              <button
                onClick={() => setShowSaveModal(false)}
                className="px-4 py-3 rounded-xl bg-zinc-800 text-zinc-300 font-semibold text-xs hover:bg-zinc-700 transition"
              >
                Resume
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
