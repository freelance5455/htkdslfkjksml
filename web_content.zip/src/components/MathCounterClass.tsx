import React, { useState } from 'react';
import { Volume2, Edit3, Sparkles, Star, Plus, Minus, ArrowRight, ArrowLeft } from 'lucide-react';
import { MATH_NUMBERS } from '../data/learningData';
import { NumberItem } from '../types/curriculum';
import { sound } from '../utils/sound';

interface MathCounterClassProps {
  childName: string;
  onTraceNumber: (item: { letter: string; name: string; example: string }) => void;
  onEarnStar: () => void;
}

export const MathCounterClass: React.FC<MathCounterClassProps> = ({
  childName,
  onTraceNumber,
  onEarnStar,
}) => {
  const [selectedNum, setSelectedNum] = useState<NumberItem>(MATH_NUMBERS[0]);
  const [tappedItemsCount, setTappedItemsCount] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [learnedNumbers, setLearnedNumbers] = useState<Set<string>>(new Set(['num-1']));

  const handleSelectNumber = (item: NumberItem) => {
    sound.playPopSound();
    setSelectedNum(item);
    setTappedItemsCount(0);
    playNumberAudio(item);

    if (!learnedNumbers.has(item.id)) {
      setLearnedNumbers((prev) => new Set(prev).add(item.id));
      onEarnStar();
    }
  };

  const playNumberAudio = async (item: NumberItem) => {
    if (isPlayingAudio) return;
    setIsPlayingAudio(true);
    const textToSay = `${item.wordUrdu}! ${item.wordEnglish}! نمبر ${item.number}! ${item.funFact}`;
    await sound.speakWithGeminiOrLocal(textToSay, 'ur');
    setIsPlayingAudio(false);
  };

  const handleTapObject = (index: number) => {
    sound.playPopSound();
    setTappedItemsCount(index + 1);

    // Speak the single number
    const countNumber = index + 1;
    sound.speakText(`${countNumber}`, 'en');

    if (countNumber === selectedNum.number) {
      sound.playSuccessSound();
      onEarnStar();
    }
  };

  const handleNext = () => {
    const currentIndex = MATH_NUMBERS.findIndex((n) => n.id === selectedNum.id);
    const nextIndex = (currentIndex + 1) % MATH_NUMBERS.length;
    handleSelectNumber(MATH_NUMBERS[nextIndex]);
  };

  const handlePrev = () => {
    const currentIndex = MATH_NUMBERS.findIndex((n) => n.id === selectedNum.id);
    const prevIndex = (currentIndex - 1 + MATH_NUMBERS.length) % MATH_NUMBERS.length;
    handleSelectNumber(MATH_NUMBERS[prevIndex]);
  };

  return (
    <div className="space-y-6">
      {/* Featured Big Number Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500 via-teal-600 to-emerald-700 p-6 sm:p-8 text-white shadow-xl border-4 border-emerald-300">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Big Number Visual */}
          <div className="flex flex-col items-center">
            <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl bg-white text-emerald-700 flex flex-col items-center justify-center shadow-2xl border-4 border-yellow-300 animate-float">
              <div className="flex items-center gap-2">
                <span className="font-fun text-6xl sm:text-7xl font-black leading-none select-none">
                  {selectedNum.number}
                </span>
                <span className="font-urdu text-4xl sm:text-5xl font-black text-amber-500">
                  {selectedNum.urduDigit}
                </span>
              </div>
              <span className="text-xs sm:text-sm font-bold text-teal-600 mt-1">
                {selectedNum.wordEnglish} • {selectedNum.wordUrdu}
              </span>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() => playNumberAudio(selectedNum)}
                disabled={isPlayingAudio}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-yellow-950 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              >
                <Volume2 className={`w-5 h-5 ${isPlayingAudio ? 'animate-bounce text-emerald-700' : ''}`} />
                <span>{isPlayingAudio ? 'سنیں...' : 'گنتی سنیں (Listen)'}</span>
              </button>

              <button
                onClick={() =>
                  onTraceNumber({
                    letter: `${selectedNum.number}`,
                    name: `Number ${selectedNum.number} (${selectedNum.wordUrdu})`,
                    example: `${selectedNum.wordEnglish} (${selectedNum.urduDigit})`,
                  })
                }
                className="px-4 py-2 bg-white hover:bg-emerald-50 text-emerald-700 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer"
              >
                <Edit3 className="w-5 h-5 text-emerald-600" />
                <span>لکھنا سیکھیں (Trace)</span>
              </button>
            </div>
          </div>

          {/* Counting Playground */}
          <div className="flex-1 text-center md:text-right space-y-3">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-yellow-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>گنتی اور اعداد کی کلاس برائے {childName} 🔢</span>
            </div>

            <h3 className="font-urdu text-2xl sm:text-3xl font-extrabold text-white flex items-center justify-center md:justify-start gap-3">
              <span>{selectedNum.wordUrdu} ({selectedNum.wordEnglish})</span>
              <span className="text-3xl sm:text-4xl text-yellow-300 font-fun">#{selectedNum.number}</span>
            </h3>

            {/* Interactive Object Counters (Tap to count!) */}
            <div className="bg-white/15 backdrop-blur-sm p-4 rounded-2xl border border-white/20 text-white space-y-2">
              <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-yellow-200">
                <span>پیارے {childName}! انگلی سے گنو:</span>
                <span className="bg-white/20 px-2.5 py-0.5 rounded-full">
                  گنا گیا: {tappedItemsCount} / {selectedNum.number}
                </span>
              </div>

              {/* Items grid */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 pt-1">
                {Array.from({ length: selectedNum.number }).map((_, i) => {
                  const isCounted = i < tappedItemsCount;

                  return (
                    <button
                      key={i}
                      onClick={() => handleTapObject(i)}
                      className={`relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center text-2xl sm:text-3xl transition-all cursor-pointer ${
                        isCounted
                          ? 'bg-yellow-400 text-yellow-950 scale-110 shadow-lg ring-2 ring-white'
                          : 'bg-white/30 hover:bg-white/40 opacity-80 hover:opacity-100 hover:scale-105'
                      }`}
                      title={`Item ${i + 1}`}
                    >
                      <span>{selectedNum.emoji}</span>
                      <span className="absolute -top-1 -right-1 bg-emerald-900 text-emerald-100 text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                        {i + 1}
                      </span>
                    </button>
                  );
                })}
              </div>

              <p className="font-urdu text-base font-bold text-white pt-2">
                "{selectedNum.funFact}"
              </p>
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-center md:justify-start gap-3 pt-2">
              <button
                onClick={handlePrev}
                className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span>پچھلا عدد</span>
              </button>
              <span className="text-xs text-white/80 font-bold">
                {MATH_NUMBERS.findIndex((n) => n.id === selectedNum.id) + 1} / {MATH_NUMBERS.length}
              </span>
              <button
                onClick={handleNext}
                className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <span>اگلا عدد</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Numbers 1 to 20 */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl shadow-lg border-2 border-emerald-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h4 className="text-xl font-extrabold text-slate-800 flex items-center gap-2">
            <span>گنتی کے اعداد (1 تا 20 / ۱ تا ۲۰)</span>
          </h4>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-emerald-50 px-3 py-1.5 rounded-full">
            <span>اعداد مکمل ہوئے:</span>
            <span className="text-emerald-600 font-extrabold">{learnedNumbers.size} / 20</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-10 gap-2.5 sm:gap-3">
          {MATH_NUMBERS.map((item) => {
            const isSelected = selectedNum.id === item.id;
            const isLearned = learnedNumbers.has(item.id);

            return (
              <button
                key={item.id}
                onClick={() => handleSelectNumber(item)}
                className={`group relative p-2.5 sm:p-3 rounded-2xl flex flex-col items-center justify-center transition-all duration-200 cursor-pointer text-center ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-lg ring-4 ring-emerald-200 scale-105'
                    : 'bg-emerald-50/70 hover:bg-emerald-100 text-slate-800 border-2 border-emerald-100 hover:scale-105'
                }`}
              >
                {isLearned && (
                  <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-yellow-950 p-0.5 rounded-full text-[10px] shadow">
                    ⭐
                  </span>
                )}

                <div className="flex items-baseline gap-1">
                  <span className="font-fun text-2xl font-black">
                    {item.number}
                  </span>
                  <span className="font-urdu text-sm font-bold opacity-80">
                    {item.urduDigit}
                  </span>
                </div>
                <span className={`text-[10px] sm:text-xs font-bold mt-0.5 ${isSelected ? 'text-emerald-100' : 'text-slate-600'}`}>
                  {item.wordUrdu}
                </span>
                <span className="text-sm mt-0.5">
                  {item.emoji}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
