import React, { useState } from "react";
import { ShieldCheck, Lock, Brain, Trash2, Plus, Check, Info, FileText, AlertTriangle, User, RefreshCw } from "lucide-react";
import { UserMemory } from "../types";
import { purgeAllData } from "../utils/storage";

interface MemoryAndPrivacyProps {
  memory: UserMemory;
  onUpdateMemory: (updated: UserMemory) => void;
}

export const MemoryAndPrivacy: React.FC<MemoryAndPrivacyProps> = ({
  memory,
  onUpdateMemory,
}) => {
  const [addressingMode, setAddressingMode] = useState<"tumi" | "apni">(memory.addressingMode || "tumi");
  const [profession, setProfession] = useState(memory.profession);
  const [interests, setInterests] = useState(memory.interests);
  const [newFact, setNewFact] = useState("");
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<"memory" | "privacy" | "about">("memory");

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserMemory = {
      ...memory,
      addressingMode,
      profession,
      interests,
      lastUpdated: new Date().toISOString(),
    };
    onUpdateMemory(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddFact = () => {
    if (!newFact.trim()) return;
    const updated: UserMemory = {
      ...memory,
      facts: [...memory.facts, newFact.trim()],
      lastUpdated: new Date().toISOString(),
    };
    onUpdateMemory(updated);
    setNewFact("");
  };

  const handleDeleteFact = (index: number) => {
    const updated: UserMemory = {
      ...memory,
      facts: memory.facts.filter((_, idx) => idx !== index),
      lastUpdated: new Date().toISOString(),
    };
    onUpdateMemory(updated);
  };

  const handlePurge = () => {
    if (confirm("আপনি কি নিশ্চিত যে আপনার সমস্ত সংরক্ষিত মেমরি এবং হিস্ট্রি মুছে ফেলতে চান? এটি সম্পূর্ণরূপে স্থায়ী।")) {
      purgeAllData();
      window.location.reload();
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full px-3 sm:px-4 py-4 pb-24 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
          <span>মেমরি মোড ও এনক্রিপ্টেড প্রাইভেসি ভল্ট</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          তোমার নাম ও পছন্দ মনে রাখবে, যাতে একই কথা বারবার বলতে না হয়। সকল ডেটা সম্পূর্ণ স্থানীয়ভাবে এনক্রিপ্টেড।
        </p>
      </div>

      {/* Sub tabs: Memory / Privacy / About Us */}
      <div className="flex items-center gap-2 p-1 rounded-xl glass-panel border border-white/10 w-fit text-xs font-semibold">
        <button
          onClick={() => setActiveSubTab("memory")}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === "memory" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          <Brain className="w-3.5 h-3.5" />
          <span>মেমরি প্রোফাইল</span>
        </button>
        <button
          onClick={() => setActiveSubTab("privacy")}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === "privacy" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>প্রাইভেসি ও সিকিউরিটি</span>
        </button>
        <button
          onClick={() => setActiveSubTab("about")}
          className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
            activeSubTab === "about" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          <Info className="w-3.5 h-3.5" />
          <span>About Us</span>
        </button>
      </div>

      {/* Tab 1: Memory Profile */}
      {activeSubTab === "memory" && (
        <div className="space-y-6">
          {/* User Profile Details */}
          <div className="glass-panel-elevated rounded-2xl p-5 border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <User className="w-4 h-4 text-indigo-400" />
                <span>ব্যক্তিগত মেমরি প্রোফাইল</span>
              </h3>
              <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium">
                <Lock className="w-3 h-3" />
                <span>Client-Side Encrypted</span>
              </div>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">সম্বোধন পদ্ধতি (তুমি / আপনি):</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAddressingMode("tumi")}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                        addressingMode === "tumi"
                          ? "bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/30"
                          : "bg-slate-800/80 border-white/5 text-slate-400 hover:text-white"
                      }`}
                    >
                      তুমি (বন্ধুত্বপূর্ণ)
                    </button>
                    <button
                      type="button"
                      onClick={() => setAddressingMode("apni")}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                        addressingMode === "apni"
                          ? "bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/30"
                          : "bg-slate-800/80 border-white/5 text-slate-400 hover:text-white"
                      }`}
                    >
                      আপনি (শ্রদ্ধাশীল)
                    </button>
                  </div>
                  <span className="text-[10px] text-cyan-400 mt-1 block">
                    ✓ রণবীর কখনোই নাম ধরে ডাকবে না, সর্বদা &apos;তুমি&apos; বা &apos;আপনি&apos; দিয়ে কথা বলবে।
                  </span>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">পেশা / কাজ (Profession):</label>
                  <input
                    type="text"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                    placeholder="যেমন: ছাত্র, সফটওয়্যার ডেভেলপার, ক্রিয়েটর"
                    className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">পছন্দের বিষয় (Interests):</label>
                <input
                  type="text"
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                  placeholder="যেমন: কোডিং, এআই প্রযুক্তি, সাহিত্য, ইউটিউব"
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-slate-500">
                  Ranabir চ্যাট করার সময় এই তথ্যগুলো মনে রেখে ব্যক্তিগতভাবে উত্তর দেবে।
                </span>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  {savedSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>সংরক্ষণ সফল!</span>
                    </>
                  ) : (
                    <span>মেমরি সেভ করুন</span>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Facts Remembered by Ranabir */}
          <div className="glass-panel-elevated rounded-2xl p-5 border border-white/10 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Brain className="w-4 h-4 text-cyan-400" />
              <span>মনে রাখা নির্দিষ্ট তথ্যসমূহ (Learned Facts)</span>
            </h3>

            <div className="flex gap-2">
              <input
                type="text"
                value={newFact}
                onChange={(e) => setNewFact(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAddFact()}
                placeholder="একটি নতুন তথ্য যোগ করুন (যেমন: আমি রাতে কোডিং করতে পছন্দ করি)..."
                className="flex-1 glass-input rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              />
              <button
                onClick={handleAddFact}
                className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs flex items-center gap-1 transition-colors shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>যোগ করুন</span>
              </button>
            </div>

            <div className="space-y-2">
              {memory.facts.map((fact, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between gap-3 text-xs"
                >
                  <span className="text-slate-200">{fact}</span>
                  <button
                    onClick={() => handleDeleteFact(idx)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    title="Delete fact"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Privacy & Security */}
      {activeSubTab === "privacy" && (
        <div className="glass-panel-elevated rounded-2xl p-6 border border-white/10 shadow-xl space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">সম্পূর্ণ গোপনীয়তা ও সিকিউরিটি নীতি</h3>
              <p className="text-xs text-slate-400">
                Ranabir AI আপনার কোনো ব্যক্তিগত তথ্য বা চ্যাট বাইরে পাঠায় না।
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-800/60 border border-white/5 space-y-2">
              <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                <span>ক্লায়েন্ট-সাইড এনক্রিপশন (AES)</span>
              </h4>
              <p className="text-slate-400 leading-relaxed">
                আপনার নাম, মেমরি এবং প্রম্পট হিস্ট্রি সম্পূর্ণ লোকাল ব্রাউজার স্টোরেজে এনক্রিপ্ট করে সুরক্ষিত রাখা হয়।
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/60 border border-white/5 space-y-2">
              <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-indigo-400" />
                <span>জিরো টেলিমেট্রি ও নো-লিক পলিসি</span>
              </h4>
              <p className="text-slate-400 leading-relaxed">
                এটি কখনো নিজের কথা বাইরে বলতে পারবে না এবং সম্পূর্ণ গোপনীয়তা নিশ্চিত করবে। কোনো ডেটা তৃতীয় পক্ষের কাছে বিক্রি করা হয় না।
              </p>
            </div>
          </div>

          {/* Purge button */}
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-rose-300 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>সমস্ত ডেটা পার্জ করুন (Clear All Data)</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                এক ক্লিকে সমস্ত মেমরি, চ্যাট হিস্ট্রি এবং ছবি লোকাল ভল্ট থেকে চিরতরে মুছে ফেলুন।
              </p>
            </div>

            <button
              onClick={handlePurge}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shrink-0 shadow-sm"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>ডেটা মুছুন</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab 3: About Us */}
      {activeSubTab === "about" && (
        <div className="glass-panel-elevated rounded-2xl p-6 border border-white/10 shadow-xl space-y-6">
          <div className="text-center max-w-lg mx-auto space-y-3">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white font-extrabold text-2xl shadow-xl shadow-indigo-600/30">
              R
            </div>
            <h3 className="text-xl font-bold text-white">Ranabir - AI Assistant</h3>
            <p className="text-sm text-cyan-300 font-semibold">
              &quot;সর্বদা সাহায্য করার জন্য প্রস্তুত&quot;
            </p>
          </div>

          {/* Official Creator Statement */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-900/40 via-purple-900/30 to-slate-900/50 border border-indigo-500/30 text-center space-y-2">
            <div className="text-xs font-bold uppercase tracking-widest text-indigo-300">
              অফিসিয়াল পরিচিতি
            </div>
            <p className="text-lg sm:text-xl font-extrabold text-white">
              &quot;Ranabir AI, Ranabir Team দ্বারা তৈরি&quot;
            </p>
            <p className="text-xs text-slate-300 max-w-md mx-auto italic">
              ইউজার জিজ্ঞেস করলে বলবে: &quot;আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।&quot;
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 text-center">
              <div className="text-slate-400">প্রযুক্তিগত ভিত্তি</div>
              <div className="font-bold text-white mt-1">Flutter &amp; Web Engine</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 text-center">
              <div className="text-slate-400">ভয়েস ইঞ্জিন</div>
              <div className="font-bold text-white mt-1">Whisper &amp; Speech API</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 text-center">
              <div className="text-slate-400">ইমেজ ও ভিডিও এডিট</div>
              <div className="font-bold text-white mt-1">Stable Diffusion &amp; Canvas</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
