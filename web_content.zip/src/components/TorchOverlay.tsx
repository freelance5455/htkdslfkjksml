import React from 'react';
import { Flashlight, X } from 'lucide-react';

interface TorchOverlayProps {
  isActive: boolean;
  onTurnOff: () => void;
  isHardware: boolean;
}

export const TorchOverlay: React.FC<TorchOverlayProps> = ({
  isActive,
  onTurnOff,
  isHardware,
}) => {
  if (!isActive) return null;

  // Agar apparat chirog'i bo'lsa, ekran to'liq oq bo'lishi shart emas, kichik indikator yetadi.
  // Agar apparat chirog'i bo'lmasa, ekran chirog'i (Screen Flashlight) sifatida to'liq oq yorug'lik porlaydi.
  if (isHardware) {
    return (
      <div className="fixed top-20 right-4 z-40 bg-amber-400 text-slate-950 px-4 py-2 rounded-full shadow-[0_0_20px_rgba(251,191,36,0.8)] flex items-center gap-2 text-xs font-bold animate-pulse">
        <Flashlight className="w-4 h-4 fill-current" />
        <span>CHIROQ YONIQ</span>
        <button
          onClick={onTurnOff}
          className="ml-2 bg-slate-950/20 hover:bg-slate-950/40 p-1 rounded-full text-slate-950 transition-colors"
        >
          <X className="w-3 h-3" />
        </button>
      </div>
    );
  }

  return (
    <div
      onClick={onTurnOff}
      className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-6 select-none cursor-pointer transition-opacity duration-300"
      title="Chiroqni o'chirish uchun istalgan joyga bosing"
    >
      <div className="text-slate-800 font-display text-sm tracking-widest pt-4">
        JARVIS // EKRAN CHIROG'I
      </div>

      <div className="flex flex-col items-center text-center text-slate-900 gap-3">
        <Flashlight className="w-20 h-20 text-amber-500 fill-amber-400 animate-pulse" />
        <h2 className="text-2xl font-bold font-display tracking-wider">
          MAKSIMAL YORUG'LIK
        </h2>
        <p className="text-xs text-slate-600 max-w-xs">
          O'chirish uchun ekranning istalgan joyiga bosing, Sir.
        </p>
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation();
          onTurnOff();
        }}
        className="px-6 py-2.5 bg-slate-900 text-white text-xs font-semibold rounded-full shadow-lg hover:bg-slate-850"
      >
        Chiroqni o'chirish
      </button>
    </div>
  );
};
