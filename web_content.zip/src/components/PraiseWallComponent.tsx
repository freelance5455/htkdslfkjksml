import React, { useState, useEffect } from 'react';
import { Flame, Sparkles, Send, Heart, Clock } from 'lucide-react';

interface PraiseItem {
  id: string;
  text: string;
  category: 'Healing' | 'Victory' | 'Financial Breakthrough' | 'Family Blessing' | 'Divine Peace';
  timestamp: number; // Date.now()
  likes: number;
}

const INITIAL_PRAISES: PraiseItem[] = [
  {
    id: 'praise-1',
    text: 'Praise Jesus! My chronic back pain completely vanished during the prophetic soaking session yesterday!',
    category: 'Healing',
    timestamp: Date.now() - 3600000 * 2, // 2 hours ago
    likes: 24,
  },
  {
    id: 'praise-2',
    text: 'God opened a miraculous career door after months of waiting. Hallelujah to the King of Kings!',
    category: 'Victory',
    timestamp: Date.now() - 3600000 * 7, // 7 hours ago
    likes: 42,
  },
  {
    id: 'praise-3',
    text: 'Overflowing peace in my home today. Thank you Prophet JUHNKRIX for the daily word!',
    category: 'Divine Peace',
    timestamp: Date.now() - 3600000 * 14, // 14 hours ago
    likes: 19,
  },
];

export const PraiseWallComponent: React.FC = () => {
  const [praises, setPraises] = useState<PraiseItem[]>(() => {
    const saved = localStorage.getItem('juhnkrix_praise_wall');
    if (saved) {
      try {
        const parsed: PraiseItem[] = JSON.parse(saved);
        const twentyFourHoursAgo = Date.now() - 24 * 60 * 60 * 1000;
        const valid = parsed.filter(p => p.timestamp > twentyFourHoursAgo);
        return valid.length > 0 ? valid : INITIAL_PRAISES;
      } catch (e) {
        return INITIAL_PRAISES;
      }
    }
    return INITIAL_PRAISES;
  });

  const [newText, setNewText] = useState('');
  const [category, setCategory] = useState<PraiseItem['category']>('Victory');
  const [isPosting, setIsPosting] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'mine'>('all');
  const [myPraiseIds, setMyPraiseIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('juhnkrix_my_praise_ids');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    const twentyFourHoursAgo = Date.now() - 24 * 60 * 60 * 1000;
    const filtered = praises.filter(p => p.timestamp > twentyFourHoursAgo);
    localStorage.setItem('juhnkrix_praise_wall', JSON.stringify(filtered));
  }, [praises]);

  const handlePostPraise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    setIsPosting(true);
    const newId = `praise-${Date.now()}`;
    const item: PraiseItem = {
      id: newId,
      text: newText.trim(),
      category,
      timestamp: Date.now(),
      likes: 1,
    };

    const updatedMyIds = [newId, ...myPraiseIds];
    setMyPraiseIds(updatedMyIds);
    localStorage.setItem('juhnkrix_my_praise_ids', JSON.stringify(updatedMyIds));

    setPraises(prev => [item, ...prev]);
    setNewText('');
    setTimeout(() => setIsPosting(false), 400);
  };

  const handleLike = (id: string) => {
    setPraises(prev => prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
  };

  const displayedPraises = filterMode === 'mine'
    ? praises.filter(p => myPraiseIds.includes(p.id))
    : praises;

  return (
    <div className="bg-gradient-to-br from-amber-950/70 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-amber-500/40 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-mono font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Community Praise Wall • 24-Hour Testimonies</span>
          </div>
          <h3 className="text-xl font-bold font-serif text-amber-100">Anonymous Declarations of Victory & Thanks</h3>
          <p className="text-xs text-slate-300">
            Share what God has done for you today. All declarations are anonymous and automatically clear after 24 hours.
          </p>
        </div>
      </div>

      {/* Post Form */}
      <form onSubmit={handlePostPraise} className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/30 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Post Anonymous Testimony</span>
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1">
            {(['Victory', 'Healing', 'Financial Breakthrough', 'Family Blessing', 'Divine Peace'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`px-2.5 py-1 rounded-xl text-[10px] font-bold transition-all whitespace-nowrap ${
                  category === cat
                    ? 'bg-amber-400 text-slate-950 shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-amber-200 border border-amber-500/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            required
            placeholder="Type your short declaration of thanks or victory here..."
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            disabled={isPosting}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg transition-all shrink-0 flex items-center space-x-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Post Praise</span>
          </button>
        </div>
      </form>

      {/* Filter Mode Toggle */}
      <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-amber-500/10">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterMode === 'all'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-900 text-slate-300 hover:text-amber-200 border border-amber-500/20'
            }`}
          >
            View All ({praises.length})
          </button>
          <button
            onClick={() => setFilterMode('mine')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterMode === 'mine'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-900 text-slate-300 hover:text-amber-200 border border-amber-500/20'
            }`}
          >
            My Declarations ({myPraiseIds.length})
          </button>
        </div>
        <span className="text-[10px] text-slate-400 font-mono">Auto-clears after 24 hours</span>
      </div>

      {/* Praise Feed Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {displayedPraises.length === 0 ? (
          <div className="col-span-3 text-center py-8 text-slate-400 text-xs italic bg-slate-950/60 rounded-2xl border border-amber-500/10">
            {filterMode === 'mine' ? 'You have not posted any declarations yet today.' : 'No praise items found.'}
          </div>
        ) : (
          displayedPraises.map((item) => {
          const hoursAgo = Math.max(1, Math.floor((Date.now() - item.timestamp) / (1000 * 60 * 60)));
          const expiresLeft = Math.max(1, 24 - hoursAgo);

          return (
            <div
              key={item.id}
              className="bg-slate-950/90 p-5 rounded-2xl border border-amber-500/20 hover:border-amber-400/40 transition-all flex flex-col justify-between space-y-3 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-400/20 font-bold">
                    {item.category}
                  </span>
                  <span className="text-[10px] text-slate-400 flex items-center space-x-1 font-mono">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>Expires in {expiresLeft}h</span>
                  </span>
                </div>
                <p className="text-xs text-amber-100 font-serif leading-relaxed">
                  &ldquo;{item.text}&rdquo;
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-amber-500/10 text-[11px] text-slate-400">
                <span className="text-[10px] italic text-slate-400 font-mono">
                  {myPraiseIds.includes(item.id) ? '⭐ My Declaration' : 'Anonymous Believer'}
                </span>
                <button
                  onClick={() => handleLike(item.id)}
                  className="flex items-center space-x-1 text-amber-300 hover:text-amber-100 bg-amber-500/10 hover:bg-amber-500/20 px-2.5 py-1 rounded-xl transition-all"
                >
                  <Heart className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span className="font-bold">{item.likes}</span>
                </button>
              </div>
            </div>
          );
        })
        )}
      </div>
    </div>
  );
};
