/**
 * GODEX Preview Viewport Component
 * Bridges OperationManager active operation and generated artifact to the LivePreview / SandboxRunner.
 */

import React, { useState, useEffect } from 'react';
import { LivePreview } from './LivePreview';
import { OperationManager } from '../godex/operationManager';
import { GeneratedArtifact, OperationState } from '../godex/operationState';

export interface PreviewViewportProps {
  files?: Record<string, string>;
  artifact?: GeneratedArtifact | null;
  operationId?: string;
  isVerifying?: boolean;
  onConsoleLog?: (level: string, message: string) => void;
  onRuntimeError?: (err: any) => void;
  onAutoFixError?: (errorMessage: string) => void;
  onSelectFile?: (file: string) => void;
  onSelectWorkspaceView?: (view: any) => void;
  browserAutomationAction?: { type: string; selector?: string; message?: string } | null;
}

export const PreviewViewport: React.FC<PreviewViewportProps> = ({
  files,
  artifact: propArtifact,
  operationId,
  isVerifying,
  onConsoleLog,
  onRuntimeError,
  onAutoFixError,
  onSelectFile,
  onSelectWorkspaceView,
  browserAutomationAction
}) => {
  const [activeOperation, setActiveOperation] = useState<OperationState | null>(() => {
    const opMgr = OperationManager.getInstance();
    if (operationId) {
      return opMgr.getOperation(operationId) || opMgr.getActiveOperation();
    }
    return opMgr.getActiveOperation();
  });

  useEffect(() => {
    const opMgr = OperationManager.getInstance();
    const unsub = opMgr.subscribe((op) => {
      if (operationId) {
        if (op.operationId === operationId) {
          setActiveOperation(op);
        }
      } else {
        setActiveOperation(op);
      }
    });
    return () => unsub();
  }, [operationId]);

  // Resolve generated artifact from prop or active operation
  const resolvedArtifact = propArtifact || activeOperation?.artifact || (activeOperation as any)?.generatedArtifact || null;

  // Resolve runtime files from resolved artifact or passed files
  const resolvedFiles = resolvedArtifact?.files || files || {};

  return (
    <LivePreview
      files={resolvedFiles}
      artifact={resolvedArtifact}
      isVerifying={isVerifying}
      onConsoleLog={onConsoleLog}
      onRuntimeError={onRuntimeError}
      onAutoFixError={onAutoFixError}
      onSelectFile={onSelectFile}
      onSelectWorkspaceView={onSelectWorkspaceView}
      browserAutomationAction={browserAutomationAction}
    />
  );
};
