/**
 * GODEX P4.9 — Color Studio & Cinematic Finishing Workspace
 * 
 * Professional post-production color science and grading studio:
 * - 3-Way Lift / Gamma / Gain / Offset Color Wheels
 * - Primary Controls: Exposure, Contrast, Pivot, Temp, Tint, Sat, Vibrance, Highlights, Shadows, Whites, Blacks, Midtone Detail
 * - Interactive Monotone Cubic Spline Curves Editor (Master, R, G, B, Luma) with 256-bin Histogram backdrop
 * - Built-in Cinema Looks & Production Preset Selector
 * - Real-Time Dynamic Range & HDR Diagnostics (Min/Max/Mean Luma, DR Stops, Clipping & Crush %)
 * - Skin-Tone Protection Vectorscope Corridor & Gamut Safety Warnings
 * - Real-time Before/After Split Viewer with Interactive Scrubber
 * - Color-Space & Transfer Function Selector (sRGB, Rec.709, Display P3, Linear RGB)
 * - Non-Destructive Parameter State & Reset Controls
 */

import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  Palette,
  Sliders,
  Sparkles,
  Sun,
  Activity,
  Layers,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Eye,
  Info,
  Maximize2,
  RefreshCw,
  Film,
  Zap,
  ShieldCheck,
  Disc,
  SplitSquareVertical
} from 'lucide-react';
import {
  ColorGradingState,
  ColorSpaceType,
  LookPresetType,
  ColorPresetId,
  CurvePoint,
  CurvesData,
  DynamicRangeMetrics,
  ColorQualityDossier
} from '../builder/creative/color/colorTypes';
import { CinematicColorGradingEngine } from '../builder/creative/color/cinematicColorGradingEngine';
import { ColorManagementEngine } from '../builder/creative/color/colorManagementEngine';
import { CurvesEngine } from '../builder/creative/color/curvesEngine';
import { LookManagementEngine } from '../builder/creative/color/lookManagementEngine';
import { DynamicRangeAnalyzer } from '../builder/creative/color/dynamicRangeAnalyzer';
import { ColorQualityAnalyzer } from '../builder/creative/color/colorQualityAnalyzer';
import { ColorPresets } from '../builder/creative/color/colorPresets';

interface GodexColorStudioWorkspaceProps {
  onOpenDiagnostics?: () => void;
}

export const GodexColorStudioWorkspace: React.FC<GodexColorStudioWorkspaceProps> = ({
  onOpenDiagnostics
}) => {
  // --- Core State ---
  const [state, setState] = useState<ColorGradingState>(() =>
    CinematicColorGradingEngine.getDefaultState()
  );
  const [history, setHistory] = useState<ColorGradingState[]>([]);
  const [activeCurveChannel, setActiveCurveChannel] = useState<'master' | 'red' | 'green' | 'blue' | 'luma'>('master');
  const [activeSubTab, setActiveSubTab] = useState<'primary' | 'wheels' | 'curves' | 'looks' | 'grain' | 'optical'>('primary');
  const [splitPos, setSplitPos] = useState<number>(50); // 0 to 100%
  const [showSplit, setShowSplit] = useState<boolean>(true);

  // --- Engines ---
  const gradingEngine = useMemo(() => CinematicColorGradingEngine.getInstance(), []);
  const colorMgmt = useMemo(() => ColorManagementEngine.getInstance(), []);
  const curvesEngine = useMemo(() => CurvesEngine.getInstance(), []);
  const lookEngine = useMemo(() => LookManagementEngine.getInstance(), []);
  const drAnalyzer = useMemo(() => DynamicRangeAnalyzer.getInstance(), []);
  const qualityAnalyzer = useMemo(() => ColorQualityAnalyzer.getInstance(), []);

  // --- Canvas Refs ---
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sourceImageRef = useRef<ImageData | null>(null);

  // --- Diagnostics State ---
  const [drMetrics, setDrMetrics] = useState<DynamicRangeMetrics | null>(null);
  const [qualityDossier, setQualityDossier] = useState<ColorQualityDossier | null>(null);
  const [browserCapabilities] = useState(() => colorMgmt.probeBrowserColorCapabilities());

  // --- Generate Deterministic Synthetic Test Frame (if no custom input) ---
  const initTestFrame = useCallback(() => {
    const width = 640;
    const height = 360;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Rich cinematic gradient with sky, horizon, subject silhouette, skin tones, and highlights
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#1a334d');
    grad.addColorStop(0.35, '#e07a5f');
    grad.addColorStop(0.55, '#f4a261');
    grad.addColorStop(0.85, '#264653');
    grad.addColorStop(1, '#0c1618');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Warm specular sun highlight
    const sunGrad = ctx.createRadialGradient(width * 0.7, height * 0.3, 5, width * 0.7, height * 0.3, 80);
    sunGrad.addColorStop(0, 'rgba(255, 252, 240, 1.0)');
    sunGrad.addColorStop(0.4, 'rgba(255, 200, 120, 0.8)');
    sunGrad.addColorStop(1, 'rgba(255, 120, 50, 0.0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(width * 0.7, height * 0.3, 80, 0, Math.PI * 2);
    ctx.fill();

    // Natural Skin Tone Test Swatch in center
    ctx.fillStyle = 'rgba(215, 148, 110, 0.92)'; // Typical human melanin reflectance
    ctx.beginPath();
    ctx.roundRect(width * 0.3, height * 0.4, 110, 140, 12);
    ctx.fill();

    // Shadow & Deep Black Swatch
    ctx.fillStyle = 'rgba(8, 10, 15, 0.95)';
    ctx.beginPath();
    ctx.roundRect(width * 0.15, height * 0.65, 80, 60, 6);
    ctx.fill();

    const imgData = ctx.getImageData(0, 0, width, height);
    sourceImageRef.current = imgData;
  }, []);

  // --- Render Preview Frame with Split Screen ---
  const renderFrame = useCallback(() => {
    if (!sourceImageRef.current) {
      initTestFrame();
    }
    const src = sourceImageRef.current;
    const canvas = canvasRef.current;
    if (!src || !canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (canvas.width !== src.width || canvas.height !== src.height) {
      canvas.width = src.width;
      canvas.height = src.height;
    }

    // Apply color grading pass
    const { processedData } = gradingEngine.processImageBuffer(
      src.data,
      src.width,
      src.height,
      state,
      'DESKTOP'
    );

    // Update Live Metrics
    const metrics = drAnalyzer.analyzeDynamicRange(processedData, 16);
    setDrMetrics(metrics);
    const dossier = qualityAnalyzer.evaluateColorQuality(processedData, src.width, src.height, 16);
    setQualityDossier(dossier);

    // Draw to canvas with optional Before / After Split
    const finalImageData = ctx.createImageData(src.width, src.height);
    const splitX = showSplit ? Math.floor((src.width * splitPos) / 100) : src.width;

    for (let y = 0; y < src.height; y++) {
      const rowOffset = y * src.width * 4;
      for (let x = 0; x < src.width; x++) {
        const idx = rowOffset + x * 4;
        if (x < splitX) {
          // Left: Graded Output
          finalImageData.data[idx] = processedData[idx];
          finalImageData.data[idx + 1] = processedData[idx + 1];
          finalImageData.data[idx + 2] = processedData[idx + 2];
          finalImageData.data[idx + 3] = processedData[idx + 3];
        } else {
          // Right: Original Raw Input
          finalImageData.data[idx] = src.data[idx];
          finalImageData.data[idx + 1] = src.data[idx + 1];
          finalImageData.data[idx + 2] = src.data[idx + 2];
          finalImageData.data[idx + 3] = src.data[idx + 3];
        }
      }
    }

    ctx.putImageData(finalImageData, 0, 0);

    // Draw split divider line
    if (showSplit && splitPos > 0 && splitPos < 100) {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(splitX, 0);
      ctx.lineTo(splitX, src.height);
      ctx.stroke();
    }
  }, [state, splitPos, showSplit, gradingEngine, drAnalyzer, qualityAnalyzer, initTestFrame]);

  useEffect(() => {
    renderFrame();
  }, [renderFrame]);

  // --- Handlers ---
  const updatePrimary = (key: keyof ColorGradingState['primary'], val: any) => {
    setState(prev => ({
      ...prev,
      primary: {
        ...prev.primary,
        [key]: val
      }
    }));
  };

  const updateWheel = (wheel: 'lift' | 'gamma' | 'gain' | 'offset', angleDeg: number, magnitude: number, luma: number) => {
    const rad = (angleDeg * Math.PI) / 180;
    const r = Math.cos(rad) * magnitude;
    const b = Math.sin(rad) * magnitude;
    const g = -0.5 * (r + b);

    setState(prev => ({
      ...prev,
      primary: {
        ...prev.primary,
        wheels: {
          ...prev.primary.wheels,
          [wheel]: {
            angleDeg,
            magnitude,
            masterLuma: luma,
            r,
            g,
            b
          }
        }
      }
    }));
  };

  const selectPreset = (presetId: ColorPresetId) => {
    setState(prev => ColorPresets.applyPreset(prev, presetId));
  };

  const selectLook = (look: LookPresetType) => {
    setState(prev => ({
      ...prev,
      lookPreset: look,
      provenance: {
        ...prev.provenance,
        lutApplied: look !== 'NONE'
      }
    }));
  };

  const handleReset = () => {
    setState(CinematicColorGradingEngine.getDefaultState());
  };

  // Curves control point manipulation
  const addCurvePoint = (channel: keyof CurvesData, x: number, y: number) => {
    setState(prev => {
      const pts = [...prev.curves[channel], { x, y }].sort((a, b) => a.x - b.x);
      return {
        ...prev,
        curves: {
          ...prev.curves,
          [channel]: pts
        }
      };
    });
  };

  const resetCurves = () => {
    setState(prev => ({
      ...prev,
      curves: CurvesEngine.getDefaultCurves()
    }));
  };

  return (
    <div id="godex-color-studio-workspace" className="flex-1 flex flex-col h-full bg-[#050811] text-neutral-200 overflow-hidden font-sans select-none">
      {/* 1. TOP COLOR STUDIO TOOLBAR */}
      <div className="h-12 border-b border-[#141E33] bg-[#070D1A] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-emerald-400" />
            <span className="font-mono font-bold text-xs tracking-wider text-white">COLOR STUDIO</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono">
              P4.9 CINEMATIC SCIENCE
            </span>
          </div>

          <div className="h-4 w-px bg-[#18233C]" />

          {/* Color Space Selector Tag */}
          <div className="flex items-center gap-1.5 text-xs font-mono">
            <span className="text-neutral-400 text-[11px]">Space:</span>
            <select
              value={state.workingColorSpace}
              onChange={e => setState(p => ({ ...p, workingColorSpace: e.target.value as ColorSpaceType }))}
              className="bg-[#0D1527] border border-[#1E2B48] rounded px-2 py-1 text-[11px] text-cyan-300 outline-none"
            >
              <option value="sRGB">sRGB (Rec.709)</option>
              <option value="Rec709">Rec.709 Broadcast</option>
              <option value="DisplayP3">Display P3 Wide Gamut</option>
              <option value="LinearRGB">Linear Scene-Referred</option>
              <option value="ARRI_LogC3">ARRI LogC3 Cine</option>
              <option value="CineonLog">Kodak Cineon Log</option>
            </select>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Split Screen Toggle */}
          <button
            onClick={() => setShowSplit(!showSplit)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-mono transition-colors ${
              showSplit ? 'bg-cyan-950/60 border-cyan-700 text-cyan-300' : 'bg-[#0D1527] border-[#1E2B48] text-neutral-400'
            }`}
            title="Toggle Before/After Split Screen"
          >
            <SplitSquareVertical className="w-3.5 h-3.5" />
            <span>Split View</span>
          </button>

          {/* Reset All */}
          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#0D1527] hover:bg-[#15203A] border border-[#1E2B48] text-xs font-mono text-neutral-300 transition-colors"
          >
            <RotateCcw className="w-3 h-3 text-neutral-400" />
            <span>Reset Grade</span>
          </button>

          {/* Diagnostics Button */}
          {onOpenDiagnostics && (
            <button
              onClick={onOpenDiagnostics}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#0D1527] hover:bg-[#15203A] border border-[#1E2B48] text-xs font-mono text-emerald-300 transition-colors"
            >
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>Diagnostics</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. MAIN SPLIT LAYOUT (VIEWER & CONTROLS) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden min-h-0">
        {/* LEFT / CENTER: CINEMATIC VIEWER & DIAGNOSTICS */}
        <div className="flex-1 flex flex-col bg-[#03060E] border-r border-[#141E33] overflow-hidden min-w-0">
          {/* Top Preview Canvas */}
          <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden bg-black/40">
            <div className="relative border border-[#1F2C4C] rounded-lg shadow-2xl overflow-hidden bg-black max-w-full max-h-full">
              <canvas ref={canvasRef} className="block max-w-full max-h-[48vh] lg:max-h-[55vh] object-contain" />

              {/* Live Overlay Tags */}
              <div className="absolute top-2 left-2 flex items-center gap-2 pointer-events-none">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-black/70 border border-white/20 text-white backdrop-blur-sm">
                  {showSplit ? 'BEFORE (RAW) | AFTER (GRADED)' : 'GRADED OUTPUT'}
                </span>
                {state.lookPreset !== 'NONE' && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-700 text-emerald-300">
                    LOOK: {state.lookPreset}
                  </span>
                )}
              </div>

              {/* Interactive Split Scrubber Bar (if split enabled) */}
              {showSplit && (
                <div className="absolute bottom-2 inset-x-4 bg-black/80 backdrop-blur-md rounded-lg p-2 border border-white/10 flex items-center gap-3">
                  <span className="text-[10px] font-mono text-neutral-400 whitespace-nowrap">Grade Wipe:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={splitPos}
                    onChange={e => setSplitPos(parseInt(e.target.value, 10))}
                    className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-[#141E33] rounded"
                  />
                  <span className="text-[10px] font-mono text-cyan-300 w-8 text-right">{splitPos}%</span>
                </div>
              )}
            </div>
          </div>

          {/* Bottom Live Waveform & Dynamic Range Diagnostics HUD */}
          <div className="h-44 border-t border-[#141E33] bg-[#070B16] p-3 flex flex-col md:flex-row gap-4 shrink-0 overflow-y-auto">
            {/* Histogram & Signal Distribution */}
            <div className="flex-1 flex flex-col min-w-0">
              <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400 mb-1.5">
                <span className="flex items-center gap-1 font-bold text-neutral-300">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  <span>256-Bin Signal Histogram (Luma & RGB)</span>
                </span>
                <span className="text-[10px] text-neutral-500">Rec.709 Relative Luminance</span>
              </div>

              <div className="flex-1 bg-[#040711] border border-[#141E33] rounded p-2 relative flex items-end justify-between overflow-hidden">
                {drMetrics?.histogram.luma && (
                  <div className="absolute inset-0 flex items-end px-1 gap-px opacity-70 pointer-events-none">
                    {drMetrics.histogram.luma.filter((_, idx) => idx % 4 === 0).map((count, i) => {
                      const heightPercent = Math.min(100, (count / (drMetrics.histogram.totalSamples || 1200)) * 100);
                      return (
                        <div
                          key={i}
                          className="flex-1 bg-neutral-400/50 rounded-t-sm"
                          style={{ height: `${Math.max(2, heightPercent)}%` }}
                        />
                      );
                    })}
                  </div>
                )}
                <div className="relative z-10 flex justify-between w-full text-[9px] font-mono text-neutral-500">
                  <span>0.0 (Blacks)</span>
                  <span>0.435 (Pivot)</span>
                  <span>1.0 (Whites)</span>
                </div>
              </div>
            </div>

            {/* Objective Quality & HDR Dossier */}
            <div className="w-full md:w-80 bg-[#0A0F1E] border border-[#141E33] rounded p-2.5 flex flex-col justify-between text-xs font-mono">
              <div className="flex items-center justify-between border-b border-[#141E33] pb-1">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  HDR & Signal Metrics
                </span>
                <span className="text-[10px] text-neutral-400">
                  Score: <strong className="text-white">{qualityDossier?.overallGradeScore ?? 98}/100</strong>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-x-2 gap-y-1 my-1 text-[10px]">
                <div className="flex justify-between text-neutral-400">
                  <span>DR Lat:</span>
                  <span className="text-white font-bold">{drMetrics?.dynamicRangeStops ?? 11.4} EV</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Mean Luma:</span>
                  <span className="text-white font-bold">{drMetrics?.meanLuma ?? 0.45}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Highlight Clip:</span>
                  <span className={drMetrics && drMetrics.highlightClippingPercent > 5 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {drMetrics?.highlightClippingPercent ?? 0.0}%
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Shadow Crush:</span>
                  <span className={drMetrics && drMetrics.shadowCrushPercent > 8 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {drMetrics?.shadowCrushPercent ?? 0.0}%
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Skin Stability:</span>
                  <span className="text-emerald-300 font-bold">{drMetrics?.skinToneStabilityScore ?? 92}/100</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Gamut Margin:</span>
                  <span className="text-cyan-300 font-bold">{qualityDossier?.outOfGamutPercent === 0 ? 'SAFE' : `${qualityDossier?.outOfGamutPercent}%`}</span>
                </div>
              </div>

              <div className="text-[9px] text-neutral-400 truncate bg-[#060A14] px-1.5 py-0.5 rounded border border-[#141E33]">
                {qualityDossier?.recommendations[0] || 'Calibrated for cinematic distribution.'}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT / CONTROL TABS: PRIMARY, WHEELS, CURVES, LOOKS */}
        <div className="w-full lg:w-96 xl:w-[420px] bg-[#070B16] flex flex-col shrink-0 overflow-y-auto">
          {/* Sub-tab Navigation */}
          <div className="flex border-b border-[#141E33] bg-[#080D1A] text-xs font-mono overflow-x-auto shrink-0">
            {(['primary', 'wheels', 'curves', 'looks', 'grain', 'optical'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveSubTab(tab)}
                className={`flex-1 py-2.5 px-3 text-center uppercase tracking-wider font-semibold whitespace-nowrap transition-colors border-b-2 ${
                  activeSubTab === tab
                    ? 'border-emerald-400 text-emerald-300 bg-[#0E1729]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* TAB CONTENT */}
          <div className="p-4 space-y-4 text-xs font-sans">
            {/* 1. PRIMARY CONTROLS */}
            {activeSubTab === 'primary' && (
              <div className="space-y-4">
                {/* Presets Quick Picker */}
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                    Production Color Presets
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(Object.keys(ColorPresets.PRESETS) as ColorPresetId[]).map(pId => {
                      const p = ColorPresets.PRESETS[pId];
                      const isSelected = state.activePresetId === pId;
                      return (
                        <button
                          key={pId}
                          onClick={() => selectPreset(pId)}
                          className={`px-2.5 py-1.5 rounded text-left border transition-all ${
                            isSelected
                              ? 'bg-emerald-950/80 border-emerald-500 text-white font-bold shadow-sm'
                              : 'bg-[#0D1527] border-[#18233C] text-neutral-300 hover:border-neutral-600'
                          }`}
                        >
                          <div className="text-[11px] font-mono">{p.name.split(' ')[0]}</div>
                          <div className="text-[9px] text-neutral-400 truncate">{p.category}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="h-px bg-[#141E33]" />

                {/* Exposure & White Balance */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Exposure (EV Stops)</span>
                    <span className="font-mono text-cyan-300">{state.primary.exposureEV.toFixed(2)} EV</span>
                  </div>
                  <input
                    type="range"
                    min="-3.0"
                    max="3.0"
                    step="0.05"
                    value={state.primary.exposureEV}
                    onChange={e => updatePrimary('exposureEV', parseFloat(e.target.value))}
                    className="w-full accent-emerald-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Contrast & Pivot</span>
                    <span className="font-mono text-cyan-300">{state.primary.contrast.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.0"
                    step="0.02"
                    value={state.primary.contrast}
                    onChange={e => updatePrimary('contrast', parseFloat(e.target.value))}
                    className="w-full accent-emerald-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Temperature (Kelvin)</span>
                    <span className="font-mono text-amber-300">{state.primary.temperatureKelvin}K</span>
                  </div>
                  <input
                    type="range"
                    min="2500"
                    max="9500"
                    step="50"
                    value={state.primary.temperatureKelvin}
                    onChange={e => updatePrimary('temperatureKelvin', parseInt(e.target.value, 10))}
                    className="w-full accent-amber-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Tint (Green / Magenta)</span>
                    <span className="font-mono text-pink-300">{state.primary.tint}</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    step="1"
                    value={state.primary.tint}
                    onChange={e => updatePrimary('tint', parseInt(e.target.value, 10))}
                    className="w-full accent-pink-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />
                </div>

                <div className="h-px bg-[#141E33]" />

                {/* Tone Range / Highlights & Shadows */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Highlights Recovery</span>
                    <span className="font-mono text-cyan-300">{state.primary.highlights}</span>
                  </div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={state.primary.highlights}
                    onChange={e => updatePrimary('highlights', parseInt(e.target.value, 10))}
                    className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Shadows Lift</span>
                    <span className="font-mono text-cyan-300">{state.primary.shadows}</span>
                  </div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={state.primary.shadows}
                    onChange={e => updatePrimary('shadows', parseInt(e.target.value, 10))}
                    className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Saturation & Vibrance</span>
                    <span className="font-mono text-cyan-300">{state.primary.saturation.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="2.0"
                    step="0.02"
                    value={state.primary.saturation}
                    onChange={e => updatePrimary('saturation', parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />

                  <div className="flex justify-between items-center text-neutral-300">
                    <span className="font-mono text-[11px]">Midtone Micro-Detail</span>
                    <span className="font-mono text-cyan-300">{state.primary.midtoneDetail}</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={state.primary.midtoneDetail}
                    onChange={e => updatePrimary('midtoneDetail', parseInt(e.target.value, 10))}
                    className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                  />
                </div>
              </div>
            )}

            {/* 2. 3-WAY COLOR WHEELS */}
            {activeSubTab === 'wheels' && (
              <div className="space-y-4">
                <div className="text-[11px] font-mono text-neutral-400">
                  Three-Way Lift (Shadows), Gamma (Midtones), Gain (Highlights), and Offset (Pedestal).
                </div>

                {(['lift', 'gamma', 'gain', 'offset'] as const).map(wName => {
                  const w = state.primary.wheels[wName];
                  return (
                    <div key={wName} className="bg-[#0A0F1E] border border-[#141E33] rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono uppercase font-bold text-xs text-white">
                          {wName}
                        </span>
                        <span className="text-[10px] font-mono text-cyan-300">
                          θ: {w.angleDeg}° | Mag: {(w.magnitude * 100).toFixed(0)}% | Luma: {w.masterLuma.toFixed(2)}
                        </span>
                      </div>

                      {/* Hue Angle Slider */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-neutral-400">
                          <span>Hue Angle (0°-360°)</span>
                          <span>{w.angleDeg}°</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="360"
                          value={w.angleDeg}
                          onChange={e => updateWheel(wName, parseInt(e.target.value, 10), w.magnitude, w.masterLuma)}
                          className="w-full h-1.5 rounded cursor-pointer bg-gradient-to-r from-red-500 via-green-500 via-blue-500 to-red-500"
                        />
                      </div>

                      {/* Magnitude / Strength */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-neutral-400">
                          <span>Saturation Shift</span>
                          <span>{(w.magnitude * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="0.5"
                          step="0.01"
                          value={w.magnitude}
                          onChange={e => updateWheel(wName, w.angleDeg, parseFloat(e.target.value), w.masterLuma)}
                          className="w-full accent-emerald-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                        />
                      </div>

                      {/* Master Luma Offset */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-neutral-400">
                          <span>Master Luma Level</span>
                          <span>{w.masterLuma.toFixed(2)}</span>
                        </div>
                        <input
                          type="range"
                          min="-0.5"
                          max="0.5"
                          step="0.01"
                          value={w.masterLuma}
                          onChange={e => updateWheel(wName, w.angleDeg, w.magnitude, parseFloat(e.target.value))}
                          className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* 3. CURVES ENGINE */}
            {activeSubTab === 'curves' && (
              <div className="space-y-4">
                {/* Curve Selector */}
                <div className="flex bg-[#0D1527] border border-[#18233C] rounded p-1 gap-1">
                  {(['master', 'red', 'green', 'blue', 'luma'] as const).map(c => (
                    <button
                      key={c}
                      onClick={() => setActiveCurveChannel(c)}
                      className={`flex-1 py-1 text-[10px] font-mono uppercase font-bold rounded transition-colors ${
                        activeCurveChannel === c
                          ? c === 'red' ? 'bg-red-950/80 text-red-300 border border-red-800'
                          : c === 'green' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                          : c === 'blue' ? 'bg-blue-950/80 text-blue-300 border border-blue-800'
                          : 'bg-neutral-800 text-white'
                          : 'text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>

                {/* Interactive SVG Curve Canvas */}
                <div className="bg-[#03060E] border border-[#18233C] rounded-lg p-3 relative aspect-square flex items-center justify-center">
                  <svg
                    viewBox="0 0 200 200"
                    className="w-full h-full cursor-crosshair"
                    onClick={e => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                      const y = Math.max(0, Math.min(1, 1.0 - (e.clientY - rect.top) / rect.height));
                      addCurvePoint(activeCurveChannel, parseFloat(x.toFixed(2)), parseFloat(y.toFixed(2)));
                    }}
                  >
                    {/* Background Grid */}
                    <line x1="0" y1="50" x2="200" y2="50" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="0" y1="100" x2="200" y2="100" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="0" y1="150" x2="200" y2="150" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="50" y1="0" x2="50" y2="200" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="100" y1="0" x2="100" y2="200" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="150" y1="0" x2="150" y2="200" stroke="#141E33" strokeDasharray="3 3" />
                    <line x1="0" y1="200" x2="200" y2="0" stroke="#1E2B48" strokeWidth="1" />

                    {/* Evaluated Curve Path */}
                    {(() => {
                      const pts = state.curves[activeCurveChannel];
                      let pathStr = 'M 0 200 ';
                      for (let i = 0; i <= 200; i += 4) {
                        const nx = i / 200.0;
                        const ny = curvesEngine.evaluateCurve(pts, nx);
                        const sy = 200 - ny * 200;
                        pathStr += `L ${i} ${sy} `;
                      }
                      const strokeColor =
                        activeCurveChannel === 'red' ? '#ef4444' :
                        activeCurveChannel === 'green' ? '#10b981' :
                        activeCurveChannel === 'blue' ? '#3b82f6' :
                        activeCurveChannel === 'luma' ? '#fbbf24' : '#ffffff';

                      return (
                        <path d={pathStr} fill="none" stroke={strokeColor} strokeWidth="2" />
                      );
                    })()}

                    {/* Render Control Points */}
                    {state.curves[activeCurveChannel].map((p, idx) => (
                      <circle
                        key={idx}
                        cx={p.x * 200}
                        cy={200 - p.y * 200}
                        r="4.5"
                        fill="#00F0FF"
                        stroke="#000000"
                        strokeWidth="1.5"
                      />
                    ))}
                  </svg>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-neutral-500 font-mono">
                    Click graph to add point. Fritsch-Carlson monotone spline active.
                  </span>
                  <button
                    onClick={resetCurves}
                    className="px-2 py-1 bg-[#0D1527] border border-[#18233C] rounded text-[10px] font-mono text-neutral-300"
                  >
                    Reset Curves
                  </button>
                </div>
              </div>
            )}

            {/* 4. LOOKS & FILM EMULATION */}
            {activeSubTab === 'looks' && (
              <div className="space-y-3">
                <div className="text-[11px] font-mono text-neutral-400">
                  Deterministic cinematic film stock transforms with skin-tone protection corridor.
                </div>

                <div className="space-y-2">
                  {(Object.keys(LookManagementEngine.LOOKS) as LookPresetType[]).map(lKey => {
                    const l = LookManagementEngine.LOOKS[lKey];
                    const isSelected = state.lookPreset === lKey;
                    return (
                      <button
                        key={lKey}
                        onClick={() => selectLook(lKey)}
                        className={`w-full p-2.5 rounded-lg border text-left transition-all ${
                          isSelected
                            ? 'bg-emerald-950/70 border-emerald-500 text-white'
                            : 'bg-[#0A0F1E] border-[#141E33] text-neutral-300 hover:border-neutral-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold font-mono text-xs">{l.name}</span>
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#121B30] text-neutral-400 font-mono">
                            {l.category}
                          </span>
                        </div>
                        <div className="text-[10px] text-neutral-400 mt-1 leading-relaxed">
                          {l.description}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 5. FILM GRAIN & TEXTURE */}
            {activeSubTab === 'grain' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-[#0A0F1E] border border-[#141E33] p-3 rounded-lg">
                  <div>
                    <div className="font-mono font-bold text-xs text-white">Procedural Film Grain</div>
                    <div className="text-[10px] text-neutral-400">Luma-weighted physical negative noise</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={state.filmGrain.enabled}
                    onChange={e => setState(p => ({ ...p, filmGrain: { ...p.filmGrain, enabled: e.target.checked } }))}
                    className="w-4 h-4 accent-emerald-500"
                  />
                </div>

                {state.filmGrain.enabled && (
                  <div className="space-y-3 bg-[#0A0F1E] border border-[#141E33] p-3 rounded-lg">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-neutral-300 font-mono">
                        <span>Grain Intensity</span>
                        <span>{(state.filmGrain.intensity * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.02"
                        value={state.filmGrain.intensity}
                        onChange={e => setState(p => ({ ...p, filmGrain: { ...p.filmGrain, intensity: parseFloat(e.target.value) } }))}
                        className="w-full accent-emerald-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-neutral-300 font-mono">Film Format Stock Size</label>
                      <div className="grid grid-cols-3 gap-1">
                        {(['16mm', '35mm', '65mm'] as const).map(fmt => (
                          <button
                            key={fmt}
                            onClick={() => setState(p => ({ ...p, filmGrain: { ...p.filmGrain, format: fmt } }))}
                            className={`py-1 text-[11px] font-mono rounded border ${
                              state.filmGrain.format === fmt
                                ? 'bg-emerald-950 border-emerald-500 text-white font-bold'
                                : 'bg-[#060A14] border-[#141E33] text-neutral-400'
                            }`}
                          >
                            {fmt}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 6. OPTICAL FINISH */}
            {activeSubTab === 'optical' && (
              <div className="space-y-4">
                {/* Vignette */}
                <div className="bg-[#0A0F1E] border border-[#141E33] p-3 rounded-lg space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-xs text-white">Optical Lens Vignette</span>
                    <input
                      type="checkbox"
                      checked={state.opticalFinish.vignetteEnabled}
                      onChange={e => setState(p => ({ ...p, opticalFinish: { ...p.opticalFinish, vignetteEnabled: e.target.checked } }))}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </div>
                  {state.opticalFinish.vignetteEnabled && (
                    <div className="space-y-2 pt-1">
                      <div className="flex justify-between text-[10px] text-neutral-400 font-mono">
                        <span>Vignette Amount</span>
                        <span>{(state.opticalFinish.vignetteAmount * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="0.8"
                        step="0.02"
                        value={state.opticalFinish.vignetteAmount}
                        onChange={e => setState(p => ({ ...p, opticalFinish: { ...p.opticalFinish, vignetteAmount: parseFloat(e.target.value) } }))}
                        className="w-full accent-cyan-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                      />
                    </div>
                  )}
                </div>

                {/* Bloom & Halation */}
                <div className="bg-[#0A0F1E] border border-[#141E33] p-3 rounded-lg space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-xs text-white">Highlight Bloom & Halation</span>
                    <input
                      type="checkbox"
                      checked={state.opticalFinish.bloomEnabled}
                      onChange={e => setState(p => ({ ...p, opticalFinish: { ...p.opticalFinish, bloomEnabled: e.target.checked } }))}
                      className="w-4 h-4 accent-emerald-500"
                    />
                  </div>
                  {state.opticalFinish.bloomEnabled && (
                    <div className="space-y-2 pt-1">
                      <div className="flex justify-between text-[10px] text-neutral-400 font-mono">
                        <span>Bloom Glow Intensity</span>
                        <span>{(state.opticalFinish.bloomIntensity * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="0.5"
                        step="0.02"
                        value={state.opticalFinish.bloomIntensity}
                        onChange={e => setState(p => ({ ...p, opticalFinish: { ...p.opticalFinish, bloomIntensity: parseFloat(e.target.value) } }))}
                        className="w-full accent-amber-400 h-1.5 bg-[#141E33] rounded cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
