import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Formula } from '../../types';
import { Bookmark, Calculator, ArrowUpRight, Copy, Check, Share2, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ShareModal } from './ShareModal';

interface FormulaCardProps {
  formula: Formula;
  isFavorite?: boolean;
  onFavoriteChange?: (formulaId: string, isFav: boolean) => void;
}

export const FormulaCard: React.FC<FormulaCardProps> = ({
  formula,
  onFavoriteChange
}) => {
  const { isFavorite, toggleFavorite, showToast, playSound, triggerHaptic } = useApp();
  const navigate = useNavigate();

  const isFav = isFavorite(formula.id);
  const [copied, setCopied] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  const handleToggleFav = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const nextState = toggleFavorite(formula.id);
    showToast(nextState ? `Saved ${formula.title} to favorites` : 'Removed from favorites');
    onFavoriteChange?.(formula.id, nextState);
  };

  const copyFormulaText = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(`${formula.title}: ${formula.formula}`);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Formula copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Failed to copy', 'error');
    }
  };

  const openShare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    playSound('button');
    setShareOpen(true);
  };

  const difficultyColors = {
    Beginner: 'bg-[#232323] text-[#72A65A] border-[#303030]',
    Intermediate: 'bg-[#232323] text-[#E87535] border-[#303030]',
    Advanced: 'bg-[#232323] text-[#D65A1F] border-[#303030]'
  };

  return (
    <>
      <div className="group relative flex flex-col justify-between rounded-2xl bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F]/60 p-5 transition-all duration-200 shadow-sm">
        <div>
          {/* Header row: category, difficulty, favorite */}
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-mono uppercase tracking-wider font-semibold text-[#D65A1F] bg-[#232323] border border-[#303030] px-2 py-0.5 rounded-md">
                {formula.category}
              </span>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded-md border font-medium ${
                  difficultyColors[formula.difficulty] || difficultyColors.Beginner
                }`}
              >
                {formula.difficulty}
              </span>
              {formula.featured && (
                <span className="flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-[#232323] text-[#E87535] border border-[#303030]">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Featured</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={copyFormulaText}
                className="p-1.5 rounded-lg text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#232323] transition-colors"
                title="Copy Formula"
                aria-label="Copy Formula"
              >
                {copied ? <Check className="w-4 h-4 text-[#72A65A]" /> : <Copy className="w-4 h-4" />}
              </button>

              <button
                onClick={openShare}
                className="p-1.5 rounded-lg text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#232323] transition-colors"
                title="Share Formula"
                aria-label="Share Formula"
              >
                <Share2 className="w-4 h-4" />
              </button>

              <button
                onClick={handleToggleFav}
                className={`p-1.5 rounded-lg border transition-colors ${
                  isFav
                    ? 'text-[#D65A1F] bg-[#232323] border-[#D65A1F]'
                    : 'text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#232323] border-transparent'
                }`}
                title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                aria-label="Toggle favorite"
              >
                <Bookmark className="w-4 h-4" fill={isFav ? '#D65A1F' : 'none'} />
              </button>
            </div>
          </div>

          {/* Formula Title */}
          <Link
            to={`/formula/${formula.id}`}
            onClick={() => playSound('tab')}
            className="block group-hover:text-[#D65A1F] transition-colors"
          >
            <h3 className="text-base font-bold text-[#F5F2ED] tracking-tight leading-snug mb-1">
              {formula.title}
            </h3>
          </Link>

          <p className="text-xs text-[#A9A39C] line-clamp-2 mb-4 leading-relaxed">
            {formula.description}
          </p>

          {/* Math Expression Box */}
          <Link
            to={`/calculator/${formula.id}`}
            onClick={() => playSound('tab')}
            className="block p-3.5 rounded-xl bg-[#151515] border border-[#303030] font-mono text-center mb-4 hover:border-[#D65A1F]/50 transition-colors"
          >
            <div className="text-base font-bold text-[#D65A1F] tracking-wider">
              {formula.formula}
            </div>
            <div className="text-[10px] text-[#A9A39C] mt-1 flex items-center justify-center gap-1 font-sans">
              <span>Result:</span>
              <span className="font-mono text-[#F5F2ED]">{formula.resultVariable} ({formula.resultUnit})</span>
            </div>
          </Link>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#303030]">
          <Link
            to={`/formula/${formula.id}`}
            onClick={() => playSound('tab')}
            className="text-xs font-semibold text-[#A9A39C] hover:text-[#F5F2ED] flex items-center gap-1 transition-colors"
          >
            <span>Derivation & Usage</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>

          <button
            onClick={() => {
              playSound('tab');
              navigate(`/calculator/${formula.id}`);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#232323] hover:bg-[#D65A1F] hover:border-[#D65A1F] border border-[#303030] text-[#F5F2ED] text-xs font-semibold transition-all shadow-sm group/btn"
          >
            <Calculator className="w-3.5 h-3.5 text-[#D65A1F] group-hover/btn:text-[#F5F2ED]" />
            <span>Calculate</span>
          </button>
        </div>
      </div>

      <ShareModal
        isOpen={shareOpen}
        onClose={() => setShareOpen(false)}
        title={formula.title}
        formulaText={formula.formula}
        url={`${window.location.origin}/formula/${formula.id}`}
      />
    </>
  );
};
