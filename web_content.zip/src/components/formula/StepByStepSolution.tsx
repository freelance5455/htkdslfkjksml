import React, { useState } from 'react';
import { Copy, Check, Sparkles, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface StepByStepSolutionProps {
  steps: string[];
  formulaTitle?: string;
  resultVariable?: string;
  resultValue?: string;
  resultUnit?: string;
}

export const StepByStepSolution: React.FC<StepByStepSolutionProps> = ({
  steps,
  formulaTitle
}) => {
  const { showToast, playSound, triggerHaptic } = useApp();
  const [copied, setCopied] = useState(false);

  if (!steps || steps.length === 0) return null;

  const copySteps = async () => {
    try {
      const text = steps.join('\n');
      await navigator.clipboard.writeText(text);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Step-by-step solution copied!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Failed to copy steps', 'error');
    }
  };

  return (
    <div className="rounded-2xl border border-[#303030] bg-[#151515] p-5">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#303030]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#232323] border border-[#303030] flex items-center justify-center text-[#D65A1F]">
            <Sparkles className="w-4 h-4 text-[#D65A1F]" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#F5F2ED] tracking-tight">Step-by-Step Derivation</h4>
            {formulaTitle && <p className="text-[11px] text-[#A9A39C]">{formulaTitle}</p>}
          </div>
        </div>

        <button
          onClick={copySteps}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-[#F5F2ED] hover:bg-[#232323] bg-[#1C1C1C] border border-[#303030] transition-colors"
          title="Copy solution steps"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied' : 'Copy Steps'}</span>
        </button>
      </div>

      <div className="space-y-3 font-mono text-xs">
        {steps.map((step, idx) => {
          const colonIndex = step.indexOf(':');
          const stepLabel = colonIndex !== -1 ? step.substring(0, colonIndex).trim() : `Step ${idx + 1}`;
          const stepBody = colonIndex !== -1 ? step.substring(colonIndex + 1).trim() : step;
          const isAnswer = stepLabel.toLowerCase().includes('answer');

          return (
            <div
              key={idx}
              className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 transition-all ${
                isAnswer
                  ? 'bg-[#232323] border-[#D65A1F]/50 text-[#F5F2ED] font-bold'
                  : 'bg-[#1C1C1C] border-[#303030] text-[#A9A39C]'
              }`}
            >
              <div className="flex items-center gap-2 shrink-0">
                <span className="w-5 h-5 rounded-md bg-[#232323] border border-[#303030] text-[#D65A1F] text-[10px] flex items-center justify-center font-bold">
                  {idx + 1}
                </span>
                <span className={`text-[11px] uppercase tracking-wider ${isAnswer ? 'text-[#D65A1F]' : 'text-[#A9A39C]'}`}>
                  {stepLabel}
                </span>
              </div>
              <div className={`text-xs sm:text-right font-mono ${isAnswer ? 'text-[#D65A1F] text-sm' : 'text-[#F5F2ED]'}`}>
                {stepBody}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
