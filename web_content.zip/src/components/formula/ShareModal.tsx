import React, { useState } from 'react';
import { Copy, Check, Share2, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  formulaText: string;
  url?: string;
  stepsText?: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  title,
  formulaText,
  url,
  stepsText
}) => {
  const { showToast, playSound, triggerHaptic } = useApp();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareUrl = url || window.location.href;
  const fullSharePayload = `${title}\n${formulaText}\n${stepsText ? `\nSolution:\n${stepsText}\n` : ''}\nFormulaX Pro: ${shareUrl}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(fullSharePayload);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Formula details copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Could not copy to clipboard', 'error');
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: `${title} — ${formulaText}`,
          url: shareUrl
        });
        playSound('button');
      } catch {
        // User cancelled or share failed
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-3xl bg-[#1C1C1C] border border-[#303030] p-6 shadow-2xl">
        <button
          onClick={() => {
            playSound('button');
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#232323] transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-bold text-[#F5F2ED] mb-1 flex items-center gap-2">
          <Share2 className="w-5 h-5 text-[#D65A1F]" />
          <span>Share Equation</span>
        </h3>
        <p className="text-xs text-[#A9A39C] mb-4">{title}</p>

        <div className="bg-[#151515] border border-[#303030] rounded-2xl p-4 mb-5 font-mono text-xs select-all overflow-x-auto">
          <p className="font-semibold text-[#F5F2ED] mb-1">{title}</p>
          <p className="text-sm font-bold text-[#D65A1F] mb-2">{formulaText}</p>
          <p className="text-[11px] text-[#A9A39C] truncate">{shareUrl}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#232323] hover:bg-[#303030] border border-[#303030] text-[#F5F2ED] text-xs font-bold transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-[#72A65A]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] text-xs font-bold transition-colors cursor-pointer shadow-md"
          >
            <Share2 className="w-4 h-4" />
            <span>Share Link</span>
          </button>
        </div>
      </div>
    </div>
  );
};
