import React, { useState, useEffect } from 'react';
import { useGame } from '../context/GameContext';

interface VentureIconProps {
  ventureId: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  overrideUrl?: string;
  forceVector?: boolean;
}

/**
 * Rich, stylized fantasy RPG icons for all Kingdom Ventures.
 * Supports custom uploaded .jpg image icons with live fallback to
 * hand-crafted layered vector graphics with rich gradients.
 */
export function VentureIcon({
  ventureId,
  className = '',
  size = 'md',
  overrideUrl,
  forceVector = false,
}: VentureIconProps) {
  const { customIcons } = useGame();
  const [imgError, setImgError] = useState(false);

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-full h-full',
    lg: 'w-16 h-16',
  }[size];

  const activeCustom = overrideUrl
    ? { url: overrideUrl }
    : !forceVector && customIcons && customIcons[ventureId];

  const imgUrl = activeCustom ? activeCustom.url : null;
  useEffect(() => {
    setImgError(false);
  }, [imgUrl]);

  if (activeCustom && activeCustom.url && !imgError) {
    return (
      <div
        className={`${sizeClasses} ${className} relative overflow-hidden rounded-xl border border-amber-500/30 shadow-inner bg-slate-900 shrink-0 flex items-center justify-center`}
      >
        <img
          src={activeCustom.url}
          alt={`${ventureId} icon`}
          className="w-full h-full object-cover rounded-xl"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
        />
        {/* Subtle fantasy vignette ring */}
        <div className="absolute inset-0 rounded-xl pointer-events-none ring-1 ring-inset ring-amber-400/25 shadow-[inset_0_0_8px_rgba(0,0,0,0.5)]" />
      </div>
    );
  }

  switch (ventureId) {
    case 'mana_herbs':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            {/* Ambient Magical Garden Glow */}
            <radialGradient id="mana-plot-glow" cx="50%" cy="45%" r="52%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.45" />
              <stop offset="60%" stopColor="#047857" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#022c22" stopOpacity="0" />
            </radialGradient>

            {/* Planter Heartwood Border */}
            <linearGradient id="plot-wood" x1="10" y1="42" x2="54" y2="58" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#78350f" />
              <stop offset="50%" stopColor="#92400e" />
              <stop offset="100%" stopColor="#451a03" />
            </linearGradient>

            {/* Planter Golden / Brass Bracket Trim */}
            <linearGradient id="plot-gold-trim" x1="12" y1="40" x2="52" y2="56" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="40%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>

            {/* Enchanted Rich Dark Loam Soil */}
            <radialGradient id="plot-rich-soil" cx="50%" cy="40%" r="55%">
              <stop offset="0%" stopColor="#3f2716" />
              <stop offset="65%" stopColor="#24140b" />
              <stop offset="100%" stopColor="#140a05" />
            </radialGradient>

            {/* Luminescent Emerald & Cyan Leaf Gradients */}
            <linearGradient id="mana-leaf-main" x1="14" y1="12" x2="50" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#a7f3d0" />
              <stop offset="35%" stopColor="#34d399" />
              <stop offset="75%" stopColor="#059669" />
              <stop offset="100%" stopColor="#064e3b" />
            </linearGradient>
            <linearGradient id="mana-leaf-cyan" x1="48" y1="14" x2="20" y2="46" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#67e8f9" />
              <stop offset="45%" stopColor="#14b8a6" />
              <stop offset="100%" stopColor="#0f766e" />
            </linearGradient>
            <linearGradient id="stem-growth" x1="32" y1="20" x2="32" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#6ee7b7" />
              <stop offset="50%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#065f46" />
            </linearGradient>

            {/* Bloom / Glow Filter */}
            <filter id="plot-spore-glow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background Ambient Radiance */}
          <circle cx="32" cy="32" r="28" fill="url(#mana-plot-glow)" />

          {/* ================= ENCHANTED SOIL PLOT & PLANTER BED ================= */}
          {/* Planter Base Shadow */}
          <ellipse cx="32" cy="55" rx="22" ry="5.5" fill="#000000" opacity="0.45" />

          {/* Raised Wooden Planter Box (Front & Sides) */}
          <path
            d="M10 44 L32 50 L54 44 L54 52 L32 58 L10 52 Z"
            fill="url(#plot-wood)"
            stroke="#451a03"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
          {/* Planter Front Bevel Plank Seam */}
          <path d="M32 50 L32 58" stroke="#451a03" strokeWidth="1.5" />
          <path d="M10 48 L32 54 L54 48" stroke="#78350f" strokeWidth="0.8" opacity="0.7" />

          {/* Planter Bed Rim (Top Rim) */}
          <polygon
            points="10,44 32,50 54,44 32,38"
            fill="url(#plot-wood)"
            stroke="url(#plot-gold-trim)"
            strokeWidth="1.2"
          />

          {/* Enchanted Soil Mound inside the Plot */}
          <ellipse
            cx="32"
            cy="43.5"
            rx="19"
            ry="5.5"
            fill="url(#plot-rich-soil)"
            stroke="#1a0e07"
            strokeWidth="0.8"
          />

          {/* Glowing Arcane Fertilizer Runes on Soil */}
          <path
            d="M23 43.5 Q27 45 32 44.5 Q37 44 41 43.5"
            stroke="#10b981"
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.65"
          />
          <circle cx="26" cy="43.5" r="1.1" fill="#6ee7b7" opacity="0.8" />
          <circle cx="38" cy="43" r="1.1" fill="#6ee7b7" opacity="0.8" />

          {/* Golden Corner Reinforcements on Planter Box */}
          <path d="M10 44 L14 45.2 L14 51.5 L10 50 Z" fill="url(#plot-gold-trim)" />
          <path d="M54 44 L50 45.2 L50 51.5 L54 50 Z" fill="url(#plot-gold-trim)" />
          <path d="M30 49.5 L32 50 L34 49.5 L34 57.5 L32 58 L30 57.5 Z" fill="url(#plot-gold-trim)" />
          {/* Rivets on Center Bracket */}
          <circle cx="32" cy="52" r="0.8" fill="#fef08a" />
          <circle cx="32" cy="56" r="0.8" fill="#fef08a" />

          {/* ================= VIBRANT MANA HERB VEGETATION ================= */}
          {/* Main Central Mana Herb Stems */}
          <path
            d="M32 43 Q30 35 32 24"
            stroke="url(#stem-growth)"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          <path
            d="M31 38 Q22 34 18 27"
            stroke="url(#stem-growth)"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path
            d="M33 37 Q42 34 46 26"
            stroke="url(#stem-growth)"
            strokeWidth="2.2"
            strokeLinecap="round"
          />

          {/* Left Moon-Thistle Leaf (Broad & Pointed) */}
          <path
            d="M31 38 C17 37 10 27 12 17 C21 18 28 27 31 36 Z"
            fill="url(#mana-leaf-main)"
            filter="drop-shadow(0 2px 3px rgba(0,0,0,0.5))"
          />
          <path
            d="M13 19 Q20 25 30 35"
            stroke="#d1fae5"
            strokeWidth="1.3"
            strokeLinecap="round"
            opacity="0.85"
          />

          {/* Right Solar-Clover Leaf (Vibrant Cyan-Emerald) */}
          <path
            d="M33 37 C47 36 54 26 52 16 C43 17 36 26 33 35 Z"
            fill="url(#mana-leaf-cyan)"
            filter="drop-shadow(0 2px 3px rgba(0,0,0,0.5))"
          />
          <path
            d="M51 18 Q44 25 34 35"
            stroke="#a7f3d0"
            strokeWidth="1.3"
            strokeLinecap="round"
            opacity="0.85"
          />

          {/* Center Royal Mana Bud / Crown Sprout */}
          <path
            d="M32 10 C38 18 36 28 32 33 C28 28 26 18 32 10 Z"
            fill="url(#mana-leaf-main)"
            filter="url(#plot-spore-glow)"
          />
          {/* Bud Spine */}
          <path
            d="M32 11 L32 30"
            stroke="#ecfdf5"
            strokeWidth="1.5"
            strokeLinecap="round"
          />

          {/* Emerging Lower Sprouts / Small Leaflets */}
          <path
            d="M30 41 C24 40 21 37 20 34 C25 34 28 38 30 41 Z"
            fill="#34d399"
            opacity="0.9"
          />
          <path
            d="M34 41 C40 40 43 37 44 34 C39 34 36 38 34 41 Z"
            fill="#34d399"
            opacity="0.9"
          />

          {/* ================= LUMINESCENT DEW & STARLIGHT SPORES ================= */}
          {/* Radiant Mana Droplets on Leaf Tips */}
          <circle cx="32" cy="11" r="2.2" fill="#ffffff" filter="drop-shadow(0 0 3px #34d399)" />
          <circle cx="13" cy="20" r="1.6" fill="#ecfdf5" filter="drop-shadow(0 0 2px #10b981)" />
          <circle cx="51" cy="19" r="1.6" fill="#ecfdf5" filter="drop-shadow(0 0 2px #06b6d4)" />
          <circle cx="21" cy="28" r="1.3" fill="#6ee7b7" />
          <circle cx="43" cy="28" r="1.3" fill="#6ee7b7" />

          {/* Ethereal Floating Mana Spores */}
          <circle cx="20" cy="12" r="1.2" fill="#a7f3d0" opacity="0.85" filter="drop-shadow(0 0 2px #34d399)" />
          <circle cx="44" cy="11" r="1.2" fill="#67e8f9" opacity="0.85" filter="drop-shadow(0 0 2px #22d3ee)" />
          <circle cx="28" cy="5" r="1.4" fill="#ffffff" opacity="0.9" filter="drop-shadow(0 0 3px #10b981)" />
          <circle cx="37" cy="6" r="1.2" fill="#d1fae5" opacity="0.85" />

          {/* Brilliant 4-Point Starlight Sparkles */}
          <path
            d="M32 3 L33 6.5 L36.5 7.5 L33 8.5 L32 12 L31 8.5 L27.5 7.5 L31 6.5 Z"
            fill="#ffffff"
            filter="drop-shadow(0 0 4px #34d399)"
          />
          <path
            d="M48 33 L49 35 L51 35.8 L49 36.6 L48 38.6 L47 36.6 L45 35.8 L47 35 Z"
            fill="#a7f3d0"
            opacity="0.9"
          />
          <path
            d="M16 35 L17 37 L19 37.8 L17 38.6 L16 40.6 L15 38.6 L13 37.8 L15 37 Z"
            fill="#a7f3d0"
            opacity="0.9"
          />
        </svg>
      );

    case 'potion_brewery':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="potion-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#083344" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="potion-liquid" x1="32" y1="28" x2="32" y2="54" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#0369a1" />
            </linearGradient>
            <linearGradient id="glass-rim" x1="24" y1="10" x2="40" y2="10" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#bae6fd" />
              <stop offset="100%" stopColor="#38bdf8" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#potion-glow)" />

          {/* Cork & Golden Stopper */}
          <path d="M28 10 H36 V14 H28 Z" fill="#d97706" rx="1" />
          <path d="M26 14 H38 V17 H26 Z" fill="url(#glass-rim)" rx="1.5" />

          {/* Flask Neck */}
          <path d="M28 17 H36 V26 H28 Z" fill="#38bdf8" opacity="0.25" stroke="#7dd3fc" strokeWidth="1.5" />

          {/* Flask Bulbous Body */}
          <path
            d="M28 26 L18 43 C15 49 19 56 26 56 H38 C45 56 49 49 46 43 L36 26 Z"
            fill="#0c4a6e"
            opacity="0.5"
            stroke="#38bdf8"
            strokeWidth="2"
            strokeLinejoin="round"
          />

          {/* Glowing Liquid Filling */}
          <path
            d="M20 44 C22 40 28 37 32 37 C36 37 42 40 44 44 C46 49 43 54 38 54 H26 C21 54 18 49 20 44 Z"
            fill="url(#potion-liquid)"
          />

          {/* Liquid Wave Highlight & Swirl */}
          <path
            d="M21 43 Q26 40 32 42 T43 43"
            stroke="#bae6fd"
            strokeWidth="1.8"
            strokeLinecap="round"
          />

          {/* Bubbles */}
          <circle cx="28" cy="46" r="2" fill="#e0f2fe" opacity="0.9" />
          <circle cx="35" cy="48" r="1.5" fill="#e0f2fe" opacity="0.8" />
          <circle cx="32" cy="30" r="1.8" fill="#38bdf8" opacity="0.9" />
          <circle cx="30" cy="22" r="1.3" fill="#bae6fd" opacity="0.8" />

          {/* Glass Specular Glare */}
          <path
            d="M22 36 L20 42 C19 45 20 49 22 51"
            stroke="#ffffff"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.6"
          />
        </svg>
      );

    case 'dwarven_forge':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="forge-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#78350f" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="hammer-metal" x1="18" y1="12" x2="46" y2="30" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef3c7" />
              <stop offset="30%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>
            <linearGradient id="anvil-metal" x1="16" y1="40" x2="48" y2="58" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#94a3b8" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#forge-glow)" />

          {/* Sturdy Anvil Base */}
          <path
            d="M14 54 H50 L46 44 H38 L40 40 H24 L26 44 H18 Z"
            fill="url(#anvil-metal)"
            stroke="#cbd5e1"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
          <path d="M22 40 H42" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" />

          {/* Molten Strike Flash */}
          <circle cx="32" cy="39" r="6" fill="#fbbf24" opacity="0.6" filter="blur(2px)" />

          {/* Dwarven Runic Warhammer (Diagonal Strike Angle) */}
          <g transform="rotate(-30 32 30)">
            {/* Wooden/Leather Handle */}
            <rect x="30" y="14" width="4" height="28" rx="2" fill="#78350f" stroke="#451a03" strokeWidth="1" />
            <path d="M30 20 H34 M30 24 H34 M30 28 H34" stroke="#d97706" strokeWidth="1" />
            <circle cx="32" cy="42" r="3" fill="#b45309" />

            {/* Heavy Hammer Head */}
            <path
              d="M22 8 H42 V20 H22 Z"
              fill="url(#hammer-metal)"
              stroke="#fbbf24"
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
            {/* Glowing Runic Carvings */}
            <path d="M26 14 H38 M32 10 V18" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
          </g>

          {/* Flying Mithril Sparks */}
          <circle cx="24" cy="32" r="1.5" fill="#fef08a" />
          <circle cx="40" cy="33" r="1.8" fill="#f59e0b" />
          <circle cx="38" cy="24" r="1.2" fill="#fbbf24" />
          <circle cx="22" cy="25" r="1.2" fill="#fef08a" />
          <path d="M30 36 L26 31 M34 36 L39 31 M32 34 L32 28" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'goblin_vaults':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="vault-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#eab308" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#713f12" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="chest-wood" x1="14" y1="26" x2="50" y2="52" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#854d0e" />
              <stop offset="100%" stopColor="#451a03" />
            </linearGradient>
            <linearGradient id="chest-gold" x1="14" y1="20" x2="50" y2="40" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#eab308" />
              <stop offset="100%" stopColor="#a16207" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#vault-glow)" />

          {/* Treasure Chest Body */}
          <path
            d="M14 30 H50 V50 C50 52 48 54 46 54 H18 C16 54 14 52 14 50 Z"
            fill="url(#chest-wood)"
            stroke="#713f12"
            strokeWidth="1.5"
          />

          {/* Iron/Gold Studded Bands */}
          <rect x="18" y="30" width="6" height="24" fill="url(#chest-gold)" />
          <rect x="40" y="30" width="6" height="24" fill="url(#chest-gold)" />

          {/* Overflowing Gold Coins & Gems */}
          <ellipse cx="32" cy="27" rx="15" ry="6" fill="#fef08a" opacity="0.3" />
          <circle cx="28" cy="27" r="4.5" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
          <circle cx="36" cy="27" r="4.5" fill="#fde047" stroke="#ca8a04" strokeWidth="1" />
          <circle cx="32" cy="24" r="4.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
          {/* Emerald Gem */}
          <polygon points="32,18 36,22 32,26 28,22" fill="#10b981" stroke="#34d399" strokeWidth="1" />

          {/* Arched Open Lid */}
          <path
            d="M12 28 C12 18 20 14 32 14 C44 14 52 18 52 28 H12 Z"
            fill="url(#chest-wood)"
            stroke="#a16207"
            strokeWidth="1.5"
          />
          <path d="M19 15 C24 14 24 24 24 28 M45 15 C40 14 40 24 40 28" stroke="url(#chest-gold)" strokeWidth="3" />

          {/* Heavy Goblin Lock & Keyhole */}
          <rect x="28" y="33" width="8" height="10" rx="2" fill="url(#chest-gold)" stroke="#78350f" strokeWidth="1" />
          <circle cx="32" cy="37" r="1.5" fill="#451a03" />
          <path d="M32 38.5 V41" stroke="#451a03" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'griffin_aviary':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="griffin-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#1e1b4b" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="griffin-wing" x1="10" y1="14" x2="54" y2="46" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#e0e7ff" />
              <stop offset="40%" stopColor="#818cf8" />
              <stop offset="100%" stopColor="#4338ca" />
            </linearGradient>
            <linearGradient id="griffin-gold" x1="28" y1="20" x2="44" y2="36" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#f59e0b" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#griffin-glow)" />

          {/* Wind Swirl Rings */}
          <path d="M10 40 Q32 46 54 40" stroke="#a5b4fc" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />
          <path d="M16 46 Q32 50 48 46" stroke="#818cf8" strokeWidth="1.5" opacity="0.5" />

          {/* Left Wing Spread */}
          <path
            d="M30 32 C24 24 14 16 8 20 C10 28 16 34 22 38 C14 36 10 40 12 44 C18 45 26 42 30 38 Z"
            fill="url(#griffin-wing)"
            filter="drop-shadow(0 2px 4px rgba(0,0,0,0.5))"
          />

          {/* Right Wing Spread */}
          <path
            d="M34 32 C40 24 50 16 56 20 C54 28 48 34 42 38 C50 36 54 40 52 44 C46 45 38 42 34 38 Z"
            fill="url(#griffin-wing)"
            filter="drop-shadow(0 2px 4px rgba(0,0,0,0.5))"
          />

          {/* Griffin Head & Eagle Beak Silhouette */}
          <path
            d="M32 16 C36 16 40 20 40 25 C40 28 38 31 36 34 H28 C26 31 24 28 24 25 C24 20 28 16 32 16 Z"
            fill="#e0e7ff"
            stroke="#818cf8"
            strokeWidth="1.5"
          />
          {/* Golden Curved Eagle Beak */}
          <path d="M30 25 C32 23 35 24 37 27 C36 30 33 32 31 31 Z" fill="url(#griffin-gold)" stroke="#b45309" strokeWidth="1" />
          {/* Piercing Eye */}
          <circle cx="31" cy="22" r="1.5" fill="#f59e0b" />
          <circle cx="31" cy="22" r="0.7" fill="#0f172a" />

          {/* Majestic Crown Plume */}
          <path d="M30 16 L28 10 M32 16 L32 8 M34 16 L36 10" stroke="#facc15" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'arcane_spire':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="spire-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#a855f7" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#3b0764" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="spire-stone" x1="20" y1="20" x2="44" y2="56" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#c084fc" />
              <stop offset="50%" stopColor="#7e22ce" />
              <stop offset="100%" stopColor="#4c1d95" />
            </linearGradient>
            <linearGradient id="spire-crystal" x1="32" y1="8" x2="32" y2="22" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#f5d0fe" />
              <stop offset="100%" stopColor="#d946ef" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#spire-glow)" />

          {/* Orbiting Magical Rune Rings */}
          <ellipse cx="32" cy="24" rx="22" ry="7" stroke="#e879f9" strokeWidth="1.2" strokeDasharray="4 3" opacity="0.75" />
          <ellipse cx="32" cy="38" rx="20" ry="6" stroke="#c084fc" strokeWidth="1.2" opacity="0.6" />

          {/* Tower Bastion Base & Pillars */}
          <path
            d="M22 56 L26 34 H38 L42 56 Z"
            fill="url(#spire-stone)"
            stroke="#a855f7"
            strokeWidth="1.5"
          />

          {/* Tower Balcony / Corbel */}
          <path d="M24 34 H40 V30 H24 Z" fill="#6b21a8" stroke="#d8b4fe" strokeWidth="1" />

          {/* Tower Crown Arch */}
          <path d="M26 30 L32 20 L38 30 Z" fill="url(#spire-stone)" stroke="#c084fc" strokeWidth="1.5" />

          {/* Floating Levitating Apex Crystal */}
          <polygon
            points="32,7 37,16 32,22 27,16"
            fill="url(#spire-crystal)"
            stroke="#ffffff"
            strokeWidth="1.5"
            filter="drop-shadow(0 0 6px #d946ef)"
          />

          {/* Glowing Arcane Windows */}
          <rect x="30" y="40" width="4" height="8" rx="2" fill="#f5d0fe" filter="drop-shadow(0 0 4px #e879f9)" />
          <circle cx="32" cy="26" r="2" fill="#fdf4ff" />

          {/* Orbiting Arcane Runes */}
          <circle cx="16" cy="22" r="1.5" fill="#f5d0fe" />
          <circle cx="48" cy="26" r="1.5" fill="#f5d0fe" />
          <circle cx="44" cy="42" r="1.2" fill="#e879f9" />
          <circle cx="20" cy="36" r="1.2" fill="#e879f9" />
        </svg>
      );

    case 'dragon_roost':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="dragon-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#881337" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="dragon-scale" x1="16" y1="12" x2="48" y2="52" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fb7185" />
              <stop offset="50%" stopColor="#e11d48" />
              <stop offset="100%" stopColor="#9f1239" />
            </linearGradient>
            <linearGradient id="fire-grad" x1="32" y1="20" x2="32" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#dragon-glow)" />

          {/* Background Fire Embers Aura */}
          <path
            d="M32 10 Q40 22 46 28 Q40 36 32 52 Q24 36 18 28 Q24 22 32 10 Z"
            fill="url(#fire-grad)"
            opacity="0.3"
            filter="blur(3px)"
          />

          {/* Dragon Head / Skull Silhouette */}
          <path
            d="M32 14 C36 14 44 18 48 24 L42 28 L50 36 L40 40 L38 50 L32 54 L26 50 L24 40 L14 36 L22 28 L16 24 C20 18 28 14 32 14 Z"
            fill="url(#dragon-scale)"
            stroke="#fecdd3"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />

          {/* Fierce Horns Sweeping Upward */}
          <path d="M26 18 C22 12 16 8 10 10 C14 16 20 20 24 22" fill="#be123c" stroke="#f43f5e" strokeWidth="1.5" />
          <path d="M38 18 C42 12 48 8 54 10 C50 16 44 20 40 22" fill="#be123c" stroke="#f43f5e" strokeWidth="1.5" />

          {/* Glowing Amber/Yellow Eyes */}
          <polygon points="25,27 29,29 26,32" fill="#fde047" filter="drop-shadow(0 0 3px #f59e0b)" />
          <polygon points="39,27 35,29 38,32" fill="#fde047" filter="drop-shadow(0 0 3px #f59e0b)" />

          {/* Draconic Snout and Fire Flare */}
          <path d="M28 44 Q32 46 36 44" stroke="#f43f5e" strokeWidth="2" strokeLinecap="round" />
          <circle cx="30" cy="43" r="1.2" fill="#4c0519" />
          <circle cx="34" cy="43" r="1.2" fill="#4c0519" />

          {/* Flaming Breath Embers */}
          <circle cx="32" cy="48" r="2.5" fill="#fef08a" filter="drop-shadow(0 0 4px #f97316)" />
          <circle cx="28" cy="54" r="1.5" fill="#fb923c" />
          <circle cx="36" cy="54" r="1.5" fill="#fb923c" />
        </svg>
      );

    case 'astral_observatory':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="astral-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#2e1065" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="brass-astral" x1="16" y1="16" x2="48" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="40%" stopColor="#a855f7" />
              <stop offset="100%" stopColor="#6b21a8" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#astral-glow)" />

          {/* Outer Astrolabe/Armillary Ring */}
          <circle cx="32" cy="32" r="21" stroke="url(#brass-astral)" strokeWidth="2.5" />
          <circle cx="32" cy="32" r="23" stroke="#c4b5fd" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.6" />

          {/* Tilted Meridian Rings */}
          <ellipse cx="32" cy="32" rx="20" ry="9" transform="rotate(-35 32 32)" stroke="#a78bfa" strokeWidth="1.8" />
          <ellipse cx="32" cy="32" rx="20" ry="9" transform="rotate(35 32 32)" stroke="#c084fc" strokeWidth="1.8" />

          {/* Central Pulsing Cosmic Sun / Singularity */}
          <circle cx="32" cy="32" r="5" fill="#fdf4ff" filter="drop-shadow(0 0 6px #a855f7)" />
          <circle cx="32" cy="32" r="3" fill="#ffffff" />

          {/* Constellation Nodes and Pointer */}
          <line x1="32" y1="11" x2="32" y2="53" stroke="#ddd6fe" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="11" y1="32" x2="53" y2="32" stroke="#ddd6fe" strokeWidth="1" strokeDasharray="2 2" />

          {/* Glistening Stars on the Celestial Sphere */}
          <circle cx="20" cy="20" r="1.5" fill="#fef08a" filter="drop-shadow(0 0 2px #ffffff)" />
          <circle cx="44" cy="20" r="1.5" fill="#fef08a" filter="drop-shadow(0 0 2px #ffffff)" />
          <circle cx="22" cy="42" r="1.5" fill="#fef08a" />
          <circle cx="42" cy="42" r="1.5" fill="#fef08a" />
        </svg>
      );

    case 'titan_citadel':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="titan-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#134e4a" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="titan-stone" x1="16" y1="16" x2="48" y2="52" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#5eead4" />
              <stop offset="40%" stopColor="#0f766e" />
              <stop offset="100%" stopColor="#115e59" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#titan-glow)" />

          {/* Fortress Foundation Wall */}
          <path
            d="M12 54 L16 26 H24 L26 32 H38 L40 26 H48 L52 54 Z"
            fill="url(#titan-stone)"
            stroke="#2dd4bf"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />

          {/* Twin Watchtower Battlements */}
          <path d="M14 26 H22 V20 H14 Z M42 26 H50 V20 H42 Z" fill="#0d9488" stroke="#5eead4" strokeWidth="1.2" />
          <rect x="16" y="16" width="3" height="4" fill="#99f6e4" />
          <rect x="45" y="16" width="3" height="4" fill="#99f6e4" />

          {/* Center Runic Gateway Arches */}
          <path
            d="M26 54 V36 C26 33 29 30 32 30 C35 30 38 33 38 36 V54 Z"
            fill="#042f2e"
            stroke="#2dd4bf"
            strokeWidth="2"
          />

          {/* Energy Shield Barrier in the Gate */}
          <path
            d="M28 54 V37 C28 35 30 33 32 33 C34 33 36 35 36 37 V54 Z"
            fill="#14b8a6"
            opacity="0.6"
            filter="drop-shadow(0 0 6px #2dd4bf)"
          />

          {/* Titan Horn Crest Atop Citadel */}
          <path d="M28 24 L32 12 L36 24" stroke="#99f6e4" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="32" cy="22" r="2.5" fill="#f0fdfa" filter="drop-shadow(0 0 4px #2dd4bf)" />
        </svg>
      );

    case 'celestial_core':
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <defs>
            <radialGradient id="core-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.5" />
              <stop offset="60%" stopColor="#fbbf24" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#78350f" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="crown-gold" x1="16" y1="12" x2="48" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fffbeb" />
              <stop offset="35%" stopColor="#fef08a" />
              <stop offset="70%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>
          </defs>
          <circle cx="32" cy="32" r="28" fill="url(#core-glow)" />

          {/* Radiating Divine Sunburst Rays */}
          <g opacity="0.85">
            <line x1="32" y1="6" x2="32" y2="12" stroke="#fde047" strokeWidth="2" strokeLinecap="round" />
            <line x1="32" y1="52" x2="32" y2="58" stroke="#fde047" strokeWidth="2" strokeLinecap="round" />
            <line x1="6" y1="32" x2="12" y2="32" stroke="#fde047" strokeWidth="2" strokeLinecap="round" />
            <line x1="52" y1="32" x2="58" y2="32" stroke="#fde047" strokeWidth="2" strokeLinecap="round" />
            <line x1="14" y1="14" x2="18" y2="18" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="46" y1="46" x2="50" y2="50" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="50" y1="14" x2="46" y2="18" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="14" y1="50" x2="18" y2="46" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
          </g>

          {/* Double Divine Halo Rings */}
          <circle cx="32" cy="32" r="22" stroke="#fde047" strokeWidth="1" strokeDasharray="3 3" opacity="0.7" />
          <circle cx="32" cy="32" r="17" stroke="url(#crown-gold)" strokeWidth="1.8" />

          {/* Seraphic Feather Wings Framing the Core */}
          <path
            d="M32 44 C22 44 14 36 12 24 C18 25 24 30 28 36 Z"
            fill="url(#crown-gold)"
            opacity="0.9"
          />
          <path
            d="M32 44 C42 44 50 36 52 24 C46 25 40 30 36 36 Z"
            fill="url(#crown-gold)"
            opacity="0.9"
          />

          {/* Center Divine Diamond Core Prism */}
          <polygon
            points="32,18 42,32 32,46 22,32"
            fill="#ffffff"
            stroke="#fef08a"
            strokeWidth="2"
            filter="drop-shadow(0 0 8px #f59e0b)"
          />
          <polygon points="32,22 39,32 32,42 25,32" fill="#fef08a" opacity="0.75" />
          <circle cx="32" cy="32" r="3" fill="#ffffff" />
        </svg>
      );

    default:
      return (
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${sizeClasses} ${className}`}
        >
          <circle cx="32" cy="32" r="24" fill="#f59e0b" opacity="0.2" />
          <circle cx="32" cy="32" r="16" fill="#f59e0b" />
        </svg>
      );
  }
}
