/**
 * ui.js — small, dependency-free DOM-building helpers.
 * Kept intentionally framework-free: each function returns an HTMLElement.
 * This is the vanilla-JS equivalent of the Card/Button/Checklist/StatTile
 * components described in the blueprint's design system.
 */

export function el(tag, className, children = []) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  ([]).concat(children).forEach((child) => {
    if (child == null) return;
    node.append(typeof child === 'string' ? document.createTextNode(child) : child);
  });
  return node;
}

export function card(children, { tappable = false, onClick = null } = {}) {
  const node = el('div', `card${tappable ? ' card--tappable' : ''}`, children);
  if (onClick) node.addEventListener('click', onClick);
  return node;
}

export function sectionHeader(eyebrow, title) {
  return el('div', 'section-header', [
    el('h3', null, title),
    eyebrow ? el('span', 'eyebrow', eyebrow) : null,
  ]);
}

export function button(label, { variant = 'primary', block = false, onClick = null, size = null } = {}) {
  const classes = ['btn', `btn--${variant}`, block ? 'btn--block' : '', size ? `btn--${size}` : ''].join(' ').trim();
  const node = el('button', classes, label);
  if (onClick) node.addEventListener('click', onClick);
  return node;
}

const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';

export function checklistItem(label, checked, onToggle) {
  const item = el('div', `checklist-item${checked ? ' checklist-item--done' : ''}`);
  const box = el('div', `checkbox${checked ? ' checkbox--checked' : ''}`);
  box.innerHTML = CHECK_SVG;
  const labelEl = el('span', 'checklist-item__label', label);
  item.append(box, labelEl);
  item.addEventListener('click', () => onToggle(!checked));
  return item;
}

export function statTile(value, label) {
  return el('div', 'stat-tile', [
    el('div', 'stat-tile__value', String(value)),
    el('div', 'stat-tile__label', label),
  ]);
}

export function xpBar(pct) {
  const track = el('div', 'xp-bar-track');
  const fill = el('div', 'xp-bar-fill');
  fill.style.width = `${Math.min(100, Math.max(0, pct))}%`;
  track.append(fill);
  return track;
}

export function emptyState(title, subtitle) {
  return el('div', 'empty-state', [
    el('h4', null, title),
    el('p', null, subtitle),
  ]);
}

export function textInput({ placeholder = '', value = '', type = 'text' } = {}) {
  const input = el('input', 'field-input');
  input.type = type;
  input.placeholder = placeholder;
  input.value = value;
  return input;
}

export function textareaInput({ placeholder = '', value = '', rows = 3 } = {}) {
  const textarea = el('textarea', 'field-input');
  textarea.placeholder = placeholder;
  textarea.value = value;
  textarea.rows = rows;
  return textarea;
}

export function fieldLabel(text) {
  return el('label', 'field-label', text);
}

/** A row of tappable chips where exactly one is selected at a time. */
export function chipSelect(options, selectedValue, onSelect) {
  const row = el('div', 'chip-row');
  options.forEach(({ label, value }) => {
    const chip = el('button', `chip${value === selectedValue ? ' chip--active' : ''}`, label);
    chip.addEventListener('click', () => onSelect(value));
    row.append(chip);
  });
  return row;
}

export function progressRing(pct, size = 56, strokeWidth = 5, colorVar = '--c-emerald-soft') {
  const wrap = el('div', 'progress-ring');
  wrap.style.width = `${size}px`;
  wrap.style.height = `${size}px`;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.min(100, Math.max(0, pct)) / 100);

  wrap.innerHTML = `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle cx="${size / 2}" cy="${size / 2}" r="${radius}" stroke="var(--c-surface-2)" stroke-width="${strokeWidth}" fill="none"/>
      <circle cx="${size / 2}" cy="${size / 2}" r="${radius}" stroke="var(${colorVar})" stroke-width="${strokeWidth}" fill="none"
        stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" stroke-linecap="round"
        transform="rotate(-90 ${size / 2} ${size / 2})" style="transition: stroke-dashoffset var(--dur-slow) var(--ease-out);"/>
    </svg>
    <span class="progress-ring__value">${Math.round(pct)}</span>
  `;
  return wrap;
}

/** Labeled slider returning { node, getValue }. */
export function sliderField(label, { min = 1, max = 10, step = 1, value = 5 } = {}) {
  const out = el('span', 'slider-value', String(value));
  const input = el('input', 'slider');
  input.type = 'range';
  input.min = min; input.max = max; input.step = step; input.value = value;
  input.addEventListener('input', () => { out.textContent = input.value; });
  const node = el('div', 'field', [el('div', 'flex justify-between', [fieldLabel(label), out]), input]);
  return { node, getValue: () => Number(input.value) };
}

/** Horizontal bar list: items = [{label, value, text}] */
export function barList(items) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return el('div', 'bar-list', items.map((i) => el('div', 'bar-list__row', [
    el('div', 'flex justify-between', [el('span', 'text-xs', i.label), el('span', 'text-xs text-dim', i.text ?? String(i.value))]),
    xpBar((i.value / max) * 100),
  ])));
}

/** A compact grid of stat tiles: items = [{value, label, hint}] */
export function statGrid(items) {
  return el('div', 'stat-grid', items.map((i) => el('div', 'stat-tile', [
    el('div', 'stat-tile__value', String(i.value)),
    el('div', 'stat-tile__label', i.label),
    i.hint ? el('div', 'stat-tile__hint', i.hint) : null,
  ])));
}

/** Pill-style tab row; onPick(key). */
export function tabs(options, activeKey, onPick) {
  const row = el('div', 'tab-row');
  options.forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeKey === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', () => onPick(key));
    row.append(pill);
  });
  return row;
}

export function trendBadge(pct) {
  if (pct === null || pct === undefined) return el('span', 'trend trend--flat', '—');
  const cls = pct > 0 ? 'trend--up' : pct < 0 ? 'trend--down' : 'trend--flat';
  return el('span', `trend ${cls}`, `${pct > 0 ? '▲' : pct < 0 ? '▼' : '•'} ${Math.abs(pct)}%`);
}
