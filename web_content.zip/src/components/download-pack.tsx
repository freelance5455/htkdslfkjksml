import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export function DownloadPack() {
  return (
    <section className="rounded-xl border border-border bg-surface p-5">
      <h2 className="text-base font-medium">Android-Paket</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Das ZIP enthält das vollständige Android-Projekt (Kotlin) mit lokalem
        VPN, Domainprüfung, Nachfrage-Bildschirm und den nötigen
        Berechtigungsabfragen. Daraus entsteht die APK — nicht durch Umbenennen
        der Datei, sondern über Android Studio.
      </p>
      <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-fg">
        <li>ZIP herunterladen und entpacken.</li>
        <li>
          Android Studio öffnen (kostenlos bei Google) und den Ordner{" "}
          <span className="font-mono text-xs">Netzschild</span> als Projekt
          laden.
        </li>
        <li>
          Handy per USB verbinden oder einen Emulator wählen, USB-Debugging
          erlauben.
        </li>
        <li>
          Menü <span className="font-medium">Build → Build APK(s)</span>. Die
          fertige Datei liegt unter{" "}
          <span className="font-mono text-xs">app/release</span>.
        </li>
      </ol>
      <Button asChild className="mt-5 w-full" size="lg">
        <a href="/netzschild-android.zip" download>
          <Download />
          ZIP herunterladen
        </a>
      </Button>
      <p className="mt-3 text-xs leading-relaxed text-subtle">
        Netzschild entschlüsselt kein HTTPS. Geprüft werden DNS-Namen, Ziel-IPs
        und Vertrauenssignale. Der Schutz läuft als sichtbarer Dienst — kein
        verstecktes Mitschneiden.
      </p>
    </section>
  );
}
