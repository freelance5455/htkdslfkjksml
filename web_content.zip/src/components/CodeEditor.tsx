import React, { useState, useRef, useEffect } from 'react';
import { Search, ArrowDown, ArrowUp, RefreshCw, X, AlertCircle } from 'lucide-react';
import { ProjectFile, EditorSettings } from '../types';

interface CodeEditorProps {
  file: ProjectFile;
  onChangeContent: (content: string) => void;
  settings: EditorSettings;
  errorLine?: number | null;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  file,
  onChangeContent,
  settings,
  errorLine,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  // Search & Replace state
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [matchCount, setMatchCount] = useState(0);

  // Cursor position tracking for status bar
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });

  const lines = file.content.split('\n');

  // Sync scroll between textarea and line numbers
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
    }
  };

  // Keyboard shortcut listener for Ctrl+F
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
        e.preventDefault();
        setShowSearch(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Update cursor position and match counts
  const handleSelect = () => {
    if (!textareaRef.current) return;
    const pos = textareaRef.current.selectionStart;
    const upTo = file.content.slice(0, pos);
    const lineList = upTo.split('\n');
    setCursorPos({
      line: lineList.length,
      col: lineList[lineList.length - 1].length + 1,
    });
  };

  // Auto-indentation and Tab key handling
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const spaces = ' '.repeat(settings.tabSize || 2);
      const newContent = file.content.substring(0, start) + spaces + file.content.substring(end);
      onChangeContent(newContent);
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + spaces.length;
      }, 0);
      return;
    }

    if (e.key === 'Enter') {
      const pos = textarea.selectionStart;
      const textBefore = file.content.substring(0, pos);
      const currentLine = textBefore.split('\n').pop() || '';
      const match = currentLine.match(/^(\s+)/);
      let indent = match ? match[1] : '';

      // Increase indent if line ends with { or :
      if (currentLine.trim().endsWith('{') || currentLine.trim().endsWith(':') || currentLine.trim().endsWith('(')) {
        indent += ' '.repeat(settings.tabSize || 2);
      }

      if (indent.length > 0) {
        e.preventDefault();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const insert = '\n' + indent;
        const newContent = file.content.substring(0, start) + insert + file.content.substring(end);
        onChangeContent(newContent);
        setTimeout(() => {
          textarea.selectionStart = textarea.selectionEnd = start + insert.length;
        }, 0);
      }
    }
  };

  // Search logic
  useEffect(() => {
    if (!searchQuery) {
      setMatchCount(0);
      return;
    }
    try {
      const regex = new RegExp(searchQuery, 'gi');
      const matches = file.content.match(regex);
      setMatchCount(matches ? matches.length : 0);
    } catch (e) {
      setMatchCount(0);
    }
  }, [searchQuery, file.content]);

  const handleFindNext = () => {
    if (!searchQuery || !textareaRef.current) return;
    const currentPos = textareaRef.current.selectionEnd;
    const lowerContent = file.content.toLowerCase();
    const lowerQuery = searchQuery.toLowerCase();
    let nextIndex = lowerContent.indexOf(lowerQuery, currentPos);
    if (nextIndex === -1) {
      // Loop around
      nextIndex = lowerContent.indexOf(lowerQuery, 0);
    }
    if (nextIndex !== -1) {
      textareaRef.current.focus();
      textareaRef.current.setSelectionRange(nextIndex, nextIndex + searchQuery.length);
      handleSelect();
    }
  };

  const handleReplace = () => {
    if (!searchQuery || !textareaRef.current) return;
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const selected = file.content.substring(start, end);

    if (selected.toLowerCase() === searchQuery.toLowerCase()) {
      const newContent = file.content.substring(0, start) + replaceQuery + file.content.substring(end);
      onChangeContent(newContent);
      setTimeout(() => {
        handleFindNext();
      }, 0);
    } else {
      handleFindNext();
    }
  };

  const handleReplaceAll = () => {
    if (!searchQuery) return;
    const regex = new RegExp(searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    const newContent = file.content.replace(regex, replaceQuery);
    onChangeContent(newContent);
  };

  // Mobile quick characters bar
  const mobileChars = ['Tab', '{', '}', '(', ')', '[', ']', '<', '>', '"', "'", '=', ';', ':', '/', '*', '+', '-'];
  const insertMobileChar = (char: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const insertion = char === 'Tab' ? ' '.repeat(settings.tabSize || 2) : char;
    const newContent = file.content.substring(0, start) + insertion + file.content.substring(end);
    onChangeContent(newContent);
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + insertion.length;
    }, 0);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#070a14] relative overflow-hidden font-code text-slate-100 h-full">
      {/* Floating Search & Replace Bar */}
      {showSearch && (
        <div className="absolute top-2 right-4 z-40 bg-[#0d1322] border border-cyan-500/40 rounded-xl p-2.5 shadow-2xl flex flex-col gap-2 max-w-sm animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="Find..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-slate-900 text-xs px-2 py-1 rounded text-white border border-slate-700 outline-hidden w-full font-mono"
            />
            <span className="text-[10px] text-slate-400 font-mono px-1 shrink-0">
              {matchCount} found
            </span>
            <button
              onClick={handleFindNext}
              aria-label="Find next"
              className="p-1 rounded hover:bg-slate-800 text-slate-300"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowSearch(false)}
              aria-label="Close search"
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <input
              type="text"
              placeholder="Replace with..."
              value={replaceQuery}
              onChange={e => setReplaceQuery(e.target.value)}
              className="bg-slate-900 text-xs px-2 py-1 rounded text-white border border-slate-700 outline-hidden w-full font-mono"
            />
            <button
              onClick={handleReplace}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold rounded shrink-0"
            >
              Replace
            </button>
            <button
              onClick={handleReplaceAll}
              className="px-2 py-1 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 text-[10px] font-semibold rounded shrink-0"
            >
              All
            </button>
          </div>
        </div>
      )}

      {/* Editor Main Canvas with Line Numbers */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Line Numbers Gutter */}
        {settings.lineNumbers && (
          <div
            ref={lineNumbersRef}
            className="w-12 bg-[#050811] text-slate-600 py-3 select-none text-right pr-3 font-mono overflow-hidden shrink-0 border-r border-slate-800/80"
            style={{ fontSize: `${settings.fontSize}px`, lineHeight: '1.5' }}
          >
            {lines.map((_, idx) => {
              const lineNum = idx + 1;
              const isError = errorLine === lineNum;
              return (
                <div
                  key={idx}
                  className={`leading-normal ${
                    isError
                      ? 'text-rose-400 font-bold bg-rose-500/20 rounded-l pr-1'
                      : cursorPos.line === lineNum
                      ? 'text-cyan-400 font-semibold'
                      : ''
                  }`}
                >
                  {lineNum}
                </div>
              );
            })}
          </div>
        )}

        {/* Textarea Code Surface */}
        <div className="flex-1 relative h-full">
          <textarea
            ref={textareaRef}
            value={file.content}
            onChange={e => onChangeContent(e.target.value)}
            onKeyDown={handleKeyDown}
            onSelect={handleSelect}
            onScroll={handleScroll}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            aria-label={`Code editor for ${file.name}`}
            className="w-full h-full p-3 bg-transparent text-slate-100 font-code outline-hidden resize-none overflow-auto border-0 leading-normal"
            style={{
              fontSize: `${settings.fontSize}px`,
              lineHeight: '1.5',
              tabSize: settings.tabSize || 2,
              whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            }}
          />
        </div>
      </div>

      {/* Mobile Touch Keyboard Bar */}
      <div className="h-8 bg-[#090d18] border-t border-slate-800 flex items-center px-2 gap-1 overflow-x-auto select-none shrink-0 md:hidden">
        {mobileChars.map((ch, idx) => (
          <button
            key={idx}
            onClick={() => insertMobileChar(ch)}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-cyan-500/20 text-slate-300 font-mono text-xs font-semibold shrink-0 active:scale-90"
          >
            {ch}
          </button>
        ))}
      </div>

      {/* Editor Status Bar */}
      <div className="h-6 bg-[#050811] border-t border-slate-800/80 px-3 flex items-center justify-between text-[11px] font-mono text-slate-500 select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>
            Ln <span className="text-cyan-400">{cursorPos.line}</span>, Col{' '}
            <span className="text-cyan-400">{cursorPos.col}</span>
          </span>
          <span>{lines.length} lines</span>
          {errorLine && (
            <span className="flex items-center gap-1 text-rose-400 font-semibold">
              <AlertCircle className="w-3 h-3" /> Error on line {errorLine}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span className="capitalize">{file.language}</span>
          <span>UTF-8</span>
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="hover:text-cyan-400 transition-colors"
          >
            Ctrl+F Search
          </button>
        </div>
      </div>
    </div>
  );
};
