/**
 * GODEX v0.0.1 - Advanced Code Editor
 */

import React, { useState, useEffect } from 'react';
import { FileCode, Copy, Check, Save, Sparkles, FileText } from 'lucide-react';

interface CodeEditorProps {
  activeFile: string;
  files: Record<string, string>;
  onUpdateFileContent: (path: string, content: string) => void;
  onOpenDiff: () => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  activeFile,
  files,
  onUpdateFileContent,
  onOpenDiff
}) => {
  const currentContent = files[activeFile] || '';
  const [copied, setCopied] = useState(false);
  const [lineCount, setLineCount] = useState(1);

  useEffect(() => {
    setLineCount(currentContent.split('\n').length);
  }, [currentContent]);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const lines = currentContent.split('\n');

  return (
    <div className="flex-1 h-full flex flex-col bg-[#090B10] border-r border-[#1C2230] overflow-hidden">
      {/* Tab & Editor Action Header */}
      <div className="h-9 border-b border-[#1C2230] bg-[#0D1017] px-3 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="flex items-center gap-2 px-3 py-1 bg-[#090B10] rounded-t border-t-2 border-cyan-400 text-xs font-mono text-cyan-300 font-semibold border-x border-[#1C2230]">
            <FileCode className="w-3.5 h-3.5 text-cyan-400" />
            <span className="truncate max-w-[200px]">{activeFile}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <button
            onClick={onOpenDiff}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#131926] hover:bg-[#1C2538] border border-[#222E46] text-cyan-300 text-[10px] font-medium transition-colors"
            title="Inspect AI Diff"
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>DIFF</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#131926] hover:bg-[#1C2538] border border-[#222E46] text-neutral-300 text-[10px] font-medium transition-colors"
            title="Copy file contents"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'COPIED' : 'COPY'}</span>
          </button>
        </div>
      </div>

      {/* Editor Content Area */}
      <div className="flex-1 flex overflow-hidden relative font-mono text-xs leading-relaxed bg-[#08090D]">
        {/* Line Numbers Gutter */}
        <div className="w-11 py-3 bg-[#06070A] border-r border-[#161B26] select-none text-right pr-2.5 text-neutral-600 font-mono text-[11px] overflow-hidden shrink-0">
          {lines.map((_, i) => (
            <div key={i} className="h-5 leading-5">{i + 1}</div>
          ))}
        </div>

        {/* Textarea Code Input */}
        <div className="flex-1 relative overflow-auto p-3 bg-tech-dots/10">
          <textarea
            spellCheck={false}
            value={currentContent}
            onChange={(e) => onUpdateFileContent(activeFile, e.target.value)}
            className="w-full h-full min-h-[500px] bg-transparent text-neutral-200 placeholder-neutral-600 resize-none font-mono text-xs leading-5 focus:outline-none whitespace-pre overflow-visible"
          />
        </div>
      </div>

      {/* Status Bar */}
      <div className="h-5 bg-[#0D1017] border-t border-[#1C2230] px-3 flex items-center justify-between text-[10px] font-mono text-neutral-400 select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>{lineCount} lines</span>
          <span>{currentContent.length} chars</span>
          <span className="text-cyan-400">TypeScript / React</span>
        </div>
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span>Spaces: 2</span>
        </div>
      </div>
    </div>
  );
};
