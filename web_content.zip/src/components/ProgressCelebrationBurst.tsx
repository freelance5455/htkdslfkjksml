import { AnimatePresence, motion } from 'framer-motion';
import { Heart, Star } from 'lucide-react';

interface CelebrationParticle {
  id: number;
  kind: 'heart' | 'star';
  startXPercent: number;
  driftX: number;
  riseY: number;
  rotate: number;
  color: string;
  size: number;
  delay: number;
}

const CELEBRATION_PARTICLES: CelebrationParticle[] = [
  { id: 1, kind: 'star', startXPercent: 18, driftX: -22, riseY: 36, rotate: -35, color: '#FBBF24', size: 17, delay: 0 },
  { id: 2, kind: 'heart', startXPercent: 28, driftX: 16, riseY: 44, rotate: 24, color: '#EC4899', size: 16, delay: 0.05 },
  { id: 3, kind: 'star', startXPercent: 40, driftX: -14, riseY: 50, rotate: 45, color: '#8B5CF6', size: 18, delay: 0.03 },
  { id: 4, kind: 'heart', startXPercent: 50, driftX: 8, riseY: 54, rotate: -18, color: '#F43F5E', size: 17, delay: 0.08 },
  { id: 5, kind: 'star', startXPercent: 58, driftX: -18, riseY: 46, rotate: 30, color: '#10B981', size: 16, delay: 0.04 },
  { id: 6, kind: 'heart', startXPercent: 68, driftX: 20, riseY: 42, rotate: -26, color: '#EC4899', size: 15, delay: 0.1 },
  { id: 7, kind: 'star', startXPercent: 78, driftX: -12, riseY: 48, rotate: 52, color: '#F59E0B', size: 18, delay: 0.06 },
  { id: 8, kind: 'heart', startXPercent: 86, driftX: 18, riseY: 38, rotate: 20, color: '#F43F5E', size: 15, delay: 0.12 },
  { id: 9, kind: 'star', startXPercent: 34, driftX: 24, riseY: 32, rotate: -48, color: '#3B82F6', size: 14, delay: 0.11 },
  { id: 10, kind: 'heart', startXPercent: 62, driftX: -24, riseY: 34, rotate: 32, color: '#A855F7', size: 14, delay: 0.09 },
];

interface ProgressCelebrationBurstProps {
  burstKey: number | null;
}

export function ProgressCelebrationBurst({ burstKey }: ProgressCelebrationBurstProps) {
  return (
    <AnimatePresence>
      {burstKey !== null && (
        <div
          key={burstKey}
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-30 overflow-visible"
        >
          {CELEBRATION_PARTICLES.map((p) => (
            <motion.span
              key={p.id}
              initial={{
                opacity: 0,
                scale: 0.25,
                x: 0,
                y: 6,
                rotate: 0,
              }}
              animate={{
                opacity: [0, 1, 1, 0],
                scale: [0.3, 1.25, 1.05, 0.7],
                x: p.driftX,
                y: p.riseY,
                rotate: p.rotate,
              }}
              exit={{ opacity: 0 }}
              transition={{
                duration: 1.05,
                delay: p.delay,
                ease: [0.16, 1, 0.3, 1],
              }}
              style={{
                left: `${p.startXPercent}%`,
                top: '50%',
                color: p.color,
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 drop-shadow-sm"
            >
              {p.kind === 'heart' ? (
                <Heart
                  style={{ width: p.size, height: p.size }}
                  fill="currentColor"
                  strokeWidth={1.6}
                />
              ) : (
                <Star
                  style={{ width: p.size, height: p.size }}
                  fill="currentColor"
                  strokeWidth={1.6}
                />
              )}
            </motion.span>
          ))}
        </div>
      )}
    </AnimatePresence>
  );
}
