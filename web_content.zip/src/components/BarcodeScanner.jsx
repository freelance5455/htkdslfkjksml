import { useEffect, useId, useRef, useState } from 'react'
import { Html5Qrcode } from 'html5-qrcode'

const RESCAN_DELAY = 1200

function message(e) {
  if (typeof e === 'string') return e
  return e && e.message ? e.message : String(e)
}

export default function BarcodeScanner({ onScan, onScanError, onClose }) {
  const uid = useId()
  const readerId = `barcode-reader-${uid.replace(/[^a-zA-Z0-9]/g, '')}`
  const [error, setError] = useState('')
  const [running, setRunning] = useState(false)
  const lastScan = useRef({ code: '', at: 0 })
  const handlers = useRef({ onScan, onScanError })

  useEffect(() => {
    handlers.current = { onScan, onScanError }
  })

  useEffect(() => {
    let mounted = true
    let stopPromise = null

    const stopScanner = () => {
      if (stopPromise) return stopPromise
      try {
        stopPromise = Promise.resolve(scanner.stop()).catch(() => {})
      } catch {
        stopPromise = null
      }
      return stopPromise
    }

    let scanner
    try {
      scanner = new Html5Qrcode(readerId, { verbose: false })
    } catch (e) {
      const msg = message(e)
      Promise.resolve().then(() => {
        if (mounted) setError(msg)
      })
      return undefined
    }

    const config = {
      fps: 10,
      qrbox: { width: 250, height: 150 },
      aspectRatio: 1.0,
    }

    scanner
      .start(
        { facingMode: 'environment' },
        config,
        (decoded) => {
          const now = Date.now()
          if (decoded === lastScan.current.code && now - lastScan.current.at < RESCAN_DELAY)
            return
          lastScan.current = { code: decoded, at: now }
          const { onScan: scan, onScanError: onErr } = handlers.current
          try {
            scan(decoded)
          } catch (e) {
            if (onErr) onErr(e)
          }
        },
        () => {},
      )
      .then(() => {
        if (!mounted) {
          stopScanner()
          return
        }
        setRunning(true)
      })
      .catch((e) => {
        if (!mounted) {
          stopScanner()
          return
        }
        setError(message(e))
        setRunning(false)
      })

    return () => {
      mounted = false
      const stopped = stopScanner()
      const clear = () => {
        try {
          scanner.clear()
        } catch {}
      }
      if (stopped) stopped.then(clear)
      else clear()
    }
  }, [readerId])

  return (
    <div className="scanner-overlay" role="dialog" aria-modal="true">
      <div className="scanner-card">
        <div className="scanner-header">
          <strong>Barcode Scan</strong>
          <button className="btn btn-ghost" aria-label="Camera band karo" onClick={onClose}>
            ✕
          </button>
        </div>
        <div id={readerId} className="scanner-box" />
        {error && (
          <p className="scanner-error">
            Camera chalu nahi ho paya. Chrome/Android browser aur HTTPS use karo.
            <br />
            <span className="muted">{error.slice(0, 120)}</span>
          </p>
        )}
        {running && !error && <p className="muted center">Product ke barcode par camera rakho…</p>}
      </div>
    </div>
  )
}
