import React, { useState } from 'react';
import {
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  Download,
  ExternalLink,
  Eye,
  X,
} from 'lucide-react';
import { ChapterNote, LanguageCode } from '../types/edutoon';
import { Logo } from './Logo';

interface NoteReaderModalProps {
  note: ChapterNote;
  subjectName: string;
  isSaved: boolean;
  isCompleted: boolean;
  language: LanguageCode;
  onToggleSave: () => void;
  onDownloadPdf: () => Promise<void>;
  onToggleCompleted: () => void;
  onClose: () => void;
}

export const NoteReaderModal: React.FC<NoteReaderModalProps> = ({
  note,
  subjectName,
  isSaved,
  isCompleted,
  language,
  onToggleSave,
  onDownloadPdf,
  onToggleCompleted,
  onClose,
}) => {
  const isHi = language === 'hi';
  const [showAnswer, setShowAnswer] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await onDownloadPdf();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-3xl bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header with official EduToon Logo */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3 min-w-0">
            <Logo size="xs" />
            <div className="min-w-0">
              <p className="text-xs text-slate-500 truncate">
                {subjectName} · {isHi ? `कक्षा ${note.classLevel}` : `Class ${note.classLevel}`} ·{' '}
                {isHi ? `अध्याय ${note.chapterNumber}` : `Chapter ${note.chapterNumber}`}
              </p>
              <h2 className="font-display text-sm sm:text-base font-bold text-slate-900 truncate">
                {note.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close reader"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-200/70 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Note Content */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-6">
          <div>
            <p className="text-xs text-slate-500 font-medium">
              {note.language === 'hi' ? 'हिंदी माध्यम' : 'English Medium'} ·{' '}
              <span className="font-mono-num">{note.readTimeMinutes} min read</span>
            </p>
            <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-slate-900">
              {note.title}
            </h1>
            <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
              {note.summary}
            </p>
          </div>

          {note.mediaUrl && (
            <div className="rounded-2xl border border-sky-200 bg-sky-50/60 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-sky-900">
                  {isHi ? 'अपलोड की गई PDF अध्ययन सामग्री' : 'Attached PDF Study Material'}
                </span>
                <a
                  href={note.mediaUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-sky-700 hover:text-sky-800"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>{isHi ? 'नई टैब में PDF खोलें' : 'Open PDF in New Tab'}</span>
                </a>
              </div>
              <iframe
                src={note.mediaUrl}
                title={note.title}
                className="w-full h-72 sm:h-96 rounded-xl border border-slate-200 bg-white"
              />
            </div>
          )}

          <div className="divide-y divide-slate-200">
            {note.sections.map((sec, idx) => (
              <section key={idx} className="py-5 first:pt-2">
                <h3 className="font-display text-lg font-semibold text-slate-900">
                  {sec.heading}
                </h3>
                <p className="mt-2 text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line">
                  {sec.body}
                </p>
                {sec.keyFormulaOrPoint && (
                  <div className="mt-3 p-4 rounded-xl bg-sky-50 border border-sky-200 text-sm font-semibold text-sky-900">
                    {sec.keyFormulaOrPoint}
                  </div>
                )}
              </section>
            ))}
          </div>

          {/* Practice Question Card */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200">
            <p className="text-xs font-semibold text-slate-500">
              {isHi ? 'त्वरित अभ्यास प्रश्न' : 'Practice Check'}
            </p>
            <p className="mt-1 text-sm sm:text-base font-semibold text-slate-900">
              {note.practiceQuestion.question}
            </p>
            {!showAnswer ? (
              <button
                type="button"
                onClick={() => setShowAnswer(true)}
                className="mt-3 min-h-[40px] px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-800 inline-flex items-center gap-2 cursor-pointer"
              >
                <Eye className="h-3.5 w-3.5" />
                <span>{isHi ? 'उत्तर देखें' : 'Reveal Answer'}</span>
              </button>
            ) : (
              <p className="mt-3 text-sm font-semibold text-emerald-700">
                {isHi ? 'उत्तर: ' : 'Answer: '}
                {note.practiceQuestion.answer}
              </p>
            )}
          </div>
        </div>

        {/* Sticky Bottom Action Bar */}
        <div className="px-4 sm:px-6 py-3.5 border-t border-slate-200 bg-white flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleSave}
              className={`min-h-[44px] px-4 rounded-xl border text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
                isSaved
                  ? 'border-amber-300 bg-amber-50 text-amber-800'
                  : 'border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {isSaved ? (
                <BookmarkCheck className="h-4 w-4" />
              ) : (
                <Bookmark className="h-4 w-4" />
              )}
              <span>
                {isSaved ? (isHi ? 'सेव किया गया' : 'Saved') : isHi ? 'नोट्स सेव करें' : 'Save Note'}
              </span>
            </button>

            <button
              type="button"
              disabled={downloading}
              onClick={handleDownload}
              className="min-h-[44px] px-4 rounded-xl border border-slate-300 text-slate-800 hover:bg-slate-50 text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <Download className="h-4 w-4" />
              <span>
                {downloading
                  ? isHi
                    ? 'डाउनलोड...'
                    : 'Preparing PDF...'
                  : isHi
                    ? 'PDF डाउनलोड'
                    : 'Download PDF'}
              </span>
            </button>
          </div>

          <button
            type="button"
            onClick={onToggleCompleted}
            className={`min-h-[44px] px-5 rounded-xl text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
              isCompleted
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-sky-600 text-white hover:bg-sky-700'
            }`}
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>
              {isCompleted
                ? isHi
                  ? 'अध्याय पूर्ण हुआ'
                  : 'Chapter Completed'
                : isHi
                  ? 'पूर्ण चिह्नित करें'
                  : 'Mark Completed'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
