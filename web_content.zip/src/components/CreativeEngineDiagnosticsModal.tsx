/**
 * GODEX P3.8 — Creative Engine Diagnostics & Hardware Audit Panel
 * 
 * Provides truthful empirical diagnostics on:
 * 1. Host Hardware Capabilities (WebGPU, WebGL, WASM SIMD, CPU Cores, Memory)
 * 2. Local Neural Engine Connectivity (ComfyUI 8188, Ollama 11434, LocalAI 8080)
 * 3. Model Registry, Precision Matrix, and VRAM Allocation
 * 4. Zero Fabrication & Truth Classification Audit
 */

import React, { useState, useEffect } from 'react';
import {
  Activity,
  Cpu,
  RefreshCw,
  X,
  Server,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Info,
  Terminal,
  Zap,
  HardDrive,
  Eye,
  Check,
  Film,
  Clock,
  ShieldCheck,
  Smartphone,
  Monitor
} from 'lucide-react';
import { HardwareAuditor } from '../builder/creative/hardwareAuditor';
import { NeuralRuntimeDiscovery } from '../builder/creative/neuralRuntimeDiscovery';
import { NeuralRuntimeDiscoveryReport, HardwareAuditReport } from '../builder/creative/creativeStudioTypes';
import { ModelManager } from '../builder/creative/modelManager';
import { CreativeEngineRegistry } from '../builder/creative/creativeEngineRegistry';
import { PreviewRuntimeHealth, RuntimeHealthMetric } from '../services/previewRuntimeHealth';
import { RenderCheckpointEngine } from '../builder/creative/renderCheckpointEngine';
import { RenderResourceGovernor } from '../builder/creative/renderResourceGovernor';
import { MediaExportEngine } from '../builder/creative/mediaExportEngine';
import { ExportCapability, RenderCheckpoint } from '../builder/creative/mediaAssemblyTypes';
import { DeviceCapabilityProfiler, DeviceCapabilityProfile } from '../builder/creative/deviceCapabilityProfiler';
import { VideoEncodingCapabilityEngine, VideoCodecAuditReport } from '../builder/creative/videoEncodingCapabilityEngine';
import { ProductionRuntimeCapabilityEngine, ProductionRuntimeCapabilityMatrix } from '../builder/creative/production/productionRuntimeCapabilityEngine';
import { MobileProductionGovernor, MobileGovernorPolicy } from '../builder/creative/production/mobileProductionGovernor';
import { ProductionOutputIngestionEngine } from '../builder/creative/production/productionOutputIngestionEngine';

interface CreativeEngineDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreativeEngineDiagnosticsModal: React.FC<CreativeEngineDiagnosticsModalProps> = ({
  isOpen,
  onClose
}) => {
  const [hwReport, setHwReport] = useState<HardwareAuditReport | null>(null);
  const [deviceProfile, setDeviceProfile] = useState<DeviceCapabilityProfile | null>(null);
  const [codecReport, setCodecReport] = useState<VideoCodecAuditReport | null>(null);
  const [runtimeReport, setRuntimeReport] = useState<NeuralRuntimeDiscoveryReport | null>(null);
  const [engineHealth, setEngineHealth] = useState<Map<string, { healthy: boolean; latencyMs: number; error?: string }>>(new Map());
  const [runtimeMetric, setRuntimeMetric] = useState<RuntimeHealthMetric>(() => PreviewRuntimeHealth.getInstance().getHealth());
  const [exportCaps, setExportCaps] = useState<ExportCapability[]>([]);
  const [checkpoints, setCheckpoints] = useState<RenderCheckpoint[]>([]);
  const [capabilityMatrix, setCapabilityMatrix] = useState<ProductionRuntimeCapabilityMatrix | null>(null);
  const [governorPolicy, setGovernorPolicy] = useState<MobileGovernorPolicy | null>(null);
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [activeSubTab, setActiveSubTab] = useState<'HARDWARE' | 'DEVICE_PROFILER' | 'RUNTIME_BRIDGE' | 'RUNTIMES' | 'MODELS' | 'RENDER_GOVERNANCE' | 'PREVIEW_HEALTH' | 'TRUTH'>('RUNTIME_BRIDGE');

  const runDiagnostics = async () => {
    setIsAuditing(true);
    try {
      const hw = await HardwareAuditor.getInstance().auditHardware();
      setHwReport(hw);

      const devProf = await DeviceCapabilityProfiler.getInstance().profileDevice();
      setDeviceProfile(devProf);

      const codecs = await VideoEncodingCapabilityEngine.getInstance().auditVideoEncoding();
      setCodecReport(codecs);

      const runtimes = await NeuralRuntimeDiscovery.getInstance().discoverRuntimes();
      setRuntimeReport(runtimes);

      const health = await CreativeEngineRegistry.getInstance().healthCheckAllEngines();
      setEngineHealth(health);

      const metric = PreviewRuntimeHealth.getInstance().probeHealth();
      setRuntimeMetric(metric);

      const caps = MediaExportEngine.getInstance().auditExportCapabilities();
      setExportCaps(caps);

      const chks = RenderCheckpointEngine.getInstance().getAllCheckpoints();
      setCheckpoints(chks);

      const matrix = await ProductionRuntimeCapabilityEngine.getInstance().probeCapabilities();
      setCapabilityMatrix(matrix);

      const policy = MobileProductionGovernor.getInstance().resolvePolicy(matrix);
      setGovernorPolicy(policy);
    } catch (e) {
      console.error('Diagnostics error:', e);
    } finally {
      setIsAuditing(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runDiagnostics();
      return PreviewRuntimeHealth.getInstance().subscribe(m => setRuntimeMetric(m));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const modelManager = ModelManager.getInstance();
  const allModels = modelManager.getAllModels();
  const loadedModels = modelManager.getLoadedModels();
  const cachedModels = modelManager.getCachedModels();
  const activeVram = modelManager.getActiveVramUsageMb();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#070B16] border border-[#1C2C4E] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden font-sans">
        {/* Header */}
        <div className="h-14 border-b border-[#141E33] bg-[#0A0F1D] px-4 sm:px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <Activity className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2 font-mono">
                ENGINE DIAGNOSTICS & HARDWARE AUDITOR
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  P3.9 TRUTH-VERIFIED
                </span>
              </div>
              <div className="text-[11px] text-neutral-400">
                Empirical host hardware detection and local neural engine discovery
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runDiagnostics}
              disabled={isAuditing}
              className="px-2.5 py-1 rounded-lg bg-[#121E36] hover:bg-[#1A2C4F] text-xs text-neutral-200 border border-[#22355C] flex items-center gap-1.5 transition-all font-mono"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isAuditing ? 'animate-spin text-emerald-400' : ''}`} />
              Re-Audit
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-[#141F36] text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sub-Navigation */}
        <div className="border-b border-[#141E33] bg-[#050811] px-4 sm:px-6 flex items-center gap-2 overflow-x-auto text-xs font-mono">
          {[
            { id: 'RUNTIME_BRIDGE', label: 'P5.2 Runtime Bridge', icon: Zap },
            { id: 'HARDWARE', label: 'Hardware & GPU', icon: Cpu },
            { id: 'DEVICE_PROFILER', label: 'Real-Device Profiler', icon: Smartphone },
            { id: 'RUNTIMES', label: 'Inference Bridges', icon: Server },
            { id: 'MODELS', label: 'Neural Models', icon: Layers },
            { id: 'RENDER_GOVERNANCE', label: 'Render & Governance', icon: Film },
            { id: 'PREVIEW_HEALTH', label: 'Preview DOM & Health', icon: Eye },
            { id: 'TRUTH', label: 'Truth Classification', icon: Terminal }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`py-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-all shrink-0 ${
                  activeSubTab === tab.id
                    ? 'border-emerald-500 text-emerald-400 font-bold bg-[#0D1629]'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs font-mono bg-[#03060E]">
          {/* TAB: RUNTIME_BRIDGE */}
          {activeSubTab === 'RUNTIME_BRIDGE' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#091024] border border-[#18284C] flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-white font-bold text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-400" />
                    P5.2 Production Runtime Bridge & Delivery Hardening
                  </div>
                  <div className="text-[11px] text-neutral-400 mt-0.5">
                    Strict capability matrix, mobile-first governance, and zero-fabrication execution.
                  </div>
                </div>
                {governorPolicy && (
                  <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs font-bold font-mono">
                    GOVERNOR: {governorPolicy.profile}
                  </span>
                )}
              </div>

              {/* Capability Matrix Grid */}
              {capabilityMatrix && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">WebGPU Compute</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      {capabilityMatrix.capabilities.webgpu.usable ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      {capabilityMatrix.capabilities.webgpu.usable ? 'AVAILABLE' : 'UNAVAILABLE'}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      {capabilityMatrix.capabilities.webgpu.limitation || 'Direct compute pipeline'}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">WebGL2 Rasterizer</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      {capabilityMatrix.capabilities.webgl2.usable ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      {capabilityMatrix.capabilities.webgl2.usable ? 'OPERATIONAL' : 'FALLBACK'}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      Max texture: {capabilityMatrix.maxTextureDimension}px
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">WebCodecs Hardware Mux</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      {capabilityMatrix.capabilities.webcodecs.usable ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      {capabilityMatrix.capabilities.webcodecs.usable ? 'HARDWARE_ACCELERATED' : 'CONTAINER_FALLBACK'}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      Zero-copy video frame encoding
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">WASM SIMD Acceleration</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      {capabilityMatrix.capabilities.webassemblySimd.usable ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      {capabilityMatrix.capabilities.webassemblySimd.usable ? '128-BIT VECTORIZED' : 'SCALAR'}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      DSP & color transform speedup
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">AudioContext 48kHz DSP</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      {capabilityMatrix.capabilities.audioContext.usable ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      )}
                      {capabilityMatrix.capabilities.audioContext.usable ? 'OPERATIONAL' : 'DISABLED'}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      Sample Rate: {governorPolicy?.audioSampleRateHz ?? 48000} Hz
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                    <div className="text-neutral-400 text-[10px] uppercase font-bold">Hardware Concurrency</div>
                    <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-cyan-400" />
                      {capabilityMatrix.hardwareConcurrency} Logical Threads
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-1">
                      Memory Est: {capabilityMatrix.memoryEstimateMb ? `${capabilityMatrix.memoryEstimateMb} MB` : 'Standard Sandbox'}
                    </div>
                  </div>
                </div>
              )}

              {/* Mobile Governor Policy Details */}
              {governorPolicy && (
                <div className="p-4 rounded-xl bg-[#080E1E] border border-[#162544] space-y-3">
                  <div className="text-xs font-bold text-white uppercase flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-sky-400" />
                    Mobile Governor Active Constraints
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                    <div>
                      <div className="text-neutral-400 text-[10px]">Max Resolution</div>
                      <div className="text-cyan-300 font-bold">{governorPolicy.maxResolution.width}×{governorPolicy.maxResolution.height}</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Target FPS Cap</div>
                      <div className="text-cyan-300 font-bold">{governorPolicy.maxFps} FPS</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Batch Chunk Size</div>
                      <div className="text-cyan-300 font-bold">{governorPolicy.renderBatchFrameCount} frames</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Max Shot Duration</div>
                      <div className="text-cyan-300 font-bold">{governorPolicy.maxShotDurationSec} seconds</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">RAM Budget</div>
                      <div className="text-emerald-300 font-bold">{governorPolicy.maxRamBudgetMb} MB</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Audio Sample Rate</div>
                      <div className="text-emerald-300 font-bold">{governorPolicy.audioSampleRateHz} Hz</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Tracks Allowed</div>
                      <div className="text-emerald-300 font-bold">{governorPolicy.allowSimultaneousTracks} Tracks</div>
                    </div>
                    <div>
                      <div className="text-neutral-400 text-[10px]">Progressive Flush</div>
                      <div className="text-emerald-300 font-bold">{governorPolicy.requiresProgressiveFlushing ? 'ENABLED' : 'DISABLED'}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          {/* TAB 1: HARDWARE */}
          {activeSubTab === 'HARDWARE' && hwReport && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                  <div className="text-neutral-400 text-[10px] uppercase font-bold">WebGPU Classification</div>
                  <div className="text-sm font-bold text-white mt-1 flex items-center gap-1.5">
                    {hwReport.webGpuClassification === 'WEBGPU_AVAILABLE' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    )}
                    {hwReport.webGpuClassification}
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-1">
                    {hwReport.webGpuClassification === 'WEBGPU_AVAILABLE'
                      ? 'Hardware compute shaders accessible'
                      : 'WebGPU unavailable in current runtime'}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                  <div className="text-neutral-400 text-[10px] uppercase font-bold">Graphics Accelerator</div>
                  <div className="text-sm font-bold text-white mt-1 truncate">
                    {hwReport.gpuModel || 'Host Integrated GPU'}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Vendor: {hwReport.gpuVendor} | {hwReport.webGlVersion}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#090E1D] border border-[#182645]">
                  <div className="text-neutral-400 text-[10px] uppercase font-bold">Compute Concurrency</div>
                  <div className="text-sm font-bold text-emerald-400 mt-1">
                    {hwReport.cpuCores} Logical CPU Cores
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    WASM SIMD: {hwReport.webAssembly.simd ? 'Supported (128-bit)' : 'Disabled'}
                  </div>
                </div>
              </div>

              {/* Hardware Details Table */}
              <div className="p-4 rounded-xl bg-[#070B18] border border-[#152340] space-y-2">
                <div className="text-neutral-300 font-bold text-xs uppercase flex items-center gap-2">
                  <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
                  Detailed Hardware Audit Trail
                </div>
                <div className="space-y-1 text-neutral-400 text-[11px]">
                  <div>• GPU Classification: <span className="text-white">{hwReport.gpuClassification}</span></div>
                  <div>• WebGL Unmasked Renderer: <span className="text-neutral-300">{hwReport.gpuModel}</span></div>
                  <div>• Max 2D Texture Resolution: <span className="text-emerald-400">{hwReport.computeLimits.maxTextureSize}px</span></div>
                  <div>• WebAssembly Threads / SharedArrayBuffer: <span className="text-white">{hwReport.webAssembly.threads ? 'Available' : 'Restricted (COOP/COEP)'}</span></div>
                  <div>• System Memory Pressure: <span className="text-emerald-400">{hwReport.vramPressureLevel || (hwReport as any).memoryPressure || 'LOW'}</span></div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: REAL-DEVICE PROFILER (P4.7) */}
          {activeSubTab === 'DEVICE_PROFILER' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#091024] border border-[#18284C] space-y-2">
                <div className="font-bold text-white text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-purple-400" />
                    <span>P4.7 Empirical Real-Device & Constrained Hardware Profiler</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800">
                    EMPIRICAL DETECTION
                  </span>
                </div>
                <div className="text-[11px] text-neutral-300 leading-relaxed">
                  Active auditing of client architecture, CPU core topology, RAM boundaries, WebCodecs hardware acceleration, and dynamic batch size throttling.
                </div>
              </div>

              {deviceProfile ? (
                <>
                  {/* Key Stats Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Device Classification</div>
                      <div className="text-sm font-bold text-white mt-0.5">
                        {deviceProfile.isMobileOrConstrained ? 'MOBILE / CONSTRAINED' : 'DESKTOP WORKSTATION'}
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1">
                        DPR: {deviceProfile.viewport.devicePixelRatio}x ({deviceProfile.viewport.orientation})
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Memory Boundary</div>
                      <div className="text-sm font-bold text-emerald-400 mt-0.5">
                        {deviceProfile.memory.jsHeapLimitMb !== 'UNKNOWN' ? `${deviceProfile.memory.jsHeapLimitMb} MB` : `${deviceProfile.memory.deviceMemoryGb} GB RAM`}
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1 font-mono">
                        {deviceProfile.memory.truthState}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Max Practical Target</div>
                      <div className="text-sm font-bold text-cyan-300 mt-0.5">
                        {deviceProfile.maxPracticalResolution.width}×{deviceProfile.maxPracticalResolution.height}
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1">
                        Preset: {deviceProfile.maxPracticalResolution.label} ({deviceProfile.viewport.screenWidth}×{deviceProfile.viewport.screenHeight})
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Adaptive Profile</div>
                      <div className="text-sm font-bold text-purple-300 font-mono mt-0.5">
                        {deviceProfile.recommendedProfile}
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-1">
                        Concurrency: {deviceProfile.cpuConcurrency}x cores
                      </div>
                    </div>
                  </div>

                  {/* Hardware Accelerated Codecs (VideoEncodingCapabilityEngine) */}
                  {codecReport && (
                    <div className="p-4 rounded-xl bg-[#070B18] border border-[#152340] space-y-3">
                      <div className="text-neutral-300 font-bold text-xs uppercase flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <Film className="w-3.5 h-3.5 text-emerald-400" />
                          Host Video Codecs & Hardware Acceleration
                        </span>
                        <span className="text-[10px] font-mono text-neutral-400">
                          WebCodecs API: {codecReport.webCodecsSupported ? 'Available' : 'Unsupported'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                        {codecReport.codecs.map(c => (
                          <div key={c.codecId} className="p-2.5 rounded-lg bg-[#0E1729] border border-neutral-800 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-white text-xs">{c.name}</span>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                                c.truthState.includes('AVAILABLE') ? 'bg-emerald-950 text-emerald-300' : 'bg-neutral-800 text-neutral-400'
                              }`}>
                                {c.truthState}
                              </span>
                            </div>
                            <div className="text-[10px] text-neutral-400 font-mono truncate">{c.mimeType}</div>
                            <div className="text-[10px] text-neutral-500">
                              HW Accel: {c.hardwareAccelerated ? 'Yes (GPU Direct)' : 'Software DSP'}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Device Architecture Trail */}
                  <div className="p-4 rounded-xl bg-[#070B18] border border-[#152340] space-y-2">
                    <div className="text-neutral-300 font-bold text-xs uppercase flex items-center gap-2">
                      <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                      Client Architecture & Capabilities Audit Trail
                    </div>
                    <div className="space-y-1 text-neutral-400 text-[11px]">
                      <div>• Hardware Concurrency: <span className="text-emerald-400">{deviceProfile.cpuConcurrency} logical threads ({deviceProfile.cpuTruthState})</span></div>
                      <div>• WebGL Max Texture Dimension: <span className="text-white">{deviceProfile.webGl.maxTextureSize}px ({deviceProfile.webGl.version})</span></div>
                      <div>• WebGPU Compute State: <span className="text-cyan-300">{deviceProfile.webGpu.truthState}</span></div>
                      <div>• WebAssembly SIMD: <span className="text-emerald-400">{deviceProfile.wasm.simdSupported ? 'Supported (128-bit)' : 'Not Available'}</span></div>
                      <div>• OffscreenCanvas & Web Workers: <span className="text-white">{deviceProfile.offscreenCanvas.supported ? 'Supported' : 'Main-thread only'} / {deviceProfile.webWorkers.supported ? 'Supported' : 'Disabled'}</span></div>
                      <div>• Executive Summary: <span className="text-neutral-300">{deviceProfile.summary}</span></div>
                      {deviceProfile.runtimeLimitations.length > 0 && (
                        <div className="pt-1">
                          <div className="text-amber-400 font-bold">Runtime Constraints & Policies:</div>
                          {deviceProfile.runtimeLimitations.map((lim, i) => (
                            <div key={i} className="text-neutral-400 text-[10px]">• {lim}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-8 text-center text-neutral-500">
                  Profiling host device capabilities...
                </div>
              )}
            </div>
          )}

          {/* TAB 2: RUNTIMES & BRIDGES */}
          {activeSubTab === 'RUNTIMES' && (
            <div className="space-y-4">
              <div className="text-neutral-400 text-xs">
                Active status of local neural inference endpoints and browser acceleration adapters:
              </div>

              <div className="space-y-2.5">
                {[
                  {
                    name: 'Browser-Native DSP & Canvas Engine',
                    endpoint: 'Local Browser Context',
                    status: 'AVAILABLE_BROWSER_NATIVE',
                    details: 'Zero-latency deterministic processing, spatial convolution, bicubic scaling.'
                  },
                  {
                    name: 'ComfyUI Local Diffusion Worker',
                    endpoint: 'http://127.0.0.1:8188',
                    status: engineHealth.get('engine-comfyui-local')?.healthy ? 'AVAILABLE_LOCALLY' : 'REQUIRES_ENGINE',
                    details: engineHealth.get('engine-comfyui-local')?.healthy
                      ? `Connected (Latency: ${engineHealth.get('engine-comfyui-local')?.latencyMs}ms)`
                      : 'Endpoint offline. Start ComfyUI at localhost:8188 to enable real neural generation.'
                  },
                  {
                    name: 'Local GPU Acceleration (WebGPU)',
                    endpoint: 'Hardware DirectML / Metal',
                    status: hwReport?.webGpuClassification === 'WEBGPU_AVAILABLE' ? 'AVAILABLE_LOCALLY' : 'UNAVAILABLE',
                    details: hwReport?.webGpuClassification === 'WEBGPU_AVAILABLE'
                      ? 'Local WebGPU accelerator ready'
                      : 'Hardware WebGPU adapter not discovered on host.'
                  },
                  {
                    name: 'Configured External Inference Cluster',
                    endpoint: 'Custom Cloud Endpoint',
                    status: 'REQUIRES_ENGINE',
                    details: 'Available when remote API endpoint is explicitly configured.'
                  }
                ].map((ep, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-[#080E1E] border border-[#162544] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white text-xs">{ep.name}</div>
                      <div className="text-[10px] text-cyan-400 font-mono">{ep.endpoint}</div>
                      <div className="text-[11px] text-neutral-400">{ep.details}</div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono shrink-0 ${
                        ep.status.includes('AVAILABLE')
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : ep.status === 'REQUIRES_ENGINE'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {ep.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: MODELS */}
          {activeSubTab === 'MODELS' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400 text-xs">
                  Model Registry: {allModels.length} Registered | {loadedModels.length} Loaded | {cachedModels.length} Cached
                </span>
                <span className="text-emerald-400 text-xs font-bold">
                  Active VRAM Usage: {activeVram} MB
                </span>
              </div>

              <div className="space-y-2">
                {allModels.map(m => (
                  <div key={m.modelId} className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white text-xs flex items-center gap-2">
                        {m.name}
                        <span className="text-[9px] px-1 rounded bg-[#13203A] text-cyan-300 border border-[#1F335C]">
                          {m.format}
                        </span>
                      </div>
                      <div className="text-[10px] text-neutral-400 mt-0.5">
                        Size: {(m.sizeBytes / (1024 * 1024)).toFixed(0)} MB | Memory: {m.memoryConsumptionMb} MB | Backend: {m.deviceBackend}
                      </div>
                      <div className="text-[10px] text-neutral-500">
                        Workflows: {m.supportedWorkflows.join(', ')}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        m.loaded ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                      }`}>
                        {m.loaded ? 'LOADED' : 'UNLOADED'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: RENDER & GOVERNANCE */}
          {activeSubTab === 'RENDER_GOVERNANCE' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#091024] border border-[#18284C] space-y-2">
                <div className="font-bold text-white text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Film className="w-4 h-4 text-indigo-400" />
                    <span>P4.6 Production Delivery, Memory Governance & Checkpoint Engine</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                    HARDENED
                  </span>
                </div>
                <div className="text-[11px] text-neutral-300 leading-relaxed">
                  Real-time monitoring of RAM/VRAM resource budgets, mobile memory ceilings, deterministic timeline hash signatures, and container encoding capabilities.
                </div>
              </div>

              {/* Codec & Export Capabilities */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Audited Output Format Capabilities (Zero-Fabrication)
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                  {exportCaps.map(cap => (
                    <div key={cap.format} className="p-2.5 rounded-lg bg-[#080E1E] border border-[#162544] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-xs">{cap.format}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono ${
                          cap.supported ? 'bg-emerald-950 text-emerald-300' : 'bg-neutral-800 text-neutral-400'
                        }`}>
                          {cap.truthState}
                        </span>
                      </div>
                      <div className="text-[10px] text-neutral-400 truncate">{cap.encoderName}</div>
                      <div className="text-[9px] text-neutral-500 line-clamp-2">{cap.reason}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Checkpoints */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Active Render Checkpoints ({checkpoints.length})
                </div>
                {checkpoints.length === 0 ? (
                  <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] text-neutral-500 text-xs italic">
                    No active or interrupted checkpoints. Renders execute clean deterministic passes.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {checkpoints.map(chk => (
                      <div key={chk.checkpointId} className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-white">{chk.compositionId}</div>
                          <div className="text-[10px] text-neutral-400 font-mono mt-0.5">
                            Stage: {chk.currentStage} • Frames: {chk.completedFrames}/{chk.totalFrames} • Hash: {chk.timelineHash}
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 font-mono">
                          {chk.resourceState}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: PREVIEW RUNTIME HEALTH */}
          {activeSubTab === 'PREVIEW_HEALTH' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#091024] border border-[#18284C] space-y-2">
                <div className="font-bold text-white text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-cyan-400" />
                    <span>Live Preview Mounting & Browser Environment Verification</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    runtimeMetric.status === 'HEALTHY'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {runtimeMetric.status}
                  </span>
                </div>
                <div className="text-[11px] text-neutral-300 leading-relaxed">
                  Real-time validation of DOM mount tree, viewport geometry, React root presence, and canvas context availability.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">React Root Mount</div>
                  <div className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    {runtimeMetric.rootMounted ? 'MOUNTED & VERIFIED' : 'UNMOUNTED'}
                  </div>
                  <div className="text-[10px] text-neutral-500">Target: #root container in DOM</div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">Viewport Geometry</div>
                  <div className="text-sm font-bold text-cyan-300">
                    {runtimeMetric.viewportWidth} × {runtimeMetric.viewportHeight} px
                  </div>
                  <div className="text-[10px] text-neutral-500">Live browser preview resolution</div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">DOM Element Count</div>
                  <div className="text-sm font-bold text-neutral-200">
                    {runtimeMetric.domElementCount} Elements
                  </div>
                  <div className="text-[10px] text-neutral-500">Active rendered subtree</div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">Canvas 2D & DSP</div>
                  <div className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    {runtimeMetric.canvasAvailable ? 'AVAILABLE' : 'UNAVAILABLE'}
                  </div>
                  <div className="text-[10px] text-neutral-500">Zero-latency generation fallback</div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">Active Workspace View</div>
                  <div className="text-sm font-bold text-purple-300 font-mono">
                    {runtimeMetric.activeView}
                  </div>
                  <div className="text-[10px] text-neutral-500">Landing default view mode</div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544] space-y-1">
                  <div className="text-[10px] text-neutral-400 font-bold uppercase">Runtime Exceptions</div>
                  <div className={`text-sm font-bold ${runtimeMetric.errorCount === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {runtimeMetric.errorCount} Errors
                  </div>
                  <div className="text-[10px] text-neutral-500">Captured in error boundary</div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TRUTH CLASSIFICATION */}
          {activeSubTab === 'TRUTH' && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-[#091024] border border-[#18284C] space-y-2">
                <div className="font-bold text-white text-xs flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  Zero Fabrication & Execution Truth Guarantee
                </div>
                <div className="text-[11px] text-neutral-300 leading-relaxed">
                  GODEX strictly forbids generating fake progress, fabricated neural frames, or simulating AI diffusion without genuine execution.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                  <div className="text-emerald-400 font-bold text-xs font-mono">REAL_NEURAL</div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Output produced by actual local GPU / ComfyUI / PyTorch diffusion model inference with verified binary hash and containers.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                  <div className="text-cyan-400 font-bold text-xs font-mono">LOCAL_DETERMINISTIC</div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Deterministic browser Canvas 2D, WebGL shaders, Web Audio DSP, and pixel enhancement. No cloud cost, 100% offline.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                  <div className="text-amber-400 font-bold text-xs font-mono">REQUIRES_ENGINE</div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Truthfully informs the user that a neural diffusion cluster or local inference server is required. Never generates synthetic fakes.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#080E1E] border border-[#162544]">
                  <div className="text-rose-400 font-bold text-xs font-mono">UNAVAILABLE</div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Engine or hardware accelerator is not present on the host system.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="h-12 border-t border-[#141E33] bg-[#0A0F1D] px-4 sm:px-6 flex items-center justify-between shrink-0 text-xs font-mono">
          <span className="text-neutral-500 text-[10px]">
            Audited at: {hwReport?.timestamp ? new Date(hwReport.timestamp).toLocaleTimeString() : ((hwReport as any)?.auditTimestamp ? new Date((hwReport as any).auditTimestamp).toLocaleTimeString() : 'N/A')}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
          >
            Close Panel
          </button>
        </div>
      </div>
    </div>
  );
};
