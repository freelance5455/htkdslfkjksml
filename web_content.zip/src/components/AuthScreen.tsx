import React, { useState } from 'react';
import { UserProfile } from '../types';
import { db } from '../firebase';
import { doc, getDoc, setDoc, collection, getDocs } from 'firebase/firestore';
import { generateUniqueAsefId, STORAGE_KEY } from '../utils/helpers';
import { playAppSound } from '../utils/audio';
import { Crown, Sparkles, User, Lock, UserCheck, PhoneCall, Download } from 'lucide-react';
import { InstallAppModal } from './InstallAppModal';

interface AuthScreenProps {
  onLoginSuccess: (user: UserProfile) => void;
  onToast: (msg: string) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess, onToast }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [loading, setLoading] = useState(false);
  const [showInstallModal, setShowInstallModal] = useState(false);

  // Login form
  const [loginId, setLoginId] = useState('');
  const [loginPass, setLoginPass] = useState('');

  // Register form
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regGender, setRegGender] = useState<'male' | 'female'>('male');
  const [regPass, setRegPass] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const idInput = loginId.trim();
    const pass = loginPass.trim();
    if (!idInput || !pass) {
      onToast('يرجى ملء جميع الحقول لتسجيل الدخول');
      return;
    }

    setLoading(true);
    try {
      let found: UserProfile | null = null;

      // 1. Check if user document directly exists by ID
      try {
        const directDoc = await getDoc(doc(db, 'users', idInput));
        if (directDoc.exists()) {
          const d = directDoc.data() as UserProfile;
          if (d.pass === pass) found = d;
        }
      } catch (err) {
        console.warn('Direct doc query err', err);
      }

      // 2. Query all users collection if not found directly
      if (!found) {
        try {
          const snap = await getDocs(collection(db, 'users'));
          snap.forEach((d) => {
            const data = d.data() as UserProfile;
            if (
              (data.id === idInput ||
                data.username?.toLowerCase() === idInput.toLowerCase() ||
                data.name === idInput) &&
              data.pass === pass
            ) {
              found = data;
            }
          });
        } catch (err) {
          console.warn('Collection scan err', err);
        }
      }

      // 3. Fallback to localStorage offline session if Firestore failed
      if (!found) {
        const offlineUsersRaw = localStorage.getItem(STORAGE_KEY + '_users');
        if (offlineUsersRaw) {
          try {
            const list: UserProfile[] = JSON.parse(offlineUsersRaw);
            const offlineFound = list.find(
              (u) =>
                (u.id === idInput ||
                  u.username.toLowerCase() === idInput.toLowerCase() ||
                  u.name === idInput) &&
                u.pass === pass
            );
            if (offlineFound) found = offlineFound;
          } catch {
            // ignore
          }
        }
      }

      if (found) {
        // Special founder upgrade if applicable
        if (found.username.toLowerCase() === 'alhtmy1577') {
          found.id = 'ASEF-777777';
          found.rank = '👑 المؤسس الملكي';
          found.points = Math.max(found.points || 0, 1000000);
          found.vipLevel = 20;
          found.avatar =
            'https://firebasestorage.googleapis.com/v0/b/asef-web-86bcb.appspot.com/o/profiles%2F1000070297.png?alt=media';
          try {
            await setDoc(doc(db, 'users', 'ASEF-777777'), found, { merge: true });
          } catch {
            // ignore
          }
        }

        found.online = true;
        playAppSound('vip');
        onLoginSuccess(found);
        onToast(`أهلاً بعودتك يا ${found.name} 👑`);
      } else {
        playAppSound('alert');
        onToast('معرّف الحساب أو كلمة المرور غير صحيحة');
      }
    } catch (err) {
      console.error(err);
      onToast('تعذر الاتصال بالخادم، يرجى المحاولة ثانية');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = async () => {
    setLoading(true);
    try {
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      const demoId = `ASEF-TEST-${randomNum}`;
      const demoUser: UserProfile = {
        id: demoId,
        name: `عضو تجريبي ${randomNum}`,
        username: `guest_${randomNum}`,
        gender: 'male',
        points: 50,
        vipLevel: 3,
        rank: 'عضو نشط ⭐',
        statusText: 'أنا عضو لتجربة تطبيق عالم عاصف الفاخر 👑',
        pass: '1234',
        online: true,
        lastSeen: new Date().toISOString()
      };
      try {
        await setDoc(doc(db, 'users', demoId), demoUser, { merge: true });
      } catch {
        // ignore
      }
      playAppSound('vip');
      onLoginSuccess(demoUser);
      onToast(`مرحباً بك! تم الدخول بحساب تجريبي (${demoUser.name})`);
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء الدخول التجريبي');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = regName.trim();
    const username = regUsername.trim().toLowerCase().replace(/\s+/g, '');
    const pass = regPass.trim();

    if (!name || !username || pass.length < 4) {
      onToast('يرجى إدخال اسم صحيح واسم مستخدم وكلمة مرور 4 خانات على الأقل');
      return;
    }

    setLoading(true);
    try {
      // Check if username is already taken to prevent duplicates
      let usernameTaken = false;
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        usersSnap.forEach((d) => {
          const u = d.data() as UserProfile;
          if (u.username && u.username.toLowerCase() === username.toLowerCase()) {
            usernameTaken = true;
          }
        });
      } catch (err) {
        console.warn('Check username error:', err);
      }

      if (!usernameTaken) {
        const offlineUsersRaw = localStorage.getItem(STORAGE_KEY + '_users');
        if (offlineUsersRaw) {
          try {
            const list: UserProfile[] = JSON.parse(offlineUsersRaw);
            if (list.some((u) => u.username && u.username.toLowerCase() === username.toLowerCase())) {
              usernameTaken = true;
            }
          } catch {}
        }
      }

      if (usernameTaken) {
        playAppSound('alert');
        onToast('⚠️ اسم المستخدم هذا مستخدم بالفعل! يرجى اختيار اسم مستخدم آخر.');
        setLoading(false);
        return;
      }

      let id = generateUniqueAsefId();
      let rank = 'عضو ذهبي 👑';
      let points = 10;
      let vipLevel = 0;
      let avatar = '';

      // Check founder username
      const isFounder = username.toLowerCase() === 'alhtmy1577';

      if (isFounder) {
        id = 'ASEF-777777';
        rank = '👑 المؤسس الملكي';
        points = 1000000;
        vipLevel = 20;
        avatar =
          'https://firebasestorage.googleapis.com/v0/b/asef-web-86bcb.appspot.com/o/profiles%2F1000070297.png?alt=media';
      }

      // Referral credit
      const pendingRef = localStorage.getItem(STORAGE_KEY + '_pending_ref');
      if (pendingRef && pendingRef !== id) {
        points += 5; // Bonus for invited user
        try {
          const refDoc = await getDoc(doc(db, 'users', pendingRef));
          if (refDoc.exists()) {
            const pData = refDoc.data() as UserProfile;
            const newPoints = (pData.points || 0) + 5;
            await setDoc(doc(db, 'users', pendingRef), { points: newPoints }, { merge: true });
          }
        } catch {
          // ignore
        }
        localStorage.removeItem(STORAGE_KEY + '_pending_ref');
      }

      const newUser: UserProfile = {
        id,
        name,
        username,
        gender: regGender,
        pass,
        avatar,
        rank,
        points,
        vipLevel,
        online: true,
        lastSeen: new Date().toISOString(),
        statusText: 'مرحباً، أنا أستخدم عالم عاصف الفاخر 👑'
      };

      // Save to Firestore
      try {
        await setDoc(doc(db, 'users', id), newUser);
      } catch (err) {
        console.warn('Firestore write warning:', err);
      }

      // Save to local storage list
      try {
        const offlineUsersRaw = localStorage.getItem(STORAGE_KEY + '_users') || '[]';
        const list = JSON.parse(offlineUsersRaw);
        list.push(newUser);
        localStorage.setItem(STORAGE_KEY + '_users', JSON.stringify(list));
      } catch {
        // ignore
      }

      playAppSound('vip');
      onLoginSuccess(newUser);
      onToast(`تم إنشاء حسابك الملكي بنجاح! معرّفك هو: ${id} 🎉`);
    } catch (err) {
      console.error(err);
      onToast('حدث خطأ أثناء إنشاء الحساب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
      <div className="w-full max-w-md glass-panel-heavy rounded-3xl border border-white/10 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#00a884] to-[#25d366] text-black mb-3 shadow-lg shadow-[#00a884]/30">
            <Crown className="w-9 h-9" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-wide text-white flex items-center justify-center gap-2">
            <span>ASEF</span>
            <span className="text-[#25d366]">|</span>
            <span className="text-gray-100">عالم عاصف</span>
          </h1>
          <p className="text-xs text-[#00a884] font-bold tracking-widest mt-1">
            LUXURY MESSENGER PRO
          </p>
          <p className="text-[11px] text-gray-400 mt-1">
            تواصل فوري فائق السرعة، ومجموعات ملكية، ونظام رتب فاخر
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex bg-black/40 p-1.5 rounded-2xl border border-white/10 mb-6">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              playAppSound('click');
            }}
            className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition duration-200 flex items-center justify-center gap-1.5 ${
              mode === 'login'
                ? 'bg-[#25d366] text-black shadow-md shadow-[#25d366]/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>تسجيل الدخول</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              playAppSound('click');
            }}
            className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition duration-200 flex items-center justify-center gap-1.5 ${
              mode === 'register'
                ? 'bg-[#25d366] text-black shadow-md shadow-[#25d366]/20'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>إنشاء حساب ملكي</span>
          </button>
        </div>

        {/* Login form */}
        {mode === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5 text-right">
                معرّف ASEF أو اسم المستخدم
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="مثال: ASEF-777777 أو alhtmy1577"
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  className="w-full glass-input rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 outline-none focus:border-[#25d366] transition"
                />
                <User className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5 text-right">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  placeholder="كلمة المرور الخاصة بك"
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  className="w-full glass-input rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 outline-none focus:border-[#25d366] transition"
                />
                <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-[#25d366] hover:bg-[#20ba59] active:scale-[0.99] text-black font-black text-sm transition duration-200 shadow-lg shadow-[#25d366]/25 mt-2 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{loading ? 'جارِ التحقق والدخول...' : 'دخول إلى التطبيق الملكي ✦'}</span>
            </button>

            <button
              type="button"
              onClick={handleQuickDemoLogin}
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:scale-[0.99] border border-white/10 text-gray-300 hover:text-white text-xs font-semibold transition duration-200 flex items-center justify-center gap-1.5 cursor-pointer"
              title="دخول فوري بحساب جديد لتجربة التطبيق بين نافذتين أو جهازين"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#ffd700]" />
              <span>دخول تجريبي سريع (حساب ضيف للتجربة الفورية ⚡)</span>
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1 text-right">
                الاسم الظاهر
              </label>
              <input
                type="text"
                required
                maxLength={35}
                placeholder="اسمك الكامل أو اللقب الفاخر"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                className="w-full glass-input rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-500 outline-none focus:border-[#25d366] transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1 text-right">
                اسم المستخدم (Username)
              </label>
              <input
                type="text"
                required
                maxLength={24}
                placeholder="اسم المستخدم بالإنجليزية بدون مسافات"
                value={regUsername}
                onChange={(e) => setRegUsername(e.target.value)}
                className="w-full glass-input rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-500 outline-none focus:border-[#25d366] transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1 text-right">
                  الجنس
                </label>
                <select
                  value={regGender}
                  onChange={(e) => setRegGender(e.target.value as 'male' | 'female')}
                  className="w-full glass-input rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-[#25d366] transition bg-[#111b21]"
                >
                  <option value="male">ذكر</option>
                  <option value="female">أنثى</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1 text-right">
                  كلمة المرور
                </label>
                <input
                  type="password"
                  required
                  minLength={4}
                  placeholder="4 خانات على الأقل"
                  value={regPass}
                  onChange={(e) => setRegPass(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-[#25d366] transition"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#00a884] via-[#25d366] to-[#00a884] hover:opacity-95 text-black font-black text-sm transition duration-200 shadow-lg shadow-[#25d366]/25 mt-2 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{loading ? 'جارِ تأسيس الحساب...' : 'إنشاء حسابي الموثّق 👑'}</span>
            </button>
          </form>
        )}

        {/* Install App on Phone Button */}
        <div className="mt-4 pt-3 border-t border-white/5">
          <button
            type="button"
            onClick={() => {
              playAppSound('click');
              setShowInstallModal(true);
            }}
            className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-[#25d366]/15 via-[#00a884]/15 to-[#25d366]/15 hover:from-[#25d366]/25 hover:to-[#25d366]/25 border border-[#25d366]/30 text-white font-black text-xs transition duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#25d366]/10"
          >
            <Download className="w-4 h-4 text-[#25d366] animate-bounce" />
            <span>كيفية تنزيل وتثبيت التطبيق على هاتفك 📲</span>
          </button>
        </div>

        {/* Developer Contact Footer */}
        <div className="mt-4 pt-3 border-t border-white/10 text-center">
          <p className="text-[11px] text-gray-400">
            تطوير وإشراف الأستاذ عاصف الحاتمي
          </p>
          <a
            href="https://wa.me/967738654396"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-[#25d366] font-semibold mt-1 hover:underline"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>+967 738 654 396 (واتساب الدعم الفني)</span>
          </a>
        </div>
      </div>

      {/* Install App Modal */}
      <InstallAppModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
        onToast={onToast}
      />
    </div>
  );
};
