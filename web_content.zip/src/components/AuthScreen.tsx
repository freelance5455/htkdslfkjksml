import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { BookOpen, Building2, Download, Globe, MessageCircle, Moon, ShieldCheck, Sun, Users } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { auth } from '../lib/firebase';
import { BUILTIN_COURSES, TEVETA_COLLEGES } from '../lib/tevetaCatalog';
import type { LanguageCode, ThemeMode, UserRole } from '../types';
import { TRANSLATIONS } from '../lib/i18n';
import { DownloadAppModal } from './DownloadAppModal';
import { TevetaCollegeNoticeModal } from './TevetaCollegeNoticeModal';

interface AuthScreenProps {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  onPendingRegistrationProfile: (draft: {
    fullName: string;
    username: string;
    phone: string;
    college: string;
    course: string;
    level: string;
    role: UserRole;
  }) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  language,
  setLanguage,
  theme,
  setTheme,
  onPendingRegistrationProfile,
}) => {
  const t = TRANSLATIONS[language];
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [college, setCollege] = useState(TEVETA_COLLEGES[0]);
  const [course, setCourse] = useState(BUILTIN_COURSES[0].name);
  const [level, setLevel] = useState('Level 1');
  const [role, setRole] = useState<UserRole>('student');
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [downloadOpen, setDownloadOpen] = useState(false);

  const handleGoogleSignIn = async () => {
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed';
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === 'reset') {
        await sendPasswordResetEmail(auth, email.trim());
        setInfo('Password reset link sent to your email address.');
        setBusy(false);
        return;
      }

      if (mode === 'register') {
        const cleanUsername = username.trim().replace(/[^a-zA-Z0-9_.]/g, '').toLowerCase();
        if (fullName.trim().length < 2 || cleanUsername.length < 3) {
          setError('Enter your full name and a username (at least 3 letters/numbers).');
          setBusy(false);
          return;
        }
        onPendingRegistrationProfile({
          fullName: fullName.trim(),
          username: cleanUsername,
          phone: phone.trim(),
          college,
          course,
          level,
          role: role === 'admin' ? 'student' : role,
        });
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: fullName.trim() });
        try {
          await sendEmailVerification(cred.user);
        } catch {
          // Email verification optional if SMTP suppressed
        }
        return;
      }

      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication failed';
      if (msg.includes('auth/operation-not-allowed')) {
        setError(
          'Email/Password sign-in is not enabled yet in Firebase Console. Use "Continue with Google" below, or enable Email/Password under Firebase Console > Authentication > Sign-in method.'
        );
      } else {
        setError(msg);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Top Bar */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/src/assets/images/tevet_app_logo_1794522896439.jpg"
              alt="TEVET POWER APP logo"
              className="w-9 h-9 rounded-xl object-cover shrink-0"
              referrerPolicy="no-referrer"
            />
            <span className="font-display font-bold text-lg tracking-tight text-blue-700 dark:text-blue-400 whitespace-nowrap">
              {t.appName}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setDownloadOpen(true)}
              className="min-h-[40px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download App</span>
            </button>
            <button
              type="button"
              onClick={() => setLanguage(language === 'en' ? 'ny' : 'en')}
              className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>{language === 'en' ? 'Chichewa' : 'English'}</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              aria-label="Toggle theme"
              className="min-h-[40px] min-w-[40px] rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Split Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 lg:py-12 grid lg:grid-cols-12 gap-8 items-stretch">
        {/* Left Editorial Hero */}
        <section className="lg:col-span-7 flex flex-col justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="relative h-64 sm:h-80 lg:h-96 overflow-hidden bg-blue-900">
            <img
              src="/src/assets/images/hero_workshop_banner_1794522898239.jpg"
              alt="Malawi TEVETA technical college students testing solar panels"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent flex flex-col justify-end p-6 sm:p-8">
              <p className="text-xs font-medium text-emerald-300 tracking-wide mb-2">
                Malawi Technical & Vocational Education Network
              </p>
              <h1 className="font-display text-2xl sm:text-4xl font-bold text-white leading-tight max-w-xl [text-wrap:balance]">
                {t.tagline}
              </h1>
            </div>
          </div>

          <div className="p-6 sm:p-8 grid sm:grid-cols-3 gap-6 border-t border-slate-100 dark:border-slate-800">
            <div>
              <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 flex items-center justify-center mb-3">
                <BookOpen className="w-5 h-5" />
              </div>
              <h2 className="font-display font-semibold text-sm mb-1">TEVETA Digital Library</h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                7 common subjects, trade courses, practical manuals, fundamentals, and offline study packs.
              </p>
            </div>
            <div>
              <div className="w-9 h-9 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center mb-3">
                <MessageCircle className="w-5 h-5" />
              </div>
              <h2 className="font-display font-semibold text-sm mb-1">Chats, Groups & Calls</h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Private chats, voice notes, 24h status updates, study groups, and WebRTC voice & video calls.
              </p>
            </div>
            <div>
              <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 flex items-center justify-center mb-3">
                <Users className="w-5 h-5" />
              </div>
              <h2 className="font-display font-semibold text-sm mb-1">TEVET AI & Community</h2>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Bilingual English & Chichewa AI study tutor tailored to your technical trade and level.
              </p>
            </div>
          </div>

          <div className="px-6 sm:px-8 py-4 bg-blue-50/80 dark:bg-blue-950/30 border-t border-blue-100 dark:border-blue-900/60 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-2.5 max-w-xl">
              <Building2 className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <p className="text-xs font-display font-bold text-blue-900 dark:text-blue-200">
                  {t.studentNotice.headline}
                </p>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  {t.studentNotice.summary}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setNoticeOpen(true)}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-400 text-xs font-semibold hover:bg-blue-50 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              {t.studentNotice.viewCollegesBtn}
            </button>
          </div>
        </section>

        {/* Right Authentication Card */}
        <section className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-center">
          <div className="mb-6">
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              {mode === 'login' ? 'Sign in to TEVET POWER' : mode === 'register' ? 'Create Learner Account' : 'Reset Password'}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Connect with technical college learners, instructors, and verified TEVETA resources.
            </p>
          </div>

          {/* Primary Google Sign-In */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={busy}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold text-sm flex items-center justify-center gap-2.5 transition-colors disabled:opacity-60 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{t.actions.signInGoogle}</span>
          </button>

          <div className="my-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
            <span className="text-xs text-slate-400">or with email & password</span>
            <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'login'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Register
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('reset');
                setError(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'reset'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Reset
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/50 text-xs text-red-700 dark:text-red-300">
              {error}
            </div>
          )}
          {info && (
            <div className="mb-4 p-3 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/50 text-xs text-emerald-700 dark:text-emerald-300">
              {info}
            </div>
          )}

          <form onSubmit={handleEmailAuth} className="space-y-3">
            {mode === 'register' && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Chisomo Banda"
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Username</label>
                    <input
                      type="text"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="chisomo_pv"
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Phone (Optional)</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0999 000 000"
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Role</label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserRole)}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      <option value="student">TEVETA Student</option>
                      <option value="graduate">Graduate / Artisan</option>
                      <option value="instructor">Technical Instructor</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">College</label>
                    <select
                      value={college}
                      onChange={(e) => setCollege(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      {TEVETA_COLLEGES.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Programme / Level</label>
                    <select
                      value={course}
                      onChange={(e) => setCourse(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      {BUILTIN_COURSES.map((c) => (
                        <option key={c.id} value={c.name}>{c.trade}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@college.mw"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            {mode !== 'reset' && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Password</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-colors disabled:opacity-60 cursor-pointer"
            >
              {busy
                ? 'Please wait...'
                : mode === 'login'
                ? 'Sign In'
                : mode === 'register'
                ? 'Create Account'
                : 'Send Reset Link'}
            </button>
          </form>
        </section>
      </main>

      <TevetaCollegeNoticeModal
        open={noticeOpen}
        onClose={() => setNoticeOpen(false)}
        language={language}
      />

      <DownloadAppModal
        open={downloadOpen}
        onClose={() => setDownloadOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        isIOS={isIOS}
        onInstallPWA={install}
      />
    </div>
  );
};
