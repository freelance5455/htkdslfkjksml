import React, { useEffect, useRef, useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { motion } from 'motion/react';
import { CheckCircle2, Loader2, ShieldAlert, ShieldCheck, X } from 'lucide-react';
import {
  auth,
  authPersistenceReady,
  getCurrentAuthDomainDiagnostics,
  googleProvider,
} from '../lib/firebase';
import { mapFirebaseAuthError } from '../utils/authHelpers';
import { Logo } from './Logo';

interface AuthScreenProps {
  onAuthenticated: () => void;
  onSelectEntryIntent?: (intent: 'student' | 'admin') => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onAuthenticated,
  onSelectEntryIntent,
}) => {
  const [loadingIntent, setLoadingIntent] = useState<'student' | 'admin' | null>(null);
  const [verifiedSuccess, setVerifiedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [legalModal, setLegalModal] = useState<'terms' | 'privacy' | null>(null);

  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const handleGoogleSignIn = async (intent: 'student' | 'admin') => {
    if (loadingIntent) return;
    setErrorMessage(null);
    setLoadingIntent(intent);
    onSelectEntryIntent?.(intent);
    try {
      await authPersistenceReady;
      await signInWithPopup(auth, googleProvider);
      if (!isMountedRef.current) return;
      setVerifiedSuccess(true);
      window.setTimeout(() => {
        onAuthenticated();
      }, 250);
    } catch (err) {
      if (!isMountedRef.current) return;
      const { currentHostname } = getCurrentAuthDomainDiagnostics();
      setErrorMessage(mapFirebaseAuthError(err, currentHostname));
    } finally {
      if (isMountedRef.current) {
        setLoadingIntent(null);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#060C1D] text-white relative overflow-hidden flex items-center justify-center px-4 py-8 sm:px-8">
      {/* Dark navy + blue neon & purple atmospheric glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -top-32 -left-24 h-96 w-96 rounded-full opacity-40 blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(56,189,248,0.4) 0%, transparent 72%)',
        }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -bottom-32 -right-24 h-[420px] w-[420px] rounded-full opacity-40 blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(139,92,246,0.38) 0%, transparent 72%)',
        }}
      />

      <div className="relative z-10 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Desktop Brand Showcase */}
        <div className="hidden lg:flex lg:col-span-5 flex-col justify-center space-y-6 pr-4">
          <div className="flex items-center gap-4">
            <Logo size="lg" glow />
            <div>
              <p className="font-display text-2xl font-bold text-white tracking-tight">
                EduToon Education
              </p>
              <p className="text-xs font-semibold tracking-[0.18em] text-sky-300 mt-1">
                ANIMATION SE AASAAN PADHAI
              </p>
            </div>
          </div>

          <h1 className="font-display text-3xl xl:text-4xl font-bold leading-tight text-white">
            Animated learning for Classes 1 to 10 in Hindi &amp; English.
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            Sign in or create your student account in one tap with Google. Your selected medium,
            locked academic class, chapter notes, saved bookmarks, and video watch progress sync
            securely across visits.
          </p>

          <div className="space-y-3 text-sm text-slate-200 pt-2">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-4 w-4 text-sky-400 shrink-0" />
              <span>Instant student account setup via Google Sign-In</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-4 w-4 text-purple-400 shrink-0" />
              <span>Classes 1 to 10 bilingual notes, PDFs &amp; animated videos</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-4 w-4 text-sky-400 shrink-0" />
              <span>Persistent login session across devices</span>
            </div>
          </div>
        </div>

        {/* Google-Only Student Login Card */}
        <div className="lg:col-span-7 w-full max-w-md mx-auto">
          <div className="rounded-3xl bg-[#0D1633]/95 border border-sky-400/25 shadow-[0_24px_60px_rgba(2,6,23,0.75)] p-6 sm:p-8 backdrop-blur-md">
            {/* Official EduToon Logo + App Name + Tagline */}
            <div className="flex flex-col items-center text-center mb-7">
              <Logo size="lg" glow />
              <h2 className="mt-4 font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                EduToon Education
              </h2>
              <p className="mt-1.5 text-xs font-semibold tracking-[0.18em] text-sky-300">
                ANIMATION SE AASAAN PADHAI
              </p>
              <p className="mt-4 text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xs">
                Sign in with your Google Account to start learning or continue where you left off.
              </p>
            </div>

            {verifiedSuccess && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-5 p-4 rounded-2xl bg-emerald-500/15 border border-emerald-400/40 text-emerald-200 text-sm font-semibold flex items-center gap-3"
              >
                <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                <span>Signed in! Verifying your EduToon workspace...</span>
              </motion.div>
            )}

            {errorMessage && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-5 p-3.5 rounded-2xl bg-red-500/15 border border-red-400/40 text-red-200 text-xs sm:text-sm flex items-start gap-2.5"
              >
                <ShieldAlert className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </motion.div>
            )}

            {/* Primary Continue with Google Button (Student) */}
            <button
              type="button"
              onClick={() => handleGoogleSignIn('student')}
              disabled={Boolean(loadingIntent) || verifiedSuccess}
              className="w-full min-h-[54px] px-5 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 hover:from-sky-400 hover:via-blue-500 hover:to-indigo-500 border border-sky-300/40 disabled:opacity-60 text-white text-sm sm:text-base font-bold flex items-center justify-center gap-3 shadow-[0_0_28px_rgba(56,189,248,0.48)] transition-all cursor-pointer"
            >
              {loadingIntent === 'student' ? (
                <Loader2 className="h-5 w-5 animate-spin text-white" />
              ) : (
                <span className="h-7 w-7 rounded-lg bg-white flex items-center justify-center shrink-0">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                    />
                  </svg>
                </span>
              )}
              <span>
                {loadingIntent === 'student'
                  ? 'Connecting Google Account...'
                  : 'Continue with Google'}
              </span>
            </button>

            <p className="mt-3 text-center text-xs text-slate-400">
              Students sign in or create their account automatically with Google.
            </p>

            {/* Clearly Visible Separate Admin Panel Entry */}
            <div className="mt-6 pt-5 border-t border-slate-800/90 space-y-2.5">
              <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-purple-300">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-purple-400" />
                  <span>Separate Admin Entry</span>
                </span>
                <span className="text-slate-400">Authorized Only</span>
              </div>
              <button
                type="button"
                onClick={() => handleGoogleSignIn('admin')}
                disabled={Boolean(loadingIntent) || verifiedSuccess}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-[#131F47] hover:bg-[#192859] border border-purple-400/40 hover:border-purple-300/70 disabled:opacity-60 text-purple-100 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer"
              >
                {loadingIntent === 'admin' ? (
                  <Loader2 className="h-4 w-4 animate-spin text-purple-300" />
                ) : (
                  <ShieldCheck className="h-4 w-4 text-purple-300 shrink-0" />
                )}
                <span>
                  {loadingIntent === 'admin'
                    ? 'Verifying Admin Google Account...'
                    : 'Admin Panel Login with Google'}
                </span>
              </button>
            </div>

            {/* Terms & Privacy Footer */}
            <p className="mt-6 pt-4 border-t border-slate-800 text-center text-[11px] sm:text-xs text-slate-400 leading-relaxed">
              By continuing, you agree to EduToon Education&apos;s{' '}
              <button
                type="button"
                onClick={() => setLegalModal('terms')}
                className="text-sky-300 hover:text-sky-200 underline underline-offset-2 cursor-pointer"
              >
                Terms of Service
              </button>{' '}
              and{' '}
              <button
                type="button"
                onClick={() => setLegalModal('privacy')}
                className="text-sky-300 hover:text-sky-200 underline underline-offset-2 cursor-pointer"
              >
                Privacy Policy
              </button>
              .
            </p>
          </div>
        </div>
      </div>

      {/* Terms & Privacy Modal */}
      {legalModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[#0D1633] border border-slate-700 p-6 text-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Logo size="xs" />
                <h3 className="font-display text-lg font-bold text-white">
                  {legalModal === 'terms'
                    ? 'EduToon Education — Terms of Service'
                    : 'EduToon Education — Privacy Policy'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setLegalModal(null)}
                aria-label="Close"
                className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="text-xs sm:text-sm text-slate-300 leading-relaxed space-y-2.5">
              {legalModal === 'terms' ? (
                <>
                  <p>
                    EduToon Education provides animated video lessons, chapter-wise study notes, and
                    PDF guides for Classes 1 to 10 in Hindi and English.
                  </p>
                  <p>
                    Once selected, your enrolled class remains locked for the active academic
                    session and may only be modified after administrator review of a Class Change
                    Report.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    We collect your Firebase UID, student name, Google email, profile photo, selected
                    learning medium, and enrolled class solely to maintain your educational
                    progress.
                  </p>
                  <p>
                    Personal contact information is isolated in private Firestore subcollections
                    readable only by your authenticated account and authorized administrators.
                  </p>
                </>
              )}
            </div>
            <button
              type="button"
              onClick={() => setLegalModal(null)}
              className="w-full min-h-[44px] rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
