import { useState, type FormEvent } from 'react';
import { ArrowRight, Lock, ShieldCheck, Smartphone, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';
import { apiRequest, setAuthToken } from '../api.ts';
import type { ServiceItem, UserProfile } from '../types.ts';
import { formatInr, formatNumber } from '../utils/format.ts';

interface AuthScreenProps {
  services: ServiceItem[];
  paymentMode: 'upi_direct' | 'razorpay';
  onAuthenticated: (user: UserProfile) => void;
  onOpenDeployGuide: () => void;
}

export function AuthScreen({
  services,
  paymentMode,
  onAuthenticated,
  onOpenDeployGuide,
}: AuthScreenProps) {
  const [portal, setPortal] = useState<'customer' | 'admin'>('customer');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const switchPortal = (nextPortal: 'customer' | 'admin') => {
    setPortal(nextPortal);
    setError('');
    setEmail('');
    setPassword('');
    if (nextPortal === 'admin') {
      setMode('login');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      if (portal === 'customer' && mode === 'register') {
        const res = await apiRequest<{ token?: string; user: UserProfile }>('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({ name, email, phone, password }),
        });
        if (res.token) setAuthToken(res.token);
        onAuthenticated(res.user);
      } else {
        const res = await apiRequest<{ token?: string; user: UserProfile }>('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password, portal }),
        });
        if (res.token) setAuthToken(res.token);
        onAuthenticated(res.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen text-slate-100 flex flex-col">
      {/* Clean 3-zone top bar */}
      <header className="border-b border-white/12 bg-[#0a0b22]/85 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <div className="h-8 w-8 rounded-lg btn-gradient-primary flex items-center justify-center shadow-md shadow-fuchsia-500/25">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <span className="text-base font-extrabold tracking-tight text-gradient-aurora whitespace-nowrap shrink-0">
              SOCIAL BOOST
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300">
            <a href="#pricing-preview" className="hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0">
              Reference Pricing
            </a>
            <a href="#compliance" className="hover:text-fuchsia-300 transition-colors whitespace-nowrap shrink-0">
              Policy Compliance
            </a>
            <button
              type="button"
              onClick={onOpenDeployGuide}
              className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Deploy & APK Guide
            </button>
          </nav>

          <button
            type="button"
            onClick={() => switchPortal(portal === 'customer' ? 'admin' : 'customer')}
            className="min-h-[40px] px-4 py-2 rounded-lg border border-fuchsia-400/30 bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-xs font-semibold text-fuchsia-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {portal === 'customer' ? 'Admin Console' : 'Customer Sign In'}
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-8 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left column: Value proposition + transparent reference pricing */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="lg:col-span-7 space-y-8"
        >
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium">
              <span className="text-fuchsia-300">Creator Campaign Platform</span>
              <span aria-hidden="true" className="text-slate-500">·</span>
              <span className="text-cyan-300">
                {paymentMode === 'razorpay' ? 'Razorpay Live Gateway' : 'UPI QR & Gateway Checkout'}
              </span>
              <span aria-hidden="true" className="text-slate-500">·</span>
              <span className="text-emerald-300">Android & Web Ready</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-[1.12] [text-wrap:balance] text-gradient-aurora">
              Transparent social reach campaigns built for modern creators.
            </h1>

            <p className="text-base text-slate-200 leading-relaxed max-w-2xl">
              Launch compliant creator promotion campaigns with instant custom quantity pricing,{' '}
              <span className="text-cyan-300 font-semibold">UPI QR &amp; app checkout</span>, and real-time order
              tracking from any Android phone or desktop browser.
            </p>
          </div>

          {/* Transparent Pricing Reference Table */}
          <section id="pricing-preview" className="rounded-2xl sb-surface overflow-hidden">
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between gap-4">
              <div>
                <h2 className="text-sm font-bold text-gradient-sunset">Approved Service Reference Rates</h2>
                <p className="text-xs text-slate-300 mt-0.5">
                  Formula: Total price = (Selected quantity &divide; Reference quantity) &times; Reference price
                </p>
              </div>
              <span className="text-xs font-mono font-semibold text-cyan-300 whitespace-nowrap shrink-0">INR (₹)</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-xs text-slate-300">
                    <th className="px-5 py-3 font-medium">Service</th>
                    <th className="px-5 py-3 font-medium text-right">Reference Quantity</th>
                    <th className="px-5 py-3 font-medium text-right">Reference Price</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.08]">
                  {services.map((svc, idx) => {
                    const nameColors = [
                      'text-cyan-300',
                      'text-pink-300',
                      'text-violet-300',
                      'text-emerald-300',
                    ];
                    return (
                      <tr key={svc.id} className="hover:bg-white/[0.04] transition-colors">
                        <td className="px-5 py-3.5">
                          <div className={`font-semibold ${nameColors[idx % nameColors.length]}`}>{svc.name}</div>
                          <div className="text-xs text-slate-400 mt-0.5">{svc.category}</div>
                        </td>
                        <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-200">
                          {formatNumber(svc.reference_quantity)}
                        </td>
                        <td className="px-5 py-3.5 text-right font-mono tabular-nums font-bold text-gradient-sunset">
                          {formatInr(svc.reference_price_paise)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          {/* Compliance & Security Highlights */}
          <div id="compliance" className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="rounded-xl sb-surface p-4 space-y-2 border-emerald-400/20">
              <ShieldCheck className="h-5 w-5 text-emerald-400" />
              <h3 className="text-sm font-semibold text-emerald-200">Policy Compliant</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Only approved discovery placements. Never requests passwords or promises guaranteed counts.
              </p>
            </div>
            <div className="rounded-xl sb-surface p-4 space-y-2 border-cyan-400/20">
              <Lock className="h-5 w-5 text-cyan-400" />
              <h3 className="text-sm font-semibold text-cyan-200">Verified Payments</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Server-side price calculation and verified UPI UTR / webhook settlement—never trusts screenshots.
              </p>
            </div>
            <div className="rounded-xl sb-surface p-4 space-y-2 border-fuchsia-400/20">
              <Smartphone className="h-5 w-5 text-fuchsia-400" />
              <h3 className="text-sm font-semibold text-fuchsia-200">Mobile-First</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Built for 44px+ Android thumb ergonomics, UPI apps, and Android APK packaging.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Right column: Sign in / Register Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, delay: 0.05 }}
          className="lg:col-span-5 rounded-2xl sb-surface p-6 sm:p-8 space-y-6"
        >
          {/* Portal Switcher */}
          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl sb-surface-inner">
            <button
              type="button"
              onClick={() => switchPortal('customer')}
              className={`min-h-[44px] rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                portal === 'customer'
                  ? 'btn-gradient-primary text-white shadow-md shadow-fuchsia-500/20'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Customer Account
            </button>
            <button
              type="button"
              onClick={() => switchPortal('admin')}
              className={`min-h-[44px] rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                portal === 'admin'
                  ? 'btn-gradient-primary text-white shadow-md shadow-fuchsia-500/20'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Administrator
            </button>
          </div>

          <div className="space-y-1">
            <h2 className="text-xl font-bold text-gradient-aurora">
              {portal === 'admin'
                ? 'Administrator Sign In'
                : mode === 'login'
                  ? 'Sign in to SOCIAL BOOST'
                  : 'Create Customer Account'}
            </h2>
            <p className="text-xs text-slate-300">
              {portal === 'admin'
                ? 'Role-protected console for orders, UPI QR settings, pricing, and refunds.'
                : mode === 'login'
                  ? 'Access your dashboard, place custom orders, and track verified receipts.'
                  : 'Create your free account to place compliant social campaigns with instant INR pricing.'}
            </p>
          </div>

          {portal === 'customer' && (
            <div className="flex items-center gap-4 border-b border-white/10 text-sm">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                }}
                className={`pb-2.5 font-semibold border-b-2 transition-colors cursor-pointer ${
                  mode === 'login' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setEmail('');
                  setPassword('');
                  setError('');
                }}
                className={`pb-2.5 font-semibold border-b-2 transition-colors cursor-pointer ${
                  mode === 'register'
                    ? 'border-fuchsia-400 text-fuchsia-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Create Account
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {portal === 'customer' && mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-medium text-cyan-200 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-cyan-200 mb-1.5">Phone (Optional)</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98XXX XXXXX"
                    className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-medium text-cyan-200 mb-1.5">
                {portal === 'admin' ? 'Administrator User ID' : 'Email Address'}
              </label>
              <input
                type={portal === 'admin' ? 'text' : 'email'}
                required
                autoComplete={portal === 'admin' ? 'username' : 'email'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={portal === 'admin' ? 'Enter administrator user ID' : 'you@domain.com'}
                className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-fuchsia-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-cyan-200 mb-1.5">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={portal === 'admin' ? 'Enter administrator password' : 'Minimum 8 characters'}
                className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-fuchsia-400"
              />
            </div>

            {error && (
              <div className="rounded-xl bg-rose-500/15 border border-rose-400/40 px-3.5 py-2.5 text-xs text-rose-200">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[48px] rounded-xl btn-gradient-primary disabled:opacity-60 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-violet-600/25"
            >
              <span>
                {submitting
                  ? 'Authenticating...'
                  : portal === 'admin'
                    ? 'Sign In to Admin Panel'
                    : mode === 'register'
                      ? 'Create Account'
                      : 'Sign In'}
              </span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        </motion.div>
      </main>
    </div>
  );
}
