import React, { useState } from 'react';
import { Eye, EyeOff, KeyRound, Lock, Plus, Trash2, X } from 'lucide-react';
import { PROVIDER_META } from '../constants/models';
import type { ApiKeysMap, ModelOption, ProviderId } from '../types/mycode';

interface ApiKeysModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: ApiKeysMap;
  onSaveApiKeys: (nextKeys: ApiKeysMap) => Promise<void>;
  customModels: ModelOption[];
  onAddCustomModel: (model: ModelOption) => void;
  onRemoveCustomModel: (modelId: string) => void;
}

const PROVIDERS_ORDER: ProviderId[] = [
  'google',
  'groq',
  'openrouter',
  'zhipu',
  'openai',
  'anthropic',
];

export function ApiKeysModal({
  isOpen,
  onClose,
  apiKeys,
  onSaveApiKeys,
  customModels,
  onAddCustomModel,
  onRemoveCustomModel,
}: ApiKeysModalProps) {
  const [draftKeys, setDraftKeys] = useState<ApiKeysMap>(apiKeys);
  const [revealed, setRevealed] = useState<Record<ProviderId, boolean>>({
    google: false,
    groq: false,
    openrouter: false,
    zhipu: false,
    openai: false,
    anthropic: false,
  });
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const [newProvider, setNewProvider] = useState<ProviderId>('openrouter');
  const [newModelId, setNewModelId] = useState('');
  const [newModelLabel, setNewModelLabel] = useState('');
  const [newModelTier, setNewModelTier] = useState<'Free' | 'Paid'>('Free');

  if (!isOpen) return null;

  const handleSaveKeys = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSaveApiKeys(draftKeys);
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  const handleAddModel = (e: React.FormEvent) => {
    e.preventDefault();
    const id = newModelId.trim();
    if (!id) return;
    const label = newModelLabel.trim() || `${id} (${newModelTier})`;
    onAddCustomModel({
      id,
      label,
      provider: newProvider,
      tier: newModelTier,
      isCustom: true,
    });
    setNewModelId('');
    setNewModelLabel('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="API Keys and Custom Models"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full sm:max-w-xl overflow-y-auto rounded-t-3xl sm:rounded-2xl border border-[#E5E7EB] bg-white p-5 sm:p-6 shadow-2xl"
      >
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-[#E5E7EB] sm:hidden" />

        <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#E5E7EB]">
          <div>
            <h2 className="font-display text-lg font-bold text-[#111827]">API Keys & Models</h2>
            <p className="mt-1 flex items-center gap-1.5 text-[12px] text-[#6B7280]">
              <Lock className="h-3.5 w-3.5 text-[#4B5563]" />
              <span>Encrypted locally on this device using AES-GCM Web Crypto storage.</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#111827]"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        {/* Provider Keys Form */}
        <form onSubmit={handleSaveKeys} className="mt-5 space-y-4">
          {PROVIDERS_ORDER.map((provider) => {
            const meta = PROVIDER_META[provider];
            const isShown = revealed[provider];
            return (
              <div key={provider} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor={`key-${provider}`}
                    className="text-[13px] font-medium text-[#111827]"
                  >
                    {meta.keyLabel}
                  </label>
                  <span className="text-[11px] text-[#6B7280]">{meta.docsHint}</span>
                </div>
                <div className="relative flex items-center">
                  <KeyRound className="pointer-events-none absolute left-3 h-4 w-4 text-[#9CA3AF]" />
                  <input
                    id={`key-${provider}`}
                    type={isShown ? 'text' : 'password'}
                    value={draftKeys[provider]}
                    onChange={(e) =>
                      setDraftKeys((prev) => ({ ...prev, [provider]: e.target.value }))
                    }
                    placeholder={meta.placeholder}
                    autoComplete="off"
                    spellCheck={false}
                    className="w-full rounded-xl border border-[#E5E7EB] bg-white py-2.5 pl-9 pr-10 font-mono text-[12px] text-[#111827] placeholder:text-[#9CA3AF] focus:border-[#111827] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setRevealed((prev) => ({ ...prev, [provider]: !prev[provider] }))
                    }
                    aria-label={isShown ? `Hide ${meta.name} key` : `Show ${meta.name} key`}
                    className="absolute right-2 rounded-lg p-1.5 text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#111827]"
                  >
                    {isShown ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            );
          })}

          <div className="flex items-center justify-between pt-2">
            <span className="text-[12px] text-[#047857] font-medium">
              {savedNotice ? 'API keys encrypted and saved.' : ''}
            </span>
            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-[#111827] px-4 py-2.5 text-[13px] font-medium text-white hover:bg-[#1F2937] disabled:opacity-50 transition-colors"
            >
              {saving ? 'Encrypting...' : 'Save Keys'}
            </button>
          </div>
        </form>

        {/* Custom Models Section */}
        <div className="mt-6 pt-5 border-t border-[#E5E7EB]">
          <h3 className="font-display text-[14px] font-semibold text-[#111827]">
            Custom Model IDs
          </h3>
          <p className="mt-0.5 text-[12px] text-[#6B7280]">
            Add any model identifier supported by your connected provider endpoints.
          </p>

          <form onSubmit={handleAddModel} className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <select
              value={newProvider}
              onChange={(e) => setNewProvider(e.target.value as ProviderId)}
              aria-label="Provider"
              className="rounded-xl border border-[#E5E7EB] bg-white px-3 py-2 text-[13px] text-[#111827] focus:border-[#111827] focus:outline-none"
            >
              {PROVIDERS_ORDER.map((p) => (
                <option key={p} value={p}>
                  {PROVIDER_META[p].name}
                </option>
              ))}
            </select>

            <select
              value={newModelTier}
              onChange={(e) => setNewModelTier(e.target.value as 'Free' | 'Paid')}
              aria-label="Tier"
              className="rounded-xl border border-[#E5E7EB] bg-white px-3 py-2 text-[13px] text-[#111827] focus:border-[#111827] focus:outline-none"
            >
              <option value="Free">Free Tier</option>
              <option value="Paid">Paid Tier</option>
            </select>

            <input
              type="text"
              value={newModelId}
              onChange={(e) => setNewModelId(e.target.value)}
              placeholder="Model ID (e.g. qwen/qwen-2.5-coder-32b-instruct:free)"
              className="sm:col-span-2 rounded-xl border border-[#E5E7EB] bg-white px-3 py-2 font-mono text-[12px] text-[#111827] placeholder:text-[#9CA3AF] focus:border-[#111827] focus:outline-none"
            />

            <input
              type="text"
              value={newModelLabel}
              onChange={(e) => setNewModelLabel(e.target.value)}
              placeholder="Display Name (optional)"
              className="rounded-xl border border-[#E5E7EB] bg-white px-3 py-2 text-[13px] text-[#111827] placeholder:text-[#9CA3AF] focus:border-[#111827] focus:outline-none"
            />

            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-[13px] font-medium text-[#111827] hover:bg-[#F3F4F6] transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>Add Model</span>
            </button>
          </form>

          {customModels.length > 0 && (
            <div className="mt-3 space-y-1.5">
              {customModels.map((cm) => (
                <div
                  key={cm.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-[#E5E7EB] bg-[#FAFAFA] px-3 py-2"
                >
                  <div className="min-w-0">
                    <div className="truncate text-[13px] font-medium text-[#111827]">
                      {cm.label}
                    </div>
                    <div className="truncate font-mono text-[11px] text-[#6B7280]">
                      {PROVIDER_META[cm.provider].name} · {cm.id}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemoveCustomModel(cm.id)}
                    aria-label={`Remove ${cm.label}`}
                    className="rounded-lg p-1.5 text-[#6B7280] hover:bg-[#FEE2E2] hover:text-[#DC2626] transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
