import React from 'react';
import { X, Copy, Check, CheckCircle2, AlertTriangle, ShieldCheck, User } from 'lucide-react';
import { CnicRecord } from '../types/cnic';

interface CnicDetailModalProps {
  record: CnicRecord | null;
  onClose: () => void;
}

export const CnicDetailModal: React.FC<CnicDetailModalProps> = ({ record, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  if (!record) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const raw = record.cnicRaw;
  const adminCode = raw.slice(0, 5);
  const familyCode = raw.slice(5, 12);
  const checkDigit = raw.slice(12, 13);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-[#087d3e] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-200" />
            <h3 className="font-bold text-base sm:text-lg">NADRA CNIC Architecture</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {/* Main CNIC Display with Segment Highlights */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center">
            <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block mb-1">
              Formatted Identity Number
            </span>
            <div className="flex items-center justify-center gap-1 font-mono text-2xl sm:text-3xl font-extrabold text-slate-900">
              <span className="text-emerald-700 bg-emerald-100/60 px-1.5 py-0.5 rounded">
                {adminCode}
              </span>
              <span className="text-slate-400">-</span>
              <span className="text-blue-700 bg-blue-100/60 px-1.5 py-0.5 rounded">
                {familyCode}
              </span>
              <span className="text-slate-400">-</span>
              <span className="text-amber-700 bg-amber-100/60 px-1.5 py-0.5 rounded">
                {checkDigit}
              </span>
            </div>

            <button
              onClick={() => handleCopy(record.cnicFormatted)}
              className="mt-3 text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-white border border-emerald-300 px-3 py-1.5 rounded-lg shadow-2xs hover:bg-emerald-50 transition-colors inline-flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Formatted CNIC'}</span>
            </button>
          </div>

          {/* Breakdown Explanation Cards */}
          <div className="space-y-2.5 text-xs sm:text-sm">
            {/* 1. Administrative Code */}
            <div className="p-3 rounded-lg border border-emerald-200 bg-emerald-50/50 flex items-start gap-3">
              <div className="w-7 h-7 rounded-md bg-emerald-600 text-white font-mono font-bold flex items-center justify-center shrink-0 text-xs">
                {adminCode}
              </div>
              <div className="flex-1">
                <div className="font-bold text-emerald-950 flex items-center justify-between">
                  <span>Administrative Division Code</span>
                  <span className="text-emerald-700 font-mono text-xs">{record.provinceName}</span>
                </div>
                <p className="text-slate-600 text-xs mt-0.5">
                  1st digit <strong className="font-mono text-slate-800">&quot;{adminCode[0]}&quot;</strong> indicates {record.provinceName}. The remaining 4 digits identify Division ({adminCode[1]}), District ({adminCode[2]}), Tehsil ({adminCode[3]}), and Union Council ({adminCode[4]}).
                </p>
              </div>
            </div>

            {/* 2. Family Serial Code */}
            <div className="p-3 rounded-lg border border-blue-200 bg-blue-50/50 flex items-start gap-3">
              <div className="w-7 h-7 rounded-md bg-blue-600 text-white font-mono font-bold flex items-center justify-center shrink-0 text-xs">
                {familyCode}
              </div>
              <div className="flex-1">
                <div className="font-bold text-blue-950 flex items-center justify-between">
                  <span>Family Tree Serial Number</span>
                  <span className="text-blue-700 font-mono text-xs">NADRA Registry</span>
                </div>
                <p className="text-slate-600 text-xs mt-0.5">
                  7-digit unique sequential registry number linking the individual to their family tree in the central NADRA database.
                </p>
              </div>
            </div>

            {/* 3. Gender & Check Digit */}
            <div className="p-3 rounded-lg border border-amber-200 bg-amber-50/50 flex items-start gap-3">
              <div className="w-7 h-7 rounded-md bg-amber-600 text-white font-mono font-bold flex items-center justify-center shrink-0 text-xs">
                {checkDigit}
              </div>
              <div className="flex-1">
                <div className="font-bold text-amber-950 flex items-center justify-between">
                  <span>Gender Indicator & Check Digit</span>
                  <span className="text-amber-800 font-semibold text-xs">
                    {record.gender} ({parseInt(checkDigit, 10) % 2 !== 0 ? 'Odd Digit' : 'Even Digit'})
                  </span>
                </div>
                <p className="text-slate-600 text-xs mt-0.5">
                  In Pakistan NADRA standards, odd numbers (1, 3, 5, 7, 9) signify Male citizens; even numbers (0, 2, 4, 6, 8) signify Female citizens.
                </p>
              </div>
            </div>
          </div>

          {/* Verification Status Banner */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-medium text-slate-700">Status in Current Batch:</span>
            </div>
            <span className="font-bold text-[#a36b00]">{record.status}</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-slate-800 hover:bg-slate-900 text-white transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
