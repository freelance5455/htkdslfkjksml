import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  X,
  Send,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  KeyRound,
  ExternalLink,
  MessageCircle,
  HelpCircle,
  Zap,
} from 'lucide-react';
import { AppSettings, ChatMessage } from '../types';

interface ChatbotModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onUnlockAdmin: () => void;
  onOpenAdmin: () => void;
  isAdminUnlocked: boolean;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg_welcome_1',
    sender: 'bot',
    text: 'नमस्ते! 👋 I am your InstaBoost Assistant. How can I help you today? You can ask me how to grow your followers, account safety, or enter your admin code.',
    timestamp: 'Just now',
  },
];

export const ChatbotModal: React.FC<ChatbotModalProps> = ({
  settings,
  isOpen,
  onClose,
  onUnlockAdmin,
  onOpenAdmin,
  isAdminUnlocked,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 100);
    }
  }, [isOpen, messages, isTyping]);

  if (!isOpen) return null;

  const handleSendMessage = (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    // Add user message
    const userMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Bot response logic
    setTimeout(() => {
      const lower = query.toLowerCase();
      const currentAdminCode = (settings.admin_code || '805040').trim().toLowerCase();

      let botResponse: ChatMessage;

      // 1. Direct match with current admin code
      if (lower === currentAdminCode || lower.includes(`code ${currentAdminCode}`) || query.trim() === settings.admin_code) {
        onUnlockAdmin();
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `🎉 Access Granted! Admin Verification Successful! ✅\n\nस्वागत है एडमिन! आपका कोड "${settings.admin_code}" सही है। अब आप एडमिन पैनल खोलकर सभी इंस्टाग्राम ऑर्डर्स और सेटिंग्स प्रबंधित कर सकते हैं।`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isAdminUnlock: true,
          actionButton: {
            label: 'Open Admin Panel / एडमिन पैनल खोलें 🚀',
            action: 'open_admin',
          },
        };
      }
      // 2. Admin inquiry
      else if (
        lower.includes('admin') ||
        lower.includes('एडमिन') ||
        lower.includes('access code') ||
        lower.includes('password code')
      ) {
        if (isAdminUnlocked) {
          botResponse = {
            id: `bot_${Date.now()}`,
            sender: 'bot',
            text: '🔓 You are already verified as Admin! You can open the Admin Panel at any time.',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isAdminUnlock: true,
            actionButton: {
              label: 'Open Admin Panel 🚀',
              action: 'open_admin',
            },
          };
        } else {
          botResponse = {
            id: `bot_${Date.now()}`,
            sender: 'bot',
            text: '🔐 **Admin Access Required:**\n\nकृपया अपना एडमिन एक्सेस कोड दर्ज करें (Please enter the Admin Access Code to continue):\n\n*(Tip: Default system code is 805040)*',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
        }
      }
      // 3. How to use inquiry
      else if (
        lower.includes('how to use') ||
        lower.includes('kaise use') ||
        lower.includes('kaise') ||
        lower.includes('guide') ||
        lower.includes('help') ||
        lower.includes('स्टेप') ||
        lower.includes('उपयोग')
      ) {
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `📋 **How to Use InstaBoost (स्टेप-बाय-स्टेप गाइड):**\n\n1️⃣ **Enter Details:** अपना Instagram username और password दर्ज करें।\n2️⃣ **Add Account:** "Add Account & Select Followers" बटन पर क्लिक करें।\n3️⃣ **Choose Package:** 100 से 5,000 फॉलोअर्स में से अपनी पसंद का पैकेज चुनें।\n4️⃣ **Send & Process:** "Send" पर क्लिक करें, 10 सेकंड का ऑटोमेशन काउंटडाउन शुरू होगा।\n5️⃣ **Delivery:** ऑर्डर सबमिट होते ही 24 घंटे के अंदर आपके खाते पर रियल फॉलोअर्स बढ़ना शुरू हो जाएंगे! ✨`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }
      // 4. Safe / Security inquiry
      else if (
        lower.includes('safe') ||
        lower.includes('सुरक्षित') ||
        lower.includes('security') ||
        lower.includes('ban') ||
        lower.includes('risk') ||
        lower.includes('password safe')
      ) {
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `🛡️ **100% Safe & Secure Guarantee:**\n\n• **Anti-Ban Algorithm:** फॉलोअर्स नेचुरल ऑर्गेनिक ड्रिप (organic drip rate) से डिलीवर होते हैं, जिससे इंस्टाग्राम का एल्गोरिदम आपके अकाउंट को फ्लैग नहीं करता।\n• **256-Bit SSL:** आपका डेटा एंड-टू-एंड एनक्रिप्टेड रहता है।\n• **No Bot Leaks:** केवल एक्टिव और हाई-रिटेंशन प्रोफाइल से डिलीवरी की जाती है।\n• **30-Day Drop Refill:** यदि कोई फॉलोअर कम होता है तो सिस्टम आटोमेटिक रीफिल कर देता है।`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }
      // 5. Followers inquiry
      else if (
        lower.includes('follower') ||
        lower.includes('फॉलोअर्स') ||
        lower.includes('delivery time') ||
        lower.includes('kab aayenge') ||
        lower.includes('real')
      ) {
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `👥 **Followers Information:**\n\n• **Available Tiers:** 100, 250, 500, 1,000, 2,500, और 5,000 फॉलोअर्स।\n• **Delivery Speed:** सबमिट करने के बाद डिलीवरी तुरंत कतार में लग जाती है और **24 घंटे के अंदर** पूरी हो जाती है।\n• **Account Quality:** वास्तविक और सक्रिय प्रोफाइल (Real active accounts with posts and stories)।`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }
      // 6. Coins inquiry
      else if (lower.includes('coin') || lower.includes('सिक्के') || lower.includes('free')) {
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `🪙 **Coins System:**\n\nहर नए यूजर को शुरुआत में **500 Free Coins** मिलते हैं! आप ऊपर दाईं ओर स्थित कॉइन्स बैज पर क्लिक करके अपना बैलेंस देख सकते हैं और अतिरिक्त कॉइन्स रिवॉर्ड क्लेम कर सकते हैं।`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }
      // 7. Fallback smart answer
      else {
        botResponse = {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: `धन्यवाद आपके सवाल के लिए! ✨\n\nआप मुझसे निम्न में से कोई भी विषय पूछ सकते हैं:\n• "How to use" - एप्लिकेशन का उपयोग कैसे करें\n• "Followers" - फॉलोअर्स डिलीवरी और स्पीड की जानकारी\n• "Safe" - अकाउंट सुरक्षा और एंटी-बैन पॉलिसी\n• "Admin" - एडमिन पैनल कोड वेरिफिकेशन`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }

      setMessages((prev) => [...prev, botResponse]);
      setIsTyping(false);
    }, 500);
  };

  const handleQuickPrompt = (prompt: string) => {
    handleSendMessage(prompt);
  };

  const handleActionButton = (action: string) => {
    if (action === 'open_admin') {
      onClose();
      onOpenAdmin();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center sm:justify-end p-2 sm:p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full sm:w-[420px] h-[92vh] sm:h-[620px] max-h-[800px] flex flex-col rounded-3xl bg-slate-900 border border-purple-500/40 shadow-2xl shadow-purple-950/90 overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-950 via-slate-900 to-pink-950 border-b border-purple-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-md shadow-pink-900/40">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-white">InstaSupport AI</h3>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-medium border border-emerald-500/30">
                  Online
                </span>
              </div>
              <p className="text-[11px] text-purple-300/80">Support, FAQ & Admin Gateway</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isBot ? 'items-start' : 'items-end justify-end'}`}
              >
                {isBot && (
                  <div className="w-7 h-7 rounded-xl bg-purple-600/30 border border-purple-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5 text-pink-400" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] rounded-2xl p-3.5 leading-relaxed ${
                    isBot
                      ? 'bg-slate-800/90 border border-purple-500/20 text-slate-200'
                      : 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Interactive Button if provided by bot */}
                  {msg.actionButton && (
                    <div className="mt-3 pt-2.5 border-t border-purple-500/20">
                      <button
                        type="button"
                        onClick={() => handleActionButton(msg.actionButton!.action)}
                        className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/60 transition-all animate-pulse"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{msg.actionButton.label}</span>
                      </button>
                    </div>
                  )}

                  <span
                    className={`block text-[9px] mt-1 text-right ${
                      isBot ? 'text-slate-400' : 'text-purple-200'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 text-slate-400 text-xs pl-2">
              <Bot className="w-3.5 h-3.5 text-pink-400 animate-spin" />
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0.2s' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-3 py-2 bg-slate-950/60 border-t border-purple-500/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => handleQuickPrompt('How to use')}
            className="shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1"
          >
            <HelpCircle className="w-3 h-3 text-pink-400" />
            <span>How to use</span>
          </button>
          <button
            onClick={() => handleQuickPrompt('Is it safe/सुरक्षित?')}
            className="shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1"
          >
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>Safe & Secure</span>
          </button>
          <button
            onClick={() => handleQuickPrompt('Followers delivery info')}
            className="shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1"
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>Followers Info</span>
          </button>
          <button
            onClick={() => handleQuickPrompt('Admin access')}
            className="shrink-0 px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/30 text-[11px] text-pink-200 font-semibold transition-colors flex items-center gap-1"
          >
            <KeyRound className="w-3 h-3 text-pink-400" />
            <span>Admin</span>
          </button>
        </div>

        {/* Chat Input Bar */}
        <div className="p-3 bg-slate-950 border-t border-purple-500/20">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask a question or enter Admin Code..."
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-purple-500/30 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-xs text-white placeholder:text-slate-500 outline-none"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 disabled:opacity-40 text-white transition-opacity active:scale-95"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
