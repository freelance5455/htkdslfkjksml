import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrickCategory, Product, Order } from '../../types';
import {
  Factory,
  Package,
  Plus,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Truck,
  DollarSign,
  ArrowRight,
  ChevronRight,
  Layers,
  Edit3,
  Calendar,
  Shield,
  FileText
} from 'lucide-react';

export const ManufacturerApp: React.FC = () => {
  const {
    t,
    products,
    addProduct,
    updateProductStock,
    orders,
    updateOrderStatus,
    settlements,
    setInvoiceModalOrderId
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'stock' | 'orders' | 'earnings' | 'add_product'>('dashboard');

  // Screen 19: Add Product state
  const [newProductName, setNewProductName] = useState('');
  const [newBrickType, setNewBrickType] = useState<BrickCategory>('1st Class Brick');
  const [newSize, setNewSize] = useState('9" x 4.25" x 2.75"');
  const [newQuality, setNewQuality] = useState<Product['quality']>('Class 1 Heavy Load');
  const [newPrice, setNewPrice] = useState<number>(9500);
  const [newStock, setNewStock] = useState<number>(100);
  const [newMinOrder, setNewMinOrder] = useState<number>(3);
  const [newRadius, setNewRadius] = useState<number>(60);
  const [newGst, setNewGst] = useState<number>(5);
  const [newDesc, setNewDesc] = useState('');
  const [showAddSuccess, setShowAddSuccess] = useState(false);

  // Screen 22: Order processing modal
  const [processingOrderId, setProcessingOrderId] = useState<string | null>(null);
  const activeProcessingOrder = orders.find((o) => o.id === processingOrderId) || null;

  // Filter products for this manufacturer
  const mfgProducts = products.filter((p) => p.manufacturerId === 'mfg_01' || p.manufacturerId === 'mfg_02');

  // Manufacturer metrics (Screen 18)
  const totalMfgStock = mfgProducts.reduce((sum, p) => sum + p.availableStockThousand, 0);
  const totalMfgSales = 47000 + 45600 + 48800;
  const pendingOrdersCount = orders.filter((o) => o.orderStatus !== 'Delivered' && o.orderStatus !== 'Cancelled').length;

  const handlePublishProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName) return;

    addProduct({
      name: newProductName,
      brickType: newBrickType,
      size: newSize,
      quality: newQuality,
      pricePerThousand: Number(newPrice),
      availableStockThousand: Number(newStock),
      minOrderThousand: Number(newMinOrder),
      photos: [
        'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=800&q=80'
      ],
      manufacturerId: 'mfg_01',
      manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
      deliveryChargePerKm: 32,
      deliveryAreaRadiusKm: Number(newRadius),
      gstPercent: Number(newGst),
      description: newDesc || 'High quality kiln-fired bricks with uniform color and sharp edges.'
    });

    setShowAddSuccess(true);
    setTimeout(() => {
      setShowAddSuccess(false);
      setActiveTab('stock');
      setNewProductName('');
    }, 1500);
  };

  const handleRequestTransport = (orderId: string) => {
    updateOrderStatus(orderId, 'Vehicle Assigned');
    setProcessingOrderId(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Sub navigation bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#131822] border border-[#242f40] p-2 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-600/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <Factory className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">
              Maa Tara Brick Kiln (BFB Bhatta)
            </h2>
            <span className="text-[10px] text-emerald-400 font-semibold">
              Kolkata-Barasat Highway Kiln Belt • Verified Manufacturer
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'dashboard' as const, label: 'Dashboard' },
            { id: 'add_product' as const, label: '+ Add Product' },
            { id: 'stock' as const, label: 'Stock Mgmt' },
            { id: 'orders' as const, label: 'Kiln Orders' },
            { id: 'earnings' as const, label: 'Earnings & Settlements' }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`mfg-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2432]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* =========================================================================
          SCREEN 22: ORDER PROCESSING MODAL
      ========================================================================= */}
      {processingOrderId && activeProcessingOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#161c26] border border-[#2b384a] rounded-2xl p-6 text-xs text-slate-300 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#242f3e]">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                  Screen 22 • Order Processing & Transport Request
                </span>
                <h3 className="text-lg font-bold text-white mt-0.5">
                  Process Order {activeProcessingOrder.id}
                </h3>
              </div>
              <button
                onClick={() => setProcessingOrderId(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 bg-[#10141e] border border-[#212c3d] rounded-xl space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Customer:</span>
                <span className="font-semibold text-white">{activeProcessingOrder.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Site Address:</span>
                <span className="text-slate-200 text-right max-w-[240px] truncate">
                  {activeProcessingOrder.deliveryAddress}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Bricks to Load:</span>
                <span className="font-bold text-[#e55938]">
                  {activeProcessingOrder.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Kiln Yard Loading Point:</span>
                <span className="text-slate-200">Yard 2, Main Chimney Platform</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Scheduled Dispatch:</span>
                <span className="text-white font-medium">{activeProcessingOrder.deliveryDate}</span>
              </div>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-[11px] flex items-center gap-2">
              <Truck className="w-4 h-4 shrink-0" />
              <span>
                Dispatch request will alert nearby verified 10-wheeler & 6-wheeler drivers to accept haulage.
              </span>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                id="request-transport-confirm-btn"
                onClick={() => handleRequestTransport(activeProcessingOrder.id)}
                className="flex-1 py-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-600/20"
              >
                <Truck className="w-4 h-4" />
                <span>{t('requestTransport')}</span>
              </button>
              <button
                onClick={() => setProcessingOrderId(null)}
                className="px-4 py-3 bg-[#1e2634] hover:bg-[#283344] text-slate-300 font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 18: MANUFACTURER DASHBOARD
      ========================================================================= */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Key Stat Cards (Screen 18 Cards specification) */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">{t('todayOrders')}</span>
              <div className="text-2xl font-black text-white mt-1">2</div>
              <span className="text-[10px] text-emerald-400">₹97,980 bookings</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">{t('pendingOrders')}</span>
              <div className="text-2xl font-black text-amber-400 mt-1">{pendingOrdersCount}</div>
              <span className="text-[10px] text-slate-400">Needs truck assignment</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">{t('totalSales')}</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">
                ₹{totalMfgSales.toLocaleString()}
              </div>
              <span className="text-[10px] text-emerald-400">+12% vs last week</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-xs text-slate-400">{t('availableStock')}</span>
              <div className="text-2xl font-black text-white mt-1">{totalMfgStock}k</div>
              <span className="text-[10px] text-slate-400">Ready in cooling sheds</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl col-span-2 lg:col-span-1">
              <span className="text-xs text-slate-400">{t('pendingPayments')}</span>
              <div className="text-2xl font-black text-[#e55938] mt-1">₹45,355</div>
              <span className="text-[10px] text-amber-400">Settling to HDFC A/C</span>
            </div>
          </div>

          {/* Quick Actions Bar (Screen 18 specification) */}
          <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-4 sm:p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">
              Quick Operations
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-semibold">
              <button
                id="qa-add-product"
                onClick={() => setActiveTab('add_product')}
                className="p-3 bg-[#1c2432] hover:bg-[#253042] border border-[#2e3d54] text-white rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4 text-amber-400" />
                <span>{t('addProduct')}</span>
              </button>
              <button
                id="qa-update-stock"
                onClick={() => setActiveTab('stock')}
                className="p-3 bg-[#1c2432] hover:bg-[#253042] border border-[#2e3d54] text-white rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Package className="w-4 h-4 text-emerald-400" />
                <span>{t('updateStock')}</span>
              </button>
              <button
                id="qa-view-orders"
                onClick={() => setActiveTab('orders')}
                className="p-3 bg-[#1c2432] hover:bg-[#253042] border border-[#2e3d54] text-white rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Clock className="w-4 h-4 text-blue-400" />
                <span>{t('orders')} ({pendingOrdersCount})</span>
              </button>
              <button
                id="qa-price-mgmt"
                onClick={() => setActiveTab('stock')}
                className="p-3 bg-[#1c2432] hover:bg-[#253042] border border-[#2e3d54] text-white rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <DollarSign className="w-4 h-4 text-purple-400" />
                <span>{t('priceManagement')}</span>
              </button>
            </div>
          </div>

          {/* Pending Dispatches Table */}
          <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                Active Kiln Dispatches
              </h3>
              <button
                onClick={() => setActiveTab('orders')}
                className="text-xs text-amber-400 hover:underline"
              >
                View All Orders →
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-3.5 bg-[#10141e] border border-[#222c3d] rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white">{ord.id}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {ord.orderStatus}
                      </span>
                    </div>
                    <p className="text-slate-300 mt-1">
                      Customer: <strong>{ord.customerName}</strong> ({ord.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks)
                    </p>
                    <p className="text-slate-400 text-[11px] truncate max-w-md">
                      Site: {ord.deliveryAddress}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {ord.orderStatus === 'Order Confirmed' || ord.orderStatus === 'Manufacturer Preparing' ? (
                      <button
                        id={`process-order-${ord.id}`}
                        onClick={() => setProcessingOrderId(ord.id)}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Process & Request Truck</span>
                      </button>
                    ) : (
                      <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Assigned ({ord.vehicleNumber || 'WB 39 B 4812'})</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 19: ADD PRODUCT
      ========================================================================= */}
      {activeTab === 'add_product' && (
        <div className="max-w-2xl mx-auto bg-[#151b25] border border-[#263345] rounded-2xl p-6 shadow-xl">
          <div className="pb-4 border-b border-[#232f41] mb-5">
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
              Screen 19 • Product Catalog Entry
            </span>
            <h2 className="text-xl font-bold text-white mt-0.5">{t('addProduct')}</h2>
            <p className="text-xs text-slate-400">
              List new fired batches directly from your kiln chambers
            </p>
          </div>

          {showAddSuccess && (
            <div className="p-3.5 mb-4 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Product batch published to marketplace successfully!</span>
            </div>
          )}

          <form onSubmit={handlePublishProduct} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Product Batch Name</label>
              <input
                id="product-name-input"
                type="text"
                required
                value={newProductName}
                onChange={(e) => setNewProductName(e.target.value)}
                placeholder="e.g., Maa Tara Special 1st Class Wirecut Batch #14"
                className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Brick Type</label>
                <select
                  id="product-brick-type"
                  value={newBrickType}
                  onChange={(e) => setNewBrickType(e.target.value as BrickCategory)}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white outline-none"
                >
                  <option value="1st Class Brick">1st Class Brick</option>
                  <option value="2nd Class Brick">2nd Class Brick</option>
                  <option value="Fly Ash Brick">Fly Ash Brick</option>
                  <option value="Concrete Block">Concrete Block</option>
                  <option value="Building Materials">Building Materials</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Standard Size</label>
                <input
                  id="product-size-input"
                  type="text"
                  value={newSize}
                  onChange={(e) => setNewSize(e.target.value)}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3.5 py-2.5 text-white outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Price / 1,000 (₹)</label>
                <input
                  id="product-price-input"
                  type="number"
                  value={newPrice}
                  onChange={(e) => setNewPrice(Number(e.target.value))}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Stock (Thousands)</label>
                <input
                  id="product-stock-input"
                  type="number"
                  value={newStock}
                  onChange={(e) => setNewStock(Number(e.target.value))}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Min Order (k)</label>
                <input
                  id="product-min-order-input"
                  type="number"
                  value={newMinOrder}
                  onChange={(e) => setNewMinOrder(Number(e.target.value))}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white font-bold outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Delivery Radius (km)</label>
                <input
                  id="product-radius-input"
                  type="number"
                  value={newRadius}
                  onChange={(e) => setNewRadius(Number(e.target.value))}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-300 mb-1">GST Tax Rate (%)</label>
                <input
                  id="product-gst-input"
                  type="number"
                  value={newGst}
                  onChange={(e) => setNewGst(Number(e.target.value))}
                  className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3 py-2.5 text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">Batch Description</label>
              <textarea
                id="product-desc-input"
                rows={2}
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Firing method, compressive strength, edge sharpness..."
                className="w-full bg-[#10151f] border border-[#263447] rounded-xl px-3.5 py-2 text-white outline-none resize-none"
              />
            </div>

            <button
              id="publish-product-btn"
              type="submit"
              className="w-full py-3.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-600/20"
            >
              <span>Publish Product to Marketplace</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* =========================================================================
          SCREEN 20: STOCK MANAGEMENT
      ========================================================================= */}
      {activeTab === 'stock' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                Screen 20 • Kiln Inventory Control
              </span>
              <h2 className="text-xl font-bold text-white">{t('updateStock')}</h2>
            </div>
            <span className="text-xs text-slate-400">Total Yard: {totalMfgStock}k Bricks</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mfgProducts.map((prod) => (
              <div
                key={prod.id}
                className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl text-xs text-slate-300 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-amber-400 uppercase">
                      {prod.brickType}
                    </span>
                    <h4 className="font-bold text-white text-sm">{prod.name}</h4>
                  </div>
                  <span className="text-xs font-mono font-bold text-white bg-[#11151f] px-2 py-1 rounded-lg border border-[#242e3f]">
                    ₹{prod.pricePerThousand}/1k
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 p-3 bg-[#10141e] border border-[#212c3e] rounded-xl text-center">
                  <div>
                    <span className="text-[10px] text-slate-400">Available</span>
                    <div className="font-bold text-emerald-400 text-base">
                      {prod.availableStockThousand}k
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Reserved</span>
                    <div className="font-bold text-amber-400 text-base">12k</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Sold (Mo)</span>
                    <div className="font-bold text-white text-base">45k</div>
                  </div>
                </div>

                {/* Stock update buttons */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-slate-400">Adjust Cooling Shed Stock:</span>
                  <div className="flex items-center gap-2">
                    <button
                      id={`decrease-stock-${prod.id}`}
                      onClick={() =>
                        updateProductStock(prod.id, prod.availableStockThousand - 5)
                      }
                      className="px-2.5 py-1 bg-[#1e2736] hover:bg-[#283549] text-white font-bold rounded-lg"
                    >
                      -5k
                    </button>
                    <button
                      id={`increase-stock-${prod.id}`}
                      onClick={() =>
                        updateProductStock(prod.id, prod.availableStockThousand + 10)
                      }
                      className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg"
                    >
                      +10k
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 21: MANUFACTURER ORDERS
      ========================================================================= */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
              Screen 21 • Kiln Loading Orders
            </span>
            <h2 className="text-xl font-bold text-white">{t('orders')}</h2>
          </div>

          <div className="space-y-3 text-xs">
            {orders.map((ord) => (
              <div
                key={ord.id}
                className="p-4 bg-[#151b25] border border-[#263345] rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white text-sm">{ord.id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {ord.orderStatus}
                    </span>
                  </div>
                  <p className="text-slate-200 font-semibold">
                    {ord.customerName} • {ord.items[0]?.productName} ({ord.items.reduce((s, i) => s + i.quantityThousand, 0)}k Bricks)
                  </p>
                  <p className="text-slate-400">
                    Site: {ord.deliveryAddress} • Vehicle: {ord.vehicleType}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right mr-2">
                    <span className="text-[10px] text-slate-400">Kiln Net Payout</span>
                    <div className="font-bold text-emerald-400 text-sm">
                      ₹{ord.productTotal.toLocaleString()}
                    </div>
                  </div>

                  <button
                    id={`mfg-process-btn-${ord.id}`}
                    onClick={() => setProcessingOrderId(ord.id)}
                    className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    Process Dispatch
                  </button>

                  <button
                    id={`mfg-invoice-btn-${ord.id}`}
                    onClick={() => setInvoiceModalOrderId(ord.id)}
                    className="px-3 py-1.5 bg-[#1f2937] hover:bg-[#283547] text-slate-200 font-medium rounded-lg"
                  >
                    Invoice
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 23: MANUFACTURER EARNINGS & SETTLEMENTS
      ========================================================================= */}
      {activeTab === 'earnings' && (
        <div className="space-y-6">
          <div>
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
              Screen 23 • Net Earnings & Settlements
            </span>
            <h2 className="text-xl font-bold text-white">{t('mfgDashboard')} Earnings</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl">
              <span className="text-xs text-slate-400">{t('grossSales')}</span>
              <div className="text-2xl font-black text-white mt-1">₹1,41,400</div>
              <span className="text-[10px] text-slate-400">Across 3 kiln batches</span>
            </div>
            <div className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl">
              <span className="text-xs text-slate-400">{t('platformCommission')} (3.5%)</span>
              <div className="text-2xl font-black text-rose-400 mt-1">-₹4,949</div>
              <span className="text-[10px] text-slate-400">Deducted automatically</span>
            </div>
            <div className="p-5 bg-[#151b25] border border-[#263345] rounded-2xl">
              <span className="text-xs text-slate-400">{t('netEarnings')}</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">₹1,36,451</div>
              <span className="text-[10px] text-emerald-400">Direct NEFT to Bank</span>
            </div>
          </div>

          <div className="bg-[#151b25] border border-[#263345] rounded-2xl p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">
              Bank Settlement History
            </h3>
            <div className="space-y-3 text-xs">
              {settlements
                .filter((s) => s.beneficiaryType === 'Manufacturer')
                .map((settle) => (
                  <div
                    key={settle.id}
                    className="p-3.5 bg-[#10141e] border border-[#222c3d] rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white">{settle.id}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            settle.status === 'Paid'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-amber-500/20 text-amber-400'
                          }`}
                        >
                          {settle.status}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        Order Ref: {settle.orderId} • Date: {settle.date}
                      </p>
                      {settle.paymentRef && (
                        <p className="text-[10px] text-slate-400 font-mono">
                          Ref: {settle.paymentRef}
                        </p>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-white text-sm">
                        ₹{settle.netPayable.toLocaleString()}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        Commission: ₹{settle.platformCommission}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
