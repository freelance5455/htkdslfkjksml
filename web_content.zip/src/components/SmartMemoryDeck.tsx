import React, { useState } from 'react';
import { MemoryItem } from '../types/jarvis';
import {
  Brain,
  Sparkles,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  RotateCcw,
  ShieldCheck,
  Key,
} from 'lucide-react';

interface SmartMemoryDeckProps {
  memories: MemoryItem[];
  onSaveMemory: (key: string, value: string, label?: string) => void;
  onUpdateMemory: (key: string, value: string) => void;
  onDeleteMemory: (key: string) => void;
  onClearMemories: () => void;
  onVoiceCommandExecute: (cmd: string) => void;
}

export const SmartMemoryDeck: React.FC<SmartMemoryDeckProps> = ({
  memories,
  onSaveMemory,
  onUpdateMemory,
  onDeleteMemory,
  onClearMemories,
  onVoiceCommandExecute,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingKey, setEditingKey] = useState<string | null>(null);

  // Form states
  const [keyInput, setKeyInput] = useState('');
  const [labelInput, setLabelInput] = useState('');
  const [valueInput, setValueInput] = useState('');

  const handleOpenAdd = () => {
    setEditingKey(null);
    setKeyInput('');
    setLabelInput('');
    setValueInput('');
    setShowAddModal(true);
  };

  const handleOpenEdit = (item: MemoryItem) => {
    setEditingKey(item.key);
    setKeyInput(item.key);
    setLabelInput(item.label);
    setValueInput(item.value);
    setShowAddModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyInput.trim() || !valueInput.trim()) return;

    if (editingKey) {
      onUpdateMemory(editingKey, valueInput.trim());
    } else {
      onSaveMemory(
        keyInput.trim(),
        valueInput.trim(),
        labelInput.trim() || undefined
      );
    }
    setShowAddModal(false);
  };

  const currentUserName = memories.find((m) => m.key === 'name')?.value || 'User';

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Brain className="w-5 h-5" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Jarvis Smart Memory (Hafiza)
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Aapki zaati maloomat, pasand aur hidayat jo Jarvis ko hamesha yaad rehti hain
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-[10px] font-mono-code px-2.5 py-1 rounded-md bg-emerald-950 border border-emerald-500/40 text-emerald-300 uppercase flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            {currentUserName ? `Active for ${currentUserName}` : 'Active'}
          </span>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-gray-950 font-orbitron font-bold text-xs uppercase tracking-wider transition shadow-md shadow-cyan-500/20 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            Nayi Yaad
          </button>
        </div>
      </div>

      {/* Urdu Voice Shortcuts Bar */}
      <div className="mb-4 p-2.5 rounded-xl bg-gray-950/70 border border-cyan-500/20 flex flex-wrap items-center gap-2">
        <span className="text-[11px] font-mono-code text-cyan-400 flex items-center gap-1 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Urdu Voice Shortcuts:
        </span>
        <button
          onClick={() => onVoiceCommandExecute('Mera naam Hafiz hai, yaad rakhna')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Mera naam Hafiz hai, yaad rakhna"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Mera naam kya hai?')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Mera naam kya hai?"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Mera naya naam Saib hai, update karo')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Mera naya naam Saib hai, update karo"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Meri memory dikhao')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Meri memory dikhao"
        </button>
      </div>

      {/* Memory List Grid */}
      {memories.length === 0 ? (
        <div className="text-center py-8 border border-dashed border-gray-800 rounded-xl">
          <Brain className="w-8 h-8 text-gray-600 mx-auto mb-2" />
          <p className="text-sm text-slate-400 font-rajdhani">
            Memory abhi khaali hai. Bolen: "Mera naam Hafiz hai, yaad rakhna".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          {memories.map((mem) => (
            <div
              key={mem.key}
              className="p-3.5 rounded-xl bg-gray-950/80 border border-gray-800 hover:border-cyan-500/40 transition flex items-center justify-between gap-3 group shadow-sm"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 mt-0.5">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono-code uppercase px-1.5 py-0.2 rounded bg-gray-900 border border-gray-700 text-slate-400">
                      {mem.key}
                    </span>
                    <h4 className="text-xs font-semibold text-cyan-300 font-rajdhani">
                      {mem.label}
                    </h4>
                  </div>
                  <p className="text-sm font-semibold text-slate-100 mt-1">
                    {mem.value}
                  </p>
                  <span className="text-[10px] font-mono-code text-slate-500 block mt-0.5">
                    Updated: {new Date(mem.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleOpenEdit(mem)}
                  aria-label={`Edit ${mem.label}`}
                  className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/50 transition"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onDeleteMemory(mem.key)}
                  aria-label={`Delete ${mem.label}`}
                  className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-red-400 hover:border-red-500/50 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer & Clear Memory */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-800 text-xs font-mono-code text-slate-400">
        <span>Persistent Storage: Local Android Database</span>
        {memories.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Kya aap waqai saari stored memory clear karna chahte hain?')) {
                onClearMemories();
              }
            }}
            className="flex items-center gap-1 text-slate-500 hover:text-red-400 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Saari Memory Saaf Karein
          </button>
        )}
      </div>

      {/* Add / Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <h3 className="font-orbitron text-sm font-bold text-cyan-300 uppercase tracking-wider">
                {editingKey ? 'Maloomat Update Karein' : 'Nayi Yaad Mehfooz Karein'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              {!editingKey && (
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">
                    Memory Key (e.g. name, city, preference, email)
                  </label>
                  <input
                    type="text"
                    required
                    value={keyInput}
                    onChange={(e) => setKeyInput(e.target.value)}
                    placeholder="e.g. name / city / food"
                    className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Urdu Label (e.g. Mera Naam / Shehar / Pasand)
                </label>
                <input
                  type="text"
                  value={labelInput}
                  onChange={(e) => setLabelInput(e.target.value)}
                  placeholder="e.g. Aapka Naam"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Value (Asal Maloomat)
                </label>
                <input
                  type="text"
                  required
                  value={valueInput}
                  onChange={(e) => setValueInput(e.target.value)}
                  placeholder="e.g. Hafiz / Lahore / Biryani"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30"
                >
                  {editingKey ? 'Update Karein' : 'Mehfooz Karein'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
