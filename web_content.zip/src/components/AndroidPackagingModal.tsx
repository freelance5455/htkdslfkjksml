import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Download, 
  Terminal, 
  CheckCircle2, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldCheck, 
  Cpu, 
  Layers,
  Sparkles
} from 'lucide-react';

interface AndroidPackagingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidPackagingModal: React.FC<AndroidPackagingModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeWorkflow, setActiveWorkflow] = useState<'pwabuilder' | 'bubblewrap' | 'capacitor'>('pwabuilder');

  if (!isOpen) return null;

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const downloadManifest = () => {
    const manifestData = {
      name: "FaceLook Social Network",
      short_name: "FaceLook",
      description: "Mobile-first social media application with feeds, reels, photo & video sharing, and creator profiles.",
      start_url: "/",
      display: "standalone",
      background_color: "#F0F2F5",
      theme_color: "#1877F2",
      orientation: "portrait",
      icons: [
        {
          src: "/icon.svg",
          sizes: "any",
          type: "image/svg+xml",
          purpose: "any maskable"
        }
      ]
    };
    const blob = new Blob([JSON.stringify(manifestData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'manifest.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadAssetLinks = () => {
    const assetlinks = [
      {
        relation: ["delegate_permission/common.handle_all_urls"],
        target: {
          namespace: "android_app",
          package_name: "com.facelook.app",
          sha256_cert_fingerprints: [
            "14:6D:E9:7F:0F:70:E4:FA:E3:64:CA:04:E0:F1:C9:F8:78:44:8D:88:51:79:BE:85:2B:64:1D:64:4D:2F:32:04"
          ]
        }
      }
    ];
    const blob = new Blob([JSON.stringify(assetlinks, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'assetlinks.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-linear-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <Smartphone className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-black text-lg sm:text-xl leading-tight">Android APK Packaging</h2>
              <p className="text-xs text-emerald-100 font-medium">100% Free & Open-Source Build Workflows</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-sm text-slate-700">
          
          {/* Readiness Checklist */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4">
            <h3 className="font-bold text-emerald-900 text-sm flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>FaceLook Mobile Readiness Status</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-white p-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-medium text-slate-800">PWA Manifest Ready</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-medium text-slate-800">Standalone Display</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-medium text-slate-800">App Icon (SVG)</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-medium text-slate-800">Android Gallery Input</span>
              </div>
            </div>
          </div>

          {/* Workflow Selector Tabs */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Select Free Packaging Method
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setActiveWorkflow('pwabuilder')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  activeWorkflow === 'pwabuilder'
                    ? 'border-emerald-500 bg-emerald-50/50 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-900 mb-0.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>PWABuilder</span>
                </div>
                <p className="text-[11px] text-slate-500">1-Click Online (Easiest)</p>
              </button>

              <button
                onClick={() => setActiveWorkflow('bubblewrap')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  activeWorkflow === 'bubblewrap'
                    ? 'border-emerald-500 bg-emerald-50/50 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-900 mb-0.5">
                  <Terminal className="w-4 h-4 text-teal-600" />
                  <span>Bubblewrap</span>
                </div>
                <p className="text-[11px] text-slate-500">Google Official CLI</p>
              </button>

              <button
                onClick={() => setActiveWorkflow('capacitor')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  activeWorkflow === 'capacitor'
                    ? 'border-emerald-500 bg-emerald-50/50 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-900 mb-0.5">
                  <Cpu className="w-4 h-4 text-blue-600" />
                  <span>Capacitor</span>
                </div>
                <p className="text-[11px] text-slate-500">Native Android Studio</p>
              </button>
            </div>
          </div>

          {/* Workflow Instructions */}
          {activeWorkflow === 'pwabuilder' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-slate-900 text-sm flex items-center justify-between">
                <span>Method 1: PWABuilder (Free Microsoft Web Tool)</span>
                <a
                  href="https://www.pwabuilder.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-blue-600 hover:underline"
                >
                  <span>Open pwabuilder.com</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </h4>
              <ol className="list-decimal list-inside space-y-2 text-xs sm:text-sm text-slate-600 leading-relaxed">
                <li>
                  Go to <strong className="text-slate-900">pwabuilder.com</strong> in your browser (no installation required).
                </li>
                <li>
                  Paste your FaceLook public URL:
                  <div className="my-1.5 p-2 bg-white rounded-lg border border-slate-200 font-mono text-xs text-slate-800 flex items-center justify-between">
                    <span className="truncate">{window.location.origin}</span>
                    <button
                      onClick={() => handleCopy(window.location.origin, 101)}
                      className="text-slate-500 hover:text-slate-800 p-1 cursor-pointer"
                    >
                      {copiedIndex === 101 ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </li>
                <li>
                  Click <strong className="text-slate-900">Start</strong>. PWABuilder will scan this app's manifest and icons.
                </li>
                <li>
                  Click <strong className="text-slate-900">Package for Stores</strong> &rarr; Select <strong className="text-slate-900">Android</strong>.
                </li>
                <li>
                  Click <strong className="text-slate-900">Generate APK</strong>. It compiles a free signed APK/AAB package ready to install on your phone or upload to the Google Play Store!
                </li>
              </ol>
            </div>
          )}

          {activeWorkflow === 'bubblewrap' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-slate-900 text-sm">
                Method 2: Google Chrome Bubblewrap CLI (Free Terminal Workflow)
              </h4>
              <p className="text-xs text-slate-600">
                Bubblewrap is Google's official open-source tool for turning PWAs into Android APKs using Trusted Web Activity (TWA).
              </p>

              <div className="space-y-2">
                <div className="bg-slate-900 rounded-xl p-3 text-emerald-400 font-mono text-xs flex items-center justify-between">
                  <span>npm install -g @bubblewrap/cli</span>
                  <button
                    onClick={() => handleCopy('npm install -g @bubblewrap/cli', 201)}
                    className="text-slate-400 hover:text-white p-1 cursor-pointer"
                  >
                    {copiedIndex === 201 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="bg-slate-900 rounded-xl p-3 text-emerald-400 font-mono text-xs flex items-center justify-between">
                  <span>bubblewrap init --manifest={window.location.origin}/manifest.json</span>
                  <button
                    onClick={() => handleCopy(`bubblewrap init --manifest=${window.location.origin}/manifest.json`, 202)}
                    className="text-slate-400 hover:text-white p-1 cursor-pointer"
                  >
                    {copiedIndex === 202 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="bg-slate-900 rounded-xl p-3 text-emerald-400 font-mono text-xs flex items-center justify-between">
                  <span>bubblewrap build</span>
                  <button
                    onClick={() => handleCopy('bubblewrap build', 203)}
                    className="text-slate-400 hover:text-white p-1 cursor-pointer"
                  >
                    {copiedIndex === 203 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <p className="text-xs text-slate-500">
                This outputs an <code className="text-slate-800 font-mono">app-release-signed.apk</code> file in your folder that installs directly on any Android phone.
              </p>
            </div>
          )}

          {activeWorkflow === 'capacitor' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-slate-900 text-sm">
                Method 3: Capacitor & Android Studio (Free Native Shell)
              </h4>
              <p className="text-xs text-slate-600">
                If you want to customize native Android permissions, splash screens, or Java/Kotlin code:
              </p>

              <div className="bg-slate-900 rounded-xl p-3 text-emerald-400 font-mono text-xs space-y-1">
                <p># 1. Install Capacitor packages</p>
                <p>npm install @capacitor/core @capacitor/android</p>
                <p className="mt-2"># 2. Initialize and build</p>
                <p>npx cap init FaceLook com.facelook.app --web-dir=dist</p>
                <p>npm run build</p>
                <p>npx cap add android</p>
                <p className="mt-2"># 3. Open in Android Studio & Build APK</p>
                <p>npx cap open android</p>
              </div>
            </div>
          )}

          {/* Quick Assets Download Bar */}
          <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-bold text-xs text-slate-800">Packaging Asset Helpers</p>
              <p className="text-[11px] text-slate-500">Download config files needed for store verification</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={downloadManifest}
                className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs px-3 py-1.5 rounded-xl cursor-pointer transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>manifest.json</span>
              </button>

              <button
                onClick={downloadAssetLinks}
                className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs px-3 py-1.5 rounded-xl cursor-pointer transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>assetlinks.json</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
