import { useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import { highlightRegex, runSearch, TIER_STYLE, toArabicDigits, type Db } from "../lib/data";
import { HadithCard } from "./HadithCard";
import { CloseIcon, SearchIcon } from "./Icons";

type Props = {
  db: Db;
  topic?: string;
  imam?: string;
  placeholder?: string;
  autoFocus?: boolean;
  emptyHint?: string;
  onTopic?: (code: string) => void;
  onImam?: (code: string) => void;
  /** يعرض الأحاديث حتى بدون عبارة بحث */
  browse?: boolean;
};

const PAGE = 30;

export function ResultsList({ db, topic = "", imam: fixedImam, placeholder, autoFocus, emptyHint, onTopic, onImam, browse }: Props) {
  const [query, setQuery] = useState("");
  const [imam, setImam] = useState(fixedImam ?? "");
  const [tier, setTier] = useState(0);
  const [limit, setLimit] = useState(PAGE);
  const dq = useDeferredValue(query);
  const topRef = useRef<HTMLDivElement>(null);

  useEffect(() => setLimit(PAGE), [dq, imam, tier, topic]);

  const active = browse || !!dq.trim() || !!imam || tier > 0 || !!topic;
  const results = useMemo(
    () => (active ? runSearch(db, { query: dq, imam, tier, topic, book: -1 }) : []),
    [db, dq, imam, tier, topic, active]
  );
  const re = useMemo(() => highlightRegex(dq), [dq]);

  const imamChips = db.meta.imams.filter(([c]) => (db.imamCounts[c] || 0) > 0);

  return (
    <div>
      <div ref={topRef} className="sticky top-0 z-20 -mx-4 space-y-2 bg-[#f6f3ea]/95 px-4 pb-2 pt-3 backdrop-blur dark:bg-[#0b1512]/95">
        <div className="flex items-center gap-2 rounded-2xl border border-stone-300 bg-white px-3 shadow-sm focus-within:border-emerald-600 focus-within:ring-2 focus-within:ring-emerald-200 dark:border-stone-600 dark:bg-stone-900 dark:focus-within:ring-emerald-900">
          <span className="text-stone-400">
            <SearchIcon size={20} />
          </span>
          <input
            autoFocus={autoFocus}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            type="search"
            enterKeyHint="search"
            placeholder={placeholder ?? "ابحث في الأحاديث… مثال: صلة الرحم"}
            className="h-12 min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-stone-400"
          />
          {query && (
            <button onClick={() => setQuery("")} aria-label="مسح" className="rounded-full p-1.5 text-stone-500 active:scale-90">
              <CloseIcon />
            </button>
          )}
        </div>

        {fixedImam === undefined && (
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
            <Chip active={imam === ""} onClick={() => setImam("")}>
              كل المعصومين
            </Chip>
            {imamChips.map(([c, n]) => (
              <Chip key={c} active={imam === c} onClick={() => setImam(imam === c ? "" : c)}>
                {n.replace(/\s*\(.*\)/, "")}
                <span className="mr-1 opacity-60">{toArabicDigits(db.imamCounts[c])}</span>
              </Chip>
            ))}
          </div>
        )}

        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          <Chip small active={tier === 0} onClick={() => setTier(0)}>
            كل الدرجات
          </Chip>
          <Chip small active={tier === 6} onClick={() => setTier(6)}>
            ✔ المسنَدة المعتبرة
          </Chip>
          {[1, 2, 3, 4, 5].map((t) => (
            <Chip key={t} small active={tier === t} onClick={() => setTier(tier === t ? 0 : t)}>
              {TIER_STYLE[t].label}
              <span className="mr-1 opacity-60">{toArabicDigits(db.tierCounts[t])}</span>
            </Chip>
          ))}
        </div>
      </div>

      {!active ? (
        <div className="px-6 py-16 text-center text-stone-500 dark:text-stone-400">
          <div className="mb-3 text-5xl">🔎</div>
          <p className="text-base font-semibold text-stone-700 dark:text-stone-200">
            ابحث في {toArabicDigits(db.items.length.toLocaleString("en"))} حديثاً
          </p>
          <p className="mt-2 text-sm leading-7">
            {emptyHint ?? "اكتب كلمة أو أكثر؛ البحث يتجاهل التشكيل وأشكال الألف والهمزة، ويعمل بدون إنترنت."}
          </p>
        </div>
      ) : (
        <>
          <div className="px-1 py-2 text-xs text-stone-500 dark:text-stone-400">
            {results.length
              ? `النتائج: ${toArabicDigits(results.length.toLocaleString("en"))} حديث`
              : "لا توجد نتائج مطابقة"}
          </div>
          <div className="space-y-3 pb-4">
            {results.slice(0, limit).map((h) => (
              <HadithCard key={h.id} db={db} h={h} re={re} onTopic={onTopic} onImam={onImam} />
            ))}
          </div>
          {results.length > limit && (
            <button
              onClick={() => setLimit(limit + PAGE)}
              className="mb-6 w-full rounded-2xl bg-emerald-800 py-3 text-sm font-bold text-white active:scale-[.98] dark:bg-emerald-700"
            >
              عرض المزيد ({toArabicDigits(results.length - limit)} متبقٍ)
            </button>
          )}
          {!results.length && (
            <div className="px-6 py-12 text-center text-sm text-stone-500">
              جرّب كلمات أقل أو ألغِ بعض المرشحات أعلاه.
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
  small,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  small?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 whitespace-nowrap rounded-full border transition active:scale-95 ${
        small ? "px-3 py-1 text-xs" : "px-3.5 py-1.5 text-sm"
      } ${
        active
          ? "border-emerald-800 bg-emerald-800 font-bold text-white dark:border-emerald-600 dark:bg-emerald-700"
          : "border-stone-300 bg-white text-stone-700 dark:border-stone-600 dark:bg-stone-900 dark:text-stone-300"
      }`}
    >
      {children}
    </button>
  );
}
