import React, { useState } from 'react';
import { Language, NumeralSystem } from '../types/calculator';
import { toUrduNumerals, sanitizeFloat } from '../utils/math';
import { Percent, ArrowRightLeft, Tag } from 'lucide-react';

interface QuickConvertersProps {
  language: Language;
  numeralSystem: NumeralSystem;
}

export const QuickConverters: React.FC<QuickConvertersProps> = ({ language, numeralSystem }) => {
  const isUrdu = language === 'ur';

  // Sub-tab: discount | proportion | units
  const [activeSubTab, setActiveSubTab] = useState<'discount' | 'proportion' | 'units'>('discount');

  // Discount calculator state
  const [originalPrice, setOriginalPrice] = useState<string>('1000');
  const [discountPercent, setDiscountPercent] = useState<string>('20');

  // Proportion calculator state: "What is X% of Y"
  const [percentRate, setPercentRate] = useState<string>('15');
  const [baseAmount, setBaseAmount] = useState<string>('500');

  // Unit converter state
  const [unitType, setUnitType] = useState<'length' | 'weight' | 'temp'>('length');
  const [unitInputValue, setUnitInputValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<string>('meter');
  const [toUnit, setToUnit] = useState<string>('foot');

  const formatVal = (val: string | number) => {
    const s = String(val);
    return numeralSystem === 'eastern' ? toUrduNumerals(s) : s;
  };

  // Discount computation
  const orig = parseFloat(originalPrice) || 0;
  const disc = parseFloat(discountPercent) || 0;
  const savedAmount = sanitizeFloat((orig * disc) / 100);
  const finalPrice = sanitizeFloat(Math.max(0, orig - savedAmount));

  // Proportion computation
  const rate = parseFloat(percentRate) || 0;
  const base = parseFloat(baseAmount) || 0;
  const proportionResult = sanitizeFloat((base * rate) / 100);

  // Unit conversion formulas
  const convertUnits = (): string => {
    const val = parseFloat(unitInputValue);
    if (isNaN(val)) return '0';

    if (unitType === 'length') {
      // Base: meters
      const toMeters: Record<string, number> = {
        meter: 1,
        foot: 0.3048,
        inch: 0.0254,
        km: 1000,
        mile: 1609.344,
      };
      const meters = val * (toMeters[fromUnit] || 1);
      const converted = meters / (toMeters[toUnit] || 1);
      return sanitizeFloat(parseFloat(converted.toFixed(4))).toString();
    }

    if (unitType === 'weight') {
      // Base: grams
      const toGrams: Record<string, number> = {
        kg: 1000,
        gram: 1,
        pound: 453.59237,
        ounce: 28.3495,
      };
      const grams = val * (toGrams[fromUnit] || 1);
      const converted = grams / (toGrams[toUnit] || 1);
      return sanitizeFloat(parseFloat(converted.toFixed(4))).toString();
    }

    if (unitType === 'temp') {
      if (fromUnit === toUnit) return val.toString();
      if (fromUnit === 'celsius' && toUnit === 'fahrenheit') {
        return sanitizeFloat(parseFloat(((val * 9) / 5 + 32).toFixed(2))).toString();
      }
      if (fromUnit === 'fahrenheit' && toUnit === 'celsius') {
        return sanitizeFloat(parseFloat((((val - 32) * 5) / 9).toFixed(2))).toString();
      }
    }

    return '0';
  };

  const unitResult = convertUnits();

  // Unit options based on unitType
  const getUnitOptions = () => {
    if (unitType === 'length') {
      return [
        { id: 'meter', ur: 'میٹر (Meter)', en: 'Meter (m)' },
        { id: 'foot', ur: 'فٹ (Feet)', en: 'Foot (ft)' },
        { id: 'inch', ur: 'انچ (Inches)', en: 'Inch (in)' },
        { id: 'km', ur: 'کلومیٹر (KM)', en: 'Kilometer (km)' },
        { id: 'mile', ur: 'میل (Mile)', en: 'Mile (mi)' },
      ];
    }
    if (unitType === 'weight') {
      return [
        { id: 'kg', ur: 'کلوگرام (KG)', en: 'Kilogram (kg)' },
        { id: 'gram', ur: 'گرام (Gram)', en: 'Gram (g)' },
        { id: 'pound', ur: 'پاؤنڈ (Pound)', en: 'Pound (lb)' },
        { id: 'ounce', ur: 'اونس (Ounce)', en: 'Ounce (oz)' },
      ];
    }
    return [
      { id: 'celsius', ur: 'سینٹی گریڈ (°C)', en: 'Celsius (°C)' },
      { id: 'fahrenheit', ur: 'فارن ہائیٹ (°F)', en: 'Fahrenheit (°F)' },
    ];
  };

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
      {/* Sub Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800/80">
        <button
          type="button"
          onClick={() => setActiveSubTab('discount')}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            activeSubTab === 'discount'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>{isUrdu ? 'رعایت / چھوٹ' : 'Discount'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('proportion')}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            activeSubTab === 'proportion'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>{isUrdu ? 'فیصد حساب' : 'Percentage'}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveSubTab('units');
            setFromUnit('meter');
            setToUnit('foot');
          }}
          className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            activeSubTab === 'units'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" />
          <span>{isUrdu ? 'تبدیلی اکائیاں' : 'Units'}</span>
        </button>
      </div>

      {/* Discount Calculator */}
      {activeSubTab === 'discount' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                {isUrdu ? 'اصل رقم یا قیمت:' : 'Original Price:'}
              </label>
              <input
                type="number"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-base font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="1000"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                {isUrdu ? 'چھوٹ / رعایت فیصد (%):' : 'Discount Rate (%):'}
              </label>
              <input
                type="number"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-base font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="20"
              />
            </div>
          </div>

          {/* Quick preset discount buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400">{isUrdu ? 'فوری انتخاب:' : 'Presets:'}</span>
            {[5, 10, 15, 20, 25, 30, 50].map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setDiscountPercent(String(p))}
                className={`px-2.5 py-1 text-xs rounded-lg border font-mono transition-colors ${
                  discountPercent === String(p)
                    ? 'bg-amber-400/20 text-amber-300 border-amber-500/50'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {formatVal(p)}%
              </button>
            ))}
          </div>

          {/* Result Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 grid grid-cols-2 gap-4">
            <div>
              <span className="text-xs text-slate-400 block">{isUrdu ? 'آخری ادا کی جانے والی رقم:' : 'Final Price:'}</span>
              <span className="text-2xl font-bold font-mono text-amber-400">
                {formatVal(finalPrice)}
              </span>
            </div>
            <div>
              <span className="text-xs text-emerald-400/90 block">{isUrdu ? 'کل بچت:' : 'Total Savings:'}</span>
              <span className="text-2xl font-bold font-mono text-emerald-400">
                {formatVal(savedAmount)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Percentage / Proportion Calculator */}
      {activeSubTab === 'proportion' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                {isUrdu ? 'کتنے فیصد (%):' : 'Percentage Rate (%):'}
              </label>
              <input
                type="number"
                value={percentRate}
                onChange={(e) => setPercentRate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-base font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="15"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                {isUrdu ? 'کل رقم یا تعداد:' : 'Of Total Amount:'}
              </label>
              <input
                type="number"
                value={baseAmount}
                onChange={(e) => setBaseAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-base font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="500"
              />
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4">
            <span className="text-xs text-slate-400 block mb-1">
              {isUrdu
                ? `${formatVal(base)} کا ${formatVal(rate)} فیصد بنتا ہے:`
                : `${formatVal(rate)}% of ${formatVal(base)} is:`}
            </span>
            <span className="text-3xl font-bold font-mono text-amber-400">
              {formatVal(proportionResult)}
            </span>
          </div>
        </div>
      )}

      {/* Unit Converter */}
      {activeSubTab === 'units' && (
        <div className="space-y-4">
          {/* Unit category selector */}
          <div className="flex items-center gap-2">
            {(['length', 'weight', 'temp'] as const).map((t) => {
              const labels = {
                length: isUrdu ? 'لمبائی' : 'Length',
                weight: isUrdu ? 'وزن' : 'Weight',
                temp: isUrdu ? 'درجہ حرارت' : 'Temperature',
              };
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setUnitType(t);
                    if (t === 'length') {
                      setFromUnit('meter');
                      setToUnit('foot');
                    } else if (t === 'weight') {
                      setFromUnit('kg');
                      setToUnit('pound');
                    } else {
                      setFromUnit('celsius');
                      setToUnit('fahrenheit');
                    }
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                    unitType === t
                      ? 'bg-amber-400/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {labels[t]}
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                {isUrdu ? 'مقدار:' : 'Input Value:'}
              </label>
              <input
                type="number"
                value={unitInputValue}
                onChange={(e) => setUnitInputValue(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-base font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  {isUrdu ? 'سے:' : 'From:'}
                </label>
                <select
                  value={fromUnit}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2 py-2.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {getUnitOptions().map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {isUrdu ? opt.ur : opt.en}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  {isUrdu ? 'میں:' : 'To:'}
                </label>
                <select
                  value={toUnit}
                  onChange={(e) => setToUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-2 py-2.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {getUnitOptions().map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {isUrdu ? opt.ur : opt.en}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              {isUrdu ? 'تبدیل شدہ نتیجہ:' : 'Converted Result:'}
            </span>
            <span className="text-2xl font-bold font-mono text-amber-400">
              {formatVal(unitResult)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
