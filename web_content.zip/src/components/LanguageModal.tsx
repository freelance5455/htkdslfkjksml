import React from 'react';
import { useApp } from '../context/AppContext';
import { Language } from '../utils/translations';
import { X, Check, Globe } from 'lucide-react';

export const LanguageModal: React.FC = () => {
  const { 
    isLanguageModalOpen, 
    setIsLanguageModalOpen, 
    language, 
    setLanguage, 
    t 
  } = useApp();

  if (!isLanguageModalOpen) return null;

  const languages: { id: Language; label: string; sub: string; icon: string }[] = [
    { id: 'hinglish', label: 'Hinglish', sub: 'Campus Wali Bolchal (Mix)', icon: '💬' },
    { id: 'en', label: 'English', sub: 'Global English', icon: '🌐' },
    { id: 'hi', label: 'हिंदी', sub: 'शुद्ध हिंदी', icon: '🇮🇳' },
  ];

  const handleSelect = (lang: Language) => {
    setLanguage(lang);
    setIsLanguageModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-sm bg-[#0e111d] border border-cyan-500/40 rounded-3xl p-5 shadow-2xl shadow-cyan-950/40 relative space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            <h3 className="font-display font-bold text-base text-slate-100">
              {t.selectLanguageTitle}
            </h3>
          </div>
          <button
            onClick={() => setIsLanguageModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2.5">
          {languages.map((lang) => {
            const isSelected = language === lang.id;
            return (
              <button
                key={lang.id}
                onClick={() => handleSelect(lang.id)}
                className={`w-full flex items-center justify-between p-3.5 rounded-2xl border text-left transition-all ${
                  isSelected 
                    ? 'bg-cyan-950/40 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/10' 
                    : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{lang.icon}</span>
                  <div>
                    <span className="font-bold text-xs sm:text-sm block text-slate-100">
                      {lang.label}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {lang.sub}
                    </span>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
