import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  Square, 
  Copy, 
  Check, 
  Image as ImageIcon, 
  Trash2, 
  Camera, 
  Monitor, 
  Sparkles,
  Search,
  Youtube,
  StickyNote,
  Clock,
  Flashlight,
  Share2
} from 'lucide-react';
import { ChatMessage, SupportedLanguage } from '../types/assistant';

interface AssistantChatProps {
  messages: ChatMessage[];
  isThinking: boolean;
  isListening: boolean;
  isSpeaking: boolean;
  userName: string;
  language: SupportedLanguage;
  onSendMessage: (text: string, imageBase64?: string) => void;
  onToggleVoice: () => void;
  onStopSpeaking: () => void;
  onSpeakMessage: (text: string) => void;
  onClearChat: () => void;
  onNavigateTab: (tab: any) => void;
  onToggleTorch: () => void;
  isTorchActive: boolean;
}

export const AssistantChat: React.FC<AssistantChatProps> = ({
  messages,
  isThinking,
  isListening,
  isSpeaking,
  userName,
  language,
  onSendMessage,
  onToggleVoice,
  onStopSpeaking,
  onSpeakMessage,
  onClearChat,
  onNavigateTab,
  onToggleTorch,
  isTorchActive,
}) => {
  const [inputText, setInputText] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleSend = () => {
    if (!inputText.trim() && !attachedImage) return;
    onSendMessage(inputText, attachedImage || undefined);
    setInputText('');
    setAttachedImage(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#070b16] rounded-3xl border border-cyan-900/40 shadow-xl overflow-hidden">
      {/* Quick Action Chips Carousel */}
      <div className="px-4 py-2.5 bg-slate-950/80 border-b border-cyan-900/30 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => onNavigateTab('vision')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900 text-xs font-mono-tech whitespace-nowrap transition-all"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Vision AI</span>
        </button>

        <button
          onClick={() => onNavigateTab('vision')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-fuchsia-950/70 border border-fuchsia-500/40 text-fuchsia-300 hover:bg-fuchsia-900 text-xs font-mono-tech whitespace-nowrap transition-all"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Screen Scan</span>
        </button>

        <button
          onClick={() => onNavigateTab('social')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/70 border border-blue-500/40 text-blue-300 hover:bg-blue-900 text-xs font-mono-tech whitespace-nowrap transition-all"
        >
          <Share2 className="w-3.5 h-3.5 text-blue-400" />
          <span>Apps & Social</span>
        </button>

        <button
          onClick={() => onNavigateTab('notes')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-mono-tech whitespace-nowrap transition-all"
        >
          <StickyNote className="w-3.5 h-3.5 text-amber-400" />
          <span>Notes</span>
        </button>

        <button
          onClick={() => onNavigateTab('reminders')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-mono-tech whitespace-nowrap transition-all"
        >
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span>Reminders</span>
        </button>

        <button
          onClick={onToggleTorch}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-mono-tech whitespace-nowrap transition-all ${
            isTorchActive
              ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-md shadow-amber-500/30'
              : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Flashlight className="w-3.5 h-3.5" />
          <span>{isTorchActive ? 'Torch: ON' : 'Torch'}</span>
        </button>

        <button
          onClick={onClearChat}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/40 border border-red-500/30 text-red-400 hover:bg-red-900/60 text-xs font-mono-tech whitespace-nowrap transition-all ml-auto"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear</span>
        </button>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        {messages.map((msg) => {
          const isBot = msg.role === 'assistant';
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isBot ? 'items-start' : 'items-end'} max-w-full`}
            >
              {/* Message Header Badge */}
              <div className="flex items-center gap-2 mb-1 px-1 text-[11px] font-mono-tech">
                <span className={isBot ? 'text-cyan-400 font-bold' : 'text-fuchsia-400 font-bold'}>
                  {isBot ? 'RUBEL BOSS AI' : userName.toUpperCase()}
                </span>
                <span className="text-slate-500">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              {/* Message Bubble */}
              <div
                className={`relative group max-w-[92%] sm:max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed ${
                  isBot
                    ? 'bg-[#0e172a]/95 text-slate-100 border border-cyan-500/30 shadow-md shadow-cyan-950/20'
                    : 'bg-gradient-to-r from-fuchsia-950/80 to-[#1e1338] text-slate-100 border border-fuchsia-500/40 shadow-md'
                }`}
              >
                {/* Attached image if present */}
                {msg.imageBase64 && (
                  <div className="mb-3 rounded-xl overflow-hidden border border-slate-700 max-h-60 bg-black/50">
                    <img
                      src={msg.imageBase64}
                      alt="Attached scan"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}

                {/* Content display */}
                <div className="whitespace-pre-wrap break-words font-sans">
                  {msg.content}
                </div>

                {/* Action controls for bot messages */}
                {isBot && (
                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-end gap-2 text-slate-400">
                    <button
                      onClick={() => onSpeakMessage(msg.content)}
                      title="Read aloud"
                      className="p-1 rounded-lg hover:text-cyan-300 hover:bg-cyan-950/60 transition-colors"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleCopy(msg.id, msg.content)}
                      title="Copy text"
                      className="p-1 rounded-lg hover:text-cyan-300 hover:bg-cyan-950/60 transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Quantum Thinking / Processing Indicator */}
        {isThinking && (
          <div className="flex flex-col items-start">
            <div className="flex items-center gap-2 mb-1 px-1 text-[11px] font-mono-tech text-cyan-400 font-bold">
              <span>RUBEL BOSS AI</span>
            </div>
            <div className="bg-[#0e172a] border border-cyan-500/40 rounded-2xl px-4 py-3 flex items-center gap-3">
              <span className="text-xs font-mono-tech text-cyan-300 font-semibold tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>PROCESSING INTEL...</span>
              </span>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-300 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Image Attachment Preview */}
      {attachedImage && (
        <div className="px-4 py-2 bg-slate-950 border-t border-cyan-900/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg border border-cyan-500/50 overflow-hidden bg-black">
              <img src={attachedImage} alt="Preview" className="w-full h-full object-cover" />
            </div>
            <span className="text-xs text-cyan-300 font-mono-tech">Image attached for AI Vision scan</span>
          </div>
          <button
            onClick={() => setAttachedImage(null)}
            className="text-xs text-red-400 hover:text-red-300 px-2 py-1 rounded bg-red-950/40 border border-red-800"
          >
            Remove
          </button>
        </div>
      )}

      {/* Input Composer & Controls */}
      <div className="p-3 md:p-4 bg-slate-950/95 border-t border-cyan-900/40">
        <div className="flex items-center gap-2">
          {/* Hidden File Picker */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageFile}
            accept="image/*"
            className="hidden"
          />

          {/* Attach Image Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            title="Attach Image or Screenshot"
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-400 transition-colors flex items-center justify-center shrink-0"
          >
            <ImageIcon className="w-5 h-5" />
          </button>

          {/* Prompt Text Field */}
          <div className="relative flex-1">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                isListening
                  ? language === 'bn'
                    ? 'বস কথা বলুন, আমি শুনছি...'
                    : 'Listening to Boss...'
                  : language === 'bn'
                  ? 'রুবেল বস এআই-কে কমান্ড দিন...'
                  : 'Message JARVIS...'
              }
              className="w-full bg-[#0a101f] text-slate-100 placeholder:text-slate-500 text-sm md:text-base px-4 py-3 rounded-2xl border border-cyan-900/60 focus:outline-none focus:border-cyan-400/80 focus:ring-1 focus:ring-cyan-400/40 transition-all font-sans"
            />
          </div>

          {/* Stop TTS Speaking Button (if active) */}
          {isSpeaking && (
            <button
              onClick={onStopSpeaking}
              title="Stop Voice Output"
              className="p-3 rounded-2xl bg-fuchsia-950 hover:bg-fuchsia-900 border border-fuchsia-500/50 text-fuchsia-300 transition-colors flex items-center justify-center shrink-0 animate-pulse"
            >
              <Square className="w-5 h-5 fill-current" />
            </button>
          )}

          {/* Dynamic Voice Mic or Send Button */}
          {inputText.trim() || attachedImage ? (
            <button
              onClick={handleSend}
              title="Send Command"
              className="p-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 transition-all flex items-center justify-center shadow-lg shadow-cyan-500/30 shrink-0 font-bold"
            >
              <Send className="w-5 h-5" />
            </button>
          ) : (
            <button
              onClick={onToggleVoice}
              title={isListening ? 'Stop Listening' : 'Start Voice Input'}
              className={`p-3 rounded-2xl transition-all flex items-center justify-center shrink-0 ${
                isListening
                  ? 'bg-fuchsia-600 hover:bg-fuchsia-500 text-white shadow-lg shadow-fuchsia-600/50 animate-pulse'
                  : 'bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-400'
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
