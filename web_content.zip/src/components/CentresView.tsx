import React, { useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  MapPin,
  Plus,
  Edit2,
  Search,
  PlusCircle,
  Phone,
  Smartphone,
  Mail,
  Globe,
  ExternalLink
} from 'lucide-react';
import { ClubManagerModal } from './ClubManagerModal';

interface CentresViewProps {
  onLogClimbAtCentre: (clubId: string) => void;
}

export const CentresView: React.FC<CentresViewProps> = ({ onLogClimbAtCentre }) => {
  const { clubs, climbs } = useClimbing();
  const [searchTerm, setSearchTerm] = useState('');
  const [isManagerOpen, setIsManagerOpen] = useState(false);

  const filteredClubs = clubs.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.phone && c.phone.includes(searchTerm)) ||
    (c.email && c.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full overflow-hidden">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[11px] font-semibold text-orange-600 uppercase tracking-wider">Lookup Database</span>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">UK Climbing Centres Directory</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 max-w-xl">
            Directory of indoor climbing centres including full contact info (phone, mobile, email, website) where candidate ascents and NICAS assessments are held.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsManagerOpen(true)}
          className="flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs transition-colors shrink-0 self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Centre</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          placeholder="Filter centres by name, region, phone or email..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-xs text-slate-900 dark:text-white"
        />
      </div>

      {/* Centres Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {filteredClubs.map(club => {
          const clubClimbs = climbs.filter(c => c.clubId === club.id);
          const email = club.email || club.contactEmail;

          return (
            <div
              key={club.id}
              className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all space-y-3"
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
                      {club.name}
                    </h3>
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                      <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                      <span className="truncate">{club.region || 'UK'}</span>
                    </div>
                  </div>

                  {club.isOfficialNicasCentre && (
                    <span className="shrink-0 text-[10px] font-bold text-orange-800 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/60 border border-orange-200 dark:border-orange-800 px-1.5 py-0.2 rounded">
                      NICAS
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                  {club.location}
                </p>

                {/* Contact details */}
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-100 dark:border-slate-800 text-xs space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
                    Contact Details
                  </span>

                  {club.phone && (
                    <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                      <Phone className="w-3 h-3 text-orange-600 shrink-0" />
                      <span className="text-[10px] text-slate-500">Phone:</span>
                      <a href={`tel:${club.phone.replace(/\s+/g, '')}`} className="font-mono hover:text-orange-600 hover:underline">
                        {club.phone}
                      </a>
                    </div>
                  )}

                  {club.mobile && (
                    <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                      <Smartphone className="w-3 h-3 text-orange-600 shrink-0" />
                      <span className="text-[10px] text-slate-500">Mobile:</span>
                      <a href={`tel:${club.mobile.replace(/\s+/g, '')}`} className="font-mono hover:text-orange-600 hover:underline">
                        {club.mobile}
                      </a>
                    </div>
                  )}

                  {email && (
                    <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 truncate">
                      <Mail className="w-3 h-3 text-orange-600 shrink-0" />
                      <span className="text-[10px] text-slate-500">Email:</span>
                      <a href={`mailto:${email}`} className="truncate hover:text-orange-600 hover:underline">
                        {email}
                      </a>
                    </div>
                  )}

                  {club.website && (
                    <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 truncate">
                      <Globe className="w-3 h-3 text-orange-600 shrink-0" />
                      <span className="text-[10px] text-slate-500">Web:</span>
                      <a
                        href={club.website.startsWith('http') ? club.website : `https://${club.website}`}
                        target="_blank"
                        rel="noreferrer"
                        className="truncate text-orange-600 dark:text-orange-400 hover:underline flex items-center gap-1"
                      >
                        <span className="truncate">{club.website.replace(/^https?:\/\//, '')}</span>
                        <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                      </a>
                    </div>
                  )}
                </div>

                {/* Wall styles */}
                <div className="pt-0.5">
                  <div className="flex flex-wrap gap-1">
                    {club.wallTypes.map(type => (
                      <span
                        key={type}
                        className="text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.5 rounded"
                      >
                        {type}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Card Actions */}
              <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                  {clubClimbs.length} logged
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onLogClimbAtCentre(club.id)}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/40 rounded-lg border border-orange-200 dark:border-orange-800 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Log Here</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsManagerOpen(true)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                    title="Manage in database"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Lookup Database Manager Modal */}
      <ClubManagerModal
        isOpen={isManagerOpen}
        onClose={() => setIsManagerOpen(false)}
      />
    </div>
  );
};
