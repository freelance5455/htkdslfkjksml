import React, { useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  Eye,
  FileCode2,
  FilePlus2,
  Pencil,
  Trash2,
  X,
} from 'lucide-react';
import type { WorkspaceFile } from '../types/mycode';
import { HighlightedCode } from '../utils/syntaxHighlight';

interface WorkspacePanelProps {
  mode: 'split' | 'sheet';
  files: Record<string, WorkspaceFile>;
  selectedPath: string | null;
  onSelectPath: (path: string) => void;
  onCreateOrUpdateFile: (path: string, content: string) => void;
  onDeleteFile: (path: string) => void;
  onExportZip: () => void;
  onClose?: () => void;
  compact?: boolean;
}

function buildLiveHtmlDocument(files: Record<string, WorkspaceFile>): string | null {
  const htmlFile =
    files['index.html'] ||
    Object.values(files).find((f) => f.path.toLowerCase().endsWith('.html'));

  if (!htmlFile) return null;

  let doc = htmlFile.content;

  // Inline local <link rel="stylesheet" href="..."> and <script src="..."> if present in workspace
  doc = doc.replace(/<link[^>]+href=["']([^"']+)["'][^>]*>/gi, (full, href: string) => {
    const clean = href.replace(/^\.?\//, '');
    const cssFile = files[clean];
    if (cssFile && clean.endsWith('.css')) {
      return `<style>\n${cssFile.content}\n</style>`;
    }
    return full;
  });

  doc = doc.replace(/<script[^>]+src=["']([^"']+)["'][^>]*><\/script>/gi, (full, src: string) => {
    const clean = src.replace(/^\.?\//, '');
    const jsFile = files[clean];
    if (jsFile && (clean.endsWith('.js') || clean.endsWith('.mjs'))) {
      return `<script>\n${jsFile.content}\n</script>`;
    }
    return full;
  });

  return doc;
}

export function WorkspacePanel({
  mode,
  files,
  selectedPath,
  onSelectPath,
  onCreateOrUpdateFile,
  onDeleteFile,
  onExportZip,
  onClose,
  compact = false,
}: WorkspacePanelProps) {
  const [viewTab, setViewTab] = useState<'code' | 'edit' | 'preview'>('code');
  const [copied, setCopied] = useState(false);
  const [creatingFile, setCreatingFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');

  const fileList = useMemo(
    () => Object.values(files).sort((a, b) => a.path.localeCompare(b.path)),
    [files]
  );

  const activeFile =
    (selectedPath && files[selectedPath]) || fileList[0] || null;

  const previewDoc = useMemo(() => buildLiveHtmlDocument(files), [files]);

  const handleCopyActive = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleCreateNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newFileName.trim().replace(/^\/+/, '');
    if (!cleaned) return;
    onCreateOrUpdateFile(cleaned, '');
    onSelectPath(cleaned);
    setNewFileName('');
    setCreatingFile(false);
    setViewTab('edit');
  };

  const panelContent = (
    <div className="flex h-full flex-col bg-white overflow-hidden">
      {/* Workspace Header */}
      <div
        className={`flex items-center justify-between gap-2 border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 ${
          compact ? 'h-10' : 'h-12'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0">
          <span className="font-display text-[13px] font-semibold text-[#111827] whitespace-nowrap">
            Workspace
          </span>
          <span className="text-[11px] text-[#6B7280] tabular-nums whitespace-nowrap">
            {fileList.length} {fileList.length === 1 ? 'file' : 'files'}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setCreatingFile((prev) => !prev)}
            title="New file"
            className="inline-flex h-8 items-center gap-1 rounded-lg border border-[#E5E7EB] bg-white px-2.5 text-[11px] font-medium text-[#111827] hover:bg-[#F3F4F6] transition-colors whitespace-nowrap"
          >
            <FilePlus2 className="h-3.5 w-3.5 text-[#4B5563]" />
            <span>New</span>
          </button>

          <button
            type="button"
            onClick={onExportZip}
            title="Export project as ZIP"
            className="inline-flex h-8 items-center gap-1 rounded-lg border border-[#E5E7EB] bg-white px-2.5 text-[11px] font-medium text-[#111827] hover:bg-[#F3F4F6] transition-colors whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5 text-[#4B5563]" />
            <span>ZIP</span>
          </button>

          {mode === 'sheet' && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close workspace"
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-[#4B5563] hover:bg-[#E5E7EB] hover:text-[#111827]"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Inline New File Creator */}
      {creatingFile && (
        <form
          onSubmit={handleCreateNewFile}
          className="flex items-center gap-2 border-b border-[#E5E7EB] bg-white px-3 py-2"
        >
          <input
            type="text"
            autoFocus
            value={newFileName}
            onChange={(e) => setNewFileName(e.target.value)}
            placeholder="e.g. src/utils.ts or app.py"
            className="flex-1 rounded-lg border border-[#E5E7EB] px-2.5 py-1.5 font-mono text-[12px] text-[#111827] focus:border-[#111827] focus:outline-none"
          />
          <button
            type="submit"
            className="rounded-lg bg-[#111827] px-3 py-1.5 text-[12px] font-medium text-white hover:bg-[#1F2937]"
          >
            Create
          </button>
          <button
            type="button"
            onClick={() => setCreatingFile(false)}
            className="rounded-lg px-2 py-1.5 text-[12px] text-[#6B7280] hover:text-[#111827]"
          >
            Cancel
          </button>
        </form>
      )}

      {fileList.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center p-6 text-center">
          <FileCode2 className="h-8 w-8 text-[#9CA3AF] mb-2" />
          <p className="text-[13px] font-medium text-[#111827]">No files in workspace</p>
          <p className="mt-1 text-[12px] text-[#6B7280] max-w-xs">
            Ask MyCode to generate code or create a file manually to inspect, edit, preview, and
            export as ZIP.
          </p>
        </div>
      ) : (
        <div className="flex flex-1 min-h-0 flex-col sm:flex-row">
          {/* File Explorer Strip / Sidebar */}
          <aside className="shrink-0 border-b sm:border-b-0 sm:border-r border-[#E5E7EB] bg-[#FAFAFA] sm:w-48 md:w-52 overflow-x-auto sm:overflow-y-auto">
            <div className="flex sm:flex-col p-1.5 gap-1">
              {fileList.map((f) => {
                const isSelected = activeFile?.path === f.path;
                return (
                  <div
                    key={f.path}
                    className={`group flex items-center justify-between gap-1 rounded-lg px-2.5 py-1.5 transition-colors shrink-0 sm:shrink ${
                      isSelected
                        ? 'bg-[#111827] text-white'
                        : 'text-[#374151] hover:bg-[#E5E7EB]/60'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onSelectPath(f.path);
                        if (viewTab === 'preview') setViewTab('code');
                      }}
                      className="flex min-w-0 flex-1 items-center gap-1.5 text-left"
                    >
                      <FileCode2
                        className={`h-3.5 w-3.5 shrink-0 ${
                          isSelected ? 'text-white/80' : 'text-[#6B7280]'
                        }`}
                      />
                      <span className="truncate font-mono text-[12px]">{f.path}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteFile(f.path)}
                      aria-label={`Delete ${f.path}`}
                      className={`p-0.5 rounded opacity-70 hover:opacity-100 ${
                        isSelected
                          ? 'text-white/80 hover:text-white'
                          : 'text-[#6B7280] hover:text-[#DC2626]'
                      }`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          </aside>

          {/* File Content / Live Preview Area */}
          <div className="flex flex-1 min-w-0 min-h-0 flex-col bg-white">
            {/* Active File Toolbar */}
            {activeFile && (
              <div className="flex items-center justify-between gap-2 border-b border-[#E5E7EB] px-3 py-1.5 bg-white">
                <span className="truncate font-mono text-[12px] font-medium text-[#111827]">
                  {activeFile.path}
                </span>

                <div className="flex items-center gap-1 shrink-0">
                  {/* View Mode Tabs */}
                  <div className="flex items-center rounded-lg bg-[#F3F4F6] p-0.5">
                    <button
                      type="button"
                      onClick={() => setViewTab('code')}
                      className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                        viewTab === 'code'
                          ? 'bg-white text-[#111827] shadow-xs'
                          : 'text-[#6B7280] hover:text-[#111827]'
                      }`}
                    >
                      <Code2 className="h-3 w-3" />
                      <span>Code</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setViewTab('edit')}
                      className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                        viewTab === 'edit'
                          ? 'bg-white text-[#111827] shadow-xs'
                          : 'text-[#6B7280] hover:text-[#111827]'
                      }`}
                    >
                      <Pencil className="h-3 w-3" />
                      <span>Edit</span>
                    </button>
                    {previewDoc && (
                      <button
                        type="button"
                        onClick={() => setViewTab('preview')}
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                          viewTab === 'preview'
                            ? 'bg-white text-[#111827] shadow-xs'
                            : 'text-[#6B7280] hover:text-[#111827]'
                        }`}
                      >
                        <Eye className="h-3 w-3" />
                        <span>Preview</span>
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleCopyActive}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#E5E7EB] bg-white px-2 py-1 text-[11px] font-medium text-[#111827] hover:bg-[#F9FAFB]"
                  >
                    {copied ? (
                      <>
                        <Check className="h-3 w-3 text-[#047857]" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3 text-[#4B5563]" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Viewer Body */}
            <div className="flex-1 min-h-0 overflow-auto bg-[#FAFAFA]">
              {viewTab === 'preview' && previewDoc ? (
                <iframe
                  title="Workspace Live Preview"
                  sandbox="allow-scripts allow-forms allow-modals"
                  srcDoc={previewDoc}
                  className="h-full w-full border-0 bg-white"
                />
              ) : viewTab === 'edit' && activeFile ? (
                <textarea
                  value={activeFile.content}
                  onChange={(e) => onCreateOrUpdateFile(activeFile.path, e.target.value)}
                  spellCheck={false}
                  className="h-full w-full resize-none bg-white p-4 font-mono text-[12px] leading-relaxed text-[#111827] focus:outline-none"
                />
              ) : activeFile ? (
                <HighlightedCode
                  code={activeFile.content}
                  language={activeFile.language}
                  showLineNumbers
                  compact={compact}
                />
              ) : null}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (mode === 'split') {
    return (
      <div className="h-full w-full border-l border-[#E5E7EB] bg-white overflow-hidden">
        {panelContent}
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Workspace Files"
        onClick={(e) => e.stopPropagation()}
        className="h-[88vh] w-full sm:max-w-4xl sm:h-[82vh] rounded-t-3xl sm:rounded-2xl border border-[#E5E7EB] bg-white shadow-2xl overflow-hidden"
      >
        {panelContent}
      </div>
    </div>
  );
}
