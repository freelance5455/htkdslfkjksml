import React from 'react';
import { 
  ShieldCheck, 
  HardHat, 
  Building2, 
  Check, 
  ArrowRight,
  User as UserIcon,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { User } from '../types';

interface PersonaSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PersonaSwitcherModal: React.FC<PersonaSwitcherModalProps> = ({ isOpen, onClose }) => {
  const { users, currentUser, switchUser } = useApp();

  if (!isOpen) return null;

  const handleSelectUser = (user: User) => {
    switchUser(user.id);
    onClose();
  };

  const adminUsers = users.filter(u => u.role === 'Admin');
  const employeeUsers = users.filter(u => u.role === 'Employee');
  const clientUsers = users.filter(u => u.role === 'Client');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-red-600" />
              <span>Switch User Persona</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Select any account to experience the app as Administrator, Employee, or Client
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold shrink-0"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Active Persona Banner */}
          <div className="p-3 bg-red-50/70 border border-red-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-red-600 text-white font-bold flex items-center justify-center text-xs shadow-xs">
                {currentUser.name.charAt(0)}
              </div>
              <div>
                <p className="font-bold text-slate-900">{currentUser.name}</p>
                <p className="text-[11px] text-slate-600">{currentUser.designation}</p>
              </div>
            </div>
            <span className="px-2.5 py-1 bg-red-600 text-white font-bold rounded-full text-[10px] uppercase tracking-wider">
              Active Role: {currentUser.role}
            </span>
          </div>

          {/* Role 1: Administrator */}
          <div>
            <div className="flex items-center gap-1.5 mb-2 font-bold text-[11px] text-red-700 uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Administrator Accounts (Full Operations Control)</span>
            </div>
            <div className="space-y-1.5">
              {adminUsers.map(user => {
                const isSelected = user.id === currentUser.id;
                return (
                  <button
                    key={user.id}
                    onClick={() => handleSelectUser(user)}
                    className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-red-50/60 border-red-500 shadow-xs ring-1 ring-red-500'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{user.name}</span>
                        <span className="bg-red-100 text-red-700 text-[10px] font-semibold px-2 py-0.5 rounded">
                          {user.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{user.designation}</p>
                    </div>
                    {isSelected ? (
                      <span className="w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-slate-400 group-hover:text-slate-700 flex items-center gap-1">
                        Select <ArrowRight className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Role 2: Employees */}
          <div>
            <div className="flex items-center gap-1.5 mb-2 font-bold text-[11px] text-blue-700 uppercase tracking-wider">
              <HardHat className="w-3.5 h-3.5" />
              <span>Employee Accounts (Work Orders & Site Updates)</span>
            </div>
            <div className="space-y-1.5">
              {employeeUsers.map(user => {
                const isSelected = user.id === currentUser.id;
                return (
                  <button
                    key={user.id}
                    onClick={() => handleSelectUser(user)}
                    className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-blue-50/60 border-blue-500 shadow-xs ring-1 ring-blue-500'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{user.name}</span>
                        <span className="bg-blue-100 text-blue-700 text-[10px] font-semibold px-2 py-0.5 rounded">
                          {user.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{user.designation}</p>
                    </div>
                    {isSelected ? (
                      <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-slate-400 group-hover:text-slate-700 flex items-center gap-1">
                        Select <ArrowRight className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Role 3: Clients */}
          <div>
            <div className="flex items-center gap-1.5 mb-2 font-bold text-[11px] text-emerald-700 uppercase tracking-wider">
              <Building2 className="w-3.5 h-3.5" />
              <span>Client Accounts (Transparent Facility Tracking)</span>
            </div>
            <div className="space-y-1.5">
              {clientUsers.map(user => {
                const isSelected = user.id === currentUser.id;
                return (
                  <button
                    key={user.id}
                    onClick={() => handleSelectUser(user)}
                    className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-emerald-50/60 border-emerald-500 shadow-xs ring-1 ring-emerald-500'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{user.name}</span>
                        <span className="bg-emerald-100 text-emerald-700 text-[10px] font-semibold px-2 py-0.5 rounded">
                          {user.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{user.designation}</p>
                    </div>
                    {isSelected ? (
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-slate-400 group-hover:text-slate-700 flex items-center gap-1">
                        Select <ArrowRight className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Switching role re-renders views automatically.</span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
