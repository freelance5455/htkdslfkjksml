import React, { useState } from 'react';
import { 
  Receipt, 
  Calendar, 
  Search, 
  CreditCard, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Send, 
  Sparkles,
  Download,
  Filter
} from 'lucide-react';
import { Bill, Language, BusinessProfile, Customer } from '../types';
import { translations } from '../translations';
import { receiptService } from '../services/receiptService';
import { WhatsAppDispatchPayload } from './WhatsAppDispatchModal';

interface BillingViewProps {
  bills: Bill[];
  customers: Customer[];
  activeMonth: string;
  language: Language;
  profile: BusinessProfile;
  onGenerateBills: () => void;
  onCollectPaymentForBill: (bill: Bill) => void;
  onExportBillingReport: () => void;
  onOpenWhatsAppModal: (payload: WhatsAppDispatchPayload) => void;
}

export const BillingView: React.FC<BillingViewProps> = ({
  bills,
  customers,
  activeMonth,
  language,
  profile,
  onGenerateBills,
  onCollectPaymentForBill,
  onExportBillingReport,
  onOpenWhatsAppModal,
}) => {
  const t = translations[language];

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL'); // ALL, UNPAID, PAID, PARTIAL

  const monthBills = bills.filter(b => b.billingMonth === activeMonth);

  const filteredBills = monthBills.filter(b => {
    const q = searchQuery.toLowerCase().trim();
    const matchQuery = 
      !q ||
      b.customerName.toLowerCase().includes(q) ||
      b.customerCode.toLowerCase().includes(q) ||
      b.billNumber.toLowerCase().includes(q) ||
      b.area.toLowerCase().includes(q) ||
      b.mobile.includes(q);

    let matchStatus = true;
    if (statusFilter === 'UNPAID') {
      matchStatus = b.status === 'UNPAID' || b.status === 'PARTIAL';
    } else if (statusFilter === 'PAID') {
      matchStatus = b.status === 'PAID';
    }

    return matchQuery && matchStatus;
  });

  // Totals for this month
  const totalBilled = monthBills.reduce((acc, b) => acc + (b.totalAmount || 0), 0);
  const totalCollected = monthBills.reduce((acc, b) => acc + (b.paidAmount || 0), 0);
  const totalPending = monthBills.reduce((acc, b) => acc + (b.balanceDue || 0), 0);

  return (
    <div className="space-y-6">
      
      {/* Top Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-cyan-400" />
            <span>{t.billing}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
              {activeMonth}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Automated calendar month billing with carry-forward dues and WhatsApp reminder dispatch.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={onExportBillingReport}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow-sm transition"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>{t.exportMonthlyReport}</span>
          </button>

          <button
            onClick={onGenerateBills}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-cyan-950/40 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>{t.generateBills} ({activeMonth})</span>
          </button>
        </div>
      </div>

      {/* Monthly Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Total Billed ({activeMonth})
          </span>
          <span className="text-2xl font-black text-cyan-300 font-mono-num mt-1 block">
            {receiptService.formatCurrency(totalBilled)}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {monthBills.length} Active bills generated
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Total Collected
          </span>
          <span className="text-2xl font-black text-emerald-400 font-mono-num mt-1 block">
            {receiptService.formatCurrency(totalCollected)}
          </span>
          <span className="text-[11px] text-emerald-400/90 mt-1 block">
            {monthBills.filter(b => b.status === 'PAID').length} Fully paid
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Balance Due / Pending
          </span>
          <span className="text-2xl font-black text-rose-400 font-mono-num mt-1 block">
            {receiptService.formatCurrency(totalPending)}
          </span>
          <span className="text-[11px] text-rose-400/90 mt-1 block">
            {monthBills.filter(b => b.status === 'UNPAID' || b.status === 'PARTIAL').length} Pending collection
          </span>
        </div>

      </div>

      {/* Filter and Search */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bill number, name, mobile..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'ALL' ? 'bg-cyan-600 text-white shadow-sm' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {t.allBills} ({monthBills.length})
          </button>
          <button
            onClick={() => setStatusFilter('UNPAID')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'UNPAID' ? 'bg-rose-600 text-white shadow-sm' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {t.unpaidOnly} ({monthBills.filter(b => b.status === 'UNPAID' || b.status === 'PARTIAL').length})
          </button>
          <button
            onClick={() => setStatusFilter('PAID')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'PAID' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {t.paidOnly} ({monthBills.filter(b => b.status === 'PAID').length})
          </button>
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        {filteredBills.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <Receipt className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-sm font-semibold">No bills found for {activeMonth}.</p>
            <p className="text-xs text-slate-500 mt-1">Tap &quot;Generate Monthly Bills&quot; above to create bills for all active subscribers.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-bold">{t.billNumber}</th>
                  <th className="py-3.5 px-4 font-bold">{t.customerName}</th>
                  <th className="py-3.5 px-4 font-bold">{t.area}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.planAmount}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.previousDues}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.totalPayable}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.balanceDue}</th>
                  <th className="py-3.5 px-4 font-bold text-center">{t.status}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredBills.map((bill) => {
                  const isPaid = bill.status === 'PAID';
                  const isPartial = bill.status === 'PARTIAL';
                  return (
                    <tr key={bill.id} className="hover:bg-slate-850/50 transition">
                      <td className="py-3.5 px-4 font-mono text-cyan-300 font-semibold">
                        {bill.billNumber}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-100 block">{bill.customerName}</span>
                        <span className="text-[11px] font-mono text-slate-400">{bill.customerCode} • {bill.mobile}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {bill.area}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono-num text-slate-300">
                        {receiptService.formatCurrency(bill.planAmount)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono-num text-slate-400">
                        {receiptService.formatCurrency(bill.previousDues)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono-num font-bold text-slate-100">
                        {receiptService.formatCurrency(bill.totalAmount)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono-num font-black text-sm">
                        <span className={bill.balanceDue > 0 ? 'text-rose-400' : 'text-emerald-400'}>
                          {receiptService.formatCurrency(bill.balanceDue)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          isPaid
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : isPartial
                            ? 'bg-amber-950 text-amber-400 border border-amber-800'
                            : 'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}>
                          {bill.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          
                          {/* Collect Payment */}
                          {!isPaid && (
                            <button
                              onClick={() => onCollectPaymentForBill(bill)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition"
                              title={t.recordPayment}
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span>Collect</span>
                            </button>
                          )}

                          {/* WhatsApp Reminder */}
                          {bill.balanceDue > 0 && (
                            <button
                              onClick={() => {
                                const cust = customers.find(c => c.id === bill.customerId);
                                if (cust) {
                                  onOpenWhatsAppModal({
                                    mode: 'DUES',
                                    customer: cust,
                                    bill,
                                  });
                                }
                              }}
                              className="p-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 transition"
                              title="Send WhatsApp Bill Reminder"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          )}

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
