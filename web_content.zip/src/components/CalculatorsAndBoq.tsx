import React, { useState } from 'react';
import { Calculator, ClipboardList, Check } from 'lucide-react';
import { LangMode } from '../data/types';
import { BOQ_ITEMS } from '../data/vocabQuizAndCareer';

export const CalculatorsPanel: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [pipeRunMeters, setPipeRunMeters] = useState<number>(6);
  const [slopeRatio, setSlopeRatio] = useState<number>(50);
  const [offsetMm, setOffsetMm] = useState<number>(300);
  const [occupants, setOccupants] = useState<number>(6);

  const dropMm = Math.round((pipeRunMeters * 1000) / slopeRatio);
  const dropCm = (dropMm / 10).toFixed(1);
  const travelMm = Math.round(offsetMm * 1.414);
  const tankLiters = occupants * 150;
  const tankGallons = Math.round(tankLiters * 0.264172);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* 1. Pipe Slope / Gradient Calculator */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-base">
              {lang === 'hi' ? 'पाइप स्लोप (ढलान) कैलकुलेटर' : 'Pipe Slope & Fall Calculator'}
            </h3>
            <p className="text-xs text-slate-500">
              {lang === 'hi' ? 'लंबाई और रेश्यो चुनें · सही ढलान निकालें' : 'Calculate exact fall in mm & cm'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="block space-y-1">
            <span className="text-xs font-medium text-slate-700">
              {lang === 'hi' ? 'पाइप की लंबाई (मीटर)' : 'Pipe Length (Meters)'}
            </span>
            <input
              type="number"
              min={1}
              max={100}
              value={pipeRunMeters}
              onChange={(e) => setPipeRunMeters(Math.max(1, Number(e.target.value) || 1))}
              className="w-full h-11 px-3 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-xs font-medium text-slate-700">
              {lang === 'hi' ? 'ढलान अनुपात (Slope)' : 'Slope Gradient'}
            </span>
            <select
              value={slopeRatio}
              onChange={(e) => setSlopeRatio(Number(e.target.value))}
              className="w-full h-11 px-3 rounded-xl border border-slate-300 font-mono-num text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value={40}>1:40 (40–50mm Waste)</option>
              <option value={50}>1:50 (50mm Bathroom)</option>
              <option value={60}>1:60 (75mm Collector)</option>
              <option value={80}>1:80 (110mm Branch)</option>
              <option value={100}>1:100 (110mm Main Soil)</option>
            </select>
          </label>
        </div>

        {/* Live SVG Slope Preview */}
        <div className="blueprint-grid rounded-xl p-4 border border-slate-200">
          <svg viewBox="0 0 360 95" className="w-full h-24">
            <line x1="20" y1="22" x2="340" y2="22" stroke="#94A3B8" strokeWidth="1.5" strokeDasharray="4 4" />
            <line
              x1="20"
              y1="22"
              x2="340"
              y2={Math.min(78, 22 + Math.round(1800 / slopeRatio))}
              stroke="#1D4ED8"
              strokeWidth="8"
              strokeLinecap="round"
            />
            <text x="24" y="15" fontSize="10" fill="#475569" fontFamily="monospace">LEVEL 0 mm</text>
            <text
              x="336"
              y={Math.min(91, 38 + Math.round(1800 / slopeRatio))}
              textAnchor="end"
              fontSize="11"
              fill="#1D4ED8"
              fontFamily="monospace"
              fontWeight="700"
            >
              DROP: -{dropMm} mm (-{dropCm} cm)
            </text>
          </svg>
        </div>

        <div className="grid grid-cols-2 gap-3 bg-blue-50 border border-blue-200 rounded-xl p-3.5">
          <div>
            <div className="text-xs text-blue-800">{lang === 'hi' ? 'कुल ढलान (mm में)' : 'Total Fall (mm)'}</div>
            <div className="text-xl font-bold font-mono-num text-blue-950">{dropMm} mm</div>
          </div>
          <div>
            <div className="text-xs text-blue-800">{lang === 'hi' ? 'कुल ढलान (cm में)' : 'Total Fall (cm)'}</div>
            <div className="text-xl font-bold font-mono-num text-blue-950">{dropCm} cm</div>
          </div>
        </div>
      </div>

      {/* 2. 45-Degree Offset & Water Tank Sizing */}
      <div className="space-y-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">
            {lang === 'hi' ? '45° पाइप ऑफसेट कैलकुलेटर' : '45° Pipe Offset Travel Calculator'}
          </h3>
          <div className="flex flex-col sm:flex-row sm:items-end gap-3">
            <label className="flex-1 space-y-1">
              <span className="text-xs font-medium text-slate-700">
                {lang === 'hi' ? 'दोनों लाइनों के बीच दूरी (Offset mm)' : 'Center-to-Center Offset (mm)'}
              </span>
              <input
                type="number"
                min={20}
                max={5000}
                value={offsetMm}
                onChange={(e) => setOffsetMm(Math.max(10, Number(e.target.value) || 0))}
                className="w-full h-11 px-3 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </label>
            <div className="bg-slate-900 text-white rounded-xl px-4 py-2.5 shrink-0">
              <div className="text-[11px] text-slate-300">Travel = Offset × 1.414</div>
              <div className="text-lg font-bold font-mono-num">{travelMm} mm</div>
            </div>
          </div>
          <p className="text-xs text-slate-600">
            {lang === 'hi'
              ? 'याद रखें: कुल ट्रैवल में से दोनों 45° एल्बो के अंदर जाने वाली गहराई (Socket depth) घटाकर पाइप काटें।'
              : 'Remember: Subtract the socket insertion depths of both 45° elbows from the Travel length before cutting.'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">
            {lang === 'hi' ? 'वाटर टैंक साइज कैलकुलेटर' : 'Water Tank Capacity Estimator'}
          </h3>
          <div className="flex flex-col sm:flex-row sm:items-end gap-3">
            <label className="flex-1 space-y-1">
              <span className="text-xs font-medium text-slate-700">
                {lang === 'hi' ? 'घर में रहने वाले लोग (Persons)' : 'Number of Residents / Users'}
              </span>
              <input
                type="number"
                min={1}
                max={500}
                value={occupants}
                onChange={(e) => setOccupants(Math.max(1, Number(e.target.value) || 1))}
                className="w-full h-11 px-3 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </label>
            <div className="bg-blue-700 text-white rounded-xl px-4 py-2.5 shrink-0">
              <div className="text-[11px] text-blue-100">150 L / Person / Day</div>
              <div className="text-lg font-bold font-mono-num">
                {tankLiters.toLocaleString()} L · {tankGallons} USG
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-600">
            {lang === 'hi'
              ? 'बड़े विला या 2 दिन के बैकअप के लिए इसे 1.5 से 2 गुना साइज का टैंक चुनें।'
              : 'For villas or 48-hour storage reserve, select 1.5× to 2× the daily demand tank capacity.'}
          </p>
        </div>
      </div>
    </div>
  );
};

export const BoqEstimator: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [bathrooms, setBathrooms] = useState(2);
  const [kitchens, setKitchens] = useState(1);
  const [currency, setCurrency] = useState<'AED' | 'INR'>('AED');
  const [copied, setCopied] = useState(false);

  const rows = BOQ_ITEMS.map((item) => {
    const qty = item.qtyPerBathroom * bathrooms + item.qtyPerKitchen * kitchens;
    const rate = currency === 'AED' ? item.approxRateAed : item.approxRateInr;
    return {
      ...item,
      qty,
      rate,
      total: qty * rate,
    };
  }).filter((r) => r.qty > 0);

  const grandTotal = rows.reduce((sum, r) => sum + r.total, 0);

  const handleCopySummary = () => {
    const lines = [
      `Farid Plumber Pro - BOQ (${bathrooms} Bath, ${kitchens} Kitchen)`,
      ...rows.map((r) => `- ${r.item.en}: ${r.qty} ${r.unit} (${currency} ${r.total})`),
      `Estimated Material Total: ${currency} ${grandTotal.toLocaleString()}`,
    ];
    navigator.clipboard?.writeText(lines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700">
            <ClipboardList className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-base">
              {lang === 'hi' ? 'प्लंबिंग मटेरियल लिस्ट (BOQ) और खर्च अनुमान' : 'Plumbing BOQ & Material Cost Estimator'}
            </h3>
            <p className="text-xs text-slate-500">
              {lang === 'hi' ? 'बाथरूम और किचन की संख्या चुनकर तुरंत सामान की लिस्ट पाएं' : 'Adjust room counts to generate instant pipe & fitting quantities'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-medium text-slate-700">{lang === 'hi' ? 'बाथरूम' : 'Bathrooms'}:</span>
            <button
              onClick={() => setBathrooms((b) => Math.max(0, b - 1))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 font-bold text-slate-800"
            >
              -
            </button>
            <span className="w-6 text-center font-mono-num font-bold text-sm">{bathrooms}</span>
            <button
              onClick={() => setBathrooms((b) => Math.min(20, b + 1))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 font-bold text-slate-800"
            >
              +
            </button>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-medium text-slate-700">{lang === 'hi' ? 'किचन' : 'Kitchens'}:</span>
            <button
              onClick={() => setKitchens((k) => Math.max(0, k - 1))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 font-bold text-slate-800"
            >
              -
            </button>
            <span className="w-6 text-center font-mono-num font-bold text-sm">{kitchens}</span>
            <button
              onClick={() => setKitchens((k) => Math.min(10, k + 1))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 font-bold text-slate-800"
            >
              +
            </button>
          </div>

          <div className="flex p-1 bg-slate-100 rounded-xl">
            {(['AED', 'INR'] as const).map((c) => (
              <button
                key={c}
                onClick={() => setCurrency(c)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  currency === c ? 'bg-blue-700 text-white' : 'text-slate-700'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-xs text-slate-500">
              <th className="py-2.5 pr-4 font-semibold">{lang === 'hi' ? 'सामान का नाम (Material)' : 'Material Item'}</th>
              <th className="py-2.5 px-3 font-semibold text-right">Qty</th>
              <th className="py-2.5 px-3 font-semibold">Unit</th>
              <th className="py-2.5 px-3 font-semibold text-right">Rate ({currency})</th>
              <th className="py-2.5 pl-3 font-semibold text-right">Total ({currency})</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((row) => (
              <tr key={row.id} className="hover:bg-slate-50">
                <td className="py-3 pr-4">
                  <div className="font-medium text-slate-900">{row.item.en}</div>
                  {lang !== 'en' && <div className="text-xs text-slate-600">{row.item.hi}</div>}
                </td>
                <td className="py-3 px-3 text-right font-mono-num font-semibold text-blue-700">{row.qty}</td>
                <td className="py-3 px-3 text-xs text-slate-600">{row.unit}</td>
                <td className="py-3 px-3 text-right font-mono-num text-slate-700">{row.rate}</td>
                <td className="py-3 pl-3 text-right font-mono-num font-semibold text-slate-900">
                  {row.total.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-200">
        <div>
          <div className="text-xs text-slate-500">
            {lang === 'hi' ? 'अनुमानित पाइप व फिटिंग मटेरियल खर्च (सैनिटरीवेयर अलग)' : 'Estimated First-Fix Material Total (Excludes Sanitaryware & Labor)'}
          </div>
          <div className="text-2xl font-bold font-mono-num text-blue-700">
            {currency} {grandTotal.toLocaleString()}
          </div>
        </div>
        <button
          onClick={handleCopySummary}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors min-h-[44px]"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <ClipboardList className="w-4 h-4" />}
          <span>{copied ? (lang === 'hi' ? 'लिस्ट कॉपी हो गई!' : 'BOQ Copied!') : (lang === 'hi' ? 'BOQ लिस्ट कॉपी करें' : 'Copy BOQ List')}</span>
        </button>
      </div>
    </div>
  );
};
