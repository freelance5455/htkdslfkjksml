import React from 'react';
import { Award, Clock, Radio, Users, CheckCircle, ShieldCheck, Zap, BatteryCharging, Headphones } from 'lucide-react';

export const TrustSection: React.FC = () => {
  const trustPillars = [
    {
      icon: <Award className="w-6 h-6 text-purple-400" />,
      title: 'Cross DJ Pro Expert',
      tag: 'Precision & Flow',
      desc: 'Known as "The Cue King" across Kampala for millisecond-sharp hot cue transitions, live looping, and seamless beatmatching with zero dead air.',
    },
    {
      icon: <Clock className="w-6 h-6 text-cyan-400" />,
      title: '5+ Years Active Experience',
      tag: 'Over 350+ Events',
      desc: 'From high-profile Munyonyo weddings and Kwanjulas in Mukono to packed club nights in Kansanga and student bashes in Kikoni.',
    },
    {
      icon: <Radio className="w-6 h-6 text-rose-500" />,
      title: 'TikTok LIVE Daily 8:00 PM',
      tag: '@djevanproug',
      desc: 'Watch me perform live every single night. Test my mixing live before paying a single shilling of your event deposit.',
    },
    {
      icon: <Users className="w-6 h-6 text-emerald-400" />,
      title: 'Works with Ugandan Artists',
      tag: 'Ugandan Music Pulse',
      desc: 'Direct connection with Kampala hitmakers. Access to unreleased dubplates, clean radio edits, and trending Bax Ragga & Amapiano drops.',
    },
  ];

  const gearChecklist = [
    { label: 'Cross DJ Pro Digital Controller Console', detail: 'Zero latency hot-cue triggers' },
    { label: 'Uninterruptible Battery / Power Backup', detail: 'No music stoppage during power blinks' },
    { label: 'Dual Professional Wireless UHF Microphones', detail: 'Crystal-clear speech for your Emcee' },
    { label: 'Balanced Gold-Plated Audio Cables', detail: 'Zero humming, buzz, or speaker distortion' },
  ];

  return (
    <section className="py-14 px-4 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase tracking-widest bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800/40 mb-3">
          <ShieldCheck className="w-3.5 h-3.5" />
          The DJ You Can Trust With Your Special Day
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
          Why Book DJ Evan Pro UG?
        </h2>
        <p className="text-sm text-slate-300 max-w-xl mx-auto mt-2">
          Your event only happens once. Here is why party hosts and wedding couples in Kampala choose The Cue King over amateur DJs.
        </p>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {trustPillars.map((pillar, idx) => (
          <div
            key={idx}
            className="p-6 rounded-2xl bg-gradient-to-br from-[#120a22] to-[#0c0817] border border-purple-900/60 hover:border-purple-500/50 transition-all flex gap-4 items-start shadow-lg"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-950/80 border border-purple-700/50 flex items-center justify-center shrink-0 shadow-md">
              {pillar.icon}
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                  {pillar.tag}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight">
                {pillar.title}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {pillar.desc}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Gear & Reliability Banner */}
      <div className="bg-[#0e0a1a] border border-purple-800/40 rounded-3xl p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-3">
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
              <BatteryCharging className="w-4 h-4 text-emerald-400" />
              100% Reliability Guarantee
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white uppercase">
              No Power Cuts. No Awkward Pauses. No Late Arrivals.
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              We know how important your event is. DJ Evan Pro arrives at least 60 to 90 minutes before your first guest steps in to complete full audio sound checks.
            </p>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {gearChecklist.map((item, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/40 flex items-start gap-2.5"
              >
                <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white">{item.label}</div>
                  <div className="text-[11px] text-slate-400">{item.detail}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
