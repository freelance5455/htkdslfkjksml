import React, { useState, useEffect, useRef } from "react";
import {
  StylusSettings,
  PalmRejectionMode,
  SmartEraserFilterMode,
} from "../types";
import {
  StylusSettingsManager,
  calculateStrokeWidth,
} from "../utils/digitalInkEngine";
import { StylusEngine } from "../utils/stylusEngine";
import {
  CustomPaletteManager,
  CustomPaletteConfig,
} from "../utils/canvasDrawingEngine";
import { PenPreviewBadge } from "./PenPreviewBadge";
import { RealisticPenPalette } from "./RealisticPenPalette";
import {
  SkeuomorphicFountainPen,
  SkeuomorphicPencil,
  SkeuomorphicHighlighter,
  SkeuomorphicEraser,
  SkeuomorphicLasso,
  SkeuomorphicLaserMarker,
  SkeuomorphicRecallTape,
} from "./SkeuomorphicPenIcons";
import {
  PenTool,
  Check,
  CheckCircle2,
  Sliders,
  Shield,
  Zap,
  Sparkles,
  Grid,
  RotateCcw,
  Cpu,
  Smartphone,
  Info,
  Layers,
  Feather,
  Pencil,
  Highlighter,
  Eraser,
  HelpCircle,
  Plus,
  Palette,
  Scissors,
  Trash2,
  EyeOff,
  Eye,
  Link,
  Moon,
  Sun,
  Bookmark,
} from "lucide-react";

export const StylusSettingsHub: React.FC = () => {
  const [settings, setSettings] = useState<StylusSettings>(
    StylusSettingsManager.getSettings()
  );
  const [toastNotice, setToastNotice] = useState<string | null>(null);
  const [demoTapeRevealed, setDemoTapeRevealed] = useState<boolean>(false);
  const [customPalettes, setCustomPalettes] = useState<CustomPaletteConfig[]>(
    CustomPaletteManager.getPalettes()
  );
  const [selectedPaletteId, setSelectedPaletteId] = useState<string>("custom_user_palette");
  const [newColorInput, setNewColorInput] = useState<string>("#10B981");

  const handleAddColorToPalette = (paletteId: string) => {
    if (!newColorInput) return;
    const current = CustomPaletteManager.getPalettes();
    const target = current.find((p) => p.id === paletteId);
    if (target) {
      if (!target.colors.includes(newColorInput)) {
        const updatedColors = [...target.colors, newColorInput];
        CustomPaletteManager.updatePalette(paletteId, { colors: updatedColors });
        setCustomPalettes(CustomPaletteManager.getPalettes());
        setToastNotice(`✓ Palete yeni renk eklendi: ${newColorInput}`);
        setTimeout(() => setToastNotice(null), 3000);
      }
    }
  };

  const handleRemoveColorFromPalette = (paletteId: string, colorHex: string) => {
    const current = CustomPaletteManager.getPalettes();
    const target = current.find((p) => p.id === paletteId);
    if (target && target.colors.length > 2) {
      const updatedColors = target.colors.filter((c) => c !== colorHex);
      CustomPaletteManager.updatePalette(paletteId, { colors: updatedColors });
      setCustomPalettes(CustomPaletteManager.getPalettes());
    }
  };
  const [engineInfo, setEngineInfo] = useState(StylusEngine.selectProvider());

  // Sandbox Live Test Canvas State
  const sandboxRef = useRef<HTMLCanvasElement | null>(null);
  const [lastPressure, setLastPressure] = useState<number>(0);
  const [lastPointerType, setLastPointerType] = useState<string>("Bilinmiyor");
  const [isSandboxDrawing, setIsSandboxDrawing] = useState<boolean>(false);

  useEffect(() => {
    const unsub = StylusSettingsManager.subscribe((newSettings) => {
      setSettings(newSettings);
    });
    setEngineInfo(StylusEngine.selectProvider());
    return unsub;
  }, []);

  const updateSetting = <K extends keyof StylusSettings>(
    key: K,
    val: StylusSettings[K]
  ) => {
    StylusSettingsManager.updateSettings({ [key]: val });
    setToastNotice(`✓ Kalem ayarı güncellendi: ${String(key)}`);
    setTimeout(() => setToastNotice(null), 3000);
  };

  // Sandbox Canvas Pointer Handlers
  const handleSandboxPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = sandboxRef.current;
    if (!canvas) return;

    canvas.setPointerCapture(e.pointerId);
    setIsSandboxDrawing(true);
    setLastPressure(e.pressure > 0 ? e.pressure : 0.5);
    setLastPointerType((e.pointerType as string) === "pen" ? "Stylus Kalem (pen)" : e.pointerType);

    const ctx = canvas.getContext("2d");
    if (ctx) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const handleSandboxPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isSandboxDrawing) return;
    const canvas = sandboxRef.current;
    if (!canvas) return;

    const pressure = e.pressure > 0 ? e.pressure : 0.5;
    setLastPressure(pressure);
    setLastPointerType((e.pointerType as string) === "pen" ? "Stylus Kalem (pen)" : e.pointerType);

    const ctx = canvas.getContext("2d");
    if (ctx) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const w = calculateStrokeWidth(4, pressure, "fountain", settings.pressureSensitivity);
      ctx.lineWidth = w;
      ctx.strokeStyle = "#0D9488"; // Teal
      ctx.lineCap = "round";
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const handleSandboxPointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    setIsSandboxDrawing(false);
    const canvas = sandboxRef.current;
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }
  };

  const clearSandbox = () => {
    const canvas = sandboxRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    setLastPressure(0);
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-200">
      {/* Toast Feedback */}
      {toastNotice && (
        <div className="p-3 sm:p-4 rounded-2xl bg-teal-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{toastNotice}</span>
          </div>
          <button
            onClick={() => setToastNotice(null)}
            className="p-1 hover:bg-teal-700 rounded-lg text-teal-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* HEADER BANNER: KALEM & STYLUS ENGINE HUB */}
      <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-indigo-950 text-white px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-teal-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center justify-center font-black">
              <PenTool className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-teal-100 flex items-center gap-2">
                <span>DİJİTAL KALEM & STYLUS MERKEZİ</span>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-800 text-teal-200 border border-teal-600">
                  GMS & HMS Engine
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Avuç içi engelleme (Palm Rejection), basınca duyarlı Bezier pürüzsüzleştirme ve ML Kit el yazısı tanıma ayarları.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-2xl border border-slate-700 text-xs font-mono text-teal-300">
            <Cpu className="w-4 h-4 text-amber-400" />
            <span>{engineInfo.providerName}</span>
          </div>
        </div>
      </div>

      {/* ULTRA-REALISTIC STUDIO STYLUS PEN PALETTE */}
      <RealisticPenPalette />

      {/* 1. HARDWARE CAPABILITY DIAGNOSTIC CARD */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>Donanım Sürücüsü ve S-Pen / M-Pencil / Apple Pencil Desteği</span>
          </h3>
          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
            ✓ Etkin Motor: {engineInfo.providerId}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          {engineInfo.capabilities.map((cap, idx) => (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center gap-2 text-slate-700 dark:text-slate-300 font-medium"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span className="truncate">{cap}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 9 REGISTERED PEN TOOL PLUGINS & CUSTOMIZATION GALLERY */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>9 Özel Kalem Çeşidi & Çizip Kesme (Lasso Cut) Galerisi</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Tüm kalem türlerinin varsayılan fırça boyutunu, opaklığını, basınç duyarlılığını ve açı desteğini özelleştirin.
            </p>
          </div>
          <span className="text-[10px] font-black px-2.5 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-800 self-start sm:self-center">
            {StylusEngine.getRegisteredBrushes().length} Özel Kalem Araçı
          </span>
        </div>

        {/* 9 Pens Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {StylusEngine.getRegisteredBrushes().map((b, idx) => (
            <div
              key={b.id}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2.5 hover:border-teal-400 transition-all shadow-xs"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <span className="w-5 h-5 rounded-lg bg-teal-600 text-white flex items-center justify-center text-[10px] font-bold">
                    {idx + 1}
                  </span>
                  <span>{b.name}</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/80 px-2 py-0.5 rounded-md border border-teal-200 dark:border-teal-800">
                  {b.defaultSize}px
                </span>
              </div>

              {/* Live Stroke Preview Canvas */}
              <div className="flex items-center justify-between bg-slate-900/60 p-2 rounded-xl border border-slate-700/60">
                <span className="text-[10px] font-mono font-bold text-slate-400">Canlı Ön İzleme:</span>
                <PenPreviewBadge
                  tool={b.id as any}
                  color={b.id === "neon_glow" ? "#FACC15" : b.id === "laser_marker" ? "#EF4444" : "#0D9488"}
                  size={b.defaultSize}
                  width={88}
                  height={28}
                />
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                {b.description}
              </p>

              <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                {b.supportsPressure && (
                  <span className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    Basınç Duyarlı ✓
                  </span>
                )}
                {b.supportsTilt && (
                  <span className="px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                    Açı / Eğim Duyarlı ✓
                  </span>
                )}
                <span className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                  Opaklık: {(b.defaultOpacity * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* SPECIAL TOOL: LASSO CUT & SCISSORS DEMO & CUSTOMIZATION */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-500/10 via-slate-800/20 to-teal-500/10 border border-rose-300/40 dark:border-rose-900/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <h4 className="text-xs font-black text-rose-700 dark:text-rose-300 flex items-center gap-1.5">
              <span>✂️ Çizip Kesme (Lasso Cut & Scissors) & İşaretleme Vurgu Aracı</span>
            </h4>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 max-w-xl">
              Çizim veya el yazısı üzerinde kement atarak istediğiniz parçayı seçebilir, kesip başka bir alana taşıyabilir, kopyalayabilir ya da tek tıkla silebilirsiniz.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <PenPreviewBadge tool="lasso_cut" color="#0D9488" size={3} width={72} height={28} />
            <span className="px-3 py-1 rounded-full bg-rose-600 text-white text-[10px] font-black shrink-0 shadow-xs">
              Kement Seçim Aktif
            </span>
          </div>
        </div>

        {/* 3. ÖZELLEŞTİRİLEBİLİR RENK PALETLERİ VE CANLI ÖN İZLEME (CUSTOM PALETTES STUDIO) */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Palette className="w-4 h-4 text-amber-500" />
                <span>3. Palet Kullanımı Özelleştirme & Canlı Fırça Ön İzleme Studio</span>
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Kombinasyon 1, 2 ve 3. özel paletlerinizi düzenleyin, yeni renkler ekleyin ve canlı çizgi ön izlemelerini inceleyin.
              </p>
            </div>
          </div>

          {/* Palette Picker Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {customPalettes.map((p) => {
              const isSelected = selectedPaletteId === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPaletteId(p.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    isSelected
                      ? "border-amber-500 bg-amber-500/10 ring-2 ring-amber-500/20 shadow-md"
                      : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900 dark:text-white truncate">
                      {p.name}
                    </span>
                    {isSelected && <Check className="w-4 h-4 text-amber-500 shrink-0" />}
                  </div>

                  <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-2">
                    {p.description}
                  </p>

                  {/* Swatches List */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {p.colors.map((hex) => (
                      <div
                        key={hex}
                        className="group relative w-6 h-6 rounded-full border border-white/60 shadow-inner shrink-0"
                        style={{ backgroundColor: hex }}
                        title={hex}
                      >
                        {p.colors.length > 2 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveColorFromPalette(p.id, hex);
                            }}
                            className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-rose-600 text-white text-[8px] font-bold hidden group-hover:flex items-center justify-center cursor-pointer"
                            title="Rengi Sil"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Live Stroke Previews for Palette Colors */}
                  <div className="pt-2 border-t border-slate-200/50 dark:border-slate-700/50 flex items-center justify-between gap-1 overflow-x-auto">
                    {p.colors.slice(0, 4).map((c) => (
                      <PenPreviewBadge key={c} tool="fountain" color={c} size={4} width={42} height={20} />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Color to Selected Palette Form */}
          {selectedPaletteId && (
            <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  Seçili Palete Renk Ekle:
                </span>
                <input
                  type="color"
                  value={newColorInput}
                  onChange={(e) => setNewColorInput(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                />
                <span className="font-mono text-xs font-bold text-teal-600 dark:text-teal-400 uppercase">
                  {newColorInput}
                </span>
              </div>

              <button
                type="button"
                onClick={() => handleAddColorToPalette(selectedPaletteId)}
                className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Palete Ekle</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 2. INTERACTIVE LIVE STYLUS SANDBOX (PRESSURE TEST) */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Feather className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Canlı Kalem & Basınç Test Kanvası (Sandbox)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Kaleminizi ekrana bastırarak basınca göre değişen fırça kalınlığını ve Bezier eğrilerini test edin.
            </p>
          </div>

          <button
            type="button"
            onClick={clearSandbox}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Testi Temizle</span>
          </button>
        </div>

        {/* Live Test Canvas Box */}
        <div className="relative w-full h-36 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 overflow-hidden">
          <canvas
            ref={sandboxRef}
            width={800}
            height={200}
            onPointerDown={handleSandboxPointerDown}
            onPointerMove={handleSandboxPointerMove}
            onPointerUp={handleSandboxPointerUp}
            onPointerCancel={handleSandboxPointerUp}
            className="w-full h-full cursor-crosshair touch-none"
            style={{ touchAction: "none" }}
          />

          {/* Sandbox Realtime Diagnostic Overlay */}
          <div className="absolute top-2 left-2 flex items-center gap-2 text-[10px] font-mono bg-slate-900/80 text-white px-3 py-1 rounded-full backdrop-blur-md border border-slate-700 pointer-events-none">
            <span>Girdi Tipi: <strong className="text-teal-400">{lastPointerType}</strong></span>
            <span>|</span>
            <span>Basınç (Pressure): <strong className="text-amber-400">{(lastPressure * 100).toFixed(0)}%</strong></span>
          </div>
        </div>
      </div>

      {/* 3. PALM REJECTION & DOUBLE TAP SETTINGS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* PALM REJECTION MODE */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Avuç İçi Engelleme (Palm Rejection)</span>
            </h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300">
              TOOL_TYPE_STYLUS
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Eliniz ekrandayken parmak dokunuşlarını çizimden muaf tutarak sadece kalemin iz bırakmasını sağlar.
          </p>

          <div className="grid grid-cols-3 gap-2 pt-1">
            {[
              { id: "strict", label: "Sıkı (Katı)", desc: "Parmakları Tamamen Engelle" },
              { id: "balanced", label: "Dengeli", desc: "Parmakla Pan/Zoom İzni Ver" },
              { id: "disabled", label: "Devre Dışı", desc: "Dokunmatik Çizim Açık" },
            ].map((m) => {
              const isSel = settings.palmRejection === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => updateSetting("palmRejection", m.id as PalmRejectionMode)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                    isSel
                      ? "border-teal-500 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 font-bold shadow-xs ring-2 ring-teal-500/20"
                      : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold">{m.label}</span>
                    {isSel && <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />}
                  </div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500">{m.desc}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* DOUBLE TAP GESTURE SETTING */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Çift Dokunma Eylemi (Double Tap Gesture)</span>
            </h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
              S-Pen / Apple Pencil
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Kalem gövdesine çift dokunulduğunda veya butonuna basıldığında tetiklenecek hızlı eylemi seçin.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {[
              { id: "eraser", label: "Silgiye Geç / Kaleme Dön", icon: Eraser },
              { id: "undo", label: "Son Çizgiyi Geri Al (Undo)", icon: RotateCcw },
              { id: "palette", label: "Renk Paletini Aç", icon: Sliders },
              { id: "toggle_tool", label: "Son Kullanılan Araca Geç", icon: PenTool },
            ].map((g) => {
              const isSel = settings.doubleTapAction === g.id;
              const IconComp = g.icon;
              return (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => updateSetting("doubleTapAction", g.id as any)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                    isSel
                      ? "border-amber-500 bg-amber-50/60 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 font-bold shadow-xs ring-2 ring-amber-500/20"
                      : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <IconComp className="w-4 h-4 text-amber-500 shrink-0" />
                  <span className="text-xs truncate">{g.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. SMOOTHING & OCR TOGGLES */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Sliders className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span>İnce Kalem ve El Yazısı OCR Hassasiyeti</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Pressure Sensitivity Slider */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>Basınç Duyarlılığı Çarpanı:</span>
              <span className="font-mono text-teal-600 dark:text-teal-400 font-black">
                {settings.pressureSensitivity.toFixed(1)}x
              </span>
            </div>
            <input
              type="range"
              min="0.2"
              max="2.0"
              step="0.1"
              value={settings.pressureSensitivity}
              onChange={(e) => updateSetting("pressureSensitivity", parseFloat(e.target.value))}
              className="w-full accent-teal-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>Hafif Dokunuş</span>
              <span>Yoğun Basınç</span>
            </div>
          </div>

          {/* Auto ML Kit Digital Ink OCR Toggle */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Otomatik El Yazısı OCR İndeksleme</span>
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                Çizilen el yazılarını arka planda aranabilir metne çevirir.
              </span>
            </div>

            <input
              type="checkbox"
              checked={settings.autoOCR}
              onChange={(e) => updateSetting("autoOCR", e.target.checked)}
              className="w-5 h-5 rounded text-teal-600 focus:ring-teal-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 5. ACTIVE RECALL TAPE & SMART ERASER FILTER STUDIO */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* ACTIVE RECALL TAPE CONFIGURATION & LIVE DEMO CARD */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-amber-500" />
              <span>Hafıza Bandı (Active Recall Tape)</span>
            </h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
              Aktif Hatırlama
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Ders çalışırken formül veya cevapların üstünü kapatır. Tıklandığında şeffaflaşarak altındaki bilgiyi gösterir.
          </p>

          {/* Interactive Live Scratch & Reveal Preview */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-bold text-slate-400 block">Canlı Test (Banta Dokunun):</span>
            <div
              onClick={() => setDemoTapeRevealed((prev) => !prev)}
              className="relative p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer overflow-hidden select-none"
            >
              <div className="text-xs font-mono text-slate-800 dark:text-slate-200 font-bold">
                E = m · c² &nbsp;|&nbsp; Mitoz Bölünme: Profaz, Metafaz, Anafaz
              </div>

              {/* Tape Overlay */}
              <div
                className={`absolute inset-0 flex items-center justify-center font-bold text-[11px] transition-all duration-300 ${
                  demoTapeRevealed
                    ? "opacity-20 border-2 border-dashed border-amber-400 bg-amber-400/20 text-transparent"
                    : "opacity-98 shadow-md text-slate-950"
                }`}
                style={{
                  backgroundColor: demoTapeRevealed ? undefined : (settings.recallTapeColor || "#F59E0B"),
                }}
              >
                {!demoTapeRevealed && (
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 text-slate-900 text-[10px] shadow-sm font-black">
                    <Eye className="w-3 h-3 text-amber-600" />
                    Cevabı Görmek İçin Dokun (Tap to Reveal)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Tape Color Selector */}
          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300">Bant Rengi:</span>
            <div className="flex items-center gap-2">
              {[
                { name: "Kehribar Sarı", hex: "#F59E0B" },
                { name: "Koyu Gece", hex: "#1E293B" },
                { name: "Zümrüt", hex: "#0D9488" },
                { name: "Yakut Kırmızı", hex: "#E11D48" },
              ].map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => updateSetting("recallTapeColor", c.hex)}
                  className={`w-6 h-6 rounded-full border transition-transform cursor-pointer ${
                    settings.recallTapeColor === c.hex ? "scale-125 ring-2 ring-amber-500 shadow-md" : ""
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
            </div>
          </div>
        </div>

        {/* SMART ERASER LAYER FILTER MODE */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Eraser className="w-4 h-4 text-rose-500" />
              <span>Akıllı Silgi Katman Filtresi</span>
            </h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300">
              Layer Filtering
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Silgi kullanırken hangi nesne katmanlarının silineceğini belirleyin. Vurgulayıcıyı silerken el yazınızı koruyabilirsiniz.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {[
              { id: "all", label: "Tümünü Sil", desc: "Çizim, vurgu ve bantlar" },
              { id: "ink_only", label: "Sadece Çizim", desc: "Vurgu ve bantları korur" },
              { id: "highlighter_only", label: "Sadece Vurgulayıcı", desc: "El yazısını korur" },
              { id: "tape_only", label: "Sadece Bantları", desc: "Mürekkebi korur" },
            ].map((f) => {
              const isSel = settings.activeEraserFilter === f.id;
              return (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => updateSetting("activeEraserFilter", f.id as SmartEraserFilterMode)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                    isSel
                      ? "border-rose-500 bg-rose-50/60 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 font-bold shadow-xs ring-2 ring-rose-500/20"
                      : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold">{f.label}</span>
                    {isSel && <Check className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />}
                  </div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500">{f.desc}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 6. NIGHT MODE INK ADAPTATION & BIDIRECTIONAL LINKS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* NIGHT MODE INK CONTRAST ADAPTATION */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Moon className="w-4 h-4 text-indigo-400" />
              <span>Gece Modu Akıllı Mürekkep Uyarlaması</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Gece (karanlık) temaya geçildiğinde siyah/koyu mürekkepleri otomatik olarak parlak beyaz çizgiye dönüştürür; renkli kalemler korunur.
            </p>
          </div>

          <input
            type="checkbox"
            checked={settings.adaptiveNightModeInk}
            onChange={(e) => updateSetting("adaptiveNightModeInk", e.target.checked)}
            className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer shrink-0"
          />
        </div>

        {/* BIDIRECTIONAL LINKS [[NOTE]] KNOWLEDGE GRAPH TOGGLE */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Link className="w-4 h-4 text-sky-500" />
              <span>Çift Yönlü Bağlantılar ([[Not Adı]])</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Tuval veya metin kutusuna <code>[[Not Başlığı]]</code> yazıldığında otomatik tıklanabilir köprü kurar ve notlar arası kronolojik ağ örer.
            </p>
          </div>

          <input
            type="checkbox"
            checked={settings.bidirectionalLinksEnabled}
            onChange={(e) => updateSetting("bidirectionalLinksEnabled", e.target.checked)}
            className="w-5 h-5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer shrink-0"
          />
        </div>
      </div>

      {/* EXTENSIBLE STYLUS FEATURE EXPANSION BOX */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-teal-500/10 via-slate-900/40 to-indigo-500/10 border border-teal-500/30 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Plus className="w-4 h-4 text-teal-400 shrink-0" />
          <span>Gelecekte eklenecek yeni Stylus araçları ve özel fırça eklentileri (Plugins) buraya dinamik eklenebilir.</span>
        </div>
        <span className="text-[10px] font-bold px-2 py-1 rounded bg-teal-900 text-teal-200 border border-teal-700">
          Genişletilebilir Modüler Mimari
        </span>
      </div>
    </div>
  );
};
