import { useState } from 'react';
import { Layers, FolderTree, Database, GitFork, Smartphone, Palette, Terminal, Copy, Check } from 'lucide-react';
import { Language } from '../../types';

interface FlutterArchitectureDocProps {
  language: Language;
}

export function FlutterArchitectureDoc({ language }: FlutterArchitectureDocProps) {
  const [activeSection, setActiveSection] = useState<'arch' | 'folders' | 'schema' | 'flows' | 'screens' | 'design' | 'flutter_code'>('arch');
  const [copied, setCopied] = useState(false);

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-24 text-white">
      {/* Header */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-[#0c1a40] via-[#091535] to-[#060c22] border border-cyan-500/30">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
            Production Blueprint · Flutter & Dart Enterprise Ready
          </span>
        </div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {language === 'ar' ? 'معمارية نظام TAKI-GO وتطبيق Flutter' : 'TAKI-GO Mobile Architecture Blueprint'}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {language === 'ar'
            ? 'الهندسة المعمارية الكاملة لتطبيق الهاتف المحمول (Android & iOS) بنمط Clean Architecture وهيكل المجلدات وقاعدة البيانات وتدفق العمليات.'
            : 'Enterprise Clean Architecture specification for native Flutter mobile apps targeting iOS & Android.'}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
        {[
          { id: 'arch', label: '1. Architecture', icon: <Layers className="w-3.5 h-3.5" /> },
          { id: 'folders', label: '2. Folder Structure', icon: <FolderTree className="w-3.5 h-3.5" /> },
          { id: 'schema', label: '3. Database Schema', icon: <Database className="w-3.5 h-3.5" /> },
          { id: 'flows', label: '4 & 5. User & Admin Flows', icon: <GitFork className="w-3.5 h-3.5" /> },
          { id: 'screens', label: '6. Screen Map', icon: <Smartphone className="w-3.5 h-3.5" /> },
          { id: 'design', label: '7. UI Design System', icon: <Palette className="w-3.5 h-3.5" /> },
          { id: 'flutter_code', label: '8. Flutter Source Code', icon: <Terminal className="w-3.5 h-3.5" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id as any)}
            className={`px-3.5 py-2 rounded-2xl flex items-center gap-1.5 whitespace-nowrap font-bold transition-all border ${
              activeSection === tab.id
                ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 1. ARCHITECTURE */}
      {activeSection === 'arch' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Clean Architecture & Domain Separation</span>
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            تم بناء تطبيق TAKI-GO وفق معمارية <strong>Clean Architecture</strong> القائمة على فصل المسؤوليات (Separation of Concerns) وFeature-Based Structure لضمان استقلالية طبقات الأعمال عن مكتبات العرض وواجهات برمجة التطبيقات:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-4 bg-slate-900/90 rounded-2xl border border-blue-500/30">
              <span className="font-mono text-cyan-400 font-bold text-[11px] block mb-1">Presentation Layer</span>
              <p className="font-semibold text-white mb-2">Bloc / Cubit State Management</p>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>Widgets & Custom UI Components</li>
                <li>Reactive State (BlocProvider & BlocBuilder)</li>
                <li>Haptic Feedback & Micro-Interactions</li>
                <li>RTL / LTR & Trilingual Localization</li>
              </ul>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-cyan-500/30">
              <span className="font-mono text-cyan-400 font-bold text-[11px] block mb-1">Domain Layer</span>
              <p className="font-semibold text-white mb-2">Pure Business Rules & UseCases</p>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>Entities (Immutable Data Models)</li>
                <li>Repository Interfaces (Contracts)</li>
                <li>UseCases (e.g. SearchFlightsUseCase, GenerateDevisUseCase)</li>
                <li>No framework or Flutter dependencies</li>
              </ul>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-indigo-500/30">
              <span className="font-mono text-cyan-400 font-bold text-[11px] block mb-1">Data Layer</span>
              <p className="font-semibold text-white mb-2">Local Persistence & Remote Gateways</p>
              <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside">
                <li>DataSources (SQLite, Hive, FlutterSecureStorage)</li>
                <li>Repository Implementations</li>
                <li>JSON Mappers & Encoders</li>
                <li>Offline Sync Engine</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* 2. FOLDER STRUCTURE */}
      {activeSection === 'folders' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FolderTree className="w-5 h-5 text-cyan-400" />
              <span>Flutter Project Folder Structure</span>
            </h2>
            <button
              onClick={() => handleCopyCode(`lib/
├── core/
│   ├── constants/
│   ├── errors/
│   ├── network/
│   ├── services/
│   │   ├── local_db_service.dart
│   │   ├── secure_storage_service.dart
│   │   ├── push_notification_service.dart
│   │   └── offline_cache_service.dart
│   ├── theme/
│   │   ├── app_colors.dart
│   │   └── app_theme.dart
│   └── utils/
├── features/
│   ├── auth/
│   ├── home/
│   ├── explore_globe/
│   ├── ai_assistant/
│   ├── flights/
│   ├── hotels/
│   ├── visa_center/
│   ├── trips/
│   ├── trip_guardian/
│   ├── wallet_offline/
│   ├── airport_ar/
│   └── agency_dashboard/
└── main.dart`)}
              className="text-xs text-cyan-400 flex items-center gap-1 hover:underline"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Tree'}</span>
            </button>
          </div>

          <pre className="p-4 rounded-2xl bg-[#040714] border border-slate-800 text-cyan-300 font-mono text-[11px] overflow-x-auto leading-relaxed">
{`taki_go_mobile/
├── android/               # Native Android configurations & Gradle
├── ios/                   # Native iOS configurations & Podfile
├── assets/
│   ├── icons/             # Custom SVG icons & brand vector assets
│   ├── images/            # High-res travel & destination photography
│   └── 3d_models/         # GLTF/GLB models for 3D Globe & AR Wayfinding
├── lib/
│   ├── core/
│   │   ├── constants/     # API routes, asset paths, currency exchange constants
│   │   ├── localization/  # Arabic (ar.json), French (fr.json), English (en.json)
│   │   ├── network/       # Dio HTTP client, offline interceptors, retry policies
│   │   ├── security/      # AES-256 local encryption, Biometrics, SecureStorage
│   │   ├── theme/         # Dark Navy (#050814), Electric Blue (#0066FF), Cyan (#00F0FF)
│   │   └── widgets/       # GlassContainer, NeonButton, HologramCard, AppAvatar
│   ├── features/
│   │   ├── auth/          # Presentation (Login/Signup), Domain, Data (Hive Session)
│   │   ├── home/          # Top user bar, 3D Globe controller, services matrix
│   │   ├── ai_assistant/  # Speech-to-Text, Local Rule-Engine NLP, Itinerary Builder
│   │   ├── explore/       # Interactive 3D World Globe, Continents, City guides
│   │   ├── flights/       # Search form, cabin selector, flight card results, ticket flow
│   │   ├── hotels/        # Resort cards, room picker, photo galleries, vouchers
│   │   ├── visa_center/   # Visa guides, checklist validator, VFS appointment tracker
│   │   ├── trips/         # Active dossier, timeline itinerary, past journeys
│   │   ├── guardian/      # Smart Trip Guardian, live radar, gate countdown, weather
│   │   ├── wallet/        # Boarding passes, encrypted offline cache, QR generator
│   │   ├── airport_ar/    # Camera HUD simulation, ARKit/ARCore sensor integration
│   │   └── agency_admin/  # Tourism By Taki Backoffice, Client Manager, DEVIS Generator
│   └── main.dart          # Entry point with BlocProviders, Theme, and Locale bootstrap`}
          </pre>
        </div>
      )}

      {/* 3. DATABASE SCHEMA */}
      {activeSection === 'schema' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-cyan-400" />
            <span>Relational & Offline Database Schema (SQLite & Hive)</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800">
              <span className="font-mono text-cyan-400 font-bold block mb-1">TABLE users</span>
              <p className="text-[11px] text-slate-300 font-mono">
                id (PK, UUID), full_name, email, phone, passport_number, nationality, role ('client' | 'agency_admin'), language, currency, created_at
              </p>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800">
              <span className="font-mono text-cyan-400 font-bold block mb-1">TABLE trips</span>
              <p className="text-[11px] text-slate-300 font-mono">
                id (PK), user_id (FK), destination_city, destination_country, start_date, end_date, status ('upcoming' | 'completed'), flight_id, hotel_id
              </p>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800">
              <span className="font-mono text-cyan-400 font-bold block mb-1">TABLE wallet_documents</span>
              <p className="text-[11px] text-slate-300 font-mono">
                id (PK), user_id (FK), trip_id (FK), title, category ('ticket' | 'boarding_pass' | 'voucher' | 'visa'), qr_payload, encrypted_blob, is_offline_cached
              </p>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800">
              <span className="font-mono text-cyan-400 font-bold block mb-1">TABLE devis_quotations</span>
              <p className="text-[11px] text-slate-300 font-mono">
                id (PK), devis_number, client_id (FK), client_name, destination, subtotal_dzd, agency_fee_dzd, vat_percent, total_dzd, status, pdf_path
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 4 & 5. FLOWS */}
      {activeSection === 'flows' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <GitFork className="w-5 h-5 text-cyan-400" />
            <span>User & Agency Operations Flows</span>
          </h2>

          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800 space-y-2">
              <p className="font-bold text-cyan-300">مسار العميل والمسافر (Client Flow):</p>
              <p className="text-slate-300 leading-relaxed">
                1. فتح التطبيق ← Splash Screen بـ 3D Globe وطائرة متحركة ← Onboarding (4 شاشات تفاعلية).
                <br />
                2. الصفحة الرئيسية ← استكشاف الوجهات أو البحث عن طيران وفنادق أو التحدث مع المساعد الذكي AI.
                <br />
                3. اختيار الرحلة ← تأكيد الحجز وإصدار التذكرة الفورية في قسم "محفظتي".
                <br />
                4. يوم السفر ← تفعيل Smart Trip Guardian لمتابعة البوابة (Gate 16) والعد التنازلي للصعود، ثم تشغيل Airport AR للتوجيه داخل المطار.
              </p>
            </div>

            <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800 space-y-2">
              <p className="font-bold text-cyan-300">مسار الوكالة وإدارة السياحة (Admin Flow):</p>
              <p className="text-slate-300 leading-relaxed">
                1. الدخول عبر صلاحية Agency Admin ← فتح لوحة تحكم Tourism By Taki.
                <br />
                2. إدارة العملاء ← إضافة عميل، تسجيل رقم جواز السفر، وتصنيف عملاء VIP.
                <br />
                3. نظام Devis ← إنشاء عرض سعر احترافي (DEVIS – TOURISME BY TAKI) مع احتساب الرسوم والضرائب، وتصديره أو مشاركته عبر واتساب.
                <br />
                4. إرسال الإشعارات ← بث تنبيهات push مباشرة لهواتف العملاء بإشعار جاهزية الوثائق.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 6. SCREEN MAP */}
      {activeSection === 'screens' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4 text-xs">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            <span>Application Screen Map & Routing</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { route: '/', name: 'Splash Screen', desc: 'شاشة البداية المتحركة بهوية Tourism By Taki' },
              { route: '/onboarding', name: 'Onboarding Carousel', desc: '4 خطوات تقديمية لاكتشاف ميزات التطبيق' },
              { route: '/home', name: 'Home View', desc: 'الرئيسية مع 3D Globe، البحث الذكي، والخدمات' },
              { route: '/ai-assistant', name: 'AI Travel Companion', desc: 'المساعد الذكي الصوتي وتصميم البرامج' },
              { route: '/explore', name: 'Explore World', desc: 'الكرة الأرضية التفاعلية وأدلة المدن' },
              { route: '/flights', name: 'Flight Consolidator', desc: 'البحث عن الرحلات والدرجات والأسعار' },
              { route: '/hotels', name: 'Hotels & Resorts', desc: 'حجز الفنادق الفاخرة والقسائم' },
              { route: '/visa-center', name: 'Visa Dossier Center', desc: 'تأشيرات 8 دول ومتطلبات الملفات' },
              { route: '/trips', name: 'My Trips & Timeline', desc: 'متابعة الرحلة الحالية والجدول الزمني' },
              { route: '/wallet', name: 'Travel Wallet (Offline)', desc: 'تذاكر الطيران، كود QR، وقسائم الإقامة' },
              { route: '/airport-ar', name: 'Airport AR Wayfinder', desc: 'الملاحة المكانية داخل صالات المطار' },
              { route: '/agency-dashboard', name: 'Agency Console', desc: 'إدارة العملاء، Devis، وبث الإشعارات' },
            ].map((s, i) => (
              <div key={i} className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800">
                <span className="font-mono text-cyan-400 font-bold text-[10px]">{s.route}</span>
                <p className="font-bold text-white text-xs mt-0.5">{s.name}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. UI DESIGN SYSTEM */}
      {activeSection === 'design' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4 text-xs">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Palette className="w-5 h-5 text-cyan-400" />
            <span>UI Design System & Visual Identity</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-2xl bg-[#050814] border border-slate-800">
              <span className="w-full h-8 rounded-lg bg-[#050814] border border-cyan-500/20 block mb-2" />
              <p className="font-bold text-white">Dark Navy Space</p>
              <p className="font-mono text-slate-400 text-[10px]">#050814</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="w-full h-8 rounded-lg bg-[#0066ff] block mb-2 shadow-[0_0_15px_#0066ff]" />
              <p className="font-bold text-white">Electric Blue</p>
              <p className="font-mono text-slate-400 text-[10px]">#0066FF</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="w-full h-8 rounded-lg bg-[#00f0ff] block mb-2 shadow-[0_0_15px_#00f0ff]" />
              <p className="font-bold text-white">Cyan Neon</p>
              <p className="font-mono text-slate-400 text-[10px]">#00F0FF</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="w-full h-8 rounded-lg bg-emerald-400 block mb-2 shadow-[0_0_15px_#34d399]" />
              <p className="font-bold text-white">Emerald Guardian</p>
              <p className="font-mono text-slate-400 text-[10px]">#34D399</p>
            </div>
          </div>
        </div>
      )}

      {/* 8. FLUTTER SOURCE CODE EXPORT */}
      {activeSection === 'flutter_code' && (
        <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              <span>Production Flutter `main.dart` & State Architecture</span>
            </h2>
            <button
              onClick={() => handleCopyCode(`// Flutter Production Entry point for TAKI-GO
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TakiGoApp());
}

class TakiGoApp extends StatelessWidget {
  const TakiGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TAKI-GO | Tourism By Taki',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF050814),
        primaryColor: const Color(0xFF0066FF),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0066FF),
          secondary: Color(0xFF00F0FF),
          surface: Color(0xFF0D152F),
        ),
      ),
      supportedLocales: const [
        Locale('ar'),
        Locale('fr'),
        Locale('en'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
    );
  }
}`)}
              className="text-xs text-cyan-400 flex items-center gap-1 hover:underline"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Flutter Code'}</span>
            </button>
          </div>

          <pre className="p-4 rounded-2xl bg-[#040714] border border-slate-800 text-cyan-300 font-mono text-[11px] overflow-x-auto leading-relaxed">
{`// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Local Hive DB & Secure Storage
  // await Hive.initFlutter();
  runApp(const TakiGoApp());
}

class TakiGoApp extends StatelessWidget {
  const TakiGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TAKI-GO | Tourism By Taki',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF050814),
        primaryColor: const Color(0xFF0066FF),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0066FF),
          secondary: Color(0xFF00F0FF),
          surface: Color(0xFF0D152F),
        ),
      ),
      supportedLocales: const [
        Locale('ar'),
        Locale('fr'),
        Locale('en'),
      ],
      home: const SplashScreen(),
    );
  }
}`}
          </pre>
        </div>
      )}
    </div>
  );
}
