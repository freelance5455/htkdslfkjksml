import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { Kingdom } from '../types/kingdom';
import { getKingdomPopulationHistory } from '../game/gameConfig';
import { TrendingUp, Users, Shield, Home, Calendar, Zap } from 'lucide-react';

interface PopulationHistoryChartProps {
  kingdom: Kingdom;
}

type ChartMetric = 'capacity' | 'breakdown' | 'growth';
type TimeRange = 6 | 12;

export const PopulationHistoryChart: React.FC<PopulationHistoryChartProps> = ({ kingdom }) => {
  const [timeRange, setTimeRange] = useState<TimeRange>(6);
  const [selectedMetric, setSelectedMetric] = useState<ChartMetric>('capacity');

  const historyData = useMemo(() => {
    return getKingdomPopulationHistory(kingdom, timeRange);
  }, [kingdom, timeRange]);

  const initialPoint = historyData[0] || { population: 0 };
  const currentPoint = historyData[historyData.length - 1] || { population: 0 };
  const popGrowth = Math.max(0, currentPoint.population - initialPoint.population);
  const popGrowthPct = initialPoint.population > 0
    ? Math.round((popGrowth / initialPoint.population) * 100)
    : 100;

  return (
    <div className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800/90 shadow-inner">
      {/* Chart Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-950/60 border border-amber-800/60 text-amber-400">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold font-serif text-stone-200 flex items-center gap-1.5">
              <span>Registro Histórico Poblacional</span>
              <span className="text-[10px] font-sans font-normal text-amber-400/80 bg-amber-950/40 border border-amber-800/40 px-1.5 py-0.2 rounded-md">
                Crónica Feudal
              </span>
            </h4>
            <p className="text-[10px] text-stone-400">
              Evolución y censos demográficos registrados mes a mes
            </p>
          </div>
        </div>

        {/* View Switchers */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Metric Selector */}
          <div className="flex bg-stone-900 border border-stone-800 p-0.5 rounded-xl text-[10px] font-medium">
            <button
              type="button"
              onClick={() => setSelectedMetric('capacity')}
              className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                selectedMetric === 'capacity'
                  ? 'bg-amber-600 text-stone-950 font-bold shadow'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
              title="Comparar Población con el Límite de Vivienda"
            >
              <Home className="w-3 h-3" />
              <span className="hidden sm:inline">Población /</span> Capacidad
            </button>
            <button
              type="button"
              onClick={() => setSelectedMetric('breakdown')}
              className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                selectedMetric === 'breakdown'
                  ? 'bg-emerald-600 text-stone-950 font-bold shadow'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
              title="Ver proporción de Civiles Libres frente a Soldados"
            >
              <Shield className="w-3 h-3" />
              <span>Civiles / Tropas</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedMetric('growth')}
              className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                selectedMetric === 'growth'
                  ? 'bg-blue-600 text-stone-950 font-bold shadow'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
              title="Tasa de natalidad e inmigración (+hab/h)"
            >
              <Zap className="w-3 h-3" />
              <span>Ritmo (+hab/h)</span>
            </button>
          </div>

          {/* Time Range Selector */}
          <div className="flex bg-stone-900 border border-stone-800 p-0.5 rounded-xl text-[10px] font-medium">
            <button
              type="button"
              onClick={() => setTimeRange(6)}
              className={`px-2 py-1 rounded-lg transition cursor-pointer ${
                timeRange === 6
                  ? 'bg-stone-700 text-stone-100 font-bold shadow'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              6M
            </button>
            <button
              type="button"
              onClick={() => setTimeRange(12)}
              className={`px-2 py-1 rounded-lg transition cursor-pointer ${
                timeRange === 12
                  ? 'bg-stone-700 text-stone-100 font-bold shadow'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              12M
            </button>
          </div>
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="w-full h-[220px] min-h-[220px] relative">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={historyData}
            margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
          >
            <defs>
              {/* Gradients */}
              <linearGradient id="popFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.45} />
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="capFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#78716c" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#78716c" stopOpacity={0.01} />
              </linearGradient>
              <linearGradient id="recFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.45} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="milFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.45} />
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="growthFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.50} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.03} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" stroke="#292524" vertical={false} />

            <XAxis
              dataKey="month"
              stroke="#57534e"
              tick={{ fill: '#a8a29e', fontSize: 10 }}
              tickLine={false}
              dy={5}
            />

            <YAxis
              stroke="#57534e"
              tick={{ fill: '#a8a29e', fontSize: 10 }}
              tickLine={false}
              dx={-2}
            />

            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-stone-950/95 border border-stone-800 rounded-2xl p-3 shadow-2xl backdrop-blur-md text-xs min-w-[210px]">
                      <div className="font-serif font-bold text-stone-200 border-b border-stone-800 pb-1.5 mb-2 flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-stone-100">
                          <Calendar className="w-3.5 h-3.5 text-amber-400" />
                          {label}
                        </span>
                        <span className="text-[10px] text-amber-400/90 font-mono">
                          Año 1085
                        </span>
                      </div>

                      <div className="space-y-1.5 font-mono text-[11px]">
                        <div className="flex items-center justify-between gap-3 text-amber-400">
                          <span className="flex items-center gap-1.5 text-stone-300 font-sans">
                            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                            Población Total:
                          </span>
                          <span className="font-bold">{data.population.toLocaleString()} habs</span>
                        </div>

                        <div className="flex items-center justify-between gap-3 text-stone-400">
                          <span className="flex items-center gap-1.5 text-stone-300 font-sans">
                            <span className="w-2 h-2 rounded-full bg-stone-400 shrink-0" />
                            Capacidad Máx:
                          </span>
                          <span className="font-bold text-stone-300">{data.capacity.toLocaleString()} plazas</span>
                        </div>

                        <div className="flex items-center justify-between gap-3 text-emerald-400">
                          <span className="flex items-center gap-1.5 text-stone-300 font-sans">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                            Aldeanos Libres:
                          </span>
                          <span className="font-bold">{data.recruits.toLocaleString()}</span>
                        </div>

                        <div className="flex items-center justify-between gap-3 text-red-400">
                          <span className="flex items-center gap-1.5 text-stone-300 font-sans">
                            <span className="w-2 h-2 rounded-full bg-red-400 shrink-0" />
                            Guerreros en Armas:
                          </span>
                          <span className="font-bold">{data.military.toLocaleString()}</span>
                        </div>

                        <div className="flex items-center justify-between gap-3 text-blue-400 pt-1.5 border-t border-stone-800 text-[10px]">
                          <span className="flex items-center gap-1.5 text-stone-400 font-sans">
                            <Zap className="w-3 h-3 text-blue-400 shrink-0" />
                            Ritmo demográfico:
                          </span>
                          <span className="font-bold">+{data.growthRate}/h</span>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              }}
            />

            {selectedMetric === 'capacity' && (
              <>
                <Area
                  type="monotone"
                  dataKey="capacity"
                  name="Capacidad Habitacional"
                  stroke="#78716c"
                  strokeDasharray="4 4"
                  strokeWidth={2}
                  fill="url(#capFill)"
                />
                <Area
                  type="monotone"
                  dataKey="population"
                  name="Población Habitante"
                  stroke="#f59e0b"
                  strokeWidth={2.5}
                  fill="url(#popFill)"
                  activeDot={{ r: 5, fill: '#f59e0b', stroke: '#1c1917', strokeWidth: 2 }}
                />
              </>
            )}

            {selectedMetric === 'breakdown' && (
              <>
                <Area
                  type="monotone"
                  dataKey="recruits"
                  name="Aldeanos Libres"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#recFill)"
                  activeDot={{ r: 4, fill: '#10b981' }}
                />
                <Area
                  type="monotone"
                  dataKey="military"
                  name="Ejército en Armas"
                  stroke="#ef4444"
                  strokeWidth={2}
                  fill="url(#milFill)"
                  activeDot={{ r: 4, fill: '#ef4444' }}
                />
              </>
            )}

            {selectedMetric === 'growth' && (
              <Area
                type="monotone"
                dataKey="growthRate"
                name="Tasa de Crecimiento (+hab/h)"
                stroke="#3b82f6"
                strokeWidth={2.5}
                fill="url(#growthFill)"
                activeDot={{ r: 5, fill: '#3b82f6', stroke: '#1c1917', strokeWidth: 2 }}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Stats Summary Strip */}
      <div className="mt-3 pt-3 border-t border-stone-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
        <div className="p-2 rounded-xl bg-stone-900/60 border border-stone-850">
          <div className="text-[10px] text-stone-400">Población Inicial</div>
          <div className="font-mono font-bold text-stone-200">
            {initialPoint.population} <span className="text-[9px] text-stone-500 font-sans">almas</span>
          </div>
        </div>

        <div className="p-2 rounded-xl bg-stone-900/60 border border-stone-850">
          <div className="text-[10px] text-stone-400">Censo Actual</div>
          <div className="font-mono font-bold text-amber-400">
            {currentPoint.population} <span className="text-[9px] text-stone-500 font-sans">almas</span>
          </div>
        </div>

        <div className="p-2 rounded-xl bg-stone-900/60 border border-stone-850">
          <div className="text-[10px] text-stone-400">Crecimiento Periodo</div>
          <div className="font-mono font-bold text-emerald-400 flex items-center gap-1">
            <span>+{popGrowth}</span>
            <span className="text-[10px] font-normal text-emerald-500/90">(+{popGrowthPct}%)</span>
          </div>
        </div>

        <div className="p-2 rounded-xl bg-stone-900/60 border border-stone-850">
          <div className="text-[10px] text-stone-400">Capacidad Techo</div>
          <div className="font-mono font-bold text-stone-300">
            {currentPoint.capacity} <span className="text-[9px] text-stone-500 font-sans">plazas</span>
          </div>
        </div>
      </div>
    </div>
  );
};
