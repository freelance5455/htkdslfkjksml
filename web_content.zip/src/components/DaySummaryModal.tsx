import React from 'react';
import {
  TrendingUp,
  DollarSign,
  Award,
  Calendar,
  ArrowRight,
  Sparkles,
  Tv,
} from 'lucide-react';
import { DayReport } from '../types/game';
import { soundFx } from '../utils/audio';

interface DaySummaryModalProps {
  report: DayReport;
  onProceedNextDay: () => void;
  stationName: string;
}

export const DaySummaryModal: React.FC<DaySummaryModalProps> = ({
  report,
  onProceedNextDay,
  stationName,
}) => {
  const isProfitable = report.netProfit >= 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 select-none">
      <div className="w-full max-w-sm sm:max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl flex flex-col gap-4 relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono font-bold text-amber-400 tracking-wider uppercase">
              ENCERRAMENTO DA TRANSMISSÃO DIÁRIA
            </div>
            <h2 className="text-2xl font-black text-white font-display mt-0.5">
              Boletim do Dia {report?.day || 1} · {report?.weekday || 'Hoje'}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Tv className="w-5 h-5" />
            </div>
            <button
              onClick={() => {
                soundFx.playClick();
                onProceedNextDay();
              }}
              className="text-slate-400 hover:text-white p-1 rounded-lg text-xs"
              title="Continuar para o próximo dia"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Audience Performance strip */}
        <div className="grid grid-cols-3 gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
          <div className="text-center">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">
              MÉDIA GERAL IBOPE
            </span>
            <span className="text-xl md:text-2xl font-black text-white font-mono tabular-nums">
              {report.avgIbope.toFixed(1)} <span className="text-xs text-amber-400">pts</span>
            </span>
          </div>

          <div className="text-center border-x border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">
              PICO DE AUDIÊNCIA
            </span>
            <span className="text-xl md:text-2xl font-black text-amber-400 font-mono tabular-nums">
              {report.peakIbope.toFixed(1)} <span className="text-xs text-amber-400">pts</span>
            </span>
          </div>

          <div className="text-center">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">
              POSIÇÃO NACIONAL
            </span>
            <span className="text-xl md:text-2xl font-black text-emerald-400 font-display">
              {report.ranking}º Lugar
            </span>
          </div>
        </div>

        {/* Financial Ledger Section */}
        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80 space-y-2.5 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span>Faturamento Bruto (Comerciais & Cotas):</span>
            <span className="font-mono font-bold text-emerald-400">
              + R$ {report.revenue.toLocaleString('pt-BR')}
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span>Custos Operacionais & Folha Salarial:</span>
            <span className="font-mono font-bold text-red-400">
              - R$ {report.expenses.toLocaleString('pt-BR')}
            </span>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-sm font-bold">
            <span className="text-white">Resultado Líquido do Dia:</span>
            <span
              className={`font-mono text-base ${
                isProfitable ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {isProfitable ? '+' : ''} R$ {report.netProfit.toLocaleString('pt-BR')}
            </span>
          </div>
        </div>

        {report.ranking === 1 && (
          <div className="p-3 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-200 text-xs font-semibold flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400 shrink-0" />
            <span>Parabéns! Sua emissora bateu todos os gigantes e fechou o dia na liderança absoluta!</span>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={() => {
            soundFx.playVictory();
            onProceedNextDay();
          }}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <span>Abrir Nova Grade · Iniciar Dia {report.day + 1}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
