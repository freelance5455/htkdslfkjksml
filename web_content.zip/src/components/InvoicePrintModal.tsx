import React, { useState, useEffect } from 'react';
import {
  Printer,
  X,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  Plus,
  Trash2,
  Building2,
  UserCheck,
  FileText,
  Eye,
  SlidersHorizontal,
  Check,
  Sparkles,
} from 'lucide-react';
import {
  type PrintableInvoiceConfig,
  type PrintableInvoiceLine,
  type PrintableInvoiceType,
  getSavedIssuerPresets,
  saveIssuerPreset,
  sortInvoiceLines,
  moveInvoiceLine,
  calculatePrintableTotals,
} from '../utils/invoicePrint.ts';
import { formatIQD, formatDateArabic } from '../utils/calculations.ts';

interface InvoicePrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialConfig: PrintableInvoiceConfig | null;
  knownSuppliers?: string[];
  knownBuyers?: string[];
  catalogMedicines?: Array<{ barcode: string; name: string; unitPrice?: number }>;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  isOpen,
  onClose,
  initialConfig,
  knownSuppliers = [],
  knownBuyers = [],
  catalogMedicines = [],
}) => {
  const [config, setConfig] = useState<PrintableInvoiceConfig>(() => {
    const presets = getSavedIssuerPresets();
    return (
      initialConfig || {
        invoiceNumber: `INV-${Date.now().toString().slice(-5)}`,
        invoiceType: 'sale',
        customTitle: 'فاتورة بيع وتجهيز أدوية',
        date: new Date().toISOString().split('T')[0],
        issuerName: presets[0] || 'مذخر التمشمش للأدوية',
        issuerSubtitle: 'لتجارة وتوزيع الأدوية والمستلزمات الطبية',
        issuerPhone: '',
        recipientLabel: 'معنون إلى الصيدلية / المذخر:',
        recipientName: '',
        recipientPhone: '',
        lines: [],
        amountPaid: 0,
        discountAmount: 0,
        notes: '',
        showPrices: true,
        showExpiry: true,
        showBarcode: false,
        showPaymentSummary: true,
        showSignatures: true,
      }
    );
  });

  const [issuerPresets, setIssuerPresets] = useState<string[]>(() => getSavedIssuerPresets());
  const [mobileStep, setMobileStep] = useState<'edit' | 'preview'>('edit');
  const [presetSavedToast, setPresetSavedToast] = useState(false);

  // Quick new line state
  const [newMedName, setNewMedName] = useState('');
  const [newMedQty, setNewMedQty] = useState('1');
  const [newMedPrice, setNewMedPrice] = useState('');
  const [newMedUnit, setNewMedUnit] = useState('باكيت');

  useEffect(() => {
    if (initialConfig) {
      setConfig(initialConfig);
      setMobileStep('edit');
    }
  }, [initialConfig]);

  if (!isOpen) return null;

  const totals = calculatePrintableTotals(
    config.lines,
    config.discountAmount,
    config.amountPaid
  );

  const allParties = Array.from(new Set([...knownBuyers, ...knownSuppliers])).filter(Boolean);

  const handleSetInvoiceType = (type: PrintableInvoiceType) => {
    if (type === 'sale') {
      setConfig((prev) => ({
        ...prev,
        invoiceType: 'sale',
        customTitle: 'فاتورة بيع وتجهيز أدوية',
        recipientLabel: 'معنون إلى الصيدلية / المذخر المشتري:',
      }));
    } else if (type === 'purchase') {
      setConfig((prev) => ({
        ...prev,
        invoiceType: 'purchase',
        customTitle: 'قائمة طلبية وشراء أدوية من مذخر',
        recipientLabel: 'معنون إلى المورد / المذخر المجهز:',
      }));
    } else {
      setConfig((prev) => ({
        ...prev,
        invoiceType: 'order',
        customTitle: 'طلبية تجهيز مواد دوائية',
        recipientLabel: 'معنون إلى السادة (مذخر / صيدلية):',
      }));
    }
  };

  const handleSaveIssuerPreset = () => {
    if (!config.issuerName.trim()) return;
    const updated = saveIssuerPreset(config.issuerName);
    setIssuerPresets(updated);
    setPresetSavedToast(true);
    setTimeout(() => setPresetSavedToast(false), 2000);
  };

  const handleMoveLine = (idx: number, dir: 'up' | 'down') => {
    setConfig((prev) => ({
      ...prev,
      lines: moveInvoiceLine(prev.lines, idx, dir),
    }));
  };

  const handleSortLines = (
    order: 'name_asc' | 'qty_desc' | 'price_desc' | 'expiry_asc'
  ) => {
    setConfig((prev) => ({
      ...prev,
      lines: sortInvoiceLines(prev.lines, order),
    }));
  };

  const handleUpdateLine = (
    id: string,
    field: keyof PrintableInvoiceLine,
    value: string | number
  ) => {
    setConfig((prev) => ({
      ...prev,
      lines: prev.lines.map((line) => {
        if (line.id !== id) return line;
        if (field === 'qty') {
          return { ...line, qty: Math.max(1, Number(value) || 1) };
        }
        if (field === 'unitPrice') {
          return { ...line, unitPrice: Math.max(0, Number(value) || 0) };
        }
        return { ...line, [field]: value };
      }),
    }));
  };

  const handleRemoveLine = (id: string) => {
    setConfig((prev) => ({
      ...prev,
      lines: prev.lines.filter((l) => l.id !== id),
    }));
  };

  const handleAddLine = () => {
    if (!newMedName.trim()) return;
    const matched = catalogMedicines.find(
      (m) => m.name.toLowerCase() === newMedName.trim().toLowerCase()
    );
    const newLine: PrintableInvoiceLine = {
      id: `pline_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      barcode: matched?.barcode || `629${Date.now().toString().slice(-6)}`,
      medicineName: newMedName.trim(),
      unit: newMedUnit || 'باكيت',
      qty: Math.max(1, parseInt(newMedQty, 10) || 1),
      unitPrice: Math.max(0, parseFloat(newMedPrice) || matched?.unitPrice || 0),
    };
    setConfig((prev) => {
      const nextLines = [...prev.lines, newLine];
      const nextSum = nextLines.reduce((s, l) => s + l.qty * l.unitPrice, 0);
      return {
        ...prev,
        lines: nextLines,
        amountPaid: prev.amountPaid === totals.subtotal ? nextSum : prev.amountPaid,
      };
    });
    setNewMedName('');
    setNewMedQty('1');
    setNewMedPrice('');
  };

  const handlePrintNow = () => {
    if (config.issuerName.trim()) {
      setIssuerPresets(saveIssuerPreset(config.issuerName));
    }
    setMobileStep('preview');
    setTimeout(() => {
      window.print();
    }, 120);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/75 backdrop-blur-xs p-0 sm:p-4 animate-fadeIn print:static print:bg-white print:p-0 print:block">
      <div className="bg-white w-full sm:max-w-5xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 max-h-[95vh] flex flex-col overflow-hidden print:max-h-none print:shadow-none print:border-none print:rounded-none">
        {/* Top Modal Header (Hidden in Print) */}
        <div className="bg-gradient-to-l from-slate-900 via-teal-950 to-slate-900 text-white px-4 sm:px-6 py-3.5 flex items-center justify-between gap-2 print:hidden shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-10 w-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
              <Printer className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-black truncate">
                ترتيب وتخصيص وطباعة الفاتورة / الطلبية
              </h2>
              <p className="text-[11px] text-teal-200/80 truncate">
                اختر بأي اسم تُطبع الفاتورة، حدد اسم المذخر أو الصيدلية، ورتب المواد قبل الطباعة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handlePrintNow}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 px-3.5 py-2 text-xs font-black shadow-sm transition active:scale-95"
            >
              <Printer className="h-4 w-4" />
              <span>طباعة / PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-white/10 hover:bg-white/20 p-2 text-white transition"
              aria-label="إغلاق نافذة الطباعة"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Mobile View Switcher: Customize vs Preview (Hidden on Desktop & Print) */}
        <div className="lg:hidden bg-slate-100 p-1.5 border-b border-slate-200 grid grid-cols-2 gap-1.5 shrink-0 print:hidden">
          <button
            type="button"
            onClick={() => setMobileStep('edit')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-black transition ${
              mobileStep === 'edit'
                ? 'bg-teal-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>1. الترتيب وتحديد الأسماء ({config.lines.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileStep('preview')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-black transition ${
              mobileStep === 'preview'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Eye className="h-3.5 w-3.5" />
            <span>2. معاينة شكل الطباعة</span>
          </button>
        </div>

        {/* Main Workspace: Split on Desktop, Tabbed on Mobile */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-200 print:block print:overflow-visible">
          {/* RIGHT COLUMN: Controls, Names & Item Arrangement (Hidden in Print) */}
          <div
            className={`lg:col-span-6 p-3.5 sm:p-5 space-y-4 overflow-y-auto bg-slate-50/60 print:hidden ${
              mobileStep === 'preview' ? 'hidden lg:block' : 'block'
            }`}
          >
            {/* Section 1: Choose Issuer Name (بأي اسم تطبع الفاتورة) */}
            <div className="rounded-2xl bg-white border border-slate-200 p-3.5 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-teal-950">
                  <UserCheck className="h-4 w-4 text-teal-700" />
                  <span>1. بأي اسم تريد طباعة الفاتورة؟ (اسمك / مذخرك / صيدليتك)</span>
                </div>
                <button
                  type="button"
                  onClick={handleSaveIssuerPreset}
                  className="text-[11px] font-bold text-teal-700 hover:text-teal-900 bg-teal-50 hover:bg-teal-100 px-2.5 py-1 rounded-lg border border-teal-200 transition flex items-center gap-1"
                >
                  {presetSavedToast ? (
                    <>
                      <Check className="h-3 w-3 text-emerald-600" />
                      <span>تم الحفظ</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-3 w-3" />
                      <span>حفظ كاسم جاهز</span>
                    </>
                  )}
                </button>
              </div>

              {/* Saved Issuer Quick Presets */}
              <div className="flex flex-wrap gap-1.5">
                {issuerPresets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setConfig((prev) => ({ ...prev, issuerName: preset }))}
                    className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition ${
                      config.issuerName === preset
                        ? 'bg-teal-900 text-white border-teal-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    الاسم الرئيسي في ترويسة الفاتورة المطبوعة *
                  </label>
                  <input
                    type="text"
                    value={config.issuerName}
                    onChange={(e) => setConfig((prev) => ({ ...prev, issuerName: e.target.value }))}
                    placeholder="اكتب الاسم الذي تريد ظهور الفاتورة به (مثال: مذخر النور / صيدلية الأمل)..."
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-teal-600 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    وصف الترويسة / العنوان الفرعي
                  </label>
                  <input
                    type="text"
                    value={config.issuerSubtitle}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, issuerSubtitle: e.target.value }))
                    }
                    placeholder="مثال: لتجارة الأدوية والمستلزمات الطبية"
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    رقم الهاتف / العنوان (اختياري)
                  </label>
                  <input
                    type="text"
                    value={config.issuerPhone}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, issuerPhone: e.target.value }))
                    }
                    placeholder="مثال: بغداد - السعدون | 07700000000"
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Specify Target Supplier / Pharmacy / Warehouse */}
            <div className="rounded-2xl bg-white border border-slate-200 p-3.5 space-y-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-black text-indigo-950">
                <Building2 className="h-4 w-4 text-indigo-700" />
                <span>2. تحديد نوع الفاتورة واسم المورد / المذخر / الصيدلية</span>
              </div>

              {/* Invoice Type Switcher */}
              <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => handleSetInvoiceType('sale')}
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-black transition ${
                    config.invoiceType === 'sale'
                      ? 'bg-indigo-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  فاتورة بيع لصيدلية/مذخر
                </button>
                <button
                  type="button"
                  onClick={() => handleSetInvoiceType('purchase')}
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-black transition ${
                    config.invoiceType === 'purchase'
                      ? 'bg-teal-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  طلبية شراء من مورد
                </button>
                <button
                  type="button"
                  onClick={() => handleSetInvoiceType('order')}
                  className={`py-1.5 px-2 rounded-lg text-[11px] font-black transition ${
                    config.invoiceType === 'order'
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  طلبية تجهيز / عرض سعر
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                <div className="sm:col-span-7">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    اسم المورد / المذخر / الصيدلية (الجهة المعنون إليها) *
                  </label>
                  <input
                    type="text"
                    list="print-parties-list"
                    value={config.recipientName}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, recipientName: e.target.value }))
                    }
                    placeholder="اكتب أو اختر اسم المذخر أو الصيدلية..."
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                  />
                  <datalist id="print-parties-list">
                    {allParties.map((p) => (
                      <option key={p} value={p} />
                    ))}
                  </datalist>
                </div>

                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    تاريخ القائمة
                  </label>
                  <input
                    type="date"
                    value={config.date}
                    onChange={(e) => setConfig((prev) => ({ ...prev, date: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-900 focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>

                <div className="sm:col-span-7">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    عنوان القائمة المطبوع
                  </label>
                  <input
                    type="text"
                    value={config.customTitle}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, customTitle: e.target.value }))
                    }
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>

                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    رقم الفاتورة / الطلبية
                  </label>
                  <input
                    type="text"
                    value={config.invoiceNumber}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, invoiceNumber: e.target.value }))
                    }
                    className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-mono font-bold text-slate-800 focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Arrange, Sort & Edit Invoice Items */}
            <div className="rounded-2xl bg-white border border-slate-200 p-3.5 space-y-3 shadow-2xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-slate-900">
                  <ArrowUpDown className="h-4 w-4 text-teal-700" />
                  <span>3. ترتيب وتعديل مواد الفاتورة ({config.lines.length} مواد)</span>
                </div>

                {/* Quick Sort Buttons */}
                <div className="flex flex-wrap items-center gap-1">
                  <span className="text-[10px] font-bold text-slate-400 ml-1">ترتيب سريع:</span>
                  <button
                    type="button"
                    onClick={() => handleSortLines('name_asc')}
                    className="rounded-lg bg-slate-100 hover:bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-700 transition"
                  >
                    أبجدي (أ-ي)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSortLines('qty_desc')}
                    className="rounded-lg bg-slate-100 hover:bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-700 transition"
                  >
                    الأكثر كمية
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSortLines('price_desc')}
                    className="rounded-lg bg-slate-100 hover:bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-700 transition"
                  >
                    الأعلى قيمة
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSortLines('expiry_asc')}
                    className="rounded-lg bg-slate-100 hover:bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-700 transition"
                  >
                    الأقرب صلاحية
                  </button>
                </div>
              </div>

              {/* Items List with Up/Down Reordering & Inline Editing */}
              {config.lines.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-xs text-slate-400">
                  لا توجد مواد في الفاتورة حالياً. أضف مادة من الحقل أدناه.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl max-h-64 overflow-y-auto">
                  {config.lines.map((line, index) => (
                    <div
                      key={line.id}
                      className="p-2.5 bg-white hover:bg-slate-50/80 transition space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex items-center gap-1 shrink-0">
                          <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-slate-900 text-white text-[10px] font-black">
                            {index + 1}
                          </span>
                          <button
                            type="button"
                            disabled={index === 0}
                            onClick={() => handleMoveLine(index, 'up')}
                            className="p-1 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                            title="تحريك للأعلى"
                            aria-label={`تحريك ${line.medicineName} للأعلى`}
                          >
                            <ArrowUp className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            disabled={index === config.lines.length - 1}
                            onClick={() => handleMoveLine(index, 'down')}
                            className="p-1 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                            title="تحريك للأسفل"
                            aria-label={`تحريك ${line.medicineName} للأسفل`}
                          >
                            <ArrowDown className="h-3 w-3" />
                          </button>
                        </div>

                        <input
                          type="text"
                          value={line.medicineName}
                          onChange={(e) =>
                            handleUpdateLine(line.id, 'medicineName', e.target.value)
                          }
                          className="flex-1 min-w-0 rounded-lg border border-slate-200 px-2 py-1 text-xs font-black text-slate-900 focus:border-teal-600 focus:outline-hidden"
                        />

                        <button
                          type="button"
                          onClick={() => handleRemoveLine(line.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                          title="حذف السطر"
                          aria-label={`حذف ${line.medicineName}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-12 gap-1.5 items-center">
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-400">الكمية</label>
                          <input
                            type="number"
                            min="1"
                            value={line.qty}
                            onChange={(e) => handleUpdateLine(line.id, 'qty', e.target.value)}
                            className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-black"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-400">الوحدة</label>
                          <input
                            type="text"
                            value={line.unit}
                            onChange={(e) => handleUpdateLine(line.id, 'unit', e.target.value)}
                            className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-bold"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-400">سعر المفرد</label>
                          <input
                            type="number"
                            min="0"
                            value={line.unitPrice}
                            onChange={(e) =>
                              handleUpdateLine(line.id, 'unitPrice', e.target.value)
                            }
                            className="w-full rounded-lg border border-slate-200 px-2 py-1 text-center text-xs font-black"
                          />
                        </div>
                        <div className="col-span-3 text-left">
                          <label className="block text-[10px] text-slate-400">الإجمالي</label>
                          <div className="font-mono text-xs font-black text-teal-900 py-1">
                            {formatIQD(line.qty * line.unitPrice)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick Add Extra Item to Invoice */}
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-2.5 space-y-2">
                <div className="text-[11px] font-bold text-slate-700">
                  إضافة مادة إضافية إلى الفاتورة / الطلبية:
                </div>
                <div className="grid grid-cols-12 gap-1.5">
                  <input
                    type="text"
                    list="print-catalog-meds"
                    value={newMedName}
                    onChange={(e) => setNewMedName(e.target.value)}
                    placeholder="اسم الدواء / المادة..."
                    className="col-span-5 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold"
                  />
                  <datalist id="print-catalog-meds">
                    {catalogMedicines.map((m) => (
                      <option key={m.barcode} value={m.name} />
                    ))}
                  </datalist>
                  <input
                    type="number"
                    min="1"
                    value={newMedQty}
                    onChange={(e) => setNewMedQty(e.target.value)}
                    placeholder="العدد"
                    className="col-span-2 rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-center text-xs font-bold"
                  />
                  <input
                    type="number"
                    min="0"
                    value={newMedPrice}
                    onChange={(e) => setNewMedPrice(e.target.value)}
                    placeholder="السعر"
                    className="col-span-3 rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-center text-xs font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleAddLine}
                    className="col-span-2 flex items-center justify-center rounded-lg bg-teal-800 hover:bg-teal-900 text-white text-xs font-black transition"
                    title="إضافة السطر"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Section 4: Display Options & Payment Details */}
            <div className="rounded-2xl bg-white border border-slate-200 p-3.5 space-y-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-black text-slate-900">
                <FileText className="h-4 w-4 text-teal-700" />
                <span>4. خيارات الطباعة والخصم والتسديد</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.showPrices}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, showPrices: e.target.checked }))
                    }
                    className="rounded text-teal-700 focus:ring-teal-600"
                  />
                  <span className="font-bold text-slate-700">إظهار الأسعار والمجموع</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.showExpiry}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, showExpiry: e.target.checked }))
                    }
                    className="rounded text-teal-700 focus:ring-teal-600"
                  />
                  <span className="font-bold text-slate-700">إظهار تاريخ الصلاحية</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.showPaymentSummary}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, showPaymentSummary: e.target.checked }))
                    }
                    className="rounded text-teal-700 focus:ring-teal-600"
                  />
                  <span className="font-bold text-slate-700">إظهار الواصل والباقي</span>
                </label>

                <label className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.showSignatures}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, showSignatures: e.target.checked }))
                    }
                    className="rounded text-teal-700 focus:ring-teal-600"
                  />
                  <span className="font-bold text-slate-700">إظهار خانات التوقيع</span>
                </label>
              </div>

              {config.showPrices && (
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      مبلغ الخصم (د.ع)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={config.discountAmount || ''}
                      onChange={(e) =>
                        setConfig((prev) => ({
                          ...prev,
                          discountAmount: Math.max(0, Number(e.target.value) || 0),
                        }))
                      }
                      placeholder="0"
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      المبلغ الواصل / المدفوع (د.ع)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={config.amountPaid}
                      onChange={(e) =>
                        setConfig((prev) => ({
                          ...prev,
                          amountPaid: Math.max(0, Number(e.target.value) || 0),
                        }))
                      }
                      className="w-full rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  ملاحظات أسفل الفاتورة (اختياري)
                </label>
                <input
                  type="text"
                  value={config.notes}
                  onChange={(e) => setConfig((prev) => ({ ...prev, notes: e.target.value }))}
                  placeholder="مثال: البضاعة مفحوصة ومكفولة الصلاحية..."
                  className="w-full rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* LEFT COLUMN: Live Printable Invoice Sheet Preview */}
          <div
            className={`lg:col-span-6 p-3.5 sm:p-6 bg-slate-200/70 overflow-y-auto print:block print:p-0 print:bg-white ${
              mobileStep === 'edit' ? 'hidden lg:block' : 'block'
            }`}
          >
            <div
              id="printable-invoice-sheet"
              className="bg-white rounded-2xl border border-slate-300 shadow-md p-5 sm:p-7 mx-auto max-w-2xl text-slate-900 space-y-5 print:shadow-none print:border-none print:rounded-none print:p-2 print:max-w-none"
            >
              {/* Invoice Header Banner */}
              <div className="border-b-2 border-slate-900 pb-4 flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <h1 className="text-lg sm:text-xl font-black text-slate-950 tracking-tight">
                    {config.issuerName || 'مذخر التمشمش للأدوية'}
                  </h1>
                  {config.issuerSubtitle && (
                    <p className="text-xs font-bold text-slate-600 mt-0.5">
                      {config.issuerSubtitle}
                    </p>
                  )}
                  {config.issuerPhone && (
                    <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                      {config.issuerPhone}
                    </p>
                  )}
                </div>

                <div className="sm:text-left bg-slate-100 px-3.5 py-2 rounded-xl border border-slate-300">
                  <div className="text-xs sm:text-sm font-black text-slate-950">
                    {config.customTitle || 'فاتورة رسمية'}
                  </div>
                  <div className="text-[11px] text-slate-600 mt-1 flex sm:justify-end items-center gap-3 font-mono">
                    <span>العدد: {config.invoiceNumber}</span>
                    <span>•</span>
                    <span>التاريخ: {formatDateArabic(config.date)}</span>
                  </div>
                </div>
              </div>

              {/* Recipient / Supplier / Pharmacy Box */}
              <div className="rounded-xl bg-slate-50 border border-slate-300 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs sm:text-sm">
                  <span className="font-bold text-slate-600 ml-1.5">{config.recipientLabel}</span>
                  <strong className="font-black text-slate-950 text-sm sm:text-base">
                    {config.recipientName || '................................................'}
                  </strong>
                </div>
                <div className="text-xs font-bold text-slate-600">
                  إجمالي المواد: <strong className="text-slate-950">{config.lines.length}</strong> (الكمية الكلية: <strong className="text-slate-950">{totals.totalQty}</strong>)
                </div>
              </div>

              {/* Organized Invoice Table */}
              <div className="overflow-x-auto border border-slate-300 rounded-xl">
                <table className="w-full text-right border-collapse text-[11px] sm:text-xs">
                  <thead>
                    <tr className="bg-slate-900 text-white font-black">
                      <th className="py-2 px-1.5 sm:py-2.5 sm:px-2.5 border-l border-slate-700 w-7 sm:w-9 text-center">
                        ت
                      </th>
                      <th className="py-2 px-2 sm:py-2.5 sm:px-3 border-l border-slate-700">
                        اسم المادة / الدواء
                      </th>
                      <th className="hidden sm:table-cell py-2.5 px-2.5 border-l border-slate-700 text-center w-16 print:table-cell">
                        الوحدة
                      </th>
                      <th className="py-2 px-1.5 sm:py-2.5 sm:px-2.5 border-l border-slate-700 text-center w-14 sm:w-16">
                        الكمية
                      </th>
                      {config.showExpiry && (
                        <th className="py-2 px-1.5 sm:py-2.5 sm:px-2.5 border-l border-slate-700 text-center w-20 sm:w-24">
                          الصلاحية
                        </th>
                      )}
                      {config.showPrices && (
                        <>
                          <th className="py-2 px-1.5 sm:py-2.5 sm:px-2.5 border-l border-slate-700 text-center w-16 sm:w-24">
                            المفرد
                          </th>
                          <th className="py-2 px-2 sm:py-2.5 sm:px-3 text-left w-20 sm:w-28">
                            الإجمالي
                          </th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {config.lines.map((line, idx) => (
                      <tr key={line.id} className="odd:bg-white even:bg-slate-50/70">
                        <td className="py-1.5 px-1.5 sm:py-2 sm:px-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-600">
                          {idx + 1}
                        </td>
                        <td className="py-1.5 px-2 sm:py-2 sm:px-3 border-l border-slate-200 font-black text-slate-900">
                          <div>{line.medicineName}</div>
                          {config.showBarcode && line.barcode && (
                            <div className="text-[10px] font-mono text-slate-500">
                              {line.barcode}
                            </div>
                          )}
                        </td>
                        <td className="hidden sm:table-cell py-2 px-2.5 border-l border-slate-200 text-center font-bold text-slate-700 print:table-cell">
                          {line.unit}
                        </td>
                        <td className="py-1.5 px-1.5 sm:py-2 sm:px-2.5 border-l border-slate-200 text-center font-mono font-black text-slate-950">
                          <span>{line.qty}</span>
                          <span className="block sm:hidden print:hidden text-[9px] font-sans font-bold text-slate-500">
                            {line.unit}
                          </span>
                        </td>
                        {config.showExpiry && (
                          <td className="py-1.5 px-1.5 sm:py-2 sm:px-2.5 border-l border-slate-200 text-center font-mono text-[10px] sm:text-[11px] text-slate-700">
                            {line.expiryDate ? formatDateArabic(line.expiryDate) : '—'}
                          </td>
                        )}
                        {config.showPrices && (
                          <>
                            <td className="py-1.5 px-1.5 sm:py-2 sm:px-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-800">
                              {line.unitPrice.toLocaleString('en-US')}
                            </td>
                            <td className="py-1.5 px-2 sm:py-2 sm:px-3 text-left font-mono font-black text-slate-950">
                              {(line.qty * line.unitPrice).toLocaleString('en-US')}
                            </td>
                          </>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Financial Summary & Notes */}
              {config.showPrices && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="space-y-1.5 text-xs">
                    {config.notes && (
                      <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
                        <span className="font-bold text-slate-600 block mb-0.5">ملاحظات:</span>
                        <p className="text-slate-800 font-semibold">{config.notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="rounded-xl border-2 border-slate-900 p-3.5 space-y-2 text-xs bg-slate-50/60">
                    {totals.discount > 0 && (
                      <>
                        <div className="flex items-center justify-between text-slate-600">
                          <span>المجموع قبل الخصم:</span>
                          <span className="font-mono font-bold">{formatIQD(totals.subtotal)}</span>
                        </div>
                        <div className="flex items-center justify-between text-rose-700">
                          <span>الخصم الممنوح:</span>
                          <span className="font-mono font-bold">- {formatIQD(totals.discount)}</span>
                        </div>
                      </>
                    )}
                    <div className="flex items-center justify-between text-sm font-black text-slate-950 border-b border-slate-300 pb-2">
                      <span>صافي مبلغ الفاتورة:</span>
                      <span className="font-mono text-base">{formatIQD(totals.netTotal)}</span>
                    </div>

                    {config.showPaymentSummary && (
                      <>
                        <div className="flex items-center justify-between text-emerald-800 font-bold">
                          <span>المبلغ الواصل (المدفوع):</span>
                          <span className="font-mono">{formatIQD(totals.paid)}</span>
                        </div>
                        <div className="flex items-center justify-between text-amber-900 font-black pt-1 border-t border-slate-200">
                          <span>الباقي في الذمة:</span>
                          <span className="font-mono">{formatIQD(totals.remaining)}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {!config.showPrices && config.notes && (
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-3 text-xs">
                  <span className="font-bold text-slate-600 block mb-0.5">ملاحظات الطلبية:</span>
                  <p className="text-slate-800 font-semibold">{config.notes}</p>
                </div>
              )}

              {/* Signatures Footer */}
              {config.showSignatures && (
                <div className="pt-6 mt-4 border-t border-dashed border-slate-300 grid grid-cols-2 gap-6 text-center text-xs text-slate-600">
                  <div>
                    <div className="font-bold text-slate-800 mb-6">
                      توقيع وختم {config.issuerName || 'المجهز'}
                    </div>
                    <div className="border-b border-slate-300 mx-auto w-28 sm:w-36" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-800 mb-6">
                      توقيع المستلم ({config.recipientName || 'العميل / المذخر'})
                    </div>
                    <div className="border-b border-slate-300 mx-auto w-28 sm:w-36" />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sticky Footer Bar (Hidden in Print) */}
        <div className="bg-white border-t border-slate-200 px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 shrink-0 print:hidden">
          <div className="text-[11px] sm:text-xs text-slate-600 truncate">
            <span>المواد: </span>
            <strong className="text-slate-900">{config.lines.length}</strong>
            {config.showPrices && (
              <>
                <span className="mx-1.5">•</span>
                <span>الصافي: </span>
                <strong className="text-teal-900 font-mono">{formatIQD(totals.netTotal)}</strong>
              </>
            )}
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-300 px-3 sm:px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={handlePrintNow}
              className="inline-flex items-center gap-1.5 rounded-xl bg-teal-900 hover:bg-teal-800 text-amber-300 px-3.5 sm:px-5 py-2 sm:py-2.5 text-xs font-black shadow-sm transition active:scale-95 whitespace-nowrap"
            >
              <Printer className="h-4 w-4 shrink-0" />
              <span>طباعة الفاتورة الآن</span>
              <span className="hidden sm:inline">({config.issuerName.slice(0, 22)})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
