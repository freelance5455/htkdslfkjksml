"use client";

import { useState } from "react";
import { apiDelete, apiPatch } from "@/lib/client/api";
import { CopyButton, Pill } from "./ui";

export type LibraryRow = {
  id: number;
  tool: string;
  title: string;
  body: string;
  createdAt: string;
};

const TOOL_EMOJI: Record<string, string> = {
  titles: "🎯",
  hooks: "🪝",
  scripts: "🎬",
  captions: "✍️",
  hashtags: "#️⃣",
  thumbnail: "🖼️",
  ideas: "💡",
  calendar: "🗓️",
  analyze: "🔍",
};

export default function LibraryList({ initial }: { initial: LibraryRow[] }) {
  const [items, setItems] = useState(initial);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [draftTitle, setDraftTitle] = useState("");
  const [draftBody, setDraftBody] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [busy, setBusy] = useState(false);

  const visible = filter === "all" ? items : items.filter((i) => i.tool === filter);
  const toolKeys = Array.from(new Set(items.map((i) => i.tool)));

  if (!items.length) {
    return (
      <div className="card p-6 text-center">
        <p className="text-sm font-medium">Your library is empty</p>
        <p className="mt-1 text-sm text-[color:var(--muted)]">
          Tap “Save to library” on any generation and it will show up here.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="scrollbar-slim flex gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setFilter("all")}
          className={`btn btn-sm ${filter === "all" ? "btn-primary" : "btn-ghost"}`}
        >
          All ({items.length})
        </button>
        {toolKeys.map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setFilter(key)}
            className={`btn btn-sm shrink-0 ${filter === key ? "btn-primary" : "btn-ghost"}`}
          >
            {TOOL_EMOJI[key] ?? "✨"} {key}
          </button>
        ))}
      </div>

      <ul className="space-y-2">
        {visible.map((item) => {
          const isEditing = editingId === item.id;
          return (
            <li key={item.id} className="card p-3">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  {isEditing ? (
                    <input className="input" value={draftTitle} onChange={(e) => setDraftTitle(e.target.value)} />
                  ) : (
                    <p className="truncate text-sm font-semibold">{item.title}</p>
                  )}
                  <div className="mt-1 flex items-center gap-2">
                    <Pill>
                      {TOOL_EMOJI[item.tool] ?? "✨"} {item.tool}
                    </Pill>
                    <span className="text-[0.7rem] text-[color:var(--muted)]">
                      {new Date(item.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <CopyButton value={item.body} label="" />
                  {isEditing ? (
                    <>
                      <button
                        type="button"
                        className="btn btn-primary btn-sm"
                        disabled={busy}
                        onClick={async () => {
                          setBusy(true);
                          try {
                            await apiPatch(`/api/library/${item.id}`, { title: draftTitle, body: draftBody });
                            setItems((list) =>
                              list.map((i) => (i.id === item.id ? { ...i, title: draftTitle, body: draftBody } : i)),
                            );
                            setEditingId(null);
                          } finally {
                            setBusy(false);
                          }
                        }}
                      >
                        Save
                      </button>
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditingId(null)}>
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        className="btn btn-ghost btn-sm"
                        onClick={() => {
                          setEditingId(item.id);
                          setDraftTitle(item.title);
                          setDraftBody(item.body);
                        }}
                      >
                        ✎ Edit
                      </button>
                      <button
                        type="button"
                        className="btn btn-ghost btn-sm"
                        onClick={async () => {
                          await apiDelete(`/api/library/${item.id}`);
                          setItems((list) => list.filter((i) => i.id !== item.id));
                        }}
                      >
                        🗑
                      </button>
                    </>
                  )}
                </div>
              </div>
              {isEditing ? (
                <textarea className="textarea mt-2" value={draftBody} onChange={(e) => setDraftBody(e.target.value)} />
              ) : (
                <pre className="scrollbar-slim mt-2 max-h-56 overflow-auto whitespace-pre-wrap rounded-xl border border-white/10 bg-black/25 p-3 text-sm text-white/85">
                  {item.body}
                </pre>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
