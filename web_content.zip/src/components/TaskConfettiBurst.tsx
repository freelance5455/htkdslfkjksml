import { AnimatePresence, motion } from 'motion/react';
import { Heart, Star } from 'lucide-react';

interface ParticleSpec {
  id: number;
  kind: 'star' | 'heart' | 'confetti';
  x: number;
  y: number;
  rotate: number;
  color: string;
  size: number;
  delay: number;
}

const PARTICLES: ParticleSpec[] = [
  { id: 1, kind: 'star', x: -34, y: -42, rotate: -35, color: '#FBBF24', size: 15, delay: 0 },
  { id: 2, kind: 'heart', x: 32, y: -44, rotate: 28, color: '#EC4899', size: 14, delay: 0.03 },
  { id: 3, kind: 'confetti', x: -48, y: -16, rotate: 65, color: '#8B5CF6', size: 8, delay: 0.02 },
  { id: 4, kind: 'confetti', x: 46, y: -18, rotate: -55, color: '#10B981', size: 8, delay: 0.04 },
  { id: 5, kind: 'star', x: 0, y: -56, rotate: 18, color: '#F97316', size: 16, delay: 0.01 },
  { id: 6, kind: 'confetti', x: -22, y: -52, rotate: 110, color: '#3B82F6', size: 7, delay: 0.05 },
  { id: 7, kind: 'confetti', x: 22, y: -50, rotate: -95, color: '#FBBF24', size: 7, delay: 0.05 },
  { id: 8, kind: 'heart', x: -40, y: 12, rotate: -20, color: '#F43F5E', size: 12, delay: 0.06 },
  { id: 9, kind: 'star', x: 40, y: 14, rotate: 40, color: '#A855F7', size: 13, delay: 0.04 },
  { id: 10, kind: 'confetti', x: 0, y: 30, rotate: 45, color: '#10B981', size: 7, delay: 0.03 },
];

interface TaskConfettiBurstProps {
  burstKey: number | null;
}

export function TaskConfettiBurst({ burstKey }: TaskConfettiBurstProps) {
  return (
    <AnimatePresence>
      {burstKey !== null && (
        <div
          key={burstKey}
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 flex items-center justify-center z-20 overflow-visible"
        >
          {PARTICLES.map((p) => (
            <motion.span
              key={p.id}
              initial={{ opacity: 1, x: 0, y: 0, scale: 0.3, rotate: 0 }}
              animate={{
                opacity: [1, 1, 0],
                x: p.x,
                y: p.y,
                scale: [0.4, 1.15, 0.75],
                rotate: p.rotate,
              }}
              exit={{ opacity: 0 }}
              transition={{
                duration: 0.78,
                delay: p.delay,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="absolute flex items-center justify-center"
              style={{ color: p.color }}
            >
              {p.kind === 'star' && (
                <Star
                  style={{ width: p.size, height: p.size }}
                  fill="currentColor"
                  strokeWidth={1.5}
                />
              )}
              {p.kind === 'heart' && (
                <Heart
                  style={{ width: p.size, height: p.size }}
                  fill="currentColor"
                  strokeWidth={1.5}
                />
              )}
              {p.kind === 'confetti' && (
                <span
                  className="block rounded-sm"
                  style={{
                    width: p.size,
                    height: Math.round(p.size * 0.6),
                    backgroundColor: p.color,
                  }}
                />
              )}
            </motion.span>
          ))}
        </div>
      )}
    </AnimatePresence>
  );
}
