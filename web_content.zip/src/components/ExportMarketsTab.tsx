import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Globe2,
  TrendingUp,
  TrendingDown,
  Building2,
  FileCheck2,
  PhoneCall,
  CheckCircle2,
  Search,
  Scale,
  Sparkles,
  ShieldCheck,
  X,
  Target,
  Send,
  Award,
  Ship,
  Clock,
  Compass,
} from 'lucide-react';
import { Language, ExportMarketDemand } from '../types';
import { EXPORT_MARKET_DEMAND } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';
import WorldExportMap, { SupportedCountryFilter } from './WorldExportMap';
import AIProfitAdvisorModal from './AIProfitAdvisorModal';

interface ExportMarketsTabProps {
  language: Language;
  onNavigateToBuyers?: () => void;
  onSetAlertForCrop?: (cropId: string, currentPrice: number) => void;
}

export default function ExportMarketsTab({
  language,
  onNavigateToBuyers,
  onSetAlertForCrop,
}: ExportMarketsTabProps) {
  const isSw = language === 'sw';

  // Filters
  const [selectedCountry, setSelectedCountry] = useState<SupportedCountryFilter>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // AI Profit Advisor Modal State
  const [isProfitAdvisorOpen, setIsProfitAdvisorOpen] = useState<boolean>(false);

  // Expand quality specs
  const [expandedMarketId, setExpandedMarketId] = useState<string | null>(null);

  // Inquiry / Contract Modal State
  const [selectedMarketForInquiry, setSelectedMarketForInquiry] = useState<ExportMarketDemand | null>(null);
  const [farmerTonnage, setFarmerTonnage] = useState<string>('25');
  const [farmerRegion, setFarmerRegion] = useState<string>('Morogoro');
  const [inquirySubmitted, setInquirySubmitted] = useState<boolean>(false);
  const [contactRevealedId, setContactRevealedId] = useState<string | null>(null);

  // Quick Export Calculator State
  const [calcSelectedCropId, setCalcSelectedCropId] = useState<string>('exp-cn-sesame');
  const [calcTons, setCalcTons] = useState<string>('25');

  // Filtered markets
  const filteredMarkets = EXPORT_MARKET_DEMAND.filter((m) => {
    if (selectedCountry === 'china' && m.countryCode !== 'CN') return false;
    if (selectedCountry === 'india' && m.countryCode !== 'IN') return false;
    if (selectedCountry === 'uae' && m.countryCode !== 'AE') return false;
    if (selectedCountry === 'eu' && m.countryCode !== 'EU' && m.countryCode !== 'NL') return false;
    if (selectedCountry === 'us' && m.countryCode !== 'US') return false;

    if (selectedCategory !== 'all' && m.category !== selectedCategory) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = m.marketName.toLowerCase().includes(q) || m.marketNameEn.toLowerCase().includes(q);
      const matchCrop = m.cropSw.toLowerCase().includes(q) || m.cropEn.toLowerCase().includes(q);
      const matchBuyer = m.buyerEntity.toLowerCase().includes(q);
      const matchCity = m.city.toLowerCase().includes(q);
      if (!matchName && !matchCrop && !matchBuyer && !matchCity) return false;
    }

    return true;
  });

  const chinaMarketsCount = EXPORT_MARKET_DEMAND.filter((m) => m.countryCode === 'CN').length;

  // Selected crop for quick calculator
  const activeCalcMarket = EXPORT_MARKET_DEMAND.find((m) => m.id === calcSelectedCropId) || EXPORT_MARKET_DEMAND[0];
  const calcTonsNum = Number(calcTons) || 0;
  const calcTotalKg = calcTonsNum * 1000;
  const calcTotalTsh = calcTotalKg * activeCalcMarket.pricePerKgTsh;
  const calcTotalUsd = calcTonsNum * activeCalcMarket.pricePerMtUsd;

  const handleOpenInquiry = (market: ExportMarketDemand) => {
    playKeyTap();
    setSelectedMarketForInquiry(market);
    setInquirySubmitted(false);
    // default tonnage to min order or 25
    setFarmerTonnage('25');
  };

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    playSuccessChime();
    setInquirySubmitted(true);
  };

  return (
    <div id="export-markets-tab" className="space-y-4">
      {/* 0. GLOBAL EXPORT INSIGHTS: WORLD MAP VISUALIZATION & CORRIDORS */}
      <WorldExportMap
        language={language}
        selectedCountry={selectedCountry}
        onSelectCountry={(c) => setSelectedCountry(c)}
        onOpenProfitAdvisor={() => setIsProfitAdvisorOpen(true)}
      />

      {/* 1. BILATERAL PROTOCOL & TRADE AGREEMENT HERO BANNER */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-red-900/90 via-red-950/95 to-slate-900 text-[#F7F4E9] border border-red-500/40 shadow-md relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-10 -right-10 w-44 h-44 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-red-600/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-2.5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/40 flex items-center gap-1.5">
              <span>🇨🇳 🤝 🇹🇿</span>
              <span>{isSw ? 'Mikataba ya Kimataifa & Ushuru Sifuri' : 'Zero-Tariff Bilateral Quota'}</span>
            </span>
            <span className="text-[10px] font-semibold text-emerald-300 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isSw ? 'Malipo Salama ya Barua ya Mkopo (LC)' : 'Escrow & Irrevocable LC'}</span>
            </span>
          </div>

          <div>
            <h3 className="font-display text-lg md:text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>{isSw ? 'Nafasi za Masoko ya China & Nje ya Nchi' : 'China & Global Export Demand'}</span>
            </h3>
            <p className="text-xs text-slate-200 mt-1 leading-relaxed">
              {isSw
                ? 'China inahitaji kiasi kikubwa cha mazao ya Tanzania (Ufuta, Soya, Muhogo Mkaushwa, Parachichi, Mbaazi, Korosho na Pilipili) chini ya mpango wa forodha wa Ushuru Sifuri (Zero-Tariff 98%).'
                : 'Direct high-volume import quotas for Tanzanian sesame, soybeans, dried cassava, avocados, pulses, cashews, and bird’s eye chili with zero customs duties.'}
            </p>
          </div>

          {/* Key Export Summary Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 text-center">
              <div className="text-[10px] text-slate-300 font-medium">
                {isSw ? 'Masoko ya China' : 'China Markets'}
              </div>
              <div className="font-display font-bold text-base text-amber-300 mt-0.5">
                {chinaMarketsCount} {isSw ? 'Makuu' : 'Active Hubs'}
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 text-center">
              <div className="text-[10px] text-slate-300 font-medium">
                {isSw ? 'Ujazo Unaohitajika' : 'Total Quota'}
              </div>
              <div className="font-display font-bold text-base text-white mt-0.5">
                250,000+ Tan
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 text-center">
              <div className="text-[10px] text-slate-300 font-medium">
                {isSw ? 'Bei ya Juu' : 'Top Commodity Price'}
              </div>
              <div className="font-display font-bold text-base text-emerald-300 mt-0.5">
                Tsh 21,500/kg
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 text-center">
              <div className="text-[10px] text-slate-300 font-medium">
                {isSw ? 'Uwasilishaji' : 'Delivery Terms'}
              </div>
              <div className="font-display font-bold text-xs text-amber-200 mt-1">
                FOB Dar / Mtwara
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. INTERACTIVE EXPORT VALUE CALCULATOR */}
      <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-emerald-500/15 text-[var(--forest)] flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-[var(--ink)]">
                {isSw ? 'Kikokotoo cha Mapato ya Nje (China & Export Calculator)' : 'Export Revenue Calculator'}
              </h4>
              <p className="text-[10px] text-[var(--ink-soft)]">
                {isSw ? 'Hesabu thamani ya tani zako kwa sarafu ya Dola ($) na Shilingi (Tsh)' : 'Calculate export earnings in USD ($) and Tsh for your harvest volume'}
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30">
            {isSw ? 'Bei Rasmi za FOB' : 'FOB Export Value'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
          {/* Crop Selector */}
          <div className="sm:col-span-6">
            <label className="text-[10px] font-bold text-[var(--ink-soft)] block mb-1">
              {isSw ? 'Chagua Zao la Nje / Soko' : 'Select Export Crop & Market'}
            </label>
            <select
              value={calcSelectedCropId}
              onChange={(e) => {
                playKeyTap();
                setCalcSelectedCropId(e.target.value);
              }}
              className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] font-semibold"
            >
              {EXPORT_MARKET_DEMAND.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.cropIcon} {isSw ? m.cropSw : m.cropEn} — {m.country} ({isSw ? m.priceDisplaySw : m.priceDisplayEn})
                </option>
              ))}
            </select>
          </div>

          {/* Volume in Metric Tons */}
          <div className="sm:col-span-6">
            <label className="text-[10px] font-bold text-[var(--ink-soft)] block mb-1">
              {isSw ? 'Kiasi Chako (Tani / MT)' : 'Your Volume (Metric Tons)'}
            </label>
            <div className="flex gap-1.5">
              <input
                type="number"
                min="1"
                step="1"
                value={calcTons}
                onChange={(e) => setCalcTons(e.target.value)}
                placeholder="25"
                className="flex-1 p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] font-bold text-xs text-[var(--ink)]"
              />
              <div className="flex gap-1">
                {['5', '25', '50', '100'].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      playKeyTap();
                      setCalcTons(preset);
                    }}
                    className={`px-2 py-1 rounded-xl text-[10px] font-bold border transition-all cursor-pointer ${
                      calcTons === preset
                        ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)]'
                        : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
                    }`}
                  >
                    {preset}T
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Calculated Result Box */}
        <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="text-[10px] text-[var(--ink-soft)] font-medium">
              {isSw
                ? `Makadirio ya Mapato ya Tani ${calcTonsNum.toLocaleString()} (${calcTotalKg.toLocaleString()} Kgs):`
                : `Gross Earnings for ${calcTonsNum.toLocaleString()} MT (${calcTotalKg.toLocaleString()} Kgs):`}
            </div>
            <div className="font-display font-bold text-lg text-[var(--forest)] flex items-center gap-2 mt-0.5">
              <span>Tsh {calcTotalTsh.toLocaleString()}</span>
              <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold px-2 py-0.5 rounded-lg bg-amber-500/15">
                ≈ ${calcTotalUsd.toLocaleString()} USD
              </span>
            </div>
          </div>

          <button
            onClick={() => handleOpenInquiry(activeCalcMarket)}
            className="py-2 px-3.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs hover:bg-[var(--forest-dark)] shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isSw ? 'Wasilisha Kiasi Hiki' : 'Apply With This Quota'}</span>
          </button>
        </div>
      </div>

      {/* 3. FILTER & SEARCH CONTROLS */}
      <div className="space-y-2">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-[var(--ink-soft)] absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isSw
                ? 'Tafuta soko, zao (mf. Ufuta, Soya, Muhogo, Parachichi, China, Qingdao)...'
                : 'Search market, crop (e.g. Sesame, Soybeans, Cassava, Avocado, China)...'
            }
            className="w-full pl-9 pr-8 py-2 rounded-xl bg-[var(--paper)] border border-[var(--line)] text-xs text-[var(--ink)] placeholder:text-[var(--ink-soft)] focus:outline-none focus:border-[var(--forest)] shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-[var(--ink-soft)] hover:text-[var(--ink)] p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Country Filter Chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {[
            { id: 'all' as SupportedCountryFilter, sw: '🌍 Masoko Yote', en: '🌍 All Corridors' },
            { id: 'china' as SupportedCountryFilter, sw: '🇨🇳 China (Zero-Tariff 98%)', en: '🇨🇳 China (Zero-Tariff 98%)' },
            { id: 'eu' as SupportedCountryFilter, sw: '🇪🇺 Ulaya / EU (EBA 0%)', en: '🇪🇺 European Union (EBA 0%)' },
            { id: 'us' as SupportedCountryFilter, sw: '🇺🇸 Marekani (AGOA 0%)', en: '🇺🇸 United States (AGOA 0%)' },
            { id: 'india' as SupportedCountryFilter, sw: '🇮🇳 India (G2G)', en: '🇮🇳 India (G2G Quota)' },
            { id: 'uae' as SupportedCountryFilter, sw: '🇦🇪 Falme za Kiarabu / UAE', en: '🇦🇪 UAE & Gulf' },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => {
                playKeyTap();
                setSelectedCountry(c.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex-shrink-0 transition-all cursor-pointer border ${
                selectedCountry === c.id
                  ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] shadow-xs font-bold'
                  : 'bg-[var(--paper)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
              }`}
            >
              {isSw ? c.sw : c.en}
            </button>
          ))}
        </div>

        {/* Category Filter Chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {[
            { id: 'all', sw: 'Mazao Yote', en: 'All Crops' },
            { id: 'oilseeds', sw: '🌱 Ufuta & Soya', en: '🌱 Sesame & Soybeans' },
            { id: 'roots', sw: '🥔 Mihogo Mkaushwa', en: '🥔 Dried Cassava' },
            { id: 'fruits', sw: '🥑 Parachichi la Hass', en: '🥑 Hass Avocado' },
            { id: 'pulses', sw: '🫛 Mbaazi & Choroko', en: '🫛 Pigeon Peas & Mung' },
            { id: 'nuts_spices', sw: '🥜 Korosho & Pilipili', en: '🥜 Cashew & Chili' },
            { id: 'beverages', sw: '☕ Kahawa & Kakao', en: '☕ Coffee & Cocoa' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                playKeyTap();
                setSelectedCategory(cat.id);
              }}
              className={`px-2.5 py-1 rounded-xl text-[10px] font-semibold flex-shrink-0 transition-all cursor-pointer border ${
                selectedCategory === cat.id
                  ? 'bg-[var(--soil)] text-[#F7F4E9] border-[var(--soil)] shadow-xs'
                  : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
              }`}
            >
              {isSw ? cat.sw : cat.en}
            </button>
          ))}
        </div>
      </div>

      {/* 4. MARKETS LISTING */}
      <div className="space-y-3">
        {filteredMarkets.length === 0 ? (
          <div className="p-8 text-center bg-[var(--paper)] rounded-2xl border border-[var(--line)] space-y-2">
            <Globe2 className="w-8 h-8 text-[var(--ink-soft)] mx-auto opacity-50" />
            <div className="text-xs font-bold text-[var(--ink)]">
              {isSw ? 'Hakuna soko lililopatikana' : 'No export market matched your filter'}
            </div>
            <p className="text-[11px] text-[var(--ink-soft)]">
              {isSw ? 'Jaribu kubadili jina au kuweka vichungi vya nchi zote.' : 'Try adjusting your search or clear the country filters.'}
            </p>
            <button
              onClick={() => {
                setSelectedCountry('all');
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="py-1 px-3 rounded-xl bg-[var(--bg)] text-xs font-bold border border-[var(--line)] text-[var(--forest)] hover:bg-[var(--paper)] cursor-pointer mt-1"
            >
              {isSw ? 'Rejesha Masoko Yote' : 'Reset All Filters'}
            </button>
          </div>
        ) : (
          filteredMarkets.map((market) => {
            const isExpanded = expandedMarketId === market.id;
            const isContactRevealed = contactRevealedId === market.id;

            return (
              <div
                key={market.id}
                className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-3 transition-all hover:border-[var(--forest)]/50"
              >
                {/* Header: Country & Badges */}
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{market.cropIcon}</span>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-600/15 text-red-700 dark:text-red-300 border border-red-500/20 flex items-center gap-1">
                          <span>{market.country}</span>
                        </span>
                        <span className="text-[10px] text-[var(--ink-soft)]">
                          📍 {market.city}
                        </span>
                        {market.urgentStatus === 'urgent' && (
                          <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-500 text-black uppercase animate-pulse">
                            {isSw ? 'Mkataba wa Haraka' : 'Urgent Quota'}
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm text-[var(--ink)] mt-0.5">
                        {isSw ? market.marketName : market.marketNameEn}
                      </h4>
                    </div>
                  </div>

                  {/* Pricing Badge & EPI */}
                  <div className="text-right">
                    <div className="font-display font-bold text-base text-[var(--forest)]">
                      {isSw ? market.priceDisplaySw : market.priceDisplayEn}
                    </div>
                    {market.exportPriceIndex && (
                      <div className="text-[10px] font-mono text-emerald-700 dark:text-emerald-300 font-bold mt-0.5">
                        EPI {market.exportPriceIndex} ({market.exportPriceIndexDelta})
                      </div>
                    )}
                    <div className="text-[10px] font-semibold text-[var(--up)] flex items-center justify-end gap-0.5 mt-0.5">
                      <TrendingUp className="w-3 h-3" />
                      <span>{market.trendDelta} {isSw ? 'wiki hii' : 'this week'}</span>
                    </div>
                  </div>
                </div>

                {/* Crop & Requirements Card */}
                <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ink-soft)] font-medium">
                      {isSw ? 'Zao Linalohitajika:' : 'Required Crop:'}
                    </span>
                    <span className="font-bold text-[var(--ink)] flex items-center gap-1">
                      <span>{isSw ? market.cropSw : market.cropEn}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ink-soft)] font-medium">
                      {isSw ? 'Ujazo Unaohitajika (Quota):' : 'Demand Volume:'}
                    </span>
                    <span className="font-display font-bold text-amber-700 dark:text-amber-400 bg-amber-500/15 px-2 py-0.5 rounded-lg border border-amber-500/20">
                      {isSw ? market.requiredVolumeSw : market.requiredVolumeEn}
                    </span>
                  </div>

                  {/* Standard Quantity / Container Requirement */}
                  {market.standardQuantityReqSw && (
                    <div className="flex items-center justify-between">
                      <span className="text-[var(--ink-soft)] font-medium flex items-center gap-1">
                        <Ship className="w-3 h-3 text-[var(--forest)]" />
                        <span>{isSw ? 'Ujazo wa Kontena (FCL):' : 'Standard FCL Spec:'}</span>
                      </span>
                      <span className="font-semibold text-emerald-700 dark:text-emerald-300">
                        {isSw ? market.standardQuantityReqSw : market.standardQuantityReqEn}
                      </span>
                    </div>
                  )}

                  {/* Destination Port & Transit Days */}
                  {market.destinationPort && (
                    <div className="flex items-center justify-between">
                      <span className="text-[var(--ink-soft)] font-medium flex items-center gap-1">
                        <Compass className="w-3 h-3 text-[var(--ink-soft)]" />
                        <span>{isSw ? 'Bandari ya Marudio:' : 'Destination Port:'}</span>
                      </span>
                      <span className="text-[11px] font-semibold text-[var(--ink)]">
                        ⚓ {market.destinationPort} ({market.transitDays} {isSw ? 'siku' : 'days'})
                      </span>
                    </div>
                  )}

                  {/* Tariff & Net Margin */}
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ink-soft)] font-medium">
                      {isSw ? 'Kiwango cha Forodha:' : 'Tariff Protocol:'}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                      {isSw ? market.tariffProtocolTagSw : market.tariffProtocolTagEn}
                    </span>
                  </div>

                  {market.estimatedNetProfitMargin && (
                    <div className="flex items-center justify-between">
                      <span className="text-[var(--ink-soft)] font-medium">
                        {isSw ? 'Makadirio ya Faida Halisi:' : 'Est. Net Margin:'}
                      </span>
                      <span className="font-display font-black text-xs text-amber-600 dark:text-amber-400">
                        +{market.estimatedNetProfitMargin}% ROI
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ink-soft)] font-medium">
                      {isSw ? 'Mnunuzi / Mshirika:' : 'Buyer Entity:'}
                    </span>
                    <span className="font-semibold text-[var(--ink)] truncate max-w-[210px]" title={market.buyerEntity}>
                      <Building2 className="w-3 h-3 inline mr-1 text-[var(--forest)]" />
                      {market.buyerEntity}
                    </span>
                  </div>

                  <div className="pt-1 border-t border-[var(--line)] text-[10px] text-[var(--ink-soft)] flex items-center justify-between flex-wrap gap-1">
                    <span className="flex items-center gap-1 text-[var(--forest)] font-semibold">
                      <Award className="w-3 h-3" />
                      <span>{isSw ? market.tradeProtocolSw : market.tradeProtocolEn}</span>
                    </span>
                    <span>⏱️ {market.contractDeadline}</span>
                  </div>
                </div>

                {/* Direct AI Profit Comparison Button */}
                <button
                  type="button"
                  onClick={() => {
                    playKeyTap();
                    setIsProfitAdvisorOpen(true);
                  }}
                  className="w-full py-2 px-3 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-[11px] font-bold text-[var(--ink)] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>
                    {isSw
                      ? `Ushauri wa Faida: Linganisha Soko la ${market.country}`
                      : `Compare Net Margin for ${market.country}`}
                  </span>
                </button>

                {/* Collapsible Quality Specs */}
                <div>
                  <button
                    onClick={() => {
                      playKeyTap();
                      setExpandedMarketId(isExpanded ? null : market.id);
                    }}
                    className="w-full text-left py-1.5 px-2 rounded-xl text-xs font-semibold text-[var(--forest)] hover:bg-[var(--bg)] flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <span className="flex items-center gap-1.5">
                      <FileCheck2 className="w-3.5 h-3.5" />
                      <span>
                        {isExpanded
                          ? (isSw ? 'Funga Vigezo vya Ubora & Uwasilishaji' : 'Hide Quality & Delivery Terms')
                          : (isSw ? 'Tazama Vigezo vya Ubora & Uwasilishaji (Phytosanitary & Grade)' : 'View Quality Specs & Delivery Terms')}
                      </span>
                    </span>
                    <span className="text-xs">{isExpanded ? '▲' : '▼'}</span>
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden pt-2"
                      >
                        <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs space-y-2.5">
                          <div>
                            <div className="font-bold text-[11px] text-[var(--ink)] mb-1 flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>{isSw ? 'Vigezo vya Ubora Vinavyohitajika:' : 'Quality & Sanitary Requirements:'}</span>
                            </div>
                            <ul className="space-y-1 pl-1">
                              {(isSw ? market.qualitySpecsSw : market.qualitySpecsEn).map((spec, idx) => (
                                <li key={idx} className="text-[11px] text-[var(--ink-soft)] flex items-start gap-1.5">
                                  <span className="text-emerald-600 font-bold">•</span>
                                  <span>{spec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div className="pt-2 border-t border-[var(--line)]">
                            <div className="font-bold text-[11px] text-[var(--ink)] mb-0.5">
                              {isSw ? 'Mahali pa Kuwasilisha & Malipo:' : 'Delivery Point & Payment Terms:'}
                            </div>
                            <p className="text-[11px] text-[var(--ink-soft)] leading-relaxed">
                              {isSw ? market.deliveryTermsSw : market.deliveryTermsEn}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Contact Information Revealed Area */}
                {isContactRevealed && (
                  <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs space-y-1">
                    <div className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                      <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{isSw ? 'Mwakilishi wa Mkataba wa Nje:' : 'Official Export Desk Contacts:'}</span>
                    </div>
                    <div className="text-[11px] text-[var(--ink)] font-semibold">
                      {market.contactPerson}
                    </div>
                    <div className="text-[11px] font-mono text-[var(--forest)] font-bold">
                      {market.contactPhone}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      playKeyTap();
                      setContactRevealedId(isContactRevealed ? null : market.id);
                    }}
                    className="py-2.5 px-3 rounded-xl border border-[var(--line)] hover:bg-[var(--bg)] font-bold text-xs text-[var(--ink)] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-[var(--forest)]" />
                    <span>
                      {isContactRevealed
                        ? (isSw ? 'Ficha Namba' : 'Hide Contact')
                        : (isSw ? 'Namba za Simu' : 'Official Phone')}
                    </span>
                  </button>

                  <button
                    onClick={() => handleOpenInquiry(market)}
                    className="py-2.5 px-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Omba Mkataba' : 'Apply For Quota'}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* 5. INQUIRY / QUOTA APPLICATION MODAL */}
      <AnimatePresence>
        {selectedMarketForInquiry && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-md bg-[var(--paper)] rounded-3xl p-5 shadow-2xl border border-[var(--line)] max-h-[90vh] overflow-y-auto space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-800 dark:text-amber-300 border border-amber-400/30">
                    {selectedMarketForInquiry.country}
                  </span>
                  <h3 className="font-display text-lg font-bold text-[var(--ink)] mt-1">
                    {isSw ? 'Maombi ya Mkataba wa Kusafirisha' : 'Export Quota Application'}
                  </h3>
                  <p className="text-[11px] text-[var(--ink-soft)]">
                    {isSw ? selectedMarketForInquiry.marketName : selectedMarketForInquiry.marketNameEn}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedMarketForInquiry(null)}
                  className="p-1.5 rounded-full hover:bg-[var(--bg)] text-[var(--ink-soft)] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {inquirySubmitted ? (
                <div className="py-6 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-sm text-[var(--ink)]">
                      {isSw ? 'Maombi Yako Yamepokelewa Kikamilifu!' : 'Quota Request Registered!'}
                    </h4>
                    <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                      {isSw
                        ? `Umesajiliwa kuwasilisha Tani ${farmerTonnage} za ${selectedMarketForInquiry.cropSw}. Afisa wa dawati la usafirishaji atakupigia simu ndani ya saa 24 kupanga ukaguzi wa shamba na mkataba wa FOB.`
                        : `You have been registered for ${farmerTonnage} MT of ${selectedMarketForInquiry.cropEn}. An export logistics officer will call you within 24 hours.`}
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs text-left space-y-1 font-mono">
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">Nambari ya Kumbukumbu:</span>
                      <span className="font-bold text-[var(--forest)]">EXP-CN-{(Date.now() % 1000000).toString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">Makadirio ya Mapato:</span>
                      <span className="font-bold text-emerald-600">
                        Tsh {((Number(farmerTonnage) || 0) * 1000 * selectedMarketForInquiry.pricePerKgTsh).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedMarketForInquiry(null)}
                    className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs cursor-pointer shadow-xs hover:bg-[var(--forest-dark)]"
                  >
                    {isSw ? 'Funga & Endelea na Masoko' : 'Close & Continue'}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitInquiry} className="space-y-3">
                  <div className="p-3 rounded-2xl bg-[var(--bg)] text-xs space-y-1 border border-[var(--line)]">
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Zao:' : 'Crop:'}</span>
                      <span className="font-bold text-[var(--ink)]">
                        {selectedMarketForInquiry.cropIcon} {isSw ? selectedMarketForInquiry.cropSw : selectedMarketForInquiry.cropEn}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Bei ya Soko:' : 'Market Price:'}</span>
                      <span className="font-bold text-[var(--forest)]">
                        {isSw ? selectedMarketForInquiry.priceDisplaySw : selectedMarketForInquiry.priceDisplayEn}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Kiwango cha Chini:' : 'Minimum Batch:'}</span>
                      <span className="font-semibold text-[var(--ink)]">
                        {isSw ? selectedMarketForInquiry.minVolumeSw : selectedMarketForInquiry.minVolumeEn}
                      </span>
                    </div>
                  </div>

                  {/* Farmer Tonnage Input */}
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink)] block mb-1">
                      {isSw ? 'Kiasi Unachoweza Kuwasilisha (Tani / Metric Tons):' : 'Volume You Can Supply (Metric Tons):'}
                    </label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={farmerTonnage}
                      onChange={(e) => setFarmerTonnage(e.target.value)}
                      placeholder="e.g. 25"
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] font-bold text-sm text-[var(--ink)]"
                    />
                  </div>

                  {/* Region of farm / collection */}
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink)] block mb-1">
                      {isSw ? 'Mkoa Lilipo Shamba / Ghala Lako:' : 'Farm / Warehouse Region:'}
                    </label>
                    <select
                      value={farmerRegion}
                      onChange={(e) => setFarmerRegion(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] font-semibold"
                    >
                      <option value="Morogoro">Morogoro (Kilombero, Gairo, Mvomero)</option>
                      <option value="Mtwara">Mtwara & Lindi (Masasi, Tandahimba, Nachingwea)</option>
                      <option value="Ruvuma">Ruvuma (Songea, Namtumbo, Tunduru)</option>
                      <option value="Pwani">Pwani (Kibaha, Kisarawe, Rufiji, Bagamoyo)</option>
                      <option value="Mbeya">Mbeya & Songwe (Rungwe, Kyela, Mbozi)</option>
                      <option value="Njombe">Njombe & Iringa (Makambako, Wanging'ombe)</option>
                      <option value="Dodoma">Dodoma (Kongwa, Chamwino, Bahi)</option>
                      <option value="Tanga">Tanga (Korogwe, Muheza, Lushoto)</option>
                      <option value="Arusha">Arusha & Kilimanjaro (Moshi, Hai)</option>
                      <option value="Shinyanga">Shinyanga, Simiyu & Geita</option>
                    </select>
                  </div>

                  {/* Dynamic Earnings Estimation */}
                  <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-[var(--ink-soft)] block">
                        {isSw ? 'Makadirio ya Malipo yako ya FOB:' : 'Estimated Gross FOB Payout:'}
                      </span>
                      <span className="font-display font-bold text-base text-[var(--forest)]">
                        Tsh {((Number(farmerTonnage) || 0) * 1000 * selectedMarketForInquiry.pricePerKgTsh).toLocaleString()}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-400">
                      ≈ ${((Number(farmerTonnage) || 0) * selectedMarketForInquiry.pricePerMtUsd).toLocaleString()} USD
                    </span>
                  </div>

                  {/* Submit Actions */}
                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedMarketForInquiry(null)}
                      className="flex-1 py-2.5 rounded-xl border border-[var(--line)] font-bold text-xs text-[var(--ink)] hover:bg-[var(--bg)] cursor-pointer"
                    >
                      {isSw ? 'Ghairi' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2.5 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isSw ? 'Tuma Maombi ya Mkataba' : 'Submit Application'}</span>
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. AI EXPORT PROFIT ADVISOR MODAL */}
      <AIProfitAdvisorModal
        isOpen={isProfitAdvisorOpen}
        onClose={() => setIsProfitAdvisorOpen(false)}
        language={language}
        onSelectCountry={(countryCode) => {
          setSelectedCountry(countryCode as SupportedCountryFilter);
          setIsProfitAdvisorOpen(false);
        }}
      />
    </div>
  );
}
