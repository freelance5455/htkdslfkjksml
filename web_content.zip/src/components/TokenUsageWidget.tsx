import React, { useState, useRef, useEffect } from 'react';
import {
  Activity,
  ChevronDown,
  Info,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  ArrowDownLeft,
  Sliders,
} from 'lucide-react';
import { SessionTokenStats, ChatSettings } from '../types/index.ts';
import { getModelContextLimit } from '../utils/models.ts';

interface TokenUsageWidgetProps {
  tokenStats?: SessionTokenStats;
  settings: ChatSettings;
  onOpenSettings: () => void;
  isStreaming?: boolean;
}

export const TokenUsageWidget: React.FC<TokenUsageWidgetProps> = ({
  tokenStats,
  settings,
  onOpenSettings,
  isStreaming,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const inputTokens = tokenStats?.totalInputTokens || 0;
  const outputTokens = tokenStats?.totalOutputTokens || 0;
  const totalTokens = tokenStats?.totalTokens || inputTokens + outputTokens;

  // Dynamic context window limit based on selected model (1M for Gemini, 128k for Gemma)
  const CONTEXT_LIMIT = getModelContextLimit(settings.model);
  const usagePercent = Math.min(100, (totalTokens / CONTEXT_LIMIT) * 100);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const formatNumber = (num: number) => {
    if (num < 1000) return num.toString();
    if (num < 1000000) return `${(num / 1000).toFixed(1)}k`;
    return `${(num / 1000000).toFixed(2)}M`;
  };

  const isSensorOff = !settings.safetyFilterEnabled || settings.safetyThreshold === 'BLOCK_NONE';

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button in Header */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="Klik untuk melihat rincian real-time token per sesi dan status sensor AI"
        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl border text-xs font-mono transition cursor-pointer ${
          isStreaming
            ? 'bg-indigo-950/60 border-indigo-500/60 text-indigo-300 animate-pulse'
            : isOpen
            ? 'bg-slate-800 border-indigo-500/80 text-white'
            : 'bg-slate-900/80 hover:bg-slate-800 border-slate-700/60 text-slate-300 hover:text-white'
        }`}
      >
        <Activity className={`w-3.5 h-3.5 ${isStreaming ? 'text-indigo-400' : 'text-sky-400'}`} />

        {/* Mini Segmented Progress Bar */}
        <div className="hidden sm:flex flex-col gap-0.5 items-start">
          <div className="flex items-center gap-1.5 text-[11px] font-sans">
            <span className="flex items-center gap-0.5 text-sky-400">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 inline-block" />
              In: {formatNumber(inputTokens)}
            </span>
            <span className="text-slate-500">|</span>
            <span className="flex items-center gap-0.5 text-indigo-400">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 inline-block" />
              Out: {formatNumber(outputTokens)}
            </span>
          </div>

          <div className="w-24 bg-slate-800 h-1 rounded-full overflow-hidden flex">
            {totalTokens > 0 ? (
              <>
                <div
                  className="bg-sky-400 h-full transition-all duration-300"
                  style={{ width: `${(inputTokens / (totalTokens || 1)) * 100}%` }}
                />
                <div
                  className="bg-indigo-500 h-full transition-all duration-300"
                  style={{ width: `${(outputTokens / (totalTokens || 1)) * 100}%` }}
                />
              </>
            ) : (
              <div className="w-full bg-slate-700 h-full" />
            )}
          </div>
        </div>

        {/* Compact view on mobile */}
        <span className="sm:hidden text-[11px] font-mono text-slate-300">
          {formatNumber(totalTokens)} tok
        </span>

        {/* Sensor status mini badge */}
        <div
          className={`hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-sans font-medium border ${
            isSensorOff
              ? 'bg-amber-950/60 border-amber-600/40 text-amber-300'
              : 'bg-emerald-950/60 border-emerald-600/40 text-emerald-300'
          }`}
        >
          {isSensorOff ? '🔓 Bebas Sensor' : '🛡️ Sensor Aktif'}
        </div>

        <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Popover Card */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-92 rounded-2xl bg-slate-900/95 border border-slate-700/80 shadow-2xl backdrop-blur-md p-4 z-50 text-xs text-slate-200 animate-in fade-in zoom-in-95 duration-150">
          {/* Card Title */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                <Zap className="w-3.5 h-3.5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-xs">Statistik Token Real-Time Sesi</h3>
                <p className="text-[10px] text-slate-400">Pemantauan kapasitas konteks &amp; limit API</p>
              </div>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-300">
              {settings.model}
            </span>
          </div>

          {/* Token Breakdown Grid */}
          <div className="grid grid-cols-2 gap-2 my-3">
            {/* Input (Prompt) Tokens */}
            <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-750">
              <div className="flex items-center justify-between text-slate-400 text-[10px] mb-1">
                <span className="flex items-center gap-1 text-sky-400 font-semibold">
                  <ArrowDownLeft className="w-3 h-3" />
                  Input (Prompt)
                </span>
                <span className="font-mono">{totalTokens > 0 ? ((inputTokens / totalTokens) * 100).toFixed(0) : 0}%</span>
              </div>
              <div className="text-base font-bold font-mono text-sky-300">
                {inputTokens.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                Instruksi &amp; pertanyaan Anda
              </div>
            </div>

            {/* Output (Model) Tokens */}
            <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-750">
              <div className="flex items-center justify-between text-slate-400 text-[10px] mb-1">
                <span className="flex items-center gap-1 text-indigo-400 font-semibold">
                  <ArrowUpRight className="w-3 h-3" />
                  Output (Jawaban)
                </span>
                <span className="font-mono">{totalTokens > 0 ? ((outputTokens / totalTokens) * 100).toFixed(0) : 0}%</span>
              </div>
              <div className="text-base font-bold font-mono text-indigo-300">
                {outputTokens.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                Tanggapan yang dibuat AI
              </div>
            </div>
          </div>

          {/* Total & Context Window Capacity Gauge */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="flex justify-between items-center text-[11px]">
              <span className="text-slate-300 font-medium">Penggunaan Context Window (1M)</span>
              <span className="font-mono text-slate-100 font-bold">
                {totalTokens.toLocaleString('id-ID')} / 1.048.576
              </span>
            </div>

            {/* Segmented Dual Bar */}
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
              {totalTokens > 0 ? (
                <>
                  <div
                    className="bg-sky-400 h-full transition-all duration-300"
                    title={`Input: ${inputTokens} tokens`}
                    style={{ width: `${(inputTokens / (totalTokens || 1)) * 100}%` }}
                  />
                  <div
                    className="bg-indigo-500 h-full transition-all duration-300"
                    title={`Output: ${outputTokens} tokens`}
                    style={{ width: `${(outputTokens / (totalTokens || 1)) * 100}%` }}
                  />
                </>
              ) : (
                <div className="w-full bg-slate-800 h-full" />
              )}
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400">
              <span>Terpakai: {usagePercent < 0.01 && totalTokens > 0 ? '<0.01%' : `${usagePercent.toFixed(2)}%`}</span>
              <span className="text-emerald-400 font-medium">
                {(CONTEXT_LIMIT - totalTokens).toLocaleString('id-ID')} token tersisa
              </span>
            </div>
          </div>

          {/* AI Censorship / Safety Status Section */}
          <div className="mt-3 p-2.5 rounded-xl bg-slate-800/40 border border-slate-750 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isSensorOff ? (
                <ShieldAlert className="w-4 h-4 text-amber-400" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              )}
              <div>
                <div className="font-semibold text-xs text-white">
                  {isSensorOff ? 'Sensor AI: Dimatikan (Bebas)' : 'Sensor AI: Aktif (Tersaring)'}
                </div>
                <div className="text-[10px] text-slate-400">
                  {isSensorOff
                    ? 'Konten tanpa filter sensor (BLOCK_NONE)'
                    : `Tingkat filter: ${settings.safetyThreshold}`}
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setIsOpen(false);
                onOpenSettings();
              }}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-indigo-300 hover:text-white border border-slate-700 transition"
            >
              Ubah
            </button>
          </div>

          {/* Quick Footer Action */}
          <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">
              Memori riwayat:{' '}
              <strong className="text-slate-200">
                {settings.contextWindow === 0 ? 'Semua' : `${settings.contextWindow} pesan`}
              </strong>
            </span>
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenSettings();
              }}
              className="flex items-center gap-1 text-indigo-400 hover:underline font-medium"
            >
              <Sliders className="w-3 h-3" />
              <span>Buka Pengaturan</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
