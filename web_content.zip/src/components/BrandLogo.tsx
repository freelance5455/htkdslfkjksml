import React, { useState } from 'react';

export const APP_LOGO_URL = 'https://i.ibb.co.com/B0hcP22/Tiga-Rekan-ID-1.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<BrandLogoProps['size']>, string> = {
  sm: 'w-8 h-8',
  md: 'w-9 h-9',
  lg: 'w-14 h-14',
  xl: 'w-20 h-20 sm:w-24 sm:h-24',
};

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 'md', className = '' }) => {
  const [failed, setFailed] = useState(false);
  const boxClass = SIZE_CLASSES[size];

  if (failed) {
    return (
      <div
        className={`${boxClass} rounded-xl bg-orange-600 text-white flex items-center justify-center font-bold text-sm shrink-0 ${className}`}
        aria-label="Logo Tiga Rekan ID"
      >
        TR
      </div>
    );
  }

  return (
    <div
      className={`${boxClass} shrink-0 flex items-center justify-center overflow-hidden ${className}`}
    >
      <img
        src={APP_LOGO_URL}
        alt="Logo Tiga Rekan ID"
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        className="w-full h-full object-contain select-none"
      />
    </div>
  );
};
