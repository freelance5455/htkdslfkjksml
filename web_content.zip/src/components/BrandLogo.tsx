import React from "react";

interface BrandLogoProps {
  size?: "sm" | "md" | "lg";
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = "md",
  showSubtitle = false,
}) => {
  const iconDimensions =
    size === "lg" ? "w-12 h-12" : size === "sm" ? "w-7 h-7" : "w-9 h-9";
  const titleClass =
    size === "lg"
      ? "text-2xl font-bold tracking-tight"
      : size === "sm"
      ? "text-base font-bold tracking-tight"
      : "text-lg font-bold tracking-tight";

  return (
    <div className="inline-flex items-center gap-2.5 shrink-0">
      <div
        className={`${iconDimensions} rounded-xl bg-slate-900 dark:bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm`}
        aria-hidden="true"
      >
        <svg
          viewBox="0 0 32 32"
          fill="none"
          className="w-[62%] h-[62%]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M5 24V9.5L16 17L27 9.5V24"
            stroke="currentColor"
            strokeWidth="2.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M16 17V25"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <circle cx="16" cy="7" r="2.25" fill="currentColor" />
        </svg>
      </div>
      <div className="flex flex-col leading-none">
        <span
          className={`${titleClass} font-display text-slate-900 dark:text-white whitespace-nowrap`}
        >
          MIH<span className="text-blue-600 dark:text-blue-400">.AI</span>
        </span>
        {showSubtitle && (
          <span className="text-xs text-slate-500 dark:text-slate-400 mt-1 whitespace-nowrap">
            Your Personal AI Assistant
          </span>
        )}
      </div>
    </div>
  );
};
