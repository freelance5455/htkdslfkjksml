import React from 'react';

interface BrandLogoProps {
  variant?: 'horizontal' | 'square';
  size?: 'sm' | 'md' | 'lg';
  showSlogan?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'horizontal',
  size = 'md',
  showSlogan = false,
}) => {
  const iconDims =
    size === 'lg' ? 'w-11 h-11' : size === 'sm' ? 'w-7 h-7' : 'w-9 h-9';

  const svgMark = (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${iconDims} shrink-0`}
      aria-hidden="true"
    >
      <rect
        width="40"
        height="40"
        rx="10"
        className="fill-[#0B1020] dark:fill-[#151D2E]"
      />
      <rect
        x="1"
        y="1"
        width="38"
        height="38"
        rx="9"
        stroke="#6366F1"
        strokeOpacity="0.45"
        strokeWidth="1.4"
      />
      {/* HTML bracket */}
      <path
        d="M13 14.5L8.5 20L13 25.5"
        stroke="#F8FAFC"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Conversion arrow */}
      <path
        d="M16 20H22"
        stroke="#6366F1"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path
        d="M19.8 17.5L22.5 20L19.8 22.5"
        stroke="#6366F1"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Android device screen */}
      <rect
        x="24.5"
        y="11"
        width="8.5"
        height="18"
        rx="2.4"
        stroke="#3B82F6"
        strokeWidth="2"
      />
      <circle cx="28.75" cy="25.5" r="1.1" fill="#22C55E" />
    </svg>
  );

  if (variant === 'square') {
    return svgMark;
  }

  return (
    <div className="inline-flex items-center gap-2.5 shrink-0">
      {svgMark}
      <div className="leading-none text-left">
        <div
          className={`font-display font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] whitespace-nowrap ${
            size === 'lg' ? 'text-lg' : size === 'sm' ? 'text-sm' : 'text-[15px]'
          }`}
        >
          HTML TO APK STUDIO
        </div>
        {showSlogan && (
          <div className="mt-1 text-[11px] font-medium text-slate-500 dark:text-[#94A3B8] whitespace-nowrap">
            Your Website. Your Android App.
          </div>
        )}
      </div>
    </div>
  );
};
