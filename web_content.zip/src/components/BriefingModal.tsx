import React from 'react';
import { BodycamSettings, GameHudState, LightingMood } from '../game/types';

interface BriefingModalProps {
  hud: GameHudState;
  settings: BodycamSettings;
  mobileControlsEnabled: boolean;
  onToggleMobileControls: () => void;
  onUpdateSettings: (next: Partial<BodycamSettings>) => void;
  onStart: () => void;
  onResume: () => void;
  onRestart: () => void;
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const BriefingModal: React.FC<BriefingModalProps> = ({
  hud,
  settings,
  mobileControlsEnabled,
  onToggleMobileControls,
  onUpdateSettings,
  onStart,
  onResume,
  onRestart,
}) => {
  if (hud.phase === 'playing') return null;

  const atmospheres: { id: LightingMood; title: string; desc: string }[] = [
    {
      id: 'flare_night',
      title: 'Night Magnesium Flare',
      desc: 'Swaying parachute flares cutting across wet mud, sandbags, and razor wire.',
    },
    {
      id: 'dawn_mist',
      title: 'Overcast Dawn Mist',
      desc: 'Cold morning fog diffusing across the cratered trench line.',
    },
    {
      id: 'blackout',
      title: 'Power Blackout',
      desc: 'Pitch-black night trench lit strictly by your weapon light and breach strobes.',
    },
  ];

  return (
    <div className="fixed inset-0 z-20 flex items-center justify-center bg-zinc-950/75 p-4 sm:p-8 overflow-y-auto">
      <div className="w-full max-w-2xl rounded border border-zinc-700/80 bg-zinc-950/95 p-5 sm:p-8 text-zinc-100 shadow-2xl">
        {/* Header */}
        <div className="border-b border-zinc-800 pb-4 sm:pb-5">
          <div className="font-mono-tech mb-1.5 text-xs tracking-wider text-amber-400">
            AXON-TAC BODYCAM · SECTOR 04 FORWARD TRENCH LINE
          </div>
          <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight text-white">
            {hud.phase === 'briefing' && 'Modern Trench Clearance'}
            {hud.phase === 'paused' && 'Deployment Paused'}
            {hud.phase === 'extracted' && 'Trench Cleared & Extracted'}
            {hud.phase === 'down' && 'Signal Lost — Officer Down'}
          </h1>
          <p className="mt-2 max-w-xl text-xs sm:text-sm leading-relaxed text-zinc-400">
            {hud.phase === 'briefing' &&
              'Assault the zig-zag trench network and timber dugouts, neutralize hostile patrol drones, and recover all three encrypted field radios before extracting at the North Command Pillbox.'}
            {hud.phase === 'paused' &&
              'Bodycam recording remains active. Adjust optical calibration, switch touch controls, or resume trench clearance.'}
            {hud.phase === 'extracted' &&
              'All field radio ciphers uploaded at the North Command Pillbox. Trench sector secured.'}
            {hud.phase === 'down' &&
              'Vital telemetry dropped to zero in the trench sector. Redeploy from the staging approach trench.'}
          </p>
        </div>

        {/* Summary Metrics for Extracted / Down / Paused */}
        {(hud.phase === 'extracted' || hud.phase === 'down' || hud.phase === 'paused') && (
          <div className="font-mono-tech mt-4 grid grid-cols-3 gap-4 border-b border-zinc-800 pb-4 text-xs">
            <div>
              <div className="text-zinc-500">Elapsed Time</div>
              <div className="mt-1 text-base sm:text-lg font-semibold text-white">
                {formatDuration(hud.elapsedSeconds)}
              </div>
            </div>
            <div>
              <div className="text-zinc-500">Radios Secured</div>
              <div className="mt-1 text-base sm:text-lg font-semibold text-cyan-400">
                {hud.drivesCollected} / {hud.totalDrives}
              </div>
            </div>
            <div>
              <div className="text-zinc-500">Hostiles Cleared</div>
              <div className="mt-1 text-base sm:text-lg font-semibold text-amber-400">
                {hud.hostilesNeutralized} / {hud.totalHostiles}
              </div>
            </div>
          </div>
        )}

        {/* Lighting Preset Picker (Briefing & Paused) */}
        {(hud.phase === 'briefing' || hud.phase === 'paused') && (
          <div className="mt-4 sm:mt-5">
            <div className="mb-2 text-xs font-medium text-zinc-300">
              Battlefield Atmosphere
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
              {atmospheres.map((atm) => {
                const active = settings.lightingMood === atm.id;
                return (
                  <button
                    key={atm.id}
                    type="button"
                    onClick={() => onUpdateSettings({ lightingMood: atm.id })}
                    className={`rounded border p-2.5 sm:p-3 text-left transition-colors ${
                      active
                        ? 'border-amber-500 bg-amber-500/10 text-white'
                        : 'border-zinc-800 bg-zinc-900/70 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                    }`}
                  >
                    <div className="text-xs font-semibold text-zinc-100">{atm.title}</div>
                    <div className="mt-1 text-[11px] leading-snug text-zinc-400">{atm.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Controls Reference */}
        <div className="font-mono-tech mt-4 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-1.5 border-t border-zinc-800 pt-3.5 text-[11px] text-zinc-400">
          {mobileControlsEnabled ? (
            <>
              <div>
                <span className="text-zinc-200 font-semibold">Left Stick</span> Move / Sprint
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">Right Pad</span> Drag Aim
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">FIRE / AIM</span> Combat
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">Utility</span> Light / Crouch
              </div>
            </>
          ) : (
            <>
              <div>
                <span className="text-zinc-200 font-semibold">WASD</span> Move
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">LMB / RMB</span> Fire / Aim
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">F / N</span> Light / IR Mode
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">E / R</span> Interact / Reload
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">Shift</span> Sprint
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">C / Ctrl</span> Crouch
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">Q / Z</span> Tactical Lean
              </div>
              <div>
                <span className="text-zinc-200 font-semibold">H / P</span> Toggle Dock / Pause
              </div>
            </>
          )}
        </div>

        {/* Primary Action Footer */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onToggleMobileControls}
            className={`whitespace-nowrap shrink-0 rounded border px-3.5 py-2 text-xs font-medium transition-colors ${
              mobileControlsEnabled
                ? 'border-cyan-500/70 bg-cyan-500/15 text-cyan-300'
                : 'border-zinc-700 bg-zinc-900 text-zinc-300 hover:text-white'
            }`}
          >
            {mobileControlsEnabled ? 'Mobile Touch: On' : 'Mobile Touch: Off'}
          </button>

          <div className="flex items-center gap-3">
            {hud.phase === 'briefing' && (
              <button
                type="button"
                onClick={onStart}
                className="whitespace-nowrap shrink-0 rounded bg-amber-500 px-6 py-2.5 text-sm font-semibold text-zinc-950 transition-colors hover:bg-amber-400"
              >
                Enter Trench
              </button>
            )}

            {hud.phase === 'paused' && (
              <>
                <button
                  type="button"
                  onClick={onRestart}
                  className="whitespace-nowrap shrink-0 rounded border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-sm font-medium text-zinc-200 transition-colors hover:bg-zinc-800"
                >
                  Restart Mission
                </button>
                <button
                  type="button"
                  onClick={onResume}
                  className="whitespace-nowrap shrink-0 rounded bg-amber-500 px-6 py-2.5 text-sm font-semibold text-zinc-950 transition-colors hover:bg-amber-400"
                >
                  Resume
                </button>
              </>
            )}

            {(hud.phase === 'extracted' || hud.phase === 'down') && (
              <button
                type="button"
                onClick={onRestart}
                className="whitespace-nowrap shrink-0 rounded bg-amber-500 px-6 py-2.5 text-sm font-semibold text-zinc-950 transition-colors hover:bg-amber-400"
              >
                Redeploy
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
