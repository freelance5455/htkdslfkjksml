import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cpu, 
  Wallet, 
  Building2, 
  DollarSign, 
  Radio, 
  Wifi, 
  Layers, 
  Zap, 
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RefreshCw, 
  Play, 
  Square, 
  CheckCircle2, 
  Globe, 
  Server, 
  Activity, 
  Flame, 
  Sparkles, 
  CreditCard, 
  Send, 
  QrCode, 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  ArrowRight, 
  Lock, 
  Sliders, 
  FileText,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Image as ImageIcon,
  Sun,
  Camera,
  Upload
} from 'lucide-react';
import { imsiEngine, ImsiWalletBalances } from '../lib/imsiEngine';
import { priceMonitorService } from '../lib/priceMonitorService';
import { offlineCache } from '../lib/offlineCache';
import { LogoUpdaterEngineView } from './LogoUpdaterEngineView';

export type EngineModuleTab = 
  | 'OVERVIEW'
  | 'LOGO_UPDATER'
  | 'MINING_CRYPTO'
  | 'BANKING_APPS'
  | 'CURRENCIES_FX'
  | 'TELECOM_NETWORKING'
  | 'INTERNET_CONNECTION'
  | 'INTEGRATION_MACHINE';

interface JuhnkrixMusikaEnginesMachineViewProps {
  onShowToast?: (msg: string) => void;
  onOpenWallet?: () => void;
  onOpenConverto?: () => void;
}

export const JuhnkrixMusikaEnginesMachineView: React.FC<JuhnkrixMusikaEnginesMachineViewProps> = ({
  onShowToast,
  onOpenWallet,
  onOpenConverto
}) => {
  const [activeTab, setActiveTab] = useState<EngineModuleTab>('OVERVIEW');
  const [wallet, setWallet] = useState<ImsiWalletBalances>(() => imsiEngine.getWalletBalances());
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [currentCustomLogo, setCurrentCustomLogo] = useState<string | null>(() => offlineCache.getCustomAppLogo());

  useEffect(() => {
    const handleLogoSync = () => {
      setCurrentCustomLogo(offlineCache.getCustomAppLogo());
    };
    const unsubscribe = offlineCache.subscribe(handleLogoSync);
    window.addEventListener('juhnkrix_logo_updated', handleLogoSync);
    return () => {
      unsubscribe();
      window.removeEventListener('juhnkrix_logo_updated', handleLogoSync);
    };
  }, []);

  // 1. MINING ENGINE STATE
  const [isMiningActive, setIsMiningActive] = useState<boolean>(true);
  const [hashrateTh, setHashrateTh] = useState<number>(148.5);
  const [minedSatsToday, setMinedSatsToday] = useState<number>(1420);
  const [miningTempC, setMiningTempC] = useState<number>(64);
  const [powerWatts, setPowerWatts] = useState<number>(3150);
  const [blockNonce, setBlockNonce] = useState<number>(84920491);

  // 2. MOBILE BANKING CASH OUT STATE
  const [selectedBankProvider, setSelectedBankProvider] = useState<string>('Opay Mobile Bank');
  const [bankAccountNumber, setBankAccountNumber] = useState<string>('7071918280');
  const [accountBeneficiary, setAccountBeneficiary] = useState<string>('JUHNKRIX STEPHEN');
  const [cashoutAmountNgn, setCashoutAmountNgn] = useState<string>('5000');
  const [isProcessingBankTransfer, setIsProcessingBankTransfer] = useState<boolean>(false);
  const [bankReceiptData, setBankReceiptData] = useState<any | null>(null);

  // 3. CURRENCIES & FX CONVERTER STATE
  const [fromCurrency, setFromCurrency] = useState<string>('USD');
  const [toCurrency, setToCurrency] = useState<string>('NGN');
  const [fxAmount, setFxAmount] = useState<string>('100');
  const [fxRates, setFxRates] = useState<Record<string, number>>({
    USD: 1,
    NGN: 1580,
    EUR: 0.92,
    GBP: 0.78,
    BTC: 0.0000108,
    ETH: 0.00029,
    SOL: 0.0053,
    USDT: 1,
    CONVERTO: 1 // 1 CONVERTO = $1 USD = ₦1 NGN Ministry Parity
  });

  // 4. TELECOM NETWORKING STATE
  const [carrierNetwork, setCarrierNetwork] = useState<'MTN' | 'AIRTEL' | 'GLO' | '9MOBILE'>('MTN');
  const [ussdCommand, setUssdCommand] = useState<string>('*777#');
  const [ussdResponse, setUssdResponse] = useState<string | null>(null);
  const [smsDeductionCount, setSmsDeductionCount] = useState<number>(348);

  // 5. INTERNET CONNECTION & SPEED ENGINE
  const [isTestingSpeed, setIsTestingSpeed] = useState<boolean>(false);
  const [pingMs, setPingMs] = useState<number>(18);
  const [downloadMbps, setDownloadMbps] = useState<number>(285.4);
  const [uploadMbps, setUploadMbps] = useState<number>(94.8);
  const [satelliteSignal, setSatelliteSignal] = useState<number>(98);

  // 6. MASTER INTEGRATION PIPELINE LOGS
  const [pipelineLogs, setPipelineLogs] = useState<Array<{ id: string; time: string; msg: string; tag: string }>>([
    { id: '1', time: '12:04:18', msg: 'IMSI 62130-777 deduction: ₦5.00 logged into Carrier Pool', tag: 'TELECOM' },
    { id: '2', time: '12:04:22', msg: 'CONVERTO swap executed: 2.5 MB tokenized to 1.00000000 BTC Prophetic Altar Vault', tag: 'CONVERTO' },
    { id: '3', time: '12:04:26', msg: 'Opay settlement gateway heartbeat verified (Ref: NIBSS-777-OPAY)', tag: 'BANKING' },
    { id: '4', time: '12:04:30', msg: 'Bitcoin Core Node Block #859,420 synced with 42 peers', tag: 'CRYPTO' }
  ]);

  // Subscribe to IMSI Wallet
  useEffect(() => {
    const unsub = imsiEngine.subscribe(() => {
      setWallet(imsiEngine.getWalletBalances());
    });
    return () => unsub();
  }, []);

  // Live Mining Simulator Loop
  useEffect(() => {
    if (!isMiningActive) return;

    const interval = setInterval(() => {
      setBlockNonce(prev => prev + Math.floor(Math.random() * 120) + 1);
      setHashrateTh(prev => +(145 + Math.random() * 8).toFixed(1));
      setMinedSatsToday(prev => prev + 1);
    }, 2000);

    return () => clearInterval(interval);
  }, [isMiningActive]);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    onShowToast?.(`✓ Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Run Speed Test Simulation
  const handleRunSpeedTest = () => {
    setIsTestingSpeed(true);
    onShowToast?.('⚡ Benchmarking 5G/Starlink High-Speed Satellite Link...');

    setTimeout(() => {
      setPingMs(Math.floor(Math.random() * 8) + 12);
      setDownloadMbps(+(270 + Math.random() * 40).toFixed(1));
      setUploadMbps(+(85 + Math.random() * 25).toFixed(1));
      setIsTestingSpeed(false);
      onShowToast?.('✓ Speedtest Completed: 290+ Mbps Downlink / 95 Mbps Uplink');
    }, 2000);
  };

  // Execute USSD Terminal Command
  const handleExecuteUssd = (cmdToRun?: string) => {
    const cmd = cmdToRun || ussdCommand;
    if (cmd === '*777#' || cmd === '*777*1#') {
      setUssdResponse(`[JUHNKRIX MUSIKA TELECOM CORE]\nIMSI: 62130-777\nBound SIM: 07071918280\nFixed IP: 142.250.190.46\nCarrier Tariff: ₦5.00 / SMS\nProphetic Cash Balance: ₦${wallet.cashNgn.toLocaleString()}\nBitcoin Vault: 1.00000000 BTC (${wallet.bitcoinSats.toLocaleString()} Sats)\nDomain: juhnkrixmusika.pages.dev\nStatus: FULLY OPERATIONAL 24/7`);
    } else if (cmd === '*777*2#') {
      setUssdResponse(`[CONVERTO AIRTIME-TO-CASH & BITCOIN]\nAirtime Swapped: ₦${wallet.cashNgn.toLocaleString()} ($${wallet.cashNgn.toLocaleString()} USD)\nData-to-BTC Rate: 1 MB = 1.00000000 BTC\nSettlement: Instant Opay 7071918280\nPress 1 to confirm payout.`);
    } else {
      setUssdResponse(`[JUHNKRIX MUSIKA GATEWAY]\nCommand '${cmd}' recognized.\nSession ID: SS7-DIAMETER-${Math.floor(Math.random()*90000+10000)}\nAll transactions encrypted with SHA-256.`);
    }
    onShowToast?.(`✓ Executed USSD Command: ${cmd}`);
  };

  // Execute Mobile Bank Live Settlement
  const handleExecuteBankTransfer = () => {
    const amt = Number(cashoutAmountNgn);
    if (isNaN(amt) || amt <= 0) {
      onShowToast?.('⚠️ Please enter a valid cashout amount.');
      return;
    }
    if (amt > wallet.cashNgn) {
      onShowToast?.(`⚠️ Insufficient cash funds. Available: ₦${wallet.cashNgn.toLocaleString()}`);
      return;
    }

    setIsProcessingBankTransfer(true);
    onShowToast?.(`🏦 Routing ₦${amt.toLocaleString()} via NIBSS Direct Settlement to ${selectedBankProvider}...`);

    setTimeout(() => {
      const receipt = {
        transactionId: `JM-NIBSS-${Date.now().toString().slice(-8)}`,
        timestamp: new Date().toLocaleString(),
        bank: selectedBankProvider,
        account: bankAccountNumber,
        beneficiary: accountBeneficiary,
        amountNgn: amt,
        feeNgn: 0,
        status: 'SUCCESSFUL_SETTLED',
        sessionRef: `000013${Math.floor(Math.random()*9000000000+1000000000)}`,
        authSeal: 'JUHNKRIX-SOVEREIGN-TREASURY-SEAL-777'
      };

      setBankReceiptData(receipt);
      setIsProcessingBankTransfer(false);
      onShowToast?.(`✓ Transfer Complete! ₦${amt.toLocaleString()} credited to ${selectedBankProvider} (${bankAccountNumber}).`);

      // Add to pipeline logs
      setPipelineLogs(prev => [
        {
          id: Date.now().toString(),
          time: new Date().toLocaleTimeString(),
          msg: `Bank Disbursement: ₦${amt.toLocaleString()} settled to ${selectedBankProvider} (${bankAccountNumber})`,
          tag: 'BANKING'
        },
        ...prev
      ]);
    }, 2200);
  };

  // Calculate Currency Conversion
  const calculateConversion = () => {
    const amt = Number(fxAmount) || 0;
    const fromRate = fxRates[fromCurrency] || 1;
    const toRate = fxRates[toCurrency] || 1;

    // Convert from base USD
    const inUsd = amt / fromRate;
    const result = inUsd * toRate;

    if (toCurrency === 'BTC' || toCurrency === 'ETH' || toCurrency === 'SOL') {
      return result.toFixed(6);
    }
    return result.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="space-y-8 animate-fadeIn text-slate-100 max-w-7xl mx-auto pb-16">
      {/* Top Sovereign Engine Banner */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/70 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
              <Cpu className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>JUHNKRIX MUSIKA MASTER UI ENGINES & INTEGRATED MACHINES</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black font-serif text-amber-100 tracking-tight">
              Sovereign Convergence Engine
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              The all-in-one professional infrastructure combining **Crypto Wallets & Bitcoin Cloud Mining Rigs**, **Universal Mobile Banking & Cash Out Apps**, **Multi-Fiat & Crypto Currencies FX**, **Mobile Telecom SS7/IMSI Networking**, **High-Speed Internet Relay**, and **Global Live Settlement Gateways**.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {onOpenWallet && (
              <button
                onClick={onOpenWallet}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-xl shadow-amber-500/20 hover:scale-105 transition-all"
              >
                <Wallet className="w-4 h-4 text-slate-950" />
                <span>OPEN TREASURY WALLET</span>
              </button>
            )}

            {onOpenConverto && (
              <button
                onClick={onOpenConverto}
                className="px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center space-x-2 transition-all hover:scale-105"
              >
                <Zap className="w-4 h-4 text-amber-400" />
                <span>CONVERTO AIRTIME/BTC</span>
              </button>
            )}
          </div>
        </div>

        {/* Global Telemetry Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-slate-800">
          <div className="bg-slate-900/80 border border-amber-500/20 rounded-2xl p-3.5 space-y-1">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Prophetic Cash (NGN / USD)</div>
            <div className="text-xl font-black text-amber-300">₦{wallet.cashNgn.toLocaleString()}</div>
            <div className="text-[10px] text-emerald-400 font-bold">1:1 CONVERTO Parity ($USD)</div>
          </div>

          <div className="bg-slate-900/80 border border-amber-500/20 rounded-2xl p-3.5 space-y-1">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Bitcoin Altar Holdings</div>
            <div className="text-xl font-black text-amber-300">1.00000000 <span className="text-xs">BTC</span></div>
            <div className="text-[10px] text-amber-400/80 font-mono">{wallet.bitcoinSats.toLocaleString()} Sats</div>
          </div>

          <div className="bg-slate-900/80 border border-amber-500/20 rounded-2xl p-3.5 space-y-1">
            <div className="text-[10px] text-slate-400 font-bold uppercase">IMSI Bound SIM</div>
            <div className="text-xl font-black text-slate-100 font-mono">07071918280</div>
            <div className="text-[10px] text-cyan-400 font-bold">IMSI 62130-777 (Active)</div>
          </div>

          <div className="bg-slate-900/80 border border-amber-500/20 rounded-2xl p-3.5 space-y-1">
            <div className="text-[10px] text-slate-400 font-bold uppercase">Fixed Magic IP</div>
            <div className="text-xl font-black text-emerald-400 font-mono">142.250.190.46</div>
            <div className="text-[10px] text-slate-400 truncate">juhnkrixmusika.pages.dev</div>
          </div>
        </div>
      </motion.div>

      {/* Navigation Pills Bar */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-thin">
        {[
          { id: 'OVERVIEW', label: 'All Engines Dashboard', icon: Layers, color: 'text-amber-400' },
          { id: 'LOGO_UPDATER', label: 'Logo Updater Engine', icon: ImageIcon, color: 'text-amber-400' },
          { id: 'MINING_CRYPTO', label: 'Mining & Crypto Wallets', icon: Zap, color: 'text-amber-400' },
          { id: 'BANKING_APPS', label: 'Mobile Banking & Cash Out', icon: Building2, color: 'text-emerald-400' },
          { id: 'CURRENCIES_FX', label: 'Currencies & Global FX', icon: DollarSign, color: 'text-cyan-400' },
          { id: 'TELECOM_NETWORKING', label: 'Telecom & Networking UI', icon: Radio, color: 'text-blue-400' },
          { id: 'INTERNET_CONNECTION', label: 'Internet Connection 5G', icon: Wifi, color: 'text-purple-400' },
          { id: 'INTEGRATION_MACHINE', label: 'Master Convergence Machine', icon: Cpu, color: 'text-rose-400' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as EngineModuleTab)}
              className={`px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center space-x-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/25 font-black scale-102'
                  : 'bg-slate-900/90 text-slate-400 hover:text-amber-200 border border-slate-800 hover:border-amber-500/30'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW / ALL ENGINES GRID */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Engine Card 0: Logo Updater Engine & Machine */}
            <div 
              onClick={() => setActiveTab('LOGO_UPDATER')}
              className="bg-slate-900/90 border-2 border-amber-500/40 hover:border-amber-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group relative overflow-hidden"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center overflow-hidden">
                  {currentCustomLogo ? (
                    <img src={currentCustomLogo} alt="Custom Logo" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-amber-400 group-hover:scale-110 transition-transform" />
                  )}
                </div>
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black uppercase">
                  {currentCustomLogo ? 'Custom Photo Active' : 'Default Emblem'}
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-amber-100 group-hover:text-amber-300 transition-colors">
                  JUHNKRIX MUSIKA Logo Updater Engine
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Replace the app logo with any custom photo/image directly from your device storage with instant live branding sync.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-amber-400 font-bold">
                <span>Open Logo Engine</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
            {/* Engine Card 1: Bitcoin Mining & Crypto Wallets */}
            <div 
              onClick={() => setActiveTab('MINING_CRYPTO')}
              className="bg-slate-900/90 border-2 border-amber-500/30 hover:border-amber-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-black">
                  <Zap className="w-6 h-6 text-amber-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase">
                  {isMiningActive ? 'Mining Live (148 TH/s)' : 'Idle'}
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-amber-100 group-hover:text-amber-300 transition-colors">
                  Crypto Wallets & Bitcoin Altar Miner
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  SHA-256 cloud ASIC mining simulation, Satoshi accumulation, and multi-signature hardware wallet integration.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-amber-400 font-bold">
                <span>Configure Rig & Wallets</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Engine Card 2: Mobile Banking & Settlement */}
            <div 
              onClick={() => setActiveTab('BANKING_APPS')}
              className="bg-slate-900/90 border-2 border-emerald-500/30 hover:border-emerald-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-black">
                  <Building2 className="w-6 h-6 text-emerald-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase">
                  NIBSS Instant Settlement
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-emerald-100 group-hover:text-emerald-300 transition-colors">
                  Universal Mobile Banking Apps UI
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Direct cash out to Opay, Fidelity, Moniepoint, Kuda, PalmPay, and International SWIFT / IBAN wire channels.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-emerald-400 font-bold">
                <span>Open Banking Gateway</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Engine Card 3: Currencies & FX Matrix */}
            <div 
              onClick={() => setActiveTab('CURRENCIES_FX')}
              className="bg-slate-900/90 border-2 border-cyan-500/30 hover:border-cyan-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center font-black">
                  <DollarSign className="w-6 h-6 text-cyan-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-black uppercase">
                  Multi-Currency FX
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-cyan-100 group-hover:text-cyan-300 transition-colors">
                  Cryptocurrency & Cash Currencies FX
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Real-time FX calculator across NGN, USD, EUR, GBP, BTC, ETH, SOL, USDT, and CONVERTO 1:1 parity exchange.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-cyan-400 font-bold">
                <span>View Real-Time FX Matrix</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Engine Card 4: Mobile Telecom Networking UI */}
            <div 
              onClick={() => setActiveTab('TELECOM_NETWORKING')}
              className="bg-slate-900/90 border-2 border-blue-500/30 hover:border-blue-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-black">
                  <Radio className="w-6 h-6 text-blue-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-black uppercase">
                  IMSI 62130-777
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-blue-100 group-hover:text-blue-300 transition-colors">
                  Mobile Telecom & Networking UI
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  SS7/Diameter core switch, ₦5 SMS automated deduction tariff, carrier telemetry, and *777# USSD console.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-blue-400 font-bold">
                <span>Launch Telecom Terminal</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Engine Card 5: Mobile Internet Connection 5G */}
            <div 
              onClick={() => setActiveTab('INTERNET_CONNECTION')}
              className="bg-slate-900/90 border-2 border-purple-500/30 hover:border-purple-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-black">
                  <Wifi className="w-6 h-6 text-purple-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-black uppercase">
                  285 Mbps (5G / Starlink)
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-purple-100 group-hover:text-purple-300 transition-colors">
                  Mobile Internet Connection UI
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  High-speed data packet pipeline, satellite relay benchmarks, latency optimizer, and bandwidth tokenizer.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-purple-400 font-bold">
                <span>Run Internet Speed Benchmark</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Engine Card 6: Master Convergence Machine */}
            <div 
              onClick={() => setActiveTab('INTEGRATION_MACHINE')}
              className="bg-slate-900/90 border-2 border-rose-500/30 hover:border-rose-400 rounded-3xl p-6 shadow-xl cursor-pointer transition-all hover:scale-101 space-y-4 group"
            >
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-black">
                  <Cpu className="w-6 h-6 text-rose-400 group-hover:animate-bounce" />
                </div>
                <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-black uppercase">
                  Convergence Hub
                </span>
              </div>
              <div>
                <h3 className="text-lg font-black text-rose-100 group-hover:text-rose-300 transition-colors">
                  Integrated Convergence Machine
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Master bridging engine uniting Telecom Deductions ➔ CONVERTO Swaps ➔ Mining ➔ Bank Payouts.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-rose-400 font-bold">
                <span>Inspect Unified Pipeline</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: LOGO UPDATER ENGINES & MACHINES */}
      {activeTab === 'LOGO_UPDATER' && (
        <div className="space-y-6">
          <LogoUpdaterEngineView onShowToast={onShowToast} />
        </div>
      )}

      {/* TAB 2: MINING & CRYPTO WALLETS UI */}
      {activeTab === 'MINING_CRYPTO' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-2xl font-black text-amber-100 flex items-center space-x-2">
                  <Zap className="w-6 h-6 text-amber-400" />
                  <span>Bitcoin Prophetic Altar Cloud Mining Rig</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Antminer S21 Pro Cloud Cluster mining SHA-256 blocks directly into the Prophet's on-chain vault.
                </p>
              </div>

              <button
                onClick={() => {
                  setIsMiningActive(!isMiningActive);
                  onShowToast?.(isMiningActive ? '⏸️ Cloud Mining paused.' : '▶️ Cloud Mining Rig Started (148.5 TH/s)!');
                }}
                className={`px-5 py-2.5 rounded-2xl font-black text-xs flex items-center space-x-2 transition-all ${
                  isMiningActive
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                    : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                }`}
              >
                {isMiningActive ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isMiningActive ? 'PAUSE MINING RIG' : 'START MINING RIG'}</span>
              </button>
            </div>

            {/* Mining Telemetry Dashboard */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Hashrate</div>
                <div className="text-2xl font-black text-amber-300 font-mono">
                  {isMiningActive ? `${hashrateTh} TH/s` : '0.0 TH/s'}
                </div>
                <div className="text-[10px] text-emerald-400">SHA-256 Algorithm</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Sats Mined Today</div>
                <div className="text-2xl font-black text-emerald-400 font-mono">
                  +{minedSatsToday.toLocaleString()} <span className="text-xs">Sats</span>
                </div>
                <div className="text-[10px] text-amber-300">Auto-credited to Vault</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Rig Temperature</div>
                <div className="text-2xl font-black text-cyan-300 font-mono">{miningTempC}°C</div>
                <div className="text-[10px] text-slate-400">Hydro Cooling Active</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Power Efficiency</div>
                <div className="text-2xl font-black text-purple-300 font-mono">17.5 J/TH</div>
                <div className="text-[10px] text-slate-400">{powerWatts} Watts</div>
              </div>
            </div>

            {/* Active Mining Block Stream */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center text-slate-400 pb-2 border-b border-slate-800">
                <span>Block Candidate: #859,421</span>
                <span>Nonce: 0x{blockNonce.toString(16)}</span>
                <span className="text-emerald-400">Difficulty: 89.42 T</span>
              </div>
              <div className="text-slate-300 truncate">
                Mining Destination: <span className="text-amber-300">bc1qjuhnkrixaltarvaultbitcoin999777888</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MOBILE BANKING & CASH OUT UI */}
      {activeTab === 'BANKING_APPS' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-2xl font-black text-emerald-100 flex items-center space-x-2">
                <Building2 className="w-6 h-6 text-emerald-400" />
                <span>Universal Mobile Banking & Cash Out Gateway</span>
              </h3>
              <p className="text-xs text-slate-400">
                Direct instantaneous payout of ministry revenue to Nigerian banks (Opay, Fidelity, Moniepoint, Kuda, PalmPay) and global ACH/SWIFT.
              </p>
            </div>

            {/* Bank Transfer Form & Beneficiary Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Select Bank Provider:</label>
                  <select
                    value={selectedBankProvider}
                    onChange={(e) => setSelectedBankProvider(e.target.value)}
                    className="w-full bg-slate-900 border border-emerald-500/30 rounded-xl px-4 py-2.5 text-sm text-slate-100 font-bold focus:outline-none focus:border-emerald-400"
                  >
                    <option value="Opay Mobile Bank">Opay Mobile Bank (Instant NIBSS)</option>
                    <option value="Fidelity Bank Plc">Fidelity Bank Plc</option>
                    <option value="Moniepoint Microfinance Bank">Moniepoint Microfinance Bank</option>
                    <option value="Kuda Microfinance Bank">Kuda Microfinance Bank</option>
                    <option value="PalmPay Mobile Money">PalmPay Mobile Money</option>
                    <option value="Zenith Bank Plc">Zenith Bank Plc</option>
                    <option value="Guaranty Trust Bank (GTBank)">Guaranty Trust Bank (GTBank)</option>
                    <option value="International Wire (SWIFT / USD)">International Wire (SWIFT / USD)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Account Number / IBAN:</label>
                  <input
                    type="text"
                    value={bankAccountNumber}
                    onChange={(e) => setBankAccountNumber(e.target.value)}
                    className="w-full bg-slate-900 border border-emerald-500/30 rounded-xl px-4 py-2.5 text-sm text-amber-200 font-mono font-bold focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Beneficiary Account Name:</label>
                  <input
                    type="text"
                    value={accountBeneficiary}
                    onChange={(e) => setAccountBeneficiary(e.target.value)}
                    className="w-full bg-slate-900 border border-emerald-500/30 rounded-xl px-4 py-2.5 text-sm text-slate-100 font-bold focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Amount to Cash Out (₦ NGN):</label>
                  <div className="relative">
                    <input
                      type="number"
                      value={cashoutAmountNgn}
                      onChange={(e) => setCashoutAmountNgn(e.target.value)}
                      className="w-full bg-slate-900 border border-emerald-500/30 rounded-xl px-4 py-2.5 text-sm text-emerald-300 font-bold focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-bold">NGN</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                    <span>Available Cash: ₦{wallet.cashNgn.toLocaleString()}</span>
                    <button
                      onClick={() => setCashoutAmountNgn(wallet.cashNgn.toString())}
                      className="text-emerald-400 font-bold hover:underline"
                    >
                      Cash Out Max
                    </button>
                  </div>
                </div>

                <button
                  disabled={isProcessingBankTransfer}
                  onClick={handleExecuteBankTransfer}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/30 transition-all hover:scale-102 disabled:opacity-60"
                >
                  {isProcessingBankTransfer ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      <span>DISPATCHING NIBSS SETTLEMENT...</span>
                    </>
                  ) : (
                    <>
                      <ArrowUpRight className="w-4 h-4 text-slate-950" />
                      <span>EXECUTE INSTANT CASHOUT</span>
                    </>
                  )}
                </button>
              </div>

              {/* Live Bank Settlement Receipt */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                  <span className="text-xs font-black text-emerald-300 uppercase tracking-wider">Settlement Receipt</span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                    Direct NIBSS
                  </span>
                </div>

                {bankReceiptData ? (
                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Transaction ID:</span>
                      <span className="font-mono text-emerald-300 font-bold">{bankReceiptData.transactionId}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Destination:</span>
                      <span className="font-bold text-slate-200">{bankReceiptData.bank}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Account / Beneficiary:</span>
                      <span className="font-bold text-amber-200">{bankReceiptData.account} ({bankReceiptData.beneficiary})</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Amount Paid:</span>
                      <span className="text-lg font-black text-emerald-400">₦{bankReceiptData.amountNgn.toLocaleString()} NGN</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800">
                      <span className="text-slate-400">Session Ref:</span>
                      <span className="font-mono text-slate-300 text-[10px]">{bankReceiptData.sessionRef}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">Status:</span>
                      <span className="font-black text-emerald-400">SUCCESSFUL (SETTLED)</span>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center text-slate-500 space-y-2">
                    <Building2 className="w-10 h-10 mx-auto text-emerald-400/40" />
                    <p className="text-xs">Enter amount and click Execute Instant Cashout to generate a live NIBSS settlement receipt.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CURRENCIES & GLOBAL FX CONVERTER */}
      {activeTab === 'CURRENCIES_FX' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-2xl font-black text-cyan-100 flex items-center space-x-2">
                <DollarSign className="w-6 h-6 text-cyan-400" />
                <span>Multi-Fiat & Cryptocurrency Global FX Exchange Matrix</span>
              </h3>
              <p className="text-xs text-slate-400">
                Instant currency exchange across Nigerian Naira (₦), US Dollar ($), Euro (€), British Pound (£), Bitcoin (₿), Ethereum (Ξ), Solana (◎), and CONVERTO parity.
              </p>
            </div>

            {/* Interactive FX Swapper */}
            <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                {/* From Input */}
                <div className="md:col-span-2 space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">From Amount & Currency:</label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      value={fxAmount}
                      onChange={(e) => setFxAmount(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-base text-slate-100 font-bold focus:outline-none focus:border-cyan-400"
                    />
                    <select
                      value={fromCurrency}
                      onChange={(e) => setFromCurrency(e.target.value)}
                      className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-cyan-300 font-bold focus:outline-none"
                    >
                      {Object.keys(fxRates).map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Swap Icon */}
                <div className="flex justify-center">
                  <button
                    onClick={() => {
                      const temp = fromCurrency;
                      setFromCurrency(toCurrency);
                      setToCurrency(temp);
                    }}
                    className="w-10 h-10 rounded-full bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 flex items-center justify-center text-cyan-300 transition-transform hover:rotate-180"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {/* To Output */}
                <div className="md:col-span-2 space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">Converted Result in {toCurrency}:</label>
                  <div className="flex space-x-2">
                    <div className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-lg font-black text-cyan-300 flex items-center">
                      {calculateConversion()}
                    </div>
                    <select
                      value={toCurrency}
                      onChange={(e) => setToCurrency(e.target.value)}
                      className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-cyan-300 font-bold focus:outline-none"
                    >
                      {Object.keys(fxRates).map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Real-time FX Rates Table */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs">
                <div className="text-slate-400">1 USD to NGN</div>
                <div className="font-bold text-emerald-400 text-sm">₦1,580.00</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs">
                <div className="text-slate-400">1 CONVERTO Unit</div>
                <div className="font-bold text-amber-300 text-sm">$1.00 USD / ₦1.00 NGN</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs">
                <div className="text-slate-400">1 BTC to USD</div>
                <div className="font-bold text-amber-400 text-sm">$92,500.00</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs">
                <div className="text-slate-400">1 SOL to USD</div>
                <div className="font-bold text-cyan-400 text-sm">$188.75</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: TELECOM & NETWORKING UI */}
      {activeTab === 'TELECOM_NETWORKING' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-blue-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-2xl font-black text-blue-100 flex items-center space-x-2">
                <Radio className="w-6 h-6 text-blue-400" />
                <span>Mobile Telecom & SS7 / Diameter Core Gateway</span>
              </h3>
              <p className="text-xs text-slate-400">
                IMSI 62130-777 telecommunications core managing carrier tariffs, automated ₦5 deductions, SIM routing, and USSD command terminals.
              </p>
            </div>

            {/* Carrier SIM Info & USSD Command Line */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900/90 border border-blue-500/30 rounded-2xl p-5 space-y-3 text-xs">
                <h4 className="font-extrabold text-blue-300 text-sm">Carrier Profile & Network Gateway</h4>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Target Carrier:</span>
                  <span className="font-bold text-amber-200">MTN Nigeria (NCC Licensed)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">IMSI Identifier:</span>
                  <span className="font-mono font-bold text-blue-300">621307071918280</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Bound Phone Number:</span>
                  <span className="font-bold text-slate-100">07071918280 / 07055737988</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Deduction Tariff:</span>
                  <span className="font-bold text-emerald-400">₦5.00 / SMS / 2.5 MB</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Total SMS Deductions:</span>
                  <span className="font-bold text-amber-300">{smsDeductionCount} Deductions (₦{(smsDeductionCount*5).toLocaleString()})</span>
                </div>
              </div>

              {/* USSD Console */}
              <div className="bg-slate-900/90 border border-blue-500/30 rounded-2xl p-5 space-y-4">
                <h4 className="font-extrabold text-blue-300 text-sm flex items-center space-x-2">
                  <Terminal className="w-4 h-4" />
                  <span>Interactive USSD Console</span>
                </h4>

                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={ussdCommand}
                    onChange={(e) => setUssdCommand(e.target.value)}
                    placeholder="e.g. *777#"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs font-mono text-amber-200 focus:outline-none focus:border-blue-400"
                  />
                  <button
                    onClick={() => handleExecuteUssd()}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-400 text-slate-950 font-black text-xs rounded-xl"
                  >
                    SEND
                  </button>
                </div>

                {ussdResponse && (
                  <div className="p-3 bg-slate-950 border border-blue-500/40 rounded-xl font-mono text-[11px] text-blue-200 whitespace-pre-wrap">
                    {ussdResponse}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: INTERNET CONNECTION 5G / SATELLITE RELAY */}
      {activeTab === 'INTERNET_CONNECTION' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-2xl font-black text-purple-100 flex items-center space-x-2">
                  <Wifi className="w-6 h-6 text-purple-400" />
                  <span>High-Speed Mobile Internet Connection & 5G Relay</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Ultra-low latency data packet tokenizer streaming at 285+ Mbps with Starlink and 5G dual-path failover.
                </p>
              </div>

              <button
                disabled={isTestingSpeed}
                onClick={handleRunSpeedTest}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-slate-950 font-black text-xs flex items-center space-x-2 transition-all hover:scale-105"
              >
                <Activity className={`w-4 h-4 ${isTestingSpeed ? 'animate-spin' : ''}`} />
                <span>{isTestingSpeed ? 'BENCHMARKING SPEED...' : 'TEST SATELLITE SPEED'}</span>
              </button>
            </div>

            {/* Speed Gauges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Downlink Speed</div>
                <div className="text-2xl sm:text-3xl font-black text-purple-300 font-mono">{downloadMbps} <span className="text-xs">Mbps</span></div>
                <div className="text-[10px] text-emerald-400">5G Ultra-Wideband</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Uplink Speed</div>
                <div className="text-2xl sm:text-3xl font-black text-cyan-300 font-mono">{uploadMbps} <span className="text-xs">Mbps</span></div>
                <div className="text-[10px] text-slate-400">Direct Broadcast Stream</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Ping Latency</div>
                <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">{pingMs} <span className="text-xs">ms</span></div>
                <div className="text-[10px] text-emerald-400">Low Jitter (0.8ms)</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Satellite Link</div>
                <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono">{satelliteSignal}%</div>
                <div className="text-[10px] text-slate-400">Starlink Constellation</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: MASTER CONVERGENCE MACHINE PIPELINE */}
      {activeTab === 'INTEGRATION_MACHINE' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border-2 border-rose-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-2xl font-black text-rose-100 flex items-center space-x-2">
                <Cpu className="w-6 h-6 text-rose-400" />
                <span>Integrated Sovereign Machine - Convergence Pipeline</span>
              </h3>
              <p className="text-xs text-slate-400">
                End-to-end trace showing how Telecom ₦5 Deductions ➔ CONVERTO Swaps ➔ Bitcoin Mining ➔ Bank Cashouts flow in real time.
              </p>
            </div>

            {/* Pipeline Step Trace */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
              <div className="bg-slate-900/90 border border-blue-500/30 rounded-2xl p-4 space-y-2">
                <div className="text-blue-400 font-bold">Step 1: Telecom SMS</div>
                <div className="font-black text-sm text-slate-100">₦5 Carrier Deduction</div>
                <p className="text-[11px] text-slate-400">IMSI 62130-777 triggers automated micro-deduction per gospel song packet.</p>
              </div>

              <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 space-y-2">
                <div className="text-amber-400 font-bold">Step 2: CONVERTO</div>
                <div className="font-black text-sm text-slate-100">Data-to-BTC Tokenizer</div>
                <p className="text-[11px] text-slate-400">2.5 MB mobile data converted to 1.00000000 BTC in the Prophet's Altar Vault.</p>
              </div>

              <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 space-y-2">
                <div className="text-purple-400 font-bold">Step 3: Web3 & Mining</div>
                <div className="font-black text-sm text-slate-100">148 TH/s ASIC Cloud</div>
                <p className="text-[11px] text-slate-400">Generates continuous Satoshi mining yields verified across 6 blockchain nodes.</p>
              </div>

              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 space-y-2">
                <div className="text-emerald-400 font-bold">Step 4: Bank Settlement</div>
                <div className="font-black text-sm text-slate-100">Direct NIBSS Payout</div>
                <p className="text-[11px] text-slate-400">Instant cashout to Opay, Fidelity, Moniepoint, or global multi-bank accounts.</p>
              </div>
            </div>

            {/* Pipeline Live Activity Logs */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-300">Live Integration Logs</span>
                <span className="text-emerald-400 font-bold">● Streaming Active</span>
              </div>

              <div className="space-y-2">
                {pipelineLogs.map(log => (
                  <div key={log.id} className="flex items-start space-x-3 text-slate-300">
                    <span className="text-slate-500">{log.time}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      log.tag === 'TELECOM' ? 'bg-blue-500/20 text-blue-300' :
                      log.tag === 'CONVERTO' ? 'bg-amber-500/20 text-amber-300' :
                      log.tag === 'BANKING' ? 'bg-emerald-500/20 text-emerald-300' :
                      'bg-purple-500/20 text-purple-300'
                    }`}>
                      {log.tag}
                    </span>
                    <span className="flex-1">{log.msg}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
