import { useState, useEffect } from 'react';
import {
  Bot,
  Mic,
  Send,
  Sparkles,
  Compass,
  CheckCircle2,
  Calendar,
  MapPin,
  Users,
  DollarSign,
  ArrowRight,
  ArrowLeft,
  Volume2,
  VolumeX,
  Plane,
  Building2,
  ShieldCheck,
  Luggage,
  Copy,
  Check,
  RotateCcw,
  Sliders,
  Zap,
} from 'lucide-react';
import { Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';
import {
  parseTravelRequest,
  generateTripSuggestion,
  getSamplePrompts,
  ParsedTravelRequest,
  AITripSuggestion,
} from '../../utils/aiAssistant';

interface AIAssistantScreenProps {
  language: Language;
  currency: Currency;
  onBookPlan: (planDetails: { destination: string; budget: number }) => void;
}

export function AIAssistantScreen({ language, currency, onBookPlan }: AIAssistantScreenProps) {
  const isRTL = language === 'ar';
  const t = translations[language];

  // Initial state with a default Istanbul plan
  const initialInput =
    language === 'ar'
      ? 'أريد السفر إلى إسطنبول لمدة 7 أيام لشخصين بميزانية 250,000 دج'
      : 'Trip to Istanbul for 7 days, 2 persons, budget 250,000 DZD';

  const [inputText, setInputText] = useState(initialInput);
  const [isListening, setIsListening] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [voiceProgress, setVoiceProgress] = useState(0);
  const [copied, setCopied] = useState(false);
  const [audioFeedbackEnabled, setAudioFeedbackEnabled] = useState(true);

  // Parsed request state & generated trip suggestion
  const [parsedData, setParsedData] = useState<ParsedTravelRequest>(() =>
    parseTravelRequest(initialInput, language)
  );

  const [tripSuggestion, setTripSuggestion] = useState<AITripSuggestion>(() =>
    generateTripSuggestion(parseTravelRequest(initialInput, language), language)
  );

  // Simulated Voice Input Handler
  const handleVoiceToggle = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    setIsListening(true);
    setVoiceProgress(0);

    const voiceSamplesAr = [
      'أريد رحلة عائلية إلى دبي لمدة 6 أيام لـ 4 أشخاص بميزانية مميزة',
      'عمرة مباركة لشخصين في شهر رمضان المبارك مع فندق قريب من الحرم',
      'رحلة شهر عسل إلى المالديف 6 ليالٍ في فيلا فوق الماء لشخصين',
      'جولة استكشافية في باريس 5 أيام لشخصين مع زيارة برج إيفل ومتحف اللوفر',
      'عطلة سياحية إلى إسطنبول لمدة أسبوع لشخصين بميزانية 280,000 دج',
    ];

    const voiceSamplesEn = [
      'Family vacation in Dubai for 6 days for 4 persons with premium package',
      'Umrah pilgrimage for 2 travelers in Ramadan with 5-star hotel near Haram',
      'Honeymoon in Maldives 6 nights in an overwater villa for couple',
      'Explore Paris 5 days package for 2 travelers with Eiffel Tower and Louvre',
      'Trip to Istanbul for 7 days, 2 travelers, budget 280,000 DZD',
    ];

    const pool = language === 'ar' ? voiceSamplesAr : voiceSamplesEn;
    const selectedVoiceText = pool[Math.floor(Math.random() * pool.length)];

    let p = 0;
    const interval = setInterval(() => {
      p += 20;
      setVoiceProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        setIsListening(false);
        setInputText(selectedVoiceText);
        triggerAnalysis(selectedVoiceText);
      }
    }, 350);
  };

  const triggerAnalysis = (textToParse: string) => {
    if (!textToParse.trim()) return;
    setIsAnalyzing(true);

    setTimeout(() => {
      const parsed = parseTravelRequest(textToParse, language);
      const suggestion = generateTripSuggestion(parsed, language);
      setParsedData(parsed);
      setTripSuggestion(suggestion);
      setIsAnalyzing(false);
    }, 700);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    triggerAnalysis(inputText);
  };

  const handlePromptSelect = (prompt: string) => {
    setInputText(prompt);
    triggerAnalysis(prompt);
  };

  const handleCopySummary = () => {
    if (!tripSuggestion) return;
    const text = `${tripSuggestion.title}\n${tripSuggestion.subtitle}\n📍 ${tripSuggestion.destination}\n🗓️ ${tripSuggestion.durationDays} days\n👥 ${tripSuggestion.travelersCount} travelers\n💰 Total: ${formatPrice(tripSuggestion.totalCostDZD, currency, language)}`;
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const samplePrompts = getSamplePrompts(language);

  return (
    <div className="space-y-6 pb-24">
      {/* Robot / AI Cyberpunk HUD Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#0c1838] via-[#08122a] to-[#040816] border border-cyan-500/30 shadow-[0_0_40px_rgba(0,102,255,0.25)]">
        {/* Glow backdrop grid */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #00f0ff 1px, transparent 0)`,
            backgroundSize: '20px 20px',
          }}
        />

        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_10px_#00f0ff]" />
              <span className="text-xs font-mono text-cyan-400 font-semibold tracking-wider uppercase">
                TAKI-Bot Neural Core v4.2
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white">
              {t.aiAssistantTitle}
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-sm">
              {isRTL
                ? 'تحدث بالصوت أو اكتب تفاصيل رحلتك، وسيقوم المساعد الذكي باستخراج الوجهة، التواريخ، المسافرين والميزانية وتقديم عرض سفر فوري.'
                : 'Speak or type your travel vision. The AI parses destination, dates, travelers, and budget into instant tailored packages.'}
            </p>
          </div>

          {/* Holographic Robot Avatar */}
          <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-500 to-indigo-600 p-0.5 shadow-[0_0_30px_rgba(0,240,255,0.4)] shrink-0">
            <div className="w-full h-full bg-[#050b1e] rounded-2xl flex flex-col items-center justify-center relative overflow-hidden">
              {/* Antenna Glow */}
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 mb-1 shadow-[0_0_8px_#00f0ff] animate-ping" />

              {/* Robot Face Visual */}
              <div className="relative">
                <Bot
                  className={`w-9 h-9 transition-transform ${
                    isListening
                      ? 'text-rose-400 scale-110'
                      : isAnalyzing
                      ? 'text-amber-400 animate-spin'
                      : 'text-cyan-300'
                  }`}
                />
                {/* Glowing Robot LED Eyes */}
                <div className="absolute top-[14px] left-[10px] w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#00f0ff] animate-pulse" />
                <div className="absolute top-[14px] right-[10px] w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#00f0ff] animate-pulse" />
              </div>

              {/* Status scanline */}
              <div className="text-[8px] font-mono font-bold text-cyan-400 mt-1 uppercase tracking-tighter">
                {isListening ? 'REC_AUDIO' : isAnalyzing ? 'PARSING' : 'ONLINE'}
              </div>

              <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 to-transparent pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Audio Waveform Simulator when listening */}
        {isListening && (
          <div className="mt-4 p-3 rounded-2xl bg-rose-950/40 border border-rose-500/40 flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="text-xs font-mono text-rose-300 font-semibold">
                {isRTL ? 'جاري الاستماع إلى صوتك وتحليله...' : 'Listening & transcribing voice audio...'}
              </span>
            </div>

            {/* Audio frequency wave visualizer */}
            <div className="flex items-end gap-1 h-6">
              {[12, 24, 16, 28, 14, 20, 26, 18, 22, 14, 28, 16].map((h, i) => (
                <div
                  key={i}
                  className="w-1 bg-gradient-to-t from-rose-500 to-cyan-400 rounded-full animate-pulse"
                  style={{
                    height: `${Math.max(6, (h * (voiceProgress + 20)) / 100)}px`,
                    animationDuration: `${0.3 + (i % 4) * 0.1}s`,
                  }}
                />
              ))}
            </div>
          </div>
        )}

        {/* Quick Suggested Prompts Pills */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <p className="text-[11px] text-slate-400 mb-2 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isRTL ? 'نماذج لطلبات السفر السريعة:' : 'Suggested Quick Prompts:'}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {samplePrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handlePromptSelect(prompt)}
                className="text-xs bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-400/50 text-slate-200 px-3 py-1.5 rounded-xl transition-all active:scale-[0.98] text-right"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Box with Voice & Send Controls */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#091129] border border-cyan-500/30 shadow-[0_4px_25px_rgba(0,102,255,0.15)] focus-within:border-cyan-400">
          {/* Simulated Voice Input Toggle Button */}
          <button
            type="button"
            onClick={handleVoiceToggle}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all shrink-0 ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_#f43f5e]'
                : 'bg-slate-800/90 text-cyan-400 hover:bg-slate-700 hover:text-white'
            }`}
            aria-label="Voice Input"
            title={isRTL ? 'تفعيل البحث الصوتي التجريبي' : 'Simulated Voice Input'}
          >
            <Mic className="w-5 h-5" />
          </button>

          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={
              isListening
                ? (isRTL ? 'تحدث الآن... TAKI-Bot يستمع' : 'Speak now... TAKI-Bot is listening')
                : t.aiInputPlaceholder
            }
            className="flex-1 bg-transparent px-3 py-2 text-xs md:text-sm text-white placeholder-slate-500 outline-none"
          />

          <button
            type="submit"
            disabled={isAnalyzing || !inputText.trim()}
            className="w-11 h-11 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white flex items-center justify-center hover:brightness-110 active:scale-[0.96] transition-all disabled:opacity-40 shrink-0"
            aria-label="Submit Prompt"
          >
            {isAnalyzing ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : isRTL ? (
              <ArrowLeft className="w-5 h-5" />
            ) : (
              <ArrowRight className="w-5 h-5" />
            )}
          </button>
        </div>
      </form>

      {/* Extracted Entity Parameters HUD (Destination, Dates, Travelers, Budget) */}
      <div className="p-4 rounded-3xl bg-[#060c20] border border-cyan-500/20 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              {isRTL ? 'البيانات المستخلصة بالذكاء الاصطناعي (AI Parsed Entities)' : 'AI Parsed Travel Entities'}
            </h3>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded-full">
            {isRTL ? 'دقة التحليل:' : 'Confidence:'} {parsedData.confidenceScore}%
          </span>
        </div>

        {/* The 4 Parsed Parameters Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
          {/* 1. Destination */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 hover:border-cyan-500/40 transition-colors">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isRTL ? '1. الوجهة' : '1. Destination'}</span>
            </div>
            <p className="text-xs font-bold text-white truncate">{parsedData.destination}</p>
            <p className="text-[10px] text-cyan-400 truncate">{parsedData.destinationCountry}</p>
          </div>

          {/* 2. Dates & Duration */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 hover:border-blue-500/40 transition-colors">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>{isRTL ? '2. المدة والمواعيد' : '2. Dates / Duration'}</span>
            </div>
            <p className="text-xs font-bold text-white truncate">{parsedData.datesText}</p>
            <p className="text-[10px] text-blue-400 truncate">
              {parsedData.durationDays} {isRTL ? 'أيام / ليالٍ' : 'days / nights'}
            </p>
          </div>

          {/* 3. Travelers */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 hover:border-emerald-500/40 transition-colors">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
              <Users className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isRTL ? '3. المسافرون' : '3. Travelers'}</span>
            </div>
            <p className="text-xs font-bold text-white truncate">{parsedData.travelersLabel}</p>
            <p className="text-[10px] text-emerald-400 truncate">
              {parsedData.travelersCount} {isRTL ? 'مسافرين' : 'travelers'}
            </p>
          </div>

          {/* 4. Budget */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 hover:border-amber-500/40 transition-colors">
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <span>{isRTL ? '4. الميزانية' : '4. Budget'}</span>
            </div>
            <p className="text-xs font-bold text-amber-300 truncate">
              {formatPrice(parsedData.budgetEstimatedDZD, currency, language)}
            </p>
            <p className="text-[10px] text-slate-400 uppercase font-mono">
              {parsedData.budgetSpecified ? (isRTL ? 'محددة بالطلب' : 'Explicit') : (isRTL ? 'تقدير ذكي' : 'Estimated')} • {parsedData.budgetTier}
            </p>
          </div>
        </div>
      </div>

      {/* Generated Sample Trip Suggestion Card */}
      {tripSuggestion && (
        <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-400/30 text-white space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold">
                  {isRTL ? 'اقتراح الرحلة الذكي المُخصص' : 'AI Tailored Trip Recommendation'}
                </span>
              </div>
              <h2 className="text-base md:text-lg font-black text-white">
                {tripSuggestion.title}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {tripSuggestion.subtitle}
              </p>
            </div>

            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/70 border border-cyan-800/80 px-2.5 py-1 rounded-xl shrink-0">
              {tripSuggestion.tripStyle}
            </span>
          </div>

          {/* Core Flight & Hotel Recommendation Strip */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Flight Card */}
            <div className="p-3.5 rounded-2xl bg-[#070e24] border border-cyan-500/30 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5 font-semibold">
                  <Plane className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isRTL ? 'رحلة الطيران المقترحة' : 'Flight Recommendation'}</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/70 px-2 py-0.5 rounded">
                  {tripSuggestion.flight.cabin}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-white">{tripSuggestion.flight.airline}</p>
                  <p className="text-[11px] text-slate-400">{tripSuggestion.flight.route}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-cyan-300">
                    {formatPrice(tripSuggestion.flight.priceDZD, currency, language)}
                  </p>
                  <p className="text-[10px] text-slate-500">{isRTL ? 'للفرد الواحد' : 'per person'}</p>
                </div>
              </div>
            </div>

            {/* Hotel Card */}
            <div className="p-3.5 rounded-2xl bg-[#070e24] border border-blue-500/30 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5 font-semibold">
                  <Building2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>{isRTL ? 'الإقامة الفندقية' : 'Hotel Accommodation'}</span>
                </span>
                <span className="text-[10px] text-amber-400 font-bold">
                  {'★'.repeat(tripSuggestion.hotel.stars)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-white">{tripSuggestion.hotel.name}</p>
                  <p className="text-[11px] text-slate-400">{tripSuggestion.hotel.roomType}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-blue-300">
                    {formatPrice(tripSuggestion.hotel.pricePerNightDZD, currency, language)}
                  </p>
                  <p className="text-[10px] text-slate-500">{isRTL ? 'لكل ليلة' : 'per night'}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Highlights Checklist */}
          <div className="space-y-2 pt-1">
            <p className="text-xs text-cyan-400 font-bold flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5" />
              <span>{isRTL ? 'أبرز محطات البرنامج السياحي:' : 'Itinerary Highlights:'}</span>
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {tripSuggestion.timelineHighlights.map(h => (
                <div
                  key={h.day}
                  className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex items-start gap-2.5 text-xs"
                >
                  <span className="text-base shrink-0">{h.icon}</span>
                  <div>
                    <p className="font-bold text-white">
                      {isRTL ? `اليوم ${h.day}:` : `Day ${h.day}:`} {h.title}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{h.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Included Services Checklist */}
          <div className="space-y-1.5 pt-1">
            <p className="text-xs text-slate-300 font-semibold mb-1">
              {isRTL ? 'الخدمات المشمولة في هذه الباقة:' : 'Services Included in Package:'}
            </p>
            {tripSuggestion.includedServices.slice(0, 4).map((service, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{service}</span>
              </div>
            ))}
          </div>

          {/* Smart Tip from Robot */}
          <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-800/60 text-xs text-cyan-200 flex items-start gap-2.5">
            <Bot className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{tripSuggestion.smartTip}</p>
          </div>

          {/* Price Breakdown & Total Cost */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#070e24] to-[#0a1638] border border-cyan-500/30 flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-[11px] text-slate-400 block">
                {isRTL ? 'التكلفة الإجمالية المقدرة للرحلة بالكامل:' : 'Estimated Total Package Cost:'}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl md:text-2xl font-black text-cyan-300">
                  {formatPrice(tripSuggestion.totalCostDZD, currency, language)}
                </span>
                <span className="text-xs text-slate-400">
                  ({formatPrice(tripSuggestion.costPerPersonDZD, currency, language)} / {isRTL ? 'فرد' : 'person'})
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopySummary}
                className="px-3 py-2 rounded-xl bg-slate-800/90 border border-slate-700 hover:border-slate-600 text-slate-300 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
                title={isRTL ? 'نسخ ملخص العرض' : 'Copy proposal summary'}
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? (isRTL ? 'تم النسخ' : 'Copied') : (isRTL ? 'نسخ الملخص' : 'Copy')}</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  onBookPlan({
                    destination: tripSuggestion.destination,
                    budget: tripSuggestion.totalCostDZD,
                  })
                }
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_20px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
              >
                <span>{t.aiBookThisPlan}</span>
                {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
