import { useState } from 'react';
import { Bot, Mic, Send, Sparkles, Compass, CheckCircle2, Calendar, MapPin, Users, DollarSign, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { formatPrice } from '../../utils/currency';

interface AIAssistantScreenProps {
  language: Language;
  currency: Currency;
  onBookPlan: (planDetails: { destination: string; budget: number }) => void;
}

interface GeneratedPlan {
  destination: string;
  country: string;
  durationDays: number;
  travelers: number;
  estimatedCostDZD: number;
  flightRecommendation: string;
  hotelRecommendation: string;
  tripStyle: string;
  highlights: string[];
}

export function AIAssistantScreen({ language, currency, onBookPlan }: AIAssistantScreenProps) {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<GeneratedPlan | null>({
    destination: 'إسطنبول (Istanbul)',
    country: 'تركيا',
    durationDays: 7,
    travelers: 2,
    estimatedCostDZD: 485000,
    flightRecommendation: 'Turkish Airlines (مباشر ALG - IST)',
    hotelRecommendation: 'Swissôtel The Bosphorus (5 نجوم مع إطلالة البوسفور)',
    tripStyle: 'سياحة فاخرة وتاريخية (Luxury & Culture)',
    highlights: [
      'جولة يخت مسائية خاصة في مضيق البوسفور',
      'زيارة آيا صوفيا وقصر توبكابي مع مرشد خاص',
      'يوم استجمام في جزر الأميرات',
      'جولة تسوق حصرية في مجمع استينيا بارك وزورلو',
      'تأمين السفر وتأشيرة سريعة مشمولة',
    ],
  });

  const t = translations[language];
  const isRTL = language === 'ar';

  const handleVoiceToggle = () => {
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      setInputText(
        language === 'ar'
          ? 'أريد السفر من الجزائر إلى إسطنبول لمدة 7 أيام لشخصين بميزانية مميزة'
          : 'Trip from Algiers to Istanbul for 7 days, 2 persons, premium package'
      );
    }, 1800);
  };

  const handlePromptSelect = (prompt: string) => {
    setInputText(prompt);
  };

  const handleGenerate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    setIsGenerating(true);

    setTimeout(() => {
      // Smart local rule-based parsing simulation
      const lower = inputText.toLowerCase();
      let destination = 'إسطنبول (Istanbul)';
      let country = 'تركيا';
      let durationDays = 7;
      let travelers = 2;
      let estimatedCostDZD = 420000;
      let flightRecommendation = 'Turkish Airlines direct';
      let hotelRecommendation = 'Swissôtel The Bosphorus';
      let tripStyle = 'رحلة استجمام واكتشاف';

      if (lower.includes('عمرة') || lower.includes('مكة') || lower.includes('omra')) {
        destination = 'مكة المكرمة والمدينة المنورة';
        country = 'المملكة العربية السعودية';
        durationDays = 14;
        travelers = 2;
        estimatedCostDZD = 780000;
        flightRecommendation = 'Saudia Airlines (الخطوط السعودية مباشرة)';
        hotelRecommendation = 'بولمان زمزم مكة + أوبروي المدينة';
        tripStyle = 'عمرة روحانية VIP';
      } else if (lower.includes('باريس') || lower.includes('paris') || lower.includes('فرنسا')) {
        destination = 'باريس (Paris)';
        country = 'فرنسا';
        durationDays = 5;
        travelers = 2;
        estimatedCostDZD = 560000;
        flightRecommendation = 'Air Algérie / Air France (ALG-CDG)';
        hotelRecommendation = 'Hôtel Plaza Athénée Paris';
        tripStyle = 'أناقة وعاصمة النور والتسوق';
      } else if (lower.includes('دبي') || lower.includes('dubai')) {
        destination = 'دبي (Dubai)';
        country = 'الإمارات العربية المتحدة';
        durationDays = 6;
        travelers = 2;
        estimatedCostDZD = 610000;
        flightRecommendation = 'طيران الإمارات Emirates direct';
        hotelRecommendation = 'Raffles The Palm Dubai';
        tripStyle = 'فخامة وشواطئ وفعاليات حديثة';
      } else if (lower.includes('مالديف') || lower.includes('maldives')) {
        destination = 'المالديف (Maldives)';
        country = 'جزر المالديف';
        durationDays = 6;
        travelers = 2;
        estimatedCostDZD = 890000;
        flightRecommendation = 'Qatar Airways (ALG - DOH - MLE)';
        hotelRecommendation = 'Overwater Villa Resort 5 Stars';
        tripStyle = 'استجمام مائي وشهر عسل الأحلام';
      }

      setGeneratedPlan({
        destination,
        country,
        durationDays,
        travelers,
        estimatedCostDZD,
        flightRecommendation,
        hotelRecommendation,
        tripStyle,
        highlights: [
          `رحلة طيران ذهاب وعودة مع ${flightRecommendation}`,
          `إقامة فندقية فاخرة في ${hotelRecommendation}`,
          'استقبال وتوديع خاص VIP في المطار',
          'برنامج سياحي مصمم خصيصاً مع سائق خاص',
          'دعم مخصص من وكيل Tourism By Taki 24/7',
        ],
      });

      setIsGenerating(false);
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#0c1838] via-[#08122a] to-[#040816] border border-cyan-500/30 shadow-[0_0_40px_rgba(0,102,255,0.25)]">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_10px_#00f0ff]" />
              <span className="text-xs font-mono text-cyan-400 font-semibold tracking-wider uppercase">
                TAKI-GO Neural Core
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white">
              {t.aiAssistantTitle}
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-sm">
              {t.aiAssistantDesc}
            </p>
          </div>

          {/* AI Robot Hologram Graphic */}
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-[0_0_25px_rgba(0,240,255,0.4)]">
            <div className="w-full h-full bg-[#070b1e] rounded-2xl flex items-center justify-center relative overflow-hidden">
              <Bot className="w-9 h-9 text-cyan-300 animate-bounce [animation-duration:3s]" />
              <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 to-transparent pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Quick Voice / Text Prompts Chips */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <p className="text-[11px] text-slate-400 mb-2">
            {language === 'ar' ? 'أمثلة لطلبات سريعة:' : 'Quick Suggested Prompts:'}
          </p>
          <div className="flex flex-wrap gap-2">
            {t.aiQuickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handlePromptSelect(prompt)}
                className="text-xs bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-400/50 text-slate-200 px-3 py-1.5 rounded-xl transition-all active:scale-[0.98] text-right"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Box with Voice & Send */}
      <form onSubmit={handleGenerate} className="relative">
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#091129] border border-cyan-500/30 shadow-[0_4px_25px_rgba(0,102,255,0.15)] focus-within:border-cyan-400">
          <button
            type="button"
            onClick={handleVoiceToggle}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all shrink-0 ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_#f43f5e]'
                : 'bg-slate-800/90 text-cyan-400 hover:bg-slate-700'
            }`}
            aria-label="Voice Input"
          >
            <Mic className="w-5 h-5" />
          </button>

          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={isListening ? t.aiVoiceListen : t.aiInputPlaceholder}
            className="flex-1 bg-transparent px-3 py-2 text-xs md:text-sm text-white placeholder-slate-500 outline-none"
          />

          <button
            type="submit"
            disabled={isGenerating || !inputText.trim()}
            className="w-11 h-11 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white flex items-center justify-center hover:brightness-110 active:scale-[0.96] transition-all disabled:opacity-40 shrink-0"
            aria-label="Submit Prompt"
          >
            {isGenerating ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : isRTL ? (
              <ArrowLeft className="w-5 h-5" />
            ) : (
              <ArrowRight className="w-5 h-5" />
            )}
          </button>
        </div>
      </form>

      {/* Generated Travel Package Card */}
      {generatedPlan && (
        <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-400/30 text-white space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <h2 className="text-sm font-bold text-white">{t.aiPlanReady}</h2>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/70 border border-cyan-800/80 px-2.5 py-0.5 rounded-full">
              {generatedPlan.tripStyle}
            </span>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t.destination}</span>
              </div>
              <p className="text-xs font-bold text-white truncate">{generatedPlan.destination}</p>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                <span>{language === 'ar' ? 'المدة' : 'Duration'}</span>
              </div>
              <p className="text-xs font-bold text-white">{generatedPlan.durationDays} {language === 'ar' ? 'أيام' : 'days'}</p>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'ar' ? 'المسافرون' : 'Travelers'}</span>
              </div>
              <p className="text-xs font-bold text-white">{generatedPlan.travelers} {language === 'ar' ? 'أشخاص' : 'persons'}</p>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'ar' ? 'التكلفة التقديرية' : 'Est. Total'}</span>
              </div>
              <p className="text-xs font-bold text-cyan-300">
                {formatPrice(generatedPlan.estimatedCostDZD, currency, language)}
              </p>
            </div>
          </div>

          {/* Recommendations Breakdown */}
          <div className="space-y-2 pt-1 text-xs">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between">
              <span className="text-slate-400">{t.flight}:</span>
              <span className="font-semibold text-white">{generatedPlan.flightRecommendation}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between">
              <span className="text-slate-400">{t.hotel}:</span>
              <span className="font-semibold text-white">{generatedPlan.hotelRecommendation}</span>
            </div>
          </div>

          {/* Highlights checklist */}
          <div className="space-y-1.5 pt-2">
            <p className="text-xs text-cyan-400 font-semibold mb-2">
              {language === 'ar' ? 'مميزات هذا البرنامج:' : 'Package Highlights:'}
            </p>
            {generatedPlan.highlights.map((h, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{h}</span>
              </div>
            ))}
          </div>

          {/* Direct Booking CTA */}
          <button
            onClick={() => onBookPlan({ destination: generatedPlan.destination, budget: generatedPlan.estimatedCostDZD })}
            className="w-full h-12 mt-2 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <span>{t.aiBookThisPlan}</span>
            {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </button>
        </div>
      )}
    </div>
  );
}
