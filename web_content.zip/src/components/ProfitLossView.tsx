import React from 'react';
import { PieChart, TrendingUp, TrendingDown, Layers, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Ledger, StockItem } from '../types/tally';
import { computeProfitAndLoss, formatCurrency } from '../utils/tallyEngine';

interface ProfitLossViewProps {
  ledgers: Ledger[];
  stockItems: StockItem[];
}

export const ProfitLossView: React.FC<ProfitLossViewProps> = ({ ledgers, stockItems }) => {
  const pnl = computeProfitAndLoss(ledgers, stockItems);

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 shadow-xs">
        <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
          Performance Statement
        </div>
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold">Profit & Loss Account</h2>
          <span className="text-[11px] text-emerald-200 font-mono">01-Apr-26 to 31-Mar-27</span>
        </div>
      </div>

      {/* Net Result Highlight Banner */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] uppercase tracking-wider font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Net Profit (for the period)</span>
            </div>
            <div className="text-xl font-bold font-mono text-emerald-700 dark:text-emerald-300 tabular-nums mt-0.5">
              {formatCurrency(pnl.netProfit)}
            </div>
          </div>
          <div className="text-right text-[11px] font-mono text-slate-500 dark:text-slate-400">
            <div>Gross Profit: {formatCurrency(pnl.grossProfit)}</div>
            <div>Expenses: {formatCurrency(pnl.indirectExpensesTotal)}</div>
          </div>
        </div>
      </div>

      {/* Main Breakdown */}
      <div className="p-3 space-y-4">
        {/* 1. TRADING ACCOUNT SECTION */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center justify-between">
            <span>Trading Account (Gross Margin)</span>
            <span className="text-[10px] font-normal text-slate-500">Sales & Cost of Goods</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs font-mono">
            {/* Sales (Cr) */}
            <div className="p-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-900 dark:text-white">Sales Accounts</div>
                <div className="text-[10px] text-slate-400">Gross Invoiced Revenue</div>
              </div>
              <span className="tabular-nums font-bold text-emerald-600 dark:text-emerald-400">
                +{formatCurrency(pnl.sales)}
              </span>
            </div>

            {/* Closing Stock (Cr) */}
            <div className="p-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-900 dark:text-white">Closing Stock</div>
                <div className="text-[10px] text-slate-400">Inventory valuation at cost</div>
              </div>
              <span className="tabular-nums font-bold text-emerald-600 dark:text-emerald-400">
                +{formatCurrency(pnl.closingStock)}
              </span>
            </div>

            {/* Less: Opening Stock (Dr) */}
            <div className="p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-700 dark:text-slate-300">Less: Opening Stock</div>
                <div className="text-[10px] text-slate-400">Opening Inventory b/f</div>
              </div>
              <span className="tabular-nums text-rose-600 dark:text-rose-400">
                -{formatCurrency(pnl.openingStock)}
              </span>
            </div>

            {/* Less: Purchases (Dr) */}
            <div className="p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-700 dark:text-slate-300">Less: Purchases Accounts</div>
                <div className="text-[10px] text-slate-400">Raw materials & goods bought</div>
              </div>
              <span className="tabular-nums text-rose-600 dark:text-rose-400">
                -{formatCurrency(pnl.purchases)}
              </span>
            </div>

            {/* Direct Expenses */}
            {pnl.directExpenses > 0 && (
              <div className="p-3 flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-700 dark:text-slate-300">Less: Direct Expenses</div>
                </div>
                <span className="tabular-nums text-rose-600">-{formatCurrency(pnl.directExpenses)}</span>
              </div>
            )}

            {/* GROSS PROFIT TOTAL */}
            <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/30 flex items-center justify-between font-bold text-sm text-emerald-800 dark:text-emerald-300">
              <span>GROSS PROFIT c/o</span>
              <span className="tabular-nums">{formatCurrency(pnl.grossProfit)}</span>
            </div>
          </div>
        </div>

        {/* 2. PROFIT & LOSS ACCOUNT SECTION */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center justify-between">
            <span>Operating & Overhead Expenses</span>
            <span className="text-[10px] font-normal text-slate-500">P&L Account</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs font-mono">
            {/* Gross Profit b/f */}
            <div className="p-3 flex items-center justify-between bg-slate-50 dark:bg-slate-800/40">
              <span className="font-semibold text-slate-800 dark:text-slate-200">Gross Profit b/f</span>
              <span className="tabular-nums font-bold text-emerald-600 dark:text-emerald-400">
                {formatCurrency(pnl.grossProfit)}
              </span>
            </div>

            {/* Indirect Expenses List */}
            <div className="p-3 space-y-2">
              <div className="font-bold text-slate-700 dark:text-slate-300 text-[11px] uppercase tracking-wider">
                Indirect Expenses
              </div>
              <div className="space-y-1.5 pl-2 text-[11px]">
                {pnl.indirectExpensesList.map((exp, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="text-slate-600 dark:text-slate-400">{exp.name}</span>
                    <span className="tabular-nums text-rose-600 dark:text-rose-400">
                      -{formatCurrency(exp.amount)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Total Overheads */}
            <div className="p-3 flex items-center justify-between text-slate-600 dark:text-slate-400">
              <span>Total Overheads:</span>
              <span className="tabular-nums font-semibold text-rose-600">
                -{formatCurrency(pnl.indirectExpensesTotal)}
              </span>
            </div>

            {/* NET PROFIT TOTAL */}
            <div className="p-3 bg-emerald-100/60 dark:bg-emerald-950/60 flex items-center justify-between font-extrabold text-base text-emerald-900 dark:text-emerald-200">
              <span>NET PROFIT (Transferred to Capital)</span>
              <span className="tabular-nums">{formatCurrency(pnl.netProfit)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
