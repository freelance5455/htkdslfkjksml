import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, AppSettings, Account } from '../types';
import {
  Camera,
  User,
  Sparkles,
  Check,
  ArrowRight,
  ArrowLeft,
  Globe2,
  Cloud,
  KeyRound,
  Eye,
  EyeOff,
  RefreshCw,
  Dices,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { getDualAccentInfo } from '../utils/theme';
import { cloudSyncService } from '../utils/cloudSync';

interface WelcomeOnboardingModalProps {
  isOpen: boolean;
  onComplete: (
    profile: UserProfile,
    openingAccounts?: Account[],
    selectedLanguage?: 'bn' | 'en',
    isSyncedLogin?: boolean
  ) => void;
  appSettings: AppSettings;
  onClose?: () => void;
  onUpdateSettings?: (newSettings: AppSettings) => void;
}

type OnboardingMode = 'create' | 'login' | null;

export const WelcomeOnboardingModal: React.FC<WelcomeOnboardingModalProps> = ({
  isOpen,
  onComplete,
  appSettings,
  onClose,
  onUpdateSettings,
}) => {
  // activeMode controls whether the form fields are expanded above the buttons:
  // null = initial welcome screen with the two distinct buttons
  // 'create' = Create New ID form expanded above
  // 'login' = Login and Sync form expanded above
  const [activeMode, setActiveMode] = useState<OnboardingMode>(null);

  // Create fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [userId, setUserId] = useState('');
  const [cloudPassword, setCloudPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<'bn' | 'en'>(appSettings.language || 'en');

  // Login fields
  const [loginUserId, setLoginUserId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // States for checking availability & loading
  const [isCheckingId, setIsCheckingId] = useState(false);
  const [idAvailability, setIdAvailability] = useState<'available' | 'taken' | 'invalid' | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const isLight = appSettings.themeMode === 'light';
  const isOled = appSettings.themeMode === 'oled';
  const isEn = selectedLanguage === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const handleLanguageChange = (lang: 'bn' | 'en') => {
    setSelectedLanguage(lang);
    if (onUpdateSettings) {
      onUpdateSettings({
        ...appSettings,
        language: lang,
        useBanglaDigits: lang === 'bn',
      });
    }
  };

  // Handle Photo Upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      setError(isEn ? 'Image size must be less than 3MB' : 'ছবি ৩ মেগাবাইটের কম হতে হবে');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setAvatarUrl(event.target?.result as string);
      setError('');
    };
    reader.readAsDataURL(file);
  };

  // Generate random user ID
  const handleGenerateRandomId = () => {
    const candidateName = firstName || 'user';
    const randId = cloudSyncService.generateSuggestedUserId(candidateName);
    setUserId(randId);
  };

  // Debounced real-time availability check so typing is never interrupted or erased
  useEffect(() => {
    if (!isOpen) return;

    const clean = userId.trim().replace(/\s+/g, '_');
    if (!clean) {
      setIdAvailability(null);
      setIsCheckingId(false);
      return;
    }

    if (clean.length < 3) {
      setIdAvailability('invalid');
      setIsCheckingId(false);
      return;
    }

    setIsCheckingId(true);
    const timer = setTimeout(async () => {
      try {
        const result = await cloudSyncService.checkUserIdAvailability(clean);
        if (result.available) {
          setIdAvailability('available');
          setError('');
        } else {
          setIdAvailability('taken');
        }
      } catch {
        setIdAvailability('available');
      } finally {
        setIsCheckingId(false);
      }
    }, 350);

    return () => clearTimeout(timer);
  }, [isOpen, userId]);

  // Handle Create New User ID Submit (triggered on second touch of Create New ID)
  const handleCreateSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!firstName.trim() || !lastName.trim()) {
      setError(
        isEn
          ? 'Please enter both First Name and Last Name'
          : 'অনুগ্রহ করে নামের প্রথম ও শেষ অংশ লিখুন'
      );
      return;
    }

    const cleanId = userId.trim().replace(/\s+/g, '_');
    if (cleanId.length < 3) {
      setError(isEn ? 'User ID must be at least 3 characters' : 'ইউজার আইডি কমপক্ষে ৩ অক্ষরের হতে হবে');
      return;
    }

    if (!cloudPassword || cloudPassword.trim().length < 4) {
      setError(
        isEn
          ? 'Sync password must be at least 4 characters'
          : 'সিঙ্ক পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const newProfile: UserProfile = {
        userId: cleanId,
        cloudPassword: cloudPassword.trim(),
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        avatarUrl: avatarUrl.trim(),
        isProfileCompleted: true,
        isCloudSynced: true,
        joinedDate: new Date().toISOString().split('T')[0],
      };

      const res = await cloudSyncService.register(cleanId, cloudPassword.trim(), newProfile);

      if (!res.success) {
        setError(res.error || 'Failed to register User ID');
        setIsSubmitting(false);
        return;
      }

      setSuccessMsg(
        isEn
          ? 'User ID created successfully! Synchronized with cloud.'
          : 'ইউজার আইডি তৈরি সম্পন্ন হয়েছে এবং ক্লাউডে সিঙ্ক নিশ্চিত করা হয়েছে।'
      );

      setTimeout(() => {
        onComplete(res.profile || newProfile, undefined, selectedLanguage, false);
      }, 500);
    } catch (err: any) {
      setError(err?.message || 'Error creating account');
      setIsSubmitting(false);
    }
  };

  // Handle Login / Restore with Existing User ID (triggered on second touch of Login and Sync)
  const handleLoginSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');
    setSuccessMsg('');

    const cleanId = loginUserId.trim().replace(/\s+/g, '_');
    const cleanPass = loginPassword.trim();

    if (!cleanId || !cleanPass) {
      setError(
        isEn
          ? 'Please enter both User ID and Password'
          : 'অনুগ্রহ করে ইউজার আইডি এবং পাসওয়ার্ড উভয়ই লিখুন'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await cloudSyncService.login(cleanId, cleanPass);

      if (!res.success) {
        setError(res.error || (isEn ? 'Login failed' : 'লগইন ব্যর্থ হয়েছে'));
        setIsSubmitting(false);
        return;
      }

      const txCount = res.data?.transactions?.length || 0;
      setSuccessMsg(
        isEn
          ? `Welcome back! Restored ${txCount} transactions and all your accounts.`
          : `স্বাগতম! আপনার পূর্বের ${txCount}টি লেনদেন ও সকল হিসাব সফলভাবে সিঙ্ক হয়েছে।`
      );

      setTimeout(() => {
        if (res.profile) {
          onComplete(res.profile, undefined, selectedLanguage, true);
        } else {
          const fallbackProfile: UserProfile = {
            userId: cleanId,
            cloudPassword: cleanPass,
            firstName: cleanId,
            lastName: '',
            isProfileCompleted: true,
            isCloudSynced: true,
            joinedDate: new Date().toISOString().split('T')[0],
          };
          onComplete(fallbackProfile, undefined, selectedLanguage, true);
        }
      }, 800);
    } catch (err: any) {
      setError(err?.message || 'Error logging in');
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isOled
          ? 'bg-black/90 backdrop-blur-md'
          : isLight
          ? 'bg-slate-900/60 backdrop-blur-sm'
          : 'bg-black/85 backdrop-blur-sm'
      } p-3 sm:p-4 animate-in fade-in duration-300`}
    >
      <div
        className={`w-full max-w-md ${
          isLight
            ? 'bg-white border-slate-200 text-slate-900 shadow-2xl'
            : isOled
            ? 'bg-black border-neutral-800 text-white shadow-2xl ring-1 ring-neutral-800'
            : 'bg-slate-900 border-slate-700 text-slate-100 shadow-2xl'
        } border rounded-3xl overflow-y-auto max-h-[94vh] p-5 sm:p-7 space-y-5`}
      >
        {/* Header with Icon & Greeting */}
        <div className="text-center space-y-1 relative">
          {activeMode !== null && (
            <button
              type="button"
              id="welcome-btn-back-to-options"
              onClick={() => {
                setActiveMode(null);
                setError('');
                setSuccessMsg('');
              }}
              className="absolute left-0 top-0 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              title={isEn ? 'Back to choices' : 'বিকল্প অপশনে ফিরে যান'}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div
            className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center shadow-lg transition-colors"
            style={{ backgroundColor: dualAccent.primary.hex, color: '#fff' }}
          >
            <Sparkles className="w-6 h-6" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight pt-1">
            {isEn ? 'Welcome to Onu Finance!' : 'Onu Finance-এ স্বাগতম!'}
          </h2>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Success Notification */}
        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2 font-bold">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* ========================================================
            INITIAL WELCOME SCREEN: TWO DISTINCT BUTTONS
           ======================================================== */}
        {activeMode === null && (
          <div className="pt-2 animate-in fade-in duration-300">
            {/* The Two Distinct Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                id="welcome-btn-initial-create"
                onClick={() => {
                  setActiveMode('create');
                  setError('');
                  setSuccessMsg('');
                }}
                className="flex-1 py-4 px-4 rounded-2xl text-white font-black text-sm sm:text-base shadow-xl flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer hover:brightness-110"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <User className="w-5 h-5" />
                <span>{isEn ? 'Create New ID' : 'ক্রিয়েট নিউ আইডি'}</span>
              </button>

              <button
                type="button"
                id="welcome-btn-initial-login"
                onClick={() => {
                  setActiveMode('login');
                  setError('');
                  setSuccessMsg('');
                }}
                className={`flex-1 py-4 px-4 rounded-2xl font-black text-sm sm:text-base border-2 shadow-lg flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-800 hover:bg-slate-100 hover:border-slate-400'
                    : isOled
                    ? 'bg-neutral-900 border-neutral-700 text-white hover:bg-neutral-800'
                    : 'bg-slate-800 border-slate-600 text-white hover:bg-slate-700'
                }`}
              >
                <Cloud className="w-5 h-5" style={{ color: dualAccent.primary.hex }} />
                <span>Login and Sync</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            MODE 1: CREATE NEW ID FORM (APPEARS ABOVE ON TAP)
           ======================================================== */}
        {activeMode === 'create' && (
          <form
            onSubmit={handleCreateSubmit}
            className="space-y-4 animate-in fade-in slide-in-from-top-3 duration-300"
          >
            {/* Profile Photo (Optional) */}
            <div className="flex justify-center pt-1">
              <div className="relative group">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-18 h-18 rounded-full border-4 shadow-md overflow-hidden flex items-center justify-center cursor-pointer transition transform hover:scale-105 ${
                    isLight
                      ? 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                      : isOled
                      ? 'border-neutral-800 bg-neutral-900 text-neutral-300 hover:border-neutral-700'
                      : 'border-slate-700 bg-slate-800 text-slate-300 hover:border-slate-500'
                  }`}
                  style={{ borderColor: avatarUrl ? dualAccent.primary.hex : undefined }}
                >
                  {avatarUrl ? (
                    <img src={avatarUrl} alt="User Profile" className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center justify-center p-2 text-center">
                      <User className="w-7 h-7 mb-0.5 opacity-70" />
                      <span className="text-[10px] font-bold opacity-80">
                        {isEn ? 'Photo' : 'ছবি'}
                      </span>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-0 right-0 p-1.5 rounded-full text-white shadow-lg cursor-pointer transform hover:scale-110 transition"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                  title={isEn ? 'Upload Photo' : 'ছবি আপলোড করুন'}
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            </div>

            {/* First Name and Last Name Inputs */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold mb-1 opacity-90">
                  {isEn ? 'First Name *' : 'ফার্স্ট নেম *'}
                </label>
                <input
                  type="text"
                  required
                  id="onboarding-first-name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder={isEn ? 'e.g. Onu' : 'যেমন: অনু'}
                  className={`w-full px-3 py-2.5 rounded-xl border text-sm font-medium ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : isOled
                      ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                  } outline-hidden focus:ring-2`}
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1 opacity-90">
                  {isEn ? 'Last Name *' : 'লাস্ট নেম *'}
                </label>
                <input
                  type="text"
                  required
                  id="onboarding-last-name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder={isEn ? 'e.g. Sultan' : 'যেমন: সুলতান'}
                  className={`w-full px-3 py-2.5 rounded-xl border text-sm font-medium ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : isOled
                      ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                  } outline-hidden focus:ring-2`}
                />
              </div>
            </div>

            {/* Create New ID / Your ID Input with Availability Indicator Inside Right */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold opacity-90 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                  <span>{isEn ? 'Create New ID / Your ID *' : 'ক্রিয়েট নিউ আইডি / ইউর আইডি *'}</span>
                </label>
                <button
                  type="button"
                  id="onboarding-random-id-btn"
                  onClick={handleGenerateRandomId}
                  className="text-[11px] font-bold flex items-center gap-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition cursor-pointer"
                  title={isEn ? 'Generate Random ID' : 'র্যান্ডম আইডি তৈরি করুন'}
                >
                  <Dices className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Random ID' : 'স্বয়ংক্রিয় আইডি'}</span>
                </button>
              </div>

              <div className="relative flex items-center">
                <input
                  type="text"
                  required
                  id="onboarding-user-id"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder={isEn ? 'Create ID' : 'ক্রিয়েট আইডি'}
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  className={`w-full px-3.5 py-2.5 pr-28 rounded-xl border text-sm font-mono font-bold placeholder:font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500 ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : isOled
                      ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                  } outline-hidden focus:ring-2`}
                />

                {/* এভেলেবেল শব্দ / Status Badge INSIDE the box at the right edge */}
                <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                  {isCheckingId ? (
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    </span>
                  ) : idAvailability === 'available' ? (
                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/15 dark:bg-emerald-400/15 border border-emerald-500/30 px-2 py-0.5 rounded-lg flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      <span>{isEn ? 'Available' : 'এভেলেবেল'}</span>
                    </span>
                  ) : idAvailability === 'taken' ? (
                    <span className="text-[11px] font-bold text-rose-500 bg-rose-500/15 border border-rose-500/30 px-2 py-0.5 rounded-lg flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 shrink-0" />
                      <span>{isEn ? 'Taken' : 'ব্যবহৃত'}</span>
                    </span>
                  ) : null}
                </div>
              </div>
            </div>

            {/* Sync Password Input */}
            <div>
              <label className="block text-xs font-bold mb-1 opacity-90 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                <span>{isEn ? 'Sync Password *' : 'সিন্ক পাসওয়ার্ড *'}</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  id="onboarding-sync-password"
                  value={cloudPassword}
                  onChange={(e) => setCloudPassword(e.target.value)}
                  placeholder={isEn ? 'Min 4 characters password' : 'কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড লিখুন'}
                  className={`w-full px-3 py-2.5 pr-10 rounded-xl border text-sm font-mono ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : isOled
                      ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                  } outline-hidden focus:ring-2`}
                />
                <button
                  type="button"
                  id="onboarding-toggle-password-btn"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Language Selection Option */}
            <div className="pt-1 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold opacity-90 flex items-center gap-1.5">
                  <Globe2 className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                  <span>{isEn ? 'Preferred Language' : 'পছন্দের ভাষা (Language)'}</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Bengali Option */}
                <button
                  type="button"
                  onClick={() => handleLanguageChange('bn')}
                  id="onboarding-lang-bn"
                  className={`py-2 px-3 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-between transition cursor-pointer ${
                    selectedLanguage === 'bn'
                      ? isLight
                        ? 'bg-slate-50 text-slate-900 shadow-xs'
                        : isOled
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-slate-800 text-white shadow-xs'
                      : isLight
                      ? 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      : isOled
                      ? 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                  style={{
                    borderColor: selectedLanguage === 'bn' ? dualAccent.primary.hex : undefined,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">🇧🇩</span>
                    <span className="font-bold">বাংলা</span>
                  </div>
                  {selectedLanguage === 'bn' && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: dualAccent.primary.hex }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>

                {/* English Option */}
                <button
                  type="button"
                  onClick={() => handleLanguageChange('en')}
                  id="onboarding-lang-en"
                  className={`py-2 px-3 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-between transition cursor-pointer ${
                    selectedLanguage === 'en'
                      ? isLight
                        ? 'bg-slate-50 text-slate-900 shadow-xs'
                        : isOled
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-slate-800 text-white shadow-xs'
                      : isLight
                      ? 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      : isOled
                      ? 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                  style={{
                    borderColor: selectedLanguage === 'en' ? dualAccent.primary.hex : undefined,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">🇺🇸</span>
                    <span className="font-bold">English</span>
                  </div>
                  {selectedLanguage === 'en' && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: dualAccent.primary.hex }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>
              </div>
            </div>

            {/* The Two Distinct Buttons at the Bottom */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
              {/* Primary Active Button: ক্রিয়েট নিউ আইডি (2nd touch submits) */}
              <button
                type="submit"
                id="welcome-btn-create-submit"
                disabled={isSubmitting || idAvailability === 'taken'}
                className="flex-1 py-3.5 px-4 rounded-2xl text-white font-black text-sm shadow-xl flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer disabled:opacity-50"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isEn ? 'Creating & Syncing...' : 'আইডি তৈরি হচ্ছে...'}</span>
                  </>
                ) : (
                  <>
                    <User className="w-4 h-4" />
                    <span>{isEn ? 'Create New ID' : 'ক্রিয়েট নিউ আইডি'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Secondary Button: Login and Sync (switches mode on click) */}
              <button
                type="button"
                id="welcome-btn-switch-to-login"
                onClick={() => {
                  setActiveMode('login');
                  setError('');
                  setSuccessMsg('');
                }}
                className={`flex-1 py-3.5 px-4 rounded-2xl font-bold text-sm border-2 flex items-center justify-center gap-2 transition cursor-pointer ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    : isOled
                    ? 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Cloud className="w-4 h-4" />
                <span>Login and Sync</span>
              </button>
            </div>
          </form>
        )}

        {/* ========================================================
            MODE 2: LOGIN & SYNC FORM (APPEARS ABOVE ON TAP)
           ======================================================== */}
        {activeMode === 'login' && (
          <form
            onSubmit={handleLoginSubmit}
            className="space-y-4 animate-in fade-in slide-in-from-top-3 duration-300"
          >
            {/* 1. Existing User ID Input */}
            <div>
              <label className="block text-xs font-bold mb-1 opacity-90 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                <span>{isEn ? 'Your ID / User ID *' : 'ইউর আইডি / ইউজার আইডি *'}</span>
              </label>
              <input
                type="text"
                required
                id="onboarding-login-user-id"
                value={loginUserId}
                onChange={(e) => setLoginUserId(e.target.value)}
                placeholder={isEn ? 'Enter your User ID' : 'আপনার ইউজার আইডি লিখুন'}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-mono font-bold ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                    : isOled
                    ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                    : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                } outline-hidden focus:ring-2`}
                autoFocus
              />
            </div>

            {/* 2. Existing Password Input */}
            <div>
              <label className="block text-xs font-bold mb-1 opacity-90 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                <span>{isEn ? 'Sync Password *' : 'সিন্ক পাসওয়ার্ড *'}</span>
              </label>
              <div className="relative">
                <input
                  type={showLoginPassword ? 'text' : 'password'}
                  required
                  id="onboarding-login-password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder={isEn ? 'Enter password' : 'পাসওয়ার্ড লিখুন'}
                  className={`w-full px-3.5 py-2.5 pr-10 rounded-xl border text-sm font-mono ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : isOled
                      ? 'bg-neutral-950 border-neutral-800 text-neutral-100 focus:border-neutral-700'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
                  } outline-hidden focus:ring-2`}
                />
                <button
                  type="button"
                  id="onboarding-toggle-login-password-btn"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* 3. Language Selection */}
            <div className="pt-1 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold opacity-90 flex items-center gap-1.5">
                  <Globe2 className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                  <span>{isEn ? 'Preferred Language' : 'পছন্দের ভাষা (Language)'}</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleLanguageChange('bn')}
                  id="onboarding-login-lang-bn"
                  className={`py-2 px-3 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-between transition cursor-pointer ${
                    selectedLanguage === 'bn'
                      ? isLight
                        ? 'bg-slate-50 text-slate-900 shadow-xs'
                        : isOled
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-slate-800 text-white shadow-xs'
                      : isLight
                      ? 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      : isOled
                      ? 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                  style={{
                    borderColor: selectedLanguage === 'bn' ? dualAccent.primary.hex : undefined,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">🇧🇩</span>
                    <span className="font-bold">বাংলা</span>
                  </div>
                  {selectedLanguage === 'bn' && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: dualAccent.primary.hex }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => handleLanguageChange('en')}
                  id="onboarding-login-lang-en"
                  className={`py-2 px-3 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-between transition cursor-pointer ${
                    selectedLanguage === 'en'
                      ? isLight
                        ? 'bg-slate-50 text-slate-900 shadow-xs'
                        : isOled
                        ? 'bg-neutral-900 text-white shadow-xs'
                        : 'bg-slate-800 text-white shadow-xs'
                      : isLight
                      ? 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      : isOled
                      ? 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                  style={{
                    borderColor: selectedLanguage === 'en' ? dualAccent.primary.hex : undefined,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">🇺🇸</span>
                    <span className="font-bold">English</span>
                  </div>
                  {selectedLanguage === 'en' && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: dualAccent.primary.hex }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </button>
              </div>
            </div>

            {/* The Two Distinct Buttons at the Bottom */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
              {/* Secondary Button: ক্রিয়েট নিউ আইডি (switches mode on click) */}
              <button
                type="button"
                id="welcome-btn-switch-to-create-from-login"
                onClick={() => {
                  setActiveMode('create');
                  setError('');
                  setSuccessMsg('');
                }}
                className={`flex-1 py-3.5 px-4 rounded-2xl font-bold text-sm border-2 flex items-center justify-center gap-2 transition cursor-pointer ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    : isOled
                    ? 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <User className="w-4 h-4" />
                <span>{isEn ? 'Create New ID' : 'ক্রিয়েট নিউ আইডি'}</span>
              </button>

              {/* Primary Active Button: Login and Sync (2nd touch submits) */}
              <button
                type="submit"
                id="welcome-btn-login-submit"
                disabled={isSubmitting || !loginUserId || !loginPassword}
                className="flex-1 py-3.5 px-4 rounded-2xl text-white font-black text-sm shadow-xl flex items-center justify-center gap-2 transform active:scale-98 transition cursor-pointer disabled:opacity-50"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isEn ? 'Logging in & Syncing...' : 'লগইন ও তথ্য সিঙ্ক হচ্ছে...'}</span>
                  </>
                ) : (
                  <>
                    <Cloud className="w-4 h-4" />
                    <span>Login and Sync</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
