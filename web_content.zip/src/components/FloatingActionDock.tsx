import React, { useState, useEffect } from "react";
import {
  StickyNote,
  CheckSquare,
  Network,
  User,
  Plus,
  Table,
  FileText,
  Sparkles,
  Shield,
  Layers,
  Search,
  BookOpen,
  Mic,
} from "lucide-react";
import { ActiveTab, ThemeAccent, UserProfile } from "../types";
import { THEME_ACCENTS } from "../utils/theme";
import {
  getStoredPlusButtonConfig,
  PlusButtonConfig,
  DEFAULT_PLUS_BUTTON_CONFIG,
} from "../utils/storage";

interface FloatingActionDockProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenCreateMenu: () => void;
  onOpenAIChat: () => void;
  onOpenSideGallery: () => void;
  onOpenCommandPalette: () => void;
  onOpenVault?: () => void;
  totalNotesCount?: number;
  vaultNotesCount?: number;
  isVaultUnlocked?: boolean;
  themeAccent?: ThemeAccent;
  profile?: UserProfile;
  menuOrder?: ActiveTab[];
  plusButtonConfig?: PlusButtonConfig;
  onQuickNoteCreate?: () => void;
}

export const FloatingActionDock: React.FC<FloatingActionDockProps> = ({
  activeTab,
  setActiveTab,
  onOpenCreateMenu,
  onOpenAIChat,
  onOpenSideGallery,
  onOpenCommandPalette,
  onOpenVault,
  totalNotesCount = 0,
  vaultNotesCount = 0,
  isVaultUnlocked = false,
  themeAccent = "teal",
  profile,
  menuOrder = [
    "home",
    "docs",
    "mindmap",
    "plus_action",
    "vault",
    "study",
    "profile",
    "tips",
    "settings",
  ],
  plusButtonConfig,
  onQuickNoteCreate,
}) => {
  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;
  const isAiActive = profile?.isLoggedIn && profile?.aiModeEnabled;

  const [effectivePlusConfig, setEffectivePlusConfig] = useState<PlusButtonConfig>(
    plusButtonConfig || getStoredPlusButtonConfig()
  );

  useEffect(() => {
    if (plusButtonConfig) {
      setEffectivePlusConfig(plusButtonConfig);
    } else {
      setEffectivePlusConfig(getStoredPlusButtonConfig());
    }
  }, [plusButtonConfig, menuOrder]);

  const handlePlusClick = () => {
    switch (effectivePlusConfig.action) {
      case "quick_note":
        if (onQuickNoteCreate) {
          onQuickNoteCreate();
        } else {
          onOpenCreateMenu();
        }
        break;
      case "mindmap":
        setActiveTab("mindmap");
        break;
      case "vault":
        setActiveTab("vault");
        if (onOpenVault) onOpenVault();
        break;
      case "create_menu":
      default:
        onOpenCreateMenu();
        break;
    }
  };

  // Get size class based on plus button config
  const getPlusSizeClasses = () => {
    switch (effectivePlusConfig.size) {
      case "compact":
        return "w-9 h-9 sm:w-10 sm:h-10";
      case "large":
        return "w-12 h-12 sm:w-14 sm:h-14";
      case "normal":
      default:
        return "w-10 h-10 sm:w-12 sm:h-12";
    }
  };

  // Ensure plus_action is included in menuOrder
  const effectiveMenuOrder: ActiveTab[] = [...menuOrder];
  if (!effectiveMenuOrder.includes("plus_action")) {
    // If not in menu order, place in the middle
    const mid = Math.floor(effectiveMenuOrder.length / 2);
    effectiveMenuOrder.splice(mid, 0, "plus_action");
  }

  const renderDockItem = (tabId: ActiveTab, index: number) => {
    // 1. RENDER '+' BUTTON AT CUSTOM POSITION
    if (tabId === "plus_action") {
      return (
        <div key="plus-action-item" className="px-0.5 sm:px-1 shrink-0">
          <button
            id="floating-dock-plus-btn"
            onClick={handlePlusClick}
            className={`group relative ${getPlusSizeClasses()} rounded-full bg-gradient-to-tr ${
              themeDef.gradient
            } ${themeDef.gradientHover} flex items-center justify-center text-white shadow-lg transition-transform hover:scale-110 active:scale-95 cursor-pointer`}
            style={{ boxShadow: `0 8px 20px -3px ${themeDef.preview}60` }}
            title="Yeni Oluştur (Not, Görev, Zihin Haritası, Belge, Kasa)"
          >
            <Plus className="w-5 h-5 sm:w-6 sm:h-6 stroke-[3] transition-transform group-hover:rotate-90 duration-300" />

            {/* Glowing Halo */}
            {effectivePlusConfig.effect === "glow" && (
              <span
                className="absolute inset-0 rounded-full animate-ping opacity-25 pointer-events-none"
                style={{ backgroundColor: themeDef.preview }}
              />
            )}

            {/* Double Ring Effect */}
            {effectivePlusConfig.effect === "double_ring" && (
              <span className="absolute -inset-1 rounded-full border-2 border-dashed border-teal-400/60 animate-spin-slow pointer-events-none" />
            )}
          </button>
        </div>
      );
    }

    // 2. RENDER REGULAR TABS & EXTRA ACTIONS
    switch (tabId) {
      case "home":
        return (
          <button
            key="home"
            onClick={() => setActiveTab("home")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "home"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Notlar"
          >
            <StickyNote className="w-4 h-4 shrink-0" />
            <span className="hidden md:inline">Notlar</span>
          </button>
        );
      case "docs":
        return (
          <button
            key="docs"
            onClick={() => setActiveTab("docs")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "docs"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Belgeler (Word/PDF)"
          >
            <FileText className="w-4 h-4 shrink-0" />
            <span className="hidden md:inline">Belgeler</span>
          </button>
        );
      case "mindmap":
        return (
          <button
            key="mindmap"
            onClick={() => setActiveTab("mindmap")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "mindmap"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Zihin & Bilgi Haritası"
          >
            <Network className="w-4 h-4 shrink-0" />
            <span className="hidden md:inline">Harita</span>
          </button>
        );
      case "vault":
        return (
          <button
            key="vault"
            onClick={() => {
              setActiveTab("vault");
              if (onOpenVault) onOpenVault();
            }}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "vault" || isVaultUnlocked
                ? "text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 shadow-xs font-extrabold"
                : "text-slate-600 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title={isVaultUnlocked ? "Şifreli Kasa (Kilit Açık)" : "Şifreli Kasa (Korumalı)"}
          >
            <Shield
              className={`w-4 h-4 shrink-0 ${
                activeTab === "vault" || isVaultUnlocked
                  ? "text-emerald-600 dark:text-emerald-400 fill-emerald-500/20"
                  : "text-slate-500 dark:text-slate-400"
              }`}
            />
            <span className="hidden md:inline">Kasa</span>
            {vaultNotesCount > 0 && (
              <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-600 text-white text-[8px] sm:text-[9px] font-extrabold flex items-center justify-center shrink-0">
                {vaultNotesCount}
              </span>
            )}
          </button>
        );
      case "study":
        return (
          <button
            key="study"
            onClick={() => setActiveTab("study")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "study"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Çalışma Kartları"
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span className="hidden lg:inline">Öğren</span>
          </button>
        );
      case "profile":
        return (
          <button
            key="profile"
            onClick={() => setActiveTab("profile")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "profile"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Profil & Düzen Ayarları"
          >
            <User className="w-4 h-4 shrink-0" />
            <span className="hidden lg:inline">Profil</span>
          </button>
        );
      case "tips":
        return (
          <button
            key="tips"
            onClick={() => setActiveTab("tips")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "tips"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="İpuçları Rehberi"
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <span className="hidden xl:inline">İpuçları</span>
          </button>
        );
      case "settings":
        return (
          <button
            key="settings"
            onClick={() => setActiveTab("settings")}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-full text-xs font-bold transition-all cursor-pointer shrink-0 ${
              activeTab === "settings"
                ? `${themeDef.activeTab}`
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Sistem Ayarları"
          >
            <Table className="w-4 h-4 shrink-0" />
            <span className="hidden xl:inline">Ayarlar</span>
          </button>
        );
      case "ai_chat":
        return (
          <button
            key="ai_chat"
            onClick={onOpenAIChat}
            className={`relative p-2 rounded-full transition-all cursor-pointer shrink-0 ${
              isAiActive
                ? "bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 hover:bg-teal-100"
                : "text-slate-400 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            title="Yapay Zeka Sohbet & Asistan"
          >
            <Sparkles className="w-4 h-4 text-teal-500" />
            {isAiActive && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            )}
          </button>
        );
      case "quick_search":
        return (
          <button
            key="quick_search"
            onClick={onOpenCommandPalette}
            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer shrink-0"
            title="Hızlı Komut Paleti & Arama"
          >
            <Search className="w-4 h-4" />
          </button>
        );
      case "voice_memo":
        return (
          <button
            key="voice_memo"
            onClick={onOpenCreateMenu}
            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer shrink-0"
            title="Hızlı Sesli Not"
          >
            <Mic className="w-4 h-4 text-rose-500" />
          </button>
        );
      default:
        return null;
    }
  };

  return (
    <aside
      aria-label="Alt Navigasyon ve Eylem Çubuğu"
      className="fixed bottom-[max(0.75rem,env(safe-area-inset-bottom))] left-1/2 -translate-x-1/2 z-40 flex items-center justify-center pointer-events-auto select-none print:hidden max-w-[calc(100vw-12px)]"
    >
      {/* Main Glassmorphic Dock Container */}
      <div className="flex items-center gap-0.5 sm:gap-1.5 p-1 sm:p-1.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-full border border-slate-200/90 dark:border-slate-800 shadow-2xl shadow-slate-900/15 dark:shadow-black/60 transition-all duration-300 max-w-full overflow-x-auto no-scrollbar">
        {/* Render sequential menu items in exact custom order */}
        {effectiveMenuOrder.map((tabId, idx) => renderDockItem(tabId, idx))}
      </div>
    </aside>
  );
};
