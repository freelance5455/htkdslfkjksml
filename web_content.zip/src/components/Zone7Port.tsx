import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { ALL_SPECIES, SPECIES_MAP } from '../data/species.ts';
import { ALL_RECIPES, RECIPES_MAP } from '../data/recipes.ts';
import type { Tier } from '../types/game.ts';
import { Ship, ShoppingBag, DollarSign, Sparkles, Scroll, CheckCircle2, Search } from 'lucide-react';

export const Zone7Port: React.FC = () => {
  const {
    player,
    inventory,
    animalPens,
    aquaticTanks,
    merchantShip,
    buyStoreItem,
    sellSingleItem,
    fulfillMerchantOrder,
    claimShipFormula,
  } = useGame();

  const [activeMainTab, setActiveMainTab] = useState<'buy' | 'sell' | 'ship'>('buy');

  // Buy subcategories: 'seeds' | 'animals' | 'aquatics' | 'supplies'
  const [buyCategory, setBuyCategory] = useState<'seeds' | 'animals' | 'aquatics' | 'supplies'>('seeds');
  const [cropGroupFilter, setCropGroupFilter] = useState<'all' | 'grain' | 'vegetable' | 'flower' | 'herb'>('all');
  const [buyTierFilter, setBuyTierFilter] = useState<Tier | 'all'>('all');
  const [buySearch, setBuySearch] = useState<string>('');

  // Sell subcategories: 'crops' | 'animals' | 'aquatics' | 'crafted' | 'special_floor'
  const [sellCategory, setSellCategory] = useState<'crops' | 'animals' | 'aquatics' | 'crafted' | 'special_floor'>('crops');

  // Lucky daily event for regular crafted products: +50% price surge
  const luckyItemSurgeId = 'item_baked_2';

  // Buy list filtering
  const buyCandidates = ALL_SPECIES.filter((s) => {
    // Only Tier 1 to 3 are sold in store! Tier 4 & 5 must be bred/gacha!
    if (s.tier > 3 || s.seedBuyPrice <= 0) return false;
    if (player.level < s.unlockLevel) return false;
    if (buyTierFilter !== 'all' && s.tier !== buyTierFilter) return false;
    if (buySearch && !s.name.toLowerCase().includes(buySearch.toLowerCase())) return false;

    if (buyCategory === 'seeds') {
      if (s.category === 'animal' || s.category === 'aquatic' || s.category === 'bee') return false;
      if (cropGroupFilter === 'grain' && s.category !== 'crop_grain') return false;
      if (cropGroupFilter === 'vegetable' && s.category !== 'crop_vegetable') return false;
      if (cropGroupFilter === 'flower' && s.category !== 'crop_flower') return false;
      if (cropGroupFilter === 'herb' && s.category !== 'crop_herb') return false;
      return true;
    }
    if (buyCategory === 'animals') return s.category === 'animal';
    if (buyCategory === 'aquatics') return s.category === 'aquatic';
    return false;
  });

  // Supplies list
  const suppliesList = [
    { id: 'thức_ăn_gia_cầm', name: 'Thức Ăn Gia Cầm Cơ Bản', icon: '🥣', price: 25, desc: 'Cho Gà ta, Vịt bầu' },
    { id: 'thức_ăn_cỏ', name: 'Cỏ Dinh Dưỡng Thú Nhỏ', icon: '🌾🥣', price: 30, desc: 'Cho Thỏ, Dê núi' },
    { id: 'thức_ăn_thủy_sinh', name: 'Thức Ăn Thủy Sinh Cơ Bản', icon: '🐟🥣', price: 35, desc: 'Cho Cá chép, Rô phi' },
    { id: 'mồi_tôm_đặc_biệt', name: 'Mồi Tôm Sú & Hàu Ngọc', icon: '🦐🥣', price: 80, desc: 'Thức ăn yêu thích tăng sản lượng' },
    { id: 'cám_cao_cấp', name: 'Cám Dinh Dưỡng Cao Cấp', icon: '✨🥣', price: 120, desc: '-25% thời gian tạo sản phẩm' },
    { id: 'phân_hữu_cơ', name: 'Phân Hữu Cơ Siêu Cấp', icon: '🌱🧪', price: 90, desc: '+50-100% sản lượng nông sản' },
  ];

  // Sell candidate items from inventory
  const sellItems = inventory.filter((item) => {
    if (item.count <= 0) return false;
    if (sellCategory === 'crops') return item.categoryTab === 2;
    if (sellCategory === 'animals') return item.categoryTab === 3;
    if (sellCategory === 'aquatics') return item.categoryTab === 4;
    if (sellCategory === 'crafted') return item.categoryTab === 5 && !item.name.includes('✨') && item.tier <= 3;
    if (sellCategory === 'special_floor') return item.categoryTab === 5 && (item.tier >= 4 || item.name.includes('✨'));
    return false;
  });

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">⛵</span>
            <div>
              <h2 className="text-base font-bold text-amber-300">Khu 7: Thương Cảng Quốc Tế</h2>
              <p className="text-xs text-stone-400">
                Cửa hàng mua sắm nông nghiệp • Quầy thu mua giao thương & Bến Tàu Buôn viễn dương
              </p>
            </div>
          </div>
        </div>

        {/* 3 Main Tabs: Buy, Sell, Ship */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-stone-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveMainTab('buy')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-bold transition ${
              activeMainTab === 'buy'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow-sm'
                : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Cửa Hàng Mua Sắm</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMainTab('sell')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-bold transition ${
              activeMainTab === 'sell'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow-sm'
                : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Quầy Thu Mua & Giao Thương</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMainTab('ship')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-bold transition ${
              activeMainTab === 'ship'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow-sm'
                : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
            }`}
          >
            <Ship className="w-3.5 h-3.5" />
            <span>Bến Tàu Buôn (Mở Cấp 5)</span>
          </button>
        </div>
      </div>

      {/* Main Tab 1: BUY */}
      {activeMainTab === 'buy' && (
        <div className="space-y-3">
          {/* 4 Buy Categories */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs bg-stone-900 p-2 rounded-xl border border-stone-800">
            {[
              { id: 'seeds', label: '🌱 Hạt Giống Cây Trồng' },
              { id: 'animals', label: '🐔 Vật Nuôi & Thú Cưng' },
              { id: 'aquatics', label: '🐟 Giống Thủy Hải Sản' },
              { id: 'supplies', label: '🥣 Thức Ăn & Phân Bón' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setBuyCategory(cat.id as any)}
                className={`px-3 py-1 rounded-lg border font-bold transition ${
                  buyCategory === cat.id
                    ? 'bg-amber-500 text-stone-950 border-amber-400 shadow'
                    : 'bg-stone-800 text-stone-300 border-stone-700 hover:text-stone-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Seeds Filters */}
          {buyCategory === 'seeds' && (
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs bg-stone-950 p-2.5 rounded-xl border border-stone-800">
              <div className="flex items-center gap-1">
                <span className="text-stone-400 font-semibold mr-1">Nhóm:</span>
                {[
                  { id: 'all', label: 'Tất Cả' },
                  { id: 'grain', label: 'Ngũ Cốc' },
                  { id: 'vegetable', label: 'Rau Củ' },
                  { id: 'flower', label: 'Hoa Màu' },
                  { id: 'herb', label: 'Dược Liệu' },
                ].map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => setCropGroupFilter(g.id as any)}
                    className={`px-2 py-0.5 rounded border text-[11px] font-semibold ${
                      cropGroupFilter === g.id
                        ? 'bg-amber-400 text-stone-950 border-amber-300'
                        : 'bg-stone-800 text-stone-400 border-stone-700'
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-stone-500 absolute left-2 top-2" />
                <input
                  type="text"
                  placeholder="Tìm giống cây..."
                  value={buySearch}
                  onChange={(e) => setBuySearch(e.target.value)}
                  className="bg-stone-800 border border-stone-700 rounded-lg pl-7 pr-2 py-1 text-stone-200 placeholder-stone-500 text-xs w-40"
                />
              </div>
            </div>
          )}

          {/* Candidates Grid */}
          {buyCategory === 'supplies' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {suppliesList.map((sup) => (
                <div
                  key={sup.id}
                  className="bg-stone-900 border border-stone-800 rounded-2xl p-3 flex flex-col justify-between space-y-2"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl p-1 bg-stone-800 rounded-xl">{sup.icon}</span>
                    <div>
                      <div className="font-bold text-stone-100 text-xs sm:text-sm">{sup.name}</div>
                      <div className="text-[10px] text-stone-400">{sup.desc}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-amber-400 font-bold text-xs">{sup.price} 🪙</span>
                    <button
                      type="button"
                      disabled={player.gold < sup.price}
                      onClick={() => buyStoreItem(sup.id, 1, sup.price)}
                      className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs rounded-lg shadow transition disabled:opacity-50"
                    >
                      Mua 1 Cái
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {buyCandidates.map((sp) => {
                let currentCount = 0;
                let isFull = false;

                if (sp.category === 'animal') {
                  const pen = animalPens[sp.id];
                  currentCount = pen ? pen.count : 0;
                  isFull = currentCount >= 10;
                } else if (sp.category === 'aquatic') {
                  const tank = aquaticTanks[sp.id];
                  currentCount = tank ? tank.count : 0;
                  isFull = currentCount >= 10;
                }

                return (
                  <div
                    key={sp.id}
                    className="bg-stone-900 border border-stone-800 rounded-2xl p-3 flex flex-col justify-between space-y-2 hover:border-stone-700 transition"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl p-1 bg-stone-800 rounded-xl">{sp.icon}</span>
                        <div>
                          <div className="flex items-center gap-1">
                            <h4 className="font-bold text-stone-100 text-xs sm:text-sm">{sp.name}</h4>
                            <span className="text-[9px] px-1 bg-stone-800 text-amber-400 rounded border border-amber-600/40">
                              Bậc {sp.tier}
                            </span>
                          </div>
                          <p className="text-[10px] text-stone-400 mt-0.5">
                            {sp.category === 'animal' || sp.category === 'aquatic'
                              ? `Đang nuôi: ${currentCount}/10 con`
                              : `Sinh trưởng: ${sp.growthTime}s`}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-amber-400 font-bold text-xs">{sp.seedBuyPrice} 🪙</span>
                      <button
                        type="button"
                        disabled={player.gold < sp.seedBuyPrice || isFull}
                        onClick={() => buyStoreItem(sp.id, 1, sp.seedBuyPrice)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition shadow ${
                          isFull
                            ? 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                            : player.gold >= sp.seedBuyPrice
                            ? 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                            : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                        }`}
                      >
                        {isFull ? 'Chuồng Đầy (10/10)' : 'Mua'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Main Tab 2: SELL */}
      {activeMainTab === 'sell' && (
        <div className="space-y-3">
          {/* 5 Sell Categories */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs bg-stone-900 p-2 rounded-xl border border-stone-800">
            {[
              { id: 'crops', label: '🌾 Nông Sản & Trái Cây' },
              { id: 'animals', label: '🥚 Chăn Nuôi, Mật & Nấm' },
              { id: 'aquatics', label: '🐟 Thủy Hải Sản' },
              { id: 'crafted', label: '🥐 Thành Phẩm Thông Thường' },
              { id: 'special_floor', label: '👑 Sàn Giao Dịch Đặc Biệt (4x-10x)' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSellCategory(cat.id as any)}
                className={`px-3 py-1 rounded-lg border font-bold transition ${
                  sellCategory === cat.id
                    ? 'bg-amber-500 text-stone-950 border-amber-400 shadow'
                    : 'bg-stone-800 text-stone-300 border-stone-700 hover:text-stone-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {sellCategory === 'crafted' && (
            <div className="bg-amber-950/40 border border-amber-500/40 rounded-xl p-2.5 text-xs text-amber-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin-slow" />
              <span>
                <strong>Sự Kiện Thị Trường Hôm Nay:</strong> Các mặt hàng Bánh nướng đang được thương nhân cảng thu mua với giá tăng <strong>+50% Vàng</strong>!
              </span>
            </div>
          )}

          {sellCategory === 'special_floor' && (
            <div className="bg-purple-950/40 border border-purple-500/40 rounded-xl p-2.5 text-xs text-purple-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400 animate-bounce" />
              <span>
                <strong>Sàn Giao Dịch Thành Phẩm Đặc Biệt:</strong> Chuyên thu mua các sản phẩm Thần Thoại & Vũ Trụ với giá trị cao gấp <strong>4 đến 10 lần</strong>!
              </span>
            </div>
          )}

          {sellItems.length === 0 ? (
            <div className="text-center py-12 bg-stone-900/60 rounded-xl border border-stone-800 text-stone-400 text-sm">
              <p>Hiện không có vật phẩm nào để bán trong danh mục này!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {sellItems.map((item) => {
                const isLucky = sellCategory === 'crafted' && item.id === luckyItemSurgeId;
                const effectivePrice = isLucky
                  ? Math.round(item.sellPrice * 1.5)
                  : sellCategory === 'special_floor'
                  ? item.sellPrice * 4
                  : item.sellPrice;

                return (
                  <div
                    key={item.id}
                    className="bg-stone-900 border border-stone-800 rounded-2xl p-3 flex flex-col justify-between space-y-2 hover:border-stone-700 transition"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl p-1 bg-stone-800 rounded-xl">{item.icon}</span>
                        <div>
                          <div className="font-bold text-stone-100 text-xs sm:text-sm">{item.name}</div>
                          <div className="text-[10px] text-stone-400">
                            Trong kho: <strong className="text-amber-400">{item.count} đơn vị</strong>
                          </div>
                        </div>
                      </div>
                      {isLucky && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500 text-stone-950 font-black animate-pulse">
                          +50% HOT
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-amber-400 font-bold text-xs">{effectivePrice} 🪙/đơn vị</span>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => sellSingleItem(item.id, 1)}
                          className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-semibold rounded-lg"
                        >
                          Bán 1
                        </button>
                        <button
                          type="button"
                          onClick={() => sellSingleItem(item.id, item.count)}
                          className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg shadow"
                        >
                          Bán Hết ({item.count})
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Main Tab 3: SHIP */}
      {activeMainTab === 'ship' && (
        <div className="space-y-4">
          {player.level < 5 ? (
            <div className="text-center py-12 bg-stone-900/60 rounded-xl border border-stone-800 text-stone-400 text-sm">
              <p className="text-amber-400 font-bold text-base">Bến Tàu Buôn Khóa Đến Cấp 5</p>
              <p className="mt-1">Hãy tích lũy thêm EXP từ trồng trọt và chăn nuôi để đón chuyến tàu buôn đầu tiên!</p>
            </div>
          ) : (
            <div className="bg-stone-900/90 border border-amber-500/40 rounded-2xl p-4 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                <div className="flex items-center gap-3">
                  <span className="text-4xl p-2 bg-stone-800 rounded-xl border border-stone-700">⛵</span>
                  <div>
                    <h3 className="font-bold text-amber-300 text-base">Tàu Buôn Viễn Dương Hoàng Gia</h3>
                    <p className="text-xs text-stone-400">
                      Cập bến giao thương • Thưởng Vàng, Ngọc Bích & EXP lớn (8-15% cấp độ)
                    </p>
                  </div>
                </div>

                <div className="text-xs bg-stone-800 px-3 py-1.5 rounded-xl border border-stone-700 text-stone-300">
                  Trạng thái: <strong className="text-emerald-400">Đã Cập Bến ⚓</strong>
                </div>
              </div>

              {/* Formula drop section */}
              {merchantShip.droppedFormulaId && !merchantShip.formulaClaimed && (
                <div className="bg-amber-950/80 border-2 border-amber-400 rounded-2xl p-3 flex items-center justify-between text-xs animate-bounce">
                  <div className="flex items-center gap-2">
                    <Scroll className="w-5 h-5 text-amber-400" />
                    <div>
                      <div className="font-black text-amber-300">RƠI BÍ KÍP CÔNG THỨC MỚI (15% Xác Suất)!</div>
                      <div className="text-[10px] text-amber-100">
                        {RECIPES_MAP.get(merchantShip.droppedFormulaId)?.name}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={claimShipFormula}
                    className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-black rounded-xl shadow"
                  >
                    Học Bí Kíp Ngay
                  </button>
                </div>
              )}

              {/* Orders */}
              <div className="space-y-2">
                <h4 className="font-bold text-stone-200 text-xs uppercase tracking-wider">
                  Đơn Hàng Xuất Khẩu Cần Giao:
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {merchantShip.orders.map((ord) => {
                    const invItem = inventory.find((i) => i.id === ord.itemId);
                    const haveCount = invItem ? invItem.count : 0;
                    const canFulfill = haveCount >= ord.countRequired;

                    return (
                      <div
                        key={ord.id}
                        className={`bg-stone-950 p-3 rounded-2xl border flex flex-col justify-between space-y-2 text-xs ${
                          ord.fulfilled ? 'border-emerald-500/60 bg-emerald-950/20' : 'border-stone-800'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{ord.itemIcon}</span>
                            <div>
                              <div className="font-bold text-stone-200">{ord.itemName}</div>
                              <div className="text-[10px] text-stone-400">
                                Yêu cầu: <strong className="text-amber-400">{ord.countRequired}</strong> (Bạn có: {haveCount})
                              </div>
                            </div>
                          </div>

                          {ord.fulfilled && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                        </div>

                        <div className="flex items-center justify-between pt-1 border-t border-stone-800/80">
                          <div className="flex items-center gap-2 text-[11px] font-bold">
                            <span className="text-amber-400">+{ord.rewardGold} 🪙</span>
                            <span className="text-emerald-400">+{ord.rewardJade} 💎</span>
                            <span className="text-sky-300">+{Math.round(ord.rewardExpRatio * 100)}% EXP</span>
                          </div>

                          <button
                            type="button"
                            disabled={ord.fulfilled || !canFulfill}
                            onClick={() => fulfillMerchantOrder(ord.id)}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition shadow ${
                              ord.fulfilled
                                ? 'bg-stone-800 text-stone-500 cursor-not-allowed'
                                : canFulfill
                                ? 'bg-amber-500 hover:bg-amber-400 text-stone-950 font-black'
                                : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                            }`}
                          >
                            {ord.fulfilled ? 'Đã Giao' : canFulfill ? 'Giao Hàng' : 'Thiếu Hàng'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
