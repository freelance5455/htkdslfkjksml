import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  MapPin,
  Heart,
  Sparkles,
  Ticket,
  ChevronRight,
  ArrowRight,
  ShieldCheck,
  Compass,
} from 'lucide-react';
import { EventItem } from '../types';
import { SearchBar } from './ui/SearchBar';
import { EmptyState } from './ui/EmptyState';
import { EventDetailsModal } from './EventDetailsModal';

export const HomePage: React.FC = () => {
  const {
    events,
    setCurrentPage,
    searchQuery,
    setSearchQuery,
    openPurchaseModal,
    isFavorite,
    toggleFavorite,
    formatKsh,
  } = useApp();

  const [inspectingEvent, setInspectingEvent] = useState<EventItem | null>(null);

  // Filter events based on active search query
  const filteredEvents = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return events;
    return events.filter(
      (e) =>
        e.title.toLowerCase().includes(q) ||
        e.venue.toLowerCase().includes(q) ||
        e.city.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        (e.categoryLabel && e.categoryLabel.toLowerCase().includes(q))
    );
  }, [events, searchQuery]);

  const featuredEvent = events[0] || null;
  const upcomingEvents = filteredEvents.slice(0, 8);

  const scrollToGrid = () => {
    const el = document.getElementById('discover-events-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-20 pb-28 transition-colors">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 space-y-12">
        {/* ========================================================= */}
        {/* HERO SECTION: Visually Impressive, Sharp & Minimalistic   */}
        {/* ========================================================= */}
        <section className="relative rounded-[36px] overflow-hidden bg-[#111317] border border-[#1f2229] shadow-2xl mt-4">
          {/* Static high-resolution festival hero atmosphere */}
          <div className="relative min-h-[460px] sm:min-h-[520px] w-full flex flex-col justify-end p-6 sm:p-12 overflow-hidden">
            <img
              src="/src/assets/images/event_hero_festival_1793028386968.jpg"
              alt="Eventra Live Experience"
              className="absolute inset-0 w-full h-full object-cover object-center brightness-60 contrast-105"
            />
            {/* Ambient Multi-Stop Dark Vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-[#090a0d]/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#090a0d]/80 via-transparent to-transparent hidden md:block" />

            {/* Content Layer */}
            <div className="relative z-10 max-w-2xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#111317]/90 border border-[#1f2229] text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Live Event Passbook</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#f4f4f6] leading-[1.08]">
                Live Experiences. <br />
                <span className="text-emerald-400">Seamless Entry.</span>
              </h1>

              <p className="text-sm sm:text-base text-[#9496a1] max-w-lg leading-relaxed font-normal">
                Discover premier festivals, intimate concerts, and stadium spectacles across Kenya with instant cryptographic passes.
              </p>

              {/* Working CTA buttons with unified emerald accent */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={scrollToGrid}
                  className="px-6 py-3 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs sm:text-sm font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer active:scale-98"
                >
                  <Compass className="w-4 h-4" />
                  <span>Discover Events</span>
                </button>

                <button
                  onClick={() => {
                    setCurrentPage('create');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-6 py-3 rounded-full border border-[#1f2229] bg-[#111317]/90 hover:bg-[#17191f] text-[#f4f4f6] text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer active:scale-98"
                >
                  <span>Host on Eventra</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#9496a1]" />
                </button>
              </div>
            </div>

            {/* Live Guarantee pill in corner */}
            <div className="absolute top-6 right-6 hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#111317]/80 backdrop-blur-xs border border-[#1f2229] text-xs font-semibold text-[#9496a1]">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Safaricom M-Pesa & PayPal Secured</span>
            </div>
          </div>
        </section>

        {/* ========================================================= */}
        {/* PROMINENT SEARCH BAR SECTION                              */}
        {/* ========================================================= */}
        <section className="space-y-4 max-w-3xl mx-auto text-center" id="search-section">
          <div className="max-w-2xl mx-auto">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Search by event title, artist, venue, or city..."
              resultCount={filteredEvents.length}
              size="lg"
            />
          </div>
        </section>

        {/* ========================================================= */}
        {/* UPCOMING & FEATURED EVENTS GRID                           */}
        {/* ========================================================= */}
        <section className="space-y-6" id="discover-events-section">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f2229]">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#f4f4f6]">
                {searchQuery.trim() ? `Search Matches (${filteredEvents.length})` : 'Upcoming Curated Experiences'}
              </h2>
              <p className="text-xs text-[#9496a1] mt-0.5">
                {searchQuery.trim()
                  ? `Showing results for "${searchQuery}"`
                  : 'Verified live performances with real-time pass generation'}
              </p>
            </div>

            <button
              onClick={() => {
                setCurrentPage('events');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Explore All Catalog</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Events Grid */}
          {filteredEvents.length === 0 ? (
            <EmptyState
              icon={<Calendar className="w-6 h-6 text-[#9496a1]" />}
              title="No events match your search"
              description="Try adjusting your keywords, searching for a different city, or clear the search to explore all live events."
              actionText="Clear Search"
              onAction={() => setSearchQuery('')}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingEvents.map((evt) => {
                const isFav = isFavorite(evt.id);
                const price = evt.personalPrice || evt.price;
                return (
                  <div
                    key={evt.id}
                    className="group rounded-3xl bg-[#111317] border border-[#1f2229] hover:border-emerald-500/40 transition-all flex flex-col overflow-hidden shadow-xs"
                  >
                    {/* Event Cover Image */}
                    <div
                      className="relative aspect-16/10 w-full overflow-hidden bg-[#17191f] cursor-pointer"
                      onClick={() => setInspectingEvent(evt)}
                    >
                      <img
                        src={evt.image}
                        alt={evt.title}
                        className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#111317] via-transparent to-transparent" />

                      {/* Category Label */}
                      <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-[#111317]/90 border border-[#1f2229] text-[10px] font-bold uppercase tracking-wider text-[#f4f4f6]">
                        {evt.categoryLabel || evt.category}
                      </span>

                      {/* Favorite Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(evt.id);
                        }}
                        className={`absolute top-3 right-3 w-8 h-8 rounded-full border border-[#1f2229] flex items-center justify-center transition-all cursor-pointer ${
                          isFav
                            ? 'bg-red-500 text-white border-red-500'
                            : 'bg-[#111317]/80 text-[#9496a1] hover:text-white'
                        }`}
                        aria-label="Save to favorites"
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                      </button>
                    </div>

                    {/* Event Body Info */}
                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{evt.date.split(',')[1] || evt.date} · {evt.time}</span>
                        </div>

                        <h3
                          className="text-base font-bold text-[#f4f4f6] group-hover:text-emerald-400 transition-colors cursor-pointer line-clamp-1"
                          onClick={() => setInspectingEvent(evt)}
                        >
                          {evt.title}
                        </h3>

                        <p className="text-xs text-[#9496a1] line-clamp-2 leading-relaxed">
                          {evt.subtitle || evt.description}
                        </p>

                        <div className="flex items-center gap-1.5 text-xs text-[#646875] pt-0.5">
                          <MapPin className="w-3.5 h-3.5 shrink-0 text-[#646875]" />
                          <span className="truncate">{evt.venue}, {evt.city}</span>
                        </div>
                      </div>

                      {/* Price and CTA row */}
                      <div className="pt-3 border-t border-[#1f2229] flex items-center justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#646875] block">
                            Pass From
                          </span>
                          <span className="text-base font-black text-[#f4f4f6]">
                            {formatKsh(price)}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setInspectingEvent(evt)}
                            className="px-3 py-1.5 rounded-xl border border-[#1f2229] hover:bg-[#17191f] text-xs font-semibold text-[#9496a1] hover:text-[#f4f4f6] transition-colors cursor-pointer"
                          >
                            Details
                          </button>

                          <button
                            onClick={() => openPurchaseModal(evt)}
                            className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                          >
                            <Ticket className="w-3.5 h-3.5" />
                            <span>Book</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Event Details Inspection Modal */}
      {inspectingEvent && (
        <EventDetailsModal
          event={inspectingEvent}
          onClose={() => setInspectingEvent(null)}
          onBookNow={() => {
            const ev = inspectingEvent;
            setInspectingEvent(null);
            openPurchaseModal(ev);
          }}
        />
      )}
    </div>
  );
};
