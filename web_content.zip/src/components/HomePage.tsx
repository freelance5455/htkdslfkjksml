"use client";
import { useEffect, useState } from "react";
import { SEARCH_ENGINES, hostOf, type SearchEngineId } from "@/lib/browser";
import { Favicon, Icon } from "./ui";

type Bookmark = { id: number; url: string; title: string };
type Hist = { url: string; title: string };

const QUICK = [
  { title: "Google", url: "https://www.google.com" },
  { title: "Яндекс", url: "https://ya.ru" },
  { title: "Wikipedia", url: "https://ru.wikipedia.org" },
  { title: "YouTube", url: "https://m.youtube.com" },
  { title: "GitHub", url: "https://github.com" },
  { title: "Habr", url: "https://habr.com" },
  { title: "Hacker News", url: "https://news.ycombinator.com" },
  { title: "MDN", url: "https://developer.mozilla.org/ru/" },
];

export function HomePage({
  engine,
  incognito,
  profileId,
  onNavigate,
  onEngineChange,
  onAskAI,
}: {
  engine: SearchEngineId;
  incognito: boolean;
  profileId: number;
  onNavigate: (input: string) => void;
  onEngineChange: (e: SearchEngineId) => void;
  onAskAI: (q: string) => void;
}) {
  const [q, setQ] = useState("");
  const [bms, setBms] = useState<Bookmark[]>([]);
  const [recent, setRecent] = useState<Hist[]>([]);

  useEffect(() => {
    if (incognito) return;
    fetch(`/api/bookmarks?profileId=${profileId}`).then((r) => r.json()).then((d) => setBms(Array.isArray(d) ? d.slice(0, 8) : [])).catch(() => {});
    fetch(`/api/history?profileId=${profileId}`)
      .then((r) => r.json())
      .then((d: Hist[]) => {
        const seen = new Set<string>();
        setRecent((Array.isArray(d) ? d : []).filter((h) => (seen.has(h.url) ? false : (seen.add(h.url), true))).slice(0, 6));
      })
      .catch(() => {});
  }, [incognito, profileId]);

  const E = SEARCH_ENGINES[engine];
  const dial = bms.length ? bms : QUICK;

  return (
    <div className="flex h-full flex-col items-center overflow-y-auto bg-gradient-to-b from-slate-100 to-slate-200 px-4 pb-10 pt-[10vh] dark:from-[#0b1020] dark:to-[#111833]">
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-400 text-white shadow-lg shadow-indigo-500/30">
          <Icon name="globe" size={26} />
        </div>
        <div>
          <div className="text-2xl font-bold tracking-tight">NovaBrowser</div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{incognito ? "Приватный режим — история не сохраняется" : "Быстро. Безопасно. С ИИ."}</div>
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (q.trim()) onNavigate(q);
        }}
        className="accent-ring flex w-full max-w-xl items-center gap-2 rounded-full border border-black/5 bg-white p-1.5 pl-4 shadow-xl dark:border-white/10 dark:bg-white/10"
      >
        <Icon name="search" size={18} className="text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={`Поиск в ${E.name} или адрес сайта`}
          className="min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-slate-400"
          autoFocus
        />
        <button type="button" onClick={() => q.trim() && onAskAI(q)} title="Спросить Nova AI" className="hidden h-9 items-center gap-1 rounded-full px-3 text-xs font-semibold accent-text hover:bg-black/5 sm:flex dark:hover:bg-white/10">
          <Icon name="sparkles" size={15} /> Nova AI
        </button>
        <button type="submit" className="accent-bg flex h-9 w-9 items-center justify-center rounded-full text-white">
          <Icon name="forward" size={18} />
        </button>
      </form>

      <div className="mt-3 flex items-center gap-2">
        {(Object.keys(SEARCH_ENGINES) as SearchEngineId[]).map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => onEngineChange(id)}
            className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition ${
              id === engine ? "border-transparent text-white shadow" : "border-black/10 text-slate-500 hover:bg-black/5 dark:border-white/10 dark:text-slate-400"
            }`}
            style={id === engine ? { background: SEARCH_ENGINES[id].color } : {}}
          >
            {SEARCH_ENGINES[id].name}
          </button>
        ))}
      </div>

      <div className="mt-10 grid w-full max-w-xl grid-cols-4 gap-3 sm:grid-cols-8">
        {dial.map((b) => (
          <button key={b.url} type="button" onClick={() => onNavigate(b.url)} className="group flex flex-col items-center gap-1.5">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow transition group-hover:-translate-y-0.5 group-hover:shadow-lg dark:bg-white/10">
              <Favicon src={`https://www.google.com/s2/favicons?domain=${hostOf(b.url)}&sz=64`} title={b.title} size={24} />
            </span>
            <span className="w-full truncate text-center text-[11px] text-slate-600 dark:text-slate-300">{b.title}</span>
          </button>
        ))}
      </div>

      {recent.length > 0 && (
        <div className="mt-10 w-full max-w-xl">
          <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-slate-400">
            <Icon name="history" size={14} /> Недавние
          </div>
          <div className="overflow-hidden rounded-2xl bg-white shadow dark:bg-white/5">
            {recent.map((h) => (
              <button key={h.url} type="button" onClick={() => onNavigate(h.url)} className="flex w-full items-center gap-3 border-b border-black/5 px-4 py-2.5 text-left text-sm last:border-0 hover:bg-black/5 dark:border-white/5 dark:hover:bg-white/5">
                <Favicon src={`https://www.google.com/s2/favicons?domain=${hostOf(h.url)}&sz=32`} title={h.title} />
                <span className="min-w-0 flex-1 truncate">{h.title || h.url}</span>
                <span className="shrink-0 text-xs text-slate-400">{hostOf(h.url)}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
