import { Link } from "react-router-dom";
import { Leaf } from "lucide-react";

export default function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-border/70 bg-secondary/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-10 sm:flex-row sm:items-center sm:justify-between lg:px-8">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Leaf className="h-4 w-4 text-primary" />
          </span>
          <div>
            <p className="font-display text-sm font-semibold">Clean City Coimbatore</p>
            <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted-foreground">
              A resident-run waste watch. Every report on this board is public, so the whole
              city can follow what changed and when.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Board</Link>
          <Link to="/insights" className="hover:text-foreground">Insights</Link>
          <Link to="/team" className="hover:text-foreground">City team</Link>
          <Link to="/report" className="hover:text-foreground">Report an issue</Link>
        </div>
      </div>
    </footer>
  );
}