import React, { useState } from 'react';
import { Copy, Check, Delete } from 'lucide-react';
import { formatDisplayValue } from '../utils/math';
import { NumeralSystem, Language } from '../types/calculator';

interface DisplayProps {
  expression: string;
  currentValue: string;
  numeralSystem: NumeralSystem;
  language: Language;
  onBackspace: () => void;
  onClear: () => void;
}

export const Display: React.FC<DisplayProps> = ({
  expression,
  currentValue,
  numeralSystem,
  language,
  onBackspace,
  onClear,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      const textToCopy = currentValue || '0';
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const formattedDisplay = formatDisplayValue(currentValue || '0', numeralSystem);
  const formattedExpression = expression ? formatDisplayValue(expression, numeralSystem) : '';

  // Dynamic font sizing based on length of number
  const length = formattedDisplay.length;
  let textSizeClass = 'text-4xl sm:text-5xl';
  if (length > 15) {
    textSizeClass = 'text-2xl sm:text-3xl';
  } else if (length > 10) {
    textSizeClass = 'text-3xl sm:text-4xl';
  }

  return (
    <div className="relative w-full rounded-2xl bg-slate-900 border border-slate-800/80 p-5 shadow-inner transition-all flex flex-col justify-between min-h-[148px]">
      {/* Top action row & Expression */}
      <div className="flex items-center justify-between gap-2 text-xs sm:text-sm text-slate-400 mb-1">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors focus-visible:ring-2 focus-visible:ring-amber-500"
            title={language === 'ur' ? 'کاپی کریں' : 'Copy result'}
            aria-label={language === 'ur' ? 'نتیجہ کاپی کریں' : 'Copy result'}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-medium">{language === 'ur' ? 'کاپی ہو گیا' : 'Copied'}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{language === 'ur' ? 'کاپی' : 'Copy'}</span>
              </>
            )}
          </button>
        </div>

        {/* Previous expression row */}
        <div 
          className="text-right truncate font-mono tracking-wide text-slate-400 max-w-[240px] sm:max-w-[320px]"
          dir={numeralSystem === 'eastern' ? 'rtl' : 'ltr'}
        >
          {formattedExpression ? (
            <span>{formattedExpression}</span>
          ) : (
            <span className="text-slate-600 select-none">&nbsp;</span>
          )}
        </div>
      </div>

      {/* Main result & backspace row */}
      <div className="flex items-end justify-between gap-3 pt-2">
        {/* Backspace button on display */}
        <div className="flex items-center gap-1 shrink-0 pb-1">
          <button
            type="button"
            onClick={onBackspace}
            disabled={!currentValue || currentValue === '0'}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 active:scale-95 disabled:opacity-30 disabled:hover:bg-transparent transition-all focus-visible:ring-2 focus-visible:ring-amber-500"
            title={language === 'ur' ? 'ایک ہندسہ مٹائیں (Backspace)' : 'Delete last digit'}
            aria-label={language === 'ur' ? 'ایک ہندسہ مٹائیں' : 'Backspace'}
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Large Number Display */}
        <div
          className={`w-full text-right font-mono tabular-nums font-bold text-slate-50 tracking-tight select-all overflow-x-auto no-scrollbar ${textSizeClass}`}
          dir={numeralSystem === 'eastern' ? 'rtl' : 'ltr'}
        >
          {formattedDisplay}
        </div>
      </div>
    </div>
  );
};
