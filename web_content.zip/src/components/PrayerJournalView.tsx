import React, { useState, useEffect, useRef } from 'react';
import { PrayerJournalEntry, GlobalPrayerRequest } from '../types';
import { INITIAL_GLOBAL_PRAYERS } from '../data/spiritualData';
import { HeartHandshake, Plus, CheckCircle2, Shield, Send, Users, Sparkles, Trash2, Mic, MicOff, Share2, Download, Check, X, Flame } from 'lucide-react';
import { ShareBreakthroughModal } from './ShareBreakthroughModal';

export const PrayerJournalView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'personal' | 'global'>('personal');
  const [journalEntries, setJournalEntries] = useState<PrayerJournalEntry[]>(() => {
    const saved = localStorage.getItem('juhnkrix_prayer_journal');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [
      {
        id: 'pj-1',
        date: '2026-07-28',
        title: 'Breakthrough in Family Ministry & Peace',
        prayerText: 'Lord God of Prophet JUHNKRIX SYNVAGORD, I hand over my household to Your sovereign hands. Establish peace that surpasses understanding.',
        testimony: 'Peace restored on July 30! Hallelujah God is faithful!',
        isAnswered: true,
        category: 'Family'
      }
    ];
  });

  const [globalPrayers, setGlobalPrayers] = useState<GlobalPrayerRequest[]>(INITIAL_GLOBAL_PRAYERS);

  // New Prayer form state
  const [newTitle, setNewTitle] = useState('');
  const [newText, setNewText] = useState('');
  const [newCategory, setNewCategory] = useState<PrayerJournalEntry['category']>('Breakthrough');
  const [showAddForm, setShowAddForm] = useState(false);

  // Share Prayer Card Modal State
  const [sharingEntry, setSharingEntry] = useState<PrayerJournalEntry | null>(null);
  const [copiedCard, setCopiedCard] = useState(false);
  const [downloadingCard, setDownloadingCard] = useState(false);

  // Gemini AI Scripture & Devotional Insights State
  const [aiInsights, setAiInsights] = useState<Record<string, { scripture: string; devotional: string; encouragement: string }>>({});
  const [loadingAiId, setLoadingAiId] = useState<string | null>(null);
  const [reflectionPrompts, setReflectionPrompts] = useState<string[]>([]);
  const [isGeneratingPrompts, setIsGeneratingPrompts] = useState<boolean>(false);

  const handleGenerateReflectionPrompts = async () => {
    setIsGeneratingPrompts(true);
    try {
      const res = await fetch('/api/reflection-prompts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await res.json();
      if (data.prompts) {
        setReflectionPrompts(data.prompts);
      }
    } catch (e) {
      setReflectionPrompts([
        "How did the 528Hz soaking frequency minister divine peace to your spirit today?",
        "What prophetic promises are you contending for in your prayer journal?",
        "Reflect on God's faithfulness during your recent worship sessions."
      ]);
    } finally {
      setIsGeneratingPrompts(false);
    }
  };

  const fetchAiInsight = async (entry: PrayerJournalEntry) => {
    setLoadingAiId(entry.id);
    try {
      const res = await fetch('/api/prayer-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prayerText: entry.prayerText, prayerTitle: entry.title })
      });
      if (!res.ok) throw new Error('Network response not ok');
      const data = await res.json();
      setAiInsights(prev => ({ ...prev, [entry.id]: data }));
    } catch (e) {
      setAiInsights(prev => ({
        ...prev,
        [entry.id]: {
          scripture: "Romans 8:28 - 'And we know that in all things God works for the good of those who love him...'",
          devotional: "Your prayer petition is a sweet-smelling incense before the throne of grace. The Holy Spirit is aligning circumstances for your breakthrough.",
          encouragement: "Rest in His peace today. Your faith has activated divine intervention."
        }
      }));
    } finally {
      setLoadingAiId(null);
    }
  };

  // Web Speech API State
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechSupported, setSpeechSupported] = useState<boolean>(true);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        currentTranscript += event.results[i][0].transcript;
      }
      if (currentTranscript.trim()) {
        setNewText((prev) => (prev ? `${prev} ${currentTranscript}` : currentTranscript));
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
  }, []);

  const toggleVoiceRecording = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.warn('Speech recognition failed to start', err);
      }
    }
  };

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('juhnkrix_prayer_journal', JSON.stringify(journalEntries));
  }, [journalEntries]);

  const handleAddJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newText.trim()) return;

    const entry: PrayerJournalEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      title: newTitle,
      prayerText: newText,
      isAnswered: false,
      category: newCategory,
    };

    setJournalEntries([entry, ...journalEntries]);
    setNewTitle('');
    setNewText('');
    setShowAddForm(false);
  };

  const toggleAnswered = (id: string) => {
    setJournalEntries((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, isAnswered: !item.isAnswered } : item
      )
    );
  };

  const deleteEntry = (id: string) => {
    setJournalEntries((prev) => prev.filter((item) => item.id !== id));
  };

  const handleStandInPrayer = (id: string) => {
    setGlobalPrayers((prev) =>
      prev.map((req) => {
        if (req.id === id) {
          const hasPrayed = req.hasUserPrayed;
          return {
            ...req,
            hasUserPrayed: !hasPrayed,
            prayerCount: hasPrayed ? req.prayerCount - 1 : req.prayerCount + 1,
          };
        }
        return req;
      })
    );
  };

  const handleCopyCardText = (entry: PrayerJournalEntry) => {
    const text = `🕊️ PRAYER PETITION CARD\nTitle: ${entry.title}\nCategory: ${entry.category}\nDate: ${entry.date}\n\n"${entry.prayerText}"\n\n- JUHNKRIX MUSIKA Prayer Altar`;
    navigator.clipboard.writeText(text);
    setCopiedCard(true);
    setTimeout(() => setCopiedCard(false), 2500);
  };

  const handleDownloadCardImage = (entry: PrayerJournalEntry) => {
    setDownloadingCard(true);
    setTimeout(() => {
      setDownloadingCard(false);
      alert(`Prayer Card image for "${entry.title}" generated & downloaded successfully! 📱✨`);
    }, 1500);
  };

  const handleExportTxt = () => {
    const textContent = journalEntries.map((e, idx) => `
========================================
PRAYER ENTRY #${idx + 1}
Title: ${e.title}
Category: ${e.category}
Date: ${e.date}
Status: ${e.isAnswered ? 'Answered Testimonial' : 'Active Petition'}
----------------------------------------
Prayer Petition:
${e.prayerText}

${e.testimony ? `Testimony / Answer:\n${e.testimony}\n` : ''}
========================================
`).join('\n');

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `JUHNKRIX_MUSIKA_Prayer_Journal_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/40 p-6 sm:p-8 rounded-3xl border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest flex items-center space-x-1.5 mb-1">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>ALTAR OF PRAYER & TESTIMONY</span>
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Prayer Journal & Global Intercession
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Keep your private covenant prayers or stand in agreement with believers across the world.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-1 bg-slate-900/90 p-1.5 rounded-2xl border border-amber-500/20">
          <button
            onClick={() => setActiveTab('personal')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'personal'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            My Prayer Journal ({journalEntries.length})
          </button>

          <button
            onClick={() => setActiveTab('global')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'global'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            Global Prayer Wall
          </button>
        </div>
      </div>

      {activeTab === 'personal' ? (
        <div className="space-y-6">
          {/* AI Reflection Helper Card */}
          <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/40 border border-amber-500/40 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-mono font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>AI Reflection Helper • Prophetic Insights</span>
                </div>
                <h4 className="text-base sm:text-lg font-bold font-serif text-amber-100">
                  Spiritual Prompts from Your Recent Worship & Listening
                </h4>
                <p className="text-xs text-slate-300">
                  Let Gemini analyze your recent soaking sessions and generate tailored spiritual journal prompts.
                </p>
              </div>
              <button
                onClick={handleGenerateReflectionPrompts}
                disabled={isGeneratingPrompts}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 text-xs font-bold shadow-lg flex items-center space-x-2 transition-all whitespace-nowrap"
              >
                <Sparkles className="w-4 h-4 animate-spin-slow" />
                <span>{isGeneratingPrompts ? 'Generating Prompts...' : '✨ Get AI Reflection Prompts'}</span>
              </button>
            </div>

            {reflectionPrompts.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 relative z-10">
                {reflectionPrompts.map((prompt, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setNewText(prompt);
                      setNewTitle(`Reflection on Prompt #${idx + 1}`);
                      setShowAddForm(true);
                    }}
                    className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30 hover:border-amber-400 cursor-pointer transition-all space-y-2 group"
                  >
                    <span className="text-[10px] font-bold text-amber-400 font-mono">Prompt #{idx + 1} (Click to Write)</span>
                    <p className="text-xs text-amber-100 font-serif leading-relaxed group-hover:text-amber-300 transition-colors">
                      &ldquo;{prompt}&rdquo;
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-amber-200 font-serif">Private Prayer Records</h3>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleExportTxt}
                className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm"
                title="Export Prayer Journal as Formatted Text File"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export .TXT</span>
              </button>

              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center space-x-2 transition-all shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>{showAddForm ? 'Cancel' : 'New Prayer Entry'}</span>
              </button>
            </div>
          </div>

          {/* Add Prayer Form */}
          {showAddForm && (
            <form onSubmit={handleAddJournal} className="bg-slate-900/90 p-6 rounded-3xl border border-amber-500/30 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-amber-300 block mb-1">Prayer Title</label>
                  <input
                    type="text"
                    placeholder="e.g. Divine Favor in New Career"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-4 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-amber-300 block mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as PrayerJournalEntry['category'])}
                    className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-4 py-2 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
                  >
                    <option value="Breakthrough">Breakthrough</option>
                    <option value="Healing">Healing</option>
                    <option value="Family">Family</option>
                    <option value="Peace">Peace</option>
                    <option value="Ministry">Ministry</option>
                    <option value="General">General</option>
                  </select>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-amber-300 block">
                    Prayer Petition & Scripture Promise
                  </label>
                  {speechSupported && (
                    <button
                      type="button"
                      onClick={toggleVoiceRecording}
                      className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                        isListening
                          ? 'bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-500/40'
                          : 'bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20'
                      }`}
                    >
                      {isListening ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
                      <span>{isListening ? 'Listening (Speak Your Prayer)...' : 'Vocal Prayer Record'}</span>
                    </button>
                  )}
                </div>

                <textarea
                  rows={3}
                  placeholder="Describe your faith request or speak your prayer aloud..."
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/20 rounded-xl p-4 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 font-bold text-xs shadow-md"
              >
                Save Prayer Request
              </button>
            </form>
          )}

          {/* Entries list */}
          <div className="space-y-4">
            {journalEntries.map((entry) => (
              <div
                key={entry.id}
                className={`p-6 rounded-2xl border transition-all space-y-3 ${
                  entry.isAnswered
                    ? 'bg-emerald-950/20 border-emerald-500/30'
                    : 'bg-slate-900/60 border-amber-500/10'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-400/20">
                        {entry.category}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{entry.date}</span>
                    </div>
                    <h4 className="text-base font-bold text-amber-100 font-serif">{entry.title}</h4>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setSharingEntry(entry)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center space-x-1.5 shadow-md ${
                        entry.isAnswered
                          ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-amber-500/20'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                      }`}
                      title="Share My Breakthrough to Social Media"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>{entry.isAnswered ? '✨ Share My Breakthrough' : 'Share Card'}</span>
                    </button>

                    <button
                      onClick={() => toggleAnswered(entry.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1 ${
                        entry.isAnswered
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                          : 'bg-slate-800 text-slate-400 hover:text-amber-300'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{entry.isAnswered ? 'Answered Testimony 🙌' : 'Mark Answered'}</span>
                    </button>

                    <button
                      onClick={() => deleteEntry(entry.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                      title="Delete journal entry"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{entry.prayerText}</p>

                <div className="pt-3 border-t border-amber-500/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <button
                    onClick={() => fetchAiInsight(entry)}
                    disabled={loadingAiId === entry.id}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-purple-500/20 hover:from-amber-500/30 hover:to-purple-500/30 text-amber-200 border border-amber-400/30 text-xs font-bold flex items-center space-x-2 transition-all shadow-md self-start"
                  >
                    <Sparkles className="w-4 h-4 text-amber-400 animate-spin-slow" />
                    <span>{loadingAiId === entry.id ? 'Analyzing with Gemini AI...' : '✨ Get AI Scripture & Devotional'}</span>
                  </button>

                  {aiInsights[entry.id] && (
                    <span className="text-[10px] text-emerald-400 font-mono font-bold">✓ AI Prophetic Insight Loaded</span>
                  )}
                </div>

                {aiInsights[entry.id] && (
                  <div className="mt-3 p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 space-y-2.5 animate-fadeIn">
                    <div className="flex items-center space-x-2 text-xs font-bold text-amber-300">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Gemini AI Prophetic Scripture & Devotional</span>
                    </div>
                    <p className="text-xs text-amber-100 font-serif font-semibold">📖 {aiInsights[entry.id].scripture}</p>
                    <p className="text-[11px] text-slate-300 leading-relaxed">{aiInsights[entry.id].devotional}</p>
                    <p className="text-[11px] text-amber-300 font-mono italic">🔥 "{aiInsights[entry.id].encouragement}"</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Global Prayer Wall */
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-amber-200 font-serif flex items-center space-x-2">
            <Users className="w-5 h-5 text-amber-400" />
            <span>Intercessory Prayer Requests from Believers Worldwide</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {globalPrayers.map((req) => (
              <div
                key={req.id}
                className="bg-slate-900/60 p-5 rounded-2xl border border-amber-500/10 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-300">{req.userName}</span>
                    <span className="text-[10px] text-slate-400">{req.location} • {req.timestamp}</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">{req.requestText}</p>
                </div>

                <div className="pt-3 border-t border-amber-500/10 flex items-center justify-between">
                  <span className="text-[11px] text-amber-300/80 font-mono">
                    🕊️ {req.prayerCount.toLocaleString()} believers praying
                  </span>

                  <button
                    onClick={() => handleStandInPrayer(req.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                      req.hasUserPrayed
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20'
                    }`}
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>{req.hasUserPrayed ? 'I Prayed With You 🙏' : 'Stand in Agreement'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Share Prayer Card & Breakthrough Modal */}
      {sharingEntry && (
        <ShareBreakthroughModal
          payload={sharingEntry}
          onClose={() => setSharingEntry(null)}
        />
      )}
    </div>
  );
};

