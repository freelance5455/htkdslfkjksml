import React, { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Archive,
  Check,
  CheckCheck,
  Image as ImageIcon,
  Lock,
  Mic,
  Phone,
  Plus,
  Reply,
  Search,
  Send,
  Square,
  Trash2,
  Users,
  Video,
  VolumeX,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { compressImageFile, deterministicPairId, formatRelativeTime } from '../lib/mediaUtils';
import { BUILTIN_COURSES, TEVETA_COLLEGES } from '../lib/tevetaCatalog';
import type {
  CallLogItem,
  ChatMessage,
  ChatThread,
  GroupMember,
  GroupMessage,
  LanguageCode,
  StudyGroup,
  UserProfile,
} from '../types';

interface ChatsTabProps {
  profile: UserProfile;
  language: LanguageCode;
  onlineUids: string[];
  typingByChatId: Record<string, boolean>;
  selectedPeerForChat: UserProfile | null;
  onClearSelectedPeer: () => void;
  onSendTyping: (toUid: string, chatId: string, isTyping: boolean) => void;
  onStartCall: (peer: UserProfile, callType: 'voice' | 'video') => void;
}

export const ChatsTab: React.FC<ChatsTabProps> = ({
  profile,
  language,
  onlineUids,
  typingByChatId,
  selectedPeerForChat,
  onClearSelectedPeer,
  onSendTyping,
  onStartCall,
}) => {
  const t = TRANSLATIONS[language];
  const [subTab, setSubTab] = useState<'private' | 'groups' | 'calls'>('private');
  const [searchQuery, setSearchQuery] = useState('');
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [chats, setChats] = useState<ChatThread[]>([]);
  const [activeChat, setActiveChat] = useState<ChatThread | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [msgText, setMsgText] = useState('');
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [recordingVoice, setRecordingVoice] = useState(false);
  const [recorder, setRecorder] = useState<MediaRecorder | null>(null);
  const [mutedChatIds, setMutedChatIds] = useState<Set<string>>(new Set());
  const [archivedChatIds, setArchivedChatIds] = useState<Set<string>>(new Set());

  // Groups state
  const [groups, setGroups] = useState<StudyGroup[]>([]);
  const [activeGroup, setActiveGroup] = useState<StudyGroup | null>(null);
  const [groupMembers, setGroupMembers] = useState<GroupMember[]>([]);
  const [groupMessages, setGroupMessages] = useState<GroupMessage[]>([]);
  const [groupMsgText, setGroupMsgText] = useState('');
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [newGroupType, setNewGroupType] = useState<'public' | 'private'>('public');
  const [newGroupCollege, setNewGroupCollege] = useState(TEVETA_COLLEGES[0]);
  const [newGroupCourse, setNewGroupCourse] = useState(BUILTIN_COURSES[0].trade);

  // Calls history
  const [callLogs, setCallLogs] = useState<CallLogItem[]>([]);

  useEffect(() => {
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => setAllUsers(snap.docs.map((d) => d.data() as UserProfile)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );

    const unsubChatsA = onSnapshot(
      query(collection(db, 'chats'), where('userA', '==', profile.uid)),
      (snap) => {
        const listA = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ChatThread, 'id'>) }));
        setChats((prev) => {
          const rest = prev.filter((c) => c.userA !== profile.uid);
          return [...listA, ...rest];
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'chats')
    );

    const unsubChatsB = onSnapshot(
      query(collection(db, 'chats'), where('userB', '==', profile.uid)),
      (snap) => {
        const listB = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ChatThread, 'id'>) }));
        setChats((prev) => {
          const rest = prev.filter((c) => c.userB !== profile.uid);
          return [...rest, ...listB];
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'chats')
    );

    const unsubGroups = onSnapshot(
      collection(db, 'groups'),
      (snap) => setGroups(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudyGroup, 'id'>) }))),
      (err) => handleFirestoreError(err, OperationType.LIST, 'groups')
    );

    const unsubCallsA = onSnapshot(
      query(collection(db, 'calls'), where('callerUid', '==', profile.uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<CallLogItem, 'id'>) }));
        setCallLogs((prev) => {
          const map = new Map<string, CallLogItem>();
          [...prev, ...list].forEach((c) => map.set(c.id, c));
          return Array.from(map.values());
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'calls')
    );

    const unsubCallsB = onSnapshot(
      query(collection(db, 'calls'), where('calleeUid', '==', profile.uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<CallLogItem, 'id'>) }));
        setCallLogs((prev) => {
          const map = new Map<string, CallLogItem>();
          [...prev, ...list].forEach((c) => map.set(c.id, c));
          return Array.from(map.values());
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'calls')
    );

    return () => {
      unsubUsers();
      unsubChatsA();
      unsubChatsB();
      unsubGroups();
      unsubCallsA();
      unsubCallsB();
    };
  }, [profile.uid]);

  // Open direct chat when launched from FriendsTab
  useEffect(() => {
    if (!selectedPeerForChat) return;
    const openOrCreate = async () => {
      const chatId = deterministicPairId(profile.uid, selectedPeerForChat.uid);
      const existing = chats.find((c) => c.id === chatId);
      if (existing) {
        setActiveChat(existing);
        setSubTab('private');
        onClearSelectedPeer();
        return;
      }
      const [userA, userB] =
        profile.uid < selectedPeerForChat.uid
          ? [profile.uid, selectedPeerForChat.uid]
          : [selectedPeerForChat.uid, profile.uid];
      const [userAName, userBName] =
        profile.uid < selectedPeerForChat.uid
          ? [profile.fullName, selectedPeerForChat.fullName]
          : [selectedPeerForChat.fullName, profile.fullName];
      try {
        await setDoc(doc(db, 'chats', chatId), {
          userA,
          userB,
          userAName,
          userBName,
          lastMessage: '',
          lastSenderId: profile.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setActiveChat({
          id: chatId,
          userA,
          userB,
          userAName,
          userBName,
        });
        setSubTab('private');
        onClearSelectedPeer();
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `chats/${chatId}`);
      }
    };
    void openOrCreate();
  }, [selectedPeerForChat, chats, profile, onClearSelectedPeer]);

  // Listen to messages in active private chat
  useEffect(() => {
    if (!activeChat) {
      setMessages([]);
      return;
    }
    const q = query(collection(db, 'chats', activeChat.id, 'messages'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ChatMessage, 'id'>) }));
        setMessages(list);
        // Mark incoming unread messages as read
        list.forEach((m) => {
          if (m.senderId !== profile.uid && !m.read) {
            void updateDoc(doc(db, 'chats', activeChat.id, 'messages', m.id), {
              read: true,
              delivered: true,
            });
          }
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `chats/${activeChat.id}/messages`)
    );
    return () => unsub();
  }, [activeChat, profile.uid]);

  // Listen to active study group members & messages
  useEffect(() => {
    if (!activeGroup) {
      setGroupMembers([]);
      setGroupMessages([]);
      return;
    }
    const unsubMembers = onSnapshot(
      collection(db, 'groups', activeGroup.id, 'members'),
      (snap) =>
        setGroupMembers(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<GroupMember, 'id'>) }))),
      (err) => handleFirestoreError(err, OperationType.LIST, `groups/${activeGroup.id}/members`)
    );
    const unsubMsgs = onSnapshot(
      query(collection(db, 'groups', activeGroup.id, 'messages'), orderBy('createdAt', 'asc')),
      (snap) =>
        setGroupMessages(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<GroupMessage, 'id'>) }))
        ),
      () => {
        // Private group non-members cannot read messages until approved
        setGroupMessages([]);
      }
    );
    return () => {
      unsubMembers();
      unsubMsgs();
    };
  }, [activeGroup]);

  const getPeerInfo = (chat: ChatThread) => {
    const peerUid = chat.userA === profile.uid ? chat.userB : chat.userA;
    const found = allUsers.find((u) => u.uid === peerUid);
    const name = found?.fullName || (chat.userA === profile.uid ? chat.userBName : chat.userAName) || 'Learner';
    return { peerUid, name, profile: found };
  };

  const handleSendMessage = async (
    e?: React.FormEvent,
    override?: { type: 'image' | 'audio'; mediaUrl: string; text?: string }
  ) => {
    if (e) e.preventDefault();
    if (!activeChat) return;
    const textVal = override ? override.text || '' : msgText.trim();
    if (!override && !textVal) return;

    const { peerUid } = getPeerInfo(activeChat);
    try {
      await addDoc(collection(db, 'chats', activeChat.id, 'messages'), {
        chatId: activeChat.id,
        senderId: profile.uid,
        senderName: profile.fullName,
        type: override ? override.type : 'text',
        text: textVal,
        mediaUrl: override ? override.mediaUrl : '',
        replyPreview: replyingTo ? `${replyingTo.senderName}: ${(replyingTo.text || '[Media]').slice(0, 60)}` : '',
        delivered: true,
        read: false,
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'chats', activeChat.id), {
        lastMessage: override ? (override.type === 'audio' ? 'Voice note' : 'Photo') : textVal.slice(0, 120),
        lastSenderId: profile.uid,
        updatedAt: serverTimestamp(),
      });
      await addDoc(collection(db, 'notifications'), {
        recipientUid: peerUid,
        actorUid: profile.uid,
        type: 'message',
        title: `Message from ${profile.fullName}`,
        body: override ? `Sent a ${override.type}` : textVal.slice(0, 140),
        read: false,
        createdAt: serverTimestamp(),
      });
      onSendTyping(peerUid, activeChat.id, false);
      setMsgText('');
      setReplyingTo(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `chats/${activeChat.id}/messages`);
    }
  };

  const handlePickChatImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const compressed = await compressImageFile(file, 840, 0.7);
    await handleSendMessage(undefined, { type: 'image', mediaUrl: compressed, text: 'Photo' });
  };

  const handleToggleVoiceNote = async () => {
    if (recordingVoice && recorder) {
      recorder.stop();
      setRecordingVoice(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      mr.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };
      mr.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          void handleSendMessage(undefined, {
            type: 'audio',
            mediaUrl: String(reader.result),
            text: 'Voice note',
          });
        };
        reader.readAsDataURL(blob);
      };
      mr.start();
      setRecorder(mr);
      setRecordingVoice(true);
    } catch {
      // Mic permission declined
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!activeChat) return;
    try {
      await deleteDoc(doc(db, 'chats', activeChat.id, 'messages', messageId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `chats/${activeChat.id}/messages/${messageId}`);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;
    try {
      const groupRef = await addDoc(collection(db, 'groups'), {
        name: newGroupName.trim(),
        description: newGroupDesc.trim(),
        type: newGroupType,
        college: newGroupCollege,
        course: newGroupCourse,
        creatorId: profile.uid,
        membersCount: 1,
        createdAt: serverTimestamp(),
      });
      await setDoc(doc(db, 'groups', groupRef.id, 'members', profile.uid), {
        uid: profile.uid,
        displayName: profile.fullName,
        role: 'admin',
        status: 'approved',
        joinedAt: serverTimestamp(),
      });
      setShowNewGroupModal(false);
      setNewGroupName('');
      setNewGroupDesc('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'groups');
    }
  };

  const handleJoinGroup = async (group: StudyGroup) => {
    try {
      await setDoc(doc(db, 'groups', group.id, 'members', profile.uid), {
        uid: profile.uid,
        displayName: profile.fullName,
        role: 'member',
        status: group.type === 'public' ? 'approved' : 'pending',
        joinedAt: serverTimestamp(),
      });
      if (group.type === 'public') {
        await updateDoc(doc(db, 'groups', group.id), { membersCount: increment(1) });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `groups/${group.id}/members/${profile.uid}`);
    }
  };

  const handleApproveMember = async (group: StudyGroup, memberUid: string) => {
    try {
      await updateDoc(doc(db, 'groups', group.id, 'members', memberUid), {
        status: 'approved',
      });
      await updateDoc(doc(db, 'groups', group.id), { membersCount: increment(1) });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `groups/${group.id}/members/${memberUid}`);
    }
  };

  const handleSendGroupMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGroup || !groupMsgText.trim()) return;
    try {
      await addDoc(collection(db, 'groups', activeGroup.id, 'messages'), {
        groupId: activeGroup.id,
        senderId: profile.uid,
        senderName: profile.fullName,
        type: 'text',
        text: groupMsgText.trim(),
        createdAt: serverTimestamp(),
      });
      setGroupMsgText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `groups/${activeGroup.id}/messages`);
    }
  };

  const visibleChats = chats
    .filter((c) => !archivedChatIds.has(c.id))
    .filter((c) => {
      if (!searchQuery.trim()) return true;
      return getPeerInfo(c).name.toLowerCase().includes(searchQuery.toLowerCase());
    });

  const myMembership = activeGroup
    ? groupMembers.find((m) => m.uid === profile.uid)
    : undefined;

  return (
    <div className="space-y-4">
      {/* Sub-navigation */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl">
          {(['private', 'groups', 'calls'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setSubTab(tab)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                subTab === tab
                  ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {tab === 'private' ? t.chats.privateChats : tab === 'groups' ? t.chats.groups : t.chats.callHistory}
            </button>
          ))}
        </div>

        {subTab === 'groups' && (
          <button
            type="button"
            onClick={() => setShowNewGroupModal(true)}
            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.chats.newGroup}</span>
          </button>
        )}
      </div>

      {/* PRIVATE CHATS */}
      {subTab === 'private' && (
        <div className="grid lg:grid-cols-12 gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden min-h-[520px]">
          {/* Thread List */}
          <aside
            className={`lg:col-span-5 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 flex flex-col ${
              activeChat ? 'hidden lg:flex' : 'flex'
            }`}
          >
            <div className="p-3 border-b border-slate-100 dark:border-slate-800">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search conversations..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-xs"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {visibleChats.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  No private conversations yet. Visit Friends to start chatting with a classmate or instructor.
                </div>
              ) : (
                visibleChats.map((chat) => {
                  const { peerUid, name, profile: peerProf } = getPeerInfo(chat);
                  const isOnline = onlineUids.includes(peerUid);
                  const isSelected = activeChat?.id === chat.id;
                  return (
                    <button
                      key={chat.id}
                      type="button"
                      onClick={() => setActiveChat(chat)}
                      className={`w-full text-left p-3.5 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer ${
                        isSelected ? 'bg-blue-50/70 dark:bg-blue-950/30' : ''
                      }`}
                    >
                      <div className="relative w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold text-sm shrink-0 overflow-hidden">
                        {peerProf?.photoUrl ? (
                          <img src={peerProf.photoUrl} alt={name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          name.slice(0, 2).toUpperCase()
                        )}
                        {isOnline && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-semibold text-sm truncate">{name}</p>
                          <span className="text-[11px] text-slate-400 shrink-0">
                            {formatRelativeTime(chat.updatedAt)}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                          {typingByChatId[chat.id] ? (
                            <span className="text-emerald-600 font-medium">{t.chats.typing}</span>
                          ) : (
                            chat.lastMessage || 'Tap to send message'
                          )}
                        </p>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </aside>

          {/* Active Conversation Pane */}
          <section
            className={`lg:col-span-7 flex flex-col ${activeChat ? 'flex' : 'hidden lg:flex'}`}
          >
            {!activeChat ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 text-sm">
                Select a conversation to message, share notes, send voice notes, or start a voice/video call.
              </div>
            ) : (
              <>
                {(() => {
                  const { peerUid, name, profile: peerProf } = getPeerInfo(activeChat);
                  const isOnline = onlineUids.includes(peerUid);
                  return (
                    <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <button
                          type="button"
                          onClick={() => setActiveChat(null)}
                          className="lg:hidden px-2 py-1 text-xs font-semibold text-blue-700"
                        >
                          Back
                        </button>
                        <div className="min-w-0">
                          <p className="font-semibold text-sm truncate">{name}</p>
                          <p className="text-[11px] text-slate-500">
                            {typingByChatId[activeChat.id]
                              ? t.chats.typing
                              : isOnline
                              ? t.chats.online
                              : 'Offline'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {peerProf && (
                          <>
                            <button
                              type="button"
                              onClick={() => onStartCall(peerProf, 'voice')}
                              title="Voice call"
                              className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-emerald-600"
                            >
                              <Phone className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onStartCall(peerProf, 'video')}
                              title="Video call"
                              className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-blue-600"
                            >
                              <Video className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            setMutedChatIds((prev) => {
                              const next = new Set(prev);
                              if (next.has(activeChat.id)) next.delete(activeChat.id);
                              else next.add(activeChat.id);
                              return next;
                            })
                          }
                          title="Mute chat"
                          className={`min-h-[38px] min-w-[38px] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center ${
                            mutedChatIds.has(activeChat.id) ? 'text-amber-600' : 'text-slate-400'
                          }`}
                        >
                          <VolumeX className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setArchivedChatIds((prev) => new Set(prev).add(activeChat.id));
                            setActiveChat(null);
                          }}
                          title="Archive chat"
                          className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-400"
                        >
                          <Archive className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })()}

                <div className="flex-1 overflow-y-auto p-4 space-y-2.5 bg-slate-50 dark:bg-slate-950/60 max-h-[380px]">
                  {messages.map((m) => {
                    const isMine = m.senderId === profile.uid;
                    return (
                      <div key={m.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                        <div
                          className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm space-y-1 ${
                            isMine
                              ? 'bg-blue-700 text-white'
                              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          {m.replyPreview && (
                            <div className="text-[11px] opacity-75 border-b border-current/20 pb-1 mb-1">
                              {m.replyPreview}
                            </div>
                          )}
                          {m.type === 'image' && m.mediaUrl && (
                            <img src={m.mediaUrl} alt="Chat attachment" className="rounded-xl max-h-52 object-cover" />
                          )}
                          {m.type === 'audio' && m.mediaUrl && (
                            <audio controls src={m.mediaUrl} className="max-w-[230px]" />
                          )}
                          {m.text && <p className="whitespace-pre-wrap break-words">{m.text}</p>}

                          <div className="flex items-center justify-end gap-2 text-[10px] opacity-75 pt-0.5">
                            <button
                              type="button"
                              onClick={() => setReplyingTo(m)}
                              title="Reply"
                              className="hover:opacity-100"
                            >
                              <Reply className="w-3 h-3" />
                            </button>
                            {isMine && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteMessage(m.id)}
                                  title="Delete"
                                  className="hover:opacity-100"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                                {m.read ? <CheckCheck className="w-3.5 h-3.5 text-emerald-300" /> : <Check className="w-3.5 h-3.5" />}
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {replyingTo && (
                  <div className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-xs flex items-center justify-between">
                    <span className="truncate">
                      Replying to <strong>{replyingTo.senderName}</strong>: {replyingTo.text}
                    </span>
                    <button type="button" onClick={() => setReplyingTo(null)}>
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <form
                  onSubmit={(e) => void handleSendMessage(e)}
                  className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
                >
                  <label className="min-h-[40px] min-w-[40px] rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center cursor-pointer text-slate-600 dark:text-slate-300">
                    <ImageIcon className="w-4 h-4" />
                    <input type="file" accept="image/*" onChange={handlePickChatImage} className="hidden" />
                  </label>
                  <button
                    type="button"
                    onClick={handleToggleVoiceNote}
                    title="Voice note"
                    className={`min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer ${
                      recordingVoice
                        ? 'bg-red-600 text-white'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {recordingVoice ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </button>
                  <input
                    type="text"
                    value={msgText}
                    onChange={(e) => {
                      setMsgText(e.target.value);
                      const { peerUid } = getPeerInfo(activeChat);
                      onSendTyping(peerUid, activeChat.id, e.target.value.length > 0);
                    }}
                    placeholder={t.chats.typeMessage}
                    className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <button
                    type="submit"
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </>
            )}
          </section>
        </div>
      )}

      {/* STUDY GROUPS (PUBLIC & PRIVATE) */}
      {subTab === 'groups' && (
        <div className="grid lg:grid-cols-12 gap-4">
          <div className="lg:col-span-5 space-y-3">
            {groups.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
                No study groups yet. Create the first public or private group for your trade or college!
              </div>
            ) : (
              groups.map((grp) => (
                <div
                  key={grp.id}
                  onClick={() => setActiveGroup(grp)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-colors ${
                    activeGroup?.id === grp.id
                      ? 'bg-blue-50/70 dark:bg-blue-950/30 border-blue-400 dark:border-blue-800'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-display font-semibold text-sm">{grp.name}</h3>
                    {grp.type === 'private' ? (
                      <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                    ) : (
                      <Users className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    {grp.course || 'All Trades'} · {grp.college || 'Malawi'} · {grp.membersCount} members
                  </p>
                </div>
              ))
            )}
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 min-h-[420px] flex flex-col">
            {!activeGroup ? (
              <div className="flex-1 flex items-center justify-center text-sm text-slate-500 text-center">
                Select a study group to view discussions, shared notes, or request membership.
              </div>
            ) : (
              <>
                <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-display font-bold text-base">{activeGroup.name}</h3>
                    <p className="text-xs text-slate-500">
                      {activeGroup.type === 'private' ? 'Private Approval Group' : 'Public Study Group'} · {activeGroup.college}
                    </p>
                  </div>
                  {!myMembership && (
                    <button
                      type="button"
                      onClick={() => handleJoinGroup(activeGroup)}
                      className="min-h-[38px] px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                    >
                      {activeGroup.type === 'public' ? t.chats.joinGroup : t.chats.requestJoin}
                    </button>
                  )}
                  {myMembership?.status === 'pending' && (
                    <span className="text-xs font-medium text-amber-600">Membership pending approval</span>
                  )}
                </div>

                {/* Admin Pending Approvals */}
                {activeGroup.creatorId === profile.uid &&
                  groupMembers.some((m) => m.status === 'pending') && (
                    <div className="my-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 space-y-2">
                      <p className="text-xs font-semibold">Pending Member Requests</p>
                      {groupMembers
                        .filter((m) => m.status === 'pending')
                        .map((m) => (
                          <div key={m.uid} className="flex items-center justify-between text-xs">
                            <span>{m.displayName || m.uid}</span>
                            <button
                              type="button"
                              onClick={() => handleApproveMember(activeGroup, m.uid)}
                              className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-semibold"
                            >
                              Approve
                            </button>
                          </div>
                        ))}
                    </div>
                  )}

                <div className="flex-1 overflow-y-auto py-4 space-y-3 max-h-[300px]">
                  {activeGroup.type === 'private' && myMembership?.status !== 'approved' ? (
                    <p className="text-xs text-slate-500 text-center py-8">
                      This is a private group. Request access to read and participate in discussions.
                    </p>
                  ) : groupMessages.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-8">
                      No messages in this study group yet.
                    </p>
                  ) : (
                    groupMessages.map((gm) => (
                      <div key={gm.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                        <div className="flex items-center justify-between text-slate-500">
                          <span className="font-semibold text-slate-900 dark:text-white">{gm.senderName}</span>
                          <span>{formatRelativeTime(gm.createdAt)}</span>
                        </div>
                        <p className="text-sm text-slate-800 dark:text-slate-200">{gm.text}</p>
                      </div>
                    ))
                  )}
                </div>

                {myMembership?.status === 'approved' && (
                  <form onSubmit={handleSendGroupMessage} className="pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                    <input
                      type="text"
                      value={groupMsgText}
                      onChange={(e) => setGroupMsgText(e.target.value)}
                      placeholder="Share study notes or discussion message..."
                      className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold"
                    >
                      Send
                    </button>
                  </form>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* CALL HISTORY */}
      {subTab === 'calls' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
          <h2 className="font-display font-semibold text-base">Voice & Video Call History</h2>
          {callLogs.length === 0 ? (
            <p className="text-xs text-slate-500">No voice or video calls logged yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {callLogs.map((call) => {
                const isCaller = call.callerUid === profile.uid;
                const peerName = isCaller ? call.calleeName || call.calleeUid : call.callerName || call.callerUid;
                return (
                  <div key={call.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-semibold text-sm text-slate-900 dark:text-white">{peerName}</p>
                      <p className="text-slate-500">
                        {call.callType === 'video' ? 'Video' : 'Voice'} · {isCaller ? 'Outgoing' : 'Incoming'} · {call.status}
                        {call.durationSeconds ? ` · ${call.durationSeconds}s` : ''}
                      </p>
                    </div>
                    <span className="text-slate-400">{formatRelativeTime(call.createdAt)}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Create Group Modal */}
      {showNewGroupModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">Create Study Group</h3>
              <button type="button" onClick={() => setShowNewGroupModal(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateGroup} className="space-y-3">
              <input
                type="text"
                required
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="Group name (e.g. Salima Solar PV Level 2)"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <textarea
                rows={2}
                value={newGroupDesc}
                onChange={(e) => setNewGroupDesc(e.target.value)}
                placeholder="Purpose of this study group..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newGroupType}
                  onChange={(e) => setNewGroupType(e.target.value as 'public' | 'private')}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="public">Public Group</option>
                  <option value="private">Private (Approval)</option>
                </select>
                <select
                  value={newGroupCourse}
                  onChange={(e) => setNewGroupCourse(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  {BUILTIN_COURSES.map((c) => (
                    <option key={c.id} value={c.trade}>{c.trade}</option>
                  ))}
                </select>
              </div>
              <select
                value={newGroupCollege}
                onChange={(e) => setNewGroupCollege(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
              >
                {TEVETA_COLLEGES.map((col) => (
                  <option key={col} value={col}>{col}</option>
                ))}
              </select>
              <button
                type="submit"
                className="w-full min-h-[44px] rounded-xl bg-blue-700 text-white text-sm font-semibold"
              >
                Create Group
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
