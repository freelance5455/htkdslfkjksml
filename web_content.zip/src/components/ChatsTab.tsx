import React, { useState } from 'react';
import { MessageSquare, Users, Sparkles, ChevronLeft, Trash2 } from 'lucide-react';
import { Character, ChatMessage } from '../types';

interface ChatsTabProps {
  characters: Character[];
  chatHistories: Record<string, ChatMessage[]>;
  activeChatId: string | null;
  onSelectChat: (characterId: string) => void;
  onDeleteChat: (characterId: string) => void;
  freeMessages: number;
}

export const ChatsTab: React.FC<ChatsTabProps> = ({
  characters,
  chatHistories,
  onSelectChat,
  onDeleteChat,
  freeMessages,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'chats' | 'groups'>('chats');

  // Filter characters that have existing chat history or default active list
  const activeChatCharacters = characters.filter((char) => {
    return chatHistories[char.id] && chatHistories[char.id].length > 0;
  });

  return (
    <div className="pb-24 pt-2 px-4 max-w-lg mx-auto">
      {/* Top Header with Tabs & Free Badge matching Screenshot 2 */}
      <div className="flex items-center justify-between mb-5 border-b border-slate-800 pb-3">
        {/* Sub tabs: "الدردشات" & "المجموعات" */}
        <div className="flex items-center space-x-4 space-x-reverse">
          <button
            onClick={() => setActiveSubTab('chats')}
            className={`text-base font-bold transition-all relative pb-1 ${
              activeSubTab === 'chats'
                ? 'text-white border-b-2 border-pink-500'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            الدردشات
          </button>
          <button
            onClick={() => setActiveSubTab('groups')}
            className={`text-base font-bold transition-all relative pb-1 ${
              activeSubTab === 'groups'
                ? 'text-white border-b-2 border-pink-500'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            المجموعات
          </button>
        </div>

        {/* Free message pill badge matching screenshot */}
        <div className="bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-semibold px-3 py-1 rounded-full">
          {freeMessages} رسالة مجانية
        </div>
      </div>

      {/* List View */}
      {activeSubTab === 'chats' ? (
        <div className="space-y-3">
          {activeChatCharacters.length > 0 ? (
            activeChatCharacters.map((char) => {
              const history = chatHistories[char.id] || [];
              const lastMsg = history[history.length - 1];
              const lastText = lastMsg
                ? lastMsg.text
                : char.greeting;
              const timestamp = lastMsg?.timestamp || '2026-07-25';

              return (
                <div
                  key={char.id}
                  onClick={() => onSelectChat(char.id)}
                  className="group bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 hover:border-pink-500/40 rounded-2xl p-3 flex items-center justify-between transition-all cursor-pointer shadow-sm"
                >
                  <div className="flex items-center space-x-3 space-x-reverse flex-1 min-w-0">
                    {/* Avatar with pink badge */}
                    <div className="relative w-12 h-12 rounded-full overflow-hidden bg-slate-700 flex-shrink-0 border border-pink-500/30">
                      <img
                        src={char.avatar}
                        alt={char.name}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full" />
                    </div>

                    {/* Character Name & Last Message snippet */}
                    <div className="flex-1 min-w-0 pr-1">
                      <div className="flex items-center justify-between mb-0.5">
                        <h4 className="text-sm font-bold text-white group-hover:text-pink-300 transition-colors truncate">
                          {char.nameAr || char.name}
                        </h4>
                        <span className="text-[11px] text-slate-400 font-medium">
                          {timestamp}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 truncate font-sans text-right dir-rtl opacity-90">
                        {lastText}
                      </p>
                    </div>
                  </div>

                  {/* Actions / Arrow */}
                  <div className="flex items-center space-x-1 space-x-reverse mr-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteChat(char.id);
                      }}
                      className="p-1.5 text-slate-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="حذف المحادثة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-pink-400 transition-colors" />
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-16 px-4 bg-slate-800/40 rounded-2xl border border-slate-800">
              <MessageSquare className="w-12 h-12 text-pink-500/40 mx-auto mb-3" />
              <h3 className="text-white font-bold text-base mb-1">
                لا توجد محادثات نشطة بعد
              </h3>
              <p className="text-slate-400 text-xs mb-4">
                اختر إحدى الشخصيات المميزة من قسم الاستكشاف وابدأ الدردشة فوراً!
              </p>
            </div>
          )}
        </div>
      ) : (
        /* Groups Sub-tab Placeholder */
        <div className="text-center py-16 px-4 bg-slate-800/40 rounded-2xl border border-slate-800">
          <Users className="w-12 h-12 text-purple-500/40 mx-auto mb-3" />
          <h3 className="text-white font-bold text-base mb-1">
            المجموعات التفاعلية
          </h3>
          <p className="text-slate-400 text-xs mb-4">
            يمكنك إنشاء غرفة دردشة جماعية تجمع عدة شخصيات للتفاعل معاً!
          </p>
        </div>
      )}
    </div>
  );
};
