import React, { useState, useEffect } from 'react';
import { Activity, Heart, AlertCircle, ShieldAlert, Zap, Compass, Moon, Droplets, Dumbbell, X, RefreshCw } from 'lucide-react';

interface HealthMonitorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HealthMonitorModal: React.FC<HealthMonitorModalProps> = ({ isOpen, onClose }) => {
  const [motionData, setMotionData] = useState<{ x: number; y: number; z: number }>({ x: 0, y: 0, z: 0 });
  const [stepCount, setStepCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('jarvis_step_count');
      return saved ? parseInt(saved, 10) : 1420;
    } catch {
      return 1420;
    }
  });

  const [waterGlasses, setWaterGlasses] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('jarvis_water_intake');
      return saved ? parseInt(saved, 10) : 5;
    } catch {
      return 5;
    }
  });

  const [sleepHours, setSleepHours] = useState<number>(7.5);
  const [workoutMins, setWorkoutMins] = useState<number>(30);
  const [sensorStatus, setSensorStatus] = useState<string>('Initializing Device Sensors...');

  useEffect(() => {
    if (!isOpen) return;

    let lastMagnitude = 0;
    const handleDeviceMotion = (event: DeviceMotionEvent) => {
      const acc = event.accelerationIncludingGravity;
      if (acc) {
        const x = acc.x || 0;
        const y = acc.y || 0;
        const z = acc.z || 0;
        setMotionData({ x: parseFloat(x.toFixed(2)), y: parseFloat(y.toFixed(2)), z: parseFloat(z.toFixed(2)) });
        setSensorStatus('Accelerometer Active');

        const currentMagnitude = Math.sqrt(x * x + y * y + z * z);
        const delta = Math.abs(currentMagnitude - lastMagnitude);
        if (delta > 3.2) {
          setStepCount(prev => {
            const next = prev + 1;
            try { localStorage.setItem('jarvis_step_count', next.toString()); } catch {}
            return next;
          });
        }
        lastMagnitude = currentMagnitude;
      }
    };

    if (typeof window !== 'undefined' && 'DeviceMotionEvent' in window) {
      window.addEventListener('devicemotion', handleDeviceMotion);
    } else {
      setSensorStatus('Accelerometer not accessible in current browser environment');
    }

    return () => {
      if (typeof window !== 'undefined' && 'DeviceMotionEvent' in window) {
        window.removeEventListener('devicemotion', handleDeviceMotion);
      }
    };
  }, [isOpen]);

  const addWater = () => {
    setWaterGlasses(prev => {
      const next = prev + 1;
      try { localStorage.setItem('jarvis_water_intake', next.toString()); } catch {}
      return next;
    });
  };

  const resetSteps = () => {
    setStepCount(0);
    try { localStorage.setItem('jarvis_step_count', '0'); } catch {}
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              PHYSICAL CONDITION & SENSOR TELEMETRY
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* TRUTHFUL MEDICAL HONESTY NOTICE */}
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-amber-200 leading-relaxed">
              <span className="font-bold uppercase tracking-wider block mb-0.5 text-amber-300">
                Truthful Sensor Disclosure (Zero Mock Medical Data)
              </span>
              Standard smartphone screens and web browsers do not possess optical photoplethysmography (PPG) or sphygmomanometer hardware to measure Blood Pressure or SpO2. Displayed readings below represent genuine physical device motion, calibrated steps, and verified daily habits.
            </div>
          </div>

          {/* Device Motion & Pedometry */}
          <div className="p-4 rounded-xl bg-gray-950/70 border border-cyan-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-tech text-xs uppercase text-cyan-300 font-bold flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-cyan-400" />
                Hardware Motion Accelerometer
              </span>
              <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                {sensorStatus}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-lg bg-gray-900 border border-cyan-500/20">
                <div className="text-[10px] text-cyan-400 font-mono-tech">ACCEL X</div>
                <div className="text-sm font-bold font-mono-tech text-cyan-100">{motionData.x} m/s²</div>
              </div>
              <div className="p-2.5 rounded-lg bg-gray-900 border border-cyan-500/20">
                <div className="text-[10px] text-cyan-400 font-mono-tech">ACCEL Y</div>
                <div className="text-sm font-bold font-mono-tech text-cyan-100">{motionData.y} m/s²</div>
              </div>
              <div className="p-2.5 rounded-lg bg-gray-900 border border-cyan-500/20">
                <div className="text-[10px] text-cyan-400 font-mono-tech">ACCEL Z</div>
                <div className="text-sm font-bold font-mono-tech text-cyan-100">{motionData.z} m/s²</div>
              </div>
            </div>

            {/* Pedometer Display */}
            <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
              <div>
                <div className="text-xs text-cyan-400/80 font-tech">ESTIMATED STEPS TODAY</div>
                <div className="text-2xl font-bold font-mono-tech text-cyan-100 flex items-center gap-2">
                  {stepCount.toLocaleString()}
                  <span className="text-xs font-normal text-cyan-400">/ 6,000 Goal</span>
                </div>
              </div>
              <button
                onClick={resetSteps}
                className="p-1.5 rounded-lg bg-gray-900 hover:bg-cyan-500/20 text-cyan-400 text-xs flex items-center gap-1 border border-cyan-500/20 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Reset
              </button>
            </div>
          </div>

          {/* Daily Vital Habits */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Hydration */}
            <div className="p-3.5 rounded-xl bg-gray-950/70 border border-cyan-500/25 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-tech text-cyan-300 uppercase flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5 text-cyan-400" /> Hydration
                </span>
                <span className="text-xs font-mono-tech text-cyan-400">{waterGlasses} / 8</span>
              </div>
              <div className="text-lg font-bold font-mono-tech text-cyan-100 mb-2">
                {(waterGlasses * 0.25).toFixed(2)} L
              </div>
              <button
                onClick={addWater}
                className="w-full py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase transition-colors cursor-pointer"
              >
                + Drink Glass
              </button>
            </div>

            {/* Sleep Log */}
            <div className="p-3.5 rounded-xl bg-gray-950/70 border border-cyan-500/25 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-tech text-cyan-300 uppercase flex items-center gap-1">
                  <Moon className="w-3.5 h-3.5 text-indigo-400" /> Rest
                </span>
                <span className="text-xs font-mono-tech text-indigo-400">Target 8h</span>
              </div>
              <div className="text-lg font-bold font-mono-tech text-cyan-100 mb-2">
                {sleepHours} Hours
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setSleepHours(prev => Math.max(0, prev - 0.5))}
                  className="flex-1 py-1 rounded bg-gray-900 border border-cyan-500/30 text-xs text-cyan-300"
                >
                  -
                </button>
                <button
                  onClick={() => setSleepHours(prev => prev + 0.5)}
                  className="flex-1 py-1 rounded bg-gray-900 border border-cyan-500/30 text-xs text-cyan-300"
                >
                  +
                </button>
              </div>
            </div>

            {/* Workout */}
            <div className="p-3.5 rounded-xl bg-gray-950/70 border border-cyan-500/25 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-tech text-cyan-300 uppercase flex items-center gap-1">
                  <Dumbbell className="w-3.5 h-3.5 text-emerald-400" /> Exercise
                </span>
                <span className="text-xs font-mono-tech text-emerald-400">Target 45m</span>
              </div>
              <div className="text-lg font-bold font-mono-tech text-cyan-100 mb-2">
                {workoutMins} Mins
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setWorkoutMins(prev => Math.max(0, prev - 5))}
                  className="flex-1 py-1 rounded bg-gray-900 border border-cyan-500/30 text-xs text-cyan-300"
                >
                  -
                </button>
                <button
                  onClick={() => setWorkoutMins(prev => prev + 5)}
                  className="flex-1 py-1 rounded bg-gray-900 border border-cyan-500/30 text-xs text-cyan-300"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-400/70 flex items-center justify-between">
          <span>Harman Sir, your physical readiness state is optimal.</span>
          <span className="font-mono-tech">STANDBY</span>
        </div>
      </div>
    </div>
  );
};
