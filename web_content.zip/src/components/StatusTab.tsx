import React, { useState, useEffect } from 'react';
import { Plus, Eye, Clock, X, Image as ImageIcon } from 'lucide-react';
import type { User, StatusStory } from '../types/index.ts';
import { api } from '../services/api.ts';

interface StatusTabProps {
  currentUser: User;
}

export const StatusTab: React.FC<StatusTabProps> = ({ currentUser }) => {
  const [statuses, setStatuses] = useState<StatusStory[]>([]);
  const [activeStory, setActiveStory] = useState<StatusStory | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCaption, setNewCaption] = useState('');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [loading, setLoading] = useState(true);

  const loadStatuses = async () => {
    try {
      const data = await api.getStatuses();
      setStatuses(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStatuses();
  }, []);

  const handleCreateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCaption.trim()) return;

    try {
      await api.createStatus(currentUser.id, newCaption.trim(), newMediaUrl.trim() || undefined);
      setNewCaption('');
      setNewMediaUrl('');
      setShowAddModal(false);
      loadStatuses();
    } catch (e: any) {
      alert(e.message || 'Failed to post status');
    }
  };

  const handleOpenStory = (story: StatusStory) => {
    setActiveStory(story);
    api.markStatusViewed(story.id, currentUser.id);
  };

  const myStatus = statuses.find(s => s.userId === currentUser.id);
  const otherStatuses = statuses.filter(s => s.userId !== currentUser.id);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080a0f] overflow-hidden text-slate-100">
      {/* Top Banner */}
      <div className="p-4 bg-[#0a0f18] border-b border-slate-800 shrink-0">
        <h2 className="text-sm font-bold text-white font-display uppercase tracking-wider">
          Gaming Status & Stories
        </h2>
        <p className="text-xs text-slate-400">Share 24-hour highlights, clips, and tournament updates</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* My Status Card */}
        <div className="p-3.5 rounded-2xl bg-[#0c121e] border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={currentUser.avatarUrl}
                alt="My Status"
                className="w-12 h-12 rounded-xl object-cover border-2 border-cyan-400"
              />
              <button
                onClick={() => setShowAddModal(true)}
                className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center font-bold"
              >
                <Plus size={14} />
              </button>
            </div>
            <div>
              <div className="font-bold text-white text-xs">My Gaming Status</div>
              <div className="text-[11px] text-slate-400">
                {myStatus ? (
                  <span className="text-cyan-400 font-medium">Active · {myStatus.viewers.length} views</span>
                ) : (
                  'Tap + to post a match highlight'
                )}
              </div>
            </div>
          </div>

          {myStatus && (
            <button
              onClick={() => handleOpenStory(myStatus)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-300"
            >
              View Mine
            </button>
          )}
        </div>

        {/* Recent Updates Header */}
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 px-1 mb-2">
            Recent Clan Updates ({otherStatuses.length})
          </div>

          {otherStatuses.length === 0 ? (
            <div className="p-8 text-center text-slate-500 rounded-xl bg-[#0a0f18] border border-slate-800/80">
              <Clock size={32} className="mx-auto mb-2 text-slate-600" />
              <p className="text-xs">No active updates from clan members</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {otherStatuses.map((story) => {
                const isViewed = story.viewers.includes(currentUser.id);
                return (
                  <div
                    key={story.id}
                    onClick={() => handleOpenStory(story)}
                    className="p-3 rounded-2xl bg-[#0c121e] border border-slate-800/80 hover:border-cyan-500/30 transition-all flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={story.userAvatar}
                          alt={story.username}
                          className={`w-12 h-12 rounded-xl object-cover border-2 ${
                            isViewed ? 'border-slate-700' : 'border-cyan-400 shadow-[0_0_10px_rgba(0,210,255,0.4)]'
                          }`}
                        />
                      </div>
                      <div>
                        <div className="font-bold text-white text-xs">{story.fullName}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[200px]">
                          {story.caption}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {new Date(story.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-slate-500">
                      <Eye size={14} />
                      <span>{story.viewers.length}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ADD STATUS MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-cyan-500/30 p-5 space-y-4 text-xs text-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm">Post Gaming Highlight</h3>
              <button onClick={() => setShowAddModal(false)}>
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateStatus} className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Highlight Caption *</label>
                <textarea
                  rows={2}
                  value={newCaption}
                  onChange={(e) => setNewCaption(e.target.value)}
                  placeholder="e.g. Scrims clutch victory 1v4! GG"
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 resize-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Media URL (Optional Image/Screenshot)</label>
                <input
                  type="text"
                  value={newMediaUrl}
                  onChange={(e) => setNewMediaUrl(e.target.value)}
                  placeholder="Paste image link..."
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold"
                >
                  Share to Squad
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FULL SCREEN STORY VIEWER */}
      {activeStory && (
        <div
          onClick={() => setActiveStory(null)}
          className="fixed inset-0 z-50 flex flex-col justify-between bg-black/95 p-4 sm:p-6"
        >
          {/* Progress bar */}
          <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mb-4">
            <div className="h-full bg-cyan-400 animate-[progress_5s_linear]" />
          </div>

          <div className="flex items-center justify-between text-white mb-auto">
            <div className="flex items-center gap-3">
              <img src={activeStory.userAvatar} alt="" className="w-10 h-10 rounded-xl object-cover" />
              <div>
                <div className="font-bold text-sm">{activeStory.fullName}</div>
                <div className="text-xs text-cyan-400 font-mono">@{activeStory.username}</div>
              </div>
            </div>
            <button onClick={() => setActiveStory(null)} className="p-2 text-slate-400 hover:text-white">
              <X size={20} />
            </button>
          </div>

          {/* Center media or large text */}
          <div className="my-auto max-w-lg mx-auto text-center space-y-4">
            {activeStory.mediaUrl && (
              <img
                src={activeStory.mediaUrl}
                alt="Story"
                className="max-h-[60vh] mx-auto rounded-2xl object-contain border border-slate-800"
              />
            )}
            <p className="text-lg md:text-xl font-bold text-white px-4 leading-relaxed font-display">
              "{activeStory.caption}"
            </p>
          </div>

          <div className="text-center text-xs text-slate-500 pt-4">
            {activeStory.viewers.length} clan members viewed
          </div>
        </div>
      )}
    </div>
  );
};
