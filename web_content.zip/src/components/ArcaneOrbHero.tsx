import React, { useState, useEffect, useRef } from 'react';
import { Coins, Zap, Sparkles } from 'lucide-react';
import { useGame, TapPoint } from '../context/GameContext';
import { formatNumber } from '../utils/formatters';
import arcaneCrystalOrbImg from '../assets/images/arcane_crystal_orb_1791261385611.jpg';

const FANTASY_CHRONICLES = [
  'Royal Court declares magical enterprises exempt from medieval harvest levies.',
  'Botanist Bramble discovers glowing lunar clover with triple mana density.',
  'Dwarven smiths claim mithril hammers strike truer than regular iron.',
  'Goblins open subterranean vaults with unprecedented 9.4% interest rates.',
  'Archmage Vaelin proclaims: "Gold is merely condensed ambient starlight."',
  'Griffin skyways report zero missed parcels across all kingdom peaks.',
  'Elder Wyrm spotted snoozing atop twenty cartloads of freshly minted coin.',
  'Planar tollway gatekeepers announce record trade traffic this quarter.',
  'Celestial Archons whisper: "The faithful sovereign shall ascend."',
  'Alchemical draughts rated 10/10 by guild adventurers exploring ancient crypts.',
];

// Orbiting rune glyphs around the orb (matching the orbiting cursors in Cookie Clicker)
const ORBIT_GLYPHS = [
  '✦', 'ᚱ', '⚡', 'ᛗ', '✧', 'ᛟ', '★', 'ᛋ', '✦', 'ᚹ', '⚡', 'ᚦ', '✧', 'ᛢ', '★', 'ᚢ'
];

interface TouchVisual {
  id: number;
  x: number;
  y: number;
}

export function ArcaneOrbHero() {
  const {
    gold,
    totalRealmProfitPerSec,
    effectiveProfitPerSec,
    tapsPerSec,
    clickOrb,
    frenzyMeter,
    isFrenzyActive,
    frenzyTimeRemaining,
    numberFormat,
  } = useGame();

  const [newsIndex, setNewsIndex] = useState(0);
  const [isPressed, setIsPressed] = useState(false);
  const [activeFingers, setActiveFingers] = useState<number>(0);
  const [touchRipples, setTouchRipples] = useState<TouchVisual[]>([]);
  const [imgError, setImgError] = useState(false);
  const [showFrenzyPopup, setShowFrenzyPopup] = useState(false);
  const prevFrenzyActive = useRef(false);
  const lastTouchTimestamp = useRef<number>(0);
  const rippleCounter = useRef<number>(1);
  const orbButtonRef = useRef<HTMLButtonElement | null>(null);
  const heroSectionRef = useRef<HTMLDivElement | null>(null);
  const clickOrbRef = useRef(clickOrb);
  const activeFingersRef = useRef<number>(0);

  // Keep clickOrb ref current without causing listener recreation
  useEffect(() => {
    clickOrbRef.current = clickOrb;
  }, [clickOrb]);

  // Trigger popup when Arcane Frenzy activates
  useEffect(() => {
    if (isFrenzyActive && !prevFrenzyActive.current) {
      setShowFrenzyPopup(true);
      const timer = setTimeout(() => {
        setShowFrenzyPopup(false);
      }, 3200);
      return () => clearTimeout(timer);
    } else if (!isFrenzyActive) {
      setShowFrenzyPopup(false);
    }
    prevFrenzyActive.current = isFrenzyActive;
  }, [isFrenzyActive]);

  // Rotate chronicle news ticker periodically
  useEffect(() => {
    const timer = setInterval(() => {
      setNewsIndex((prev) => (prev + 1) % FANTASY_CHRONICLES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  // Permanent capture-phase touch listeners on the hero section and orb
  // Completely eliminates Android Chrome/WebView pull-to-refresh ("refreshing" white flash) and multi-touch gesture conflicts
  useEffect(() => {
    const heroEl = heroSectionRef.current;
    const orbEl = orbButtonRef.current;
    if (!heroEl) return;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.cancelable) {
        e.preventDefault();
      }
      lastTouchTimestamp.current = Date.now();
      setIsPressed(true);

      const changedTouches = Array.from(e.changedTouches);
      const currentTotalFingers = Math.max(e.touches.length, changedTouches.length);
      activeFingersRef.current = currentTotalFingers;
      setActiveFingers(currentTotalFingers);

      const tapPoints: TapPoint[] = changedTouches.map((t) => ({
        clientX: t.clientX,
        clientY: t.clientY,
      }));

      if (tapPoints.length > 0) {
        clickOrbRef.current(tapPoints);
      }

      // Calculate ripples relative to the orb
      const rect = (orbEl || heroEl).getBoundingClientRect();
      const newRipples: TouchVisual[] = changedTouches.map((t) => ({
        id: rippleCounter.current++,
        x: t.clientX - rect.left,
        y: t.clientY - rect.top,
      }));

      setTouchRipples((prev) => [...prev.slice(-12), ...newRipples]);

      setTimeout(() => {
        setTouchRipples((prev) => prev.filter((r) => !newRipples.some((nr) => nr.id === r.id)));
      }, 550);

      setTimeout(() => {
        setIsPressed(false);
      }, 90);
    };

    const handleTouchMove = (e: TouchEvent) => {
      // Disallow micro-drags during rapid spamming to completely prevent browser pull-to-refresh
      if (e.cancelable) {
        e.preventDefault();
      }
    };

    const handleWindowTouchMove = (e: TouchEvent) => {
      // If user is currently touching the orb/hero or using multi-touch anywhere:
      if (activeFingersRef.current > 0 || (e.touches && e.touches.length > 1)) {
        if (e.cancelable) {
          e.preventDefault();
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (e.cancelable) {
        e.preventDefault();
      }
      if (e.touches.length === 0) {
        setIsPressed(false);
        activeFingersRef.current = 0;
        setTimeout(() => setActiveFingers(0), 120);
      } else {
        activeFingersRef.current = e.touches.length;
        setActiveFingers(e.touches.length);
      }
    };

    const handleTouchCancel = (e: TouchEvent) => {
      if (e.cancelable) {
        e.preventDefault();
      }
      setIsPressed(false);
      activeFingersRef.current = 0;
      setActiveFingers(0);
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Attach to heroEl with capture: true so gestures never reach native browser compositor
    heroEl.addEventListener('touchstart', handleTouchStart, { passive: false, capture: true });
    heroEl.addEventListener('touchmove', handleTouchMove, { passive: false, capture: true });
    heroEl.addEventListener('touchend', handleTouchEnd, { passive: false, capture: true });
    heroEl.addEventListener('touchcancel', handleTouchCancel, { passive: false, capture: true });
    heroEl.addEventListener('contextmenu', handleContextMenu);

    window.addEventListener('touchmove', handleWindowTouchMove, { passive: false, capture: true });

    if (orbEl) {
      orbEl.addEventListener('touchmove', handleTouchMove, { passive: false, capture: true });
      orbEl.addEventListener('contextmenu', handleContextMenu);
    }

    return () => {
      heroEl.removeEventListener('touchstart', handleTouchStart, { capture: true });
      heroEl.removeEventListener('touchmove', handleTouchMove, { capture: true });
      heroEl.removeEventListener('touchend', handleTouchEnd, { capture: true });
      heroEl.removeEventListener('touchcancel', handleTouchCancel, { capture: true });
      heroEl.removeEventListener('contextmenu', handleContextMenu);

      window.removeEventListener('touchmove', handleWindowTouchMove, { capture: true });

      if (orbEl) {
        orbEl.removeEventListener('touchmove', handleTouchMove, { capture: true });
        orbEl.removeEventListener('contextmenu', handleContextMenu);
      }
    };
  }, []);

  // Mouse click handler (for desktop mouse users)
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Ignore synthetic click triggered after touchstart
    if (Date.now() - lastTouchTimestamp.current < 500) {
      return;
    }

    setIsPressed(true);
    clickOrb([{ clientX: e.clientX, clientY: e.clientY }]);

    const rect = e.currentTarget.getBoundingClientRect();
    const ripple: TouchVisual = {
      id: rippleCounter.current++,
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
    setTouchRipples((prev) => [...prev.slice(-12), ripple]);

    setTimeout(() => {
      setTouchRipples((prev) => prev.filter((r) => r.id !== ripple.id));
    }, 550);

    setTimeout(() => setIsPressed(false), 90);
  };

  return (
    <div
      ref={heroSectionRef}
      data-no-pull="true"
      className="relative w-full flex flex-col items-center justify-center pt-3 pb-8 px-4 overflow-hidden select-none bg-gradient-to-b from-slate-950 via-slate-900/60 to-slate-950 border-b border-amber-900/30 touch-none"
      style={{
        touchAction: 'none',
        overscrollBehavior: 'none',
        overscrollBehaviorY: 'none',
        WebkitTouchCallout: 'none',
      }}
    >
      {/* Mystical Background Atmospheric Glow (GPU-safe radial gradient without filter blur) */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-950/30 via-slate-950/80 to-slate-950 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] sm:w-[650px] sm:h-[650px] rounded-full bg-[radial-gradient(circle,_rgba(6,182,212,0.12)_0%,_rgba(6,182,212,0.03)_50%,_transparent_70%)] pointer-events-none" />

      {/* Top News Chronicle Ticker */}
      <div className="relative z-10 w-full max-w-2xl text-center mb-3 px-4">
        <div className="inline-flex items-center gap-2 text-xs sm:text-sm text-slate-300 font-medium py-1 px-4 rounded-full bg-slate-900 border border-slate-800 shadow-sm truncate max-w-full">
          <span className="text-amber-400 font-bold uppercase tracking-wider text-[11px] shrink-0">
            Chronicle :
          </span>
          <span className="italic truncate text-slate-300">
            "{FANTASY_CHRONICLES[newsIndex]}"
          </span>
        </div>
      </div>

      {/* Centered Large Gold & Rate Display */}
      <div className="relative z-10 text-center mb-4 sm:mb-6">
        <div className="flex items-center justify-center gap-2">
          <h2 className="font-cinzel text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-amber-100 tabular-nums [text-shadow:0_4px_16px_rgba(245,158,11,0.3)]">
            {formatNumber(gold, numberFormat)}
          </h2>
          <span className="text-amber-400 font-cinzel text-xl sm:text-2xl font-bold">
            Gold
          </span>
        </div>

        <div className="text-sm sm:text-base font-semibold text-emerald-400/90 flex items-center justify-center gap-1.5 mt-1 tabular-nums flex-wrap px-2">
          <Coins className="w-4 h-4 text-emerald-400" />
          <span>+ {formatNumber(effectiveProfitPerSec, numberFormat)} / sec</span>
          {tapsPerSec > 0 && (
            <span className="text-amber-300 font-bold text-xs sm:text-sm bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full inline-flex items-center gap-1 animate-pulse shadow-sm shadow-amber-500/20">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>+{tapsPerSec} {tapsPerSec === 1 ? 'tap/s' : 'taps/s'}</span>
            </span>
          )}
          {isFrenzyActive && (
            <span className="text-amber-400 font-bold ml-2 animate-pulse flex items-center gap-0.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>3x OVERDRIVE (3x Taps & Revenue!)</span>
            </span>
          )}
        </div>
      </div>

      {/* Giant Arcane Orb with Multi-Finger Sensing */}
      <div
        data-no-pull="true"
        className="relative z-10 flex items-center justify-center my-2 sm:my-4 touch-none select-none"
        style={{
          touchAction: 'none',
          overscrollBehavior: 'none',
        }}
      >
        {/* Outer Orbiting Magical Runes Ring */}
        <div
          className={`absolute w-[310px] h-[310px] sm:w-[410px] sm:h-[410px] md:w-[480px] md:h-[480px] rounded-full pointer-events-none transition-all duration-500 will-change-transform ${
            isFrenzyActive ? 'animate-[spin_22s_linear_infinite]' : 'animate-[spin_60s_linear_infinite]'
          }`}
          style={{ transform: 'translate3d(0, 0, 0)' }}
        >
          {ORBIT_GLYPHS.map((glyph, index) => {
            const angle = (index / ORBIT_GLYPHS.length) * 2 * Math.PI;
            return (
              <div
                key={index}
                className={`absolute font-mono text-sm sm:text-base transition-colors ${
                  isFrenzyActive ? 'text-amber-300 font-bold [text-shadow:0_0_6px_rgba(245,158,11,0.8)]' : 'text-cyan-400/50 hover:text-cyan-300'
                }`}
                style={{
                  left: '50%',
                  top: '50%',
                  transform: `rotate(${angle}rad) translate(min(220px, 42vw)) rotate(-${angle}rad)`,
                }}
              >
                {glyph}
              </div>
            );
          })}
        </div>

        {/* Second Reverse Subtle Orbit Ring */}
        <div className={`absolute w-[280px] h-[280px] sm:w-[370px] sm:h-[370px] md:w-[440px] md:h-[440px] rounded-full border border-dashed pointer-events-none ${
          isFrenzyActive
            ? 'border-amber-400/50 animate-[spin_15s_linear_infinite_reverse]'
            : 'border-cyan-500/20 animate-[spin_40s_linear_infinite_reverse]'
        }`} />

        {/* The Clickable Giant Orb with Touch Event Handlers */}
        <button
          ref={orbButtonRef}
          type="button"
          onClick={handleClick}
          data-arcane-orb="true"
          data-no-pull="true"
          style={{
            touchAction: 'none',
            overscrollBehavior: 'none',
            userSelect: 'none',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
          }}
          className={`relative group w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-full cursor-pointer focus:outline-none transition-transform duration-75 ease-out touch-none select-none ${
            isPressed ? 'scale-95' : 'scale-100 hover:scale-[1.02]'
          }`}
          title="Channel Mana Sparks!"
          aria-label="Tap Arcane Mana Orb"
        >
          {/* Radiant Halo Backing (GPU-safe radial gradient halo without heavy blur) */}
          <div
            className={`absolute -inset-4 rounded-full transition-all duration-300 pointer-events-none ${
              isFrenzyActive
                ? 'bg-[radial-gradient(circle,_rgba(251,191,36,0.6)_0%,_rgba(245,158,11,0.25)_55%,_transparent_75%)] opacity-100 animate-pulse'
                : activeFingers > 1
                ? 'bg-[radial-gradient(circle,_rgba(252,211,77,0.5)_0%,_rgba(245,158,11,0.2)_55%,_transparent_75%)] opacity-100'
                : 'bg-[radial-gradient(circle,_rgba(34,211,238,0.4)_0%,_rgba(6,182,212,0.15)_55%,_transparent_75%)] opacity-80'
            }`}
          />

          {/* Golden Filigree Ring Container */}
          <div className={`relative w-full h-full rounded-full p-2 bg-gradient-to-br from-amber-400 via-cyan-500/50 to-amber-600 border-4 overflow-hidden transition-all duration-300 ${
            isFrenzyActive
              ? 'border-amber-400 shadow-[0_0_60px_rgba(245,158,11,0.8)]'
              : 'border-amber-300/60 shadow-[0_0_50px_rgba(6,182,212,0.4)]'
          }`}>
            {/* The High-Fidelity Arcane Crystal Image with Resilient Fallback */}
            {!imgError ? (
              <img
                src={arcaneCrystalOrbImg}
                alt="Arcane Crystal Orb"
                onError={() => setImgError(true)}
                className="w-full h-full object-cover rounded-full pointer-events-none select-none transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full rounded-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-300 via-indigo-600 to-slate-950 flex items-center justify-center pointer-events-none select-none shadow-inner">
                <div className="w-24 h-24 rounded-full bg-[radial-gradient(circle,_rgba(34,211,238,0.4)_0%,_transparent_70%)] animate-pulse" />
                <span className="font-cinzel text-5xl text-amber-200 [text-shadow:0_0_20px_rgba(245,158,11,0.8)] animate-pulse">
                  ✦
                </span>
              </div>
            )}

            {/* Active Arcane Frenzy Golden Energy Wave */}
            {isFrenzyActive && (
              <div className="absolute inset-0 rounded-full bg-gradient-to-t from-amber-500/25 via-transparent to-amber-300/30 pointer-events-none animate-pulse" />
            )}

            {/* Radiant Shimmer Overlay */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-t from-cyan-900/40 via-transparent to-amber-200/20 pointer-events-none" />

            {/* Localized Multi-Finger Touch Ripples */}
            {touchRipples.map((ripple) => (
              <div
                key={ripple.id}
                className="absolute w-12 h-12 -ml-6 -mt-6 rounded-full border-2 border-amber-300 bg-cyan-300/40 pointer-events-none animate-ping will-change-transform"
                style={{
                  left: `${ripple.x}px`,
                  top: `${ripple.y}px`,
                  transform: 'translate3d(0, 0, 0)',
                }}
              />
            ))}

            {/* Active Multi-Touch Flash */}
            {isPressed && activeFingers > 1 && (
              <div className="absolute inset-0 rounded-full bg-amber-400/35 pointer-events-none animate-pulse" />
            )}
          </div>
        </button>

        {/* Arcane Frenzy Pop-up Text (Centered directly over orb, purely text, no box) */}
        {showFrenzyPopup && (
          <div
            className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none z-30 px-3 animate-frenzy-pop"
            style={{ transform: 'translate3d(0, 0, 0)' }}
          >
            <div className="flex items-center justify-center gap-1.5 font-cinzel font-black text-2xl sm:text-3xl md:text-4xl text-amber-300 uppercase tracking-wider [text-shadow:0_0_16px_rgba(245,158,11,1),0_0_35px_rgba(251,191,36,0.9),0_2px_8px_rgba(0,0,0,0.95)]">
              <Zap className="w-6 h-6 sm:w-7 sm:h-7 text-amber-300 fill-amber-300 drop-shadow-[0_0_8px_rgba(245,158,11,1)] shrink-0" />
              <span>ARCANE OVERDRIVE!</span>
              <Sparkles className="w-6 h-6 sm:w-7 sm:h-7 text-amber-300 fill-amber-300 drop-shadow-[0_0_8px_rgba(245,158,11,1)] shrink-0" />
            </div>
            <div className="font-cinzel font-bold text-xs sm:text-sm md:text-base text-yellow-100 mt-1.5 [text-shadow:0_0_12px_rgba(245,158,11,0.9),0_2px_6px_rgba(0,0,0,1)] tracking-wide">
              ✦ 3x Taps & 3x Revenue Active! ✦
            </div>
          </div>
        )}
      </div>

      {/* Arcane Frenzy Bar Directly Below the Giant Orb */}
      <div className="relative z-10 w-full max-w-xs sm:max-w-sm mt-1.5 flex flex-col items-center">
        <div className="w-full h-2 sm:h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-700/80 shadow-inner">
          <div
            className={`h-full transition-all duration-150 ${
              isFrenzyActive
                ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 animate-pulse shadow-[0_0_12px_rgba(245,158,11,0.8)]'
                : 'bg-gradient-to-r from-cyan-500 to-blue-500'
            }`}
            style={{
              width: isFrenzyActive
                ? `${(frenzyTimeRemaining / 12) * 100}%`
                : `${frenzyMeter}%`,
            }}
          />
        </div>
        <div className="text-xs text-slate-400 mt-1 font-medium flex items-center gap-1.5">
          {isFrenzyActive ? (
            <span className="text-amber-300 font-bold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>ARCANE OVERDRIVE (3x Taps & Revenue • {frenzyTimeRemaining.toFixed(1)}s remaining)</span>
            </span>
          ) : (
            <span>Tap rapidly to unleash Arcane Overdrive ({Math.round(frenzyMeter)}%)</span>
          )}
        </div>
      </div>
    </div>
  );
}
