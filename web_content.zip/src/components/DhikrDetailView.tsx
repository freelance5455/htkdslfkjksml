import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  ChevronLeft, 
  ChevronRight, 
  Heart, 
  Copy, 
  Share2, 
  RotateCcw, 
  Undo2, 
  Check, 
  BookOpen, 
  ZoomIn, 
  ZoomOut, 
  Sparkles,
  Vibrate,
  Volume2,
  VolumeX,
  Sliders,
  X,
  Maximize2,
  Minimize2,
  Headphones,
  Type,
  Moon,
  Sun,
  Eye,
  Info,
  Award,
  Hourglass,
  Timer
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MORNING_ADHKAR, EVENING_ADHKAR, DEDICATION_TEXT } from '../data/adhkarData';
import { IslamicArchBorder } from './IslamicPattern';
import { DhikrAudioPlayer } from './DhikrAudioPlayer';
import { DhikrExplanationModal } from './DhikrExplanationModal';
import { DigitalCounter } from './DigitalCounter';
import { NightModeModal } from './NightModeModal';
import { DhikrPacingTimer } from './DhikrPacingTimer';
import { SmartTasbeehCounter } from './SmartTasbeehCounter';
import { recitationEngine } from '../utils/recitationService';
import { triggerVibration } from '../utils/audioFeedback';
import { MilestoneOption, NightReadingMode, NightWarmthLevel } from '../types';

// Format repetition number in Arabic words
function formatRepetitionArabic(count: number): string {
  if (count === 1) return 'مرة واحدة';
  if (count === 2) return 'مرتان';
  if (count === 3) return '٣ مرات';
  if (count === 4) return '٤ مرات';
  if (count === 7) return '٧ مرات';
  if (count === 10) return '١٠ مرات';
  if (count === 100) return '١٠٠ مرة';
  return `${count} مرات`;
}

export const DhikrDetailView: React.FC = () => {
  const { 
    selectedDhikr, 
    closeDhikr, 
    nextDhikr, 
    prevDhikr, 
    isFavorite, 
    toggleFavorite, 
    getProgressFor, 
    incrementProgress, 
    decrementProgress,
    resetDhikrProgress,
    setProgressValue,
    resetAllProgress,
    showToast,
    settings,
    updateSettings,
    setShowAmbientModal,
    ambientType,
    ambientPlaying,
    toggleAmbientPlay,
    solarTimes,
    totalDhikrCount,
    incrementTotalDhikrCount
  } = useApp();

  // Cumulative Lifetime Dhikr Count (محفوظ في localStorage وعبر التطبيق)
  const [lifetimeTotal, setLifetimeTotal] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('hisn_total_dhikr_count');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed)) return parsed;
      }
    } catch {}
    return totalDhikrCount || 0;
  });

  useEffect(() => {
    if (totalDhikrCount !== undefined) {
      setLifetimeTotal(totalDhikrCount);
    }
  }, [totalDhikrCount]);

  const [copied, setCopied] = useState(false);
  const [tapEffect, setTapEffect] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [showMilestoneModal, setShowMilestoneModal] = useState(false);
  const [showExplanationModal, setShowExplanationModal] = useState(false);
  const [showNightModeModal, setShowNightModeModal] = useState(false);
  const [fullScreenMode, setFullScreenMode] = useState(false);
  const [freeCounterMode, setFreeCounterMode] = useState(false);
  const [smartTarget, setSmartTarget] = useState<number>(selectedDhikr?.count || 1);
  const [cyclesCompleted, setCyclesCompleted] = useState<number>(0);
  const [showSmartTasbeehModal, setShowSmartTasbeehModal] = useState<boolean>(false);

  // Optional Pacing & Contemplation Timer (مؤقت زمني اختياري لقراءة الأذكار بتمهل وتؤدة)
  const [showPacingTimer, setShowPacingTimer] = useState<boolean>(() => {
    try {
      return localStorage.getItem('hisn_show_pacing_timer') === 'true';
    } catch {
      return false;
    }
  });

  const togglePacingTimer = () => {
    const next = !showPacingTimer;
    setShowPacingTimer(next);
    triggerVibration(settings.vibration !== false, 'light');
    try {
      localStorage.setItem('hisn_show_pacing_timer', next ? 'true' : 'false');
    } catch {}
    if (next) {
      showToast('تم تفعيل مؤقت التمهل والتدبر ⏱️ اقرأ بتؤدة وسكينة');
    } else {
      showToast('تم إيقاف مؤقت التمهل');
    }
  };

  useEffect(() => {
    if (selectedDhikr) {
      setSmartTarget(selectedDhikr.count);
      setCyclesCompleted(0);
    }
  }, [selectedDhikr?.id, selectedDhikr?.count]);

  // Night Reading Mode (وضع القراءة الليلي: تلقائي أو يدوي مع درجات الدفء وتخفيف الضوء الأزرق)
  const nightReadingMode: NightReadingMode = settings.nightReadingMode || 'auto';
  const nightWarmthLevel: NightWarmthLevel = settings.nightWarmthLevel || 'warm';
  const isNightReadingActive = nightReadingMode === 'on' || (nightReadingMode === 'auto' && solarTimes.isNight);

  const cycleNightReadingMode = () => {
    let next: NightReadingMode;
    if (nightReadingMode === 'auto') {
      next = 'on';
    } else if (nightReadingMode === 'on') {
      next = 'off';
    } else {
      next = 'auto';
    }
    updateSettings({ nightReadingMode: next });
    if (next === 'auto') {
      showToast(solarTimes.isNight ? 'وضع القراءة الليلي: تلقائي (مفعّل الآن لحلول الليل 🌙)' : 'وضع القراءة الليلي: تلقائي (سيفعّل عند حلول الليل 🌅)');
    } else if (next === 'on') {
      showToast('تم تفعيل وضع القراءة الليلي يدوياً (ألوان معتمة وتباين مريح للعين) 🌙');
    } else {
      showToast('تم إيقاف وضع القراءة الليلي ☀️');
    }
  };

  const setNightReadingMode = (mode: NightReadingMode) => {
    updateSettings({ nightReadingMode: mode });
    if (mode === 'auto') {
      showToast(solarTimes.isNight ? 'وضع القراءة الليلي: تلقائي (مفعّل الآن لحلول الليل 🌙)' : 'وضع القراءة الليلي: تلقائي (سيفعّل عند حلول الليل 🌅)');
    } else if (mode === 'on') {
      showToast('تم تفعيل وضع القراءة الليلي يدوياً (ألوان معتمة وتباين مريح للعين) 🌙');
    } else {
      showToast('تم إيقاف وضع القراءة الليلي ☀️');
    }
  };

  // Ensure audio stops if detail view closes
  useEffect(() => {
    return () => {
      recitationEngine.stop();
    };
  }, []);

  if (!selectedDhikr) return null;

  const currentCount = getProgressFor(selectedDhikr.id);
  const effectiveTarget = smartTarget > 0 ? smartTarget : selectedDhikr.count;
  const targetCount = effectiveTarget;
  const isCompleted = !freeCounterMode && currentCount >= targetCount;
  const remaining = Math.max(0, targetCount - currentCount);
  const progressRatio = targetCount > 0 ? Math.min(currentCount / targetCount, 1) : 0;
  const favorited = isFavorite(selectedDhikr.id);

  // Position in list (e.g. 5 of 24)
  const list = selectedDhikr.category === 'morning' ? MORNING_ADHKAR : EVENING_ADHKAR;
  const currentIndex = list.findIndex(d => d.id === selectedDhikr.id);
  const totalInList = list.length;
  const hasNext = currentIndex < totalInList - 1;
  const hasPrev = currentIndex > 0;

  // Circular progress calculations for the SVG Dial
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = freeCounterMode 
    ? circumference - ((currentCount % 100) / 100) * circumference
    : circumference - progressRatio * circumference;

  const handleTasbeehTap = () => {
    if (isCompleted) {
      triggerVibration(settings.vibration !== false, 'complete');
      return;
    }
    setTapEffect(true);
    setTimeout(() => setTapEffect(false), 140);

    // Immediate tactile haptic feedback on counter tap
    const nextCount = currentCount + 1;
    const isTargetDone = !freeCounterMode && nextCount >= targetCount;
    const msOption = settings.vibrationMilestone || '33';
    const isMilestone = 
      (msOption === '33' && (nextCount % 33 === 0 || nextCount === 100)) ||
      (msOption === '10' && nextCount % 10 === 0) ||
      (msOption === 'target' && isTargetDone);

    // VIBRATION FEATURE WHEN REACHING TARGET COUNT (الاهتزاز عند الوصول للعدد المستهدف)
    if (isTargetDone) {
      triggerVibration(settings.vibration !== false, 'complete');
      showToast(`🎯 تم الوصول للعدد المستهدف (${targetCount} تسبيحة)! هنيئاً لك الأجر`);
    } else if (isMilestone) {
      triggerVibration(settings.vibration !== false, 'milestone');
    } else {
      triggerVibration(settings.vibration !== false, 'tap');
    }

    // Update cumulative lifetime total tasbeeh count in state & localStorage
    const nextTotal = lifetimeTotal + 1;
    setLifetimeTotal(nextTotal);
    try {
      localStorage.setItem('hisn_total_dhikr_count', nextTotal.toString());
    } catch {}
    incrementTotalDhikrCount(1);

    if (nextTotal === 100 || nextTotal === 500 || nextTotal === 1000 || nextTotal === 5000 || nextTotal === 10000) {
      showToast(`ما شاء الله! بلغت ${nextTotal.toLocaleString('ar-EG')} تسبيحة في رصيدك التراكمي المبارك ✨`);
    }

    incrementProgress(selectedDhikr.id);
  };

  const handleUndo = () => {
    triggerVibration(settings.vibration !== false, 'undo');
    const nextTotal = Math.max(0, lifetimeTotal - 1);
    setLifetimeTotal(nextTotal);
    try {
      localStorage.setItem('hisn_total_dhikr_count', nextTotal.toString());
    } catch {}
    decrementProgress(selectedDhikr.id);
  };

  const handleStartNewCycle = () => {
    triggerVibration(settings.vibration !== false, 'tap');
    setCyclesCompleted(prev => prev + 1);
    setProgressValue(selectedDhikr.id, 0);
    showToast(`بدء الدورة ${cyclesCompleted + 2} من التسبيح الذكي (${targetCount} تسبيحة) 🔄`);
  };

  const handleSetTarget = (newTarget: number) => {
    triggerVibration(settings.vibration !== false, 'tap');
    setSmartTarget(newTarget);
    if (freeCounterMode) setFreeCounterMode(false);
    showToast(`تم تعيين الهدف الذكي للتكرار: ${newTarget} تسبيحة 🎯`);
  };

  const isUthmani = settings.arabicFont === 'uthmani';

  const toggleUthmaniScript = () => {
    const nextFont = isUthmani ? 'amiri' : 'uthmani';
    updateSettings({ arabicFont: nextFont });
    showToast(nextFont === 'uthmani' ? 'تم تفعيل الخط العثماني (رسم المصحف) 📖' : 'تم العودة للخط القياسي');
  };

  const cycleFontSize = () => {
    const nextSize = settings.fontSize === 'sm' ? 'md' : settings.fontSize === 'md' ? 'lg' : 'sm';
    updateSettings({ fontSize: nextSize });
    const label = nextSize === 'sm' ? 'صغير' : nextSize === 'md' ? 'متوسط' : 'كبير';
    showToast(`حجم الخط: ${label}`);
  };

  // Font size mapping (صغير، متوسط، كبير)
  const getFontSizeClass = () => {
    switch (settings.fontSize) {
      case 'sm': return 'text-lg md:text-xl';
      case 'md': return 'text-xl md:text-2xl';
      case 'lg': 
      case 'xl':
      default: return 'text-2xl md:text-3xl';
    }
  };

  const handleCopy = async () => {
    const textToCopy = `${selectedDhikr.text}\n\n[عدد التكرار: ${selectedDhikr.count} ${selectedDhikr.note ? selectedDhikr.note : ''}]\nمن تطبيق: ${DEDICATION_TEXT.appName} - ${DEDICATION_TEXT.subTitle}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        showToast('تم نسخ الذكر بنجاح');
        setTimeout(() => setCopied(false), 2000);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = textToCopy;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopied(true);
        showToast('تم نسخ الذكر بنجاح');
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      showToast('تعذر النسخ');
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: `${selectedDhikr.title} - ${DEDICATION_TEXT.appName}`,
      text: `${selectedDhikr.text}\n\n[عدد التكرار: ${selectedDhikr.count}]\n${DEDICATION_TEXT.appName} - ${DEDICATION_TEXT.subTitle}`,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User cancelled or not supported
      }
    } else {
      handleCopy();
    }
  };

  const adjustFontSize = (delta: 'up' | 'down') => {
    const sizes: ('sm' | 'md' | 'lg' | 'xl')[] = ['sm', 'md', 'lg', 'xl'];
    const curIdx = sizes.indexOf(settings.fontSize);
    if (delta === 'up' && curIdx < sizes.length - 1) {
      updateSettings({ fontSize: sizes[curIdx + 1] });
    } else if (delta === 'down' && curIdx > 0) {
      updateSettings({ fontSize: sizes[curIdx - 1] });
    }
  };

  // Milestone check for UI badges
  const isHighCount = targetCount >= 33 || freeCounterMode;
  const milestones = [33, 66, 99, 100];

  return (
    <div className={`fixed inset-0 z-40 flex flex-col justify-between overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-200 transition-colors ${
      isNightReadingActive
        ? nightWarmthLevel === 'deep_amber'
          ? 'bg-[#070503] text-[#ebd4b8]'
          : nightWarmthLevel === 'mild'
            ? 'bg-[#100d09] text-[#eedbc5]'
            : 'bg-[#0c0906] text-[#edd8bf]'
        : 'bg-[#f4f8f5] dark:bg-[#02140e] text-[#0c2e20] dark:text-[#e8f5ee]'
    }`}>
      {/* Top Header Bar */}
      <header className={`sticky top-0 z-10 backdrop-blur-md px-4 py-2.5 flex items-center justify-between shadow-xs transition-colors ${
        isNightReadingActive
          ? 'bg-[#120d09]/95 border-b border-amber-900/50 text-[#edd8bf]'
          : 'bg-[#ffffff]/95 dark:bg-[#042017]/95 border-b border-emerald-600/15 dark:border-emerald-800/60'
      }`}>
        <button
          onClick={() => {
            recitationEngine.stop();
            closeDhikr();
          }}
          className={`p-2 -mr-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer ${
            isNightReadingActive
              ? 'text-amber-200 hover:bg-amber-950/60'
              : 'text-[#e8f5ee] hover:bg-emerald-900/40'
          }`}
          aria-label="الرجوع للقائمة"
        >
          <ArrowRight className={`w-5 h-5 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-400'}`} />
          <span className="text-sm font-bold font-cairo">رجوع</span>
        </button>

        <div className="text-center truncate px-2">
          <p className={`text-xs font-bold font-tajawal ${
            isNightReadingActive ? 'text-amber-400' : 'text-amber-300'
          }`}>
            {selectedDhikr.categoryArabic} ({currentIndex + 1} من {totalInList})
          </p>
          <h2 className={`text-sm md:text-base font-extrabold truncate font-cairo ${
            isNightReadingActive ? 'text-[#f5ebd9]' : 'text-[#e8f5ee]'
          }`}>
            {selectedDhikr.title}
          </h2>
        </div>

        {/* Quick actions: Explanation & virtue, Ambient sound, Uthmani, Font adjust, Night Mode, Fullscreen */}
        <div className="flex items-center gap-1">
          {/* Quick Info & Virtue Button */}
          <button
            onClick={() => setShowExplanationModal(true)}
            className="p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-400/40 shadow-xs"
            title="عرض فضل هذا الذكر وتفسيره ومعانيه والوقفة التدبرية"
            aria-label="فضل الذكر وتفسيره"
          >
            <Info className="w-4 h-4 text-amber-400" />
            <span className="text-[11px] font-tajawal font-bold hidden md:inline text-amber-200">
              فضل وتفسير
            </span>
          </button>

          {/* Ambient Sound Button */}
          <button
            onClick={() => setShowAmbientModal(true)}
            className={`p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer ${
              ambientPlaying 
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/50 shadow-xs' 
                : isNightReadingActive ? 'text-amber-300/70 hover:bg-amber-950/60' : 'text-[#a7d7c0] hover:bg-emerald-900/30'
            }`}
            title="أصوات السكينة والخشوع (مطر، طيور، طبيعة)"
            aria-label="أصوات السكينة والخشوع"
          >
            <Headphones className={`w-4 h-4 ${ambientPlaying ? 'animate-pulse text-amber-300' : ''}`} />
            {ambientPlaying && (
              <span className="text-[10px] font-tajawal font-bold text-amber-300 hidden sm:inline">
                {ambientType === 'rain' ? 'مطر 🌧️' : ambientType === 'birds' ? 'طيور 🕊️' : ambientType === 'nature' ? 'طبيعة 🍃' : ambientType === 'water' ? 'ماء 🌊' : 'ليل 🌙'}
              </span>
            )}
          </button>

          {/* Quick Uthmani Script Toggle Button */}
          <button
            onClick={toggleUthmaniScript}
            className={`p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer border ${
              isUthmani
                ? 'bg-amber-500/20 text-amber-300 border-amber-400/60 shadow-xs ring-1 ring-amber-400/30'
                : isNightReadingActive ? 'text-amber-300/70 border-transparent hover:bg-amber-950/60' : 'text-[#a7d7c0] border-transparent hover:bg-emerald-900/30'
            }`}
            title={isUthmani ? 'الخط العثماني مفعل (اضغط للإلغاء)' : 'تحويل النص إلى الخط العثماني'}
            aria-label="تبديل الخط العثماني"
          >
            <BookOpen className={`w-4 h-4 ${isUthmani ? 'text-amber-400' : 'text-emerald-400'}`} />
            <span className="text-[11px] font-tajawal font-bold hidden sm:inline">
              {isUthmani ? 'عثماني ✓' : 'عثماني'}
            </span>
          </button>

          {/* Quick Font Size Switcher Button (صغير / متوسط / كبير) */}
          <button
            onClick={cycleFontSize}
            className={`p-2 rounded-xl border transition-colors cursor-pointer flex items-center gap-1 font-bold text-xs ${
              isNightReadingActive
                ? 'text-amber-300/80 border-amber-900/40 hover:bg-amber-950/60'
                : 'text-[#a7d7c0] hover:bg-emerald-900/30 border-emerald-800/40'
            }`}
            title="تبديل حجم الخط: صغير • متوسط • كبير"
            aria-label="تبديل حجم الخط"
          >
            <Type className={`w-4 h-4 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-400'}`} />
            <span className="text-[11px] font-tajawal">
              {settings.fontSize === 'sm' ? 'صغير' : settings.fontSize === 'md' ? 'متوسط' : 'كبير'}
            </span>
          </button>

          {/* Night Reading Mode Quick Button (وضع القراءة الليلية لراحة العين والضوء الأزرق) */}
          <button
            onClick={() => setShowNightModeModal(true)}
            className={`p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer border ${
              isNightReadingActive
                ? 'bg-amber-500/25 text-amber-300 border-amber-400/60 shadow-xs ring-1 ring-amber-400/40'
                : 'text-[#a7d7c0] border-transparent hover:bg-emerald-900/30'
            }`}
            title={
              nightReadingMode === 'on' 
                ? 'وضع القراءة الليلي: مفعّل يدوياً (ألوان دافئة وضوء أزرق مخفض) 🌙'
                : nightReadingMode === 'auto'
                  ? solarTimes.isNight ? 'وضع القراءة الليلي: تلقائي (مفعّل الآن لحلول الليل) 🌙' : 'وضع القراءة الليلي: تلقائي (سيفعّل مع الليل) 🌅'
                  : 'وضع القراءة الليلي: معطل ☀️ (اضغط للتفعيل لراحة العين)'
            }
            aria-label="وضع القراءة الليلي"
          >
            <Moon className={`w-4 h-4 ${isNightReadingActive ? 'text-amber-400 fill-amber-400/40' : 'text-emerald-400'}`} />
            <span className="text-[11px] font-tajawal font-bold hidden sm:inline">
              {isNightReadingActive ? 'ليلي 🌙' : 'ليلي'}
            </span>
          </button>

          {/* Optional Pacing & Contemplation Timer Button (مؤقت التمهل والتدبر) */}
          <button
            onClick={togglePacingTimer}
            className={`p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer border ${
              showPacingTimer
                ? isNightReadingActive
                  ? 'bg-amber-500/25 text-amber-300 border-amber-400/60 shadow-xs ring-1 ring-amber-400/40'
                  : 'bg-emerald-600/25 text-emerald-300 border-emerald-500/60 shadow-xs ring-1 ring-emerald-400/40'
                : isNightReadingActive ? 'text-amber-300/70 border-transparent hover:bg-amber-950/60' : 'text-[#a7d7c0] border-transparent hover:bg-emerald-900/30'
            }`}
            title={showPacingTimer ? 'إيقاف / إخفاء مؤقت التمهل والتدبر' : 'تفعيل مؤقت التمهل لمساعدتك على قراءة الذكر بتمهل وتؤدة ⏱️'}
            aria-label="مؤقت التمهل والتدبر"
          >
            <Hourglass className={`w-4 h-4 ${showPacingTimer ? 'text-amber-400 animate-pulse' : isNightReadingActive ? 'text-amber-400' : 'text-emerald-400'}`} />
            <span className="text-[11px] font-tajawal font-bold hidden sm:inline">
              {showPacingTimer ? 'تمهل ✓' : 'تمهل'}
            </span>
          </button>

          {/* Smart Tasbeeh Counter Button (عداد تسبيح رقمي مع ميزة الاهتزاز وحفظ العدد) */}
          <button
            onClick={() => setShowSmartTasbeehModal(true)}
            className={`p-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer border ${
              isNightReadingActive
                ? 'text-amber-300 border-amber-900/40 hover:bg-amber-950/60'
                : 'text-amber-300 bg-amber-500/10 border-amber-500/30 hover:bg-amber-500/20'
            }`}
            title="عداد تسبيح رقمي مستقل مع ميزة الاهتزاز عند أرقام معينة وحفظ العدد تلقائياً"
            aria-label="المسبحة الرقمية الذكية"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-[11px] font-tajawal font-bold hidden sm:inline">
              مسبحة
            </span>
          </button>

          <button
            onClick={() => setFullScreenMode(!fullScreenMode)}
            className={`p-2 rounded-lg transition-colors cursor-pointer ${
              fullScreenMode 
                ? isNightReadingActive ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40' : 'bg-emerald-800/30 text-emerald-300' 
                : isNightReadingActive ? 'text-amber-300/70 hover:bg-amber-950/60' : 'text-[#a7d7c0] hover:bg-emerald-900/30'
            }`}
            title={fullScreenMode ? 'الخروج من وضع التركيز' : 'وضع التركيز والتسبيح'}
            aria-label="وضع التركيز والتسبيح"
          >
            {fullScreenMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Dhikr Card (Scrollable, hidden or minimized in fullscreen focus mode) */}
      {!fullScreenMode && (
        <div className="flex-1 overflow-y-auto px-4 py-2.5 max-w-2xl mx-auto w-full flex flex-col justify-start">
          <div 
            onClick={(e) => {
              const target = e.target as HTMLElement;
              if (target.closest('button') || target.closest('input') || target.closest('audio') || target.closest('a')) {
                return;
              }
              handleTasbeehTap();
            }}
            className={`border rounded-3xl p-5 md:p-6 flex flex-col items-center text-center relative overflow-hidden transition-all cursor-pointer active:scale-[0.99] select-none ${
            isNightReadingActive
              ? 'bg-[#150f0a] border-amber-800/40 shadow-amber-950/20 text-[#edd8bf]'
              : 'bg-[#ffffff] dark:bg-[#042017] border-emerald-600/15 dark:border-emerald-700/60 shadow-md text-[#0c2e20] dark:text-[#e8f5ee]'
          }`}>
            {/* Eye Comfort Warm Banner (يظهر عند تفعيل وضع القراءة الليلية) */}
            {isNightReadingActive && (
              <div className="w-full flex items-center justify-between gap-2 px-3.5 py-1.5 mb-2.5 rounded-2xl bg-amber-950/60 border border-amber-800/40 text-amber-200 text-xs animate-in fade-in duration-150">
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-amber-400 fill-amber-400/30 shrink-0" />
                  <span className="font-tajawal text-[11px] leading-tight">
                    وضع القراءة الليلية مفعّل · ألوان دافئة وضوء أزرق مخفف لنوم هادئ
                  </span>
                </div>
                <button
                  onClick={() => setShowNightModeModal(true)}
                  className="text-[10px] font-bold text-amber-300 hover:text-white px-2 py-0.5 rounded-lg bg-amber-900/50 border border-amber-700/40 transition-colors cursor-pointer shrink-0"
                >
                  تعديل الدفء
                </button>
              </div>
            )}

            {/* Repetition and Title Header */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-2">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold font-cairo ${
                isNightReadingActive
                  ? 'bg-amber-950/60 border-amber-800/40 text-amber-200'
                  : 'bg-emerald-900/10 dark:bg-emerald-950/70 border-emerald-800/20 dark:border-emerald-700/40 text-emerald-900 dark:text-emerald-200'
              }`}>
                <BookOpen className={`w-3.5 h-3.5 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-700 dark:text-emerald-400'}`} />
                <span>{selectedDhikr.title}</span>
              </span>

              {/* Repetition Badge */}
              <span className={`inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full border text-xs font-bold font-cairo shadow-2xs ${
                isNightReadingActive
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-emerald-700/15 border-emerald-600/40 text-[#123828] dark:text-emerald-300'
              }`}>
                <Sparkles className={`w-3 h-3 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-700 dark:text-emerald-400'}`} />
                <span>التكرار: {formatRepetitionArabic(selectedDhikr.count)}</span>
              </span>

              {selectedDhikr.isQuran && (
                <span className={`px-2.5 py-1 rounded-full border text-xs font-bold ${
                  isNightReadingActive
                    ? 'bg-amber-950/50 border-amber-700/40 text-amber-200'
                    : 'bg-emerald-800/10 dark:bg-emerald-950/50 border border-emerald-600/30 text-emerald-800 dark:text-emerald-300'
                }`}>
                  قرآن كريم
                </span>
              )}

              {/* Dedicated Info / Virtue Badge Button */}
              <button
                onClick={() => setShowExplanationModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/15 via-amber-400/20 to-amber-500/15 hover:from-amber-500/25 hover:to-amber-500/25 border border-amber-500/40 text-amber-900 dark:text-amber-200 text-xs font-bold font-cairo shadow-2xs transition-all cursor-pointer group"
                title="اضغط لعرض فضل الذكر وتفسيره ومعانيه والتدبر"
              >
                <Info className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform" />
                <span>فضل وتفسير الذكر</span>
                <span className="text-[10px] bg-amber-500/20 dark:bg-amber-400/20 px-1 rounded-md text-amber-800 dark:text-amber-300 font-normal">
                  تدبّر
                </span>
              </button>
            </div>

            {/* Reading Typography Controls Bar: Font Size (صغير، متوسط، كبير) & Uthmani Script Toggle Switch */}
            <div className={`w-full flex flex-wrap items-center justify-between gap-2.5 px-3.5 py-2 my-2 border rounded-2xl shadow-xs transition-colors ${
              isNightReadingActive
                ? 'bg-[#100a06]/90 border-amber-900/40 text-amber-200'
                : 'bg-[#f0f7f3]/90 dark:bg-[#031d14]/90 border-emerald-600/20 dark:border-emerald-700/60'
            }`}>
              {/* Font Size 3-Way Switcher: صغير | متوسط | كبير */}
              <div className="flex items-center gap-1.5">
                <span className={`text-[11px] font-bold font-cairo flex items-center gap-1 ${
                  isNightReadingActive ? 'text-amber-300' : 'text-[#1a4432] dark:text-emerald-300'
                }`}>
                  <Type className={`w-3.5 h-3.5 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                  <span>حجم الخط:</span>
                </span>
                <div className={`inline-flex items-center p-0.5 rounded-xl border shadow-inner ${
                  isNightReadingActive ? 'bg-[#181109] border-amber-900/50' : 'bg-white dark:bg-[#05261b] border-emerald-600/25 dark:border-emerald-700/50'
                }`}>
                  <button
                    onClick={() => {
                      updateSettings({ fontSize: 'sm' });
                      showToast('حجم الخط: صغير');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      settings.fontSize === 'sm'
                        ? isNightReadingActive ? 'bg-amber-600 text-black shadow-xs font-black' : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                        : isNightReadingActive ? 'text-amber-300 hover:bg-amber-950/40' : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                    }`}
                    aria-label="خط صغير"
                  >
                    صغير
                  </button>
                  <button
                    onClick={() => {
                      updateSettings({ fontSize: 'md' });
                      showToast('حجم الخط: متوسط');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      settings.fontSize === 'md'
                        ? isNightReadingActive ? 'bg-amber-600 text-black shadow-xs font-black' : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                        : isNightReadingActive ? 'text-amber-300 hover:bg-amber-950/40' : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                    }`}
                    aria-label="خط متوسط"
                  >
                    متوسط
                  </button>
                  <button
                    onClick={() => {
                      updateSettings({ fontSize: 'lg' });
                      showToast('حجم الخط: كبير');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      settings.fontSize === 'lg' || settings.fontSize === 'xl'
                        ? isNightReadingActive ? 'bg-amber-600 text-black shadow-xs font-black' : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                        : isNightReadingActive ? 'text-amber-300 hover:bg-amber-950/40' : 'text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500/10'
                    }`}
                    aria-label="خط كبير"
                  >
                    كبير
                  </button>
                </div>
              </div>

              {/* Uthmani Script Toggle Switch (تحويل النص إلى الخط العثماني) */}
              <button
                onClick={toggleUthmaniScript}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  isUthmani
                    ? 'bg-gradient-to-r from-amber-500/20 via-amber-400/25 to-amber-500/20 text-amber-300 border-amber-400/70 shadow-xs ring-1 ring-amber-400/30'
                    : isNightReadingActive
                      ? 'bg-[#181109] text-amber-300 border-amber-900/50 hover:border-amber-500/40'
                      : 'bg-white dark:bg-[#05261b] text-emerald-800 dark:text-emerald-200 border-emerald-600/25 dark:border-emerald-700/50 hover:border-amber-400/50'
                }`}
                title={isUthmani ? 'الخط العثماني مفعل (اضغط للإلغاء)' : 'تحويل النص إلى الخط العثماني ورسم المصحف'}
                aria-label="تبديل الخط العثماني"
              >
                <BookOpen className={`w-3.5 h-3.5 ${isUthmani ? 'text-amber-400' : isNightReadingActive ? 'text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                <span className="font-cairo">الخط العثماني</span>
                {/* Switch indicator pill */}
                <div className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                  isUthmani ? 'bg-amber-500 justify-end' : isNightReadingActive ? 'bg-amber-950 justify-start' : 'bg-emerald-800/30 dark:bg-emerald-950 justify-start'
                }`}>
                  <div className="w-3 h-3 rounded-full bg-white shadow-xs" />
                </div>
              </button>
            </div>

            <IslamicArchBorder className={`${isNightReadingActive ? 'text-amber-700/30' : 'text-emerald-600/30'} my-1`} />

            {/* Full Arabic Text with Night Mode Comfort Warmth */}
            <div className="w-full my-auto py-2">
              {isUthmani && (
                <div className="flex items-center justify-center gap-1.5 mb-2">
                  <span className="text-[11px] font-bold text-amber-600 dark:text-amber-300 font-cairo bg-amber-400/10 border border-amber-400/30 px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-amber-500 dark:text-amber-400" />
                    <span>رسم المصحف الشريف (الخط العثماني)</span>
                  </span>
                </div>
              )}
              <p 
                className={`${isUthmani ? 'font-uthmani leading-[2.6]' : 'font-quran leading-loose'} ${getFontSizeClass()} ${
                  isNightReadingActive 
                    ? 'text-[#f5ebd9] selection:bg-amber-800' 
                    : 'text-[#0c2e20] dark:text-[#e4f2ea]'
                } font-normal tracking-wide text-center select-text transition-all duration-150`}
                dir="rtl"
              >
                {selectedDhikr.text}
              </p>
            </div>

            {selectedDhikr.note && (
              <p className={`mt-1 text-xs font-semibold font-tajawal border px-3 py-1 rounded-xl ${
                isNightReadingActive
                  ? 'bg-amber-950/40 border-amber-800/40 text-amber-200'
                  : 'text-emerald-900 dark:text-emerald-200 bg-emerald-800/10 dark:bg-emerald-950/50 border-emerald-600/30'
              }`}>
                {selectedDhikr.note}
              </p>
            )}

            {/* Simple audio player for recitation with chosen reciter */}
            <div className="w-full mt-2">
              <DhikrAudioPlayer 
                dhikr={selectedDhikr} 
                isNightReadingActive={isNightReadingActive}
              />
            </div>

            {/* Optional Pacing & Contemplation Timer (مؤقت التمهل والتدبر في بطاقة الذكر) */}
            {showPacingTimer && (
              <div className="w-full mt-2.5 animate-in fade-in duration-200">
                <DhikrPacingTimer
                  dhikrText={selectedDhikr.text}
                  dhikrCount={targetCount}
                  currentCount={currentCount}
                  isNightReadingActive={isNightReadingActive}
                  onAutoIncrement={handleTasbeehTap}
                  onNotify={(msg) => showToast(msg)}
                  onClose={() => {
                    setShowPacingTimer(false);
                    try { localStorage.setItem('hisn_show_pacing_timer', 'false'); } catch {}
                    showToast('تم إخفاء مؤقت التمهل');
                  }}
                />
              </div>
            )}

            {/* Utility Toolbar for this Dhikr */}
            <div className={`flex flex-wrap items-center justify-center gap-2 mt-4 pt-3 border-t w-full ${
              isNightReadingActive
                ? 'border-amber-900/40 text-amber-200/90'
                : 'border-emerald-100 dark:border-emerald-800/50 text-[#2b5945] dark:text-emerald-200/90'
            }`}>
              {/* Optional Pacing Timer Toggle Button */}
              <button
                onClick={togglePacingTimer}
                className={`px-3 py-1.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                  showPacingTimer
                    ? isNightReadingActive
                      ? 'border-amber-500 bg-amber-950/60 text-amber-300'
                      : 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-600'
                    : isNightReadingActive
                      ? 'border-amber-900/40 text-amber-300/80 hover:bg-amber-950/50'
                      : 'border-emerald-300/40 dark:border-emerald-800/60 hover:bg-[#eaf5ef] dark:hover:bg-[#083526]'
                }`}
                title="مؤقت التمهل والتدبر لقراءة الأذكار بهدوء وتؤدة"
              >
                <Hourglass className={`w-3.5 h-3.5 ${showPacingTimer ? (isNightReadingActive ? 'text-amber-400' : 'text-emerald-500') : ''}`} />
                <span>{showPacingTimer ? 'مؤقت التمهل: مفعّل' : 'مؤقت التمهل'}</span>
              </button>

              {/* Dedicated Smart Tasbeeh Counter Button (عداد تسبيح رقمي مع ميزة الاهتزاز وحفظ العدد) */}
              <button
                onClick={() => setShowSmartTasbeehModal(true)}
                className={`px-3 py-1.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                  isNightReadingActive
                    ? 'border-amber-900/40 text-amber-300 hover:bg-amber-950/50'
                    : 'border-emerald-300/40 dark:border-emerald-800/60 bg-emerald-50/50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-200 hover:bg-[#eaf5ef] dark:hover:bg-[#083526]'
                }`}
                title="فتح عداد تسبيح رقمي مستقل لهذا الذكر مع ميزة الاهتزاز عند أرقام معينة وحفظ العدد تلقائياً"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500 dark:text-amber-300" />
                <span>عداد تسبيح رقمي</span>
              </button>

              {/* Dedicated Info / Virtue Button */}
              <button
                onClick={() => setShowExplanationModal(true)}
                className="px-3.5 py-1.5 rounded-xl border border-amber-500/40 dark:border-amber-400/50 bg-amber-50/80 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer shadow-xs"
                title="عرض فضل هذا الذكر وتفسيره ومعانيه والوقفة التدبرية"
              >
                <Info className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>الفضل والتفسير</span>
              </button>

              {/* Favorite */}
              <button
                onClick={() => toggleFavorite(selectedDhikr.id)}
                className={`px-3 py-1.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                  favorited 
                    ? isNightReadingActive
                      ? 'border-amber-500 bg-amber-950/60 text-amber-300'
                      : 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-600' 
                    : isNightReadingActive
                      ? 'border-amber-900/40 text-amber-300/80 hover:bg-amber-950/50'
                      : 'border-emerald-300/40 dark:border-emerald-800/60 hover:bg-[#eaf5ef] dark:hover:bg-[#083526]'
                }`}
                title="إضافة إلى المفضلة"
              >
                <Heart className={`w-3.5 h-3.5 ${favorited ? isNightReadingActive ? 'fill-amber-500 text-amber-500' : 'fill-emerald-600 text-emerald-600' : ''}`} />
                <span>المفضلة</span>
              </button>

              {/* Copy */}
              <button
                onClick={handleCopy}
                className={`px-3 py-1.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                  isNightReadingActive
                    ? 'border-amber-900/40 text-amber-300/80 hover:bg-amber-950/50'
                    : 'border-emerald-300/40 dark:border-emerald-800/60 hover:bg-[#eaf5ef] dark:hover:bg-[#083526]'
                }`}
                title="نسخ نص الذكر"
              >
                {copied ? <Check className={`w-3.5 h-3.5 ${isNightReadingActive ? 'text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`} /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
              </button>

              {/* Share */}
              <button
                onClick={handleShare}
                className={`px-3 py-1.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer ${
                  isNightReadingActive
                    ? 'border-amber-900/40 text-amber-300/80 hover:bg-amber-950/50'
                    : 'border-emerald-300/40 dark:border-emerald-800/60 hover:bg-[#eaf5ef] dark:hover:bg-[#083526]'
                }`}
                title="مشاركة الذكر"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>مشاركة</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Mode Compact Text Bar */}
      {fullScreenMode && (
        <>
          <div className={`px-4 py-2.5 border-b flex items-center justify-between gap-3 ${
            isNightReadingActive
              ? 'bg-[#120d09]/95 border-amber-900/40 text-amber-200'
              : 'bg-[#042017]/85 dark:bg-[#042017]/85 border-emerald-600/20'
          }`}>
            <p className={`text-xs md:text-sm line-clamp-2 flex-1 text-center ${
              isNightReadingActive ? 'text-amber-200/90' : 'text-[#123828] dark:text-[#a7d7c0]'
            } ${isUthmani ? 'font-uthmani leading-loose' : 'font-quran'}`} dir="rtl">
              {selectedDhikr.text}
            </p>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={togglePacingTimer}
                className={`p-1.5 px-2 rounded-xl text-xs font-bold font-cairo flex items-center gap-1 cursor-pointer border ${
                  showPacingTimer 
                    ? 'bg-amber-500/20 text-amber-300 border-amber-400/50' 
                    : 'text-gray-400 border-transparent hover:text-white'
                }`}
                title="مؤقت التمهل والتدبر"
              >
                <Hourglass className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">تمهل</span>
              </button>
              <button
                onClick={() => setShowExplanationModal(true)}
                className="p-1.5 px-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/50 shrink-0 text-xs font-bold font-cairo flex items-center gap-1 cursor-pointer"
                title="عرض فضل الذكر وتفسيره"
              >
                <Info className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">فضل الذكر</span>
              </button>
            </div>
          </div>

          {showPacingTimer && (
            <div className="px-4 py-2 max-w-lg mx-auto w-full">
              <DhikrPacingTimer
                dhikrText={selectedDhikr.text}
                dhikrCount={targetCount}
                currentCount={currentCount}
                isNightReadingActive={isNightReadingActive}
                onAutoIncrement={handleTasbeehTap}
                onNotify={(msg) => showToast(msg)}
                onClose={() => {
                  setShowPacingTimer(false);
                  try { localStorage.setItem('hisn_show_pacing_timer', 'false'); } catch {}
                }}
              />
            </div>
          )}
        </>
      )}

      {/* ============================================================== */}
      {/* DIGITAL COUNTER / ELECTRONIC MISBAHA (مكون المسبحة الإلكترونية الرقمية) */}
      {/* ============================================================== */}
      <div className={`p-3 pb-safe backdrop-blur-md transition-all ${
        isNightReadingActive
          ? 'bg-[#100a06]/98 border-t border-amber-900/50 shadow-2xl'
          : 'bg-[#ffffff]/98 dark:bg-[#021811]/98 border-t border-emerald-600/20 dark:border-emerald-800/70 shadow-2xl'
      } ${fullScreenMode ? 'flex-1 flex flex-col justify-center' : ''}`}>
        {/* Cumulative Total Tasbeeh Counter Bar (عداد التسبيح التراكمي المحفوظ في localStorage) */}
        <div className="w-full max-w-lg mx-auto flex items-center justify-between px-3 py-1 mb-1.5 rounded-xl bg-black/25 border border-emerald-700/30 text-xs">
          <div className="flex items-center gap-1.5 font-cairo">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] text-[#84b8a0] font-tajawal">إجمالي التسبيح التراكمي:</span>
            <span className="font-mono font-bold text-amber-300 text-xs px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-400/30">
              {lifetimeTotal.toLocaleString('ar-EG')}
            </span>
          </div>
          <span className="text-[10px] text-emerald-400/90 font-tajawal flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5 text-amber-400" />
            <span>{lifetimeTotal >= 1000 ? 'ما شاء الله 🌟' : 'محفوظ في رصيدك 🌿'}</span>
          </span>
        </div>

        <DigitalCounter
          currentCount={currentCount}
          targetCount={targetCount}
          originalTarget={selectedDhikr.count}
          onSetTarget={handleSetTarget}
          cyclesCompleted={cyclesCompleted}
          onNewCycle={handleStartNewCycle}
          freeCounterMode={freeCounterMode}
          onTap={handleTasbeehTap}
          onUndo={handleUndo}
          onReset={() => {
            triggerVibration(settings.vibration !== false, 'light');
            setShowResetModal(true);
          }}
          onToggleFreeMode={() => {
            const next = !freeCounterMode;
            setFreeCounterMode(next);
            triggerVibration(settings.vibration !== false, 'light');
            showToast(next ? 'تم تفعيل وضع التسبيح المفتوح ♾️' : `تم العودة للهدف (${targetCount})`);
          }}
          onNextDhikr={nextDhikr}
          onPrevDhikr={prevDhikr}
          hasNext={hasNext}
          hasPrev={hasPrev}
          isNightReadingActive={isNightReadingActive}
          soundEnabled={settings.sound}
          vibrationEnabled={settings.vibration}
          onToggleSound={() => updateSettings({ sound: !settings.sound })}
          onToggleVibration={() => {
            const next = !settings.vibration;
            updateSettings({ vibration: next });
            if (next) {
              triggerVibration(true, 'tap');
              showToast('تم تفعيل الاهتزاز عند التسبيح والهدف 📳');
            } else {
              showToast('تم تعطيل الاهتزاز 📴');
            }
          }}
          onOpenMilestoneModal={() => setShowMilestoneModal(true)}
          vibrationMilestone={settings.vibrationMilestone || '33'}
          fullScreenMode={fullScreenMode}
        />
      </div>

      {/* ============================================================== */}
      {/* RESET OPTIONS MODAL (خيارات إعادة التعيين) */}
      {/* ============================================================== */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div 
            className="w-full max-w-sm bg-[#042017] dark:bg-[#042017] border border-emerald-600/30 dark:border-emerald-700/60 rounded-3xl p-5 shadow-2xl space-y-3.5 text-right"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between pb-2 border-b border-emerald-200/50 dark:border-emerald-800/60">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                  خيارات إعادة تعيين العداد
                </h3>
              </div>
              <button
                onClick={() => setShowResetModal(false)}
                className="p-1 rounded-full text-[#4d7d67] hover:text-[#0c2e20] dark:hover:text-emerald-300"
                aria-label="إلغاء"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {/* Option 1: Reset this dhikr to 0 */}
              <button
                onClick={() => {
                  resetDhikrProgress(selectedDhikr.id);
                  setShowResetModal(false);
                }}
                className="w-full p-3 rounded-2xl bg-[#062c20] dark:bg-[#062c20] hover:bg-[#e6f4ed] dark:hover:bg-[#093526] border border-emerald-300/40 dark:border-emerald-800/60 flex items-center justify-between transition-colors text-right cursor-pointer"
              >
                <div>
                  <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                    تصفير عداد هذا الذكر إلى (0)
                  </p>
                  <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
                    البدء من جديد للذكر الحالي
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-300">0</span>
              </button>

              {/* Option 2: Quick milestone preset (33) */}
              {isHighCount && (
                <button
                  onClick={() => {
                    setProgressValue(selectedDhikr.id, 33);
                    showToast('تم ضبط العداد على ٣٣ تسبيحة');
                    setShowResetModal(false);
                  }}
                  className="w-full p-3 rounded-2xl bg-[#062c20] dark:bg-[#062c20] hover:bg-[#e6f4ed] dark:hover:bg-[#093526] border border-emerald-300/40 dark:border-emerald-800/60 flex items-center justify-between transition-colors text-right cursor-pointer"
                >
                  <div>
                    <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                      ضبط العداد على (٣٣)
                    </p>
                    <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
                      اكتمال الشوط الأول من التسبيح
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-300">33</span>
                </button>
              )}

              {/* Option 3: Quick milestone preset (66) */}
              {isHighCount && (
                <button
                  onClick={() => {
                    setProgressValue(selectedDhikr.id, 66);
                    showToast('تم ضبط العداد على ٦٦ تسبيحة');
                    setShowResetModal(false);
                  }}
                  className="w-full p-3 rounded-2xl bg-[#062c20] dark:bg-[#062c20] hover:bg-[#e6f4ed] dark:hover:bg-[#093526] border border-emerald-300/40 dark:border-emerald-800/60 flex items-center justify-between transition-colors text-right cursor-pointer"
                >
                  <div>
                    <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                      ضبط العداد على (٦٦)
                    </p>
                    <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
                      اكتمال الشوط الثاني من التسبيح
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-300">66</span>
                </button>
              )}

              {/* Option 4: Toggle Free Mode / Fixed Mode */}
              <button
                onClick={() => {
                  setFreeCounterMode(!freeCounterMode);
                  showToast(!freeCounterMode ? 'تم تفعيل وضع التسبيح المفتوح ♾️' : 'تم العودة للعدد المأثور');
                  setShowResetModal(false);
                }}
                className="w-full p-3 rounded-2xl bg-[#062c20] dark:bg-[#062c20] hover:bg-[#e6f4ed] dark:hover:bg-[#093526] border border-emerald-300/40 dark:border-emerald-800/60 flex items-center justify-between transition-colors text-right cursor-pointer"
              >
                <div>
                  <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                    {freeCounterMode ? 'العودة للعدد المأثور للذكر' : 'وضع التسبيح الحر المفتوح (غير المحدود)'}
                  </p>
                  <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
                    {freeCounterMode ? `الالتزام بـ ${targetCount} مرات` : 'مواصلة التسبيح بلا حد مع الاهتزاز عند المحطات'}
                  </p>
                </div>
                <span className="text-sm font-bold text-emerald-700 dark:text-emerald-300 font-mono">
                  {freeCounterMode ? 'مقيد' : 'حر ∞'}
                </span>
              </button>

              {/* Option 5: Reset All Today */}
              <button
                onClick={() => {
                  if (window.confirm('هل تريد تصفير جميع عدادات أذكار اليوم؟')) {
                    resetAllProgress();
                    setShowResetModal(false);
                  }
                }}
                className="w-full p-2.5 rounded-2xl bg-red-500/10 hover:bg-red-500/20 border border-red-400/30 text-red-600 dark:text-red-400 flex items-center justify-center gap-2 text-xs font-bold font-cairo transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة ضبط جميع أذكار اليوم</span>
              </button>
            </div>

            <button
              onClick={() => setShowResetModal(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-800/15 text-[#123828] dark:text-emerald-200 text-xs font-bold font-cairo hover:bg-emerald-800/25 transition-colors cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MILESTONE VIBRATION SETTINGS MODAL (خيارات أرقام الاهتزاز المحددة) */}
      {/* ============================================================== */}
      {showMilestoneModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div 
            className="w-full max-w-sm bg-[#042017] dark:bg-[#042017] border border-emerald-600/30 dark:border-emerald-700/60 rounded-3xl p-5 shadow-2xl space-y-3.5 text-right"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between pb-2 border-b border-emerald-200/50 dark:border-emerald-800/60">
              <div className="flex items-center gap-2">
                <Vibrate className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                  خيارات الاهتزاز عند أرقام محددة
                </h3>
              </div>
              <button
                onClick={() => setShowMilestoneModal(false)}
                className="p-1 rounded-full text-[#4d7d67] hover:text-[#0c2e20] dark:hover:text-emerald-300"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal leading-relaxed">
              اختر متى يعطيك الهاتف نبضة اهتزاز تنبيهية أثناء التسبيح دون الحاجة للنظر إلى الشاشة:
            </p>

            <div className="space-y-2">
              {[
                { 
                  id: '33' as MilestoneOption, 
                  title: 'كل ٣٣ تسبيحة (٣٣، ٦٦، ٩٩، ١٠٠)', 
                  desc: 'اهتزاز مميز مع مسبحة الأذكار المشهورة' 
                },
                { 
                  id: '10' as MilestoneOption, 
                  title: 'كل ١٠ تسبيحات', 
                  desc: 'نبضة خفيفة كل ١٠ عدات' 
                },
                { 
                  id: 'target' as MilestoneOption, 
                  title: 'عند اكتمال العدد المطلوب فقط', 
                  desc: `اهتزاز تنبيهي عند الوصول إلى ${targetCount}` 
                },
                { 
                  id: 'none' as MilestoneOption, 
                  title: 'إيقاف اهتزاز المحطات', 
                  desc: 'اهتزاز عادي مع كل ضغطة فقط' 
                },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => {
                    updateSettings({ vibrationMilestone: opt.id, vibration: true });
                    showToast(`تم تعيين: ${opt.title}`);
                    setShowMilestoneModal(false);
                  }}
                  className={`w-full p-3 rounded-2xl border text-right transition-colors cursor-pointer flex items-center justify-between ${
                    settings.vibrationMilestone === opt.id
                      ? 'border-emerald-600 bg-emerald-700/15 dark:bg-emerald-950/70 text-emerald-900 dark:text-emerald-200 font-bold'
                      : 'border-emerald-200/50 dark:border-emerald-800/60 bg-[#062c20] dark:bg-[#062c20] text-[#0c2e20] dark:text-[#e8f5ee] hover:bg-[#e6f4ed]'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold font-cairo">{opt.title}</p>
                    <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0] mt-0.5">{opt.desc}</p>
                  </div>
                  {settings.vibrationMilestone === opt.id && (
                    <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 stroke-[3]" />
                  )}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowMilestoneModal(false)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-800 text-white text-xs font-bold font-cairo hover:from-emerald-600 hover:to-emerald-700 transition-colors cursor-pointer shadow-xs"
            >
              تم
            </button>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* NIGHT READING MODE & EYE COMFORT MODAL (نافذة وضع القراءة الليلية) */}
      {/* ============================================================== */}
      <NightModeModal
        isOpen={showNightModeModal}
        onClose={() => setShowNightModeModal(false)}
        currentMode={nightReadingMode}
        warmthLevel={nightWarmthLevel}
        onSelectMode={(mode) => setNightReadingMode(mode)}
        onSelectWarmth={(level) => {
          updateSettings({ nightWarmthLevel: level });
          showToast(`تم تغيير دفء الإضاءة الليلية: ${level === 'deep_amber' ? 'شمعة داكنة' : level === 'warm' ? 'عنبري هادئ' : 'معتدل'}`);
        }}
        isNightBySolar={solarTimes.isNight}
        sunsetFormatted={solarTimes.sunsetFormatted}
      />

      {/* ============================================================== */}
      {/* DHIKR EXPLANATION & VIRTUE MODAL (نافذة فضل وتفسير الذكر للتدبر) */}
      {/* ============================================================== */}
      <DhikrExplanationModal
        dhikr={selectedDhikr}
        isOpen={showExplanationModal}
        onClose={() => setShowExplanationModal(false)}
        showToast={showToast}
      />

      {/* ============================================================== */}
      {/* SMART DIGITAL TASBEEH COUNTER (عداد التسبيح الرقمي المخصص لهذا الذكر) */}
      {/* ============================================================== */}
      {selectedDhikr && (
        <SmartTasbeehCounter
          isOpen={showSmartTasbeehModal}
          onClose={() => setShowSmartTasbeehModal(false)}
          dhikrContext={{
            id: selectedDhikr.id,
            title: selectedDhikr.title,
            text: selectedDhikr.text,
            target: selectedDhikr.count,
            currentCount: getProgressFor(selectedDhikr.id),
            onUpdateCount: (val) => setProgressValue(selectedDhikr.id, val)
          }}
        />
      )}
    </div>
  );
};
