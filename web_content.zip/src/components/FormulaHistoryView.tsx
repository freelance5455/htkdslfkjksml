import { useMemo, useState } from "react";
import { filterHistory, useFormulaHistory, type FormulaHistoryEntry } from "../state/FormulaHistoryState";
import type { Board, ClassLevel, Subject } from "../data/types";
import { useAppState } from "../state/AppState";

const SUBJECTS: (Subject | "All")[] = ["All", "Mathematics", "Physics", "Chemistry"];
const CLASSES: (ClassLevel | "All")[] = ["All", 8, 9, 10];
const BOARDS: (Board | "All")[] = ["All", "CBSE", "ICSE"];

function formatTimestamp(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
  } catch {
    return iso;
  }
}

export default function FormulaHistoryView() {
  const { entries, removeEntry, clearAll } = useFormulaHistory();
  const { navigate } = useAppState();
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState<Subject | "All">("All");
  const [classLevel, setClassLevel] = useState<ClassLevel | "All">("All");
  const [boardFilter, setBoardFilter] = useState<Board | "All">("All");
  const [openId, setOpenId] = useState<string | null>(null);

  const topics = useMemo(() => Array.from(new Set(entries.map((e) => e.topic).filter(Boolean))) as string[], [entries]);
  const [topic, setTopic] = useState<string | "All">("All");

  const filtered = useMemo(
    () => filterHistory(entries, { search, subject, classLevel, topic, board: boardFilter }),
    [entries, search, subject, classLevel, topic, boardFilter]
  );

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Formula History</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Every formula or theorem the Problem Solver has actually used, saved automatically on this device.
          </p>
        </div>
        {entries.length > 0 && (
          <button
            onClick={() => {
              if (confirm("Clear all formula history? This cannot be undone.")) clearAll();
            }}
            className="shrink-0 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300"
          >
            Clear All
          </button>
        )}
      </div>

      {entries.length === 0 ? (
        <div className="mx-auto mt-16 max-w-md text-center">
          <div className="text-4xl">🧾</div>
          <h2 className="mt-3 text-lg font-semibold text-slate-700 dark:text-slate-200">No history yet</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Solve a question in the Problem Solver and any formula or theorem it uses will be saved here automatically.
          </p>
          <button
            onClick={() => navigate({ name: "solver" })}
            className="mt-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90"
          >
            Open Problem Solver →
          </button>
        </div>
      ) : (
        <>
          <div className="mt-5 flex flex-col gap-2 sm:flex-row">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search formula, topic, or question..."
              className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm shadow-sm outline-none ring-indigo-200 transition focus:ring-4 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:ring-indigo-500/20"
            />
            <select
              value={boardFilter}
              onChange={(e) => setBoardFilter(e.target.value as Board | "All")}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              {BOARDS.map((b) => (
                <option key={b} value={b}>
                  {b === "All" ? "All Boards" : b}
                </option>
              ))}
            </select>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value as Subject | "All")}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              {SUBJECTS.map((s) => (
                <option key={s} value={s}>
                  {s === "All" ? "All Subjects" : s}
                </option>
              ))}
            </select>
            <select
              value={classLevel}
              onChange={(e) => setClassLevel(e.target.value === "All" ? "All" : (Number(e.target.value) as ClassLevel))}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              {CLASSES.map((c) => (
                <option key={c} value={c}>
                  {c === "All" ? "All Classes" : `Class ${c}`}
                </option>
              ))}
            </select>
            {topics.length > 0 && (
              <select
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm shadow-sm outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              >
                <option value="All">All Topics</option>
                {topics.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            )}
          </div>

          <p className="mt-3 text-xs text-slate-400 dark:text-slate-500">
            {filtered.length} of {entries.length} formula{entries.length === 1 ? "" : "s"} used
          </p>

          <div className="mt-3 space-y-3">
            {filtered.map((entry) => (
              <HistoryCard
                key={entry.id}
                entry={entry}
                isOpen={openId === entry.id}
                onToggle={() => setOpenId(openId === entry.id ? null : entry.id)}
                onRemove={() => removeEntry(entry.id)}
                onOpenFormula={entry.formulaId ? () => navigate({ name: "formula", id: entry.formulaId! }) : undefined}
              />
            ))}
            {filtered.length === 0 && <p className="py-10 text-center text-sm text-slate-400">No entries match your filters.</p>}
          </div>
        </>
      )}
    </div>
  );
}

function HistoryCard({
  entry,
  isOpen,
  onToggle,
  onRemove,
  onOpenFormula,
}: {
  entry: FormulaHistoryEntry;
  isOpen: boolean;
  onToggle: () => void;
  onRemove: () => void;
  onOpenFormula?: () => void;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-start justify-between gap-3">
        <button onClick={onToggle} className="flex-1 text-left">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-semibold text-slate-800 dark:text-slate-100">{entry.name}</h3>
            {entry.subject && (
              <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
                {entry.board ? `${entry.board} · ` : ""}
                {entry.classLevel ? `Class ${entry.classLevel} · ` : ""}
                {entry.subject}
              </span>
            )}
            {entry.chapter && (
              <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">{entry.chapter}</span>
            )}
            {entry.usageCount > 1 && (
              <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300">
                used {entry.usageCount}×
              </span>
            )}
          </div>
          <p className="mt-1 font-mono text-sm text-indigo-600 dark:text-indigo-400">{entry.expression}</p>
          <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">Last used {formatTimestamp(entry.lastUsedAt)}</p>
        </button>
        <button
          onClick={onRemove}
          className="shrink-0 rounded-lg p-1.5 text-slate-300 transition hover:bg-rose-50 hover:text-rose-500 dark:text-slate-600 dark:hover:bg-rose-500/10"
          aria-label="Remove entry"
        >
          ✕
        </button>
      </div>

      {isOpen && (
        <div className="mt-3 space-y-2 border-t border-slate-100 pt-3 text-sm dark:border-slate-800">
          <p className="text-slate-600 dark:text-slate-300">{entry.explanation}</p>
          {entry.example && (
            <div className="rounded-lg bg-emerald-50 px-3 py-2 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-200">
              <span className="font-semibold">Example: </span>
              {entry.example}
            </div>
          )}
          <div className="rounded-lg bg-slate-50 px-3 py-2 text-slate-600 dark:bg-slate-800/60 dark:text-slate-300">
            <span className="font-semibold">Used for: </span>"{entry.question}"
          </div>
          {entry.reason && <p className="text-xs text-slate-400 dark:text-slate-500">Why this formula: {entry.reason}</p>}
          {entry.source ? (
            <a href={entry.source.url} target="_blank" rel="noopener noreferrer" className="inline-block text-xs font-medium text-indigo-600 underline dark:text-indigo-400">
              Source: {entry.source.name} ↗
            </a>
          ) : (
            <p className="text-xs text-slate-400 dark:text-slate-500">Source: FormulaVerse built-in library (not fetched from the internet).</p>
          )}
          {onOpenFormula && (
            <button
              onClick={onOpenFormula}
              className="mt-1 w-full rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs font-semibold text-indigo-600 transition hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300"
            >
              Open interactive formula page →
            </button>
          )}
        </div>
      )}
    </div>
  );
}
