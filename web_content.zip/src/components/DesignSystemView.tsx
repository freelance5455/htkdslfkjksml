import React, { useState } from 'react';
import { Palette, Check, Copy, Sparkles, Layers, ShieldCheck, Zap } from 'lucide-react';

export const DesignSystemView: React.FC = () => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const copyToClipboard = (hex: string) => {
    navigator.clipboard?.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  const colorTokens = [
    {
      role: 'Primary Brand (Energy & Urgency)',
      name: 'Sewora Orange',
      hex: '#FF6600',
      rgb: 'rgb(255, 102, 0)',
      contrast: '4.8:1 on White (Large), High impact',
      rationale: 'Inspired by Daraz / Alibaba retail vitality. Drives immediate click-throughs on Flash Sales and primary Buy Now CTAs while establishing brand warmth.'
    },
    {
      role: 'Primary Hover / Dark Accent',
      name: 'Deep Vermilion',
      hex: '#E05500',
      rgb: 'rgb(224, 85, 0)',
      contrast: '5.6:1 WCAG AA Legible',
      rationale: 'Pressed and active button state providing tactile visual depth on touch interaction.'
    },
    {
      role: 'Secondary Brand (Trust & Stability)',
      name: 'Sapphire Slate / Royal Navy',
      hex: '#0F172A',
      rgb: 'rgb(15, 23, 42)',
      contrast: '15.8:1 WCAG AAA Compliant',
      rationale: 'Anchors marketplace legitimacy, high-contrast headings, prices, and bank-grade checkout reassurance.'
    },
    {
      role: 'Neutral Canvas Background',
      name: 'Chalk White & Soft Slate',
      hex: '#F8FAFC',
      rgb: 'rgb(248, 250, 252)',
      contrast: 'Clean product backdrop',
      rationale: 'Ensures multi-vendor product photography pops with 0% chromatic distortion.'
    },
    {
      role: 'Semantic Success & Logistics',
      name: 'Emerald Green',
      hex: '#059669',
      rgb: 'rgb(5, 150, 105)',
      contrast: '4.9:1 WCAG AA Legible',
      rationale: 'Signals Free Islandwide Delivery, Verified Purchase reviews, and order fulfillment progression.'
    },
    {
      role: 'Semantic Reward & Timer',
      name: 'Amber Gold',
      hex: '#F59E0B',
      rgb: 'rgb(245, 158, 11)',
      contrast: 'High visibility attention',
      rationale: 'Highlights Sewora Coins rewards, star ratings, and flash countdown urgency.'
    }
  ];

  const components = [
    {
      category: '1. Product Cards (Feed & Flash Sale)',
      spec: 'Corner radius rounded-xl (12px), subtle border border-slate-100, soft shadow-2xs. Image takes 65% of card height on clean neutral canvas. Always pairs current deal price (15px bold tabular) with slashed MSRP and compact sold count.',
      rules: 'Lead with photo, never wrap titles in pills, uniform aspect ratio.'
    },
    {
      category: '2. Badges & Tags System',
      spec: '• Mall Badge: Solid #FF6600 rectangle with white bold uppercase 8px type ("MALL").\n• Discount Tag: Compact solid tag "-45%" in bright orange.\n• Free Delivery: Solid emerald rounded tag with 8px bold text.\n• Verified Purchase: Quiet green inline indicator with subtle checkmark.',
      rules: 'Maximum 1 promotional badge per card to prevent cognitive clutter.'
    },
    {
      category: '3. Call-to-Action (CTA) Buttons',
      spec: '• Primary Buy Now: Full-bleed #FF6600 solid fill, rounded-xl (12px), min-height 44px, bold 13px white typography, active scale-[0.98].\n• Secondary Add to Cart: Outlined or soft tinted background (orange-50) with #FF6600 border and text.\n• Sticky Bottom Mobile Purchase Module: Always pinned within the natural thumb zone (<15% total screen height cap).',
      rules: 'All touch targets ≥44px × 44px for zero mis-taps on mobile.'
    },
    {
      category: '4. Typography Scale',
      spec: '• Display Brand: Plus Jakarta Sans Extrabold (20px–24px)\n• Section Titles: Plus Jakarta Sans Bold (14px–16px)\n• Body & Captions: Plus Jakarta Sans Medium (12px–13px)\n• Financial Figures / Prices: Tabular Numerals (tabular-nums font-mono/sans)',
      rules: 'Strict 2-font system with tabular figures for currency alignment.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-[#FF6600] uppercase tracking-wider mb-1">
          <Palette className="w-4 h-4" />
          <span>Design System & Visual Guidelines</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          Sewora Marketplace Design Language
        </h1>
        <p className="text-xs text-slate-600 mt-2 leading-relaxed">
          Crafted to balance the energetic urgency of flash marketplaces with the bank-grade trust 
          required for emerging e-commerce shoppers. Enforces clean spatial math, anti-slop typography, 
          and ergonomic thumb-zone touch targets.
        </p>
      </div>

      {/* Color Palette Grid */}
      <div className="space-y-3">
        <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#FF6600]" />
          <span>Color Palette Tokens</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {colorTokens.map((c) => (
            <div key={c.hex} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-3">
              <div
                className="h-20 rounded-xl shadow-inner flex items-end p-2.5 justify-between"
                style={{ backgroundColor: c.hex }}
              >
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded shadow-xs ${
                  c.hex === '#F8FAFC' ? 'bg-slate-200 text-slate-800' : 'bg-black/30 text-white backdrop-blur-xs'
                }`}>
                  {c.hex}
                </span>

                <button
                  onClick={() => copyToClipboard(c.hex)}
                  className={`p-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
                    c.hex === '#F8FAFC'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white/90 text-slate-900 hover:bg-white'
                  }`}
                  title="Copy Hex"
                >
                  {copiedHex === c.hex ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div>
                <div className="text-[11px] font-bold text-[#FF6600] uppercase tracking-wider">{c.role}</div>
                <h3 className="text-sm font-black text-slate-900">{c.name}</h3>
                <p className="text-[11px] text-slate-500 mt-1 leading-snug">{c.rationale}</p>
                <div className="text-[10px] text-slate-400 font-mono mt-2 pt-2 border-t border-slate-100">
                  Contrast: {c.contrast}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* UI Component Specifications */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#FF6600]" />
          <span>UI Component Style Guidelines</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {components.map((comp, idx) => (
            <div key={idx} className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-2">
              <h3 className="text-xs font-black text-slate-900">{comp.category}</h3>
              <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">{comp.spec}</p>
              <div className="pt-2 border-t border-slate-200 text-[10px] font-bold text-[#FF6600]">
                Design Rule: <span className="text-slate-600 font-normal">{comp.rules}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
