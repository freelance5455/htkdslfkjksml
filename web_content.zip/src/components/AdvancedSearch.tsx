import React from 'react';
import { 
  Filter, 
  RotateCcw, 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  MapPin, 
  Calendar, 
  School, 
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { FilterState, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';
import { SRI_LANKAN_SCHOOLS, SUBJECTS_BY_GRADE } from '../data/mockData';

interface AdvancedSearchProps {
  language: Language;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  onResetFilters: () => void;
  onAiSearch: () => void;
  totalResultsCount: number;
}

export const AdvancedSearch: React.FC<AdvancedSearchProps> = ({
  language,
  filters,
  setFilters,
  onResetFilters,
  onAiSearch,
  totalResultsCount
}) => {
  const t = TRANSLATIONS[language];

  const gradesList = ['ALL', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'G.C.E. O/L', 'G.C.E. A/L'];
  const provincesList = [
    'ALL',
    'Western',
    'Central',
    'Southern',
    'Northern',
    'Eastern',
    'North Western',
    'North Central',
    'Uva',
    'Sabaragamuwa',
    'National'
  ];
  const paperTypesList = ['ALL', 'Past Paper', 'Term Test', 'Model Paper', 'Marking Scheme', 'Short Notes'];
  const mediumsList = ['ALL', 'Sinhala', 'English', 'Tamil'];
  const yearsList = ['ALL', '2025', '2024', '2023', '2022', '2021', '2020', '2019', '2018'];

  // Calculate available subjects dynamically based on chosen grade
  const availableSubjects = ['ALL'];
  if (filters.grade !== 'ALL' && SUBJECTS_BY_GRADE[filters.grade]) {
    availableSubjects.push(...SUBJECTS_BY_GRADE[filters.grade]);
  } else {
    // Collect all unique subjects
    const all = new Set<string>();
    Object.values(SUBJECTS_BY_GRADE).forEach((list) => list.forEach((s) => all.add(s)));
    availableSubjects.push(...Array.from(all));
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
      
      {/* Top Bar Header & Total Count */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Filter className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <span>{t.filterTitle}</span>
              <span className="text-xs font-normal text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                {totalResultsCount} {totalResultsCount === 1 ? 'Paper' : 'Papers Found'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">Refine by Grade, Subject, Province, School, and Year</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onAiSearch}
            className="px-3.5 py-1.5 text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-xl flex items-center gap-1.5 shadow-md shadow-amber-500/10 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Natural Filter</span>
          </button>
          
          <button
            onClick={onResetFilters}
            className="px-3 py-1.5 text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center gap-1 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetFilters}</span>
          </button>
        </div>
      </div>

      {/* Grid of Dropdown Selectors */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        
        {/* Grade */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <GraduationCap className="w-3 h-3 text-amber-400" />
            <span>{t.grade}</span>
          </label>
          <select
            value={filters.grade}
            onChange={(e) => setFilters((prev) => ({ ...prev, grade: e.target.value, subject: 'ALL' }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {gradesList.map((g) => (
              <option key={g} value={g}>{g === 'ALL' ? 'All Grades' : g}</option>
            ))}
          </select>
        </div>

        {/* Subject */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-amber-400" />
            <span>{t.subject}</span>
          </label>
          <select
            value={filters.subject}
            onChange={(e) => setFilters((prev) => ({ ...prev, subject: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {availableSubjects.map((s) => (
              <option key={s} value={s}>{s === 'ALL' ? 'All Subjects' : s}</option>
            ))}
          </select>
        </div>

        {/* Medium */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <Layers className="w-3 h-3 text-amber-400" />
            <span>{t.medium}</span>
          </label>
          <select
            value={filters.medium}
            onChange={(e) => setFilters((prev) => ({ ...prev, medium: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {mediumsList.map((m) => (
              <option key={m} value={m}>{m === 'ALL' ? 'All Mediums' : m}</option>
            ))}
          </select>
        </div>

        {/* Year */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-amber-400" />
            <span>{t.year}</span>
          </label>
          <select
            value={filters.year}
            onChange={(e) => setFilters((prev) => ({ ...prev, year: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {yearsList.map((y) => (
              <option key={y} value={y}>{y === 'ALL' ? 'All Years' : y}</option>
            ))}
          </select>
        </div>

        {/* Province */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-amber-400" />
            <span>{t.province}</span>
          </label>
          <select
            value={filters.province}
            onChange={(e) => setFilters((prev) => ({ ...prev, province: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {provincesList.map((p) => (
              <option key={p} value={p}>{p === 'ALL' ? 'All Provinces' : `${p} Province`}</option>
            ))}
          </select>
        </div>

        {/* School */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <School className="w-3 h-3 text-amber-400" />
            <span>{t.school}</span>
          </label>
          <select
            value={filters.school}
            onChange={(e) => setFilters((prev) => ({ ...prev, school: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            <option value="ALL">All Schools</option>
            {SRI_LANKAN_SCHOOLS.map((sch) => (
              <option key={sch} value={sch}>{sch}</option>
            ))}
          </select>
        </div>

        {/* Paper Type */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-amber-400" />
            <span>{t.paperType}</span>
          </label>
          <select
            value={filters.paperType}
            onChange={(e) => setFilters((prev) => ({ ...prev, paperType: e.target.value }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 transition-all"
          >
            {paperTypesList.map((pt) => (
              <option key={pt} value={pt}>{pt === 'ALL' ? 'All Types' : pt}</option>
            ))}
          </select>
        </div>

        {/* Sort By */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
            <ArrowUpDown className="w-3 h-3 text-amber-400" />
            <span>{t.sortBy}</span>
          </label>
          <select
            value={filters.sortBy}
            onChange={(e) => setFilters((prev) => ({ ...prev, sortBy: e.target.value as any }))}
            className="w-full bg-slate-800 text-xs text-white border border-slate-700/80 rounded-xl p-2 focus:outline-none focus:border-amber-400 font-medium transition-all"
          >
            <option value="newest">{t.newest}</option>
            <option value="popular">{t.popular}</option>
            <option value="trending">{t.trending}</option>
            <option value="downloads">{t.downloads}</option>
          </select>
        </div>

      </div>
    </div>
  );
};
