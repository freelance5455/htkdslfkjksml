import React, { useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ArrowRight, Sparkles, CheckCircle2 } from "lucide-react";
import { Dish } from "../types";

interface FoodDetailModalProps {
  dish: Dish | null;
  onClose: () => void;
  onOrderOnline?: (dish: Dish) => void;
}

export const FoodDetailModal: React.FC<FoodDetailModalProps> = ({
  dish,
  onClose,
  onOrderOnline,
}) => {
  // Support Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  if (!dish) return null;

  const isNonVeg = dish.dietaryLabel?.some(
    (label) =>
      label.toLowerCase().includes("non-veg") ||
      label.toLowerCase().includes("chicken") ||
      label.toLowerCase().includes("fish") ||
      label.toLowerCase().includes("prawn")
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#17201C]/75 backdrop-blur-xs"
        />

        {/* Modal Container */}
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-labelledby="dish-detail-title"
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97, y: 12 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame z-10 my-auto shadow-2xl p-5 sm:p-8"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            aria-label="Close dish detail"
            className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-[#F4F0E7] border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Top Kitchen Badge & Type Symbol */}
          <div className="flex items-center justify-between gap-3 mb-4 pr-8">
            <div className="flex items-center gap-2">
              <span
                className={`inline-flex items-center justify-center w-4 h-4 border rounded-[2px] shrink-0 ${
                  isNonVeg ? "border-[#B96D52]" : "border-emerald-700"
                }`}
                title={isNonVeg ? "Non-Vegetarian" : "Vegetarian"}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    isNonVeg ? "bg-[#B96D52]" : "bg-emerald-700"
                  }`}
                />
              </span>
              <span className="text-[11px] font-sans tracking-widest uppercase text-[#9BAF82] font-semibold">
                KALOREEZ KITCHEN
              </span>
            </div>

            {dish.dietaryLabel && dish.dietaryLabel.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {dish.dietaryLabel.map((label, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center px-2 py-0.5 text-[10px] font-medium tracking-wider uppercase rounded-full bg-[#EAE4D7] text-[#17201C]/80 border border-[#D8D0C2]/60"
                  >
                    {label}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Dish Name & Price */}
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[#D8D0C2]/60 pb-4 mb-4">
            <h3
              id="dish-detail-title"
              className="font-serif text-2xl sm:text-3xl text-[#17201C] leading-snug tracking-tight"
            >
              {dish.name}
            </h3>
            {dish.price && (
              <div className="text-xl sm:text-2xl font-serif font-medium text-[#B96D52] shrink-0">
                {dish.price}
              </div>
            )}
          </div>

          {/* Short Description */}
          <div className="mb-6">
            <h4 className="text-[10px] uppercase tracking-widest text-[#17201C]/50 font-semibold mb-1.5">
              Dish Description & Preparation
            </h4>
            <p className="text-sm sm:text-base text-[#17201C]/85 leading-relaxed font-sans">
              {dish.description}
            </p>
          </div>

          {/* Wholesome Commitment Checklist */}
          <div className="bg-[#F4F0E7]/70 rounded-xs p-3.5 border border-[#D8D0C2]/60 mb-6 space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-[#17201C]/80">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#9BAF82] shrink-0" />
              <span>Prepared fresh to order using olive oil, ghee, or cold-pressed oils</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-[#17201C]/80">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#9BAF82] shrink-0" />
              <span>No artificial colours, preservatives, or refined flour thickeners</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-[#17201C]/80">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#9BAF82] shrink-0" />
              <span>Average serving time: 15 to 20 minutes</span>
            </div>
          </div>

          {/* Nutrition info if available */}
          {(dish.calories || dish.protein || dish.carbs || dish.fat) && (
            <div className="border-t border-[#D8D0C2]/60 pt-3 mb-6">
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="p-2 bg-[#F4F0E7]/60 rounded-xs">
                  <div className="text-[10px] text-[#17201C]/60 uppercase tracking-wider">Calories</div>
                  <div className="text-xs font-semibold text-[#17201C] mt-0.5">{dish.calories || "—"}</div>
                </div>
                <div className="p-2 bg-[#F4F0E7]/60 rounded-xs">
                  <div className="text-[10px] text-[#17201C]/60 uppercase tracking-wider">Protein</div>
                  <div className="text-xs font-semibold text-[#17201C] mt-0.5">{dish.protein || "—"}</div>
                </div>
                <div className="p-2 bg-[#F4F0E7]/60 rounded-xs">
                  <div className="text-[10px] text-[#17201C]/60 uppercase tracking-wider">Carbs</div>
                  <div className="text-xs font-semibold text-[#17201C] mt-0.5">{dish.carbs || "—"}</div>
                </div>
                <div className="p-2 bg-[#F4F0E7]/60 rounded-xs">
                  <div className="text-[10px] text-[#17201C]/60 uppercase tracking-wider">Fat</div>
                  <div className="text-xs font-semibold text-[#17201C] mt-0.5">{dish.fat || "—"}</div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-3 border-t border-[#D8D0C2]/60 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs uppercase tracking-wider text-[#17201C]/70 hover:text-[#17201C] transition-colors cursor-pointer"
            >
              Back to Menu
            </button>
            <button
              type="button"
              onClick={() => onOrderOnline && onOrderOnline(dish)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium uppercase tracking-widest hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors cursor-pointer"
            >
              Order This Item
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
