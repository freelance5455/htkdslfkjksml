import React from 'react';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { WifiOff, Wifi, CloudCheck, HardDriveDownload, RefreshCw, Smartphone } from 'lucide-react';
import { StorageService } from '../db/storage';

interface OfflineStatusBannerProps {
  lang: 'bn' | 'en';
  onSyncRequest?: () => void;
}

export const OfflineStatusBanner: React.FC<OfflineStatusBannerProps> = ({
  lang,
  onSyncRequest,
}) => {
  const { isOnline, isOffline, justReconnected } = useNetworkStatus();

  // If online and not just reconnected, we don't need a persistent intrusive banner,
  // but we provide a subtle status or notification when network state shifts.
  if (isOnline && !justReconnected) {
    return null;
  }

  const handleDownloadOfflineBackup = () => {
    const backupJson = StorageService.exportData();
    const blob = new Blob([backupJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mobile_parts_offline_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (justReconnected) {
    return (
      <div className="bg-emerald-600 text-white px-4 py-2.5 text-xs font-semibold flex items-center justify-between shadow-sm animate-in fade-in slide-in-from-top duration-300">
        <div className="flex items-center gap-2 max-w-2xl">
          <Wifi className="w-4 h-4 text-emerald-200 shrink-0" />
          <span>
            {lang === 'bn'
              ? 'ইন্টারনেট সংযোগ ফিরে এসেছে! আপনার লোকাল লেনদেনের তথ্য ক্লাউড ফায়ারবেসে স্বয়ংক্রিয়ভাবে সিঙ্ক হচ্ছে।'
              : 'Internet restored! Your local data is ready to sync with the cloud database.'}
          </span>
        </div>
        {onSyncRequest && (
          <button
            onClick={onSyncRequest}
            className="px-3 py-1 bg-white text-emerald-700 hover:bg-emerald-50 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer"
          >
            {lang === 'bn' ? 'এখনই সিঙ্ক করুন' : 'Sync Now'}
          </button>
        )}
      </div>
    );
  }

  // Offline banner
  return (
    <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-orange-700 text-white px-4 py-2.5 text-xs shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-start sm:items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-white/15 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
            <WifiOff className="w-4 h-4 text-amber-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold uppercase tracking-wide text-[10px] px-1.5 py-0.5 rounded bg-amber-900/50 text-amber-200 border border-amber-500/40">
                {lang === 'bn' ? 'অফলাইন মোড সক্রিয়' : 'Offline Mode Active'}
              </span>
              <span className="text-[11px] font-bold text-amber-100">
                {lang === 'bn' ? 'অ্যান্ড্রয়েড ৮-১৬ ফুল অফলাইন সাপোর্ট' : 'Android 8-16 Offline Support'}
              </span>
            </div>
            <p className="text-[11px] text-amber-100 mt-0.5 leading-snug">
              {lang === 'bn'
                ? 'ইন্টারনেট ছাড়াই বিক্রয়, ইনভয়েস তৈরি, চালান প্রিন্ট ও মজুদ চেক পুরোপুরি সচল। সমস্ত তথ্য ফোনে সুরক্ষিত আছে।'
                : 'Full sales, POS invoicing, receipts & stock work without internet. Data is securely saved on your device.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 pt-1 sm:pt-0">
          <button
            onClick={handleDownloadOfflineBackup}
            className="px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-bold text-[11px] flex items-center gap-1.5 transition cursor-pointer"
            title={lang === 'bn' ? 'লোকাল ব্যাকআপ ফাইল ডাউনলোড করুন' : 'Download local backup'}
          >
            <HardDriveDownload className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'ডিভাইস ব্যাকআপ' : 'Device Backup'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
