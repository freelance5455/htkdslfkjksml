import React from 'react';
import { ColorOption } from '../types';
import { Sparkles, Bomb } from 'lucide-react';

interface ColorButtonsProps {
  options: ColorOption[];
  onSelect: (option: ColorOption, event: React.PointerEvent<HTMLButtonElement>) => void;
  disabled?: boolean;
}

export const ColorButtons: React.FC<ColorButtonsProps> = ({
  options,
  onSelect,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-sm px-6 pb-6 pt-1 select-none">
      <div className="grid grid-cols-2 gap-4 sm:gap-6 place-items-center">
        {options.map((option, index) => {
          const isGolden = !!option.isGolden;
          const isBomb = !!option.isBomb;

          return (
            <button
              key={`${option.id}-${index}`}
              disabled={disabled}
              onPointerDown={(e) => {
                e.preventDefault();
                if (!disabled) {
                  onSelect(option, e);
                }
              }}
              className={`group relative flex h-24 w-24 sm:h-28 sm:w-28 cursor-pointer select-none items-center justify-center rounded-full transition-transform duration-75 active:scale-90 active:brightness-110 focus:outline-none disabled:pointer-events-none disabled:opacity-50 touch-manipulation ${
                isGolden
                  ? 'animate-gold-pulse ring-4 ring-amber-300 ring-offset-2 ring-offset-slate-900'
                  : isBomb
                  ? 'animate-pulse ring-4 ring-rose-600 ring-offset-2 ring-offset-slate-950'
                  : ''
              }`}
              style={{
                backgroundColor: option.hex,
                boxShadow: isGolden
                  ? '0 8px 24px rgba(251, 191, 36, 0.7), inset 0 3px 10px rgba(255, 255, 255, 0.8), 0 4px 0 #B45309'
                  : isBomb
                  ? '0 8px 24px rgba(239, 68, 68, 0.8), inset 0 3px 10px rgba(255, 80, 80, 0.5), 0 5px 0 #991B1B'
                  : `0 8px 20px ${option.glow}, inset 0 3px 8px rgba(255, 255, 255, 0.45), 0 5px 0 ${option.ringHex}`,
              }}
              aria-label={isBomb ? 'Danger Bomb' : `Select ${option.name}`}
            >
              {/* Top glass reflection rim */}
              <div className="pointer-events-none absolute inset-x-2.5 top-2 h-7 sm:h-8 rounded-full bg-gradient-to-b from-white/40 to-transparent" />

              {/* Shimmer effect for Golden button */}
              {isGolden && (
                <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-full">
                  <div className="animate-shimmer absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent" />
                </div>
              )}

              {/* Center icon / keyboard hint */}
              <div className="relative flex flex-col items-center justify-center pointer-events-none">
                {isGolden ? (
                  <div className="flex flex-col items-center">
                    <Sparkles className="h-7 w-7 text-amber-950 fill-amber-300 drop-shadow-sm" />
                    <span className="text-[11px] font-black tracking-tight text-amber-950">
                      BONUS
                    </span>
                  </div>
                ) : isBomb ? (
                  <div className="flex flex-col items-center animate-pulse">
                    <Bomb className="h-7 w-7 text-rose-500 fill-rose-600/30 drop-shadow-[0_0_8px_rgba(239,68,68,0.9)]" />
                    <span className="text-[10px] font-black tracking-wider text-rose-400">
                      BOMB
                    </span>
                  </div>
                ) : (
                  <span className="text-xs font-bold tracking-wider text-white/50 group-hover:text-white/80 transition-colors uppercase">
                    {index + 1}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
