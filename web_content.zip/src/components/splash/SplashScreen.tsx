import { useEffect } from 'react';
import { Plane, Compass, Sparkles } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface SplashScreenProps {
  language: Language;
  onFinish: () => void;
}

export function SplashScreen({ language, onFinish }: SplashScreenProps) {
  const t = translations[language];

  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 2800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div
      onClick={onFinish}
      className="fixed inset-0 z-50 flex flex-col items-center justify-between p-8 bg-[#050814] text-white cursor-pointer select-none overflow-hidden"
    >
      {/* Background Animated Neon Orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

      {/* Top brand accent */}
      <div className="pt-8 flex items-center gap-2 text-cyan-400 text-xs font-medium tracking-widest uppercase">
        <Sparkles className="w-4 h-4 animate-spin text-cyan-400" />
        <span>Luxury Travel Redefined</span>
      </div>

      {/* Center Hologram Logo & Globe Orbit */}
      <div className="flex flex-col items-center justify-center relative my-auto">
        {/* Orbit Ring */}
        <div className="relative w-44 h-44 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border border-cyan-500/30 animate-spin [animation-duration:12s]" />
          <div className="absolute inset-2 rounded-full border border-blue-500/20 border-dashed animate-spin [animation-duration:18s] [animation-direction:reverse]" />
          
          {/* Glowing Center Core */}
          <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-blue-700 via-indigo-900 to-cyan-500 p-1 flex items-center justify-center shadow-[0_0_50px_rgba(0,102,255,0.45)]">
            <div className="w-full h-full rounded-full bg-[#070b1e] flex flex-col items-center justify-center relative overflow-hidden">
              <Compass className="w-12 h-12 text-cyan-400 animate-pulse" />
            </div>
          </div>

          {/* Flying Airplane on Orbit */}
          <div className="absolute w-full h-full flex items-center justify-center animate-spin [animation-duration:6s]">
            <div className="absolute -top-3 text-cyan-300 drop-shadow-[0_0_10px_#00f0ff] transform rotate-90">
              <Plane className="w-6 h-6 fill-cyan-400" />
            </div>
          </div>
        </div>

        {/* Brand Titles */}
        <h1 className="mt-8 text-4xl md:text-5xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-blue-400">
          TAKI-GO
        </h1>
        <p className="mt-2 text-sm md:text-base font-semibold text-cyan-400 tracking-wide">
          {t.brandName}
        </p>

        {/* Tagline */}
        <p className="mt-4 text-xs md:text-sm text-slate-300 max-w-xs text-center font-medium">
          {t.tagline}
        </p>
      </div>

      {/* Bottom Loading Progress & Tap to Enter */}
      <div className="w-full max-w-xs flex flex-col items-center gap-3 pb-6">
        <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden relative">
          <div className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-500 rounded-full animate-[shimmer_2s_infinite] w-full" />
        </div>
        <div className="flex items-center justify-between w-full text-[11px] text-slate-400">
          <span>{t.splashLoading}</span>
          <span className="text-cyan-400 font-mono">100%</span>
        </div>
        <span className="text-[10px] text-slate-500 underline mt-1">
          {language === 'ar' ? 'المس الشاشة للمتابعة' : 'Tap to enter'}
        </span>
      </div>
    </div>
  );
}
