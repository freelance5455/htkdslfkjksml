import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Activity, 
  Sparkles, 
  Smartphone, 
  Wifi, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { cryptoTickerService, CryptoTickerData } from '../lib/cryptoTickerService';

export const CryptoTickerBar: React.FC = () => {
  const [ticker, setTicker] = useState<CryptoTickerData>(() => cryptoTickerService.getTickerData());
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  useEffect(() => {
    const unsub = cryptoTickerService.subscribe((data) => {
      setTicker(data);
    });
    return () => unsub();
  }, []);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await cryptoTickerService.fetchLivePrices();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <div className="w-full bg-slate-950/95 border-2 border-amber-500/40 rounded-2xl p-2.5 sm:p-3 shadow-xl overflow-hidden relative">
      {/* Subtle background glow */}
      <div className="absolute top-0 right-1/4 w-64 h-full bg-amber-500/5 blur-xl pointer-events-none" />

      <div className="flex flex-col lg:flex-row items-center justify-between gap-3 text-xs">
        {/* Left Live Badge */}
        <div className="flex items-center space-x-2 shrink-0 self-start sm:self-center">
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-mono font-bold text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
            <span>LIVE CRYPTO & CONVERTO TICKER</span>
          </div>
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 transition-all"
            title="Refresh Live Rates"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Scrolling / Marquee Ticker Strip */}
        <div className="flex-1 overflow-x-auto no-scrollbar w-full flex items-center space-x-4 py-0.5 font-mono text-[11px]">
          {/* Item 1: Bitcoin BTC/USD & NGN */}
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
            <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 font-black text-[10px]">
              ₿
            </span>
            <span className="font-bold text-slate-200">BTC/USD:</span>
            <span className="text-amber-300 font-black">
              ${ticker.btcUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">
              ₦{ticker.btcNgn.toLocaleString()}
            </span>
            <span className={`flex items-center text-[10px] font-bold ${ticker.change24hBtc >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {ticker.change24hBtc >= 0 ? <TrendingUp className="w-3 h-3 inline mr-0.5" /> : <TrendingDown className="w-3 h-3 inline mr-0.5" />}
              {ticker.change24hBtc >= 0 ? `+${ticker.change24hBtc}%` : `${ticker.change24hBtc}%`}
            </span>
          </div>

          {/* Item 2: CONVERTO Rate - Data to Bitcoin */}
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-950/60 to-slate-900 border border-amber-500/40 shrink-0 shadow-sm">
            <span className="flex items-center space-x-1 text-amber-300 font-bold">
              <Wifi className="w-3.5 h-3.5 text-amber-400" />
              <span>DATA &rarr; BITCOIN:</span>
            </span>
            <span className="text-emerald-300 font-extrabold">
              1 MB = 100,000,000 Sats (1.0 BTC)
            </span>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/30">
              DIVINE PEG
            </span>
          </div>

          {/* Item 3: CONVERTO Rate - Airtime to Cash */}
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/40 shrink-0 shadow-sm">
            <span className="flex items-center space-x-1 text-emerald-300 font-bold">
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>AIRTIME &rarr; CASH:</span>
            </span>
            <span className="text-amber-200 font-extrabold">
              ₦1.00 Airtime = $1.00 USD / ₦1,550 Cash
            </span>
            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold border border-amber-500/30">
              1:1 PARITY
            </span>
          </div>

          {/* Item 4: Ethereum */}
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
            <span className="w-5 h-5 rounded-full bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300 font-black text-[10px]">
              Ξ
            </span>
            <span className="font-bold text-slate-200">ETH:</span>
            <span className="text-blue-300 font-black">${ticker.ethUsd.toLocaleString()}</span>
            <span className={`text-[10px] font-bold ${ticker.change24hEth >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              +{ticker.change24hEth}%
            </span>
          </div>

          {/* Item 5: USDT / NGN */}
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
            <span className="w-5 h-5 rounded-full bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300 font-black text-[10px]">
              ₮
            </span>
            <span className="font-bold text-slate-200">USDT/NGN:</span>
            <span className="text-teal-300 font-bold">₦{ticker.usdtNgn.toLocaleString()}</span>
          </div>
        </div>

        {/* Updated Timestamp */}
        <div className="text-[10px] text-slate-500 font-mono shrink-0 hidden sm:block">
          Sync: {ticker.lastUpdated}
        </div>
      </div>
    </div>
  );
};
