import { Avatar } from "@/components/avatar";
import { ScreenHeader } from "@/components/phone-shell";
import { formatPhone } from "@/lib/emergency";
import { formatCallWhen, formatDurationLabel } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import { useMemo, useState } from "react";

const FILTERS = ["Handled", "Summaries", "Messages", "Important"] as const;
type Filter = (typeof FILTERS)[number];

export function AiCallsView() {
  const calls = useAppStore((s) => s.calls);
  const summaries = useAppStore((s) => s.summaries);
  const messages = useAppStore((s) => s.messages);
  const setOverlay = useAppStore((s) => s.setOverlay);
  const [filter, setFilter] = useState<Filter>("Handled");

  const lisaCalls = useMemo(() => calls.filter((c) => c.handler === "lisa"), [calls]);
  const important = useMemo(
    () => calls.filter((c) => c.important || c.emergency),
    [calls],
  );

  return (
    <div>
      <ScreenHeader title="AI Calls" subtitle="Lisa-handled conversations" />
      <div className="flex gap-2 overflow-x-auto px-5 pb-4">
        {FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            className={
              filter === f
                ? "h-9 shrink-0 rounded-full bg-foreground px-3 text-sm text-background"
                : "h-9 shrink-0 rounded-full bg-muted px-3 text-sm text-muted-foreground"
            }
          >
            {f}
          </button>
        ))}
      </div>

      {filter === "Messages" ? (
        messages.length === 0 ? (
          <Empty text="No messages yet. When Lisa takes one, it appears here." />
        ) : (
          messages.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setOverlay({ kind: "call-detail", callId: m.callId })}
              className="flex w-full gap-3 px-5 py-3 text-left hover:bg-muted/60"
            >
              <Avatar name={m.caller} />
              <div className="min-w-0">
                <p className="font-medium">{m.caller}</p>
                <p className="truncate text-sm text-muted-foreground">{m.text}</p>
                <p className="mt-1 text-xs text-subtle">{formatCallWhen(m.at)}</p>
              </div>
            </button>
          ))
        )
      ) : null}

      {filter === "Summaries" ? (
        summaries.length === 0 ? (
          <Empty text="Summaries are saved after Lisa-handled calls, if enabled in Privacy." />
        ) : (
          summaries.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setOverlay({ kind: "call-detail", callId: s.callId })}
              className="flex w-full gap-3 px-5 py-3 text-left hover:bg-muted/60"
            >
              <Avatar name={s.caller} />
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium">{s.caller}</p>
                  <UrgencyBadge urgency={s.urgency} />
                </div>
                <p className="text-sm text-muted-foreground">{s.reason}</p>
                <p className="mt-0.5 line-clamp-2 text-xs text-subtle">{s.summary}</p>
              </div>
            </button>
          ))
        )
      ) : null}

      {filter === "Handled" ? (
        lisaCalls.length === 0 ? (
          <Empty text="No Lisa-handled calls yet. Ring a demo incoming call from the keypad." />
        ) : (
          lisaCalls.map((c) => {
            const sum = summaries.find((s) => s.callId === c.id);
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setOverlay({ kind: "call-detail", callId: c.id })}
                className="flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60"
              >
                <Avatar name={c.name} />
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{c.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatPhone(c.number)} · {formatDurationLabel(c.durationSec)}
                    {sum ? " · Summary" : ""}
                    {c.hasMessage ? " · Message" : ""}
                  </p>
                </div>
                <span className="text-xs text-subtle">{formatCallWhen(c.startedAt)}</span>
              </button>
            );
          })
        )
      ) : null}

      {filter === "Important" ? (
        important.length === 0 ? (
          <Empty text="Mark a call important, or let Lisa flag high-urgency ones." />
        ) : (
          important.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setOverlay({ kind: "call-detail", callId: c.id })}
              className="flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60"
            >
              <Avatar name={c.name} />
              <div className="min-w-0 flex-1">
                <p className="font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">
                  {c.emergency ? "Emergency" : "Important"} · {formatPhone(c.number)}
                </p>
              </div>
            </button>
          ))
        )
      ) : null}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="px-5 text-sm leading-relaxed text-muted-foreground">{text}</p>;
}

export function UrgencyBadge({ urgency }: { urgency: string }) {
  const cls =
    urgency === "emergency" || urgency === "high"
      ? "text-destructive"
      : urgency === "low"
        ? "text-subtle"
        : "text-accent";
  return <span className={`text-[0.65rem] tracking-wide uppercase ${cls}`}>{urgency}</span>;
}
