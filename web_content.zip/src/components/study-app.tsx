import { useEffect, useRef } from "react";
import {
  BookOpen,
  ChartColumn,
  CircleHelp,
  Home,
  NotebookPen,
  Timer,
  type LucideIcon,
} from "lucide-react";
import { useCopy } from "@/components/bits";
import { HomeView } from "@/components/views/home-view";
import { NotesView } from "@/components/views/notes-view";
import { ProgressView } from "@/components/views/progress-view";
import { QuizView } from "@/components/views/quiz-view";
import { SubjectsView } from "@/components/views/subjects-view";
import { TimerView } from "@/components/views/timer-view";
import { chime } from "@/lib/chime";
import type { CopyKey } from "@/lib/i18n";
import type { View } from "@/lib/model";
import { useStudy } from "@/lib/store";

const NAV: { view: View; key: CopyKey; icon: LucideIcon }[] = [
  { view: "home", key: "home", icon: Home },
  { view: "subjects", key: "subjects", icon: BookOpen },
  { view: "timer", key: "timer", icon: Timer },
  { view: "notes", key: "notes", icon: NotebookPen },
  { view: "quiz", key: "quiz", icon: CircleHelp },
  { view: "progress", key: "progress", icon: ChartColumn },
];

export function StudyApp() {
  useEffect(() => {
    const unsub = useStudy.persist.onFinishHydration(() => {
      useStudy.getState().reconcileTimer();
    });
    void useStudy.persist.rehydrate();
    return unsub;
  }, []);

  return (
    <>
      <TimerEngine />
      <Shell />
    </>
  );
}

function TimerEngine() {
  const status = useStudy((s) => s.timer.status);
  const sound = useStudy((s) => s.sound);
  const prev = useRef(status);

  useEffect(() => {
    useStudy.getState().reconcileTimer();
    const id = window.setInterval(() => useStudy.getState().reconcileTimer(), 250);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (prev.current === "running" && status === "done" && useStudy.getState().sound) chime();
    prev.current = status;
  }, [status, sound]);

  return null;
}

function Shell() {
  const { lang, t } = useCopy();
  const view = useStudy((s) => s.view);
  const setView = useStudy((s) => s.setView);
  const setLang = useStudy((s) => s.setLang);
  const timer = useStudy((s) => s.timer);

  useEffect(() => {
    document.documentElement.lang = lang === "hi" ? "hi" : "en";
  }, [lang]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh w-full max-w-5xl">
        <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-border px-4 py-6 md:flex">
          <p className="text-xs font-semibold tracking-widest text-primary">STUDYFLOW</p>
          <p className="mt-1 text-sm text-muted">{t("tagline")}</p>
          <nav className="mt-8 flex flex-col gap-1" aria-label={t("primaryNav")}>
            {NAV.map((item) => (
              <NavButton key={item.view} item={item} active={view === item.view} onClick={() => setView(item.view)} rail />
            ))}
          </nav>
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur md:px-8">
            <div className="md:hidden">
              <p className="text-xs font-semibold tracking-widest text-primary">STUDYFLOW</p>
              <p className="text-sm text-muted">{t("tagline")}</p>
            </div>
            <p className="hidden text-sm text-muted md:block">{t("tagline")}</p>
            <div className="flex rounded-full border border-border p-1" role="group" aria-label={t("switchLang")}>
              <LangButton active={lang === "hi"} onClick={() => setLang("hi")}>
                {t("langHi")}
              </LangButton>
              <LangButton active={lang === "en"} onClick={() => setLang("en")}>
                {t("langEn")}
              </LangButton>
            </div>
          </header>
          {timer.status === "done" && view !== "timer" ? (
            <button
              type="button"
              className="mx-4 mt-3 min-h-11 rounded-md border border-primary bg-surface px-3 text-sm font-medium text-primary md:mx-8"
              onClick={() => setView("timer")}
            >
              {timer.mode === "focus" ? t("focusDone") : t("breakDone")}
            </button>
          ) : null}
          <main className="flex-1 px-4 pb-24 pt-4 md:px-8 md:pb-10" data-view={view}>
            {view === "home" ? <HomeView /> : null}
            {view === "subjects" ? <SubjectsView /> : null}
            {view === "timer" ? <TimerView /> : null}
            {view === "notes" ? <NotesView /> : null}
            {view === "quiz" ? <QuizView /> : null}
            {view === "progress" ? <ProgressView /> : null}
          </main>
        </div>
      </div>
      <nav
        className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur md:hidden"
        aria-label={t("primaryNav")}
      >
        <div className="mx-auto grid max-w-lg grid-cols-6 px-1 pb-2 pt-1">
          {NAV.map((item) => (
            <NavButton key={item.view} item={item} active={view === item.view} onClick={() => setView(item.view)} />
          ))}
        </div>
      </nav>
    </div>
  );
}

function NavButton({
  item,
  active,
  onClick,
  rail = false,
}: {
  item: (typeof NAV)[number];
  active: boolean;
  onClick: () => void;
  rail?: boolean;
}) {
  const { t } = useCopy();
  const Icon = item.icon;
  return (
    <button
      type="button"
      aria-current={active ? "page" : undefined}
      className={
        rail
          ? `flex min-h-11 items-center gap-3 rounded-md px-3 text-sm font-medium ${
              active ? "bg-surface text-fg" : "text-muted hover:bg-surface-2 hover:text-fg"
            }`
          : `flex min-h-12 min-w-0 flex-col items-center justify-center gap-1 rounded-md px-0.5 text-xs ${
              active ? "text-primary" : "text-muted"
            }`
      }
      onClick={onClick}
    >
      <Icon className={rail ? "size-4" : "size-5"} aria-hidden="true" />
      <span className={rail ? "" : "max-w-full truncate"}>{t(item.key)}</span>
    </button>
  );
}

function LangButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`min-h-11 rounded-full px-3 text-sm font-medium ${
        active ? "bg-primary text-primary-fg" : "text-muted"
      }`}
      aria-pressed={active}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
