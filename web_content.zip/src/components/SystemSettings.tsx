import React, { useState } from 'react';
import { Settings, Shield, Battery, Zap, HardDrive, Lock } from 'lucide-react';

export function SystemSettings() {
  const [powerProfile, setPowerProfile] = useState('balanced');
  const [autoCleanup, setAutoCleanup] = useState(true);
  const [backgroundOptimization, setBackgroundOptimization] = useState(true);
  const [thermalThrottle, setThermalThrottle] = useState(true);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-2">
          <Settings className="w-6 h-6 text-gray-400" />
          System Settings
        </h2>
        <p className="text-gray-400 text-sm">Configure launcher preferences & performance profiles</p>
      </div>

      {/* Power Profile Selection */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Battery className="w-5 h-5 text-yellow-500" />
          <h3 className="text-lg font-bold text-white">Power Profile</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              id: 'powersave',
              name: 'Power Saver',
              icon: '🔋',
              description: 'Maximum battery life',
              benefits: ['Minimal CPU usage', 'Reduced refresh rate', 'Limited features'],
            },
            {
              id: 'balanced',
              name: 'Balanced',
              icon: '⚖️',
              description: 'Standard performance',
              benefits: ['Moderate performance', 'Reasonable battery', 'All features'],
            },
            {
              id: 'performance',
              name: 'High Performance',
              icon: '⚡',
              description: 'Maximum power',
              benefits: ['Peak performance', 'All cores active', 'Maximum features'],
            },
          ].map(profile => (
            <button
              key={profile.id}
              onClick={() => setPowerProfile(profile.id)}
              className={`p-4 rounded-lg border-2 transition-all duration-200 text-left ${
                powerProfile === profile.id
                  ? 'border-yellow-500 bg-yellow-900/20'
                  : 'border-gray-700 bg-gray-700/20 hover:border-gray-600'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-3xl">{profile.icon}</span>
                {powerProfile === profile.id && (
                  <span className="px-2 py-1 bg-yellow-600/30 rounded text-xs font-bold text-yellow-300">
                    ACTIVE
                  </span>
                )}
              </div>
              <p className="font-bold text-white text-sm mb-1">{profile.name}</p>
              <p className="text-xs text-gray-400 mb-3">{profile.description}</p>
              <ul className="space-y-1">
                {profile.benefits.map((benefit, i) => (
                  <li key={i} className="text-xs text-gray-300">
                    ✓ {benefit}
                  </li>
                ))}
              </ul>
            </button>
          ))}
        </div>
      </div>

      {/* Optimization Settings */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Zap className="w-5 h-5 text-red-500" />
          <h3 className="text-lg font-bold text-white">Optimization Settings</h3>
        </div>

        {[
          {
            id: 'autoclean',
            name: 'Auto Memory Cleanup',
            description: 'Automatically clean memory every 15 minutes',
            icon: '🧹',
            enabled: autoCleanup,
            onChange: setAutoCleanup,
          },
          {
            id: 'bgopt',
            name: 'Background Optimization',
            description: 'Run lightweight background cleanup tasks',
            icon: '🔄',
            enabled: backgroundOptimization,
            onChange: setBackgroundOptimization,
          },
          {
            id: 'thermal',
            name: 'Thermal Throttling',
            description: 'Reduce performance if device overheats',
            icon: '🌡️',
            enabled: thermalThrottle,
            onChange: setThermalThrottle,
          },
        ].map(setting => (
          <div
            key={setting.id}
            className="flex items-center justify-between p-4 bg-gray-700/20 rounded-lg hover:bg-gray-700/30 transition-all duration-200"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{setting.icon}</span>
              <div>
                <p className="font-semibold text-white text-sm">{setting.name}</p>
                <p className="text-xs text-gray-400">{setting.description}</p>
              </div>
            </div>
            <button
              onClick={() => setting.onChange(!setting.enabled)}
              className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
                setting.enabled ? 'bg-green-600' : 'bg-gray-600'
              }`}
            >
              <div
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-300 ${
                  setting.enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        ))}
      </div>

      {/* Security & Privacy */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-5 h-5 text-green-500" />
          <h3 className="text-lg font-bold text-white">Security & Privacy</h3>
        </div>

        {[
          {
            label: 'Session Encryption',
            status: 'Enabled',
            statusColor: 'text-green-400',
            icon: '🔐',
            description: 'All sessions encrypted with TLS 1.3',
          },
          {
            label: 'Google Play Protect',
            status: 'Verified',
            statusColor: 'text-green-400',
            icon: '✓',
            description: '100% malware-free, safe to use',
          },
          {
            label: 'Data Collection',
            status: 'Disabled',
            statusColor: 'text-green-400',
            icon: '🚫',
            description: 'No user data collection or tracking',
          },
          {
            label: 'Root Detection',
            status: 'Active',
            statusColor: 'text-green-400',
            icon: '🛡️',
            description: 'Detects & prevents rooted devices',
          },
        ].map((item, i) => (
          <div key={i} className="p-4 bg-green-900/10 border border-green-700/30 rounded-lg">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-lg">{item.icon}</span>
                <div>
                  <p className="font-semibold text-white text-sm">{item.label}</p>
                  <p className="text-xs text-gray-400">{item.description}</p>
                </div>
              </div>
              <span className={`text-xs font-bold ${item.statusColor}`}>{item.status}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Storage & Cache */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <HardDrive className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-bold text-white">Storage & Cache</h3>
        </div>

        {[
          { name: 'App Cache', size: '1.2GB', action: 'Clear' },
          { name: 'Temp Files', size: '342MB', action: 'Clear' },
          { name: 'Crash Logs', size: '45MB', action: 'Clear' },
        ].map((item, i) => (
          <div key={i} className="flex items-center justify-between p-3 bg-gray-700/20 rounded-lg">
            <div>
              <p className="font-semibold text-white text-sm">{item.name}</p>
              <p className="text-xs text-gray-400">{item.size}</p>
            </div>
            <button className="px-3 py-1 bg-red-600/30 hover:bg-red-600/50 border border-red-700/50 rounded text-xs font-bold text-red-300 transition-all duration-200">
              {item.action}
            </button>
          </div>
        ))}

        <button className="w-full mt-4 py-3 bg-red-600/20 hover:bg-red-600/30 border border-red-700/50 rounded-lg text-red-300 font-bold transition-all duration-200">
          🗑️ Clear All Cache
        </button>
      </div>

      {/* About & Version */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm space-y-3">
        <h3 className="text-lg font-bold text-white mb-4">About</h3>

        {[
          { label: 'App Name', value: 'RedMagic Game Space' },
          { label: 'Version', value: '2.0.1' },
          { label: 'Build Number', value: '20250115' },
          { label: 'Android API', value: '14+' },
          { label: 'License', value: 'GPL v3 - Open Source' },
        ].map((item, i) => (
          <div key={i} className="flex justify-between py-2 border-b border-gray-700/50 last:border-0">
            <span className="text-gray-400 text-sm">{item.label}</span>
            <span className="text-white font-semibold text-sm">{item.value}</span>
          </div>
        ))}

        <div className="mt-4 space-y-2">
          <button className="w-full py-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-700/50 rounded-lg text-blue-300 font-semibold transition-all duration-200 text-sm">
            📖 View Documentation
          </button>
          <button className="w-full py-2 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-700/50 rounded-lg text-purple-300 font-semibold transition-all duration-200 text-sm">
            ⭐ Rate on Play Store
          </button>
        </div>
      </div>

      {/* Compliance Badge */}
      <div className="bg-gradient-to-r from-green-900/30 to-blue-900/30 border border-green-700/50 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <Lock className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
          <div>
            <p className="font-bold text-green-300 mb-2">✓ 100% Google Play Protect Compliant</p>
            <ul className="text-xs text-green-300/80 space-y-1">
              <li>✓ No malware, no spyware, no unauthorized system modifications</li>
              <li>✓ Uses only official, documented Android APIs</li>
              <li>✓ No root/privilege escalation exploits</li>
              <li>✓ No game server account suspension risks</li>
              <li>✓ Privacy-first design with optional data collection</li>
              <li>✓ Regular security audits and updates</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
