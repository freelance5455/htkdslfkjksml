import React, { useState, useEffect } from 'react';
import { 
  X, 
  Trophy, 
  Award, 
  Gift, 
  Clock, 
  Users, 
  Search, 
  Sparkles, 
  ShieldCheck, 
  Star, 
  Medal,
  Crown,
  ChevronRight,
  CheckCircle,
  RefreshCw,
  Send,
  MapPin,
  Phone,
  User,
  Loader2,
  Check
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizLeaderboardEntry, UserProfile } from '../types';

interface WeeklyQuizLeaderboardModalProps {
  quiz: WeeklyQuiz;
  language: string;
  userProfile?: UserProfile;
  onClose: () => void;
  onJoinQuiz?: () => void;
}

export default function WeeklyQuizLeaderboardModal({
  quiz,
  language,
  userProfile,
  onClose,
  onJoinQuiz
}: WeeklyQuizLeaderboardModalProps) {
  const [leaderboard, setLeaderboard] = useState<WeeklyQuizLeaderboardEntry[]>([]);
  const [winner, setWinner] = useState<any>(quiz.winner || null);
  const [totalParticipants, setTotalParticipants] = useState<number>(quiz.participantsCount || 0);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Winner Claim Prize Form State
  const [showClaimModal, setShowClaimModal] = useState<boolean>(false);
  const [claimSubmitted, setClaimSubmitted] = useState<boolean>(false);
  const [claimSubmitting, setClaimSubmitting] = useState<boolean>(false);
  const [claimError, setClaimError] = useState<string>('');
  const [claimForm, setClaimForm] = useState({
    fullName: userProfile?.name || '',
    phone: userProfile?.phone || '',
    address: '',
    pincode: '',
    state: 'West Bengal',
    additionalNotes: ''
  });

  const currentUserId = userProfile?.name 
    ? `user-${userProfile.name.toLowerCase().replace(/\s+/g, '-')}`
    : 'user-guest';

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/weekly-quiz/${quiz.id}/leaderboard?userId=${currentUserId}`);
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data.leaderboard || []);
        setWinner(data.winner || null);
        setTotalParticipants(data.totalParticipants || (data.leaderboard || []).length);
      }
    } catch (e) {
      console.warn('Failed to fetch leaderboard:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, [quiz.id]);

  const filteredLeaderboard = leaderboard.filter(entry => 
    entry.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentUserEntry = leaderboard.find(e => e.isCurrentUser || e.userId === currentUserId);
  const isCurrentUserWinner = winner && (winner.userId === currentUserId || (currentUserEntry && currentUserEntry.rank === 1 && quiz.winnerVerified));

  const handleClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimForm.fullName || !claimForm.phone || !claimForm.address || !claimForm.pincode) {
      setClaimError(language === 'bn' ? 'সবগুলো প্রয়োজনীয় ঘর পূরণ করুন' : 'Please fill in all required fields');
      return;
    }

    try {
      setClaimSubmitting(true);
      setClaimError('');
      const res = await fetch(`/api/weekly-quiz/${quiz.id}/claim-prize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUserId,
          claimInfo: claimForm
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setClaimSubmitted(true);
        setShowClaimModal(false);
        fetchLeaderboard();
      } else {
        setClaimError(data.error || (language === 'bn' ? 'তথ্য জমা দিতে সমস্যা হয়েছে' : 'Failed to submit claim info'));
      }
    } catch (err: any) {
      setClaimError(language === 'bn' ? 'নেটওয়ার্ক ত্রুটি' : 'Network error');
    } finally {
      setClaimSubmitting(false);
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    if (mins > 0) {
      return `${mins}m ${s}s`;
    }
    return `${s}s`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-slate-100">
        
        {/* MODAL HEADER */}
        <div className="bg-slate-800/90 border-b border-slate-700/80 px-4 md:px-6 py-3.5 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 rounded-xl font-black shadow-lg shadow-amber-500/20">
              <Trophy className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base md:text-lg font-black text-white">
                {language === 'bn' ? '🏆 সাপ্তাহিক কুইজ লিডারবোর্ড' : '🏆 Weekly Quiz Leaderboard'}
              </h2>
              <p className="text-[11px] text-slate-400">
                {quiz.title} • {totalParticipants} {language === 'bn' ? 'জন অংশগ্রহণকারী' : 'Participants'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchLeaderboard}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 rounded-full transition-all cursor-pointer"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 rounded-full transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* WINNER SHOWCASE BANNER (IF ANNOUNCED / VERIFIED) */}
        {winner && (
          <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border-b border-amber-500/30 p-4 md:p-5 shrink-0">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 bg-gradient-to-tr from-amber-400 to-amber-600 text-slate-950 rounded-2xl flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
                  <Crown className="w-7 h-7 fill-current text-slate-950" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-black rounded-md">
                      🥇 {language === 'bn' ? 'অফিশিয়াল বিজয়ী' : 'Official Winner'}
                    </span>
                    {winner.status && (
                      <span className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-bold rounded-md">
                        {winner.status}
                      </span>
                    )}
                  </div>
                  <h3 className="text-base md:text-lg font-black text-white mt-0.5">
                    {winner.displayName}
                  </h3>
                  <p className="text-xs text-amber-200/90 font-medium">
                    {language === 'bn' ? 'স্কোর:' : 'Score:'} <strong>{winner.score}/{winner.totalQuestions}</strong> • {formatTime(winner.completionTimeSeconds)}
                  </p>
                </div>
              </div>

              {/* PRIZE METADATA & CLAIM CTA */}
              <div className="flex items-center gap-3">
                <div className="bg-slate-950/70 border border-amber-500/30 p-3 rounded-2xl flex items-center gap-3 max-w-xs">
                  {quiz.prizeImage ? (
                    <img 
                      src={quiz.prizeImage} 
                      alt={quiz.prizeName} 
                      className="w-11 h-11 rounded-xl object-cover border border-amber-500/40 shrink-0 shadow-md"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-300">
                      <Gift className="w-5 h-5" />
                    </div>
                  )}
                  <div>
                    <span className="text-[10px] font-bold text-amber-400 block">{language === 'bn' ? '🎁 পুরস্কার' : '🎁 Prize'}</span>
                    <span className="text-xs font-black text-white line-clamp-1">{quiz.prizeName}</span>
                  </div>
                </div>

                {isCurrentUserWinner && (
                  <button
                    onClick={() => setShowClaimModal(true)}
                    className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 whitespace-nowrap"
                  >
                    <Gift className="w-4 h-4 text-amber-300" />
                    <span>{claimSubmitted ? (language === 'bn' ? 'ঠিকানা আপডেট করুন' : 'Update Address') : (language === 'bn' ? 'পুরস্কার দাবি করুন' : 'Claim Prize')}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* CLAIM SUCCESS BANNER IF SUBMITTED */}
        {claimSubmitted && (
          <div className="bg-emerald-950/60 border-b border-emerald-500/40 px-4 md:px-6 py-2.5 flex items-center justify-between text-xs text-emerald-200">
            <span className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{language === 'bn' ? 'আপনার ডেলিভারি ঠিকানা সফলভাবে জমা হয়েছে! অ্যাডমিন কুরিয়ারে পুরস্কার পাঠাবেন।' : 'Your delivery details have been submitted! Admin will ship your physical prize.'}</span>
            </span>
          </div>
        )}

        {/* USER'S OWN RANK HIGHLIGHT */}
        {currentUserEntry && (
          <div className="bg-indigo-950/70 border-b border-indigo-500/40 px-4 md:px-6 py-3 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 border border-indigo-400 text-white flex items-center justify-center font-black text-sm shadow-md">
                #{currentUserEntry.rank}
              </div>
              <div>
                <span className="text-xs font-black text-indigo-200 block">
                  {language === 'bn' ? 'আপনার বর্তমান র‍্যাঙ্ক' : 'Your Official Rank'}
                </span>
                <span className="text-[11px] text-slate-300">
                  {currentUserEntry.displayName} • {currentUserEntry.score}/{currentUserEntry.totalQuestions} ({formatTime(currentUserEntry.completionTimeSeconds)})
                </span>
              </div>
            </div>

            <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-extrabold rounded-xl">
              ✓ {language === 'bn' ? 'যাচাইকৃত স্কোর' : 'Verified Score'}
            </span>
          </div>
        )}

        {/* SEARCH & FILTER BAR */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between gap-3 shrink-0">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={language === 'bn' ? 'প্রতিযোগীদের নাম খুঁজুন...' : 'Search participant name...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 text-slate-100 text-xs rounded-xl pl-9 pr-4 py-2 focus:outline-none"
            />
          </div>

          <div className="text-xs text-slate-400 font-bold shrink-0 hidden sm:block">
            {language === 'bn' ? 'র‍্যাঙ্কিং: সর্বোচ্চ স্কোর → দ্রুততম সময়' : 'Rank: High score → Fast time'}
          </div>
        </div>

        {/* LEADERBOARD PARTICIPANTS LIST */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-2.5">
          {loading ? (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <span>{language === 'bn' ? 'লিডারবোর্ড লোড হচ্ছে...' : 'Loading leaderboard...'}</span>
            </div>
          ) : filteredLeaderboard.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <Users className="w-8 h-8 mx-auto text-slate-600" />
              <span>{language === 'bn' ? 'কোনো ফলাফল পাওয়া যায়নি' : 'No participants found'}</span>
            </div>
          ) : (
            filteredLeaderboard.map((entry) => {
              const isTop1 = entry.rank === 1;
              const isTop2 = entry.rank === 2;
              const isTop3 = entry.rank === 3;
              const isUser = entry.isCurrentUser || entry.userId === currentUserId;

              return (
                <div 
                  key={entry.userId + entry.rank}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition-all ${
                    isUser
                      ? 'bg-indigo-950/60 border-indigo-500 shadow-md ring-1 ring-indigo-400'
                      : isTop1
                      ? 'bg-amber-950/30 border-amber-500/50 text-white'
                      : isTop2
                      ? 'bg-slate-800/80 border-slate-600 text-white'
                      : isTop3
                      ? 'bg-amber-950/20 border-amber-700/40 text-white'
                      : 'bg-slate-800/50 border-slate-800 text-slate-300'
                  }`}
                >
                  {/* RANK & NAME */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 flex items-center justify-center shrink-0">
                      {isTop1 ? (
                        <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black text-sm shadow-md">
                          🥇
                        </div>
                      ) : isTop2 ? (
                        <div className="w-8 h-8 rounded-xl bg-slate-300 text-slate-950 flex items-center justify-center font-black text-sm shadow-md">
                          🥈
                        </div>
                      ) : isTop3 ? (
                        <div className="w-8 h-8 rounded-xl bg-amber-700 text-white flex items-center justify-center font-black text-sm shadow-md">
                          🥉
                        </div>
                      ) : (
                        <span className="font-extrabold text-xs text-slate-400">
                          #{entry.rank}
                        </span>
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-xs md:text-sm text-white truncate max-w-[160px] md:max-w-[240px]">
                          {entry.displayName}
                        </span>
                        {isUser && (
                          <span className="px-2 py-0.5 bg-indigo-500/30 border border-indigo-400/40 text-indigo-300 text-[10px] font-black rounded-md shrink-0">
                            {language === 'bn' ? 'আপনি' : 'You'}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {language === 'bn' ? 'সময়:' : 'Time:'} {formatTime(entry.completionTimeSeconds)}
                      </span>
                    </div>
                  </div>

                  {/* SCORE & MEDAL */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-sm md:text-base font-black text-emerald-400">
                        {entry.score} <span className="text-slate-500 text-xs">/ {entry.totalQuestions}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="bg-slate-800/90 border-t border-slate-700/80 px-4 md:px-6 py-3.5 flex items-center justify-between gap-3 shrink-0">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{language === 'bn' ? 'অ্যাডমিন দ্বারা যাচাইকৃত ও সুরক্ষিত ফলাফল' : 'Verified fair-play leaderboard'}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-xl cursor-pointer transition-all"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* WINNER PRIZE CLAIM ADDRESS POPUP MODAL */}
      {/* ========================================================================= */}
      {showClaimModal && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 text-slate-100">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    {language === 'bn' ? '🎁 পুরস্কার গ্রহণের ডেলিভারি তথ্য' : '🎁 Claim Your Physical Prize'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn' ? 'কুরিয়ারের মাধ্যমে উপহার পৌঁছে দেওয়ার জন্য সঠিক ঠিকানা দিন' : 'Enter valid postal address for physical delivery'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setShowClaimModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {claimError && (
              <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl text-xs text-rose-300 font-bold">
                {claimError}
              </div>
            )}

            <form onSubmit={handleClaimSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1">
                    <User className="w-3 h-3 text-indigo-400" />
                    <span>{language === 'bn' ? 'পূর্ণ নাম *' : 'Full Name *'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={claimForm.fullName}
                    onChange={(e) => setClaimForm({ ...claimForm, fullName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                    placeholder="Candidate Name"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-400" />
                    <span>{language === 'bn' ? 'মোবাইল নম্বর *' : 'Phone Number *'}</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={claimForm.phone}
                    onChange={(e) => setClaimForm({ ...claimForm, phone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                    placeholder="10-digit mobile"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-rose-400" />
                  <span>{language === 'bn' ? 'সম্পূর্ণ ডেলিভারি ঠিকানা (গ্রাম/শহর, থানা, জেলা) *' : 'Full Postal Address *'}</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={claimForm.address}
                  onChange={(e) => setClaimForm({ ...claimForm, address: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                  placeholder="House/Street, Post Office, Police Station, District"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-bold">
                    <span>{language === 'bn' ? 'পিন কোড (PIN Code) *' : 'PIN Code *'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={claimForm.pincode}
                    onChange={(e) => setClaimForm({ ...claimForm, pincode: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                    placeholder="700001"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold">
                    <span>{language === 'bn' ? 'রাজ্য (State)' : 'State'}</span>
                  </label>
                  <input
                    type="text"
                    value={claimForm.state}
                    onChange={(e) => setClaimForm({ ...claimForm, state: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                    placeholder="West Bengal"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium text-[11px]">
                  <span>{language === 'bn' ? 'অতিরিক্ত নির্দেশিকা (ঐচ্ছিক)' : 'Landmark / Additional Notes (Optional)'}</span>
                </label>
                <input
                  type="text"
                  value={claimForm.additionalNotes}
                  onChange={(e) => setClaimForm({ ...claimForm, additionalNotes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                  placeholder="Near School / Hospital"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowClaimModal(false)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={claimSubmitting}
                  className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  {claimSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>{language === 'bn' ? 'তথ্য জমা দিন' : 'Submit Delivery Details'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
