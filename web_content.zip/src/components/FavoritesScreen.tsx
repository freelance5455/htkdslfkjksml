import React, { useState, useEffect } from 'react';
import { Heart, ChevronLeft, Trash2, Volume2, VolumeX } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ALL_ADHKAR } from '../data/adhkarData';
import { DhikrItem } from '../types';
import { recitationEngine } from '../utils/recitationService';
import { triggerVibration } from '../utils/audioFeedback';

export const FavoritesScreen: React.FC = () => {
  const { favorites, toggleFavorite, openDhikr, getProgressFor, setActiveTab, settings, showToast } = useApp();

  const [activeAudioDhikrId, setActiveAudioDhikrId] = useState<string | null>(null);

  useEffect(() => {
    const handleAudioState = () => {
      if (!recitationEngine.isPlaying()) {
        setActiveAudioDhikrId(null);
      }
    };
    recitationEngine.setOnStateChange(handleAudioState);
    return () => {};
  }, []);

  const handleToggleAudio = (dhikr: DhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerVibration(settings.vibration !== false, 'light');

    if (activeAudioDhikrId === dhikr.id && recitationEngine.isPlaying()) {
      recitationEngine.pause();
      setActiveAudioDhikrId(null);
      showToast('تم إيقاف تلاوة الذكر');
    } else {
      setActiveAudioDhikrId(dhikr.id);
      recitationEngine.setReciter(settings.selectedReciter || 'alafasy');
      recitationEngine.playDhikr(dhikr);
      showToast(`استماع للذكر المبارك: ${dhikr.title} 🎙️`);
    }
  };

  const favoriteDhikrs = ALL_ADHKAR.filter(d => favorites.includes(d.id));

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="pt-2">
        <h2 className="text-2xl font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
          الأذكار المفضلة
        </h2>
        <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
          {favoriteDhikrs.length} {favoriteDhikrs.length === 1 ? 'ذكر محفوظ' : 'أذكار محفوظة في قائمتك الخاصة'}
        </p>
      </div>

      {favoriteDhikrs.length === 0 ? (
        /* Empty State */
        <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-3xl p-8 text-center space-y-4 my-8">
          <div className="w-16 h-16 rounded-full bg-red-500/15 dark:bg-red-950/30 text-red-500 mx-auto flex items-center justify-center">
            <Heart className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
              لا توجد أذكار في المفضلة بعد
            </h3>
            <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] max-w-xs mx-auto font-tajawal">
              يمكنك الضغط على رمز القلب في أي ذكر لحفظه هنا والوصول إليه بسرعة وسهولة في أي وقت.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('list')}
            className="px-6 py-2.5 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-600 hover:to-emerald-700 text-[#f4faf6] font-bold rounded-xl text-xs transition-colors cursor-pointer font-cairo shadow-md shadow-emerald-950/20"
          >
            تصفح جميع الأذكار
          </button>
        </div>
      ) : (
        /* List of favorites */
        <div className="space-y-2.5">
          {favoriteDhikrs.map((dhikr) => {
            const currentCount = getProgressFor(dhikr.id);
            const isDone = currentCount >= dhikr.count;

            const repetitionText = 
              dhikr.count === 1 ? 'مرة واحدة' :
              dhikr.count === 3 ? '٣ مرات' :
              dhikr.count === 4 ? '٤ مرات' :
              dhikr.count === 7 ? '٧ مرات' :
              dhikr.count === 10 ? '١٠ مرات' :
              dhikr.count === 100 ? '١٠٠ مرة' : `${dhikr.count} مرات`;

            return (
              <div
                key={dhikr.id}
                onClick={() => openDhikr(dhikr)}
                className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/60 rounded-2xl p-4 shadow-xs hover:border-emerald-500 dark:hover:border-emerald-600 hover:shadow-md transition-all cursor-pointer flex items-start justify-between gap-3 group"
              >
                <div className="w-10 h-10 rounded-xl bg-red-500/15 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-300/40 flex items-center justify-center shrink-0 shadow-2xs">
                  <Heart className="w-4 h-4 fill-red-500/30" />
                </div>

                <div className="flex-1 min-w-0 text-right">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] truncate font-cairo group-hover:text-emerald-800 dark:group-hover:text-emerald-300">
                      {dhikr.title}
                    </h3>
                    <span className="shrink-0 px-2 py-0.5 rounded-full bg-emerald-700/15 border border-emerald-600/40 text-[#123828] dark:text-emerald-300 text-[10px] font-bold font-cairo shadow-2xs">
                      {repetitionText}
                    </span>
                  </div>

                  <p className="text-xs text-[#2b5945] dark:text-[#84b8a0] font-tajawal line-clamp-2 leading-relaxed">
                    {dhikr.text}
                  </p>

                  <div className="flex items-center gap-3 mt-2 text-[11px] text-[#4d7d67] dark:text-[#7ba993]">
                    <span className="text-emerald-800 dark:text-emerald-300 font-medium">
                      · {dhikr.categoryArabic}
                    </span>
                    {currentCount > 0 && (
                      <span className={isDone ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-amber-600 dark:text-amber-400 font-medium'}>
                        · المنجز: {currentCount} / {dhikr.count}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-center gap-1.5 shrink-0">
                  {/* Audio Listen Button */}
                  <button
                    type="button"
                    onClick={(e) => handleToggleAudio(dhikr, e)}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      activeAudioDhikrId === dhikr.id
                        ? 'bg-amber-500 text-[#0c2e20] shadow-xs animate-pulse ring-1 ring-amber-300'
                        : 'text-[#62927c] hover:text-amber-500 dark:hover:text-amber-300'
                    }`}
                    title={activeAudioDhikrId === dhikr.id ? 'إيقاف الاستماع' : 'استمع لتلاوة الذكر'}
                    aria-label="الاستماع للذكر"
                  >
                    {activeAudioDhikrId === dhikr.id ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(dhikr.id);
                    }}
                    className="p-1.5 rounded-lg text-red-400 hover:text-red-600 transition-colors cursor-pointer"
                    title="إزالة من المفضلة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <ChevronLeft className="w-4 h-4 text-[#7ca994] dark:text-[#5e967e] group-hover:text-emerald-600 transition-colors" />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
