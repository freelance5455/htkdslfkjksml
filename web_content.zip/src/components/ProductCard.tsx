import React from 'react';
import { ShoppingBag, Eye, ArrowRight, Zap, CheckCircle, AlertTriangle } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductCardProps {
  product: Product;
  onSelect: (p: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addToCart, buyNow } = useStore();

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.minStockAlert;

  const categoryLabels: Record<string, string> = {
    ebooks: 'eBook & Capa 3D',
    spreadsheets: 'Planilha Automatizada',
    covers3d: 'Mockup 3D',
    ads_banners: 'Criativos & Banners',
    courses_vsl: 'Curso & VSL',
    physical: 'Produto Físico'
  };

  return (
    <div className="group flex flex-col bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-slate-300 hover:shadow-md transition-all duration-200">
      
      {/* Product Image Slot */}
      <div 
        onClick={() => onSelect(product)}
        className="relative aspect-4/3 w-full bg-slate-100 overflow-hidden cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-102 transition-transform duration-300"
          onError={(e) => {
            // Elegant fallback container if external image fails
            (e.target as HTMLElement).style.display = 'none';
          }}
        />

        {/* Fallback pattern underneath */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-tr from-slate-200 to-slate-100 flex items-center justify-center p-4 text-center">
          <span className="text-xs font-medium text-slate-500">{product.name}</span>
        </div>

        {/* Stock status overlay flag */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {isOutOfStock ? (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-rose-900/85 text-white backdrop-blur-xs shadow-xs">
              Esgotado
            </span>
          ) : isLowStock ? (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-amber-500/90 text-white backdrop-blur-xs shadow-xs flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              Resta apenas {product.stock} un.
            </span>
          ) : (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-900/75 text-white backdrop-blur-xs">
              {product.stock} em estoque
            </span>
          )}

          {product.badge && !isOutOfStock && !isLowStock && (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-emerald-600 text-white shadow-xs">
              {product.badge}
            </span>
          )}
        </div>

        {/* Quick view button overlay on hover */}
        <div className="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onSelect(product);
            }}
            className="px-3.5 py-1.5 bg-white text-slate-900 text-xs font-semibold rounded-lg shadow-lg flex items-center gap-1.5 hover:bg-slate-50 transition-colors"
          >
            <Eye className="w-3.5 h-3.5 text-slate-600" />
            Ver Detalhes
          </button>
        </div>
      </div>

      {/* Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata: Category & Format (unboxed text with separator) */}
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1.5">
            <span className="font-medium text-emerald-700">
              {categoryLabels[product.category] || product.category}
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="font-mono text-[11px] text-slate-400">
              {product.sku}
            </span>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => onSelect(product)}
            className="text-sm font-semibold text-slate-900 line-clamp-1 hover:text-emerald-700 cursor-pointer transition-colors"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Short description */}
          <p className="mt-1 text-xs text-slate-500 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-bold font-mono tabular-nums text-slate-900">
                {product.price.toLocaleString('pt-MZ')} MT
              </span>
              {product.originalPrice && (
                <span className="text-xs text-slate-400 line-through font-mono tabular-nums">
                  {product.originalPrice.toLocaleString('pt-MZ')} MT
                </span>
              )}
            </div>
            <div className="text-[11px] text-emerald-600 font-medium">
              Taxa: Grátis (M-Pesa)
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => addToCart(product)}
              disabled={isOutOfStock}
              title={isOutOfStock ? 'Sem estoque' : 'Adicionar ao carrinho'}
              className="p-2 text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              aria-label="Adicionar ao carrinho"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>

            <button
              onClick={() => buyNow(product)}
              disabled={isOutOfStock}
              className="px-3 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg shadow-xs transition-colors flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            >
              <span>Comprar</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
