import React, { useState } from 'react';
import { Product, AppLanguage } from '../types';
import { formatPKR } from '../utils/storage';
import { Plus, Minus, Check, ImageOff, ShoppingBag, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  quantityInCart: number;
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onViewDetails: (product: Product) => void;
  language: AppLanguage;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  quantityInCart,
  onAddToCart,
  onUpdateQuantity,
  onViewDetails,
  language
}) => {
  const [imageError, setImageError] = useState(false);
  const isUrdu = language === 'ur';

  // Category badge styling
  const categoryLabels: Record<Product['category'], { ur: string; en: string; bg: string }> = {
    grocery: { ur: 'کریانہ', en: 'Grocery', bg: 'bg-emerald-100 text-emerald-800' },
    general: { ur: 'جنرل', en: 'General', bg: 'bg-blue-100 text-blue-800' },
    cosmetics: { ur: 'کاسمیٹکس', en: 'Cosmetics', bg: 'bg-pink-100 text-pink-800' },
    pansar: { ur: 'پنسار', en: 'Pansar', bg: 'bg-amber-100 text-amber-900' },
    books: { ur: 'بک ڈپو', en: 'Stationery', bg: 'bg-indigo-100 text-indigo-900' },
  };

  const catMeta = categoryLabels[product.category] || { ur: 'سامان', en: 'Item', bg: 'bg-slate-100 text-slate-800' };

  return (
    <div className={`group bg-white rounded-2xl border transition-all duration-200 overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md ${
      !product.inStock ? 'opacity-70 border-slate-200' : 'border-slate-200/90 hover:border-emerald-300'
    }`}>
      {/* Product Image & Badges */}
      <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
        {imageError ? (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-slate-400 p-4 text-center">
            <ImageOff className="w-8 h-8 mb-1 text-slate-300" />
            <span className="text-[11px] font-medium text-slate-500">
              {isUrdu ? product.urduName : product.name}
            </span>
          </div>
        ) : (
          <img
            src={product.image}
            alt={product.urduName || product.name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        )}

        {/* Top Floating Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs backdrop-blur-xs ${catMeta.bg}`}>
            {isUrdu ? catMeta.ur : catMeta.en}
          </span>
          {product.badge && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500 text-emerald-950 shadow-xs">
              {product.badge}
            </span>
          )}
        </div>

        {/* Stock Status Badge */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[1px] flex items-center justify-center p-2 z-10">
            <span className="bg-red-600 text-white font-bold text-xs px-2.5 py-1 rounded-md shadow-md">
              {isUrdu ? 'ختم ہے (Out of Stock)' : 'Out of Stock'}
            </span>
          </div>
        )}

        {/* Quick View Button Overlay */}
        <button
          onClick={() => onViewDetails(product)}
          className="absolute bottom-2 right-2 p-1.5 rounded-full bg-white/90 text-slate-700 hover:text-emerald-700 shadow-md backdrop-blur-xs transition active:scale-95 z-10"
          title="تفصیل دیکھیں / View Details"
        >
          <Eye className="w-4 h-4" />
        </button>
      </div>

      {/* Product Content */}
      <div className="p-3 flex-1 flex flex-col justify-between">
        <div>
          {/* Unit Tag */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
            <span className="bg-slate-100 text-slate-600 font-medium px-2 py-0.5 rounded-md text-[11px]">
              {product.unit}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-red-600 font-bold text-[10px]">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% {isUrdu ? 'رعایت' : 'OFF'}
              </span>
            )}
          </div>

          {/* Urdu / English Titles */}
          <button
            onClick={() => onViewDetails(product)}
            className="text-left w-full focus:outline-none"
          >
            <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug hover:text-emerald-700 transition line-clamp-2">
              {product.urduName}
            </h3>
            <p className="text-xs text-slate-500 font-medium truncate mt-0.5">
              {product.name}
            </p>
          </button>
        </div>

        {/* Price & Cart Actions */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
          {/* Price */}
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-black text-emerald-800 tracking-tight">
                {formatPKR(product.price, isUrdu)}
              </span>
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[11px] text-slate-400 line-through">
                {formatPKR(product.originalPrice, isUrdu)}
              </span>
            )}
          </div>

          {/* Add to Cart / Quantity Stepper */}
          {product.inStock ? (
            quantityInCart > 0 ? (
              <div className="flex items-center gap-1.5 bg-emerald-700 text-white rounded-xl p-1 shadow-sm">
                <button
                  onClick={() => onUpdateQuantity(product.id, quantityInCart - 1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-emerald-800 transition active:scale-95"
                  aria-label="کم کریں"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-5 text-center font-bold text-xs">
                  {quantityInCart}
                </span>
                <button
                  onClick={() => onUpdateQuantity(product.id, quantityInCart + 1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-emerald-800 transition active:scale-95"
                  aria-label="زیادہ کریں"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => onAddToCart(product)}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-2 rounded-xl shadow-xs transition transform active:scale-95"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{isUrdu ? 'شامل کریں' : 'Add'}</span>
              </button>
            )
          ) : (
            <button
              disabled
              className="bg-slate-100 text-slate-400 text-xs px-2.5 py-1.5 rounded-lg cursor-not-allowed font-medium"
            >
              {isUrdu ? 'دستیاب نہیں' : 'Unavailable'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
