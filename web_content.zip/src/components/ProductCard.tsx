import React, { useState } from 'react';
import { ShoppingBag, ArrowUpRight, ImageOff } from 'lucide-react';
import { Product } from '../types/store';
import { formatCurrency, getDiscountPercent, getEffectivePrice } from '../lib/formatters';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, size: string, color: string) => void;
  onBuyNow: (product: Product, size: string, color: string) => void;
}

export function ProductCard({
  product,
  onSelectProduct,
  onAddToCart,
  onBuyNow,
}: ProductCardProps) {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'M');
  const [imgFailed, setImgFailed] = useState(false);

  const effectivePrice = getEffectivePrice(product);
  const discountPct = getDiscountPercent(product.price, product.discountPrice);
  const defaultColor = product.colors[0] || 'Standard';
  const outOfStock = product.stock <= 0;

  return (
    <article className="group flex flex-col bg-white border border-neutral-200/80 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      {/* 3:4 Product Image Container */}
      <button
        type="button"
        onClick={() => onSelectProduct(product)}
        className="relative aspect-[3/4] w-full overflow-hidden bg-[#F6F6F6] text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0A0A0A]"
      >
        {!imgFailed && product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-neutral-100 to-neutral-200">
            <ImageOff className="w-7 h-7 text-neutral-400 mb-2" />
            <span className="text-xs font-medium text-neutral-500 line-clamp-2">
              {product.name}
            </span>
          </div>
        )}

        {outOfStock && (
          <div className="absolute inset-0 bg-white/65 backdrop-blur-[1px] flex items-center justify-center">
            <span className="px-4 py-1.5 bg-[#0A0A0A] text-white text-xs font-medium tracking-wider uppercase">
              Out of Stock
            </span>
          </div>
        )}
      </button>

      {/* Card Body */}
      <div className="p-5 flex flex-col flex-1">
        {/* Clean Unboxed Metadata */}
        <div className="flex items-center justify-between gap-2 text-[11px] uppercase tracking-wider text-neutral-500 mb-1.5">
          <span className="truncate">
            {product.category} <span aria-hidden="true">·</span> {product.gender}
          </span>
          {discountPct > 0 ? (
            <span className="text-[#0A0A0A] font-semibold tabular-nums shrink-0">
              {discountPct}% Off
            </span>
          ) : product.isNewArrival ? (
            <span className="text-[#0A0A0A] font-medium shrink-0">New</span>
          ) : null}
        </div>

        {/* Product Title */}
        <button
          type="button"
          onClick={() => onSelectProduct(product)}
          className="text-left group/title cursor-pointer mb-1.5"
        >
          <h3 className="text-[15px] font-semibold text-[#0A0A0A] leading-snug line-clamp-1 group-hover/title:underline">
            {product.name}
          </h3>
        </button>

        {/* Product Details Excerpt */}
        <p className="text-xs text-neutral-500 line-clamp-2 leading-relaxed mb-3">
          {product.description}
        </p>

        {/* Price Row */}
        <div className="flex items-baseline gap-2.5 mb-4 tabular-nums">
          <span className="text-base font-semibold text-[#0A0A0A]">
            {formatCurrency(effectivePrice)}
          </span>
          {discountPct > 0 && (
            <span className="text-xs text-neutral-400 line-through">
              {formatCurrency(product.price)}
            </span>
          )}
        </div>

        {/* Size Selector */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-[11px] text-neutral-500 mb-1.5">
            <span>Size</span>
            <span className="tabular-nums">
              {product.stock > 0 ? `${product.stock} in stock` : 'Sold out'}
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {product.sizes.map((size) => {
              const active = selectedSize === size;
              return (
                <button
                  key={size}
                  type="button"
                  onClick={() => setSelectedSize(size)}
                  className={`min-w-[34px] h-8 px-2 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                      : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400'
                  }`}
                >
                  {size}
                </button>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-auto pt-2 grid grid-cols-2 gap-2">
          <button
            type="button"
            disabled={outOfStock}
            onClick={() => onAddToCart(product, selectedSize, defaultColor)}
            className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-full border border-[#0A0A0A] text-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Add to Cart</span>
          </button>
          <button
            type="button"
            disabled={outOfStock}
            onClick={() => onBuyNow(product, selectedSize, defaultColor)}
            className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Buy Now</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
}
