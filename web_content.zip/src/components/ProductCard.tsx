"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import { formatBDT } from "@/lib/utils";

export interface ProductCardData {
  id: number;
  name: string;
  modelNumber: string;
  category: string;
  price: number;
  description: string;
  image: string;
  status: string;
  isFeatured: boolean;
  isBestSeller: boolean;
  isNewArrival: boolean;
}

export default function ProductCard({ product }: { product: ProductCardData }) {
  const { addToCart, toggleWishlist, wishlist } = useCart();
  const inWishlist = wishlist.includes(product.id);
  const available = product.status === "available";

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5 }}
      className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-xl transition-all duration-500 hover:-translate-y-2 hover:border-purple-400/50 hover:shadow-[0_0_40px_rgba(139,92,246,0.25)]"
    >
      {/* glow top line */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-purple-400/70 to-transparent opacity-0 transition group-hover:opacity-100" />

      <div className="relative m-3 overflow-hidden rounded-2xl bg-black/40">
        <div className="relative aspect-square">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 100vw, 33vw"
            className="object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
        </div>
        {/* badges */}
        <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
          {product.isNewArrival && (
            <span className="rounded-full bg-gradient-to-r from-purple-500 to-blue-500 px-2.5 py-1 text-[10px] font-bold text-white shadow-lg">
              NEW
            </span>
          )}
          {product.isBestSeller && (
            <span className="rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-2.5 py-1 text-[10px] font-bold text-black shadow-lg">
              BEST SELLER
            </span>
          )}
          {product.isFeatured && (
            <span className="rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold text-black shadow-lg">
              ★ FEATURED
            </span>
          )}
        </div>
        {/* wishlist */}
        <button
          onClick={() => toggleWishlist(product.id)}
          aria-label="Toggle wishlist"
          className={`absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full border backdrop-blur-md transition ${
            inWishlist
              ? "border-pink-400 bg-pink-500/90 text-white"
              : "border-white/20 bg-black/40 text-white hover:border-pink-400/60"
          }`}
        >
          <svg className="h-4 w-4" fill={inWishlist ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>
        {/* status */}
        <span
          className={`absolute bottom-3 left-3 rounded-full px-2.5 py-1 text-[10px] font-semibold ${
            product.status === "available"
              ? "bg-emerald-500/90 text-white"
              : product.status === "pre_order"
                ? "bg-amber-500/90 text-black"
                : "bg-red-500/90 text-white"
          }`}
        >
          {product.status === "available" ? "● Available" : product.status === "pre_order" ? "Pre-Order" : "Out of Stock"}
        </span>
      </div>

      <div className="p-4">
        <p className="text-[11px] font-semibold uppercase tracking-widest text-purple-400">{product.category}</p>
        <h3 className="mt-1 font-display text-lg font-bold text-white">{product.name}</h3>
        <p className="text-xs text-slate-500">Model: {product.modelNumber}</p>
        <p className="mt-2 line-clamp-2 text-sm text-slate-400">{product.description}</p>
        <div className="mt-4 flex items-end justify-between">
          <div>
            <p className="font-display text-xl font-black text-white">{formatBDT(product.price)}</p>
            <p className="text-[10px] text-slate-500">incl. VAT · BDT</p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <Link
            href={`/product/${product.id}`}
            className="rounded-xl border border-white/15 py-2.5 text-center text-sm font-semibold text-slate-200 transition hover:border-purple-400/60 hover:text-purple-300"
          >
            View Details
          </Link>
          <button
            onClick={() => addToCart({ productId: product.id, name: product.name, modelNumber: product.modelNumber, price: product.price, image: product.image })}
            disabled={!available}
            className={`rounded-xl py-2.5 text-sm font-bold transition ${
              available
                ? "bg-gradient-to-r from-purple-500 to-blue-600 text-white shadow-[0_0_18px_rgba(139,92,246,0.4)] hover:brightness-110"
                : "cursor-not-allowed bg-white/5 text-slate-500"
            }`}
          >
            {available ? "Order Now" : "Unavailable"}
          </button>
        </div>
      </div>
    </motion.div>
  );
}