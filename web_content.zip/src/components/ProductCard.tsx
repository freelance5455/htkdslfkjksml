import React from 'react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { ShoppingCart, MessageCircle, Eye, Check, Shield } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { language, t, addToCart, setIsCartOpen, setSelectedProductForModal } = useApp();

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setIsCartOpen(true);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <div
      onClick={() => setSelectedProductForModal(product)}
      className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 shadow-lg hover:shadow-blue-500/10 transition-all duration-300 flex flex-col overflow-hidden relative"
    >
      {/* Thumbnail Area with Badges */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-950">
        <img
          src={product.image}
          alt={product.name[language] || product.name.en}
          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60"></div>

        {/* Condition Badge */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.condition === 'refurbished' ? (
            <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-500/90 text-slate-950 shadow-sm backdrop-blur-sm">
              {t.productCard.refurbishedBadge}
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-blue-600 text-white shadow-sm backdrop-blur-sm">
              {t.productCard.newBadge}
            </span>
          )}

          {discountPercent > 0 && (
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-600 text-white shadow-sm">
              {discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Stock status indicator */}
        <div className="absolute top-3 right-3">
          {product.inStock ? (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 backdrop-blur-sm">
              ● {t.productCard.inStock}
            </span>
          ) : (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-950/80 text-red-400 border border-red-500/40 backdrop-blur-sm">
              ● {t.productCard.outOfStock}
            </span>
          )}
        </div>

        {/* Brand label */}
        <div className="absolute bottom-2.5 left-3">
          <span className="text-[11px] font-semibold text-slate-300 bg-slate-900/80 px-2 py-0.5 rounded backdrop-blur-sm">
            {product.brand}
          </span>
        </div>
      </div>

      {/* Details Area */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <h3 className="font-bold text-white text-sm sm:text-base group-hover:text-blue-400 transition line-clamp-2 leading-snug">
            {product.name[language] || product.name.en}
          </h3>

          {/* Quick Specifications list */}
          <ul className="mt-2.5 space-y-1 text-xs text-slate-400">
            {(product.specs[language] || product.specs.en).slice(0, 3).map((spec, i) => (
              <li key={i} className="flex items-start gap-1.5 truncate">
                <span className="text-blue-400 font-bold">•</span>
                <span className="truncate">{spec}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Pricing and Action Buttons */}
        <div className="pt-3 border-t border-slate-800/80">
          <div className="flex items-baseline justify-between mb-3">
            <div>
              <span className="text-xs text-slate-400 font-medium mr-1.5">
                {language === 'hi' ? 'कीमत:' : 'Price:'}
              </span>
              <span className="text-lg sm:text-xl font-extrabold text-white">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
            </div>
            {product.originalPrice > product.price && (
              <div className="text-xs text-slate-500 line-through">
                MRP ₹{product.originalPrice.toLocaleString('en-IN')}
              </div>
            )}
          </div>

          {/* Dual Action Buttons: Add to Bag & Buy via WhatsApp */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-semibold border border-slate-700 transition flex items-center justify-center gap-1.5"
            >
              <ShoppingCart className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.productCard.addToCart}</span>
            </button>

            <button
              onClick={handleBuyNow}
              disabled={!product.inStock}
              className="py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-blue-600/20 transition flex items-center justify-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>{t.productCard.buyNow}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
