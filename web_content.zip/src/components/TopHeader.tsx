import React from "react";
import { Settings, Sparkles, Download, CheckCircle2, AlertCircle, RefreshCw } from "lucide-react";
import { BackendStatus } from "../types";

interface TopHeaderProps {
  status: BackendStatus;
  onOpenSettings: () => void;
  onRefreshHealth: () => void;
  canInstall?: boolean;
  onInstallApp?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  status,
  onOpenSettings,
  onRefreshHealth,
  canInstall,
  onInstallApp,
}) => {
  return (
    <header
      id="app-top-header"
      className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3"
    >
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {/* Logo & Name */}
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-pink-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-1.5 leading-tight">
              VEW AI Studio
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-medium uppercase border border-blue-500/30">
                PRO
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 leading-tight">Mobile AI Workspace</p>
          </div>
        </div>

        {/* Status indicator & Actions */}
        <div className="flex items-center space-x-2">
          {/* Real Backend Status indicator (Section 24) */}
          <button
            id="header-backend-status-btn"
            onClick={onRefreshHealth}
            title={`Status: ${status.statusText}. Click to check connection.`}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800/90 border border-slate-700/80 hover:bg-slate-700/90 transition-colors"
          >
            {status.checking ? (
              <>
                <RefreshCw className="w-3 h-3 text-amber-400 animate-spin" />
                <span className="text-amber-300 text-[11px] hidden xs:inline">Checking</span>
              </>
            ) : status.connected ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <span className="text-emerald-300 text-[11px] hidden xs:inline">Connected</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.8)]" />
                <span className="text-rose-300 text-[11px] hidden xs:inline">Offline</span>
              </>
            )}
          </button>

          {/* Android PWA Install App Button */}
          {canInstall && onInstallApp && (
            <button
              id="install-pwa-btn"
              onClick={onInstallApp}
              className="flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/20 hover:from-blue-500 hover:to-indigo-500 transition-all active:scale-95"
            >
              <Download className="w-3 h-3" />
              <span className="text-[11px]">Install</span>
            </button>
          )}

          {/* Settings icon */}
          <button
            id="header-settings-btn"
            onClick={onOpenSettings}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
