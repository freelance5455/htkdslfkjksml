import React, { useState, useEffect } from 'react';
import { X, Plus, Package, Layers, Image as ImageIcon, Save, Trash2 } from 'lucide-react';
import { Product, ProductCategory, ProductType } from '../types';
import { useStore } from '../context/StoreContext';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
}

export const AddProductModal: React.FC<AddProductModalProps> = ({ 
  isOpen, 
  onClose, 
  productToEdit 
}) => {
  const { addProduct, updateProduct, deleteProduct } = useStore();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<number>(350);
  const [originalPrice, setOriginalPrice] = useState<number>(500);
  const [category, setCategory] = useState<ProductCategory>('ebooks');
  const [type, setType] = useState<ProductType>('digital');
  const [stock, setStock] = useState<number>(20);
  const [minStockAlert, setMinStockAlert] = useState<number>(5);
  const [sku, setSku] = useState('');
  const [image, setImage] = useState('');
  const [badge, setBadge] = useState('');
  const [weightOrFormat, setWeightOrFormat] = useState('PDF + Mockup 3D');
  const [featuresText, setFeaturesText] = useState('Download imediato\nAcesso vitalício\nSuporte por WhatsApp');

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name);
      setDescription(productToEdit.description);
      setPrice(productToEdit.price);
      setOriginalPrice(productToEdit.originalPrice || productToEdit.price * 1.4);
      setCategory(productToEdit.category);
      setType(productToEdit.type);
      setStock(productToEdit.stock);
      setMinStockAlert(productToEdit.minStockAlert);
      setSku(productToEdit.sku);
      setImage(productToEdit.image);
      setBadge(productToEdit.badge || '');
      setWeightOrFormat(productToEdit.weightOrFormat || '');
      setFeaturesText(productToEdit.features.join('\n'));
    } else {
      // Defaults for new product
      setName('');
      setDescription('');
      setPrice(350);
      setOriginalPrice(500);
      setCategory('ebooks');
      setType('digital');
      setStock(25);
      setMinStockAlert(5);
      setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
      setImage('https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80');
      setBadge('Novo');
      setWeightOrFormat('Ficheiro Digital PDF');
      setFeaturesText('Acesso imediato após confirmação\nCompatível com telemóvel e PC\nSuporte incluído');
    }
  }, [productToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const featuresArray = featuresText
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean);

    if (productToEdit) {
      const updated: Product = {
        ...productToEdit,
        name,
        description,
        price,
        originalPrice,
        category,
        type,
        stock,
        minStockAlert,
        sku,
        image: image || productToEdit.image,
        badge,
        weightOrFormat,
        features: featuresArray.length > 0 ? featuresArray : productToEdit.features
      };
      updateProduct(updated);
    } else {
      addProduct({
        name,
        slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        description,
        price,
        originalPrice,
        category,
        type,
        stock,
        minStockAlert,
        sku: sku || `SKU-${Date.now().toString().slice(-4)}`,
        image: image || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80',
        badge,
        weightOrFormat,
        features: featuresArray,
        digitalContentUrl: type === 'digital' ? 'https://escalepay.com/downloads/sample-product.pdf' : undefined
      });
    }

    onClose();
  };

  const handleDelete = () => {
    if (!productToEdit) return;
    if (confirm(`Tem a certeza que deseja remover "${productToEdit.name}" do catálogo e estoque?`)) {
      deleteProduct(productToEdit.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">
              {productToEdit ? 'Editar Produto e Estoque' : 'Cadastrar Novo Produto'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Name */}
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Nome do Produto <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Livro Digital: Guia de Investimentos em Moçambique"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Categoria
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ebooks">eBooks & Capas</option>
                <option value="spreadsheets">Planilhas Excel</option>
                <option value="covers3d">Capas 3D & Mockups</option>
                <option value="ads_banners">Anúncios & Banners</option>
                <option value="courses_vsl">Cursos & VSL</option>
                <option value="physical">Produto Físico</option>
              </select>
            </div>

            {/* Type */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Tipo de Entrega
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as ProductType)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="digital">Digital (Download Instantâneo)</option>
                <option value="physical">Físico (Envio / Entrega Postal)</option>
              </select>
            </div>

            {/* Price (MZN) */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Preço de Venda (MT) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="10"
                required
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>

            {/* Original Price */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Preço Anterior / Riscado (MT)
              </label>
              <input
                type="number"
                min="0"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>

            {/* Initial Stock */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Estoque Inicial (Unidades) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                required
                value={stock}
                onChange={(e) => setStock(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>

            {/* Min Stock Alert */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Alerta de Estoque Baixo (Limiar)
              </label>
              <input
                type="number"
                min="1"
                value={minStockAlert}
                onChange={(e) => setMinStockAlert(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>

            {/* SKU */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Código SKU / Referência
              </label>
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="Ex: EB-MZ-09"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
              />
            </div>

            {/* Badge */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Selo Promocional (Opcional)
              </label>
              <input
                type="text"
                value={badge}
                onChange={(e) => setBadge(e.target.value)}
                placeholder="Ex: Mais Vendido, Lançamento"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            {/* Image URL */}
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                URL da Capa ou Foto do Produto
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  placeholder="https://..."
                  className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-[11px]"
                />
              </div>
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Descrição Detalhada
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descreva o que o comprador vai receber e os benefícios do produto..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            {/* Features (one per line) */}
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Benefícios e Itens Inclusos (um por linha)
              </label>
              <textarea
                rows={3}
                value={featuresText}
                onChange={(e) => setFeaturesText(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-[11px]"
              />
            </div>

          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            {productToEdit ? (
              <button
                type="button"
                onClick={handleDelete}
                className="px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-lg font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Excluir Produto</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{productToEdit ? 'Salvar Alterações' : 'Cadastrar no Estoque'}</span>
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
