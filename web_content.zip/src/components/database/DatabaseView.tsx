// PostgreSQL Database & System Architecture Inspector
import React, { useState } from 'react';
import { dbStore } from '../../server/services/dbStore';
import {
  Database,
  FileCode2,
  Table,
  Layers,
  ShieldCheck,
  Server,
  Download,
  Copy,
  Check,
} from 'lucide-react';

export const DatabaseView: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'schema' | 'migration' | 'seed' | 'docker'>('schema');
  const [copied, setCopied] = useState(false);

  const branches = dbStore.getBranches();
  const products = dbStore.getProducts();
  const suppliers = dbStore.getSuppliers();
  const customers = dbStore.getCustomers();
  const inventory = dbStore.getInventory();
  const sales = dbStore.getSales();
  const movements = dbStore.getStockMovements();

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const schemaSnippet = `// Production PostgreSQL Supermarket Schema
// Prisma ORM Definition

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id             String         @id @default(uuid()) @db.Uuid
  email          String         @unique @db.VarChar(255)
  username       String         @unique @db.VarChar(100)
  passwordHash   String         @db.VarChar(255)
  name           String         @db.VarChar(255)
  role           RoleType       @default(CASHIER)
  branchId       String         @db.Uuid
  active         Boolean        @default(true)
  failedAttempts Int            @default(0)
  lockedUntil    DateTime?
  sales          Sale[]
  stockMovements StockMovement[]
  createdAt      DateTime       @default(now())
}

model Product {
  id             String          @id @default(uuid()) @db.Uuid
  sku            String          @unique @db.VarChar(100)
  barcode        String          @unique @db.VarChar(100)
  name           String          @db.VarChar(255)
  costPrice      Decimal         @db.Decimal(12, 2)
  sellingPrice   Decimal         @db.Decimal(12, 2)
  taxRate        Decimal         @default(15.00) @db.Decimal(5, 2)
  unit           String          @default("pcs") @db.VarChar(50)
  minStockLevel  Int             @default(10)
  reorderLevel   Int             @default(20)
  inventory      InventoryItem[]
  saleItems      SaleItem[]
}

model Sale {
  id             String       @id @default(uuid()) @db.Uuid
  receiptNumber  String       @unique @db.VarChar(100)
  subtotal       Decimal      @db.Decimal(12, 2)
  taxTotal       Decimal      @db.Decimal(12, 2)
  grandTotal     Decimal      @db.Decimal(12, 2)
  paymentMethod  PaymentMethod
  items          SaleItem[]
  createdAt      DateTime     @default(now())
}`;

  const migrationSnippet = `-- Production PostgreSQL Migration 0_init
-- Migration: 0_init/migration.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TYPE "RoleType" AS ENUM ('SUPER_ADMIN', 'MANAGER', 'CASHIER', 'INVENTORY_MANAGER', 'ACCOUNTANT');
CREATE TYPE "MovementType" AS ENUM ('PURCHASE', 'SALE', 'SALE_RETURN', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT', 'DAMAGE', 'EXPIRY', 'TRANSFER_IN', 'TRANSFER_OUT', 'OPENING_BALANCE');
CREATE TYPE "PaymentMethod" AS ENUM ('CASH', 'CARD', 'MOBILE_PAYMENT', 'BANK_TRANSFER', 'STORE_CREDIT');

CREATE TABLE "branches" (
    "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "address" TEXT NOT NULL,
    "is_main" BOOLEAN DEFAULT false,
    "active" BOOLEAN DEFAULT true
);

CREATE TABLE "products" (
    "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    "sku" VARCHAR(100) UNIQUE NOT NULL,
    "barcode" VARCHAR(100) UNIQUE NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "cost_price" NUMERIC(12, 2) NOT NULL,
    "selling_price" NUMERIC(12, 2) NOT NULL,
    "tax_rate" NUMERIC(5, 2) DEFAULT 15.00 NOT NULL,
    "unit" VARCHAR(50) DEFAULT 'pcs' NOT NULL,
    "reorder_level" INTEGER DEFAULT 20 NOT NULL
);

CREATE TABLE "inventory" (
    "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    "product_id" UUID REFERENCES "products"("id") ON DELETE CASCADE,
    "branch_id" UUID REFERENCES "branches"("id") ON DELETE CASCADE,
    "quantity" INTEGER DEFAULT 0 NOT NULL,
    CONSTRAINT "uniq_prod_branch" UNIQUE ("product_id", "branch_id")
);`;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-emerald-400" />
              <h1 className="text-xl font-bold text-slate-100">Authoritative PostgreSQL Architecture & Data</h1>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Milestone 1 Verified
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Production schema definitions, migrations, initial seed counts, and dual-sync Firestore rules.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-xs text-slate-300 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              PostgreSQL 16 + Firestore Dual-Sync
            </span>
          </div>
        </div>
      </div>

      {/* Database Live Record Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Branches</div>
          <div className="text-xl font-bold text-slate-100 font-mono mt-1">{branches.length}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Catalog Products</div>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1">{products.length}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Suppliers</div>
          <div className="text-xl font-bold text-slate-100 font-mono mt-1">{suppliers.length}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Customers</div>
          <div className="text-xl font-bold text-slate-100 font-mono mt-1">{customers.length}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Stock Records</div>
          <div className="text-xl font-bold text-cyan-400 font-mono mt-1">{inventory.length}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <div className="text-[11px] text-slate-400 font-medium">Completed Sales</div>
          <div className="text-xl font-bold text-amber-400 font-mono mt-1">{sales.length}</div>
        </div>
      </div>

      {/* Technical Code Inspector Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 px-4 pt-3 bg-slate-950/70">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveSubTab('schema')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors flex items-center gap-2 ${
                activeSubTab === 'schema'
                  ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              prisma/schema.prisma
            </button>
            <button
              onClick={() => setActiveSubTab('migration')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors flex items-center gap-2 ${
                activeSubTab === 'migration'
                  ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              0_init/migration.sql
            </button>
            <button
              onClick={() => setActiveSubTab('docker')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors flex items-center gap-2 ${
                activeSubTab === 'docker'
                  ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              docker-compose.yml
            </button>
          </div>

          <button
            onClick={() => handleCopy(activeSubTab === 'schema' ? schemaSnippet : migrationSnippet)}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded bg-slate-800 border border-slate-700 mb-1"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto max-h-[500px]">
          {activeSubTab === 'schema' && <pre>{schemaSnippet}</pre>}
          {activeSubTab === 'migration' && <pre>{migrationSnippet}</pre>}
          {activeSubTab === 'docker' && (
            <pre>{`services:
  postgres:
    image: postgres:16-alpine
    container_name: supermarket_db
    restart: always
    environment:
      POSTGRES_USER: \${POSTGRES_USER:-supermarket_admin}
      POSTGRES_PASSWORD: \${POSTGRES_PASSWORD:-SuperSecurePass2026!}
      POSTGRES_DB: \${POSTGRES_DB:-supermarket_pos}
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: "postgresql://supermarket_admin:SuperSecurePass2026!@postgres:5432/supermarket_pos"
    depends_on:
      - postgres

volumes:
  pgdata:`}</pre>
          )}
        </div>
      </div>
    </div>
  );
};
