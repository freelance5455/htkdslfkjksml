import React, { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Shield,
  Lock,
  Unlock,
  Key,
  HelpCircle,
  AlertTriangle,
  Eye,
  EyeOff,
  RefreshCw,
  Fingerprint,
  RotateCw,
  Plus,
  Trash2,
  FileText,
  Clock,
  ArrowLeft,
  X,
  Search,
  CheckCircle,
  Download,
  Copy,
  Sliders,
  Check,
  Sparkles,
  Zap,
  Layers,
  ArrowRight,
  Database,
  ExternalLink,
  Info,
  Delete,
  Keyboard,
  Smartphone,
  LayoutGrid,
  List,
  ArrowUpDown,
  Pin,
  Maximize2,
  ChevronDown,
  ChevronUp,
  BookOpen,
  Tag,
  Filter,
  Calendar
} from "lucide-react";
import { Note, VaultMetadata, ThemeAccent } from "../types";
import {
  initializeVault,
  unlockVault,
  unlockVaultWithSecurityAnswer,
  unlockVaultWithMnemonic,
  unlockVaultWithEmergencyHexKey,
  resetVaultPinWithSecurityAnswer,
  resetVaultPinWithRawKey,
  saveVaultPayload,
  changeVaultPin,
  detectSensitiveDataInNote,
  SensitiveDetectionResult,
  bytesToHex,
  rawKeyToMnemonic
} from "../utils/crypto";

export function resolveReadableNoteContent(rawContent: string | undefined): string {
  if (!rawContent) return "";
  let text = rawContent.trim();

  // Try JSON parse (ColorNote backup notes or object dumps)
  if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
    try {
      const parsed = JSON.parse(text);
      if (typeof parsed === "object" && parsed !== null) {
        const extracted = parsed.note || parsed.content || parsed.text || parsed._body || parsed.body || parsed.message || parsed.memo;
        if (typeof extracted === "string" && extracted.trim()) {
          text = extracted;
        } else if (Array.isArray(parsed)) {
          text = parsed.map((item) => (typeof item === "object" ? (item.note || item.content || item.text || JSON.stringify(item)) : String(item))).join("\n\n");
        } else {
          text = Object.entries(parsed)
            .map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : v}`)
            .join("\n");
        }
      }
    } catch {}
  }

  // Try Base64 decode
  if (/^[A-Za-z0-9+/=]+$/.test(text) && text.length > 8 && text.length % 4 === 0) {
    try {
      const decoded = atob(text);
      if (/^[\x20-\x7E\u00A0-\uFFFF\r\n\t]+$/.test(decoded)) {
        text = decoded;
        if (text.startsWith("{") && text.endsWith("}")) {
          try {
            const nested = JSON.parse(text);
            const nestedExt = nested.note || nested.content || nested.text || nested._body || nested.body;
            if (typeof nestedExt === "string" && nestedExt.trim()) {
              text = nestedExt;
            }
          } catch {}
        }
      }
    } catch {}
  }

  // Clean HTML entities
  text = text
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/<br\s*[\/]?>/gi, "\n");

  return text;
}

interface VaultViewProps {
  vaultRecord: VaultMetadata | null;
  setVaultRecord: (record: VaultMetadata | null) => void;
  isVaultUnlocked: boolean;
  setIsVaultUnlocked: (unlocked: boolean) => void;
  rawVaultKey: Uint8Array | null;
  setRawVaultKey: (key: Uint8Array | null) => void;
  vaultNotes: Note[];
  setVaultNotes: (notes: Note[]) => void;
  themeAccent: ThemeAccent;
  workspaceNotes?: Note[];
  onMigrateNotesToVault?: (notesToMigrate: Note[]) => Promise<void>;
  onClose: () => void;
}

// Biometric State
type BiometricState = "idle" | "scanning" | "success" | "failed";

// Decoy Mock Notes
const DECOY_NOTES: Note[] = [
  {
    id: "decoy-1",
    title: "Haftalık Market Listesi",
    content: "Organik süt, 2 koli yumurta, sızma zeytinyağı, tam buğday ekmeği, maden suyu, yeşil elma, kahve çekirdeği.",
    category: "Kişisel",
    tags: ["#alışveriş", "#market"],
    pinned: true,
    favorite: false,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "decoy-2",
    title: "Ev Düzenleme & Temizlik Rutini",
    content: "Pazartesi: Çalışma masası düzeni\nÇarşamba: Kitaplık ve salon toz alımı\nCuma: Balkon ve çiçek bakımı\nPazar: Genel temizlik.",
    category: "Kişisel",
    tags: ["#düzen", "#ev"],
    pinned: false,
    favorite: false,
    createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "decoy-3",
    title: "İzlenecek Başyapıt Filmler",
    content: "1. 12 Angry Men (1957)\n2. Rear Window (1954)\n3. Interstellar (2014)\n4. The Grand Budapest Hotel (2014)",
    category: "Fikirler",
    tags: ["#sinema", "#favoriler"],
    pinned: false,
    favorite: true,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
  }
];

export const VaultView: React.FC<VaultViewProps> = ({
  vaultRecord,
  setVaultRecord,
  isVaultUnlocked,
  setIsVaultUnlocked,
  rawVaultKey,
  setRawVaultKey,
  vaultNotes,
  setVaultNotes,
  themeAccent,
  workspaceNotes = [],
  onMigrateNotesToVault,
  onClose,
}) => {
  // Navigation & View Mode inside Vault
  const [activeSubTab, setActiveSubTab] = useState<"notes" | "migrate" | "settings">("notes");
  const [pin, setPin] = useState("");
  const [isDecoyVault, setIsDecoyVault] = useState(false);
  const [decoyNotesState, setDecoyNotesState] = useState<Note[]>(() => {
    const saved = localStorage.getItem("noteflow_decoy_notes");
    return saved ? JSON.parse(saved) : DECOY_NOTES;
  });

  // Setup Wizard State
  const [isSettingUp, setIsSettingUp] = useState<boolean>(() => !vaultRecord);
  const tempVaultRecordRef = useRef<VaultMetadata | null>(null);
  const tempRawKeyRef = useRef<Uint8Array | null>(null);
  const [setupPin, setSetupPin] = useState("");
  const [setupPinConfirm, setSetupPinConfirm] = useState("");
  const [showSetupPin, setShowSetupPin] = useState(false);
  const [showSetupPinConfirm, setShowSetupPinConfirm] = useState(false);
  const [decoyPin, setDecoyPin] = useState("");
  const [showDecoyPin, setShowDecoyPin] = useState(false);
  const [pinTypeMode, setPinTypeMode] = useState<"numeric" | "alphanumeric">("numeric");
  const [securityQuestion, setSecurityQuestion] = useState("İlk evcil hayvanınızın adı nedir?");
  const [customQuestionText, setCustomQuestionText] = useState("");
  const [securityAnswer, setSecurityAnswer] = useState("");
  const [showSecurityAnswer, setShowSecurityAnswer] = useState(false);
  const [hint, setHint] = useState("");
  const [setupStep, setSetupStep] = useState<1 | 2 | 3>(1); // 1: PINs, 2: QA & Hint, 3: Master Emergency Kit Backup
  const [setupError, setSetupError] = useState<string | null>(null);
  const [generatedMnemonic, setGeneratedMnemonic] = useState<string>("");
  const [generatedHexKey, setGeneratedHexKey] = useState<string>("");
  const [copiedKit, setCopiedKit] = useState(false);
  const [hasConfirmedBackup, setHasConfirmedBackup] = useState(false);

  // Genius Forgot Password / Recovery Suite State
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryMethod, setRecoveryMethod] = useState<"question" | "mnemonic" | "hex" | "hint">("question");
  const [recoveryAnswer, setRecoveryAnswer] = useState("");
  const [recoveryMnemonicInput, setRecoveryMnemonicInput] = useState("");
  const [recoveryHexInput, setRecoveryHexInput] = useState("");
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const [recoverySuccessKey, setRecoverySuccessKey] = useState<Uint8Array | null>(null);
  const [newRecoveryPin, setNewRecoveryPin] = useState("");
  const [newRecoveryPinConfirm, setNewRecoveryPinConfirm] = useState("");

  // Vault Settings / Customizer State
  const [currentChangePin, setCurrentChangePin] = useState("");
  const [newChangePin, setNewChangePin] = useState("");
  const [newChangePinConfirm, setNewChangePinConfirm] = useState("");
  const [changePinError, setChangePinError] = useState<string | null>(null);
  const [changePinSuccess, setChangePinSuccess] = useState<string | null>(null);
  const [customDecoyPin, setCustomDecoyPin] = useState(localStorage.getItem("noteflow_decoy_pin") || "9999");
  const [autoLockSetting, setAutoLockSetting] = useState<number>(vaultRecord?.autoLockTimeout ?? 0);
  const [showEmergencyKitModal, setShowEmergencyKitModal] = useState(false);

  // Auto-Migrate Scanner State
  const [isMigratingLoading, setIsMigratingLoading] = useState(false);
  const [selectedMigrateIds, setSelectedMigrateIds] = useState<string[]>([]);
  const [migrationSummary, setMigrationSummary] = useState<string | null>(null);

  // Note Editor State inside Vault
  const [editingVaultNote, setEditingVaultNote] = useState<Note | null>(null);
  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [noteCategory, setNoteCategory] = useState("Şifreler");
  const [isNoteEditorOpen, setIsNoteEditorOpen] = useState(false);
  const [showMaskedContent, setShowMaskedContent] = useState(true);

  // General UI States
  const [unlockError, setUnlockError] = useState<string | null>(null);
  const [biometric, setBiometric] = useState<BiometricState>("idle");
  const [searchQuery, setSearchQuery] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const [realNotes, setRealNotes] = useState<Note[]>(vaultNotes);

  // Vault Note Sorting & Listing States
  const [vaultSortOption, setVaultSortOption] = useState<
    "newest" | "oldest" | "title-asc" | "title-desc" | "pinned" | "length"
  >("newest");
  const [vaultLayoutMode, setVaultLayoutMode] = useState<"grid" | "list">("grid");
  const [selectedVaultCategory, setSelectedVaultCategory] = useState<string>("all");
  const [expandedNoteIds, setExpandedNoteIds] = useState<Set<string>>(new Set());
  const [expandAllNotes, setExpandAllNotes] = useState<boolean>(false);
  const [previewingVaultNote, setPreviewingVaultNote] = useState<Note | null>(null);
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);

  // Android & Mobile PIN Keypad Experience States
  const [pinInputMode, setPinInputMode] = useState<"keypad" | "keyboard">("keypad");
  const [isPinVisible, setIsPinVisible] = useState(false);
  const [isShaking, setIsShaking] = useState(false);

  const decoyPinRef = useRef<string>(localStorage.getItem("noteflow_decoy_pin") || "9999");

  // Synchronize realNotes with vaultNotes prop and resolve encrypted/BIN/ColorNote content
  useEffect(() => {
    const resolved = vaultNotes.map((n) => ({
      ...n,
      content: resolveReadableNoteContent(n.content),
    }));
    setRealNotes(resolved);
  }, [vaultNotes]);

  // Decoy pin fallback setup
  useEffect(() => {
    if (!localStorage.getItem("noteflow_decoy_pin")) {
      localStorage.setItem("noteflow_decoy_pin", "9999");
    }
  }, []);

  const saveDecoyNotes = (notes: Note[]) => {
    setDecoyNotesState(notes);
    localStorage.setItem("noteflow_decoy_notes", JSON.stringify(notes));
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  const triggerHaptic = (duration = 15) => {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(duration);
      } catch (e) {}
    }
  };

  // Multi-layered Auto-Lock: Tab Blur, App Switch (visibilitychange), and Page Hide
  useEffect(() => {
    const handleLock = () => {
      if (isVaultUnlocked) {
        handleLockVault();
        showToast("🔒 Güvenlik Panik Kilidi: Kasa otomatik olarak güvenle kilitlendi.");
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden" && isVaultUnlocked) {
        handleLock();
      }
    };

    window.addEventListener("blur", handleLock);
    window.addEventListener("pagehide", handleLock);
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      window.removeEventListener("blur", handleLock);
      window.removeEventListener("pagehide", handleLock);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [isVaultUnlocked]);

  // Inactivity Auto-Lock Timer
  useEffect(() => {
    if (!isVaultUnlocked || !autoLockSetting || autoLockSetting <= 0) return;

    let timeoutId: any;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleLockVault();
        showToast("⏳ Zaman Aşımı: Kasa hareketsizlik nedeniyle otomatik kilitlendi.");
      }, autoLockSetting * 1000);
    };

    resetTimer();
    const events = ["mousedown", "mousemove", "keydown", "touchstart", "scroll", "click"];
    events.forEach((evt) => window.addEventListener(evt, resetTimer, { passive: true }));

    return () => {
      clearTimeout(timeoutId);
      events.forEach((evt) => window.removeEventListener(evt, resetTimer));
    };
  }, [isVaultUnlocked, autoLockSetting]);

  // Cihaz Sallama ile Panik Kilidi (Shake Sensor)
  useEffect(() => {
    let lastX: number | null = null;
    let lastY: number | null = null;
    let lastZ: number | null = null;
    const threshold = 16;

    const handleMotion = (event: DeviceMotionEvent) => {
      if (!isVaultUnlocked) return;
      const acc = event.accelerationIncludingGravity;
      if (!acc || acc.x === null || acc.y === null || acc.z === null) return;

      if (lastX !== null && lastY !== null && lastZ !== null) {
        const deltaX = Math.abs(acc.x - lastX);
        const deltaY = Math.abs(acc.y - lastY);
        const deltaZ = Math.abs(acc.z - lastZ);

        if ((deltaX > threshold && deltaY > threshold) || (deltaX > threshold && deltaZ > threshold) || (deltaY > threshold && deltaZ > threshold)) {
          handleLockVault();
          showToast("📳 Panik Sallama Algılandı: Kasa anında güvenle kilitlendi!");
        }
      }
      lastX = acc.x;
      lastY = acc.y;
      lastZ = acc.z;
    };

    window.addEventListener("devicemotion", handleMotion);
    return () => window.removeEventListener("devicemotion", handleMotion);
  }, [isVaultUnlocked]);

  const handleLockVault = () => {
    setIsVaultUnlocked(false);
    setRawVaultKey(null);
    setVaultNotes([]);
    setPin("");
    setIsDecoyVault(false);
    setSearchQuery("");
    setShowRecovery(false);
    setRecoverySuccessKey(null);
  };

  // Execute Unlock
  const executeUnlock = async (pinToTest: string) => {
    setUnlockError(null);

    if (!vaultRecord) {
      setUnlockError("Kasa henüz kurulmadı.");
      return;
    }

    try {
      const currentDecoy = decoyPinRef.current || "9999";
      if (pinToTest === currentDecoy) {
        setIsDecoyVault(true);
        setIsVaultUnlocked(true);
        triggerHaptic(20);
        showToast("⚠️ Sahte Kasa (Decoy Mode) Açıldı!");
        return;
      }

      const { notes, rawKey } = await unlockVault(vaultRecord, pinToTest);
      setRawVaultKey(rawKey);
      setVaultNotes(notes);
      setRealNotes(notes);
      setIsVaultUnlocked(true);
      setIsDecoyVault(false);
      localStorage.setItem("noteflow_vault_cached_pin", pinToTest);
      triggerHaptic(35);
      showToast("🔑 Kasa Açıldı: Askeri Düzey AES-256 Şifreleme Aktif.");
    } catch (err: any) {
      setUnlockError("Hatalı PIN Kodu! Lütfen tekrar deneyin.");
      setIsShaking(true);
      triggerHaptic(60);
      setTimeout(() => setIsShaking(false), 500);
      setPin("");
    }
  };

  // Mobile Keypad Handlers
  const handleKeypadPress = (digit: string) => {
    triggerHaptic(12);
    if (pin.length < 8) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setUnlockError(null);
      // Auto-unlock check if pin reaches 4 digits and matches
      if (nextPin.length === 4) {
        const currentDecoy = decoyPinRef.current || "9999";
        if (nextPin === currentDecoy) {
          executeUnlock(nextPin);
        }
      }
    }
  };

  const handleKeypadBackspace = () => {
    triggerHaptic(15);
    setPin((prev) => prev.slice(0, -1));
    setUnlockError(null);
  };

  const handleKeypadClear = () => {
    triggerHaptic(20);
    setPin("");
    setUnlockError(null);
  };

  // Biyometrik Giriş Simülasyonu
  const handleBiometricAuth = () => {
    if (biometric === "scanning") return;
    setBiometric("scanning");
    triggerHaptic(20);

    setTimeout(() => {
      if (!vaultRecord) {
        setBiometric("failed");
        setUnlockError("Lütfen önce kasanızı kurun.");
        setTimeout(() => setBiometric("idle"), 2000);
        return;
      }

      const cachedPin = localStorage.getItem("noteflow_vault_cached_pin");
      if (cachedPin) {
        unlockVault(vaultRecord, cachedPin)
          .then(({ notes, rawKey }) => {
            setBiometric("success");
            setRawVaultKey(rawKey);
            setVaultNotes(notes);
            setRealNotes(notes);
            setIsDecoyVault(false);
            triggerHaptic(40);
            setTimeout(() => {
              setIsVaultUnlocked(true);
              setBiometric("idle");
              showToast("✓ Parmak İzi / Biyometrik anahtarla kilit açıldı!");
            }, 400);
          })
          .catch(() => {
            setBiometric("failed");
            setUnlockError("Biyometrik oturum zaman aşımına uğradı. Lütfen PIN girin.");
            triggerHaptic(80);
            setTimeout(() => setBiometric("idle"), 2500);
          });
      } else {
        setBiometric("failed");
        setUnlockError("Biyometrik doğrulamayı etkinleştirmek için ilk girişi PIN ile yapın.");
        triggerHaptic(80);
        setTimeout(() => setBiometric("idle"), 2500);
      }
    }, 1100);
  };

  // PIN ile Giriş Form Gönderimi
  const handleUnlockWithPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin) return;
    executeUnlock(pin);
  };

  // Kasa Kurulumu ve Kayıt İşlemleri
  const handleSetupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError(null);

    if (setupStep === 1) {
      if (setupPin.trim().length < 4) {
        setSetupError("Güvenliğiniz için şifreniz en az 4 karakter olmalıdır.");
        return;
      }
      if (setupPin !== setupPinConfirm) {
        setSetupError("Girdiğiniz şifreler uyuşmuyor! Lütfen kontrol edin.");
        return;
      }
      if (decoyPin && decoyPin.trim() === setupPin.trim()) {
        setSetupError("Tuzak (Decoy) şifre, asıl kasa şifresi ile aynı olamaz!");
        return;
      }
      setSetupStep(2);
    } else if (setupStep === 2) {
      const finalQuestion = securityQuestion === "custom" ? customQuestionText.trim() : securityQuestion.trim();
      if (!finalQuestion) {
        setSetupError("Lütfen güvenlik sorusu seçin veya kendi özel sorunuzu yazın.");
        return;
      }
      if (!securityAnswer.trim()) {
        setSetupError("Güvenlik sorusunun cevabı boş bırakılamaz!");
        return;
      }

      try {
        const { record, rawKey, mnemonicPhrase, emergencyHexKey } = await initializeVault(
          setupPin.trim(),
          finalQuestion,
          securityAnswer.trim(),
          hint.trim() || undefined,
          autoLockSetting
        );

        if (decoyPin.trim()) {
          localStorage.setItem("noteflow_decoy_pin", decoyPin.trim());
          decoyPinRef.current = decoyPin.trim();
        } else {
          localStorage.setItem("noteflow_decoy_pin", "9999");
          decoyPinRef.current = "9999";
        }

        setGeneratedMnemonic(mnemonicPhrase);
        setGeneratedHexKey(emergencyHexKey);

        // Store in temporary references so Step 3 emergency kit is displayed properly
        tempVaultRecordRef.current = record;
        tempRawKeyRef.current = rawKey;

        // Advance to Step 3: Emergency Kit Display
        setSetupStep(3);
      } catch (err: any) {
        setSetupError("Kurulum hatası: " + (err?.message || "Bilinmeyen hata"));
      }
    } else {
      // Step 3 Confirmation & Final Activation
      const finalRecord = tempVaultRecordRef.current;
      const finalRawKey = tempRawKeyRef.current;

      if (finalRecord && finalRawKey) {
        setVaultRecord(finalRecord);
        setRawVaultKey(finalRawKey);
        setVaultNotes([]);
        setRealNotes([]);
        localStorage.setItem("noteflow_vault_cached_pin", setupPin.trim());
      }

      setIsSettingUp(false);
      setSetupStep(1);
      setIsVaultUnlocked(true);
      setIsDecoyVault(false);
      showToast("🎉 Akıllı Kasa Mimarisi ve Kriptografik Kurtarma Kiti Başarıyla Kuruldu!");
    }
  };

  // Kurtarma Kiti İndir
  const downloadEmergencyKit = (mnemonic: string, hexKey: string) => {
    const textContent = `=====================================================
NOTEFLOW AKILLI KASA KRİPTOGRAFİK ACİL DURUM KURTARMA KİTİ
=====================================================
Oluşturulma Tarihi: ${new Date().toLocaleString("tr-TR")}
Güvenlik Standardı: AES-256-GCM + PBKDF2 (120,000 Iteration)

[1] 12 KELİMELİK ACİL KURTARMA CÜMLESİ (BIP-39 MNEMONIC):
-----------------------------------------------------
${mnemonic}

[2] 256-BİT MASTER MASTER ACİL DURUM ANAHTARI (HEX TOKEN):
-----------------------------------------------------
${hexKey}

[3] GÜVENLİK SORUSU:
-----------------------------------------------------
Soru: ${vaultRecord?.securityQuestion || securityQuestion}

UYARI: Bu dosyayı güvenli bir yerde saklayın. Şifrenizi unutsanız dahi
bu 12 kelime veya anahtar tokeni ile tüm kasanızı tek tıkla kurtarabilirsiniz.
=====================================================`;

    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `noteflow-vault-emergency-kit-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("✓ Acil Durum Kurtarma Kiti İndirildi!");
  };

  // Dahi Şifre Kurtarma Gönderimi (3 Yöntem)
  const handleRecoverySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (!vaultRecord) return;

    try {
      if (recoveryMethod === "question") {
        if (!recoveryAnswer.trim()) {
          setRecoveryError("Lütfen güvenlik sorusu cevabınızı girin.");
          return;
        }
        const { notes, rawKey } = await unlockVaultWithSecurityAnswer(vaultRecord, recoveryAnswer);
        setRecoverySuccessKey(rawKey);
        setRealNotes(notes);
        showToast("✓ Güvenlik sorusu doğrulandı!");
      } else if (recoveryMethod === "mnemonic") {
        if (!recoveryMnemonicInput.trim()) {
          setRecoveryError("Lütfen 12 kelimelik kurtarma cümlenizi girin.");
          return;
        }
        const { notes, rawKey } = await unlockVaultWithMnemonic(vaultRecord, recoveryMnemonicInput.trim());
        setRecoverySuccessKey(rawKey);
        setRealNotes(notes);
        showToast("✓ 12 Kelimelik Kurtarma Cümlesi doğrulandı!");
      } else if (recoveryMethod === "hex") {
        if (!recoveryHexInput.trim()) {
          setRecoveryError("Lütfen 64 karakterlik Acil Durum Anahtarını girin.");
          return;
        }
        const { notes, rawKey } = await unlockVaultWithEmergencyHexKey(vaultRecord, recoveryHexInput.trim());
        setRecoverySuccessKey(rawKey);
        setRealNotes(notes);
        showToast("✓ Master Acil Durum Tokeni doğrulandı!");
      }
    } catch (err: any) {
      setRecoveryError(
        recoveryMethod === "question"
          ? "Güvenlik sorusu cevabı eşleşmedi. Lütfen tekrar deneyin."
          : recoveryMethod === "mnemonic"
          ? "Kurtarma kelimeleri geçersiz veya hatalı. Lütfen kelimeleri kontrol edin."
          : "Acil durum anahtarı geçersiz veya bozuk."
      );
    }
  };

  // Yeni Şifre ile Sıfırlama
  const handleResetRecoveryPinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (!vaultRecord || !recoverySuccessKey) return;
    if (newRecoveryPin.length < 4) {
      setRecoveryError("Yeni şifre en az 4 haneli olmalıdır.");
      return;
    }
    if (newRecoveryPin !== newRecoveryPinConfirm) {
      setRecoveryError("Girdiğiniz yeni şifreler uyuşmuyor!");
      return;
    }

    try {
      const { newRecord, newRawKey } = await resetVaultPinWithRawKey(
        vaultRecord,
        recoverySuccessKey,
        newRecoveryPin
      );

      setVaultRecord(newRecord);
      setRawVaultKey(newRawKey);
      setVaultNotes(realNotes);
      setIsVaultUnlocked(true);
      setShowRecovery(false);
      setRecoverySuccessKey(null);
      setRecoveryAnswer("");
      setRecoveryMnemonicInput("");
      setRecoveryHexInput("");
      setNewRecoveryPin("");
      setNewRecoveryPinConfirm("");
      localStorage.setItem("noteflow_vault_cached_pin", newRecoveryPin);
      showToast("✓ Kasa şifresi başarıyla sıfırlandı ve giriş yapıldı!");
    } catch (err: any) {
      setRecoveryError("Sıfırlama sırasında hata oluştu: " + err.message);
    }
  };

  // PIN Değiştirme (Ayarlar Sekmesi)
  const handleChangePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePinError(null);
    setChangePinSuccess(null);

    if (!vaultRecord) return;
    if (newChangePin.length < 4) {
      setChangePinError("Yeni şifre en az 4 haneli olmalıdır.");
      return;
    }
    if (newChangePin !== newChangePinConfirm) {
      setChangePinError("Yeni şifreler birbiriyle uyuşmuyor!");
      return;
    }

    try {
      const { newRecord, newRawKey } = await changeVaultPin(
        vaultRecord,
        currentChangePin,
        newChangePin,
        realNotes
      );
      setVaultRecord(newRecord);
      setRawVaultKey(newRawKey);
      localStorage.setItem("noteflow_vault_cached_pin", newChangePin);
      setChangePinSuccess("✓ Kasa şifresi başarıyla güncellendi!");
      setCurrentChangePin("");
      setNewChangePin("");
      setNewChangePinConfirm("");
      setTimeout(() => setChangePinSuccess(null), 3000);
    } catch (err: any) {
      setChangePinError("Mevcut şifreniz hatalı! Lütfen doğru şifreyi girin.");
    }
  };

  // Tuzak PIN Kaydetme
  const handleSaveDecoyPin = () => {
    if (customDecoyPin.length < 4) {
      showToast("Tuzak PIN en az 4 haneli olmalıdır.");
      return;
    }
    localStorage.setItem("noteflow_decoy_pin", customDecoyPin);
    decoyPinRef.current = customDecoyPin;
    showToast("✓ Sahte Kasa (Decoy PIN) güncellendi: " + customDecoyPin);
  };

  // Not Kaydetme
  const handleSaveVaultNote = async () => {
    if (!noteTitle.trim()) {
      showToast("Not başlığı boş bırakılamaz.");
      return;
    }

    const updatedNotes = [...realNotes];
    if (editingVaultNote) {
      const idx = updatedNotes.findIndex((n) => n.id === editingVaultNote.id);
      if (idx !== -1) {
        updatedNotes[idx] = {
          ...editingVaultNote,
          title: noteTitle,
          content: noteContent,
          category: noteCategory,
          updatedAt: new Date().toISOString(),
        };
      }
    } else {
      const newNote: Note = {
        id: `vault-note-${Date.now()}`,
        title: noteTitle,
        content: noteContent,
        category: noteCategory,
        tags: ["#kasa", "#şifreli", "#özel"],
        pinned: false,
        favorite: false,
        isVault: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      updatedNotes.unshift(newNote);
    }

    if (isDecoyVault) {
      saveDecoyNotes(updatedNotes);
      setDecoyNotesState(updatedNotes);
      showToast("✓ Not sahte kasaya eklendi.");
    } else {
      if (vaultRecord && rawVaultKey) {
        const updatedRecord = await saveVaultPayload(vaultRecord, updatedNotes, rawVaultKey);
        setVaultRecord(updatedRecord);
        setVaultNotes(updatedNotes);
        setRealNotes(updatedNotes);
        showToast("✓ Not AES-256 askeri standartla şifrelenip kasaya alındı.");
      }
    }

    setIsNoteEditorOpen(false);
    setEditingVaultNote(null);
    setNoteTitle("");
    setNoteContent("");
  };

  // Not Silme
  const handleDeleteVaultNote = async (id: string) => {
    const updated = realNotes.filter((n) => n.id !== id);
    if (previewingVaultNote?.id === id) {
      setPreviewingVaultNote(null);
    }
    if (isDecoyVault) {
      saveDecoyNotes(updated);
      setDecoyNotesState(updated);
      showToast("Not sahte kasadan silindi.");
    } else {
      if (vaultRecord && rawVaultKey) {
        const updatedRecord = await saveVaultPayload(vaultRecord, updated, rawVaultKey);
        setVaultRecord(updatedRecord);
        setVaultNotes(updated);
        setRealNotes(updated);
        showToast("✓ Not silindi ve bellek kalıntıları temizlendi.");
      }
    }
  };

  // Not Sabitleme (Pin/Unpin)
  const handleTogglePinVaultNote = async (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = realNotes.map((n) =>
      n.id === id ? { ...n, pinned: !n.pinned, updatedAt: new Date().toISOString() } : n
    );
    if (isDecoyVault) {
      saveDecoyNotes(updated);
      setDecoyNotesState(updated);
      showToast("Not sabitleme durumu güncellendi.");
    } else {
      if (vaultRecord && rawVaultKey) {
        const updatedRecord = await saveVaultPayload(vaultRecord, updated, rawVaultKey);
        setVaultRecord(updatedRecord);
        setVaultNotes(updated);
        setRealNotes(updated);
        const targetNote = updated.find((n) => n.id === id);
        showToast(targetNote?.pinned ? "📌 Not kasanın en üstüne sabitlendi." : "Not sabitlemesi kaldırıldı.");
      }
    }
  };

  // Not İçeriğini Panoya Kopyalama
  const handleCopyNoteContent = (note: Note, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!note.content) {
      showToast("Kopyalanacak not içeriği boş.");
      return;
    }
    navigator.clipboard.writeText(note.content);
    setCopiedNoteId(note.id);
    showToast("✓ Not metni panoya kopyalandı!");
    setTimeout(() => {
      setCopiedNoteId((curr) => (curr === note.id ? null : curr));
    }, 2000);
  };

  // Tekil Not Metnini Aç / Daralt (Inline Expand)
  const handleToggleExpandNote = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedNoteIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Tüm Notların Metnini Topluca Aç / Kapat
  const handleToggleExpandAll = () => {
    if (expandAllNotes) {
      setExpandAllNotes(false);
      setExpandedNoteIds(new Set());
      showToast("Not metinleri kompakt görünüme alındı.");
    } else {
      setExpandAllNotes(true);
      const allIds = new Set(activeNotes.map((n) => n.id));
      setExpandedNoteIds(allIds);
      showToast("📖 Tüm notların yazıları tam metin olarak açıldı.");
    }
  };

  // Not Detayını Görüntüleyici Modalda Aç
  const handleOpenNoteReader = (note: Note) => {
    setPreviewingVaultNote(note);
  };

  // Görüntüleyiciden Düzenleyiciye Geçiş
  const handleEditFromReader = (note: Note) => {
    setPreviewingVaultNote(null);
    setEditingVaultNote(note);
    setNoteTitle(note.title);
    setNoteContent(note.content || "");
    setNoteCategory(note.category);
    setIsNoteEditorOpen(true);
  };

  // =========================================================================
  // OTOMATİK TARAMA & ŞİFRELİ NOTLARI KASAYA AKTARMA MOTORU
  // =========================================================================
  const sensitiveWorkspaceNotes = useMemo(() => {
    return workspaceNotes
      .filter((n) => !n.isVault)
      .map((note) => {
        const result = detectSensitiveDataInNote(note);
        return {
          note,
          result,
        };
      })
      .filter((item) => item.result.isSensitive);
  }, [workspaceNotes]);

  // Initial selection of all sensitive notes
  useEffect(() => {
    setSelectedMigrateIds(sensitiveWorkspaceNotes.map((item) => item.note.id));
  }, [sensitiveWorkspaceNotes]);

  const handleBatchMigrateToVault = async () => {
    if (selectedMigrateIds.length === 0) {
      showToast("Lütfen taşınacak en az bir not seçin.");
      return;
    }
    if (!vaultRecord || !rawVaultKey) {
      showToast("Önce kasanızı şifrenizle açmanız gerekmektedir.");
      return;
    }

    setIsMigratingLoading(true);
    try {
      const notesToMove = workspaceNotes.filter((n) => selectedMigrateIds.includes(n.id));
      const preparedVaultNotes = notesToMove.map((n) => ({ ...n, isVault: true }));

      // Merge into vault notes
      const mergedVaultNotes = [...preparedVaultNotes, ...realNotes];
      const uniqueVaultNotes = Array.from(new Map(mergedVaultNotes.map((n) => [n.id, n])).values());

      // Save encrypted
      const updatedRecord = await saveVaultPayload(vaultRecord, uniqueVaultNotes, rawVaultKey);
      setVaultRecord(updatedRecord);
      setVaultNotes(uniqueVaultNotes);
      setRealNotes(uniqueVaultNotes);

      // Trigger workspace removal callback
      if (onMigrateNotesToVault) {
        await onMigrateNotesToVault(notesToMove);
      }

      setMigrationSummary(`✓ ${notesToMove.length} adet şifreli not başarıyla kasaya aktarıldı ve şifrelendi!`);
      showToast(`🔒 ${notesToMove.length} adet not AES-256 ile şifrelendi!`);
      setTimeout(() => {
        setMigrationSummary(null);
        setActiveSubTab("notes");
      }, 2000);
    } catch (err: any) {
      showToast("Aktarma hatası: " + err.message);
    } finally {
      setIsMigratingLoading(false);
    }
  };

  const activeNotes = isDecoyVault ? decoyNotesState : realNotes;

  const categoriesInVault = useMemo(() => {
    const cats = new Set<string>();
    activeNotes.forEach((n) => {
      if (n.category) cats.add(n.category);
    });
    return Array.from(cats);
  }, [activeNotes]);

  const filteredNotes = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const result = activeNotes.filter((n) => {
      const matchesSearch =
        query === "" ||
        n.title.toLowerCase().includes(query) ||
        (n.content && n.content.toLowerCase().includes(query)) ||
        (n.tags && n.tags.some((t) => t.toLowerCase().includes(query))) ||
        (n.category && n.category.toLowerCase().includes(query));

      const matchesCat =
        selectedVaultCategory === "all" || n.category === selectedVaultCategory;

      return matchesSearch && matchesCat;
    });

    return [...result].sort((a, b) => {
      if (vaultSortOption === "pinned") {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime();
      }
      if (vaultSortOption === "newest") {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime();
      }
      if (vaultSortOption === "oldest") {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
      }
      if (vaultSortOption === "title-asc") {
        return a.title.localeCompare(b.title, "tr");
      }
      if (vaultSortOption === "title-desc") {
        return b.title.localeCompare(a.title, "tr");
      }
      if (vaultSortOption === "length") {
        return (b.content?.length || 0) - (a.content?.length || 0);
      }
      return 0;
    });
  }, [activeNotes, searchQuery, selectedVaultCategory, vaultSortOption]);

  return (
    <div className="min-h-[85dvh] w-full bg-slate-50 dark:bg-slate-900 flex flex-col items-center justify-start p-2 sm:p-6 transition-colors safe-bottom">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-16 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold flex items-center gap-2"
          >
            <Shield className="w-4 h-4 animate-pulse" />
            <span>{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="w-full max-w-3xl bg-white dark:bg-slate-800 rounded-2xl sm:rounded-3xl border border-slate-200 dark:border-slate-700/80 shadow-2xl p-4 sm:p-8 relative overflow-hidden transition-colors modal-overscroll-contain">
        
        {/* Subtle decorative glow */}
        <div className="absolute right-0 top-0 w-48 h-48 bg-emerald-500/5 dark:bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* ========================================================================= */}
        {/* 1. SETUP WIZARD (KASA KURULUMU & RECOVERY KIT OLUŞTURMA) */}
        {/* ========================================================================= */}
        {(!vaultRecord || isSettingUp) && !isVaultUnlocked && (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="inline-flex p-3.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-2xl mb-1 shadow-xs">
                <Shield className="w-8 h-8" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                Akıllı Kasa Kurulumu & Şifre Belirleme
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                Askeri standart AES-256-GCM sıfır bilgi mimarisi. Verileriniz sunucuya gitmez, yalnızca cihazınızda güvenle kriptolanır.
              </p>
            </div>

            {/* Step Progress Indicators */}
            <div className="flex items-center justify-center gap-3 max-w-sm mx-auto pb-2">
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className={`h-2 w-full rounded-full transition-all ${setupStep >= 1 ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"}`} />
                <span className="text-[10px] font-bold text-slate-500">1. Şifre</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className={`h-2 w-full rounded-full transition-all ${setupStep >= 2 ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"}`} />
                <span className="text-[10px] font-bold text-slate-500">2. Güvenlik</span>
              </div>
              <div className="flex-1 flex flex-col items-center gap-1">
                <div className={`h-2 w-full rounded-full transition-all ${setupStep === 3 ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"}`} />
                <span className="text-[10px] font-bold text-slate-500">3. Kurtarma Kiti</span>
              </div>
            </div>

            <form onSubmit={handleSetupSubmit} className="space-y-5 max-w-md mx-auto">
              {setupStep === 1 && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-3">
                  
                  {/* Password Type Selector */}
                  <div className="flex p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200/80 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => setPinTypeMode("numeric")}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                        pinTypeMode === "numeric"
                          ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                          : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Sayısal PIN (0-9)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPinTypeMode("alphanumeric")}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                        pinTypeMode === "alphanumeric"
                          ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                          : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                      }`}
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Alfanümerik Parola</span>
                    </button>
                  </div>

                  {/* Master Password Input */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        {pinTypeMode === "numeric" ? "Asıl Kasa Giriş PIN Kodu" : "Asıl Kasa Giriş Parolası"}
                      </label>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {setupPin.length > 0 ? `${setupPin.length} karakter` : "En az 4 karakter"}
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type={showSetupPin ? "text" : "password"}
                        maxLength={pinTypeMode === "numeric" ? 12 : 32}
                        pattern={pinTypeMode === "numeric" ? "[0-9]*" : undefined}
                        inputMode={pinTypeMode === "numeric" ? "numeric" : "text"}
                        value={setupPin}
                        onChange={(e) => {
                          const val = pinTypeMode === "numeric" ? e.target.value.replace(/\D/g, "") : e.target.value;
                          setSetupPin(val);
                        }}
                        placeholder={pinTypeMode === "numeric" ? "Örn: 1234 veya 584920" : "Örn: GizliKasa.2026"}
                        className="w-full pl-4 pr-11 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-base font-bold tracking-wider focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                        required
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => setShowSetupPin(!showSetupPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                        title={showSetupPin ? "Gizle" : "Göster"}
                      >
                        {showSetupPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Password Confirm Input */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        Şifreyi Yeniden Yazın (Doğrulama)
                      </label>
                      {setupPinConfirm.length > 0 && (
                        <span className={`text-[10px] font-bold flex items-center gap-1 ${
                          setupPin === setupPinConfirm ? "text-emerald-600 dark:text-emerald-400" : "text-amber-500"
                        }`}>
                          {setupPin === setupPinConfirm ? "✓ Eşleşti" : "✗ Uyuşmuyor"}
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <input
                        type={showSetupPinConfirm ? "text" : "password"}
                        maxLength={pinTypeMode === "numeric" ? 12 : 32}
                        pattern={pinTypeMode === "numeric" ? "[0-9]*" : undefined}
                        inputMode={pinTypeMode === "numeric" ? "numeric" : "text"}
                        value={setupPinConfirm}
                        onChange={(e) => {
                          const val = pinTypeMode === "numeric" ? e.target.value.replace(/\D/g, "") : e.target.value;
                          setSetupPinConfirm(val);
                        }}
                        placeholder="Şifrenizi teyit edin"
                        className={`w-full pl-4 pr-11 py-3 rounded-xl border bg-slate-50 dark:bg-slate-900/60 text-base font-bold tracking-wider focus:outline-none focus:ring-2 text-slate-900 dark:text-white ${
                          setupPinConfirm.length > 0 && setupPin !== setupPinConfirm
                            ? "border-amber-400 focus:ring-amber-400"
                            : "border-slate-200 dark:border-slate-700 focus:ring-emerald-500"
                        }`}
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowSetupPinConfirm(!showSetupPinConfirm)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                        title={showSetupPinConfirm ? "Gizle" : "Göster"}
                      >
                        {showSetupPinConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Decoy PIN Input (Optional) */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                        <span>Tuzak / Tehdit Şifresi (Decoy PIN - İsteğe Bağlı)</span>
                        <span className="text-[9px] bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 px-1.5 py-0.2 rounded font-extrabold">Stealth</span>
                      </label>
                    </div>
                    <div className="relative">
                      <input
                        type={showDecoyPin ? "text" : "password"}
                        maxLength={pinTypeMode === "numeric" ? 12 : 32}
                        pattern={pinTypeMode === "numeric" ? "[0-9]*" : undefined}
                        inputMode={pinTypeMode === "numeric" ? "numeric" : "text"}
                        value={decoyPin}
                        onChange={(e) => {
                          const val = pinTypeMode === "numeric" ? e.target.value.replace(/\D/g, "") : e.target.value;
                          setDecoyPin(val);
                        }}
                        placeholder="Zorla açtırılma anı için tuzak şifre (Örn: 9999)"
                        className="w-full pl-4 pr-11 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs font-bold tracking-wider focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={() => setShowDecoyPin(!showDecoyPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                        title={showDecoyPin ? "Gizle" : "Göster"}
                      >
                        {showDecoyPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-normal">
                      * Biri sizi kasayı açmaya zorlarsa bu şifreyi girin; sıradan sahte notların olduğu tuzak kasa açılır.
                    </p>
                  </div>
                </div>
              )}

              {setupStep === 2 && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Kurtarma Güvenlik Sorusu
                    </label>
                    <select
                      value={securityQuestion}
                      onChange={(e) => setSecurityQuestion(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="İlk evcil hayvanınızın adı nedir?">İlk evcil hayvanınızın adı nedir?</option>
                      <option value="Annenizin gençlik soyadı nedir?">Annenizin gençlik soyadı nedir?</option>
                      <option value="En sevdiğiniz ilkokul öğretmeninizin adı nedir?">En sevdiğiniz ilkokul öğretmeninizin adı nedir?</option>
                      <option value="Hangi şehirde doğdunuz?">Hangi şehirde doğdunuz?</option>
                      <option value="İlk arabanızın markası neydi?">İlk arabanızın markası neydi?</option>
                      <option value="custom">+ Kendi Özel Güvenlik Sorunuzu Yazın...</option>
                    </select>
                  </div>

                  {securityQuestion === "custom" && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        Özel Güvenlik Sorunuz
                      </label>
                      <input
                        type="text"
                        value={customQuestionText}
                        onChange={(e) => setCustomQuestionText(e.target.value)}
                        placeholder="Örn: İlk okuduğum kitabın başlığı nedir?"
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        required
                        autoFocus
                      />
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        Cevabınız (Şifre Sıfırlama için)
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowSecurityAnswer(!showSecurityAnswer)}
                        className="text-[10px] text-emerald-600 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        {showSecurityAnswer ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{showSecurityAnswer ? "Gizle" : "Göster"}</span>
                      </button>
                    </div>
                    <input
                      type={showSecurityAnswer ? "text" : "password"}
                      value={securityAnswer}
                      onChange={(e) => setSecurityAnswer(e.target.value)}
                      placeholder="Cevabınızı buraya yazın"
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                      required
                      autoFocus={securityQuestion !== "custom"}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Şifre İpucu (İsteğe Bağlı)
                    </label>
                    <input
                      type="text"
                      value={hint}
                      onChange={(e) => setHint(e.target.value)}
                      placeholder="Örn: Mezuniyet yılım ve okul kısaltmam"
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              {setupStep === 3 && (
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-3">
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 text-xs font-black">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>12 Kelimelik Kriptografik Acil Durum Cümleniz</span>
                    </div>
                    <p className="text-[11px] text-emerald-900/80 dark:text-emerald-300/80 leading-relaxed">
                      Şifrenizi veya PIN'inizi unutsanız bile bu 12 kelime ile kasanızı her zaman anında kurtarabilirsiniz:
                    </p>
                    <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-emerald-200 text-xs font-mono font-bold text-emerald-700 dark:text-emerald-300 grid grid-cols-3 gap-2">
                      {generatedMnemonic.split(" ").map((w, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 bg-emerald-50/50 dark:bg-slate-800/80 px-2 py-1 rounded-lg">
                          <span className="text-[9px] text-slate-400 select-none">{idx + 1}.</span>
                          <span className="truncate">{w}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(generatedMnemonic);
                          setCopiedKit(true);
                          setTimeout(() => setCopiedKit(false), 2000);
                          showToast("✓ 12 Kelimelik Cümle Kopyalandı!");
                        }}
                        className="flex-1 py-2 px-3 bg-white dark:bg-slate-900 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-bold border border-emerald-300 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        {copiedKit ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedKit ? "Kopyalandı" : "Kelimeleri Kopyala"}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => downloadEmergencyKit(generatedMnemonic, generatedHexKey)}
                        className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Kurtarma Kitini İndir (.txt)</span>
                      </button>
                    </div>

                    <label className="flex items-center gap-2 pt-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={hasConfirmedBackup}
                        onChange={(e) => setHasConfirmedBackup(e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
                      />
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                        Kurtarma kelimelerimi güvenli bir yere kaydettim.
                      </span>
                    </label>
                  </div>
                </div>
              )}

              {setupError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/40 rounded-xl border border-red-200 text-[11px] text-red-600 dark:text-red-400 font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{setupError}</span>
                </div>
              )}

              <div className="flex gap-3">
                {setupStep === 2 && (
                  <button
                    type="button"
                    onClick={() => {
                      setSetupError(null);
                      setSetupStep(1);
                    }}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                  >
                    Geri
                  </button>
                )}
                {setupStep === 3 && (
                  <button
                    type="button"
                    onClick={() => {
                      setSetupError(null);
                      setSetupStep(2);
                    }}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                  >
                    Geri
                  </button>
                )}
                <button
                  type="submit"
                  className="flex-1 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md shadow-emerald-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {setupStep === 1 ? (
                    <>
                      <span>Devam Et</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  ) : setupStep === 2 ? (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Kasa ve Kurtarma Kitini Oluştur</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Kurulumu Tamamla ve Kasayı Aç</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. UNLOCK PORTAL WITH MOBILE PIN KEYPAD & BIOMETRICS */}
        {/* ========================================================================= */}
        {vaultRecord && !isSettingUp && !isVaultUnlocked && !showRecovery && (
          <div className="space-y-4 max-w-sm mx-auto animate-in fade-in zoom-in-95 duration-200">
            {/* Header / Lock Status Icon */}
            <div className="text-center space-y-1.5">
              <div className="relative inline-flex p-3.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-full mb-0.5 shadow-sm border border-emerald-200/60 dark:border-emerald-800/60">
                <Lock className="w-6 h-6" />
                <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
              </div>
              <h2 className="text-base font-black text-slate-900 dark:text-white tracking-tight">
                Şifreli Kasa Korumalı
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Lütfen PIN kodunuzu tuşlayın veya parmak izinizi okutun.
              </p>
            </div>

            {/* PIN Dots Display & Input Switcher */}
            <div className="space-y-3">
              {/* PIN Indicator Box with Shake animation */}
              <motion.div
                animate={isShaking ? { x: [-10, 10, -8, 8, -4, 4, 0] } : {}}
                transition={{ duration: 0.4 }}
                className="p-3.5 rounded-2xl bg-slate-100/80 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-2 shadow-inner"
              >
                {/* Dots / Masked numbers */}
                <div className="flex items-center justify-center gap-3 py-1 min-h-[36px]">
                  {pinInputMode === "keypad" ? (
                    isPinVisible ? (
                      <span className="text-2xl font-mono font-black tracking-widest text-emerald-600 dark:text-emerald-400">
                        {pin || "•"}
                      </span>
                    ) : (
                      // 4 fixed dots (expands if pin > 4)
                      Array.from({ length: Math.max(4, pin.length) }).map((_, idx) => {
                        const isFilled = idx < pin.length;
                        return (
                          <motion.div
                            key={idx}
                            initial={false}
                            animate={{
                              scale: isFilled ? 1.15 : 1,
                              backgroundColor: isFilled ? "#10b981" : "transparent",
                            }}
                            className={`w-3.5 h-3.5 rounded-full border-2 transition-colors ${
                              isFilled
                                ? "border-emerald-500 bg-emerald-500 shadow-sm shadow-emerald-500/50"
                                : "border-slate-300 dark:border-slate-600 bg-transparent"
                            }`}
                          />
                        );
                      })
                    )
                  ) : (
                    <input
                      type={isPinVisible ? "text" : "password"}
                      maxLength={32}
                      value={pin}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPin(val);
                        const currentDecoy = decoyPinRef.current || "9999";
                        if (val === currentDecoy) {
                          executeUnlock(val);
                        }
                      }}
                      placeholder="Şifrenizi yazın..."
                      className="w-full text-center text-lg font-black tracking-wider bg-transparent border-none focus:outline-none text-slate-900 dark:text-white px-2"
                      autoFocus
                    />
                  )}
                </div>

                {/* Helper Controls (Peek PIN & Switch Keypad / Keyboard) */}
                <div className="flex items-center justify-between w-full px-2 text-[10px] text-slate-400 border-t border-slate-200/60 dark:border-slate-800/80 pt-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setIsPinVisible(!isPinVisible);
                    }}
                    className="flex items-center gap-1 hover:text-slate-600 dark:hover:text-slate-300 transition-colors cursor-pointer"
                  >
                    {isPinVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{isPinVisible ? "Şifreyi Gizle" : "Şifreyi Göster"}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic(10);
                      setPinInputMode(pinInputMode === "keypad" ? "keyboard" : "keypad");
                    }}
                    className="flex items-center gap-1 hover:text-slate-600 dark:hover:text-slate-300 transition-colors cursor-pointer"
                  >
                    {pinInputMode === "keypad" ? (
                      <>
                        <Keyboard className="w-3 h-3" />
                        <span>Klavye ile Yaz</span>
                      </>
                    ) : (
                      <>
                        <Smartphone className="w-3 h-3" />
                        <span>Tuş Takımına Geç</span>
                      </>
                    )}
                  </button>
                </div>
              </motion.div>

              {/* Unlock Error Notice */}
              {unlockError && (
                <div className="p-2.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 rounded-xl text-[11px] text-red-600 dark:text-red-400 font-bold flex items-center gap-2 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{unlockError}</span>
                </div>
              )}

              {/* TACTILE NUMERIC TOUCH KEYPAD (Android PIN Experience) */}
              {pinInputMode === "keypad" ? (
                <div className="grid grid-cols-3 gap-2.5 pt-1">
                  {[
                    { num: "1", sub: "" },
                    { num: "2", sub: "ABC" },
                    { num: "3", sub: "DEF" },
                    { num: "4", sub: "GHI" },
                    { num: "5", sub: "JKL" },
                    { num: "6", sub: "MNO" },
                    { num: "7", sub: "PQRS" },
                    { num: "8", sub: "TUV" },
                    { num: "9", sub: "WXYZ" },
                  ].map(({ num, sub }) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeypadPress(num)}
                      className="h-14 sm:h-15 rounded-2xl bg-white dark:bg-slate-800/90 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 active:scale-92 active:bg-emerald-100 dark:active:bg-emerald-900 border border-slate-200/90 dark:border-slate-700/80 shadow-xs flex flex-col items-center justify-center transition-all cursor-pointer select-none"
                    >
                      <span className="text-xl font-black text-slate-800 dark:text-white leading-none">
                        {num}
                      </span>
                      {sub && (
                        <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 tracking-wider mt-0.5">
                          {sub}
                        </span>
                      )}
                    </button>
                  ))}

                  {/* Row 4: Biometric / Parmak İzi, 0, Backspace */}
                  <button
                    type="button"
                    onClick={handleBiometricAuth}
                    disabled={biometric === "scanning"}
                    className="h-14 sm:h-15 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 active:scale-92 border border-emerald-300 dark:border-emerald-700/60 shadow-xs flex flex-col items-center justify-center transition-all cursor-pointer text-emerald-600 dark:text-emerald-400 select-none"
                    title="Parmak İzi / Biyometrik Kilit Açma"
                  >
                    {biometric === "scanning" ? (
                      <RotateCw className="w-5 h-5 animate-spin" />
                    ) : biometric === "success" ? (
                      <CheckCircle className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Fingerprint className="w-6 h-6" />
                    )}
                    <span className="text-[8px] font-extrabold mt-0.5">Parmak İzi</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleKeypadPress("0")}
                    className="h-14 sm:h-15 rounded-2xl bg-white dark:bg-slate-800/90 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 active:scale-92 active:bg-emerald-100 dark:active:bg-emerald-900 border border-slate-200/90 dark:border-slate-700/80 shadow-xs flex flex-col items-center justify-center transition-all cursor-pointer select-none"
                  >
                    <span className="text-xl font-black text-slate-800 dark:text-white leading-none">0</span>
                    <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 tracking-wider mt-0.5">+</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleKeypadBackspace}
                    className="h-14 sm:h-15 rounded-2xl bg-white dark:bg-slate-800/90 hover:bg-red-50 dark:hover:bg-red-950/40 active:scale-92 active:bg-red-100 dark:active:bg-red-900 border border-slate-200/90 dark:border-slate-700/80 shadow-xs flex flex-col items-center justify-center transition-all cursor-pointer text-slate-600 dark:text-slate-300 hover:text-red-600 dark:hover:text-red-400 select-none"
                    title="Son Haneyi Sil"
                  >
                    <Delete className="w-5 h-5" />
                    <span className="text-[8px] font-extrabold mt-0.5">Sil</span>
                  </button>
                </div>
              ) : null}

              {/* Action Buttons: Giriş Yap & Parmak İzi */}
              <div className="flex gap-2 pt-1">
                {pin.length > 0 && (
                  <button
                    type="button"
                    onClick={handleKeypadClear}
                    className="px-3.5 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 text-slate-600 dark:text-slate-300 text-xs font-bold transition-all cursor-pointer"
                  >
                    Temizle
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => executeUnlock(pin)}
                  disabled={!pin}
                  className="flex-1 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                >
                  <Unlock className="w-4 h-4" />
                  <span>Kasayı Aç ({pin.length > 0 ? `${pin.length} Hane` : "PIN Bekleniyor"})</span>
                </button>
              </div>
            </div>

            {/* Hint & Forgot Password Link */}
            <div className="flex flex-col gap-1.5 items-center justify-center text-[11px] pt-1 border-t border-slate-100 dark:border-slate-800/60">
              {vaultRecord.hint && (
                <span className="text-slate-500 dark:text-slate-400 text-[10px]">
                  İpucu: <strong className="text-slate-700 dark:text-slate-200">{vaultRecord.hint}</strong>
                </span>
              )}
              <button
                type="button"
                onClick={() => {
                  triggerHaptic(10);
                  setShowRecovery(true);
                  setRecoveryMethod("question");
                }}
                className="text-emerald-600 dark:text-emerald-400 hover:underline font-extrabold cursor-pointer flex items-center gap-1 py-1"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Şifremi Unuttum (Kriptografik Kurtarma)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerHaptic(10);
                  if (window.confirm("Yeni bir kasa kaydı ve şifresi oluşturmak istiyor musunuz? Mevcut kasa sıfırlanıp yeni kurulum sihirbazı başlatılacaktır.")) {
                    setSetupPin("");
                    setSetupPinConfirm("");
                    setShowSetupPin(false);
                    setShowSetupPinConfirm(false);
                    setDecoyPin("");
                    setShowDecoyPin(false);
                    setSecurityAnswer("");
                    setShowSecurityAnswer(false);
                    setCustomQuestionText("");
                    setHint("");
                    setSetupError(null);
                    setSetupStep(1);
                    setHasConfirmedBackup(false);
                    setShowRecovery(false);
                    setIsSettingUp(true);
                  }
                }}
                className="text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors py-1"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Yeni Kasa Kaydı Oluştur / Sıfırdan Kur</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. DAHİ ŞİFRE KURTARMA MERKEZİ (FORGOT PASSWORD / MULTI-FACTOR RECOVERY) */}
        {/* ========================================================================= */}
        {showRecovery && (
          <div className="space-y-5 max-w-md mx-auto animate-in fade-in zoom-in-95">
            <div className="text-center space-y-1.5">
              <div className="inline-flex p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-2xl mb-1">
                <Sparkles className="w-6 h-6 text-emerald-500" />
              </div>
              <h2 className="text-base font-black text-slate-900 dark:text-white">
                Dahi Kriptografik Kurtarma Merkezi
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Kasanızın şifresini unuttuysanız sıfır bilgi kaybı olmadan aşağıdaki 3 yöntemden biriyle kasanızı kurtarın:
              </p>
            </div>

            {/* Recovery Method Tabs */}
            <div className="flex bg-slate-100 dark:bg-slate-900/80 p-1 rounded-2xl text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setRecoveryMethod("question")}
                className={`flex-1 py-1.5 rounded-xl transition-all ${recoveryMethod === "question" ? "bg-white dark:bg-slate-800 text-emerald-600 shadow-sm" : "text-slate-500"}`}
              >
                🧠 Güvenlik Sorusu
              </button>
              <button
                type="button"
                onClick={() => setRecoveryMethod("mnemonic")}
                className={`flex-1 py-1.5 rounded-xl transition-all ${recoveryMethod === "mnemonic" ? "bg-white dark:bg-slate-800 text-emerald-600 shadow-sm" : "text-slate-500"}`}
              >
                📜 12 Kelime
              </button>
              <button
                type="button"
                onClick={() => setRecoveryMethod("hex")}
                className={`flex-1 py-1.5 rounded-xl transition-all ${recoveryMethod === "hex" ? "bg-white dark:bg-slate-800 text-emerald-600 shadow-sm" : "text-slate-500"}`}
              >
                🔑 Master Token
              </button>
            </div>

            {!recoverySuccessKey ? (
              <form onSubmit={handleRecoverySubmit} className="space-y-4">
                {recoveryMethod === "question" && (
                  <div className="space-y-3 animate-in fade-in">
                    <div className="p-3 bg-slate-50 dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200">
                      Soru: {vaultRecord?.securityQuestion || "Kurtarma sorusu ayarlanmamış."}
                    </div>
                    <input
                      type="text"
                      value={recoveryAnswer}
                      onChange={(e) => setRecoveryAnswer(e.target.value)}
                      placeholder="Güvenlik sorusu cevabı"
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                      required
                      autoFocus
                    />
                  </div>
                )}

                {recoveryMethod === "mnemonic" && (
                  <div className="space-y-2 animate-in fade-in">
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                      12 Kelimelik Kurtarma Cümlenizi Yapıştırın:
                    </label>
                    <textarea
                      rows={3}
                      value={recoveryMnemonicInput}
                      onChange={(e) => setRecoveryMnemonicInput(e.target.value)}
                      placeholder="Örn: atlas akdeniz anadolu gunes ruzgar..."
                      className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                      required
                      autoFocus
                    />
                  </div>
                )}

                {recoveryMethod === "hex" && (
                  <div className="space-y-2 animate-in fade-in">
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                      64 Karakterlik Acil Durum Master Anahtarını Yapıştırın:
                    </label>
                    <textarea
                      rows={3}
                      value={recoveryHexInput}
                      onChange={(e) => setRecoveryHexInput(e.target.value)}
                      placeholder="Örn: 4a8f9c2d1b7e..."
                      className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                      required
                      autoFocus
                    />
                  </div>
                )}

                {recoveryError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 text-[10px] text-red-600 dark:text-red-400 font-bold flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{recoveryError}</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowRecovery(false);
                      setRecoveryAnswer("");
                      setRecoveryMnemonicInput("");
                      setRecoveryHexInput("");
                      setRecoveryError(null);
                    }}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
                  >
                    Doğrula ve Sıfırla
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleResetRecoveryPinSubmit} className="space-y-4 animate-in fade-in">
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold rounded-xl border border-emerald-200 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  Kriptografik doğrulama başarılı! Şimdi kasanız için yeni bir PIN belirleyin:
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Yeni Kasa Şifresi (Yeni PIN)
                  </label>
                  <input
                    type="password"
                    maxLength={8}
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={newRecoveryPin}
                    onChange={(e) => setNewRecoveryPin(e.target.value.replace(/\D/g, ""))}
                    placeholder="En az 4 haneli yeni şifre"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-base text-center font-bold tracking-widest focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                    required
                    autoFocus
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Yeni Şifre (Doğrulama)
                  </label>
                  <input
                    type="password"
                    maxLength={8}
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={newRecoveryPinConfirm}
                    onChange={(e) => setNewRecoveryPinConfirm(e.target.value.replace(/\D/g, ""))}
                    placeholder="Şifreyi tekrar yazın"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-base text-center font-bold tracking-widest focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                    required
                  />
                </div>

                {recoveryError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 text-[10px] text-red-600 dark:text-red-400 font-bold flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{recoveryError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  Şifreyi Sıfırla ve Kasayı Aç
                </button>
              </form>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 4. UNLOCKED SECURE VAULT DASHBOARD */}
        {/* ========================================================================= */}
        {isVaultUnlocked && (
          <div className="space-y-5 animate-in fade-in zoom-in-95">
            
            {/* Header Area inside Vault */}
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-2xl">
                  {isDecoyVault ? <AlertTriangle className="w-5 h-5 text-amber-500" /> : <Unlock className="w-5 h-5" />}
                </div>
                <div>
                  <h2 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                    {isDecoyVault ? "Sahte Kasa (Decoy Mode)" : "Kişisel Güvenli Kasa"}
                    <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md ${isDecoyVault ? "bg-amber-100 text-amber-800" : "bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300/40"}`}>
                      {isDecoyVault ? "Tuzak" : "AES-256 Askeri"}
                    </span>
                  </h2>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {isDecoyVault ? "Sıradan tuzak notlar gösteriliyor." : `${realNotes.length} adet güvenli not deşifre edildi.`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleLockVault}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-red-50 hover:text-red-600 text-slate-700 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-red-950/40 dark:hover:text-red-400 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  Kasayı Kilitle
                </button>
              </div>
            </div>

            {/* Sub Tabs: Kasa Notları | Şifreli Notları Tara & Aktar | Güvenlik & Kişiselleştirme */}
            <div className="flex bg-slate-100 dark:bg-slate-900/60 p-1 rounded-2xl text-xs font-bold gap-1">
              <button
                type="button"
                onClick={() => setActiveSubTab("notes")}
                className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeSubTab === "notes"
                    ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-700"
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Kasa Notlarım ({filteredNotes.length})</span>
              </button>

              {!isDecoyVault && (
                <>
                  <button
                    type="button"
                    onClick={() => setActiveSubTab("migrate")}
                    className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeSubTab === "migrate"
                        ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700"
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-500" />
                    <span>Şifreli Notları Aktar</span>
                    {sensitiveWorkspaceNotes.length > 0 && (
                      <span className="px-1.5 py-0.2 text-[9px] bg-amber-500 text-white rounded-full">
                        {sensitiveWorkspaceNotes.length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveSubTab("settings")}
                    className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeSubTab === "settings"
                        ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700"
                    }`}
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Kişiselleştirme</span>
                  </button>
                </>
              )}
            </div>

            {/* TAB 1: KASA NOTLARI */}
            {activeSubTab === "notes" && (
              <div className="space-y-4">
                {/* 1. Arama ve Ana Eylemler Çubuğu */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Kasadaki şifreli notlarda ara (başlık, içerik, etiket)..."
                      className="w-full pl-9 pr-8 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white transition-all"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery("")}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                        title="Aramayı Temizle"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Tüm Notların Yazılarını Aç / Kapat Butonu */}
                    <button
                      type="button"
                      onClick={handleToggleExpandAll}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        expandAllNotes
                          ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300"
                          : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
                      }`}
                      title={expandAllNotes ? "Not metinlerini kompakt görünüme al" : "Tüm notların yazılarını tam metin olarak aç"}
                    >
                      <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span>{expandAllNotes ? "Yazıları Kısalt" : "Yazıları Aç"}</span>
                    </button>

                    <button
                      onClick={() => {
                        setEditingVaultNote(null);
                        setNoteTitle("");
                        setNoteContent("");
                        setNoteCategory("Şifreler");
                        setIsNoteEditorOpen(true);
                      }}
                      className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/15 transition-all cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Yeni Gizli Not</span>
                    </button>
                  </div>
                </div>

                {/* 2. Sıralama, Kategori ve Görünüm Çubuğu */}
                <div className="p-3 bg-slate-50/70 dark:bg-slate-900/40 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    {/* Sıralama Seçenekleri */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <ArrowUpDown className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Sırala:</span>
                      </span>
                      <select
                        value={vaultSortOption}
                        onChange={(e) => setVaultSortOption(e.target.value as any)}
                        className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer shadow-2xs"
                      >
                        <option value="newest">🕒 En Yeni (Güncelleme)</option>
                        <option value="oldest">⏳ En Eski (Oluşturma)</option>
                        <option value="pinned">📌 Önce Sabitlenenler</option>
                        <option value="title-asc">🔤 Başlık (A - Z)</option>
                        <option value="title-desc">🔡 Başlık (Z - A)</option>
                        <option value="length">📄 Metin Uzunluğu</option>
                      </select>
                    </div>

                    {/* Görünüm Düzeni (Grid / List) & Sayaç */}
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-extrabold text-slate-500 dark:text-slate-400 px-2 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                        {filteredNotes.length} / {activeNotes.length} Not
                      </span>

                      <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-0.5 shadow-2xs">
                        <button
                          type="button"
                          onClick={() => setVaultLayoutMode("grid")}
                          className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                            vaultLayoutMode === "grid"
                              ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400"
                              : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                          }`}
                          title="Izgara (Kart) Görünümü"
                        >
                          <LayoutGrid className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setVaultLayoutMode("list")}
                          className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                            vaultLayoutMode === "list"
                              ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400"
                              : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                          }`}
                          title="Liste Görünümü"
                        >
                          <List className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Kategori Filtresi Hapları */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar text-xs">
                    <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1 shrink-0 mr-0.5">
                      <Filter className="w-3 h-3" />
                      Kategori:
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedVaultCategory("all")}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all shrink-0 cursor-pointer ${
                        selectedVaultCategory === "all"
                          ? "bg-emerald-600 text-white shadow-xs"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      Tümü ({activeNotes.length})
                    </button>
                    {categoriesInVault.map((cat) => {
                      const count = activeNotes.filter((n) => n.category === cat).length;
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setSelectedVaultCategory(cat)}
                          className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all shrink-0 cursor-pointer ${
                            selectedVaultCategory === cat
                              ? "bg-emerald-600 text-white shadow-xs"
                              : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          {cat} ({count})
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 3. Notların Listelenmesi */}
                {filteredNotes.length === 0 ? (
                  <div className="text-center py-12 border border-dashed border-slate-200 dark:border-slate-700 rounded-3xl bg-slate-50/40 dark:bg-slate-900/20">
                    <Shield className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                    <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {searchQuery || selectedVaultCategory !== "all"
                        ? "Aramanıza veya seçilen kategoriye uygun kasa notu bulunamadı."
                        : "Kasada henüz kayıtlı not bulunmuyor."}
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                      {searchQuery || selectedVaultCategory !== "all" ? (
                        <button
                          onClick={() => {
                            setSearchQuery("");
                            setSelectedVaultCategory("all");
                          }}
                          className="text-emerald-600 hover:underline font-bold mt-1"
                        >
                          Filtreleri Temizle
                        </button>
                      ) : (
                        "Yukarıdaki 'Yeni Gizli Not' butonuna basarak veya 'Şifreli Notları Aktar' sekmesinden çalışma alanınızdaki notları aktararak başlayabilirsiniz."
                      )}
                    </p>
                  </div>
                ) : vaultLayoutMode === "grid" ? (
                  /* ================= GRID (IZGARA) GÖRÜNÜMÜ ================= */
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {filteredNotes.map((note) => {
                      const isExpanded = expandAllNotes || expandedNoteIds.has(note.id);
                      const isCopied = copiedNoteId === note.id;

                      return (
                        <div
                          key={note.id}
                          className="rounded-2xl border border-slate-200/90 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-xs hover:shadow-md hover:border-emerald-400/80 dark:hover:border-emerald-500/80 transition-all group relative overflow-hidden flex flex-col justify-between"
                        >
                          {/* Üst Renk Vurgusu */}
                          <div
                            className={`h-1.5 w-full ${
                              note.pinned ? "bg-amber-400" : "bg-emerald-500"
                            }`}
                          />

                          <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                            {/* Üst Rozetler ve Eylemler */}
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-2">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60">
                                    {note.category || "Genel"}
                                  </span>
                                  {note.pinned && (
                                    <span className="text-[9px] font-extrabold flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                                      <Pin className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      Sabit
                                    </span>
                                  )}
                                </div>

                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={(e) => handleTogglePinVaultNote(note.id, e)}
                                    className={`p-1 rounded-lg transition-all cursor-pointer ${
                                      note.pinned
                                        ? "text-amber-500 bg-amber-50 dark:bg-amber-950/60"
                                        : "text-slate-300 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-700"
                                    }`}
                                    title={note.pinned ? "Sabitlemeyi Kaldır" : "Kasa Üstüne Sabitle"}
                                  >
                                    <Pin className={`w-3.5 h-3.5 ${note.pinned ? "fill-amber-500" : ""}`} />
                                  </button>
                                  <span className="flex items-center gap-1 text-[9px] text-slate-400">
                                    <Clock className="w-3 h-3" />
                                    {new Date(note.updatedAt || note.createdAt).toLocaleDateString("tr-TR")}
                                  </span>
                                </div>
                              </div>

                              {/* Not Başlığı (Tıklayınca Okuyucu Modalı Açılır) */}
                              <h4
                                onClick={() => handleOpenNoteReader(note)}
                                className="text-xs font-black text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5 leading-snug"
                              >
                                <span>{note.title || "Başlıksız Gizli Not"}</span>
                              </h4>

                              {/* Not İçeriği (Tam Metin Açılabilir veya Özet) */}
                              <div className="mt-2">
                                {isExpanded ? (
                                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-700/70 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed select-text font-sans max-h-72 overflow-y-auto">
                                    {note.content || "İçerik boş..."}
                                  </div>
                                ) : (
                                  <p
                                    onClick={() => handleOpenNoteReader(note)}
                                    className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed font-sans cursor-pointer hover:text-slate-900 dark:hover:text-white transition-colors"
                                  >
                                    {note.content || "Boş içerik..."}
                                  </p>
                                )}

                                {/* Aç / Kapat Butonu */}
                                <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-100 dark:border-slate-700/60 text-[10px]">
                                  <button
                                    type="button"
                                    onClick={(e) => handleToggleExpandNote(note.id, e)}
                                    className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                                  >
                                    {isExpanded ? (
                                      <>
                                        <ChevronUp className="w-3 h-3" />
                                        <span>Yazıyı Kısalt</span>
                                      </>
                                    ) : (
                                      <>
                                        <ChevronDown className="w-3 h-3" />
                                        <span>Yazıyı Aç (Tam Metin)</span>
                                      </>
                                    )}
                                  </button>

                                  <span className="text-[10px] text-slate-400">
                                    {note.content ? `${note.content.length} karakter` : ""}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Alt Eylemler Çubuğu: Oku, Kopyala, Düzenle, Sil */}
                            <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-700/60">
                              <button
                                type="button"
                                onClick={() => handleOpenNoteReader(note)}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 dark:text-emerald-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                title="Notu Tam Ekranda İncele & Oku"
                              >
                                <BookOpen className="w-3.5 h-3.5" />
                                <span>Notu Oku</span>
                              </button>

                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={(e) => handleCopyNoteContent(note, e)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer"
                                  title="Not İçeriğini Panoya Kopyala"
                                >
                                  {isCopied ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingVaultNote(note);
                                    setNoteTitle(note.title);
                                    setNoteContent(note.content || "");
                                    setNoteCategory(note.category);
                                    setIsNoteEditorOpen(true);
                                  }}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                                  title="Düzenle"
                                >
                                  <Sliders className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteVaultNote(note.id);
                                  }}
                                  className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors cursor-pointer"
                                  title="Kasa Notunu Sil"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* ================= LIST (LİSTE) GÖRÜNÜMÜ ================= */
                  <div className="space-y-2">
                    {filteredNotes.map((note) => {
                      const isExpanded = expandAllNotes || expandedNoteIds.has(note.id);
                      const isCopied = copiedNoteId === note.id;

                      return (
                        <div
                          key={note.id}
                          className="p-3.5 rounded-2xl border border-slate-200/90 dark:border-slate-700/80 bg-white dark:bg-slate-800 shadow-2xs hover:shadow-xs hover:border-emerald-400 dark:hover:border-emerald-500 transition-all space-y-2"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <button
                                type="button"
                                onClick={(e) => handleTogglePinVaultNote(note.id, e)}
                                className={`p-1 rounded transition-all cursor-pointer shrink-0 ${
                                  note.pinned
                                    ? "text-amber-500"
                                    : "text-slate-300 hover:text-amber-500"
                                }`}
                                title={note.pinned ? "Sabitlendi" : "Sabitle"}
                              >
                                <Pin className={`w-3.5 h-3.5 ${note.pinned ? "fill-amber-500" : ""}`} />
                              </button>

                              <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shrink-0">
                                {note.category || "Genel"}
                              </span>

                              <h4
                                onClick={() => handleOpenNoteReader(note)}
                                className="text-xs font-black text-slate-900 dark:text-white hover:text-emerald-600 dark:hover:text-emerald-400 cursor-pointer truncate"
                              >
                                {note.title || "Başlıksız Not"}
                              </h4>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <span className="text-[10px] text-slate-400 mr-1 hidden sm:inline">
                                {new Date(note.updatedAt || note.createdAt).toLocaleDateString("tr-TR")}
                              </span>

                              <button
                                type="button"
                                onClick={() => handleOpenNoteReader(note)}
                                className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                                title="Notu Oku"
                              >
                                <BookOpen className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => handleCopyNoteContent(note, e)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                                title="Kopyala"
                              >
                                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingVaultNote(note);
                                  setNoteTitle(note.title);
                                  setNoteContent(note.content || "");
                                  setNoteCategory(note.category);
                                  setIsNoteEditorOpen(true);
                                }}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                                title="Düzenle"
                              >
                                <Sliders className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteVaultNote(note.id);
                                }}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors"
                                title="Sil"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Not Metni (Açık veya Kısaltılmış) */}
                          <div className="pl-6">
                            {isExpanded ? (
                              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-700/70 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed select-text font-sans">
                                {note.content || "Boş içerik..."}
                              </div>
                            ) : (
                              <p
                                onClick={() => handleOpenNoteReader(note)}
                                className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed cursor-pointer hover:text-slate-900 dark:hover:text-white"
                              >
                                {note.content || "Boş içerik..."}
                              </p>
                            )}

                            <div className="flex items-center justify-between mt-1 text-[10px]">
                              <button
                                type="button"
                                onClick={(e) => handleToggleExpandNote(note.id, e)}
                                className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-0.5 cursor-pointer"
                              >
                                {isExpanded ? "Yazıyı Kısalt" : "Yazıyı Tam Göster"}
                              </button>
                              <span className="text-slate-400 font-mono text-[9px]">
                                {note.content ? `${note.content.length} karakter` : ""}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: OTOMATİK TARAMA & ŞİFRELİ NOTLARI KASAYA AKTARMA */}
            {activeSubTab === "migrate" && (
              <div className="space-y-4 animate-in fade-in">
                <div className="p-4 bg-amber-50 dark:bg-amber-950/30 rounded-2xl border border-amber-200/80 flex items-start gap-3">
                  <Zap className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h3 className="text-xs font-bold text-amber-900 dark:text-amber-200">
                      Otonom Şifreli & Hassas Not Tarayıcısı
                    </h3>
                    <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80 leading-relaxed">
                      Sistem çalışma alanınızdaki tüm notları taradı. İçinde şifre, parola, IBAN, kredi kartı veya gizli anahtar barındıran notlar otomatik tespit edildi.
                    </p>
                  </div>
                </div>

                {sensitiveWorkspaceNotes.length === 0 ? (
                  <div className="text-center py-10 border border-slate-200 dark:border-slate-700 rounded-2xl bg-slate-50/50">
                    <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Açıkta Kalan Şifreli Not Bulunmadı!
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Çalışma alanınızdaki tüm hassas veriler güvenli bir şekilde Kasada korunuyor.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 px-1">
                      <span>Bulunan Şifreli Notlar ({sensitiveWorkspaceNotes.length})</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedMigrateIds(sensitiveWorkspaceNotes.map((i) => i.note.id))}
                          className="text-[11px] text-emerald-600 hover:underline cursor-pointer"
                        >
                          Tümünü Seç
                        </button>
                        <button
                          onClick={() => setSelectedMigrateIds([])}
                          className="text-[11px] text-slate-400 hover:underline cursor-pointer"
                        >
                          Seçimi Temizle
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                      {sensitiveWorkspaceNotes.map(({ note, result }) => {
                        const isSelected = selectedMigrateIds.includes(note.id);
                        return (
                          <div
                            key={note.id}
                            onClick={() => {
                              setSelectedMigrateIds((prev) =>
                                isSelected ? prev.filter((id) => id !== note.id) : [...prev, note.id]
                              );
                            }}
                            className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                              isSelected
                                ? "bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-400"
                                : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 opacity-70"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}}
                                className="w-4 h-4 text-emerald-600 rounded"
                              />
                              <div>
                                <h5 className="text-xs font-bold text-slate-900 dark:text-white">
                                  {note.title || "Başlıksız Not"}
                                </h5>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                  {result.detectedTypes.map((type, tIdx) => (
                                    <span
                                      key={tIdx}
                                      className="text-[9px] bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 px-1.5 py-0.2 rounded font-extrabold"
                                    >
                                      {type}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {note.category}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {migrationSummary && (
                      <div className="p-3 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-xl flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        <span>{migrationSummary}</span>
                      </div>
                    )}

                    <button
                      onClick={handleBatchMigrateToVault}
                      disabled={isMigratingLoading || selectedMigrateIds.length === 0}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-black shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
                    >
                      {isMigratingLoading ? (
                        <>
                          <RotateCw className="w-4 h-4 animate-spin" />
                          <span>AES-256 ile Kriptolanıyor...</span>
                        </>
                      ) : (
                        <>
                          <Shield className="w-4 h-4" />
                          <span>Seçilen {selectedMigrateIds.length} Şifreli Notu Kasaya Kilitle</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: GÜVENLİK & KİŞİSELLEŞTİRME */}
            {activeSubTab === "settings" && (
              <div className="space-y-6 animate-in fade-in">
                
                {/* Section 1: Change PIN */}
                <form onSubmit={handleChangePinSubmit} className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-emerald-500" />
                    <span>Kasa Giriş PIN Şifresini Değiştir</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <input
                      type="password"
                      maxLength={8}
                      pattern="[0-9]*"
                      inputMode="numeric"
                      value={currentChangePin}
                      onChange={(e) => setCurrentChangePin(e.target.value.replace(/\D/g, ""))}
                      placeholder="Mevcut PIN"
                      className="px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                      required
                    />
                    <input
                      type="password"
                      maxLength={8}
                      pattern="[0-9]*"
                      inputMode="numeric"
                      value={newChangePin}
                      onChange={(e) => setNewChangePin(e.target.value.replace(/\D/g, ""))}
                      placeholder="Yeni PIN"
                      className="px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                      required
                    />
                    <input
                      type="password"
                      maxLength={8}
                      pattern="[0-9]*"
                      inputMode="numeric"
                      value={newChangePinConfirm}
                      onChange={(e) => setNewChangePinConfirm(e.target.value.replace(/\D/g, ""))}
                      placeholder="Yeni PIN Tekrar"
                      className="px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                      required
                    />
                  </div>

                  {changePinError && <p className="text-[10px] text-red-500 font-bold">{changePinError}</p>}
                  {changePinSuccess && <p className="text-[10px] text-emerald-500 font-bold">{changePinSuccess}</p>}

                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Şifreyi Güncelle
                  </button>
                </form>

                {/* Section 2: Decoy PIN Setting */}
                <div className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      <span>Tehdit / Sahte Kasa (Decoy PIN) Ayarı</span>
                    </h4>
                    <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-bold">Stealth</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      maxLength={8}
                      pattern="[0-9]*"
                      inputMode="numeric"
                      value={customDecoyPin}
                      onChange={(e) => setCustomDecoyPin(e.target.value.replace(/\D/g, ""))}
                      className="px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white w-40 font-mono text-center font-bold"
                    />
                    <button
                      type="button"
                      onClick={handleSaveDecoyPin}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold cursor-pointer"
                    >
                      Tuzak PIN'i Kaydet
                    </button>
                  </div>
                </div>

                {/* Section 3: Recovery Kit Viewer & Export */}
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>Acil Durum Kurtarma Kiti (12 Kelime & Master Key)</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => {
                        if (rawVaultKey) {
                          const mnem = rawKeyToMnemonic(rawVaultKey);
                          const hex = bytesToHex(rawVaultKey);
                          downloadEmergencyKit(mnem, hex);
                        } else {
                          showToast("Kurtarma kitini indirmek için önce kasanızı açın.");
                        }
                      }}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Kit Dosyasını İndir (.txt)</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80">
                    Acil durum kurtarma cümlenizi veya master tokeninizi güvenli bir yerde saklayarak şifrenizi unutsanız dahi kasanızı sıfırlayabilirsiniz.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 5. INTEGRATED VAULT NOTE EDITOR MODAL */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {isNoteEditorOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/30">
                <span className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  {editingVaultNote ? "Kasa Notunu Düzenle" : "Kasa İçinde Yeni Gizli Not"}
                </span>
                <button
                  onClick={() => setIsNoteEditorOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Not Başlığı</label>
                  <input
                    type="text"
                    value={noteTitle}
                    onChange={(e) => setNoteTitle(e.target.value)}
                    placeholder="Örn: Kripto Cüzdanım, Banka Girişi..."
                    className="w-full px-3.5 py-2.5 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 rounded-xl text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Kategori</label>
                  <select
                    value={noteCategory}
                    onChange={(e) => setNoteCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="Şifreler">Şifreler & Parolalar</option>
                    <option value="Finans">Banka & Finans</option>
                    <option value="Kişisel">Kişisel Özel</option>
                    <option value="İş">İş & Gizli Proje</option>
                    <option value="Fikirler">Özel Fikirler</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Şifreli İçerik</label>
                    <button
                      type="button"
                      onClick={() => setShowMaskedContent(!showMaskedContent)}
                      className="text-[10px] text-emerald-600 flex items-center gap-1 font-bold cursor-pointer"
                    >
                      {showMaskedContent ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showMaskedContent ? "Parola Maskele" : "Açık Göster"}</span>
                    </button>
                  </div>
                  <textarea
                    rows={6}
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    placeholder="Gizli not detayları, parolalar, PIN kodları, özel anahtarlar..."
                    className={`w-full p-3 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 rounded-xl text-xs leading-relaxed text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 ${
                      showMaskedContent ? "" : "font-mono"
                    }`}
                  />
                </div>
              </div>

              <div className="p-4 border-t border-slate-100 dark:border-slate-700 flex justify-end gap-2 bg-slate-50/50 dark:bg-slate-900/30">
                <button
                  onClick={() => setIsNoteEditorOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                >
                  Vazgeç
                </button>
                <button
                  onClick={handleSaveVaultNote}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5" />
                  AES-256 ile Kasaya Kilitle
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 6. GÜVENLİ KASA NOTU OKUYUCU (TAM DETAY MODALI) */}
        {/* ========================================================================= */}
        {previewingVaultNote && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Modal Başlık Çubuğu */}
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-emerald-50 dark:bg-emerald-950/60 rounded-xl text-emerald-600 dark:text-emerald-400">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>Kasa Notu Görünümü</span>
                      <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/50 px-1.5 py-0.5 rounded">
                        AES-256
                      </span>
                    </h3>
                    <p className="text-[10px] text-slate-400">Bellekte çözüldü, güvenli görüntüleniyor</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleTogglePinVaultNote(previewingVaultNote.id)}
                    className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                      previewingVaultNote.pinned
                        ? "bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-700 text-amber-500"
                        : "border-slate-200 dark:border-slate-700 text-slate-400 hover:text-amber-500"
                    }`}
                    title={previewingVaultNote.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle"}
                  >
                    <Pin className={`w-4 h-4 ${previewingVaultNote.pinned ? "fill-amber-500" : ""}`} />
                  </button>

                  <button
                    onClick={() => setPreviewingVaultNote(null)}
                    className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Modal Gövdesi: Başlık, Metadata ve Çözülmüş Tam Metin */}
              <div className="p-5 overflow-y-auto space-y-4 flex-1">
                {/* Not Başlığı ve Kategori */}
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                      {previewingVaultNote.category || "Genel"}
                    </span>
                    {previewingVaultNote.pinned && (
                      <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full">
                        <Pin className="w-3 h-3 fill-amber-500" />
                        Sabitlenmiş Kasa Notu
                      </span>
                    )}
                  </div>

                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-tight">
                    {previewingVaultNote.title || "Başlıksız Not"}
                  </h2>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      Oluşturma: {new Date(previewingVaultNote.createdAt).toLocaleString("tr-TR")}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      Son Güncelleme: {new Date(previewingVaultNote.updatedAt).toLocaleString("tr-TR")}
                    </span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono font-bold">
                      {previewingVaultNote.content ? `${previewingVaultNote.content.length} karakter` : "0 karakter"}
                    </span>
                  </div>
                </div>

                {/* Etiketler (varsa) */}
                {previewingVaultNote.tags && previewingVaultNote.tags.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {previewingVaultNote.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md flex items-center gap-1"
                      >
                        <Tag className="w-3 h-3 text-slate-400" />
                        {t}
                      </span>
                    ))}
                  </div>
                )}

                {/* Tam Metin Alanı */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-500">
                    <span className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Notun Açık Metni (Korumalı Alanda Çözüldü):</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyNoteContent(previewingVaultNote)}
                      className="text-emerald-600 hover:text-emerald-700 flex items-center gap-1 text-[11px] font-bold cursor-pointer"
                    >
                      {copiedNoteId === previewingVaultNote.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Kopyalandı!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Metni Kopyala</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/80 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-slate-100 whitespace-pre-wrap leading-relaxed select-text font-sans shadow-inner min-h-[140px]">
                    {resolveReadableNoteContent(previewingVaultNote.content) || "Bu notun içeriği bulunmamaktadır."}
                  </div>
                </div>
              </div>

              {/* Modal Alt Eylemler Çubuğu */}
              <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70 dark:bg-slate-900/80">
                <button
                  type="button"
                  onClick={() => {
                    handleDeleteVaultNote(previewingVaultNote.id);
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Notu Sil</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyNoteContent(previewingVaultNote)}
                    className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedNoteId === previewingVaultNote.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>Kopyala</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleEditFromReader(previewingVaultNote)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Notu Düzenle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
