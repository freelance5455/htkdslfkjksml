import { useMemo, useState, type ReactNode } from "react";
import { Activity, Download, ShieldCheck, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldMark } from "@/components/shield-mark";
import { UrlChecker } from "@/components/url-checker";
import { TrafficFeed } from "@/components/traffic-feed";
import { DownloadPack } from "@/components/download-pack";
import { useShield } from "@/lib/store";
import { nextAttack } from "@/lib/traffic-sim";

type Tab = "home" | "traffic" | "pack";

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function Dashboard() {
  const [tab, setTab] = useState<Tab>("home");
  const protectionOn = useShield((s) => s.protectionOn);
  const setProtection = useShield((s) => s.setProtection);
  const bytesProtected = useShield((s) => s.bytesProtected);
  const blockedCount = useShield((s) => s.blockedCount);
  const askedCount = useShield((s) => s.askedCount);
  const events = useShield((s) => s.events);
  const ingest = useShield((s) => s.ingest);
  const permissions = useShield((s) => s.permissions);
  const grant = useShield((s) => s.grantPermission);

  const grantedCount = useMemo(
    () => Object.values(permissions).filter((p) => p.granted).length,
    [permissions],
  );

  async function toggleProtection() {
    if (!protectionOn) {
      if ("Notification" in window && Notification.permission === "default") {
        const res = await Notification.requestPermission();
        grant("notifications", res === "granted");
      }
      grant("vpn", true);
      grant("background", true);
    }
    setProtection(!protectionOn);
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col">
      <header className="flex items-center justify-between px-5 pb-3 pt-6">
        <div className="flex items-center gap-2">
          <ShieldMark className="size-7" />
          <div>
            <p className="text-sm font-medium leading-none">Netzschild</p>
            <p className="mt-1 text-[11px] uppercase tracking-wider text-subtle">
              {protectionOn ? "Hintergrund aktiv" : "Pause"}
            </p>
          </div>
        </div>
        <Badge tone={protectionOn ? "safe" : "muted"}>
          {protectionOn ? "Schutz an" : "Schutz aus"}
        </Badge>
      </header>

      <div className="flex-1 px-5 pb-28">
        {tab === "home" ? (
          <div className="space-y-4">
            <section className="rounded-xl border border-border bg-surface p-5">
              <div className="flex items-center gap-4">
                {protectionOn ? (
                  <ShieldMark pulse className="size-16 shrink-0" />
                ) : (
                  <ShieldOff className="size-12 shrink-0 text-muted" />
                )}
                <div className="min-w-0">
                  <h1 className="text-xl font-medium tracking-tight">
                    {protectionOn
                      ? "Ihr Netz wird geprüft"
                      : "Schutz ist ausgeschaltet"}
                  </h1>
                  <p className="mt-1 text-sm leading-relaxed text-muted">
                    {protectionOn
                      ? "Jede neue Domain wird bewertet. Bei Zweifel kommt eine Nachfrage."
                      : "Ohne aktiven Dienst passiert Verkehr ungeprüft."}
                  </p>
                </div>
              </div>
              <Button
                className="mt-5 w-full"
                variant={protectionOn ? "secondary" : "default"}
                size="lg"
                onClick={toggleProtection}
              >
                {protectionOn ? "Schutz pausieren" : "Schutz starten"}
              </Button>
            </section>

            <div className="grid grid-cols-3 gap-2">
              <Stat label="Verkehr" value={formatBytes(bytesProtected)} />
              <Stat label="Nachfragen" value={String(askedCount)} />
              <Stat label="Blockiert" value={String(blockedCount)} />
            </div>

            <UrlChecker />

            <section className="rounded-xl border border-border bg-surface p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-medium">Phishing-Probe</h2>
                <Badge tone="warn">Demo</Badge>
              </div>
              <p className="mt-1 text-xs leading-relaxed text-muted">
                Simuliert einen gefälschten Link (Sparkasse, PayPal, DHL) und
                öffnet die Nachfrage.
              </p>
              <Button
                className="mt-3"
                size="sm"
                variant="outline"
                onClick={() => {
                  if (!protectionOn) setProtection(true);
                  ingest(nextAttack());
                }}
              >
                Gefälschte Seite auslösen
              </Button>
            </section>

            <section className="rounded-xl border border-border bg-surface p-4">
              <h2 className="text-sm font-medium">Rechte</h2>
              <p className="mt-1 text-xs text-muted">
                {grantedCount} von 6 erteilt · erforderliche zuerst
              </p>
              <ul className="mt-3 space-y-1.5 text-xs text-muted">
                <li>VPN, Benachrichtigungen, Hintergrund: für den Schutz</li>
                <li>Autostart, App-Zuordnung, Overlay: schärfer, optional</li>
              </ul>
            </section>
          </div>
        ) : null}

        {tab === "traffic" ? (
          <div className="space-y-4">
            <h1 className="text-xl font-medium tracking-tight">Verkehr</h1>
            <p className="text-sm text-muted">{events.length} erfasste Verbindungen</p>
            <TrafficFeed />
          </div>
        ) : null}

        {tab === "pack" ? (
          <div className="space-y-4">
            <h1 className="text-xl font-medium tracking-tight">APK-Paket</h1>
            <DownloadPack />
          </div>
        ) : null}
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-lg grid-cols-3">
          <NavBtn
            active={tab === "home"}
            onClick={() => setTab("home")}
            icon={<ShieldCheck className="size-4" />}
            label="Schutz"
          />
          <NavBtn
            active={tab === "traffic"}
            onClick={() => setTab("traffic")}
            icon={<Activity className="size-4" />}
            label="Verkehr"
          />
          <NavBtn
            active={tab === "pack"}
            onClick={() => setTab("pack")}
            icon={<Download className="size-4" />}
            label="ZIP"
          />
        </div>
      </nav>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-3">
      <p className="text-[11px] uppercase tracking-wider text-subtle">{label}</p>
      <p className="mt-1 font-mono text-sm tabular-nums">{value}</p>
    </div>
  );
}

function NavBtn({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] ${
        active ? "text-primary" : "text-muted"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
