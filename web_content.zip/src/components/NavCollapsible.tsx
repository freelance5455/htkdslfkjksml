import React from 'react';
import { useGame } from '../context/GameContext.tsx';
import type { ZoneId } from '../types/game.ts';
import { ChevronDown, ChevronUp, Lock } from 'lucide-react';

interface ZoneItem {
  id: ZoneId;
  name: string;
  shortName: string;
  icon: string;
  minLevel: number;
}

const ZONES: ZoneItem[] = [
  { id: 1, name: 'Vùng Đất Vàng', shortName: '1. Trồng Trọt', icon: '🌾', minLevel: 1 },
  { id: 2, name: 'Trang Trại Chuồng Thú', shortName: '2. Chuồng Thú', icon: '🐔', minLevel: 1 },
  { id: 3, name: 'Hồ Thủy Sinh & Đầm Sen', shortName: '3. Thủy Sinh', icon: '🐟', minLevel: 8 },
  { id: 4, name: 'Vườn Quả, Nấm & Ong', shortName: '4. Vườn Quả', icon: '🍎', minLevel: 5 },
  { id: 5, name: 'Nhà Kính Sinh Học Lai Gen', shortName: '5. Lai Gen', icon: '🧬', minLevel: 12 },
  { id: 6, name: 'Xưởng Chế Biến Thủ Công', shortName: '6. Xưởng Máy', icon: '🏭', minLevel: 3 },
  { id: 7, name: 'Thương Cảng Quốc Tế', shortName: '7. Thương Cảng', icon: '⛵', minLevel: 1 },
];

export const NavCollapsible: React.FC = () => {
  const { player, activeZone, setActiveZone, navCollapsed, setNavCollapsed, notificationBadges } = useGame();

  const currentZoneObj = ZONES.find((z) => z.id === activeZone) || ZONES[0];
  const hasAnyOtherBadge = ZONES.some((z) => z.id !== activeZone && notificationBadges[z.id]);

  if (navCollapsed) {
    return (
      <div className="sticky top-[49px] sm:top-[53px] z-30 bg-stone-900/90 border-b border-stone-800 text-stone-200 px-3 py-1 shadow-sm flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-base">{currentZoneObj.icon}</span>
          <span className="font-bold text-amber-300">
            {currentZoneObj.id}. {currentZoneObj.name}
          </span>
          {hasAnyOtherBadge && (
            <span className="flex items-center gap-1 bg-rose-500/20 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-rose-500/40 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              Có nông sản chờ
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => setNavCollapsed(false)}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 text-[11px] font-semibold border border-stone-700 transition"
          aria-label="Mở rộng menu 7 phân khu"
        >
          <span>Mở rộng</span>
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="sticky top-[49px] sm:top-[53px] z-30 bg-stone-900/95 border-b-2 border-stone-800 text-stone-100 px-2 py-2 shadow-md">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-1.5 px-1 text-xs text-stone-400">
          <span className="font-bold uppercase tracking-wide text-amber-400/90 flex items-center gap-1">
            <span>🗺️</span> 7 Phân Khu Nông Trại
          </span>
          <button
            type="button"
            onClick={() => setNavCollapsed(true)}
            className="flex items-center gap-1 text-[11px] text-stone-400 hover:text-stone-200 transition"
            aria-label="Thu nhỏ thanh điều hướng"
          >
            <span>Thu nhỏ</span>
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 7 Zone Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-1.5">
          {ZONES.map((zone) => {
            const isUnlocked = player.level >= zone.minLevel;
            const isActive = activeZone === zone.id;
            const hasBadge = notificationBadges[zone.id];

            return (
              <button
                key={zone.id}
                type="button"
                disabled={!isUnlocked}
                onClick={() => isUnlocked && setActiveZone(zone.id)}
                className={`relative flex items-center gap-1.5 px-2 py-1.5 rounded-lg border text-left transition ${
                  isActive
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow ring-1 ring-amber-400/50'
                    : isUnlocked
                    ? 'bg-stone-800/80 hover:bg-stone-800 border-stone-700/80 text-stone-200'
                    : 'bg-stone-950/40 border-stone-800 text-stone-500 cursor-not-allowed opacity-60'
                }`}
                aria-label={zone.name}
              >
                <span className="text-base sm:text-lg">{zone.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] sm:text-xs font-bold truncate">{zone.shortName}</div>
                  {!isUnlocked && (
                    <div className="text-[9px] text-amber-500/90 flex items-center gap-0.5">
                      <Lock className="w-2.5 h-2.5" />
                      <span>Cấp {zone.minLevel}</span>
                    </div>
                  )}
                </div>

                {/* Red notification dot */}
                {isUnlocked && hasBadge && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500 border border-stone-900"></span>
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
