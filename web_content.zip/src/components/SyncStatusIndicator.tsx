import React, { useState, useEffect } from 'react';
import { CheckCircle2, RefreshCw, HardDrive } from 'lucide-react';

interface SyncStatusIndicatorProps {
  lastSaved: Date | null;
  isSaving?: boolean;
}

export const SyncStatusIndicator: React.FC<SyncStatusIndicatorProps> = ({
  lastSaved,
  isSaving = false,
}) => {
  const [, setTick] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);

  // Re-render every 15 seconds to update relative time string
  useEffect(() => {
    const timer = setInterval(() => {
      setTick((t) => t + 1);
    }, 15000);
    return () => clearInterval(timer);
  }, []);

  const formatRelativeSaveTime = (date: Date | null): string => {
    if (!date) return 'सुरक्षित';

    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffSec < 10) {
      return 'अभी-अभी';
    }
    if (diffSec < 60) {
      return `${diffSec} से. पहले`;
    }
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) {
      return `${diffMin} मि. पहले`;
    }

    // Format as 12-hour time: e.g., 05:48 PM
    return date.toLocaleTimeString('hi-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const fullTimeString = lastSaved
    ? lastSaved.toLocaleTimeString('hi-IN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      })
    : '';

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onClick={() => setShowTooltip((prev) => !prev)}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold transition cursor-pointer select-none border ${
          isSaving
            ? 'bg-amber-400/20 text-amber-200 border-amber-300/40 animate-pulse'
            : 'bg-emerald-950/30 text-emerald-100 hover:bg-emerald-900/40 border-emerald-400/30'
        }`}
        title="ब्राउज़र लोकल स्टोरेज सिंक स्थिति"
      >
        {isSaving ? (
          <>
            <RefreshCw className="w-3 h-3 text-amber-300 animate-spin" />
            <span>सेव हो रहा है...</span>
          </>
        ) : (
          <>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
            <CheckCircle2 className="w-3 h-3 text-emerald-300" />
            <span className="truncate">
              लोकल सेव: {formatRelativeSaveTime(lastSaved)}
            </span>
          </>
        )}
      </button>

      {/* Detail Popover / Tooltip */}
      {showTooltip && (
        <div className="absolute left-0 sm:left-auto sm:right-0 top-full mt-1.5 z-50 w-56 rounded-xl bg-slate-900 text-white p-2.5 shadow-xl border border-slate-700 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-emerald-400 mb-1">
            <HardDrive className="w-3.5 h-3.5" />
            <span>लोकल स्टोरेज में सुरक्षित</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            सभी फोल्डर और ग्राहक रिकॉर्ड आपके फोन/ब्राउज़र के <strong>Local Storage</strong> में सुरक्षित हैं।
          </p>
          {fullTimeString && (
            <div className="mt-1.5 pt-1.5 border-t border-slate-800 text-[10px] text-slate-400 font-mono">
              अंतिम सुरक्षित समय: <span className="text-slate-200 font-bold">{fullTimeString}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
