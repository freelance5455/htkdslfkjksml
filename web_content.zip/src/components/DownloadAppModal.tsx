import React, { useState } from 'react';
import {
  Bluetooth,
  Check,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  MessageCircle,
  Share2,
  Smartphone,
  Terminal,
  X,
} from 'lucide-react';

interface DownloadAppModalProps {
  open: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onInstallPWA: () => Promise<boolean>;
}

const SHARED_PUBLIC_URL =
  'https://ais-pre-ijf5yr3w6zhqfej6suwbku-1004957384312.europe-west2.run.app';

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({
  open,
  onClose,
  isInstallable,
  isInstalled,
  isIOS,
  onInstallPWA,
}) => {
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installFeedback, setInstallFeedback] = useState<string | null>(null);
  const [installing, setInstalling] = useState(false);

  if (!open) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : SHARED_PUBLIC_URL;
  // Prefer the public shared URL when sharing with other students over WhatsApp/Facebook/Bluetooth
  const shareUrl = currentOrigin.includes('ais-dev-') ? SHARED_PUBLIC_URL : currentOrigin;
  const shareText =
    'Join TEVET POWER APP — Malawi TEVETA digital library across all technical colleges, chats, calls, and AI study tutor. Open & install here:';
  const whatsappShareHref = `https://wa.me/?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`;
  const facebookShareHref = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
  const pwabuilderHref = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(shareUrl)}`;

  const isEmbeddedIframe =
    typeof window !== 'undefined' && window.self !== window.top;
  const canNativeShare =
    typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  const handleDirectInstall = async () => {
    setInstalling(true);
    setInstallFeedback(null);
    try {
      const accepted = await onInstallPWA();
      if (accepted) {
        setInstallFeedback('TEVET POWER APP is being installed to your device.');
      } else {
        setInstallFeedback('Install prompt dismissed. You can install anytime from Chrome menu -> Install app.');
      }
    } finally {
      setInstalling(false);
    }
  };

  const handleNativeShare = async () => {
    if (!canNativeShare) return;
    try {
      await navigator.share({
        title: 'TEVET POWER APP',
        text: shareText,
        url: shareUrl,
      });
    } catch {
      // User cancelled share sheet
    }
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      setInstallFeedback(`Share or open this link in Chrome/Safari: ${shareUrl}`);
    }
  };

  const handleDownloadApkBuildScript = () => {
    const script = `#!/usr/bin/env bash
set -euo pipefail

# TEVET POWER APP — Automated Standalone Android APK Builder
# Produces an installable .apk file you can share via SHAREit, Bluetooth, WhatsApp, or Xender.
# Requirements: Node.js 20+, Java JDK 21, and Android SDK (Android Studio).

echo "1. Installing npm dependencies & building production web bundle..."
npm install
npm run build

echo "2. Installing Capacitor Android runtime..."
npm install --no-save @capacitor/core @capacitor/cli @capacitor/android

if [ ! -d "android" ]; then
  npx cap add android
fi

echo "3. Syncing web assets & capacitor.config.ts..."
CAPACITOR_SERVER_URL="${shareUrl}" npx cap sync android

echo "4. Building shareable Android APK..."
cd android
./gradlew assembleDebug

echo ""
echo "SUCCESS! Shareable APK built at:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
echo "Rename to TEVET-POWER-APP.apk and share via SHAREit, Bluetooth, WhatsApp, or Xender."
`;
    const blob = new Blob([script], { type: 'text/x-shellscript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'build-tevet-power-apk.sh';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="/pwa-192x192.png"
              alt="TEVET POWER APP icon"
              className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
            />
            <div>
              <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
                Install & Share TEVET POWER APP
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Standalone phone install + WhatsApp, Facebook, Bluetooth & SHAREit APK options
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close download dialog"
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* 1. Direct Standalone Phone Install */}
          {isInstalled ? (
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-emerald-900 dark:text-emerald-200">
                  Installed in Standalone Mode
                </p>
                <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-0.5">
                  TEVET POWER APP is installed on this device with offline library caching active.
                </p>
              </div>
            </div>
          ) : isInstallable ? (
            <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 space-y-3">
              <div className="flex items-start gap-3">
                <Smartphone className="w-5 h-5 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    1. Install Standalone App Now (Android / Desktop)
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                    Creates a full-screen standalone app icon on your phone with offline TEVETA notes.
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={installing}
                onClick={handleDirectInstall}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <Download className="w-4 h-4" />
                <span>{installing ? 'Opening Installer...' : 'Install Standalone App Now'}</span>
              </button>
            </div>
          ) : isIOS ? (
            <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 space-y-2">
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                1. Install Standalone App on iPhone / iPad
              </p>
              <ol className="text-xs text-slate-700 dark:text-slate-300 space-y-1 list-decimal list-inside">
                <li>Open the shared link below in <strong>Safari</strong>.</li>
                <li>Tap the <strong>Share</strong> icon at the bottom.</li>
                <li>Select <strong>Add to Home Screen</strong>.</li>
              </ol>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 space-y-2.5">
              <div className="flex items-start gap-3">
                <Smartphone className="w-5 h-5 text-blue-700 dark:text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    1. Install Standalone on Android Phone (Chrome WebAPK)
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                    {isEmbeddedIframe
                      ? 'Inside this preview frame, browsers hide the native install prompt. Open the Shared App Link below in Google Chrome on Android, then tap Menu (⋮) → "Install app".'
                      : 'In Chrome or Edge, tap the browser menu (⋮) and choose "Install app" or "Add to Home screen".'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {installFeedback && (
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-200">
              {installFeedback}
            </div>
          )}

          {/* 2. Share via WhatsApp, Facebook, Bluetooth & System Share */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-xs font-display font-bold text-slate-900 dark:text-white">
              <Share2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>2. Share App via WhatsApp, Facebook, Bluetooth & More</span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                aria-label="Shareable app URL"
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs font-mono text-slate-700 dark:text-slate-300"
              />
              <button
                type="button"
                onClick={handleCopyUrl}
                className="min-h-[38px] px-3 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {canNativeShare && (
                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="min-h-[38px] px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Bluetooth className="w-3.5 h-3.5" />
                  <span>Phone Share / Bluetooth</span>
                </button>
              )}
              <a
                href={whatsappShareHref}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[38px] px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Share on WhatsApp</span>
              </a>
              <a
                href={facebookShareHref}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[38px] px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Share on Facebook</span>
              </a>
            </div>
          </div>

          {/* 3. Real Standalone .APK Packaging for SHAREit / Bluetooth / Xender */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5 bg-slate-50/70 dark:bg-slate-950/60">
            <div className="flex items-center gap-2 text-xs font-display font-bold text-slate-900 dark:text-white">
              <Terminal className="w-4 h-4 text-blue-700 dark:text-blue-400" />
              <span>3. Standalone .APK File (for SHAREit, Bluetooth & WhatsApp File)</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              This cloud sandbox runs Node.js without the Android SDK/Java compiler, so an <code className="font-mono">.apk</code> file cannot be compiled directly inside this server. To generate a real installable <code className="font-mono">.apk</code> that students can send offline via <strong>SHAREit, Bluetooth, Xender, or WhatsApp</strong>:
            </p>
            <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1 list-disc list-inside">
              <li>
                <strong>Cloud Option (No Android Studio needed):</strong> Push to GitHub and run the included <code className="font-mono">.github/workflows/build-android-apk.yml</code> workflow, or package the live manifest via PWABuilder.
              </li>
              <li>
                <strong>Local Option:</strong> Run the pre-configured <code className="font-mono">capacitor.config.ts</code> builder script below to output <code className="font-mono">app-debug.apk</code>.
              </li>
            </ul>
            <div className="pt-1 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleDownloadApkBuildScript}
                className="min-h-[38px] px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                <span>Download APK Builder Script (.sh)</span>
              </button>
              <a
                href={pwabuilderHref}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[38px] px-3.5 py-2 rounded-xl border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-semibold flex items-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Package APK via PWABuilder</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
