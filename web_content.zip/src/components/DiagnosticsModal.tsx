import React, { useState, useEffect } from 'react';
import { Activity, Cpu, CheckCircle2, AlertTriangle, XCircle, RefreshCw, X, Zap } from 'lucide-react';
import { DiagnosticItem } from '../types';
import { safeFetchJson } from '../services/apiClient';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  batterySupported: boolean;
  micSupported: boolean;
  speechSynthSupported: boolean;
  cameraSupported: boolean;
  averageLatencyMs: number;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  batterySupported,
  micSupported,
  speechSynthSupported,
  cameraSupported,
  averageLatencyMs,
}) => {
  const [serverHealth, setServerHealth] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      checkDiagnostics();
    }
  }, [isOpen]);

  const checkDiagnostics = async () => {
    setLoading(true);
    try {
      const data = await safeFetchJson('/api/health');
      setServerHealth(data);
    } catch (e: any) {
      setServerHealth({ status: 'OFFLINE_OR_LIMITED', error: e.message || 'Server health check timed out' });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const diagnostics: DiagnosticItem[] = [
    {
      name: 'Gemini AI Core Endpoint',
      status: serverHealth?.apiConfigured ? 'operational' : 'warning',
      message: serverHealth?.apiConfigured ? 'Configured & connected via secure server proxy' : 'API Key check pending in Settings > Secrets',
      details: 'Processes reasoning, multimodal vision, and internet grounding.',
    },
    {
      name: 'Permanent Master Male Voice Core',
      status: speechSynthSupported ? 'operational' : 'error',
      message: speechSynthSupported ? 'JARVIS Master Voice Prime active (Deep Masculine Baritone, Pitch 0.76)' : 'Speech synthesis not supported in this browser environment',
      details: 'Delivers vocal responses, alarms, and acknowledgments with zero automatic switching.',
    },
    {
      name: 'Device Hardware Clock (Asia/Kolkata IST)',
      status: 'operational',
      message: 'Direct device clock telemetry anchored to Asia/Kolkata (UTC+05:30) with background resync',
      details: 'Evaluates alarms, daily routines, midnight date shifts, and live India time.',
    },
    {
      name: 'Speech Recognition (STT)',
      status: micSupported ? 'operational' : 'warning',
      message: micSupported ? 'WebKit Speech Recognition engine ready for wake phrases' : 'Speech recognition requires Chromium-based browser or mobile app permission',
      details: 'Listens for "Jarvis", Hindi, English, and Punjabi commands.',
    },
    {
      name: 'Device Battery Telemetry',
      status: batterySupported ? 'operational' : 'warning',
      message: batterySupported ? 'Hardware Battery API operational (reads level, charging, time)' : 'Battery API not supported on this specific browser (standard on Chrome/Android)',
      details: 'Triggers 10% low-battery warning and 100% full-charge alert.',
    },
    {
      name: 'Vision & Optical Camera',
      status: cameraSupported ? 'operational' : 'error',
      message: cameraSupported ? 'Camera media devices available for Google Lens scanning' : 'Camera hardware access restricted or denied',
      details: 'Powers real-time product inspection and OCR.',
    },
  ];

  // Self-Improvement system recommendations
  const suggestions = [
    {
      title: 'Redmi 12 RAM Optimization (4GB)',
      tip: 'Keep Fast Latency Mode active to limit reasoning token processing and preserve UI responsiveness.',
      impact: 'Reduces memory pressure and speeds up replies by ~40%.',
    },
    {
      title: 'Permanent Male Voice Tuning',
      tip: 'The voice engine is locked to male baritone. On mobile devices with Google TTS installed, install "Google Speech Recognition & Synthesis" for the highest fidelity English/Hindi male voice.',
      impact: 'Crisp studio-quality male voice matching Iron Man movie experience.',
    },
    {
      title: 'Wake-Word Browser Background Limitation',
      tip: 'Web browsers sleep background tabs to conserve battery. For continuous background listening while your screen is off, convert this app to the Android APK using the built-in Android Bridge guide.',
      impact: '24/7 background listening via native Android Foreground Service.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              JARVIS DIAGNOSTICS & SELF-IMPROVEMENT
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {/* Top Performance Status Card */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/20 flex items-center gap-2.5">
              <Cpu className="w-5 h-5 text-cyan-400" />
              <div>
                <span className="text-[10px] text-cyan-400/70 font-mono-tech uppercase">Avg Latency</span>
                <div className="font-mono-tech text-sm font-bold text-cyan-200">
                  {averageLatencyMs > 0 ? `${averageLatencyMs} ms` : 'Local Instant (<50ms)'}
                </div>
              </div>
            </div>

            <div className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/20 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-cyan-400/70 font-mono-tech uppercase">Core Status</span>
                <div className="font-tech text-sm font-bold text-emerald-400">
                  ALL SYSTEMS NOMINAL
                </div>
              </div>
              <button
                onClick={checkDiagnostics}
                title="Refresh diagnostics"
                className="p-2 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Subsystems Checklist */}
          <div className="space-y-2">
            <div className="text-xs font-tech text-cyan-300 uppercase">Subsystem Telemetry:</div>
            {diagnostics.map((d) => (
              <div
                key={d.name}
                className="p-2.5 rounded-xl bg-gray-950/60 border border-cyan-500/20 flex items-start gap-2.5"
              >
                {d.status === 'operational' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : d.status === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-cyan-200 flex items-center justify-between">
                    <span>{d.name}</span>
                    <span className={`text-[10px] font-mono-tech uppercase ${
                      d.status === 'operational' ? 'text-emerald-400' : 'text-amber-400'
                    }`}>
                      {d.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-cyan-300/80 mt-0.5">{d.message}</div>
                  <div className="text-[10px] text-cyan-400/50 mt-0.5 font-mono-tech">{d.details}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Self-Improvement System Suggestions */}
          <div className="space-y-2">
            <div className="text-xs font-tech text-cyan-300 uppercase flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              JARVIS Self-Improvement Recommendations
            </div>
            {suggestions.map((s, idx) => (
              <div key={idx} className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/20 text-xs space-y-1">
                <div className="font-semibold text-cyan-200">{s.title}</div>
                <div className="text-cyan-300/80 text-[11px] leading-relaxed">{s.tip}</div>
                <div className="text-emerald-400/90 text-[10px] font-mono-tech">Expected benefit: {s.impact}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-300/60 text-center">
          In adherence to Iron Man protocols, JARVIS never modifies code without Sir's explicit verification.
        </div>
      </div>
    </div>
  );
};
