import { ArrowRight, Bolt, Flag, Shield, Steering } from "./Icons";
import { Pill, Reveal, SectionIntro } from "./ui";

const STEPS = [
  {
    number: "01",
    title: "Steer with intent",
    text: "Arrow keys or A / D to slide across the lanes. On touch, drag anywhere on the road — the car follows your finger. Tap the throttle keys to ask for everything the night allows.",
    icon: Steering,
  },
  {
    number: "02",
    title: "Read the traffic",
    text: "Four lanes, mixed speeds. Look two cars ahead, not one. A gap you can see at 200 km/h is a gap you should already be in. Near misses pay plus forty and top up the nitro.",
    icon: Flag,
  },
  {
    number: "03",
    title: "Spend the charge",
    text: "Hold Shift (or the Nitro button) to burn charge. While it lasts you cover fourteen percent more ground and the score climbs with you. Collect glowing hexes to refill.",
    icon: Bolt,
  },
  {
    number: "04",
    title: "Protect the shields",
    text: "Three shields, then the night ends. Every impact costs one and scrubs your speed. Reach every third sector and the crew patches one shield back in.",
    icon: Shield,
  },
];

export function FieldNotes({ onStart }: { onStart: () => void }) {
  return (
    <section id="how-to-play" className="relative scroll-mt-24 border-t border-white/8 py-20 sm:py-28">
      <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
        <SectionIntro
          label="Field notes"
          title={
            <>
              Read the road.
              <br />
              <span className="font-serif font-normal italic text-volt">Own the gaps.</span>
            </>
          }
          copy="No tutorials, no cutscenes. Three controls to learn, one night to master. Here is everything the crew would tell you before you leave the bay."
          aside={
            <Pill tone="ghost">
              <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> Keyboard · touch · gamepad-free
            </Pill>
          }
        />

        <div className="mt-10 grid gap-5 sm:mt-12 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <figure className="group relative h-full min-h-[360px] overflow-hidden rounded-[24px] border border-white/12 bg-ink-800 lg:min-h-[520px]">
              <img
                src="/images/cockpit.jpg"
                alt="Driver's view of the night highway through the windscreen"
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/20 to-ink-950/30" />
              <div className="absolute inset-x-0 top-0 flex flex-wrap items-start justify-between gap-2 p-4">
                <span className="glass rounded-full border border-white/15 px-3 py-1.5 font-mono text-[8px] uppercase tracking-[0.18em] text-bone">
                  The cockpit · 03:12 AM
                </span>
                <span className="glass flex items-center gap-1.5 rounded-full border border-white/15 px-2.5 py-1.5 font-mono text-[8px] uppercase tracking-[0.16em] text-volt">
                  <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> 186 km/h
                </span>
              </div>
              <figcaption className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
                <p className="font-serif text-xl italic text-bone sm:text-2xl">“Brake later. Breathe sooner.”</p>
                <div className="mt-3 grid grid-cols-3 gap-2 border-t border-white/15 pt-3">
                  {[
                    ["Grip", "High"],
                    ["Traffic", "Live"],
                    ["Record", "12,480 m"],
                  ].map(([label, value]) => (
                    <div key={label}>
                      <p className="font-mono text-[7px] uppercase tracking-[0.12em] text-moss-400">{label}</p>
                      <p className="mt-0.5 font-mono text-[10px] text-bone">{value}</p>
                    </div>
                  ))}
                </div>
              </figcaption>
            </figure>
          </Reveal>

          <div className="flex flex-col">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              return (
                <Reveal key={step.number} delay={index * 70}>
                  <div className="group flex gap-4 border-b border-white/8 py-4 first:pt-1 sm:gap-5 sm:py-5">
                    <div className="flex flex-col items-center gap-2">
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/12 bg-white/4 text-moss-300 transition-colors group-hover:border-volt/40 group-hover:bg-volt/10 group-hover:text-volt">
                        <Icon className="h-4 w-4" />
                      </span>
                      <span className="font-mono text-[8px] tracking-[0.12em] text-moss-600">{step.number}</span>
                    </div>
                    <div>
                      <h3 className="text-[15px] font-medium tracking-tight text-bone">{step.title}</h3>
                      <p className="mt-1 text-[12.5px] leading-relaxed text-moss-300">{step.text}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
            <Reveal className="pt-4">
              <button
                type="button"
                onClick={onStart}
                className="group inline-flex items-center gap-2.5 rounded-full bg-volt px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-950 transition hover:bg-volt-bright"
              >
                Put it into practice
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </button>
            </Reveal>
          </div>
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-3">
          <Reveal>
            <div className="h-full rounded-2xl border border-white/10 bg-ink-900/60 p-4 sm:p-5">
              <p className="kicker">The controls</p>
              <dl className="mt-3 space-y-2.5">
                {[
                  { label: "Steer", keys: ["←", "→"], alt: "or A / D" },
                  { label: "Throttle", keys: ["↑"], alt: "brake ↓" },
                  { label: "Nitro", keys: ["shift"], alt: "hold" },
                  { label: "Pause", keys: ["P"], alt: "R restarts" },
                ].map((row) => (
                  <div key={row.label} className="flex items-center justify-between gap-2">
                    <dt className="text-[11.5px] text-moss-300">{row.label}</dt>
                    <dd className="flex items-center gap-1.5">
                      {row.keys.map((key) => (
                        <span key={key} className="keycap">
                          {key}
                        </span>
                      ))}
                      <span className="font-mono text-[8px] uppercase tracking-[0.1em] text-moss-500">{row.alt}</span>
                    </dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 border-t border-white/8 pt-2.5 text-[10.5px] leading-relaxed text-moss-500">
                On mobile, use the arrows under the game and drag the road to steer.
              </p>
            </div>
          </Reveal>

          <Reveal delay={80}>
            <div className="h-full rounded-2xl border border-white/10 bg-ink-900/60 p-4 sm:p-5">
              <p className="kicker">Crew notes</p>
              <ul className="mt-3 space-y-2.5">
                {[
                  "Near miss: +40 pts and +7% nitro.",
                  "Every 750 m is a new sector: +250 pts.",
                  "Third sector patches one shield.",
                  "Nitro covers 14% more ground per second.",
                ].map((tip) => (
                  <li key={tip} className="flex gap-2 text-[11.5px] leading-relaxed text-moss-300">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-volt" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={140}>
            <div className="relative flex h-full flex-col overflow-hidden rounded-2xl border border-volt/20 bg-gradient-to-br from-volt/10 via-ink-900 to-ink-900 p-4 sm:p-5">
              <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-volt/10 blur-2xl" />
              <p className="kicker !text-volt">The only rule</p>
              <p className="mt-3 font-serif text-[22px] italic leading-snug text-bone">
                “There is no finish line. Only the next personal best.”
              </p>
              <div className="mt-auto flex items-center justify-between border-t border-white/10 pt-3 font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">
                <span>Vanta highway division</span>
                <span className="text-volt">Est. 2026</span>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
