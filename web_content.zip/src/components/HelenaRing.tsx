/**
 * HELENA - Green Neon Ring & Ambient Particle Field
 * Centralized in CSS variables:
 * --cor-anel: #0E7A3D
 * --cor-brilho: #17B35A
 * --cor-particula: #2FD16F
 * --cor-texto: #CDEBD8
 * --cor-borda: #14502D
 * 
 * Optimized for mobile:
 * - Dynamic pause when modals or 3D viewer are active (saves 100% GPU)
 * - Capped pixel ratio (1.5 max on mobile)
 * - Tap-to-talk interactive center ring
 * - Respects prefers-reduced-motion and document visibility
 */

import React, { useEffect, useRef, useState } from 'react';
import { RingState } from '../types';

interface HelenaRingProps {
  state: RingState;
  onStateChange?: (newState: RingState) => void;
  subtleStatusText?: string;
  isPaused?: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
}

export const HelenaRing: React.FC<HelenaRingProps> = ({
  state,
  onStateChange,
  subtleStatusText,
  isPaused = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showTester, setShowTester] = useState(false);

  useEffect(() => {
    // If paused because a modal or 3D scene is active, halt canvas rendering
    if (isPaused) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;
    let isTabVisible = !document.hidden;

    // Read colors from CSS variables
    const computedStyle = getComputedStyle(document.documentElement);
    const corAnel = computedStyle.getPropertyValue('--cor-anel').trim() || '#0E7A3D';
    const corBrilho = computedStyle.getPropertyValue('--cor-brilho').trim() || '#17B35A';
    const corParticula = computedStyle.getPropertyValue('--cor-particula').trim() || '#2FD16F';
    const corBorda = computedStyle.getPropertyValue('--cor-borda').trim() || '#14502D';

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const resize = () => {
      // Mobile optimization: cap at 1.5 to save battery and guarantee 60 FPS
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener('resize', resize);

    // Visibility listener to save CPU/battery on mobile
    const handleVisibilityChange = () => {
      isTabVisible = !document.hidden;
      if (isTabVisible && !isPaused) {
        animationFrameId = requestAnimationFrame(render);
      } else {
        cancelAnimationFrame(animationFrameId);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Initialize 28 ambient particles (optimized for smooth mobile performance)
    const particleCount = 28;
    const particles: Particle[] = [];
    const colors = [corParticula, corBrilho, corAnel, '#48E585', '#A7F3C4'];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.8 + 0.8,
        alpha: Math.random() * 0.5 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    const render = () => {
      if (!isTabVisible || isPaused) return;

      time += prefersReducedMotion ? 0.008 : 0.024;
      const width = window.innerWidth;
      const height = window.innerHeight;
      const cx = width / 2;
      const cy = height / 2;

      // Pure black canvas background (#000000)
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      // Mobile adaptive base radius
      const isMobile = width < 640;
      const baseRadius = Math.min(width, height) * (isMobile ? 0.22 : 0.18);
      let currentRadius = baseRadius;
      let glowSpread = 20;
      let ringThickness = isMobile ? 3.4 : 3.8;
      let waveAmplitude = 0;
      let waveSpeed = 1;

      if (state === 'repouso') {
        const breath = Math.sin(time * 1.2);
        currentRadius = baseRadius + breath * 3.5;
        glowSpread = 16 + breath * 5;
      } else if (state === 'ouvindo') {
        const pulse = Math.abs(Math.sin(time * 3.5));
        currentRadius = baseRadius + pulse * 12;
        glowSpread = 32 + pulse * 16;
        ringThickness = 4.4;
      } else if (state === 'pensando') {
        currentRadius = baseRadius;
        waveAmplitude = 6;
        waveSpeed = 3.0;
        glowSpread = 25;
      } else if (state === 'falando') {
        const vocal = Math.sin(time * 6) * Math.cos(time * 2.5);
        currentRadius = baseRadius + vocal * 9;
        waveAmplitude = 4 + Math.abs(vocal) * 5;
        waveSpeed = 4.5;
        glowSpread = 28 + Math.abs(vocal) * 12;
      }

      // 1. Draw particles & delicate connector lines
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        if (state === 'ouvindo') {
          const dx = cx - p.x;
          const dy = cy - p.y;
          const dist = Math.hypot(dx, dy);
          if (dist > currentRadius + 15) {
            p.x += (dx / dist) * 1.2;
            p.y += (dy / dist) * 1.2;
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 75) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = corBorda;
            ctx.globalAlpha = (1 - dist / 75) * 0.2;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1;

      // 2. Render Neon Ring Structure
      ctx.save();
      ctx.translate(cx, cy);

      const segments = 120;
      const points: { x: number; y: number }[] = [];

      for (let i = 0; i < segments; i++) {
        const angle = (i / segments) * Math.PI * 2;
        let r = currentRadius;

        if (waveAmplitude > 0) {
          const wave = Math.sin(angle * 6 + time * waveSpeed) + Math.cos(angle * 3 - time * 2);
          r += wave * waveAmplitude;
        }

        points.push({
          x: Math.cos(angle) * r,
          y: Math.sin(angle) * r,
        });
      }

      const drawRingPath = () => {
        ctx.beginPath();
        if (points.length > 0) {
          ctx.moveTo(points[0].x, points[0].y);
          for (let i = 1; i < points.length; i++) {
            ctx.lineTo(points[i].x, points[i].y);
          }
          ctx.closePath();
        }
      };

      // Layer 1: Wide Outer Aura
      ctx.shadowColor = corAnel;
      ctx.shadowBlur = glowSpread * 1.5;
      ctx.strokeStyle = corAnel;
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = ringThickness * 2.5;
      drawRingPath();
      ctx.stroke();

      // Layer 2: Vivid Green Glow
      ctx.shadowColor = corBrilho;
      ctx.shadowBlur = glowSpread;
      ctx.strokeStyle = corBrilho;
      ctx.globalAlpha = 0.9;
      ctx.lineWidth = ringThickness * 1.4;
      drawRingPath();
      ctx.stroke();

      // Layer 3: Intense Core Ring
      ctx.shadowColor = '#ffffff';
      ctx.shadowBlur = 8;
      ctx.strokeStyle = '#E8FDF0';
      ctx.globalAlpha = 1.0;
      ctx.lineWidth = ringThickness * 0.7;
      drawRingPath();
      ctx.stroke();

      // 3. Keep Center Interior Deep Black & Void
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(1, currentRadius - ringThickness * 2.5), 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();

      // Orbiting energy spark in 'pensando' state
      if (state === 'pensando') {
        const sparkAngle = time * 2.5;
        const sx = Math.cos(sparkAngle) * currentRadius;
        const sy = Math.sin(sparkAngle) * currentRadius;
        ctx.beginPath();
        ctx.arc(sx, sy, 4.0, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = corParticula;
        ctx.shadowBlur = 14;
        ctx.fill();
      }

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [state, isPaused]);

  return (
    <div className="relative w-full h-full bg-black overflow-hidden flex items-center justify-center">
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 block w-full h-full pointer-events-none" 
      />

      {/* Subtle status text when processing */}
      {subtleStatusText && (
        <div className="absolute bottom-24 z-10 text-center pointer-events-none px-4 max-w-sm">
          <p className="text-xs font-mono text-[#CDEBD8]/90 tracking-widest uppercase">
            {subtleStatusText}
          </p>
        </div>
      )}

      {/* Hidden / Discreet Test Selector */}
      <div className="absolute bottom-3 left-3 z-30 opacity-20 hover:opacity-100 transition-opacity">
        {showTester ? (
          <div className="bg-black/95 border border-[#14502D] rounded-xl p-2.5 flex flex-col space-y-1.5 shadow-2xl backdrop-blur-md">
            <span className="text-[10px] text-[#2FD16F] font-mono uppercase tracking-wider mb-1">
              Estado do Anel
            </span>
            {(['repouso', 'ouvindo', 'pensando', 'falando'] as RingState[]).map((st) => (
              <button
                key={st}
                onClick={() => onStateChange?.(st)}
                className={`text-[11px] px-2.5 py-1 rounded text-left transition-colors min-h-[36px] ${
                  state === st
                    ? 'bg-[#0E7A3D]/40 text-[#CDEBD8] font-semibold border border-[#17B35A]/50'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                ● {st}
              </button>
            ))}
            <button
              onClick={() => setShowTester(false)}
              className="text-[10px] text-zinc-500 hover:text-zinc-300 pt-1"
            >
              Fechar
            </button>
          </div>
        ) : (
          <button
            onClick={() => setShowTester(true)}
            className="text-[10px] font-mono text-[#2FD16F]/60 hover:text-[#2FD16F] px-2.5 py-1.5 bg-black/80 border border-[#14502D] rounded min-h-[36px] flex items-center"
            title="Seletor de estado do anel"
          >
            ● {state}
          </button>
        )}
      </div>
    </div>
  );
};
