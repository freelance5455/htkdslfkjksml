import React, { useState, useRef } from 'react';
import { Upload, X, FileText, Check, AlertCircle, Send } from 'lucide-react';
import { FileAttachment } from '../types';

interface FileUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFileAnalyzed: (prompt: string, fileData: FileAttachment) => void;
}

export const FileUploadModal: React.FC<FileUploadModalProps> = ({
  isOpen,
  onClose,
  onFileAnalyzed,
}) => {
  const [selectedFile, setSelectedFile] = useState<FileAttachment | null>(null);
  const [queryPrompt, setQueryPrompt] = useState('Bu faylın məzmununu xülasə et və əsas məqamları çıxart.');
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    processFile(file);
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      setSelectedFile({
        name: file.name,
        size: file.size,
        type: file.type,
        text: text,
      });
    };
    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = () => {
    setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleSubmit = () => {
    if (!selectedFile) return;
    onFileAnalyzed(queryPrompt, selectedFile);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-zinc-900 border border-amber-500/30 w-full max-w-md rounded-2xl p-5 space-y-4 relative shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <Upload className="w-5 h-5 text-amber-400" />
          <h3 className="text-sm font-bold text-amber-200">Fayl və Mətn Analizi</h3>
        </div>

        {/* Drag Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition ${
            dragActive
              ? 'border-amber-400 bg-amber-500/10'
              : 'border-zinc-700 bg-zinc-950/60 hover:border-amber-500/50'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".txt,.md,.json,.js,.ts,.py,.html,.css,.csv"
            className="hidden"
          />

          <FileText className="w-8 h-8 text-amber-400 mx-auto mb-2" />
          <p className="text-xs font-semibold text-zinc-200">
            Faylı sürüşdürüb bura atın və ya seçin
          </p>
          <p className="text-[10px] text-zinc-500 mt-1">
            TXT, MD, Code (.js, .py, .ts, .json, .html), CSV və s.
          </p>
        </div>

        {/* File Preview */}
        {selectedFile && (
          <div className="p-3 bg-zinc-950 border border-amber-500/40 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 overflow-hidden">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="truncate">
                <p className="font-semibold text-amber-300 truncate">{selectedFile.name}</p>
                <p className="text-[10px] text-zinc-500">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedFile(null)}
              className="text-zinc-500 hover:text-rose-400"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Query Prompt */}
        <div>
          <label className="text-[11px] font-medium text-zinc-400 block mb-1">
            AI-a Tapşırıq (Sual / Analiz)
          </label>
          <textarea
            value={queryPrompt}
            onChange={(e) => setQueryPrompt(e.target.value)}
            rows={2}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-zinc-100 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Action Button */}
        <button
          onClick={handleSubmit}
          disabled={!selectedFile}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 disabled:opacity-40 hover:brightness-110 transition"
        >
          <Send className="w-4 h-4" />
          <span>Faylı SM AI-a Göndər & Analiz Et</span>
        </button>
      </div>
    </div>
  );
};
