import React, { useMemo, useRef, useState } from 'react';
import { CalendarPlus, Music, Search, X } from 'lucide-react';
import type { AlarmSlot, Language } from '../types/study';
import { AlarmVectorIcon, ShieldWaveIcon, SoundWaveIcon } from './LiquidIcons';

interface AlarmsManagerProps {
  lang: Language;
  alarms: AlarmSlot[];
  sleepModeEnabled: boolean;
  ringtoneName: string | null;
  onToggleSleepMode: () => void;
  onSelectPhoneRingtone: (file: File) => void;
  onClearPhoneRingtone: () => void;
  onExportToPhone: (alarm: AlarmSlot) => void;
  onUpdateAlarm: (id: number, patch: Partial<AlarmSlot>) => void;
  onTestAlarm: (alarm: AlarmSlot) => void;
  onDisableAll: () => void;
}

export const AlarmsManager: React.FC<AlarmsManagerProps> = ({
  lang,
  alarms,
  sleepModeEnabled,
  ringtoneName,
  onToggleSleepMode,
  onSelectPhoneRingtone,
  onClearPhoneRingtone,
  onExportToPhone,
  onUpdateAlarm,
  onTestAlarm,
  onDisableAll,
}) => {
  const isBn = lang === 'bn';
  const [filterMode, setFilterMode] = useState<'all' | 'active'>('all');
  const [search, setSearch] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const activeCount = useMemo(() => alarms.filter((a) => a.enabled).length, [alarms]);

  const visibleAlarms = useMemo(() => {
    const q = search.trim().toLowerCase();
    return alarms.filter((alarm) => {
      if (filterMode === 'active' && !alarm.enabled) return false;
      if (!q) return true;
      return (
        alarm.name.toLowerCase().includes(q) ||
        alarm.time.includes(q) ||
        String(alarm.id).includes(q)
      );
    });
  }, [alarms, filterMode, search]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onSelectPhoneRingtone(file);
    }
    e.target.value = '';
  };

  return (
    <section className="liquid-glass rounded-3xl p-5 sm:p-6">
      {/* Header Toolbar */}
      <div className="flex flex-col gap-4 border-b border-white/12 pb-5 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-sky-300/30 bg-sky-400/15 text-sky-200">
            <AlarmVectorIcon active className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">
              {isBn ? '২০টি অ্যালার্ম' : '20 Alarms'}
            </h2>
            <p className="mt-0.5 text-xs text-slate-300 tabular-nums">
              {isBn ? `সক্রিয়: ${activeCount}` : `Active: ${activeCount}`}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl border border-white/15 bg-white/5 p-1">
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap ${
                filterMode === 'all'
                  ? 'bg-white text-slate-950'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isBn ? 'সব (২০)' : 'All (20)'}
            </button>
            <button
              type="button"
              onClick={() => setFilterMode('active')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap ${
                filterMode === 'active'
                  ? 'bg-white text-slate-950'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isBn ? `সক্রিয় (${activeCount})` : `Active (${activeCount})`}
            </button>
          </div>

          {activeCount > 0 && (
            <button
              type="button"
              onClick={onDisableAll}
              className="min-h-[40px] rounded-xl border border-white/20 bg-white/10 px-3.5 py-2 text-xs font-medium text-slate-100 transition hover:bg-white/20 whitespace-nowrap"
            >
              {isBn ? 'সব বন্ধ' : 'Disable All'}
            </button>
          )}
        </div>
      </div>

      {/* Sleep-Mode Guard + Phone Ringtone Picker Bar (Clean Option Names Only) */}
      <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        <button
          type="button"
          onClick={onToggleSleepMode}
          className={`flex min-h-[48px] items-center justify-between gap-3 rounded-2xl px-4 py-2.5 text-left ${
            sleepModeEnabled ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
          }`}
        >
          <span className="flex items-center gap-2.5 text-xs font-semibold text-white">
            <ShieldWaveIcon active={sleepModeEnabled} className="h-4 w-4 text-sky-300" />
            <span>{isBn ? 'স্লিপ-মোড অ্যালার্ম' : 'Sleep-Mode Alarm'}</span>
          </span>
          <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
            {sleepModeEnabled ? (isBn ? 'চালু' : 'On') : isBn ? 'বন্ধ' : 'Off'}
          </span>
        </button>

        <div className="liquid-glass-tile flex min-h-[48px] items-center justify-between gap-2 rounded-2xl px-4 py-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
          >
            <Music className="h-4 w-4 shrink-0 text-sky-300" aria-hidden="true" />
            <span className="truncate text-xs font-semibold text-white">
              {ringtoneName
                ? ringtoneName
                : isBn
                  ? 'ফোনের রিংটোন নিন'
                  : 'Phone Ringtone'}
            </span>
          </button>

          {ringtoneName ? (
            <button
              type="button"
              onClick={onClearPhoneRingtone}
              aria-label={isBn ? 'ডিফল্ট রিংটোন' : 'Reset ringtone'}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-300 hover:bg-white/15 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="rounded-lg bg-white/12 px-2.5 py-1 text-[11px] font-semibold text-sky-200 hover:bg-white/20 whitespace-nowrap shrink-0"
            >
              {isBn ? 'বাছাই' : 'Pick'}
            </button>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="relative mt-4">
        <Search
          className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
          aria-hidden="true"
        />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isBn ? 'খুঁজুন...' : 'Search...'}
          className="glass-input w-full min-h-[44px] rounded-xl pl-10 pr-4 text-sm"
        />
      </div>

      {/* 20 Alarm Slots Grid */}
      {visibleAlarms.length === 0 ? (
        <div className="py-12 text-center">
          <AlarmVectorIcon className="mx-auto h-9 w-9 text-slate-400" />
          <p className="mt-3 text-sm font-medium text-slate-200">
            {isBn ? 'কোনো অ্যালার্ম নেই' : 'No alarms'}
          </p>
        </div>
      ) : (
        <div className="mt-5 grid grid-cols-1 gap-3.5 lg:grid-cols-2">
          {visibleAlarms.map((alarm) => (
            <div
              key={alarm.id}
              className={`rounded-2xl p-4 ${
                alarm.enabled ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <span className="font-mono-tabular text-xs font-semibold text-slate-300 shrink-0">
                    #{String(alarm.id).padStart(2, '0')}
                  </span>

                  <input
                    type="text"
                    value={alarm.name}
                    aria-label={`Alarm ${alarm.id}`}
                    onChange={(e) => onUpdateAlarm(alarm.id, { name: e.target.value })}
                    placeholder={isBn ? `অ্যালার্ম ${alarm.id}` : `Alarm ${alarm.id}`}
                    maxLength={48}
                    className="glass-input min-w-0 flex-1 min-h-[40px] rounded-xl px-3 text-sm font-medium"
                  />
                </div>

                <button
                  type="button"
                  role="switch"
                  aria-checked={alarm.enabled}
                  aria-label={alarm.name || `Alarm ${alarm.id}`}
                  onClick={() =>
                    onUpdateAlarm(alarm.id, {
                      enabled: !alarm.enabled,
                      lastTriggeredDateKey: undefined,
                    })
                  }
                  className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full border transition ${
                    alarm.enabled
                      ? 'border-sky-300/60 bg-sky-400'
                      : 'border-white/25 bg-white/15'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${
                      alarm.enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <input
                    type="time"
                    value={alarm.time}
                    aria-label={`Time ${alarm.id}`}
                    onChange={(e) =>
                      onUpdateAlarm(alarm.id, {
                        time: e.target.value,
                        lastTriggeredDateKey: undefined,
                      })
                    }
                    className="glass-input font-mono-tabular min-h-[42px] rounded-xl px-3 text-base font-semibold"
                  />

                  <select
                    value={alarm.repeat}
                    aria-label={`Repeat ${alarm.id}`}
                    onChange={(e) =>
                      onUpdateAlarm(alarm.id, {
                        repeat: e.target.value as 'daily' | 'once',
                      })
                    }
                    className="glass-input min-h-[42px] rounded-xl px-2.5 text-xs font-medium"
                  >
                    <option value="daily">{isBn ? 'প্রতিদিন' : 'Daily'}</option>
                    <option value="once">{isBn ? 'একবার' : 'Once'}</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onExportToPhone(alarm)}
                    title={isBn ? 'ফোনের ক্যালেন্ডার/অ্যালার্মে যুক্ত' : 'Add to Phone Calendar'}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-white/18 bg-white/10 px-2.5 py-1.5 text-xs font-medium text-slate-100 transition hover:bg-white/20 whitespace-nowrap"
                  >
                    <CalendarPlus className="h-3.5 w-3.5 text-sky-300" aria-hidden="true" />
                    <span>{isBn ? 'ফোন' : 'Phone'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTestAlarm(alarm)}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-white/18 bg-white/10 px-3 py-1.5 text-xs font-medium text-slate-100 transition hover:bg-white/20 whitespace-nowrap"
                  >
                    <SoundWaveIcon className="h-4 w-4 text-sky-300" />
                    <span>{isBn ? 'টেস্ট' : 'Test'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
