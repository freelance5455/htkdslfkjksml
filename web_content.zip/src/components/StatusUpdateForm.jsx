import { useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { updateReportStatus } from "@/lib/reportActions";
import { STATUSES, statusMeta } from "@/lib/reportStats";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function StatusUpdateForm({ report, onUpdated }) {
  const { user } = useAuth();
  const [status, setStatus] = useState(report.status);
  const [crew, setCrew] = useState(report.assigned_crew || "");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  if (user?.role !== "admin") return null;

  const handleSave = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await updateReportStatus(report, status, {
        note,
        crew,
        authorName: user.full_name || user.email,
      });
      setNote("");
      toast({ title: "Board updated", description: `Marked as ${statusMeta(status).label}.` });
      onUpdated?.();
    } catch (err) {
      toast({
        title: "Couldn't update",
        description: err.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="rounded-2xl border border-border bg-card p-5">
      <p className="font-display text-sm font-semibold">City team update</p>
      <p className="mt-1 text-[11px] text-muted-foreground">
        Visible on the public board as soon as you save.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {STATUSES.map((item) => (
          <button
            key={item.value}
            type="button"
            onClick={() => setStatus(item.value)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs transition-colors",
              status === item.value
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="mt-4 space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="crew" className="text-xs">Crew / team on it</Label>
          <Input
            id="crew"
            value={crew}
            onChange={(e) => setCrew(e.target.value)}
            placeholder="Zone 4 sanitation crew"
            className="h-10 rounded-xl text-sm"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="note" className="text-xs">Note for residents</Label>
          <Textarea
            id="note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Debris cleared, bin replaced this morning."
            rows={3}
            className="rounded-xl text-sm"
          />
        </div>
      </div>

      <Button type="submit" className="mt-4 w-full rounded-full" disabled={saving}>
        {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
        {saving ? "Saving..." : "Publish update"}
      </Button>
      <p className="mt-2 text-center text-[10px] text-muted-foreground">
        Signed in as {user?.email}
      </p>
    </form>
  );
}