import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Users, 
  Send, 
  ArrowLeft 
} from 'lucide-react';

export const ChatRoomsView: React.FC = () => {
  const { chatRooms, sendChatMessage, user, setActiveTab } = useApp();
  const [selectedRoomId, setSelectedRoomId] = useState<string>(chatRooms[0]?.id || '');
  const [inputText, setInputText] = useState('');

  const currentRoom = chatRooms.find(r => r.id === selectedRoomId) || chatRooms[0];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendChatMessage(currentRoom.id, inputText);
    setInputText('');
  };

  return (
    <div className="space-y-4 pb-20">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>
      
      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-indigo-950/30 to-slate-900 border border-cyan-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-semibold mb-1">
            <Users className="w-3.5 h-3.5" />
            <span>Anonymous Sanctuaries</span>
          </div>
          <h2 className="font-display font-black text-lg sm:text-xl text-slate-100">
            Live Whispers Rooms
          </h2>
          <p className="text-xs text-slate-400">
            Real-time multi-peer chatrooms with masked personas.
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-cyan-900/40 border border-cyan-500/40 flex items-center justify-center text-2xl shadow-lg neon-glow-cyan">
          💬
        </div>
      </div>

      {/* Horizontal Room Switcher Carousel */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {chatRooms.map(room => {
          const isSelected = room.id === currentRoom.id;
          return (
            <button
              key={room.id}
              onClick={() => setSelectedRoomId(room.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold whitespace-nowrap transition-all shrink-0 ${
                isSelected 
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 shadow-sm shadow-cyan-500/20' 
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{room.icon}</span>
              <span>{room.name}</span>
              <span className="text-[10px] text-slate-500 font-mono">({room.activeCount})</span>
            </button>
          );
        })}
      </div>

      {/* Active Room Chat Container */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl flex flex-col h-[520px] overflow-hidden">
        
        {/* Room Header */}
        <div className="p-3.5 border-b border-slate-800/80 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">{currentRoom.icon}</span>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-semibold text-sm text-slate-100">
                  {currentRoom.name}
                </h3>
                <span className="text-[11px] font-mono text-cyan-400">
                  {currentRoom.tag}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1">
                {currentRoom.description}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded-full shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-mono">{currentRoom.activeCount} online</span>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0a0c14]/60">
          <div className="text-center py-2">
            <span className="text-[10px] text-slate-500 font-mono bg-slate-900/80 px-2.5 py-1 rounded-full border border-slate-800">
              End-to-End Masked Encryption • Real identities never logged
            </span>
          </div>

          {currentRoom.messages.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              Be the first to say something in {currentRoom.name}!
            </div>
          ) : (
            currentRoom.messages.map(msg => (
              <div 
                key={msg.id}
                className={`flex items-start gap-2.5 ${msg.isOwn ? 'flex-row-reverse' : ''}`}
              >
                <div className="w-8 h-8 rounded-full bg-slate-800/90 border border-slate-700 flex items-center justify-center text-sm shrink-0">
                  {msg.senderEmoji}
                </div>
                <div className={`max-w-[78%] rounded-2xl p-3 text-xs ${
                  msg.isOwn 
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-none' 
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}>
                  <div className={`flex items-center gap-1.5 text-[10px] mb-1 ${msg.isOwn ? 'text-cyan-200 justify-end' : 'text-slate-400'}`}>
                    <span className="font-semibold">{msg.senderName}</span>
                    <span aria-hidden="true">•</span>
                    <span>{msg.timestamp}</span>
                  </div>
                  <p className="leading-relaxed font-sans">{msg.text}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800/80 bg-slate-950/80 flex items-center gap-2">
          <div className="flex items-center gap-1 pl-1 text-sm text-cyan-400 shrink-0">
            <span>{user.avatarEmoji}</span>
          </div>
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Whisper in ${currentRoom.tag}...`}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 transition-all shrink-0 active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
