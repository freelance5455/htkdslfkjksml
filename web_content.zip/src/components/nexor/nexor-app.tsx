import { useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from "react";
import {
  Bell,
  Check,
  Download,
  FileBarChart,
  FolderKanban,
  LayoutDashboard,
  ListChecks,
  Mic,
  Plus,
  Send,
  Sprout,
  Square,
  Trash2,
  Upload,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import "sonner/dist/styles.css";
import {
  CHAT_KEY,
  containsSecret,
  fresh,
  localStamp,
  normalizeTr,
  parseAppData,
  parseChat,
  type AppData,
  type ChatMsg,
  type Project,
  type Scale,
  type Task,
  rankTask,
  readStored,
  STORAGE_KEY,
  sweepReminders,
  todayString,
  writeStored,
} from "@/lib/nexor/data";
import {
  applyActions,
  executeCommand,
  importanceLabel,
  priorityLabel,
  resolvePending,
  type Pending,
} from "@/lib/nexor/commands";
import { askNexor, speakNexor } from "@/lib/nexor/chat.functions";
import { buildDataContext, composeReply, parseActions } from "@/lib/nexor/prompt";
import {
  canListen,
  cleanForSpeech,
  playBase64,
  speechErrorMessage,
  speakWithBrowser,
  startListening,
  stopListening,
  stopSpeaking,
  unlockSpeech,
} from "@/lib/nexor/speech";

type TabId = "home" | "projects" | "growth" | "plan" | "reminders" | "report" | "nexor";

const TABS: { id: TabId; label: string; icon?: typeof LayoutDashboard }[] = [
  { id: "home", label: "Genel", icon: LayoutDashboard },
  { id: "projects", label: "Projeler", icon: FolderKanban },
  { id: "growth", label: "Gelişim", icon: Sprout },
  { id: "plan", label: "Görevler", icon: ListChecks },
  { id: "reminders", label: "Hatırlatıcı", icon: Bell },
  { id: "report", label: "Rapor", icon: FileBarChart },
  { id: "nexor", label: "NEXOR" },
];

const inputCls =
  "mt-1 w-full min-h-11 rounded-xl border border-line bg-bg px-3 py-2 text-base text-ink placeholder:text-muted";

function useStored(key: string): string {
  return useSyncExternalStore(
    (cb) => {
      const handler = () => cb();
      window.addEventListener(key, handler);
      window.addEventListener("storage", handler);
      return () => {
        window.removeEventListener(key, handler);
        window.removeEventListener("storage", handler);
      };
    },
    () => localStorage.getItem(key) ?? "",
    () => "",
  );
}

function loadData(): AppData {
  return parseAppData(readStored(STORAGE_KEY));
}

function saveData(data: AppData) {
  writeStored(STORAGE_KEY, JSON.stringify(data));
}

function saveChat(messages: ChatMsg[]) {
  writeStored(CHAT_KEY, JSON.stringify(messages.filter((msg) => !containsSecret(msg.content)).slice(-40)));
}

function download(obj: unknown, name: string) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

function Btn({
  children,
  onClick,
  variant = "primary",
  disabled,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "nexor";
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const look = {
    primary: "bg-gold text-gold-ink",
    ghost: "border border-line bg-surface-2 text-ink",
    danger: "border border-nexor/50 bg-nexor/20 text-danger",
    nexor: "bg-nexor text-ink",
  }[variant];
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${look}`}>
      {children}
    </button>
  );
}

function Card({ children }: { children: ReactNode }) {
  return <section className="rounded-2xl border border-line bg-surface p-4">{children}</section>;
}

function Tag({ level, label }: { level: Scale; label: string }) {
  const look = level === 3 ? "bg-nexor/20 text-danger" : level === 2 ? "bg-gold/15 text-gold" : "bg-surface-2 text-muted";
  return <span className={`rounded-full px-2 py-1 text-xs font-semibold ${look}`}>{label}</span>;
}

function Bar({ pct }: { pct: number }) {
  return (
    <div className="mt-3 h-2 overflow-hidden rounded-full bg-line">
      <div className="h-full rounded-full bg-gold" style={{ width: `${pct}%` }} />
    </div>
  );
}

function Empty({ children }: { children: ReactNode }) {
  return <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">{children}</p>;
}

function Orb({ size = "size-12" }: { size?: string }) {
  return <div className={`nexor-core ${size} shrink-0 rounded-full bg-nexor`} />;
}

export function NexorApp() {
  const raw = useStored(STORAGE_KEY);
  const chatRaw = useStored(CHAT_KEY);
  const data = useMemo(() => parseAppData(raw), [raw]);
  const chat = useMemo(() => parseChat(chatRaw), [chatRaw]);
  const [tab, setTab] = useState<TabId>("home");
  const [now, setNow] = useState<Date | null>(null);
  const [status, setStatus] = useState("");
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [listening, setListening] = useState(false);
  const [pending, setPending] = useState<Pending | null>(null);
  const [projectOpen, setProjectOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [pName, setPName] = useState("");
  const [pDesc, setPDesc] = useState("");
  const [pImportance, setPImportance] = useState<Scale>(3);
  const [pDate, setPDate] = useState("");
  const [tName, setTName] = useState("");
  const [tProject, setTProject] = useState("");
  const [tPriority, setTPriority] = useState<Scale>(3);
  const [tDate, setTDate] = useState("");
  const [gName, setGName] = useState("");
  const [gAction, setGAction] = useState("");
  const [rTitle, setRTitle] = useState("");
  const [rWhen, setRWhen] = useState("");
  const [rRepeat, setRRepeat] = useState<"once" | "daily">("once");
  const [rLink, setRLink] = useState<"general" | "task" | "project">("general");
  const [rLinked, setRLinked] = useState("");
  const [modal, setModal] = useState<null | { title: string; body: string; confirmLabel: string; danger?: boolean; onConfirm: () => void }>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const chatRef = useRef<HTMLDivElement>(null);
  const sendingRef = useRef(false);
  const voiceSession = useRef(false);
  const pendingRef = useRef<Pending | null>(null);
  const stickyStatus = useRef(false);

  useEffect(() => {
    pendingRef.current = pending;
  }, [pending]);

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const synth = window.speechSynthesis;
    synth?.getVoices();
    const load = () => synth?.getVoices();
    synth?.addEventListener("voiceschanged", load);
    return () => synth?.removeEventListener("voiceschanged", load);
  }, []);

  useEffect(() => {
    const check = () => {
      const current = loadData();
      const swept = sweepReminders(current, Date.now());
      if (!swept.fired.length) return;
      saveData(swept.data);
      for (const title of swept.fired) {
        toast("Hatırlatıcı", { description: title });
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          try {
            new Notification("Nexor", { body: title, tag: title });
          } catch {
            /* ignore */
          }
        }
      }
    };
    check();
    const id = window.setInterval(check, 15_000);
    const onVis = () => {
      if (!document.hidden) check();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [raw]);

  useEffect(() => {
    if (tab === "nexor") chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight });
  }, [tab, chat, pending]);

  const today = now ? todayString(now) : "";
  const openTasks = data.tasks.filter((task) => !task.done).sort((a, b) => rankTask(b, today) - rankTask(a, today));
  const doneTasks = data.tasks.filter((task) => task.done);

function run(cmd: unknown): boolean {
    const current = loadData();
    const res = executeCommand(current, cmd, { now: new Date() });
    if (res.needsConfirm && res.confirmData) {
      const confirmData = res.confirmData;
      setModal({
        title: "Onay gerekli",
        body: res.error,
        confirmLabel: "Evet, sil",
        danger: true,
        onConfirm: () => {
          const done = executeCommand(loadData(), confirmData, { bypassConfirm: true, now: new Date() });
          if (done.ok) saveData(done.data);
          else toast.error(done.error);
          setModal(null);
        },
      });
      return false;
    }
    if (!res.ok) {
      toast.error(res.error);
      return false;
    }
    saveData(res.data);
    return true;
  }

  async function voiceOut(text: string) {
    const cleaned = cleanForSpeech(text);
    if (!cleaned) return;
    const spoken = await speakWithBrowser(cleaned);
    if (spoken) return;
    try {
      const audio = await speakNexor({ data: { text: cleaned } });
      if (audio.ok) await playBase64(audio.audio, audio.mime);
    } catch {
      /* voice is optional */
    }
  }

  function pushChat(extra: ChatMsg[]) {
    saveChat([...parseChat(readStored(CHAT_KEY)), ...extra]);
  }

  async function finish(fromVoice: boolean, reply: string, nextPending: Pending | null) {
    if (fromVoice) voiceSession.current = true;
    if (voiceSession.current) await voiceOut(reply);
    if (!nextPending) voiceSession.current = false;
  }

  async function send(text: string, fromVoice: boolean) {
    const trimmed = text.trim();
    if (!trimmed) return;
    if (sendingRef.current) {
      setInput(trimmed);
      stickyStatus.current = true;
      setStatus("Önceki yanıt bitmeden bu mesaj gönderilmedi.");
      return;
    }
    if (containsSecret(trimmed)) {
      setInput("");
      pushChat([{ role: "err", content: "Mesajda bir API anahtarı vardı. Gönderilmedi. Anahtar bu uygulamada istenmez." }]);
      return;
    }
    if (!fromVoice) voiceSession.current = false;
    setInput("");
    const active = pendingRef.current;
    const norm = normalizeTr(trimmed);
    if (active?.kind === "confirm" && ["evet", "onayla", "onaylıyorum", "onayliyorum", "tamam"].includes(norm)) {
      pushChat([{ role: "user", content: trimmed }]);
      const result = resolvePending(loadData(), active, undefined, new Date());
      if (result.data !== loadData()) saveData(result.data);
      setPending(result.pending);
      const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
      pushChat([
        ...result.logs.map((log) => ({ role: log.level === "ok" ? ("log" as const) : ("err" as const), content: log.text })),
        { role: "nexor", content: reply },
      ]);
      await finish(fromVoice, reply, result.pending);
      return;
    }
    if (active?.kind === "confirm" && ["hayır", "hayir", "iptal", "vazgeç", "vazgec"].includes(norm)) {
      pushChat([
        { role: "user", content: trimmed },
        { role: "nexor", content: "İşlem iptal edildi. Kayıtlar değişmedi." },
      ]);
      setPending(null);
      await finish(fromVoice, "İşlem iptal edildi. Kayıtlar değişmedi.", null);
      return;
    }
    if (active?.kind === "select") {
      const exact = active.candidates.filter((item) => normalizeTr(item.label) === norm);
      if (exact.length === 1 && exact[0]) {
        pushChat([{ role: "user", content: trimmed }]);
        const result = resolvePending(loadData(), active, exact[0].id, new Date());
        saveData(result.data);
        setPending(result.pending);
        const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
        pushChat([
          ...result.logs.map((log) => ({ role: log.level === "ok" ? ("log" as const) : ("err" as const), content: log.text })),
          { role: "nexor", content: reply },
        ]);
        await finish(fromVoice, reply, result.pending);
        return;
      }
    }

    sendingRef.current = true;
    setSending(true);
    stickyStatus.current = true;
    setStatus("NEXOR analiz ediyor…");
    pushChat([{ role: "user", content: trimmed }]);
    const history = parseChat(readStored(CHAT_KEY))
      .filter((msg) => msg.role === "user" || msg.role === "nexor")
      .slice(-12)
      .map((msg) => ({ role: msg.role === "nexor" ? ("assistant" as const) : ("user" as const), content: msg.content }));
    const deviceNow = new Date();
    try {
      const res = await askNexor({
        data: {
          messages: history,
          dataContext: buildDataContext(loadData(), deviceNow),
          nowLocal: localStamp(deviceNow),
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "yerel",
        },
      });
      if (!res.ok) throw new Error(res.error);
      const parsed = parseActions(res.text);
      const applied = applyActions(loadData(), parsed.cmds, deviceNow);
      if (JSON.stringify(applied.data) !== JSON.stringify(loadData())) saveData(applied.data);
      setPending(applied.pending);
      const reply = composeReply(parsed.clean, applied.summaries, [...parsed.errors, ...applied.errors], applied.pending?.error);
      pushChat([
        ...applied.logs.map((log) => ({ role: log.level === "ok" ? ("log" as const) : ("err" as const), content: log.text })),
        { role: "nexor", content: reply },
      ]);
      setStatus("");
      await finish(fromVoice, reply, applied.pending);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Bağlantı hatası.";
      pushChat([
        { role: "err", content: message },
        { role: "nexor", content: "Yanıt alınamadı. Biraz sonra yeniden dene." },
      ]);
      setStatus(message);
      await finish(fromVoice, "Yanıt alınamadı. Biraz sonra yeniden dene.", null);
    } finally {
      sendingRef.current = false;
      setSending(false);
    }
  }

  function toggleVoice() {
    if (!canListen()) {
      setStatus("Bu tarayıcı ses tanımayı desteklemiyor.");
      return;
    }
    if (listening) {
      stopListening();
      return;
    }
    unlockSpeech();
    stopSpeaking();
    try {
      startListening({
        onStart: () => {
          stickyStatus.current = false;
          setListening(true);
          setStatus("Dinliyorum…");
        },
        onEnd: () => {
          setListening(false);
          if (!stickyStatus.current) setStatus("");
        },
        onError: (code) => {
          setListening(false);
          const message = speechErrorMessage(code);
          if (!message) return;
          stickyStatus.current = true;
          setStatus(message);
        },
        onText: (text) => {
          stickyStatus.current = true;
          setStatus("NEXOR analiz ediyor…");
          void send(text, true);
        },
      });
    } catch {
      setListening(false);
      setStatus("Mikrofon şu an meşgul. Tekrar dene.");
    }
  }

  function choose(id: string) {
    const active = pendingRef.current;
    if (!active || active.kind !== "select") return;
    const result = resolvePending(loadData(), active, id, new Date());
    saveData(result.data);
    setPending(result.pending);
    const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
    pushChat([
      ...result.logs.map((log) => ({ role: log.level === "ok" ? ("log" as const) : ("err" as const), content: log.text })),
      { role: "nexor", content: reply },
    ]);
    void finish(voiceSession.current, reply, result.pending);
  }

  function confirmChat() {
    const active = pendingRef.current;
    if (!active || active.kind !== "confirm") return;
    const result = resolvePending(loadData(), active, undefined, new Date());
    saveData(result.data);
    setPending(result.pending);
    const reply = composeReply("", result.summaries, result.errors, result.pending?.error);
    pushChat([
      ...result.logs.map((log) => ({ role: log.level === "ok" ? ("log" as const) : ("err" as const), content: log.text })),
      { role: "nexor", content: reply },
    ]);
    void finish(voiceSession.current, reply, result.pending);
  }

  function cancelChat() {
    setPending(null);
    const reply = "İşlem iptal edildi. Kayıtlar değişmedi.";
    pushChat([{ role: "nexor", content: reply }]);
    void finish(voiceSession.current, reply, null);
  }

  const linkItems = rLink === "task" ? data.tasks.filter((task) => !task.done) : rLink === "project" ? data.projects.filter((project) => !project.done) : [];

  return (
    <div className={tab === "nexor" ? "mx-auto flex h-dvh max-w-3xl flex-col overflow-hidden px-4" : "mx-auto flex min-h-dvh max-w-3xl flex-col px-4"}>
      <Toaster theme="dark" position="top-center" toastOptions={{ style: { background: "var(--color-surface)", color: "var(--color-ink)", border: "1px solid var(--color-line)" } }} />
      <header className="shrink-0 pt-5 pb-2">
        <div className="flex items-center gap-3">
          <Orb size="size-11" />
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-wide">Nexor</h1>
            <p className="text-sm text-muted">Fikirlerini tamamla, kendini geliştir.</p>
          </div>
        </div>
        <p className="mt-2 text-xs text-gold tabular-nums">
          {now
            ? `Cihaz saati: ${new Intl.DateTimeFormat("tr-TR", { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" }).format(now)}`
            : "Cihaz saati alınıyor…"}
        </p>
      </header>
      <nav className="sticky top-0 z-10 -mx-4 flex shrink-0 gap-2 overflow-x-auto bg-bg/90 px-4 py-2 backdrop-blur">
        {TABS.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          const accent = item.id === "nexor";
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border px-3 text-sm font-semibold ${active ? (accent ? "border-nexor text-nexor" : "border-gold text-gold") : accent ? "border-nexor/40 text-nexor" : "border-line bg-surface text-muted"}`}
            >
              {accent || !Icon ? <span className="nexor-core size-2.5 rounded-full bg-nexor" /> : <Icon className="size-4" aria-hidden />}
              {item.label}
            </button>
          );
        })}
      </nav>
      <main className={tab === "nexor" ? "flex min-h-0 flex-1 flex-col pb-safe" : "flex flex-col gap-3 py-3 pb-safe"}>
        {tab === "home" && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Card><p className="text-xs text-muted">Aktif proje</p><p className="font-display text-3xl text-gold">{data.projects.filter((p) => !p.done).length}</p></Card>
              <Card><p className="text-xs text-muted">Tamamlanan görev</p><p className="font-display text-3xl text-gold">{doneTasks.length}</p></Card>
              <Card><p className="text-xs text-muted">Açık görev</p><p className="font-display text-3xl text-gold">{openTasks.length}</p></Card>
              <Card><p className="text-xs text-muted">Biten proje</p><p className="font-display text-3xl text-gold">{data.projects.filter((p) => p.done).length}</p></Card>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <h2 className="font-display text-lg">Bugünün odağı</h2>
              <span className="text-xs text-muted">Öncelik sırası</span>
            </div>
            {openTasks.length === 0 ? <Empty>Öncelikli görev yok. Bir görev ekleyebilirsin.</Empty> : openTasks.slice(0, 3).map((task) => <TaskRow key={task.id} task={task} data={data} today={today} onRun={run} />)}
            <div className="mt-2 flex items-center justify-between">
              <h2 className="font-display text-lg">Projelerde ilerleme</h2>
              <Btn variant="ghost" onClick={() => setTab("projects")}>Tümünü gör</Btn>
            </div>
            {data.projects.length === 0 ? <Empty>Henüz proje eklemedin.</Empty> : data.projects.slice(0, 4).map((project) => <ProjectRow key={project.id} project={project} data={data} onRun={run} />)}
          </>
        )}
        {tab === "projects" && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg">Projelerim</h2>
              <Btn onClick={() => { setProjectOpen((v) => !v); if (!pDate && now) setPDate(todayString(now)); }}><Plus className="size-4" /> Proje ekle</Btn>
            </div>
            {projectOpen && (
              <Card>
                <h3 className="font-semibold">Yeni proje</h3>
                <label className="mt-2 block text-xs text-muted">Proje adı<input className={inputCls} value={pName} onChange={(e) => setPName(e.target.value)} placeholder="Örn. Kişisel uygulamam" /></label>
                <label className="mt-2 block text-xs text-muted">Açıklama<textarea className={inputCls} value={pDesc} onChange={(e) => setPDesc(e.target.value)} placeholder="Bu projede ne yapmak istiyorsun?" /></label>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="text-xs text-muted">Önem
                    <select className={inputCls} value={pImportance} onChange={(e) => setPImportance(Number(e.target.value) as Scale)}>
                      <option value={3}>Çok önemli</option><option value={2}>Önemli</option><option value={1}>Daha sonra</option>
                    </select>
                  </label>
                  <label className="text-xs text-muted">Son tarih<input className={inputCls} type="date" value={pDate} onChange={(e) => setPDate(e.target.value)} /></label>
                </div>
                <div className="mt-3 flex gap-2">
                  <Btn onClick={() => { if (!run({ type: "add_project", name: pName, desc: pDesc, importance: pImportance, date: pDate })) return; setPName(""); setPDesc(""); setPDate(""); setProjectOpen(false); }}>Kaydet</Btn>
                  <Btn variant="ghost" onClick={() => setProjectOpen(false)}>Vazgeç</Btn>
                </div>
              </Card>
            )}
            {data.projects.length === 0 ? <Empty>İlk projen burada görünecek.</Empty> : [...data.projects].sort((a, b) => b.importance - a.importance).map((project) => <ProjectRow key={project.id} project={project} data={data} onRun={run} />)}
          </>
        )}
        {tab === "growth" && (
          <>
            <h2 className="font-display text-lg">Gelişim alanlarım</h2>
            <p className="text-sm text-muted">Bunlar kesin etiket değil; üzerinde çalışılabilecek başlıklar.</p>
            {data.growth.length === 0 ? <Empty>Henüz gelişim alanı yok.</Empty> : data.growth.map((item) => (
              <Card key={item.id}>
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-semibold">{item.name}</h3>
                  <label className="flex items-center gap-2 text-sm text-muted"><input className="size-5 accent-gold" type="checkbox" checked={item.done} onChange={() => run({ type: "edit_growth", id: item.id, done: !item.done })} /> Tamam</label>
                </div>
                <p className="mt-1 text-sm text-muted">{item.action || "Adım belirtilmemiş."}</p>
                <Bar pct={item.progress} />
                <div className="mt-2 flex items-center justify-between gap-2">
                  <span className="text-xs text-muted">İlerleme %{item.progress}</span>
                  <div className="flex gap-2">
                    <Btn variant="ghost" onClick={() => run({ type: "update_growth_progress", id: item.id, progress: Math.min(100, item.progress + 25) })}>+%25</Btn>
                    <Btn variant="danger" onClick={() => run({ type: "delete_growth", id: item.id })}>Sil</Btn>
                  </div>
                </div>
              </Card>
            ))}
            <Card>
              <h3 className="font-semibold">Yeni gelişim alanı</h3>
              <input className={inputCls} value={gName} onChange={(e) => setGName(e.target.value)} placeholder="Örn. Düzenli tekrar" />
              <textarea className={inputCls} value={gAction} onChange={(e) => setGAction(e.target.value)} placeholder="Bunun için atacağım küçük adım" />
              <div className="mt-2"><Btn onClick={() => { if (!run({ type: "add_growth", name: gName, action: gAction })) return; setGName(""); setGAction(""); }}>Ekle</Btn></div>
            </Card>
          </>
        )}
        {tab === "plan" && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg">Görevler</h2>
              <Btn onClick={() => { setTaskOpen((v) => !v); if (!tDate && now) setTDate(todayString(now)); }}><Plus className="size-4" /> Görev ekle</Btn>
            </div>
            {taskOpen && (
              <Card>
                <label className="text-xs text-muted">Görev<input className={inputCls} value={tName} onChange={(e) => setTName(e.target.value)} placeholder="Yapılacak iş" /></label>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="text-xs text-muted">Bağlı proje
                    <select className={inputCls} value={tProject} onChange={(e) => setTProject(e.target.value)}>
                      <option value="">Genel görev</option>
                      {data.projects.filter((project) => !project.done).map((project) => <option key={project.id} value={project.id}>{project.name}</option>)}
                    </select>
                  </label>
                  <label className="text-xs text-muted">Öncelik
                    <select className={inputCls} value={tPriority} onChange={(e) => setTPriority(Number(e.target.value) as Scale)}>
                      <option value={3}>Acil ve önemli</option><option value={2}>Önemli</option><option value={1}>Daha sonra</option>
                    </select>
                  </label>
                </div>
                <label className="mt-2 block text-xs text-muted">Son tarih<input className={inputCls} type="date" value={tDate} onChange={(e) => setTDate(e.target.value)} /></label>
                <div className="mt-2"><Btn onClick={() => { if (!run({ type: "add_task", name: tName, project_id: tProject || undefined, priority: tPriority, date: tDate })) return; setTName(""); setTDate(""); setTaskOpen(false); }}>Görevi kaydet</Btn></div>
              </Card>
            )}
            {openTasks.length === 0 && doneTasks.length === 0 ? <Empty>Henüz görev yok.</Empty> : null}
            {openTasks.map((task) => <TaskRow key={task.id} task={task} data={data} today={today} onRun={run} />)}
            {doneTasks.length > 0 && <h3 className="mt-2 font-display text-base">Tamamlananlar</h3>}
            {doneTasks.map((task) => <TaskRow key={task.id} task={task} data={data} today={today} onRun={run} />)}
          </>
        )}
        {tab === "reminders" && (
          <>
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-lg">Hatırlatıcılar</h2>
              <Btn variant="ghost" onClick={() => {
                if (typeof Notification === "undefined") { toast.error("Bu tarayıcı bildirim sunmuyor."); return; }
                void Notification.requestPermission().then((permission) => toast(permission === "granted" ? "Bildirim izni verildi." : "Bildirim izni verilmedi."));
              }}>Bildirim izni</Btn>
            </div>
            <Card>
              <label className="text-xs text-muted">Ne hatırlatayım?<input className={inputCls} value={rTitle} onChange={(e) => setRTitle(e.target.value)} placeholder="Örn. Ders çalışmaya geri dön" /></label>
              <label className="mt-2 block text-xs text-muted">Tarih ve saat<input className={inputCls} type="datetime-local" value={rWhen} onChange={(e) => setRWhen(e.target.value)} /></label>
              <div className="mt-2 grid gap-3 sm:grid-cols-2">
                <label className="text-xs text-muted">Tekrar
                  <select className={inputCls} value={rRepeat} onChange={(e) => setRRepeat(e.target.value === "daily" ? "daily" : "once")}>
                    <option value="once">Bir kez</option><option value="daily">Her gün</option>
                  </select>
                </label>
                <label className="text-xs text-muted">Bağlantı
                  <select className={inputCls} value={rLink} onChange={(e) => { const value = e.target.value; setRLink(value === "task" || value === "project" ? value : "general"); setRLinked(""); }}>
                    <option value="general">Genel</option><option value="task">Görev</option><option value="project">Proje</option>
                  </select>
                </label>
              </div>
              {rLink !== "general" && (
                <select className={inputCls} value={rLinked} onChange={(e) => setRLinked(e.target.value)}>
                  <option value="">Seç</option>
                  {linkItems.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
                </select>
              )}
              <div className="mt-3"><Btn onClick={() => { if (!run({ type: "add_reminder", title: rTitle, datetime: rWhen, repeat: rRepeat, link_type: rLink, link_id: rLink === "general" ? undefined : rLinked })) return; setRTitle(""); setRWhen(""); }}>Oluştur</Btn></div>
              <p className="mt-3 text-xs text-muted">Hatırlatıcılar bu cihazda saklanır ve uygulama açıkken kontrol edilir. Uygulama tamamen kapalıyken bildirim için tarayıcının bildirim izni gerekir; kapalı uygulamada garanti değildir.</p>
            </Card>
            {[...data.reminders].sort((a, b) => a.at - b.at).map((item) => (
              <Card key={item.id}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold">{item.title}</h3>
                    <p className="mt-1 text-sm text-muted">{new Date(item.at).toLocaleString("tr-TR")} · {item.repeat === "daily" ? "Her gün" : "Bir kez"} · {item.linkType === "task" ? "Görev" : item.linkType === "project" ? "Proje" : "Genel"}{item.active ? "" : " · geçti"}</p>
                  </div>
                  <Btn variant="danger" onClick={() => run({ type: "delete_reminder", id: item.id })}>Sil</Btn>
                </div>
              </Card>
            ))}
            {data.reminders.length === 0 && <Empty>Henüz hatırlatıcı yok.</Empty>}
          </>
        )}
        {tab === "report" && (
          <>
            <Card>
              <h2 className="font-display text-lg">Gelişim raporu</h2>
              <p className="mt-2 text-sm text-muted">{data.projects.length} proje · {doneTasks.length} tamamlanan görev · {openTasks.length} açık görev · {data.growth.filter((item) => item.done).length}/{data.growth.length} gelişim alanı tamamlandı</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Btn onClick={() => download({ app: "Nexor", reportDate: new Date().toISOString(), ...data }, "nexor-raporu.json")}><Download className="size-4" /> Raporu indir</Btn>
                <Btn variant="ghost" onClick={() => download(data, "nexor-yedek.json")}><Download className="size-4" /> Yedek al</Btn>
              </div>
            </Card>
            <Card>
              <h3 className="font-semibold">Yedeği geri yükle</h3>
              <p className="mt-1 text-sm text-muted">Seçtiğin yedek mevcut kayıtların üzerine yazılır.</p>
              <input ref={fileRef} className="mt-3 block w-full text-sm" type="file" accept=".json,application/json" />
              <div className="mt-3">
                <Btn variant="ghost" onClick={() => {
                  const file = fileRef.current?.files?.[0];
                  if (!file) { toast.error("Önce yedek dosyasını seç."); return; }
                  const reader = new FileReader();
                  reader.onload = () => {
                    try {
                      const parsed = JSON.parse(String(reader.result)) as Partial<AppData>;
                      if (!Array.isArray(parsed.projects) || !Array.isArray(parsed.tasks) || !Array.isArray(parsed.growth)) throw new Error("bad");
                      setModal({
                        title: "Yedeği yükle",
                        body: "Mevcut kayıtların yerine bu yedek yazılacak.",
                        confirmLabel: "Yükle",
                        danger: true,
                        onConfirm: () => {
                          saveData(parseAppData(JSON.stringify({ projects: parsed.projects, tasks: parsed.tasks, growth: parsed.growth, reminders: parsed.reminders ?? [] })));
                          setModal(null);
                          toast.success("Yedek yüklendi.");
                        },
                      });
                    } catch {
                      toast.error("Dosya geçerli bir Nexor yedeği değil.");
                    }
                  };
                  reader.readAsText(file);
                }}><Upload className="size-4" /> Yedeği yükle</Btn>
              </div>
            </Card>
            <Card>
              <h3 className="flex items-center gap-2 font-semibold"><ShieldIcon /> Gizlilik</h3>
              <p className="mt-1 text-sm text-muted">Kayıtlar yalnızca bu cihazdaki tarayıcı hafızasında durur. Tarayıcı verisini silersen kayıtlar gidebilir; ara sıra yedek al. Sohbet anahtarın bu sayfada saklanmaz.</p>
              <div className="mt-3"><Btn variant="danger" onClick={() => setModal({ title: "Tüm verileri sil", body: "Projeler, görevler, gelişim alanları ve hatırlatıcılar silinir. Sohbet ayrıca durur.", confirmLabel: "Hepsini sil", danger: true, onConfirm: () => { saveData(fresh()); saveChat([]); setPending(null); setModal(null); } })}>Tüm verileri sil</Btn></div>
            </Card>
          </>
        )}
        {tab === "nexor" && (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex items-center justify-between gap-3 py-2">
              <div className="flex items-center gap-3">
                <Orb />
                <div>
                  <p className="font-display text-lg font-semibold tracking-wide">NEXOR</p>
                  <p className="text-xs text-muted">Kişisel asistan · doğrulanmış işlem</p>
                </div>
              </div>
              <Btn variant="ghost" onClick={() => setModal({ title: "Sohbeti temizle", body: "Projelerin ve görevlerin durur. Yalnızca sohbet silinir.", confirmLabel: "Temizle", onConfirm: () => { saveChat([]); setPending(null); setModal(null); } })}>Sohbeti temizle</Btn>
            </div>
            <div ref={chatRef} className="min-h-0 flex-1 space-y-2 overflow-y-auto rounded-2xl border border-nexor/30 bg-nexor-deep p-3">
              {chat.length === 0 && <Bubble role="nexor">Merhaba. Ben NEXOR. Görevlerini, projelerini ve gelişim alanlarını buradan yönetebilirim. Ne yapıyoruz?</Bubble>}
              {chat.map((msg, index) => <Bubble key={`${msg.role}-${index}`} role={msg.role}>{msg.content}</Bubble>)}
              {pending?.kind === "confirm" && (
                <div className="max-w-bubble rounded-2xl border border-nexor bg-nexor-deep p-3">
                  <p className="text-sm text-danger">{pending.error}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Btn variant="danger" onClick={confirmChat}>Evet, kalıcı olarak sil</Btn>
                    <Btn variant="ghost" onClick={cancelChat}>Vazgeç</Btn>
                  </div>
                </div>
              )}
              {pending?.kind === "select" && (
                <div className="max-w-bubble rounded-2xl border border-nexor bg-nexor-deep p-3">
                  <p className="text-sm text-ink">{pending.error}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {pending.candidates.map((item) => <Btn key={item.id} variant="ghost" onClick={() => choose(item.id)}>{item.label}</Btn>)}
                    <Btn variant="danger" onClick={cancelChat}>İptal</Btn>
                  </div>
                </div>
              )}
            </div>
            <p className="min-h-6 py-1 text-xs text-nexor" aria-live="polite">{status}</p>
            <div className="flex gap-2 pb-2">
              <input className="min-h-11 flex-1 rounded-xl border border-nexor/40 bg-bg px-3 text-base text-ink placeholder:text-muted" value={input} placeholder="NEXOR’a yaz veya komut ver…" autoComplete="off" onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); unlockSpeech(); void send(input, false); } }} />
              <button type="button" aria-label={listening ? "Dinlemeyi durdur" : "Sesli komut"} disabled={sending} onClick={toggleVoice} className={`inline-flex size-11 items-center justify-center rounded-xl border ${listening ? "border-nexor bg-nexor text-ink" : "border-line bg-surface text-ink"}`}>
                {listening ? <Square className="size-4" /> : <Mic className="size-4" />}
              </button>
              <button type="button" aria-label="Gönder" disabled={sending || !input.trim()} onClick={() => { unlockSpeech(); void send(input, false); }} className="inline-flex size-11 items-center justify-center rounded-xl bg-nexor text-ink disabled:opacity-50">
                <Send className="size-4" />
              </button>
            </div>
          </div>
        )}
      </main>
      {tab !== "nexor" && <p className="pb-6 text-center text-xs text-muted">Nexor · kişisel kullanım</p>}
      {modal && (
        <div className="fixed inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl border border-line bg-surface p-4">
            <h2 className="font-display text-lg">{modal.title}</h2>
            <p className="mt-2 text-sm text-muted">{modal.body}</p>
            <div className="mt-4 flex gap-2">
              <Btn variant={modal.danger ? "danger" : "primary"} onClick={modal.onConfirm}>{modal.confirmLabel}</Btn>
              <Btn variant="ghost" onClick={() => setModal(null)}>Vazgeç</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ShieldIcon() {
  return <Check className="size-4 text-gold" aria-hidden />;
}

function Bubble({ role, children }: { role: ChatMsg["role"]; children: ReactNode }) {
  const look = role === "user" ? "ml-auto border-line bg-surface-2" : role === "log" ? "border-line bg-surface text-gold" : role === "err" ? "border-nexor/50 bg-nexor/10 text-danger" : "border-nexor/40 bg-bg text-ink";
  return <div className={`max-w-bubble rounded-2xl border px-3 py-2 text-sm leading-6 whitespace-pre-wrap ${look}`}>{children}</div>;
}

function TaskRow({ task, data, today, onRun }: { task: Task; data: AppData; today: string; onRun: (cmd: unknown) => void }) {
  const project = data.projects.find((item) => item.id === task.project);
  const overdue = Boolean(today && task.date && !task.done && task.date < today);
  return (
    <Card>
      <div className="flex items-start justify-between gap-3">
        <label className="flex items-start gap-3 text-sm font-semibold">
          <input className="mt-0.5 size-5 accent-gold" type="checkbox" checked={task.done} onChange={() => onRun({ type: "edit_task", id: task.id, done: !task.done })} />
          <span>{task.name}</span>
        </label>
        <Tag level={task.priority} label={priorityLabel(task.priority)} />
      </div>
      <p className="mt-2 text-sm text-muted">{project ? `Proje: ${project.name}` : "Genel görev"}{task.date ? ` · Tarih: ${task.date}` : ""}{overdue ? " · Gecikti" : ""}</p>
      <div className="mt-3"><Btn variant="ghost" onClick={() => onRun({ type: "delete_task", id: task.id })}><Trash2 className="size-4" /> Sil</Btn></div>
    </Card>
  );
}

function ProjectRow({ project, data, onRun }: { project: Project; data: AppData; onRun: (cmd: unknown) => void }) {
  const related = data.tasks.filter((task) => task.project === project.id);
  const completed = related.filter((task) => task.done).length;
  const pct = related.length ? Math.round((completed / related.length) * 100) : project.done ? 100 : 0;
  return (
    <Card>
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-semibold">{project.name}</h3>
        <Tag level={project.importance} label={importanceLabel(project.importance)} />
      </div>
      <p className="mt-1 text-sm text-muted">{project.desc}{project.date ? ` · Son tarih: ${project.date}` : ""}</p>
      <Bar pct={pct} />
      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="text-xs text-muted">%{pct} · {completed}/{related.length} görev</span>
        <div className="flex gap-2">
          <Btn variant="ghost" onClick={() => onRun({ type: "edit_project", id: project.id, done: !project.done })}>{project.done ? "Geri al" : "Bitir"}</Btn>
          <Btn variant="danger" onClick={() => onRun({ type: "delete_project", id: project.id })}>Sil</Btn>
        </div>
      </div>
    </Card>
  );
}
