import React, { useState } from 'react';
import {
  Bell,
  Bookmark,
  BookOpen,
  Check,
  Clock,
  Download,
  Edit3,
  Lock,
  LogOut,
  ShieldCheck,
  Trash2,
  User as UserIcon,
} from 'lucide-react';
import {
  Announcement,
  AnnouncementCategory,
  ClassChangeReport,
  LanguageCode,
  NoteDownloadRecord,
  SavedNoteRecord,
  StudentProfile,
} from '../types/edutoon';
import { Logo } from './Logo';

export const SavedNotesView: React.FC<{
  language: LanguageCode;
  savedNotes: SavedNoteRecord[];
  onOpenNoteById: (noteId: string, classLevel: number, subjectId: string, lang: LanguageCode) => void;
  onRemoveSaved: (noteId: string) => void;
}> = ({ language, savedNotes, onOpenNoteById, onRemoveSaved }) => {
  const isHi = language === 'hi';

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <Logo size="sm" />
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
              {isHi ? 'सेव किए गए नोट्स (Saved Notes)' : 'Saved Notes'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              {isHi
                ? 'त्वरित रिवीजन के लिए आपके बुकमार्क किए गए अध्याय'
                : 'Your bookmarked chapters for fast revision'}
            </p>
          </div>
        </div>
        <span className="font-mono-num text-sm font-bold text-sky-700">
          {savedNotes.length} saved
        </span>
      </div>

      {savedNotes.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center">
          <Bookmark className="h-9 w-9 text-slate-300 mx-auto" />
          <p className="mt-3 font-display text-base font-semibold text-slate-800">
            {isHi ? 'अभी कोई नोट्स सेव नहीं हैं' : 'No saved notes yet'}
          </p>
          <p className="mt-1 text-sm text-slate-500">
            {isHi
              ? 'किसी भी विषय के अध्याय में Bookmark बटन दबाकर यहाँ सेव करें।'
              : 'Bookmark any chapter inside a subject to find it quickly here.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {savedNotes.map((item) => (
            <div
              key={item.noteId}
              className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="min-w-0">
                <p className="text-xs text-slate-500">
                  Class {item.classLevel} · Chapter {item.chapterNumber} ·{' '}
                  {item.language === 'hi' ? 'हिंदी' : 'English'}
                </p>
                <h3 className="mt-1 font-display text-base sm:text-lg font-bold text-slate-900 truncate">
                  {item.title}
                </h3>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onRemoveSaved(item.noteId)}
                  aria-label="Remove saved note"
                  className="min-h-[44px] px-3.5 rounded-xl border border-slate-200 hover:bg-red-50 hover:border-red-200 hover:text-red-700 text-slate-600 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>{isHi ? 'हटाएँ' : 'Remove'}</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onOpenNoteById(item.noteId, item.classLevel, item.subjectId, item.language)
                  }
                  className="min-h-[44px] px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <BookOpen className="h-4 w-4" />
                  <span>{isHi ? 'पढ़ें' : 'Open Note'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const DownloadsView: React.FC<{
  language: LanguageCode;
  downloads: NoteDownloadRecord[];
  onRedownloadPdf: (item: NoteDownloadRecord) => Promise<void>;
  onOpenNoteById: (noteId: string, classLevel: number, subjectId: string, lang: LanguageCode) => void;
  onRemoveDownload: (noteId: string) => void;
}> = ({ language, downloads, onRedownloadPdf, onOpenNoteById, onRemoveDownload }) => {
  const isHi = language === 'hi';
  const [busyId, setBusyId] = useState<string | null>(null);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <Logo size="sm" />
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
              {isHi ? 'डाउनलोड किए गए PDF' : 'Downloaded PDFs'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              {isHi
                ? 'आपके डिवाइस के लिए तैयार अध्ययन सामग्री PDF'
                : 'Study material PDFs saved from your chapters'}
            </p>
          </div>
        </div>
        <span className="font-mono-num text-sm font-bold text-sky-700">
          {downloads.length} files
        </span>
      </div>

      {downloads.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center">
          <Download className="h-9 w-9 text-slate-300 mx-auto" />
          <p className="mt-3 font-display text-base font-semibold text-slate-800">
            {isHi ? 'अभी कोई PDF डाउनलोड नहीं है' : 'No downloaded PDFs yet'}
          </p>
          <p className="mt-1 text-sm text-slate-500">
            {isHi
              ? 'किसी भी अध्याय के नोट्स पर "PDF" बटन दबाकर डाउनलोड करें।'
              : 'Tap Download PDF on any chapter note to generate and save your study sheet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {downloads.map((item) => (
            <div
              key={item.noteId}
              className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="min-w-0">
                <p className="text-xs text-slate-500">
                  Class {item.classLevel} · Chapter {item.chapterNumber} ·{' '}
                  <span className="font-mono-num">{item.fileName}</span>
                </p>
                <h3 className="mt-1 font-display text-base sm:text-lg font-bold text-slate-900 truncate">
                  {item.title}
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onRemoveDownload(item.noteId)}
                  aria-label="Remove download record"
                  className="min-h-[44px] px-3 rounded-xl border border-slate-200 hover:bg-red-50 hover:text-red-700 text-slate-600 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onOpenNoteById(item.noteId, item.classLevel, item.subjectId, item.language)
                  }
                  className="min-h-[44px] px-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <BookOpen className="h-4 w-4" />
                  <span>{isHi ? 'पढ़ें' : 'Read'}</span>
                </button>
                <button
                  type="button"
                  disabled={busyId === item.noteId}
                  onClick={async () => {
                    setBusyId(item.noteId);
                    try {
                      await onRedownloadPdf(item);
                    } finally {
                      setBusyId(null);
                    }
                  }}
                  className="min-h-[44px] px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>{busyId === item.noteId ? '...' : isHi ? 'PDF डाउनलोड' : 'Download PDF'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const AnnouncementsView: React.FC<{
  language: LanguageCode;
  announcements: Announcement[];
}> = ({ language, announcements }) => {
  const isHi = language === 'hi';
  const [catFilter, setCatFilter] = useState<'All' | AnnouncementCategory>('All');

  const visible = announcements.filter((a) => catFilter === 'All' || a.category === catFilter);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <Logo size="sm" />
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
              {isHi ? 'सूचनाएँ (Announcements)' : 'Announcements'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              {isHi
                ? 'कक्षा और परीक्षा से जुड़े आधिकारिक अपडेट'
                : 'Official school & curriculum updates for your class'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-xl self-start">
          {(['All', 'Exam', 'Content', 'Schedule', 'General'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCatFilter(cat)}
              className={`min-h-[38px] px-3 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                catFilter === cat
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center">
          <Bell className="h-9 w-9 text-slate-300 mx-auto" />
          <p className="mt-3 font-display text-base font-semibold text-slate-800">
            {isHi ? 'कोई नई सूचना नहीं है' : 'No announcements right now'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {visible.map((ann) => (
            <article
              key={ann.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2"
            >
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span className="font-semibold text-sky-700">{ann.category}</span>
                <span aria-hidden="true">·</span>
                <span>{ann.targetClass === 0 ? 'All Classes' : `Class ${ann.targetClass}`}</span>
                <span aria-hidden="true">·</span>
                <span>By {ann.authorName}</span>
              </div>
              <h3 className="font-display text-lg font-bold text-slate-900">{ann.title}</h3>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">{ann.body}</p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};

export const ProfileView: React.FC<{
  profile: StudentProfile;
  email: string;
  phoneNumber: string;
  reports: ClassChangeReport[];
  onUpdateName: (name: string) => Promise<void>;
  onSwitchLanguage: (lang: LanguageCode) => Promise<void>;
  onOpenClassChangeModal: () => void;
  onOpenAdminDashboard?: () => void;
  onSignOut: () => Promise<void>;
}> = ({
  profile,
  email,
  phoneNumber,
  reports,
  onUpdateName,
  onSwitchLanguage,
  onOpenClassChangeModal,
  onOpenAdminDashboard,
  onSignOut,
}) => {
  const isHi = profile.language === 'hi';
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.displayName);
  const [savingName, setSavingName] = useState(false);

  const latestReport = reports[0];

  const handleSaveName = async () => {
    if (!nameInput.trim()) return;
    setSavingName(true);
    try {
      await onUpdateName(nameInput.trim());
      setEditingName(false);
    } finally {
      setSavingName(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          {profile.photoURL ? (
            <img
              src={profile.photoURL}
              alt={profile.displayName}
              referrerPolicy="no-referrer"
              className="h-14 w-14 rounded-2xl object-cover border border-slate-200 shrink-0"
            />
          ) : (
            <Logo size="md" />
          )}
          <div>
            <p className="text-xs font-medium text-slate-500">
              {isHi ? 'छात्र प्रोफ़ाइल' : 'Student Profile'} · Session {profile.academicSession} ·{' '}
              {profile.authProvider === 'google' ? 'Google Account' : 'Verified Account'}
            </p>
            {editingName ? (
              <div className="mt-1 flex items-center gap-2">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  maxLength={80}
                  className="h-10 px-3 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900"
                />
                <button
                  type="button"
                  disabled={savingName}
                  onClick={handleSaveName}
                  className="min-h-[40px] px-3 rounded-xl bg-sky-600 text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Check className="h-4 w-4" />
                  <span>Save</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 mt-0.5">
                <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
                  {profile.displayName}
                </h1>
                <button
                  type="button"
                  onClick={() => {
                    setNameInput(profile.displayName);
                    setEditingName(true);
                  }}
                  aria-label="Edit display name"
                  className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500 cursor-pointer"
                >
                  <Edit3 className="h-4 w-4" />
                </button>
              </div>
            )}
            <p className="text-xs text-slate-500 mt-0.5">
              {email || phoneNumber || 'Verified Student'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onSignOut}
          className="min-h-[44px] px-4 rounded-xl border border-slate-300 hover:bg-red-50 hover:border-red-200 hover:text-red-700 text-slate-700 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <LogOut className="h-4 w-4" />
          <span>{isHi ? 'साइन आउट' : 'Sign Out'}</span>
        </button>
      </div>

      {/* Academic Class Lock & Change Report */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {isHi ? 'चुनी हुई कक्षा (लॉक)' : 'Academic Class Lock'}
            </h2>
            <Lock className="h-5 w-5 text-sky-600" />
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <p className="text-xs text-slate-500">
              {isHi ? 'वर्तमान कक्षा' : 'Current Enrolled Class'}
            </p>
            <p className="mt-1 font-display text-2xl font-bold text-slate-900 font-mono-num">
              {isHi ? `कक्षा ${profile.selectedClass}` : `Class ${profile.selectedClass}`}
            </p>
            <p className="mt-1 text-xs text-slate-600">
              {isHi
                ? `सत्र ${profile.academicSession} तक लॉक है। सीधे बदलाव संभव नहीं है।`
                : `Locked for session ${profile.academicSession}. Direct editing is disabled.`}
            </p>
          </div>

          {latestReport && (
            <div className="text-xs text-slate-600 flex items-center gap-2">
              <Clock className="h-4 w-4 text-slate-400 shrink-0" />
              <span>
                Latest Report (Class {latestReport.currentClass} → {latestReport.requestedClass}):{' '}
                <strong className="uppercase">{latestReport.status}</strong>
              </span>
            </div>
          )}

          <button
            type="button"
            onClick={onOpenClassChangeModal}
            className="w-full min-h-[44px] px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold cursor-pointer"
          >
            {isHi ? 'क्लास चेंज रिपोर्ट भेजें / स्थिति देखें' : 'Submit or Track Class Change Report'}
          </button>
        </div>

        {/* Learning Medium & Account */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {isHi ? 'अध्ययन भाषा (Medium)' : 'Learning Medium'}
            </h2>
            <UserIcon className="h-5 w-5 text-sky-600" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => onSwitchLanguage('hi')}
              className={`min-h-[48px] rounded-xl border-2 text-sm font-bold cursor-pointer transition-colors ${
                profile.language === 'hi'
                  ? 'border-sky-500 bg-sky-50 text-sky-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              हिंदी
            </button>
            <button
              type="button"
              onClick={() => onSwitchLanguage('en')}
              className={`min-h-[48px] rounded-xl border-2 text-sm font-bold cursor-pointer transition-colors ${
                profile.language === 'en'
                  ? 'border-sky-500 bg-sky-50 text-sky-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              English
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 text-xs text-slate-500 space-y-1">
            <p>
              Completed Notes:{' '}
              <strong className="font-mono-num text-slate-900">
                {profile.completedNoteIds.length}
              </strong>
            </p>
            <p>
              Completed Videos:{' '}
              <strong className="font-mono-num text-slate-900">
                {profile.completedVideoIds.length}
              </strong>
            </p>
          </div>

          {onOpenAdminDashboard && (
            <button
              type="button"
              onClick={onOpenAdminDashboard}
              className="w-full min-h-[44px] px-4 rounded-xl bg-[#0B132B] hover:bg-[#131F47] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="h-4 w-4 text-sky-400" />
              <span>Open Admin Dashboard</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
