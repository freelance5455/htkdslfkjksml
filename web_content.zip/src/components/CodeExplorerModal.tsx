import React, { useState } from 'react';
import {
  FolderTree,
  FileCode,
  Download,
  Copy,
  Check,
  X,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_FILES } from '../utils/androidProjectFiles';
import { AndroidProjectFile } from '../types';

interface CodeExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeExplorerModal: React.FC<CodeExplorerModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  if (!isOpen) return null;

  const categories = ['All', 'Compose UI', 'Architecture & Storage', 'Services & Receivers', 'Build & Config'];

  const filteredFiles =
    selectedCategory === 'All'
      ? ANDROID_FILES
      : ANDROID_FILES.filter(f => f.category === selectedCategory);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard fallback
    }
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Add all android project files to zip
      ANDROID_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add root gradle files & README
      zip.file(
        'README.md',
        `# JARVIS - Native Android AI Assistant\n\nBuilt with Kotlin & Jetpack Compose.\nImport this folder directly in Android Studio Ladybug or newer.`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'JARVIS-Android-JetpackCompose-Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-5xl h-[88vh] bg-[#0D121F] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-white">
        {/* Header */}
        <div className="h-16 px-6 border-b border-slate-800 flex items-center justify-between bg-[#111827] shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/30">
              <FolderTree className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white tracking-wide">
                  Native Android Project Tree
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium">
                  Kotlin + Jetpack Compose
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Modular Android Architecture • On-Device DataStore • Notification Services
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Download Full Zip Button */}
            <button
              id="btn-download-android-zip"
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="px-3.5 py-2 rounded-xl bg-[#00E5FF] hover:bg-[#00c4db] text-[#0A0E17] font-bold text-xs flex items-center gap-2 transition-all shadow-lg shadow-[#00E5FF]/20 active:scale-95 disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {isZipping ? 'PACKING ZIP...' : 'DOWNLOAD ANDROID PROJECT (.ZIP)'}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="h-10 px-6 border-b border-slate-800/80 bg-[#0F1626] flex items-center gap-2 overflow-x-auto text-xs shrink-0">
          <span className="text-slate-500 text-[11px] uppercase tracking-wider font-mono mr-1">
            Category:
          </span>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#00E5FF]/20 text-[#00E5FF] font-semibold border border-[#00E5FF]/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Body: Left Sidebar File Tree + Right Code View */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Sidebar */}
          <div className="w-72 border-r border-slate-800 bg-[#0A0E17]/60 overflow-y-auto p-3 space-y-1 shrink-0">
            <div className="px-2 py-1 text-[11px] font-mono text-slate-400 uppercase tracking-wider">
              Project Files ({filteredFiles.length})
            </div>
            {filteredFiles.map(file => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-mono transition-all flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-[#162238] text-[#00E5FF] font-medium border border-[#00E5FF]/40 shadow-sm'
                      : 'text-slate-300 hover:bg-[#121929] hover:text-white'
                  }`}
                >
                  <FileCode
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      isSelected ? 'text-[#00E5FF]' : 'text-slate-500'
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{file.name}</p>
                    <p className="text-[10px] text-slate-400 truncate opacity-80">{file.path}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-[#080C14] overflow-hidden">
            {/* File Path & Copy Bar */}
            <div className="h-11 px-4 border-b border-slate-800/80 bg-[#0D1322] flex items-center justify-between text-xs font-mono shrink-0">
              <span className="text-slate-300 truncate">{selectedFile.path}</span>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 rounded bg-[#1A2338] hover:bg-[#23304D] text-slate-200 text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#00E676]" />
                    <span className="text-[#00E676]">COPIED</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>COPY CODE</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content with Syntax Formatting */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200 bg-[#06090F]">
              <pre className="select-text">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
