import React, { useState, useEffect } from "react";
import {
  Wrench,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Terminal,
  Cpu,
  Database,
  Layers,
  Sliders,
  Palette,
  Send,
  Zap,
  RotateCcw,
  Check,
  Info,
  Clock,
  Wifi,
  WifiOff,
  Trash2,
  ChevronRight,
  ShieldAlert,
  Copy,
  Download,
  Activity,
  HardDrive,
  FileCheck,
  SlidersHorizontal,
  Compass,
  PenTool,
} from "lucide-react";
import {
  useGlobalState,
  AutoRepairResult,
  DiagnosticCommandResult,
} from "../context/GlobalContext";
import {
  DiagnosticHealthMetrics,
  LevelRepairResult,
  DetailedDiagnosticReport,
} from "../utils/TroubleshootingEngine";

interface TroubleshootingCenterProps {
  onNotify?: (msg: string) => void;
}

export const TroubleshootingCenter: React.FC<TroubleshootingCenterProps> = ({ onNotify }) => {
  const {
    state,
    runAutoRepair,
    runLevel1Repair,
    runLevel2Repair,
    runLevel3Repair,
    runFullDiagnosticsAudit,
    generateDiagnosticReport,
    triggerOnlineHeal,
    executeDiagnosticCommand,
    clearDiagnosticLogs,
    addDiagnosticLog,
    resetScaleConfig,
    resetSections,
    resetMenuOrder,
  } = useGlobalState();

  const [promptInput, setPromptInput] = useState("");
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditMetrics, setAuditMetrics] = useState<DiagnosticHealthMetrics>(() =>
    runFullDiagnosticsAudit()
  );
  const [activeRepairLevel, setActiveRepairLevel] = useState<number | null>(null);
  const [lastLevelResult, setLastLevelResult] = useState<LevelRepairResult | null>(null);
  const [isExecutingCommand, setIsExecutingCommand] = useState(false);
  const [commandFeedback, setCommandFeedback] = useState<DiagnosticCommandResult | null>(null);
  const [copiedReport, setCopiedReport] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [generatedReport, setGeneratedReport] = useState<DetailedDiagnosticReport | null>(null);

  // Quick Preset Diagnostic Prompt Chips
  const QUICK_PROMPT_CHIPS = [
    { label: "Tema Sıfırla", desc: "Zümrüt Teal & Minimalist Temaya Dön", icon: Palette },
    { label: "Navigasyon Tam Onarım", desc: "Alt Yapışık / Dok & 64dp Güvenli Düzen", icon: Compass },
    { label: "Tuval Hizala", desc: "Baseline & Ruled Çizgi 1:1 Senkronu", icon: PenTool },
    { label: "Veritabanı Onar", desc: "5 Temel Kategori & Arama İndeksi", icon: Database },
    { label: "Tam Temizlik", desc: "Geçici UI & Çökme Loglarını Temizle", icon: Trash2 },
  ];

  const handleAudit = () => {
    setIsAuditing(true);
    setTimeout(() => {
      const res = runFullDiagnosticsAudit();
      setAuditMetrics(res);
      setIsAuditing(false);
      if (onNotify) onNotify("✓ Sistem sağlık taraması başarıyla tamamlandı.");
    }, 600);
  };

  const handleLevel1SoftRepair = async () => {
    setActiveRepairLevel(1);
    try {
      const result = await runLevel1Repair();
      setLastLevelResult(result);
      setAuditMetrics(runFullDiagnosticsAudit());
      if (onNotify) onNotify("✓ Düzey 1 Soft Repair: Arayüz ve önbellekler başarıyla yenilendi.");
    } finally {
      setActiveRepairLevel(null);
    }
  };

  const handleLevel2ReIndex = async () => {
    setActiveRepairLevel(2);
    try {
      const result = await runLevel2Repair();
      setLastLevelResult(result);
      setAuditMetrics(runFullDiagnosticsAudit());
      if (onNotify) onNotify("✓ Düzey 2: İndeksler ve tuval koordinatları başarıyla yeniden inşa edildi.");
    } finally {
      setActiveRepairLevel(null);
    }
  };

  const handleLevel3ResetUI = async () => {
    if (!window.confirm("Tema, navigasyon ve ölçek ayarları fabrika varsayılanına dönecektir. Notlarınız ve verileriniz kesinlikle korunacaktır. Onaylıyor musunuz?")) {
      return;
    }
    setActiveRepairLevel(3);
    try {
      const result = await runLevel3Repair();
      setLastLevelResult(result);
      setAuditMetrics(runFullDiagnosticsAudit());
      if (onNotify) onNotify("✓ Düzey 3: Fabrika UI ayarlarına başarıyla dönüldü.");
    } finally {
      setActiveRepairLevel(null);
    }
  };

  const handleExecutePrompt = (cmdToRun?: string) => {
    const text = (cmdToRun || promptInput).trim();
    if (!text) return;

    setIsExecutingCommand(true);
    setCommandFeedback(null);

    setTimeout(() => {
      const res = executeDiagnosticCommand(text);
      setCommandFeedback(res);
      setIsExecutingCommand(false);
      setPromptInput("");
      setAuditMetrics(runFullDiagnosticsAudit());

      if (onNotify) {
        onNotify(`✓ '${text}' komutu başarıyla işlendi.`);
      }
    }, 300);
  };

  const handleExportReport = () => {
    const report = generateDiagnosticReport();
    setGeneratedReport(report);
    const jsonStr = JSON.stringify(report, null, 2);
    navigator.clipboard.writeText(jsonStr).then(() => {
      setCopiedReport(true);
      if (onNotify) onNotify("✓ Teşhis raporu panoya kopyalandı!");
      setTimeout(() => setCopiedReport(false), 3500);
    });
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-200">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER & SYSTEM HEALTH STATUS BADGE                                */}
      {/* ========================================================================= */}
      <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-indigo-950 text-white px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-teal-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-teal-300 flex items-center justify-center shrink-0 shadow-xs">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-black tracking-wide text-white uppercase flex items-center gap-1.5">
                  <span>SORUN ÇÖZME & ONARIM MERKEZİ</span>
                </h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-teal-400/20 text-teal-300 border border-teal-400/40">
                  v{state.version} Self-Healing
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Sıfır Tolerans
                </span>
              </div>
              <p className="text-[11px] text-teal-200/80">
                Merkezi Durum Doğrulama, Çevrimiçi Kendi Kendini İyileştirme ve 3 Aşamalı Onarım Motoru
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-bold text-xs ${
                auditMetrics.healthScore >= 90
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                  : auditMetrics.healthScore >= 75
                  ? "bg-amber-500/10 border-amber-500/30 text-amber-300"
                  : "bg-rose-500/10 border-rose-500/30 text-rose-300"
              }`}
            >
              <Activity className="w-4 h-4 animate-pulse" />
              <span>Sağlık Skoru: %{auditMetrics.healthScore}</span>
            </div>

            <div
              className={`flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1.5 rounded-xl border ${
                state.isOnline
                  ? "bg-teal-500/10 border-teal-500/30 text-teal-300"
                  : "bg-amber-500/10 border-amber-500/30 text-amber-300"
              }`}
              title={state.isOnline ? "İnternet bağlantısı aktif: Online Auto-Heal Daemon devrede" : "Çevrimdışı mod"}
            >
              {state.isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
              <span>{state.isOnline ? "Online" : "Offline"}</span>
            </div>
          </div>
        </div>

        {/* Data Security Guarantee Callout */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-50/80 via-white to-teal-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-teal-950/30 border-b border-slate-100 dark:border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>%100 Kullanıcı Verisi ve Not Güvenliği Garantisi</span>
              </h4>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                Tüm onarım kademelerinde not içerikleriniz, şifreli kasa kilitleriniz ve el yazısı çizimleriniz <strong>Salt-Okunur (Read-Only)</strong> alanda tutulur; hiçbir onarım adımında kullanıcı verisi silinmez.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={isAuditing}
              onClick={handleAudit}
              className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isAuditing ? "animate-spin text-teal-600" : ""}`} />
              <span>{isAuditing ? "Taranıyor..." : "Sağlık Taraması"}</span>
            </button>

            <button
              type="button"
              onClick={handleExportReport}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              title="Teşhis raporunu panoya JSON olarak kopyala"
            >
              {copiedReport ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedReport ? "Kopyalandı!" : "Rapor Al"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. DIAGNOSTICS AUDIT METRICS DASHBOARD                                     */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Sağlık Durumu
          </span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-xs sm:text-sm font-black text-slate-900 dark:text-white capitalize">
              {auditMetrics.overallStatus}
            </span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Bellek Kullanımı
          </span>
          <div className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-mono font-black text-xs sm:text-sm">
            <Cpu className="w-3.5 h-3.5 shrink-0" />
            <span>~{auditMetrics.memoryUsageEstimateMB} MB</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Depolama Boyutu
          </span>
          <div className="flex items-center gap-1 text-teal-600 dark:text-teal-400 font-mono font-black text-xs sm:text-sm">
            <HardDrive className="w-3.5 h-3.5 shrink-0" />
            <span>{auditMetrics.storageUsageEstimateKB} KB</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Not & Kasa Adedi
          </span>
          <div className="flex items-center gap-1 text-slate-800 dark:text-slate-200 font-black text-xs sm:text-sm">
            <FileCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>{auditMetrics.totalNotesCount} Not</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Tuval Matrisi
          </span>
          <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
            <Check className="w-3.5 h-3.5" />
            1:1 Kilitli
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Nav Safe Insets
          </span>
          <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            Koruma Aktif
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. AŞAMALI "HATALARI ÇÖZ" (MULTI-LEVEL REPAIR SYSTEM)                      */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
              <span>Aşamalı "Hataları Çöz" Motoru (Multi-Level Repair)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              İhtiyacınıza göre yumuşak arayüz yenileme, indeks onarımı veya fabrika UI ayarlarına dönüş kademelerini seçin.
            </p>
          </div>
          <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            Sıfır Veri Kaybı Mimarisi
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* LEVEL 1: Soft Repair */}
          <div className="p-4.5 rounded-2xl border-2 border-teal-500/30 bg-teal-50/30 dark:bg-teal-950/20 flex flex-col justify-between gap-4 shadow-xs">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-600 text-white">
                  DÜZEY 1
                </span>
                <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400">
                  Hızlı & Güvenli
                </span>
              </div>
              <h4 className="text-sm font-black text-slate-900 dark:text-white">
                Arayüz & Önbellek Yenile
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Not içeriklerine dokunmadan; tema, navigasyon, yazı tahtası çizgileri ve font ölçekleme önbelleklerini temizler, Global Context'i re-hydrate eder.
              </p>
            </div>

            <button
              type="button"
              disabled={activeRepairLevel !== null || state.isRepairing}
              onClick={handleLevel1SoftRepair}
              className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              {activeRepairLevel === 1 ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Yenileniyor...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Düzey 1: Soft Repair</span>
                </>
              )}
            </button>
          </div>

          {/* LEVEL 2: Re-Index & Re-Matrix */}
          <div className="p-4.5 rounded-2xl border-2 border-indigo-500/30 bg-indigo-50/30 dark:bg-indigo-950/20 flex flex-col justify-between gap-4 shadow-xs">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-600 text-white">
                  DÜZEY 2
                </span>
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">
                  İndeks & Tuval
                </span>
              </div>
              <h4 className="text-sm font-black text-slate-900 dark:text-white">
                İndeksleri & Matrisi Yeniden İnşa Et
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Not bağlantılarını, kategori etiketlerini, arama indeksini ve çizim katmanı (Canvas Overlay) koordinatlarını 1:1 yeniden hizalar.
              </p>
            </div>

            <button
              type="button"
              disabled={activeRepairLevel !== null || state.isRepairing}
              onClick={handleLevel2ReIndex}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              {activeRepairLevel === 2 ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>İnşa Ediliyor...</span>
                </>
              ) : (
                <>
                  <Database className="w-3.5 h-3.5" />
                  <span>Düzey 2: Re-Index & Matrix</span>
                </>
              )}
            </button>
          </div>

          {/* LEVEL 3: Reset UI Settings */}
          <div className="p-4.5 rounded-2xl border-2 border-amber-500/30 bg-amber-50/30 dark:bg-amber-950/20 flex flex-col justify-between gap-4 shadow-xs">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-amber-600 text-white">
                  DÜZEY 3
                </span>
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">
                  Fabrika UI Ayarları
                </span>
              </div>
              <h4 className="text-sm font-black text-slate-900 dark:text-white">
                Fabrika UI Ayarlarına Dön
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Tüm kullanıcı notları korunarak yalnızca Tema, Navigasyon konumu ve Arayüz boyutlarını fabrika çıkış ayarlarına döndürür.
              </p>
            </div>

            <button
              type="button"
              disabled={activeRepairLevel !== null || state.isRepairing}
              onClick={handleLevel3ResetUI}
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              {activeRepairLevel === 3 ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Sıfırlanıyor...</span>
                </>
              ) : (
                <>
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Düzey 3: Fabrika UI Sıfırla</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Last Level Result Banner */}
        {lastLevelResult && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-2 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{lastLevelResult.levelName} Başarıyla Tamamlandı ({lastLevelResult.durationMs}ms)</span>
              </span>
              <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-300">
                {lastLevelResult.timestamp}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[11px] text-slate-600 dark:text-slate-300">
              {lastLevelResult.fixedItems.map((item, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. DIAGNOSTIC PROMPT COMMAND TERMINAL                                      */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center shrink-0">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>Metin / İstem Tabanlı Komut Teşhis Kutusu (Diagnostic Terminal)</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Akıllı Komut Motoru
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
              Çalıştırmak istediğiniz onarım komutunu doğal dilde yazın veya aşağıdaki hazır çiplere tek tıkla dokunun.
            </p>
          </div>
        </div>

        {/* Prompt Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleExecutePrompt();
          }}
          className="flex flex-col sm:flex-row gap-2"
        >
          <div className="relative flex-1">
            <Terminal className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={promptInput}
              onChange={(e) => setPromptInput(e.target.value)}
              placeholder="Örn: Tema Sıfırla, Navigasyon Tam Onarım, Tuval Hizala, Veritabanı Onar, Tam Temizlik..."
              className="w-full pl-10 pr-4 py-2.5 text-xs rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 font-mono placeholder:font-sans"
            />
          </div>

          <button
            type="submit"
            disabled={!promptInput.trim() || isExecutingCommand}
            className="px-5 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
          >
            {isExecutingCommand ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            <span>Komutu Çalıştır</span>
          </button>
        </form>

        {/* Quick Command Chips */}
        <div className="space-y-1.5 pt-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Önceden Tanımlı Teşhis Komutları:
          </span>
          <div className="flex flex-wrap gap-2">
            {QUICK_PROMPT_CHIPS.map((chip, i) => {
              const IconComp = chip.icon;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleExecutePrompt(chip.label)}
                  className="group flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 hover:bg-teal-50 dark:hover:bg-teal-950/40 hover:border-teal-300 dark:hover:border-teal-800 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-all cursor-pointer shadow-2xs"
                >
                  <IconComp className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                  <span>{chip.label}</span>
                  <span className="text-[10px] text-slate-400 font-normal hidden md:inline">
                    • {chip.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Command Feedback Box */}
        {commandFeedback && (
          <div className="p-4 rounded-2xl bg-slate-900 text-white border border-slate-800 space-y-2 font-mono text-xs animate-in fade-in">
            <div className="flex items-center justify-between text-teal-400 text-[11px]">
              <span className="font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {commandFeedback.feedback}
              </span>
              <span className="text-slate-400 font-sans">{new Date().toLocaleTimeString("tr-TR")}</span>
            </div>
            <div className="space-y-1 text-slate-300 text-[11px]">
              {commandFeedback.actionsTaken.map((act, i) => (
                <div key={i} className="flex items-start gap-1.5">
                  <span className="text-emerald-400 font-bold">➔</span>
                  <span>{act}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 5. REAL-TIME EVENT LOGS & STATE MATRIX                                    */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Live Terminal Logs */}
        <div className="lg:col-span-2 p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
                Canlı Tanılama & Onarım Günlüğü
              </h3>
            </div>
            {state.diagnosticLogs.length > 0 && (
              <button
                type="button"
                onClick={clearDiagnosticLogs}
                className="text-[11px] font-semibold text-slate-400 hover:text-rose-500 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Trash2 className="w-3 h-3" />
                <span>Günlüğü Temizle</span>
              </button>
            )}
          </div>

          <div className="rounded-2xl bg-slate-950 p-3.5 max-h-56 overflow-y-auto space-y-2 font-mono text-[11px] border border-slate-800 scrollbar-none">
            {state.diagnosticLogs.length === 0 ? (
              <div className="text-slate-500 text-center py-6">
                Henüz bir teşhis olayı kaydedilmedi. Tüm sistemler nominal çalışıyor.
              </div>
            ) : (
              state.diagnosticLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-2 border-b border-slate-900 pb-1.5 last:border-0"
                >
                  <span className="text-slate-500 shrink-0">{log.timestamp}</span>
                  <span
                    className={`font-bold px-1.5 py-0.2 rounded text-[9px] shrink-0 ${
                      log.type === "success"
                        ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                        : log.type === "warning"
                        ? "bg-amber-950 text-amber-400 border border-amber-800"
                        : log.type === "error"
                        ? "bg-rose-950 text-rose-400 border border-rose-800"
                        : "bg-teal-950 text-teal-400 border border-teal-800"
                    }`}
                  >
                    {log.type.toUpperCase()}
                  </span>
                  <span className="text-slate-300 break-words flex-1">
                    {log.source && <strong className="text-teal-400 font-medium">[{log.source}] </strong>}
                    {log.message}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Col: Active State Matrix Snapshot */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
              Aktif Durum Matrisi
            </h3>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Şema Sürümü:</span>
              <span className="font-mono font-bold text-teal-600 dark:text-teal-400">v{state.version}</span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Vurgu & Stil:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 capitalize">
                {state.themeAccent} • {state.uiThemeStyle}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Arayüz Ölçeği:</span>
              <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                %{Math.round(state.scaleConfig.uiScale * 100)}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Defter Teması:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {state.paperConfig.activeTheme}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Navigasyon Çubuğu:</span>
              <span className="font-bold text-indigo-600 dark:text-indigo-400 capitalize">
                {state.navBarConfig.position.replace("_", " ")} ({state.navBarConfig.height}dp)
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Kayıtlı Bölümler:</span>
              <span className="font-bold text-rose-600 dark:text-rose-400">
                {state.sections.length} Aktif Bölüm
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
