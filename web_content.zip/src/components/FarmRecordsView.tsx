import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Plus,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  LandPlot,
  Sprout,
  DollarSign,
  Calendar,
  Building2,
  Award,
  QrCode,
  Download,
  Share2,
  Store,
  ShoppingCart,
  PhoneCall,
  Check,
  X,
  Sparkles,
  Search,
  Filter,
  Layers,
  Scale,
  Bug,
  Camera,
} from 'lucide-react';
import {
  Language,
  UserProfile,
  FarmPlotRecord,
  FarmActivityLog,
  CertifiedInputSupplier,
  FarmCreditDossier,
} from '../types';
import {
  INITIAL_FARM_PLOTS,
  INITIAL_FARM_LOGS,
  CERTIFIED_INPUT_SUPPLIERS,
  INITIAL_FARM_CREDIT_DOSSIER,
} from '../data/mockData';
import { playKeyTap, playSuccessSound, playSuccessChime } from '../utils/audio';
import CropProfitabilityAnalyzer from './CropProfitabilityAnalyzer';

interface FarmRecordsViewProps {
  language: Language;
  user: UserProfile;
  onNavigateToWallet?: () => void;
  onNavigateToMarket?: () => void;
  onNavigateToPestDoctor?: () => void;
}

type SubTab = 'plots' | 'profitability_analyzer' | 'suppliers' | 'credit_dossier';

export default function FarmRecordsView({
  language,
  user,
  onNavigateToWallet,
  onNavigateToMarket,
  onNavigateToPestDoctor,
}: FarmRecordsViewProps) {
  const isSw = language === 'sw';
  const [activeTab, setActiveTab] = useState<SubTab>('plots');

  // Plots and Logs state
  const [plots, setPlots] = useState<FarmPlotRecord[]>(INITIAL_FARM_PLOTS);
  const [logs, setLogs] = useState<FarmActivityLog[]>(INITIAL_FARM_LOGS);
  const [selectedPlotFilter, setSelectedPlotFilter] = useState<string>('all');

  // Input Suppliers state
  const [supplierCategory, setSupplierCategory] = useState<string>('all');
  const [supplierSearch, setSupplierSearch] = useState<string>('');
  const [orderedProduct, setOrderedProduct] = useState<string | null>(null);

  // New Plot Modal
  const [isAddPlotOpen, setIsAddPlotOpen] = useState<boolean>(false);
  const [newPlotName, setNewPlotName] = useState<string>('');
  const [newPlotLocation, setNewPlotLocation] = useState<string>('');
  const [newPlotAcres, setNewPlotAcres] = useState<string>('3.5');
  const [newPlotCrop, setNewPlotCrop] = useState<string>('Ufuta Mweupe');

  // New Activity Log Modal
  const [isAddLogOpen, setIsAddLogOpen] = useState<boolean>(false);
  const [logPlotId, setLogPlotId] = useState<string>(plots[0]?.id || 'plot-1');
  const [logType, setLogType] = useState<FarmActivityLog['activityType']>('harvest');
  const [logTitle, setLogTitle] = useState<string>('');
  const [logDesc, setLogDesc] = useState<string>('');
  const [logCost, setLogCost] = useState<string>('150000');
  const [logYield, setLogYield] = useState<string>('1200');

  // Dossier downloaded banner state
  const [isDossierDownloaded, setIsDossierDownloaded] = useState<boolean>(false);

  // Filter logs
  const filteredLogs = logs.filter((l) => {
    if (selectedPlotFilter !== 'all' && l.plotId !== selectedPlotFilter) return false;
    return true;
  });

  // Filter suppliers
  const filteredSuppliers = CERTIFIED_INPUT_SUPPLIERS.filter((s) => {
    if (supplierCategory !== 'all' && s.category !== supplierCategory) return false;
    if (supplierSearch.trim()) {
      const q = supplierSearch.toLowerCase();
      const matchComp = s.companyName.toLowerCase().includes(q);
      const matchLoc = s.location.toLowerCase().includes(q);
      const matchProd = s.featuredProducts.some(
        (p) => p.nameSw.toLowerCase().includes(q) || p.nameEn.toLowerCase().includes(q)
      );
      if (!matchComp && !matchLoc && !matchProd) return false;
    }
    return true;
  });

  // Handle Add Plot
  const handleSavePlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlotName.trim()) return;
    playSuccessSound();

    const createdPlot: FarmPlotRecord = {
      id: `plot-${Date.now()}`,
      name: newPlotName,
      location: newPlotLocation || 'Mkoa wa Morogoro',
      sizeAcres: Number(newPlotAcres) || 2.0,
      soilTypeSw: 'Tifu-tifu yenye rutuba (Loamy)',
      soilTypeEn: 'Fertile Loam',
      primaryCropSw: newPlotCrop,
      primaryCropEn: newPlotCrop,
      plantedDate: 'Mwezi Huu',
      expectedHarvestDate: 'Msimu Ujao',
      status: 'growing',
      healthScore: 92,
    };

    setPlots([createdPlot, ...plots]);
    setIsAddPlotOpen(false);
    setNewPlotName('');
  };

  // Handle Add Log
  const handleSaveLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logTitle.trim()) return;
    playSuccessChime();

    const plotFound = plots.find((p) => p.id === logPlotId);
    const createdLog: FarmActivityLog = {
      id: `log-${Date.now()}`,
      plotId: logPlotId,
      plotName: plotFound ? plotFound.name : 'Shamba Langu',
      date: 'Leo',
      activityType: logType,
      titleSw: logTitle,
      titleEn: logTitle,
      descriptionSw: logDesc || 'Kumbukumbu ya shughuli imerekodiwa kikamilifu.',
      descriptionEn: logDesc || 'Activity successfully logged.',
      costTsh: Number(logCost) || 0,
      yieldKg: Number(logYield) || 0,
      revenueTsh: logType === 'sales' ? (Number(logYield) || 0) * 3500 : undefined,
      receiptNumber: `REC-TZ-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    setLogs([createdLog, ...logs]);
    setIsAddLogOpen(false);
    setLogTitle('');
    setLogDesc('');
  };

  const handleOrderProduct = (prodName: string) => {
    playSuccessChime();
    setOrderedProduct(prodName);
    setTimeout(() => {
      setOrderedProduct(null);
    }, 4000);
  };

  const handleApplyCropToPlot = (plotId: string, cropNameSw: string, cropNameEn: string) => {
    setPlots((prev) =>
      prev.map((p) =>
        p.id === plotId
          ? { ...p, primaryCropSw: cropNameSw, primaryCropEn: cropNameEn }
          : p
      )
    );
  };

  const dossier: FarmCreditDossier = INITIAL_FARM_CREDIT_DOSSIER;

  return (
    <div id="farm-records-container" className="space-y-4">
      {/* 1. TOP HEADER BANNER & STATS */}
      <div className="p-4 rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-900 text-[#F7F4E9] border border-emerald-500/40 shadow-md relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950 flex items-center gap-1 shadow-xs">
                <ShieldCheck className="w-3 h-3" />
                <span>{isSw ? 'Uthibitisho Rasmi wa Kilimo' : 'Verified Farm Records'}</span>
              </span>
              <span className="text-[10px] text-emerald-300 font-mono">
                {isSw ? 'Mkulima Idhinishwa' : 'Accredited Producer'}
              </span>
            </div>
            <h2 className="font-display text-lg sm:text-xl font-bold text-white mt-1">
              {isSw
                ? 'Utunzaji wa Kumbukumbu, Pembejeo & Dhamana ya Kifedha'
                : 'Farm Logbook, Certified Inputs & Credit Collateral'}
            </h2>
            <p className="text-xs text-slate-200 mt-1 max-w-2xl leading-relaxed">
              {isSw
                ? 'Weka kumbukumbu za mashamba yako, ungana moja kwa moja na wauzaji wa pembejeo zilizoidhinishwa na TOSCI/TFRA, na toa ripoti rasmi ya uzalishaji inayokubalika na mabenki kama dhamana ya mkopo na bima.'
                : 'Manage farm plot logs, access TOSCI/TFRA verified inputs, and generate bankable production credit collateral dossiers for agricultural loans & insurance.'}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="farm-btn-profit-analyzer"
              onClick={() => {
                playKeyTap();
                setActiveTab('profitability_analyzer');
              }}
              className="py-2 px-3 rounded-2xl bg-gradient-to-r from-amber-400 to-emerald-400 hover:from-amber-300 hover:to-emerald-300 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              <span>{isSw ? 'Uchambuzi wa Faida (AI)' : 'Profitability Analyzer'}</span>
            </button>
            <button
              id="farm-btn-add-plot"
              onClick={() => {
                playKeyTap();
                setIsAddPlotOpen(true);
              }}
              className="py-2 px-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isSw ? 'Sajili Shamba Jipya' : 'Add New Plot'}</span>
            </button>
            <button
              id="farm-btn-add-log"
              onClick={() => {
                playKeyTap();
                setIsAddLogOpen(true);
              }}
              className="py-2 px-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer border border-white/20 transition-all"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{isSw ? 'Rekodi Shughuli' : 'Log Activity'}</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Metric Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 mt-3 border-t border-white/10 relative z-10 text-center">
          <div className="p-2 rounded-2xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-300 block">{isSw ? 'Mashamba Yaliyosajiliwa' : 'Active Plots'}</span>
            <span className="font-display font-bold text-base text-white mt-0.5">
              {plots.length} {isSw ? 'Mashamba' : 'Plots'} ({plots.reduce((acc, p) => acc + p.sizeAcres, 0).toFixed(1)} Ac)
            </span>
          </div>
          <div className="p-2 rounded-2xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-300 block">{isSw ? 'Thamani ya Uzalishaji' : 'Annual Harvest Value'}</span>
            <span className="font-display font-bold text-base text-emerald-300 mt-0.5">
              Tsh {(dossier.grossProductionValueTsh / 1000000).toFixed(1)}M
            </span>
          </div>
          <div className="p-2 rounded-2xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-300 block">{isSw ? 'Kiwango cha Mkopo' : 'Eligible Loan Limit'}</span>
            <span className="font-display font-bold text-base text-amber-300 mt-0.5">
              Tsh {(dossier.recommendedLoanLimitTsh / 1000000).toFixed(1)}M
            </span>
          </div>
          <div className="p-2 rounded-2xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-300 block">{isSw ? 'Alama ya Uaminifu' : 'Agri-Credit Score'}</span>
            <span className="font-display font-bold text-base text-teal-300 mt-0.5">
              {dossier.creditScore}/100 (Tier A)
            </span>
          </div>
        </div>
      </div>

      {/* 2. FOUR CORE SUB-TABS NAVIGATION */}
      <div className="flex p-1 bg-[var(--bg)] rounded-2xl border border-[var(--line)] gap-1 shadow-xs overflow-x-auto">
        <button
          id="farm-subtab-plots"
          onClick={() => {
            playKeyTap();
            setActiveTab('plots');
          }}
          className={`flex-1 min-w-[110px] py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'plots'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <LandPlot className="w-4 h-4 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Mashamba' : 'Plots & Logs'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[var(--forest)]/15 text-[var(--forest)] font-mono">
            {plots.length}
          </span>
        </button>

        <button
          id="farm-subtab-profitability"
          onClick={() => {
            playKeyTap();
            setActiveTab('profitability_analyzer');
          }}
          className={`flex-1 min-w-[130px] py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'profitability_analyzer'
              ? 'bg-[var(--paper)] text-emerald-700 dark:text-emerald-300 shadow-xs border border-emerald-500/30 font-extrabold'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-500 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Uchambuzi wa Faida' : 'Profit Analyzer'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-gradient-to-r from-amber-400 to-emerald-500 text-slate-950 font-black">
            AI
          </span>
        </button>

        <button
          id="farm-subtab-suppliers"
          onClick={() => {
            playKeyTap();
            setActiveTab('suppliers');
          }}
          className={`flex-1 min-w-[110px] py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'suppliers'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Store className="w-4 h-4 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Pembejeo' : 'Inputs'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-800 dark:text-amber-300 font-bold">
            TOSCI
          </span>
        </button>

        <button
          id="farm-subtab-credit"
          onClick={() => {
            playKeyTap();
            setActiveTab('credit_dossier');
          }}
          className={`flex-1 min-w-[110px] py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'credit_dossier'
              ? 'bg-[var(--paper)] text-emerald-700 dark:text-emerald-300 shadow-xs border border-emerald-500/30 font-extrabold'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Award className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Dhamana' : 'Dossier'}</span>
          <span className="hidden xs:inline px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-600 text-white">
            CRDB
          </span>
        </button>
      </div>

      {/* 3. CONTENT AREA PER SUB-TAB */}
      {/* SUB-TAB 1: PLOTS & FARM LOGBOOK */}
      {activeTab === 'plots' && (
        <div className="space-y-4">
          {/* Registered Plots Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)] flex items-center gap-1.5">
                <LandPlot className="w-3.5 h-3.5 text-[var(--forest)]" />
                <span>{isSw ? 'Mashamba Yako Yaliyohakikiwa (Plots)' : 'Your Verified Farm Plots'}</span>
              </h3>
              <span className="text-[10px] text-[var(--ink-soft)]">
                {isSw ? 'Ramani na Hali ya Mazao' : 'Soil & Crop Health Tracking'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {plots.map((plot) => (
                <div
                  key={plot.id}
                  className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-xs space-y-2.5 transition-all hover:border-[var(--forest)]"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-[var(--ink)]">{plot.name}</h4>
                      <p className="text-[11px] text-[var(--ink-soft)]">📍 {plot.location}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                      {plot.sizeAcres} {isSw ? 'Hekari' : 'Acres'}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-[var(--bg)] text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Zao Kuu:' : 'Primary Crop:'}</span>
                      <span className="font-semibold text-[var(--ink)]">{isSw ? plot.primaryCropSw : plot.primaryCropEn}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Udongo:' : 'Soil:'}</span>
                      <span className="text-[11px] text-[var(--ink)]">{isSw ? plot.soilTypeSw : plot.soilTypeEn}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Mavuno Yanayotarajiwa:' : 'Harvest Target:'}</span>
                      <span className="font-semibold text-emerald-600">{plot.expectedHarvestDate}</span>
                    </div>
                  </div>

                  {/* Health Score Progress Bar */}
                  <div>
                    <div className="flex justify-between text-[10px] font-semibold mb-1">
                      <span className="text-[var(--ink-soft)]">{isSw ? 'Alama ya Afya ya Mazao' : 'Crop Health Index'}</span>
                      <span className="text-emerald-600 font-bold">{plot.healthScore}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-[var(--line)] overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                        style={{ width: `${plot.healthScore}%` }}
                      />
                    </div>
                  </div>

                  {/* Quick Action Triggers: AI Profitability & Pest Doctor */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    <button
                      onClick={() => {
                        playKeyTap();
                        setActiveTab('profitability_analyzer');
                      }}
                      className="py-1.5 px-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/20 text-[10.5px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-all"
                    >
                      <Sparkles className="w-3 h-3 text-amber-500 flex-shrink-0" />
                      <span className="truncate">{isSw ? 'Chambua Faida (AI)' : 'Profit Analyzer (AI)'}</span>
                    </button>

                    {onNavigateToPestDoctor && (
                      <button
                        onClick={() => {
                          playKeyTap();
                          onNavigateToPestDoctor();
                        }}
                        className="py-1.5 px-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/25 text-[10.5px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-all"
                      >
                        <Bug className="w-3 h-3 text-amber-600 flex-shrink-0" />
                        <span className="truncate">{isSw ? 'Kagua Wadudu' : 'Check Pests'}</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity Logbook Section */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)] flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-[var(--forest)]" />
                  <span>{isSw ? 'Daftari la Shughuli za Kilimo (Activity Logbook)' : 'Farm Activity Logbook'}</span>
                </h3>
                <p className="text-[10px] text-[var(--ink-soft)]">
                  {isSw
                    ? 'Rekodi za kupalilia, mbolea, viuatilifu, na mauzo hutumika kuthibitisha historia ya uzalishaji.'
                    : 'Weeding, inputs, and sales logs used by financial auditors to certify yield credibility.'}
                </p>
              </div>

              {/* Filter by Plot */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-[var(--ink-soft)]">{isSw ? 'Chuja Shamba:' : 'Filter Plot:'}</span>
                <select
                  value={selectedPlotFilter}
                  onChange={(e) => setSelectedPlotFilter(e.target.value)}
                  className="p-1.5 rounded-xl bg-[var(--paper)] border border-[var(--line)] text-xs text-[var(--ink)] font-semibold"
                >
                  <option value="all">{isSw ? 'Mashamba Yote' : 'All Plots'}</option>
                  {plots.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Logs List */}
            <div className="space-y-2 bg-[var(--paper)] rounded-3xl border border-[var(--line)] p-3 divide-y divide-[var(--line)]">
              {filteredLogs.map((log) => {
                const isHarvest = log.activityType === 'harvest' || log.activityType === 'sales';
                return (
                  <div key={log.id} className="pt-3 first:pt-0 pb-3 last:pb-0 space-y-1.5">
                    <div className="flex items-start justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">
                          {log.activityType === 'harvest'
                            ? '🌾'
                            : log.activityType === 'sales'
                            ? '💰'
                            : log.activityType === 'fertilizer'
                            ? '🧪'
                            : '🌱'}
                        </span>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-bold text-xs text-[var(--ink)]">
                              {isSw ? log.titleSw : log.titleEn}
                            </h4>
                            <span className="text-[10px] px-2 py-0.2 rounded-md bg-[var(--bg)] border border-[var(--line)] text-[var(--ink-soft)] font-medium">
                              {log.plotName}
                            </span>
                            {log.receiptNumber && (
                              <span className="text-[9px] font-mono text-emerald-600 bg-emerald-500/10 px-1.5 py-0.2 rounded">
                                {log.receiptNumber}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-[var(--ink-soft)]">{log.date}</span>
                        </div>
                      </div>

                      {/* Cost / Revenue figures */}
                      <div className="text-right">
                        {log.revenueTsh ? (
                          <div className="font-display font-bold text-xs text-emerald-600">
                            +{isSw ? 'Mauzo:' : 'Rev:'} Tsh {log.revenueTsh.toLocaleString()}
                          </div>
                        ) : log.costTsh ? (
                          <div className="text-[11px] font-semibold text-[var(--soil)]">
                            -{isSw ? 'Gharama:' : 'Cost:'} Tsh {log.costTsh.toLocaleString()}
                          </div>
                        ) : null}
                        {log.yieldKg && (
                          <div className="text-[10px] text-[var(--ink-soft)] font-mono">
                            {log.yieldKg.toLocaleString()} kg ({((log.yieldKg || 0) / 1000).toFixed(1)} MT)
                          </div>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-[var(--ink-soft)] pl-7 leading-relaxed">
                      {isSw ? log.descriptionSw : log.descriptionEn}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB: AI PROFITABILITY ANALYZER */}
      {activeTab === 'profitability_analyzer' && (
        <CropProfitabilityAnalyzer
          language={language}
          user={user}
          plots={plots}
          onApplyCropToPlot={handleApplyCropToPlot}
          onNavigateToSuppliers={() => setActiveTab('suppliers')}
          onNavigateToCreditDossier={() => setActiveTab('credit_dossier')}
        />
      )}

      {/* SUB-TAB 2: SOKO LA MOJA KWA MOJA LA PEMBEJEO (CERTIFIED INPUT SUPPLIERS) */}
      {activeTab === 'suppliers' && (
        <div className="space-y-3">
          {/* Supplier Search & Category Chips */}
          <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] space-y-2.5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-bold text-xs text-[var(--ink)] flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-[var(--forest)]" />
                  <span>{isSw ? 'Wauzaji Walioidhinishwa wa Pembejeo za Kilimo' : 'TOSCI & TFRA Accredited Input Dealers'}</span>
                </h3>
                <p className="text-[10px] text-[var(--ink-soft)]">
                  {isSw
                    ? 'Nunua mbegu safi, mbolea za asili, na dawa zisizo na kemikali haramu moja kwa moja bila madalali.'
                    : 'Direct procurement of genuine seed, fertilizers, and biological plant health inputs with verified QR seals.'}
                </p>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                {isSw ? 'Dhamana ya Asilimia 100 Ubora' : '100% Genuine Certified'}
              </span>
            </div>

            {/* Search and Category Filter */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              <div className="sm:col-span-6 relative">
                <Search className="w-3.5 h-3.5 text-[var(--ink-soft)] absolute left-3 top-3 pointer-events-none" />
                <input
                  type="text"
                  value={supplierSearch}
                  onChange={(e) => setSupplierSearch(e.target.value)}
                  placeholder={isSw ? 'Tafuta mbegu, mbolea, kampuni (mf. Tanseed, Minjingu, Balton)...' : 'Search inputs, company...'}
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] placeholder:text-[var(--ink-soft)] focus:outline-none"
                />
              </div>

              <div className="sm:col-span-6 flex gap-1 overflow-x-auto no-scrollbar py-0.5">
                {[
                  { id: 'all', sw: 'Zote', en: 'All' },
                  { id: 'seeds', sw: '🌱 Mbegu (TOSCI)', en: '🌱 Seeds (TOSCI)' },
                  { id: 'fertilizer', sw: '🧪 Mbolea (TFRA)', en: '🧪 Fertilizer (TFRA)' },
                  { id: 'chemicals', sw: '🛡️ Kinga (TPRI)', en: '🛡️ Crop Care (TPRI)' },
                  { id: 'irrigation', sw: '💧 Umwagiliaji', en: '💧 Irrigation' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      playKeyTap();
                      setSupplierCategory(c.id);
                    }}
                    className={`px-2.5 py-1.5 rounded-xl text-[10px] font-semibold whitespace-nowrap cursor-pointer transition-all border ${
                      supplierCategory === c.id
                        ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)]'
                        : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
                    }`}
                  >
                    {isSw ? c.sw : c.en}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Feedback banner when product ordered */}
          {orderedProduct && (
            <div className="p-3 rounded-2xl bg-emerald-600 text-white text-xs font-bold flex items-center justify-between shadow-md animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>
                  {isSw
                    ? `Agizo la "${orderedProduct}" limepokelewa! Mfanyabiashara anawasiliana nawe sasa.`
                    : `Order placed for "${orderedProduct}"! Direct supplier is dispatching.`}
                </span>
              </div>
              <button
                onClick={() => setOrderedProduct(null)}
                className="text-white/80 hover:text-white p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Supplier Cards List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredSuppliers.map((supplier) => (
              <div
                key={supplier.id}
                className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-xs space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="px-2 py-0.5 rounded-md text-[9px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                          {supplier.certificationBody} Certified
                        </span>
                        <span className="text-[10px] font-mono text-[var(--ink-soft)]">
                          {supplier.certNumber}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-[var(--ink)] mt-1">
                        {supplier.companyName}
                      </h4>
                      <p className="text-[11px] text-[var(--ink-soft)]">📍 {supplier.location}</p>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="text-xs font-bold text-amber-500">★ {supplier.rating}</span>
                      <span className="text-[10px] text-emerald-600 block font-semibold flex items-center justify-end gap-0.5 mt-0.5">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{isSw ? 'Imehakikiwa' : 'Verified'}</span>
                      </span>
                    </div>
                  </div>

                  {/* Featured Products Table */}
                  <div className="mt-3 space-y-1.5">
                    <span className="text-[10px] font-bold uppercase text-[var(--ink-soft)] block">
                      {isSw ? 'Bidhaa Kuu Zilizoidhinishwa:' : 'Authorized Products:'}
                    </span>
                    <div className="space-y-1">
                      {supplier.featuredProducts.map((prod, idx) => (
                        <div
                          key={idx}
                          className="p-2 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between text-xs"
                        >
                          <div>
                            <div className="font-semibold text-[var(--ink)]">
                              {isSw ? prod.nameSw : prod.nameEn}
                            </div>
                            <div className="text-[10px] text-[var(--ink-soft)]">{prod.packSize}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-display font-bold text-[var(--forest)]">
                              {prod.priceDisplay}
                            </span>
                            <button
                              onClick={() => handleOrderProduct(isSw ? prod.nameSw : prod.nameEn)}
                              className="py-1 px-2.5 rounded-lg bg-[var(--forest)] text-[#F7F4E9] text-[10px] font-bold hover:bg-[var(--forest-dark)] transition-all cursor-pointer flex items-center gap-1"
                            >
                              <ShoppingCart className="w-3 h-3" />
                              <span>{isSw ? 'Agiza' : 'Order'}</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Direct Contact Button */}
                <div className="pt-2 border-t border-[var(--line)] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 text-[var(--ink-soft)] font-mono text-[11px]">
                    <PhoneCall className="w-3 h-3 text-[var(--forest)]" />
                    <span>{supplier.phone}</span>
                  </div>
                  <a
                    href={`tel:${supplier.phone}`}
                    className="text-xs font-bold text-[var(--forest)] hover:underline"
                  >
                    {isSw ? 'Piga Simu Moja kwa Moja' : 'Call Depot Direct'}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: MSAADA WA KIFEDHA & DHAMANA YA UZALISHAJI (BANK CREDIT DOSSIER) */}
      {activeTab === 'credit_dossier' && (
        <div className="space-y-4">
          {/* Dossier Action Callout */}
          <div className="p-4 rounded-3xl bg-[var(--paper)] border-2 border-emerald-500/40 shadow-md space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--line)]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-600/20">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                      {dossier.tier}
                    </span>
                    <span className="text-[10px] text-[var(--ink-soft)] font-mono">
                      Tarehe: {dossier.issueDate}
                    </span>
                  </div>
                  <h3 className="font-display text-base font-bold text-[var(--ink)] mt-0.5">
                    {isSw
                      ? 'Taarifa Rasmi ya Uzalishaji wa Kilimo Kama Dhamana (Collateral Dossier)'
                      : 'Certified Agricultural Production Collateral Report'}
                  </h3>
                </div>
              </div>

              {/* Download / Share Report */}
              <div className="flex items-center gap-2">
                <button
                  id="download-dossier-btn"
                  onClick={() => {
                    playSuccessSound();
                    setIsDossierDownloaded(true);
                  }}
                  className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isSw ? 'Pakua PDF ya Benki' : 'Export Bank PDF'}</span>
                </button>
              </div>
            </div>

            {/* Download Success Notice */}
            {isDossierDownloaded && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>
                  {isSw
                    ? 'Ripoti ya dhamana ya uzalishaji imezalishwa na kuthibitishwa na nambari ya QR!'
                    : 'Production collateral dossier generated with active digital bank verification seal!'}
                </span>
              </div>
            )}

            {/* OFFICIAL BANKABLE DOSSIER CARD */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 text-white border border-emerald-500/40 space-y-4">
              {/* Dossier Header with Seal */}
              <div className="flex items-start justify-between border-b border-white/10 pb-3">
                <div>
                  <div className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-bold">
                    TANZANIA AGRICULTURAL CREDIT CLEARINGHOUSE
                  </div>
                  <h4 className="font-display text-lg font-bold text-white mt-0.5">
                    {dossier.farmerName}
                  </h4>
                  <div className="text-xs text-slate-300 font-mono">
                    NIDA: {dossier.nationalIdMasked}
                  </div>
                </div>

                <div className="text-right">
                  <div className="w-14 h-14 rounded-xl bg-white p-1 ml-auto shadow-md">
                    <QrCode className="w-full h-full text-slate-950" />
                  </div>
                  <span className="text-[8px] font-mono text-emerald-300 block mt-1">
                    {dossier.qrVerificationCode}
                  </span>
                </div>
              </div>

              {/* Assessment Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 block">{isSw ? 'Hekari Zilizothibitishwa' : 'Verified Acres'}</span>
                  <span className="font-display text-base font-bold text-white mt-1">
                    {dossier.totalVerifiedAcres} Acres
                  </span>
                  <span className="text-[10px] text-emerald-400 block">GPS Tagged</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 block">{isSw ? 'Msimu wa Kilimo' : 'Verified Seasons'}</span>
                  <span className="font-display text-base font-bold text-white mt-1">
                    {dossier.activeSeasonsCount} Seasons
                  </span>
                  <span className="text-[10px] text-slate-300 block">Avg {dossier.averageAnnualYieldMt} MT/Yr</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] text-slate-400 block">{isSw ? 'Thamani ya Mavuno Ghafi' : 'Gross Annual Harvest'}</span>
                  <span className="font-display text-base font-bold text-amber-400 mt-1">
                    Tsh {dossier.grossProductionValueTsh.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-300 block">Net: Tsh {dossier.netProductionProfitTsh.toLocaleString()}</span>
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/50">
                  <span className="text-[10px] text-emerald-200 block font-bold">{isSw ? 'Kiwango cha Mkopo Kinachopendekezwa' : 'Max Loan Collateral Value'}</span>
                  <span className="font-display text-lg font-black text-emerald-300 mt-1">
                    Tsh {dossier.recommendedLoanLimitTsh.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-emerald-200 block">Tier A Rating</span>
                </div>
              </div>

              {/* Certified Partner Banks */}
              <div className="pt-3 border-t border-white/10">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  {isSw ? 'Mabenki na Bima Zinazokubali Ripoti Hii Kama Dhamana:' : 'Partner Banks & Underwriters Accepting This Dossier:'}
                </span>
                <div className="flex flex-wrap gap-2">
                  {dossier.certifiedBankPartners.map((bank, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-xl bg-white/10 border border-white/15 text-xs text-slate-200 font-semibold flex items-center gap-1.5"
                    >
                      <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{bank}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Explanatory Steps */}
            <div className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs space-y-2">
              <h5 className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>{isSw ? 'Jinsi ya Kutumia Taarifa Hii Kupata Mkopo au Bima:' : 'How to Use This Dossier for Loan & Insurance Approvals:'}</span>
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-[var(--ink-soft)]">
                <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                  <strong className="text-[var(--ink)] block mb-0.5">
                    1. {isSw ? 'Weka Kumbukumbu za Kila Siku' : 'Log Daily Activities'}
                  </strong>
                  <span>
                    {isSw
                      ? 'Rekodi kila palizi, mbolea na risiti ya pembejeo ili kuongeza alama yako ya uaminifu (Credit Score).'
                      : 'Consistently record labor, fertilizer, and seed receipts to boost creditworthiness.'}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                  <strong className="text-[var(--ink)] block mb-0.5">
                    2. {isSw ? 'Pakua Ripoti ya QR Code' : 'Export Verified PDF'}
                  </strong>
                  <span>
                    {isSw
                      ? 'Pakua ripoti hii na iwasilishe kwa afisa mikopo wa CRDB, NMB au TADB tawi lolote.'
                      : 'Present the QR-coded PDF to agricultural credit loan officers at your regional branch.'}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                  <strong className="text-[var(--ink)] block mb-0.5">
                    3. {isSw ? 'Pata Bima ya Kilimo' : 'Secure Crop Insurance'}
                  </strong>
                  <span>
                    {isSw
                      ? 'Dhamana hii inakupatia bima ya kulinda mavuno dhidi ya ukame, mafuriko au wadudu.'
                      : 'Eligible for comprehensive subsidized crop insurance against drought or pest shock.'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD NEW PLOT */}
      <AnimatePresence>
        {isAddPlotOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[var(--paper)] border border-[var(--line)] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden p-5 space-y-4"
            >
              <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-white flex items-center justify-center">
                    <LandPlot className="w-4 h-4" />
                  </div>
                  <h3 className="font-bold text-sm text-[var(--ink)]">
                    {isSw ? 'Sajili Shamba Jipya' : 'Register New Farm Plot'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsAddPlotOpen(false)}
                  className="p-1 rounded-lg text-[var(--ink-soft)] hover:bg-[var(--line)]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSavePlot} className="space-y-3 text-xs">
                <div>
                  <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                    {isSw ? 'Jina la Shamba (mf. Shamba la Bonde, Plot D)' : 'Plot Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newPlotName}
                    onChange={(e) => setNewPlotName(e.target.value)}
                    placeholder="mf. Shamba la Ufuta - Kilosa"
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Ukubwa (Hekari / Acres)' : 'Size in Acres'}
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      min="0.5"
                      required
                      value={newPlotAcres}
                      onChange={(e) => setNewPlotAcres(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Zao Linalolimwa' : 'Primary Crop'}
                    </label>
                    <input
                      type="text"
                      required
                      value={newPlotCrop}
                      onChange={(e) => setNewPlotCrop(e.target.value)}
                      placeholder="Ufuta / Soya / Parachichi"
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                    {isSw ? 'Eneo / Mkoa / Wilaya' : 'Location / District'}
                  </label>
                  <input
                    type="text"
                    value={newPlotLocation}
                    onChange={(e) => setNewPlotLocation(e.target.value)}
                    placeholder="mf. Iringa Vijijini au Morogoro"
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddPlotOpen(false)}
                    className="py-2 px-3 rounded-xl border border-[var(--line)] text-[var(--ink-soft)] font-bold text-xs"
                  >
                    {isSw ? 'Ghairi' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="py-2 px-4 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs hover:bg-[var(--forest-dark)]"
                  >
                    {isSw ? 'Hifadhi Shamba' : 'Save Plot'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: ADD ACTIVITY LOG */}
      <AnimatePresence>
        {isAddLogOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[var(--paper)] border border-[var(--line)] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden p-5 space-y-4"
            >
              <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-white flex items-center justify-center">
                    <FileText className="w-4 h-4" />
                  </div>
                  <h3 className="font-bold text-sm text-[var(--ink)]">
                    {isSw ? 'Rekodi Shughuli ya Shamba' : 'Log Farm Activity'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsAddLogOpen(false)}
                  className="p-1 rounded-lg text-[var(--ink-soft)] hover:bg-[var(--line)]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveLog} className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Shamba Husika' : 'Target Plot'}
                    </label>
                    <select
                      value={logPlotId}
                      onChange={(e) => setLogPlotId(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    >
                      {plots.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Aina ya Shughuli' : 'Activity Type'}
                    </label>
                    <select
                      value={logType}
                      onChange={(e) => setLogType(e.target.value as any)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    >
                      <option value="harvest">{isSw ? '🌾 Mavuno (Harvest)' : 'Harvest'}</option>
                      <option value="sales">{isSw ? '💰 Mauzo (Sales)' : 'Sales'}</option>
                      <option value="fertilizer">{isSw ? '🧪 Mbolea (Fertilizer)' : 'Fertilizer'}</option>
                      <option value="weeding">{isSw ? '🌱 Palizi (Weeding)' : 'Weeding'}</option>
                      <option value="planting">{isSw ? '🚜 Kupanda (Planting)' : 'Planting'}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                    {isSw ? 'Kichwa cha Shughuli' : 'Activity Title'}
                  </label>
                  <input
                    type="text"
                    required
                    value={logTitle}
                    onChange={(e) => setLogTitle(e.target.value)}
                    placeholder={isSw ? 'mf. Mavuno ya Ufuta Magunia 30' : 'e.g. Sesame Harvest 30 bags'}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Gharama (Tsh)' : 'Cost (Tsh)'}
                    </label>
                    <input
                      type="number"
                      value={logCost}
                      onChange={(e) => setLogCost(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                      {isSw ? 'Ujazo / Mavuno (Kg)' : 'Yield (Kg)'}
                    </label>
                    <input
                      type="number"
                      value={logYield}
                      onChange={(e) => setLogYield(e.target.value)}
                      className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[var(--ink-soft)] block mb-1">
                    {isSw ? 'Maelezo ya Ziada' : 'Description'}
                  </label>
                  <textarea
                    rows={2}
                    value={logDesc}
                    onChange={(e) => setLogDesc(e.target.value)}
                    placeholder={isSw ? 'Wafanyakazi, pembejeo zilizotumika au mnunuzi...' : 'Notes...'}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddLogOpen(false)}
                    className="py-2 px-3 rounded-xl border border-[var(--line)] text-[var(--ink-soft)] font-bold text-xs"
                  >
                    {isSw ? 'Ghairi' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="py-2 px-4 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs hover:bg-[var(--forest-dark)]"
                  >
                    {isSw ? 'Hifadhi Rekodi' : 'Save Log'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
