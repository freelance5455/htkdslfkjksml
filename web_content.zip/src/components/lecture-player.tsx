"use client";

import Image from "next/image";
import { useRef, useState } from "react";
import { ExternalLink, Pause, Play, RotateCcw, RotateCw } from "lucide-react";
import type { Lecture } from "@/data/lectures";
import { formatTime, toArabicDigits } from "@/lib/site";

const SPEEDS = [1, 1.25, 1.5, 2];

/**
 * Lecture browser for scholars' recordings.
 * - `youtubeId`: the video plays embedded right on this page (no navigation).
 * - `audioSrc`: a real audio file plays through an <audio> element with seek, ±10s, speed and chapters.
 * - Otherwise the cover links out to the recording's source.
 */
export function LecturePlayer({ lectures }: { lectures: Lecture[] }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speedIndex, setSpeedIndex] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const lecture = lectures[activeIndex];
  if (!lecture) return null;

  const mode: "video" | "audio" | "link" = lecture.youtubeId
    ? "video"
    : lecture.audioSrc
      ? "audio"
      : "link";
  const speed = SPEEDS[speedIndex];
  const progressPct = duration ? Math.min((time / duration) * 100, 100) : 0;
  const chapters = lecture.chapters ?? [];

  let activeChapter = 0;
  chapters.forEach((c, i) => {
    if (c.start <= time) activeChapter = i;
  });
  const chapter = chapters[activeChapter];

  const seek = (to: number) => {
    const clamped = Math.min(Math.max(to, 0), duration || to);
    setTime(clamped);
    if (audioRef.current) audioRef.current.currentTime = clamped;
  };

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      audio.play().catch(() => setPlaying(false));
    } else {
      audio.pause();
    }
  };

  const changeSpeed = () => {
    const next = (speedIndex + 1) % SPEEDS.length;
    setSpeedIndex(next);
    if (audioRef.current) audioRef.current.playbackRate = SPEEDS[next];
  };

  const selectLecture = (index: number) => {
    audioRef.current?.pause();
    setActiveIndex(index);
    setTime(0);
    setDuration(0);
    setPlaying(false);
    setSpeedIndex(0);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
      <article className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.03] shadow-[0_40px_80px_-40px_rgba(0,0,0,0.6)] backdrop-blur">
        {/* Media */}
        {mode === "video" && lecture.youtubeId ? (
          <div className="relative aspect-video w-full bg-navy-deep">
            <iframe
              key={lecture.youtubeId}
              src={`https://www.youtube-nocookie.com/embed/${lecture.youtubeId}?rel=0&modestbranding=1`}
              title={lecture.title}
              className="absolute inset-0 size-full"
              loading="lazy"
              allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
            />
          </div>
        ) : (
          <div className="relative aspect-[16/9] overflow-hidden">
            <Image
              key={lecture.image}
              src={lecture.image}
              alt=""
              fill
              sizes="(min-width: 1024px) 60vw, 100vw"
              className="object-cover"
              priority={activeIndex === 0}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-deep via-navy-deep/30 to-transparent" aria-hidden="true" />
            {mode === "audio" ? (
              <button
                type="button"
                onClick={togglePlay}
                aria-label={playing ? "إيقاف مؤقت" : "تشغيل المحاضرة"}
                className="group absolute inset-0 grid place-items-center"
              >
                <span className="grid size-20 place-items-center rounded-full bg-gradient-to-b from-gold-light to-gold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-transform group-hover:scale-105 group-active:scale-95">
                  {playing ? <Pause className="size-7" aria-hidden="true" /> : <Play className="size-7 -scale-x-100" aria-hidden="true" />}
                </span>
              </button>
            ) : (
              <a
                href={lecture.source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group absolute inset-0 grid place-items-center"
                aria-label={`افتح المحاضرة في المصدر: ${lecture.title}`}
              >
                <span className="inline-flex items-center gap-3 rounded-full bg-gradient-to-b from-gold-light to-gold px-7 py-3.5 font-semibold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-transform group-hover:scale-105">
                  <ExternalLink className="size-5" aria-hidden="true" />
                  استمع إلى المحاضرة
                </span>
              </a>
            )}
          </div>
        )}

        <div className="p-6 sm:p-8">
          <span className="rounded-full border border-gold/30 px-3 py-1 text-xs text-gold-light">{lecture.category}</span>
          <h3 className="mt-4 font-serif text-3xl leading-tight font-bold text-ivory sm:text-4xl">{lecture.title}</h3>
          <p className="mt-3 text-sm text-ivory/60">
            <span className="text-gold-light">{lecture.speaker}</span>
            {lecture.series && <> — {lecture.series}</>}
          </p>
          <p className="mt-2 text-sm leading-7 text-ivory/50">{lecture.speakerNote}</p>

          {mode === "audio" && (
            <>
              <div className="mt-8 space-y-2">
                <label htmlFor="lecture-seek" className="text-sm text-ivory/60">
                  موضع التشغيل
                </label>
                <input
                  id="lecture-seek"
                  type="range"
                  min={0}
                  max={Math.max(Math.round(duration), 1)}
                  step={1}
                  value={Math.floor(time)}
                  onChange={(e) => seek(Number(e.target.value))}
                  className="h-1.5 w-full cursor-pointer appearance-none rounded-full accent-gold"
                  style={{
                    direction: "ltr",
                    background: `linear-gradient(to right, #B69A69 ${progressPct}%, rgba(255,255,255,0.1) 0)`,
                  }}
                />
                <div className="flex justify-between text-xs tabular-nums text-ivory/50">
                  <span>{formatTime(time)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    aria-label="تقديم ١٠ ثوانٍ"
                    onClick={() => seek(time + 10)}
                    className="grid size-11 place-items-center rounded-full border border-white/10 text-ivory/80 transition-colors hover:border-gold hover:text-gold-light"
                  >
                    <RotateCw className="size-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={togglePlay}
                    aria-label={playing ? "إيقاف مؤقت" : "تشغيل"}
                    className="grid size-14 place-items-center rounded-full bg-gradient-to-b from-gold-light to-gold text-navy transition-transform active:scale-95"
                  >
                    {playing ? <Pause className="size-6" aria-hidden="true" /> : <Play className="size-6 -scale-x-100" aria-hidden="true" />}
                  </button>
                  <button
                    type="button"
                    aria-label="إرجاع ١٠ ثوانٍ"
                    onClick={() => seek(time - 10)}
                    className="grid size-11 place-items-center rounded-full border border-white/10 text-ivory/80 transition-colors hover:border-gold hover:text-gold-light"
                  >
                    <RotateCcw className="size-4" aria-hidden="true" />
                  </button>
                </div>
                <button
                  type="button"
                  aria-label="سرعة التشغيل"
                  onClick={changeSpeed}
                  className="rounded-full border border-white/10 px-4 py-2 text-sm text-ivory/80 tabular-nums transition-colors hover:border-gold hover:text-gold-light"
                >
                  ×{toArabicDigits(speed)}
                </button>
              </div>

              {chapters.length > 0 && (
                <>
                  <div className="mt-8 rounded-2xl border border-gold/20 bg-navy/40 p-5" aria-live="polite">
                    <p className="text-xs text-gold-light">
                      {chapter ? `الفصل ${toArabicDigits(activeChapter + 1)}: ${chapter.title}` : ""}
                    </p>
                    {chapter?.text && <p className="mt-3 font-serif text-xl leading-[2] text-ivory/90">{chapter.text}</p>}
                  </div>
                  <ol className="mt-6 grid gap-2 sm:grid-cols-2">
                    {chapters.map((c, i) => {
                      const selected = i === activeChapter;
                      return (
                        <li key={`${lecture.id}-${i}`}>
                          <button
                            type="button"
                            onClick={() => seek(c.start)}
                            aria-current={selected ? "true" : undefined}
                            className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-start text-sm transition-colors ${
                              selected ? "border-gold/60 bg-gold/10 text-ivory" : "border-white/5 text-ivory/60 hover:border-white/20"
                            }`}
                          >
                            <span className="font-serif text-gold">{toArabicDigits(i + 1)}</span>
                            <span className="flex-1">{c.title}</span>
                            <span className="text-xs tabular-nums text-ivory/40">{formatTime(c.start)}</span>
                          </button>
                        </li>
                      );
                    })}
                  </ol>
                </>
              )}

              <audio
                key={lecture.id}
                ref={audioRef}
                src={lecture.audioSrc}
                preload="metadata"
                className="hidden"
                onPlay={() => setPlaying(true)}
                onPause={() => setPlaying(false)}
                onEnded={() => setPlaying(false)}
                onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
                onLoadedMetadata={(e) => {
                  const d = e.currentTarget.duration;
                  if (Number.isFinite(d)) setDuration(d);
                }}
              />
            </>
          )}

          <a
            href={lecture.source.url}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-3 rounded-full border border-gold/50 px-6 py-3 text-sm text-gold-light transition-all hover:bg-gold hover:text-navy"
          >
            <ExternalLink className="size-4" aria-hidden="true" />
            المصدر: {lecture.source.label}
          </a>
        </div>
      </article>

      {/* Lecture list */}
      <ul className="flex flex-col gap-4" aria-label="قائمة المحاضرات">
        {lectures.map((item, index) => {
          const selected = index === activeIndex;
          return (
            <li key={item.id}>
              <button
                type="button"
                aria-current={selected ? "true" : undefined}
                onClick={() => selectLecture(index)}
                className={`group flex w-full items-center gap-4 rounded-2xl border p-3 text-start transition-all duration-300 ${
                  selected ? "border-gold/60 bg-gold/10" : "border-white/10 bg-white/[0.03] hover:-translate-x-1 hover:border-gold/40"
                }`}
              >
                <span className="relative aspect-[4/3] w-28 shrink-0 overflow-hidden rounded-xl">
                  <Image src={item.image} alt="" fill sizes="112px" className="object-cover transition-transform duration-500 group-hover:scale-110" />
                  <span className="absolute inset-0 grid place-items-center bg-navy/30">
                    <Play className="size-5 -scale-x-100 text-ivory" aria-hidden="true" />
                  </span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-serif text-lg font-bold text-ivory">{item.title}</span>
                  <span className="mt-1 block truncate text-xs text-ivory/55">{item.speaker}</span>
                  <span className="mt-2 flex items-center gap-3 text-xs text-gold-light">
                    <span>{item.category}</span>
                    {item.youtubeId && (
                      <>
                        <span className="size-1 rounded-full bg-gold/50" />
                        <span>فيديو</span>
                      </>
                    )}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
