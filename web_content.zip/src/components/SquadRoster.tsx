import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Copy, 
  Check, 
  Trash2, 
  Award, 
  Smartphone, 
  Crosshair, 
  ShieldCheck, 
  Flame,
  Plus
} from 'lucide-react';
import { INITIAL_ROSTER } from '../data/freeFireData';
import { Player, PlayerRole, RankTier } from '../types';
import { sounds } from '../utils/soundEffects';

export const SquadRoster: React.FC = () => {
  const [roster, setRoster] = useState<Player[]>(INITIAL_ROSTER);
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('All');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New player form state
  const [newIgn, setNewIgn] = useState('');
  const [newUid, setNewUid] = useState('');
  const [newRole, setNewRole] = useState<PlayerRole>('Rusher');
  const [newRank, setNewRank] = useState<RankTier>('Grandmaster');
  const [newHsRate, setNewHsRate] = useState<number>(75);
  const [newKd, setNewKd] = useState<number>(5.2);
  const [newGun, setNewGun] = useState('M1887 & MP40');
  const [newDevice, setNewDevice] = useState('iPhone 15 Pro Max');

  const roles: (PlayerRole | 'All')[] = ['All', 'IGL', 'Rusher', 'Sniper', 'Flanker', 'Support'];

  const filteredRoster = selectedRoleFilter === 'All'
    ? roster
    : roster.filter(p => p.role === selectedRoleFilter);

  const copyUid = (uid: string) => {
    navigator.clipboard.writeText(uid);
    setCopiedUid(uid);
    sounds.playClick();
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const deletePlayer = (id: string) => {
    sounds.playClick();
    setRoster(prev => prev.filter(p => p.id !== id));
  };

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIgn.trim() || !newUid.trim()) return;
    sounds.playClick();

    const created: Player = {
      id: 'p-' + Date.now(),
      ign: newIgn.trim(),
      uid: newUid.trim(),
      role: newRole,
      rank: newRank,
      headshotRate: Number(newHsRate),
      kd: Number(newKd),
      favoriteGun: newGun.trim(),
      device: newDevice.trim(),
      status: 'Active'
    };

    setRoster(prev => [...prev, created]);
    setShowAddModal(false);
    setNewIgn('');
    setNewUid('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 font-rajdhani">
                GUILD & SQUAD ROSTER
              </span>
              <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
                <Users className="w-3.5 h-3.5" /> 4-Man Starting Lineup + Subs
              </span>
            </div>
            <h2 className="text-2xl font-bold font-heading text-white">
              Esports Guild & Lineup Operations
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Track player roles, verified in-game UID numbers, competitive K/D ratios, headshot percentages, and weapon proficiencies.
            </p>
          </div>

          <button
            onClick={() => { setShowAddModal(true); sounds.playClick(); }}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg shadow-orange-600/30 transition-all cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Squad Member</span>
          </button>
        </div>

        {/* Roles Filter Bar */}
        <div className="mt-5 pt-4 border-t border-slate-700/60 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {roles.map((r) => (
            <button
              key={r}
              onClick={() => { setSelectedRoleFilter(r); sounds.playClick(); }}
              className={`px-3 py-1 text-xs font-bold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                selectedRoleFilter === r
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'bg-[#151a2d] text-slate-400 hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Roster Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRoster.map((player) => (
          <div
            key={player.id}
            className="bg-[#101423] border border-slate-800 hover:border-orange-500/50 rounded-2xl p-5 space-y-4 shadow-xl transition-all relative group"
          >
            {/* Top Rank & Role */}
            <div className="flex items-center justify-between">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-rajdhani ${
                player.role === 'IGL' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' :
                player.role === 'Rusher' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                player.role === 'Sniper' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' :
                'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                ROLE: {player.role}
              </span>

              <div className="flex items-center gap-1 text-[11px] font-bold text-amber-400 font-rajdhani">
                <Award className="w-3.5 h-3.5 text-yellow-400" />
                <span>{player.rank}</span>
              </div>
            </div>

            {/* IGN & UID */}
            <div>
              <div className="font-heading font-extrabold text-base text-white tracking-wide">
                {player.ign}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-slate-400 font-mono">UID: {player.uid}</span>
                <button
                  onClick={() => copyUid(player.uid)}
                  className="text-slate-500 hover:text-orange-400 transition-colors cursor-pointer"
                  title="Copy UID"
                >
                  {copiedUid === player.uid ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Combat Stats: HS% and K/D */}
            <div className="grid grid-cols-2 gap-2.5 bg-[#090b14] p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">HEADSHOT RATE</span>
                <span className="text-lg font-bold font-mono text-red-400 flex items-center gap-1">
                  ⚡ {player.headshotRate}%
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">K/D RATIO</span>
                <span className="text-lg font-bold font-mono text-amber-300">
                  {player.kd}
                </span>
              </div>
            </div>

            {/* Hardware & Weapons */}
            <div className="space-y-1.5 text-xs text-slate-300 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-slate-500" /> Device:
                </span>
                <span className="font-semibold text-white truncate max-w-[170px]">{player.device}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 flex items-center gap-1">
                  <Crosshair className="w-3.5 h-3.5 text-slate-500" /> Loadout:
                </span>
                <span className="font-semibold text-orange-400 truncate max-w-[170px]">{player.favoriteGun}</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                player.status === 'Active' ? 'bg-emerald-950/80 text-emerald-300' : 'bg-slate-800 text-slate-400'
              }`}>
                {player.status}
              </span>

              <button
                onClick={() => deletePlayer(player.id)}
                className="text-slate-500 hover:text-red-400 transition-colors p-1"
                title="Remove Member"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Player Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#121626] border border-orange-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-heading font-bold text-lg text-white">Add Squad Member</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddPlayer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">In-Game Name (IGN)</label>
                <input
                  type="text"
                  placeholder="e.g. ⚡ DRAGON_KILLER ⚡"
                  value={newIgn}
                  onChange={e => setNewIgn(e.target.value)}
                  required
                  className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">In-Game UID</label>
                <input
                  type="text"
                  placeholder="e.g. 192847582"
                  value={newUid}
                  onChange={e => setNewUid(e.target.value)}
                  required
                  className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Role</label>
                  <select
                    value={newRole}
                    onChange={e => setNewRole(e.target.value as PlayerRole)}
                    className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="IGL">IGL</option>
                    <option value="Rusher">Rusher</option>
                    <option value="Sniper">Sniper</option>
                    <option value="Flanker">Flanker</option>
                    <option value="Support">Support</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Rank Tier</label>
                  <select
                    value={newRank}
                    onChange={e => setNewRank(e.target.value as RankTier)}
                    className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="Grandmaster">Grandmaster</option>
                    <option value="Master">Master</option>
                    <option value="Elite Master">Elite Master</option>
                    <option value="Heroic">Heroic</option>
                    <option value="Diamond">Diamond</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Headshot Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newHsRate}
                    onChange={e => setNewHsRate(Number(e.target.value))}
                    className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">K/D Ratio</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newKd}
                    onChange={e => setNewKd(Number(e.target.value))}
                    className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Preferred Weapons</label>
                <input
                  type="text"
                  placeholder="e.g. M1887 & Woodpecker"
                  value={newGun}
                  onChange={e => setNewGun(e.target.value)}
                  className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Device Model</label>
                <input
                  type="text"
                  placeholder="e.g. ROG Phone 8 Pro"
                  value={newDevice}
                  onChange={e => setNewDevice(e.target.value)}
                  className="w-full bg-[#0a0d18] border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg"
                >
                  Save Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
