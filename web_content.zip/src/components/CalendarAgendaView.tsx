import React, { useState } from 'react';
import {
  Search,
  ChevronRight,
  MapPin,
} from 'lucide-react';
import { CalendarDay, HebrewEvent, LocationPreset } from '../types';
import { getCalendarDay } from '../services/hebrewCalendarService';

interface CalendarAgendaViewProps {
  currentDate: Date;
  location: LocationPreset;
  events: HebrewEvent[];
  onSelectDate: (date: Date) => void;
  onOpenAddEvent: () => void;
}

export const CalendarAgendaView: React.FC<CalendarAgendaViewProps> = ({
  currentDate,
  location,
  events,
  onSelectDate,
  onOpenAddEvent,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'holidays' | 'fasts' | 'events'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Generate agenda items for the next 180 days
  const agendaItems: Array<{
    date: Date;
    day: CalendarDay;
    type: 'holiday' | 'fast' | 'event' | 'roshchodesh' | 'shabbat';
    title: string;
    hebrewTitle: string;
    categoryLabel: string;
    color: string;
    details?: string;
    location?: string;
  }> = [];

  const baseDate = new Date(currentDate);
  baseDate.setHours(0, 0, 0, 0);

  for (let i = 0; i < 180; i++) {
    const d = new Date(baseDate);
    d.setDate(baseDate.getDate() + i);
    const day = getCalendarDay(d, location, events);

    // Holidays & Fasts
    day.holidays.forEach((h) => {
      agendaItems.push({
        date: d,
        day,
        type: h.category === 'fast' ? 'fast' : h.category === 'roshchodesh' ? 'roshchodesh' : 'holiday',
        title: h.name,
        hebrewTitle: h.hebrewName,
        categoryLabel: h.category.toUpperCase(),
        color: h.category === 'fast' ? '#f43f5e' : '#C5A267',
        details: h.description,
      });
    });

    // Personal Hebrew events
    day.events.forEach((ev) => {
      agendaItems.push({
        date: d,
        day,
        type: 'event',
        title: ev.displayTitle || ev.title,
        hebrewTitle: ev.displayHebrewTitle || ev.hebrewTitle || '',
        categoryLabel: `HEBREW ${ev.type.toUpperCase()}`,
        color: ev.color || '#C5A267',
        details: ev.notes,
        location: ev.location,
      });
    });
  }

  // Filter items
  const filtered = agendaItems.filter((item) => {
    if (filterType === 'holidays' && item.type !== 'holiday' && item.type !== 'roshchodesh') return false;
    if (filterType === 'fasts' && item.type !== 'fast') return false;
    if (filterType === 'events' && item.type !== 'event') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.hebrewTitle.toLowerCase().includes(q) ||
        item.day.hebrewDateStr.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="bg-[#121212] rounded-xl border border-[#2A2A2A] shadow-2xl overflow-hidden">
      {/* Top Header & Search */}
      <div className="p-6 border-b border-[#2A2A2A] bg-[#161616] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-[#C5A267] tracking-tight">
            Timeline & Holidays
          </h2>
          <p className="text-sm font-medium text-[#888888] mt-0.5">
            Upcoming Jewish holidays, fasts, and personal Hebrew recurring events
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {/* Search Box */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#666666]" />
            <input
              type="text"
              placeholder="Search holiday, event..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#666666] focus:outline-hidden focus:border-[#C5A267]"
            />
          </div>
          <button
            onClick={onOpenAddEvent}
            className="px-4 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs sm:text-sm font-bold shrink-0 shadow-sm transition-colors"
          >
            + Add Event
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex items-center gap-2 p-3 border-b border-[#2A2A2A] bg-[#161616]/70">
        {[
          { id: 'all', label: 'All Items' },
          { id: 'holidays', label: 'Jewish Holidays' },
          { id: 'fasts', label: 'Fast Days' },
          { id: 'events', label: 'Personal Hebrew Events' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id as any)}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              filterType === f.id
                ? 'bg-[#2A2A2A] text-[#C5A267] border border-[#3A3A3A]'
                : 'text-[#666666] hover:text-[#888888]'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Agenda List */}
      <div className="divide-y divide-[#2A2A2A] max-h-[650px] overflow-y-auto">
        {filtered.length > 0 ? (
          filtered.map((item, idx) => {
            const isToday = item.day.isToday;
            return (
              <div
                key={idx}
                onClick={() => onSelectDate(item.date)}
                className={`p-4 sm:px-6 flex items-center justify-between gap-4 transition-colors cursor-pointer hover:bg-[#181818] ${
                  isToday ? 'bg-[#1A1A1A]' : 'bg-[#121212]'
                }`}
              >
                {/* Left: Date column */}
                <div className="flex items-center gap-4">
                  <div className="w-12 text-center">
                    <div className="text-xs uppercase tracking-wider text-[#555555]">
                      {item.date.toLocaleDateString('en-US', { month: 'short' })}
                    </div>
                    <div className="text-xl font-mono font-bold text-[#EAEAEA] leading-tight">
                      {item.date.getDate()}
                    </div>
                    <div className="text-[10px] text-[#666666]">
                      {item.date.toLocaleDateString('en-US', { weekday: 'short' })}
                    </div>
                  </div>

                  <div className="border-l border-[#2A2A2A] pl-4">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm sm:text-base text-[#EAEAEA]">
                        {item.title}
                      </h4>
                      {item.hebrewTitle && (
                        <span className="text-xs font-serif-hebrew text-[#888888]" dir="rtl">
                          ({item.hebrewTitle})
                        </span>
                      )}
                      {isToday && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-[#C5A267] text-[#0F0F0F]">
                          Today
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-[#C5A267] font-hebrew mt-0.5" dir="rtl">
                      {item.day.hebrewDateStrHe}
                    </div>

                    {item.location && (
                      <div className="flex items-center gap-1 text-xs text-[#888888] mt-1">
                        <MapPin className="w-3.5 h-3.5 text-[#C5A267]/80" />
                        <span>{item.location}</span>
                      </div>
                    )}
                    {item.details && (
                      <p className="text-xs text-[#777777] mt-1 pl-4.5">
                        {item.details}
                      </p>
                    )}
                  </div>
                </div>

                {/* Right: Category badge & arrow */}
                <div className="flex items-center gap-3 shrink-0">
                  <span
                    className="text-[10px] font-bold px-2.5 py-0.5 rounded-sm uppercase tracking-wider bg-[#1A1A1A] border border-[#2A2A2A]"
                    style={{ color: item.color }}
                  >
                    {item.categoryLabel}
                  </span>
                  <ChevronRight className="w-4 h-4 text-[#666666]" />
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center text-[#555555] text-xs">
            No events found matching your filter criteria.
          </div>
        )}
      </div>
    </div>
  );
};
