import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  FileDown,
  FileSpreadsheet,
  FileText,
  Printer,
  Calendar,
  CalendarDays,
  Check,
  Copy,
  TrendingUp,
  TrendingDown,
  Wallet,
  Layers,
  ArrowRight,
  Landmark,
  Building2,
  Receipt,
  Scale,
  ShieldCheck,
  PieChart,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  BookOpen,
  Coins,
  CreditCard,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
} from 'lucide-react';
import { Transaction, Category, Account, UserProfile, AppSettings } from '../types';
import {
  formatCurrency,
  formatDate,
  getMonthName,
  getCurrentMonthFormatted,
  getPaymentMethodLabel,
  toBanglaDigits,
} from '../utils/formatters';
import { storage } from '../utils/storage';
import { getDualAccentInfo } from '../utils/theme';

export interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  categories: Category[];
  accounts?: Account[];
  userProfile?: UserProfile;
  appSettings: AppSettings;
  defaultReportMode?: 'transactions' | 'ledger' | 'statement';
  defaultSelectedLedgerId?: string;
}

type ReportMode = 'transactions' | 'ledger' | 'statement';
type PeriodType = 'monthly' | 'yearly' | 'custom' | 'daily' | 'all';
type FilterType = 'all' | 'expense' | 'income';
type LedgerCategoryFilter = 'all' | 'wallet' | 'receivable' | 'payable';

export const ExportReportModal: React.FC<ExportReportModalProps> = ({
  isOpen,
  onClose,
  transactions = [],
  categories = [],
  accounts = [],
  userProfile,
  appSettings,
  defaultReportMode = 'transactions',
  defaultSelectedLedgerId,
}) => {
  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';
  const useBangla = appSettings.useBanglaDigits;
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = getCurrentMonthFormatted();
  const currentYearStr = String(new Date().getFullYear());

  // Report Mode: Transactions List, Ledger-based, or Full Financial Statement
  const [reportMode, setReportMode] = useState<ReportMode>(defaultReportMode);
  const [selectedLedgerId, setSelectedLedgerId] = useState<string>(
    defaultSelectedLedgerId || '__all__'
  );
  const [ledgerCategoryFilter, setLedgerCategoryFilter] =
    useState<LedgerCategoryFilter>('all');

  useEffect(() => {
    if (defaultReportMode) setReportMode(defaultReportMode);
  }, [defaultReportMode]);

  useEffect(() => {
    if (defaultSelectedLedgerId) setSelectedLedgerId(defaultSelectedLedgerId);
  }, [defaultSelectedLedgerId]);

  const [periodType, setPeriodType] = useState<PeriodType>('monthly');
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthStr);
  const [selectedYear, setSelectedYear] = useState<string>(currentYearStr);
  const [customStartDate, setCustomStartDate] = useState<string>(
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [customEndDate, setCustomEndDate] = useState<string>(todayStr);
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [showStatementDetails, setShowStatementDetails] = useState(false);

  // Fallback safe accounts and balanced accounts computation
  const allAccounts = useMemo(() => {
    if (accounts && accounts.length > 0) return accounts;
    return storage.getAccounts();
  }, [accounts]);

  const balancedAccounts = useMemo(() => {
    return storage.calculateAccountBalances(allAccounts, transactions);
  }, [allAccounts, transactions]);

  const activeUserProfile = useMemo(() => {
    if (userProfile && (userProfile.firstName || userProfile.lastName)) return userProfile;
    return storage.getUserProfile();
  }, [userProfile]);

  // Available unique years & months from transactions
  const { availableYears, availableMonths } = useMemo(() => {
    const yearsSet = new Set<string>();
    const monthsSet = new Set<string>();

    yearsSet.add(currentYearStr);
    monthsSet.add(currentMonthStr);

    transactions.forEach((tx) => {
      if (tx.date) {
        yearsSet.add(tx.date.substring(0, 4));
        monthsSet.add(tx.date.substring(0, 7));
      }
    });

    return {
      availableYears: Array.from(yearsSet).sort().reverse(),
      availableMonths: Array.from(monthsSet).sort().reverse(),
    };
  }, [transactions, currentYearStr, currentMonthStr]);

  // Filtered transactions for the selected period
  const periodTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (!tx.date) return false;
      if (periodType === 'daily') return tx.date === selectedDate;
      if (periodType === 'monthly') return tx.date.startsWith(selectedMonth);
      if (periodType === 'yearly') return tx.date.startsWith(selectedYear);
      if (periodType === 'custom') return tx.date >= customStartDate && tx.date <= customEndDate;
      return true; // all
    });
  }, [
    transactions,
    periodType,
    selectedDate,
    selectedMonth,
    selectedYear,
    customStartDate,
    customEndDate,
  ]);

  // Filtered transactions with Type filter applied (for Transaction Mode)
  const filteredTransactions = useMemo(() => {
    return periodTransactions
      .filter((tx) => {
        if (filterType === 'expense' && tx.type !== 'expense') return false;
        if (filterType === 'income' && tx.type !== 'income') return false;
        return true;
      })
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [periodTransactions, filterType]);

  // Calculations for Transaction Mode
  const stats = useMemo(() => {
    let totalIncome = 0;
    let totalExpense = 0;
    const catMap: Record<string, number> = {};

    filteredTransactions.forEach((tx) => {
      if (tx.type === 'income') {
        totalIncome += tx.amount;
      } else if (tx.type === 'expense') {
        totalExpense += tx.amount;
        catMap[tx.categoryId] = (catMap[tx.categoryId] || 0) + tx.amount;
      }
    });

    let topCategoryName = isEn ? 'None' : 'নেই';
    let topCategoryAmount = 0;
    Object.entries(catMap).forEach(([catId, amount]) => {
      if (amount > topCategoryAmount) {
        topCategoryAmount = amount;
        const cat = categories.find((c) => c.id === catId);
        topCategoryName = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId;
      }
    });

    return {
      totalIncome,
      totalExpense,
      netBalance: totalIncome - totalExpense,
      count: filteredTransactions.length,
      topCategoryName,
      topCategoryAmount,
    };
  }, [filteredTransactions, categories, isEn]);

  // =========================================================================
  // FINANCIAL STATEMENT CALCULATIONS (Statement Mode)
  // =========================================================================
  const financialPosition = useMemo(() => {
    let cashTotal = 0;
    let bankTotal = 0;
    let mobileTotal = 0;
    let cardTotal = 0;
    let receivableTotal = 0;
    let liabilityTotal = 0;

    const assetAccounts: Array<{ account: Account; balance: number }> = [];
    const liabilityAccounts: Array<{ account: Account; balance: number }> = [];

    balancedAccounts.forEach((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      if (acc.type === 'payable') {
        liabilityTotal += bal;
        liabilityAccounts.push({ account: acc, balance: bal });
      } else {
        if (acc.type === 'cash') cashTotal += bal;
        else if (acc.type === 'bank') bankTotal += bal;
        else if (acc.type === 'mobile_banking') mobileTotal += bal;
        else if (acc.type === 'card') cardTotal += bal;
        else if (acc.type === 'receivable') receivableTotal += bal;
        assetAccounts.push({ account: acc, balance: bal });
      }
    });

    const totalAssets = cashTotal + bankTotal + mobileTotal + cardTotal + receivableTotal;
    const netWorth = totalAssets - liabilityTotal;
    const liquidCash = cashTotal + bankTotal + mobileTotal;

    return {
      totalAssets,
      liabilityTotal,
      netWorth,
      liquidCash,
      cashTotal,
      bankTotal,
      mobileTotal,
      cardTotal,
      receivableTotal,
      assetAccounts,
      liabilityAccounts,
    };
  }, [balancedAccounts]);

  const incomeStatement = useMemo(() => {
    const incomeMap: Record<string, number> = {};
    const expenseMap: Record<string, number> = {};
    let totalIncome = 0;
    let totalExpense = 0;

    periodTransactions.forEach((tx) => {
      if (tx.type === 'income') {
        totalIncome += tx.amount;
        incomeMap[tx.categoryId] = (incomeMap[tx.categoryId] || 0) + tx.amount;
      } else if (tx.type === 'expense') {
        totalExpense += tx.amount;
        expenseMap[tx.categoryId] = (expenseMap[tx.categoryId] || 0) + tx.amount;
      }
    });

    const incomeCategories = Object.entries(incomeMap)
      .map(([catId, amount]) => {
        const cat = categories.find((c) => c.id === catId);
        const name = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId;
        const percentage = totalIncome > 0 ? (amount / totalIncome) * 100 : 0;
        return { catId, name, amount, percentage };
      })
      .sort((a, b) => b.amount - a.amount);

    const expenseCategories = Object.entries(expenseMap)
      .map(([catId, amount]) => {
        const cat = categories.find((c) => c.id === catId);
        const name = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId;
        const percentage = totalExpense > 0 ? (amount / totalExpense) * 100 : 0;
        return { catId, name, amount, percentage };
      })
      .sort((a, b) => b.amount - a.amount);

    const netSurplus = totalIncome - totalExpense;
    const savingsRate = totalIncome > 0 ? (netSurplus / totalIncome) * 100 : 0;

    return {
      totalIncome,
      totalExpense,
      netSurplus,
      savingsRate,
      incomeCategories,
      expenseCategories,
      count: periodTransactions.length,
    };
  }, [periodTransactions, categories, isEn]);

  // =========================================================================
  // LEDGER REPORT COMPUTATIONS & DOUBLE-ENTRY RESOLUTION
  // =========================================================================
  const { periodStartDate, periodEndDate } = useMemo(() => {
    if (periodType === 'daily') {
      return { periodStartDate: selectedDate, periodEndDate: selectedDate };
    }
    if (periodType === 'monthly') {
      const parts = selectedMonth.split('-');
      const y = Number(parts[0]);
      const m = Number(parts[1]);
      const lastDay = new Date(y, m, 0).getDate();
      const lastDayStr = String(lastDay).padStart(2, '0');
      return {
        periodStartDate: `${selectedMonth}-01`,
        periodEndDate: `${selectedMonth}-${lastDayStr}`,
      };
    }
    if (periodType === 'yearly') {
      return {
        periodStartDate: `${selectedYear}-01-01`,
        periodEndDate: `${selectedYear}-12-31`,
      };
    }
    if (periodType === 'custom') {
      return {
        periodStartDate: customStartDate,
        periodEndDate: customEndDate,
      };
    }
    return { periodStartDate: '', periodEndDate: '' }; // all time
  }, [periodType, selectedDate, selectedMonth, selectedYear, customStartDate, customEndDate]);

  // Helper to determine exact impact of a transaction on a specific account
  const getTxAccountImpact = (
    account: Account,
    tx: Transaction
  ): {
    isRelated: boolean;
    change: number;
    debit: number;
    credit: number;
    particulars: string;
    counterAccount: string;
  } => {
    const txAmount = Number(tx.amount) || 0;
    let isRelated = false;
    let change = 0;
    let particulars = '';
    let counterAccount = '';

    const cat = categories.find((c) => c.id === tx.categoryId);
    const catName = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : (tx.categoryId || '');

    // 1. Direct Income into account
    if (tx.type === 'income' && tx.accountId === account.id) {
      isRelated = true;
      if (account.type === 'payable') {
        change = txAmount; // borrowing / loan taken -> debt increases (+)
        particulars = isEn ? 'Borrowing / Loan Received' : 'কর্জ বা ঋণ গ্রহণ';
      } else if (account.type === 'receivable') {
        change = -txAmount; // repayment collected into receivable -> debt reduces (-)
        particulars = isEn ? 'Loan Repayment Received' : 'প্রাপ্য ঋণ বা পাওনা আদায়';
      } else {
        change = txAmount; // wallet deposit/income
        particulars = catName || (isEn ? 'Income' : 'আয়');
      }
      counterAccount = getPaymentMethodLabel(tx.paymentMethod, appSettings.language);
    }

    // 2. Direct Expense from account
    else if (tx.type === 'expense' && tx.accountId === account.id) {
      isRelated = true;
      if (account.type === 'payable') {
        change = txAmount; // Credit purchase -> payable debt increases (+)
        particulars = catName
          ? `${catName} (${isEn ? 'Credit Purchase' : 'বাকিতে ক্রয়'})`
          : isEn
          ? 'Credit Purchase'
          : 'বাকিতে ক্রয়';
      } else if (account.type === 'receivable') {
        change = txAmount; // Credit sale or loan given -> receivable increases (+)
        particulars = catName
          ? `${catName} (${isEn ? 'Credit Sale / Loan' : 'বাকিতে বা ধার'})`
          : isEn
          ? 'Loan Given'
          : 'ধার প্রদান';
      } else {
        change = -txAmount; // standard wallet expense (-)
        particulars = catName || (isEn ? 'Expense' : 'ব্যয়');
      }
      counterAccount = getPaymentMethodLabel(tx.paymentMethod, appSettings.language);
    }

    // 3. Transfer from this account
    else if (tx.type === 'transfer' && tx.fromAccountId === account.id) {
      isRelated = true;
      const toAcc = allAccounts.find((a) => a.id === tx.toAccountId);
      const toAccName = toAcc ? (isEn ? toAcc.nameEnglish : toAcc.nameBangla) : (tx.toAccountId || '');
      if (account.type === 'payable') {
        change = txAmount;
      } else {
        change = -txAmount;
      }
      particulars = isEn ? `Transfer Out to ${toAccName}` : `${toAccName}-এ ফান্ড স্থানান্তর`;
      counterAccount = toAccName;
    }

    // 4. Transfer to this account
    else if (tx.type === 'transfer' && tx.toAccountId === account.id) {
      isRelated = true;
      const fromAcc = allAccounts.find((a) => a.id === tx.fromAccountId);
      const fromAccName = fromAcc ? (isEn ? fromAcc.nameEnglish : fromAcc.nameBangla) : (tx.fromAccountId || '');
      if (account.type === 'payable') {
        change = -txAmount;
      } else {
        change = txAmount;
      }
      particulars = isEn ? `Transfer In from ${fromAccName}` : `${fromAccName} থেকে ফান্ড স্থানান্তর`;
      counterAccount = fromAccName;
    }

    // 5. Linked Ledger Loan/Credit transaction (tx.ledgerAccountId === account.id)
    else if (tx.type !== 'transfer' && tx.ledgerAccountId === account.id && tx.accountId !== account.id) {
      isRelated = true;
      const walletAcc = allAccounts.find((a) => a.id === tx.accountId);
      const walletName = walletAcc ? (isEn ? walletAcc.nameEnglish : walletAcc.nameBangla) : (tx.accountId || '');

      if (account.type === 'receivable') {
        if (tx.type === 'expense') {
          // Loan/advance given to debtor -> receivable balance increases (+)
          change = txAmount;
          particulars = isEn ? `Loan / Advance Given (${walletName})` : `ঋণ বা ধার প্রদান (${walletName})`;
        } else if (tx.type === 'income') {
          // Repayment received from debtor -> receivable balance decreases (-)
          change = -txAmount;
          particulars = isEn ? `Repayment Received (${walletName})` : `পাওনা টাকা আদায়/প্রাপ্তি (${walletName})`;
        }
      } else if (account.type === 'payable') {
        if (tx.type === 'income') {
          // Borrowed money from creditor -> payable balance increases (+)
          change = txAmount;
          particulars = isEn ? `Loan / Debt Incurred (${walletName})` : `কর্জ বা ঋণ গ্রহণ (${walletName})`;
        } else if (tx.type === 'expense') {
          // Debt repaid to creditor -> payable balance decreases (-)
          change = -txAmount;
          particulars = isEn ? `Debt Repaid (${walletName})` : `ঋণ বা দেনা পরিশোধ (${walletName})`;
        }
      } else {
        change = tx.type === 'income' ? txAmount : -txAmount;
        particulars = catName || (isEn ? 'Linked Transaction' : 'সংযুক্ত লেনদেন');
      }
      counterAccount = walletName;
    }

    if (!isRelated) {
      return {
        isRelated: false,
        change: 0,
        debit: 0,
        credit: 0,
        particulars: '',
        counterAccount: '',
      };
    }

    // Debit and Credit definitions:
    // Asset Accounts (cash, bank, mobile, card, receivable):
    // Inflow / positive change = DEBIT (+), Outflow / negative change = CREDIT (-)
    // Liability Accounts (payable):
    // Debt reduction / payment = DEBIT, New Debt / borrowing = CREDIT
    let debit = 0;
    let credit = 0;
    if (account.type === 'payable') {
      if (change < 0) {
        debit = Math.abs(change);
      } else {
        credit = change;
      }
    } else {
      if (change > 0) {
        debit = change;
      } else {
        credit = Math.abs(change);
      }
    }

    return {
      isRelated: true,
      change,
      debit,
      credit,
      particulars,
      counterAccount,
    };
  };

  // Filter accounts for ledger dropdown by category
  const filteredAccountsForLedger = useMemo(() => {
    return allAccounts.filter((acc) => {
      if (ledgerCategoryFilter === 'wallet') {
        return (
          acc.type === 'cash' ||
          acc.type === 'bank' ||
          acc.type === 'mobile_banking' ||
          acc.type === 'card'
        );
      }
      if (ledgerCategoryFilter === 'receivable') {
        return acc.type === 'receivable';
      }
      if (ledgerCategoryFilter === 'payable') {
        return acc.type === 'payable';
      }
      return true;
    });
  }, [allAccounts, ledgerCategoryFilter]);

  // Currently selected ledger account
  const selectedAccount = useMemo(() => {
    if (!selectedLedgerId || selectedLedgerId === '__all__') return null;
    return allAccounts.find((a) => a.id === selectedLedgerId) || null;
  }, [allAccounts, selectedLedgerId]);

  // Chronological ledger data for a single account
  const singleLedgerData = useMemo(() => {
    if (!selectedAccount) return null;

    // 1. Calculate pre-period opening balance
    let opening = Number(selectedAccount.openingBalance) || 0;
    if (periodStartDate) {
      transactions.forEach((tx) => {
        if (tx.date && tx.date < periodStartDate) {
          const impact = getTxAccountImpact(selectedAccount, tx);
          if (impact.isRelated) {
            opening += impact.change;
          }
        }
      });
    }

    // 2. Filter transactions belonging to this period & account, sorted chronologically ascending
    const periodTxs = transactions
      .filter((tx) => {
        if (!tx.date) return false;
        if (periodType === 'daily') return tx.date === selectedDate;
        if (periodType === 'monthly') return tx.date.startsWith(selectedMonth);
        if (periodType === 'yearly') return tx.date.startsWith(selectedYear);
        if (periodType === 'custom') return tx.date >= customStartDate && tx.date <= customEndDate;
        return true;
      })
      .sort((a, b) => {
        const d = (a.date || '').localeCompare(b.date || '');
        if (d !== 0) return d;
        return (a.createdAt || a.id || '').localeCompare(b.createdAt || b.id || '');
      });

    let running = opening;
    let totalDebit = 0;
    let totalCredit = 0;

    const entries: Array<{
      sl: number;
      tx: Transaction;
      date: string;
      particulars: string;
      counterAccount: string;
      note: string;
      method: string;
      debit: number;
      credit: number;
      change: number;
      runningBalance: number;
    }> = [];

    periodTxs.forEach((tx) => {
      const impact = getTxAccountImpact(selectedAccount, tx);
      if (impact.isRelated) {
        running += impact.change;
        totalDebit += impact.debit;
        totalCredit += impact.credit;
        entries.push({
          sl: entries.length + 1,
          tx,
          date: tx.date,
          particulars: impact.particulars,
          counterAccount: impact.counterAccount,
          note: tx.note || '',
          method: tx.paymentMethod || '',
          debit: impact.debit,
          credit: impact.credit,
          change: impact.change,
          runningBalance: running,
        });
      }
    });

    return {
      account: selectedAccount,
      openingBalance: opening,
      totalDebit,
      totalCredit,
      netMovement: running - opening,
      closingBalance: running,
      entries,
      count: entries.length,
    };
  }, [
    selectedAccount,
    transactions,
    periodStartDate,
    periodEndDate,
    periodType,
    selectedDate,
    selectedMonth,
    selectedYear,
    customStartDate,
    customEndDate,
    categories,
    allAccounts,
    isEn,
    appSettings.language,
  ]);

  // Master schedule for all accounts in the selected period
  const allLedgersSchedule = useMemo(() => {
    return allAccounts.map((acc, index) => {
      let opening = Number(acc.openingBalance) || 0;
      if (periodStartDate) {
        transactions.forEach((tx) => {
          if (tx.date && tx.date < periodStartDate) {
            const impact = getTxAccountImpact(acc, tx);
            if (impact.isRelated) {
              opening += impact.change;
            }
          }
        });
      }

      let running = opening;
      let periodDebit = 0;
      let periodCredit = 0;
      let txCount = 0;

      const periodTxs = transactions
        .filter((tx) => {
          if (!tx.date) return false;
          if (periodType === 'daily') return tx.date === selectedDate;
          if (periodType === 'monthly') return tx.date.startsWith(selectedMonth);
          if (periodType === 'yearly') return tx.date.startsWith(selectedYear);
          if (periodType === 'custom') return tx.date >= customStartDate && tx.date <= customEndDate;
          return true;
        })
        .sort((a, b) => (a.date || '').localeCompare(b.date || ''));

      periodTxs.forEach((tx) => {
        const impact = getTxAccountImpact(acc, tx);
        if (impact.isRelated) {
          running += impact.change;
          periodDebit += impact.debit;
          periodCredit += impact.credit;
          txCount += 1;
        }
      });

      return {
        sl: index + 1,
        account: acc,
        openingBalance: opening,
        periodDebit,
        periodCredit,
        netMovement: running - opening,
        closingBalance: running,
        txCount,
      };
    });
  }, [
    allAccounts,
    transactions,
    periodStartDate,
    periodType,
    selectedDate,
    selectedMonth,
    selectedYear,
    customStartDate,
    customEndDate,
    categories,
    isEn,
    appSettings.language,
  ]);

  const allLedgersTotals = useMemo(() => {
    let grandOpening = 0;
    let grandDebit = 0;
    let grandCredit = 0;
    let grandClosing = 0;
    let grandTxCount = 0;

    allLedgersSchedule.forEach((item) => {
      grandOpening += item.openingBalance;
      grandDebit += item.periodDebit;
      grandCredit += item.periodCredit;
      grandClosing += item.closingBalance;
      grandTxCount += item.txCount;
    });

    return {
      grandOpening,
      grandDebit,
      grandCredit,
      grandClosing,
      grandNet: grandClosing - grandOpening,
      grandTxCount,
    };
  }, [allLedgersSchedule]);

  if (!isOpen) return null;

  // Period label for titles and filenames
  const getPeriodLabel = () => {
    if (periodType === 'daily') {
      return formatDate(selectedDate, appSettings.language, useBangla);
    }
    if (periodType === 'monthly') {
      return getMonthName(selectedMonth, appSettings.language, useBangla);
    }
    if (periodType === 'yearly') {
      return isEn
        ? `Year ${selectedYear}`
        : `${useBangla ? toBanglaDigits(selectedYear) : selectedYear} সাল`;
    }
    if (periodType === 'all') {
      return isEn ? 'All Time (Cumulative)' : 'সর্বকালীন (সম্পূর্ণ হিস্ট্রি)';
    }
    return `${formatDate(customStartDate, appSettings.language, useBangla)} - ${formatDate(
      customEndDate,
      appSettings.language,
      useBangla
    )}`;
  };

  const getFileBaseName = () => {
    let slug = 'report';
    if (periodType === 'daily') slug = `daily_${selectedDate}`;
    else if (periodType === 'monthly') slug = `monthly_${selectedMonth}`;
    else if (periodType === 'yearly') slug = `yearly_${selectedYear}`;
    else if (periodType === 'all') slug = `all_time`;
    else slug = `custom_${customStartDate}_to_${customEndDate}`;
    return slug;
  };

  const getUserDisplayName = () => {
    if (!activeUserProfile) return '';
    const fullName = `${activeUserProfile.firstName || ''} ${activeUserProfile.lastName || ''}`.trim();
    return fullName || '';
  };

  // =========================================================================
  // EXPORT HANDLERS: TRANSACTION LOG MODE
  // =========================================================================
  const handleExportCSVTransactions = () => {
    const headers = [
      isEn ? 'SL' : 'ক্রমিক',
      isEn ? 'Date' : 'তারিখ',
      isEn ? 'Type' : 'ধরন',
      isEn ? 'Category' : 'ক্যাটাগরি',
      isEn ? 'Description / Note' : 'বিবরণ / নোট',
      isEn ? 'Payment Method' : 'পেমেন্ট মাধ্যম',
      isEn ? 'Amount (BDT)' : 'টাকার পরিমাণ (৳)',
    ];

    const rows = filteredTransactions.map((tx, idx) => {
      const cat = categories.find((c) => c.id === tx.categoryId);
      const catName = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : tx.categoryId;
      const typeLabel =
        tx.type === 'income' ? (isEn ? 'Income' : 'আয়') : isEn ? 'Expense' : 'ব্যয়';
      const methodLabel = getPaymentMethodLabel(tx.paymentMethod, appSettings.language);
      const note = `"${(tx.note || '').replace(/"/g, '""')}"`;

      return [
        idx + 1,
        tx.date,
        typeLabel,
        `"${catName}"`,
        note,
        `"${methodLabel}"`,
        tx.amount,
      ].join(',');
    });

    const summaryRows = [
      `"${isEn ? 'ONU FINANCE - TRANSACTION AUDIT REPORT' : 'Onu Finance - লেনদেন অডিট প্রতিবেদন'}"`,
      `"${isEn ? 'Reporting Period' : 'সময়সীমা'}: ${getPeriodLabel()}"`,
      `"${isEn ? 'Total Transactions' : 'মোট লেনদেন'}: ${stats.count}"`,
      `"${isEn ? 'Total Income' : 'মোট আয়'}: ${stats.totalIncome}"`,
      `"${isEn ? 'Total Expense' : 'মোট খরচ'}: ${stats.totalExpense}"`,
      `"${isEn ? 'Net Balance' : 'নিট উদ্বৃত্ত/সঞ্চয়'}: ${stats.netBalance}"`,
      '',
    ];

    const csvContent = '\uFEFF' + summaryRows.join('\n') + headers.join(',') + '\n' + rows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `transactions_${getFileBaseName()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('csv');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleExportTextTransactions = () => {
    const divider = '==================================================';
    const subDivider = '--------------------------------------------------';

    let text = `${divider}\n`;
    text += isEn
      ? `  ONU FINANCE - TRANSACTION AUDIT LEDGER\n`
      : `  Onu Finance - লেনদেনের পূর্ণাঙ্গ খতিয়ান\n`;
    text += `${divider}\n`;
    text += `${isEn ? 'Report Period' : 'প্রতিবেদনের সময়কাল'}: ${getPeriodLabel()}\n`;
    text += `${isEn ? 'Generated On' : 'তৈরির তারিখ'}: ${new Date().toLocaleString()}\n`;
    text += `${subDivider}\n`;
    text += `${isEn ? 'TRANSACTION SUMMARY' : 'সারসংক্ষেপ'}:\n`;
    text += `  • ${isEn ? 'Total Income' : 'মোট আয়'}: ৳ ${stats.totalIncome.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Total Expense' : 'মোট খরচ'}: ৳ ${stats.totalExpense.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Net Savings / Balance' : 'নিট সঞ্চয় / উদ্বৃত্ত'}: ৳ ${stats.netBalance.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Count' : 'সংখ্যা'}: ${stats.count} ${isEn ? 'transactions' : 'টি লেনদেন'}\n`;
    text += `${subDivider}\n\n`;

    text += `${isEn ? 'DETAILED TRANSACTIONS' : 'বিস্তারিত লেনদেন'}:\n`;
    filteredTransactions.forEach((tx, idx) => {
      const cat = categories.find((c) => c.id === tx.categoryId);
      const catName = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : tx.categoryId;
      const typeSymbol = tx.type === 'income' ? '(+) [আয়]' : '(-) [ব্যয়]';
      const method = getPaymentMethodLabel(tx.paymentMethod, appSettings.language);
      text += `${idx + 1}. [${tx.date}] ${typeSymbol} ৳ ${tx.amount.toLocaleString()} - ${catName}\n`;
      text += `   ${isEn ? 'Method' : 'মাধ্যম'}: ${method}${tx.note ? ` | ${isEn ? 'Note' : 'নোট'}: ${tx.note}` : ''}\n`;
    });

    text += `\n${divider}\n`;
    text += `Onu Finance Personal Finance Management Application\n`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `transactions_${getFileBaseName()}.txt`;
    link.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('txt');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handlePrintTransactions = () => {
    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Onu Finance - ${getPeriodLabel()}</title>
          <meta charset="utf-8" />
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 24px; color: #0f172a; line-height: 1.5; }
            h1 { font-size: 20px; margin: 0; color: #047857; }
            p { margin: 4px 0 16px; color: #475569; font-size: 13px; }
            .grid { display: flex; gap: 12px; margin-bottom: 20px; }
            .card { flex: 1; padding: 10px; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; }
            .card-title { font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold; }
            .card-value { font-size: 16px; font-weight: bold; margin-top: 4px; }
            table { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 11px; }
            th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; }
            th { background: #f1f5f9; font-weight: bold; }
            .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; }
            .badge-inc { background: #d1fae5; color: #065f46; }
            .badge-exp { background: #fee2e2; color: #991b1b; }
          </style>
        </head>
        <body>
          <h1>Onu Finance - ${isEn ? 'Transaction Audit Log' : 'লেনদেনের অডিট খতিয়ান'}</h1>
          <p><strong>${isEn ? 'Period' : 'সময়সীমা'}:</strong> ${getPeriodLabel()} | <strong>${isEn ? 'Date' : 'তারিখ'}:</strong> ${new Date().toLocaleDateString()}</p>
          <div class="grid">
            <div class="card"><div class="card-title">মোট আয়</div><div class="card-value" style="color: #059669;">৳ ${stats.totalIncome.toLocaleString()}</div></div>
            <div class="card"><div class="card-title">মোট ব্যয়</div><div class="card-value" style="color: #dc2626;">৳ ${stats.totalExpense.toLocaleString()}</div></div>
            <div class="card"><div class="card-title">নিট উদ্বৃত্ত</div><div class="card-value">৳ ${stats.netBalance.toLocaleString()}</div></div>
            <div class="card"><div class="card-title">মোট লেনদেন</div><div class="card-value">${stats.count} টি</div></div>
          </div>
          <table>
            <thead>
              <tr><th>#</th><th>তারিখ</th><th>ধরন</th><th>খাত</th><th>নোট</th><th>মাধ্যম</th><th style="text-align:right;">টাকা</th></tr>
            </thead>
            <tbody>
              ${filteredTransactions
                .map((tx, idx) => {
                  const cat = categories.find((c) => c.id === tx.categoryId);
                  const catName = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : tx.categoryId;
                  return `
                  <tr>
                    <td>${idx + 1}</td>
                    <td>${tx.date}</td>
                    <td><span class="badge ${tx.type === 'income' ? 'badge-inc' : 'badge-exp'}">${tx.type === 'income' ? 'আয়' : 'ব্যয়'}</span></td>
                    <td>${catName}</td>
                    <td>${tx.note || '-'}</td>
                    <td>${getPaymentMethodLabel(tx.paymentMethod, 'bn')}</td>
                    <td style="text-align:right;font-weight:bold;">৳ ${tx.amount.toLocaleString()}</td>
                  </tr>`;
                })
                .join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 350);
    }
  };

  // =========================================================================
  // EXPORT HANDLERS: FINANCIAL STATEMENT MODE (ফাইন্যান্সিয়াল স্টেটমেন্ট)
  // =========================================================================
  const handleExportStatementCSV = () => {
    const userName = getUserDisplayName();
    const lines: string[] = [];

    // Header & Meta
    lines.push(`"${isEn ? 'ONU FINANCE - AUDITED FINANCIAL STATEMENT & BALANCE SHEET' : 'Onu Finance - ফাইন্যান্সিয়াল স্টেটমেন্ট ও আর্থিক স্থিতিপত্র'}"`);
    if (userName) lines.push(`"${isEn ? 'Account Holder / Organization' : 'অ্যাকাউন্ট হোল্ডার / প্রতিষ্ঠান'}: ${userName}"`);
    lines.push(`"${isEn ? 'Reporting Timeframe' : 'প্রতিবেদনের সময়কাল'}: ${getPeriodLabel()}"`);
    lines.push(`"${isEn ? 'Generated On' : 'তৈরির সময়'}: ${new Date().toLocaleString()}"`);
    lines.push(`"${isEn ? 'Functional Currency' : 'মুদ্রা'}: BDT (৳)"`);
    lines.push('');

    // SECTION 1: EXECUTIVE NET WORTH & SUMMARY
    lines.push(`"=== 1. ${isEn ? 'EXECUTIVE FINANCIAL POSITION & NET WORTH' : 'আর্থিক স্থিতিপত্র ও নিট সম্পদ'} ==="`);
    lines.push(`"${isEn ? 'Metric' : 'বিবরণ'}","${isEn ? 'Amount (BDT)' : 'টাকার পরিমাণ (৳)'}","${isEn ? 'Notes' : 'মন্তব্য'}"`);
    lines.push(`"${isEn ? 'TOTAL ASSETS (Cash, Bank, Mobile & Receivables)' : 'সর্বমোট সম্পদ (নগদ, ব্যাংক ও প্রাপ্য পাওনা)'}",${financialPosition.totalAssets},"${isEn ? 'Gross assets owned' : 'মালিকানাধীন মোট সম্পদ'}"`);
    lines.push(`"${isEn ? 'TOTAL LIABILITIES (Debts, Loans & Payables)' : 'সর্বমোট দায়/দেনা (ঋণ ও প্রদেয় দেনা)'}",${financialPosition.liabilityTotal},"${isEn ? 'Total financial obligations' : 'পরিশোধযোগ্য মোট দেনা'}"`);
    lines.push(`"${isEn ? 'NET WORTH (Assets minus Liabilities)' : 'প্রকৃত নিট সম্পদ (মোট সম্পদ বাদ মোট দেনা)'}",${financialPosition.netWorth},"${isEn ? 'Net Equity' : 'প্রকৃত আর্থিক প্রাচুর্য'}"`);
    lines.push(`"${isEn ? 'Liquid Cash Reserves (Immediate Liquidity)' : 'তারল্য রিজার্ভ (নগদ ও ব্যাংকে গচ্ছিত তহবিল)'}",${financialPosition.liquidCash},"${isEn ? 'Cash + Bank + Mobile' : 'নগদ + ব্যাংক + মোবাইল'}"`);
    lines.push(`"${isEn ? 'Period Total Income' : 'নির্দিষ্ট সময়কালের মোট আয়'}",${incomeStatement.totalIncome},"${isEn ? 'Gross Inflows' : 'মোট উপার্জিত আয়'}"`);
    lines.push(`"${isEn ? 'Period Total Expenses' : 'নির্দিষ্ট সময়কালের মোট ব্যয়'}",${incomeStatement.totalExpense},"${isEn ? 'Operating Outflows' : 'পরিচালনা ব্যয়'}"`);
    lines.push(`"${isEn ? 'Period Net Surplus / Savings' : 'সময়কালের নিট উদ্বৃত্ত / সঞ্চয়'}",${incomeStatement.netSurplus},"${isEn ? 'Retained Savings' : 'অবশিষ্ট সঞ্চয়'}"`);
    lines.push(`"${isEn ? 'Savings Rate (%)' : 'সঞ্চয়ের হার (%)'}",${incomeStatement.savingsRate.toFixed(1)}%,"${isEn ? 'Surplus / Income' : 'উদ্বৃত্তের শতকরা হার'}"`);
    lines.push('');

    // SECTION 2: STATEMENT OF COMPREHENSIVE INCOME
    lines.push(`"=== 2. ${isEn ? 'STATEMENT OF OPERATING INCOME (BY SOURCE)' : 'আয় বিবরণী (উৎস অনুযায়ী)'} ==="`);
    lines.push(`"${isEn ? 'Category / Source' : 'আয়ের খাত'}","${isEn ? 'Amount (BDT)' : 'পরিমাণ (৳)'}","${isEn ? 'Share of Income' : 'শতকরা হার'}"`);
    if (incomeStatement.incomeCategories.length === 0) {
      lines.push(`"${isEn ? 'No income recorded in this period' : 'এই সময়সীমায় আয়ের কোনো তথ্য নেই'}",0,"0.0%"`);
    } else {
      incomeStatement.incomeCategories.forEach((cat) => {
        lines.push(`"${cat.name}",${cat.amount},"${cat.percentage.toFixed(1)}%"`);
      });
    }
    lines.push(`"${isEn ? 'TOTAL OPERATING INCOME' : 'সর্বমোট আয়'}",${incomeStatement.totalIncome},"100.0%"`);
    lines.push('');

    // SECTION 3: STATEMENT OF EXPENSES
    lines.push(`"=== 3. ${isEn ? 'STATEMENT OF OPERATING EXPENSES (BY PURPOSE)' : 'ব্যয় বিবরণী (খাত অনুযায়ী)'} ==="`);
    lines.push(`"${isEn ? 'Category / Purpose' : 'ব্যয়ের খাত'}","${isEn ? 'Amount (BDT)' : 'পরিমাণ (৳)'}","${isEn ? 'Share of Expense' : 'শতকরা হার'}"`);
    if (incomeStatement.expenseCategories.length === 0) {
      lines.push(`"${isEn ? 'No expense recorded in this period' : 'এই সময়সীমায় ব্যয়ের কোনো তথ্য নেই'}",0,"0.0%"`);
    } else {
      incomeStatement.expenseCategories.forEach((cat) => {
        lines.push(`"${cat.name}",${cat.amount},"${cat.percentage.toFixed(1)}%"`);
      });
    }
    lines.push(`"${isEn ? 'TOTAL OPERATING EXPENSES' : 'সর্বমোট ব্যয়'}",${incomeStatement.totalExpense},"100.0%"`);
    lines.push(`"${isEn ? 'NET SURPLUS / (DEFICIT)' : 'নিট উদ্বৃত্ত / (ঘাটতি)'}",${incomeStatement.netSurplus},"${incomeStatement.savingsRate.toFixed(1)}%"`);
    lines.push('');

    // SECTION 4: BALANCE SHEET / STATEMENT OF FINANCIAL POSITION
    lines.push(`"=== 4. ${isEn ? 'STATEMENT OF FINANCIAL POSITION (BALANCE SHEET)' : 'সম্পদ ও দায়ের স্থিতিপত্র (ব্যালেন্স শিট)'} ==="`);
    lines.push(`"${isEn ? 'Classification' : 'শ্রেণি'}","${isEn ? 'Account / Item' : 'খাত / হিসাবের নাম'}","${isEn ? 'Balance (BDT)' : 'টাকা (৳)'}"`);
    lines.push(`"[${isEn ? 'ASSET' : 'সম্পদ'}]","${isEn ? 'Cash in Hand (নগদ টাকা)' : 'হাতে নগদ ক্যাশ'}",${financialPosition.cashTotal}`);
    lines.push(`"[${isEn ? 'ASSET' : 'সম্পদ'}]","${isEn ? 'Bank Deposits (ব্যাংক আমানত)' : 'ব্যাংক হিসাব'}",${financialPosition.bankTotal}`);
    lines.push(`"[${isEn ? 'ASSET' : 'সম্পদ'}]","${isEn ? 'Mobile Wallets (বিকাশ/নগদ/রকেট)' : 'মোবাইল ওয়ালেট'}",${financialPosition.mobileTotal}`);
    lines.push(`"[${isEn ? 'ASSET' : 'সম্পদ'}]","${isEn ? 'Cards / Digital' : 'কার্ড ও ডিজিটাল'}",${financialPosition.cardTotal}`);
    lines.push(`"[${isEn ? 'ASSET' : 'সম্পদ'}]","${isEn ? 'Accounts Receivable (অন্যের কাছে পাওনা)' : 'প্রাপ্য পাওনা'}",${financialPosition.receivableTotal}`);
    lines.push(`"[${isEn ? 'TOTAL ASSETS' : 'সর্বমোট সম্পদ'}]","--",${financialPosition.totalAssets}`);
    lines.push('');
    lines.push(`"[${isEn ? 'LIABILITY' : 'দায়/দেনা'}]","${isEn ? 'Accounts Payable & Borrowings (অপরের কাছে দেনা)' : 'প্রদেয় ঋণ ও দেনা'}",${financialPosition.liabilityTotal}`);
    lines.push(`"[${isEn ? 'TOTAL LIABILITIES' : 'সর্বমোট দায়/দেনা'}]","--",${financialPosition.liabilityTotal}`);
    lines.push(`"[${isEn ? 'EQUITY / NET WORTH' : 'প্রকৃত নিট সম্পদ'}]","${isEn ? 'Assets minus Liabilities' : 'মোট সম্পদ বাদ মোট দেনা'}",${financialPosition.netWorth}`);
    lines.push('');

    // SECTION 5: DETAILED ACCOUNT SCHEDULE
    lines.push(`"=== 5. ${isEn ? 'SCHEDULE OF ACCOUNT BALANCES' : 'সকল অ্যাকাউন্টের বর্তমান স্থিতির তালিকা'} ==="`);
    lines.push(`"${isEn ? 'Account Name' : 'অ্যাকাউন্টের নাম'}","${isEn ? 'Type' : 'ধরন'}","${isEn ? 'Balance (BDT)' : 'ব্যালেন্স (৳)'}"`);
    balancedAccounts.forEach((acc) => {
      const name = isEn ? acc.nameEnglish : acc.nameBangla;
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      lines.push(`"${name}","${acc.type.toUpperCase()}",${bal}`);
    });
    lines.push('');

    const csvContent = '\uFEFF' + lines.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `financial_statement_${getFileBaseName()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('csv');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleExportStatementText = () => {
    const divider = '======================================================================';
    const subDivider = '----------------------------------------------------------------------';
    const userName = getUserDisplayName();

    let text = `${divider}\n`;
    text += `             ONU FINANCE - AUDITED FINANCIAL STATEMENT\n`;
    text += `                 আর্থিক প্রতিবেদন ও ব্যালেন্স শিট\n`;
    text += `${divider}\n`;
    if (userName) text += `${isEn ? 'Prepared For' : 'হিসাব গ্রহীতা'}  : ${userName}\n`;
    text += `${isEn ? 'Reporting Period' : 'সময়সীমা'}      : ${getPeriodLabel()}\n`;
    text += `${isEn ? 'Date of Issue' : 'তৈরির তারিখ'}    : ${new Date().toLocaleString()}\n`;
    text += `${isEn ? 'Base Currency' : 'মুদ্রা'}         : BDT (৳)\n`;
    text += `${divider}\n\n`;

    text += `1. EXECUTIVE FINANCIAL SUMMARY & NET WORTH (প্রকৃত নিট সম্পদ)\n`;
    text += `${subDivider}\n`;
    text += `  • ${isEn ? 'TOTAL ASSETS' : 'সর্বমোট সম্পদ'}              : ৳ ${financialPosition.totalAssets.toLocaleString()}\n`;
    text += `  • ${isEn ? 'TOTAL LIABILITIES' : 'সর্বমোট দায়/দেনা'}         : ৳ ${financialPosition.liabilityTotal.toLocaleString()}\n`;
    text += `  • ${isEn ? 'NET WORTH (Assets - Debt)' : 'প্রকৃত নিট সম্পদ'}        : ৳ ${financialPosition.netWorth.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Liquid Cash & Bank' : 'তারল্য নগদ ও ব্যাংক'}       : ৳ ${financialPosition.liquidCash.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Period Total Income' : 'সময়কালের মোট আয়'}         : ৳ ${incomeStatement.totalIncome.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Period Total Expense' : 'সময়কালের মোট ব্যয়'}        : ৳ ${incomeStatement.totalExpense.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Net Operating Surplus' : 'নিট উদ্বৃত্ত'}       : ৳ ${incomeStatement.netSurplus.toLocaleString()}\n`;
    text += `  • ${isEn ? 'Savings Rate' : 'সঞ্চয়ের হার'}                : ${incomeStatement.savingsRate.toFixed(1)}%\n`;
    text += `${subDivider}\n\n`;

    text += `2. STATEMENT OF OPERATING INCOME (আয় বিবরণী)\n`;
    text += `${subDivider}\n`;
    if (incomeStatement.incomeCategories.length === 0) {
      text += `  (No income recorded for this period)\n`;
    } else {
      incomeStatement.incomeCategories.forEach((cat, idx) => {
        text += `  ${idx + 1}. ${cat.name.padEnd(28)} : ৳ ${cat.amount.toLocaleString().padStart(12)} (${cat.percentage.toFixed(1)}%)\n`;
      });
    }
    text += `  ${subDivider}\n`;
    text += `  ${isEn ? 'TOTAL INCOME' : 'সর্বমোট আয়'}                   : ৳ ${incomeStatement.totalIncome.toLocaleString()}\n\n`;

    text += `3. STATEMENT OF OPERATING EXPENSES (ব্যয় বিবরণী)\n`;
    text += `${subDivider}\n`;
    if (incomeStatement.expenseCategories.length === 0) {
      text += `  (No expenses recorded for this period)\n`;
    } else {
      incomeStatement.expenseCategories.forEach((cat, idx) => {
        text += `  ${idx + 1}. ${cat.name.padEnd(28)} : ৳ ${cat.amount.toLocaleString().padStart(12)} (${cat.percentage.toFixed(1)}%)\n`;
      });
    }
    text += `  ${subDivider}\n`;
    text += `  ${isEn ? 'TOTAL EXPENSES' : 'সর্বমোট ব্যয়'}                 : ৳ ${incomeStatement.totalExpense.toLocaleString()}\n`;
    text += `  ${isEn ? 'NET SURPLUS / (DEFICIT)' : 'নিট উদ্বৃত্ত / (ঘাটতি)'}     : ৳ ${incomeStatement.netSurplus.toLocaleString()}\n\n`;

    text += `4. STATEMENT OF FINANCIAL POSITION (ব্যালেন্স শিট)\n`;
    text += `${subDivider}\n`;
    text += `  [ASSETS / মোট সম্পদ]\n`;
    text += `    - ${isEn ? 'Cash in Hand' : 'হাতে নগদ ক্যাশ'}            : ৳ ${financialPosition.cashTotal.toLocaleString()}\n`;
    text += `    - ${isEn ? 'Bank Deposits' : 'ব্যাংক আমানত'}            : ৳ ${financialPosition.bankTotal.toLocaleString()}\n`;
    text += `    - ${isEn ? 'Mobile Wallets' : 'মোবাইল ওয়ালেট'}           : ৳ ${financialPosition.mobileTotal.toLocaleString()}\n`;
    text += `    - ${isEn ? 'Accounts Receivable' : 'অন্যের কাছে পাওনা'}      : ৳ ${financialPosition.receivableTotal.toLocaleString()}\n`;
    text += `    * ${isEn ? 'SUM OF TOTAL ASSETS' : 'সর্বমোট সম্পদ'}        : ৳ ${financialPosition.totalAssets.toLocaleString()}\n\n`;
    text += `  [LIABILITIES / মোট দেনা ও ঋণ]\n`;
    text += `    - ${isEn ? 'Payables & Loans' : 'প্রদেয় ঋণ ও দেনা'}         : ৳ ${financialPosition.liabilityTotal.toLocaleString()}\n`;
    text += `    * ${isEn ? 'SUM OF TOTAL LIABILITIES' : 'সর্বমোট দায়/দেনা'}   : ৳ ${financialPosition.liabilityTotal.toLocaleString()}\n\n`;
    text += `  =======================================================\n`;
    text += `  ${isEn ? 'NET WORTH (Assets - Liabilities)' : 'প্রকৃত নিট সম্পদ (সম্পদ বাদ দেনা)'}: ৳ ${financialPosition.netWorth.toLocaleString()}\n`;
    text += `  =======================================================\n\n`;

    text += `5. ACCOUNT SCHEDULE & BALANCES (সকল অ্যাকাউন্টের স্থিতি)\n`;
    text += `${subDivider}\n`;
    balancedAccounts.forEach((acc) => {
      const name = isEn ? acc.nameEnglish : acc.nameBangla;
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      text += `  • ${name.padEnd(26)} [${acc.type.toUpperCase().padEnd(10)}] : ৳ ${bal.toLocaleString()}\n`;
    });
    text += `\n${divider}\n`;
    text += `End of Statement - Certified by Onu Finance Personal Finance Management\n`;
    text += `${divider}\n`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `financial_statement_${getFileBaseName()}.txt`;
    link.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('txt');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handlePrintStatement = () => {
    const userName = getUserDisplayName();
    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Onu Finance - ${isEn ? 'Financial Statement' : 'ফাইন্যান্সিয়াল স্টেটমেন্ট'}</title>
          <meta charset="utf-8" />
          <style>
            @page { size: A4; margin: 14mm; }
            body { font-family: system-ui, -apple-system, sans-serif; padding: 18px; color: #0f172a; line-height: 1.4; background: #fff; }
            .header-bar { border-bottom: 3px solid #059669; padding-bottom: 12px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: flex-end; }
            .brand-title { font-size: 22px; font-weight: 800; color: #047857; letter-spacing: -0.5px; margin: 0; }
            .brand-sub { font-size: 13px; font-weight: 700; color: #334155; margin-top: 2px; }
            .meta-text { font-size: 11px; color: #64748b; text-align: right; }
            
            .kpi-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; }
            .kpi-card { padding: 10px 12px; border-radius: 8px; background: #f8fafc; border: 1px solid #cbd5e1; }
            .kpi-card.highlight { background: #ecfdf5; border-color: #34d399; }
            .kpi-title { font-size: 10px; text-transform: uppercase; font-weight: 700; color: #64748b; }
            .kpi-card.highlight .kpi-title { color: #047857; }
            .kpi-val { font-size: 16px; font-weight: 800; margin-top: 3px; color: #0f172a; }
            .kpi-card.highlight .kpi-val { color: #047857; }
            
            .section-title { font-size: 12px; font-weight: 800; text-transform: uppercase; color: #0f172a; background: #f1f5f9; padding: 6px 10px; border-left: 4px solid #059669; margin: 16px 0 8px; }
            
            table { width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11px; }
            th, td { border: 1px solid #cbd5e1; padding: 5px 8px; text-align: left; }
            th { background: #f8fafc; font-weight: 700; color: #334155; }
            .tar { text-align: right; }
            .bold { font-weight: 700; }
            .tot-row { background: #f8fafc; font-weight: 800; }
            .two-column { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
            
            .net-worth-banner { background: #f0fdf4; border: 2px solid #86efac; border-radius: 8px; padding: 12px; display: flex; justify-content: space-between; align-items: center; margin: 14px 0; }
            .nw-title { font-size: 13px; font-weight: 800; color: #166534; }
            .nw-formula { font-size: 11px; color: #15803d; }
            .nw-amount { font-size: 20px; font-weight: 900; color: #15803d; }
            
            .footer-notes { margin-top: 30px; font-size: 10px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="header-bar">
            <div>
              <h1 class="brand-title">ONU FINANCE</h1>
              <div class="brand-sub">${isEn ? 'AUDITED FINANCIAL STATEMENT & BALANCE SHEET' : 'ফাইন্যান্সিয়াল স্টেটমেন্ট ও ব্যালেন্স শিট'}</div>
              ${userName ? `<div style="font-size: 11px; color: #475569; margin-top: 2px;"><strong>${isEn ? 'Account' : 'হিসাব'}:</strong> ${userName}</div>` : ''}
            </div>
            <div class="meta-text">
              <div><strong>${isEn ? 'Period' : 'সময়সীমা'}:</strong> ${getPeriodLabel()}</div>
              <div><strong>${isEn ? 'Issue Date' : 'তারিখ'}:</strong> ${new Date().toLocaleDateString()}</div>
              <div><strong>${isEn ? 'Currency' : 'মুদ্রা'}:</strong> BDT (৳)</div>
            </div>
          </div>

          <!-- KPI Cards -->
          <div class="kpi-row">
            <div class="kpi-card highlight">
              <div class="kpi-title">${isEn ? 'Net Worth' : 'প্রকৃত নিট সম্পদ'}</div>
              <div class="kpi-val">৳ ${financialPosition.netWorth.toLocaleString()}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-title">${isEn ? 'Total Assets' : 'মোট সম্পদ'}</div>
              <div class="kpi-val">৳ ${financialPosition.totalAssets.toLocaleString()}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-title">${isEn ? 'Total Liabilities' : 'মোট দায়/দেনা'}</div>
              <div class="kpi-val" style="color: #dc2626;">৳ ${financialPosition.liabilityTotal.toLocaleString()}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-title">${isEn ? 'Period Net Surplus' : 'নিট উদ্বৃত্ত'}</div>
              <div class="kpi-val" style="color: ${incomeStatement.netSurplus >= 0 ? '#059669' : '#dc2626'};">
                ৳ ${incomeStatement.netSurplus.toLocaleString()}
              </div>
            </div>
          </div>

          <!-- Section 1: Income vs Expense Statement -->
          <div class="section-title">1. ${isEn ? 'Statement of Operating Income & Expenses' : 'আয় ও ব্যয় বিবরণী'}</div>
          <div class="two-column">
            <div>
              <div style="font-weight: 700; font-size: 11px; color: #047857; margin-bottom: 4px;">(+) ${isEn ? 'Income Sources' : 'উপার্জিত আয়'}</div>
              <table>
                <thead><tr><th>খাত</th><th class="tar">টাকা</th><th class="tar">%</th></tr></thead>
                <tbody>
                  ${
                    incomeStatement.incomeCategories.length === 0
                      ? '<tr><td colspan="3" style="text-align:center;color:#94a3b8;">কোনো আয়ের তথ্য নেই</td></tr>'
                      : incomeStatement.incomeCategories
                          .map(
                            (c) =>
                              `<tr><td>${c.name}</td><td class="tar">৳ ${c.amount.toLocaleString()}</td><td class="tar">${c.percentage.toFixed(1)}%</td></tr>`
                          )
                          .join('')
                  }
                  <tr class="tot-row"><td>মোট আয়</td><td class="tar">৳ ${incomeStatement.totalIncome.toLocaleString()}</td><td class="tar">100%</td></tr>
                </tbody>
              </table>
            </div>

            <div>
              <div style="font-weight: 700; font-size: 11px; color: #dc2626; margin-bottom: 4px;">(-) ${isEn ? 'Expenses by Purpose' : 'ব্যয়সমূহ'}</div>
              <table>
                <thead><tr><th>খাত</th><th class="tar">টাকা</th><th class="tar">%</th></tr></thead>
                <tbody>
                  ${
                    incomeStatement.expenseCategories.length === 0
                      ? '<tr><td colspan="3" style="text-align:center;color:#94a3b8;">কোনো ব্যয়ের তথ্য নেই</td></tr>'
                      : incomeStatement.expenseCategories
                          .map(
                            (c) =>
                              `<tr><td>${c.name}</td><td class="tar">৳ ${c.amount.toLocaleString()}</td><td class="tar">${c.percentage.toFixed(1)}%</td></tr>`
                          )
                          .join('')
                  }
                  <tr class="tot-row"><td>মোট ব্যয়</td><td class="tar">৳ ${incomeStatement.totalExpense.toLocaleString()}</td><td class="tar">100%</td></tr>
                </tbody>
              </table>
            </div>
          </div>

          <div style="font-size: 11px; margin-bottom: 16px; padding: 6px 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; display: flex; justify-content: space-between;">
            <span><strong>${isEn ? 'Operating Result:' : 'পরিচালনা ফলাফল:'}</strong> ${incomeStatement.netSurplus >= 0 ? 'উদ্বৃত্ত (Surplus)' : 'ঘাটতি (Deficit)'}</span>
            <span style="font-weight: 800; color: ${incomeStatement.netSurplus >= 0 ? '#059669' : '#dc2626'};">৳ ${incomeStatement.netSurplus.toLocaleString()} (${isEn ? 'Savings Rate' : 'সঞ্চয়ের হার'}: ${incomeStatement.savingsRate.toFixed(1)}%)</span>
          </div>

          <!-- Section 2: Balance Sheet -->
          <div class="section-title">2. ${isEn ? 'Statement of Financial Position (Balance Sheet)' : 'আর্থিক স্থিতিপত্র (ব্যালেন্স শিট)'}</div>
          <div class="two-column">
            <div>
              <div style="font-weight: 700; font-size: 11px; color: #1e293b; margin-bottom: 4px;">[A] ${isEn ? 'Assets (মোট সম্পদ)' : 'সম্পদসমূহ'}</div>
              <table>
                <thead><tr><th>সম্পদের ধরন</th><th class="tar">স্থিতি (৳)</th></tr></thead>
                <tbody>
                  <tr><td>হাতে নগদ ক্যাশ (Cash)</td><td class="tar">৳ ${financialPosition.cashTotal.toLocaleString()}</td></tr>
                  <tr><td>ব্যাংক আমানত (Bank)</td><td class="tar">৳ ${financialPosition.bankTotal.toLocaleString()}</td></tr>
                  <tr><td>মোবাইল ব্যাংকিং (bKash/Nagad)</td><td class="tar">৳ ${financialPosition.mobileTotal.toLocaleString()}</td></tr>
                  <tr><td>কার্ড ও অন্যান্য (Cards)</td><td class="tar">৳ ${financialPosition.cardTotal.toLocaleString()}</td></tr>
                  <tr><td>প্রাপ্য ঋণ/পাওনা (Receivables)</td><td class="tar">৳ ${financialPosition.receivableTotal.toLocaleString()}</td></tr>
                  <tr class="tot-row"><td>সর্বমোট সম্পদ (Total Assets)</td><td class="tar">৳ ${financialPosition.totalAssets.toLocaleString()}</td></tr>
                </tbody>
              </table>
            </div>

            <div>
              <div style="font-weight: 700; font-size: 11px; color: #1e293b; margin-bottom: 4px;">[B] ${isEn ? 'Liabilities (মোট দায় ও দেনা)' : 'দায় ও দেনাসমূহ'}</div>
              <table>
                <thead><tr><th>দায়ের বিবরণ</th><th class="tar">স্থিতি (৳)</th></tr></thead>
                <tbody>
                  <tr><td>প্রদেয় ঋণ ও দেনা (Loans & Payables)</td><td class="tar">৳ ${financialPosition.liabilityTotal.toLocaleString()}</td></tr>
                  <tr class="tot-row"><td>সর্বমোট দায়/দেনা (Total Debt)</td><td class="tar">৳ ${financialPosition.liabilityTotal.toLocaleString()}</td></tr>
                </tbody>
              </table>
            </div>
          </div>

          <div class="net-worth-banner">
            <div>
              <div class="nw-title">${isEn ? 'NET WORTH EQUALITY' : 'প্রকৃত নিট সম্পদ (NET WORTH)'}</div>
              <div class="nw-formula">${isEn ? 'Total Assets (৳ ' + financialPosition.totalAssets.toLocaleString() + ') - Total Liabilities (৳ ' + financialPosition.liabilityTotal.toLocaleString() + ')' : 'সর্বমোট সম্পদ বাদ সর্বমোট দায়/দেনা'}</div>
            </div>
            <div class="nw-amount">৳ ${financialPosition.netWorth.toLocaleString()}</div>
          </div>

          <!-- Section 3: Detailed Account Schedule -->
          <div class="section-title">3. ${isEn ? 'Schedule of Account Balances' : 'সকল অ্যাকাউন্টের সর্বশেষ স্থিতি'}</div>
          <table>
            <thead><tr><th>#</th><th>অ্যাকাউন্টের নাম</th><th>শ্রেণি/ধরন</th><th class="tar">বর্তমান ব্যালেন্স</th></tr></thead>
            <tbody>
              ${balancedAccounts
                .map((acc, idx) => {
                  const name = isEn ? acc.nameEnglish : acc.nameBangla;
                  const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
                  return `<tr><td>${idx + 1}</td><td>${name}</td><td>${acc.type.toUpperCase()}</td><td class="tar bold">৳ ${bal.toLocaleString()}</td></tr>`;
                })
                .join('')}
            </tbody>
          </table>

          <div class="footer-notes">
            Onu Finance পার্সোনাল ফাইন্যান্স অ্যাপ্লিকেশন থেকে অফিসিয়ালি প্রস্তুতকৃত আর্থিক প্রতিবেদন।
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 350);
    }
  };

  // =========================================================================
  // EXPORT HANDLERS: LEDGER-BASED REPORT MODE
  // =========================================================================
  const handleExportLedgerCSV = () => {
    const lines: string[] = [];
    const userName = getUserDisplayName();

    if (selectedAccount && singleLedgerData) {
      const accName = isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla;
      lines.push(`"${isEn ? 'ONU FINANCE - ACCOUNT LEDGER STATEMENT' : 'Onu Finance - খতিয়ান হিসাব বিবরণী'}"`);
      lines.push(`"${isEn ? 'Account Name' : 'হিসাব/লেজারের নাম'}: ${accName}"`);
      lines.push(`"${isEn ? 'Classification' : 'শ্রেণি'}: ${selectedAccount.type.toUpperCase()}"`);
      if (selectedAccount.institutionName) {
        lines.push(`"${isEn ? 'Institution' : 'প্রতিষ্ঠান'}: ${selectedAccount.institutionName}"`);
      }
      if (selectedAccount.accountNumber || selectedAccount.phoneNumber) {
        lines.push(
          `"${isEn ? 'Account / Phone' : 'হিসাব / ফোন নম্বর'}: ${
            selectedAccount.accountNumber || selectedAccount.phoneNumber
          }"`
        );
      }
      if (userName) lines.push(`"${isEn ? 'Account Holder' : 'হিসাবধারী'}: ${userName}"`);
      lines.push(`"${isEn ? 'Reporting Period' : 'প্রতিবেদনের সময়কাল'}: ${getPeriodLabel()}"`);
      lines.push(`"${isEn ? 'Generated On' : 'তৈরির তারিখ'}: ${new Date().toLocaleString()}"`);
      lines.push('');

      lines.push(
        `"SL","${isEn ? 'Date' : 'তারিখ'}","${
          isEn ? 'Particulars / Description' : 'বিবরণ / খাত'
        }","${isEn ? 'Counter Account / Party' : 'বিপরীত হিসাব / পক্ষ'}","${
          isEn ? 'Note / Ref' : 'নোট / ভাউচার'
        }","${isEn ? 'Debit / Inflow (+)' : 'ডেবিট / জমা (+)'}","${
          isEn ? 'Credit / Outflow (-)' : 'ক্রেডিট / খরচ (-)'
        }","${isEn ? 'Running Balance (BDT)' : 'চলমান ব্যালেন্স (৳)'}"`
      );

      // Row 0: Opening Balance
      lines.push(
        `0,"${periodStartDate || '-'}","${
          isEn ? 'OPENING BALANCE (B/F)' : 'প্রারম্ভিক ব্যালেন্স (B/F)'
        }","-","-",0,0,${singleLedgerData.openingBalance}`
      );

      singleLedgerData.entries.forEach((e) => {
        const dateStr = e.date || '-';
        const cleanDesc = (e.particulars || '').replace(/"/g, '""');
        const cleanCounter = (e.counterAccount || '').replace(/"/g, '""');
        const cleanNote = (e.note || '').replace(/"/g, '""');
        lines.push(
          `${e.sl},"${dateStr}","${cleanDesc}","${cleanCounter}","${cleanNote}",${e.debit},${e.credit},${e.runningBalance}`
        );
      });

      lines.push(
        `"TOTAL","${periodEndDate || '-'}","${
          isEn ? 'PERIOD TOTALS & CLOSING BALANCE' : 'নির্দিষ্ট সময়কালের মোট ও সমাপনী জের'
        }","-","-",${singleLedgerData.totalDebit},${singleLedgerData.totalCredit},${singleLedgerData.closingBalance}`
      );
      lines.push('');
      lines.push(`"${isEn ? 'SUMMARY RECONCILIATION' : 'খতিয়ান জের সংক্ষেপ'}"`);
      lines.push(
        `"${isEn ? 'Pre-period Opening Balance' : 'প্রারম্ভিক স্থিতি'}",${singleLedgerData.openingBalance}`
      );
      lines.push(
        `"${isEn ? 'Period Total Debits' : 'মোট ডেবিট / জমা'}",${singleLedgerData.totalDebit}`
      );
      lines.push(
        `"${isEn ? 'Period Total Credits' : 'মোট ক্রেডিট / খরচ'}",${singleLedgerData.totalCredit}`
      );
      lines.push(
        `"${isEn ? 'Period Net Change' : 'নিট পরিবর্তন'}",${singleLedgerData.netMovement}`
      );
      lines.push(
        `"${isEn ? 'Final Closing Balance' : 'সর্বশেষ সমাপনী ব্যালেন্স'}",${singleLedgerData.closingBalance}`
      );

      const csvContent = '\uFEFF' + lines.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ledger_${selectedAccount.id}_${getFileBaseName()}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } else {
      lines.push(
        `"${isEn ? 'ONU FINANCE - MASTER GENERAL LEDGER SCHEDULE' : 'Onu Finance - মাস্টার সাধারণ খতিয়ান শিডিউল'}"`
      );
      if (userName) lines.push(`"${isEn ? 'Account Holder' : 'হিসাবধারী'}: ${userName}"`);
      lines.push(`"${isEn ? 'Reporting Period' : 'প্রতিবেদনের সময়কাল'}: ${getPeriodLabel()}"`);
      lines.push(`"${isEn ? 'Generated On' : 'তৈরির তারিখ'}: ${new Date().toLocaleString()}"`);
      lines.push('');

      lines.push(
        `"SL","${isEn ? 'Account Name' : 'হিসাবের নাম'}","${
          isEn ? 'Classification' : 'শ্রেণি'
        }","${isEn ? 'A/C Number' : 'অ্যাকাউন্ট নং'}","${
          isEn ? 'Opening Balance' : 'প্রারম্ভিক স্থিতি'
        }","${isEn ? 'Period Debit (+)' : 'নির্দিষ্ট সময়ের ডেবিট (+)'}","${
          isEn ? 'Period Credit (-)' : 'নির্দিষ্ট সময়ের ক্রেডিট (-)'
        }","${isEn ? 'Net Movement' : 'নিট পরিবর্তন'}","${
          isEn ? 'Closing Balance' : 'সমাপনী স্থিতি'
        }","${isEn ? 'Transactions' : 'মোট ভুক্তি'}"`
      );

      allLedgersSchedule.forEach((item) => {
        const name = isEn ? item.account.nameEnglish : item.account.nameBangla;
        const accNo = item.account.accountNumber || item.account.phoneNumber || '-';
        lines.push(
          `${item.sl},"${name}","${item.account.type.toUpperCase()}","${accNo}",${item.openingBalance},${item.periodDebit},${item.periodCredit},${item.netMovement},${item.closingBalance},${item.txCount}`
        );
      });

      lines.push(
        `"TOTAL","${isEn ? 'GRAND TOTAL' : 'সর্বমোট সমষ্টি'}","--","--",${allLedgersTotals.grandOpening},${allLedgersTotals.grandDebit},${allLedgersTotals.grandCredit},${allLedgersTotals.grandNet},${allLedgersTotals.grandClosing},${allLedgersTotals.grandTxCount}`
      );

      const csvContent = '\uFEFF' + lines.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `general_ledger_${getFileBaseName()}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    }

    setDownloadSuccess('csv');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleExportLedgerText = () => {
    const divider = '======================================================================';
    const subDivider = '----------------------------------------------------------------------';
    const userName = getUserDisplayName();

    let text = `${divider}\n`;
    if (selectedAccount && singleLedgerData) {
      const accName = isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla;
      text += `             ONU FINANCE - ACCOUNT LEDGER STATEMENT\n`;
      text += `                   হিসাব খতিয়ান বিবরণী\n`;
      text += `${divider}\n`;
      text += `${isEn ? 'Account Name' : 'লেজার হিসাব'}  : ${accName}\n`;
      text += `${isEn ? 'Account Type' : 'হিসাবের ধরন'}  : ${selectedAccount.type.toUpperCase()}\n`;
      if (selectedAccount.institutionName) {
        text += `${isEn ? 'Institution' : 'প্রতিষ্ঠান'}    : ${selectedAccount.institutionName}\n`;
      }
      if (selectedAccount.accountNumber || selectedAccount.phoneNumber) {
        text += `${isEn ? 'A/C or Phone' : 'অ্যাকাউন্ট/মোবাইল'} : ${
          selectedAccount.accountNumber || selectedAccount.phoneNumber
        }\n`;
      }
      if (userName) text += `${isEn ? 'Account Holder' : 'হিসাবধারী'} : ${userName}\n`;
      text += `${isEn ? 'Timeframe' : 'সময়কাল'}       : ${getPeriodLabel()}\n`;
      text += `${isEn ? 'Generated At' : 'তৈরির সময়'}  : ${new Date().toLocaleString()}\n`;
      text += `${divider}\n\n`;

      text += `[1] ${isEn ? 'FINANCIAL SUMMARY / রিকনসিলিয়েশন' : 'খতিয়ান সারসংক্ষেপ'}\n`;
      text += `${subDivider}\n`;
      text += ` • ${isEn ? 'Opening Balance (B/F)' : 'প্রারম্ভিক স্থিতি'} : ৳ ${singleLedgerData.openingBalance.toLocaleString()}\n`;
      text += ` • ${isEn ? 'Period Total Debits' : 'মোট ডেবিট / জমা (+)'} : ৳ ${singleLedgerData.totalDebit.toLocaleString()}\n`;
      text += ` • ${isEn ? 'Period Total Credits' : 'মোট ক্রেডিট / খরচ (-)'}: ৳ ${singleLedgerData.totalCredit.toLocaleString()}\n`;
      text += ` • ${isEn ? 'Period Net Change' : 'নিট পরিবর্তন'}         : ৳ ${singleLedgerData.netMovement.toLocaleString()}\n`;
      text += ` • ${isEn ? 'Closing Balance' : 'সমাপনী ব্যালেন্স'}     : ৳ ${singleLedgerData.closingBalance.toLocaleString()}\n`;
      text += ` • ${isEn ? 'Total Transactions' : 'মোট ভুক্তি সংখ্যা'} : ${singleLedgerData.count}\n\n`;

      text += `[2] ${isEn ? 'CHRONOLOGICAL LEDGER ENTRIES' : 'বিস্তারিত খতিয়ান বিবরণী'}\n`;
      text += `${subDivider}\n`;
      text += `SL  | Date       | Particulars / Notes            | Debit (৳)  | Credit (৳) | Balance (৳)\n`;
      text += `${subDivider}\n`;
      text += `0   | ${(periodStartDate || 'START').padEnd(10)} | OPENING BALANCE (প্রারম্ভিক স্থিতি) | 0          | 0          | ${singleLedgerData.openingBalance.toLocaleString()}\n`;

      if (singleLedgerData.entries.length === 0) {
        text += `    (এই সময়সীমায় এই লেজারে কোনো লেনদেন পাওয়া যায়নি)\n`;
      } else {
        singleLedgerData.entries.forEach((e) => {
          const slStr = String(e.sl).padEnd(3);
          const dateStr = (e.date || '').padEnd(10);
          const desc = `${e.particulars}${e.note ? ' - ' + e.note : ''}`.slice(0, 30).padEnd(30);
          const deb = e.debit > 0 ? e.debit.toLocaleString() : '-';
          const cre = e.credit > 0 ? e.credit.toLocaleString() : '-';
          text += `${slStr} | ${dateStr} | ${desc} | ${deb.padEnd(10)} | ${cre.padEnd(10)} | ${e.runningBalance.toLocaleString()}\n`;
        });
      }
      text += `${subDivider}\n`;
      text += `END | ${(periodEndDate || 'CLOSE').padEnd(10)} | CLOSING BALANCE (সমাপনী স্থিতি)   | ${singleLedgerData.totalDebit.toLocaleString().padEnd(10)} | ${singleLedgerData.totalCredit.toLocaleString().padEnd(10)} | ${singleLedgerData.closingBalance.toLocaleString()}\n`;
      text += `${divider}\n`;
    } else {
      text += `             ONU FINANCE - MASTER GENERAL LEDGER SCHEDULE\n`;
      text += `                    সাধারণ খতিয়ান মাস্টার শিডিউল\n`;
      text += `${divider}\n`;
      if (userName) text += `${isEn ? 'Account Holder' : 'হিসাবধারী'} : ${userName}\n`;
      text += `${isEn ? 'Timeframe' : 'সময়কাল'}       : ${getPeriodLabel()}\n`;
      text += `${isEn ? 'Generated At' : 'তৈরির সময়'}  : ${new Date().toLocaleString()}\n`;
      text += `${divider}\n\n`;

      text += `SL  | Account Name              | Type       | Opening (৳) | Debit (+)  | Credit (-) | Closing (৳)\n`;
      text += `${subDivider}\n`;
      allLedgersSchedule.forEach((item) => {
        const slStr = String(item.sl).padEnd(3);
        const name = (isEn ? item.account.nameEnglish : item.account.nameBangla).slice(0, 25).padEnd(25);
        const type = item.account.type.toUpperCase().slice(0, 10).padEnd(10);
        text += `${slStr} | ${name} | ${type} | ${item.openingBalance.toLocaleString().padEnd(11)} | ${item.periodDebit.toLocaleString().padEnd(10)} | ${item.periodCredit.toLocaleString().padEnd(10)} | ${item.closingBalance.toLocaleString()}\n`;
      });
      text += `${subDivider}\n`;
      text += `TOTAL | ALL ACCOUNTS (সর্বমোট)     | ALL        | ${allLedgersTotals.grandOpening.toLocaleString().padEnd(11)} | ${allLedgersTotals.grandDebit.toLocaleString().padEnd(10)} | ${allLedgersTotals.grandCredit.toLocaleString().padEnd(10)} | ${allLedgersTotals.grandClosing.toLocaleString()}\n`;
      text += `${divider}\n`;
    }

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ledger_${selectedAccount ? selectedAccount.id : 'all'}_${getFileBaseName()}.txt`;
    link.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('txt');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handlePrintLedger = () => {
    const userName = getUserDisplayName();

    let printBody = '';

    if (selectedAccount && singleLedgerData) {
      const accName = isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla;
      printBody = `
        <div class="header">
          <div class="company-name">ONU FINANCE</div>
          <div class="statement-subtitle">${isEn ? 'ACCOUNT LEDGER STATEMENT' : 'হিসাব খতিয়ান বিবরণী'}</div>
          <div class="statement-title">${accName}</div>
        </div>

        <div class="meta-grid">
          <div class="meta-item"><span class="meta-label">${isEn ? 'Account Type' : 'হিসাবের শ্রেণি'}:</span> <span class="meta-val">${selectedAccount.type.toUpperCase()}</span></div>
          <div class="meta-item"><span class="meta-label">${isEn ? 'Reporting Period' : 'প্রতিবেদনের সময়কাল'}:</span> <span class="meta-val">${getPeriodLabel()}</span></div>
          <div class="meta-item"><span class="meta-label">${isEn ? 'Account / Phone' : 'হিসাব/মোবাইল'}:</span> <span class="meta-val">${selectedAccount.accountNumber || selectedAccount.phoneNumber || '-'}</span></div>
          <div class="meta-item"><span class="meta-label">${isEn ? 'Generated At' : 'তৈরির সময়'}:</span> <span class="meta-val">${new Date().toLocaleString()}</span></div>
          ${userName ? `<div class="meta-item"><span class="meta-label">${isEn ? 'Prepared For' : 'হিসাবধারী'}:</span> <span class="meta-val">${userName}</span></div>` : ''}
        </div>

        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">${isEn ? 'Opening Balance' : 'প্রারম্ভিক জের'}</div>
            <div class="kpi-value">৳ ${singleLedgerData.openingBalance.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #10b981; background: #ecfdf5;">
            <div class="kpi-label" style="color: #047857;">${isEn ? 'Period Debits (+)' : 'মোট ডেবিট / বৃদ্ধি (+)'}</div>
            <div class="kpi-value" style="color: #047857;">+৳ ${singleLedgerData.totalDebit.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #f43f5e; background: #fff1f2;">
            <div class="kpi-label" style="color: #be123c;">${isEn ? 'Period Credits (-)' : 'মোট ক্রেডিট / হ্রাস (-)'}</div>
            <div class="kpi-value" style="color: #be123c;">-৳ ${singleLedgerData.totalCredit.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #0ea5e9; background: #f0f9ff;">
            <div class="kpi-label" style="color: #0369a1;">${isEn ? 'Closing Balance' : 'সমাপনী জের'}</div>
            <div class="kpi-value" style="color: #0369a1;">৳ ${singleLedgerData.closingBalance.toLocaleString()}</div>
          </div>
        </div>

        <div class="section-title">${isEn ? 'Chronological Ledger Transactions' : 'চলমান হিসাব ভুক্তি বিবরণী'}</div>
        <table>
          <thead>
            <tr>
              <th style="width: 35px;">#</th>
              <th style="width: 85px;">${isEn ? 'Date' : 'তারিখ'}</th>
              <th>${isEn ? 'Particulars / Description' : 'বিবরণ ও বিপরীত হিসাব'}</th>
              <th style="width: 110px;">${isEn ? 'Note / Ref' : 'নোট / মাধ্যম'}</th>
              <th class="tar" style="width: 95px;">${isEn ? 'Debit (+)' : 'ডেবিট (৳)'}</th>
              <th class="tar" style="width: 95px;">${isEn ? 'Credit (-)' : 'ক্রেডিট (৳)'}</th>
              <th class="tar" style="width: 105px;">${isEn ? 'Balance' : 'জের (৳)'}</th>
            </tr>
          </thead>
          <tbody>
            <tr style="background: #f8fafc; font-weight: bold;">
              <td>0</td>
              <td>${periodStartDate || '-'}</td>
              <td>${isEn ? 'OPENING BALANCE (B/F)' : 'প্রারম্ভিক স্থিতি (পূর্বের জের)'}</td>
              <td>--</td>
              <td class="tar">-</td>
              <td class="tar">-</td>
              <td class="tar">৳ ${singleLedgerData.openingBalance.toLocaleString()}</td>
            </tr>
            ${
              singleLedgerData.entries.length === 0
                ? `<tr><td colspan="7" style="text-align: center; color: #64748b; padding: 20px;">এই সময়সীমায় এই লেজারে কোনো নতুন লেনদেন হয়নি।</td></tr>`
                : singleLedgerData.entries
                    .map(
                      (e) => `
              <tr>
                <td>${e.sl}</td>
                <td>${e.date}</td>
                <td><strong>${e.particulars}</strong>${e.counterAccount ? `<br><small style="color: #64748b;">${e.counterAccount}</small>` : ''}</td>
                <td><small>${e.note || e.method || '-'}</small></td>
                <td class="tar" style="color: ${e.debit > 0 ? '#059669' : '#94a3b8'}; font-weight: ${e.debit > 0 ? 'bold' : 'normal'};">${e.debit > 0 ? '৳ ' + e.debit.toLocaleString() : '-'}</td>
                <td class="tar" style="color: ${e.credit > 0 ? '#e11d48' : '#94a3b8'}; font-weight: ${e.credit > 0 ? 'bold' : 'normal'};">${e.credit > 0 ? '৳ ' + e.credit.toLocaleString() : '-'}</td>
                <td class="tar" style="font-weight: bold;">৳ ${e.runningBalance.toLocaleString()}</td>
              </tr>
            `
                    )
                    .join('')
            }
            <tr class="total-row">
              <td colspan="4" style="text-align: right; padding-right: 15px;">${isEn ? 'PERIOD TOTALS & CLOSING' : 'সময়কালের মোট যোগফল ও সমাপনী জের'}:</td>
              <td class="tar" style="color: #059669;">৳ ${singleLedgerData.totalDebit.toLocaleString()}</td>
              <td class="tar" style="color: #e11d48;">৳ ${singleLedgerData.totalCredit.toLocaleString()}</td>
              <td class="tar double-underline">৳ ${singleLedgerData.closingBalance.toLocaleString()}</td>
            </tr>
          </tbody>
        </table>

        <div style="margin-top: 50px; display: flex; justify-content: space-between; font-size: 11px; color: #475569;">
          <div style="border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 6px;">
            ${isEn ? 'Prepared By' : 'প্রস্তুতকারীর স্বাক্ষর'}
          </div>
          <div style="border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 6px;">
            ${isEn ? 'Account Holder / Authorized' : 'হিসাবধারী / দায়িত্বপ্রাপ্ত স্বাক্ষর'}
          </div>
        </div>
      `;
    } else {
      printBody = `
        <div class="header">
          <div class="company-name">ONU FINANCE</div>
          <div class="statement-subtitle">${isEn ? 'MASTER GENERAL LEDGER SCHEDULE' : 'সাধারণ খতিয়ান মাস্টার শিডিউল'}</div>
          <div class="statement-title">${isEn ? 'All Accounts & Ledgers Summary' : 'সকল লেজার ও হিসাবের স্থিতি বিবরণী'}</div>
        </div>

        <div class="meta-grid">
          <div class="meta-item"><span class="meta-label">${isEn ? 'Reporting Period' : 'প্রতিবেদনের সময়কাল'}:</span> <span class="meta-val">${getPeriodLabel()}</span></div>
          <div class="meta-item"><span class="meta-label">${isEn ? 'Generated At' : 'তৈরির সময়'}:</span> <span class="meta-val">${new Date().toLocaleString()}</span></div>
          <div class="meta-item"><span class="meta-label">${isEn ? 'Total Accounts' : 'মোট লেজার হিসাব'}:</span> <span class="meta-val">${allAccounts.length} টি</span></div>
          ${userName ? `<div class="meta-item"><span class="meta-label">${isEn ? 'Prepared For' : 'হিসাবধারী'}:</span> <span class="meta-val">${userName}</span></div>` : ''}
        </div>

        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">${isEn ? 'Total Opening' : 'সর্বমোট প্রারম্ভিক'}</div>
            <div class="kpi-value">৳ ${allLedgersTotals.grandOpening.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #10b981; background: #ecfdf5;">
            <div class="kpi-label" style="color: #047857;">${isEn ? 'Total Debits (+)' : 'মোট ডেবিট (+)'}</div>
            <div class="kpi-value" style="color: #047857;">৳ ${allLedgersTotals.grandDebit.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #f43f5e; background: #fff1f2;">
            <div class="kpi-label" style="color: #be123c;">${isEn ? 'Total Credits (-)' : 'মোট ক্রেডিট (-)'}</div>
            <div class="kpi-value" style="color: #be123c;">৳ ${allLedgersTotals.grandCredit.toLocaleString()}</div>
          </div>
          <div class="kpi-card" style="border-color: #0ea5e9; background: #f0f9ff;">
            <div class="kpi-label" style="color: #0369a1;">${isEn ? 'Total Closing' : 'সর্বমোট সমাপনী'}</div>
            <div class="kpi-value" style="color: #0369a1;">৳ ${allLedgersTotals.grandClosing.toLocaleString()}</div>
          </div>
        </div>

        <div class="section-title">${isEn ? 'General Ledger Schedule Table' : 'সাধারণ খতিয়ান তালিকা'}</div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>${isEn ? 'Account Name' : 'অ্যাকাউন্টের নাম'}</th>
              <th>${isEn ? 'Type' : 'শ্রেণি'}</th>
              <th class="tar">${isEn ? 'Opening' : 'প্রারম্ভিক (৳)'}</th>
              <th class="tar">${isEn ? 'Debit (+)' : 'ডেবিট (৳)'}</th>
              <th class="tar">${isEn ? 'Credit (-)' : 'ক্রেডিট (৳)'}</th>
              <th class="tar">${isEn ? 'Closing' : 'সমাপনী (৳)'}</th>
            </tr>
          </thead>
          <tbody>
            ${allLedgersSchedule
              .map((item) => {
                const name = isEn ? item.account.nameEnglish : item.account.nameBangla;
                return `
              <tr>
                <td>${item.sl}</td>
                <td><strong>${name}</strong></td>
                <td><small>${item.account.type.toUpperCase()}</small></td>
                <td class="tar">৳ ${item.openingBalance.toLocaleString()}</td>
                <td class="tar" style="color: #059669;">৳ ${item.periodDebit.toLocaleString()}</td>
                <td class="tar" style="color: #e11d48;">৳ ${item.periodCredit.toLocaleString()}</td>
                <td class="tar bold">৳ ${item.closingBalance.toLocaleString()}</td>
              </tr>
            `;
              })
              .join('')}
            <tr class="total-row">
              <td colspan="3" style="text-align: right; padding-right: 15px;">${isEn ? 'GRAND TOTAL' : 'সর্বমোট সমষ্টি'}:</td>
              <td class="tar">৳ ${allLedgersTotals.grandOpening.toLocaleString()}</td>
              <td class="tar" style="color: #059669;">৳ ${allLedgersTotals.grandDebit.toLocaleString()}</td>
              <td class="tar" style="color: #e11d48;">৳ ${allLedgersTotals.grandCredit.toLocaleString()}</td>
              <td class="tar double-underline">৳ ${allLedgersTotals.grandClosing.toLocaleString()}</td>
            </tr>
          </tbody>
        </table>
      `;
    }

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${isEn ? 'ONU FINANCE - ACCOUNT LEDGER' : 'Onu Finance - খতিয়ান বিবরণী'}</title>
          <style>
            body { font-family: 'Hind Siliguri', 'Segoe UI', Arial, sans-serif; padding: 25px; color: #1e293b; line-height: 1.4; font-size: 12px; }
            .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 18px; }
            .company-name { font-size: 20px; font-weight: 900; letter-spacing: 2px; color: #0f172a; }
            .statement-subtitle { font-size: 10px; font-weight: 700; color: #64748b; letter-spacing: 1px; margin-top: 2px; }
            .statement-title { font-size: 15px; font-weight: bold; margin-top: 6px; color: #0284c7; }
            .meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px 20px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-size: 11px; }
            .meta-label { color: #64748b; font-weight: 600; }
            .meta-val { font-weight: bold; color: #0f172a; }
            .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; }
            .kpi-card { border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; text-align: center; background: #ffffff; }
            .kpi-label { font-size: 10px; font-weight: bold; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
            .kpi-value { font-size: 14px; font-weight: 900; color: #0f172a; }
            .section-title { font-size: 13px; font-weight: 800; border-bottom: 1.5px solid #0f172a; padding-bottom: 4px; margin: 18px 0 10px; color: #0f172a; text-transform: uppercase; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #cbd5e1; padding: 6px 8px; font-size: 11px; }
            th { background: #f1f5f9; font-weight: 800; text-align: left; }
            tr:nth-child(even) { background-color: #fafbfc; }
            .tar { text-align: right; }
            .bold { font-weight: bold; }
            .total-row { background: #f8fafc; font-weight: 900; border-top: 2px solid #0f172a; }
            .double-underline { text-decoration: underline double; }
            @media print {
              body { padding: 0; }
              @page { margin: 1.2cm; size: A4; }
            }
          </style>
        </head>
        <body>
          ${printBody}
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 350);
    }
  };

  const handleCopySummary = async () => {
    let summaryText = '';
    if (reportMode === 'statement') {
      summaryText = isEn
        ? `🏛️ ONU FINANCE - FINANCIAL STATEMENT (${getPeriodLabel()})\n` +
          `• Net Worth: ৳ ${financialPosition.netWorth.toLocaleString()}\n` +
          `• Total Assets: ৳ ${financialPosition.totalAssets.toLocaleString()}\n` +
          `• Total Liabilities: ৳ ${financialPosition.liabilityTotal.toLocaleString()}\n` +
          `• Liquid Reserves: ৳ ${financialPosition.liquidCash.toLocaleString()}\n` +
          `• Period Income: ৳ ${incomeStatement.totalIncome.toLocaleString()}\n` +
          `• Period Expense: ৳ ${incomeStatement.totalExpense.toLocaleString()}\n` +
          `• Period Surplus: ৳ ${incomeStatement.netSurplus.toLocaleString()} (${incomeStatement.savingsRate.toFixed(1)}%)`
        : `🏛️ Onu Finance - ফাইন্যান্সিয়াল স্টেটমেন্ট (${getPeriodLabel()})\n` +
          `• প্রকৃত নিট সম্পদ: ৳ ${financialPosition.netWorth.toLocaleString()}\n` +
          `• সর্বমোট সম্পদ: ৳ ${financialPosition.totalAssets.toLocaleString()}\n` +
          `• সর্বমোট দায়/দেনা: ৳ ${financialPosition.liabilityTotal.toLocaleString()}\n` +
          `• তারল্য তহবিল: ৳ ${financialPosition.liquidCash.toLocaleString()}\n` +
          `• সময়কালের মোট আয়: ৳ ${incomeStatement.totalIncome.toLocaleString()}\n` +
          `• সময়কালের মোট খরচ: ৳ ${incomeStatement.totalExpense.toLocaleString()}\n` +
          `• নিট উদ্বৃত্ত: ৳ ${incomeStatement.netSurplus.toLocaleString()} (সঞ্চয়ের হার: ${incomeStatement.savingsRate.toFixed(1)}%)`;
    } else if (reportMode === 'ledger') {
      if (selectedAccount && singleLedgerData) {
        const accName = isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla;
        summaryText = isEn
          ? `📖 ONU FINANCE - ACCOUNT LEDGER (${accName})\n` +
            `• Period: ${getPeriodLabel()}\n` +
            `• Opening Balance: ৳ ${singleLedgerData.openingBalance.toLocaleString()}\n` +
            `• Period Total Debits (+): ৳ ${singleLedgerData.totalDebit.toLocaleString()}\n` +
            `• Period Total Credits (-): ৳ ${singleLedgerData.totalCredit.toLocaleString()}\n` +
            `• Net Movement: ৳ ${singleLedgerData.netMovement.toLocaleString()}\n` +
            `• Closing Balance: ৳ ${singleLedgerData.closingBalance.toLocaleString()}\n` +
            `• Total Transactions: ${singleLedgerData.count}`
          : `📖 Onu Finance - খতিয়ান বিবরণী (${accName})\n` +
            `• সময়কাল: ${getPeriodLabel()}\n` +
            `• প্রারম্ভিক স্থিতি: ৳ ${singleLedgerData.openingBalance.toLocaleString()}\n` +
            `• মোট ডেবিট/জমা (+): ৳ ${singleLedgerData.totalDebit.toLocaleString()}\n` +
            `• মোট ক্রেডিট/খরচ (-): ৳ ${singleLedgerData.totalCredit.toLocaleString()}\n` +
            `• নিট পরিবর্তন: ৳ ${singleLedgerData.netMovement.toLocaleString()}\n` +
            `• সমাপনী স্থিতি: ৳ ${singleLedgerData.closingBalance.toLocaleString()}\n` +
            `• মোট ভুক্তির সংখ্যা: ${singleLedgerData.count} টি`;
      } else {
        summaryText = isEn
          ? `📖 ONU FINANCE - GENERAL LEDGER SUMMARY\n` +
            `• Period: ${getPeriodLabel()}\n` +
            `• Total Accounts: ${allAccounts.length}\n` +
            `• Total Debits (+): ৳ ${allLedgersTotals.grandDebit.toLocaleString()}\n` +
            `• Total Credits (-): ৳ ${allLedgersTotals.grandCredit.toLocaleString()}\n` +
            `• Total Closing: ৳ ${allLedgersTotals.grandClosing.toLocaleString()}`
          : `📖 Onu Finance - সাধারণ খতিয়ান সারসংক্ষেপ\n` +
            `• সময়কাল: ${getPeriodLabel()}\n` +
            `• সর্বমোট লেজার হিসাব: ${allAccounts.length} টি\n` +
            `• মোট ডেবিট/জমা (+): ৳ ${allLedgersTotals.grandDebit.toLocaleString()}\n` +
            `• মোট ক্রেডিট/খরচ (-): ৳ ${allLedgersTotals.grandCredit.toLocaleString()}\n` +
            `• সর্বমোট সমাপনী জের: ৳ ${allLedgersTotals.grandClosing.toLocaleString()}`;
      }
    } else {
      summaryText = isEn
        ? `📊 Onu Finance Report (${getPeriodLabel()})\n` +
          `• Total Income: ৳${stats.totalIncome.toLocaleString()}\n` +
          `• Total Expense: ৳${stats.totalExpense.toLocaleString()}\n` +
          `• Net Balance: ৳${stats.netBalance.toLocaleString()}\n` +
          `• Transactions: ${stats.count}`
        : `📊 Onu Finance রিপোর্ট (${getPeriodLabel()})\n` +
          `• মোট আয়: ৳${stats.totalIncome.toLocaleString()}\n` +
          `• মোট খরচ: ৳${stats.totalExpense.toLocaleString()}\n` +
          `• নিট ব্যালেন্স: ৳${stats.netBalance.toLocaleString()}\n` +
          `• মোট লেনদেন: ${stats.count} টি`;
    }

    try {
      await navigator.clipboard.writeText(summaryText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      if (reportMode === 'statement') handleExportStatementText();
      else if (reportMode === 'ledger') handleExportLedgerText();
      else handleExportTextTransactions();
    }
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isLight ? 'bg-slate-900/45 backdrop-blur-xs' : 'bg-black/80 backdrop-blur-xs'
      } p-3 sm:p-4 animate-in fade-in duration-200`}
    >
      <div
        className={`w-full max-w-lg max-h-[94vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 ${
          isLight ? 'bg-white border-sky-200 text-sky-950' : 'bg-slate-900 border-slate-700 text-white'
        }`}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b flex items-center justify-between border-black/10 dark:border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div
              className="p-2.5 rounded-2xl border transition"
              style={{
                backgroundColor: `${dualAccent.primary.hex}20`,
                borderColor: `${dualAccent.primary.hex}40`,
                color: dualAccent.primary.hex,
              }}
            >
              {reportMode === 'statement' ? (
                <Building2 className="w-5 h-5" />
              ) : reportMode === 'ledger' ? (
                <BookOpen className="w-5 h-5" />
              ) : (
                <FileDown className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-sm font-black flex items-center gap-2">
                <span>
                  {reportMode === 'statement'
                    ? isEn
                      ? 'Financial Statement'
                      : 'ফাইন্যান্সিয়াল স্টেটমেন্ট'
                    : reportMode === 'ledger'
                    ? isEn
                      ? 'Ledger Account Reports'
                      : 'লেজার খতিয়ান রিপোর্ট'
                    : isEn
                    ? 'Export Reports'
                    : 'রিপোর্ট এক্সপোর্ট'}
                </span>
                <span
                  className="text-[10px] px-2 py-0.5 rounded-full font-extrabold border"
                  style={{
                    backgroundColor: `${dualAccent.primary.hex}20`,
                    borderColor: `${dualAccent.primary.hex}40`,
                    color: dualAccent.primary.hex,
                  }}
                >
                  {reportMode === 'statement'
                    ? isEn
                      ? 'Balance Sheet & P&L'
                      : 'ব্যালেন্স শিট ও আয়-ব্যয়'
                    : reportMode === 'ledger'
                    ? isEn
                      ? 'Ledgers & Schedules'
                      : 'খতিয়ান বিবরণী'
                    : 'CSV / TXT / Print'}
                </span>
              </h2>
              <p className="text-[10px] opacity-75 mt-0.5">
                {reportMode === 'statement'
                  ? isEn
                    ? 'Statement of Financial Position, Income, Expenses & Net Worth'
                    : 'সম্পদ, দেনা, আয়-ব্যয় ও প্রকৃত নিট সম্পদের সম্পূর্ণ স্টেটমেন্ট'
                  : reportMode === 'ledger'
                  ? isEn
                    ? 'Individual account ledgers with opening balance, debits, credits & closing balances'
                    : 'অ্যাকাউন্ট ও পার্টি ভিত্তিক প্রারম্ভিক জের, জমা-খরচ ও চলমান খতিয়ান বিবরণী'
                  : isEn
                  ? 'Extract daily, monthly, or yearly specialized statements'
                  : 'মাসিক, দৈনিক বা বাৎসরিক বিশেষ আর্থিক বিবরণী এক্সট্রাক্ট করুন'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-1.5 rounded-xl border transition ${
              isLight
                ? 'border-sky-200 hover:bg-sky-50 text-slate-500'
                : 'border-slate-700 hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* PRIMARY SWITCHER: Transaction Report vs Ledger Report vs Financial Statement */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-extrabold uppercase tracking-wider opacity-75 block">
                {isEn ? 'Report Type' : 'রিপোর্টের ধরন'}
              </label>
              <span className="text-[10px] font-bold opacity-60">
                {reportMode === 'statement'
                  ? isEn
                    ? 'Audit Ready'
                    : 'অডিট উপযোগী'
                  : reportMode === 'ledger'
                  ? isEn
                    ? 'Account Ledgers'
                    : 'খতিয়ান হিসাব'
                  : isEn
                  ? 'Audit Log'
                  : 'লেনদেন তালিকা'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10">
              <button
                type="button"
                onClick={() => setReportMode('transactions')}
                style={
                  reportMode === 'transactions'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  reportMode === 'transactions'
                    ? 'shadow-xs border'
                    : 'opacity-70 hover:opacity-100'
                }`}
                id="tab-mode-transactions"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span className="truncate">{isEn ? 'Transactions' : 'লেনদেন তালিকা'}</span>
              </button>

              <button
                type="button"
                onClick={() => setReportMode('ledger')}
                style={
                  reportMode === 'ledger'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  reportMode === 'ledger'
                    ? 'shadow-xs border'
                    : 'opacity-70 hover:opacity-100'
                }`}
                id="tab-mode-ledger"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span className="truncate">{isEn ? 'Ledger Report' : 'লেজার খতিয়ান'}</span>
              </button>

              <button
                type="button"
                onClick={() => setReportMode('statement')}
                style={
                  reportMode === 'statement'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  reportMode === 'statement'
                    ? 'shadow-xs border'
                    : 'opacity-70 hover:opacity-100'
                }`}
                id="tab-mode-statement"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span className="truncate">{isEn ? 'Statement' : 'স্টেটমেন্ট'}</span>
              </button>
            </div>
          </div>

          {/* Timeframe Selection Tabs */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-extrabold uppercase tracking-wider opacity-75 block">
                {isEn ? '1. Select Timeframe' : '১. সময়সীমা নির্বাচন করুন'}
              </label>
              <span className="text-[10px] font-bold text-indigo-500">
                {getPeriodLabel()}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1 p-1 rounded-2xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10">
              <button
                type="button"
                onClick={() => setPeriodType('monthly')}
                style={
                  periodType === 'monthly'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-0.5 rounded-xl text-[11px] font-bold transition text-center ${
                  periodType === 'monthly' ? 'shadow-xs border' : 'opacity-70 hover:opacity-100'
                }`}
              >
                {isEn ? 'Monthly' : 'মাসিক'}
              </button>
              <button
                type="button"
                onClick={() => setPeriodType('yearly')}
                style={
                  periodType === 'yearly'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-0.5 rounded-xl text-[11px] font-bold transition text-center ${
                  periodType === 'yearly' ? 'shadow-xs border' : 'opacity-70 hover:opacity-100'
                }`}
              >
                {isEn ? 'Yearly' : 'বাৎসরিক'}
              </button>
              <button
                type="button"
                onClick={() => setPeriodType('daily')}
                style={
                  periodType === 'daily'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-0.5 rounded-xl text-[11px] font-bold transition text-center ${
                  periodType === 'daily' ? 'shadow-xs border' : 'opacity-70 hover:opacity-100'
                }`}
              >
                {isEn ? 'Daily' : 'দৈনিক'}
              </button>
              <button
                type="button"
                onClick={() => setPeriodType('custom')}
                style={
                  periodType === 'custom'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-0.5 rounded-xl text-[11px] font-bold transition text-center ${
                  periodType === 'custom' ? 'shadow-xs border' : 'opacity-70 hover:opacity-100'
                }`}
              >
                {isEn ? 'Custom' : 'কাস্টম'}
              </button>
              <button
                type="button"
                onClick={() => setPeriodType('all')}
                style={
                  periodType === 'all'
                    ? {
                        backgroundColor: isLight ? '#ffffff' : `${dualAccent.primary.hex}25`,
                        color: dualAccent.primary.hex,
                        borderColor: dualAccent.primary.hex,
                      }
                    : undefined
                }
                className={`py-2 px-0.5 rounded-xl text-[11px] font-bold transition text-center ${
                  periodType === 'all' ? 'shadow-xs border' : 'opacity-70 hover:opacity-100'
                }`}
              >
                {isEn ? 'All Time' : 'সর্বকালীন'}
              </button>
            </div>
          </div>

          {/* Timeframe Parameter Pickers */}
          <div
            className={`p-3 rounded-2xl border ${
              isLight ? 'bg-sky-50/60 border-sky-200' : 'bg-slate-800/60 border-slate-700'
            }`}
          >
            {periodType === 'monthly' && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  {isEn ? 'Choose Month' : 'মাস নির্বাচন করুন'}
                </label>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    isLight
                      ? 'bg-white border-sky-300 text-slate-800'
                      : 'bg-slate-900 border-slate-600 text-white'
                  }`}
                >
                  {availableMonths.map((ym) => (
                    <option key={ym} value={ym}>
                      {getMonthName(ym, appSettings.language, useBangla)} ({ym})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {periodType === 'daily' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold flex items-center gap-1.5">
                    <CalendarDays className="w-3.5 h-3.5 text-indigo-500" />
                    {isEn ? 'Choose Date' : 'তারিখ নির্বাচন করুন'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setSelectedDate(todayStr)}
                    className="text-[10px] text-indigo-500 hover:underline font-bold"
                  >
                    {isEn ? 'Set to Today' : 'আজকের দিন'}
                  </button>
                </div>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    isLight
                      ? 'bg-white border-sky-300 text-slate-800'
                      : 'bg-slate-900 border-slate-600 text-white'
                  }`}
                />
              </div>
            )}

            {periodType === 'yearly' && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  {isEn ? 'Choose Year' : 'বছর নির্বাচন করুন'}
                </label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    isLight
                      ? 'bg-white border-sky-300 text-slate-800'
                      : 'bg-slate-900 border-slate-600 text-white'
                  }`}
                >
                  {availableYears.map((yr) => (
                    <option key={yr} value={yr}>
                      {isEn ? `Year ${yr}` : `${useBangla ? toBanglaDigits(yr) : yr} সাল`}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {periodType === 'custom' && (
              <div className="space-y-2">
                <label className="text-[11px] font-bold flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  {isEn ? 'Date Range (From - To)' : 'তারিখের পরিসীমা (শুরু - শেষ)'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] opacity-70 block mb-1">
                      {isEn ? 'Start Date' : 'শুরুর তারিখ'}
                    </span>
                    <input
                      type="date"
                      value={customStartDate}
                      onChange={(e) => setCustomStartDate(e.target.value)}
                      className={`w-full p-2 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        isLight
                          ? 'bg-white border-sky-300 text-slate-800'
                          : 'bg-slate-900 border-slate-600 text-white'
                      }`}
                    />
                  </div>
                  <div>
                    <span className="text-[10px] opacity-70 block mb-1">
                      {isEn ? 'End Date' : 'শেষের তারিখ'}
                    </span>
                    <input
                      type="date"
                      value={customEndDate}
                      onChange={(e) => setCustomEndDate(e.target.value)}
                      className={`w-full p-2 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        isLight
                          ? 'bg-white border-sky-300 text-slate-800'
                          : 'bg-slate-900 border-slate-600 text-white'
                      }`}
                    />
                  </div>
                </div>
              </div>
            )}

            {periodType === 'all' && (
              <div className="flex items-center gap-2 text-xs py-1">
                <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="opacity-80">
                  {isEn
                    ? 'All cumulative transactions and current account balances will be included.'
                    : 'পূর্বাপর সকল লেনদেন ও বর্তমান মোট সম্পদ-দায়ের পূর্ণাঙ্গ হিসাব অন্তর্ভুক্ত থাকবে।'}
                </span>
              </div>
            )}
          </div>

          {/* =========================================================================
              VIEW 1: FINANCIAL STATEMENT DASHBOARD PREVIEW
              ========================================================================= */}
          {reportMode === 'statement' ? (
            <div className="space-y-3">
              {/* Executive Net Worth Badge */}
              <div
                className={`p-3.5 rounded-2xl border space-y-3 ${
                  isLight
                    ? 'bg-gradient-to-br from-emerald-50/80 to-sky-50/80 border-emerald-200'
                    : 'bg-slate-800/90 border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-black">
                    <Scale className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      {isEn ? 'Executive Financial Position' : 'আর্থিক অবস্থান ও নিট সম্পদ'}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                    {balancedAccounts.length} {isEn ? 'Accounts' : 'টি অ্যাকাউন্ট'}
                  </span>
                </div>

                {/* Net Worth Hero Display */}
                <div
                  className={`p-3 rounded-2xl border text-center ${
                    financialPosition.netWorth >= 0
                      ? isLight
                        ? 'bg-emerald-500/10 border-emerald-300'
                        : 'bg-emerald-950/30 border-emerald-800'
                      : isLight
                      ? 'bg-rose-500/10 border-rose-300'
                      : 'bg-rose-950/30 border-rose-800'
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-75 block">
                    {isEn ? 'Net Worth (Assets - Liabilities)' : 'প্রকৃত নিট সম্পদ (মোট সম্পদ বাদ মোট দেনা)'}
                  </span>
                  <div
                    className={`text-xl sm:text-2xl font-black mt-1 ${
                      financialPosition.netWorth >= 0
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {formatCurrency(financialPosition.netWorth, useBangla)}
                  </div>
                </div>

                {/* 4 Quadrants: Assets, Liabilities, Income, Expense */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] opacity-75 font-bold">
                      <span>{isEn ? 'Total Assets' : 'সর্বমোট সম্পদ'}</span>
                      <Landmark className="w-3 h-3 text-sky-500" />
                    </div>
                    <div className="font-extrabold text-sky-700 dark:text-sky-400 mt-1">
                      {formatCurrency(financialPosition.totalAssets, useBangla)}
                    </div>
                    <div className="text-[9px] opacity-60 mt-0.5">
                      {isEn ? 'Liquid: ' : 'তারল্য: '}
                      {formatCurrency(financialPosition.liquidCash, useBangla)}
                    </div>
                  </div>

                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-rose-200' : 'bg-slate-900 border-rose-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] opacity-75 font-bold">
                      <span>{isEn ? 'Total Liabilities' : 'সর্বমোট দায়/দেনা'}</span>
                      <TrendingDown className="w-3 h-3 text-rose-500" />
                    </div>
                    <div className="font-extrabold text-rose-600 dark:text-rose-400 mt-1">
                      {formatCurrency(financialPosition.liabilityTotal, useBangla)}
                    </div>
                    <div className="text-[9px] opacity-60 mt-0.5">
                      {financialPosition.liabilityAccounts.length} {isEn ? 'Payables' : 'টি দেনা খাত'}
                    </div>
                  </div>

                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-emerald-200' : 'bg-slate-900 border-emerald-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] opacity-75 font-bold">
                      <span>{isEn ? 'Period Income' : 'নির্দিষ্ট সময়ের আয়'}</span>
                      <TrendingUp className="w-3 h-3 text-emerald-500" />
                    </div>
                    <div className="font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">
                      {formatCurrency(incomeStatement.totalIncome, useBangla)}
                    </div>
                  </div>

                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-amber-200' : 'bg-slate-900 border-amber-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] opacity-75 font-bold">
                      <span>{isEn ? 'Period Surplus' : 'নিট উদ্বৃত্ত'}</span>
                      <Wallet className="w-3 h-3 text-amber-500" />
                    </div>
                    <div
                      className={`font-extrabold mt-1 ${
                        incomeStatement.netSurplus >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {formatCurrency(incomeStatement.netSurplus, useBangla)}
                    </div>
                    <div className="text-[9px] opacity-60 mt-0.5">
                      {isEn ? 'Savings: ' : 'সঞ্চয়: '}
                      {incomeStatement.savingsRate.toFixed(1)}%
                    </div>
                  </div>
                </div>

                {/* Collapsible Detailed Statement Breakdowns */}
                <button
                  type="button"
                  onClick={() => setShowStatementDetails(!showStatementDetails)}
                  className={`w-full py-1.5 px-3 rounded-xl border text-[11px] font-bold flex items-center justify-between transition ${
                    isLight
                      ? 'bg-white/80 border-slate-200 text-slate-700 hover:bg-white'
                      : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:bg-slate-900'
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <PieChart className="w-3.5 h-3.5 text-indigo-500" />
                    {showStatementDetails
                      ? isEn
                        ? 'Hide Statement Breakdown'
                        : 'স্টেটমেন্ট বিস্তারিত লুকান'
                      : isEn
                      ? 'View Detailed Statement Breakdown'
                      : 'স্টেটমেন্টের বিস্তারিত বিশ্লেষণ দেখুন'}
                  </span>
                  {showStatementDetails ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>

                {showStatementDetails && (
                  <div className="space-y-2 pt-1 animate-in fade-in duration-150 text-[11px]">
                    {/* Assets Schedule */}
                    <div
                      className={`p-2.5 rounded-xl border ${
                        isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-700'
                      }`}
                    >
                      <div className="font-extrabold text-sky-600 dark:text-sky-400 mb-1.5 flex justify-between">
                        <span>{isEn ? 'Assets Breakdown (সম্পদ)' : 'সম্পদের বিভাজন'}</span>
                        <span>{formatCurrency(financialPosition.totalAssets, useBangla)}</span>
                      </div>
                      <div className="space-y-1 opacity-85 text-[10px]">
                        <div className="flex justify-between">
                          <span>{isEn ? 'Cash in Hand (নগদ)' : 'হাতে নগদ ক্যাশ'}</span>
                          <span className="font-bold">
                            {formatCurrency(financialPosition.cashTotal, useBangla)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>{isEn ? 'Bank Accounts (ব্যাংক)' : 'ব্যাংক হিসাব'}</span>
                          <span className="font-bold">
                            {formatCurrency(financialPosition.bankTotal, useBangla)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>{isEn ? 'Mobile Wallets (বিকাশ/নগদ)' : 'মোবাইল ওয়ালেট'}</span>
                          <span className="font-bold">
                            {formatCurrency(financialPosition.mobileTotal, useBangla)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>{isEn ? 'Accounts Receivable (পাওনা)' : 'প্রাপ্য পাওনা'}</span>
                          <span className="font-bold">
                            {formatCurrency(financialPosition.receivableTotal, useBangla)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Top Expenses */}
                    {incomeStatement.expenseCategories.length > 0 && (
                      <div
                        className={`p-2.5 rounded-xl border ${
                          isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-700'
                        }`}
                      >
                        <div className="font-extrabold text-rose-600 dark:text-rose-400 mb-1 flex justify-between">
                          <span>{isEn ? 'Top Expenses by Category' : 'শীর্ষ খরচের খাতসমূহ'}</span>
                          <span>{formatCurrency(incomeStatement.totalExpense, useBangla)}</span>
                        </div>
                        <div className="space-y-1 opacity-85 text-[10px]">
                          {incomeStatement.expenseCategories.slice(0, 4).map((c) => (
                            <div key={c.catId} className="flex justify-between">
                              <span>{c.name}</span>
                              <span className="font-bold">
                                {formatCurrency(c.amount, useBangla)} ({c.percentage.toFixed(1)}%)
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : reportMode === 'ledger' ? (
            /* =========================================================================
               VIEW 2: LEDGER ACCOUNT REPORT PREVIEW & SELECTOR
               ========================================================================= */
            <div className="space-y-3">
              {/* Ledger Filter & Account Picker Card */}
              <div
                className={`p-3.5 rounded-2xl border space-y-2.5 ${
                  isLight ? 'bg-sky-50/50 border-sky-200' : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-extrabold uppercase tracking-wider opacity-75 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{isEn ? '2. Choose Ledger Account' : '২. লেজার বা খতিয়ান নির্বাচন করুন'}</span>
                  </label>
                  <span className="text-[10px] font-bold text-indigo-500">
                    {selectedLedgerId === '__all__'
                      ? isEn
                        ? 'Master General Ledger'
                        : 'মাস্টার শিডিউল'
                      : selectedAccount
                      ? selectedAccount.type.toUpperCase()
                      : ''}
                  </span>
                </div>

                {/* Quick Category Filter Pills: All | Wallets | Receivables (পাওনা/দেনাদার) | Payables (দেনা/পাওনাদার) */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[10px] font-bold">
                  {[
                    { id: 'all', labelEn: 'All Ledgers', labelBn: 'সকল লেজার' },
                    { id: 'wallet', labelEn: 'Cash & Banks', labelBn: 'ক্যাশ ও ব্যাংক' },
                    { id: 'receivable', labelEn: 'Receivables (পাওনা টাকা)', labelBn: 'পাওনা টাকা (দেনাদার)' },
                    { id: 'payable', labelEn: 'Payables (দেনা বা ঋণ)', labelBn: 'দেনা বা কর্জ (পাওনাদার)' },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => {
                        setLedgerCategoryFilter(tab.id as LedgerCategoryFilter);
                      }}
                      style={
                        ledgerCategoryFilter === tab.id
                          ? {
                              backgroundColor: `${dualAccent.primary.hex}25`,
                              color: dualAccent.primary.hex,
                              borderColor: dualAccent.primary.hex,
                            }
                          : undefined
                      }
                      className={`py-1 px-2.5 rounded-xl border whitespace-nowrap transition cursor-pointer ${
                        ledgerCategoryFilter === tab.id
                          ? 'border font-extrabold shadow-2xs'
                          : isLight
                          ? 'bg-white border-sky-200 text-slate-600 hover:bg-sky-50'
                          : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {isEn ? tab.labelEn : tab.labelBn}
                    </button>
                  ))}
                </div>

                {/* Main Ledger Select Dropdown */}
                <div className="relative">
                  <select
                    value={selectedLedgerId}
                    onChange={(e) => setSelectedLedgerId(e.target.value)}
                    className={`w-full p-2.5 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                      isLight
                        ? 'bg-white border-sky-300 text-slate-900'
                        : 'bg-slate-900 border-slate-600 text-white'
                    }`}
                    id="select-ledger-account"
                  >
                    <option value="__all__">
                      {isEn
                        ? '⭐ Master General Ledger (All Accounts Schedule)'
                        : '⭐ সাধারণ খতিয়ান মাস্টার শিডিউল (একত্রে সকল অ্যাকাউন্ট)'}
                    </option>
                    {filteredAccountsForLedger.map((acc) => {
                      const accName = isEn ? acc.nameEnglish : acc.nameBangla;
                      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
                      let typeBadge = '';
                      if (acc.type === 'cash') typeBadge = isEn ? 'CASH' : 'ক্যাশ';
                      else if (acc.type === 'bank') typeBadge = isEn ? 'BANK' : 'ব্যাংক';
                      else if (acc.type === 'mobile_banking') typeBadge = isEn ? 'MFS' : 'এমএফএস';
                      else if (acc.type === 'card') typeBadge = isEn ? 'CARD' : 'কার্ড';
                      else if (acc.type === 'receivable') typeBadge = isEn ? 'RECEIVABLE' : 'দেনাদার (পাওনা)';
                      else if (acc.type === 'payable') typeBadge = isEn ? 'PAYABLE' : 'পাওনাদার (দেনা)';
                      else typeBadge = acc.type.toUpperCase();

                      return (
                        <option key={acc.id} value={acc.id}>
                          [{typeBadge}] {accName} • ৳{bal.toLocaleString()}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>

              {/* If Single Ledger Account Selected */}
              {selectedAccount && singleLedgerData ? (
                <div className="space-y-3">
                  {/* Account Info Header */}
                  <div
                    className={`p-3 rounded-2xl border flex items-center justify-between ${
                      isLight ? 'bg-white border-sky-200' : 'bg-slate-800/90 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className="p-2 rounded-xl border"
                        style={{
                          backgroundColor: `${dualAccent.primary.hex}15`,
                          borderColor: `${dualAccent.primary.hex}30`,
                          color: dualAccent.primary.hex,
                        }}
                      >
                        {selectedAccount.type === 'receivable' ? (
                          <TrendingUp className="w-4 h-4" />
                        ) : selectedAccount.type === 'payable' ? (
                          <TrendingDown className="w-4 h-4" />
                        ) : selectedAccount.type === 'bank' ? (
                          <Landmark className="w-4 h-4" />
                        ) : (
                          <Wallet className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <h3 className="text-xs font-black">
                          {isEn ? selectedAccount.nameEnglish : selectedAccount.nameBangla}
                        </h3>
                        <p className="text-[10px] opacity-70">
                          {selectedAccount.institutionName
                            ? `${selectedAccount.institutionName} • `
                            : ''}
                          {selectedAccount.accountNumber || selectedAccount.phoneNumber || selectedAccount.type.toUpperCase()}
                        </p>
                      </div>
                    </div>

                    <span
                      className="text-[10px] font-extrabold px-2 py-0.5 rounded-full border"
                      style={{
                        backgroundColor: `${dualAccent.secondary.hex}15`,
                        borderColor: `${dualAccent.secondary.hex}30`,
                        color: dualAccent.secondary.hex,
                      }}
                    >
                      {singleLedgerData.count} {isEn ? 'entries' : 'টি ভুক্তি'}
                    </span>
                  </div>

                  {/* 4 KPI Metrics Card */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-center">
                    {/* Opening Balance */}
                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold opacity-70">
                        {isEn ? 'Opening' : 'প্রারম্ভিক'}
                      </div>
                      <div className="text-xs font-black mt-0.5">
                        {formatCurrency(singleLedgerData.openingBalance, useBangla)}
                      </div>
                    </div>

                    {/* Period Debits (+) */}
                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-emerald-200' : 'bg-slate-900 border-emerald-900/50'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-emerald-600 flex items-center justify-center gap-0.5">
                        <ArrowDownRight className="w-2.5 h-2.5" />
                        <span>{isEn ? 'Debit (+)' : 'ডেবিট (+)'}</span>
                      </div>
                      <div className="text-xs font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {formatCurrency(singleLedgerData.totalDebit, useBangla)}
                      </div>
                    </div>

                    {/* Period Credits (-) */}
                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-rose-200' : 'bg-slate-900 border-rose-900/50'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-rose-600 flex items-center justify-center gap-0.5">
                        <ArrowUpRight className="w-2.5 h-2.5" />
                        <span>{isEn ? 'Credit (-)' : 'ক্রেডিট (-)'}</span>
                      </div>
                      <div className="text-xs font-black text-rose-600 dark:text-rose-400 mt-0.5">
                        {formatCurrency(singleLedgerData.totalCredit, useBangla)}
                      </div>
                    </div>

                    {/* Closing Balance */}
                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-sky-50 border-sky-300' : 'bg-slate-900 border-indigo-700/60'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-indigo-600 dark:text-indigo-400">
                        {isEn ? 'Closing' : 'সমাপনী'}
                      </div>
                      <div className="text-xs font-black text-indigo-700 dark:text-indigo-300 mt-0.5">
                        {formatCurrency(singleLedgerData.closingBalance, useBangla)}
                      </div>
                    </div>
                  </div>

                  {/* Ledger Table Preview */}
                  <div
                    className={`p-3 rounded-2xl border space-y-2 ${
                      isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="opacity-80">
                        {isEn ? 'Chronological Running Ledger' : 'চলমান খতিয়ান প্রিভিউ'}
                      </span>
                      <span className="text-[10px] opacity-60">
                        {isEn ? 'Running Balance Method' : 'চলমান জের পদ্ধতি'}
                      </span>
                    </div>

                    <div className="max-h-44 overflow-y-auto rounded-xl border border-black/5 dark:border-white/5 divide-y divide-black/5 dark:divide-white/5 text-[11px]">
                      {/* Row 0: Opening Balance */}
                      <div className="p-2 flex items-center justify-between font-bold bg-black/5 dark:bg-white/5">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono">
                            B/F
                          </span>
                          <span>{isEn ? 'Opening Balance (B/F)' : 'প্রারম্ভিক স্থিতি (পূর্বানীত)'}</span>
                        </div>
                        <span>{formatCurrency(singleLedgerData.openingBalance, useBangla)}</span>
                      </div>

                      {singleLedgerData.entries.length === 0 ? (
                        <div className="p-4 text-center text-xs opacity-60">
                          {isEn
                            ? 'No transactions found for this account in the selected period.'
                            : 'এই সময়সীমায় এই অ্যাকাউন্টের কোনো লেনদেন পাওয়া যায়নি।'}
                        </div>
                      ) : (
                        singleLedgerData.entries.slice(0, 15).map((e) => (
                          <div
                            key={e.sl}
                            className="p-2 flex items-center justify-between gap-2 hover:bg-black/5 dark:hover:bg-white/5 transition"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] opacity-60 font-mono">{e.date}</span>
                                <span className="font-bold truncate">{e.particulars}</span>
                              </div>
                              {e.counterAccount && (
                                <p className="text-[10px] opacity-65 truncate mt-0.5">
                                  {e.counterAccount} {e.note ? `• ${e.note}` : ''}
                                </p>
                              )}
                            </div>
                            <div className="text-right shrink-0">
                              <div className="font-bold">
                                {e.debit > 0 ? (
                                  <span className="text-emerald-600 dark:text-emerald-400">
                                    +{formatCurrency(e.debit, useBangla)}
                                  </span>
                                ) : (
                                  <span className="text-rose-600 dark:text-rose-400">
                                    -{formatCurrency(e.credit, useBangla)}
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] opacity-60 font-mono">
                                {isEn ? 'Bal:' : 'জের:'} {formatCurrency(e.runningBalance, useBangla)}
                              </div>
                            </div>
                          </div>
                        ))
                      )}

                      {singleLedgerData.entries.length > 15 && (
                        <div className="p-1.5 text-center text-[10px] opacity-60 italic">
                          {isEn
                            ? `+ ${singleLedgerData.entries.length - 15} more entries in full export`
                            : `+ আরও ${singleLedgerData.entries.length - 15} টি ভুক্তি সম্পূর্ণ এক্সপোর্টে অন্তর্ভুক্ত থাকবে`}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                /* All Accounts Master General Ledger Preview */
                <div className="space-y-3">
                  {/* 4 Grand Totals KPI Card */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-center">
                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold opacity-70">
                        {isEn ? 'Grand Opening' : 'মোট প্রারম্ভিক'}
                      </div>
                      <div className="text-xs font-black mt-0.5">
                        {formatCurrency(allLedgersTotals.grandOpening, useBangla)}
                      </div>
                    </div>

                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-emerald-200' : 'bg-slate-900 border-emerald-900/50'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-emerald-600 flex items-center justify-center gap-0.5">
                        <ArrowDownRight className="w-2.5 h-2.5" />
                        <span>{isEn ? 'Grand Debit' : 'মোট ডেবিট (+)'}</span>
                      </div>
                      <div className="text-xs font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {formatCurrency(allLedgersTotals.grandDebit, useBangla)}
                      </div>
                    </div>

                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-white border-rose-200' : 'bg-slate-900 border-rose-900/50'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-rose-600 flex items-center justify-center gap-0.5">
                        <ArrowUpRight className="w-2.5 h-2.5" />
                        <span>{isEn ? 'Grand Credit' : 'মোট ক্রেডিট (-)'}</span>
                      </div>
                      <div className="text-xs font-black text-rose-600 dark:text-rose-400 mt-0.5">
                        {formatCurrency(allLedgersTotals.grandCredit, useBangla)}
                      </div>
                    </div>

                    <div
                      className={`p-2 rounded-xl border ${
                        isLight ? 'bg-sky-50 border-sky-300' : 'bg-slate-900 border-indigo-700/60'
                      }`}
                    >
                      <div className="text-[9px] uppercase font-bold text-indigo-600 dark:text-indigo-400">
                        {isEn ? 'Grand Closing' : 'মোট সমাপনী'}
                      </div>
                      <div className="text-xs font-black text-indigo-700 dark:text-indigo-300 mt-0.5">
                        {formatCurrency(allLedgersTotals.grandClosing, useBangla)}
                      </div>
                    </div>
                  </div>

                  {/* Schedule Table Preview */}
                  <div
                    className={`p-3 rounded-2xl border space-y-2 ${
                      isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="opacity-80">
                        {isEn ? 'Master General Ledger Schedule' : 'সাধারণ খতিয়ান মাস্টার শিডিউল'}
                      </span>
                      <span className="text-[10px] opacity-60">
                        {allAccounts.length} {isEn ? 'Accounts' : 'টি হিসাব'}
                      </span>
                    </div>

                    <div className="max-h-44 overflow-y-auto rounded-xl border border-black/5 dark:border-white/5 divide-y divide-black/5 dark:divide-white/5 text-[11px]">
                      {allLedgersSchedule.map((item) => {
                        const name = isEn ? item.account.nameEnglish : item.account.nameBangla;
                        return (
                          <div
                            key={item.account.id}
                            onClick={() => setSelectedLedgerId(item.account.id)}
                            className="p-2 flex items-center justify-between gap-2 hover:bg-black/5 dark:hover:bg-white/5 transition cursor-pointer"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold truncate">{name}</span>
                                <span className="text-[9px] px-1 py-0.2 rounded bg-black/5 dark:bg-white/10 uppercase">
                                  {item.account.type}
                                </span>
                              </div>
                              <p className="text-[10px] opacity-60">
                                {isEn ? 'Open:' : 'শুরু:'} {formatCurrency(item.openingBalance, useBangla)} •{' '}
                                {item.txCount} {isEn ? 'txs' : 'টি লেনদেন'}
                              </p>
                            </div>
                            <div className="text-right shrink-0">
                              <div className="font-bold text-indigo-600 dark:text-indigo-400">
                                {formatCurrency(item.closingBalance, useBangla)}
                              </div>
                              <div className="text-[10px] opacity-60">
                                {item.netMovement >= 0 ? '+' : ''}
                                {formatCurrency(item.netMovement, useBangla)}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* =========================================================================
               VIEW 3: TRANSACTION AUDIT LOG PREVIEW (Default Mode)
               ========================================================================= */
            <div className="space-y-3">
              {/* Transaction Scope Buttons */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-extrabold uppercase tracking-wider opacity-75 block">
                  {isEn ? '2. Transaction Scope' : '২. লেনদেনের ধরন'}
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10">
                  <button
                    type="button"
                    onClick={() => setFilterType('all')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold transition text-center ${
                      filterType === 'all'
                        ? isLight
                          ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                          : 'bg-slate-800 text-white shadow-xs border border-slate-700'
                        : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    {isEn ? 'All (Income & Expense)' : 'সব (আয় ও ব্যয়)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterType('expense')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold transition text-center ${
                      filterType === 'expense'
                        ? 'bg-rose-500 text-white shadow-xs'
                        : 'opacity-70 hover:opacity-100 text-rose-500'
                    }`}
                  >
                    {isEn ? 'Expense Only' : 'শুধু খরচ'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterType('income')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold transition text-center ${
                      filterType === 'income'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'opacity-70 hover:opacity-100 text-emerald-600'
                    }`}
                  >
                    {isEn ? 'Income Only' : 'শুধু আয়'}
                  </button>
                </div>
              </div>

              {/* Live Statement Metrics Preview */}
              <div
                className={`p-3.5 rounded-2xl border space-y-3 ${
                  isLight ? 'bg-indigo-50/40 border-indigo-100' : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-black">
                    <Layers className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{isEn ? 'Statement Summary' : 'প্রতিবেদনের সারসংক্ষেপ'}</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                    {stats.count} {isEn ? 'items' : 'টি লেনদেন'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-emerald-200' : 'bg-slate-900 border-emerald-900/50'
                    }`}
                  >
                    <div className="text-[9px] uppercase font-bold text-emerald-600 flex items-center justify-center gap-0.5">
                      <TrendingUp className="w-2.5 h-2.5" />
                      <span>{isEn ? 'Income' : 'মোট আয়'}</span>
                    </div>
                    <div className="text-xs font-black text-emerald-700 dark:text-emerald-400 mt-0.5">
                      {formatCurrency(stats.totalIncome, useBangla)}
                    </div>
                  </div>

                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-rose-200' : 'bg-slate-900 border-rose-900/50'
                    }`}
                  >
                    <div className="text-[9px] uppercase font-bold text-rose-600 flex items-center justify-center gap-0.5">
                      <TrendingDown className="w-2.5 h-2.5" />
                      <span>{isEn ? 'Expense' : 'মোট ব্যয়'}</span>
                    </div>
                    <div className="text-xs font-black text-rose-700 dark:text-rose-400 mt-0.5">
                      {formatCurrency(stats.totalExpense, useBangla)}
                    </div>
                  </div>

                  <div
                    className={`p-2 rounded-xl border ${
                      isLight ? 'bg-white border-sky-200' : 'bg-slate-900 border-slate-700'
                    }`}
                  >
                    <div className="text-[9px] uppercase font-bold text-indigo-600 flex items-center justify-center gap-0.5">
                      <Wallet className="w-2.5 h-2.5" />
                      <span>{isEn ? 'Net' : 'উদ্বৃত্ত'}</span>
                    </div>
                    <div
                      className={`text-xs font-black mt-0.5 ${
                        stats.netBalance >= 0
                          ? 'text-indigo-700 dark:text-indigo-300'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {formatCurrency(stats.netBalance, useBangla)}
                    </div>
                  </div>
                </div>

                {stats.topCategoryAmount > 0 && (
                  <div className="text-[10px] flex items-center justify-between opacity-80 pt-1 border-t border-black/5 dark:border-white/5">
                    <span>{isEn ? 'Top Expense Category:' : 'সর্বোচ্চ খরচের খাত:'}</span>
                    <span className="font-bold text-rose-600 dark:text-rose-400">
                      {stats.topCategoryName} ({formatCurrency(stats.topCategoryAmount, useBangla)})
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* =========================================================================
              ACTION BUTTONS (Extract & Download)
              ========================================================================= */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-extrabold uppercase tracking-wider opacity-75 block">
                {isEn ? '3. Extract & Download' : '৩. এক্সট্রাক্ট ও ডাউনলোড করুন'}
              </label>
              <span className="text-[10px] opacity-70 font-semibold">
                {reportMode === 'statement'
                  ? isEn
                    ? 'Financial Statement Format'
                    : 'আর্থিক বিবরণী ফরম্যাট'
                  : reportMode === 'ledger'
                  ? isEn
                    ? 'Ledger Account Format'
                    : 'খতিয়ান হিসাব ফরম্যাট'
                  : isEn
                  ? 'Audit Log Format'
                  : 'অডিট লগ ফরম্যাট'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* CSV / Excel Button */}
              <button
                type="button"
                onClick={
                  reportMode === 'ledger'
                    ? handleExportLedgerCSV
                    : reportMode === 'statement'
                    ? handleExportStatementCSV
                    : handleExportCSVTransactions
                }
                style={{ background: dualAccent.primaryGradient }}
                className="p-3 disabled:opacity-50 disabled:pointer-events-none text-white rounded-2xl text-left shadow-sm transition group cursor-pointer"
                id="btn-export-csv"
              >
                <div className="flex items-center justify-between">
                  <FileSpreadsheet className="w-4 h-4 text-white/90 group-hover:scale-110 transition" />
                  {downloadSuccess === 'csv' ? (
                    <Check className="w-3.5 h-3.5 text-white" />
                  ) : (
                    <ArrowRight className="w-3.5 h-3.5 opacity-70 group-hover:translate-x-0.5 transition" />
                  )}
                </div>
                <div className="mt-2">
                  <p className="text-xs font-black">
                    {downloadSuccess === 'csv'
                      ? isEn
                        ? 'Downloaded!'
                        : 'ডাউনলোড সম্পন্ন!'
                      : reportMode === 'statement'
                      ? isEn
                        ? 'Statement Excel (.csv)'
                        : 'স্টেটমেন্ট এক্সেল (.csv)'
                      : reportMode === 'ledger'
                      ? isEn
                        ? 'Ledger Excel (.csv)'
                        : 'খতিয়ান এক্সেল (.csv)'
                      : isEn
                      ? 'Excel / CSV File'
                      : 'এক্সেল / CSV ফাইল'}
                  </p>
                  <p className="text-[9px] text-white/85 opacity-90">
                    {reportMode === 'statement'
                      ? isEn
                        ? 'Multi-section Balance Sheet & P&L'
                        : 'সম্পদ, দেনা ও আয়ের ব্যালেন্স শিট'
                      : reportMode === 'ledger'
                      ? isEn
                        ? selectedAccount
                          ? 'Opening, debits, credits & balance'
                          : 'Master schedule of all accounts'
                        : selectedAccount
                        ? 'প্রারম্ভিক, জমা, খরচ ও চলমান জের'
                        : 'সকল অ্যাকাউন্টের পূর্ণাঙ্গ শিডিউল'
                      : isEn
                      ? 'Spreadsheet ready with Bangla'
                      : 'এক্সেলে ওপেন করার উপযোগী'}
                  </p>
                </div>
              </button>

              {/* TXT Report Button */}
              <button
                type="button"
                onClick={
                  reportMode === 'ledger'
                    ? handleExportLedgerText
                    : reportMode === 'statement'
                    ? handleExportStatementText
                    : handleExportTextTransactions
                }
                style={{ backgroundColor: dualAccent.secondary.hex }}
                className="p-3 disabled:opacity-50 disabled:pointer-events-none text-white rounded-2xl text-left shadow-sm transition group cursor-pointer"
                id="btn-export-txt"
              >
                <div className="flex items-center justify-between">
                  <FileText className="w-4 h-4 text-white/90 group-hover:scale-110 transition" />
                  {downloadSuccess === 'txt' ? (
                    <Check className="w-3.5 h-3.5 text-white" />
                  ) : (
                    <ArrowRight className="w-3.5 h-3.5 opacity-70 group-hover:translate-x-0.5 transition" />
                  )}
                </div>
                <div className="mt-2">
                  <p className="text-xs font-black">
                    {downloadSuccess === 'txt'
                      ? isEn
                        ? 'Downloaded!'
                        : 'ডাউনলোড সম্পন্ন!'
                      : reportMode === 'statement'
                      ? isEn
                        ? 'Statement Text (.txt)'
                        : 'স্টেটমেন্ট টেক্সট (.txt)'
                      : reportMode === 'ledger'
                      ? isEn
                        ? 'Ledger Book (.txt)'
                        : 'খতিয়ান বিবরণী (.txt)'
                      : isEn
                      ? 'Text Ledger (.txt)'
                      : 'টেক্সট খতিয়ান (.txt)'}
                  </p>
                  <p className="text-[9px] text-white/85 opacity-90">
                    {reportMode === 'statement'
                      ? isEn
                        ? 'Complete certified financial audit'
                        : 'সার্টিফাইড অডিট স্টেটমেন্ট নোট'
                      : reportMode === 'ledger'
                      ? isEn
                        ? 'Complete double-entry ledger statement'
                        : 'পূর্ণাঙ্গ খতিয়ান ও হিসাব বিবরণী'
                      : isEn
                      ? 'Detailed financial statement'
                      : 'সম্পূর্ণ বিবরণী ও হিসাব নোট'}
                  </p>
                </div>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              {/* Print / PDF Button */}
              <button
                type="button"
                onClick={
                  reportMode === 'ledger'
                    ? handlePrintLedger
                    : reportMode === 'statement'
                    ? handlePrintStatement
                    : handlePrintTransactions
                }
                style={{ borderColor: `${dualAccent.primary.hex}50`, color: dualAccent.primary.hex }}
                className={`p-2.5 rounded-2xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  isLight ? 'hover:bg-sky-50' : 'hover:bg-slate-800'
                } disabled:opacity-50 disabled:pointer-events-none`}
                id="btn-export-print"
              >
                <Printer className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                <span>
                  {reportMode === 'statement'
                    ? isEn
                      ? 'Print / PDF Statement'
                      : 'স্টেটমেন্ট প্রিন্ট / PDF'
                    : reportMode === 'ledger'
                    ? isEn
                      ? 'Print / PDF Ledger'
                      : 'খতিয়ান প্রিন্ট / PDF'
                    : isEn
                    ? 'Print / PDF'
                    : 'প্রিন্ট / PDF সেভ'}
                </span>
              </button>

              {/* Copy Summary Button */}
              <button
                type="button"
                onClick={handleCopySummary}
                style={{ borderColor: `${dualAccent.secondary.hex}50`, color: dualAccent.secondary.hex }}
                className={`p-2.5 rounded-2xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  isLight ? 'hover:bg-sky-50' : 'hover:bg-slate-800'
                } disabled:opacity-50 disabled:pointer-events-none`}
                id="btn-export-copy"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-emerald-600 font-bold">
                      {isEn ? 'Copied!' : 'কপি হয়েছে!'}
                    </span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" style={{ color: dualAccent.secondary.hex }} />
                    <span>
                      {reportMode === 'statement'
                        ? isEn
                          ? 'Copy Statement'
                          : 'স্টেটমেন্ট কপি'
                        : reportMode === 'ledger'
                        ? isEn
                          ? 'Copy Ledger'
                          : 'খতিয়ান কপি'
                        : isEn
                        ? 'Copy Summary'
                        : 'সারসংক্ষেপ কপি'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-black/10 dark:border-white/10 flex items-center justify-between shrink-0 bg-black/5 dark:bg-black/20">
          <span className="text-[10px] opacity-70">
            {reportMode === 'statement'
              ? isEn
                ? 'Certified Balance Sheet & P&L Statement'
                : 'ব্যালেন্স শিট ও আয়-ব্যয় স্থিতিপত্র অফলাইনে এক্সপোর্ট'
              : reportMode === 'ledger'
              ? isEn
                ? 'Individual & Master Ledger Statement'
                : 'অ্যাকাউন্ট ও পার্টি ভিত্তিক প্রারম্ভিক জের ও খতিয়ান বিবরণী'
              : isEn
              ? 'Ready for offline export'
              : 'সম্পূর্ণ অফলাইনে রিয়েল-টাইম এক্সপোর্ট'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
              isLight
                ? 'border-sky-300 text-sky-900 hover:bg-sky-50'
                : 'border-slate-700 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {isEn ? 'Close' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
