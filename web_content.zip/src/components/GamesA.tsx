import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Coins, Fish as FishIcon, Package, Play, RotateCcw, Sparkles, Star, Trophy, X } from "lucide-react";
import Cat from "./Cat";
import type { FurStyle } from "../data/catalog";
import { sfx } from "../lib/sound";

export interface GameProps {
  fur: FurStyle;
  eyeColor: string;
  catName: string;
  record: number;
  onFinish: (score: number, coins: number) => void;
  onClose: () => void;
}

export function GameShell({ title, subtitle, onClose, children, bg }: { title: string; subtitle: string; onClose: () => void; children: React.ReactNode; bg: string }) {
  return (
    <div className={`absolute inset-0 z-50 flex flex-col ${bg}`}>
      <div className="flex items-center justify-between border-b border-white/15 bg-black/35 px-4 py-3">
        <div>
          <h2 className="font-display text-lg font-semibold leading-none text-[#ffe9a8]">{title}</h2>
          <p className="mt-1 text-[11px] font-bold text-white/55">{subtitle}</p>
        </div>
        <button onClick={onClose} aria-label="Salir del juego" className="rounded-full bg-white/10 p-2 text-white active:scale-90"><X className="h-5 w-5" /></button>
      </div>
      {children}
    </div>
  );
}

export function IntroScreen({ text, record, recordLabel, onStart }: { text: string; record: number; recordLabel: string; onStart: () => void }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
      <p className="max-w-[300px] text-[15px] font-semibold leading-relaxed text-white/85">{text}</p>
      {record > 0 && (
        <p className="flex items-center gap-1.5 rounded-full bg-black/40 px-3 py-1.5 text-sm font-extrabold text-amber-300">
          <Trophy className="h-4 w-4" /> {recordLabel}: {record}
        </p>
      )}
      <button onClick={onStart} className="flex min-h-[56px] items-center gap-2 rounded-2xl bg-[#f5c451] px-8 font-display text-lg font-bold text-[#241a02] active:scale-95">
        <Play className="h-5 w-5" /> ¡A jugar!
      </button>
    </div>
  );
}

export function EndScreen({ score, scoreLabel, coins, record, isNewRecord, onReplay, onExit }: {
  score: number; scoreLabel: string; coins: number; record: number; isNewRecord: boolean;
  onReplay: () => void; onExit: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center">
      <Sparkles className="h-10 w-10 text-[#f5c451]" />
      <p className="font-display text-2xl font-bold text-white">¡Partida terminada!</p>
      <p className="text-base font-bold text-white/75">{scoreLabel}: <span className="text-[#ffe9a8]">{score}</span></p>
      <p className="flex items-center gap-1.5 rounded-full bg-black/40 px-3 py-1.5 text-sm font-extrabold text-amber-300">
        <Coins className="h-4 w-4" /> Ganaste {coins} moneditas
      </p>
      <p className="text-sm font-bold text-white/55">Récord: {record}{isNewRecord ? " · ¡Nuevo récord!" : ""}</p>
      <div className="mt-2 flex gap-2">
        <button onClick={onReplay} className="flex min-h-[52px] items-center gap-2 rounded-2xl bg-[#f5c451] px-5 font-display text-base font-bold text-[#241a02] active:scale-95">
          <RotateCcw className="h-5 w-5" /> Otra vez
        </button>
        <button onClick={onExit} className="min-h-[52px] rounded-2xl border border-white/20 bg-white/8 px-5 font-display text-base font-semibold text-white active:scale-95">
          Salir
        </button>
      </div>
    </div>
  );
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);

/* ================================================================
   A. CARRERA DE GATITOS — salta cajas, deslízate bajo ramas
   ================================================================ */
interface Ob { x: number; type: "box" | "branch" | "coin" | "star"; high?: boolean; id: number }

export function RunnerGame({ fur, eyeColor, catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [, setTick] = useState(0);
  const g = useRef({ y: 0, vy: 0, jumping: false, slideUntil: 0, dist: 0, coins: 0, stars: 0, over: false, obs: [] as Ob[], last: 0, spawnAt: 0 });
  const finished = useRef(false);

  const start = () => {
    g.current = { y: 0, vy: 0, jumping: false, slideUntil: 0, dist: 0, coins: 0, stars: 0, over: false, obs: [], last: 0, spawnAt: 0 };
    finished.current = false;
    setPhase("play");
    sfx.boing();
  };

  useEffect(() => {
    if (phase !== "play") return;
    let raf = 0;
    const loop = (t: number) => {
      const s = g.current;
      if (!s.last) s.last = t;
      const dt = Math.min(40, t - s.last);
      s.last = t;
      if (!s.over) {
        const speed = (0.045 + s.dist / 22000) * dt;
        s.dist += speed * 2.2;
        // jump physics
        if (s.jumping) {
          s.y += s.vy * (dt / 16.7);
          s.vy -= 2.4 * (dt / 16.7);
          if (s.y <= 0) { s.y = 0; s.jumping = false; }
        }
        // spawn
        if (t > s.spawnAt) {
          s.spawnAt = t + rand(750, 1350);
          const r = Math.random();
          if (r < 0.42) s.obs.push({ x: 108, type: "box", id: t });
          else if (r < 0.72) s.obs.push({ x: 108, type: "branch", id: t });
          else if (r < 0.92) s.obs.push({ x: 108, type: "coin", high: Math.random() < 0.5, id: t });
          else s.obs.push({ x: 108, type: "star", high: true, id: t });
        }
        const sliding = t < s.slideUntil;
        s.obs.forEach((o) => { o.x -= speed; });
        s.obs = s.obs.filter((o) => o.x > -12);
        for (const o of s.obs) {
          if (Math.abs(o.x - 16) < 8.5) {
            if (o.type === "box" && s.y < 44) { s.over = true; }
            if (o.type === "branch" && !sliding) { s.over = true; }
            if (o.type === "coin" && (o.high ? s.y > 34 : s.y <= 34)) { s.coins++; o.x = -99; sfx.coin(); }
            if (o.type === "star" && s.y > 34) { s.stars++; o.x = -99; sfx.sparkle(); }
          }
        }
        if (s.over) {
          sfx.error();
          setTimeout(() => setPhase("end"), 450);
        }
      }
      setTick((v) => v + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  const jump = () => {
    const s = g.current;
    if (phase === "play" && !s.jumping && !s.over) { s.jumping = true; s.vy = 15.5; sfx.pop(); }
  };
  const slide = () => {
    const s = g.current;
    if (phase === "play" && !s.over) { s.slideUntil = performance.now() + 520; if (s.jumping) { s.y = 0; s.jumping = false; } sfx.pop(); }
  };

  const s = g.current;
  const meters = Math.floor(s.dist);
  const coinsEarned = s.coins + s.stars * 3 + Math.floor(meters / 30);
  useEffect(() => {
    if (phase === "end" && !finished.current) { finished.current = true; onFinish(meters, coinsEarned); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const sliding = performance.now() < s.slideUntil;

  return (
    <GameShell title="Carrera de Gatitos" subtitle={`${catName} corre por el bosque encantado`} onClose={onClose} bg="bg-gradient-to-b from-[#1d2f1a] to-[#0f1a10]">
      {phase === "intro" && <IntroScreen text="Corre sin chocar: SALTA las cajas y DESLÍZATE bajo las ramas. Atrapa monedas y estrellas en el aire. ¡Cada vez corres más rápido!" record={record} recordLabel="Récord de distancia (m)" onStart={start} />}
      {phase === "end" && <EndScreen score={meters} scoreLabel="Distancia (m)" coins={coinsEarned} record={Math.max(record, meters)} isNewRecord={meters > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div className="relative flex-1 select-none overflow-hidden" onPointerDown={jump}>
          <div className="absolute right-3 top-3 flex gap-2">
            <span className="rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-white">{meters} m</span>
            <span className="flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-amber-300"><Coins className="h-3.5 w-3.5" /> {s.coins}</span>
            <span className="flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-[#f5c451]"><Star className="h-3.5 w-3.5" /> {s.stars}</span>
          </div>
          {/* trees */}
          {[8, 38, 68, 92].map((x, i) => (
            <div key={i} className="absolute bottom-[26%]" style={{ left: `${(x - (s.dist * 0.4) % 30 + 30) % 110}%` }}>
              <div className="mx-auto h-10 w-2 bg-[#4a3220]" /><div className="-mt-12 h-12 w-10 rounded-full bg-emerald-800/80" />
            </div>
          ))}
          <div className="absolute inset-x-0 bottom-[22%] h-1.5 bg-[#4a3220]" />
          <div className="absolute inset-x-0 bottom-0 h-[22%] bg-[#241407]" />
          {/* cat */}
          <div className="absolute bottom-[23%] w-[74px] transition-none" style={{ left: "10%", transform: `translateY(${-s.y}px) scaleY(${sliding ? 0.72 : 1})` }}>
            <Cat mood={s.over ? "normal" : "happy"} fur={fur} eyeColor={eyeColor} excited />
          </div>
          {s.obs.map((o) => (
            <div key={o.id} className="absolute" style={{ left: `${o.x}%`, bottom: o.type === "branch" ? "calc(23% + 34px)" : o.high ? "calc(23% + 58px)" : "23%" }}>
              {o.type === "box" && <span className="flex h-11 w-11 items-center justify-center rounded-lg border-2 border-[#8a6a3b] bg-[#6b4a2f]"><Package className="h-6 w-6 text-[#caa25a]" /></span>}
              {o.type === "branch" && <span className="block h-3.5 w-16 rounded-full bg-[#5b3a1e]"><span className="ml-8 block h-4 w-4 -translate-y-2 rounded-full bg-emerald-600" /></span>}
              {o.type === "coin" && <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-amber-500 bg-amber-300"><Coins className="h-4.5 w-4.5 text-amber-700" /></span>}
              {o.type === "star" && <Star className="h-8 w-8 text-[#f5c451]" fill="currentColor" />}
            </div>
          ))}
          {s.over && <p className="absolute left-1/2 top-16 -translate-x-1/2 rounded-full bg-black/70 px-4 py-2 font-display text-lg font-bold text-rose-300">¡Auch! Tropezaste</p>}
          <div className="absolute inset-x-0 bottom-3 flex justify-center gap-3 px-4">
            <button onPointerDown={(e) => { e.stopPropagation(); slide(); }} className="flex min-h-[60px] flex-1 items-center justify-center gap-2 rounded-2xl border border-white/25 bg-black/55 font-display text-base font-bold text-white active:scale-95">
              <ArrowDown className="h-6 w-6" /> Deslizar
            </button>
            <button onPointerDown={(e) => { e.stopPropagation(); jump(); }} className="flex min-h-[60px] flex-1 items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] active:scale-95">
              <ArrowUp className="h-6 w-6" /> Saltar
            </button>
          </div>
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   B. PESCA GATUNA — baja el anzuelo y atrapa peces
   ================================================================ */
interface FishT { x: number; y: number; dir: 1 | -1; speed: number; pts: number; color: string; size: number; id: number; golden?: boolean }

const FISH_KINDS = [
  { pts: 5, color: "#7dd3fc", size: 30 },
  { pts: 8, color: "#f9a8d4", size: 26 },
  { pts: 12, color: "#6ee7b7", size: 34 },
  { pts: 20, color: "#c4b5fd", size: 24 },
];

export function FishingGame({ fur, eyeColor, catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [scene, setScene] = useState<"estanque" | "rio">("estanque");
  const [, setTick] = useState(0);
  const g = useRef({ hookX: 50, hookY: 0, mode: "idle" as "idle" | "down" | "up", caught: null as FishT | null, score: 0, timeLeft: 60, fishes: [] as FishT[], startedAt: 0 });
  const finished = useRef(false);

  const start = () => {
    const speedMul = scene === "rio" ? 1.7 : 1;
    g.current = {
      hookX: 50, hookY: 0, mode: "idle", caught: null, score: 0, timeLeft: 60, startedAt: performance.now(),
      fishes: Array.from({ length: 7 }, (_, i) => {
        const k = FISH_KINDS[i % FISH_KINDS.length];
        return { x: rand(6, 90), y: rand(34, 86), dir: (Math.random() < 0.5 ? 1 : -1) as 1 | -1, speed: rand(0.02, 0.05) * speedMul, pts: k.pts, color: k.color, size: k.size, id: i, golden: scene === "rio" && i % 3 === 0 };
      }),
    };
    finished.current = false;
    setPhase("play");
    sfx.pop();
  };

  useEffect(() => {
    if (phase !== "play") return;
    let raf = 0;
    const loop = (t: number) => {
      const s = g.current;
      s.timeLeft = Math.max(0, 60 - (t - s.startedAt) / 1000);
      s.fishes.forEach((f) => {
        if (s.caught?.id === f.id) { f.x = s.hookX; f.y = s.hookY + 6; return; }
        f.x += f.dir * f.speed * 1.6;
        if (f.x > 94) f.dir = -1;
        if (f.x < 4) f.dir = 1;
      });
      if (s.mode === "down") {
        s.hookY += 1.5;
        if (s.hookY >= 88) s.mode = "up";
        if (!s.caught) {
          const hit = s.fishes.find((f) => Math.abs(f.x - s.hookX) < 7 && Math.abs(f.y - s.hookY) < 8);
          if (hit) { s.caught = hit; s.mode = "up"; sfx.pop(); }
        }
      } else if (s.mode === "up") {
        s.hookY -= 1.9;
        if (!s.caught) {
          const hit = s.fishes.find((f) => Math.abs(f.x - s.hookX) < 7 && Math.abs(f.y - s.hookY) < 8);
          if (hit) { s.caught = hit; sfx.pop(); }
        }
        if (s.hookY <= 0) {
          s.hookY = 0; s.mode = "idle";
          if (s.caught) {
            s.score += s.caught.golden ? 40 : s.caught.pts;
            sfx.coin();
            const k = FISH_KINDS[Math.floor(Math.random() * FISH_KINDS.length)];
            Object.assign(s.caught, { x: rand(6, 90), y: rand(34, 86), pts: k.pts, color: k.color, size: k.size, golden: scene === "rio" && Math.random() < 0.3 });
            s.caught = null;
          }
        }
      }
      if (s.timeLeft <= 0) { setPhase("end"); }
      setTick((v) => v + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase, scene]);

  const s = g.current;
  const coinsEarned = Math.floor(s.score / 4);
  useEffect(() => {
    if (phase === "end" && !finished.current) { finished.current = true; onFinish(s.score, coinsEarned); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const cast = () => {
    if (s.mode === "idle") { s.mode = "down"; sfx.boing(); }
    else if (s.mode === "down") s.mode = "up";
  };

  return (
    <GameShell title="Pesca Gatuna" subtitle={`${catName} pesca en el ${scene === "rio" ? "río mágico" : "estanque tranquilo"}`} onClose={onClose} bg="bg-gradient-to-b from-[#0b2e3f] to-[#071a29]">
      {phase === "intro" && (
        <div className="flex flex-1 flex-col">
          <div className="grid grid-cols-2 gap-2 p-4 pb-0">
            {(["estanque", "rio"] as const).map((sc) => (
              <button key={sc} onClick={() => setScene(sc)} className={`min-h-[52px] rounded-2xl font-display text-sm font-semibold ${scene === sc ? "bg-[#f5c451] text-[#241a02]" : "border border-white/15 bg-white/8 text-white/75"}`}>
                {sc === "estanque" ? "Estanque Tranquilo" : "Río Mágico (rápido)"}
              </button>
            ))}
          </div>
          <IntroScreen text="Mueve la caña con tu dedo o las flechas, toca LANZAR para bajar el anzuelo y atrapa peces. ¡Los dorados del río valen 40 puntos! Tienes 60 segundos." record={record} recordLabel="Récord de puntos" onStart={start} />
        </div>
      )}
      {phase === "end" && <EndScreen score={s.score} scoreLabel="Puntos de pesca" coins={coinsEarned} record={Math.max(record, s.score)} isNewRecord={s.score > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div
          className="relative flex-1 touch-none overflow-hidden"
          onPointerMove={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            s.hookX = Math.max(5, Math.min(95, ((e.clientX - r.left) / r.width) * 100));
          }}
        >
          <div className="absolute inset-x-0 top-0 h-[26%] bg-gradient-to-b from-[#f9a8d4]/25 to-transparent" />
          <div className="absolute left-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-white">{Math.ceil(s.timeLeft)}s</div>
          <div className="absolute right-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-amber-300">{s.score} pts</div>
          {/* rod + line */}
          <div className="absolute top-[6%] h-1 w-[46%] origin-left rounded bg-[#8a6a3b]" style={{ left: `${s.hookX - 22}%`, transform: "rotate(-14deg)" }} />
          <div className="absolute top-[8%] w-px bg-white/70" style={{ left: `${s.hookX}%`, height: `${s.hookY + 12}%` }} />
          <div className="absolute h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-slate-300 bg-slate-500" style={{ left: `${s.hookX}%`, top: `${20 + s.hookY * 0.78}%` }} />
          <div className="absolute top-[4%] w-[64px]" style={{ left: `calc(${s.hookX}% - 58px)` }}>
            <Cat mood="happy" fur={fur} eyeColor={eyeColor} />
          </div>
          {/* water */}
          <div className="absolute inset-x-0 bottom-0 top-[30%] bg-gradient-to-b from-sky-500/25 to-sky-900/50" />
          {s.fishes.map((f) => (
            <span key={f.id} className="absolute -translate-x-1/2" style={{ left: `${f.x}%`, top: `${f.y}%`, transform: `translateX(-50%) scaleX(${f.dir})` }}>
              <FishIcon style={{ width: f.size, height: f.size, color: f.golden ? "#f5c451" : f.color }} fill="currentColor" />
            </span>
          ))}
          <div className="absolute inset-x-0 bottom-3 flex items-center justify-center gap-3 px-4">
            <button onPointerDown={() => { s.hookX = Math.max(5, s.hookX - 7); }} className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/25 bg-black/55 text-white active:scale-95"><ArrowLeft className="h-6 w-6" /></button>
            <button onPointerDown={cast} className="min-h-[56px] flex-1 rounded-2xl bg-[#f5c451] font-display text-lg font-bold text-[#241a02] active:scale-95">
              {s.mode === "idle" ? "¡LANZAR!" : "RECOGER"}
            </button>
            <button onPointerDown={() => { s.hookX = Math.min(95, s.hookX + 7); }} className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/25 bg-black/55 text-white active:scale-95"><ArrowRight className="h-6 w-6" /></button>
          </div>
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   C. CAZADOR DE MARIPOSAS MÁGICAS
   ================================================================ */
interface BFly { x: number; y: number; vx: number; vy: number; golden: boolean; id: number; hue: string }

const DIFFS = [
  { label: "Fácil", count: 6, speed: 0.55, time: 40 },
  { label: "Normal", count: 8, speed: 0.9, time: 30 },
  { label: "Difícil", count: 11, speed: 1.35, time: 25 },
];

export function ButterfliesGame({ catName, record, onFinish, onClose, fur, eyeColor }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [diff, setDiff] = useState(1);
  const [, setTick] = useState(0);
  const [bursts, setBursts] = useState<{ id: number; x: number; y: number }[]>([]);
  const g = useRef({ flies: [] as BFly[], score: 0, timeLeft: 30, startedAt: 0 });
  const finished = useRef(false);

  const start = () => {
    const d = DIFFS[diff];
    g.current = {
      score: 0, timeLeft: d.time, startedAt: performance.now(),
      flies: Array.from({ length: d.count }, (_, i) => ({
        x: rand(10, 88), y: rand(12, 78),
        vx: rand(0.1, 0.24) * d.speed * (Math.random() < 0.5 ? -1 : 1),
        vy: rand(0.08, 0.2) * d.speed * (Math.random() < 0.5 ? -1 : 1),
        golden: i === 0, id: i, hue: ["#f9a8d4", "#c4b5fd", "#6ee7b7", "#7dd3fc"][i % 4],
      })),
    };
    finished.current = false;
    setPhase("play");
    sfx.sparkle();
  };

  useEffect(() => {
    if (phase !== "play") return;
    let raf = 0;
    const loop = (t: number) => {
      const s = g.current;
      s.timeLeft = Math.max(0, DIFFS[diff].time - (t - s.startedAt) / 1000);
      s.flies.forEach((f) => {
        f.x += f.vx; f.y += f.vy;
        if (f.x < 5 || f.x > 93) f.vx *= -1;
        if (f.y < 8 || f.y > 84) f.vy *= -1;
      });
      if (s.timeLeft <= 0) setPhase("end");
      setTick((v) => v + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase, diff]);

  const s = g.current;
  useEffect(() => {
    if (phase === "end" && !finished.current) { finished.current = true; onFinish(s.score, Math.floor(s.score / 2)); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const catchFly = (f: BFly) => {
    s.score += f.golden ? 3 : 1;
    if (f.golden) sfx.coin(); else sfx.pop();
    const b = { id: Date.now() + f.id, x: f.x, y: f.y };
    setBursts((prev) => [...prev.slice(-8), b]);
    setTimeout(() => setBursts((prev) => prev.filter((p) => p.id !== b.id)), 600);
    f.x = rand(8, 90); f.y = rand(10, 80);
  };

  return (
    <GameShell title="Cazador de Mariposas" subtitle={`${catName} salta tras las mariposas mágicas`} onClose={onClose} bg="bg-gradient-to-b from-[#2c1e4a] to-[#160f2c]">
      {phase === "intro" && (
        <div className="flex flex-1 flex-col">
          <div className="grid grid-cols-3 gap-2 p-4 pb-0">
            {DIFFS.map((d, i) => (
              <button key={d.label} onClick={() => setDiff(i)} className={`min-h-[48px] rounded-2xl font-display text-sm font-semibold ${diff === i ? "bg-[#f5c451] text-[#241a02]" : "border border-white/15 bg-white/8 text-white/75"}`}>
                {d.label}
              </button>
            ))}
          </div>
          <IntroScreen text="Toca las mariposas para atraparlas antes de que acabe el tiempo. La mariposa DORADA vale 3 puntos. ¡Sé rapidísimo como un gatito cazador!" record={record} recordLabel="Récord de mariposas" onStart={start} />
        </div>
      )}
      {phase === "end" && <EndScreen score={s.score} scoreLabel="Puntos de caza" coins={Math.floor(s.score / 2)} record={Math.max(record, s.score)} isNewRecord={s.score > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div className="relative flex-1 touch-none overflow-hidden">
          <div className="absolute left-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-white">{Math.ceil(s.timeLeft)}s</div>
          <div className="absolute right-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-pink-300">{s.score} pts</div>
          <div className="pointer-events-none absolute bottom-[6%] left-1/2 w-[86px] -translate-x-1/2">
            <Cat mood="happy" fur={fur} eyeColor={eyeColor} excited />
          </div>
          {s.flies.map((f) => (
            <button
              key={f.id}
              onPointerDown={() => catchFly(f)}
              aria-label="Atrapar mariposa"
              className="absolute flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center"
              style={{ left: `${f.x}%`, top: `${f.y}%` }}
            >
              <svg viewBox="0 0 40 40" className="h-9 w-9" style={{ transform: `scaleX(${f.vx > 0 ? 1 : -1})` }}>
                <ellipse cx="12" cy="14" rx="8" ry="11" fill={f.golden ? "#f5c451" : f.hue} opacity="0.95" transform="rotate(-24 12 14)" />
                <ellipse cx="28" cy="14" rx="8" ry="11" fill={f.golden ? "#fde68a" : f.hue} opacity="0.8" transform="rotate(24 28 14)" />
                <ellipse cx="20" cy="22" rx="3" ry="8" fill="#2b2135" />
              </svg>
            </button>
          ))}
          {bursts.map((b) => (
            <Sparkles key={b.id} className="sparkle-spin pointer-events-none absolute h-8 w-8 text-[#f5c451]" style={{ left: `${b.x}%`, top: `${b.y}%` }} />
          ))}
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   F. SALTO DE PLATAFORMAS
   ================================================================ */
interface Plat { x: number; y: number; moving: boolean; phase: number; id: number; star?: boolean }

export function PlatformsGame({ fur, eyeColor, catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [, setTick] = useState(0);
  const g = useRef({ x: 50, y: 70, vy: 0, cam: 0, height: 0, stars: 0, plats: [] as Plat[], targetX: 50, over: false });
  const finished = useRef(false);

  const start = () => {
    const plats: Plat[] = [{ x: 50, y: 78, moving: false, phase: 0, id: 0 }];
    for (let i = 1; i < 14; i++) plats.push({ x: rand(14, 86), y: 78 - i * 16, moving: i > 5 && i % 3 === 0, phase: rand(0, 6), id: i, star: i % 4 === 0 });
    g.current = { x: 50, y: 74, vy: -2, cam: 0, height: 0, stars: 0, plats, targetX: 50, over: false };
    finished.current = false;
    setPhase("play");
    sfx.boing();
  };

  useEffect(() => {
    if (phase !== "play") return;
    let raf = 0;
    const loop = (t: number) => {
      const s = g.current;
      if (!s.over) {
        s.x += (s.targetX - s.x) * 0.22;
        s.vy += 0.32;
        s.y += s.vy * 0.55;
        s.plats.forEach((p) => { if (p.moving) p.x = 50 + Math.sin(t / 700 + p.phase) * 30; });
        if (s.vy > 0) {
          for (const p of s.plats) {
            if (Math.abs(s.x - p.x) < 15 && Math.abs(s.y - (p.y - s.cam)) < 4.5 && s.y < p.y - s.cam + 4) {
              s.vy = -11.5;
              sfx.pop();
              if (p.star) { p.star = false; s.stars++; sfx.sparkle(); }
              break;
            }
          }
        }
        if (s.y < 34) { const shift = 34 - s.y; s.cam -= shift; s.y = 34; s.height += shift; }
        s.plats.forEach((p) => { if (p.y - s.cam > 108) { p.y = Math.min(...s.plats.map((q) => q.y)) - rand(13, 18); p.x = rand(14, 86); p.star = Math.random() < 0.3; } });
        if (s.y > 106) { s.over = true; sfx.error(); setTimeout(() => setPhase("end"), 350); }
      }
      setTick((v) => v + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  const s = g.current;
  const heightM = Math.floor(s.height);
  useEffect(() => {
    if (phase === "end" && !finished.current) { finished.current = true; onFinish(heightM, Math.floor(heightM / 12) + s.stars * 2); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  return (
    <GameShell title="Salto de Plataformas" subtitle={`${catName} salta entre nubecitas mágicas`} onClose={onClose} bg="bg-gradient-to-b from-[#31235c] to-[#150f2e]">
      {phase === "intro" && <IntroScreen text="Tu gatito rebota solo: mueve tu dedo (o mantén las flechas) para guiarlo de plataforma en plataforma. Algunas se mueven. ¡Sube lo más alto que puedas y atrapa estrellas!" record={record} recordLabel="Récord de altura" onStart={start} />}
      {phase === "end" && <EndScreen score={heightM} scoreLabel="Altura alcanzada" coins={Math.floor(heightM / 12) + s.stars * 2} record={Math.max(record, heightM)} isNewRecord={heightM > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div
          className="relative flex-1 touch-none overflow-hidden"
          onPointerMove={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            s.targetX = Math.max(8, Math.min(92, ((e.clientX - r.left) / r.width) * 100));
          }}
        >
          <div className="absolute left-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-white">{heightM} m</div>
          <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-[#f5c451]"><Star className="h-3.5 w-3.5" /> {s.stars}</div>
          {s.plats.map((p) => (
            <div key={p.id} className="absolute w-[19%]" style={{ left: `${p.x - 9.5}%`, top: `${p.y - s.cam}%` }}>
              <div className={`h-3.5 rounded-full border ${p.moving ? "border-violet-300 bg-violet-400/80" : "border-white/50 bg-pink-200/90"}`} />
              {p.star && <Star className="absolute -top-6 left-1/2 h-5 w-5 -translate-x-1/2 text-[#f5c451]" fill="currentColor" />}
            </div>
          ))}
          <div className="absolute w-[62px]" style={{ left: `calc(${s.x}% - 31px)`, top: `calc(${s.y}% - 56px)` }}>
            <Cat mood="happy" fur={fur} eyeColor={eyeColor} excited />
          </div>
          <div className="absolute inset-x-0 bottom-3 flex justify-between px-4">
            <button onPointerDown={() => { s.targetX = Math.max(8, s.targetX - 22); }} className="flex h-14 w-16 items-center justify-center rounded-2xl border border-white/25 bg-black/55 text-white active:scale-95"><ArrowLeft className="h-6 w-6" /></button>
            <button onPointerDown={() => { s.targetX = Math.min(92, s.targetX + 22); }} className="flex h-14 w-16 items-center justify-center rounded-2xl border border-white/25 bg-black/55 text-white active:scale-95"><ArrowRight className="h-6 w-6" /></button>
          </div>
        </div>
      )}
    </GameShell>
  );
}

/* ================================================================
   E. ESCONDITE — encuentra al gatito en la habitación
   ================================================================ */
const SPOTS = [
  { label: "Caja de cartón", bg: "#6b4a2f" },
  { label: "Tras la cortina", bg: "#f472b6" },
  { label: "Bajo la camita", bg: "#c4b5fd" },
  { label: "En la plantita", bg: "#34d399" },
  { label: "En el armario", bg: "#8a6a3b" },
  { label: "Bajo la alfombra", bg: "#f9a8d4" },
];

export function HideSeekGame({ fur, eyeColor, catName, record, onFinish, onClose }: GameProps) {
  const [phase, setPhase] = useState<"intro" | "play" | "end">("intro");
  const [round, setRound] = useState(1);
  const [hiddenAt, setHiddenAt] = useState(0);
  const [hint, setHint] = useState("¿Dónde se escondió? Toca un escondite...");
  const [attempts, setAttempts] = useState(0);
  const [foundAt, setFoundAt] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const finished = useRef(false);

  const newRound = (r: number, currentScore: number) => {
    setRound(r);
    setAttempts(0);
    setFoundAt(null);
    setScore(currentScore);
    setHiddenAt((prev) => {
      let n = Math.floor(Math.random() * SPOTS.length);
      if (n === prev) n = (n + 2) % SPOTS.length;
      return n;
    });
    setHint(r === 1 ? `¡${catName} se escondió! Toca un escondite...` : "¡Se escondió otra vez! Encuéntralo...");
  };

  const start = () => { finished.current = false; newRound(1, 0); setPhase("play"); sfx.pop(); };

  useEffect(() => {
    if (phase === "end" && !finished.current) { finished.current = true; onFinish(score, Math.floor(score / 3)); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const tapSpot = (i: number) => {
    if (foundAt !== null) return;
    if (i === hiddenAt) {
      const gained = Math.max(4, 14 - attempts * 3);
      const total = score + gained;
      setFoundAt(i);
      setScore(total);
      sfx.sparkle();
      setHint(`¡Ahí estaba! +${gained} puntos`);
      setTimeout(() => {
        if (round >= 3) setPhase("end");
        else newRound(round + 1, total);
      }, 1400);
    } else {
      const a = attempts + 1;
      setAttempts(a);
      const d = Math.abs(i - hiddenAt);
      const freq = d === 1 ? 880 : d === 2 ? 620 : 380;
      try {
        const ac = new AudioContext();
        const o = ac.createOscillator(); const gn = ac.createGain();
        o.frequency.value = freq; o.type = "sine";
        gn.gain.setValueAtTime(0.05, ac.currentTime);
        gn.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.25);
        o.connect(gn).connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.3);
        setTimeout(() => ac.close(), 400);
      } catch { /* sin audio */ }
      if (a >= 3) {
        setHint("El gatito cambió de escondite... ¡inténtalo de nuevo!");
        setAttempts(0);
        setHiddenAt((prev) => (prev + 1 + Math.floor(Math.random() * (SPOTS.length - 1))) % SPOTS.length);
      } else {
        setHint(d === 1 ? "¡Muy caliente! Casi, casi... escucha el miau agudo" : d === 2 ? "Tibio... el miau suena cerquita" : "Frío, frío... el miau se oye lejísimos");
      }
    }
  };

  return (
    <GameShell title="Escondite" subtitle={`Busca a ${catName} por la habitación mágica`} onClose={onClose} bg="bg-gradient-to-b from-[#33241a] to-[#1a120c]">
      {phase === "intro" && <IntroScreen text="El gatito se esconde en uno de 6 lugares. Toca los escondites para buscarlo: las pistas dicen frío, tibio o caliente, y el miau suena más agudo cuando estás cerca. Son 3 rondas." record={record} recordLabel="Récord de puntos" onStart={start} />}
      {phase === "end" && <EndScreen score={score} scoreLabel="Puntos de detective" coins={Math.floor(score / 3)} record={Math.max(record, score)} isNewRecord={score > record} onReplay={start} onExit={onClose} />}
      {phase === "play" && (
        <div className="flex flex-1 flex-col p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-extrabold text-white">Ronda {round} / 3</span>
            <span className="rounded-full bg-black/50 px-3 py-1 text-xs font-extrabold text-amber-300">{score} pts</span>
          </div>
          <p className="mb-4 rounded-2xl bg-black/45 px-4 py-3 text-center font-display text-[15px] font-semibold text-[#ffe9a8]">{hint}</p>
          <div className="grid flex-1 grid-cols-2 gap-3">
            {SPOTS.map((spot, i) => (
              <button
                key={spot.label}
                onClick={() => tapSpot(i)}
                className="relative flex flex-col items-center justify-center gap-2 overflow-hidden rounded-3xl border-2 border-white/15 active:scale-95"
                style={{ backgroundColor: `${spot.bg}33` }}
              >
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl" style={{ backgroundColor: spot.bg }}>
                  <Package className="h-7 w-7 text-black/50" />
                </span>
                <span className="px-2 text-center font-display text-sm font-semibold text-white">{spot.label}</span>
                {foundAt === i && (
                  <span className="absolute inset-x-4 bottom-2 flex justify-center">
                    <span className="block w-20"><Cat mood="happy" fur={fur} eyeColor={eyeColor} /></span>
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </GameShell>
  );
}
