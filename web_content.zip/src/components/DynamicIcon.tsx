import React from 'react';
import {
  ArrowDownLeft,
  Briefcase,
  Building2,
  Calculator,
  CheckCircle2,
  ClipboardList,
  Coins,
  FileSpreadsheet,
  FileText,
  FolderKanban,
  Landmark,
  Layers,
  Package,
  Receipt,
  Scale,
  ShieldCheck,
  ShoppingBag,
  TrendingUp,
  Users,
  Wallet,
} from 'lucide-react';

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  FolderKanban,
  Wallet,
  Landmark,
  Users,
  Package,
  Receipt,
  Calculator,
  Briefcase,
  ShoppingBag,
  Building2,
  FileSpreadsheet,
  FileText,
  Coins,
  TrendingUp,
  Layers,
  ClipboardList,
  ShieldCheck,
  ArrowDownLeft,
  CheckCircle2,
  Scale,
};

export const DynamicIcon: React.FC<{ name: string; className?: string }> = ({
  name,
  className = 'w-5 h-5',
}) => {
  const Comp = ICON_MAP[name] || FolderKanban;
  return <Comp className={className} aria-hidden="true" />;
};
