import React, { useState, useEffect, useRef } from 'react';
import { SOUNDSCAPE_PRESETS } from '../data/spiritualData';
import { SoundscapePreset } from '../types';
import { 
  Sparkles, 
  Play, 
  Pause, 
  Sun, 
  Volume2, 
  Timer, 
  Home, 
  ArrowLeft, 
  ArrowRight, 
  ChevronUp, 
  ChevronDown, 
  ChevronLeft, 
  ChevronRight,
  Move,
  Compass,
  Radio,
  Music2,
  Activity,
  Heart,
  Shield,
  RotateCcw,
  Zap,
  Flame,
  Clock
} from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';
import { SelahMeditationTimer } from './SelahMeditationTimer';

interface SoakingMeditationRoomProps {
  onHome?: () => void;
  onPrevPage?: () => void;
  onNextPage?: () => void;
}

export const SoakingMeditationRoom: React.FC<SoakingMeditationRoomProps> = ({ 
  onHome, 
  onPrevPage, 
  onNextPage 
}) => {
  const [activeMode, setActiveMode] = useState<'selah' | 'soundscape'>('selah');
  const [selectedPreset, setSelectedPreset] = useState<SoundscapePreset>(SOUNDSCAPE_PRESETS[0]);
  const [isSoakingActive, setIsSoakingActive] = useState<boolean>(false);
  const [timerMinutes, setTimerMinutes] = useState<number>(15);
  const [timeLeft, setTimeLeft] = useState<number>(15 * 60);
  const [breathPhase, setBreathPhase] = useState<'Inhale Divine Grace' | 'Hold Holy Faith' | 'Exhale Peace'>('Inhale Divine Grace');
  const [scriptureIndex, setScriptureIndex] = useState<number>(0);

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const presetScrollRef = useRef<HTMLDivElement>(null);

  const scriptures = [
    'Be still, and know that I am God. — Psalm 46:10',
    'He restores my soul; He leads me in paths of righteousness. — Psalm 23:3',
    'Cast all your anxiety on Him because He cares for you. — 1 Peter 5:7',
    'You will keep in perfect peace those whose minds are steadfast. — Isaiah 26:3',
    'In quietness and trust is your strength. — Isaiah 30:15',
    'The Lord will fight for you; you need only to be still. — Exodus 14:14',
    'My presence will go with you, and I will give you rest. — Exodus 33:14'
  ];

  // Navigation handlers with scroll-to-top execution
  const handleHomeClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    if (onHome) onHome();
  };

  const handlePrevClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    if (onPrevPage) onPrevPage();
  };

  const handleNextClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    if (onNextPage) onNextPage();
  };

  // 4-Directional Scroll Helpers
  const handleScrollUp = () => {
    window.scrollBy({ top: -350, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ top: -350, behavior: 'smooth' });
    }
  };

  const handleScrollDown = () => {
    window.scrollBy({ top: 350, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ top: 350, behavior: 'smooth' });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleScrollToBottom = () => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: scrollContainerRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  const handleScrollLeft = () => {
    if (presetScrollRef.current) {
      presetScrollRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const handleScrollRight = () => {
    if (presetScrollRef.current) {
      presetScrollRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  // Breathing cycle
  useEffect(() => {
    if (!isSoakingActive) return;
    const interval = window.setInterval(() => {
      setBreathPhase((prev) => {
        if (prev === 'Inhale Divine Grace') return 'Hold Holy Faith';
        if (prev === 'Hold Holy Faith') return 'Exhale Peace';
        return 'Inhale Divine Grace';
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isSoakingActive]);

  // Scripture rotator
  useEffect(() => {
    const interval = window.setInterval(() => {
      setScriptureIndex((prev) => (prev + 1) % scriptures.length);
    }, 9000);
    return () => clearInterval(interval);
  }, [scriptures.length]);

  // Soaking countdown timer with chime
  useEffect(() => {
    let timer: number;
    if (isSoakingActive && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isSoakingActive) {
      setIsSoakingActive(false);
      audioEngine.stopAll();
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(528, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 3);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 3);
      } catch (e) {
        console.log('Audio chime error:', e);
      }
    }
    return () => clearInterval(timer);
  }, [isSoakingActive, timeLeft]);

  const handleToggleSoaking = () => {
    if (isSoakingActive) {
      setIsSoakingActive(false);
      audioEngine.stopAll();
    } else {
      setIsSoakingActive(true);
      setTimeLeft(timerMinutes * 60);
      audioEngine.playTrackSyntheticSoundscape(selectedPreset.frequencyHz, selectedPreset.padType);
    }
  };

  const handlePresetSelect = (preset: SoundscapePreset) => {
    setSelectedPreset(preset);
    if (isSoakingActive) {
      audioEngine.playTrackSyntheticSoundscape(preset.frequencyHz, preset.padType);
    }
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div 
      ref={scrollContainerRef}
      id="soaking-room-scroll-container"
      className="w-full max-w-7xl mx-auto space-y-6 px-2 sm:px-4 lg:px-6 overflow-x-auto overflow-y-auto max-h-[calc(100vh-140px)] sm:max-h-[calc(100vh-160px)] pb-12 transition-all duration-300"
      style={{ scrollBehavior: 'smooth' }}
    >
      {/* Universal Sticky Top Navigation Toolbar with Home, Prev, Next and Scroll Triggers */}
      <div 
        id="soaking-nav-header"
        className="sticky top-0 z-30 bg-slate-950/95 border border-amber-500/30 rounded-2xl p-3 sm:p-4 shadow-2xl backdrop-blur-xl flex flex-wrap items-center justify-between gap-3"
      >
        {/* Left: Breadcrumbs & Page Identity */}
        <div className="flex items-center space-x-2 text-xs text-amber-300 font-mono">
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse shrink-0" />
          <span className="opacity-70 hidden sm:inline">JUHNKRIX MUSIKA</span>
          <span className="opacity-50 hidden sm:inline">/</span>
          <span className="font-bold text-amber-100 uppercase tracking-wide">528Hz Glory Soaking Sanctuary</span>
        </div>

        {/* Center: 4-Way Scroll Directional Navigation Controls (Up, Down, Left, Right) */}
        <div className="flex items-center space-x-1.5 bg-slate-900/90 px-2.5 py-1.5 rounded-xl border border-amber-500/20 shadow-inner">
          <span className="text-[10px] text-amber-400/90 font-bold uppercase tracking-wider mr-1 flex items-center space-x-1">
            <Move className="w-3 h-3 text-amber-400" />
            <span className="hidden sm:inline">Scroll:</span>
          </span>
          <button
            id="btn-soaking-scroll-up"
            onClick={handleScrollUp}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95 cursor-pointer"
            title="Scroll Up"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn-soaking-scroll-down"
            onClick={handleScrollDown}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95 cursor-pointer"
            title="Scroll Down"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn-soaking-scroll-left"
            onClick={handleScrollLeft}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95 cursor-pointer"
            title="Scroll Left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn-soaking-scroll-right"
            onClick={handleScrollRight}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-all border border-slate-700 hover:border-amber-400/40 active:scale-95 cursor-pointer"
            title="Scroll Right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Primary Page Navigation Buttons (Previous, Home, Next) */}
        <div className="flex items-center space-x-2">
          <button
            id="btn-soaking-prev-top"
            onClick={handlePrevClick}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all hover:scale-102 shadow cursor-pointer"
            title="Navigate to Previous Page"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Previous</span>
          </button>

          <button
            id="btn-soaking-home-top"
            onClick={handleHomeClick}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/30 hover:scale-105 transition-all cursor-pointer"
            title="Return to Home (Anointed Worship)"
          >
            <Home className="w-4 h-4 text-slate-950" />
            <span>Home</span>
          </button>

          <button
            id="btn-soaking-next-top"
            onClick={handleNextClick}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all hover:scale-102 shadow cursor-pointer"
            title="Navigate to Next Page"
          >
            <span className="hidden xs:inline">Next</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Sanctuary Atmospheric Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/90 p-2 sm:p-2.5 rounded-2xl border-2 border-purple-500/30 shadow-xl backdrop-blur-md">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveMode('selah')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeMode === 'selah'
                ? 'bg-gradient-to-r from-purple-500 via-indigo-500 to-purple-600 text-white shadow-lg shadow-purple-500/30 ring-1 ring-purple-300'
                : 'text-purple-300 hover:text-white hover:bg-purple-950/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>Selah Silent Prayer Meditation Timer</span>
          </button>

          <button
            onClick={() => setActiveMode('soundscape')}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeMode === 'soundscape'
                ? 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/30 ring-1 ring-amber-300 font-extrabold'
                : 'text-amber-300 hover:text-white hover:bg-amber-950/40'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-amber-400" />
            <span>528Hz Harmonic Soundscape Altar</span>
          </button>
        </div>

        <div className="text-[11px] font-mono text-purple-300/80 hidden sm:flex items-center space-x-1 pr-3">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>{activeMode === 'selah' ? 'Holy silence with automatic scripture prompt' : 'Continuous harmonic soaking pads'}</span>
        </div>
      </div>

      {/* RENDER SELAH TIMER */}
      {activeMode === 'selah' && (
        <div className="animate-fadeIn">
          <SelahMeditationTimer />
        </div>
      )}

      {/* REFACTORED RESPONSIVE GRID-BASED WRAPPER FOR MEDIA BLOCKS (CONTINUOUS SOAKING) */}
      <div 
        id="soaking-grid-wrapper"
        className={`grid grid-cols-1 lg:grid-cols-12 gap-6 w-full items-start ${activeMode === 'selah' ? 'opacity-90' : ''}`}
      >
        {/* LEFT/CENTER PRIMARY STAGE: Breathing Aura Ring & Active Meditation Center (8 Cols) */}
        <div 
          id="soaking-primary-stage"
          className="lg:col-span-8 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 p-6 sm:p-8 rounded-3xl border-2 border-amber-500/40 shadow-2xl flex flex-col items-center justify-center min-h-[460px] overflow-hidden text-center space-y-6 relative"
        >
          {/* Top Stage Tag */}
          <div className="flex items-center justify-between w-full border-b border-amber-500/20 pb-3">
            <div className="inline-flex items-center space-x-2 text-xs text-amber-300 font-bold uppercase tracking-wider bg-slate-900/90 px-3 py-1 rounded-full border border-amber-500/30">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Prophetic Glory Frequency: {selectedPreset.frequencyHz}Hz</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/30 font-bold">
              {isSoakingActive ? '● SOAKING IN PROGRESS' : '○ RESTING SANCTUARY'}
            </span>
          </div>

          {/* Pulsing Breathing Aura Ring */}
          <div className="relative flex items-center justify-center my-2">
            <div
              className={`w-60 h-60 sm:w-72 sm:h-72 rounded-full border-2 border-amber-400/40 flex items-center justify-center transition-all duration-1000 ${
                isSoakingActive
                  ? breathPhase === 'Inhale Divine Grace'
                    ? 'scale-110 shadow-[0_0_70px_rgba(251,191,36,0.5)] border-amber-300 bg-amber-500/10'
                    : breathPhase === 'Hold Holy Faith'
                    ? 'scale-105 shadow-[0_0_55px_rgba(168,85,247,0.4)] border-purple-400 bg-purple-500/10'
                    : 'scale-95 shadow-[0_0_30px_rgba(59,130,246,0.3)] border-blue-400 bg-blue-500/10'
                  : 'scale-100 shadow-[0_0_30px_rgba(245,158,11,0.2)] bg-slate-900/40'
              }`}
            >
              <div className="space-y-2.5 p-4 max-w-xs">
                {isSoakingActive ? (
                  <>
                    <span className="text-[11px] uppercase tracking-widest text-amber-300 font-bold animate-pulse block">
                      {breathPhase}
                    </span>
                    <div className="text-3xl sm:text-4xl font-extrabold font-mono text-amber-100">
                      {formatTimer(timeLeft)}
                    </div>
                    <p className="text-[11px] text-amber-200/90 italic font-serif leading-relaxed line-clamp-3">
                      &ldquo;{scriptures[scriptureIndex]}&rdquo;
                    </p>
                  </>
                ) : (
                  <>
                    <Sun className="w-10 h-10 text-amber-400 mx-auto animate-spin-slow" />
                    <h3 className="text-lg sm:text-xl font-bold font-serif text-amber-100">
                      Spiritual Rest & Alignment
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Immerse your heart in {selectedPreset.name} with harmonic synthetic soundscapes.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Soaking Control Buttons & Duration Presets */}
          <div className="flex flex-wrap items-center justify-center gap-3 w-full pt-2">
            <button
              id="btn-toggle-soaking"
              onClick={handleToggleSoaking}
              className={`px-7 py-3.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center space-x-2.5 shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer ${
                isSoakingActive
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-400/50 hover:bg-rose-500/30'
                  : 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 text-slate-950 shadow-amber-500/30'
              }`}
            >
              {isSoakingActive ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>Pause Divine Soaking</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>Begin Soaking ({selectedPreset.frequencyHz}Hz)</span>
                </>
              )}
            </button>

            {/* Timer Duration Selector */}
            <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-2xl border border-amber-500/20 shadow-inner">
              <Timer className="w-3.5 h-3.5 text-amber-400 ml-2 mr-1" />
              {[15, 30, 60].map((mins) => (
                <button
                  key={mins}
                  onClick={() => {
                    setTimerMinutes(mins);
                    if (!isSoakingActive) setTimeLeft(mins * 60);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    timerMinutes === mins
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold'
                      : 'text-slate-400 hover:text-amber-200'
                  }`}
                >
                  {mins}m
                </button>
              ))}
            </div>
          </div>

          {/* Rotating Scripture Reflection Banner */}
          <div className="w-full bg-slate-950/80 p-3.5 rounded-2xl border border-amber-500/20 text-center">
            <span className="text-[10px] text-amber-400 uppercase font-bold tracking-wider block mb-1">
              📖 Prophetic Scripture for Divine Contemplation
            </span>
            <p className="text-xs font-serif italic text-slate-200 transition-all duration-500">
              &ldquo;{scriptures[scriptureIndex]}&rdquo;
            </p>
          </div>
        </div>

        {/* RIGHT STAGE: Soundscape Presets & Real-time Frequency Monitor (4 Cols) */}
        <div 
          id="soaking-secondary-stage"
          className="lg:col-span-4 space-y-4 w-full"
        >
          {/* Active Preset Information Card */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <div className="flex items-center space-x-2">
                <Music2 className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold text-amber-100 font-serif">Selected Soundscape</h4>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold">
                {selectedPreset.padType.toUpperCase()}
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="text-base font-bold text-amber-200">{selectedPreset.name}</div>
              <p className="text-xs text-slate-300 leading-relaxed">{selectedPreset.description}</p>
            </div>

            <div className="bg-slate-950 p-3 rounded-2xl border border-amber-500/10 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Harmonic Frequency:</span>
                <span className="text-amber-300 font-bold">{selectedPreset.frequencyHz} Hz</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Audio Engine:</span>
                <span className="text-emerald-400 font-bold">Polyphonic Synth (Web Audio API)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Continuous Loop:</span>
                <span className="text-amber-200">24/7 Autonomous</span>
              </div>
            </div>
          </div>

          {/* Quick Frequency Selector Box */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center space-x-1.5">
                <Radio className="w-3.5 h-3.5 text-amber-400" />
                <span>Quick Frequencies</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Select to switch</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {SOUNDSCAPE_PRESETS.slice(0, 4).map((p) => (
                <button
                  key={p.id}
                  onClick={() => handlePresetSelect(p)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    selectedPreset.id === p.id
                      ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-bold shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-amber-500/30'
                  }`}
                >
                  <div className="text-[10px] font-mono text-amber-400">{p.frequencyHz} Hz</div>
                  <div className="truncate font-medium">{p.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Sanctuary Navigation Controls */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-3 text-xs">
            <div className="flex items-center space-x-2 text-amber-300 font-bold">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>Sanctuary Navigation Hub</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Instantly navigate across the JUHNKRIX MUSIKA spiritual sanctuary views.
            </p>
            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                onClick={handlePrevClick}
                className="py-2 px-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-amber-500/30 text-amber-300 font-bold text-[11px] text-center transition-all cursor-pointer"
              >
                ← Prev
              </button>
              <button
                onClick={handleHomeClick}
                className="py-2 px-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-[11px] text-center shadow transition-all cursor-pointer"
              >
                🏠 Home
              </button>
              <button
                onClick={handleNextClick}
                className="py-2 px-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-amber-500/30 text-amber-300 font-bold text-[11px] text-center transition-all cursor-pointer"
              >
                Next →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* FULL SOUNDSCAPE PRESETS SECTION (Responsive Horizontal and Vertical Grid) */}
      <div id="soaking-soundscapes-section" className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <h3 className="text-base sm:text-lg font-bold text-amber-200 font-serif flex items-center space-x-2">
            <Volume2 className="w-5 h-5 text-amber-400" />
            <span>Complete Anointed Soundscape Presets ({SOUNDSCAPE_PRESETS.length})</span>
          </h3>
          <div className="flex items-center space-x-1.5">
            <button
              onClick={handleScrollLeft}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 shadow active:scale-95 cursor-pointer"
              title="Scroll Soundscapes Left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleScrollRight}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 shadow active:scale-95 cursor-pointer"
              title="Scroll Soundscapes Right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div 
          ref={presetScrollRef}
          className="grid grid-flow-col auto-cols-[280px] sm:auto-cols-[320px] lg:grid-flow-row lg:grid-cols-4 gap-4 overflow-x-auto pb-4 scrollbar-thin scroll-smooth"
        >
          {SOUNDSCAPE_PRESETS.map((preset) => {
            const isSelected = selectedPreset.id === preset.id;

            return (
              <div
                key={preset.id}
                onClick={() => handlePresetSelect(preset)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 relative overflow-hidden shrink-0 ${
                  isSelected
                    ? 'bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 border-amber-400 shadow-xl ring-1 ring-amber-400/50'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-amber-500/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-mono">
                    {preset.frequencyHz}Hz
                  </span>
                  {isSelected && <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />}
                </div>

                <h4 className="text-sm font-bold text-amber-100 font-serif">{preset.name}</h4>
                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">{preset.description}</p>
                <div className="text-[10px] font-mono text-amber-300/80 pt-1 border-t border-slate-800/80">
                  Mode: {preset.padType}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* BOTTOM QUICK NAVIGATION BAR (Home, Next, Previous) */}
      <div 
        id="soaking-bottom-nav"
        className="flex items-center justify-between bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 shadow-xl backdrop-blur-md"
      >
        <button
          id="btn-soaking-prev-bottom"
          onClick={handlePrevClick}
          className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Previous Page</span>
        </button>

        <button
          id="btn-soaking-home-bottom"
          onClick={handleHomeClick}
          className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-xs shadow-md transition-all hover:scale-105 cursor-pointer"
        >
          <Home className="w-4 h-4 text-slate-950" />
          <span>RETURN TO HOME</span>
        </button>

        <button
          id="btn-soaking-next-bottom"
          onClick={handleNextClick}
          className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
        >
          <span>Next Page</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* FLOATING 4-WAY DIRECTIONAL SCROLL COMPASS PAD */}
      <div 
        id="soaking-compass-pad"
        className="fixed bottom-24 right-4 z-40 bg-slate-950/95 border-2 border-amber-500/40 rounded-2xl p-2 shadow-2xl backdrop-blur-xl flex flex-col items-center space-y-1.5 hidden md:flex"
      >
        <div className="text-[9px] font-bold text-amber-400 tracking-widest uppercase flex items-center space-x-1">
          <Compass className="w-3 h-3 text-amber-400" />
          <span>VIEW</span>
        </div>
        <button
          onClick={handleScrollUp}
          className="p-1.5 rounded-lg bg-slate-900 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all active:scale-95 shadow cursor-pointer"
          title="Scroll Page Up"
        >
          <ChevronUp className="w-4 h-4" />
        </button>
        <div className="flex items-center space-x-1.5">
          <button
            onClick={handleScrollLeft}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all active:scale-95 shadow cursor-pointer"
            title="Scroll Left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleScrollToTop}
            className="p-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-[9px] font-mono font-bold cursor-pointer"
            title="Jump to Top"
          >
            TOP
          </button>
          <button
            onClick={handleScrollRight}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all active:scale-95 shadow cursor-pointer"
            title="Scroll Right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        <button
          onClick={handleScrollDown}
          className="p-1.5 rounded-lg bg-slate-900 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all active:scale-95 shadow cursor-pointer"
          title="Scroll Page Down"
        >
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
