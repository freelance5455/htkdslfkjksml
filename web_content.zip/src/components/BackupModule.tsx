import React, { useRef, useState } from 'react';
import { CheckCircle2, Download, RotateCcw, ShieldAlert, Upload } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  downloadTextFile,
  loadSafetyBackup,
  validateBackupPayload,
} from '../utils/storage';
import type { AppDataState } from '../types';

export const BackupModule: React.FC = () => {
  const { state, replaceAllData, restoreSafetyBackup, hasSafetyBackup, themeTokens, notify } =
    useApp();

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [pendingImport, setPendingImport] = useState<{
    filename: string;
    data: AppDataState;
    counts: {
      purchases: number;
      expenses: number;
      leaves: number;
      tasks: number;
      loans: number;
      committees: number;
      customRecords: number;
    };
  } | null>(null);
  const [importError, setImportError] = useState('');
  const [importMode, setImportMode] = useState<'replace' | 'merge'>('replace');

  const safetyMeta = hasSafetyBackup ? loadSafetyBackup() : null;

  const handleExportJson = () => {
    const stamp = new Date().toISOString().slice(0, 10);
    const filename = `saif-ullah-manager-backup-${stamp}.json`;
    downloadTextFile(filename, JSON.stringify(state, null, 2), 'application/json');
    notify(`Exported backup to ${filename}`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError('');
    setPendingImport(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || ''));
        const check = validateBackupPayload(parsed);
        if (!check.valid || !check.state || !check.counts) {
          setImportError(check.error || 'Invalid backup file.');
          return;
        }
        setPendingImport({
          filename: file.name,
          data: check.state,
          counts: check.counts,
        });
      } catch {
        setImportError('Could not parse JSON file. Make sure you selected a valid .json backup.');
      }
    };
    reader.readAsText(file);
  };

  const confirmImport = () => {
    if (!pendingImport) return;
    replaceAllData(pendingImport.data, importMode);
    setPendingImport(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    notify(
      importMode === 'replace'
        ? 'Backup restored successfully. A safety backup of your previous data was saved.'
        : 'Backup merged successfully. A safety backup of your previous data was saved.'
    );
  };

  const handleRestoreSafety = () => {
    const ok = restoreSafetyBackup();
    if (ok) {
      notify('Previous data restored from automatic safety backup.');
    } else {
      notify('No safety backup found.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Export JSON */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-start gap-3">
            <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-white ${themeTokens.sidebarBg}`}>
              <Download className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900">Export Local JSON Backup</h2>
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                Download all your purchases, expenses, leave records, office tasks, loans, committees, custom modules, recycle bin, audit log, and settings as a single offline JSON file.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5 text-xs bg-slate-50 rounded-lg p-3 tabular-nums">
            <div>
              <span className="text-slate-500">Purchases:</span>{' '}
              <strong className="text-slate-900">{state.purchases.length}</strong>
            </div>
            <div>
              <span className="text-slate-500">Expenses:</span>{' '}
              <strong className="text-slate-900">{state.expenses.length}</strong>
            </div>
            <div>
              <span className="text-slate-500">Leave:</span>{' '}
              <strong className="text-slate-900">{state.leaves.length}</strong>
            </div>
            <div>
              <span className="text-slate-500">Tasks:</span>{' '}
              <strong className="text-slate-900">{state.tasks.length}</strong>
            </div>
            <div>
              <span className="text-slate-500">Loans:</span>{' '}
              <strong className="text-slate-900">{state.loanTransactions.length}</strong>
            </div>
            <div>
              <span className="text-slate-500">Committee:</span>{' '}
              <strong className="text-slate-900">{state.committeeTransactions.length}</strong>
            </div>
          </div>

          <button
            type="button"
            onClick={handleExportJson}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
          >
            <Download className="h-4 w-4" />
            <span>Download JSON Backup</span>
          </button>
        </section>

        {/* Import / Restore JSON */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700">
              <Upload className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900">Import / Restore from JSON</h2>
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                Select a previously exported JSON backup. The file structure is validated before any changes are made, and a safety backup of your current data is saved automatically.
              </p>
            </div>
          </div>

          <div>
            <label htmlFor="json-import-file" className="block text-xs font-medium text-slate-700 mb-1.5">
              Choose JSON Backup File
            </label>
            <input
              ref={fileInputRef}
              id="json-import-file"
              type="file"
              accept=".json,application/json"
              onChange={handleFileChange}
              className="block w-full text-xs text-slate-600 file:me-3 file:rounded-lg file:border file:border-slate-300 file:bg-white file:px-3 file:py-2 file:text-xs file:font-medium file:text-slate-700 hover:file:bg-slate-50"
            />
          </div>

          {importError && (
            <div role="alert" className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-700">
              <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{importError}</span>
            </div>
          )}

          {pendingImport && (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-900">
                <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                <span>Validated: {pendingImport.filename}</span>
              </div>
              <div className="text-xs text-slate-700 tabular-nums">
                Purchases: {pendingImport.counts.purchases} · Expenses: {pendingImport.counts.expenses} · Leave: {pendingImport.counts.leaves} · Tasks: {pendingImport.counts.tasks} · Loans: {pendingImport.counts.loans} · Committee: {pendingImport.counts.committees} · Custom: {pendingImport.counts.customRecords}
              </div>

              <div className="flex flex-wrap gap-4 text-xs text-slate-800">
                <label className="inline-flex items-center gap-1.5">
                  <input
                    type="radio"
                    name="importMode"
                    checked={importMode === 'replace'}
                    onChange={() => setImportMode('replace')}
                  />
                  <span>Replace all current data</span>
                </label>
                <label className="inline-flex items-center gap-1.5">
                  <input
                    type="radio"
                    name="importMode"
                    checked={importMode === 'merge'}
                    onChange={() => setImportMode('merge')}
                  />
                  <span>Merge with current data</span>
                </label>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={confirmImport}
                  className={`rounded-lg px-4 py-2 text-xs font-semibold text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  Confirm &amp; Restore
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPendingImport(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Automatic Safety Backup */}
      {safetyMeta && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Automatic Safety Backup Available</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Saved automatically before your last JSON restore ({safetyMeta.savedAt.slice(0, 19).replace('T', ' ')}).
            </p>
          </div>
          <button
            type="button"
            onClick={handleRestoreSafety}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Undo Last Import (Restore Safety Backup)</span>
          </button>
        </section>
      )}

      {/* Offline & Android APK Run Instructions */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-900">Running Offline on Desktop &amp; Android</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600 leading-relaxed">
          <div className="space-y-1.5">
            <div className="font-semibold text-slate-800">Desktop Browser (Offline)</div>
            <p>
              1. Export or build the project (<code className="font-mono bg-slate-100 px-1 rounded">npm run build</code>) to generate the standalone <code className="font-mono bg-slate-100 px-1 rounded">dist/</code> folder.
            </p>
            <p>
              2. All data is stored locally in your browser via <code className="font-mono bg-slate-100 px-1 rounded">localStorage</code> — no internet connection or external server is required after loading.
            </p>
            <p>
              3. Use <strong>Download JSON Backup</strong> regularly to save a copy to your computer or USB drive.
            </p>
          </div>
          <div className="space-y-1.5">
            <div className="font-semibold text-slate-800">Android Phone / APK Wrapper</div>
            <p>
              1. Open Settings and switch <strong>View Mode</strong> to <strong>Mobile View</strong> for a compact 3-column mobile dashboard layout.
            </p>
            <p>
              2. To package as an Android APK, wrap the built <code className="font-mono bg-slate-100 px-1 rounded">dist/</code> folder using Capacitor (<code className="font-mono bg-slate-100 px-1 rounded">npx cap add android</code>) or Android WebView with DOM Storage enabled (<code className="font-mono bg-slate-100 px-1 rounded">domStorageEnabled = true</code>).
            </p>
            <p>
              3. Transfer data between Desktop and Android anytime using JSON Export &amp; Import above.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
