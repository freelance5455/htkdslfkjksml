import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, RotateCcw } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface BreathingWidgetProps {
  onCompleteCycle?: (cycles: number) => void;
  targetMinutes?: number;
}

export const BreathingWidget: React.FC<BreathingWidgetProps> = ({
  targetMinutes = 5,
}) => {
  const { t } = useTranslation();
  const [isActive, setIsActive] = useState<boolean>(true);
  const [phase, setPhase] = useState<'inhale' | 'exhale'>('inhale');
  const [secondsInPhase, setSecondsInPhase] = useState<number>(0);
  const [completedCycles, setCompletedCycles] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);

  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play gentle bell sound using Web Audio API
  const playGentleBell = (freq: number = 440) => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 1.8);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 2.0);
    } catch {
      // Audio context might fail silently if user hasn't interacted
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive) {
      interval = setInterval(() => {
        setSecondsInPhase((prev) => {
          if (prev >= 4) {
            // Switch phase every 5 seconds (0, 1, 2, 3, 4 -> 5s total)
            setPhase((currentPhase) => {
              const next = currentPhase === 'inhale' ? 'exhale' : 'inhale';
              if (next === 'inhale') {
                setCompletedCycles((c) => c + 1);
                playGentleBell(528); // 528Hz Solfeggio frequency for heart/harmony
              } else {
                playGentleBell(396); // 396Hz calming grounding tone
              }
              return next;
            });
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive, soundEnabled]);

  const resetTimer = () => {
    setIsActive(false);
    setPhase('inhale');
    setSecondsInPhase(0);
    setCompletedCycles(0);
  };

  const progressPercent = ((secondsInPhase + 1) / 5) * 100;

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-b from-rose-50/50 to-teal-50/40 dark:from-slate-900/40 dark:to-teal-950/20 rounded-3xl border border-rose-100/80 dark:border-slate-800 shadow-sm max-w-lg mx-auto my-4">
      {/* Top Controls */}
      <div className="w-full flex items-center justify-between mb-4 px-2">
        <div className="text-xs font-semibold uppercase tracking-wider text-teal-700 dark:text-teal-300">
          {t('interactive.coherenceTitle')}
        </div>
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition-colors shadow-2xs"
          title={soundEnabled ? 'Désactiver le son' : 'Activer le son doux'}
        >
          {soundEnabled ? (
            <>
              <Volume2 className="w-3.5 h-3.5 text-rose-500" />
              <span>Son actif (440Hz/528Hz)</span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
              <span>Son coupé</span>
            </>
          )}
        </button>
      </div>

      {/* Visual Breathing Sphere */}
      <div className="relative w-64 h-64 flex items-center justify-center my-6">
        {/* Outer glowing aura */}
        <div
          className={`absolute rounded-full transition-all duration-1000 ease-in-out ${
            phase === 'inhale'
              ? 'w-60 h-60 bg-rose-200/50 dark:bg-rose-900/30 scale-105'
              : 'w-36 h-36 bg-teal-200/50 dark:bg-teal-900/30 scale-95'
          } blur-xl`}
        />

        {/* Medium ripple circle */}
        <div
          className={`absolute rounded-full border-2 border-dashed border-rose-300/60 dark:border-rose-700/50 transition-transform duration-5000 ease-in-out ${
            phase === 'inhale' ? 'scale-100 rotate-45' : 'scale-60 -rotate-45'
          }`}
          style={{ width: '220px', height: '220px' }}
        />

        {/* Main pulsating heart circle */}
        <div
          className={`relative z-10 rounded-full flex flex-col items-center justify-center text-center p-6 shadow-xl transition-all duration-5000 ease-in-out ${
            phase === 'inhale'
              ? 'w-52 h-52 bg-gradient-to-tr from-rose-400 via-rose-300 to-amber-200 text-white scale-100 ring-8 ring-rose-200/50 dark:ring-rose-900/30'
              : 'w-32 h-32 bg-gradient-to-tr from-teal-500 via-emerald-400 to-cyan-300 text-white scale-90 ring-4 ring-teal-200/50 dark:ring-teal-900/30'
          }`}
        >
          <span className="text-base font-bold tracking-wide drop-shadow-xs">
            {phase === 'inhale' ? 'INSPIRATION' : 'EXPIRATION'}
          </span>
          <span className="text-3xl font-extrabold my-1 drop-shadow-md">
            {5 - secondsInPhase}s
          </span>
          <span className="text-xs opacity-90 font-medium">
            {phase === 'inhale' ? 'Par le nez' : 'Par la bouche'}
          </span>
        </div>
      </div>

      {/* Instruction text */}
      <p className="text-center text-sm font-medium text-slate-700 dark:text-slate-300 h-10 px-4 transition-opacity">
        {phase === 'inhale'
          ? t('interactive.breatheIn')
          : t('interactive.breatheOut')}
      </p>

      {/* Progress & Stats */}
      <div className="w-full mt-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-4 border-t border-slate-100 dark:border-slate-800 pt-3">
        <div>
          {t('interactive.cycleCount')}{' '}
          <strong className="text-slate-700 dark:text-slate-200 font-bold">
            {completedCycles}
          </strong>{' '}
          / {targetMinutes * 6}
        </div>
        <div>Rythme 6 respirations / min</div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3 mt-4">
        <button
          onClick={() => setIsActive(!isActive)}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-semibold text-sm shadow-md transition-all ${
            isActive
              ? 'bg-amber-100 text-amber-800 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-200'
              : 'bg-teal-600 text-white hover:bg-teal-700'
          }`}
        >
          {isActive ? (
            <>
              <Pause className="w-4 h-4" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Reprendre</span>
            </>
          )}
        </button>

        <button
          onClick={resetTimer}
          className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          title="Réinitialiser"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
