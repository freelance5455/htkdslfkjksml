"use client";

/* eslint-disable @next/next/no-img-element */
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { useLang, type Lang } from "@/lib/i18n";

type Result = {
  slug: string;
  name: string;
  city: string;
  country: string;
  price: number;
  rating: number;
  image: string;
};

type Action =
  | { type: "navigate"; url: string }
  | { type: "set"; tickets?: number; date?: string }
  | { type: "confirm" };

type Msg = { id: number; role: "user" | "bot"; text: string; results?: Result[] };

type SRResult = ArrayLike<{ transcript: string }> & { isFinal: boolean };
type SREvent = { resultIndex: number; results: ArrayLike<SRResult> };
type SRInstance = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
};
type SRCtor = new () => SRInstance;

function getSR(): SRCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

const cleanForSpeech = (s: string) =>
  s
    .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}]/gu, " ")
    .replace(/€/g, lang0(s) === "ar" ? " يورو " : " euros ")
    .replace(/\s+/g, " ")
    .trim();

function lang0(s: string): Lang {
  return /[\u0600-\u06FF]/.test(s) ? "ar" : "en";
}

export default function VoiceAssistant() {
  const { lang, t } = useLang();
  const router = useRouter();
  const pathname = usePathname();

  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [handsFree, setHandsFree] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [supported, setSupported] = useState(true);

  const recogRef = useRef<SRInstance | null>(null);
  const handsFreeRef = useRef(false);
  const voiceOnRef = useRef(true);
  const speechLangRef = useRef<Lang>("ar");
  const lastSlugsRef = useRef<string[]>([]);
  const pathRef = useRef(pathname);
  const idRef = useRef(1);
  const noSpeechRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const sendRef = useRef<(text: string) => void>(() => {});
  const listenRef = useRef<() => void>(() => {});
  const openRef = useRef(false);

  useEffect(() => {
    pathRef.current = pathname;
  }, [pathname]);
  useEffect(() => {
    speechLangRef.current = lang;
  }, [lang]);
  useEffect(() => {
    voiceOnRef.current = voiceOn;
    if (!voiceOn && typeof window !== "undefined") window.speechSynthesis?.cancel();
  }, [voiceOn]);
  useEffect(() => {
    openRef.current = open;
  }, [open]);
  useEffect(() => {
    setSupported(!!getSR());
  }, []);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, thinking]);

  const addMsg = useCallback((m: Omit<Msg, "id">) => {
    setMsgs((prev) => [...prev, { ...m, id: idRef.current++ }]);
  }, []);

  const setHF = useCallback((v: boolean) => {
    handsFreeRef.current = v;
    setHandsFree(v);
  }, []);

  /* ------------------------------ speech output ----------------------------- */
  const speak = useCallback((text: string, l: Lang, onEnd?: () => void) => {
    const synth = typeof window !== "undefined" ? window.speechSynthesis : undefined;
    if (!synth || !voiceOnRef.current) {
      onEnd?.();
      return;
    }
    synth.cancel();
    const u = new SpeechSynthesisUtterance(cleanForSpeech(text));
    u.lang = l === "ar" ? "ar-SA" : "en-US";
    const voices = synth.getVoices();
    const v = voices.find((x) => x.lang.toLowerCase().startsWith(l)) ?? null;
    if (v) u.voice = v;
    u.rate = 1;
    u.pitch = 1;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      setSpeaking(false);
      onEnd?.();
    };
    u.onstart = () => setSpeaking(true);
    u.onend = finish;
    u.onerror = finish;
    setSpeaking(true);
    synth.speak(u);
  }, []);

  /* ------------------------------ speech input ------------------------------ */
  const stopListening = useCallback(() => {
    const r = recogRef.current;
    recogRef.current = null;
    if (r) {
      r.onend = null;
      r.onresult = null;
      r.onerror = null;
      try {
        r.abort();
      } catch {}
    }
    setListening(false);
  }, []);

  const startListening = useCallback(() => {
    const SR = getSR();
    if (!SR) {
      setSupported(false);
      return;
    }
    stopListening();
    window.speechSynthesis?.cancel();
    setSpeaking(false);

    const r = new SR();
    r.lang = speechLangRef.current === "ar" ? "ar-SA" : "en-US";
    r.interimResults = true;
    r.continuous = false;
    r.maxAlternatives = 1;
    let finalText = "";
    let interim = "";

    r.onstart = () => setListening(true);
    r.onresult = (e) => {
      let f = "";
      let i = "";
      for (let k = e.resultIndex; k < e.results.length; k++) {
        const res = e.results[k];
        if (res.isFinal) f += res[0].transcript;
        else i += res[0].transcript;
      }
      if (f) finalText += f;
      interim = i;
      setInput((finalText + i).trim());
    };
    r.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        addMsg({ role: "bot", text: t("micDenied") });
        setHF(false);
      }
    };
    r.onend = () => {
      recogRef.current = null;
      setListening(false);
      const text = (finalText || interim).trim();
      if (text) {
        noSpeechRef.current = 0;
        setInput("");
        sendRef.current(text);
      } else if (handsFreeRef.current) {
        noSpeechRef.current += 1;
        if (noSpeechRef.current >= 3) {
          noSpeechRef.current = 0;
          setHF(false);
        } else {
          setTimeout(() => handsFreeRef.current && listenRef.current(), 250);
        }
      }
    };
    recogRef.current = r;
    try {
      r.start();
    } catch {
      setListening(false);
    }
  }, [addMsg, setHF, stopListening, t]);

  useEffect(() => {
    listenRef.current = startListening;
  }, [startListening]);

  /* ------------------------------- conversation ------------------------------ */
  const runActions = useCallback(
    (actions: Action[] | undefined) => {
      for (const a of actions ?? []) {
        if (a.type === "navigate") router.push(a.url);
        else if (a.type === "set") {
          const d = { tickets: a.tickets, date: a.date };
          setTimeout(() => window.dispatchEvent(new CustomEvent("assistant:set", { detail: d })), 0);
        } else if (a.type === "confirm") {
          setTimeout(() => window.dispatchEvent(new CustomEvent("assistant:confirm")), 0);
        }
      }
    },
    [router],
  );

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text) return;
      stopListening();
      addMsg({ role: "user", text });
      setThinking(true);
      try {
        const m = pathRef.current.match(/^\/attraction\/([^/?#]+)/);
        const res = await fetch("/api/assistant", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text,
            lang: speechLangRef.current,
            currentSlug: m ? decodeURIComponent(m[1]) : null,
            lastSlugs: lastSlugsRef.current,
          }),
        });
        if (!res.ok) throw new Error("bad");
        const data = (await res.json()) as {
          reply: string;
          lang: Lang;
          results?: Result[];
          actions?: Action[];
        };
        speechLangRef.current = data.lang;
        if (data.results?.length) lastSlugsRef.current = data.results.map((r) => r.slug);
        addMsg({ role: "bot", text: data.reply, results: data.results });
        setThinking(false);
        const confirming = data.actions?.some((a) => a.type === "confirm");
        runActions(data.actions);
        if (confirming) return; // the booking form speaks the outcome itself
        speak(data.reply, data.lang, () => {
          if (handsFreeRef.current) listenRef.current();
        });
      } catch {
        setThinking(false);
        const msg = speechLangRef.current === "ar" ? "عذراً، حدث خطأ. حاول مرة أخرى." : "Sorry, something went wrong. Please try again.";
        addMsg({ role: "bot", text: msg });
        speak(msg, speechLangRef.current, () => {
          if (handsFreeRef.current) listenRef.current();
        });
      }
    },
    [addMsg, runActions, speak, stopListening],
  );

  useEffect(() => {
    sendRef.current = send;
  }, [send]);

  /* --------------------------------- events --------------------------------- */
  const ensureHello = useCallback(() => {
    setMsgs((prev) =>
      prev.length ? prev : [{ id: idRef.current++, role: "bot", text: t("assistantHello") }],
    );
  }, [t]);

  useEffect(() => {
    const onOpen = (e: Event) => {
      const listen = (e as CustomEvent<{ listen?: boolean }>).detail?.listen;
      setOpen(true);
      ensureHello();
      if (listen) {
        setHF(true);
        noSpeechRef.current = 0;
        setTimeout(() => listenRef.current(), 150);
      }
    };
    const onSpeak = (e: Event) => {
      const d = (e as CustomEvent<{ text: string; done?: boolean }>).detail;
      if (!d?.text) return;
      addMsg({ role: "bot", text: d.text });
      if (d.done) setHF(false);
      speak(d.text, lang0(d.text), () => {
        if (handsFreeRef.current) listenRef.current();
      });
    };
    window.addEventListener("assistant:open", onOpen);
    window.addEventListener("assistant:speak", onSpeak);
    return () => {
      window.removeEventListener("assistant:open", onOpen);
      window.removeEventListener("assistant:speak", onSpeak);
    };
  }, [addMsg, ensureHello, setHF, speak]);

  useEffect(() => {
    return () => {
      stopListening();
      window.speechSynthesis?.cancel();
    };
  }, [stopListening]);

  const closePanel = () => {
    setOpen(false);
    setHF(false);
    stopListening();
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  };

  const toggleMic = () => {
    if (listening || handsFree) {
      setHF(false);
      stopListening();
      window.speechSynthesis?.cancel();
      setSpeaking(false);
    } else {
      setHF(true);
      noSpeechRef.current = 0;
      startListening();
    }
  };

  const status = listening ? t("listening") : thinking ? t("thinking") : speaking ? t("speaking") : t("tapMic");
  const suggestions = [t("sug1"), t("sug2"), t("sug3"), t("sug4")];

  return (
    <>
      {!open && (
        <button
          onClick={() => {
            setOpen(true);
            ensureHello();
          }}
          aria-label={t("assistantTitle")}
          className="fixed bottom-5 end-5 z-50 grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-indigo-600 to-fuchsia-500 text-3xl text-white shadow-2xl transition hover:scale-110"
        >
          <span className="absolute inset-0 animate-ping rounded-full bg-fuchsia-400/40" />
          <span className="relative">🎙️</span>
        </button>
      )}

      {open && (
        <div className="fixed inset-x-3 bottom-3 z-50 flex max-h-[85vh] flex-col overflow-hidden rounded-3xl bg-white shadow-2xl ring-1 ring-slate-200 sm:inset-x-auto sm:bottom-5 sm:end-5 sm:w-[24rem]" style={{ height: "36rem" }}>
          <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-600 to-fuchsia-500 px-4 py-3 text-white">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-white/20 text-xl">🤖</div>
            <div className="min-w-0 flex-1">
              <div className="truncate font-bold">{t("assistantTitle")}</div>
              <div className="flex items-center gap-1.5 text-xs text-indigo-100">
                <span className={`h-2 w-2 rounded-full ${listening ? "animate-pulse bg-rose-300" : speaking ? "animate-pulse bg-emerald-300" : "bg-white/60"}`} />
                {status}
              </div>
            </div>
            <button
              onClick={() => setVoiceOn((v) => !v)}
              title={t("voiceReplies")}
              aria-label={t("voiceReplies")}
              className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-lg hover:bg-white/25"
            >
              {voiceOn ? "🔊" : "🔇"}
            </button>
            <button onClick={closePanel} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-lg hover:bg-white/25">
              ✕
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-slate-50 p-4">
            {msgs.map((m) => (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className="max-w-[88%] space-y-2">
                  <div
                    className={`whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-7 ${
                      m.role === "user" ? "rounded-ee-sm bg-indigo-600 text-white" : "rounded-es-sm bg-white text-slate-800 shadow-sm ring-1 ring-slate-200"
                    }`}
                  >
                    {m.text}
                  </div>
                  {m.results?.map((r) => (
                    <button
                      key={r.slug}
                      onClick={() => router.push(`/attraction/${r.slug}`)}
                      className="flex w-full items-center gap-3 rounded-xl bg-white p-2 text-start shadow-sm ring-1 ring-slate-200 transition hover:ring-indigo-400"
                    >
                      <img src={r.image} alt="" className="h-14 w-16 shrink-0 rounded-lg object-cover" />
                      <div className="min-w-0 flex-1">
                        <div className="line-clamp-1 text-sm font-semibold">{r.name}</div>
                        <div className="text-xs text-slate-500">
                          {r.city} · ★ {r.rating.toFixed(1)}
                        </div>
                      </div>
                      <div className="text-sm font-extrabold text-indigo-700">€{r.price}</div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {thinking && (
              <div className="flex gap-1 ps-2">
                {[0, 1, 2].map((i) => (
                  <span key={i} className="h-2 w-2 animate-bounce rounded-full bg-slate-400" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            )}
            {msgs.length <= 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {suggestions.map((s) => (
                  <button key={s} onClick={() => send(s)} className="rounded-full bg-white px-3 py-1.5 text-xs font-medium text-indigo-700 ring-1 ring-indigo-200 hover:bg-indigo-50">
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-slate-200 bg-white p-3">
            {!supported && <p className="mb-2 text-xs text-amber-600">{t("noVoice")}</p>}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const v = input;
                setInput("");
                send(v);
              }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                onClick={toggleMic}
                disabled={!supported}
                aria-label="Microphone"
                className={`relative grid h-12 w-12 shrink-0 place-items-center rounded-full text-xl text-white shadow transition disabled:opacity-40 ${
                  listening || handsFree ? "bg-rose-500" : "bg-gradient-to-br from-indigo-600 to-fuchsia-500"
                }`}
              >
                {listening && <span className="absolute inset-0 animate-ping rounded-full bg-rose-400/60" />}
                <span className="relative">{listening || handsFree ? "⏹" : "🎙️"}</span>
              </button>
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t("typeMsg")}
                className="min-w-0 flex-1 rounded-full border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
              />
              <button className="rounded-full bg-slate-900 px-4 py-3 text-sm font-semibold text-white hover:bg-slate-700">{t("send")}</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
