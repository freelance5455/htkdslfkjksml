import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { SPECIES_MAP } from '../data/species.ts';
import { Sprout, Droplets, Sparkles, Plus, Shovel, CheckCircle, Clock } from 'lucide-react';

export const Zone1Field: React.FC = () => {
  const {
    player,
    plots,
    inventory,
    shovelModeActive,
    unlockNextPlot,
    tillPlot,
    tillAllPlots,
    waterPlot,
    waterAllPlots,
    fertilizePlot,
    fertilizeAllQuick,
    plantPlot,
    harvestPlot,
    harvestAllPlots,
    shovelPlot,
  } = useGame();

  const [selectedPlotForSeed, setSelectedPlotForSeed] = useState<number | null>(null);
  const [selectedPlotForFert, setSelectedPlotForFert] = useState<number | null>(null);
  const [confirmShovelPlot, setConfirmShovelPlot] = useState<{ id: number; name: string; tier: number } | null>(null);

  const availableSeeds = inventory.filter((i) => i.categoryTab === 1 && i.count > 0);
  const unlockedCount = plots.filter((p) => p.unlocked).length;
  const nextCost = 250 + unlockedCount * 50;

  const handlePlotClick = (plot: typeof plots[0]) => {
    if (!plot.unlocked) {
      unlockNextPlot();
      return;
    }

    // Shovel mode
    if (shovelModeActive) {
      if (plot.plantedSpeciesId) {
        const sp = SPECIES_MAP.get(plot.plantedSpeciesId);
        if (sp && sp.tier >= 3) {
          setConfirmShovelPlot({ id: plot.id, name: sp.name, tier: sp.tier });
          return;
        }
        shovelPlot(plot.id);
      }
      return;
    }

    // Normal workflow
    if (!plot.tilled) {
      tillPlot(plot.id);
      return;
    }

    if (!plot.watered) {
      waterPlot(plot.id);
      return;
    }

    if (!plot.plantedSpeciesId) {
      setSelectedPlotForSeed(plot.id);
      return;
    }

    // If ready, harvest!
    if (plot.readyAt && Date.now() >= plot.readyAt) {
      harvestPlot(plot.id);
      return;
    }

    // If not fertilized, open fert option
    if (plot.fertilizerType === 'none') {
      setSelectedPlotForFert(plot.id);
    }
  };

  const now = Date.now();

  return (
    <div className="space-y-4">
      {/* Tier 1: Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🌾</span>
          <div>
            <h2 className="text-base font-bold text-amber-300">Khu 1: Vùng Đất Vàng (Trồng Trọt)</h2>
            <p className="text-xs text-stone-400">
              Quy mô: {unlockedCount}/50 ô đất • Năng suất phụ thuộc vào nước tưới & phân bón sinh học
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
          <button
            type="button"
            onClick={tillAllPlots}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 transition"
            title="Cày xới tất cả ô đất trống"
          >
            <span>⛏️ Cày Tất Cả</span>
          </button>

          <button
            type="button"
            onClick={waterAllPlots}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-900/40 hover:bg-sky-900/60 text-sky-300 border border-sky-700/60 transition"
            title="Tưới nước tất cả ô đất"
          >
            <Droplets className="w-3.5 h-3.5 text-sky-400" />
            <span>Tưới Tất Cả</span>
          </button>

          <button
            type="button"
            onClick={fertilizeAllQuick}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-900/40 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-700/60 transition"
            title="Bón phân hữu cơ nhanh vào các cây trồng"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Bón Phân Nhanh</span>
          </button>

          <button
            type="button"
            onClick={harvestAllPlots}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold border border-amber-400 shadow-sm transition"
            title="Thu hoạch tất cả nông sản đã chín"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Gặt Nhanh</span>
          </button>

          {unlockedCount < 50 && (
            <button
              type="button"
              disabled={player.gold < nextCost}
              onClick={unlockNextPlot}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border transition ${
                player.gold >= nextCost
                  ? 'bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border-amber-500/50 font-bold'
                  : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
              }`}
              title="Mở thêm ô đất mới"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Mở Ô (+{nextCost} 🪙)</span>
            </button>
          )}
        </div>
      </div>

      {shovelModeActive && (
        <div className="bg-rose-950/80 border border-rose-500/60 rounded-lg p-2.5 text-rose-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shovel className="w-4 h-4 text-rose-400 animate-bounce" />
            <span>
              <strong>Chế độ Xẻng Đang Bật:</strong> Nhấn vào ô đất đang trồng để đào bỏ cây giải phóng luống đất!
            </span>
          </div>
          <span className="text-[11px] bg-rose-900/90 px-2 py-0.5 rounded border border-rose-400 font-bold">
            Đang hoạt động
          </span>
        </div>
      )}

      {/* Tier 2: 5x10 Clean Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-2.5">
        {plots.map((plot) => {
          if (!plot.unlocked) {
            return (
              <button
                key={plot.id}
                type="button"
                onClick={() => unlockNextPlot()}
                className="h-28 rounded-xl border-2 border-dashed border-stone-700/60 bg-stone-900/40 hover:bg-stone-800/60 flex flex-col items-center justify-center text-stone-500 hover:text-amber-400 transition p-2 group"
                aria-label={`Mở khóa ô đất ${plot.id + 1}`}
              >
                <Plus className="w-5 h-5 mb-1 group-hover:scale-110 transition-transform" />
                <span className="text-[11px] font-semibold">Ô Đất #{plot.id + 1}</span>
                <span className="text-[10px] text-amber-500/80 font-bold">Mở: {nextCost} 🪙</span>
              </button>
            );
          }

          const sp = plot.plantedSpeciesId ? SPECIES_MAP.get(plot.plantedSpeciesId) : null;
          const isRipe = plot.readyAt && now >= plot.readyAt;
          const remainingSec = plot.readyAt ? Math.max(0, Math.ceil((plot.readyAt - now) / 1000)) : 0;

          // Plot background appearance
          let soilBg = 'bg-stone-800 border-stone-700';
          if (plot.tilled && !plot.watered) soilBg = 'bg-amber-950/50 border-amber-900/80';
          if (plot.watered) soilBg = 'bg-stone-900/90 border-blue-900/60 ring-1 ring-blue-500/30';
          if (isRipe) soilBg = 'bg-amber-950/40 border-amber-500/80 ring-2 ring-amber-400/60';

          return (
            <div
              key={plot.id}
              onClick={() => handlePlotClick(plot)}
              className={`relative h-28 rounded-xl border-2 p-2 flex flex-col justify-between cursor-pointer select-none transition hover:shadow-lg ${soilBg}`}
            >
              {/* Header inside plot */}
              <div className="flex items-center justify-between text-[10px]">
                <span className="font-bold text-stone-400">#{plot.id + 1}</span>
                <div className="flex items-center gap-1">
                  {plot.watered && <span title="Đã tưới nước">💧</span>}
                  {plot.fertilizerType === 'organic' && (
                    <span className="text-[10px] px-1 bg-emerald-950 text-emerald-300 rounded border border-emerald-500/50" title="Phân Hữu Cơ +50-100%">
                      🌱 +%
                    </span>
                  )}
                  {plot.fertilizerType === 'growth' && (
                    <span className="text-[10px] px-1 bg-amber-950 text-amber-300 rounded border border-amber-500/50" title="Phân Tăng Tốc -35%">
                      ⚡ Nhanh
                    </span>
                  )}
                  {plot.fertilizerType === 'crystal' && (
                    <span className="text-[10px] px-1 bg-purple-950 text-purple-300 rounded border border-purple-500/50" title="Phân Tinh Thể Đột Biến">
                      💎 ĐB
                    </span>
                  )}
                </div>
              </div>

              {/* Center Content */}
              <div className="flex-1 flex flex-col items-center justify-center my-1 text-center">
                {sp ? (
                  <>
                    <div className={`text-2xl sm:text-3xl transition-transform ${isRipe ? 'scale-110 animate-bounce' : ''}`}>
                      {sp.icon}
                    </div>
                    <span className="text-[11px] font-bold text-stone-200 truncate max-w-full">
                      {sp.name}
                    </span>
                  </>
                ) : (
                  <div className="text-stone-500 flex flex-col items-center">
                    <Sprout className="w-5 h-5 mb-0.5 opacity-60" />
                    <span className="text-[10px]">
                      {!plot.tilled ? 'Chưa Cày' : !plot.watered ? 'Chưa Tưới' : 'Sẵn Sàng Gieo'}
                    </span>
                  </div>
                )}
              </div>

              {/* Footer status / countdown */}
              <div className="text-[10px] font-semibold text-center">
                {isRipe ? (
                  <span className="bg-amber-400 text-stone-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                    ✨ Thu Hoạch!
                  </span>
                ) : sp ? (
                  <div className="flex items-center justify-center gap-1 text-stone-400">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>{remainingSec}s</span>
                  </div>
                ) : (
                  <span className="text-stone-500">
                    {!plot.tilled ? 'Nhấn để cày' : !plot.watered ? 'Nhấn để tưới' : 'Nhấn gieo hạt'}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Select Seed to Plant */}
      {selectedPlotForSeed !== null && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-md w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-amber-300 text-sm sm:text-base flex items-center gap-2">
                <span>🌱</span> Chọn Hạt Giống Cho Ô #{selectedPlotForSeed + 1}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedPlotForSeed(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            {availableSeeds.length === 0 ? (
              <div className="text-center py-6 text-stone-400 text-xs">
                <p>Bạn không có hạt giống nào trong kho!</p>
                <p className="mt-1 text-amber-400">Hãy đến Khu 7 (Thương Cảng) để mua thêm giống cây trồng.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                {availableSeeds.map((item) => {
                  const sp = SPECIES_MAP.get(item.id);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        plantPlot(selectedPlotForSeed, item.id);
                        setSelectedPlotForSeed(null);
                      }}
                      className="flex items-center gap-2 p-2 rounded-xl bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700 text-left transition"
                    >
                      <span className="text-2xl">{item.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-bold text-stone-200 truncate">{item.name}</div>
                        <div className="text-[10px] text-stone-400">Có: {item.count} túi</div>
                        {sp && (
                          <div className="text-[10px] text-amber-400 font-semibold">
                            Bậc {sp.tier} • {sp.growthTime}s
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Select Fertilizer */}
      {selectedPlotForFert !== null && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-emerald-300 text-sm flex items-center gap-1.5">
                <span>🧪</span> Bón Phân Ô #{selectedPlotForFert + 1}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedPlotForFert(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  fertilizePlot(selectedPlotForFert, 'organic');
                  setSelectedPlotForFert(null);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-emerald-500/40 text-left text-emerald-300"
              >
                <div>
                  <div className="font-bold">🌱 Phân Hữu Cơ Siêu Cấp</div>
                  <div className="text-[10px] text-stone-400">+50% đến +100% sản lượng</div>
                </div>
                <span className="text-xs font-bold">Bón ngay</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  fertilizePlot(selectedPlotForFert, 'growth');
                  setSelectedPlotForFert(null);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-amber-500/40 text-left text-amber-300"
              >
                <div>
                  <div className="font-bold">⚡ Phân Kích Thích Tăng Trưởng</div>
                  <div className="text-[10px] text-stone-400">Rút ngắn 35% thời gian chín</div>
                </div>
                <span className="text-xs font-bold">Bón ngay</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  fertilizePlot(selectedPlotForFert, 'crystal');
                  setSelectedPlotForFert(null);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-purple-500/40 text-left text-purple-300"
              >
                <div>
                  <div className="font-bold">💎 Phân Tinh Thể Đột Biến</div>
                  <div className="text-[10px] text-stone-400">Tăng tỷ lệ ra hạt giống quý</div>
                </div>
                <span className="text-xs font-bold">Bón ngay</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Shovel on Rare Crop */}
      {confirmShovelPlot !== null && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-rose-500 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <h3 className="font-bold text-rose-300 text-sm flex items-center gap-2">
              <Shovel className="w-4 h-4 text-rose-400" />
              Xác Nhận Đào Bỏ Nông Sản Quý
            </h3>
            <p className="text-xs text-stone-300">
              Bạn có chắc chắn muốn đào bỏ cây <strong>{confirmShovelPlot.name}</strong> (Bậc {confirmShovelPlot.tier}) trên ô #{confirmShovelPlot.id + 1} không? Hành động này sẽ làm mất hạt giống đang trồng!
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setConfirmShovelPlot(null)}
                className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={() => {
                  shovelPlot(confirmShovelPlot.id);
                  setConfirmShovelPlot(null);
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow"
              >
                Đào Bỏ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
