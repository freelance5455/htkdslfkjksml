import React from 'react';
import { Shield, ShieldCheck, Power, RefreshCw, Zap, ArrowRight, Lock, CheckCircle2, AlertTriangle, ChevronRight } from 'lucide-react';
import { VpnServer, ConnectionStatus, VpnSettings } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';
import { USER_ORIGINAL_NETWORK } from '../data/servers';

interface ConnectionCardProps {
  status: ConnectionStatus;
  currentServer: VpnServer;
  fastestServer: VpnServer;
  settings: VpnSettings;
  sessionTime: number; // in seconds
  language: Language;
  onToggleConnect: () => void;
  onOpenServerModal: () => void;
  onSelectFastestServer: () => void;
}

export const ConnectionCard: React.FC<ConnectionCardProps> = ({
  status,
  currentServer,
  fastestServer,
  settings,
  sessionTime,
  language,
  onToggleConnect,
  onOpenServerModal,
  onSelectFastestServer,
}) => {
  const t = TRANSLATIONS[language];
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';
  const isDisconnecting = status === 'disconnecting';

  // Format session timer HH:MM:SS
  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return [
      hrs > 0 ? String(hrs).padStart(2, '0') : null,
      String(mins).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };

  const isCurrentFastest = currentServer.id === fastestServer.id;

  return (
    <div className="w-full bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center relative overflow-hidden transition-all">
      {/* Background radial gradient spotlight */}
      <div className={`absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-3xl pointer-events-none transition-all duration-700 opacity-20 ${
        isConnected ? 'bg-emerald-500' : isConnecting ? 'bg-indigo-500' : 'bg-slate-400'
      }`} />

      {/* Connection Header & Security Headline */}
      <div className="text-center mb-6 z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold mb-2 transition-colors border">
          {isConnected ? (
            <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 border-emerald-500/20 bg-emerald-500/10">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {t.securedStatus}
            </span>
          ) : isConnecting ? (
            <span className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 border-indigo-500/20 bg-indigo-500/10">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              {t.connecting}
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 border-amber-500/20 bg-amber-500/10">
              <AlertTriangle className="w-3.5 h-3.5" />
              {t.unsecuredStatus}
            </span>
          )}
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          {isConnected
            ? t.connected
            : isConnecting
            ? t.connecting
            : isDisconnecting
            ? t.disconnecting
            : t.disconnected}
        </h2>
        
        {isConnected && (
          <p className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {t.sessionDuration}: <span className="font-semibold text-emerald-600 dark:text-emerald-400">{formatTime(sessionTime)}</span>
          </p>
        )}
      </div>

      {/* Main Big Interactive Connect / Disconnect Toggle Button */}
      <div className="relative my-4 z-10 flex items-center justify-center">
        {/* Animated Glow Rings when connecting or connected */}
        {(isConnected || isConnecting) && (
          <div
            className={`absolute inset-0 -m-3 sm:-m-4 rounded-full border-2 transition-all ${
              isConnected
                ? 'border-emerald-500/30 animate-pulse'
                : 'border-indigo-500/40 animate-ping'
            }`}
          />
        )}
        
        {isConnected && (
          <div className="absolute inset-0 -m-6 sm:-m-7 rounded-full border border-emerald-500/20 animate-pulse duration-1000" />
        )}

        <button
          onClick={onToggleConnect}
          disabled={isConnecting || isDisconnecting}
          className={`relative w-40 h-40 sm:w-48 sm:h-48 rounded-full flex flex-col items-center justify-center gap-2 font-semibold shadow-2xl transition-all transform active:scale-95 cursor-pointer disabled:cursor-not-allowed group ${
            isConnected
              ? 'bg-gradient-to-b from-emerald-500 to-teal-600 text-white shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:brightness-105'
              : isConnecting
              ? 'bg-slate-800 text-slate-300 shadow-indigo-500/20'
              : 'bg-gradient-to-b from-slate-900 to-slate-950 dark:from-slate-800 dark:to-slate-900 text-white border-2 border-slate-700/60 shadow-xl hover:border-indigo-500/80 hover:shadow-indigo-500/20'
          }`}
          aria-label={isConnected ? t.disconnect : t.connect}
        >
          {isConnecting ? (
            <RefreshCw className="w-12 h-12 animate-spin text-indigo-400" />
          ) : isConnected ? (
            <Power className="w-14 h-14 stroke-[2.2] text-white transition-transform group-hover:scale-105" />
          ) : (
            <Power className="w-14 h-14 stroke-[2.2] text-indigo-400 dark:text-indigo-300 transition-transform group-hover:scale-105" />
          )}

          <span className="text-sm sm:text-base font-bold tracking-wide">
            {isConnected
              ? t.disconnect
              : isConnecting
              ? t.connecting
              : isDisconnecting
              ? t.disconnecting
              : t.connect}
          </span>

          <span className="text-[10px] sm:text-xs opacity-75 font-mono">
            {isConnected ? 'WireGuard 256-bit' : 'Click to Shield'}
          </span>
        </button>
      </div>

      {/* Fast Server Quick Recommendation Bar if disconnected or on different server */}
      {!isCurrentFastest && (
        <div className="w-full max-w-md my-3 z-10">
          <button
            onClick={onSelectFastestServer}
            className="w-full py-2 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/15 border border-amber-500/30 flex items-center justify-between text-xs text-amber-700 dark:text-amber-300 transition-colors"
          >
            <span className="flex items-center gap-1.5 font-medium">
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>{t.fastestServer}: <strong>{fastestServer.city}</strong> {fastestServer.flag}</span>
            </span>
            <span className="flex items-center gap-1 font-mono font-semibold text-amber-600 dark:text-amber-400">
              {fastestServer.ping} {t.ms} <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </button>
        </div>
      )}

      {/* Selected Server Bar with 1-Click Modal Trigger */}
      <div className="w-full max-w-md mt-4 z-10">
        <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl filter drop-shadow-sm select-none" role="img" aria-label={currentServer.country}>
              {currentServer.flag}
            </span>
            <div className="text-left">
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.location}
              </div>
              <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>{language === 'bn' ? currentServer.cityBn : currentServer.city},</span>
                <span className="text-slate-600 dark:text-slate-300">{language === 'bn' ? currentServer.countryBn : currentServer.country}</span>
              </div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                Ping: <span className={currentServer.ping < 50 ? 'text-emerald-500 font-semibold' : currentServer.ping < 120 ? 'text-amber-500' : 'text-slate-400'}>{currentServer.ping}ms</span> · Load: {currentServer.load}%
              </div>
            </div>
          </div>

          <button
            onClick={onOpenServerModal}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 transition-colors shrink-0"
          >
            {t.changeLocation}
          </button>
        </div>
      </div>

      {/* Real vs VPN IP Comparison Card */}
      <div className="w-full max-w-md mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs z-10">
        <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-slate-400 dark:text-slate-500 mb-1 font-medium">{t.originalIp}</div>
          <div className="font-mono font-semibold text-slate-700 dark:text-slate-300">
            {USER_ORIGINAL_NETWORK.ip}
          </div>
          <div className="text-[11px] text-slate-500 truncate mt-0.5">
            {USER_ORIGINAL_NETWORK.city}, {USER_ORIGINAL_NETWORK.country}
          </div>
        </div>

        <div className={`p-3 rounded-xl border transition-colors ${
          isConnected
            ? 'bg-emerald-500/5 dark:bg-emerald-500/10 border-emerald-500/30'
            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
        }`}>
          <div className="text-slate-400 dark:text-slate-500 mb-1 font-medium flex items-center justify-between">
            <span>{t.virtualIp}</span>
            {isConnected && <Lock className="w-3 h-3 text-emerald-500" />}
          </div>
          <div className="font-mono font-semibold">
            {isConnected ? (
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">{currentServer.ip}</span>
            ) : (
              <span className="text-slate-400 italic">---.---.---.---</span>
            )}
          </div>
          <div className="text-[11px] text-slate-500 truncate mt-0.5">
            {isConnected ? `${currentServer.city}, ${currentServer.country}` : 'Not protected'}
          </div>
        </div>
      </div>

      {/* Protocol & Kill Switch Security badges */}
      <div className="w-full max-w-md mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium z-10">
        <div className="flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-indigo-500" />
          <span>{t.protocol}: <strong className="text-slate-700 dark:text-slate-200 uppercase">{settings.protocol}</strong></span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className={`w-2 h-2 rounded-full ${settings.killSwitch ? 'bg-emerald-500' : 'bg-slate-400'}`} />
          <span>{t.killSwitch}: <strong className={settings.killSwitch ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}>{settings.killSwitch ? t.killSwitchActive : t.killSwitchDisabled}</strong></span>
        </div>
      </div>
    </div>
  );
};
