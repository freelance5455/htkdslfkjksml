/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Layers } from 'lucide-react';

interface EmptyStateProps {
  message?: string;
  subMessage?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  message = 'এখনও কিছু নেই।',
  subMessage = 'নিচের + বাটন চেপে নতুন যোগ করুন।',
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center my-10 animate-in fade-in duration-300">
      <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mb-3 border border-slate-200/60 shadow-xs">
        <Layers className="w-8 h-8 stroke-1" />
      </div>
      <p className="text-base font-semibold text-slate-700">{message}</p>
      {subMessage && (
        <p className="text-sm text-slate-500 mt-1 max-w-xs">{subMessage}</p>
      )}
    </div>
  );
};
