import React from 'react';
import { Sparkles, Zap, Brain, Code2, Compass, MessageSquareCode } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface EmptyStateProps {
  onSelectPrompt: (prompt: string) => void;
  soundMuted: boolean;
}

const FEATURED_PROMPTS = [
  {
    icon: <Brain className="w-5 h-5 text-cyan-400" />,
    title: 'Physique & Sciences',
    prompt: 'Explique la physique quantique et l\'intrication simplement.',
    desc: 'Vulgarisation claire avec métaphores',
  },
  {
    icon: <Code2 className="w-5 h-5 text-blue-400" />,
    title: 'Génération de Code',
    prompt: 'Écris un script Python pour analyser des données avec asyncio.',
    desc: 'Code moderne, typé et optimisé',
  },
  {
    icon: <Sparkles className="w-5 h-5 text-purple-400" />,
    title: 'Création Littéraire',
    prompt: 'Écris un court poème cyberpunk futuriste sur l\'an 2099.',
    desc: 'Élégance de style et immersion',
  },
  {
    icon: <Compass className="w-5 h-5 text-emerald-400" />,
    title: 'Stratégie & Idées',
    prompt: 'Donne-moi 5 idées de projets technologiques innovants.',
    desc: 'Solutions créatives et concrètes',
  },
];

export const EmptyState: React.FC<EmptyStateProps> = ({ onSelectPrompt, soundMuted }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[55vh] py-8 px-4 text-center max-w-3xl mx-auto">
      {/* Glowing animated orb */}
      <div className="relative mb-6">
        <div className="absolute inset-0 rounded-full bg-cyan-500/20 blur-2xl animate-pulse-subtle" />
        <div className="relative flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-[#0f172a] via-[#162544] to-[#1e3a6a] border-2 border-cyan-400/40 shadow-2xl shadow-cyan-500/30">
          <span className="text-4xl sm:text-5xl select-none">🤖</span>
        </div>
        <div className="absolute -top-1 -right-1 px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-md">
          GPT-6
        </div>
      </div>

      {/* Main Heading & user's original message greeting */}
      <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-cyan-300 via-sky-200 to-blue-400 bg-clip-text text-transparent mb-2">
        GPT-6 Quantum Neural
      </h1>

      <div className="inline-block max-w-xl mx-auto p-4 rounded-2xl bg-[#1d293b]/90 border border-cyan-500/30 shadow-lg text-slate-100 text-base sm:text-lg font-medium mb-8">
        « Bonjour ! Je suis GPT-6. Comment puis-je t'aider ? »
      </div>

      {/* Suggestion prompt cards */}
      <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
        {FEATURED_PROMPTS.map((item, index) => (
          <button
            key={index}
            onClick={() => {
              playSound('click', soundMuted);
              onSelectPrompt(item.prompt);
            }}
            className="group relative flex flex-col p-4 rounded-2xl bg-[#151f33]/80 hover:bg-[#1c2a47] border border-cyan-500/15 hover:border-cyan-400/50 shadow-md hover:shadow-cyan-500/10 transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer text-left"
          >
            <div className="flex items-center gap-2 mb-1.5">
              <div className="p-1.5 rounded-lg bg-slate-900/80 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wide">
                {item.title}
              </span>
            </div>
            <p className="text-sm font-semibold text-slate-200 group-hover:text-white line-clamp-2">
              {item.prompt}
            </p>
            <span className="mt-1 text-[11px] text-slate-400 group-hover:text-slate-300">
              {item.desc}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
