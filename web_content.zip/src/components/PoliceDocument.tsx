import type { ReactNode } from 'react';
import type { ContentBlock, PolicePage, Tone } from '../policeContent';
import PoliceIcon from './PoliceIcon';

const RichText = ({ text }: { text: string }) => {
  const tokens = text.split(/(\*\*[^*]+\*\*|`[^`]+`|__[^_]+__|\*[^*]+\*)/g).filter(Boolean);

  return (
    <>
      {tokens.map((token, index) => {
        if (token.startsWith('**') && token.endsWith('**')) return <strong key={index}>{token.slice(2, -2)}</strong>;
        if (token.startsWith('`') && token.endsWith('`')) return <code key={index}>{token.slice(1, -1)}</code>;
        if (token.startsWith('__') && token.endsWith('__')) return <u key={index}>{token.slice(2, -2)}</u>;
        if (token.startsWith('*') && token.endsWith('*')) return <em key={index}>{token.slice(1, -1)}</em>;
        return <span key={index}>{token}</span>;
      })}
    </>
  );
};

const toneStyles: Record<Tone, { shell: string; title: string; icon: string }> = {
  info: { shell: 'border-police-blue bg-blue-50 text-blue-950', title: 'text-police-blue', icon: 'info' },
  warning: { shell: 'border-amber-500 bg-amber-50 text-amber-950', title: 'text-amber-900', icon: 'warning' },
  danger: { shell: 'border-red-600 bg-red-50 text-red-950', title: 'text-red-800', icon: 'warning' },
  success: { shell: 'border-emerald-600 bg-emerald-50 text-emerald-950', title: 'text-emerald-800', icon: 'check' },
};

const Block = ({ block }: { block: ContentBlock }) => {
  if (block.type === 'paragraph') {
    return <p className="doc-paragraph"><RichText text={block.text} /></p>;
  }

  if (block.type === 'callout') {
    const style = toneStyles[block.tone];
    return (
      <aside className={`doc-callout ${style.shell}`}>
        <div className={`doc-callout-title ${style.title}`}>
          <PoliceIcon name={style.icon} className="h-5 w-5" />
          {block.title}
        </div>
        <p><RichText text={block.text} /></p>
      </aside>
    );
  }

  if (block.type === 'quote') {
    return (
      <figure className="doc-quote">
        {block.title && <figcaption>{block.title}</figcaption>}
        <blockquote>“{block.text}”</blockquote>
      </figure>
    );
  }

  if (block.type === 'bullets') {
    return (
      <ul className="doc-list">
        {block.items.map((item) => (
          <li key={item}><span className="doc-list-mark" /><span><RichText text={item} /></span></li>
        ))}
      </ul>
    );
  }

  if (block.type === 'steps') {
    return (
      <ol className="doc-steps">
        {block.items.map((item, index) => (
          <li key={item.title}>
            <span className="doc-step-number">{index + 1}</span>
            <div><h3>{item.title}</h3><p><RichText text={item.text} /></p></div>
          </li>
        ))}
      </ol>
    );
  }

  if (block.type === 'table') {
    return (
      <div className="doc-table-wrap">
        <table className="doc-table">
          <thead><tr>{block.headers.map((header) => <th key={header}>{header}</th>)}</tr></thead>
          <tbody>
            {block.rows.map((row, rowIndex) => (
              <tr key={`${row[0]}-${rowIndex}`}>{row.map((cell, cellIndex) => <td key={cellIndex}><RichText text={cell} /></td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (block.type === 'decision') {
    return (
      <div className="decision-tree">
        {block.items.map((item, index) => (
          <div className="decision-row" key={`${item.if}-${index}`}>
            <div className="decision-if"><span>IF</span><RichText text={item.if} /></div>
            <div className="decision-arrow" aria-hidden="true">↓</div>
            <div className="decision-then"><span>THEN</span><RichText text={item.then} /></div>
            {item.otherwise && <div className="decision-otherwise"><span>IF NOT</span><RichText text={item.otherwise} /></div>}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="roleplay-block">
      <div className="roleplay-title">ROLEPLAY ACTION TEXT</div>
      {block.lines.map((line) => <code key={line}>{line}</code>)}
    </div>
  );
};

const PoliceDocument = ({ page }: { page: PolicePage }) => {
  const meta: ReactNode[] = [
    <span key="category">{page.category}</span>,
    page.jurisdiction ? <span key="jurisdiction">{page.jurisdiction}</span> : null,
    <span key="status">Training reference</span>,
  ].filter(Boolean) as ReactNode[];

  return (
    <article className="police-document">
      <header className="document-hero">
        <div className="document-kicker">UK POLICE KNOWLEDGE BASE</div>
        <h1>{page.title}</h1>
        <p>{page.summary}</p>
        <div className="document-meta">
          {meta.map((item, index) => <span key={index}>{item}</span>)}
        </div>
      </header>

      <div className="document-notice">
        <PoliceIcon name="info" className="h-5 w-5" />
        <p>Use current law, College of Policing guidance and local force policy. Powers and procedure differ across England and Wales, Scotland, and Northern Ireland.</p>
      </div>

      {page.sections.map((section, index) => (
        <section className="document-section" key={section.title}>
          <div className="section-number">{String(index + 1).padStart(2, '0')}</div>
          <div className="section-content">
            <h2>{section.title}</h2>
            <div className="section-rule" />
            <div className="section-blocks">{section.blocks.map((block, blockIndex) => <Block block={block} key={blockIndex} />)}</div>
          </div>
        </section>
      ))}
    </article>
  );
};

export default PoliceDocument;