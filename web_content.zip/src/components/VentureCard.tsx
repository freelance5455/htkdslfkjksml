import React from 'react';
import {
  Play,
  CheckCircle2,
  Lock,
  Image as ImageIcon,
} from 'lucide-react';
import { VentureConfig } from '../types/game';
import { useGame } from '../context/GameContext';
import { formatNumber, formatTime } from '../utils/formatters';
import { VentureIcon } from './VentureIcon';
import { GuildmasterAvatar } from './GuildmasterAvatar';

interface VentureCardProps {
  venture: VentureConfig;
}

export function VentureCard({ venture }: VentureCardProps) {
  const {
    ventureStates,
    getVentureProfit,
    getVentureCycleTime,
    getVentureCostForMode,
    buyVenture,
    startVentureCycle,
    numberFormat,
  } = useGame();

  const state = ventureStates[venture.id] || {
    count: 0,
    managerHired: false,
    progress: 0,
    isRunning: false,
    lastRunStart: 0,
  };

  const profit = getVentureProfit(venture.id);
  const cycleTime = getVentureCycleTime(venture.id);
  const { count: buyCount, cost: buyCost, canAfford } = getVentureCostForMode(venture.id);

  const isContinuous = cycleTime < 0.1 && state.managerHired;
  const isOwned = state.count > 0;
  const canRunManually = isOwned && !state.managerHired && !state.isRunning;

  // Next milestone calculation
  const nextMilestone = venture.milestones.find((m) => m.count > state.count);
  const prevMilestoneCount = venture.milestones
    .slice()
    .reverse()
    .find((m) => m.count <= state.count)?.count || 0;

  const milestoneProgress = nextMilestone
    ? Math.min(
        100,
        Math.max(
          0,
          ((state.count - prevMilestoneCount) / (nextMilestone.count - prevMilestoneCount)) * 100
        )
      )
    : 100;

  const handleManualRun = () => {
    if (canRunManually) {
      startVentureCycle(venture.id);
    }
  };

  return (
    <div
      className={`group relative rounded-2xl border transition-all duration-200 overflow-hidden ${
        isOwned
          ? `${venture.colorScheme.border} bg-slate-900/80 hover:bg-slate-900 shadow-lg shadow-black/40`
          : 'border-slate-800/60 bg-slate-950/60 opacity-80 hover:opacity-100'
      }`}
    >
      <div className="p-4 sm:p-5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Left Section: Icon & Level & Milestone */}
        <div className="flex items-center gap-3.5 sm:gap-4 shrink-0">
          <div
            onClick={handleManualRun}
            className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center transition-transform select-none p-1 ${
              canRunManually ? 'cursor-pointer active:scale-95 hover:border-amber-400' : 'cursor-default'
            } ${venture.colorScheme.bgGlow} border ${venture.colorScheme.border}`}
          >
            <VentureIcon ventureId={venture.id} className="w-full h-full drop-shadow-md" />

            {/* If unowned, lock badge */}
            {!isOwned && (
              <div className="absolute inset-0 bg-slate-950/75 rounded-2xl flex items-center justify-center backdrop-blur-[1px]">
                <Lock className="w-5 h-5 text-slate-400" />
              </div>
            )}

            {/* Run affordance if owned and idle and manual */}
            {canRunManually && (
              <div className="absolute -bottom-1 -right-1 p-1 bg-amber-500 rounded-full shadow-md animate-bounce">
                <Play className="w-2.5 h-2.5 text-slate-950 fill-slate-950" />
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-cinzel text-base sm:text-lg font-bold text-slate-100 leading-tight">
                {venture.name}
              </h3>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-800 border border-slate-700/60 text-amber-300 tabular-nums">
                Lvl {state.count}
              </span>
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {venture.subtitle}
            </div>

            {/* Milestone micro progress */}
            {nextMilestone ? (
              <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400">
                <span className="tabular-nums">
                  {state.count} / {nextMilestone.count}
                </span>
                <div className="w-16 sm:w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700/60">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-300"
                    style={{ width: `${milestoneProgress}%` }}
                  />
                </div>
                <span className="text-amber-400/90 font-medium text-[10px]">
                  {nextMilestone.label}
                </span>
              </div>
            ) : (
              <div className="text-[11px] text-amber-400/90 font-medium mt-1">
                ★ Max Core Mastery Reached
              </div>
            )}
          </div>
        </div>

        {/* Center: Cycle Profit, Timing, and Progress Bar */}
        <div className="flex-1 flex flex-col justify-center min-w-0 md:px-2">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="text-slate-400">Yield:</span>
              <span className="font-semibold text-amber-300 tabular-nums">
                +{formatNumber(profit, numberFormat)} Gold
              </span>
              {isContinuous && (
                <span className="text-[10px] text-emerald-400 font-medium">
                  ({formatNumber(profit / cycleTime, numberFormat)}/s)
                </span>
              )}
            </div>
            <div className="text-slate-400 tabular-nums text-[11px]">
              {isContinuous ? 'Continuous Flow' : `Cycle: ${formatTime(cycleTime)}`}
            </div>
          </div>

          {/* Production Progress Bar */}
          <div
            onClick={handleManualRun}
            className={`relative h-6 sm:h-7 w-full rounded-xl bg-slate-950 border border-slate-800 overflow-hidden select-none ${
              canRunManually ? 'cursor-pointer hover:border-amber-500/50' : 'cursor-default'
            }`}
          >
            {isOwned ? (
              isContinuous ? (
                <div className="h-full w-full bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-400 animate-pulse opacity-90 flex items-center justify-center">
                  <span className="text-[10px] font-bold tracking-wider text-slate-950 uppercase">
                    ⚡ Automated Rapid Flow
                  </span>
                </div>
              ) : (
                <>
                  <div
                    className={`h-full transition-all ease-linear ${venture.colorScheme.progressBar}`}
                    style={{
                      width: `${Math.min(100, Math.max(0, state.progress * 100))}%`,
                      transitionDuration: state.isRunning ? '60ms' : '0ms',
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-between px-3 text-[11px] font-medium text-slate-200 pointer-events-none">
                    <span className="[text-shadow:0_1px_2px_rgba(0,0,0,0.85)]">
                      {state.managerHired ? (
                        <span className="inline-flex items-center gap-1.5 text-emerald-300">
                          <GuildmasterAvatar ventureId={venture.id} size="sm" className="w-4 h-4 rounded-full ring-1 ring-emerald-400" />
                          <span>Guildmaster Active</span>
                        </span>
                      ) : state.isRunning ? (
                        'In Production...'
                      ) : (
                        <span className="text-amber-300 font-semibold animate-pulse">
                          Click To Produce
                        </span>
                      )}
                    </span>
                    <span className="tabular-nums [text-shadow:0_1px_2px_rgba(0,0,0,0.85)] text-slate-300">
                      {Math.floor(state.progress * 100)}%
                    </span>
                  </div>
                </>
              )
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500 font-medium">
                Not Yet Discovered
              </div>
            )}
          </div>
        </div>

        {/* Right Section: Buy Button */}
        <div className="shrink-0 flex items-center md:items-end justify-end">
          <button
            onClick={() => buyVenture(venture.id)}
            disabled={!canAfford}
            className={`w-full md:w-36 px-4 py-2.5 rounded-xl font-medium transition-all text-left flex flex-col justify-center cursor-pointer ${
              canAfford
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold shadow-md shadow-amber-950/40 active:scale-95'
                : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-75'
            }`}
          >
            <div className="text-xs font-bold leading-none uppercase tracking-wide">
              {isOwned ? `Buy +${buyCount}` : `Found (x${buyCount})`}
            </div>
            <div className="text-xs font-semibold leading-tight mt-0.5 tabular-nums truncate">
              {formatNumber(buyCost, numberFormat)} Gold
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
