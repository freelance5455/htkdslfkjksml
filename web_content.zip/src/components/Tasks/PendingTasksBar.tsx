import React, { useState, useMemo } from 'react';
import {
  BellRing,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Calendar,
  ArrowRight,
  Edit2,
  Check,
  X,
} from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { Task } from '../../types';
import { triggerCelebration } from '../../utils/confetti';

interface PendingTasksBarProps {
  onOpenTaskModal: (task?: Task) => void;
}

// Convert numbers to Bengali digits when language is Bengali
function toBengaliDigits(num: number | string, lang: 'en' | 'bn'): string {
  if (lang !== 'bn') return String(num);
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (d) => bengaliDigits[+d]);
}

// Gentle pleasant completion chime using Web Audio API
function playCompletionChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Tone 1
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc1.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.12); // E5
    gain1.gain.setValueAtTime(0.12, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start();
    osc1.stop(ctx.currentTime + 0.25);

    // Tone 2
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(783.99, ctx.currentTime + 0.1); // G5
    osc2.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.25); // C6
    gain2.gain.setValueAtTime(0.15, ctx.currentTime + 0.1);
    gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.38);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime + 0.1);
    osc2.stop(ctx.currentTime + 0.38);
  } catch {
    // Ignore audio failures if browser blocks autoplay
  }
}

export const PendingTasksBar: React.FC<PendingTasksBarProps> = ({ onOpenTaskModal }) => {
  const { tasks, toggleTaskCompleted, setActiveTab, language, t } = useApp();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'high' | 'today'>('all');
  const [completingTaskId, setCompletingTaskId] = useState<string | null>(null);

  const todayStr = getTodayString();

  // All uncompleted tasks
  const pendingTasks = useMemo(() => {
    return tasks
      .filter((task) => !task.completed)
      .sort((a, b) => {
        // High priority first
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
          return priorityOrder[a.priority] - priorityOrder[b.priority];
        }
        // Due today or overdue first
        const aDate = a.dueDate || '9999-99-99';
        const bDate = b.dueDate || '9999-99-99';
        if (aDate !== bDate) return aDate.localeCompare(bDate);
        // Time order
        const aTime = a.dueTime || '23:59';
        const bTime = b.dueTime || '23:59';
        return aTime.localeCompare(bTime);
      });
  }, [tasks]);

  const pendingCount = pendingTasks.length;
  const overdueCount = useMemo(
    () => pendingTasks.filter((t) => t.dueDate && t.dueDate < todayStr).length,
    [pendingTasks, todayStr]
  );
  const urgentCount = useMemo(
    () => pendingTasks.filter((t) => t.priority === 'high').length,
    [pendingTasks]
  );
  const todayCount = useMemo(
    () => pendingTasks.filter((t) => t.dueDate === todayStr || t.isRoutine).length,
    [pendingTasks, todayStr]
  );

  // Filtered pending tasks for expanded view
  const displayTasks = useMemo(() => {
    if (activeFilter === 'high') {
      return pendingTasks.filter((t) => t.priority === 'high');
    }
    if (activeFilter === 'today') {
      return pendingTasks.filter((t) => t.dueDate === todayStr || t.isRoutine);
    }
    return pendingTasks;
  }, [pendingTasks, activeFilter, todayStr]);

  // First urgent or earliest task for quick glance
  const nextTask = pendingTasks[0];

  // Quick 1-click complete handler
  const handleQuickComplete = (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCompletingTaskId(taskId);
    playCompletionChime();

    setTimeout(() => {
      toggleTaskCompleted(taskId);
      setCompletingTaskId(null);

      // If completing the last pending task, trigger celebration!
      if (pendingTasks.length === 1) {
        triggerCelebration(0.4);
      }
    }, 280);
  };

  // If no tasks exist in the app at all, don't show the bar
  if (tasks.length === 0) {
    return null;
  }

  // If all tasks are completed
  if (pendingCount === 0) {
    if (isDismissed) return null;
    return (
      <div className="mx-4 mt-2 mb-1 p-3 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-green-500/10 dark:from-emerald-950/30 dark:via-teal-950/30 dark:to-green-950/30 border border-emerald-200 dark:border-emerald-800/60 rounded-2xl flex items-center justify-between text-emerald-800 dark:text-emerald-300 shadow-sm transition-all duration-300">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 dark:bg-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold leading-tight">
              {t.allTasksCompletedTitle}
            </h4>
            <p className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80">
              {t.allTasksCompletedDesc}
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsDismissed(true)}
          className="p-1 rounded-lg text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/10 transition-colors"
          title={t.close}
          aria-label={t.close}
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  // Minimized floating / pill view if user dismissed it
  if (isDismissed) {
    return (
      <div className="px-4 mt-2 mb-1 flex justify-end">
        <button
          onClick={() => setIsDismissed(false)}
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-amber-500 text-white dark:bg-amber-600 rounded-full text-xs font-semibold shadow-md shadow-amber-500/20 hover:bg-amber-600 transition-all active:scale-95 animate-pulse"
          title={t.expandPendingBar}
        >
          <BellRing className="w-3.5 h-3.5" />
          <span>
            {toBengaliDigits(pendingCount, language)}{' '}
            {language === 'bn' ? 'টি অসম্পূর্ণ কাজ' : 'Pending Tasks'}
          </span>
          <ChevronDown className="w-3.5 h-3.5 ml-0.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="mx-4 mt-2.5 mb-2 transition-all duration-300">
      <div className="bg-white dark:bg-slate-900 border border-amber-300/80 dark:border-amber-500/30 rounded-2xl shadow-md shadow-amber-500/5 dark:shadow-black/20 overflow-hidden">
        {/* Main Notification Bar Header */}
        <div
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-3 bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-amber-500/15 dark:from-amber-950/40 dark:via-orange-950/20 dark:to-amber-950/40 cursor-pointer select-none"
        >
          <div className="flex items-center justify-between gap-2">
            {/* Left: Icon & Count */}
            <div className="flex items-center space-x-2.5 min-w-0">
              <div className="relative flex-shrink-0">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-sm shadow-amber-500/30">
                  <BellRing className="w-4 h-4 animate-bounce" />
                </div>
                {urgentCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-rose-500 border-2 border-white dark:border-slate-900 rounded-full" />
                )}
              </div>

              <div className="min-w-0">
                <div className="flex items-center space-x-2 flex-wrap">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center">
                    <span className="text-amber-600 dark:text-amber-400 font-extrabold mr-1">
                      {toBengaliDigits(pendingCount, language)}
                    </span>
                    {pendingCount === 1
                      ? t.pendingTasksSingleText
                      : t.pendingTasksCountText}
                  </span>

                  {urgentCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/50">
                      {toBengaliDigits(urgentCount, language)} {t.pendingUrgentBadge}
                    </span>
                  )}

                  {overdueCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800/50">
                      {toBengaliDigits(overdueCount, language)} {t.pendingOverdueBadge}
                    </span>
                  )}
                </div>

                {/* Subtitle / Next Task preview */}
                {nextTask && !isExpanded && (
                  <div className="flex items-center text-[11px] text-slate-600 dark:text-slate-400 truncate mt-0.5">
                    <span className="font-medium text-amber-700 dark:text-amber-400 mr-1.5 flex-shrink-0">
                      {t.nextPendingTaskLabel}:
                    </span>
                    <span className="truncate max-w-[140px] sm:max-w-[180px] font-medium text-slate-700 dark:text-slate-300">
                      {nextTask.title}
                    </span>
                    {nextTask.dueTime && (
                      <span className="ml-1.5 inline-flex items-center text-[10px] text-slate-500 dark:text-slate-400 flex-shrink-0">
                        <Clock className="w-2.5 h-2.5 mr-0.5" />
                        {toBengaliDigits(nextTask.dueTime, language)}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Right: Quick Complete & Expand / Dismiss controls */}
            <div className="flex items-center space-x-1.5 flex-shrink-0">
              {nextTask && !isExpanded && (
                <button
                  type="button"
                  onClick={(e) => handleQuickComplete(nextTask.id, e)}
                  disabled={completingTaskId === nextTask.id}
                  className={`flex items-center space-x-1 px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all ${
                    completingTaskId === nextTask.id
                      ? 'bg-emerald-600 text-white scale-95'
                      : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm shadow-emerald-500/20 active:scale-95'
                  }`}
                  title={t.quickCompleteAction}
                >
                  {completingTaskId === nextTask.id ? (
                    <Check className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Check className="w-3.5 h-3.5" />
                  )}
                  <span className="hidden xs:inline">{t.quickCompleteAction}</span>
                </button>
              )}

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className="p-1 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
                aria-label={isExpanded ? t.minimizePendingBar : t.expandPendingBar}
                title={isExpanded ? t.minimizePendingBar : t.expandPendingBar}
              >
                {isExpanded ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsDismissed(true);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
                aria-label={t.close}
                title={t.minimizePendingBar}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Expanded Drawer: List of Pending Tasks */}
        {isExpanded && (
          <div className="border-t border-slate-100 dark:border-slate-800 p-3 bg-white dark:bg-slate-900 animate-fadeIn">
            {/* Filter Tabs */}
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 text-[11px]">
              <div className="flex space-x-1">
                <button
                  type="button"
                  onClick={() => setActiveFilter('all')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    activeFilter === 'all'
                      ? 'bg-amber-500 text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {t.filterAllPending} ({toBengaliDigits(pendingCount, language)})
                </button>
                {urgentCount > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveFilter('high')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                      activeFilter === 'high'
                        ? 'bg-rose-500 text-white'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {t.filterHighPriority} ({toBengaliDigits(urgentCount, language)})
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setActiveFilter('today')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    activeFilter === 'today'
                      ? 'bg-amber-500 text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {t.filterDueToday} ({toBengaliDigits(todayCount, language)})
                </button>
              </div>

              <span className="text-[10px] text-slate-400 font-medium">
                {toBengaliDigits(displayTasks.length, language)} {language === 'bn' ? 'টি' : 'items'}
              </span>
            </div>

            {/* Tasks Scrollable List */}
            <div className="max-h-56 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {displayTasks.length === 0 ? (
                <div className="text-center py-4 text-xs text-slate-400">
                  {t.noPendingFilterMatch}
                </div>
              ) : (
                displayTasks.map((task) => {
                  const isBeingCompleted = completingTaskId === task.id;
                  const isTaskOverdue = task.dueDate && task.dueDate < todayStr;

                  return (
                    <div
                      key={task.id}
                      className={`group flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                        isBeingCompleted
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 opacity-60 scale-98'
                          : 'bg-slate-50/80 dark:bg-slate-800/50 hover:bg-slate-100/90 dark:hover:bg-slate-800 border-slate-200/80 dark:border-slate-700/60'
                      }`}
                    >
                      {/* Checkbox & Task details */}
                      <div className="flex items-center space-x-2.5 min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={(e) => handleQuickComplete(task.id, e)}
                          disabled={isBeingCompleted}
                          className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                            isBeingCompleted
                              ? 'bg-emerald-500 text-white'
                              : 'border-2 border-slate-300 dark:border-slate-600 text-transparent hover:border-emerald-500 hover:text-emerald-500'
                          }`}
                          aria-label={t.quickCompleteAction}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>

                        <div className="min-w-0 flex-1">
                          <p
                            className={`text-xs font-semibold leading-snug truncate ${
                              isBeingCompleted
                                ? 'line-through text-slate-400'
                                : 'text-slate-800 dark:text-slate-100'
                            }`}
                          >
                            {task.title}
                          </p>

                          <div className="flex items-center space-x-2 mt-0.5 text-[10px] text-slate-500 dark:text-slate-400 flex-wrap">
                            {task.dueDate && (
                              <span
                                className={`inline-flex items-center ${
                                  isTaskOverdue
                                    ? 'text-rose-600 dark:text-rose-400 font-semibold'
                                    : ''
                                }`}
                              >
                                <Calendar className="w-2.5 h-2.5 mr-0.5" />
                                {task.dueDate === todayStr
                                  ? t.pendingTodayBadge
                                  : toBengaliDigits(task.dueDate, language)}
                              </span>
                            )}

                            {task.dueTime && (
                              <span className="inline-flex items-center">
                                <Clock className="w-2.5 h-2.5 mr-0.5" />
                                {toBengaliDigits(task.dueTime, language)}
                              </span>
                            )}

                            {task.alarmEnabled && (
                              <span className="text-amber-500 dark:text-amber-400" title="Alarm Enabled">
                                🔔
                              </span>
                            )}

                            {task.priority === 'high' && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300">
                                {t.priorityHigh}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center space-x-1 ml-2 flex-shrink-0">
                        <button
                          type="button"
                          onClick={() => onOpenTaskModal(task)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 transition-colors"
                          title={t.edit}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Footer Actions */}
            <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('planner');
                  setIsExpanded(false);
                }}
                className="inline-flex items-center text-amber-700 dark:text-amber-400 hover:text-amber-800 font-semibold transition-colors"
              >
                <span>{t.viewAllPendingTasks}</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </button>

              <button
                type="button"
                onClick={() => setIsExpanded(false)}
                className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 font-medium transition-colors"
              >
                {t.minimizePendingBar}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
