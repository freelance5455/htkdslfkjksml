/**
 * SPR - Sahil Powerful Run
 * Free Coins Bonus Modal
 * With Strict Offline 24-Hour Cooldown Timer
 */

import React, { useState } from 'react';
import { X, CheckCircle2, Home, Lock, Sparkles } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';
import { useRewardCooldown } from '../hooks/useRewardCooldown';

interface Props {
  onClose: () => void;
  onRewardClaimed?: () => void;
}

export const FreeCoinsModal: React.FC<Props> = ({ onClose, onRewardClaimed }) => {
  const [justClaimed, setJustClaimed] = useState<boolean>(false);
  const bonusAmount = 500;

  const { isAvailable, countdown, claim } = useRewardCooldown('free_coins', 'COINS');

  const handleClaim = () => {
    if (!isAvailable) return;

    soundManager.playPowerupSound();
    saveManager.addCoins(bonusAmount);
    claim(); // Record offline 24-hour cooldown
    setJustClaimed(true);

    if (onRewardClaimed) onRewardClaimed();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 via-amber-950/40 to-black border-2 border-amber-500/50 rounded-3xl p-6 shadow-[0_0_50px_rgba(245,158,11,0.4)] flex flex-col items-center text-center">
        {/* Top Control Bar */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-amber-500/20 mb-2">
          <span className="text-xs text-amber-400 font-bold tracking-wider uppercase font-display">
            SPR DAILY BONUS
          </span>

          <div className="flex items-center gap-2">
            <button
              id="free-coins-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-3.5 h-3.5" />
              <span>HOME</span>
            </button>

            <button
              id="free-coins-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-[0_0_25px_rgba(245,158,11,0.6)] mb-3 mt-1">
          <span className="text-3xl">🪙</span>
        </div>

        <h2 className="text-2xl font-black text-white uppercase tracking-wider font-display">
          FREE COINS
        </h2>
        <p className="text-xs text-amber-200 mt-1">
          Claim free runner coins once every 24 hours!
        </p>

        <div className="my-5 p-4 bg-slate-800/80 border border-amber-500/30 rounded-2xl w-full">
          <span className="text-xs text-slate-400 uppercase font-semibold">Reward Allowance</span>
          <div className="text-3xl font-black text-amber-400 font-display flex items-center justify-center gap-1 mt-0.5">
            <span>🪙</span>
            <span>+₹{bonusAmount.toLocaleString()}</span>
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold block mt-1">
            {isAvailable ? '✓ Ready to collect right now' : '⏳ 24-Hour timer running'}
          </span>
        </div>

        {justClaimed && (
          <div className="w-full py-3 mb-3 bg-emerald-600/90 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center gap-2 shadow-lg animate-bounce">
            <CheckCircle2 className="w-4 h-4" />
            <span>₹{bonusAmount} Added To Wallet!</span>
          </div>
        )}

        {/* 24-Hour Cooldown Action Button */}
        {!isAvailable ? (
          <div className="w-full flex flex-col items-center gap-1.5">
            <button
              disabled
              className="w-full py-3.5 bg-slate-800/90 border-2 border-slate-700 text-slate-300 font-mono font-black text-sm sm:text-base tracking-wider rounded-2xl flex items-center justify-center gap-2 cursor-not-allowed shadow-inner"
            >
              <Lock className="w-5 h-5 text-amber-400" />
              <span>NEXT COINS IN {countdown}</span>
            </button>
            <p className="text-[11px] text-slate-400 text-center font-medium">
              ⏳ 24-Hour Cooldown active • Continues counting down offline
            </p>
          </div>
        ) : (
          <button
            id="free-coins-btn-claim"
            onClick={handleClaim}
            className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 text-slate-950 font-black text-base uppercase rounded-2xl shadow-[0_0_25px_rgba(245,158,11,0.6)] active:scale-95 transition cursor-pointer font-display flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5 fill-current" />
            <span>CLAIM FREE COINS (+₹{bonusAmount})</span>
          </button>
        )}
      </div>
    </div>
  );
};
