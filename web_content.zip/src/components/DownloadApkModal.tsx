import React, { useState, useEffect } from 'react';
import { X, Download, Smartphone, Terminal, ExternalLink, Check, Copy, Package } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface DownloadApkModalProps {
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ onClose }) => {
  const [copied, setCopied] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    const handlePrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };
    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      soundEngine.playBooster();
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstallable(false);
      }
    } else {
      alert("To install on Android: Tap Chrome's menu (⋮) at top right and choose 'Install App' or 'Add to Home screen'!");
    }
  };

  const copyBuildCommand = () => {
    navigator.clipboard.writeText('npm install && npm run build && npx cap add android && npx cap open android');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                ZIP & ANDROID APK
              </h2>
              <p className="text-xs text-slate-400">
                Download game archive and install on Android
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 text-slate-300 text-xs sm:text-sm">
          {/* Card 1: Direct ZIP Archive Download */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="font-bold text-white text-sm flex items-center gap-2">
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Full Game Source ZIP</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Complete codebase, canvas engine, sound synth, levels & assets.
              </div>
            </div>

            <a
              href="/chroma-rush.zip"
              download="chroma-rush.zip"
              onClick={() => soundEngine.playBooster()}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>DOWNLOAD .ZIP</span>
            </a>
          </div>

          {/* Card 2: Instant Android Standalone App Install */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="font-bold text-white text-sm flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Install on Android Device</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Install as a standalone native-screen Android app with home screen icon & offline play.
              </div>
            </div>

            <button
              onClick={handleInstallPWA}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all shrink-0"
            >
              <Smartphone className="w-4 h-4" />
              <span>INSTALL APP</span>
            </button>
          </div>

          {/* Card 3: Compile Native .apk via Capacitor */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="font-bold text-white text-sm flex items-center gap-2 mb-1.5">
              <Terminal className="w-4 h-4 text-purple-400" />
              <span>Build Native .apk with Android Studio / CLI</span>
            </div>
            <p className="text-slate-400 text-xs mb-3">
              The downloaded ZIP includes pre-configured <code className="text-purple-300 font-mono">capacitor.config.json</code> ready for APK export:
            </p>

            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-300 flex items-center justify-between gap-2 overflow-x-auto">
              <span className="truncate">npm install &amp;&amp; npm run build &amp;&amp; npx cap add android &amp;&amp; npx cap open android</span>
              <button
                onClick={copyBuildCommand}
                title="Copy command"
                className="shrink-0 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="text-[11px] text-slate-400 mt-2">
              Inside Android Studio, select <span className="text-white font-semibold">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</span>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
