import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Package,
  Sparkles,
  HelpCircle,
  FileCode,
  X,
  ArrowDownToLine,
  Layers,
  Cpu,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, triggerInstall, isAndroid, isIOS } = usePWAInstall();
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [activeTab, setActiveTab] = useState<'apk' | 'webapk' | 'builder' | 'source'>('apk');

  if (!isOpen) return null;

  const currentHost = typeof window !== 'undefined' ? window.location.origin : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(
    currentHost || 'https://ais-pre-cgcxmafgxxujlub24fcrwk-971711130966.asia-southeast1.run.app'
  )}`;

  const handleDownloadApk = () => {
    setDownloadStarted(true);
    const link = document.createElement('a');
    link.href = '/api/download/apk';
    link.download = 'yiuvoice-v1.2.0.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloadStarted(false);
    }, 4000);
  };

  const handleDownloadProject = () => {
    const link = document.createElement('a');
    link.href = '/api/download/android-project';
    link.download = 'yiuvoice-android-project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div
        id="apk-download-modal"
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl shadow-cyan-950/60 overflow-hidden my-auto text-slate-100"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-slate-850 to-cyan-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 p-0.5 flex items-center justify-center shadow-md shadow-emerald-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Smartphone className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-100">
                  Android APK & App Download
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  v1.2.0 Release
                </span>
              </div>
              <p className="text-xs text-slate-400">
                ఆండ్రాయిడ్ ఫోన్ కోసం YiuVoice తెలుగు వాయిస్ యాప్ ఇన్‌స్టాలేషన్
              </p>
            </div>
          </div>

          <button
            id="btn-close-apk-modal"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 p-1.5 gap-1 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'apk'
                ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Direct APK (.apk)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('webapk')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'webapk'
                ? 'bg-slate-800 text-cyan-400 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>1-Tap Phone Install</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('builder')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'builder'
                ? 'bg-slate-800 text-amber-400 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>PWABuilder (Signed APK)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('source')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'source'
                ? 'bg-slate-800 text-purple-400 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Android Studio Project (.zip)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* TAB 1: DIRECT APK DOWNLOAD */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/30 to-slate-900 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-sm text-slate-100">
                      yiuvoice-v1.2.0.apk
                    </span>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      58.9 KB
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Android 5.0+ (Lollipop to Android 14+) కోసం సంపూర్ణ అప్లికేషన్ ప్యాకేజీ.
                  </p>
                </div>

                <button
                  id="btn-download-direct-apk"
                  type="button"
                  onClick={handleDownloadApk}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer active:scale-98"
                >
                  <ArrowDownToLine className="w-4 h-4" />
                  <span>{downloadStarted ? 'డౌన్‌లోడ్ అవుతోంది...' : 'Download APK File'}</span>
                </button>
              </div>

              {downloadStarted && (
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>డౌన్‌లోడ్ ప్రారంభమైంది! మీ డౌన్‌లోడ్స్ ఫోల్డర్‌లో ఫైల్ తనిఖీ చేయండి.</span>
                </div>
              )}

              {/* Step-by-Step Installation Instructions */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>ఆండ్రాయిడ్ ఫోన్‌లో APK ఇన్‌స్టాల్ చేసే విధానం (Installation Steps)</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[11px] font-bold text-cyan-300">
                        1
                      </span>
                      <span>APK డౌన్‌లోడ్ చేయండి</span>
                    </div>
                    <p className="text-slate-400 pl-6">
                      పైన ఉన్న 'Download APK File' బటన్ నొక్కి ఫైల్‌ను మీ ఫోన్‌లోకి సేవ్ చేసుకోండి.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[11px] font-bold text-cyan-300">
                        2
                      </span>
                      <span>నోటిఫికేషన్ లేదా ఫైల్స్ తెరవండి</span>
                    </div>
                    <p className="text-slate-400 pl-6">
                      డౌన్‌లోడ్ పూర్తయ్యాక నోటిఫికేషన్ బార్‌లో లేదా Files/Downloads లో ఫైల్ నొక్కండి.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[11px] font-bold text-cyan-300">
                        3
                      </span>
                      <span>Unknown Sources అనుమతించండి</span>
                    </div>
                    <p className="text-slate-400 pl-6">
                      మొదటిసారి అయితే సెట్టింగ్స్‌లో "Allow from this source" ఎనేబుల్ చేయండి.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[11px] font-bold text-cyan-300">
                        4
                      </span>
                      <span>Install క్లిక్ చేయండి</span>
                    </div>
                    <p className="text-slate-400 pl-6">
                      ఇన్‌స్టాల్ నొక్కండి. మీ ఫోన్ హోమ్ స్క్రీన్‌పై YiuVoice ఐకాన్ వస్తుంది!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 1-TAP BROWSER INSTALL (WEBAPK) */}
          {activeTab === 'webapk' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/30 to-slate-900 border border-cyan-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <span className="font-bold text-sm text-slate-100">
                      Official Android WebAPK Direct Install
                    </span>
                  </div>
                  {isInstalled && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>యాప్ ఇన్‌స్టాల్ అయింది</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  ఆండ్రాయిడ్ గూగుల్ క్రోమ్ బ్రౌజర్ ద్వారా ఒక్క క్లిక్‌తో సిస్టమ్-లెవల్ <strong>WebAPK</strong> రూపొందించి నేరుగా మీ ఫోన్‌లో ఇన్‌స్టాల్ చేస్తుంది. అడ్రస్ బార్ లేకుండా ఫుల్‌స్క్రీన్ యాప్‌లా పనిచేస్తుంది.
                </p>

                {isInstallable ? (
                  <button
                    id="btn-trigger-pwa-install"
                    type="button"
                    onClick={triggerInstall}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer active:scale-98"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Install App on this Device (WebAPK)</span>
                  </button>
                ) : isInstalled ? (
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>YiuVoice ఇప్పటికే ఈ పరికరంలో స్టాండలోన్ యాప్‌గా ఇన్‌స్టాల్ చేయబడింది!</span>
                  </div>
                ) : (
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 space-y-2">
                    <div className="font-semibold text-cyan-300">
                      క్రోమ్ / శాంసంగ్ బ్రౌజర్‌లో ఎలా ఇన్‌స్టాల్ చేయాలి:
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-slate-400">
                      <li>బ్రౌజర్ పైన కుడివైపున ఉన్న <strong>మూడు చుక్కలు (⋮)</strong> నొక్కండి.</li>
                      <li><strong>"Install app"</strong> లేదా <strong>"Add to Home screen"</strong> ఎంచుకోండి.</li>
                      <li>ఆండ్రాయిడ్ OS స్వయంచాలకంగా పూర్తి స్థాయి WebAPK ని తయారు చేసి ఇన్‌స్టాల్ చేస్తుంది.</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: PWABUILDER */}
          {activeTab === 'builder' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/30 to-slate-900 border border-amber-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-sm text-slate-100">
                      PWABuilder (Official Microsoft Cloud APK Builder)
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Google Play Ready
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  PWABuilder ద్వారా మీ యాప్‌కి డిజిటల్ సంతకంతో కూడిన (Signed) <strong>Release APK</strong> లేదా Google Play Store కోసం <strong>Android App Bundle (.aab)</strong> ని ఉచితంగా డౌన్‌లోడ్ చేసుకోవచ్చు.
                </p>

                <a
                  id="link-pwabuilder-external"
                  href={pwaBuilderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Open PWABuilder with YiuVoice URL</span>
                </a>
              </div>
            </div>
          )}

          {/* TAB 4: ANDROID STUDIO SOURCE PROJECT */}
          {activeTab === 'source' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/30 to-slate-900 border border-purple-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-purple-400" />
                    <span className="font-bold text-sm text-slate-100">
                      Complete Android Studio Project Source (.zip)
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    24.2 KB
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  పూర్తి Android Studio ప్రాజెక్ట్: <code className="font-mono text-purple-300">AndroidManifest.xml</code>, Gradle 8+, Launcher Icons, మరియు Trusted Web Activity (TWA) కాన్ఫిగరేషన్‌లతో కూడిన సోర్స్ కోడ్.
                </p>

                <button
                  id="btn-download-project-zip"
                  type="button"
                  onClick={handleDownloadProject}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/25 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Android Studio Project (.zip)</span>
                </button>
              </div>
            </div>
          )}

          {/* App Specs Card */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/60">
              <div className="text-slate-400 text-[10px]">Package ID</div>
              <div className="font-mono font-bold text-slate-200 truncate">com.yiuvoice.telugutts</div>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/60">
              <div className="text-slate-400 text-[10px]">Android OS</div>
              <div className="font-bold text-emerald-400">Android 5.0+ (API 21-34)</div>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/60">
              <div className="text-slate-400 text-[10px]">Architecture</div>
              <div className="font-bold text-cyan-400">Trusted Web Activity</div>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/60">
              <div className="text-slate-400 text-[10px]">Safety</div>
              <div className="font-bold text-slate-200 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Verified Safe</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>సురక్షితమైన, వైరస్ లేని అధికారిక YiuVoice ఆండ్రాయిడ్ ప్యాకేజీ</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
