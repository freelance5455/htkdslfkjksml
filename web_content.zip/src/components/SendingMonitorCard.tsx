import React from 'react';
import { Activity, History, Trash2, CheckCircle2 } from 'lucide-react';
import { SendingEntry, CNICRecord, Language } from '../types';
import { formatCNIC } from '../utils/cnic';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface SendingMonitorCardProps {
  records: CNICRecord[];
  sending: SendingEntry[];
  onClearHistory: () => void;
  language: Language;
}

export const SendingMonitorCard: React.FC<SendingMonitorCardProps> = ({
  records,
  sending,
  onClearHistory,
  language,
}) => {
  const tr = t[language];

  const total = records.length;
  const sent = records.filter((r) => r.status === 'Demo').length;
  const remaining = records.filter((r) => r.status === 'Added').length;
  const failed = records.filter((r) => r.status === 'Failed').length;

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.sendingMonitor}
          </h3>
        </div>
        <span className="text-xs font-mono text-cyan-300">
          LOGS: {sending.length}
        </span>
      </div>

      {/* 4 Stats Grid matching: display:grid; grid-template-columns:1fr 1fr; gap:10px; */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
        <div className="p-3 bg-[#0c1d32] border border-[#244b70] rounded-xl text-center shadow-sm">
          <div id="total" className="text-2xl sm:text-3xl font-bold font-mono text-[#45eaff] tabular-nums">
            {total}
          </div>
          <small className="text-xs text-[#b8d4eb] font-medium block mt-0.5">{tr.total}</small>
        </div>

        <div className="p-3 bg-[#0c1d32] border border-[#244b70] rounded-xl text-center shadow-sm">
          <div id="sent" className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400 tabular-nums">
            {sent}
          </div>
          <small className="text-xs text-[#b8d4eb] font-medium block mt-0.5">{tr.sentDemo}</small>
        </div>

        <div className="p-3 bg-[#0c1d32] border border-[#244b70] rounded-xl text-center shadow-sm">
          <div id="remaining" className="text-2xl sm:text-3xl font-bold font-mono text-amber-300 tabular-nums">
            {remaining}
          </div>
          <small className="text-xs text-[#b8d4eb] font-medium block mt-0.5">{tr.remaining}</small>
        </div>

        <div className="p-3 bg-[#0c1d32] border border-[#244b70] rounded-xl text-center shadow-sm">
          <div id="failed" className="text-2xl sm:text-3xl font-bold font-mono text-rose-400 tabular-nums">
            {failed}
          </div>
          <small className="text-xs text-[#b8d4eb] font-medium block mt-0.5">{tr.failed}</small>
        </div>
      </div>

      {/* Sending History Section */}
      <div className="pt-2">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-[#41eaff] text-sm font-bold">
            <History className="w-4 h-4 text-cyan-400" />
            <span>{tr.sendingHistory}</span>
          </div>
          {sending.length > 0 && (
            <button
              onClick={() => {
                onClearHistory();
                sounds.playClick();
              }}
              className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors cursor-pointer"
              title="Clear sending logs"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          )}
        </div>

        <div
          id="sending"
          className="bg-[#07111f] border border-[#244968] rounded-xl p-2 min-h-[70px] max-h-[190px] overflow-y-auto space-y-1.5 font-mono text-xs"
        >
          {sending.length === 0 ? (
            <div className="flex items-center justify-center h-14 text-slate-400 text-xs text-center font-mono">
              {tr.noActivity}
            </div>
          ) : (
            sending.map((entry) => (
              <div
                key={entry.id}
                className="item p-2 rounded-lg bg-[#091729] border border-[#1b3651] text-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] leading-relaxed"
              >
                <div className="flex items-center gap-1.5 overflow-hidden">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="font-bold text-cyan-200">
                    {formatCNIC(entry.cnic)}
                  </span>
                  <span className="text-slate-500">|</span>
                  <span className="text-cyan-400 font-semibold">
                    Dest: {entry.destination}
                  </span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-300 truncate">
                    {entry.sim}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-slate-400 text-[10px] shrink-0">
                  <span className="text-emerald-400 font-semibold">{entry.status}</span>
                  <span>·</span>
                  <span>{entry.time}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
