import React, { useState } from 'react';
import {
  Download,
  X,
  Tablet,
  CheckCircle2,
  Smartphone,
  Share2,
  PlusSquare,
  Sparkles,
  Monitor,
  ExternalLink,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install, isIOS, isAndroid } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'pc'>(() => {
    if (isIOS) return 'ios';
    return 'android';
  });
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDirectInstall = async () => {
    const success = await install();
    if (success) {
      setInstallSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-neutral-900 border border-neutral-800 p-6 text-white shadow-2xl overflow-y-auto max-h-[90vh]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white transition"
        >
          <X className="h-6 w-6" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 text-neutral-950 font-black shadow-lg shadow-amber-500/20">
            <Download className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Como Baixar o App no Tablet</h3>
            <p className="text-xs text-neutral-400">Instalação direta e sem complicações</p>
          </div>
        </div>

        {/* Direct One-Click Install Button if supported by browser */}
        {isInstallable && !isInstalled && (
          <div className="mb-5 rounded-2xl bg-amber-500/10 border-2 border-amber-500/40 p-4 text-center space-y-2">
            <p className="text-sm font-semibold text-amber-300">
              Seu tablet é compatível com instalação em 1 clique!
            </p>
            <button
              onClick={handleDirectInstall}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 py-3 px-4 font-bold text-neutral-950 shadow-md shadow-amber-500/20 transition active:scale-95"
            >
              <Download className="h-5 w-5" />
              <span>{installSuccess ? 'Instalado com Sucesso!' : 'Baixar / Instalar App Agora'}</span>
            </button>
            <p className="text-[11px] text-neutral-400">
              O ícone dourado do app surgirá na tela inicial do seu tablet.
            </p>
          </div>
        )}

        {/* If already running as installed app */}
        {isInstalled && (
          <div className="mb-5 flex items-center gap-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 p-4 text-emerald-300 text-sm font-medium">
            <CheckCircle2 className="h-6 w-6 text-emerald-400 shrink-0" />
            <span>Este aplicativo já está instalado e rodando em modo aplicativo!</span>
          </div>
        )}

        {/* Device Selection Tabs */}
        <div className="flex rounded-2xl bg-neutral-950 p-1 border border-neutral-800 mb-5">
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'android'
                ? 'bg-neutral-800 text-amber-400 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Smartphone className="h-4 w-4" />
            <span>Tablet Android (Samsung/Outros)</span>
          </button>
          <button
            onClick={() => setActiveTab('ios')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'ios'
                ? 'bg-neutral-800 text-amber-400 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Tablet className="h-4 w-4" />
            <span>iPad / iPhone (Apple)</span>
          </button>
          <button
            onClick={() => setActiveTab('pc')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'pc'
                ? 'bg-neutral-800 text-amber-400 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Monitor className="h-4 w-4" />
            <span>PC / Notebook</span>
          </button>
        </div>

        {/* Tab Content: Android */}
        {activeTab === 'android' && (
          <div className="space-y-3.5 text-sm text-neutral-300">
            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                1
              </span>
              <div>
                <p className="font-semibold text-white">Abra o Google Chrome no seu tablet</p>
                <p className="text-xs text-neutral-400">Acesse o link do sistema no tablet da igreja.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                2
              </span>
              <div>
                <p className="font-semibold text-white">Toque nos 3 pontinhos (⋮) no topo direito</p>
                <p className="text-xs text-neutral-400">
                  É o menu de opções do navegador Chrome.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                3
              </span>
              <div>
                <p className="font-semibold text-white">
                  Selecione &quot;Instalar aplicativo&quot; ou &quot;Adicionar à tela inicial&quot;
                </p>
                <p className="text-xs text-neutral-400">
                  Confirme tocando em <strong>&quot;Instalar&quot;</strong>.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-amber-500/10 p-3.5 border border-amber-500/30">
              <CheckCircle2 className="h-6 w-6 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-300">Pronto!</p>
                <p className="text-xs text-neutral-300">
                  O ícone do <strong>Elo Igreja</strong> ficará salvo na área de trabalho do tablet. Quando você abrir, ele abre em <strong>tela cheia</strong>, sem barra de navegador, exatamente como um aplicativo da Play Store!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab Content: iOS (iPad / iPhone) */}
        {activeTab === 'ios' && (
          <div className="space-y-3.5 text-sm text-neutral-300">
            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                1
              </span>
              <div>
                <p className="font-semibold text-white">Abra no navegador Safari do iPad</p>
                <p className="text-xs text-neutral-400">Acesse o link do aplicativo.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                2
              </span>
              <div>
                <p className="font-semibold text-white flex items-center gap-1.5">
                  Toque no botão de Compartilhar <Share2 className="h-4 w-4 text-amber-400" />
                </p>
                <p className="text-xs text-neutral-400">
                  É o ícone do quadrado com a setinha apontando para cima (no topo ou rodapé do iPad).
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                3
              </span>
              <div>
                <p className="font-semibold text-white flex items-center gap-1.5">
                  Toque em &quot;Adicionar à Tela de Início&quot; <PlusSquare className="h-4 w-4 text-amber-400" />
                </p>
                <p className="text-xs text-neutral-400">
                  Role o menu para baixo se necessário e clique em &quot;Adicionar&quot;.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-amber-500/10 p-3.5 border border-amber-500/30">
              <CheckCircle2 className="h-6 w-6 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-300">Aplicativo Instalado no iPad!</p>
                <p className="text-xs text-neutral-300">
                  Ele vira um app independente na tela do iPad, funcionando sem as abas do Safari.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab Content: PC / Notebook */}
        {activeTab === 'pc' && (
          <div className="space-y-3.5 text-sm text-neutral-300">
            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                1
              </span>
              <div>
                <p className="font-semibold text-white">No Chrome ou Edge do computador</p>
                <p className="text-xs text-neutral-400">
                  Repare que aparece um pequeno ícone de computador com uma setinha de download na barra de endereço (onde você digita o link).
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-2xl bg-neutral-800/60 p-3.5 border border-neutral-700/60">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 font-bold text-neutral-950 text-xs shrink-0">
                2
              </span>
              <div>
                <p className="font-semibold text-white">Clique em &quot;Instalar Elo Igreja&quot;</p>
                <p className="text-xs text-neutral-400">
                  Ele cria um atalho na área de trabalho e no menu Iniciar do Windows / Mac.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="w-full rounded-xl bg-neutral-800 py-3 font-semibold text-neutral-200 hover:bg-neutral-700 transition"
          >
            Entendi, Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
