import React from 'react';
import { Smartphone, Download, CheckCircle, Terminal, HelpCircle, X, ShieldAlert } from 'lucide-react';

interface InstallGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallGuideModal: React.FC<InstallGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-base">How to Install APK on Android</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 leading-relaxed">
          {/* Method 1: Direct phone download */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center gap-2 font-semibold text-white text-sm">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">
                1
              </span>
              <span>Method 1: Direct Side-load on Android Phone</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 pl-2 text-slate-400">
              <li>Download the <strong className="text-white">.apk</strong> file onto your Android device (or send it via Telegram/Drive/USB).</li>
              <li>Open your phone's <strong className="text-white">Files</strong> or Downloads app.</li>
              <li>Tap the <strong className="text-white">.apk</strong> file.</li>
              <li>
                If prompted, tap <strong className="text-emerald-400">Settings</strong> and toggle on{' '}
                <strong className="text-white">"Allow from this source"</strong> (Install unknown apps).
              </li>
              <li>Tap <strong className="text-emerald-400">Install</strong>, and tap <strong className="text-white">Open</strong> to launch!</li>
            </ol>
          </div>

          {/* Method 2: ADB Command Line */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center gap-2 font-semibold text-white text-sm">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">
                2
              </span>
              <span>Method 2: Fast USB Install via ADB (Developers)</span>
            </div>
            <p className="text-slate-400">
              Enable USB Debugging on your phone, connect to computer, and run:
            </p>
            <pre className="p-2.5 bg-slate-900 rounded font-mono text-[11px] text-emerald-300 border border-slate-800 select-all">
              adb install -r my_app_v1.0.0.apk
            </pre>
            <p className="text-[11px] text-slate-500">
              The <code className="text-slate-400">-r</code> flag allows upgrading an existing installation without losing user data or cookies.
            </p>
          </div>

          {/* Method 3: Android Studio Project */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center gap-2 font-semibold text-white text-sm">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">
                3
              </span>
              <span>Method 3: Android Studio & Google Play Store</span>
            </div>
            <p className="text-slate-400">
              Download the companion <strong className="text-white">Android Studio Project (.zip)</strong> to open the full Java/Kotlin source code, customize native features, and publish directly to the Google Play Store as an AAB (Android App Bundle).
            </p>
          </div>

          {/* Play Protect Notice */}
          <div className="p-3 bg-amber-950/30 border border-amber-800/60 rounded-xl flex items-start gap-2.5 text-amber-200">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-[11px]">
              <strong className="block font-semibold">Google Play Protect notice:</strong>
              Because this APK is signed with a newly generated custom keystore certificate, Android will show a standard prompt "Unrecognized app developer". Simply tap <em>"More details &gt; Install anyway"</em>.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
