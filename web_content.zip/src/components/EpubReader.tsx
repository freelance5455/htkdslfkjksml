import React, { useEffect, useRef, useState, useCallback } from 'react';
import ePub, { Book as EpubBookInstance, Rendition } from 'epubjs';
import {
  ChevronLeft,
  ChevronRight,
  List,
  Highlighter,
  Trash2,
  X,
  Type,
  Maximize2,
  Minimize2,
  ArrowLeft,
  Check,
  Bookmark,
  ScrollText,
  BookOpen
} from 'lucide-react';
import { EpubHighlight, EpubTocItem } from '../types/epub';
import { epubStorage } from '../services/epubStorage';

interface EpubReaderProps {
  bookId: string;
  bookBuffer: ArrayBuffer;
  bookTitle: string;
  bookAuthor: string;
  fileName: string;
  onClose: () => void;
}

const HIGHLIGHT_COLORS = [
  { id: 'yellow', name: 'Amarillo', hex: '#facc15', bgClass: 'bg-yellow-400' },
  { id: 'green', name: 'Verde', hex: '#4ade80', bgClass: 'bg-green-400' },
  { id: 'blue', name: 'Azul', hex: '#60a5fa', bgClass: 'bg-blue-400' },
  { id: 'pink', name: 'Rosa', hex: '#f472b6', bgClass: 'bg-pink-400' },
  { id: 'purple', name: 'Morado', hex: '#c084fc', bgClass: 'bg-purple-400' },
];

export const EpubReader: React.FC<EpubReaderProps> = ({
  bookId,
  bookBuffer,
  bookTitle,
  bookAuthor,
  fileName,
  onClose,
}) => {
  const viewerRef = useRef<HTMLDivElement>(null);
  const bookRef = useRef<EpubBookInstance | null>(null);
  const renditionRef = useRef<Rendition | null>(null);

  // Status & Reading states
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [currentTitle, setCurrentTitle] = useState(bookTitle || fileName);
  const [currentAuthor, setCurrentAuthor] = useState(bookAuthor || '');
  const [readingPercentage, setReadingPercentage] = useState<number>(0);
  const [currentChapter, setCurrentChapter] = useState<string>('');
  const [currentCfi, setCurrentCfi] = useState<string>('');

  // Reader Settings
  const [fontSize, setFontSize] = useState<number>(100);
  const [flowMode, setFlowMode] = useState<'scrolled-doc' | 'paginated'>('scrolled-doc');

  // Navigation & TOC
  const [toc, setToc] = useState<EpubTocItem[]>([]);
  const [isTocOpen, setIsTocOpen] = useState(false);

  // Highlights state
  const [highlights, setHighlights] = useState<EpubHighlight[]>([]);
  const [isHighlightsDrawerOpen, setIsHighlightsDrawerOpen] = useState(false);
  const [activeSelection, setActiveSelection] = useState<{
    cfiRange: string;
    text: string;
    x: number;
    y: number;
  } | null>(null);
  const [selectedColor, setSelectedColor] = useState<string>(HIGHLIGHT_COLORS[0].hex);

  // Quick feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 1. Load book and saved state
  useEffect(() => {
    let isCancelled = false;

    const initBook = async () => {
      try {
        setLoading(true);
        setLoadError(null);

        if (!viewerRef.current) return;

        // Cleanup any previous instance
        if (renditionRef.current) {
          renditionRef.current.destroy();
          renditionRef.current = null;
        }
        if (bookRef.current) {
          bookRef.current.destroy();
          bookRef.current = null;
        }
        viewerRef.current.innerHTML = '';

        // Initialize ePub from ArrayBuffer
        const book = ePub(bookBuffer);
        bookRef.current = book;

        // Extract metadata
        book.loaded.metadata.then((meta) => {
          if (!isCancelled) {
            if (meta.title) setCurrentTitle(meta.title);
            if (meta.creator) setCurrentAuthor(meta.creator);
          }
        }).catch(() => {});

        // Extract TOC
        book.loaded.navigation.then((nav) => {
          if (!isCancelled && nav && nav.toc) {
            const formatToc = (items: any[]): EpubTocItem[] => {
              return items.map((item) => ({
                id: item.id || item.href,
                label: item.label ? item.label.trim() : 'Capítulo',
                href: item.href,
                subitems: item.subitems ? formatToc(item.subitems) : undefined,
              }));
            };
            setToc(formatToc(nav.toc));
          }
        }).catch(() => {});

        // Configure Rendition
        const rendition = book.renderTo(viewerRef.current, {
          width: '100%',
          height: '100%',
          flow: flowMode,
          spread: 'none',
          allowScriptedContent: true,
        });
        renditionRef.current = rendition;

        // Apply dark theme styles to epubjs rendered iframe
        rendition.themes.default({
          body: {
            color: '#e4e4e7 !important',
            background: '#09090b !important',
            'font-family': 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important',
            'line-height': '1.75 !important',
            padding: '16px 12px 60px 12px !important',
            margin: '0 auto !important',
            'max-width': '720px !important',
            '-webkit-text-size-adjust': '100% !important',
          },
          p: {
            color: '#e4e4e7 !important',
            'font-size': '1.05rem !important',
            'margin-bottom': '1.25rem !important',
            'line-height': '1.75 !important',
          },
          'h1, h2, h3, h4': {
            color: '#ffffff !important',
            'margin-top': '1.8rem !important',
            'margin-bottom': '1rem !important',
            'font-weight': '700 !important',
          },
          a: {
            color: '#60a5fa !important',
            'text-decoration': 'underline !important',
          },
          blockquote: {
            'border-left': '3px solid #3b82f6 !important',
            'margin-left': '0 !important',
            'padding-left': '1rem !important',
            color: '#a1a1aa !important',
            'font-style': 'italic !important',
          },
          img: {
            'max-width': '100% !important',
            height: 'auto !important',
            'border-radius': '8px !important',
            margin: '12px auto !important',
          },
          '::selection': {
            background: 'rgba(59, 130, 246, 0.45) !important',
            color: '#ffffff !important',
          },
        });

        // Load saved highlights from IndexedDB
        const savedHighlights = await epubStorage.getHighlights(bookId);
        if (!isCancelled) {
          setHighlights(savedHighlights);
        }

        // Hook selection event
        rendition.on('selected', (cfiRange: string, contents: any) => {
          if (!cfiRange) return;

          let text = '';
          try {
            const range = rendition.getRange(cfiRange);
            if (range) text = range.toString().trim();
          } catch {
            text = contents?.window?.getSelection?.()?.toString()?.trim() || '';
          }

          if (text) {
            // Calculate screen position for the selection floating bar
            let x = window.innerWidth / 2;
            let y = 140;
            try {
              const range = rendition.getRange(cfiRange);
              const rect = range?.getBoundingClientRect();
              const iframe = viewerRef.current?.querySelector('iframe');
              const iframeRect = iframe?.getBoundingClientRect();
              if (rect && iframeRect) {
                x = iframeRect.left + rect.left + rect.width / 2;
                y = iframeRect.top + rect.top - 10;
              }
            } catch {
              // fallback centered
            }

            // Keep within viewport bounds
            x = Math.max(140, Math.min(window.innerWidth - 140, x));
            y = Math.max(80, Math.min(window.innerHeight - 100, y));

            setActiveSelection({
              cfiRange,
              text,
              x,
              y,
            });
          }
        });

        // Register content hooks for touch/mobile selection handling in WebView
        rendition.hooks.content.register((contents: any) => {
          const doc = contents.document;
          if (!doc) return;

          // Clear selection floating toolbar on click outside
          doc.addEventListener('click', () => {
            const sel = contents.window?.getSelection?.();
            if (!sel || sel.isCollapsed) {
              setActiveSelection(null);
            }
          });
        });

        // Track relocated location & save reading progress to IndexedDB
        rendition.on('relocated', (location: any) => {
          if (!location || !location.start || isCancelled) return;

          const cfi = location.start.cfi;
          setCurrentCfi(cfi);

          // Approximate or precise percentage
          let pct = 0;
          if (location.start.percentage !== undefined) {
            pct = Math.round(location.start.percentage * 100);
          } else if (book.locations && book.locations.length()) {
            pct = Math.round(book.locations.percentageFromCfi(cfi) * 100);
          }
          pct = Math.min(100, Math.max(0, pct));
          setReadingPercentage(pct);

          // Find chapter label matching current href
          const currentHref = location.start.href;
          if (currentHref) {
            book.loaded.navigation.then((nav) => {
              const findChapter = (items: any[]): string | null => {
                for (const item of items) {
                  if (item.href && currentHref.includes(item.href.split('#')[0])) {
                    return item.label ? item.label.trim() : null;
                  }
                  if (item.subitems) {
                    const sub = findChapter(item.subitems);
                    if (sub) return sub;
                  }
                }
                return null;
              };
              const found = findChapter(nav.toc || []);
              if (found) setCurrentChapter(found);
            }).catch(() => {});
          }

          // Persist progress in IndexedDB
          epubStorage.saveProgress({
            bookId,
            cfi,
            percentage: pct,
            chapterTitle: currentChapter,
            updatedAt: Date.now(),
          }).catch((err) => console.warn('Error saving progress:', err));
        });

        // Check for saved reading position
        const savedProgress = await epubStorage.getProgress(bookId);

        // Display book at saved CFI or at beginning
        if (savedProgress && savedProgress.cfi) {
          await rendition.display(savedProgress.cfi);
          setReadingPercentage(savedProgress.percentage || 0);
          if (savedProgress.chapterTitle) setCurrentChapter(savedProgress.chapterTitle);
        } else {
          await rendition.display();
        }

        // Re-apply all saved highlights onto the rendition
        savedHighlights.forEach((hl) => {
          try {
            rendition.annotations.add('highlight', hl.cfiRange, {}, undefined, 'epub-custom-highlight', {
              fill: hl.color || '#facc15',
              'fill-opacity': '0.4',
            });
          } catch (e) {
            console.warn('Could not apply highlight to rendition', hl.cfiRange, e);
          }
        });

        // Generate locations in background for accurate reading percentages
        book.ready.then(() => {
          return book.locations.generate(1000);
        }).then(() => {
          if (!isCancelled && renditionRef.current) {
            const loc = renditionRef.current.currentLocation();
            if (loc && loc.start) {
              const precisePct = Math.round(book.locations.percentageFromCfi(loc.start.cfi) * 100);
              if (!isNaN(precisePct)) {
                setReadingPercentage(Math.min(100, Math.max(0, precisePct)));
              }
            }
          }
        }).catch(() => {});

        if (!isCancelled) {
          setLoading(false);
        }
      } catch (err: any) {
        console.error('Error loading EPUB book:', err);
        if (!isCancelled) {
          setLoadError(err?.message || 'No se pudo abrir el archivo EPUB. Verifica que sea un archivo válido.');
          setLoading(false);
        }
      }
    };

    initBook();

    return () => {
      isCancelled = true;
      if (renditionRef.current) {
        try {
          renditionRef.current.destroy();
        } catch {}
      }
      if (bookRef.current) {
        try {
          bookRef.current.destroy();
        } catch {}
      }
    };
  }, [bookId, bookBuffer, flowMode]);

  // Handle Create Highlight
  const handleCreateHighlight = async (colorHex: string) => {
    if (!activeSelection || !renditionRef.current) return;

    const { cfiRange, text } = activeSelection;

    try {
      // 1. Add visual annotation to epub rendition
      renditionRef.current.annotations.add(
        'highlight',
        cfiRange,
        {},
        undefined,
        'epub-custom-highlight',
        {
          fill: colorHex,
          'fill-opacity': '0.4',
        }
      );

      // 2. Save in IndexedDB
      const newHighlight: EpubHighlight = {
        id: `hl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        bookId,
        cfiRange,
        text,
        color: colorHex,
        createdAt: Date.now(),
      };

      await epubStorage.saveHighlight(newHighlight);
      setHighlights((prev) => [...prev, newHighlight]);
      setActiveSelection(null);
      showToast('Texto resaltado y guardado');
    } catch (err) {
      console.error('Error creating highlight:', err);
      showToast('Error al crear el resaltado');
    }
  };

  // Handle Delete Highlight
  const handleDeleteHighlight = async (hl: EpubHighlight) => {
    try {
      if (renditionRef.current) {
        renditionRef.current.annotations.remove(hl.cfiRange, 'highlight');
      }
      await epubStorage.deleteHighlight(hl.id);
      setHighlights((prev) => prev.filter((item) => item.id !== hl.id));
      showToast('Resaltado eliminado');
    } catch (err) {
      console.error('Error deleting highlight:', err);
      showToast('Error al eliminar');
    }
  };

  // Jump to location
  const handleJumpToCfi = (cfi: string) => {
    if (renditionRef.current) {
      renditionRef.current.display(cfi);
      setIsTocOpen(false);
      setIsHighlightsDrawerOpen(false);
    }
  };

  // Navigation handlers
  const handleNext = () => {
    if (renditionRef.current) {
      renditionRef.current.next();
    }
  };

  const handlePrev = () => {
    if (renditionRef.current) {
      renditionRef.current.prev();
    }
  };

  // Font size handlers
  const handleZoomIn = () => {
    const newSize = Math.min(180, fontSize + 10);
    setFontSize(newSize);
    if (renditionRef.current) {
      renditionRef.current.themes.fontSize(`${newSize}%`);
    }
  };

  const handleZoomOut = () => {
    const newSize = Math.max(70, fontSize - 10);
    setFontSize(newSize);
    if (renditionRef.current) {
      renditionRef.current.themes.fontSize(`${newSize}%`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-zinc-950 text-zinc-100 select-none overflow-hidden">
      {/* --- TOP CONTROL BAR --- */}
      <header className="h-14 bg-zinc-900/90 backdrop-blur-md border-b border-zinc-800 flex items-center justify-between px-3 sm:px-5 shrink-0 z-20">
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={onClose}
            className="p-2 -ml-1 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800/80 active:scale-95 transition-all flex items-center gap-1.5 text-xs font-semibold"
            title="Volver a la selección de libro"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="hidden sm:inline">Libros</span>
          </button>

          <div className="min-w-0 pr-2">
            <h1 className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-xs md:max-w-md">
              {currentTitle}
            </h1>
            <p className="text-[11px] text-zinc-400 truncate max-w-[200px] sm:max-w-xs">
              {currentAuthor ? `${currentAuthor} • ` : ''}
              {currentChapter || `${readingPercentage}% leído`}
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Progress Badge */}
          <div className="px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold font-mono">
            {readingPercentage}%
          </div>

          {/* Font Size controls */}
          <div className="hidden sm:flex items-center bg-zinc-800/60 rounded-xl p-0.5 border border-zinc-700/50">
            <button
              onClick={handleZoomOut}
              className="p-1.5 text-zinc-300 hover:text-white rounded-lg hover:bg-zinc-700/50 text-xs font-bold"
              title="Reducir tamaño de letra"
            >
              A-
            </button>
            <span className="text-[10px] px-1 text-zinc-400 font-mono">{fontSize}%</span>
            <button
              onClick={handleZoomIn}
              className="p-1.5 text-zinc-300 hover:text-white rounded-lg hover:bg-zinc-700/50 text-xs font-bold"
              title="Aumentar tamaño de letra"
            >
              A+
            </button>
          </div>

          {/* Highlights Drawer button */}
          <button
            onClick={() => setIsHighlightsDrawerOpen(true)}
            className={`p-2 rounded-xl border transition-all relative ${
              highlights.length > 0
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                : 'bg-zinc-800/60 border-zinc-700/50 text-zinc-400 hover:text-white'
            }`}
            title="Ver resaltados guardados"
          >
            <Highlighter className="w-4 h-4" />
            {highlights.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-black font-extrabold text-[10px] rounded-full flex items-center justify-center">
                {highlights.length}
              </span>
            )}
          </button>

          {/* Table of Contents Button */}
          <button
            onClick={() => setIsTocOpen(true)}
            className="p-2 bg-zinc-800/60 border border-zinc-700/50 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 active:scale-95 transition-all"
            title="Índice de capítulos"
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* --- MAIN EPUB CONTAINER --- */}
      <main className="flex-1 relative overflow-hidden bg-zinc-950 flex flex-col">
        {loading && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-zinc-950/90 backdrop-blur-sm gap-3">
            <div className="w-10 h-10 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
            <p className="text-sm font-medium text-zinc-300">Cargando libro EPUB...</p>
            <p className="text-xs text-zinc-500">Restaurando posición y resaltados locales</p>
          </div>
        )}

        {loadError && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center p-6 text-center bg-zinc-950">
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 mb-3">
              <X className="w-6 h-6" />
            </div>
            <h2 className="text-base font-bold text-white mb-1">Error al procesar el archivo</h2>
            <p className="text-xs text-red-300 max-w-sm mb-5 leading-relaxed">{loadError}</p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs font-semibold text-white shadow-lg transition-all"
            >
              Seleccionar otro archivo EPUB
            </button>
          </div>
        )}

        {/* EPUB.js renderer target div */}
        <div
          ref={viewerRef}
          className="w-full h-full flex-1 overflow-y-auto"
          style={{ WebkitOverflowScrolling: 'touch' }}
        />

        {/* --- FLOATING "RESALTAR" TOOLBAR --- */}
        {activeSelection && (
          <div
            className="fixed z-40 -translate-x-1/2 -translate-y-full mb-2 bg-zinc-900 border border-zinc-700 rounded-2xl p-2 shadow-2xl shadow-black/80 flex items-center gap-2 animate-fadeIn"
            style={{
              left: `${activeSelection.x}px`,
              top: `${activeSelection.y}px`,
            }}
          >
            <div className="flex items-center gap-1.5 pl-1">
              {HIGHLIGHT_COLORS.map((col) => (
                <button
                  key={col.id}
                  onClick={() => handleCreateHighlight(col.hex)}
                  className={`w-6 h-6 rounded-full transition-transform hover:scale-110 active:scale-95 flex items-center justify-center ${col.bgClass}`}
                  title={`Resaltar con ${col.name}`}
                >
                  {selectedColor === col.hex && <Check className="w-3.5 h-3.5 text-zinc-950 font-bold" />}
                </button>
              ))}
            </div>

            <div className="w-px h-5 bg-zinc-800" />

            <button
              onClick={() => handleCreateHighlight(selectedColor)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span>Resaltar</span>
            </button>

            <button
              onClick={() => setActiveSelection(null)}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
              title="Cancelar selección"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </main>

      {/* --- BOTTOM NAVIGATION BAR --- */}
      <footer className="h-14 bg-zinc-900/90 backdrop-blur-md border-t border-zinc-800 flex items-center justify-between px-4 shrink-0 z-20">
        <button
          onClick={handlePrev}
          className="h-10 px-4 bg-zinc-800/80 hover:bg-zinc-800 active:scale-95 text-zinc-200 hover:text-white rounded-xl border border-zinc-700/60 flex items-center gap-1.5 text-xs font-semibold transition-all shadow-sm"
          title="Capítulo o página anterior"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Anterior</span>
        </button>

        {/* Center reading progress track */}
        <div className="flex-1 max-w-xs mx-4 text-center">
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-blue-500 h-full transition-all duration-300"
              style={{ width: `${readingPercentage}%` }}
            />
          </div>
          <span className="text-[10px] text-zinc-400 mt-1 block">
            {readingPercentage}% completado
          </span>
        </div>

        <button
          onClick={handleNext}
          className="h-10 px-4 bg-zinc-800/80 hover:bg-zinc-800 active:scale-95 text-zinc-200 hover:text-white rounded-xl border border-zinc-700/60 flex items-center gap-1.5 text-xs font-semibold transition-all shadow-sm"
          title="Siguiente capítulo o página"
        >
          <span>Siguiente</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </footer>

      {/* --- TABLE OF CONTENTS (TOC) DRAWER --- */}
      {isTocOpen && (
        <div className="fixed inset-0 z-50 flex justify-start bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm h-full bg-zinc-900 border-r border-zinc-800 flex flex-col shadow-2xl animate-slideRight">
            <div className="h-14 px-4 border-b border-zinc-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <List className="w-5 h-5 text-blue-400" />
                <h2 className="text-sm font-bold text-white">Índice de Capítulos</h2>
              </div>
              <button
                onClick={() => setIsTocOpen(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              {toc.length === 0 ? (
                <p className="text-xs text-zinc-500 text-center py-8">
                  No se encontró tabla de contenido en este EPUB.
                </p>
              ) : (
                toc.map((item, idx) => (
                  <button
                    key={`${item.id}-${idx}`}
                    onClick={() => handleJumpToCfi(item.href)}
                    className="w-full text-left p-3 rounded-xl hover:bg-zinc-800 text-xs font-medium text-zinc-300 hover:text-white transition-all flex items-center justify-between group"
                  >
                    <span className="truncate pr-2">{item.label}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-zinc-600 group-hover:text-zinc-300 shrink-0" />
                  </button>
                ))
              )}
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsTocOpen(false)} />
        </div>
      )}

      {/* --- HIGHLIGHTS DRAWER --- */}
      {isHighlightsDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="flex-1" onClick={() => setIsHighlightsDrawerOpen(false)} />
          <div className="w-full max-w-md h-full bg-zinc-900 border-l border-zinc-800 flex flex-col shadow-2xl animate-slideLeft">
            <div className="h-14 px-4 border-b border-zinc-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Highlighter className="w-5 h-5 text-amber-400" />
                <h2 className="text-sm font-bold text-white">Resaltados ({highlights.length})</h2>
              </div>
              <button
                onClick={() => setIsHighlightsDrawerOpen(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {highlights.length === 0 ? (
                <div className="text-center py-12 px-4">
                  <Bookmark className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-zinc-400">Sin resaltados todavía</p>
                  <p className="text-[11px] text-zinc-500 mt-1">
                    Selecciona cualquier palabra o fragmento de texto en el libro y pulsa «Resaltar».
                  </p>
                </div>
              ) : (
                highlights.map((hl) => (
                  <div
                    key={hl.id}
                    className="p-3.5 rounded-2xl bg-zinc-800/60 border border-zinc-700/60 hover:border-zinc-600 transition-all flex flex-col gap-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                        style={{ backgroundColor: hl.color }}
                      />
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {new Date(hl.createdAt).toLocaleDateString()}
                      </span>
                      <button
                        onClick={() => handleDeleteHighlight(hl)}
                        className="p-1 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors"
                        title="Eliminar este resaltado"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p
                      onClick={() => handleJumpToCfi(hl.cfiRange)}
                      className="text-xs text-zinc-200 italic line-clamp-3 cursor-pointer hover:text-white transition-colors"
                      title="Toca para ir a la posición en el libro"
                    >
                      «{hl.text}»
                    </p>

                    <button
                      onClick={() => handleJumpToCfi(hl.cfiRange)}
                      className="text-[10px] text-blue-400 hover:text-blue-300 font-semibold self-start flex items-center gap-1"
                    >
                      Ir a la posición →
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- TOAST NOTIFICATION --- */}
      {toastMessage && (
        <div className="fixed bottom-18 left-1/2 -translate-x-1/2 z-50 bg-zinc-800 text-white px-4 py-2 rounded-xl border border-zinc-700 text-xs font-semibold shadow-2xl animate-fadeIn">
          {toastMessage}
        </div>
      )}
    </div>
  );
};
