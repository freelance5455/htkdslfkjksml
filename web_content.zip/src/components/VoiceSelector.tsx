import React, { useState } from 'react';
import { Volume2, Play, Check, Sparkles, User, Info } from 'lucide-react';
import { TTSEngineType, TTSVoice } from '../types/tts';

interface VoiceSelectorProps {
  voices: TTSVoice[];
  selectedVoiceId: string;
  onSelectVoice: (voiceId: string) => void;
  activeEngine: TTSEngineType;
  onPreviewVoiceSample?: (voice: TTSVoice) => void;
  isPlayingSample?: string | null;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({
  voices,
  selectedVoiceId,
  onSelectVoice,
  activeEngine,
  onPreviewVoiceSample,
  isPlayingSample,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'realistic' | 'male' | 'female'>('all');

  const filteredVoices = voices.filter((v) => {
    if (filterMode === 'realistic') return v.isRealistic;
    if (filterMode === 'male') return v.category === 'male';
    if (filterMode === 'female') return v.category === 'female';
    return true;
  });

  const realisticCount = voices.filter((v) => v.isRealistic).length;
  const maleCount = voices.filter((v) => v.category === 'male').length;
  const femaleCount = voices.filter((v) => v.category === 'female').length;

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Header & Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>గళ ఎంపిక</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Voice Selection ({voices.length})
            </span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>{realisticCount} Realistic</span>
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            సహజసిద్ధమైన తెలుగు మానవ శైలి సంభాషణలతో రియలిస్టిక్ న్యూరల్ మరియు జెమిని గళాలు
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 flex-wrap gap-1">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterMode === 'all'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            అన్నీ ({voices.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('realistic')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1 ${
              filterMode === 'realistic'
                ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-amber-400/80 hover:text-amber-300'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>రియలిస్టిక్ ({realisticCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('male')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterMode === 'male'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            పురుష ({maleCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('female')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterMode === 'female'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            మహిళా ({femaleCount})
          </button>
        </div>
      </div>

      {/* Notice regarding engine voice mapping */}
      <div className="mb-4 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-400 flex items-start gap-2">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-amber-300">రియలిస్టిక్ తెలుగు గళాలు (Realistic Human-like Voices):</span>{' '}
          మోహన్ (Mohan), శృతి (Shruti) వంటి అధునాతన న్యూరల్ ఆర్టిక్యులేషన్ ఆధారిత గళాలు మానవ సహజమైన శ్వాస, భావోద్వేగ స్థాయులు మరియు స్పష్టమైన తెలుగోళ్ల యాసతో జీవం పోస్తాయి.
        </div>
      </div>

      {/* Voice Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
        {filteredVoices.map((voice) => {
          const isSelected = selectedVoiceId === voice.id;
          const isPlaying = isPlayingSample === voice.id;

          return (
            <div
              key={voice.id}
              id={`voice-card-${voice.id}`}
              onClick={() => onSelectVoice(voice.id)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group ${
                isSelected
                  ? 'bg-gradient-to-b from-cyan-950/30 to-slate-900/90 border-cyan-500/80 ring-1 ring-cyan-500/40 shadow-lg shadow-cyan-950/40'
                  : voice.isRealistic
                  ? 'bg-slate-900/75 border-amber-900/30 hover:border-amber-500/40 hover:bg-slate-900'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              {/* Selected corner checkmark */}
              {isSelected && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </div>
              )}

              {/* Title & Tag */}
              <div className="flex items-start justify-between gap-2 pr-5">
                <div>
                  <h4 className="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition-colors flex items-center gap-1.5">
                    <span>{voice.name}</span>
                    {voice.badge && (
                      <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {voice.badge}
                      </span>
                    )}
                  </h4>
                  <div className="text-xs font-telugu text-slate-400 mt-0.5">
                    {voice.teluguName}
                  </div>
                </div>
              </div>

              {/* Badges: Gender & Style */}
              <div className="flex items-center gap-1.5 mt-2.5 flex-wrap">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    voice.category === 'male'
                      ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                      : 'bg-pink-500/10 text-pink-400 border-pink-500/20'
                  }`}
                >
                  {voice.category === 'male' ? 'పురుష (Male)' : 'మహిళా (Female)'}
                </span>

                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700/60">
                  {voice.styleTag}
                </span>

                {voice.isRealistic ? (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>Realistic Neural</span>
                  </span>
                ) : voice.isNeural ? (
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>AI</span>
                  </span>
                ) : null}
              </div>

              {/* Description */}
              <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                {voice.description}
              </p>

              {/* Preview Button */}
              {onPreviewVoiceSample && (
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onPreviewVoiceSample(voice);
                    }}
                    className="flex items-center gap-1.5 text-[11px] font-medium text-cyan-400 hover:text-cyan-300 hover:underline cursor-pointer"
                  >
                    {isPlaying ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                        <span>ప్లే అవుతోంది...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3 h-3 fill-current" />
                        <span>నమూనా వినండి (Sample)</span>
                      </>
                    )}
                  </button>

                  <span className="text-[10px] text-slate-500 font-mono">
                    {voice.nativeVoiceName || (voice.isRealistic ? 'Neural Studio' : 'Default')}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
