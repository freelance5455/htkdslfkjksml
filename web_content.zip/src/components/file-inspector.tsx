import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getFile } from "@/lib/file-registry";
import { useLibrary } from "@/lib/library-store";
import type { MediaItem } from "@/lib/media-types";
import { decoderDescription } from "@/lib/codecs";
import { formatBytes, formatClock, formatDuration } from "@/lib/utils";

export function FileInspector({
  item,
  action,
  onClose,
}: {
  item: MediaItem | undefined;
  action?: string;
  onClose: () => void;
}) {
  const rename = useLibrary((s) => s.rename);
  const remove = useLibrary((s) => s.remove);
  const relink = useLibrary((s) => s.relink);
  const [name, setName] = useState(item?.name ?? "");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setName(item?.name ?? "");
  }, [item?.id, item?.name]);

  if (!item) return null;

  const share = async () => {
    const file = getFile(item.id);
    try {
      if (file && navigator.share) {
        await navigator.share({ files: [file], title: item.name });
        return;
      }
      if (item.url && navigator.share) {
        await navigator.share({ url: item.url, title: item.name });
        return;
      }
      const text = item.url || item.name;
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      toast.error("Sharing is not available in this browser.");
    }
  };

  const openWith = () => {
    const file = getFile(item.id);
    const href = file ? URL.createObjectURL(file) : item.url;
    if (!href) {
      toast.error("This file is not available. Relink it first.");
      return;
    }
    window.open(href, "_blank", "noopener,noreferrer");
  };

  const copyFile = async () => {
    const file = getFile(item.id);
    if (!file) {
      toast.error("Nothing to copy until the file is linked.");
      return;
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(file);
    a.download = item.name;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  };

  const infoOpen = !action || action === "info" || action === "rename";
  const deleteOpen = action === "delete";

  return (
    <>
      <input
        ref={fileRef}
        type="file"
        className="sr-only"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void relink(item.id, file);
          e.target.value = "";
        }}
      />
      <Dialog open={infoOpen} onOpenChange={(o) => !o && onClose()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>File information</DialogTitle>
            <DialogDescription>{item.relativePath || item.url || item.name}</DialogDescription>
          </DialogHeader>
          {action === "rename" ? (
            <div className="grid gap-1.5">
              <Label htmlFor="rename-file">Name</Label>
              <Input id="rename-file" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
          ) : (
            <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
              <Info label="Duration" value={formatDuration(item.duration)} />
              <Info label="Size" value={formatBytes(item.size)} />
              <Info
                label="Resolution"
                value={item.width && item.height ? `${item.width}×${item.height}` : "—"}
              />
              <Info label="Type" value={item.mime || item.ext || "—"} />
              <Info label="Folder" value={item.folder} />
              <Info label="Decoder" value={decoderDescription()} />
              <Info label="Added" value={formatClock(item.addedAt)} />
              <Info
                label="Last played"
                value={item.lastPlayedAt ? formatClock(item.lastPlayedAt) : "Never"}
              />
            </dl>
          )}
          {!item.linked && item.source === "local" ? (
            <p className="text-sm text-muted">
              The original file is not linked in this session. Relink to play it.
            </p>
          ) : null}
          {item.unsupportedReason ? (
            <p className="text-sm text-destructive">{item.unsupportedReason}</p>
          ) : null}
          <DialogFooter className="flex-wrap">
            {action === "rename" ? (
              <Button
                onClick={() => {
                  rename(item.id, name);
                  onClose();
                }}
              >
                Save name
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={() => fileRef.current?.click()}>
                  Relink
                </Button>
                <Button variant="outline" onClick={() => void share()}>
                  Share
                </Button>
                <Button variant="outline" onClick={copyFile}>
                  Copy / save
                </Button>
                <Button variant="outline" onClick={openWith}>
                  Open with
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <AlertDialog open={deleteOpen} onOpenChange={(o) => !o && onClose()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove from library?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes “{item.name}” from UPLAY.IND. The original file on disk is not deleted
              unless this browser granted file-handle access.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-fg"
              onClick={() => {
                void remove(item.id);
                toast.success("Removed from library");
                onClose();
              }}
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <>
      <dt className="text-muted">{label}</dt>
      <dd className="tabular-nums">{value}</dd>
    </>
  );
}
