import type { SVGProps } from "react";

/** The geometric "lattice" emblem used across the site. */
export function LogoMark(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 40 40" aria-hidden="true" {...props}>
      <g fill="none" stroke="currentColor" strokeWidth={1.6}>
        <rect x={9} y={9} width={22} height={22} />
        <rect x={9} y={9} width={22} height={22} transform="rotate(45 20 20)" />
        <circle cx={20} cy={20} r={4.5} />
      </g>
    </svg>
  );
}
