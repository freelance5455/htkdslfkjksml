import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  isFramed: boolean;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children, isFramed }) => {
  if (!isFramed) {
    return (
      <div className="w-full max-w-4xl mx-auto bg-slate-50 min-h-screen shadow-md rounded-2xl overflow-hidden border border-slate-200">
        {children}
      </div>
    );
  }

  return (
    <div className="flex justify-center items-center py-4 px-2 bg-slate-900/5 min-h-[92vh]">
      {/* Phone chassis */}
      <div className="relative w-full max-w-[400px] h-[844px] bg-black rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-900/20 shadow-slate-950/40 flex flex-col">
        {/* Outer Bezel buttons */}
        <div className="absolute -left-[3px] top-24 w-[3px] h-8 bg-slate-700 rounded-l-sm"></div>
        <div className="absolute -left-[3px] top-36 w-[3px] h-12 bg-slate-700 rounded-l-sm"></div>
        <div className="absolute -left-[3px] top-52 w-[3px] h-12 bg-slate-700 rounded-l-sm"></div>
        <div className="absolute -right-[3px] top-32 w-[3px] h-16 bg-slate-700 rounded-r-sm"></div>

        {/* Screen inside */}
        <div className="relative w-full h-full bg-slate-50 rounded-[38px] overflow-hidden flex flex-col select-none">
          {/* iOS Dynamic Island & Status Bar */}
          <div className="h-10 bg-[#FF6600] text-white px-6 flex items-center justify-between text-xs font-semibold shrink-0 z-40 select-none">
            <span className="text-[12px] font-bold">9:41</span>
            
            {/* Dynamic Island pill */}
            <div className="w-24 h-5 bg-black rounded-full mx-auto self-center -mt-1 shadow-xs"></div>
            
            <div className="flex items-center gap-1.5 text-white/90">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <Battery className="w-4 h-4" />
            </div>
          </div>

          {/* Screen Content Scrollable Area */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative scrollbar-none">
            {children}
          </div>

          {/* Home Indicator Bar */}
          <div className="h-4 bg-white/95 backdrop-blur-md flex items-center justify-center shrink-0 z-50">
            <div className="w-28 h-1 bg-slate-300 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
