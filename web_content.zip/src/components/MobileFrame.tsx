import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Battery,
  Code2,
  Maximize2,
  Minimize2,
  BookOpen,
  Shield,
} from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  onOpenFlutterCode: () => void;
  onOpenInstructions: () => void;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  children,
  onOpenFlutterCode,
  onOpenInstructions,
}) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-start p-0 sm:p-4 md:p-6 text-slate-100">
      {/* Top Banner Toolbar for academic demonstration */}
      <header className="w-full max-w-5xl mb-3 px-4 py-2.5 bg-slate-900/90 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-500 to-red-700 flex items-center justify-center text-white shadow-md shadow-rose-900/40">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-sm tracking-wide">SafeHer AI</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/30">
                Flutter & Firebase Architecture
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              AI-Powered Women Safety & Emergency Response • B.Tech CSE (AIML)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenInstructions}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition cursor-pointer"
            title="How SafeHer AI works & demo checklist"
          >
            <BookOpen className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">How It Works / Demo Flow</span>
          </button>

          <button
            onClick={onOpenFlutterCode}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-md shadow-rose-900/30 cursor-pointer"
            title="Explore and download the complete Flutter project"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Flutter Code & ZIP</span>
          </button>

          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title={isPhoneFrame ? 'Switch to Fullscreen View' : 'Switch to Mobile Frame'}
          >
            {isPhoneFrame ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Container: Mobile Frame or Full View */}
      {isPhoneFrame ? (
        <div className="relative w-full max-w-[420px] h-[860px] bg-slate-900 rounded-[48px] border-[10px] border-slate-800 shadow-2xl shadow-rose-950/20 overflow-hidden flex flex-col ring-1 ring-slate-700/50">
          {/* Phone Notch & Status Bar */}
          <div className="h-10 bg-slate-900 px-6 flex items-center justify-between text-xs text-slate-400 select-none shrink-0 z-30">
            <span className="font-semibold text-[13px] text-white tracking-wider">{currentTime || '09:41'}</span>

            {/* Camera island pill */}
            <div className="w-24 h-4.5 bg-black rounded-full mx-auto flex items-center justify-center gap-2 px-2">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-blue-900/70"></div>
            </div>

            <div className="flex items-center gap-1.5 text-slate-300">
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* Screen Content Container */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative bg-slate-950 flex flex-col">
            {children}
          </div>

          {/* Bottom Home Indicator Bar */}
          <div className="h-4 bg-slate-950 flex items-center justify-center shrink-0">
            <div className="w-32 h-1 bg-slate-700 rounded-full"></div>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-4xl bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden min-h-[750px] flex flex-col">
          <div className="flex-1 overflow-y-auto flex flex-col">
            {children}
          </div>
        </div>
      )}
    </div>
  );
};
