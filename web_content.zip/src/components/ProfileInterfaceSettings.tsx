import React, { useState } from "react";
import {
  SlidersHorizontal,
  Compass,
  Layout,
  Layers,
  Sparkles,
  Check,
  RotateCcw,
  Eye,
  Sliders,
  ArrowUpDown,
  Move,
  CheckCircle2,
  Monitor,
  Maximize2
} from "lucide-react";
import { ProfileInterfaceConfig, NavigationConcept, ToolSortMode } from "../types";
import {
  APP_INTERFACE_TOOLS,
  DEFAULT_PROFILE_INTERFACE_CONFIG,
  getStoredProfileInterfaceConfig,
  saveStoredProfileInterfaceConfig,
} from "../utils/interfaceSorting";
import { DynamicToolMenu } from "./DynamicToolMenu";
import { RadialMenuSettings } from "./RadialMenuSettings";

interface ProfileInterfaceSettingsProps {
  onNotify?: (msg: string) => void;
  onConfigChange?: (config: ProfileInterfaceConfig) => void;
}

export const ProfileInterfaceSettings: React.FC<ProfileInterfaceSettingsProps> = ({
  onNotify,
  onConfigChange,
}) => {
  const [config, setConfig] = useState<ProfileInterfaceConfig>(getStoredProfileInterfaceConfig);
  const [activePreviewTool, setActivePreviewTool] = useState<string>("home");

  const updateConfig = (patch: Partial<ProfileInterfaceConfig>) => {
    const updated = { ...config, ...patch };
    setConfig(updated);
    saveStoredProfileInterfaceConfig(updated);
    if (onConfigChange) onConfigChange(updated);
    if (onNotify) onNotify("✓ Arayüz ve Navigasyon tercihleriniz kaydedildi.");
  };

  const handleResetToDefault = () => {
    setConfig(DEFAULT_PROFILE_INTERFACE_CONFIG);
    saveStoredProfileInterfaceConfig(DEFAULT_PROFILE_INTERFACE_CONFIG);
    if (onConfigChange) onConfigChange(DEFAULT_PROFILE_INTERFACE_CONFIG);
    if (onNotify) onNotify("Arayüz ayarları varsayılana sıfırlandı.");
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-teal-500 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Arayüz & Navigasyon Deneyimi
              </h2>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                Görsel Mimari & Modüler
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Uygulamanın tüm görsel düzenini, menü mimarisini ve araç dizilimini tamamen kendinize göre kişiselleştirin.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleResetToDefault}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold transition-all shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>Varsayılana Sıfırla</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 4. CANLI ÖNİZLEME (LIVE PREVIEW SHOWCASE BOX)                             */}
      {/* ========================================================================= */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Monitor className="w-4 h-4 text-teal-400" />
            <span className="text-xs font-black uppercase tracking-wider text-slate-200">
              Canlı Canlı Uygulama Vitrini (Live Preview)
            </span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
            Aktif Mod: {config.navigationConcept.toUpperCase()}
          </span>
        </div>

        {/* Live Preview Canvas Container */}
        <div className="p-3 sm:p-4 rounded-2xl bg-slate-950 border border-slate-800 min-h-[140px] flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="font-semibold">NoteFlow Preview Workspace</span>
            <span className="text-[10px] text-teal-400 font-bold">
              Seçili Araç: {APP_INTERFACE_TOOLS.find((t) => t.id === activePreviewTool)?.title}
            </span>
          </div>

          {/* Render the Dynamic Tool Menu in live preview mode */}
          <DynamicToolMenu
            config={config}
            tools={APP_INTERFACE_TOOLS}
            activeToolId={activePreviewTool}
            onSelectTool={(id) => setActivePreviewTool(id)}
            onUpdateConfig={updateConfig}
            onReorderTools={(newOrder) => updateConfig({ customToolOrder: newOrder })}
            isPreview={true}
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. MENÜ VE GEZİNME DÜZENİ SEÇİCİSİ (4 ANA KONSEPT)                        */}
      {/* ========================================================================= */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Layout className="w-4 h-4 text-teal-500" />
          <span>1. Menü ve Gezinme Düzeni (4 Ana Konsept)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
          {/* Concept 1: Klasik Düzen */}
          <div
            onClick={() => updateConfig({ navigationConcept: "classic" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between space-y-3 ${
              config.navigationConcept === "classic"
                ? "bg-teal-50/70 dark:bg-teal-950/50 border-teal-500 text-teal-950 dark:text-teal-100 shadow-sm ring-2 ring-teal-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    config.navigationConcept === "classic"
                      ? "bg-teal-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                  }`}
                >
                  1
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">Klasik Düzen (Mevcut)</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Ekranın üstünde veya altında yer alan, standart yatay açılır menü.
                  </p>
                </div>
              </div>
              {config.navigationConcept === "classic" && (
                <CheckCircle2 className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
              )}
            </div>
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-[10px] font-mono flex items-center gap-1.5 overflow-x-auto text-slate-500">
              <span className="px-2 py-0.5 rounded-md bg-teal-600 text-white font-bold">Notlar</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700">Hub</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700">Zihin</span>
              <span className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700">Kasa</span>
            </div>
          </div>

          {/* Concept 2: Dikey Kategori Kartları */}
          <div
            onClick={() => updateConfig({ navigationConcept: "vertical_cards" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between space-y-3 ${
              config.navigationConcept === "vertical_cards"
                ? "bg-teal-50/70 dark:bg-teal-950/50 border-teal-500 text-teal-950 dark:text-teal-100 shadow-sm ring-2 ring-teal-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    config.navigationConcept === "vertical_cards"
                      ? "bg-teal-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                  }`}
                >
                  2
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">Dikey Kategori Kartları</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Ekran kenarına sabitlenmiş, dikey boşluğu kullanan kaydırılabilir geniş paneller.
                  </p>
                </div>
              </div>
              {config.navigationConcept === "vertical_cards" && (
                <CheckCircle2 className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
              )}
            </div>
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-[10px] font-mono space-y-1 text-slate-500">
              <div className="flex items-center gap-2 p-1 rounded-md bg-white dark:bg-slate-700 shadow-xs">
                <div className="w-2 h-2 rounded-full bg-teal-500" />
                <span className="font-bold">Notlar Kartı</span>
              </div>
              <div className="flex items-center gap-2 p-1 rounded-md bg-slate-200 dark:bg-slate-800">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span>Belge Hub Kartı</span>
              </div>
            </div>
          </div>

          {/* Concept 3: Dinamik Yüzen Dok */}
          <div
            onClick={() => updateConfig({ navigationConcept: "adaptive_dock" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between space-y-3 ${
              config.navigationConcept === "adaptive_dock"
                ? "bg-teal-50/70 dark:bg-teal-950/50 border-teal-500 text-teal-950 dark:text-teal-100 shadow-sm ring-2 ring-teal-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    config.navigationConcept === "adaptive_dock"
                      ? "bg-teal-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                  }`}
                >
                  3
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">Dinamik Yüzen Dok (Adaptive)</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Ekranda bağımsızca taşınabilen (Draggable), spring animasyonlu esnek kapsül panel.
                  </p>
                </div>
              </div>
              {config.navigationConcept === "adaptive_dock" && (
                <CheckCircle2 className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
              )}
            </div>
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-[10px] font-mono flex items-center justify-center gap-2 text-slate-500">
              <div className="px-3 py-1 rounded-full bg-slate-900 text-teal-400 font-extrabold flex items-center gap-1.5 shadow-sm">
                <Sparkles className="w-3 h-3" />
                <span>Yüzen Dok kapsülü</span>
              </div>
            </div>
          </div>

          {/* Concept 4: Sadece İkonlar */}
          <div
            onClick={() => updateConfig({ navigationConcept: "minimal_icons" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between space-y-3 ${
              config.navigationConcept === "minimal_icons"
                ? "bg-teal-50/70 dark:bg-teal-950/50 border-teal-500 text-teal-950 dark:text-teal-100 shadow-sm ring-2 ring-teal-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    config.navigationConcept === "minimal_icons"
                      ? "bg-teal-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                  }`}
                >
                  4
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">Sadece İkonlar (Minimal)</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Metinlerin gizlendiği, maksimum odaklanma sağlayan en dar çalışma alanı modu.
                  </p>
                </div>
              </div>
              {config.navigationConcept === "minimal_icons" && (
                <CheckCircle2 className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
              )}
            </div>
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-[10px] font-mono flex items-center justify-center gap-2 text-slate-500">
              <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold">📝</div>
              <div className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center">📑</div>
              <div className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center">🌐</div>
              <div className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center">🔒</div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. GÖRSEL ÖNİZLEME VE CANLI KONTROLLER (TOGGLE ANAHTARLARI)               */}
      {/* ========================================================================= */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Eye className="w-4 h-4 text-indigo-500" />
          <span>2. Görsel Önizleme ve Canlı Kontroller (Toggle Anahtarları)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {/* Toggle 1: Görsel Önizlemeleri Göster */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 flex items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>Görsel Önizlemeleri Göster</span>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold">
                  Thumbnail Previews
                </span>
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Araçların ve alt menülerin yanına ne işe yaradıklarını gösteren zengin minyatür görseller ekler.
              </p>
            </div>
            <button
              type="button"
              onClick={() => updateConfig({ showThumbnails: !config.showThumbnails })}
              className={`w-12 h-6 rounded-full transition-colors relative shrink-0 cursor-pointer p-0.5 ${
                config.showThumbnails ? "bg-teal-600" : "bg-slate-300 dark:bg-slate-700"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                  config.showThumbnails ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Toggle 2: Canlı Kontrolleri (Sliders) Menüye Göm */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 flex items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>Canlı Kontrolleri (Sliders) Menüye Göm</span>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 font-bold">
                  Inline Sliders
                </span>
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Arayüz ölçeği ve yazı boyutu gibi ayar kaydırıcılarını alt menülere girmeden doğrudan liste üzerine gömer.
              </p>
            </div>
            <button
              type="button"
              onClick={() => updateConfig({ showInlineControls: !config.showInlineControls })}
              className={`w-12 h-6 rounded-full transition-colors relative shrink-0 cursor-pointer p-0.5 ${
                config.showInlineControls ? "bg-teal-600" : "bg-slate-300 dark:bg-slate-700"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                  config.showInlineControls ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. ARAÇ SIRALAMA VE ORGANİZASYON MOTORU                                  */}
      {/* ========================================================================= */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <ArrowUpDown className="w-4 h-4 text-rose-500" />
          <span>3. Araç Sıralama ve Organizasyon Motoru</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Mode 1: Akıllı / İlişkisel Gruplama */}
          <div
            onClick={() => updateConfig({ toolSortMode: "smart_relational" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              config.toolSortMode === "smart_relational"
                ? "bg-rose-50/70 dark:bg-rose-950/50 border-rose-500 text-rose-950 dark:text-rose-100 shadow-sm ring-1 ring-rose-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold">Akıllı / İlişkisel Gruplama</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Çizim, Medya, PKM ve Ayarlar bloklarına göre kategorik sıralar.
              </p>
            </div>
            {config.toolSortMode === "smart_relational" && (
              <Check className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
          </div>

          {/* Mode 2: A'dan Z'ye Alfabetik Sıralama */}
          <div
            onClick={() => updateConfig({ toolSortMode: "alphabetical" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              config.toolSortMode === "alphabetical"
                ? "bg-rose-50/70 dark:bg-rose-950/50 border-rose-500 text-rose-950 dark:text-rose-100 shadow-sm ring-1 ring-rose-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold">A'dan Z'ye Alfabetik Sıralama</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Tüm menü ve araçları Türkçe alfabetik sıraya göre otomatik dizme.
              </p>
            </div>
            {config.toolSortMode === "alphabetical" && (
              <Check className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
          </div>

          {/* Mode 3: Serbest Sürükle-Bırak */}
          <div
            onClick={() => updateConfig({ toolSortMode: "drag_drop" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              config.toolSortMode === "drag_drop"
                ? "bg-rose-50/70 dark:bg-rose-950/50 border-rose-500 text-rose-950 dark:text-rose-100 shadow-sm ring-1 ring-rose-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold flex items-center gap-1">
                <span>Serbest Sürükle-Bırak</span>
                <Move className="w-3 h-3 text-rose-500" />
              </h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Tutamaç ikonuyla sürükleyip tamamen kendi isteğinize göre dizin.
              </p>
            </div>
            {config.toolSortMode === "drag_drop" && (
              <Check className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
          </div>
        </div>
      </div>

      {/* Radial Menu & Navigation Customization Panel */}
      <div className="pt-6 border-t border-slate-200 dark:border-slate-800">
        <RadialMenuSettings onNotify={onNotify} />
      </div>
    </div>
  );
};
