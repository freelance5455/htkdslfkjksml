import React from 'react';
import { Sparkles, Sun, Eye, Compass, Volume2, Wind, Hand, Scroll, AlertCircle } from 'lucide-react';
import { StoryAnalysisData } from '../types';

interface SceneAnalysisCardProps {
  analysis: StoryAnalysisData;
  modelUsed?: string;
}

export const SceneAnalysisCard: React.FC<SceneAnalysisCardProps> = ({ analysis, modelUsed }) => {
  return (
    <div className="rounded-2xl border border-stone-800 bg-stone-900/60 backdrop-blur-sm p-5 sm:p-6 shadow-xl space-y-6">
      {/* Title & Mood Tags */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-800/80 pb-4">
        <div>
          <span className="text-[11px] uppercase tracking-wider font-semibold text-amber-500/90 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Atmospheric & Scene Synthesis
          </span>
          <h3 className="font-display text-xl font-bold text-stone-100 tracking-wide mt-1">
            {analysis.storyTitle}
          </h3>
          <p className="text-xs text-stone-400 mt-0.5">Genre: {analysis.genre}</p>
        </div>

        {/* Mood badges */}
        <div className="flex flex-wrap items-center gap-1.5">
          {analysis.moodKeywords.map((tag, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-300 border border-amber-500/25"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Grid: Visual Breakdown & Implied Stakes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800/80 space-y-1.5">
          <span className="text-stone-400 font-medium flex items-center gap-1.5 text-[11px]">
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            Lighting & Atmosphere
          </span>
          <p className="text-stone-300 leading-relaxed">
            {analysis.sceneBreakdown.lightingAndAtmosphere}
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800/80 space-y-1.5">
          <span className="text-stone-400 font-medium flex items-center gap-1.5 text-[11px]">
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            Focal Point & Visual Cues
          </span>
          <p className="text-stone-300 leading-relaxed">
            {analysis.sceneBreakdown.focalPoint}
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800/80 space-y-1.5">
          <span className="text-stone-400 font-medium flex items-center gap-1.5 text-[11px]">
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            Implied Epoch / Era
          </span>
          <p className="text-stone-300 leading-relaxed">
            {analysis.sceneBreakdown.historicalEra}
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800/80 space-y-1.5">
          <span className="text-stone-400 font-medium flex items-center gap-1.5 text-[11px]">
            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
            Latent Narrative Conflict
          </span>
          <p className="text-stone-300 leading-relaxed">
            {analysis.sceneBreakdown.impliedConflict}
          </p>
        </div>
      </div>

      {/* Sensory Palette */}
      <div className="space-y-2">
        <h5 className="text-[11px] uppercase tracking-wider font-semibold text-stone-400">
          World Sensory Palette
        </h5>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Sounds */}
          <div className="p-3 rounded-xl bg-stone-950/40 border border-stone-800/60 space-y-1">
            <span className="text-stone-400 font-medium flex items-center gap-1 text-[11px]">
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              Auditory
            </span>
            <ul className="list-disc list-inside space-y-0.5 text-stone-300 text-[11px]">
              {analysis.sensoryPalette.sounds.map((sound, i) => (
                <li key={i}>{sound}</li>
              ))}
            </ul>
          </div>

          {/* Scents */}
          <div className="p-3 rounded-xl bg-stone-950/40 border border-stone-800/60 space-y-1">
            <span className="text-stone-400 font-medium flex items-center gap-1 text-[11px]">
              <Wind className="w-3.5 h-3.5 text-teal-400" />
              Olfactory
            </span>
            <ul className="list-disc list-inside space-y-0.5 text-stone-300 text-[11px]">
              {analysis.sensoryPalette.scents.map((scent, i) => (
                <li key={i}>{scent}</li>
              ))}
            </ul>
          </div>

          {/* Tactile */}
          <div className="p-3 rounded-xl bg-stone-950/40 border border-stone-800/60 space-y-1">
            <span className="text-stone-400 font-medium flex items-center gap-1 text-[11px]">
              <Hand className="w-3.5 h-3.5 text-amber-400" />
              Tactile
            </span>
            <ul className="list-disc list-inside space-y-0.5 text-stone-300 text-[11px]">
              {analysis.sensoryPalette.tactile.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* World Lore Snippet */}
      {analysis.worldLore && (
        <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/20 via-stone-900 to-amber-950/20 border border-amber-500/20 flex gap-3 items-start">
          <Scroll className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400">
              World Lore Fragment
            </span>
            <p className="font-serif-story italic text-stone-300 text-sm leading-relaxed">
              "{analysis.worldLore}"
            </p>
          </div>
        </div>
      )}

      {modelUsed && (
        <div className="text-right">
          <span className="text-[10px] text-stone-500">
            Synthesized via <span className="text-stone-400 font-mono">{modelUsed}</span>
          </span>
        </div>
      )}
    </div>
  );
};
