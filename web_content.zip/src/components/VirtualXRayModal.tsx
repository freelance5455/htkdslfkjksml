/**
 * JARVIS 3D Virtual X-Ray & Component Analyzer
 * Built with Three.js procedural PBR hierarchy, layer-by-layer explosion, cutaway opacity,
 * interactive component raycasting, operating principles, and failure mode diagnostics.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { X, Layers, Eye, Cpu, AlertTriangle, CheckCircle2, ChevronUp, ChevronDown, RotateCcw } from 'lucide-react';

interface ComponentInfo {
  id: string;
  name: string;
  material: string;
  operatingPrinciple: string;
  failureModes: string[];
  status: 'Nominal' | 'Optimal' | 'Inspection Recommended';
  specs: Record<string, string>;
}

interface ModelPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  components: ComponentInfo[];
}

const PRESETS: ModelPreset[] = [
  {
    id: 'v8-engine',
    name: 'V8 Combustion Core & Cylinder Bank',
    category: 'Mechanical Engineering',
    description: 'High-performance 90-degree V8 block with forged crankshaft, reciprocating pistons, and dual overhead camshafts.',
    components: [
      {
        id: 'engine-block',
        name: 'Cast Aluminum Engine Block',
        material: 'A319 High-Strength Alloy',
        operatingPrinciple: 'Houses cylinders, coolant passages, and oil galleries; withstands extreme internal combustion chamber pressure.',
        failureModes: ['Thermal cylinder bore scoring', 'Coolant jacket cracking', 'Head gasket blow-by'],
        status: 'Optimal',
        specs: { Displacement: '4.8 Liters', Bore: '88 mm', Stroke: '98 mm', 'Compression Ratio': '10.5:1' },
      },
      {
        id: 'crankshaft',
        name: 'Forged Steel Crankshaft',
        material: '4340 Chromoly Steel',
        operatingPrinciple: 'Converts linear reciprocating piston thrust into rotational kinetic torque for the transmission flywheel.',
        failureModes: ['Journal bearing seizure', 'Fatigue torsional shear', 'Oil film starvation'],
        status: 'Nominal',
        specs: { 'Rod Journal': '52 mm', 'Main Journal': '64 mm', Balancing: 'Internal Counterweights' },
      },
      {
        id: 'pistons',
        name: 'Hypereutectic Pistons (Set of 8)',
        material: 'Aluminum-Silicon Alloy',
        operatingPrinciple: 'Transfers expansive combustion gas pressure through wrist pins and connecting rods to the crankshaft.',
        failureModes: ['Ring land micro-fracture', 'Pre-ignition detonation erosion', 'Skirt scuffing'],
        status: 'Optimal',
        specs: { Diameter: '88 mm', 'Ring Count': '3 (Compression + Oil)', Weight: '420g each' },
      },
      {
        id: 'camshaft',
        name: 'Dual Overhead Camshaft Assembly',
        material: 'Billet Chilled Cast Iron',
        operatingPrinciple: 'Controls precise intake and exhaust valve timing intervals synchronized via timing chain.',
        failureModes: ['Lobe premature spalling', 'VVT solenoid clogging', 'Bearing carrier galling'],
        status: 'Nominal',
        specs: { Lift: '11.5 mm', Duration: '264° Intake / 272° Exhaust', Drive: 'Chain Direct' },
      },
    ],
  },
  {
    id: 'smartphone-core',
    name: 'Smartphone Internal Chassis & SoC',
    category: 'Microelectronics',
    description: 'Multi-layer mobile hardware stack with 4nm SoC, multi-cell lithium battery, and thermal graphite vapor chamber.',
    components: [
      {
        id: 'soc-module',
        name: 'Octa-Core System-on-Chip (SoC)',
        material: '4nm FinFET Silicon Die',
        operatingPrinciple: 'Integrates high-efficiency CPU cores, Neural Processing Unit (NPU), and Vulkan GPU for mobile computing.',
        failureModes: ['Thermal throttling drop', 'Solder ball migration', 'Voltage regulator surge'],
        status: 'Optimal',
        specs: { Process: '4nm EUV', Transistors: '15 Billion', Clock: '2.8 GHz Peak', NPU: '26 TOPS' },
      },
      {
        id: 'battery-pack',
        name: '5000 mAh High-Density Lithium-Polymer',
        material: 'Cobalt-Nickel-Manganese Cathode',
        operatingPrinciple: 'Electrochemical energy storage supplying stable DC voltage to motherboard power management ICs.',
        failureModes: ['Dendrite micro-puncture', 'Thermal runaway swelling', 'Capacity degradation'],
        status: 'Nominal',
        specs: { Voltage: '3.87V Nominal', Capacity: '5000 mAh', WattHours: '19.35 Wh', ChargeRate: '33W Fast' },
      },
      {
        id: 'vapor-chamber',
        name: 'Liquid Vapor Cooling Chamber',
        material: 'Sintered Copper Capillary Wick',
        operatingPrinciple: 'Two-phase evaporative cycle that rapidly draws heat away from the processor to prevent thermal bottlenecks.',
        failureModes: ['Capillary wick dry-out', 'Vacuum seal micro-leak', 'Oxidation barrier build-up'],
        status: 'Optimal',
        specs: { Thickness: '0.4 mm', 'Thermal Conductivity': '>8000 W/m·K', Fluid: 'De-ionized H2O' },
      },
    ],
  },
  {
    id: 'arc-reactor',
    name: 'Arc Reactor Mark VII Core Turbine',
    category: 'Advanced Clean Energy',
    description: 'Palladium-isotope toroidal plasma containment ring with magnetic compression accelerators.',
    components: [
      {
        id: 'plasma-core',
        name: 'Toroidal Magnetic Plasma Core',
        material: 'Superconducting Niobium-Tin Coils',
        operatingPrinciple: 'Sustains self-collimating high-temperature plasma loop yielding zero-emission gigawatt energy output.',
        failureModes: ['Magnetic flux containment drop', 'Thermal quench transition', 'Isotope depletion'],
        status: 'Optimal',
        specs: { Output: '3.2 Gigajoules/sec', FluxDensity: '14.2 Tesla', CoreTemp: '12,000,000 K' },
      },
      {
        id: 'accelerator-ring',
        name: 'Compression Accelerator Ring',
        material: 'Titanium-Gold Matrix Alloy',
        operatingPrinciple: 'Drives synchronous relativistic particle injection to maintain continuous nuclear fusion cycle.',
        failureModes: ['Phase misalignment harmonic', 'Dielectric breakdown', 'Harmonic resonance chatter'],
        status: 'Optimal',
        specs: { 'Coil Count': '12 Primary + 24 Secondary', Efficiency: '99.98%', Frequency: '48.6 GHz' },
      },
    ],
  },
];

interface VirtualXRayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VirtualXRayModal: React.FC<VirtualXRayModalProps> = ({ isOpen, onClose }) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // States
  const [activePresetIndex, setActivePresetIndex] = useState(0);
  const [explodedAmount, setExplodedAmount] = useState(0); // 0 (assembled) to 1 (fully separated)
  const [cutawayOpacity, setCutawayOpacity] = useState(0.85); // 0.15 (ghost) to 1.0 (opaque)
  const [selectedComponent, setSelectedComponent] = useState<ComponentInfo | null>(null);
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [wireframeMode, setWireframeMode] = useState(false);

  // Three.js mutable references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const partMeshesRef = useRef<{ mesh: THREE.Mesh | THREE.Group; defaultPos: THREE.Vector3; explodeDir: THREE.Vector3; compId: string }[]>([]);
  const animFrameIdRef = useRef<number | null>(null);

  const preset = PRESETS[activePresetIndex];

  useEffect(() => {
    if (!isOpen || !mountRef.current) return;

    // 1. Detect software WebGL guard
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch (e) {
        return false;
      }
    })();

    const container = mountRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // 2. Scene & Camera Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x030712);
    scene.fog = new THREE.FogExp2(0x030712, 0.05);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 2.5, 5.5);
    cameraRef.current = camera;

    // 3. Renderer configuration
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 12;
    controls.minDistance = 1.5;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // 5. Studio Environment Reflection via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 6. Balanced 3-point Studio Lighting
    const ambientLight = new THREE.AmbientLight(0x0e2038, 1.2);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0x00f0ff, 0x050a18, 1.0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(5, 8, 6);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x00d4ff, 2.0);
    rimLight.position.set(-6, -2, -5);
    scene.add(rimLight);

    // Contact shadow grounding plane
    const shadowGeo = new THREE.PlaneGeometry(8, 8);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x001828,
      transparent: true,
      opacity: 0.5,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -1.5;
    scene.add(shadowMesh);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(10, 20, 0x00d4ff, 0x072740);
    gridHelper.position.y = -1.49;
    scene.add(gridHelper);

    // 7. Build Model Preset
    buildCurrentPreset(scene, activePresetIndex);

    // 8. Raycasting for Component Selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerDown = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const meshesToIntersect: THREE.Object3D[] = [];
      partMeshesRef.current.forEach(p => {
        if (p.mesh instanceof THREE.Mesh) meshesToIntersect.push(p.mesh);
        else p.mesh.traverse(child => { if (child instanceof THREE.Mesh) meshesToIntersect.push(child); });
      });

      const intersects = raycaster.intersectObjects(meshesToIntersect);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        const matched = partMeshesRef.current.find(p => {
          if (p.mesh === hit) return true;
          let found = false;
          p.mesh.traverse(child => { if (child === hit) found = true; });
          return found;
        });

        if (matched) {
          const comp = preset.components.find(c => c.id === matched.compId);
          if (comp) setSelectedComponent(comp);
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    // 9. Resize Observer
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 500;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 10. Animation Loop with Exponential Damping
    const clock = new THREE.Clock();
    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (controlsRef.current) {
        controlsRef.current.update();
      }

      // Smooth layer explosion interpolation
      partMeshesRef.current.forEach(item => {
        const targetOffset = item.explodeDir.clone().multiplyScalar(explodedAmount * 2.2);
        const targetPos = item.defaultPos.clone().add(targetOffset);
        item.mesh.position.lerp(targetPos, Math.min(1, delta * 7));

        // Auto slow spin when assembled
        if (explodedAmount < 0.05) {
          item.mesh.rotation.y += delta * 0.15;
        }
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.dispose();
      controls.dispose();
      scene.clear();
      partMeshesRef.current = [];
    };
  }, [isOpen, activePresetIndex]);

  // Update Cutaway Opacity and Wireframe dynamically
  useEffect(() => {
    partMeshesRef.current.forEach(item => {
      const applyMaterialUpdates = (obj: THREE.Object3D) => {
        if (obj instanceof THREE.Mesh) {
          const mat = obj.material as THREE.MeshStandardMaterial;
          if (mat) {
            mat.wireframe = wireframeMode;
            if (cutawayOpacity < 0.98) {
              mat.transparent = true;
              mat.opacity = cutawayOpacity;
            } else {
              mat.transparent = false;
              mat.opacity = 1.0;
            }
            mat.needsUpdate = true;
          }
        }
      };
      if (item.mesh instanceof THREE.Mesh) applyMaterialUpdates(item.mesh);
      else item.mesh.traverse(applyMaterialUpdates);
    });
  }, [cutawayOpacity, wireframeMode]);

  // Procedural 3D model generator for each preset
  const buildCurrentPreset = (scene: THREE.Scene, presetIdx: number) => {
    partMeshesRef.current = [];
    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    if (presetIdx === 0) {
      // 1. V8 Engine Model
      // Engine Block (Primary Silhouette)
      const blockGeo = new THREE.BoxGeometry(2.2, 1.4, 2.8);
      const blockMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        metalness: 0.85,
        roughness: 0.35,
      });
      const blockMesh = new THREE.Mesh(blockGeo, blockMat);
      blockMesh.castShadow = true;
      blockMesh.receiveShadow = true;
      rootGroup.add(blockMesh);
      partMeshesRef.current.push({
        mesh: blockMesh,
        defaultPos: new THREE.Vector3(0, 0, 0),
        explodeDir: new THREE.Vector3(0, 0, 0),
        compId: 'engine-block',
      });

      // Crankshaft (Secondary Read)
      const crankGroup = new THREE.Group();
      const crankBarGeo = new THREE.CylinderGeometry(0.18, 0.18, 3.2, 16);
      const crankMat = new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.95,
        roughness: 0.18,
      });
      const crankBar = new THREE.Mesh(crankBarGeo, crankMat);
      crankBar.rotation.x = Math.PI / 2;
      crankGroup.add(crankBar);

      // Counterweights
      for (let i = -1.2; i <= 1.2; i += 0.6) {
        const weightGeo = new THREE.BoxGeometry(0.7, 0.4, 0.12);
        const weightMesh = new THREE.Mesh(weightGeo, crankMat);
        weightMesh.position.set(0, -0.2, i);
        crankGroup.add(weightMesh);
      }
      rootGroup.add(crankGroup);
      partMeshesRef.current.push({
        mesh: crankGroup,
        defaultPos: new THREE.Vector3(0, -0.6, 0),
        explodeDir: new THREE.Vector3(0, -1.2, 0),
        compId: 'crankshaft',
      });

      // Pistons (Set of 8)
      const pistonsGroup = new THREE.Group();
      const pistonGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.5, 16);
      const pistonMat = new THREE.MeshStandardMaterial({
        color: 0x00d4ff,
        metalness: 0.9,
        roughness: 0.22,
      });

      for (let side = -1; side <= 1; side += 2) {
        for (let i = -1.0; i <= 1.0; i += 0.65) {
          const pMesh = new THREE.Mesh(pistonGeo, pistonMat);
          pMesh.position.set(side * 0.8, 0.5, i);
          pMesh.rotation.z = side * 0.45;
          pistonsGroup.add(pMesh);
        }
      }
      rootGroup.add(pistonsGroup);
      partMeshesRef.current.push({
        mesh: pistonsGroup,
        defaultPos: new THREE.Vector3(0, 0.4, 0),
        explodeDir: new THREE.Vector3(0, 1.2, 0),
        compId: 'pistons',
      });

      // Camshafts (Top Accent Details)
      const camGroup = new THREE.Group();
      const camGeo = new THREE.CylinderGeometry(0.12, 0.12, 2.9, 16);
      const camMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        metalness: 0.92,
        roughness: 0.25,
      });

      const camLeft = new THREE.Mesh(camGeo, camMat);
      camLeft.position.set(-0.7, 1.0, 0);
      camLeft.rotation.x = Math.PI / 2;
      camGroup.add(camLeft);

      const camRight = new THREE.Mesh(camGeo, camMat);
      camRight.position.set(0.7, 1.0, 0);
      camRight.rotation.x = Math.PI / 2;
      camGroup.add(camRight);

      rootGroup.add(camGroup);
      partMeshesRef.current.push({
        mesh: camGroup,
        defaultPos: new THREE.Vector3(0, 1.0, 0),
        explodeDir: new THREE.Vector3(0, 2.0, 0),
        compId: 'camshaft',
      });
    } else if (presetIdx === 1) {
      // 2. Smartphone Internal Hardware Stack
      // SoC Core Die
      const socGeo = new THREE.BoxGeometry(0.9, 0.1, 0.9);
      const socMat = new THREE.MeshStandardMaterial({
        color: 0x0284c7,
        metalness: 0.9,
        roughness: 0.2,
      });
      const socMesh = new THREE.Mesh(socGeo, socMat);
      socMesh.position.set(0, 0.3, 0.5);
      rootGroup.add(socMesh);
      partMeshesRef.current.push({
        mesh: socMesh,
        defaultPos: new THREE.Vector3(0, 0.3, 0.5),
        explodeDir: new THREE.Vector3(0, 1.2, 0),
        compId: 'soc-module',
      });

      // Battery Cell
      const battGeo = new THREE.BoxGeometry(1.8, 0.15, 2.2);
      const battMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.6,
        roughness: 0.4,
      });
      const battMesh = new THREE.Mesh(battGeo, battMat);
      battMesh.position.set(0, 0, -0.6);
      rootGroup.add(battMesh);
      partMeshesRef.current.push({
        mesh: battMesh,
        defaultPos: new THREE.Vector3(0, 0, -0.6),
        explodeDir: new THREE.Vector3(0, -0.8, 0),
        compId: 'battery-pack',
      });

      // Copper Vapor Chamber
      const vaporGeo = new THREE.BoxGeometry(1.6, 0.05, 1.8);
      const vaporMat = new THREE.MeshStandardMaterial({
        color: 0xd97706,
        metalness: 0.95,
        roughness: 0.15,
      });
      const vaporMesh = new THREE.Mesh(vaporGeo, vaporMat);
      vaporMesh.position.set(0, -0.25, 0.3);
      rootGroup.add(vaporMesh);
      partMeshesRef.current.push({
        mesh: vaporMesh,
        defaultPos: new THREE.Vector3(0, -0.25, 0.3),
        explodeDir: new THREE.Vector3(0, -1.5, 0),
        compId: 'vapor-chamber',
      });
    } else {
      // 3. Arc Reactor Mark VII Core
      // Toroidal Ring
      const torusGeo = new THREE.TorusGeometry(1.2, 0.35, 16, 48);
      const torusMat = new THREE.MeshStandardMaterial({
        color: 0x00f0ff,
        metalness: 0.85,
        roughness: 0.25,
      });
      const torusMesh = new THREE.Mesh(torusGeo, torusMat);
      rootGroup.add(torusMesh);
      partMeshesRef.current.push({
        mesh: torusMesh,
        defaultPos: new THREE.Vector3(0, 0, 0),
        explodeDir: new THREE.Vector3(0, 0, 0),
        compId: 'plasma-core',
      });

      // Accelerator Ring
      const accelGroup = new THREE.Group();
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2;
        const coilGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.7, 12);
        const coilMat = new THREE.MeshStandardMaterial({
          color: 0xd97706,
          metalness: 0.9,
          roughness: 0.3,
        });
        const coilMesh = new THREE.Mesh(coilGeo, coilMat);
        coilMesh.position.set(Math.cos(angle) * 1.2, Math.sin(angle) * 1.2, 0.1);
        coilMesh.rotation.z = angle + Math.PI / 2;
        accelGroup.add(coilMesh);
      }
      rootGroup.add(accelGroup);
      partMeshesRef.current.push({
        mesh: accelGroup,
        defaultPos: new THREE.Vector3(0, 0, 0),
        explodeDir: new THREE.Vector3(0, 0, 1.6),
        compId: 'accelerator-ring',
      });
    }

    // Default select first component
    if (preset.components.length > 0) {
      setSelectedComponent(preset.components[0]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[92vh] bg-gray-950/95 border border-cyan-500/30 rounded-2xl flex flex-col overflow-hidden shadow-[0_0_50px_rgba(0,212,255,0.18)]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-gray-900/80 border-b border-cyan-500/20 z-10">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-400">
              <Layers className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm sm:text-base font-bold font-mono tracking-wider text-cyan-300 uppercase">
                  Virtual X-Ray Analyzer // Mark VII
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-mono">
                  3D PBR Core
                </span>
              </div>
              <p className="text-xs text-gray-400 hidden sm:block">
                Interactive exploded schematic, cutaway layer peeling, and failure mode diagnostics
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setWireframeMode(!wireframeMode)}
              className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors flex items-center space-x-1 ${
                wireframeMode
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-gray-800/80 border-gray-700 text-gray-400 hover:text-cyan-400'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Wireframe</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-gray-800/80 hover:bg-red-950/50 hover:text-red-400 text-gray-400 border border-gray-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 3D Viewport Container */}
        <div className="relative flex-1 w-full bg-gray-950 overflow-hidden cursor-grab active:cursor-grabbing">
          <div ref={mountRef} className="w-full h-full" />

          {/* Model Preset Tabs Top Center */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 flex bg-gray-950/80 border border-cyan-500/30 rounded-xl p-1 backdrop-blur-md shadow-lg max-w-[94%] overflow-x-auto">
            {PRESETS.map((p, idx) => (
              <button
                key={p.id}
                onClick={() => {
                  setActivePresetIndex(idx);
                  setExplodedAmount(0);
                }}
                className={`px-3 py-1 text-xs font-mono whitespace-nowrap rounded-lg transition-all ${
                  idx === activePresetIndex
                    ? 'bg-cyan-500 text-gray-950 font-bold shadow-[0_0_12px_rgba(0,212,255,0.4)]'
                    : 'text-gray-400 hover:text-cyan-300'
                }`}
              >
                {p.name.split(' ')[0]} {p.name.split(' ')[1] || ''}
              </button>
            ))}
          </div>

          {/* Selected Component Floating Card (Top Right, Non-Intrusive) */}
          {selectedComponent && (
            <div className="absolute top-14 right-3 max-w-xs sm:max-w-sm bg-gray-950/90 border border-cyan-500/40 rounded-xl p-3 text-xs backdrop-blur-md z-20 shadow-xl hidden md:block">
              <div className="flex items-center justify-between pb-2 border-b border-gray-800">
                <div className="flex items-center space-x-1.5 text-cyan-400 font-mono font-bold">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>{selectedComponent.name}</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-mono">
                  {selectedComponent.status}
                </span>
              </div>
              <p className="text-gray-300 mt-2 text-[11px] leading-relaxed">
                {selectedComponent.operatingPrinciple}
              </p>
              <div className="mt-2 pt-2 border-t border-gray-800 space-y-1">
                <div className="text-[10px] text-amber-400/90 font-mono flex items-center space-x-1">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Primary Failure Modes:</span>
                </div>
                <ul className="list-disc list-inside text-[10px] text-gray-400 pl-1 space-y-0.5">
                  {selectedComponent.failureModes.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Unified Bottom Control Dock (Zero Viewport Occlusion Directive) */}
        <div className="z-20 bg-gray-950/95 border-t border-cyan-500/30 px-4 py-3 backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>EXPLODED KINEMATICS & CUTAWAY CONTROL</span>
            </div>
            <button
              onClick={() => setIsDockCollapsed(!isDockCollapsed)}
              className="text-xs text-gray-400 hover:text-cyan-400 flex items-center space-x-1 font-mono"
            >
              <span>{isDockCollapsed ? 'Show Parameters' : 'Hide Parameters'}</span>
              {isDockCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {!isDockCollapsed && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              {/* Exploded View Slider */}
              <div className="bg-gray-900/60 p-2.5 rounded-xl border border-gray-800">
                <div className="flex justify-between text-gray-400 font-mono mb-1.5">
                  <span>Explosion Separation</span>
                  <span className="text-cyan-400">{Math.round(explodedAmount * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.02"
                  value={explodedAmount}
                  onChange={(e) => setExplodedAmount(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-gray-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Cutaway Opacity Slider */}
              <div className="bg-gray-900/60 p-2.5 rounded-xl border border-gray-800">
                <div className="flex justify-between text-gray-400 font-mono mb-1.5">
                  <span>Cutaway Transparency</span>
                  <span className="text-cyan-400">{Math.round(cutawayOpacity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.15"
                  max="1"
                  step="0.05"
                  value={cutawayOpacity}
                  onChange={(e) => setCutawayOpacity(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-gray-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Reset Cam & Controls */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setExplodedAmount(0);
                    setCutawayOpacity(0.85);
                    setWireframeMode(false);
                    if (cameraRef.current && controlsRef.current) {
                      cameraRef.current.position.set(0, 2.5, 5.5);
                      controlsRef.current.target.set(0, 0, 0);
                      controlsRef.current.update();
                    }
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-300 font-mono hover:bg-cyan-900/50 transition-colors flex items-center justify-center space-x-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Angles</span>
                </button>
              </div>

              {/* Active Component Quick Pill */}
              <div className="bg-gray-900/60 p-2.5 rounded-xl border border-gray-800 flex items-center justify-between">
                <span className="text-gray-400 font-mono text-[11px]">Selected:</span>
                <span className="text-cyan-300 font-bold truncate max-w-[140px] text-right">
                  {selectedComponent?.name || 'All Layers'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
