import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle,
  FileText,
  Filter,
  Lock,
  RefreshCw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { AuditLog, PendingPermissionRequest, PermissionLevel } from '../types.ts';

interface SecurityConsoleProps {
  auditLogs: AuditLog[];
  pendingRequests: PendingPermissionRequest[];
  onApproveTask: (taskId: string) => void;
  onRejectTask: (taskId: string, reason?: string) => void;
}

export const SecurityConsole: React.FC<SecurityConsoleProps> = ({
  auditLogs,
  pendingRequests,
  onApproveTask,
  onRejectTask,
}) => {
  const [levelFilter, setLevelFilter] = useState<string>('all');

  const filteredLogs = auditLogs.filter((log) => {
    if (levelFilter !== 'all' && log.permissionLevel !== levelFilter) return false;
    return true;
  });

  return (
    <div id="security-console-panel" className="space-y-6">
      {/* Security Architecture Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 font-sans">
            <Shield className="w-5 h-5 text-emerald-600" />
            JARVIS Security & Permission Subsystem
          </h2>
          <p className="text-xs text-slate-600 font-mono mt-0.5">
            Strict four-tier boundary model preventing unauthorized execution of sensitive or consequential operations.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-1.5 shadow-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            ZERO-TRUST ACTIVE
          </span>
        </div>
      </div>

      {/* Permission Levels Architecture Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
        <div className="bg-white border border-emerald-200 p-4 rounded-xl shadow-xs">
          <span className="text-[10px] text-emerald-700 font-bold block mb-1 uppercase tracking-wider">TIER 1</span>
          <h4 className="font-bold text-slate-900 mb-1 font-sans">READ</h4>
          <p className="text-slate-600 font-sans text-xs mb-3 leading-relaxed">
            Information retrieval, status queries, static analysis. Safe without side-effects.
          </p>
          <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
            AUTO-ALLOWED
          </span>
        </div>

        <div className="bg-white border border-sky-200 p-4 rounded-xl shadow-xs">
          <span className="text-[10px] text-sky-700 font-bold block mb-1 uppercase tracking-wider">TIER 2</span>
          <h4 className="font-bold text-slate-900 mb-1 font-sans">SAFE_WRITE</h4>
          <p className="text-slate-600 font-sans text-xs mb-3 leading-relaxed">
            Local memory saves, logging, internal scratchpad updates.
          </p>
          <span className="text-[10px] text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-200 font-semibold">
            AUDITED WRITE
          </span>
        </div>

        <div className="bg-white border border-amber-200 p-4 rounded-xl shadow-xs">
          <span className="text-[10px] text-amber-700 font-bold block mb-1 uppercase tracking-wider">TIER 3</span>
          <h4 className="font-bold text-slate-900 mb-1 font-sans">SENSITIVE</h4>
          <p className="text-slate-600 font-sans text-xs mb-3 leading-relaxed">
            Code sandbox evaluation, deep system diagnostics, file manipulations.
          </p>
          <span className="text-[10px] text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-semibold">
            ISOLATED & GATED
          </span>
        </div>

        <div className="bg-white border border-rose-200 p-4 rounded-xl shadow-xs">
          <span className="text-[10px] text-rose-700 font-bold block mb-1 uppercase tracking-wider">TIER 4</span>
          <h4 className="font-bold text-slate-900 mb-1 font-sans">EXTERNAL_ACTION</h4>
          <p className="text-slate-600 font-sans text-xs mb-3 leading-relaxed">
            Webhooks, third-party dispatches, hardware triggers. High real-world consequence.
          </p>
          <span className="text-[10px] text-rose-900 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 font-semibold">
            HUMAN-IN-THE-LOOP
          </span>
        </div>
      </div>

      {/* Pending Authorizations Section */}
      {pendingRequests.length > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-amber-200">
            <div className="flex items-center gap-2 text-amber-900 font-mono text-xs font-bold">
              <ShieldAlert className="w-4 h-4 text-amber-700" />
              <span>PENDING OPERATOR AUTHORIZATION CHALLENGES ({pendingRequests.length})</span>
            </div>
            <span className="text-[10px] font-mono text-amber-800 font-semibold">INTERACTIVE GATING</span>
          </div>

          <div className="space-y-3">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white border border-amber-300 p-4 rounded-xl text-xs font-mono flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{req.action}</span>
                    <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold">
                      {req.permissionLevel}
                    </span>
                    <span className="text-slate-600 text-[11px]">Tool: {req.toolName}</span>
                  </div>
                  <p className="text-slate-600 font-sans text-xs">
                    Task ID: <span className="font-mono text-sky-800 font-bold">{req.taskId}</span> • Step:{' '}
                    <span className="font-mono text-sky-800 font-bold">{req.stepId}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2.5 w-full md:w-auto">
                  <button
                    onClick={() => onApproveTask(req.taskId)}
                    className="flex-1 md:flex-initial px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all shadow-xs text-xs"
                  >
                    GRANT APPROVAL
                  </button>
                  <button
                    onClick={() => onRejectTask(req.taskId, 'Rejected by operator in security console')}
                    className="flex-1 md:flex-initial px-4 py-2 rounded-lg bg-white hover:bg-rose-50 hover:text-rose-700 text-slate-700 border border-slate-300 transition-all text-xs font-medium"
                  >
                    REJECT
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Immutable Audit Trail Log */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-sky-600" />
            <h3 className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider">
              Immutable Kernel Audit Trail
            </h3>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 text-[11px] font-medium">FILTER:</span>
            {['all', 'READ', 'SAFE_WRITE', 'SENSITIVE', 'EXTERNAL_ACTION'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevelFilter(lvl)}
                className={`px-2.5 py-1 rounded-md text-[10px] uppercase transition-all font-semibold ${
                  levelFilter === lvl
                    ? 'bg-sky-50 text-sky-900 border border-sky-300 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2 max-h-96 overflow-y-auto pr-1 scrollbar-thin">
          {filteredLogs.map((log) => {
            const isAllowed = log.status === 'ALLOWED';
            const isDenied = log.status === 'DENIED';
            const isPending = log.status === 'PENDING_APPROVAL';

            return (
              <div
                key={log.id}
                className="bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs font-mono flex items-start justify-between gap-3 shadow-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{log.action}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 font-medium">
                      {log.permissionLevel}
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">Actor: {log.actor}</span>
                  </div>
                  {log.details && (
                    <div className="text-[11px] text-slate-600 truncate max-w-xl">
                      {JSON.stringify(log.details)}
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  <span
                    className={`px-2.5 py-0.5 rounded text-[10px] font-bold border ${
                      isAllowed
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : isDenied
                        ? 'bg-rose-50 text-rose-800 border-rose-200'
                        : 'bg-amber-50 text-amber-900 border-amber-300 animate-pulse'
                    }`}
                  >
                    {log.status}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
