/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Check, Lock, Sparkles } from 'lucide-react';
import { CharacterId, CharacterDef } from '../types/game';
import { CHARACTERS } from '../game/constants';

interface CharacterSelectModalProps {
  selectedCharacterId: CharacterId;
  unlockedCharacters: CharacterId[];
  totalCoins: number;
  onSelectCharacter: (id: CharacterId) => void;
  onUnlockCharacter: (char: CharacterDef) => void;
  onClose: () => void;
}

export const CharacterSelectModal: React.FC<CharacterSelectModalProps> = ({
  selectedCharacterId,
  unlockedCharacters,
  totalCoins,
  onSelectCharacter,
  onUnlockCharacter,
  onClose,
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-none flex items-center justify-center p-4 z-50 pointer-events-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full p-6 text-center shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-white italic tracking-wide">RUNNER ROSTER</h2>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 bg-slate-950 px-3 py-1 rounded-full border border-amber-500/30">
              <div className="w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[10px] font-black text-amber-950">
                $
              </div>
              <span className="font-mono text-amber-300 font-bold text-sm">{totalCoins}</span>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Characters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 my-5 overflow-y-auto pr-1">
          {CHARACTERS.map((char) => {
            const isUnlocked = unlockedCharacters.includes(char.id);
            const isSelected = selectedCharacterId === char.id;
            const canAfford = totalCoins >= char.cost;

            return (
              <div
                key={char.id}
                className={`relative rounded-2xl p-4 flex flex-col items-center justify-between border-2 transition-all ${
                  isSelected
                    ? 'bg-slate-800/90 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)]'
                    : isUnlocked
                    ? 'bg-slate-950/60 border-slate-700/80 hover:border-slate-600'
                    : 'bg-slate-950/40 border-slate-800 opacity-90'
                }`}
              >
                {/* Character Silhouette / Icon Showcase */}
                <div
                  className="w-20 h-20 rounded-2xl flex items-center justify-center shadow-inner mb-3 relative overflow-hidden"
                  style={{
                    backgroundColor: `#${char.colors.shirt.toString(16).padStart(6, '0')}`,
                  }}
                >
                  {/* Hat / Hair accent badge */}
                  <div
                    className="absolute top-2 w-10 h-3 rounded-full"
                    style={{
                      backgroundColor: `#${char.colors.hat.toString(16).padStart(6, '0')}`,
                    }}
                  />
                  <span className="text-3xl">🏃</span>

                  {isSelected && (
                    <div className="absolute top-1 right-1 bg-cyan-500 rounded-full p-1 text-slate-950">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-center mb-3">
                  <h3 className="font-black text-white text-base tracking-wide">{char.name}</h3>
                  <p className="text-[11px] text-slate-400 leading-tight mt-1 line-clamp-2">{char.tagline}</p>
                  <div className="mt-2 text-[10px] uppercase font-bold text-cyan-400 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" />
                    {char.bonusStat}
                  </div>
                </div>

                {/* Button: Select or Buy */}
                {isUnlocked ? (
                  <button
                    onClick={() => onSelectCharacter(char.id)}
                    disabled={isSelected}
                    className={`w-full py-2 rounded-xl font-black text-xs tracking-wider transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950'
                        : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-600'
                    }`}
                  >
                    {isSelected ? 'SELECTED' : 'SELECT'}
                  </button>
                ) : (
                  <button
                    onClick={() => onUnlockCharacter(char)}
                    disabled={!canAfford}
                    className={`w-full py-2 rounded-xl font-black text-xs tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      canAfford
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                    }`}
                  >
                    <Lock className="w-3 h-3" />
                    <span>{char.cost} COINS</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-xs text-slate-400">
          Earn coins during runs to unlock all parkour runners!
        </p>
      </div>
    </div>
  );
};
