import React, { useState, useMemo } from 'react';
import { X, Search, Check, Lock, Zap, Coins, Sparkles } from 'lucide-react';
import { CharacterItem } from '../types/game';
import { HEROES_54, getHeroById } from '../game/characterData';

interface CharacterSelectModalProps {
  selectedCharacterId: number;
  unlockedCharacters: number[];
  coins: number;
  gems: number;
  onSelectCharacter: (char: CharacterItem) => void;
  onUnlockCharacter: (char: CharacterItem) => boolean;
  onClose: () => void;
}

export const CharacterSelectModal: React.FC<CharacterSelectModalProps> = ({
  selectedCharacterId,
  unlockedCharacters,
  coins,
  gems,
  onSelectCharacter,
  onUnlockCharacter,
  onClose
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'الكل' | 'أولاد' | 'فتيات' | 'أبطال خوارق' | 'وحوش وأساطير'>('الكل');
  const [activePreviewId, setActivePreviewId] = useState<number>(selectedCharacterId);

  // Filtered heroes list from the 54 lineup
  const filteredHeroes = useMemo(() => {
    return HEROES_54.filter((h) => {
      if (activeCategory !== 'الكل' && h.category !== activeCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchId = String(h.id) === q || `#${h.id}` === q;
        const matchName = h.arabicName.toLowerCase().includes(q) || h.name.toLowerCase().includes(q);
        if (!matchId && !matchName) return false;
      }
      return true;
    });
  }, [searchQuery, activeCategory]);

  const previewHero = useMemo(() => {
    return getHeroById(activePreviewId);
  }, [activePreviewId]);

  const isPreviewUnlocked = unlockedCharacters.includes(previewHero.id) || previewHero.cost === 0;
  const isPreviewSelected = selectedCharacterId === previewHero.id;

  const handleUnlockClick = () => {
    onUnlockCharacter({
      id: previewHero.id,
      name: previewHero.name,
      arabicName: previewHero.arabicName,
      gender: previewHero.gender,
      category: previewHero.category,
      rarity: previewHero.rarity,
      unlocked: isPreviewUnlocked,
      cost: previewHero.cost,
      costType: previewHero.costType,
      speedBonus: previewHero.speedBonus,
      coinBonus: previewHero.coinBonus,
      description: previewHero.description,
      colors: previewHero.colors
    });
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-2 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-4xl h-[92vh] max-h-[850px] shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/95">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl">
              🦸
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white flex items-center gap-2">
                <span>أبطال صبواي الـ 54</span>
                <span className="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-xs px-2.5 py-0.5 rounded-full font-black">
                  54 بطلاً خارقاً ووحوشاً!
                </span>
              </h2>
              <div className="text-xs text-slate-400">
                تشكيلة غنية ومتنوعة من فتيان وفتيات وأبطال خوارق ووحوش أسطورية
              </div>
            </div>
          </div>

          {/* Currencies & Close */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-800 px-2.5 py-1 rounded-full text-xs font-bold border border-amber-500/30 text-amber-300">
              <span>🪙</span>
              <span className="tabular-nums">{coins.toLocaleString('ar-EG')}</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-800 px-2.5 py-1 rounded-full text-xs font-bold border border-cyan-500/30 text-cyan-300">
              <span>💎</span>
              <span className="tabular-nums">{gems.toLocaleString('ar-EG')}</span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
          {/* 4 Main Categories */}
          <div className="flex items-center flex-wrap gap-1.5 text-xs">
            <button
              onClick={() => setActiveCategory('الكل')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                activeCategory === 'الكل' ? 'bg-amber-500 text-slate-950 font-black shadow-md' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              الكل (54)
            </button>
            <button
              onClick={() => setActiveCategory('أولاد')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'أولاد' ? 'bg-blue-600 text-white font-black shadow-md' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>👦</span>
              <span>الأولاد (14)</span>
            </button>
            <button
              onClick={() => setActiveCategory('فتيات')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'فتيات' ? 'bg-pink-600 text-white font-black shadow-md' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>👧</span>
              <span>الفتيات (14)</span>
            </button>
            <button
              onClick={() => setActiveCategory('أبطال خوارق')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'أبطال خوارق' ? 'bg-amber-600 text-white font-black shadow-md' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>⚡</span>
              <span>أبطال خوارق (13)</span>
            </button>
            <button
              onClick={() => setActiveCategory('وحوش وأساطير')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'وحوش وأساطير' ? 'bg-emerald-600 text-white font-black shadow-md' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>👹</span>
              <span>وحوش وأساطير (13)</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative min-w-[160px] max-w-xs flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث بالاسم أو الرقم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-8 pl-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Content Body: Left/Right Split */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Heroes Grid */}
          <div className="flex-1 overflow-y-auto p-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
              {filteredHeroes.map((hero) => {
                const isUnlocked = unlockedCharacters.includes(hero.id) || hero.cost === 0;
                const isSelected = selectedCharacterId === hero.id;
                const isPreview = activePreviewId === hero.id;

                return (
                  <button
                    key={hero.id}
                    onClick={() => setActivePreviewId(hero.id)}
                    className={`relative flex flex-col items-center justify-between p-2.5 rounded-2xl border transition-all text-center ${
                      isPreview
                        ? 'border-amber-400 bg-amber-500/15 shadow-xl scale-[0.98]'
                        : isSelected
                        ? 'border-emerald-500 bg-slate-800/90'
                        : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80'
                    }`}
                  >
                    {/* Status Top Badges */}
                    <div className="absolute top-1.5 right-1.5 flex items-center gap-1">
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white shadow">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                      {!isUnlocked && (
                        <div className="w-5 h-5 rounded-full bg-slate-950/90 flex items-center justify-center text-amber-400 border border-amber-500/30">
                          <Lock className="w-3 h-3" />
                        </div>
                      )}
                    </div>

                    {/* ID */}
                    <div className="text-[10px] font-bold text-slate-400 self-start">#{hero.id}</div>

                    {/* Avatar Icon */}
                    <div
                      className="w-13 h-13 rounded-2xl flex items-center justify-center text-2xl my-1.5 shadow-lg border-2"
                      style={{
                        backgroundColor: hero.colors.shirt,
                        borderColor: hero.colors.accessory || hero.colors.skin
                      }}
                    >
                      {hero.icon}
                    </div>

                    {/* Name */}
                    <div className="text-xs font-black text-white truncate w-full">
                      {hero.arabicName.split(' ')[0]} {hero.arabicName.split(' ')[1] || ''}
                    </div>

                    {/* Category tag */}
                    <div
                      className={`text-[9px] px-2 py-0.5 rounded-full font-bold mt-1 ${
                        hero.category === 'أولاد'
                          ? 'bg-blue-950 text-blue-300'
                          : hero.category === 'فتيات'
                          ? 'bg-pink-950 text-pink-300'
                          : hero.category === 'أبطال خوارق'
                          ? 'bg-amber-950 text-amber-300'
                          : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {hero.category}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Details & Selection Pane */}
          <div className="w-full md:w-80 bg-slate-950/85 border-t md:border-t-0 md:border-r border-slate-800 p-4 flex flex-col justify-between">
            <div>
              {/* Avatar Centerpiece */}
              <div className="flex flex-col items-center text-center mb-3">
                <div
                  className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl shadow-2xl border-4 mb-2"
                  style={{
                    backgroundColor: previewHero.colors.shirt,
                    borderColor: previewHero.colors.accessory || previewHero.colors.skin
                  }}
                >
                  {previewHero.icon}
                </div>
                <h3 className="text-base font-black text-white">{previewHero.arabicName}</h3>
                <div className="text-xs text-amber-400 font-bold mt-0.5">
                  فئة: {previewHero.category} · {previewHero.rarity}
                </div>
                <div className="text-[11px] text-slate-300 mt-1.5 leading-relaxed px-1">
                  {previewHero.description}
                </div>
              </div>

              {/* Bonus Stats */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2 mb-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-400 font-bold">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span>مكافأة السرعة:</span>
                  </span>
                  <span className="font-black text-cyan-400 tabular-nums">+{previewHero.speedBonus}%</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-400 font-bold">
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>مكافأة العملات:</span>
                  </span>
                  <span className="font-black text-amber-400 tabular-nums">+{previewHero.coinBonus}%</span>
                </div>
              </div>

              {/* Outfit color palette swatches */}
              <div className="text-[11px] text-slate-400 font-bold mb-1.5">ألوان الزي والشخصية:</div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-full border border-white/20 shadow-sm" style={{ backgroundColor: previewHero.colors.shirt }} title="القميص / الدرع" />
                <div className="w-6 h-6 rounded-full border border-white/20 shadow-sm" style={{ backgroundColor: previewHero.colors.pants }} title="البنطال" />
                <div className="w-6 h-6 rounded-full border border-white/20 shadow-sm" style={{ backgroundColor: previewHero.colors.shoes }} title="الحذاء النفاث" />
                <div className="w-6 h-6 rounded-full border border-white/20 shadow-sm" style={{ backgroundColor: previewHero.colors.accessory || previewHero.colors.hair }} title="القبعة / القرون / الوشاح" />
              </div>
            </div>

            {/* CTA Button */}
            <div>
              {isPreviewUnlocked ? (
                <button
                  disabled={isPreviewSelected}
                  onClick={() =>
                    onSelectCharacter({
                      id: previewHero.id,
                      name: previewHero.name,
                      arabicName: previewHero.arabicName,
                      gender: previewHero.gender,
                      category: previewHero.category,
                      rarity: previewHero.rarity,
                      unlocked: true,
                      cost: previewHero.cost,
                      costType: previewHero.costType,
                      speedBonus: previewHero.speedBonus,
                      coinBonus: previewHero.coinBonus,
                      description: previewHero.description,
                      colors: previewHero.colors
                    })
                  }
                  className={`w-full py-3.5 px-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                    isPreviewSelected
                      ? 'bg-emerald-600/50 text-white cursor-default'
                      : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 active:scale-95 cursor-pointer shadow-xl'
                  }`}
                >
                  {isPreviewSelected ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>البطل المجهز حالياً</span>
                    </>
                  ) : (
                    <span>تجهيز البطل للركض الآن</span>
                  )}
                </button>
              ) : (
                <button
                  onClick={handleUnlockClick}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-red-500 hover:from-amber-400 hover:to-red-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl cursor-pointer"
                >
                  <Lock className="w-4 h-4" />
                  <span>فتح البطل مقابل {previewHero.cost.toLocaleString('ar-EG')} 🪙</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
