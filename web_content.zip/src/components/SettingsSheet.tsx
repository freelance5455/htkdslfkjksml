import React from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  Search, 
  EyeOff, 
  Cpu, 
  Cookie, 
  Globe, 
  Trash2, 
  Fingerprint, 
  Check, 
  Server
} from 'lucide-react';
import { PrivacyConfig } from '../types/browser';

interface SettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  config: PrivacyConfig;
  onUpdateConfig: (newConfig: Partial<PrivacyConfig>) => void;
  onClearAllData: () => void;
}

export const SettingsSheet: React.FC<SettingsSheetProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  onClearAllData,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm select-none animate-fade-in">
      <div className="flex-1" onClick={onClose} />

      <div className="w-full max-w-lg mx-auto bg-slate-900 border-t border-slate-700/80 rounded-t-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-slide-up">
        {/* Handle */}
        <div className="pt-3 pb-1 flex justify-center cursor-grab" onClick={onClose}>
          <div className="w-12 h-1.5 rounded-full bg-slate-700" />
        </div>

        {/* Header */}
        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Privacy & Security</h3>
              <p className="text-xs text-slate-400">Android System Protection Engine</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Settings */}
        <div className="p-5 overflow-y-auto space-y-5 no-scrollbar text-xs">
          {/* Section: Search Engine */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <Search className="w-3.5 h-3.5 text-emerald-400" />
              <span>Default Search Engine</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {(['DuckDuckGo', 'Brave Search', 'Startpage', 'SearXNG'] as const).map((engine) => (
                <button
                  key={engine}
                  onClick={() => onUpdateConfig({ searchEngine: engine })}
                  className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                    config.searchEngine === engine
                      ? 'bg-emerald-950/60 border-emerald-500/80 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-850 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="font-semibold">{engine}</span>
                  {config.searchEngine === engine && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Encrypted DNS (DoH) */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              <span>DNS over HTTPS (DoH)</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {(['Cloudflare (1.1.1.1)', 'Quad9 (9.9.9.9)', 'Mullvad DNS', 'AdGuard Privacy'] as const).map((dns) => (
                <button
                  key={dns}
                  onClick={() => onUpdateConfig({ dohProvider: dns })}
                  className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                    config.dohProvider === dns
                      ? 'bg-cyan-950/60 border-cyan-500/80 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-850 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="font-semibold truncate">{dns}</span>
                  {config.dohProvider === dns && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Shields & Hardening Switches */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-2 text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <EyeOff className="w-3.5 h-3.5 text-emerald-400" />
              <span>Protections & Telemetry Jamming</span>
            </div>

            <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
              {/* Block Trackers */}
              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">Block Cross-Site Trackers</p>
                  <p className="text-[11px] text-slate-400">Stop advertising pixels & analytics beacons</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ blockTrackers: !config.blockTrackers })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.blockTrackers ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.blockTrackers ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Block Fingerprinting */}
              <div className="flex items-center justify-between py-1 border-t border-slate-805">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">Canvas & WebGL Fingerprint Jitter</p>
                  <p className="text-[11px] text-slate-400">Randomize pixel readouts so your device cannot be identified</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ blockFingerprinting: !config.blockFingerprinting })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.blockFingerprinting ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.blockFingerprinting ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Third-Party Cookies */}
              <div className="flex items-center justify-between py-1 border-t border-slate-805">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">Block 3rd-Party Cookies</p>
                  <p className="text-[11px] text-slate-400">Isolate storage into temporary per-tab containers</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ blockThirdPartyCookies: !config.blockThirdPartyCookies })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.blockThirdPartyCookies ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.blockThirdPartyCookies ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* HTTPS Everywhere */}
              <div className="flex items-center justify-between py-1 border-t border-slate-805">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">HTTPS-Only Mode</p>
                  <p className="text-[11px] text-slate-400">Automatically upgrade all connections to TLS 1.3</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ enforceHttps: !config.enforceHttps })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.enforceHttps ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.enforceHttps ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Tor Onion Circuit */}
              <div className="flex items-center justify-between py-1 border-t border-slate-805">
                <div>
                  <p className="font-semibold text-purple-300 text-xs flex items-center gap-1.5">
                    <span>Tor Onion Routing Circuit</span>
                    <span className="text-[9px] uppercase px-1 py-0.2 rounded bg-purple-950 border border-purple-700/60 text-purple-300">
                      3 Hops
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-400">Route traffic via Guard, Middle, and Exit relays</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ torRouting: !config.torRouting })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.torRouting ? 'bg-purple-600' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.torRouting ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Section: Device & Storage Security */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-2 text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Device & Session Hygiene</span>
            </div>

            <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
              {/* Clear on exit */}
              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">Clear Data When Leaving App</p>
                  <p className="text-[11px] text-slate-400">Destroy RAM and ephemeral tab state immediately</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ clearOnExit: !config.clearOnExit })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.clearOnExit ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.clearOnExit ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Biometric lock */}
              <div className="flex items-center justify-between py-1 border-t border-slate-805">
                <div>
                  <p className="font-semibold text-slate-200 text-xs">Biometric App Lock</p>
                  <p className="text-[11px] text-slate-400">Require fingerprint / device PIN on resume</p>
                </div>
                <button
                  onClick={() => onUpdateConfig({ biometricLock: !config.biometricLock })}
                  className={`w-10 h-6 rounded-full relative p-0.5 transition-colors ${
                    config.biometricLock ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${config.biometricLock ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Clear Data Button */}
          <div className="pt-2">
            <button
              onClick={() => {
                onClearAllData();
                onClose();
              }}
              className="w-full py-3 rounded-2xl bg-red-950/50 hover:bg-red-900/60 border border-red-800/60 text-red-300 font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Trash2 className="w-4 h-4" />
              <span>Purge All Browsing Traces & Cache</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
