import React from 'react';
import { Check, Link2, Unlink, X } from 'lucide-react';
import type {
  AppThemeSettings,
  ColorMode,
  FitMode,
  PageTransition,
  ReaderSettings,
  ReadingMode,
  ScreenOrientationMode,
} from '../types/comic';
import { PWAInstallButton } from './PWAInstallButton';

export const ACCENT_SWATCHES = [
  { name: 'Crimson Ink', value: '#e11d48' },
  { name: 'Cobalt', value: '#2563eb' },
  { name: 'Emerald', value: '#059669' },
  { name: 'Amber', value: '#d97706' },
  { name: 'Indigo', value: '#4f46e5' },
  { name: 'Monochrome', value: '#52525b' },
];

export const READER_BG_SWATCHES = [
  { name: 'AMOLED Black', value: '#000000' },
  { name: 'Charcoal', value: '#0b0b0d' },
  { name: 'Slate', value: '#181c24' },
  { name: 'Warm Paper', value: '#f4efe6' },
  { name: 'Crisp White', value: '#ffffff' },
];

interface SettingsSheetProps {
  isOpen: boolean;
  onClose?: () => void;
  asPage?: boolean;
  theme: AppThemeSettings;
  readerSettings: ReaderSettings;
  onChangeTheme: (next: AppThemeSettings) => void;
  onChangeReader: (next: ReaderSettings) => void;
}

export const SettingsContent: React.FC<{
  theme: AppThemeSettings;
  readerSettings: ReaderSettings;
  onChangeTheme: (next: AppThemeSettings) => void;
  onChangeReader: (next: ReaderSettings) => void;
}> = ({ theme, readerSettings, onChangeTheme, onChangeReader }) => {
  const updateMargins = (side: 'left' | 'right', val: number) => {
    if (readerSettings.marginLinked) {
      onChangeReader({ ...readerSettings, marginLeft: val, marginRight: val });
    } else if (side === 'left') {
      onChangeReader({ ...readerSettings, marginLeft: val });
    } else {
      onChangeReader({ ...readerSettings, marginRight: val });
    }
  };

  return (
    <div className="space-y-8">
      {/* App Appearance */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
              App Appearance
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Surface theme, custom accent color, and library density
            </p>
          </div>
          <PWAInstallButton variant="settings" />
        </div>

        <div className="space-y-3">
          <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-400">
            Base Surface Mode
          </label>
          <div className="grid grid-cols-3 gap-2 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(['light', 'dark', 'amoled'] as ColorMode[]).map((mode) => {
              const active = theme.colorMode === mode;
              return (
                <button
                  key={mode}
                  type="button"
                  onClick={() => onChangeTheme({ ...theme, colorMode: mode })}
                  className={`min-h-[44px] px-3 rounded-lg text-xs font-medium capitalize transition-colors ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                  }`}
                >
                  {mode === 'amoled' ? 'AMOLED Black' : mode}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              App Theme Color
            </label>
            <span className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 uppercase">
              {theme.accentColor}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            {ACCENT_SWATCHES.map((swatch) => {
              const selected = theme.accentColor.toLowerCase() === swatch.value.toLowerCase();
              return (
                <button
                  key={swatch.value}
                  type="button"
                  onClick={() => onChangeTheme({ ...theme, accentColor: swatch.value })}
                  title={swatch.name}
                  aria-label={`Select ${swatch.name} accent color`}
                  className="w-11 h-11 rounded-xl flex items-center justify-center border border-black/10 dark:border-white/10 transition-transform active:scale-95"
                  style={{ backgroundColor: swatch.value }}
                >
                  {selected && <Check className="w-4 h-4 text-white" />}
                </button>
              );
            })}
            <label
              className="w-11 h-11 rounded-xl border border-zinc-300 dark:border-zinc-700 flex items-center justify-center cursor-pointer overflow-hidden relative bg-zinc-100 dark:bg-zinc-800"
              title="Custom accent hex color"
            >
              <input
                type="color"
                value={theme.accentColor}
                onChange={(e) => onChangeTheme({ ...theme, accentColor: e.target.value })}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                aria-label="Pick custom app theme color"
              />
              <span
                className="w-6 h-6 rounded-md border border-black/15"
                style={{ backgroundColor: theme.accentColor }}
              />
            </label>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-400">
            Shelf Grid Density
          </label>
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(['comfortable', 'compact'] as const).map((density) => {
              const active = theme.gridDensity === density;
              return (
                <button
                  key={density}
                  type="button"
                  onClick={() => onChangeTheme({ ...theme, gridDensity: density })}
                  className={`min-h-[44px] px-3 rounded-lg text-xs font-medium capitalize transition-colors ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {density}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <hr className="border-zinc-200/80 dark:border-zinc-800" />

      {/* Reader Layout & Tablet Ergonomics */}
      <section className="space-y-5">
        <div>
          <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
            Reader Viewport &amp; Margins
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Tailored for Android tablets, vertical strips, and page-wise reading
          </p>
        </div>

        {/* Reading Mode */}
        <div className="space-y-2">
          <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-400">
            Reading Mode
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(
              [
                { id: 'vertical', label: 'Continuous V' },
                { id: 'paged-vertical', label: 'Paged V' },
                { id: 'horizontal-ltr', label: 'Page LTR' },
                { id: 'horizontal-rtl', label: 'Manga RTL' },
              ] as { id: ReadingMode; label: string }[]
            ).map((opt) => {
              const active = readerSettings.readingMode === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeReader({ ...readerSettings, readingMode: opt.id })}
                  className={`min-h-[44px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Screen Orientation */}
        <div className="space-y-2">
          <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-400">
            Screen Orientation
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(
              [
                { id: 'free', label: 'Free Rotate' },
                { id: 'portrait', label: 'Portrait' },
                { id: 'portrait-reverse', label: 'Rev. Portrait' },
                { id: 'landscape', label: 'Landscape' },
              ] as { id: ScreenOrientationMode; label: string }[]
            ).map((opt) => {
              const active = (readerSettings.orientationMode || 'free') === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeReader({ ...readerSettings, orientationMode: opt.id })}
                  className={`min-h-[40px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Page Transition Effects */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Page Transition Effect
            </label>
            <span className="text-xs text-zinc-400 dark:text-zinc-500">
              Page-wise modes
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(
              [
                { id: 'slide', label: 'Slide' },
                { id: 'fade', label: 'Fade' },
                { id: 'curl', label: 'Page Curl' },
                { id: 'zoom', label: 'Zoom' },
                { id: 'stack', label: 'Stack' },
                { id: 'none', label: 'None' },
              ] as { id: PageTransition; label: string }[]
            ).map((opt) => {
              const active = (readerSettings.pageTransition || 'slide') === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeReader({ ...readerSettings, pageTransition: opt.id })}
                  className={`min-h-[40px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Reader Background Color */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Reader Background Color
            </label>
            <span className="text-xs font-mono-nums text-zinc-500 dark:text-zinc-400 uppercase">
              {readerSettings.readerBg}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            {READER_BG_SWATCHES.map((swatch) => {
              const selected = readerSettings.readerBg.toLowerCase() === swatch.value.toLowerCase();
              const isLight = swatch.value === '#ffffff' || swatch.value === '#f4efe6';
              return (
                <button
                  key={swatch.value}
                  type="button"
                  onClick={() => onChangeReader({ ...readerSettings, readerBg: swatch.value })}
                  title={swatch.name}
                  aria-label={`Set reader background to ${swatch.name}`}
                  className="w-11 h-11 rounded-xl flex items-center justify-center border border-zinc-300 dark:border-zinc-700 transition-transform active:scale-95"
                  style={{ backgroundColor: swatch.value }}
                >
                  {selected && (
                    <Check className={`w-4 h-4 ${isLight ? 'text-zinc-900' : 'text-white'}`} />
                  )}
                </button>
              );
            })}
            <label
              className="w-11 h-11 rounded-xl border border-zinc-300 dark:border-zinc-700 flex items-center justify-center cursor-pointer overflow-hidden relative bg-zinc-100 dark:bg-zinc-800"
              title="Custom reader background hex color"
            >
              <input
                type="color"
                value={readerSettings.readerBg}
                onChange={(e) => onChangeReader({ ...readerSettings, readerBg: e.target.value })}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                aria-label="Pick custom reader background color"
              />
              <span
                className="w-6 h-6 rounded-md border border-zinc-400/40"
                style={{ backgroundColor: readerSettings.readerBg }}
              />
            </label>
          </div>
        </div>

        {/* Fit & Custom Zoom Level */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Zoom &amp; Tablet Scaling
            </label>
            <span className="text-xs font-mono-nums text-zinc-700 dark:text-zinc-300">
              {readerSettings.fitMode === 'custom'
                ? `${readerSettings.customZoom}%`
                : readerSettings.fitMode.replace('-', ' ')}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80">
            {(
              [
                { id: 'fit-width', label: 'Width' },
                { id: 'fit-height', label: 'Height' },
                { id: 'fit-screen', label: 'Screen' },
                { id: 'custom', label: 'Custom' },
              ] as { id: FitMode; label: string }[]
            ).map((opt) => {
              const active = readerSettings.fitMode === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeReader({ ...readerSettings, fitMode: opt.id })}
                  className={`min-h-[40px] px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-3 pt-1">
            <span className="text-xs text-zinc-500 font-mono-nums w-10">50%</span>
            <input
              type="range"
              min={50}
              max={250}
              step={5}
              value={readerSettings.customZoom}
              onChange={(e) =>
                onChangeReader({
                  ...readerSettings,
                  fitMode: 'custom',
                  customZoom: Number(e.target.value),
                })
              }
              className="koma-slider flex-1"
              aria-label="Custom zoom percentage"
            />
            <span className="text-xs text-zinc-500 font-mono-nums w-12 text-right">
              {readerSettings.customZoom}%
            </span>
          </div>
        </div>

        {/* Left & Right Margins for Continuous Vertical Scroll */}
        <div className="space-y-3 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200/70 dark:border-zinc-800">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                Continuous Vertical Margins
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Set independent or linked left &amp; right reading margins
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                onChangeReader({
                  ...readerSettings,
                  marginLinked: !readerSettings.marginLinked,
                  marginRight: !readerSettings.marginLinked
                    ? readerSettings.marginLeft
                    : readerSettings.marginRight,
                })
              }
              className="min-h-[40px] px-3 rounded-xl border border-zinc-200 dark:border-zinc-700 inline-flex items-center gap-1.5 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0"
            >
              {readerSettings.marginLinked ? (
                <>
                  <Link2 className="w-3.5 h-3.5" />
                  <span>Linked</span>
                </>
              ) : (
                <>
                  <Unlink className="w-3.5 h-3.5" />
                  <span>Split</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-2.5 pt-1">
            <div className="flex items-center gap-3">
              <span className="text-xs text-zinc-600 dark:text-zinc-400 w-12">Left</span>
              <input
                type="range"
                min={0}
                max={30}
                step={1}
                value={readerSettings.marginLeft}
                onChange={(e) => updateMargins('left', Number(e.target.value))}
                className="koma-slider flex-1"
                aria-label="Vertical mode left margin percentage"
              />
              <span className="text-xs font-mono-nums text-zinc-700 dark:text-zinc-300 w-10 text-right">
                {readerSettings.marginLeft}%
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-zinc-600 dark:text-zinc-400 w-12">Right</span>
              <input
                type="range"
                min={0}
                max={30}
                step={1}
                value={readerSettings.marginRight}
                onChange={(e) => updateMargins('right', Number(e.target.value))}
                className="koma-slider flex-1"
                aria-label="Vertical mode right margin percentage"
              />
              <span className="text-xs font-mono-nums text-zinc-700 dark:text-zinc-300 w-10 text-right">
                {readerSettings.marginRight}%
              </span>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs text-zinc-600 dark:text-zinc-400 w-12">Gap</span>
              <input
                type="range"
                min={0}
                max={32}
                step={2}
                value={readerSettings.pageGap}
                onChange={(e) =>
                  onChangeReader({ ...readerSettings, pageGap: Number(e.target.value) })
                }
                className="koma-slider flex-1"
                aria-label="Vertical page gap in pixels"
              />
              <span className="text-xs font-mono-nums text-zinc-700 dark:text-zinc-300 w-10 text-right">
                {readerSettings.pageGap}px
              </span>
            </div>
          </div>
        </div>

        {/* Performance & Hardware Acceleration */}
        <div className="space-y-3">
          <label className="flex items-center justify-between gap-4 min-h-[44px] cursor-pointer">
            <div>
              <span className="block text-sm font-medium text-zinc-900 dark:text-zinc-100">
                Hardware Acceleration &amp; Bitmap Pre-Decode
              </span>
              <span className="block text-xs text-zinc-500 dark:text-zinc-400">
                Uses GPU-composited layers and off-thread ImageBitmap decoding
              </span>
            </div>
            <input
              type="checkbox"
              checked={readerSettings.hardwareAccel}
              onChange={(e) =>
                onChangeReader({ ...readerSettings, hardwareAccel: e.target.checked })
              }
              className="w-5 h-5 accent-rose-600 rounded shrink-0"
            />
          </label>

          <label className="flex items-center justify-between gap-4 min-h-[44px] cursor-pointer">
            <div>
              <span className="block text-sm font-medium text-zinc-900 dark:text-zinc-100">
                Long Vertical Strip GPU Slicer
              </span>
              <span className="block text-xs text-zinc-500 dark:text-zinc-400">
                Automatically splits tall webtoon images (&gt;3000px) into 2048px GPU tiles
              </span>
            </div>
            <input
              type="checkbox"
              checked={readerSettings.sliceLongStrips}
              onChange={(e) =>
                onChangeReader({ ...readerSettings, sliceLongStrips: e.target.checked })
              }
              className="w-5 h-5 accent-rose-600 rounded shrink-0"
            />
          </label>

          <label className="flex items-center justify-between gap-4 min-h-[44px] cursor-pointer">
            <div>
              <span className="block text-sm font-medium text-zinc-900 dark:text-zinc-100">
                Show Page Counter Overlay
              </span>
              <span className="block text-xs text-zinc-500 dark:text-zinc-400">
                Subtle page indicator at the bottom corner while reading
              </span>
            </div>
            <input
              type="checkbox"
              checked={readerSettings.showPageNumberHud}
              onChange={(e) =>
                onChangeReader({ ...readerSettings, showPageNumberHud: e.target.checked })
              }
              className="w-5 h-5 accent-rose-600 rounded shrink-0"
            />
          </label>
        </div>
      </section>
    </div>
  );
};

export const SettingsSheet: React.FC<SettingsSheetProps> = ({
  isOpen,
  onClose,
  theme,
  readerSettings,
  onChangeTheme,
  onChangeReader,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm sm:p-4"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-xl max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sm:hidden w-10 h-1 bg-zinc-300 dark:bg-zinc-700 rounded-full mx-auto mt-3 shrink-0" />
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-200/80 dark:border-zinc-800">
          <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
            Reader &amp; Theme Settings
          </h2>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              aria-label="Close settings"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
        <div className="overflow-y-auto p-5">
          <SettingsContent
            theme={theme}
            readerSettings={readerSettings}
            onChangeTheme={onChangeTheme}
            onChangeReader={onChangeReader}
          />
        </div>
      </div>
    </div>
  );
};
