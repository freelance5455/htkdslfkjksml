import { useState } from "react";
import { fa, faDec } from "@/lib/format";
import type { Book, Settings } from "@/lib/types";
import { cn } from "@/utils/cn";
import {
  IconBook,
  IconGrid,
  IconLeaf,
  IconMoon,
  IconReset,
  IconScan,
  IconSun,
  IconSwipe,
  IconTrash,
} from "./Icons";
import { Btn, Segmented, Sheet, Slider, Switch } from "./ui";

interface Props {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  update: (patch: Partial<Settings>) => void;
  book: Book | null;
  readingPageCount?: number;
  ocrPages?: number;
  onRedoOcr?: () => void;
  onResetProgress: () => void;
  onDeleteBook: () => void;
}

function SectionTitle({ children, icon }: { children: React.ReactNode; icon: React.ReactNode }) {
  return (
    <div className="mb-3 mt-6 flex items-center gap-2">
      <span className="grid h-7 w-7 place-items-center rounded-lg border border-gold/25 bg-gold/10 text-gold2">
        {icon}
      </span>
      <h3 className="font-display text-[18px] text-chalk">{children}</h3>
      <span className="ms-1 h-px flex-1 bg-gradient-to-l from-line to-transparent" />
    </div>
  );
}

export function SettingsSheet({
  open,
  onClose,
  settings,
  update,
  book,
  readingPageCount,
  ocrPages,
  onRedoOcr,
  onResetProgress,
  onDeleteBook,
}: Props) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const sample = "کتاب همان کلماتِ صفحهٔ اصلی است؛ اما این‌بار نوشته‌ها از فایل استخراج می‌شوند و در صفحه‌هایی تازه، با قلمی درشت و خوانا دوباره چیده می‌شوند.";

  return (
    <Sheet
      open={open}
      onClose={() => {
        setConfirmDelete(false);
        onClose();
      }}
      title="تنظیمات خواندن"
      subtitle="بازچینی واقعی متن PDF، نه برش یا بزرگ‌نمایی تصویر آن"
      footer={
        <div className="flex items-center justify-between gap-3">
          <span className="text-[11px] text-mist">
            {book
              ? `${fa(book.pageCount)} صفحهٔ PDF${readingPageCount ? `  ←  ${fa(readingPageCount)} صفحهٔ خواندنی` : ""}`
              : "پیش‌فرض برای کتاب‌های جدید"}
          </span>
          <Btn onClick={onClose}>{book ? "ادامهٔ خواندن" : "ذخیره و بستن"}</Btn>
        </div>
      }
    >
      <div className="mt-2 overflow-hidden rounded-2xl border border-line bg-ink2/70">
        <div className="flex items-center justify-between border-b border-line/70 px-3 py-2 text-[10.5px] text-mist">
          <span>پیش‌نمایش قلم جدید</span>
          <span className="font-medium text-jade">متن قابل انتخاب و کپی کردن</span>
        </div>
        <div
          dir="rtl"
          className={cn(
            "max-h-[160px] overflow-hidden px-4 py-3 transition-all duration-300",
            settings.theme === "paper" && "bg-[#fbf9f4] text-[#29251f]",
            settings.theme === "sepia" && "bg-[#eee0c7] text-[#403428]",
            settings.theme === "night" && "bg-[#141b23] text-[#e3e8e8]",
          )}
          style={{ fontSize: settings.fontSize, lineHeight: settings.lineHeight }}
        >
          {sample}
        </div>
      </div>

      <SectionTitle icon={<IconBook size={16} />}>اندازه و صفحه‌بندی متن</SectionTitle>
      <div className="space-y-4 rounded-2xl border border-line/70 bg-ink2/45 p-4">
        <Slider
          label="اندازهٔ نوشته"
          min={16}
          max={40}
          step={1}
          value={settings.fontSize}
          onChange={(fontSize) => update({ fontSize })}
          hint={`${fa(settings.fontSize)} پیکسل`}
        />
        <Slider
          label="تعداد خط در هر صفحهٔ جدید"
          min={8}
          max={45}
          step={1}
          value={settings.linesPerPage}
          onChange={(linesPerPage) => update({ linesPerPage })}
          hint={`${fa(settings.linesPerPage)} خط`}
          accent="#4bb6a0"
        />
        <Slider
          label="فاصلهٔ بین خطوط"
          min={1.3}
          max={2.4}
          step={0.1}
          value={settings.lineHeight}
          onChange={(lineHeight) => update({ lineHeight: Math.round(lineHeight * 10) / 10 })}
          hint={`${faDec(settings.lineHeight)} برابر`}
        />
      </div>
      <p className="mt-2 text-[11px] leading-6 text-mist">
        متن هر صفحهٔ PDF استخراج و با همین اندازهٔ قلم دوباره سطرچینی می‌شود. هر
        صفحهٔ جدید حداکثر {fa(settings.linesPerPage)} خط دارد؛ اگر همهٔ خطوط در ارتفاع
        گوشی جا نشوند، همان صفحه را عمودی اسکرول کنید. تعداد صفحه‌های تازه بسته به
        طول متن و اندازهٔ قلم تغییر می‌کند.
      </p>

      <SectionTitle icon={<IconGrid size={16} />}>چیدمان و ظاهر</SectionTitle>
      <span className="mb-2 block text-[13px] font-medium text-chalk/90">جهت نوشتار</span>
      <Segmented
        value={settings.direction}
        onChange={(direction) => update({ direction })}
        options={[
          { value: "auto", label: "خودکار" },
          { value: "rtl", label: "فارسی" },
          { value: "ltr", label: "چپ‌به‌راست" },
        ]}
      />
      <p className="mt-1.5 text-[10.5px] leading-5 text-mist">
        حالت خودکار زبان هر صفحه را از متن آن تشخیص می‌دهد.
      </p>
      <span className="mb-2 mt-4 block text-[13px] font-medium text-chalk/90">رنگ صفحه</span>
      <Segmented
        value={settings.theme}
        onChange={(theme) => update({ theme })}
        accent="jade"
        options={[
          { value: "paper", label: "کاغذی", icon: <IconSun size={14} /> },
          { value: "sepia", label: "سپیا", icon: <IconLeaf size={14} /> },
          { value: "night", label: "شب", icon: <IconMoon size={14} /> },
        ]}
      />

      <SectionTitle icon={<IconScan size={16} />}>PDF تصویری (اسکن‌شده)</SectionTitle>
      <div className="rounded-2xl border border-line/70 bg-ink2/45 p-3">
        <Switch
          checked={settings.ocr}
          onChange={(ocr) => update({ ocr })}
          label="تشخیص نوری متن (OCR)"
          note="صفحه‌هایی که متن ندارند و فقط تصویرند، اسکن و به متن قابل بازچینی تبدیل می‌شوند."
        />
        {settings.ocr && (
          <div className="mt-3 space-y-3 border-t border-line/60 pt-3">
            <div>
              <span className="mb-2 block text-[13px] font-medium text-chalk/90">زبان کتاب</span>
              <Segmented
                size="sm"
                value={settings.ocrLang}
                onChange={(ocrLang) => update({ ocrLang })}
                options={[
                  { value: "fas", label: "فارسی" },
                  { value: "fas+eng", label: "دوزبانه" },
                  { value: "ara", label: "عربی" },
                  { value: "eng", label: "انگلیسی" },
                ]}
              />
            </div>
            <p className="-mt-1 text-[10.5px] leading-5 text-mist">
              برای کتاب فارسی «فارسی» دقیق‌تر و سریع‌تر است؛ «دوزبانه» فقط برای کتاب‌هایی با متن انگلیسی زیاد.
            </p>
            <Switch
              checked={settings.ocrForce}
              onChange={(ocrForce) => update({ ocrForce })}
              label="OCR برای همهٔ صفحه‌ها"
              note="اگر PDF متن دارد اما حروفش به‌هم‌ریخته یا ناخوانا استخراج می‌شود، این را روشن کنید."
            />
            {book && onRedoOcr && (
              <div className="flex items-center justify-between gap-3 rounded-xl bg-panel/60 px-3 py-2">
                <span className="text-[11px] leading-5 text-mist">
                  {ocrPages ? `${fa(ocrPages)} صفحه از این کتاب با OCR تبدیل شده و ذخیره است.` : "هنوز صفحه‌ای OCR نشده."}
                </span>
                <Btn variant="outline" className="shrink-0 !px-3 !py-1.5" onClick={onRedoOcr}>
                  OCR دوباره
                </Btn>
              </div>
            )}
          </div>
        )}
      </div>
      <p className="mt-2 text-[10.5px] leading-5 text-mist">
        پردازش روی همین گوشی انجام می‌شود و تصویر جایی فرستاده نمی‌شود. بار اول دادهٔ زبان (حدود
        ۲ تا ۱۰ مگابایت) از اینترنت دریافت و ذخیره می‌شود. هر صفحه چند ثانیه طول می‌کشد؛ صفحه‌ای که
        می‌خوانید زودتر از بقیه پردازش می‌شود و متن تشخیص‌داده‌شده برای دفعه‌های بعد نگه داشته می‌شود.
      </p>

      <SectionTitle icon={<IconSwipe size={16} />}>ورق زدن و ذخیره</SectionTitle>
      <div className="rounded-2xl border border-line/70 bg-ink2/45 p-3">
        <Switch
          checked={settings.tapZones}
          onChange={(tapZones) => update({ tapZones })}
          label="ضربه روی لبه‌ها برای ورق زدن"
          note="همیشه می‌توانید با کشیدن افقی به صفحهٔ بعد بروید."
        />
        <div className="my-2 h-px bg-line/60" />
        <Switch
          checked={settings.autoSave}
          onChange={(autoSave) => update({ autoSave })}
          label="ذخیرهٔ خودکار جای مطالعه"
          note="جای دقیق کلمه در متن اصلی ذخیره می‌شود؛ با تغییر قلم هم گم نمی‌شود."
        />
      </div>

      {book && (
        <>
          <SectionTitle icon={<IconReset size={16} />}>این کتاب</SectionTitle>
          <div className="flex flex-wrap gap-2">
            <Btn variant="outline" onClick={onResetProgress}>
              <IconReset size={16} /> آغاز دوباره
            </Btn>
            {confirmDelete ? (
              <div className="flex items-center gap-2 rounded-xl border border-ember/40 bg-ember/10 px-2 py-1">
                <span className="text-[11px] text-ember">حذف شود؟</span>
                <Btn variant="danger" className="!px-3 !py-1.5" onClick={onDeleteBook}>
                  حذف
                </Btn>
                <Btn variant="ghost" className="!px-3 !py-1.5" onClick={() => setConfirmDelete(false)}>
                  انصراف
                </Btn>
              </div>
            ) : (
              <Btn variant="danger" onClick={() => setConfirmDelete(true)}>
                <IconTrash size={16} /> حذف کتاب
              </Btn>
            )}
          </div>
        </>
      )}
      <div className="h-6" />
    </Sheet>
  );
}
