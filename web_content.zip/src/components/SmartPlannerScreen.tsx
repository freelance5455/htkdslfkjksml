import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Task, Priority, TaskCategory } from '../types';
import {
  Sparkles,
  Plus,
  Clock,
  CheckCircle2,
  Circle,
  Trash2,
  Filter,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const SmartPlannerScreen: React.FC = () => {
  const { tasks, addTask, toggleTask, deleteTask, aiAutoSchedule } = useApp();

  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('day');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedDateOffset, setSelectedDateOffset] = useState<number>(0);
  const [isAddingTask, setIsAddingTask] = useState(false);

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<TaskCategory>('work');
  const [newPriority, setNewPriority] = useState<Priority>('medium');
  const [newTime, setNewTime] = useState('10:00 AM');
  const [newDuration, setNewDuration] = useState(45);
  const [newNotes, setNewNotes] = useState('');

  // Generate 7-day horizontal strip
  const dates = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i - 1);
    return {
      offset: i - 1,
      dayName: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
      dayNumber: d.getDate(),
      fullDateStr: d.toISOString().split('T')[0],
      isToday: i === 1,
    };
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    addTask({
      title: newTitle.trim(),
      category: newCategory,
      priority: newPriority,
      time: newTime,
      durationMinutes: newDuration,
      completed: false,
      date: new Date().toISOString().split('T')[0],
      notes: newNotes.trim() || undefined,
    });
    setNewTitle('');
    setNewNotes('');
    setIsAddingTask(false);
  };

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (selectedCategory !== 'all' && t.category !== selectedCategory) return false;
    if (selectedPriority !== 'all' && t.priority !== selectedPriority) return false;
    return true;
  });

  const completedCount = filteredTasks.filter((t) => t.completed).length;

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-4">
      {/* 1. Header with View Switcher */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Schedule & Planner
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {completedCount} of {filteredTasks.length} tasks completed
          </p>
        </div>

        {/* View Mode Segmented Control */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
          {(['day', 'week', 'month'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => {
                sound.playClick();
                setViewMode(mode);
              }}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg capitalize transition-colors ${
                viewMode === mode
                  ? 'bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Horizontal Date Strip */}
      <div className="flex items-center justify-between gap-1.5 p-1.5 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-2xs">
        {dates.map((d) => {
          const isSelected = selectedDateOffset === d.offset;
          return (
            <button
              key={d.offset}
              onClick={() => {
                sound.playClick();
                setSelectedDateOffset(d.offset);
              }}
              className={`flex-1 py-2 px-1 flex flex-col items-center justify-center rounded-xl transition-all ${
                isSelected
                  ? 'bg-gradient-to-b from-indigo-600 to-indigo-700 text-white shadow-sm shadow-indigo-600/30'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-600 dark:text-slate-400'
              }`}
            >
              <span
                className={`text-[10px] font-medium uppercase ${
                  isSelected ? 'text-indigo-100' : 'text-slate-400'
                }`}
              >
                {d.dayName}
              </span>
              <span className="text-sm font-bold font-mono mt-0.5">{d.dayNumber}</span>
              {d.isToday && (
                <span
                  className={`w-1 h-1 rounded-full mt-1 ${
                    isSelected ? 'bg-white' : 'bg-indigo-600 dark:bg-indigo-400'
                  }`}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* 3. AI Auto-Schedule & Quick Add Toolbar */}
      <div className="flex items-center gap-2">
        <button
          onClick={aiAutoSchedule}
          className="flex-1 py-2.5 px-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm shadow-indigo-600/20 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>AI Auto-Schedule</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setIsAddingTask(true);
          }}
          className="py-2.5 px-3.5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98] transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* 4. Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 text-xs">
        {['all', 'work', 'personal', 'health', 'finance', 'learning'].map((cat) => (
          <button
            key={cat}
            onClick={() => {
              sound.playClick();
              setSelectedCategory(cat);
            }}
            className={`px-3 py-1 rounded-full font-medium capitalize whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-700'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:border-slate-300'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 5. Add Task Modal Drawer */}
      {isAddingTask && (
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800/80 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Add New Task
            </h4>
            <button
              onClick={() => setIsAddingTask(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleCreateTask} className="space-y-3">
            <input
              type="text"
              required
              placeholder="What do you need to accomplish?"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Time
                </label>
                <input
                  type="text"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  placeholder="e.g. 10:30 AM"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as TaskCategory)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                >
                  <option value="work">Work</option>
                  <option value="personal">Personal</option>
                  <option value="health">Health</option>
                  <option value="finance">Finance</option>
                  <option value="learning">Learning</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Priority
                </label>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as Priority)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                >
                  <option value="high">High Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="low">Low Priority</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Duration (min)
                </label>
                <input
                  type="number"
                  min="5"
                  step="5"
                  value={newDuration}
                  onChange={(e) => setNewDuration(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              Add to Schedule
            </button>
          </form>
        </div>
      )}

      {/* 6. Tasks Timeline List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="py-12 text-center bg-white dark:bg-slate-800/80 rounded-3xl border border-slate-200 dark:border-slate-700 p-6">
            <CalendarIcon className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              No tasks scheduled for this filter
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Add a task or tap AI Auto-Schedule to plan your day.
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-4 rounded-2xl border transition-all flex items-start gap-3.5 group ${
                task.completed
                  ? 'bg-slate-50/80 dark:bg-slate-900/50 border-slate-200/60 dark:border-slate-800 opacity-70'
                  : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-slate-300'
              }`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className="mt-0.5 text-slate-400 hover:text-indigo-600 transition-colors"
                aria-label={task.completed ? 'Mark incomplete' : 'Mark completed'}
              >
                {task.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                ) : (
                  <Circle className="w-5 h-5 hover:text-indigo-500" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h4
                    className={`text-xs sm:text-sm font-bold truncate ${
                      task.completed
                        ? 'line-through text-slate-400 dark:text-slate-500'
                        : 'text-slate-900 dark:text-white'
                    }`}
                  >
                    {task.title}
                  </h4>

                  {task.aiSuggested && (
                    <span className="text-[10px] font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-1.5 py-0.5 rounded-md flex items-center gap-1 shrink-0">
                      <Sparkles className="w-2.5 h-2.5" /> AI
                    </span>
                  )}
                </div>

                {task.notes && (
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                    {task.notes}
                  </p>
                )}

                <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                  <span className="flex items-center gap-1 font-mono font-medium text-slate-700 dark:text-slate-300">
                    <Clock className="w-3 h-3 text-indigo-500" />
                    {task.time}
                  </span>
                  <span>·</span>
                  <span className="font-mono">{task.durationMinutes}m</span>
                  <span>·</span>
                  <span className="capitalize">{task.category}</span>
                  {task.priority === 'high' && (
                    <>
                      <span>·</span>
                      <span className="text-rose-500 font-semibold">High</span>
                    </>
                  )}
                </div>
              </div>

              <button
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-500 transition-opacity"
                title="Delete task"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
