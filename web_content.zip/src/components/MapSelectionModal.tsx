import React, { useState } from 'react';
import { MAP_CATALOG, MapInfo } from '../game/map/MapRegistry';
import { DifficultyManager, DifficultyLevel, DifficultySettings } from '../game/difficulty/DifficultyManager';
import { sound } from '../audio/SoundEngine';
import { MapPin, Trophy, ShieldAlert, Play, X, Compass, ChevronRight, Skull } from 'lucide-react';

interface MapSelectionModalProps {
  currentMapId: string;
  onSelectAndPlay: (mapId: string) => void;
  onClose: () => void;
}

export const MapSelectionModal: React.FC<MapSelectionModalProps> = ({
  currentMapId,
  onSelectAndPlay,
  onClose,
}) => {
  const [selectedMap, setSelectedMap] = useState<MapInfo>(
    MAP_CATALOG.find(m => m.id === currentMapId) || MAP_CATALOG[0]
  );
  const [diffSettings, setDiffSettings] = useState<DifficultySettings>(() => DifficultyManager.get());

  const getBestWave = (key: string): number => {
    try {
      const v = localStorage.getItem(key);
      return v ? parseInt(v, 10) : 0;
    } catch {
      return 0;
    }
  };

  const handleDifficultyChange = (lvl: DifficultyLevel) => {
    sound.playUIClick();
    const updated = DifficultyManager.setLevel(lvl);
    setDiffSettings(updated);
  };

  const handleCustomHpChange = (val: number) => {
    const updated: DifficultySettings = {
      ...diffSettings,
      level: 'custom',
      healthMultiplier: val,
    };
    DifficultyManager.set(updated);
    setDiffSettings(updated);
  };

  const handleCustomDmgChange = (val: number) => {
    const updated: DifficultySettings = {
      ...diffSettings,
      level: 'custom',
      damageMultiplier: val,
    };
    DifficultyManager.set(updated);
    setDiffSettings(updated);
  };

  const handleCustomSpeedChange = (val: number) => {
    const updated: DifficultySettings = {
      ...diffSettings,
      level: 'custom',
      speedMultiplier: val,
    };
    DifficultyManager.set(updated);
    setDiffSettings(updated);
  };

  const handleLaunch = () => {
    sound.playUIClick();
    onSelectAndPlay(selectedMap.id);
  };

  return (
    <div className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 select-none">
      <div className="relative w-full max-w-5xl h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex justify-between items-center px-4 sm:px-6 py-3 border-b border-zinc-800 bg-zinc-900/70">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sound.playUIClick();
                onClose();
              }}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 font-teko text-xl tracking-wider uppercase font-semibold cursor-pointer active:scale-95 transition-all"
            >
              <span className="text-red-500">←</span>
              <span>BACK</span>
            </button>

            <MapPin className="w-6 h-6 text-red-500 hidden sm:block" />
            <div>
              <span className="text-[10px] font-mono-tech text-zinc-400 tracking-widest uppercase">
                THEATER OF OPERATIONS // 10 CONFLICT ZONES
              </span>
              <h2 className="text-2xl sm:text-3xl font-teko uppercase text-white font-bold tracking-wider leading-none">
                SELECT <span className="text-red-500">MISSION THEATER</span>
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playUIClick();
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Content Grid */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-5 p-4 sm:p-6 overflow-y-auto" style={{ WebkitOverflowScrolling: 'touch' }}>
          {/* Map List (Left Column - 10 Maps scrollable) */}
          <div className="md:col-span-5 flex flex-col gap-2">
            <span className="font-mono-tech text-xs text-zinc-500 uppercase tracking-widest">
              10 OPERATIONAL THEATERS:
            </span>

            <div className="flex flex-col gap-2 overflow-y-auto max-h-[68vh] pr-1">
              {MAP_CATALOG.map(m => {
                const isSelected = selectedMap.id === m.id;
                const best = getBestWave(m.bestWaveKey);

                return (
                  <div
                    key={m.id}
                    onClick={() => {
                      sound.playUIClick();
                      setSelectedMap(m);
                    }}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/20'
                        : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-tech text-[10px] text-red-400 font-bold">{m.codename}</span>
                        <span
                          className={`text-[9px] font-mono-tech px-1.5 py-0.2 rounded font-bold ${
                            m.difficulty === 'EASY'
                              ? 'bg-emerald-950 text-emerald-400'
                              : m.difficulty === 'MEDIUM'
                              ? 'bg-amber-950 text-amber-400'
                              : m.difficulty === 'HARD'
                              ? 'bg-orange-950 text-orange-400'
                              : 'bg-red-950 text-red-400'
                          }`}
                        >
                          {m.difficulty}
                        </span>
                      </div>

                      <h4 className="font-teko text-2xl text-white font-bold leading-tight mt-0.5">
                        {m.name}
                      </h4>

                      <div className="flex items-center gap-1 text-[11px] font-mono-tech text-zinc-400 mt-0.5">
                        <Trophy className="w-3 h-3 text-amber-400" />
                        <span>BEST: WAVE {best > 0 ? best : '--'}</span>
                      </div>
                    </div>

                    <ChevronRight className={`w-5 h-5 ${isSelected ? 'text-red-500' : 'text-zinc-600'}`} />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Map Detailed Dossier & Difficulty Setup (Right Column) */}
          <div className="md:col-span-7 bg-zinc-900/50 rounded-2xl border border-zinc-800 p-5 flex flex-col justify-between overflow-y-auto">
            <div>
              {/* Map Preview Banner */}
              <div
                className={`w-full h-36 sm:h-40 rounded-xl border border-zinc-700/80 bg-gradient-to-br ${selectedMap.previewGradient} flex flex-col justify-between p-4 shadow-inner relative overflow-hidden mb-4`}
              >
                <div className="flex justify-between items-start z-10">
                  <span className="font-mono-tech text-xs bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-red-400 border border-red-500/40">
                    {selectedMap.codename}
                  </span>
                  <div className="flex gap-1.5 flex-wrap">
                    {selectedMap.tags.map(t => (
                      <span
                        key={t}
                        className="font-mono-tech text-[9px] bg-black/60 px-2 py-0.5 rounded text-zinc-300 border border-zinc-700"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="z-10">
                  <span className="font-mono-tech text-xs text-zinc-400">DEFAULT LIGHTING: {selectedMap.defaultTime.toUpperCase()}</span>
                  <h3 className="text-3xl sm:text-4xl font-teko font-extrabold text-white leading-none">
                    {selectedMap.name}
                  </h3>
                </div>

                <Compass className="absolute -right-6 -bottom-6 w-36 h-36 text-white/5 pointer-events-none" />
              </div>

              {/* Difficulty Selection */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 mb-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-mono-tech text-xs text-amber-400 uppercase font-bold flex items-center gap-1.5">
                    <Skull className="w-3.5 h-3.5" />
                    COMBAT DIFFICULTY SCALING
                  </span>
                  <span className="text-[10px] font-mono-tech text-zinc-400">
                    MODIFIES AI & DAMAGE
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-1.5 mb-2">
                  {(['easy', 'normal', 'hard', 'custom'] as DifficultyLevel[]).map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => handleDifficultyChange(lvl)}
                      className={`py-1.5 px-2 rounded-lg font-teko text-lg tracking-wider uppercase font-bold transition-all cursor-pointer ${
                        diffSettings.level === lvl
                          ? 'bg-red-600 border border-red-400 text-white shadow-md'
                          : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>

                {diffSettings.level === 'custom' && (
                  <div className="flex flex-col gap-2 p-2 rounded-lg bg-zinc-900/60 border border-zinc-800 mt-2">
                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                      <span>HP MULTIPLIER</span>
                      <span className="text-red-400 font-bold">{Math.round(diffSettings.healthMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.1"
                      value={diffSettings.healthMultiplier}
                      onChange={e => handleCustomHpChange(parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />

                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300 mt-1">
                      <span>DAMAGE MULTIPLIER</span>
                      <span className="text-red-400 font-bold">{Math.round(diffSettings.damageMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.1"
                      value={diffSettings.damageMultiplier}
                      onChange={e => handleCustomDmgChange(parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />

                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300 mt-1">
                      <span>SPEED (REALISTIC PACING)</span>
                      <span className="text-red-400 font-bold">{Math.round(diffSettings.speedMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.8"
                      max="1.2"
                      step="0.05"
                      value={diffSettings.speedMultiplier}
                      onChange={e => handleCustomSpeedChange(parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />
                  </div>
                )}
              </div>

              {/* Mission Briefing */}
              <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 mb-2">
                <p className="text-zinc-300 text-xs font-mono-tech leading-relaxed">
                  {selectedMap.description}
                </p>
              </div>

              {/* Environmental Features */}
              <div className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800">
                <div className="flex items-center gap-1.5 font-mono-tech text-xs text-cyan-400 uppercase">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>TERRAIN: {selectedMap.environment}</span>
                </div>
              </div>
            </div>

            {/* Launch Button */}
            <button
              onClick={handleLaunch}
              className="mt-4 w-full py-3.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-3xl tracking-widest uppercase font-bold rounded-xl shadow-2xl shadow-red-600/40 flex items-center justify-center gap-3 cursor-pointer transition-all active:scale-98"
            >
              <Play className="w-6 h-6 fill-white" />
              <span>DEPLOY TO {selectedMap.name}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
