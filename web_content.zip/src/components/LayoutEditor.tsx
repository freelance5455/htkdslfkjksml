import { useRef, useState } from "react";
import { BUTTONS } from "@/lib/defaults";
import type { ButtonId, TouchLayout } from "@/lib/types";
import { cn } from "@/utils/cn";

export default function LayoutEditor({
  layout,
  setLayout,
  enabled,
  buttonSize,
  joystickSize,
  opacity,
}: {
  layout: TouchLayout;
  setLayout: (id: ButtonId, pos: { x: number; y: number }) => void;
  enabled: ButtonId[];
  buttonSize: number;
  joystickSize: number;
  opacity: number;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{ id: ButtonId; ox: number; oy: number } | null>(null);

  const toLocal = (clientX: number, clientY: number) => {
    const rect = boxRef.current!.getBoundingClientRect();
    return {
      x: ((clientX - rect.left) / rect.width) * 100,
      y: ((clientY - rect.top) / rect.height) * 100,
    };
  };

  const startDrag = (id: ButtonId, e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    const p = toLocal(e.clientX, e.clientY);
    setDrag({ id, ox: layout[id].x - p.x, oy: layout[id].y - p.y });
  };

  const moveDrag = (e: React.PointerEvent) => {
    if (!drag) return;
    const p = toLocal(e.clientX, e.clientY);
    setLayout(drag.id, {
      x: Math.min(97, Math.max(3, p.x + drag.ox)),
      y: Math.min(97, Math.max(3, p.y + drag.oy)),
    });
  };

  const endDrag = () => setDrag(null);

  const jsSize = 92 * (joystickSize / 100);
  const btnSize = 52 * (buttonSize / 100);

  return (
    <div
      ref={boxRef}
      onPointerMove={moveDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      className="relative mx-auto aspect-[9/16] w-full max-w-[320px] touch-none overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-b from-slate-800 via-slate-900 to-black shadow-2xl shadow-black/60"
    >
      {/* grade de referência */}
      <div
        className="pointer-events-none absolute inset-0 opacity-25"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(255,255,255,.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,.12) 1px, transparent 1px)",
          backgroundSize: "10% 10%",
        }}
      />
      <div className="pointer-events-none absolute inset-x-0 top-3 text-center text-[10px] font-medium uppercase tracking-[0.25em] text-slate-500">
        Arraste para reposicionar
      </div>

      {/* joystick */}
      <div
        onPointerDown={(e) => startDrag("joystick", e)}
        className={cn(
          "absolute flex -translate-x-1/2 -translate-y-1/2 cursor-grab items-center justify-center rounded-full border-2 border-dashed border-lime-300/60 bg-lime-400/10 backdrop-blur-sm active:cursor-grabbing",
        )}
        style={{
          left: `${layout.joystick.x}%`,
          top: `${layout.joystick.y}%`,
          width: jsSize,
          height: jsSize,
          opacity: opacity / 100,
        }}
      >
        <div className="flex h-[42%] w-[42%] items-center justify-center rounded-full border border-white/30 bg-white/20">
          <span className="text-[10px] font-bold text-white/80">MOVER</span>
        </div>
      </div>

      {/* botões */}
      {BUTTONS.filter((b) => enabled.includes(b.id)).map((b) => (
        <div
          key={b.id}
          onPointerDown={(e) => startDrag(b.id, e)}
          className={cn(
            "absolute flex -translate-x-1/2 -translate-y-1/2 cursor-grab items-center justify-center rounded-full bg-gradient-to-br text-lg shadow-lg shadow-black/50 ring-1 ring-white/25 active:cursor-grabbing",
            b.accent,
          )}
          style={{
            left: `${layout[b.id].x}%`,
            top: `${layout[b.id].y}%`,
            width: btnSize,
            height: btnSize,
            opacity: opacity / 100,
          }}
        >
          <span className="drop-shadow">{b.icon}</span>
        </div>
      ))}

      {/* mira central */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="h-8 w-8 rounded-full border border-lime-300/70">
          <div className="absolute left-1/2 top-1/2 h-px w-10 -translate-x-1/2 -translate-y-1/2 bg-lime-300/70" />
          <div className="absolute left-1/2 top-1/2 h-10 w-px -translate-x-1/2 -translate-y-1/2 bg-lime-300/70" />
        </div>
      </div>
    </div>
  );
}
