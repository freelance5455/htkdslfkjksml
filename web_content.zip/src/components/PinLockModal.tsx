import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { t } from '../utils/translations';
import { Lock, KeyRound, ShieldAlert, CheckCircle2, RefreshCw } from 'lucide-react';

export const PinLockModal: React.FC = () => {
  const { language, currentUser, unlockWithPin, unlockWithSecurityAnswer } = useApp();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [recoveryError, setRecoveryError] = useState(false);

  const handleKeyPress = (num: string) => {
    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      setError(false);
      if (nextPin.length === 4) {
        setTimeout(() => {
          const success = unlockWithPin(nextPin);
          if (!success) {
            setError(true);
            setPin('');
          }
        }, 150);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleClear = () => {
    setPin('');
    setError(false);
  };

  const handleSecurityRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    const success = unlockWithSecurityAnswer(securityAnswer);
    if (!success) {
      setRecoveryError(true);
    } else {
      setShowForgot(false);
      setSecurityAnswer('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-md p-4">
      <div className="w-full max-w-sm overflow-hidden rounded-2xl border-2 border-amber-600/40 bg-stone-900 text-stone-100 shadow-2xl">
        {/* Top Auspicious & Khatavahi Ribbon */}
        <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-950 px-6 py-4 text-center border-b border-amber-500/30">
          <div className="text-xs font-semibold tracking-widest text-amber-300">
            {t('auspiciousHeader', language)}
          </div>
          <div className="mt-1 flex items-center justify-center gap-2">
            <Lock className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-amber-100">{t('pinLockedTitle', language)}</h2>
          </div>
          <p className="mt-0.5 text-xs text-amber-200/80">{currentUser.name}</p>
        </div>

        <div className="p-6">
          {!showForgot ? (
            <div>
              <p className="text-center text-sm text-stone-300 mb-6">{t('enterPin', language)}</p>

              {/* PIN circles indicator */}
              <div className="flex justify-center gap-4 mb-6">
                {[0, 1, 2, 3].map((index) => (
                  <div
                    key={index}
                    className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                      pin.length > index
                        ? 'bg-amber-400 border-amber-400 scale-110 shadow-lg shadow-amber-400/30'
                        : 'border-stone-600 bg-stone-800'
                    }`}
                  />
                ))}
              </div>

              {error && (
                <div className="mb-4 flex items-center justify-center gap-1.5 text-xs font-medium text-rose-400 animate-bounce">
                  <ShieldAlert className="w-4 h-4" />
                  <span>{t('incorrectPin', language)}</span>
                </div>
              )}

              {/* Numeric Keypad */}
              <div className="grid grid-cols-3 gap-3 max-w-[240px] mx-auto">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleKeyPress(num)}
                    className="h-12 w-full rounded-xl bg-stone-800/80 border border-stone-700/60 text-lg font-semibold text-stone-100 hover:bg-amber-600 hover:border-amber-500 hover:text-white active:scale-95 transition-all flex items-center justify-center"
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={handleClear}
                  className="h-12 w-full rounded-xl bg-stone-800/50 border border-stone-700/40 text-xs font-medium text-stone-400 hover:bg-stone-700 hover:text-stone-200 active:scale-95 transition-all flex items-center justify-center"
                >
                  C
                </button>
                <button
                  onClick={() => handleKeyPress('0')}
                  className="h-12 w-full rounded-xl bg-stone-800/80 border border-stone-700/60 text-lg font-semibold text-stone-100 hover:bg-amber-600 hover:border-amber-500 hover:text-white active:scale-95 transition-all flex items-center justify-center"
                >
                  0
                </button>
                <button
                  onClick={handleDelete}
                  className="h-12 w-full rounded-xl bg-stone-800/50 border border-stone-700/40 text-xs font-medium text-stone-400 hover:bg-stone-700 hover:text-stone-200 active:scale-95 transition-all flex items-center justify-center"
                >
                  ⌫
                </button>
              </div>

              {currentUser.securityQuestion && (
                <div className="mt-6 text-center">
                  <button
                    type="button"
                    onClick={() => setShowForgot(true)}
                    className="text-xs text-amber-400/90 hover:text-amber-300 underline underline-offset-4"
                  >
                    {t('forgotPin', language)}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <form onSubmit={handleSecurityRecovery} className="space-y-4">
              <div className="flex items-center gap-2 text-amber-400 text-sm font-medium">
                <KeyRound className="w-4 h-4" />
                <span>{t('resetWithAnswer', language)}</span>
              </div>

              <div className="rounded-lg bg-stone-800/60 p-3 border border-stone-700">
                <p className="text-xs text-stone-400 mb-1">{t('securityQuestion', language)}:</p>
                <p className="text-sm font-medium text-amber-200">{currentUser.securityQuestion}</p>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-300 mb-1">
                  {t('securityAnswer', language)}
                </label>
                <input
                  type="text"
                  value={securityAnswer}
                  onChange={(e) => {
                    setSecurityAnswer(e.target.value);
                    setRecoveryError(false);
                  }}
                  className="w-full rounded-lg bg-stone-800 border border-stone-600 px-3 py-2 text-sm text-stone-100 placeholder-stone-500 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  placeholder="Enter answer..."
                  autoFocus
                />
              </div>

              {recoveryError && (
                <p className="text-xs text-rose-400">ખોટો જવાબ છે! કૃપા કરીને ફરી તપાસો.</p>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  className="flex-1 rounded-lg bg-stone-800 border border-stone-700 px-3 py-2 text-xs font-medium text-stone-300 hover:bg-stone-700"
                >
                  {t('cancel', language)}
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-lg bg-amber-600 px-3 py-2 text-xs font-semibold text-white hover:bg-amber-500"
                >
                  {t('unlock', language)}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
