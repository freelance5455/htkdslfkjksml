import React, { useState } from 'react';
import { X, Send, CheckCheck, Sparkles, Store } from 'lucide-react';
import { Vendor } from '../types/ecommerce';

interface SellerChatDrawerProps {
  vendor: Vendor;
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'vendor';
  text: string;
  time: string;
}

export const SellerChatDrawer: React.FC<SellerChatDrawerProps> = ({
  vendor,
  isOpen,
  onClose
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'vendor',
      text: `Hello! Welcome to ${vendor.name}. How can we help you with your order today?`,
      time: '10:30 AM'
    }
  ]);
  const [inputVal, setInputVal] = useState('');

  if (!isOpen) return null;

  const quickReplies = [
    'Is this item in stock right now?',
    'Can this be delivered to Colombo by tomorrow?',
    'Is there an official manufacturer warranty?'
  ];

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    const userMsg: ChatMessage = {
      id: 'm-' + Date.now(),
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');

    // Simulated auto response
    setTimeout(() => {
      let reply = 'Thank you for inquiring! Yes, all items in our official store are 100% in stock and covered by the Sewora Genuine Guarantee.';
      if (text.toLowerCase().includes('tomorrow') || text.toLowerCase().includes('deliver')) {
        reply = 'Yes! If you select Express Delivery at checkout before 2 PM, our courier partners dispatch today for guaranteed next-day delivery.';
      } else if (text.toLowerCase().includes('warranty')) {
        reply = 'Yes, this product includes a 6-month local seller warranty against mechanical defects.';
      }

      setMessages(prev => [
        ...prev,
        {
          id: 'v-' + Date.now(),
          sender: 'vendor',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center">
      <div className="bg-white w-full max-w-md h-[520px] rounded-t-3xl flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-200">
        {/* Chat Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50 rounded-t-3xl">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <img
                src={vendor.avatar}
                alt={vendor.name}
                className="w-10 h-10 rounded-full object-cover border border-slate-200"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white"></span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-slate-900">{vendor.name}</h4>
                <span className="bg-[#FF6600] text-white text-[8px] font-black px-1 rounded">
                  {vendor.badge}
                </span>
              </div>
              <p className="text-[10px] text-emerald-600 font-medium">Online · Typically replies in 5m</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50/50">
          <div className="text-center text-[10px] text-slate-400 my-1">
            🔒 Chats on Sewora are monitored for buyer protection
          </div>

          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed shadow-2xs ${
                  m.sender === 'user'
                    ? 'bg-[#FF6600] text-white rounded-tr-none'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[9px] text-slate-400 mt-0.5 px-1 flex items-center gap-1">
                {m.time}
                {m.sender === 'user' && <CheckCheck className="w-3 h-3 text-emerald-500" />}
              </span>
            </div>
          ))}
        </div>

        {/* Quick Question Chips */}
        <div className="px-3 py-1.5 bg-white border-t border-slate-100 flex gap-1.5 overflow-x-auto scrollbar-none">
          {quickReplies.map((qr, i) => (
            <button
              key={i}
              onClick={() => handleSend(qr)}
              className="text-[10px] font-semibold text-slate-600 bg-slate-100 hover:bg-orange-50 hover:text-[#FF6600] border border-slate-200 rounded-full px-2.5 py-1 whitespace-nowrap transition-colors"
            >
              {qr}
            </button>
          ))}
        </div>

        {/* Chat Input */}
        <div className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend(inputVal);
            }}
            placeholder="Type your question to seller..."
            className="flex-1 bg-slate-100 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#FF6600]"
          />
          <button
            onClick={() => handleSend(inputVal)}
            className="p-2 rounded-xl bg-[#FF6600] text-white hover:bg-orange-600 active:scale-95 transition-all"
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
