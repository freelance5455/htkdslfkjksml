import React, { useState, useEffect } from 'react';
import { Formula, CalculationResult } from '../../types';
import {
  calculateFormula,
  getAvailableSolveTargets,
  formatResultValue
} from '../../calculator/formulaEngine';
import { StepByStepSolution } from '../formula/StepByStepSolution';
import { ShareModal } from '../formula/ShareModal';
import {
  Calculator,
  RotateCcw,
  Copy,
  Check,
  Bookmark,
  Share2,
  AlertCircle,
  Sparkles,
  ChevronRight,
  HelpCircle,
  Sliders
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { addLocalHistory } from '../../services/storage';

interface DynamicCalculatorProps {
  formula: Formula;
  initialInputs?: Record<string, number>;
  onCalculated?: (result: CalculationResult) => void;
}

export const DynamicCalculator: React.FC<DynamicCalculatorProps> = ({
  formula,
  initialInputs,
  onCalculated
}) => {
  const {
    showToast,
    settings,
    playSound,
    triggerHaptic,
    isFavorite,
    toggleFavorite
  } = useApp();

  const isFav = isFavorite(formula.id);

  // Available solve targets for this formula (Unknown Variable Solver)
  const availableTargets = getAvailableSolveTargets(formula);
  const [selectedTarget, setSelectedTarget] = useState<string>(
    formula.resultVariable || availableTargets[0]?.symbol || ''
  );

  // Active variables required for currently selected target
  const activeTargetConfig = availableTargets.find((t) => t.symbol === selectedTarget) || availableTargets[0];

  // Determine active inputs
  const [inputs, setInputs] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    formula.variables.forEach((v) => {
      if (initialInputs && initialInputs[v.symbol] !== undefined) {
        init[v.symbol] = String(initialInputs[v.symbol]);
      } else if (v.defaultValue !== undefined) {
        init[v.symbol] = String(v.defaultValue);
      } else {
        init[v.symbol] = '';
      }
    });
    return init;
  });

  const [calcResult, setCalcResult] = useState<CalculationResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedResult, setCopiedResult] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  // Reset or adjust inputs when formula or selected target changes
  useEffect(() => {
    const defaultTarget = formula.resultVariable || availableTargets[0]?.symbol || '';
    setSelectedTarget(defaultTarget);

    const init: Record<string, string> = {};
    formula.variables.forEach((v) => {
      if (initialInputs && initialInputs[v.symbol] !== undefined) {
        init[v.symbol] = String(initialInputs[v.symbol]);
      } else if (v.defaultValue !== undefined) {
        init[v.symbol] = String(v.defaultValue);
      } else {
        init[v.symbol] = '';
      }
    });
    setInputs(init);
    setCalcResult(null);
    setErrorMessage(null);
  }, [formula.id]);

  const handleTargetChange = (targetSym: string) => {
    playSound('tab');
    triggerHaptic('light');
    setSelectedTarget(targetSym);
    setCalcResult(null);
    setErrorMessage(null);
  };

  const handleInputChange = (symbol: string, value: string) => {
    setInputs((prev) => ({ ...prev, [symbol]: value }));
    setErrorMessage(null);
  };

  const handleCalculate = () => {
    const result = calculateFormula(formula, inputs, selectedTarget);

    if (result.error) {
      playSound('incorrect');
      triggerHaptic('error');
      setErrorMessage(result.error);
      setCalcResult(null);
      return;
    }

    playSound('calculate');
    triggerHaptic('success');
    setErrorMessage(null);
    setCalcResult(result);
    onCalculated?.(result);

    // Auto save to local history if enabled
    if (settings.autoSaveHistory) {
      const numInputs: Record<string, number> = {};
      Object.entries(inputs).forEach(([k, v]) => {
        numInputs[k] = Number(v);
      });
      addLocalHistory({
        formulaId: formula.id,
        formulaTitle: formula.title,
        formulaExpression: formula.formula,
        targetSymbol: selectedTarget,
        inputs: numInputs,
        result: result.formatted,
        resultUnit: result.unit,
        steps: result.steps
      });
    }
  };

  const handleReset = () => {
    playSound('button');
    triggerHaptic('light');
    const init: Record<string, string> = {};
    formula.variables.forEach((v) => {
      init[v.symbol] = v.defaultValue !== undefined ? String(v.defaultValue) : '';
    });
    setInputs(init);
    setCalcResult(null);
    setErrorMessage(null);
    showToast('Input parameters reset to defaults');
  };

  const copyResult = async () => {
    if (!calcResult) return;
    try {
      await navigator.clipboard.writeText(
        `${formula.title} (${selectedTarget}): ${calcResult.formatted} ${calcResult.unit}`
      );
      playSound('copy');
      triggerHaptic('light');
      setCopiedResult(true);
      showToast('Calculated result copied to clipboard');
      setTimeout(() => setCopiedResult(false), 2000);
    } catch {
      showToast('Failed to copy', 'error');
    }
  };

  // Filter required inputs based on selected target
  // If target is in formula.variables, we need formula.resultVariable and the remaining variables
  const inputVariables = formula.variables.filter((v) => v.symbol !== selectedTarget);
  // If solving for one of the variables, add the primary result variable as an input field
  const requiresPrimaryResultAsInput = selectedTarget !== formula.resultVariable;

  return (
    <div className="space-y-6">
      {/* Unknown Variable Solver Bar */}
      {availableTargets.length > 1 && (
        <div className="rounded-2xl bg-[#1C1C1C] border border-[#303030] p-4 space-y-2.5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-[#F5F2ED] flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-[#D65A1F]" />
              <span>Unknown Variable Solver</span>
            </span>
            <span className="text-[11px] text-[#A9A39C] font-mono">
              Choose which unknown to solve for
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {availableTargets.map((tgt) => (
              <button
                key={tgt.symbol}
                onClick={() => handleTargetChange(tgt.symbol)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all border ${
                  selectedTarget === tgt.symbol
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] shadow-sm'
                    : 'bg-[#151515] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
                }`}
              >
                <span>Solve for {tgt.symbol}</span>
                <span className="text-[10px] text-[#A9A39C] font-normal">({tgt.name})</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Calculator Card */}
      <div className="rounded-3xl bg-[#1C1C1C] border border-[#303030] p-6 sm:p-8 space-y-6 shadow-2xl">
        {/* Header Equation Display */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#151515] border border-[#303030]">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#A9A39C] block mb-1">
              Active Equation
            </span>
            <div className="text-xl sm:text-2xl font-mono font-bold text-[#D65A1F]">
              {formula.formula}
            </div>
            <div className="text-xs text-[#A9A39C] mt-1">
              Target unknown:{' '}
              <span className="text-[#F5F2ED] font-mono font-bold">{selectedTarget}</span>
              {activeTargetConfig && ` (${activeTargetConfig.unit})`}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const next = toggleFavorite(formula.id);
                showToast(next ? 'Saved to favorites' : 'Removed from favorites');
              }}
              className={`p-2.5 rounded-xl border transition-colors ${
                isFav
                  ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                  : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
              }`}
              title={isFav ? 'Remove from favorites' : 'Add to favorites'}
            >
              <Bookmark className="w-4 h-4" fill={isFav ? '#D65A1F' : 'none'} />
            </button>

            <button
              onClick={() => {
                playSound('button');
                setShareOpen(true);
              }}
              className="p-2.5 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#A9A39C] hover:text-[#F5F2ED] transition-colors"
              title="Share Formula"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleReset}
              className="p-2.5 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#A9A39C] hover:text-[#F5F2ED] transition-colors"
              title="Reset parameters"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Input Parameters Form */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono font-bold uppercase tracking-wider text-[#A9A39C]">
              Known Input Parameters
            </label>
            <span className="text-[11px] text-[#A9A39C]">Enter numerical values</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* If we are solving for a variable other than resultVariable, prompt for resultVariable */}
            {requiresPrimaryResultAsInput && formula.resultVariable && (
              <div className="space-y-1.5 p-4 rounded-2xl bg-[#151515] border border-[#303030] focus-within:border-[#D65A1F] transition-colors">
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-[#F5F2ED]">
                    {formula.title} ({formula.resultVariable})
                  </label>
                  <span className="font-mono text-[#D65A1F] font-bold">{formula.resultUnit}</span>
                </div>
                <input
                  type="number"
                  step="any"
                  value={inputs[formula.resultVariable] ?? ''}
                  onChange={(e) => handleInputChange(formula.resultVariable!, e.target.value)}
                  placeholder={`Enter ${formula.resultVariable} (${formula.resultUnit})...`}
                  className="w-full px-3 py-2 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED] font-mono text-sm placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F]"
                />
              </div>
            )}

            {/* Render input fields for other variables */}
            {inputVariables.map((v) => (
              <div
                key={v.symbol}
                className="space-y-1.5 p-4 rounded-2xl bg-[#151515] border border-[#303030] focus-within:border-[#D65A1F] transition-colors"
              >
                <div className="flex justify-between text-xs">
                  <label className="font-semibold text-[#F5F2ED]">
                    {v.name} ({v.symbol})
                  </label>
                  <span className="font-mono text-[#D65A1F] font-bold">{v.unit}</span>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={inputs[v.symbol] ?? ''}
                    onChange={(e) => handleInputChange(v.symbol, e.target.value)}
                    placeholder={`Enter ${v.name} in ${v.unit}...`}
                    className="w-full px-3 py-2 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED] font-mono text-sm placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F]"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="p-4 rounded-2xl bg-[#C84A3A]/10 border border-[#C84A3A]/40 text-[#C84A3A] flex items-center gap-3 text-xs animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Calculate Action */}
        <button
          onClick={handleCalculate}
          className="w-full py-4 rounded-2xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-sm transition-all shadow-lg shadow-[#D65A1F]/20 active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
        >
          <Calculator className="w-4 h-4" />
          <span>Compute Unknown ({selectedTarget})</span>
        </button>

        {/* Calculation Result Panel */}
        {calcResult && (
          <div className="space-y-5 pt-4 border-t border-[#303030] animate-in fade-in slide-in-from-bottom-2">
            <div className="p-6 rounded-2xl bg-[#151515] border border-[#303030] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#A9A39C] block">
                  Computed Output ({selectedTarget})
                </span>
                <div className="text-3xl sm:text-4xl font-extrabold text-[#D65A1F] font-mono mt-1">
                  {calcResult.formatted}{' '}
                  <span className="text-lg font-bold text-[#F5F2ED]">{calcResult.unit}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={copyResult}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#232323] border border-[#303030] text-xs font-semibold text-[#F5F2ED] hover:bg-[#D65A1F] hover:border-[#D65A1F] transition-colors"
                >
                  {copiedResult ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedResult ? 'Copied' : 'Copy Result'}</span>
                </button>
              </div>
            </div>

            {/* Step-by-Step Solution Breakdown */}
            {calcResult.steps && calcResult.steps.length > 0 && (
              <StepByStepSolution
                steps={calcResult.steps}
                resultVariable={selectedTarget}
                resultValue={calcResult.formatted}
                resultUnit={calcResult.unit}
              />
            )}
          </div>
        )}
      </div>

      <ShareModal
        isOpen={shareOpen}
        onClose={() => setShareOpen(false)}
        title={formula.title}
        formulaText={formula.formula}
        url={`${window.location.origin}/calculator/${formula.id}`}
      />
    </div>
  );
};
