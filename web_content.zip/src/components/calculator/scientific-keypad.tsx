import { useCalc } from "@/store/calculator-store";
import type { UnaryFn } from "@/lib/calculator/types";
import { KeyButton } from "./key-button";

export function ScientificKeypad() {
  const dispatch = useCalc((s) => s.dispatch);
  const second = useCalc((s) => s.second);
  const hyp = useCalc((s) => s.hyp);
  const angle = useCalc((s) => s.angle);
  const setPanel = useCalc((s) => s.setPanel);
  const panel = useCalc((s) => s.panel);

  function unary(normal: UnaryFn, alt: UnaryFn) {
    dispatch({ type: "unary", fn: second ? alt : normal });
  }

  const sin = hyp ? (second ? "sinh⁻¹" : "sinh") : second ? "sin⁻¹" : "sin";
  const cos = hyp ? (second ? "cosh⁻¹" : "cosh") : second ? "cos⁻¹" : "cos";
  const tan = hyp ? (second ? "tanh⁻¹" : "tanh") : second ? "tan⁻¹" : "tan";

  return (
    <div className="grid grid-cols-5 gap-2">
      <KeyButton
        label="2nd"
        variant={second ? "active" : "fn"}
        ariaLabel="Second functions"
        onPress={() => dispatch({ type: "toggleSecond" })}
      />
      <KeyButton
        label={angle.toUpperCase()}
        variant="fn"
        ariaLabel="Cycle angle unit"
        onPress={() => dispatch({ type: "cycleAngle" })}
      />
      <KeyButton
        label="HYP"
        variant={hyp ? "active" : "fn"}
        ariaLabel="Hyperbolic"
        onPress={() => dispatch({ type: "toggleHyp" })}
      />
      <KeyButton
        label="More"
        variant={panel === "more" ? "active" : "fn"}
        onPress={() => setPanel(panel === "more" ? "none" : "more")}
      />
      <KeyButton label="⌫" variant="fn" ariaLabel="Backspace" onPress={() => dispatch({ type: "backspace" })} />

      <KeyButton
        label={sin}
        variant="fn"
        onPress={() => unary(hyp ? "sinh" : "sin", hyp ? "asinh" : "asin")}
      />
      <KeyButton
        label={cos}
        variant="fn"
        onPress={() => unary(hyp ? "cosh" : "cos", hyp ? "acosh" : "acos")}
      />
      <KeyButton
        label={tan}
        variant="fn"
        onPress={() => unary(hyp ? "tanh" : "tan", hyp ? "atanh" : "atan")}
      />
      <KeyButton
        label={second ? "10ˣ" : "log"}
        variant="fn"
        onPress={() => unary("log", "exp10")}
      />
      <KeyButton
        label={second ? "eˣ" : "ln"}
        variant="fn"
        onPress={() => unary("ln", "exp")}
      />

      <KeyButton label={second ? "x³" : "x²"} variant="fn" onPress={() => unary("sq", "cube")} />
      <KeyButton label={second ? "∛x" : "√x"} variant="fn" onPress={() => unary("sqrt", "cbrt")} />
      <KeyButton
        label={second ? "ʸ√x" : "xʸ"}
        variant="fn"
        onPress={() => dispatch({ type: "op", op: second ? "root" : "pow" })}
      />
      <KeyButton label="1/x" variant="fn" onPress={() => dispatch({ type: "unary", fn: "inv" })} />
      <KeyButton label="n!" variant="fn" ariaLabel="Factorial" onPress={() => dispatch({ type: "unary", fn: "fact" })} />

      <KeyButton
        label={second ? "φ" : "π"}
        variant="fn"
        onPress={() => dispatch({ type: "const", name: second ? "phi" : "pi" })}
      />
      <KeyButton
        label={second ? "τ" : "e"}
        variant="fn"
        onPress={() => dispatch({ type: "const", name: second ? "tau" : "e" })}
      />
      <KeyButton label="(" variant="fn" onPress={() => dispatch({ type: "lparen" })} />
      <KeyButton label=")" variant="fn" onPress={() => dispatch({ type: "rparen" })} />
      <KeyButton label="÷" variant="op" ariaLabel="Divide" onPress={() => dispatch({ type: "op", op: "div" })} />

      <KeyButton label="nCr" variant="fn" onPress={() => dispatch({ type: "op", op: "nCr" })} />
      <KeyButton label="7" onPress={() => dispatch({ type: "digit", digit: "7" })} />
      <KeyButton label="8" onPress={() => dispatch({ type: "digit", digit: "8" })} />
      <KeyButton label="9" onPress={() => dispatch({ type: "digit", digit: "9" })} />
      <KeyButton label="×" variant="op" ariaLabel="Multiply" onPress={() => dispatch({ type: "op", op: "mul" })} />

      <KeyButton label="nPr" variant="fn" onPress={() => dispatch({ type: "op", op: "nPr" })} />
      <KeyButton label="4" onPress={() => dispatch({ type: "digit", digit: "4" })} />
      <KeyButton label="5" onPress={() => dispatch({ type: "digit", digit: "5" })} />
      <KeyButton label="6" onPress={() => dispatch({ type: "digit", digit: "6" })} />
      <KeyButton label="−" variant="op" ariaLabel="Subtract" onPress={() => dispatch({ type: "op", op: "sub" })} />

      <KeyButton label="EE" variant="fn" ariaLabel="Scientific notation" onPress={() => dispatch({ type: "ee" })} />
      <KeyButton label="1" onPress={() => dispatch({ type: "digit", digit: "1" })} />
      <KeyButton label="2" onPress={() => dispatch({ type: "digit", digit: "2" })} />
      <KeyButton label="3" onPress={() => dispatch({ type: "digit", digit: "3" })} />
      <KeyButton label="+" variant="op" ariaLabel="Add" onPress={() => dispatch({ type: "op", op: "add" })} />

      <KeyButton label="±" variant="fn" ariaLabel="Toggle sign" onPress={() => dispatch({ type: "sign" })} />
      <KeyButton label="0" onPress={() => dispatch({ type: "digit", digit: "0" })} />
      <KeyButton label="." ariaLabel="Decimal" onPress={() => dispatch({ type: "dot" })} />
      <KeyButton label="%" variant="fn" ariaLabel="Percent" onPress={() => dispatch({ type: "percent" })} />
      <KeyButton label="=" variant="eq" ariaLabel="Equals" onPress={() => dispatch({ type: "equals" })} />
    </div>
  );
}
