import { History, Moon, Sun } from "lucide-react";
import { useCalc } from "@/store/calculator-store";
import { cn } from "@/lib/utils";
import type { Mode } from "@/lib/calculator/types";

const MODES: { id: Mode; label: string }[] = [
  { id: "basic", label: "Basic" },
  { id: "scientific", label: "Scientific" },
  { id: "programmer", label: "Programmer" },
  { id: "converter", label: "Convert" },
];

export function Header() {
  const mode = useCalc((s) => s.mode);
  const theme = useCalc((s) => s.theme);
  const panel = useCalc((s) => s.panel);
  const setMode = useCalc((s) => s.setMode);
  const setTheme = useCalc((s) => s.setTheme);
  const setPanel = useCalc((s) => s.setPanel);

  return (
    <header className="flex flex-col gap-4 pt-[max(0.5rem,env(safe-area-inset-top))]">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-sans text-xl font-semibold tracking-tight text-fg">Calculator</h1>
        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label={theme === "amoled" ? "Switch to paper theme" : "Switch to AMOLED theme"}
            className="flex size-11 items-center justify-center rounded-md text-muted transition-[color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:text-fg active:scale-[0.96]"
            onClick={() => setTheme(theme === "amoled" ? "paper" : "amoled")}
          >
            {theme === "amoled" ? <Sun className="size-5" strokeWidth={1.75} /> : <Moon className="size-5" strokeWidth={1.75} />}
          </button>
          <button
            type="button"
            aria-label="History"
            aria-pressed={panel === "history"}
            className={cn(
              "flex size-11 items-center justify-center rounded-md transition-[color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:text-fg active:scale-[0.96]",
              panel === "history" ? "text-fg" : "text-muted",
            )}
            onClick={() => setPanel(panel === "history" ? "none" : "history")}
          >
            <History className="size-5" strokeWidth={1.75} />
          </button>
        </div>
      </div>
      <nav aria-label="Calculator mode" className="flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]">
        {MODES.map((m) => {
          const active = mode === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setMode(m.id)}
              className={cn(
                "min-h-10 flex-1 rounded-md px-3 text-sm font-medium whitespace-nowrap transition-[background-color,color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] active:scale-[0.98]",
                active ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
              )}
            >
              {m.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
