import { useCalc } from "@/store/calculator-store";
import { KeyButton } from "./key-button";

export function BasicKeypad() {
  const dispatch = useCalc((s) => s.dispatch);

  return (
    <div className="grid grid-cols-4 gap-2">
      <KeyButton label="⌫" variant="fn" size="lg" ariaLabel="Backspace" onPress={() => dispatch({ type: "backspace" })} />
      <KeyButton label="±" variant="fn" size="lg" ariaLabel="Toggle sign" onPress={() => dispatch({ type: "sign" })} />
      <KeyButton label="%" variant="fn" size="lg" ariaLabel="Percent" onPress={() => dispatch({ type: "percent" })} />
      <KeyButton label="÷" variant="op" size="lg" ariaLabel="Divide" onPress={() => dispatch({ type: "op", op: "div" })} />

      <KeyButton label="7" size="lg" onPress={() => dispatch({ type: "digit", digit: "7" })} />
      <KeyButton label="8" size="lg" onPress={() => dispatch({ type: "digit", digit: "8" })} />
      <KeyButton label="9" size="lg" onPress={() => dispatch({ type: "digit", digit: "9" })} />
      <KeyButton label="×" variant="op" size="lg" ariaLabel="Multiply" onPress={() => dispatch({ type: "op", op: "mul" })} />

      <KeyButton label="4" size="lg" onPress={() => dispatch({ type: "digit", digit: "4" })} />
      <KeyButton label="5" size="lg" onPress={() => dispatch({ type: "digit", digit: "5" })} />
      <KeyButton label="6" size="lg" onPress={() => dispatch({ type: "digit", digit: "6" })} />
      <KeyButton label="−" variant="op" size="lg" ariaLabel="Subtract" onPress={() => dispatch({ type: "op", op: "sub" })} />

      <KeyButton label="1" size="lg" onPress={() => dispatch({ type: "digit", digit: "1" })} />
      <KeyButton label="2" size="lg" onPress={() => dispatch({ type: "digit", digit: "2" })} />
      <KeyButton label="3" size="lg" onPress={() => dispatch({ type: "digit", digit: "3" })} />
      <KeyButton label="+" variant="op" size="lg" ariaLabel="Add" onPress={() => dispatch({ type: "op", op: "add" })} />

      <KeyButton label="0" wide size="lg" onPress={() => dispatch({ type: "digit", digit: "0" })} />
      <KeyButton label="." size="lg" ariaLabel="Decimal" onPress={() => dispatch({ type: "dot" })} />
      <KeyButton label="=" variant="eq" size="lg" ariaLabel="Equals" onPress={() => dispatch({ type: "equals" })} />
    </div>
  );
}
