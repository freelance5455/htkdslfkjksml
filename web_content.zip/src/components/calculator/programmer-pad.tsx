import { useCalc } from "@/store/calculator-store";
import type { BitOp, NumberBase, WordSize } from "@/lib/calculator/types";
import { KeyButton } from "./key-button";
import { cn } from "@/lib/utils";

const BASES: { id: NumberBase; label: string }[] = [
  { id: 16, label: "HEX" },
  { id: 10, label: "DEC" },
  { id: 8, label: "OCT" },
  { id: 2, label: "BIN" },
];

const SIZES: { id: WordSize; label: string }[] = [
  { id: 8, label: "BYTE" },
  { id: 16, label: "WORD" },
  { id: 32, label: "DWORD" },
  { id: 64, label: "QWORD" },
];

const HEX = ["A", "B", "C", "D", "E", "F"] as const;

export function ProgrammerPad() {
  const prog = useCalc((s) => s.prog);
  const setBase = useCalc((s) => s.setBase);
  const setWordSize = useCalc((s) => s.setWordSize);
  const toggleSigned = useCalc((s) => s.toggleSigned);
  const flipBit = useCalc((s) => s.flipBit);
  const progDigit = useCalc((s) => s.progDigit);
  const progOp = useCalc((s) => s.progOp);
  const progNot = useCalc((s) => s.progNot);
  const progEquals = useCalc((s) => s.progEquals);
  const progClear = useCalc((s) => s.progClear);
  const progBackspace = useCalc((s) => s.progBackspace);
  const progSign = useCalc((s) => s.progSign);

  let bits = 0n;
  try {
    bits = BigInt(prog.value);
  } catch {
    bits = 0n;
  }

  const hexOn = prog.base >= 16;
  const octOn = prog.base >= 8;
  const decOn = prog.base >= 10;

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-4 gap-1 rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]">
        {BASES.map((b) => (
          <button
            key={b.id}
            type="button"
            onClick={() => setBase(b.id)}
            className={cn(
              "min-h-10 rounded-md text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              prog.base === b.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {b.label}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-5 gap-1 rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]">
        {SIZES.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setWordSize(s.id)}
            className={cn(
              "min-h-10 rounded-md text-xs font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              prog.wordSize === s.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {s.label}
          </button>
        ))}
        <button
          type="button"
          onClick={toggleSigned}
          className={cn(
            "min-h-10 rounded-md text-xs font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
            prog.signed ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
          )}
        >
          ±
        </button>
      </div>

      <BitView value={bits} wordSize={prog.wordSize} onToggle={flipBit} />

      <div className="grid grid-cols-5 gap-2">
        {(["lsh", "rsh", "or", "xor", "not"] as const).map((op) => (
          <KeyButton
            key={op}
            label={op.toUpperCase()}
            variant="fn"
            onPress={() => (op === "not" ? progNot() : progOp(op as BitOp))}
          />
        ))}
        {(["and", "nand", "nor", "rol", "ror"] as const).map((op) => (
          <KeyButton key={op} label={op.toUpperCase()} variant="fn" onPress={() => progOp(op)} />
        ))}
      </div>

      <div className="grid grid-cols-4 gap-2">
        {HEX.map((h) => (
          <KeyButton
            key={h}
            label={h}
            variant="fn"
            disabled={!hexOn}
            onPress={() => progDigit(h)}
          />
        ))}
        <KeyButton label="AC" variant="fn" onPress={progClear} />
        <KeyButton label="⌫" variant="fn" ariaLabel="Backspace" onPress={progBackspace} />

        <KeyButton label="7" disabled={!octOn} onPress={() => progDigit("7")} />
        <KeyButton label="8" disabled={!decOn} onPress={() => progDigit("8")} />
        <KeyButton label="9" disabled={!decOn} onPress={() => progDigit("9")} />
        <KeyButton label="÷" variant="op" ariaLabel="Divide" onPress={() => progOp("idiv")} />

        <KeyButton label="4" onPress={() => progDigit("4")} disabled={!octOn} />
        <KeyButton label="5" onPress={() => progDigit("5")} disabled={!octOn} />
        <KeyButton label="6" onPress={() => progDigit("6")} disabled={!octOn} />
        <KeyButton label="×" variant="op" ariaLabel="Multiply" onPress={() => progOp("imul")} />

        <KeyButton label="1" onPress={() => progDigit("1")} />
        <KeyButton label="2" onPress={() => progDigit("2")} disabled={!octOn} />
        <KeyButton label="3" onPress={() => progDigit("3")} disabled={!octOn} />
        <KeyButton label="−" variant="op" ariaLabel="Subtract" onPress={() => progOp("isub")} />

        <KeyButton label="±" variant="fn" onPress={progSign} />
        <KeyButton label="0" onPress={() => progDigit("0")} />
        <KeyButton label="+" variant="op" ariaLabel="Add" onPress={() => progOp("iadd")} />
        <KeyButton label="=" variant="eq" onPress={progEquals} />
      </div>
    </div>
  );
}

function BitView({
  value,
  wordSize,
  onToggle,
}: {
  value: bigint;
  wordSize: number;
  onToggle: (i: number) => void;
}) {
  const bits = Array.from({ length: wordSize }, (_, i) => {
    const index = wordSize - 1 - i;
    const on = ((value >> BigInt(index)) & 1n) === 1n;
    return { index, on };
  });
  const groups: { index: number; on: boolean }[][] = [];
  for (let i = 0; i < bits.length; i += 8) groups.push(bits.slice(i, i + 8));

  return (
    <div className="rounded-lg bg-surface p-3 font-mono text-xs [box-shadow:var(--shadow-key)]">
      <p className="mb-2 text-2xs tracking-wide text-muted uppercase">Bits</p>
      <div className="flex flex-col gap-2">
        {groups.map((g, gi) => (
          <div key={gi} className="flex items-center gap-1">
            <span className="w-6 text-muted">{g[0]?.index}</span>
            <div className="flex flex-1 flex-wrap gap-px">
              {g.map((b) => (
                <button
                  key={b.index}
                  type="button"
                  aria-label={`Bit ${b.index} ${b.on ? "on" : "off"}`}
                  onClick={() => onToggle(b.index)}
                  className={cn(
                    "flex h-7 min-w-0 flex-1 items-center justify-center rounded-xs text-2xs transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
                    b.on ? "bg-accent text-accent-fg" : "bg-key text-muted",
                  )}
                >
                  {b.on ? "1" : "0"}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
