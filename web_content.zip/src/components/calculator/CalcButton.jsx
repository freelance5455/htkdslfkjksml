const VARIANTS = {
  digit: 'bg-[#F6F4EF] text-[#171614] hover:bg-[#EDEAE3]',
  utility: 'bg-transparent text-[#8C8880] hover:bg-[#F3F0EA]',
  operator: 'bg-[#F1E7DB] text-[#B26244] hover:bg-[#E9DACB]',
  equals: 'bg-[#1A1A18] text-[#FAF8F4] hover:bg-[#2D2D29]',
};

export default function CalcButton({ children, onClick, variant = 'digit', label }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className={`flex h-16 items-center justify-center rounded-[1.25rem] font-body text-2xl font-medium tabular-nums transition-all duration-150 active:scale-[0.96] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9BEAC] focus-visible:ring-offset-2 focus-visible:ring-offset-white ${VARIANTS[variant]}`}
    >
      {children}
    </button>
  );
}