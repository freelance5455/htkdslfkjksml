import { Copy, Trash2 } from "lucide-react";
import { copyText, tick } from "@/lib/feedback";
import { t, type Lang } from "@/lib/i18n";
import { useAppStore, type HistoryItem } from "@/lib/store";

function feedback() {
  const { sound, haptic } = useAppStore.getState();
  tick(sound, haptic);
}

function stamp(ts: number, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === "ar" ? "ar" : "en", {
    dateStyle: "medium",
    timeStyle: "short",
    numberingSystem: "latn",
  }).format(new Date(ts));
}

export function HistoryList({
  items,
  onToast,
  compact = false,
}: {
  items: HistoryItem[];
  onToast: (message: string) => void;
  compact?: boolean;
}) {
  const lang = useAppStore((s) => s.lang);
  const removeHistory = useAppStore((s) => s.removeHistory);

  if (items.length === 0) {
    return <p className="text-sm text-muted">{t(lang, "emptyHistory")}</p>;
  }

  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li key={item.id} className="rounded-2xl border border-border bg-surface px-3 py-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-sm text-muted" dir="ltr">
                {item.expression}
              </p>
              <p className="mt-1 text-lg font-semibold tabular-nums" dir="ltr">
                {item.result}
              </p>
              {!compact ? <p className="mt-1 text-xs text-muted">{stamp(item.ts, lang)}</p> : null}
            </div>
            <div className="flex shrink-0 gap-1">
              <button
                type="button"
                aria-label={t(lang, "tapCopy")}
                onClick={() => {
                  feedback();
                  void copyText(item.copyValue).then((ok) => onToast(t(lang, ok ? "copied" : "copyFail")));
                }}
                className="grid size-10 place-items-center rounded-xl text-muted"
              >
                <Copy className="size-4" />
              </button>
              <button
                type="button"
                aria-label={t(lang, "remove")}
                onClick={() => {
                  feedback();
                  removeHistory(item.id);
                }}
                className="grid size-10 place-items-center rounded-xl text-muted"
              >
                <Trash2 className="size-4" />
              </button>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

export function HistoryView({ onToast }: { onToast: (message: string) => void }) {
  const history = useAppStore((s) => s.history);
  return (
    <div className="h-full overflow-y-auto px-4 pt-2 pb-4">
      <HistoryList items={history} onToast={onToast} />
    </div>
  );
}
