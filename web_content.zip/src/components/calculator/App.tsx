import { useEffect, useState } from "react";
import { ArrowLeftRight, Calculator, History, Moon, Settings, Sun } from "lucide-react";
import { cn } from "@/lib/cn";
import { QUICK_PAIRS, convert, fetchRateBook, formatRate } from "@/lib/currency/rates";
import { tick } from "@/lib/feedback";
import { t } from "@/lib/i18n";
import { useAppStore, type TabId } from "@/lib/store";
import { CalculatorView } from "@/components/calculator/CalculatorView";
import { CurrencyView } from "@/components/calculator/CurrencyView";
import { HistoryList, HistoryView } from "@/components/calculator/HistoryView";
import { SettingsView } from "@/components/calculator/SettingsView";

const TABS: { id: TabId; icon: typeof Calculator; key: "calculator" | "currency" | "history" | "settings" }[] = [
  { id: "calc", icon: Calculator, key: "calculator" },
  { id: "fx", icon: ArrowLeftRight, key: "currency" },
  { id: "history", icon: History, key: "history" },
  { id: "settings", icon: Settings, key: "settings" },
];

function applyTheme() {
  const state = useAppStore.getState();
  let mode: "light" | "dark" = state.theme === "light" ? "light" : "dark";
  if (state.theme === "system") {
    mode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  const root = document.documentElement;
  root.dataset.mode = mode;
  root.dataset.accent = state.accent;
  root.lang = state.lang;
  root.dir = state.lang === "ar" ? "rtl" : "ltr";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", mode === "light" ? "#f3efe6" : "#12130f");
  return mode;
}

export function App() {
  const lang = useAppStore((s) => s.lang);
  const tab = useAppStore((s) => s.tab);
  const theme = useAppStore((s) => s.theme);
  const setTab = useAppStore((s) => s.setTab);
  const setTheme = useAppStore((s) => s.setTheme);
  const rates = useAppStore((s) => s.rates);
  const history = useAppStore((s) => s.history);
  const [toast, setToast] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let unsub = () => {};
    let mq: MediaQueryList | null = null;
    const onMq = () => applyTheme();
    void Promise.resolve(useAppStore.persist.rehydrate()).then(() => {
      applyTheme();
      unsub = useAppStore.subscribe(() => applyTheme());
      mq = window.matchMedia("(prefers-color-scheme: dark)");
      mq.addEventListener("change", onMq);
      setReady(true);
    });
    return () => {
      unsub();
      mq?.removeEventListener("change", onMq);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const ac = new AbortController();
    let alive = true;
    const existing = useAppStore.getState().rates;
    useAppStore.getState().setRateStatus(existing ? "cached" : "loading");
    fetchRateBook(ac.signal)
      .then((book) => {
        if (!alive) return;
        useAppStore.getState().applyBook(book, "live");
      })
      .catch(() => {
        if (!alive || ac.signal.aborted) return;
        const state = useAppStore.getState();
        state.setRateStatus(state.rates ? "cached" : "error");
      });
    return () => {
      alive = false;
      ac.abort();
    };
  }, [ready, nonce]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 1800);
    return () => window.clearTimeout(id);
  }, [toast]);

  function notify(message: string) {
    setToast(message);
  }

  function toggleTheme() {
    const { sound, haptic } = useAppStore.getState();
    tick(sound, haptic);
    const resolved =
      theme === "system"
        ? window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light"
        : theme;
    setTheme(resolved === "dark" ? "light" : "dark");
  }

  const resolvedDark =
    theme === "dark" ||
    (theme === "system" && typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches);

  return (
    <div className="mx-auto flex h-dvh w-full max-w-5xl overflow-hidden bg-bg text-fg">
      <div className="relative mx-auto flex h-full min-h-0 w-full max-w-md flex-col overflow-hidden lg:mx-0 lg:border-e lg:border-border">
        <header className="flex shrink-0 items-center gap-3 px-4 pt-4 pb-2">
          <span className="grid size-11 place-items-center rounded-2xl bg-primary text-primary-fg">
            <Calculator className="size-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-base font-semibold tracking-tight">{t(lang, "appName")}</h1>
            <p className="truncate text-xs text-muted">{t(lang, "subtitle")}</p>
          </div>
          <button
            type="button"
            aria-label={t(lang, "theme")}
            onClick={toggleTheme}
            className="grid size-11 place-items-center rounded-2xl bg-surface"
          >
            {resolvedDark ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </button>
        </header>

        <main className="min-h-0 flex-1 overflow-hidden">
          <div className={tab === "calc" ? "h-full" : "hidden"}>
            <CalculatorView onToast={notify} />
          </div>
          <div className={tab === "fx" ? "h-full" : "hidden"}>
            <CurrencyView onToast={notify} onRefresh={() => setNonce((n) => n + 1)} />
          </div>
          <div className={tab === "history" ? "h-full" : "hidden"}>
            <HistoryView onToast={notify} />
          </div>
          <div className={tab === "settings" ? "h-full" : "hidden"}>
            <SettingsView onToast={notify} />
          </div>
        </main>

        <nav className="safe-bottom grid shrink-0 grid-cols-4 border-t border-border bg-surface px-2 pt-1">
          {TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={active ? "page" : undefined}
                onClick={() => {
                  const { sound, haptic } = useAppStore.getState();
                  tick(sound, haptic);
                  setTab(item.id);
                }}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-2xl py-2 text-xs font-medium",
                  active ? "text-primary" : "text-muted",
                )}
              >
                <Icon className="size-5" />
                {t(lang, item.key)}
              </button>
            );
          })}
        </nav>

        {toast ? (
          <div className="pointer-events-none absolute inset-x-0 top-4 flex justify-center">
            <p className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-fg">{toast}</p>
          </div>
        ) : null}
      </div>

      <aside className="hidden min-h-0 flex-1 overflow-y-auto px-8 py-8 lg:block">
        <p className="text-sm font-medium text-muted">{t(lang, "spotlight")}</p>
        <div className="mt-3 grid gap-3">
          {QUICK_PAIRS.map(([from, to]) => {
            const rate = rates ? convert(1, from, to, rates) : null;
            return (
              <button
                key={`${from}-${to}`}
                type="button"
                onClick={() => {
                  useAppStore.getState().setFx({ fxFrom: from, fxTo: to });
                  setTab("fx");
                }}
                className="flex items-center justify-between rounded-3xl border border-border bg-surface px-4 py-4 text-start"
              >
                <span className="font-medium" dir="ltr">
                  {from} / {to}
                </span>
                <span className="text-lg font-semibold tabular-nums" dir="ltr">
                  {rate == null ? "—" : formatRate(rate)}
                </span>
              </button>
            );
          })}
        </div>
        <p className="mt-8 text-sm font-medium text-muted">{t(lang, "recent")}</p>
        <div className="mt-3">
          <HistoryList items={history.slice(0, 5)} onToast={notify} compact />
        </div>
      </aside>
    </div>
  );
}
