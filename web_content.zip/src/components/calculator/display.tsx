import { useMemo } from "react";
import { toast } from "sonner";
import { useCalc } from "@/store/calculator-store";
import { formatProgEntry } from "@/lib/calculator/programmer";
import { convertValue } from "@/lib/calculator/units";
import { formatDecimal } from "@/lib/calculator/format";
import { D } from "@/lib/calculator/decimal";
import { cn } from "@/lib/utils";

function opChip(op: string): string {
  const map: Record<string, string> = {
    iadd: "+",
    isub: "−",
    imul: "×",
    idiv: "÷",
  };
  return map[op] ?? op;
}

export function Display() {
  const mode = useCalc((s) => s.mode);
  const display = useCalc((s) => s.display);
  const expression = useCalc((s) => s.expression);
  const error = useCalc((s) => s.error);
  const angle = useCalc((s) => s.angle);
  const second = useCalc((s) => s.second);
  const hyp = useCalc((s) => s.hyp);
  const memory = useCalc((s) => s.memory);
  const prog = useCalc((s) => s.prog);
  const convert = useCalc((s) => s.convert);

  const text = useMemo(() => {
    if (mode === "programmer") {
      try {
        return formatProgEntry(BigInt(prog.value), prog.base, prog.wordSize, prog.signed);
      } catch {
        return prog.entry;
      }
    }
    if (mode === "converter") {
      return convert.input.replace("-", "−");
    }
    return display;
  }, [mode, display, prog, convert.input]);

  const sub = useMemo(() => {
    if (mode === "programmer") {
      const baseLabel = { 2: "BIN", 8: "OCT", 10: "DEC", 16: "HEX" }[prog.base];
      return `${baseLabel} · ${prog.wordSize}-bit${prog.signed ? " signed" : ""}`;
    }
    if (mode === "converter") {
      const n = Number(convert.input);
      if (!Number.isFinite(n)) return "";
      const out = convertValue(n, convert.category, convert.fromId, convert.toId);
      try {
        return `= ${formatDecimal(D(out.toString()))} ${convert.toId}`;
      } catch {
        return `= ${out} ${convert.toId}`;
      }
    }
    return expression;
  }, [mode, expression, prog, convert]);

  const size =
    text.length > 16 ? "text-3xl sm:text-4xl" : text.length > 10 ? "text-4xl sm:text-5xl" : "text-5xl sm:text-6xl";

  function copy() {
    const raw = text.replace(/,/g, "").replace(/−/g, "-").replace(/\s/g, "");
    void navigator.clipboard?.writeText(raw).then(
      () => toast("Copied"),
      () => {},
    );
  }

  const showM = (() => {
    try {
      return memory !== "0" && memory !== "";
    } catch {
      return false;
    }
  })();

  return (
    <section className="flex flex-col px-1 pt-2">
      <div className="mb-3 flex min-h-6 flex-wrap items-center gap-2 text-xs font-medium tracking-wide text-muted">
        {mode === "scientific" ? (
          <span className="uppercase">{angle}</span>
        ) : null}
        {second ? <span>2nd</span> : null}
        {hyp ? <span>HYP</span> : null}
        {showM && mode !== "converter" ? <span>M</span> : null}
        {mode === "programmer" && prog.pendingOp ? (
          <span className="uppercase">{opChip(prog.pendingOp)}</span>
        ) : null}
      </div>
      <p className="min-h-6 truncate text-right font-mono text-sm text-muted" title={sub}>
        {error ?? sub}
      </p>
      <button
        type="button"
        onClick={copy}
        aria-label="Copy result"
        className={cn(
          "mt-1 w-full truncate text-right font-mono font-medium leading-tight tracking-display text-fg [overflow-wrap:anywhere]",
          size,
        )}
      >
        {text}
      </button>
    </section>
  );
}
