import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee } from '../../i18n/translations';
import { Calculator, X, Delete, ArrowRight } from 'lucide-react';

export const CalculatorModal: React.FC = () => {
  const { activeModal, setActiveModal, setEditingTransaction } = useKhata();
  const [display, setDisplay] = useState('0');
  const [prevVal, setPrevVal] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  if (activeModal !== 'calculator') return null;

  const handleDigit = (digit: string) => {
    if (display === '0' || shouldResetDisplay) {
      setDisplay(digit);
      setShouldResetDisplay(false);
    } else {
      if (digit === '.' && display.includes('.')) return;
      setDisplay(display + digit);
    }
  };

  const handleOperator = (op: string) => {
    const current = parseFloat(display);
    if (prevVal !== null && operation && !shouldResetDisplay) {
      const result = calculate(prevVal, current, operation);
      setPrevVal(result);
      setDisplay(String(result));
    } else {
      setPrevVal(current);
    }
    setOperation(op);
    setShouldResetDisplay(true);
  };

  const calculate = (a: number, b: number, op: string): number => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return b !== 0 ? a / b : 0;
      default: return b;
    }
  };

  const handleEquals = () => {
    if (prevVal === null || !operation) return;
    const current = parseFloat(display);
    const result = calculate(prevVal, current, operation);
    setDisplay(String(Math.round(result * 100) / 100));
    setPrevVal(null);
    setOperation(null);
    setShouldResetDisplay(true);
  };

  const handleClear = () => {
    setDisplay('0');
    setPrevVal(null);
    setOperation(null);
    setShouldResetDisplay(false);
  };

  const handleDelete = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const applyGst = (percentage: number) => {
    const base = parseFloat(display);
    if (isNaN(base)) return;
    const total = base + (base * percentage) / 100;
    setDisplay(String(Math.round(total * 100) / 100));
    setShouldResetDisplay(true);
  };

  const applyDiscount = (percentage: number) => {
    const base = parseFloat(display);
    if (isNaN(base)) return;
    const total = base - (base * percentage) / 100;
    setDisplay(String(Math.round(total * 100) / 100));
    setShouldResetDisplay(true);
  };

  const handleUseInExpense = () => {
    const val = parseFloat(display);
    if (isNaN(val) || val <= 0) return;
    setActiveModal('add-expense');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-xs rounded-3xl bg-slate-900 text-white p-5 shadow-2xl border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-slate-300 text-xs font-semibold">
            <Calculator className="w-4 h-4 text-emerald-400" />
            <span>घरेलू कैलकुलेटर (Khata Calc)</span>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Display Screen */}
        <div className="bg-slate-950 p-4 rounded-2xl mb-4 text-right border border-slate-800/80">
          <div className="text-xs text-slate-500 h-4">
            {prevVal !== null && `${prevVal} ${operation}`}
          </div>
          <div className="text-3xl font-extrabold tracking-tight font-mono text-emerald-400 overflow-x-auto whitespace-nowrap">
            ₹ {display}
          </div>
        </div>

        {/* Quick GST & Discount Chips */}
        <div className="flex gap-1.5 mb-3 overflow-x-auto pb-1 text-[10px] font-bold">
          <button
            onClick={() => applyGst(5)}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            +5% GST
          </button>
          <button
            onClick={() => applyGst(12)}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            +12% GST
          </button>
          <button
            onClick={() => applyGst(18)}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            +18% GST
          </button>
          <button
            onClick={() => applyDiscount(10)}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300"
          >
            -10% छूट
          </button>
        </div>

        {/* Keypad Grid */}
        <div className="grid grid-cols-4 gap-2 text-sm font-bold">
          <button
            onClick={handleClear}
            className="h-12 rounded-xl bg-slate-800 text-rose-400 hover:bg-slate-700 active:scale-95"
          >
            AC
          </button>
          <button
            onClick={handleDelete}
            className="h-12 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 active:scale-95 flex items-center justify-center"
          >
            <Delete className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOperator('÷')}
            className="h-12 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700 text-base"
          >
            ÷
          </button>
          <button
            onClick={() => handleOperator('×')}
            className="h-12 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700 text-base"
          >
            ×
          </button>

          {['7', '8', '9'].map(n => (
            <button
              key={n}
              onClick={() => handleDigit(n)}
              className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95"
            >
              {n}
            </button>
          ))}
          <button
            onClick={() => handleOperator('-')}
            className="h-12 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700 text-base"
          >
            -
          </button>

          {['4', '5', '6'].map(n => (
            <button
              key={n}
              onClick={() => handleDigit(n)}
              className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95"
            >
              {n}
            </button>
          ))}
          <button
            onClick={() => handleOperator('+')}
            className="h-12 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700 text-base"
          >
            +
          </button>

          {['1', '2', '3'].map(n => (
            <button
              key={n}
              onClick={() => handleDigit(n)}
              className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95"
            >
              {n}
            </button>
          ))}
          <button
            onClick={handleEquals}
            className="row-span-2 h-[104px] rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xl font-bold shadow-md active:scale-95 flex items-center justify-center"
          >
            =
          </button>

          <button
            onClick={() => handleDigit('0')}
            className="col-span-2 h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95"
          >
            0
          </button>
          <button
            onClick={() => handleDigit('.')}
            className="h-12 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95"
          >
            .
          </button>
        </div>

        {/* Quick transfer to Khata button */}
        <button
          onClick={handleUseInExpense}
          className="mt-4 w-full py-2.5 rounded-xl bg-emerald-700/80 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
        >
          <span>यह राशि खर्च में जोड़ें (Use ₹{display})</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
