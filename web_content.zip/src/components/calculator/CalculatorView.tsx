import { useEffect, useRef, useState, type ReactNode } from "react";
import { Copy, Delete } from "lucide-react";
import { cn } from "@/lib/cn";
import {
  backspace,
  CalcError,
  evaluateTokens,
  formatNumber,
  insertConst,
  insertDigit,
  insertFact,
  insertFn,
  insertLp,
  insertNumber,
  insertOp,
  insertPct,
  insertRp,
  numberToTokens,
  plainNumber,
  tokensToDisplay,
  tryEvaluate,
  type Fn,
  type Op,
  type Token,
} from "@/lib/calc/engine";
import { copyText, tick } from "@/lib/feedback";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

type Action =
  | { t: "digit"; v: string }
  | { t: "op"; v: Op }
  | { t: "fn"; v: Fn }
  | { t: "lp" }
  | { t: "rp" }
  | { t: "pct" }
  | { t: "fact" }
  | { t: "const"; v: "pi" | "e" }
  | { t: "pow2" }
  | { t: "inv" }
  | { t: "ac" }
  | { t: "bs" }
  | { t: "eq" }
  | { t: "ans" };

type KeyDef = {
  id: string;
  label: ReactNode;
  aria: string;
  tone: "num" | "op" | "ghost" | "accent";
  span?: 2;
  action: Action;
};

const SCI_ROWS: KeyDef[][] = [
  [
    { id: "lp", label: "(", aria: "(", tone: "op", action: { t: "lp" } },
    { id: "rp", label: ")", aria: ")", tone: "op", action: { t: "rp" } },
    { id: "pow", label: "xʸ", aria: "power", tone: "op", action: { t: "op", v: "^" } },
    {
      id: "sq",
      label: (
        <span>
          x<sup>2</sup>
        </span>
      ),
      aria: "square",
      tone: "op",
      action: { t: "pow2" },
    },
  ],
  [
    { id: "sin", label: "sin", aria: "sin", tone: "op", action: { t: "fn", v: "sin" } },
    { id: "cos", label: "cos", aria: "cos", tone: "op", action: { t: "fn", v: "cos" } },
    { id: "tan", label: "tan", aria: "tan", tone: "op", action: { t: "fn", v: "tan" } },
    { id: "sqrt", label: "√", aria: "square root", tone: "op", action: { t: "fn", v: "sqrt" } },
  ],
  [
    { id: "log", label: "log", aria: "log", tone: "op", action: { t: "fn", v: "log" } },
    { id: "ln", label: "ln", aria: "ln", tone: "op", action: { t: "fn", v: "ln" } },
    { id: "pi", label: "π", aria: "pi", tone: "op", action: { t: "const", v: "pi" } },
    { id: "e", label: "e", aria: "e", tone: "op", action: { t: "const", v: "e" } },
  ],
  [
    { id: "abs", label: "|x|", aria: "absolute value", tone: "op", action: { t: "fn", v: "abs" } },
    { id: "fact", label: "n!", aria: "factorial", tone: "op", action: { t: "fact" } },
    { id: "inv", label: "1/x", aria: "reciprocal", tone: "op", action: { t: "inv" } },
    { id: "ans", label: "Ans", aria: "last answer", tone: "op", action: { t: "ans" } },
  ],
];

const BASIC_ROWS: KeyDef[][] = [
  [
    { id: "ac", label: "AC", aria: "clear", tone: "ghost", action: { t: "ac" } },
    { id: "bs", label: <Delete className="size-5" />, aria: "backspace", tone: "ghost", action: { t: "bs" } },
    { id: "pct", label: "%", aria: "percent", tone: "op", action: { t: "pct" } },
    { id: "div", label: "÷", aria: "divide", tone: "op", action: { t: "op", v: "/" } },
  ],
  [
    { id: "7", label: "7", aria: "7", tone: "num", action: { t: "digit", v: "7" } },
    { id: "8", label: "8", aria: "8", tone: "num", action: { t: "digit", v: "8" } },
    { id: "9", label: "9", aria: "9", tone: "num", action: { t: "digit", v: "9" } },
    { id: "mul", label: "×", aria: "multiply", tone: "op", action: { t: "op", v: "*" } },
  ],
  [
    { id: "4", label: "4", aria: "4", tone: "num", action: { t: "digit", v: "4" } },
    { id: "5", label: "5", aria: "5", tone: "num", action: { t: "digit", v: "5" } },
    { id: "6", label: "6", aria: "6", tone: "num", action: { t: "digit", v: "6" } },
    { id: "sub", label: "−", aria: "subtract", tone: "op", action: { t: "op", v: "-" } },
  ],
  [
    { id: "1", label: "1", aria: "1", tone: "num", action: { t: "digit", v: "1" } },
    { id: "2", label: "2", aria: "2", tone: "num", action: { t: "digit", v: "2" } },
    { id: "3", label: "3", aria: "3", tone: "num", action: { t: "digit", v: "3" } },
    { id: "add", label: "+", aria: "add", tone: "op", action: { t: "op", v: "+" } },
  ],
  [
    { id: "0", label: "0", aria: "0", tone: "num", span: 2, action: { t: "digit", v: "0" } },
    { id: "dot", label: ".", aria: "decimal", tone: "num", action: { t: "digit", v: "." } },
    { id: "eq", label: "=", aria: "equals", tone: "accent", action: { t: "eq" } },
  ],
];

function feedback() {
  const { sound, haptic } = useAppStore.getState();
  tick(sound, haptic);
}

export function CalculatorView({ onToast }: { onToast: (message: string) => void }) {
  const lang = useAppStore((s) => s.lang);
  const sci = useAppStore((s) => s.sci);
  const angle = useAppStore((s) => s.angle);
  const setSci = useAppStore((s) => s.setSci);
  const setAngle = useAppStore((s) => s.setAngle);

  const [tokens, setTokens] = useState<Token[]>([]);
  const [settled, setSettled] = useState(false);
  const [lastExpr, setLastExpr] = useState("");
  const [lastValue, setLastValue] = useState<number | null>(null);
  const [error, setError] = useState<"math" | "syntax" | "empty" | null>(null);

  const tokensRef = useRef(tokens);
  const settledRef = useRef(settled);
  const lastValueRef = useRef(lastValue);
  tokensRef.current = tokens;
  settledRef.current = settled;
  lastValueRef.current = lastValue;

  function valueBase(): Token[] {
    return settledRef.current ? [] : tokensRef.current;
  }

  function opBase(): Token[] {
    if (!settledRef.current) return tokensRef.current;
    if (lastValueRef.current == null) return [];
    return numberToTokens(lastValueRef.current);
  }

  function run(action: Action) {
    feedback();
    if (action.t === "ac") {
      setTokens([]);
      setSettled(false);
      setLastExpr("");
      setError(null);
      return;
    }
    if (action.t === "bs") {
      if (settledRef.current) {
        setSettled(false);
        setLastExpr("");
        setTokens(backspace(tokensRef.current));
      } else {
        setTokens(backspace(tokensRef.current));
      }
      setError(null);
      return;
    }
    if (action.t === "eq") {
      const current = tokensRef.current;
      try {
        const value = evaluateTokens(current, useAppStore.getState().angle);
        const expr = tokensToDisplay(current);
        const trivial = current.length === 1 && current[0].k === "num";
        if (!trivial && expr.trim()) {
          useAppStore.getState().addHistory({
            kind: "calc",
            expression: expr,
            result: formatNumber(value),
            copyValue: plainNumber(value),
          });
        }
        setLastExpr(expr);
        setLastValue(value);
        setTokens(numberToTokens(value));
        setSettled(true);
        setError(null);
      } catch (err) {
        setError(err instanceof CalcError ? err.code : "syntax");
      }
      return;
    }

    setError(null);
    const continued = action.t === "op" || action.t === "pct" || action.t === "fact" || action.t === "pow2" || action.t === "inv";
    const base = continued ? opBase() : valueBase();
    let next = base;
    if (action.t === "digit") next = insertDigit(base, action.v);
    else if (action.t === "op") next = insertOp(base, action.v);
    else if (action.t === "fn") next = insertFn(base, action.v);
    else if (action.t === "lp") next = insertLp(base);
    else if (action.t === "rp") next = insertRp(settledRef.current ? [] : tokensRef.current);
    else if (action.t === "pct") next = insertPct(base);
    else if (action.t === "fact") next = insertFact(base);
    else if (action.t === "const") next = insertConst(base, action.v);
    else if (action.t === "pow2") {
      if (base.length === 0) return;
      next = [...insertOp(base, "^"), { k: "num", s: "2" }];
    } else if (action.t === "inv") {
      if (base.length === 0) return;
      next = [...insertOp(base, "^"), { k: "lp" }, { k: "op", v: "-" }, { k: "num", s: "1" }, { k: "rp" }];
    } else if (action.t === "ans") {
      if (lastValueRef.current == null) return;
      next = insertNumber(valueBase(), lastValueRef.current);
    }
    setSettled(false);
    setTokens(next);
  }

  const runRef = useRef(run);
  runRef.current = run;

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (useAppStore.getState().tab !== "calc") return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const key = event.key;
      let action: Action | null = null;
      if (/^\d$/.test(key)) action = { t: "digit", v: key };
      else if (key === ".") action = { t: "digit", v: "." };
      else if (key === "+") action = { t: "op", v: "+" };
      else if (key === "-") action = { t: "op", v: "-" };
      else if (key === "*") action = { t: "op", v: "*" };
      else if (key === "/") action = { t: "op", v: "/" };
      else if (key === "^") action = { t: "op", v: "^" };
      else if (key === "%") action = { t: "pct" };
      else if (key === "(") action = { t: "lp" };
      else if (key === ")") action = { t: "rp" };
      else if (key === "!" ) action = { t: "fact" };
      else if (key === "Enter" || key === "=") action = { t: "eq" };
      else if (key === "Backspace") action = { t: "bs" };
      else if (key === "Escape") action = { t: "ac" };
      if (!action) return;
      event.preventDefault();
      runRef.current(action);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const live = settled ? lastValue : tryEvaluate(tokens, angle);
  const expr = settled ? lastExpr : tokensToDisplay(tokens);
  const big = error
    ? t(lang, error === "math" ? "errorMath" : error === "empty" ? "errorEmpty" : "errorSyntax")
    : live == null
      ? tokens.length
        ? "—"
        : "0"
      : formatNumber(live);

  async function onCopy() {
    if (live == null) return;
    feedback();
    const ok = await copyText(plainNumber(live));
    onToast(t(lang, ok ? "copied" : "copyFail"));
  }

  const rows = sci ? [...SCI_ROWS, ...BASIC_ROWS] : BASIC_ROWS;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="shrink-0 px-4 pt-1">
        <div className="grid grid-cols-2 rounded-full bg-surface p-1" role="group">
          <button
            type="button"
            aria-pressed={!sci}
            onClick={() => {
              feedback();
              setSci(false);
            }}
            className={cn(
              "rounded-full py-2 text-sm font-semibold",
              !sci ? "bg-primary text-primary-fg" : "text-muted",
            )}
          >
            {t(lang, "standard")}
          </button>
          <button
            type="button"
            aria-pressed={sci}
            onClick={() => {
              feedback();
              setSci(true);
            }}
            className={cn(
              "rounded-full py-2 text-sm font-semibold",
              sci ? "bg-primary text-primary-fg" : "text-muted",
            )}
          >
            {t(lang, "scientific")}
          </button>
        </div>
      </div>

      <section className="shrink-0 px-4 pt-3" dir="ltr">
        <div className="rounded-3xl border border-border bg-surface px-4 py-4">
          <div className="flex items-center gap-2">
            <p className="min-w-0 flex-1 truncate text-end text-sm text-muted" dir="ltr">
              {expr || "\u00a0"}
            </p>
            {sci ? (
              <button
                type="button"
                aria-label={t(lang, "angle")}
                onClick={() => {
                  feedback();
                  setAngle(angle === "deg" ? "rad" : "deg");
                }}
                className="rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-primary"
              >
                {angle === "deg" ? "DEG" : "RAD"}
              </button>
            ) : null}
          </div>
          <div className="mt-2 flex items-end gap-2">
            <button
              type="button"
              aria-label={t(lang, "copy")}
              onClick={() => void onCopy()}
              className="mb-1 grid size-11 shrink-0 place-items-center rounded-2xl text-muted"
            >
              <Copy className="size-5" />
            </button>
            <p
              aria-live="polite"
              className={cn(
                "min-w-0 flex-1 overflow-x-auto text-end font-semibold tabular-nums",
                error ? "text-xl text-primary" : "text-4xl sm:text-5xl",
              )}
            >
              {big}
            </p>
          </div>
        </div>
      </section>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 pt-3 pb-3">
        <div className="grid grid-cols-4 gap-2" dir="ltr">
          {rows.flat().map((key) => (
            <button
              key={key.id}
              type="button"
              aria-label={key.aria}
              onClick={() => run(key.action)}
              className={cn(
                "flex items-center justify-center rounded-2xl font-medium tabular-nums transition active:scale-95",
                sci ? "h-11 text-base" : "h-12 text-lg",
                key.span === 2 && "col-span-2",
                key.tone === "num" && "bg-key text-key-fg",
                key.tone === "op" && "bg-op text-op-fg text-base",
                key.tone === "ghost" && "bg-ghost text-ghost-fg text-base",
                key.tone === "accent" && "bg-primary text-primary-fg text-2xl",
              )}
            >
              {key.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
