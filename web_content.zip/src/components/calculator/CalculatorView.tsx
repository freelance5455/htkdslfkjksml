import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  evaluateExpression,
  CalculatorError,
  runCalculatorUnitTests,
} from '../../utils/calculatorEngine';
import {
  History,
  Delete,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Percent,
  TrendingUp,
  DollarSign,
  Fuel,
  Calendar,
  Layers,
  HelpCircle,
  X,
  Play,
} from 'lucide-react';
import { AngleMode } from '../../types';

export const CalculatorView: React.FC = () => {
  const {
    history,
    addHistoryItem,
    clearHistory,
    deleteHistoryItem,
    triggerHaptic,
    showToast,
    settings,
    updateSettings,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'scientific' | 'financial' | 'everyday'>('scientific');
  const [expression, setExpression] = useState<string>('0');
  const [liveResult, setLiveResult] = useState<string>('');
  const [angleMode, setAngleMode] = useState<AngleMode>(settings.angleMode || 'deg');
  const [isInverse, setIsInverse] = useState<boolean>(false);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [showUnitTestModal, setShowUnitTestModal] = useState<boolean>(false);
  const [testResults, setTestResults] = useState<ReturnType<typeof runCalculatorUnitTests> | null>(null);

  // Financial Calculator States
  const [finCalcType, setFinCalcType] = useState<'discount' | 'gst' | 'profit' | 'interest' | 'loan'>('discount');
  const [discountOriginal, setDiscountOriginal] = useState<string>('120');
  const [discountPercent, setDiscountPercent] = useState<string>('20');
  const [gstAmount, setGstAmount] = useState<string>('1000');
  const [gstRate, setGstRate] = useState<string>('18');
  const [costPrice, setCostPrice] = useState<string>('400');
  const [sellingPrice, setSellingPrice] = useState<string>('550');
  const [interestPrincipal, setInterestPrincipal] = useState<string>('10000');
  const [interestRate, setInterestRate] = useState<string>('6.5');
  const [interestTime, setInterestTime] = useState<string>('3');
  const [loanAmount, setLoanAmount] = useState<string>('25000');
  const [loanInterest, setLoanInterest] = useState<string>('8.5');
  const [loanTenureMonths, setLoanTenureMonths] = useState<string>('24');

  // Everyday Math States
  const [everydayType, setEverydayType] = useState<'ratio' | 'unitprice' | 'age' | 'fuel'>('ratio');
  const [ratioA, setRatioA] = useState<string>('4');
  const [ratioB, setRatioB] = useState<string>('6');
  const [ratioC, setRatioC] = useState<string>('10');
  const [priceA, setPriceA] = useState<string>('15');
  const [qtyA, setQtyA] = useState<string>('500');
  const [priceB, setPriceB] = useState<string>('28');
  const [qtyB, setQtyB] = useState<string>('1000');
  const [birthDate, setBirthDate] = useState<string>('2000-01-01');
  const [fuelDistance, setFuelDistance] = useState<string>('350');
  const [fuelUsed, setFuelUsed] = useState<string>('25');

  // Calculator button handler
  const handleKeyClick = (val: string) => {
    triggerHaptic();

    if (val === 'AC') {
      setExpression('0');
      setLiveResult('');
      return;
    }

    if (val === 'DEL') {
      if (expression.length <= 1 || expression === '0' || expression === 'Error') {
        setExpression('0');
        setLiveResult('');
      } else {
        const next = expression.slice(0, -1);
        setExpression(next);
        calculateLive(next);
      }
      return;
    }

    if (val === '=') {
      try {
        const res = evaluateExpression(expression, angleMode);
        const resStr = String(res);
        addHistoryItem(expression, resStr, 'scientific');
        setExpression(resStr);
        setLiveResult('');
        showToast(`Result: ${resStr}`, 'success');
      } catch (err: unknown) {
        const msg = err instanceof CalculatorError ? err.message : 'Invalid Expression';
        setLiveResult(msg);
        showToast(msg, 'warning');
      }
      return;
    }

    let nextExpr = expression;
    if (expression === '0' || expression === 'Error') {
      if (['+', '×', '÷', '%', '^'].includes(val)) {
        nextExpr = '0' + val;
      } else {
        nextExpr = val;
      }
    } else {
      nextExpr = expression + val;
    }

    setExpression(nextExpr);
    calculateLive(nextExpr);
  };

  const calculateLive = (expr: string) => {
    try {
      if (expr && !/[+\-×÷^%]$/.test(expr)) {
        const preview = evaluateExpression(expr, angleMode);
        setLiveResult(String(preview));
      }
    } catch {
      // live preview fails silently until complete syntax
    }
  };

  const copyToClipboard = (text: string) => {
    triggerHaptic();
    navigator.clipboard.writeText(text);
    showToast('Copied to clipboard', 'success');
  };

  const handleRunTests = () => {
    triggerHaptic();
    const suite = runCalculatorUnitTests();
    setTestResults(suite);
    setShowUnitTestModal(true);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Category Tabs: Scientific, Financial, Everyday */}
      <div className="flex bg-neutral-100 dark:bg-neutral-800/80 p-1 rounded-2xl border border-neutral-200 dark:border-neutral-700">
        <button
          onClick={() => {
            triggerHaptic();
            setActiveTab('scientific');
          }}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'scientific'
              ? 'bg-white dark:bg-[#1B221E] text-[#006C4C] dark:text-[#89F8C7] shadow-xs'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
          }`}
        >
          Scientific
        </button>
        <button
          onClick={() => {
            triggerHaptic();
            setActiveTab('financial');
          }}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'financial'
              ? 'bg-white dark:bg-[#1B221E] text-[#006C4C] dark:text-[#89F8C7] shadow-xs'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
          }`}
        >
          Financial & Tax
        </button>
        <button
          onClick={() => {
            triggerHaptic();
            setActiveTab('everyday');
          }}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${
            activeTab === 'everyday'
              ? 'bg-white dark:bg-[#1B221E] text-[#006C4C] dark:text-[#89F8C7] shadow-xs'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
          }`}
        >
          Everyday Math
        </button>
      </div>

      {/* SCIENTIFIC CALCULATOR VIEW */}
      {activeTab === 'scientific' && (
        <div className="space-y-3">
          {/* Display screen */}
          <div className="bg-white dark:bg-[#1B221E] p-4 rounded-3xl border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs relative">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    triggerHaptic();
                    const newMode = angleMode === 'deg' ? 'rad' : 'deg';
                    setAngleMode(newMode);
                    updateSettings({ angleMode: newMode });
                  }}
                  className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-mono font-bold uppercase text-[11px] active:scale-95 transition-all"
                >
                  {angleMode}
                </button>
                <button
                  onClick={() => {
                    triggerHaptic();
                    setIsInverse(!isInverse);
                  }}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold ${
                    isInverse
                      ? 'bg-[#006C4C] text-white'
                      : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                  }`}
                >
                  INV
                </button>
              </div>

              <div className="flex items-center space-x-1.5">
                <button
                  onClick={handleRunTests}
                  title="Run Math Unit Tests"
                  className="p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500 hover:text-[#006C4C] dark:hover:text-[#89F8C7] transition-colors"
                >
                  <Play className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setShowHistoryModal(true)}
                  title="Calculation History"
                  className="p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500 hover:text-[#006C4C] dark:hover:text-[#89F8C7] transition-colors"
                >
                  <History className="w-4 h-4" />
                </button>
                <button
                  onClick={() => copyToClipboard(expression)}
                  title="Copy Display"
                  className="p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500 hover:text-[#006C4C] dark:hover:text-[#89F8C7] transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Expression string */}
            <div className="min-h-[48px] flex items-center justify-end overflow-x-auto text-right font-mono text-2xl font-semibold tracking-tight text-neutral-800 dark:text-neutral-100 break-all select-all">
              {expression}
            </div>

            {/* Live calculation result preview */}
            <div className="h-6 flex items-center justify-end font-mono text-sm font-medium text-[#006C4C] dark:text-[#89F8C7]">
              {liveResult ? `= ${liveResult}` : ''}
            </div>
          </div>

          {/* Scientific Function Strip */}
          <div className="grid grid-cols-5 gap-1.5 text-xs font-medium">
            <button
              onClick={() => handleKeyClick(isInverse ? 'asin(' : 'sin(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              {isInverse ? 'sin⁻¹' : 'sin'}
            </button>
            <button
              onClick={() => handleKeyClick(isInverse ? 'acos(' : 'cos(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              {isInverse ? 'cos⁻¹' : 'cos'}
            </button>
            <button
              onClick={() => handleKeyClick(isInverse ? 'atan(' : 'tan(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              {isInverse ? 'tan⁻¹' : 'tan'}
            </button>
            <button
              onClick={() => handleKeyClick('ln(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              ln
            </button>
            <button
              onClick={() => handleKeyClick('log(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              log
            </button>

            <button
              onClick={() => handleKeyClick('sqrt(')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all"
            >
              √
            </button>
            <button
              onClick={() => handleKeyClick('^')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all font-mono"
            >
              xʸ
            </button>
            <button
              onClick={() => handleKeyClick('!')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all font-mono"
            >
              n!
            </button>
            <button
              onClick={() => handleKeyClick('π')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all font-serif"
            >
              π
            </button>
            <button
              onClick={() => handleKeyClick('e')}
              className="py-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 active:scale-95 transition-all font-serif italic"
            >
              e
            </button>
          </div>

          {/* Standard Keypad Grid */}
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => handleKeyClick('AC')}
              className="py-3.5 rounded-2xl bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-bold text-sm active:scale-95 transition-all"
            >
              AC
            </button>
            <button
              onClick={() => handleKeyClick('(')}
              className="py-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 font-bold text-sm active:scale-95 transition-all"
            >
              (
            </button>
            <button
              onClick={() => handleKeyClick(')')}
              className="py-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 font-bold text-sm active:scale-95 transition-all"
            >
              )
            </button>
            <button
              onClick={() => handleKeyClick('÷')}
              className="py-3.5 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-[#006C4C] dark:text-[#89F8C7] font-bold text-lg active:scale-95 transition-all"
            >
              ÷
            </button>

            {['7', '8', '9'].map((num) => (
              <button
                key={num}
                onClick={() => handleKeyClick(num)}
                className="py-3.5 rounded-2xl bg-white dark:bg-[#1B221E] text-neutral-800 dark:text-neutral-100 font-semibold text-lg border border-neutral-200/70 dark:border-neutral-800 active:scale-95 transition-all shadow-xs"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleKeyClick('×')}
              className="py-3.5 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-[#006C4C] dark:text-[#89F8C7] font-bold text-lg active:scale-95 transition-all"
            >
              ×
            </button>

            {['4', '5', '6'].map((num) => (
              <button
                key={num}
                onClick={() => handleKeyClick(num)}
                className="py-3.5 rounded-2xl bg-white dark:bg-[#1B221E] text-neutral-800 dark:text-neutral-100 font-semibold text-lg border border-neutral-200/70 dark:border-neutral-800 active:scale-95 transition-all shadow-xs"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleKeyClick('-')}
              className="py-3.5 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-[#006C4C] dark:text-[#89F8C7] font-bold text-lg active:scale-95 transition-all"
            >
              -
            </button>

            {['1', '2', '3'].map((num) => (
              <button
                key={num}
                onClick={() => handleKeyClick(num)}
                className="py-3.5 rounded-2xl bg-white dark:bg-[#1B221E] text-neutral-800 dark:text-neutral-100 font-semibold text-lg border border-neutral-200/70 dark:border-neutral-800 active:scale-95 transition-all shadow-xs"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleKeyClick('+')}
              className="py-3.5 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-[#006C4C] dark:text-[#89F8C7] font-bold text-lg active:scale-95 transition-all"
            >
              +
            </button>

            <button
              onClick={() => handleKeyClick('0')}
              className="py-3.5 rounded-2xl bg-white dark:bg-[#1B221E] text-neutral-800 dark:text-neutral-100 font-semibold text-lg border border-neutral-200/70 dark:border-neutral-800 active:scale-95 transition-all shadow-xs"
            >
              0
            </button>
            <button
              onClick={() => handleKeyClick('.')}
              className="py-3.5 rounded-2xl bg-white dark:bg-[#1B221E] text-neutral-800 dark:text-neutral-100 font-bold text-lg border border-neutral-200/70 dark:border-neutral-800 active:scale-95 transition-all shadow-xs"
            >
              .
            </button>
            <button
              onClick={() => handleKeyClick('DEL')}
              className="py-3.5 rounded-2xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-semibold text-sm flex items-center justify-center active:scale-95 transition-all"
            >
              <Delete className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleKeyClick('=')}
              className="py-3.5 rounded-2xl bg-[#006C4C] hover:bg-[#004D36] text-white font-bold text-xl active:scale-95 transition-all shadow-md"
            >
              =
            </button>
          </div>
        </div>
      )}

      {/* FINANCIAL & TAX CALCULATORS */}
      {activeTab === 'financial' && (
        <div className="space-y-4">
          <div className="flex overflow-x-auto space-x-1.5 pb-1 text-xs">
            {[
              { id: 'discount', label: 'Discount & Sale' },
              { id: 'gst', label: 'GST / VAT' },
              { id: 'profit', label: 'Profit & Loss' },
              { id: 'interest', label: 'Interest' },
              { id: 'loan', label: 'Loan EMI' },
            ].map((sub) => (
              <button
                key={sub.id}
                onClick={() => {
                  triggerHaptic();
                  setFinCalcType(sub.id as any);
                }}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition-all ${
                  finCalcType === sub.id
                    ? 'bg-[#006C4C] text-white'
                    : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>

          {/* Discount Calculator */}
          {finCalcType === 'discount' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Discount & Final Sale Price
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Original Price</label>
                  <input
                    type="number"
                    value={discountOriginal}
                    onChange={(e) => setDiscountOriginal(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Discount (%)</label>
                  <input
                    type="number"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const orig = parseFloat(discountOriginal) || 0;
                const disc = parseFloat(discountPercent) || 0;
                const savings = (orig * disc) / 100;
                const finalPrice = Math.max(0, orig - savings);
                return (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-neutral-600 dark:text-neutral-400">Total Savings:</span>
                      <span className="font-bold text-emerald-700 dark:text-emerald-300">${savings.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm pt-1 border-t border-emerald-600/20">
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">Final Price:</span>
                      <span className="font-bold text-[#006C4C] dark:text-[#89F8C7]">${finalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* GST / VAT Calculator */}
          {finCalcType === 'gst' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                GST / Sales Tax Calculator
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Base Amount</label>
                  <input
                    type="number"
                    value={gstAmount}
                    onChange={(e) => setGstAmount(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Tax Rate (%)</label>
                  <input
                    type="number"
                    value={gstRate}
                    onChange={(e) => setGstRate(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const base = parseFloat(gstAmount) || 0;
                const rate = parseFloat(gstRate) || 0;
                const tax = (base * rate) / 100;
                const total = base + tax;
                return (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-neutral-600 dark:text-neutral-400">Tax Component:</span>
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm pt-1 border-t border-emerald-600/20">
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">Total Including Tax:</span>
                      <span className="font-bold text-[#006C4C] dark:text-[#89F8C7]">${total.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Profit & Loss */}
          {finCalcType === 'profit' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">Profit & Loss Analysis</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Cost Price (CP)</label>
                  <input
                    type="number"
                    value={costPrice}
                    onChange={(e) => setCostPrice(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Selling Price (SP)</label>
                  <input
                    type="number"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const cp = parseFloat(costPrice) || 0;
                const sp = parseFloat(sellingPrice) || 0;
                const diff = sp - cp;
                const isProfit = diff >= 0;
                const pct = cp > 0 ? (Math.abs(diff) / cp) * 100 : 0;
                return (
                  <div
                    className={`mt-4 p-3 rounded-xl border text-xs space-y-1 ${
                      isProfit
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600/20'
                        : 'bg-rose-50 dark:bg-rose-950/40 border-rose-600/20'
                    }`}
                  >
                    <div className="flex justify-between">
                      <span className="text-neutral-600 dark:text-neutral-400">
                        {isProfit ? 'Profit Amount:' : 'Loss Amount:'}
                      </span>
                      <span className={`font-bold ${isProfit ? 'text-emerald-700 dark:text-emerald-300' : 'text-rose-600'}`}>
                        ${Math.abs(diff).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm pt-1 border-t border-neutral-200 dark:border-neutral-700">
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">
                        {isProfit ? 'Profit Margin:' : 'Loss Margin:'}
                      </span>
                      <span className={`font-bold ${isProfit ? 'text-[#006C4C] dark:text-[#89F8C7]' : 'text-rose-600'}`}>
                        {pct.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Simple & Compound Interest */}
          {finCalcType === 'interest' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Simple & Compound Interest
              </h3>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Principal</label>
                  <input
                    type="number"
                    value={interestPrincipal}
                    onChange={(e) => setInterestPrincipal(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Annual %</label>
                  <input
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Years</label>
                  <input
                    type="number"
                    value={interestTime}
                    onChange={(e) => setInterestTime(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const p = parseFloat(interestPrincipal) || 0;
                const r = parseFloat(interestRate) || 0;
                const t = parseFloat(interestTime) || 0;
                const si = (p * r * t) / 100;
                const ciTotal = p * Math.pow(1 + r / 100, t);
                const ci = ciTotal - p;
                return (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-2">
                    <div>
                      <span className="text-neutral-500 block">Simple Interest (SI):</span>
                      <span className="font-bold text-neutral-900 dark:text-neutral-100">
                        Interest: ${si.toFixed(2)} • Total: ${(p + si).toFixed(2)}
                      </span>
                    </div>
                    <div className="pt-1.5 border-t border-emerald-600/20">
                      <span className="text-neutral-500 block">Compound Interest (Annual CI):</span>
                      <span className="font-bold text-[#006C4C] dark:text-[#89F8C7]">
                        Interest: ${ci.toFixed(2)} • Total: ${ciTotal.toFixed(2)}
                      </span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Loan EMI */}
          {finCalcType === 'loan' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">Loan EMI Estimator</h3>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Loan Amount</label>
                  <input
                    type="number"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Annual %</label>
                  <input
                    type="number"
                    value={loanInterest}
                    onChange={(e) => setLoanInterest(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">Months</label>
                  <input
                    type="number"
                    value={loanTenureMonths}
                    onChange={(e) => setLoanTenureMonths(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const p = parseFloat(loanAmount) || 0;
                const r = (parseFloat(loanInterest) || 0) / 12 / 100;
                const n = parseFloat(loanTenureMonths) || 1;
                let emi = 0;
                if (r > 0) {
                  emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
                } else {
                  emi = p / n;
                }
                const totalPayment = emi * n;
                const totalInterest = Math.max(0, totalPayment - p);
                return (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-neutral-600 dark:text-neutral-400">Total Interest:</span>
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">${totalInterest.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm pt-1 border-t border-emerald-600/20">
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">Monthly EMI:</span>
                      <span className="font-bold text-[#006C4C] dark:text-[#89F8C7]">${emi.toFixed(2)} / month</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}

      {/* EVERYDAY MATH VIEW */}
      {activeTab === 'everyday' && (
        <div className="space-y-4">
          <div className="flex overflow-x-auto space-x-1.5 pb-1 text-xs">
            {[
              { id: 'ratio', label: 'Ratios & Proportions' },
              { id: 'unitprice', label: 'Unit Price Comparison' },
              { id: 'age', label: 'Age & Date Difference' },
              { id: 'fuel', label: 'Fuel & Distance' },
            ].map((sub) => (
              <button
                key={sub.id}
                onClick={() => {
                  triggerHaptic();
                  setEverydayType(sub.id as any);
                }}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition-all ${
                  everydayType === sub.id
                    ? 'bg-[#006C4C] text-white'
                    : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>

          {/* Ratios */}
          {everydayType === 'ratio' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Solve Proportion: A : B = C : X
              </h3>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">A</label>
                  <input
                    type="number"
                    value={ratioA}
                    onChange={(e) => setRatioA(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">B</label>
                  <input
                    type="number"
                    value={ratioB}
                    onChange={(e) => setRatioB(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-neutral-500 uppercase">C</label>
                  <input
                    type="number"
                    value={ratioC}
                    onChange={(e) => setRatioC(e.target.value)}
                    className="w-full mt-1 p-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-xs font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const a = parseFloat(ratioA) || 0;
                const b = parseFloat(ratioB) || 0;
                const c = parseFloat(ratioC) || 0;
                const x = a !== 0 ? (b * c) / a : 0;
                return (
                  <div className="mt-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs flex justify-between items-center">
                    <span className="font-semibold text-neutral-700 dark:text-neutral-300">Target Value X:</span>
                    <span className="font-mono font-bold text-base text-[#006C4C] dark:text-[#89F8C7]">
                      {x.toFixed(4)}
                    </span>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Unit Price Comparison */}
          {everydayType === 'unitprice' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Compare Value (Deal A vs Deal B)
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-neutral-50 dark:bg-neutral-800/40 p-2.5 rounded-xl space-y-2">
                  <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">Item A</span>
                  <input
                    type="number"
                    placeholder="Price ($)"
                    value={priceA}
                    onChange={(e) => setPriceA(e.target.value)}
                    className="w-full p-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs"
                  />
                  <input
                    type="number"
                    placeholder="Quantity / Grams"
                    value={qtyA}
                    onChange={(e) => setQtyA(e.target.value)}
                    className="w-full p-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs"
                  />
                </div>
                <div className="bg-neutral-50 dark:bg-neutral-800/40 p-2.5 rounded-xl space-y-2">
                  <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">Item B</span>
                  <input
                    type="number"
                    placeholder="Price ($)"
                    value={priceB}
                    onChange={(e) => setPriceB(e.target.value)}
                    className="w-full p-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs"
                  />
                  <input
                    type="number"
                    placeholder="Quantity / Grams"
                    value={qtyB}
                    onChange={(e) => setQtyB(e.target.value)}
                    className="w-full p-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs"
                  />
                </div>
              </div>

              {(() => {
                const pA = parseFloat(priceA) || 0;
                const qA = parseFloat(qtyA) || 1;
                const pB = parseFloat(priceB) || 0;
                const qB = parseFloat(qtyB) || 1;
                const rateA = pA / qA;
                const rateB = pB / qB;
                const isABetter = rateA < rateB;
                return (
                  <div className="mt-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>Rate A: ${(rateA * 100).toFixed(3)} per 100 units</span>
                      <span>Rate B: ${(rateB * 100).toFixed(3)} per 100 units</span>
                    </div>
                    <p className="font-bold text-[#006C4C] dark:text-[#89F8C7] pt-1">
                      {isABetter ? '✨ Item A is more economical!' : '✨ Item B is more economical!'}
                    </p>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Age Calculator */}
          {everydayType === 'age' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Age & Date Difference Calculator
              </h3>
              <div>
                <label className="text-[11px] font-semibold text-neutral-500 uppercase">Birth Date</label>
                <input
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                />
              </div>

              {(() => {
                const b = new Date(birthDate);
                const now = new Date();
                if (isNaN(b.getTime())) return null;

                let years = now.getFullYear() - b.getFullYear();
                let months = now.getMonth() - b.getMonth();
                let days = now.getDate() - b.getDate();

                if (days < 0) {
                  months--;
                  days += new Date(now.getFullYear(), now.getMonth(), 0).getDate();
                }
                if (months < 0) {
                  years--;
                  months += 12;
                }

                const totalDays = Math.floor((now.getTime() - b.getTime()) / (1000 * 60 * 60 * 24));

                return (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1.5">
                    <div className="text-base font-bold text-[#006C4C] dark:text-[#89F8C7]">
                      {years} years, {months} months, {days} days
                    </div>
                    <div className="text-neutral-600 dark:text-neutral-400">
                      Total lived: <strong>{totalDays.toLocaleString()}</strong> days
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Fuel Consumption */}
          {everydayType === 'fuel' && (
            <div className="bg-white dark:bg-[#1B221E] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                Fuel Efficiency & Consumption
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Distance (km)</label>
                  <input
                    type="number"
                    value={fuelDistance}
                    onChange={(e) => setFuelDistance(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-neutral-500 uppercase">Fuel Used (Liters)</label>
                  <input
                    type="number"
                    value={fuelUsed}
                    onChange={(e) => setFuelUsed(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-sm font-semibold"
                  />
                </div>
              </div>

              {(() => {
                const dist = parseFloat(fuelDistance) || 0;
                const fuel = parseFloat(fuelUsed) || 1;
                const kmPerL = dist / fuel;
                const lPer100 = (fuel / dist) * 100;
                return (
                  <div className="mt-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-600/20 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>Efficiency:</span>
                      <span className="font-bold text-neutral-800 dark:text-neutral-200">{kmPerL.toFixed(2)} km/L</span>
                    </div>
                    <div className="flex justify-between text-sm pt-1 border-t border-emerald-600/20">
                      <span>Consumption:</span>
                      <span className="font-bold text-[#006C4C] dark:text-[#89F8C7]">
                        {lPer100.toFixed(2)} L / 100 km
                      </span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}

      {/* History Modal / Drawer */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1B221E] w-full max-w-md rounded-3xl p-5 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
              <div className="flex items-center space-x-2">
                <History className="w-5 h-5 text-[#006C4C] dark:text-[#89F8C7]" />
                <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">Calculation History</h3>
              </div>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {history.length === 0 ? (
                <div className="text-center py-12 text-neutral-400 text-sm">
                  <RotateCcw className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  No calculation history saved yet.
                </div>
              ) : (
                history.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/80 dark:border-neutral-700/60 flex items-center justify-between group"
                  >
                    <div
                      className="cursor-pointer flex-1 mr-2"
                      onClick={() => {
                        triggerHaptic();
                        setExpression(item.expression);
                        setLiveResult(item.result);
                        setShowHistoryModal(false);
                      }}
                    >
                      <div className="font-mono text-xs text-neutral-500 dark:text-neutral-400">
                        {item.expression}
                      </div>
                      <div className="font-mono font-bold text-sm text-[#006C4C] dark:text-[#89F8C7]">
                        = {item.result}
                      </div>
                      <span className="text-[10px] text-neutral-400">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => copyToClipboard(item.result)}
                        title="Copy Result"
                        className="p-2 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          triggerHaptic();
                          deleteHistoryItem(item.id);
                        }}
                        title="Delete Item"
                        className="p-2 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-950/40 text-rose-500"
                      >
                        <Delete className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {history.length > 0 && (
              <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex justify-between">
                <button
                  onClick={() => {
                    triggerHaptic();
                    clearHistory();
                  }}
                  className="px-4 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 text-xs font-semibold hover:bg-rose-100"
                >
                  Clear All History
                </button>
                <button
                  onClick={() => setShowHistoryModal(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-semibold"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Unit Test Execution Modal */}
      {showUnitTestModal && testResults && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1B221E] w-full max-w-md rounded-3xl p-5 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200 dark:border-neutral-800">
              <div className="flex items-center space-x-2">
                <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-bold text-base text-neutral-900 dark:text-neutral-100">
                  Math Unit Tests: {testResults.passed}/{testResults.total} Passed
                </h3>
              </div>
              <button
                onClick={() => setShowUnitTestModal(false)}
                className="p-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2 text-xs">
              {testResults.results.map((tr, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded-xl border flex items-center justify-between ${
                    tr.passed
                      ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-600/20 text-neutral-800 dark:text-neutral-200'
                      : 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-600/20 text-rose-700'
                  }`}
                >
                  <div>
                    <span className="font-semibold block">{tr.name}</span>
                    <span className="text-[11px] text-neutral-500 dark:text-neutral-400">{tr.message}</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      tr.passed
                        ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300'
                        : 'bg-rose-100 text-rose-700'
                    }`}
                  >
                    {tr.passed ? 'PASSED' : 'FAILED'}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 text-right">
              <button
                onClick={() => setShowUnitTestModal(false)}
                className="px-4 py-2 rounded-xl bg-[#006C4C] text-white text-xs font-semibold"
              >
                Close Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
