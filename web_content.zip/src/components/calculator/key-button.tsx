import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const keyVariants = cva(
  "relative flex touch-manipulation select-none items-center justify-center rounded-key px-1 font-sans font-medium outline-none [box-shadow:var(--shadow-key)] transition-[transform,background-color,box-shadow,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:ring-2 focus-visible:ring-ring active:scale-[0.96] disabled:opacity-40",
  {
    variants: {
      variant: {
        digit: "bg-key text-fg hover:[box-shadow:var(--shadow-key-hover)]",
        fn: "bg-key-fn text-fg text-sm hover:[box-shadow:var(--shadow-key-hover)]",
        op: "bg-key-op text-fg hover:[box-shadow:var(--shadow-key-hover)]",
        eq: "bg-accent text-accent-fg hover:opacity-90",
        ghost: "bg-transparent text-muted [box-shadow:none] hover:text-fg",
        active: "bg-accent text-accent-fg",
      },
      wide: {
        true: "col-span-2",
        false: "",
      },
      size: {
        md: "min-h-11 text-base",
        lg: "min-h-16 text-xl",
      },
    },
    defaultVariants: {
      variant: "digit",
      wide: false,
      size: "md",
    },
  },
);

export type KeyButtonProps = VariantProps<typeof keyVariants> & {
  label: string;
  sub?: string;
  ariaLabel?: string;
  onPress: () => void;
  className?: string;
  disabled?: boolean;
};

export function KeyButton({
  label,
  sub,
  variant,
  wide,
  size,
  ariaLabel,
  onPress,
  className,
  disabled,
}: KeyButtonProps) {
  return (
    <button
      type="button"
      aria-label={ariaLabel ?? label}
      disabled={disabled}
      className={cn(keyVariants({ variant, wide, size }), className)}
      onPointerDown={(e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        onPress();
      }}
    >
      <span className="flex flex-col items-center leading-none">
        <span className="tabular-nums">{label}</span>
        {sub ? <span className="mt-0.5 text-2xs font-normal text-muted">{sub}</span> : null}
      </span>
    </button>
  );
}
