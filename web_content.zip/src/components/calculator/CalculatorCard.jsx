import { useEffect } from 'react';
import useCalculator from '@/hooks/useCalculator';
import CalcButton from '@/components/calculator/CalcButton';

export default function CalculatorCard() {
  const calc = useCalculator();
  const { display, expression } = calc;

  useEffect(() => {
    const onKeyDown = (event) => {
      const { key } = event;
      if (/^[0-9]$/.test(key)) calc.inputDigit(key);
      else if (key === '.' || key === ',') calc.inputDot();
      else if (key === '+' || key === '-' || key === '*' || key === '/') {
        event.preventDefault();
        calc.chooseOperator(key);
      } else if (key === 'Enter' || key === '=') {
        event.preventDefault();
        calc.equals();
      } else if (key === 'Backspace') calc.backspace();
      else if (key === 'Escape') calc.clearAll();
      else if (key === '%') calc.percent();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [calc]);

  return (
    <div className="rounded-[2rem] bg-white p-4 shadow-[0_30px_70px_-32px_rgba(45,36,22,0.35)] ring-1 ring-black/[0.04]">
      <div className="overflow-hidden rounded-[1.5rem] bg-[#151412] px-6 pb-6 pt-8">
        <div className="h-5 truncate text-right text-xs tracking-wide text-white/35">
          {expression || '\u00A0'}
        </div>
        <div
          className={`mt-2 truncate text-right font-medium tabular-nums tracking-tight text-white ${
            display.length > 9 ? 'text-[2rem]' : 'text-[2.75rem]'
          }`}
        >
          {display}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2.5">
        <CalcButton variant="utility" onClick={calc.clearAll} label="Clear all">
          AC
        </CalcButton>
        <CalcButton variant="utility" onClick={calc.backspace} label="Delete last digit">
          ⌫
        </CalcButton>
        <CalcButton variant="utility" onClick={calc.percent} label="Percent">
          %
        </CalcButton>
        <CalcButton variant="operator" onClick={() => calc.chooseOperator('/')} label="Divide">
          ÷
        </CalcButton>

        <CalcButton onClick={() => calc.inputDigit('7')} label="7">7</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('8')} label="8">8</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('9')} label="9">9</CalcButton>
        <CalcButton variant="operator" onClick={() => calc.chooseOperator('*')} label="Multiply">
          ×
        </CalcButton>

        <CalcButton onClick={() => calc.inputDigit('4')} label="4">4</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('5')} label="5">5</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('6')} label="6">6</CalcButton>
        <CalcButton variant="operator" onClick={() => calc.chooseOperator('-')} label="Subtract">
          −
        </CalcButton>

        <CalcButton onClick={() => calc.inputDigit('1')} label="1">1</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('2')} label="2">2</CalcButton>
        <CalcButton onClick={() => calc.inputDigit('3')} label="3">3</CalcButton>
        <CalcButton variant="operator" onClick={() => calc.chooseOperator('+')} label="Add">
          +
        </CalcButton>

        <CalcButton variant="digit" onClick={calc.toggleSign} label="Toggle sign">
          ±
        </CalcButton>
        <CalcButton onClick={() => calc.inputDigit('0')} label="0">0</CalcButton>
        <CalcButton onClick={calc.inputDot} label="Decimal point">.</CalcButton>
        <CalcButton variant="equals" onClick={calc.equals} label="Equals">
          =
        </CalcButton>
      </div>
    </div>
  );
}