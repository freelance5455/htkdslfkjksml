import { useEffect, useState } from "react";
import { cn } from "@/lib/cn";
import { tick } from "@/lib/feedback";
import { t } from "@/lib/i18n";
import { useAppStore, type Accent, type ThemeMode } from "@/lib/store";

function feedback() {
  const { sound, haptic } = useAppStore.getState();
  tick(sound, haptic);
}

type InstallPrompt = Event & { prompt: () => Promise<void> };

export function SettingsView({ onToast }: { onToast: (message: string) => void }) {
  const lang = useAppStore((s) => s.lang);
  const theme = useAppStore((s) => s.theme);
  const accent = useAppStore((s) => s.accent);
  const sound = useAppStore((s) => s.sound);
  const haptic = useAppStore((s) => s.haptic);
  const setTheme = useAppStore((s) => s.setTheme);
  const setAccent = useAppStore((s) => s.setAccent);
  const setLang = useAppStore((s) => s.setLang);
  const setSound = useAppStore((s) => s.setSound);
  const setHaptic = useAppStore((s) => s.setHaptic);
  const clearHistory = useAppStore((s) => s.clearHistory);
  const [confirm, setConfirm] = useState(false);
  const [install, setInstall] = useState<InstallPrompt | null>(null);

  useEffect(() => {
    function onPrompt(event: Event) {
      event.preventDefault();
      setInstall(event as InstallPrompt);
    }
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const themes: { id: ThemeMode; label: "light" | "dark" | "system" }[] = [
    { id: "light", label: "light" },
    { id: "dark", label: "dark" },
    { id: "system", label: "system" },
  ];
  const accents: { id: Accent; label: "gold" | "jade" | "cobalt" | "coral"; swatch: string }[] = [
    { id: "gold", label: "gold", swatch: "bg-swatch-gold" },
    { id: "jade", label: "jade", swatch: "bg-swatch-jade" },
    { id: "cobalt", label: "cobalt", swatch: "bg-swatch-cobalt" },
    { id: "coral", label: "coral", swatch: "bg-swatch-coral" },
  ];

  return (
    <div className="h-full overflow-y-auto px-4 pt-2 pb-6">
      <section className="rounded-3xl border border-border bg-surface px-4 py-2">
        <p className="pt-3 text-sm font-medium text-muted">{t(lang, "appearance")}</p>
        <div className="grid grid-cols-3 gap-2 py-3">
          {themes.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={theme === item.id}
              onClick={() => {
                feedback();
                setTheme(item.id);
              }}
              className={cn(
                "rounded-2xl py-3 text-sm font-medium",
                theme === item.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg",
              )}
            >
              {t(lang, item.label)}
            </button>
          ))}
        </div>
        <p className="text-sm font-medium text-muted">{t(lang, "accent")}</p>
        <div className="grid grid-cols-4 gap-2 py-3">
          {accents.map((item) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={accent === item.id}
              aria-label={t(lang, item.label)}
              onClick={() => {
                feedback();
                setAccent(item.id);
              }}
              className={cn(
                "flex flex-col items-center gap-2 rounded-2xl py-3 text-xs",
                accent === item.id ? "bg-primary-soft" : "bg-surface-2",
              )}
            >
              <span className={cn("size-6 rounded-full", item.swatch)} />
              {t(lang, item.label)}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-3 rounded-3xl border border-border bg-surface px-4 py-2">
        <p className="pt-3 text-sm font-medium text-muted">{t(lang, "language")}</p>
        <div className="grid grid-cols-2 gap-2 py-3">
          <button
            type="button"
            aria-pressed={lang === "ar"}
            onClick={() => {
              feedback();
              setLang("ar");
            }}
            className={cn(
              "rounded-2xl py-3 text-sm font-medium",
              lang === "ar" ? "bg-primary text-primary-fg" : "bg-surface-2",
            )}
          >
            العربية
          </button>
          <button
            type="button"
            aria-pressed={lang === "en"}
            onClick={() => {
              feedback();
              setLang("en");
            }}
            className={cn(
              "rounded-2xl py-3 text-sm font-medium",
              lang === "en" ? "bg-primary text-primary-fg" : "bg-surface-2",
            )}
          >
            English
          </button>
        </div>
        <Toggle
          title={t(lang, "sound")}
          hint={t(lang, "soundHint")}
          on={sound}
          onChange={(value) => {
            setSound(value);
            if (value) tick(true, false);
          }}
        />
        <Toggle
          title={t(lang, "haptic")}
          hint={t(lang, "hapticHint")}
          on={haptic}
          onChange={(value) => {
            setHaptic(value);
            if (value) tick(false, true);
          }}
        />
      </section>

      <section className="mt-3 rounded-3xl border border-border bg-surface px-4 py-4">
        <button
          type="button"
          onClick={() => {
            feedback();
            if (!confirm) {
              setConfirm(true);
              return;
            }
            clearHistory();
            setConfirm(false);
            onToast(t(lang, "historyCleared"));
          }}
          className="w-full rounded-2xl bg-surface-2 py-3 text-sm font-semibold"
        >
          {confirm ? t(lang, "confirmClear") : t(lang, "clearHistory")}
        </button>
      </section>

      <section className="mt-3 rounded-3xl border border-border bg-surface px-4 py-4">
        <h2 className="text-base font-semibold">{t(lang, "about")}</h2>
        <p className="mt-2 text-sm leading-6 text-muted">{t(lang, "aboutBody")}</p>
        <p className="mt-2 text-sm leading-6 text-muted">{t(lang, "disclaimer")}</p>
        <p className="mt-2 text-sm leading-6 text-muted">{t(lang, "privacy")}</p>
        <p className="mt-3 text-xs text-muted">{t(lang, "version")}</p>
      </section>

      <section className="mt-3 rounded-3xl border border-border bg-surface px-4 py-4">
        <h2 className="text-base font-semibold">{t(lang, "install")}</h2>
        <p className="mt-2 text-sm leading-6 text-muted">{t(lang, "installLead")}</p>
        <ol className="mt-3 list-decimal space-y-2 ps-5 text-sm leading-6">
          <li>{t(lang, "install1")}</li>
          <li>{t(lang, "install2")}</li>
          <li>{t(lang, "install3")}</li>
        </ol>
        {install ? (
          <button
            type="button"
            onClick={() => {
              feedback();
              void install.prompt();
              setInstall(null);
            }}
            className="mt-4 w-full rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-fg"
          >
            {t(lang, "installNow")}
          </button>
        ) : null}
      </section>
    </div>
  );
}

function Toggle({
  title,
  hint,
  on,
  onChange,
}: {
  title: string;
  hint: string;
  on: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-t border-border py-3">
      <div>
        <p className="font-medium">{title}</p>
        <p className="text-sm text-muted">{hint}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        onClick={() => onChange(!on)}
        className={cn(
          "flex h-7 w-12 shrink-0 items-center rounded-full p-1",
          on ? "justify-end bg-primary" : "justify-start bg-surface-2",
        )}
      >
        <span className={cn("size-5 rounded-full", on ? "bg-primary-fg" : "bg-fg")} />
      </button>
    </div>
  );
}
