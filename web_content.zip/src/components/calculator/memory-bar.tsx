import { useCalc } from "@/store/calculator-store";
import { KeyButton } from "./key-button";

export function MemoryBar() {
  const dispatch = useCalc((s) => s.dispatch);
  const hasMemory = useCalc((s) => s.hasMemory());
  const clearLabel = useCalc((s) => s.clearLabel());
  const mode = useCalc((s) => s.mode);

  if (mode === "converter") return null;

  return (
    <div className="grid grid-cols-6 gap-2">
      <KeyButton
        label={clearLabel}
        variant="fn"
        ariaLabel={clearLabel === "C" ? "Clear" : "All clear"}
        onPress={() => dispatch({ type: clearLabel === "C" ? "clear" : "allClear" })}
      />
      <KeyButton label="MC" variant="fn" ariaLabel="Memory clear" disabled={!hasMemory} onPress={() => dispatch({ type: "memoryClear" })} />
      <KeyButton label="MR" variant="fn" ariaLabel="Memory recall" disabled={!hasMemory} onPress={() => dispatch({ type: "memoryRecall" })} />
      <KeyButton label="M+" variant="fn" ariaLabel="Memory add" onPress={() => dispatch({ type: "memoryAdd" })} />
      <KeyButton label="M−" variant="fn" ariaLabel="Memory subtract" onPress={() => dispatch({ type: "memorySub" })} />
      <KeyButton label="MS" variant="fn" ariaLabel="Memory store" onPress={() => dispatch({ type: "memoryStore" })} />
    </div>
  );
}
