import { useCalc } from "@/store/calculator-store";
import type { ConstantName, UnaryFn } from "@/lib/calculator/types";
import { KeyButton } from "./key-button";
import { cn } from "@/lib/utils";

const UNARIES: { label: string; fn: UnaryFn }[] = [
  { label: "sec", fn: "sec" },
  { label: "csc", fn: "csc" },
  { label: "cot", fn: "cot" },
  { label: "sec⁻¹", fn: "asec" },
  { label: "csc⁻¹", fn: "acsc" },
  { label: "cot⁻¹", fn: "acot" },
  { label: "log₂", fn: "log2" },
  { label: "2ˣ", fn: "exp2" },
  { label: "|x|", fn: "abs" },
  { label: "floor", fn: "floor" },
  { label: "ceil", fn: "ceil" },
  { label: "round", fn: "round" },
  { label: "frac", fn: "frac" },
  { label: "sign", fn: "sign" },
  { label: "rand", fn: "rand" },
  { label: "→deg", fn: "toDeg" },
  { label: "→rad", fn: "toRad" },
  { label: "→grad", fn: "toGrad" },
];

const BINS: { label: string; op: "mod" | "gcd" | "lcm" | "logy" }[] = [
  { label: "mod", op: "mod" },
  { label: "gcd", op: "gcd" },
  { label: "lcm", op: "lcm" },
  { label: "logᵧ", op: "logy" },
];

const CONSTS: { label: string; name: ConstantName }[] = [
  { label: "π", name: "pi" },
  { label: "e", name: "e" },
  { label: "φ", name: "phi" },
  { label: "τ", name: "tau" },
  { label: "√2", name: "sqrt2" },
  { label: "ln2", name: "ln2" },
  { label: "c", name: "c" },
  { label: "g", name: "g" },
  { label: "h", name: "h" },
  { label: "Nₐ", name: "NA" },
];

export function MoreSheet() {
  const panel = useCalc((s) => s.panel);
  const setPanel = useCalc((s) => s.setPanel);
  const dispatch = useCalc((s) => s.dispatch);
  const open = panel === "more";

  return (
    <div
      className={cn(
        "overflow-hidden transition-[grid-template-rows,opacity] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
        open ? "grid grid-rows-[1fr] opacity-100" : "grid grid-rows-[0fr] opacity-0",
      )}
      aria-hidden={!open}
    >
      <div className="min-h-0 overflow-hidden">
        <div className="mt-3 rounded-lg bg-surface p-3 [box-shadow:var(--shadow-key)]">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm font-medium text-fg">More functions</p>
            <button
              type="button"
              className="min-h-10 px-2 text-sm text-muted hover:text-fg"
              onClick={() => setPanel("none")}
            >
              Close
            </button>
          </div>
          <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">Functions</p>
          <div className="mb-4 grid grid-cols-4 gap-2 sm:grid-cols-6">
            {UNARIES.map((u) => (
              <KeyButton
                key={u.fn}
                label={u.label}
                variant="fn"
                onPress={() => {
                  dispatch({ type: "unary", fn: u.fn });
                  setPanel("none");
                }}
              />
            ))}
          </div>
          <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">Two-value</p>
          <div className="mb-4 grid grid-cols-4 gap-2">
            {BINS.map((b) => (
              <KeyButton
                key={b.op}
                label={b.label}
                variant="op"
                onPress={() => {
                  dispatch({ type: "op", op: b.op });
                  setPanel("none");
                }}
              />
            ))}
          </div>
          <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">Constants</p>
          <div className="grid grid-cols-5 gap-2">
            {CONSTS.map((c) => (
              <KeyButton
                key={c.name}
                label={c.label}
                variant="fn"
                onPress={() => {
                  dispatch({ type: "const", name: c.name });
                  setPanel("none");
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
