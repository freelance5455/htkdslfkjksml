import { useEffect } from "react";
import { useCalc } from "@/store/calculator-store";

function isTypingTarget(el: EventTarget | null): boolean {
  if (!(el instanceof HTMLElement)) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

export function useCalculatorKeyboard() {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (isTypingTarget(e.target)) return;
      const s = useCalc.getState();
      const k = e.key;

      if (s.mode === "converter") {
        if (/^[0-9]$/.test(k)) {
          e.preventDefault();
          s.convertDigit(k);
          return;
        }
        if (k === ".") {
          e.preventDefault();
          s.convertDot();
          return;
        }
        if (k === "Backspace") {
          e.preventDefault();
          s.convertBackspace();
          return;
        }
        if (k === "Escape") {
          e.preventDefault();
          s.convertClear();
          return;
        }
        return;
      }

      if (s.mode === "programmer") {
        if (/^[0-9a-fA-F]$/.test(k)) {
          e.preventDefault();
          s.progDigit(k.toUpperCase());
          return;
        }
        if (k === "Enter" || k === "=") {
          e.preventDefault();
          s.progEquals();
          return;
        }
        if (k === "Backspace") {
          e.preventDefault();
          s.progBackspace();
          return;
        }
        if (k === "Escape") {
          e.preventDefault();
          s.progClear();
          return;
        }
        if (k === "+" ) {
          e.preventDefault();
          s.progOp("iadd");
          return;
        }
        if (k === "-") {
          e.preventDefault();
          s.progOp("isub");
          return;
        }
        if (k === "*" ) {
          e.preventDefault();
          s.progOp("imul");
          return;
        }
        if (k === "/") {
          e.preventDefault();
          s.progOp("idiv");
          return;
        }
        if (k === "&") {
          e.preventDefault();
          s.progOp("and");
          return;
        }
        if (k === "|") {
          e.preventDefault();
          s.progOp("or");
          return;
        }
        if (k === "^") {
          e.preventDefault();
          s.progOp("xor");
          return;
        }
        if (k === "~") {
          e.preventDefault();
          s.progNot();
          return;
        }
        return;
      }

      if (/^[0-9]$/.test(k)) {
        e.preventDefault();
        s.dispatch({ type: "digit", digit: k });
        return;
      }
      if (k === ".") {
        e.preventDefault();
        s.dispatch({ type: "dot" });
        return;
      }
      if (k === "+" ) {
        e.preventDefault();
        s.dispatch({ type: "op", op: "add" });
        return;
      }
      if (k === "-") {
        e.preventDefault();
        s.dispatch({ type: "op", op: "sub" });
        return;
      }
      if (k === "*" || k === "x" || k === "X") {
        e.preventDefault();
        s.dispatch({ type: "op", op: "mul" });
        return;
      }
      if (k === "/") {
        e.preventDefault();
        s.dispatch({ type: "op", op: "div" });
        return;
      }
      if (k === "%") {
        e.preventDefault();
        s.dispatch({ type: "percent" });
        return;
      }
      if (k === "Enter" || k === "=") {
        e.preventDefault();
        s.dispatch({ type: "equals" });
        return;
      }
      if (k === "Backspace") {
        e.preventDefault();
        s.dispatch({ type: "backspace" });
        return;
      }
      if (k === "Escape") {
        e.preventDefault();
        s.dispatch({ type: "clear" });
        return;
      }
      if (k === "(") {
        e.preventDefault();
        s.dispatch({ type: "lparen" });
        return;
      }
      if (k === ")") {
        e.preventDefault();
        s.dispatch({ type: "rparen" });
        return;
      }
      if (k === "^") {
        e.preventDefault();
        s.dispatch({ type: "op", op: "pow" });
        return;
      }
      if (k === "p" && s.mode === "scientific") {
        e.preventDefault();
        s.dispatch({ type: "const", name: "pi" });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
}
