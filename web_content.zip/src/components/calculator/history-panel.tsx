import { useCalc } from "@/store/calculator-store";
import { cn } from "@/lib/utils";

export function HistoryPanel({ variant }: { variant: "overlay" | "side" }) {
  const history = useCalc((s) => s.history);
  const panel = useCalc((s) => s.panel);
  const setPanel = useCalc((s) => s.setPanel);
  const dispatch = useCalc((s) => s.dispatch);
  const open = variant === "side" || panel === "history";

  if (variant === "overlay" && !open) return null;

  return (
    <aside
      className={cn(
        variant === "side"
          ? "hidden w-80 shrink-0 border-l border-border lg:flex lg:flex-col"
          : "fixed inset-0 z-20 flex flex-col bg-bg/95 lg:hidden",
      )}
    >
      <div className="flex items-center justify-between px-5 py-4">
        <h2 className="text-base font-semibold tracking-tight">History</h2>
        <div className="flex gap-2">
          {history.length > 0 ? (
            <button
              type="button"
              className="min-h-10 px-2 text-sm text-muted hover:text-fg"
              onClick={() => dispatch({ type: "clearHistory" })}
            >
              Clear
            </button>
          ) : null}
          {variant === "overlay" ? (
            <button
              type="button"
              className="min-h-10 px-2 text-sm text-muted hover:text-fg"
              onClick={() => setPanel("none")}
            >
              Close
            </button>
          ) : null}
        </div>
      </div>
      {history.length === 0 ? (
        <p className="px-5 text-sm text-muted">Results you evaluate will appear here. Tap one to reuse it.</p>
      ) : (
        <ul className="flex-1 overflow-y-auto px-3 pb-6">
          {history.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                className="flex w-full flex-col items-end rounded-md px-3 py-3 text-right transition-[background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:bg-surface"
                onClick={() => {
                  dispatch({ type: "load", value: item.result.replace(/,/g, "").replace(/−/g, "-"), expr: item.expression });
                  setPanel("none");
                }}
              >
                <span className="font-mono text-xs text-muted">{item.expression}</span>
                <span className="font-mono text-lg font-medium text-fg">{item.result}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}
