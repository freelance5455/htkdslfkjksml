import { ArrowDownUp } from "lucide-react";
import { useCalc } from "@/store/calculator-store";
import { CATEGORIES, convertValue } from "@/lib/calculator/units";
import { formatDecimal } from "@/lib/calculator/format";
import { D } from "@/lib/calculator/decimal";
import { KeyButton } from "./key-button";
import { cn } from "@/lib/utils";

export function ConverterPanel() {
  const convert = useCalc((s) => s.convert);
  const setCategory = useCalc((s) => s.setCategory);
  const setFromUnit = useCalc((s) => s.setFromUnit);
  const setToUnit = useCalc((s) => s.setToUnit);
  const swapUnits = useCalc((s) => s.swapUnits);
  const convertDigit = useCalc((s) => s.convertDigit);
  const convertDot = useCalc((s) => s.convertDot);
  const convertBackspace = useCalc((s) => s.convertBackspace);
  const convertClear = useCalc((s) => s.convertClear);
  const convertSign = useCalc((s) => s.convertSign);

  const cat = CATEGORIES.find((c) => c.id === convert.category) ?? CATEGORIES[0]!;
  const n = Number(convert.input);
  const out = Number.isFinite(n) ? convertValue(n, convert.category, convert.fromId, convert.toId) : 0;
  let outLabel = String(out);
  try {
    outLabel = formatDecimal(D(out.toString()));
  } catch {
    /* keep */
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap gap-1">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setCategory(c.id)}
            className={cn(
              "min-h-10 shrink-0 rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              convert.category === c.id ? "bg-accent text-accent-fg" : "bg-key-fn text-muted hover:text-fg",
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="rounded-lg bg-surface p-4 [box-shadow:var(--shadow-key)]">
        <label className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">From</label>
        <select
          value={convert.fromId}
          onChange={(e) => setFromUnit(e.target.value)}
          className="mb-4 min-h-11 w-full rounded-md bg-key px-3 font-sans text-sm text-fg outline-none [box-shadow:var(--shadow-key)] focus:ring-2 focus:ring-ring"
        >
          {cat.units.map((u) => (
            <option key={u.id} value={u.id}>
              {u.label}
            </option>
          ))}
        </select>

        <div className="mb-4 flex justify-center">
          <button
            type="button"
            aria-label="Swap units"
            onClick={swapUnits}
            className="flex size-11 items-center justify-center rounded-md bg-key text-fg transition-[transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] active:scale-[0.96] [box-shadow:var(--shadow-key)]"
          >
            <ArrowDownUp className="size-4" strokeWidth={1.75} />
          </button>
        </div>

        <label className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">To</label>
        <select
          value={convert.toId}
          onChange={(e) => setToUnit(e.target.value)}
          className="mb-3 min-h-11 w-full rounded-md bg-key px-3 font-sans text-sm text-fg outline-none [box-shadow:var(--shadow-key)] focus:ring-2 focus:ring-ring"
        >
          {cat.units.map((u) => (
            <option key={u.id} value={u.id}>
              {u.label}
            </option>
          ))}
        </select>
        <p className="font-mono text-2xl font-medium tracking-tight text-fg">{outLabel}</p>
      </div>

      <div className="grid grid-cols-4 gap-2">
        <KeyButton label="AC" variant="fn" onPress={convertClear} />
        <KeyButton label="⌫" variant="fn" onPress={convertBackspace} />
        <KeyButton label="±" variant="fn" onPress={convertSign} />
        <KeyButton label="." variant="fn" onPress={convertDot} />
        {["7", "8", "9", "4", "5", "6", "1", "2", "3"].map((d) => (
          <KeyButton key={d} label={d} onPress={() => convertDigit(d)} />
        ))}
        <KeyButton label="0" wide onPress={() => convertDigit("0")} />
        <KeyButton label="00" variant="fn" onPress={() => convertDigit("00")} />
      </div>
    </div>
  );
}
