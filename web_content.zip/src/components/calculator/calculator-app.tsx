import { useEffect } from "react";
import { Toaster } from "sonner";
import { useCalc } from "@/store/calculator-store";
import { Header } from "./header";
import { Display } from "./display";
import { MemoryBar } from "./memory-bar";
import { BasicKeypad } from "./basic-keypad";
import { ScientificKeypad } from "./scientific-keypad";
import { ProgrammerPad } from "./programmer-pad";
import { ConverterPanel } from "./converter-panel";
import { MoreSheet } from "./more-sheet";
import { HistoryPanel } from "./history-panel";
import { useCalculatorKeyboard } from "./use-keyboard";

export function CalculatorApp() {
  const mode = useCalc((s) => s.mode);
  const theme = useCalc((s) => s.theme);
  useCalculatorKeyboard();

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "amoled" ? "#000000" : "#e8e6e1");
  }, [theme]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-6xl">
        <div className="mx-auto flex w-full max-w-xl flex-1 flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-6">
          <Header />
          <div className="mt-4 flex flex-1 flex-col">
            <Display />
            <div className="mt-5 flex flex-col gap-3">
              <MemoryBar />
              {mode === "basic" ? <BasicKeypad /> : null}
              {mode === "scientific" ? (
                <>
                  <MoreSheet />
                  <ScientificKeypad />
                </>
              ) : null}
              {mode === "programmer" ? <ProgrammerPad /> : null}
              {mode === "converter" ? <ConverterPanel /> : null}
            </div>
          </div>
        </div>
        <HistoryPanel variant="side" />
      </div>
      <HistoryPanel variant="overlay" />
      <Toaster
        theme={theme === "amoled" ? "dark" : "light"}
        position="bottom-center"
        toastOptions={{
          className: "font-sans text-sm bg-surface text-fg border-border",
        }}
      />
    </div>
  );
}
