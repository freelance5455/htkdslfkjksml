import { useMemo, useState } from "react";
import { ArrowUpDown, Check, Copy, RefreshCw, Search, X } from "lucide-react";
import { cn } from "@/lib/cn";
import {
  POPULAR_CODES,
  QUICK_PAIRS,
  convert,
  currencyLabel,
  formatMoney,
  formatRate,
} from "@/lib/currency/rates";
import { copyText, tick } from "@/lib/feedback";
import { formatWhen, t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

function feedback() {
  const { sound, haptic } = useAppStore.getState();
  tick(sound, haptic);
}

function sanitizeAmount(raw: string): string {
  let value = raw.replace(/[^\d.,،]/g, "").replace(/[,،]/g, ".");
  const parts = value.split(".");
  if (parts.length > 2) value = `${parts[0]}.${parts.slice(1).join("")}`;
  if (value.startsWith(".")) value = `0${value}`;
  return value.slice(0, 16);
}

export function CurrencyView({
  onToast,
  onRefresh,
}: {
  onToast: (message: string) => void;
  onRefresh: () => void;
}) {
  const lang = useAppStore((s) => s.lang);
  const rates = useAppStore((s) => s.rates);
  const status = useAppStore((s) => s.rateStatus);
  const asOf = useAppStore((s) => s.rateAsOf);
  const provider = useAppStore((s) => s.rateProvider);
  const fxFrom = useAppStore((s) => s.fxFrom);
  const fxTo = useAppStore((s) => s.fxTo);
  const fxAmount = useAppStore((s) => s.fxAmount);
  const setFx = useAppStore((s) => s.setFx);
  const swapFx = useAppStore((s) => s.swapFx);
  const [picking, setPicking] = useState<"from" | "to" | null>(null);

  const amount = fxAmount === "" || fxAmount === "." ? 0 : Number(fxAmount);
  const value = rates && Number.isFinite(amount) ? convert(amount, fxFrom, fxTo, rates) : null;
  const unit = rates ? convert(1, fxFrom, fxTo, rates) : null;
  const inverse = rates ? convert(1, fxTo, fxFrom, rates) : null;
  const effective = status === "idle" && rates ? "cached" : status;
  const count = rates ? Object.keys(rates).length : 0;

  async function copyResult() {
    if (value == null) return;
    feedback();
    const ok = await copyText(String(value));
    onToast(t(lang, ok ? "copied" : "copyFail"));
  }

  function saveCompare() {
    if (value == null) return;
    feedback();
    useAppStore.getState().addHistory({
      kind: "fx",
      expression: `${fxAmount || "0"} ${fxFrom} → ${fxTo}`,
      result: `${formatMoney(value, fxTo)} ${fxTo}`,
      copyValue: String(value),
    });
    onToast(t(lang, "saved"));
  }

  if (picking) {
    return (
      <CurrencyPicker
        selected={picking === "from" ? fxFrom : fxTo}
        onClose={() => setPicking(null)}
        onPick={(code) => {
          feedback();
          setFx(picking === "from" ? { fxFrom: code } : { fxTo: code });
          setPicking(null);
        }}
      />
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col overflow-y-auto px-4 pt-2 pb-4">
      <div className="rounded-3xl border border-border bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted">{t(lang, "from")}</p>
          <button
            type="button"
            onClick={() => {
              feedback();
              setPicking("from");
            }}
            className="rounded-full bg-primary-soft px-3 py-1 text-sm font-semibold text-primary"
            dir="ltr"
          >
            {fxFrom}
          </button>
        </div>
        <label className="mt-2 block">
          <span className="sr-only">{t(lang, "amount")}</span>
          <input
            inputMode="decimal"
            value={fxAmount}
            onChange={(event) => setFx({ fxAmount: sanitizeAmount(event.target.value) })}
            className="w-full bg-transparent text-end text-4xl font-semibold tabular-nums outline-none"
            dir="ltr"
          />
        </label>
        <button
          type="button"
          onClick={() => {
            feedback();
            setPicking("from");
          }}
          className="mt-1 text-sm text-muted"
        >
          {currencyLabel(fxFrom, lang)}
        </button>
      </div>

      <div className="relative z-10 -my-3 flex justify-center">
        <button
          type="button"
          aria-label={t(lang, "swap")}
          onClick={() => {
            feedback();
            swapFx();
          }}
          className="grid size-11 place-items-center rounded-full bg-primary text-primary-fg shadow-sm"
        >
          <ArrowUpDown className="size-5" />
        </button>
      </div>

      <div className="rounded-3xl border border-border bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted">{t(lang, "to")}</p>
          <button
            type="button"
            onClick={() => {
              feedback();
              setPicking("to");
            }}
            className="rounded-full bg-primary-soft px-3 py-1 text-sm font-semibold text-primary"
            dir="ltr"
          >
            {fxTo}
          </button>
        </div>
        <div className="mt-2 flex items-end gap-2">
          <p className="min-w-0 flex-1 overflow-x-auto text-end text-4xl font-semibold text-primary tabular-nums" dir="ltr">
            {effective === "loading" && !rates ? "…" : value == null ? "—" : formatMoney(value, fxTo)}
          </p>
          <button
            type="button"
            aria-label={t(lang, "copy")}
            onClick={() => void copyResult()}
            className="grid size-11 shrink-0 place-items-center rounded-2xl text-muted"
          >
            <Copy className="size-5" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => {
            feedback();
            setPicking("to");
          }}
          className="mt-1 text-sm text-muted"
        >
          {currencyLabel(fxTo, lang)}
        </button>
      </div>

      <div className="mt-4 rounded-3xl border border-border bg-surface px-4 py-3">
        {unit != null && inverse != null ? (
          <div className="space-y-1 text-sm" dir="ltr">
            <p className="text-end">
              <span className="text-muted">{t(lang, "rate")}: </span>
              <span className="font-semibold tabular-nums">
                1 {fxFrom} = {formatRate(unit)} {fxTo}
              </span>
            </p>
            <p className="text-end text-muted tabular-nums">
              1 {fxTo} = {formatRate(inverse)} {fxFrom}
            </p>
          </div>
        ) : (
          <p className="text-sm text-muted">{effective === "loading" ? t(lang, "loadingRates") : t(lang, "noRates")}</p>
        )}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
          <span>
            {asOf ? `${t(lang, "updated")}: ${formatWhen(asOf, lang)}` : t(lang, "loadingRates")}
            {provider ? ` · ${provider}` : ""}
            {count ? ` · ${count} ${t(lang, "currenciesCount")}` : ""}
          </span>
          <button
            type="button"
            onClick={() => {
              feedback();
              onRefresh();
            }}
            className="inline-flex items-center gap-1 rounded-full bg-surface-2 px-3 py-1 font-medium text-fg"
          >
            <RefreshCw className={cn("size-3.5", effective === "loading" && "animate-spin")} />
            {t(lang, "refresh")}
          </button>
        </div>
        {effective === "live" ? (
          <p className="mt-2 text-xs font-medium text-primary">{t(lang, "live")}</p>
        ) : null}
        {effective === "cached" ? (
          <p className="mt-2 text-sm text-fg">{t(lang, "cached")}</p>
        ) : null}
        {effective === "cached" ? <p className="mt-1 text-xs text-muted">{t(lang, "cachedDetail")}</p> : null}
        {effective === "error" ? <p className="mt-2 text-sm">{t(lang, "noRates")}</p> : null}
        <p className="mt-2 text-xs text-muted">{t(lang, "disclaimer")}</p>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-sm font-medium text-muted">{t(lang, "pairs")}</p>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {QUICK_PAIRS.map(([from, to]) => {
            const active = fxFrom === from && fxTo === to;
            return (
              <button
                key={`${from}-${to}`}
                type="button"
                dir="ltr"
                onClick={() => {
                  feedback();
                  setFx({ fxFrom: from, fxTo: to });
                }}
                className={cn(
                  "shrink-0 rounded-full border px-3 py-2 text-sm font-medium tabular-nums",
                  active
                    ? "border-primary bg-primary text-primary-fg"
                    : "border-border bg-surface text-fg",
                )}
              >
                {from}/{to}
              </button>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={saveCompare}
        disabled={value == null}
        className="mt-4 rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-fg disabled:opacity-40"
      >
        {t(lang, "saveCompare")}
      </button>
    </div>
  );
}

function CurrencyPicker({
  selected,
  onPick,
  onClose,
}: {
  selected: string;
  onPick: (code: string) => void;
  onClose: () => void;
}) {
  const lang = useAppStore((s) => s.lang);
  const rates = useAppStore((s) => s.rates);
  const [query, setQuery] = useState("");
  const codes = useMemo(() => Object.keys(rates ?? {}).sort(), [rates]);
  const q = query.trim().toLowerCase();

  const filtered = useMemo(() => {
    return codes
      .map((code) => ({ code, name: currencyLabel(code, lang) }))
      .filter((item) => {
        if (!q) return true;
        return (
          item.code.toLowerCase().includes(q) ||
          item.name.toLowerCase().includes(q) ||
          currencyLabel(item.code, "en").toLowerCase().includes(q) ||
          currencyLabel(item.code, "ar").includes(query.trim())
        );
      })
      .sort((a, b) => a.name.localeCompare(b.name, lang === "ar" ? "ar" : "en"));
  }, [codes, lang, q, query]);

  const popular = POPULAR_CODES.filter((code) => codes.includes(code)).filter((code) =>
    filtered.some((item) => item.code === code),
  );

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-2 px-4 pt-2">
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl bg-surface px-3">
          <Search className="size-4 shrink-0 text-muted" />
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t(lang, "search")}
            className="h-12 w-full bg-transparent text-sm outline-none"
          />
        </div>
        <button
          type="button"
          aria-label={t(lang, "close")}
          onClick={onClose}
          className="grid size-12 place-items-center rounded-2xl bg-surface"
        >
          <X className="size-5" />
        </button>
      </div>
      <p className="px-4 pt-3 text-sm font-medium">{t(lang, "choose")}</p>
      <div className="min-h-0 flex-1 overflow-y-auto pb-4">
        {!q && popular.length > 0 ? (
          <div className="px-4 pt-3">
            <p className="mb-2 text-xs text-muted">{t(lang, "popular")}</p>
            <div className="flex flex-wrap gap-2">
              {popular.map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => onPick(code)}
                  className={cn(
                    "rounded-full px-3 py-2 text-sm font-medium",
                    code === selected ? "bg-primary text-primary-fg" : "bg-surface text-fg",
                  )}
                  dir="ltr"
                >
                  {code}
                </button>
              ))}
            </div>
          </div>
        ) : null}
        <p className="px-4 pt-4 text-xs text-muted">{t(lang, "allCurrencies")}</p>
        {filtered.length === 0 ? (
          <p className="px-4 py-6 text-sm text-muted">{rates ? t(lang, "noMatch") : t(lang, "loadingRates")}</p>
        ) : (
          <ul>
            {filtered.map((item) => (
              <li key={item.code}>
                <button
                  type="button"
                  onClick={() => onPick(item.code)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-start"
                >
                  <span
                    className="grid h-11 w-14 shrink-0 place-items-center rounded-2xl bg-surface text-sm font-semibold"
                    dir="ltr"
                  >
                    {item.code}
                  </span>
                  <span className="min-w-0 flex-1 truncate">{item.name}</span>
                  {item.code === selected ? <Check className="size-4 text-primary" /> : null}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
