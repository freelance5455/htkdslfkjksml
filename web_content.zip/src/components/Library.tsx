import { useMemo, useState } from "react";
import { fa, faPercent, formatBytes, timeAgo } from "@/lib/format";
import type { Book, Settings } from "@/lib/types";
import {
  IconBook,
  IconChevronLeft,
  IconClose,
  IconDownload,
  IconGear,
  IconLogo,
  IconPlus,
  IconSearch,
} from "./Icons";
import { FullscreenButton } from "./FullscreenButton";
import { Reveal } from "./ui";

interface Props {
  books: Book[];
  settings: Settings;
  busy: string | null;
  storage: { usage: number; quota: number } | null;
  onOpen: (id: string) => void;
  onAddFiles: (files: File[]) => void;
  onDelete: (id: string) => void;
  onOpenSettings: () => void;
}

function EmptyArt() {
  return (
    <svg viewBox="0 0 220 150" className="h-[150px] w-full max-w-[240px]">
      <defs>
        <linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f7f3ea" />
          <stop offset="1" stopColor="#ded6c4" />
        </linearGradient>
      </defs>
      <rect x="19" y="16" width="82" height="118" rx="5" fill="url(#pg)" />
      <rect x="19" y="16" width="7" height="118" rx="3" fill="#00000018" />
      {Array.from({ length: 19 }).map((_, i) => (
        <rect key={i} x={33} y={28 + i * 5} width={55 - ((i * 13) % 18)} height={1.5} rx={0.75} fill="#4a4a4a" opacity={0.55} />
      ))}
      <path d="M107 72h21m-8-8 8 8-8 8" fill="none" stroke="#e8b04b" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="137" y="16" width="65" height="118" rx="5" fill="#fdfbf5" />
      <rect x="145" y="25" width="30" height="4" rx="2" fill="#9a7137" opacity=".7" />
      {Array.from({ length: 6 }).map((_, i) => (
        <rect key={i} x={145} y={41 + i * 13} width={47 - ((i * 11) % 20)} height={5.5} rx={2.7} fill="#2b2925" opacity={0.85} />
      ))}
      <path d="M146 121h46" stroke="#e8b04b" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function Library({
  books,
  settings,
  busy,
  storage,
  onOpen,
  onAddFiles,
  onDelete,
  onOpenSettings,
}: Props) {
  const [q, setQ] = useState("");
  const [confirm, setConfirm] = useState<string | null>(null);

  const sorted = useMemo(
    () =>
      [...books].sort((a, b) => {
        const at = a.progress?.at ?? a.addedAt;
        const bt = b.progress?.at ?? b.addedAt;
        return bt - at;
      }),
    [books],
  );

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return sorted;
    return sorted.filter((b) => b.title.toLowerCase().includes(t));
  }, [sorted, q]);

  const resume = sorted.find((b) => b.progress) ?? null;

  return (
    <div className="relative mx-auto flex min-h-full w-full max-w-[560px] flex-col px-4 pb-10">
      {/* ---------- سربرگ ---------- */}
      <header className="sticky top-0 z-20 -mx-4 mb-3 border-b border-line/60 bg-ink/82 px-4 pb-2 pt-[max(env(safe-area-inset-top),14px)] backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-gold/30 bg-gradient-to-b from-gold/18 to-transparent text-gold2">
            <IconLogo size={23} />
          </span>
          <div className="min-w-0 flex-1">
            <h1 className="font-display text-[21px] leading-none tracking-tight text-chalk">
              درشت‌نما
            </h1>
            <p className="mt-1 truncate text-[10.5px] text-mist">
              متن PDF را استخراج کنید و درشت بخوانید
            </p>
          </div>
          <FullscreenButton className="press grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-line bg-panel/70 text-mist hover:text-gold2" />
          <button
            onClick={onOpenSettings}
            aria-label="تنظیمات"
            className="press grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-line bg-panel/70 text-mist hover:text-gold2"
          >
            <IconGear size={19} />
          </button>
        </div>
      </header>

      {/* ---------- قهرمان ---------- */}
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl border border-line/80 bg-panel/55 p-4">
          <div className="spines absolute inset-x-0 top-0 h-[5px] opacity-70" />
          <div className="pointer-events-none absolute -end-10 -top-12 h-40 w-40 rotate-[8deg] bg-gradient-to-b from-gold/12 to-transparent blur-[2px]" />
          <span className="animate-sheen pointer-events-none absolute -inset-y-10 start-0 w-1/2 bg-gradient-to-r from-transparent via-gold2/10 to-transparent" />
          <p className="mt-1 text-[10.5px] font-medium tracking-[0.18em] text-jade">
            خوانندهٔ آفلاین · بدون سرور
          </p>
          <h2 className="mt-2 font-display text-[30px] leading-[1.25] text-chalk">
            متن PDF،
            <br />
            <span className="text-gold2">از نو چیده می‌شود.</span>
          </h2>
          <p className="mt-2 max-w-[42ch] text-[12px] leading-6 text-mist">
            کلمات و جمله‌ها از فایل استخراج می‌شوند و در صفحه‌های تازه با قلم درشت
            دوباره سطرچینی می‌شوند. اگر کتاب اسکن‌شده باشد، نوشته‌های تصویر با OCR شناسایی می‌شوند.
          </p>
          <div className="mt-3 flex items-center gap-3 text-[10.5px] font-medium text-jade">
            <span>قلم {fa(settings.fontSize)} پیکسل</span>
            <span className="h-3 w-px bg-line" />
            <span>حداکثر {fa(settings.linesPerPage)} خط در صفحه</span>
          </div>
        </div>
      </Reveal>

      {/* ---------- افزودن ---------- */}
      <Reveal delay={90}>
        <div className="mt-4">
          <label className="press flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl border border-gold2/40 bg-gradient-to-b from-gold2 to-gold px-4 py-3 text-[13px] font-extrabold text-ink shadow-[0_10px_28px_rgba(232,176,75,.26)]">
            <IconPlus size={18} />
            افزودن کتاب PDF
            <input
              type="file"
              accept="application/pdf,.pdf"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = Array.from(e.target.files ?? []);
                if (files.length) onAddFiles(files);
                e.target.value = "";
              }}
            />
          </label>
        </div>
      </Reveal>

      {/* ---------- ادامهٔ مطالعه ---------- */}
      {resume && (
        <Reveal delay={120}>
          <button
            onClick={() => onOpen(resume.id)}
            className="press group mt-4 flex w-full items-stretch gap-3 overflow-hidden rounded-2xl border border-gold/25 bg-gradient-to-l from-panel2/80 to-panel/50 p-3 text-start"
          >
            <div className="relative h-[92px] w-[66px] shrink-0 overflow-hidden rounded-lg border border-line bg-ink2 shadow-[0_8px_20px_rgba(0,0,0,.45)]">
              {resume.cover ? (
                <img
                  src={resume.cover}
                  alt=""
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <span className="grid h-full w-full place-items-center text-mist">
                  <IconBook size={22} />
                </span>
              )}
              <span className="absolute inset-y-0 start-0 w-[5px] bg-gradient-to-b from-black/45 to-black/10" />
            </div>
            <div className="flex min-w-0 flex-1 flex-col justify-between py-0.5">
              <div className="min-w-0">
                <span className="text-[10px] font-medium tracking-wide text-jade">
                  ادامهٔ مطالعه · {timeAgo(resume.progress!.at)}
                </span>
                <h3 className="mt-1 truncate font-display text-[19px] leading-tight text-chalk">
                  {resume.title}
                </h3>
                <p className="mt-1 truncate text-[11px] text-mist">
                  صفحهٔ {fa(resume.progress!.page)} PDF · صفحهٔ خواندنی {fa(resume.progress!.displayPage)}
                </p>
              </div>
              <div>
                <div className="h-[6px] w-full overflow-hidden rounded-full bg-ink2">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-gold to-gold2 transition-[width] duration-700"
                    style={{ width: `${Math.max(2, resume.progress!.percent)}%` }}
                  />
                </div>
                <div className="mt-1.5 flex items-center justify-between">
                  <span className="text-[10.5px] text-mist">
                    {faPercent(resume.progress!.percent)} خوانده شده
                  </span>
                  <span className="flex items-center gap-1 text-[11.5px] font-bold text-gold2">
                    ادامه
                    <IconChevronLeft size={15} />
                  </span>
                </div>
              </div>
            </div>
          </button>
        </Reveal>
      )}

      {/* ---------- جست‌وجو ---------- */}
      {books.length > 2 && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-line/80 bg-panel/50 px-3">
          <IconSearch size={16} className="shrink-0 text-mist" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جست‌وجو در کتاب‌ها…"
            className="w-full bg-transparent py-2.5 text-[12.5px] text-chalk outline-none placeholder:text-mist/70"
          />
          {q && (
            <button onClick={() => setQ("")} className="press text-mist hover:text-chalk">
              <IconClose size={15} />
            </button>
          )}
        </div>
      )}

      {/* ---------- قفسه ---------- */}
      {books.length === 0 ? (
        <Reveal delay={60}>
          <div className="mt-5 flex flex-col items-center rounded-3xl border border-dashed border-line bg-panel/30 px-5 py-7 text-center">
            <EmptyArt />
            <h3 className="mt-3 font-display text-[20px] text-chalk">
              کتابخانه خالی است
            </h3>
            <p className="mt-1.5 max-w-[38ch] text-[12px] leading-6 text-mist">
              یک PDF از گوشی‌تان اضافه کنید تا متنِ ریز استخراج و به صفحه‌های جدید با
              خط‌های خوانا تبدیل شود.
            </p>
            <div className="mt-4 grid w-full grid-cols-3 gap-2 text-[10.5px] text-mist">
              {[
                { n: "۱", t: "PDF را اضافه کنید" },
                { n: "۲", t: "قلم و تعداد خط را تنظیم کنید" },
                { n: "۳", t: "بکشید و بخوانید" },
              ].map((s) => (
                <div key={s.n} className="rounded-xl border border-line/70 bg-ink2/50 px-2 py-2.5">
                  <span className="font-display text-[16px] text-gold2">{s.n}</span>
                  <p className="mt-1 leading-5">{s.t}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      ) : (
        <>
          <div className="mt-5 mb-2 flex items-baseline justify-between">
            <h3 className="font-display text-[18px] text-chalk">قفسهٔ کتاب‌ها</h3>
            <span className="text-[10.5px] text-mist">
              {fa(filtered.length)} {filtered.length === 1 ? "کتاب" : "کتاب"}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((b, i) => {
              const pct = b.progress?.percent ?? 0;
              return (
                <Reveal key={b.id} delay={Math.min(i * 45, 300)}>
                  <div className="group relative overflow-hidden rounded-2xl border border-line/80 bg-panel/50 transition-colors hover:border-gold/35">
                    <button
                      onClick={() => onOpen(b.id)}
                      className="press block w-full text-start"
                      aria-label={`باز کردن ${b.title}`}
                    >
                      <div className="relative aspect-[3/4] w-full overflow-hidden bg-ink2">
                        {b.cover ? (
                          <img
                            src={b.cover}
                            alt=""
                            loading="lazy"
                            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.06]"
                          />
                        ) : (
                          <span className="grid h-full w-full place-items-center text-mist">
                            <IconBook size={30} />
                          </span>
                        )}
                        <span className="absolute inset-y-0 start-0 w-[7px] bg-gradient-to-b from-black/55 via-black/25 to-black/55" />
                        <span className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-ink via-ink/75 to-transparent" />
                        <span className="absolute bottom-2 start-2.5 end-2.5">
                          <span className="block truncate font-display text-[14.5px] leading-tight text-chalk">
                            {b.title}
                          </span>
                          <span className="mt-0.5 block truncate text-[9.5px] text-mist">
                            {fa(b.pageCount)} صفحه · {formatBytes(b.size)}
                          </span>
                        </span>
                        {pct > 0 && (
                          <span className="absolute end-2 top-2 rounded-full bg-ink/85 px-1.5 py-0.5 text-[9.5px] font-bold text-gold2 backdrop-blur-sm">
                            {faPercent(pct)}
                          </span>
                        )}
                        <span className="absolute start-2 top-2 rounded-full bg-ink/70 px-1.5 py-0.5 text-[9px] text-chalk/80 backdrop-blur-sm">
                          متن بازچینی‌شده
                        </span>
                      </div>
                      <div className="h-[5px] w-full bg-ink2">
                        <div
                          className="h-full bg-gradient-to-l from-gold to-gold2"
                          style={{ width: `${Math.max(pct > 0 ? 4 : 0, pct)}%` }}
                        />
                      </div>
                    </button>
                    <div className="flex items-center justify-between px-2.5 py-1.5">
                      <span className="truncate text-[9.5px] text-mist">
                        {b.progress ? timeAgo(b.progress.at) : "خوانده‌نشده"}
                      </span>
                      {confirm === b.id ? (
                        <span className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              onDelete(b.id);
                              setConfirm(null);
                            }}
                            className="press rounded-md border border-ember/50 bg-ember/15 px-1.5 py-0.5 text-[9.5px] font-bold text-ember"
                          >
                            حذف
                          </button>
                          <button
                            onClick={() => setConfirm(null)}
                            className="press rounded-md border border-line px-1.5 py-0.5 text-[9.5px] text-mist"
                          >
                            نه
                          </button>
                        </span>
                      ) : (
                        <button
                          onClick={() => setConfirm(b.id)}
                          aria-label="حذف کتاب"
                          className="press grid h-6 w-6 place-items-center rounded-md text-mist/70 hover:bg-ember/12 hover:text-ember"
                        >
                          <IconClose size={13} />
                        </button>
                      )}
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </>
      )}

      {/* ---------- پانویس ---------- */}
      <footer className="mt-8 rounded-2xl border border-line/60 bg-panel/30 p-4">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-jade/30 bg-jade/10 text-jade">
            <IconBook size={16} />
          </span>
          <p className="text-[11px] leading-6 text-mist">
            کتاب‌ها و جای مطالعه فقط در حافظهٔ همین دستگاه (IndexedDB) نگه داشته می‌شوند؛ هیچ
            فایلی به اینترنت فرستاده نمی‌شود. PDFهای اسکن‌شده (تصویری) هم با OCR روی همین دستگاه به متن تبدیل می‌شوند.
            اگر دادهٔ مرورگر را پاک کنید، کتاب‌ها هم پاک می‌شوند.
          </p>
        </div>
        {storage && storage.quota > 0 && (
          <div className="mt-3">
            <div className="mb-1 flex justify-between text-[10px] text-mist">
              <span>فضای در دسترس مرورگر</span>
              <span>
                {formatBytes(storage.usage)} از {formatBytes(storage.quota)}
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-ink2">
              <div
                className="h-full rounded-full bg-gradient-to-l from-jade to-gold"
                style={{ width: `${Math.min(100, (storage.usage / storage.quota) * 100)}%` }}
              />
            </div>
          </div>
        )}
        <p className="mt-3 text-center font-display text-[13px] text-mist/70">
          درشت‌نما · ساخته‌شده برای صفحه‌های کوچک
        </p>
      </footer>

      {/* ---------- پوشش وارد کردن ---------- */}
      {busy && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-ink/85 px-8 backdrop-blur-sm">
          <div className="popin flex w-full max-w-[320px] flex-col items-center gap-3 rounded-2xl border border-line bg-panel p-5 text-center">
            <span className="relative grid h-12 w-12 place-items-center">
              <span className="absolute inset-0 animate-spin rounded-full border-2 border-gold/25 border-t-gold" />
              <IconDownload size={20} className="text-gold2" />
            </span>
            <p className="text-[12.5px] font-medium text-chalk">{busy}</p>
            <p className="text-[10.5px] leading-5 text-mist">
              در حال باز کردن فایل و ساختن جلد کتاب…
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
