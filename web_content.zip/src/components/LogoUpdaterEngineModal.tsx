import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Camera,
  CheckCircle2,
  Trash2,
  RefreshCw,
  Sparkles,
  Sliders,
  ShieldCheck,
  Eye,
  Download,
  Flame,
  Sun,
  Crown,
  Laptop,
  Smartphone,
  Layers,
  ArrowRight
} from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';

interface LogoUpdaterEngineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast?: (msg: string) => void;
}

const PRESET_EMBLEMS = [
  {
    id: 'preset-sun',
    name: 'Prophetic Golden Sun',
    description: 'Original Sacred Anointing Emblem',
    url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-glory',
    name: 'Celestial Glory Light',
    description: 'Golden Ethereal Sanctuary Presence',
    url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-flame',
    name: 'Fire of Pentecost',
    description: 'Anointed Revival Flame',
    url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-altar',
    name: 'Sovereign Throne Altar',
    description: 'Spiritual Breakthrough Crown',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80'
  }
];

export const LogoUpdaterEngineModal: React.FC<LogoUpdaterEngineModalProps> = ({
  isOpen,
  onClose,
  onShowToast
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [currentGlobalLogo, setCurrentGlobalLogo] = useState<string | null>(() => offlineCache.getCustomAppLogo());
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(() => offlineCache.getCustomAppLogo());
  const [fileDetails, setFileDetails] = useState<{ name: string; size: string; type: string; dimensions?: string } | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activePreviewTab, setActivePreviewTab] = useState<'navbar' | 'appIcon' | 'splash' | 'mobile'>('navbar');
  const [haloGlowColor, setHaloGlowColor] = useState<'gold' | 'purple' | 'amber' | 'emerald'>('gold');
  const [borderStyle, setBorderStyle] = useState<'squircle' | 'circle' | 'rounded'>('squircle');

  useEffect(() => {
    const handleLogoSync = () => {
      const active = offlineCache.getCustomAppLogo();
      setCurrentGlobalLogo(active);
      if (!selectedImagePreview) {
        setSelectedImagePreview(active);
      }
    };
    const unsubscribe = offlineCache.subscribe(handleLogoSync);
    window.addEventListener('juhnkrix_logo_updated', handleLogoSync);
    return () => {
      unsubscribe();
      window.removeEventListener('juhnkrix_logo_updated', handleLogoSync);
    };
  }, [selectedImagePreview]);

  if (!isOpen) return null;

  // Process & Optimize selected image file
  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      if (onShowToast) onShowToast('❌ Please select a valid image file (PNG, JPG, WEBP, GIF, SVG).');
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) {
        setIsProcessing(false);
        return;
      }

      // Optimize image through HTML Canvas to ensure optimal resolution and storage safety
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 600;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const optimizedDataUrl = canvas.toDataURL('image/png', 0.95);
          setSelectedImagePreview(optimizedDataUrl);
          setFileDetails({
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type || 'image/png',
            dimensions: `${Math.round(width)} × ${Math.round(height)} px`
          });
        } else {
          setSelectedImagePreview(rawDataUrl);
          setFileDetails({
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type || 'image/png',
            dimensions: `${img.width} × ${img.height} px`
          });
        }
        setIsProcessing(false);
        if (onShowToast) onShowToast(`✓ Selected "${file.name}" ready for logo replacement!`);
      };

      img.onerror = () => {
        setSelectedImagePreview(rawDataUrl);
        setIsProcessing(false);
      };

      img.src = rawDataUrl;
    };

    reader.onerror = () => {
      setIsProcessing(false);
      if (onShowToast) onShowToast('❌ Error reading image from device storage.');
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleApplyLogoGlobally = () => {
    if (!selectedImagePreview) {
      if (onShowToast) onShowToast('❌ Please select an image or photo first.');
      return;
    }

    try {
      // 1. Save to offlineCache & LocalStorage
      offlineCache.setCustomAppLogo(selectedImagePreview);
      setCurrentGlobalLogo(selectedImagePreview);

      // 2. Broadcast custom event to all open components
      window.dispatchEvent(
        new CustomEvent('juhnkrix_logo_updated', {
          detail: selectedImagePreview
        })
      );

      // 3. Dynamically update favicon if applicable
      const favicon = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
      if (favicon) {
        favicon.href = selectedImagePreview;
      }

      if (onShowToast) {
        onShowToast('✓ JUHNKRIX MUSIKA APP Logo replaced globally across all pages & navigation bars!');
      }

      onClose();
    } catch (err) {
      console.error('Failed to update app logo:', err);
      if (onShowToast) onShowToast('❌ Failed to persist logo.');
    }
  };

  const handleResetToDefault = () => {
    offlineCache.setCustomAppLogo(null);
    setCurrentGlobalLogo(null);
    setSelectedImagePreview(null);
    setFileDetails(null);

    window.dispatchEvent(
      new CustomEvent('juhnkrix_logo_updated', {
        detail: null
      })
    );

    if (onShowToast) {
      onShowToast('✓ Reset JUHNKRIX MUSIKA Logo to sacred default golden sun emblem.');
    }
  };

  const handleSelectPreset = (url: string, name: string) => {
    setSelectedImagePreview(url);
    setFileDetails({
      name,
      size: 'Optimized Preset',
      type: 'image/jpeg',
      dimensions: '400 × 400 px'
    });
    if (onShowToast) onShowToast(`✓ Selected "${name}" preset! Click "Apply" to save.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/85 backdrop-blur-xl overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 15 }}
        className="w-full max-w-4xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-2 border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto relative"
      >
        {/* Divine Header */}
        <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 p-5 sm:p-6 border-b border-amber-500/30 flex items-center justify-between relative">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden">
                {selectedImagePreview ? (
                  <img
                    src={selectedImagePreview}
                    alt="Logo Engine Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Sun className="w-6 h-6 text-amber-400 animate-spin-slow" />
                )}
              </div>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40">
                  <Sparkles className="w-3 h-3 inline mr-1 text-amber-400" />
                  LOGO UPDATER ENGINES & MACHINES
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 mt-0.5">
                JUHNKRIX MUSIKA App Logo Machine
              </h2>
              <p className="text-xs text-amber-200/70">
                Replace the JUHNKRIX MUSIKA APP Logo with any image or photo directly from your device storage.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* LOGO ENGINE button moved into the JUHNKRIX MUSIKA APP Logo updator page */}
            <button
              type="button"
              id="modal-logo-engine-header-btn"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 text-xs font-black flex items-center space-x-1.5 shadow-lg shadow-amber-500/25 border border-amber-300 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              title="Open Logo Engine File Selector from Device Storage"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
              <span>LOGO ENGINE</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-amber-200 border border-amber-500/20 transition-all cursor-pointer"
              title="Close Logo Engine"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Split Grid */}
        <div className="p-5 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[78vh] overflow-y-auto">
          {/* Left Column: Device Storage File Selector & Controls (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Dedicated LOGO ENGINE Banner & Selector Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-500/15 border border-amber-400/40 rounded-2xl p-3.5 shadow-md">
              <div className="flex items-center space-x-2.5 text-amber-200">
                <div className="p-1.5 rounded-lg bg-amber-500/20 border border-amber-400/40 text-amber-300">
                  <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-amber-200 uppercase tracking-wide">JUHNKRIX MUSIKA LOGO ENGINE</h4>
                  <p className="text-[10px] text-amber-300/80">Select any image, emblem or ministry photo from device memory</p>
                </div>
              </div>
              <button
                type="button"
                id="modal-logo-engine-selector-btn"
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black flex items-center space-x-1.5 shadow-md transition-all hover:scale-105 active:scale-95 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-slate-950" />
                <span>LOGO ENGINE</span>
              </button>
            </div>
            {/* Hidden Inputs */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
            <input
              type="file"
              ref={cameraInputRef}
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={handleFileChange}
            />

            {/* Drag & Drop Upload Machine Area */}
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 relative overflow-hidden group ${
                isDragging
                  ? 'border-amber-400 bg-amber-500/20 scale-[1.01]'
                  : 'border-amber-500/40 bg-slate-950/60 hover:bg-slate-900/80 hover:border-amber-400'
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-purple-500/5 pointer-events-none" />

              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-700/20 border border-amber-400/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-amber-500/10">
                <Upload className="w-8 h-8 text-amber-400 animate-pulse" />
              </div>

              <h3 className="text-base sm:text-lg font-bold text-amber-100 font-serif">
                Select Photo or Image from Device Storage
              </h3>
              <p className="text-xs text-slate-300 max-w-sm mt-1 mb-4">
                Click to browse your phone gallery, tablet photos, or computer files — or drag and drop any image here.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black flex items-center space-x-1.5 shadow-md shadow-amber-500/30">
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Choose from Storage</span>
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    cameraInputRef.current?.click();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-200 text-xs font-bold border border-amber-500/30 flex items-center space-x-1.5 transition-colors"
                >
                  <Camera className="w-3.5 h-3.5 text-amber-400" />
                  <span>Take Photo (Camera)</span>
                </button>
              </div>

              <span className="text-[10px] text-slate-400 mt-3">
                Supports JPG, PNG, WEBP, SVG, HEIC, GIF (High-Res Auto-Scaling)
              </span>
            </div>

            {/* Selected File Details Bar */}
            {fileDetails && (
              <div className="bg-slate-950/80 border border-amber-500/30 rounded-2xl p-3.5 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3 truncate">
                  <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
                    <ImageIcon className="w-4 h-4" />
                  </div>
                  <div className="truncate">
                    <p className="font-bold text-amber-200 truncate">{fileDetails.name}</p>
                    <p className="text-[10px] text-slate-400">
                      {fileDetails.size} • {fileDetails.dimensions || fileDetails.type}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-semibold border border-amber-500/20 shrink-0"
                >
                  Change File
                </button>
              </div>
            )}

            {/* Sacred Emblems Preset Gallery */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Or Select Anointed Ministry Emblems</span>
                </span>
                <span className="text-[10px] text-slate-400">Prophetic Presets</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {PRESET_EMBLEMS.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset.url, preset.name)}
                    className="p-2 rounded-2xl bg-slate-950/60 hover:bg-slate-900 border border-amber-500/20 hover:border-amber-400 transition-all flex flex-col items-center text-center group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-xl overflow-hidden border border-amber-500/30 mb-2 group-hover:scale-105 transition-transform">
                      <img
                        src={preset.url}
                        alt={preset.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-[11px] font-bold text-amber-200 group-hover:text-amber-100 truncate w-full">
                      {preset.name}
                    </span>
                    <span className="text-[9px] text-slate-400 truncate w-full">
                      {preset.description}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Frame & Halo Styling Engine Controls */}
            <div className="bg-slate-950/80 border border-amber-500/20 rounded-2xl p-4 space-y-3">
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                <span>Emblem Framing & Golden Glow Calibration</span>
              </span>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-[10px] font-semibold text-slate-400 block mb-1">
                    Frame Geometry
                  </label>
                  <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800">
                    {(['squircle', 'circle', 'rounded'] as const).map((shape) => (
                      <button
                        key={shape}
                        type="button"
                        onClick={() => setBorderStyle(shape)}
                        className={`flex-1 py-1 text-[10px] font-bold rounded-lg capitalize transition-all ${
                          borderStyle === shape
                            ? 'bg-amber-500 text-slate-950 shadow'
                            : 'text-slate-400 hover:text-amber-200'
                        }`}
                      >
                        {shape}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-semibold text-slate-400 block mb-1">
                    Divine Halo Glow
                  </label>
                  <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800">
                    {(['gold', 'purple', 'amber', 'emerald'] as const).map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setHaloGlowColor(color)}
                        className={`flex-1 py-1 text-[10px] font-bold rounded-lg capitalize transition-all ${
                          haloGlowColor === color
                            ? 'bg-amber-500 text-slate-950 shadow'
                            : 'text-slate-400 hover:text-amber-200'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Context Previews & Engine Action Trigger (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Preview Tabs */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>Real-time Live Preview</span>
                </span>
                <span className="text-[10px] text-emerald-400 font-mono flex items-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping mr-1" />
                  Live Sync
                </span>
              </div>

              {/* Preview Mode Selector */}
              <div className="flex rounded-2xl bg-slate-950 p-1 border border-amber-500/20 text-xs">
                {[
                  { id: 'navbar', label: 'Navbar Badge', icon: Laptop },
                  { id: 'appIcon', label: 'App Icon', icon: Smartphone },
                  { id: 'splash', label: 'Splash Screen', icon: Sparkles }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActivePreviewTab(item.id as any)}
                      className={`flex-1 py-1.5 rounded-xl font-bold flex items-center justify-center space-x-1 transition-all ${
                        activePreviewTab === item.id
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                          : 'text-slate-400 hover:text-amber-200'
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Active Preview Display Box */}
              <div className="bg-slate-950 border border-amber-500/30 rounded-3xl p-6 flex flex-col items-center justify-center min-h-[220px] relative overflow-hidden shadow-inner">
                <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 via-transparent to-purple-500/10 pointer-events-none" />

                {activePreviewTab === 'navbar' && (
                  <div className="w-full bg-slate-900/90 border border-amber-500/30 rounded-2xl p-3.5 flex items-center space-x-3 shadow-xl">
                    <div
                      className={`relative flex items-center justify-center w-11 h-11 p-0.5 shadow-lg ${
                        borderStyle === 'circle'
                          ? 'rounded-full'
                          : borderStyle === 'rounded'
                          ? 'rounded-xl'
                          : 'rounded-2xl'
                      } ${
                        haloGlowColor === 'gold'
                          ? 'bg-gradient-to-br from-amber-300 via-amber-500 to-amber-800 shadow-amber-500/30'
                          : haloGlowColor === 'purple'
                          ? 'bg-gradient-to-br from-purple-400 via-purple-600 to-indigo-900 shadow-purple-500/30'
                          : haloGlowColor === 'emerald'
                          ? 'bg-gradient-to-br from-emerald-400 via-emerald-600 to-teal-900 shadow-emerald-500/30'
                          : 'bg-gradient-to-br from-amber-400 via-amber-600 to-yellow-900 shadow-amber-500/30'
                      }`}
                    >
                      <div
                        className={`w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden ${
                          borderStyle === 'circle'
                            ? 'rounded-full'
                            : borderStyle === 'rounded'
                            ? 'rounded-[10px]'
                            : 'rounded-[14px]'
                        }`}
                      >
                        {selectedImagePreview ? (
                          <img
                            src={selectedImagePreview}
                            alt="Navbar Logo"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Sun className="w-6 h-6 text-amber-400 animate-spin-slow" />
                        )}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-100 bg-clip-text text-transparent font-serif">
                        JUHNKRIX MUSIKA
                      </h4>
                      <p className="text-[9px] tracking-widest text-amber-300/70 uppercase">
                        Prophetic Gospel & Soaking
                      </p>
                    </div>
                  </div>
                )}

                {activePreviewTab === 'appIcon' && (
                  <div className="flex flex-col items-center space-y-3">
                    <div
                      className={`w-24 h-24 p-1 shadow-2xl ${
                        borderStyle === 'circle'
                          ? 'rounded-full'
                          : borderStyle === 'rounded'
                          ? 'rounded-2xl'
                          : 'rounded-3xl'
                      } ${
                        haloGlowColor === 'gold'
                          ? 'bg-gradient-to-br from-amber-300 via-amber-500 to-amber-900 shadow-amber-500/40'
                          : haloGlowColor === 'purple'
                          ? 'bg-gradient-to-br from-purple-400 via-purple-600 to-indigo-900 shadow-purple-500/40'
                          : 'bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-800 shadow-amber-500/40'
                      }`}
                    >
                      <div
                        className={`w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden ${
                          borderStyle === 'circle'
                            ? 'rounded-full'
                            : borderStyle === 'rounded'
                            ? 'rounded-[14px]'
                            : 'rounded-[20px]'
                        }`}
                      >
                        {selectedImagePreview ? (
                          <img
                            src={selectedImagePreview}
                            alt="Mobile App Icon"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Sun className="w-12 h-12 text-amber-400 animate-spin-slow" />
                        )}
                      </div>
                    </div>
                    <span className="text-xs font-bold text-amber-200">JUHNKRIX MUSIKA App</span>
                    <span className="text-[10px] text-slate-400">Android & PWA Home Screen Icon</span>
                  </div>
                )}

                {activePreviewTab === 'splash' && (
                  <div className="w-full bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/20 rounded-2xl p-4 flex flex-col items-center text-center space-y-2">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-xl shadow-amber-500/30">
                      {selectedImagePreview ? (
                        <img
                          src={selectedImagePreview}
                          alt="Splash Emblem"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Sun className="w-8 h-8 text-amber-400 m-auto" />
                      )}
                    </div>
                    <h5 className="text-sm font-bold text-amber-100 font-serif">JUHNKRIX MUSIKA</h5>
                    <p className="text-[10px] text-slate-400">World's Powerful Spiritual Gospel Experience</p>
                  </div>
                )}
              </div>

              {/* Status Indicator */}
              <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Current App Logo:</span>
                <span className="font-bold text-amber-300 font-mono">
                  {currentGlobalLogo ? 'Custom Photo Active' : 'Sacred Golden Sun (Default)'}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-2 border-t border-slate-800">
              <button
                onClick={handleApplyLogoGlobally}
                disabled={isProcessing || !selectedImagePreview}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 text-sm font-black flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] border border-amber-200 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-5 h-5 text-slate-950" />
                <span>REPLACE APP LOGO GLOBALLY</span>
              </button>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-rose-300 hover:text-rose-200 text-xs font-bold border border-rose-500/30 flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset to Default Logo</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
