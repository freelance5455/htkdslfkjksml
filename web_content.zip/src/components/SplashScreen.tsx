import React, { useEffect, useState } from 'react';
import { ABLogo } from './ABLogo';
import { ArrowRight, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3200);

    const interval = setInterval(() => {
      setCountdown((prev) => (prev > 1 ? prev - 1 : 1));
    }, 1000);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [onComplete]);

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-6 bg-[#081225] text-white overflow-hidden select-none">
      {/* Background radial effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-[#E2C067]/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 rounded-full bg-[#1e3a8a]/20 blur-3xl pointer-events-none" />

      {/* Top subtle badge */}
      <div className="pt-8 flex items-center gap-2 text-xs tracking-widest text-[#E2C067]/80 uppercase font-semibold">
        <Sparkles className="w-3.5 h-3.5 text-[#E2C067] animate-pulse" />
        <span>Next-Gen Voice Intelligence</span>
      </div>

      {/* Center Logo & Title with Animations */}
      <div className="flex flex-col items-center justify-center -mt-6">
        <div className="animate-float">
          <ABLogo size={190} glow={true} />
        </div>

        <h1 className="mt-6 text-2xl sm:text-3xl font-extrabold tracking-[0.25em] text-[#E2C067] uppercase drop-shadow-[0_0_15px_rgba(226,192,103,0.5)]">
          AB Innovations
        </h1>

        <p className="mt-2 text-sm text-gray-300 tracking-wider font-medium">
          AB_Voice_Bot &bull; سمارٹ صوتی ساتھی
        </p>

        {/* Progress bar line */}
        <div className="w-48 h-1 bg-[#111e38] rounded-full overflow-hidden mt-8 border border-[#2a4365]/50">
          <div
            className="h-full bg-gradient-to-r from-[#b89230] via-[#E2C067] to-[#FFF2B2] transition-all duration-1000 ease-linear"
            style={{ width: `${((4 - countdown) / 3) * 100}%` }}
          />
        </div>
      </div>

      {/* Bottom Action */}
      <div className="pb-8 w-full max-w-xs flex flex-col items-center gap-3">
        <button
          onClick={onComplete}
          className="w-full py-3.5 px-6 rounded-xl font-bold text-sm tracking-wider uppercase text-[#081225] bg-gradient-to-r from-[#FFF2B2] via-[#E2C067] to-[#B89230] shadow-[0_4px_20px_rgba(226,192,103,0.35)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Continue</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <span className="text-[11px] text-gray-400">
          Starting in {countdown}s &bull; Auto-loading
        </span>
      </div>
    </div>
  );
};
