import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, GraduationCap, BookOpen, Brain, Zap, ArrowRight } from 'lucide-react';
import { Language } from '../types';

interface SplashScreenProps {
  language?: Language;
  onFinish: () => void;
}

export default function SplashScreen({ language = 'en', onFinish }: SplashScreenProps) {
  const [progress, setProgress] = useState<number>(0);
  const [stepIndex, setStepIndex] = useState<number>(0);
  const isBn = language === 'bn';

  const steps = isBn
    ? [
        { label: 'StudySkill AI ইনিশিয়ালাইজ হচ্ছে...', icon: Sparkles },
        { label: 'আপনার স্টাডি ম্যাটেরিয়াল ও নোট লোড হচ্ছে...', icon: BookOpen },
        { label: 'AI টিউটর প্রস্তুত! এখনই শুরু হচ্ছে...', icon: Brain }
      ]
    : [
        { label: 'Initializing StudySkill AI...', icon: Sparkles },
        { label: 'Loading study materials & notes...', icon: BookOpen },
        { label: 'AI Tutor is ready! Launching...', icon: Brain }
      ];

  useEffect(() => {
    const totalDuration = 3000; // 3 seconds
    const intervalTime = 30; // update every 30ms
    const totalTicks = totalDuration / intervalTime;
    let currentTick = 0;

    const timer = setInterval(() => {
      currentTick++;
      const currentProgress = Math.min(100, Math.round((currentTick / totalTicks) * 100));
      setProgress(currentProgress);

      if (currentProgress < 35) {
        setStepIndex(0);
      } else if (currentProgress < 75) {
        setStepIndex(1);
      } else {
        setStepIndex(2);
      }

      if (currentTick >= totalTicks) {
        clearInterval(timer);
        setTimeout(() => {
          onFinish();
        }, 150);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [onFinish]);

  const CurrentStepIcon = steps[stepIndex]?.icon || Sparkles;

  return (
    <AnimatePresence>
      <motion.div
        id="app-splash-screen"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 1.03 }}
        transition={{ duration: 0.4, ease: 'easeInOut' }}
        className="fixed inset-0 z-[99999] flex flex-col items-center justify-between bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 text-white select-none overflow-hidden p-6 sm:p-10"
      >
        {/* Ambient Glows */}
        <div className="absolute top-1/4 -left-20 w-72 h-72 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header info */}
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="w-full flex items-center justify-between max-w-md pt-2"
        >
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[11px] font-medium text-slate-300">
              {isBn ? 'AI এডুকেশন প্ল্যাটফর্ম' : 'AI Education Platform'}
            </span>
          </div>

          <button
            id="splash-skip-btn"
            onClick={onFinish}
            className="group flex items-center gap-1.5 text-[12px] font-medium text-slate-400 hover:text-white px-3 py-1 rounded-full hover:bg-white/10 transition-all cursor-pointer"
          >
            <span>{isBn ? 'সরাসরি প্রবেশ' : 'Skip'}</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </motion.div>

        {/* Central Brand Identity Section */}
        <div className="flex flex-col items-center text-center max-w-sm my-auto">
          {/* Logo Animation */}
          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.15 }}
            className="relative mb-6"
          >
            {/* Glowing ring */}
            <div className="absolute -inset-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 rounded-3xl blur-md opacity-60 animate-pulse" />
            
            {/* Icon Box */}
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 border border-white/20 shadow-2xl flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/20 via-transparent to-transparent pointer-events-none" />
              <motion.div
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
              >
                <GraduationCap className="w-12 h-12 sm:w-14 sm:h-14 text-white drop-shadow-md" />
              </motion.div>
              
              {/* Corner Sparkle */}
              <motion.div 
                animate={{ scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute top-2 right-2"
              >
                <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
              </motion.div>
            </div>
          </motion.div>

          {/* App Name with Stylish Typography */}
          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.25, duration: 0.5 }}
            className="text-3xl sm:text-4xl font-black tracking-tight flex items-center justify-center gap-1.5"
          >
            <span className="text-white font-extrabold tracking-tight drop-shadow-md">
              Study
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 font-black tracking-tight drop-shadow-md">
              Skill
            </span>
            <span className="ml-1.5 px-2.5 py-0.5 text-xs sm:text-sm font-black rounded-lg bg-gradient-to-r from-indigo-500 via-purple-600 to-cyan-400 text-white shadow-lg shadow-indigo-500/40 uppercase tracking-wider border border-white/20">
              AI
            </span>
          </motion.h1>

          {/* Tagline */}
          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.35, duration: 0.5 }}
            className="text-sm sm:text-base text-slate-300 mt-2 font-medium leading-relaxed"
          >
            {isBn ? 'বই দেখুন, গল্প শুনুন, সহজে শিখুন' : 'Scan Books, Listen Stories, Master Everything'}
          </motion.p>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.45 }}
            className="flex items-center gap-2 mt-4 text-[11px] text-slate-400"
          >
            <span className="flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60">
              <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
              {isBn ? 'WB + CBSE + Govt Exam' : 'WB + CBSE + Competitive'}
            </span>
            <span className="flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              {isBn ? 'বাংলা ও বহুভাষী' : 'Multi-Language'}
            </span>
          </motion.div>
        </div>

        {/* Bottom Loading Progress Section (3-Second Animation) */}
        <div className="w-full max-w-md pb-4 flex flex-col items-center">
          {/* Active Step Indicator */}
          <motion.div
            key={stepIndex}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
            className="flex items-center gap-2 text-xs text-slate-300 font-medium mb-3"
          >
            <CurrentStepIcon className="w-4 h-4 text-indigo-400 animate-spin-slow" />
            <span>{steps[stepIndex]?.label}</span>
          </motion.div>

          {/* Progress Bar Container */}
          <div className="w-full bg-slate-800/80 border border-slate-700/80 rounded-full h-2.5 p-0.5 relative overflow-hidden backdrop-blur-sm shadow-inner">
            <motion.div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 rounded-full"
              style={{ width: `${progress}%` }}
              transition={{ ease: 'linear' }}
            />
            {/* Shimmer light effect moving with the progress */}
            <div 
              className="absolute top-0 bottom-0 w-8 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-12"
              style={{ left: `${Math.max(0, progress - 10)}%` }}
            />
          </div>

          {/* Progress Stats & Countdown */}
          <div className="w-full flex items-center justify-between text-[11px] text-slate-400 mt-2 font-mono">
            <span>{Math.max(1, Math.ceil((3000 - (progress * 30)) / 1000))}s</span>
            <span className="font-semibold text-slate-300">{progress}%</span>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
