/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Headphones, Zap, Radio, Volume2 } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#06060b] text-white p-6 overflow-hidden">
      
      {/* Background Animated Neon Lasers */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-r from-cyan-600/30 via-purple-600/30 to-pink-600/30 blur-3xl animate-pulse-beat" />
        <div className="absolute top-0 left-1/4 w-0.5 h-full bg-cyan-400 shadow-[0_0_20px_#00f0ff] animate-laser" />
        <div className="absolute top-0 right-1/4 w-0.5 h-full bg-pink-500 shadow-[0_0_20px_#ff0055] animate-laser [animation-delay:1.5s]" />
      </div>

      {/* Main Branding Card */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-md w-full">
        
        {/* Animated DJ Headphone Crest */}
        <div className="relative mb-6">
          <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-cyan-500 via-purple-600 to-pink-500 p-1 shadow-[0_0_50px_rgba(0,240,255,0.7)] flex items-center justify-center animate-pulse">
            <div className="w-full h-full rounded-full bg-[#0a0b14] flex items-center justify-center">
              <Headphones className="w-14 h-14 text-cyan-400" />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-red-500 shadow-[0_0_15px_#ff0055] text-white">
            <Radio className="w-4 h-4 animate-ping" />
          </div>
        </div>

        {/* Title & Tagline */}
        <h1 className="text-4xl sm:text-5xl font-black font-dj tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-purple-300 to-pink-400 drop-shadow-[0_0_25px_rgba(0,240,255,0.8)] uppercase">
          DJ SUNNY
        </h1>
        <h2 className="text-lg sm:text-xl font-bold font-dj tracking-[0.35em] text-cyan-400 mt-1 uppercase">
          MUSIC ANIMATION
        </h2>

        <p className="text-xs text-zinc-400 max-w-xs mt-3 leading-relaxed">
          Professional Android DJ Studio with Live Audio Waveform, Scratch Turntable &amp; Neon Stage Visualizers
        </p>

        {/* Visualizer Soundbars Preview */}
        <div className="flex items-end gap-1.5 h-12 my-6">
          {[40, 75, 55, 95, 60, 100, 70, 85, 45, 90, 65, 80, 50, 92].map((height, i) => (
            <div
              key={i}
              className="w-1.5 rounded-full bg-gradient-to-t from-cyan-400 via-purple-500 to-pink-500 shadow-[0_0_8px_#00f0ff] animate-pulse"
              style={{
                height: `${height}%`,
                animationDelay: `${i * 0.08}s`,
                animationDuration: '0.8s',
              }}
            />
          ))}
        </div>

        {/* Ignition Button */}
        <button
          onClick={onStart}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 text-black font-black text-sm sm:text-base font-dj tracking-widest uppercase hover:brightness-110 active:scale-95 transition-all shadow-[0_0_35px_rgba(0,240,255,0.6)] flex items-center justify-center gap-3 cursor-pointer"
        >
          <Zap className="w-5 h-5 fill-black" />
          <span>IGNITE DJ SOUND ENGINE</span>
        </button>

        <div className="flex items-center gap-2 mt-4 text-[10px] text-zinc-500 font-mono tracking-wider">
          <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
          <span>PRO-SERIES AUDIO • 60 FPS VISUALIZER ENGINE</span>
        </div>

      </div>

    </div>
  );
};
