import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';

interface SplashScreenProps {
  onDismiss?: () => void;
  minDurationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onDismiss,
  minDurationMs = 1200
}) => {
  const { theme } = useTheme();
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFading(true);
      const dismissTimer = setTimeout(() => {
        if (onDismiss) onDismiss();
      }, 400);
      return () => clearTimeout(dismissTimer);
    }, minDurationMs);

    return () => clearTimeout(timer);
  }, [onDismiss, minDurationMs]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center p-6 transition-opacity duration-400 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      } ${
        theme === 'light'
          ? 'bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900'
          : 'bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white'
      }`}
      role="dialog"
      aria-label="Welcome to India Job Hub"
    >
      {/* Decorative India Tricolor Top Accent */}
      <div className="absolute top-0 left-0 right-0 h-1.5 flex">
        <div className="h-full flex-1 bg-amber-500" />
        <div className="h-full flex-1 bg-white" />
        <div className="h-full flex-1 bg-emerald-500" />
      </div>

      <div className="flex flex-col items-center text-center max-w-sm w-full space-y-6 animate-in fade-in zoom-in-95 duration-500">
        {/* Complete High-Resolution Brand Logo without Text Cropping */}
        <div
          className={`relative p-3 sm:p-4 rounded-3xl shadow-2xl transition-transform ${
            theme === 'light'
              ? 'bg-white border border-slate-200/90 shadow-slate-200/80 ring-4 ring-slate-100'
              : 'bg-slate-900 border border-slate-700/80 shadow-slate-950 ring-4 ring-slate-800/60'
          }`}
        >
          <img
            src="/india-job-hub-logo.png"
            alt="India Job Hub Official Logo"
            className="w-48 h-48 sm:w-56 sm:h-56 md:w-64 md:h-64 object-contain rounded-2xl drop-shadow-sm select-none"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Brand Tagline and Status */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold tracking-wider uppercase bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <span>🇮🇳 Verified Citizen Employment Platform</span>
          </div>
          <p className={`text-xs ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
            Central & State Commission Vacancies Across India
          </p>
        </div>

        {/* Loading Spinner & Status */}
        <div className="flex items-center gap-2.5 pt-2">
          <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <span className={`text-xs font-medium ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
            Synchronizing recruitment gazettes...
          </span>
        </div>
      </div>

      {/* Footer Branding Note */}
      <div className="absolute bottom-6 text-center text-[11px] text-slate-500">
        India Job Hub • Official Career Aggregator
      </div>
    </div>
  );
};
