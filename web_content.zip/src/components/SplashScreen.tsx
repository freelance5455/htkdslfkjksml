import React from 'react';
import { AppLogo } from './AppLogo';
import { ArrowLeft, BookOpen } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-gradient-to-b from-[#021811] via-[#032219] to-[#01100b] text-[#e8f5ee] p-6 select-none">
      {/* Top clean spacing without geometric ornament */}
      <div className="pt-6 flex justify-center opacity-40">
        <span className="text-xs font-tajawal text-emerald-300/80 tracking-widest">
          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
        </span>
      </div>

      {/* Center Main Identity */}
      <div className="flex flex-col items-center justify-center text-center my-auto space-y-6">
        {/* Brand New Islamic Logo: Muslim man and woman supplicating to Allah */}
        <AppLogo size={102} withGlow={true} className="drop-shadow-2xl" />

        <div className="space-y-2">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-wide text-amber-400 drop-shadow-[0_2px_12px_rgba(251,191,36,0.45)] font-cairo">
            حصن المسلم
          </h1>
          <p className="text-lg md:text-xl font-bold text-emerald-200 font-tajawal tracking-wider">
            أذكار المسلم اليومية
          </p>
        </div>

        <div className="w-16 h-0.5 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent"></div>

        <button
          onClick={onStart}
          className="mt-4 px-8 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-[#021811] font-bold rounded-2xl shadow-xl shadow-emerald-950/40 flex items-center gap-3 transition-transform active:scale-95 text-base cursor-pointer font-cairo"
        >
          <BookOpen className="w-5 h-5 text-[#021811]" />
          <span>ابدأ الأذكار</span>
          <ArrowLeft className="w-4 h-4 text-[#021811] rotate-180" />
        </button>
      </div>

      {/* Bottom Dedication */}
      <div className="pb-6 text-center space-y-2">
        <div className="inline-block px-5 py-3 rounded-2xl bg-[#021811]/60 border border-emerald-700/40 backdrop-blur-md max-w-sm mx-auto shadow-lg">
          <p className="text-xs md:text-sm text-emerald-200/90 leading-relaxed font-tajawal">
            عملٌ نرجو أن يكون صدقةً جاريةً عن الحاجة هدي
          </p>
        </div>
      </div>
    </div>
  );
};
