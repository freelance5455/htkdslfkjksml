import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { Logo } from './Logo';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    const timer = window.setTimeout(() => {
      onComplete();
    }, 2000);
    return () => window.clearTimeout(timer);
  }, [onComplete]);

  return (
    <div
      onClick={onComplete}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') onComplete();
      }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#060C1D] px-6 text-center cursor-pointer overflow-hidden"
    >
      {/* Atmospheric radial blue neon backdrop behind the official EduToon logo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute h-[420px] w-[420px] rounded-full opacity-60 blur-3xl"
        style={{
          background:
            'radial-gradient(circle, rgba(56,189,248,0.42) 0%, rgba(37,99,235,0.22) 48%, rgba(6,12,29,0) 75%)',
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.82 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
        className="relative flex flex-col items-center"
      >
        <Logo size="xl" glow />

        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 text-3xl sm:text-4xl font-bold tracking-tight text-white"
        >
          EduToon Education
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="mt-2 text-xs sm:text-sm font-semibold tracking-[0.22em] text-sky-300"
        >
          ANIMATION SE AASAAN PADHAI
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.65, duration: 0.4 }}
          className="mt-8 w-36 h-1 rounded-full bg-slate-800 overflow-hidden"
        >
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '0%' }}
            transition={{ duration: 1.35, ease: 'easeInOut' }}
            className="h-full w-full bg-gradient-to-r from-sky-400 to-blue-500"
          />
        </motion.div>
      </motion.div>
    </div>
  );
};
