/**
 * SPR - Sahil Powerful Run
 * 7-Day Daily Reward System Modal
 * With Strict Offline 24-Hour Cooldown Timer
 */

import React, { useState } from 'react';
import { X, Gift, Check, Sparkles, Home, Lock } from 'lucide-react';
import { saveManager, DAILY_REWARDS_TABLE } from '../game/storage/SaveManager';
import { soundManager } from '../game/audio/SoundManager';
import { useRewardCooldown } from '../hooks/useRewardCooldown';

interface Props {
  onClose: () => void;
  onCoinsChange: (newBalance: number) => void;
}

export const DailyRewardModal: React.FC<Props> = ({ onClose, onCoinsChange }) => {
  const saveData = saveManager.getSaveData();
  const dailyState = saveData.dailyReward;
  const { isAvailable, countdown, claim } = useRewardCooldown('daily_reward', 'REWARD');
  const [rewardClaimedAmount, setRewardClaimedAmount] = useState<number | null>(null);

  const currentDay = dailyState.currentDay || 1;
  const rewardItem = DAILY_REWARDS_TABLE[currentDay - 1] || DAILY_REWARDS_TABLE[0];

  const handleClaim = () => {
    if (!isAvailable) return;

    soundManager.playPowerupSound();
    const coinsReward = rewardItem.coins;
    saveManager.addCoins(coinsReward);

    // Record cooldown timestamp
    claim();

    // Advance 7-day streak
    const nextDay = currentDay >= 7 ? 1 : currentDay + 1;
    saveData.dailyReward.currentDay = nextDay;
    saveData.dailyReward.lastClaimDate = new Date().toISOString().split('T')[0];
    saveData.dailyReward.claimedToday = true;
    saveManager.save();

    setRewardClaimedAmount(coinsReward);
    onCoinsChange(saveManager.getCoins());
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border-2 border-emerald-500/50 rounded-3xl shadow-[0_0_50px_rgba(16,185,129,0.3)] p-5 sm:p-6 flex flex-col gap-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg text-slate-950 font-black">
              <Gift className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-wider text-white uppercase font-display">
                7-DAY DAILY REWARDS
              </h2>
              <p className="text-xs text-slate-400">Claim once every 24 hours • Offline persistent</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="daily-reward-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-4 h-4" />
              <span>HOME</span>
            </button>

            <button
              id="daily-reward-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Claim Banner message if just claimed */}
        {rewardClaimedAmount && (
          <div className="bg-emerald-950/90 border border-emerald-400 p-3 rounded-xl text-center animate-bounce">
            <span className="text-emerald-300 font-extrabold text-sm sm:text-base">
              🎉 Congratulations! You claimed +{rewardClaimedAmount.toLocaleString()} Coins!
            </span>
          </div>
        )}

        {/* 7 Days Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 my-2">
          {DAILY_REWARDS_TABLE.map((item) => {
            const isPast = item.day < currentDay;
            const isCurrent = item.day === currentDay;
            const isJackpot = item.day === 7;

            return (
              <div
                key={item.day}
                id={`daily-day-card-${item.day}`}
                className={`relative p-2.5 rounded-xl border flex flex-col items-center justify-between text-center transition ${
                  isJackpot ? 'col-span-2 sm:col-span-1' : ''
                } ${
                  isCurrent
                    ? 'bg-gradient-to-b from-emerald-500/20 to-teal-600/30 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.5)] ring-2 ring-emerald-400 scale-105'
                    : isPast
                    ? 'bg-slate-900/40 border-emerald-500/50 opacity-80'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <span className="text-[10px] font-bold text-slate-400 uppercase">
                  Day {item.day}
                </span>

                <div className="my-2">
                  {isPast ? (
                    <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-500 flex items-center justify-center text-emerald-400">
                      <Check className="w-5 h-5" />
                    </div>
                  ) : isJackpot ? (
                    <div className="w-8 h-8 rounded-full bg-amber-500/30 border border-amber-400 flex items-center justify-center text-amber-300 text-lg animate-pulse">
                      👑
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-base">
                      🪙
                    </div>
                  )}
                </div>

                <span
                  className={`text-[11px] font-extrabold font-display ${
                    isJackpot ? 'text-amber-300' : isCurrent ? 'text-emerald-300' : 'text-slate-300'
                  }`}
                >
                  +{item.coins.toLocaleString()}
                </span>
              </div>
            );
          })}
        </div>

        {/* 24-Hour Cooldown Action Button */}
        <div className="mt-2">
          {!isAvailable ? (
            <div className="w-full flex flex-col items-center gap-1.5">
              <button
                disabled
                className="w-full py-3.5 bg-slate-800/90 border-2 border-slate-700 text-slate-300 font-mono font-black text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2 cursor-not-allowed opacity-90 shadow-inner"
              >
                <Lock className="w-5 h-5 text-amber-400" />
                <span className="tracking-wider">NEXT REWARD IN {countdown}</span>
              </button>
              <p className="text-[11px] text-slate-400 text-center font-medium">
                ⏳ 24-Hour Cooldown active • Continues counting down offline
              </p>
            </div>
          ) : (
            <button
              id="daily-reward-btn-claim"
              onClick={handleClaim}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 hover:from-emerald-400 hover:to-teal-300 active:scale-98 text-slate-950 font-black text-base uppercase tracking-widest rounded-2xl transition shadow-[0_0_25px_rgba(16,185,129,0.5)] flex items-center justify-center gap-2 cursor-pointer font-display"
            >
              <Sparkles className="w-5 h-5 fill-current" />
              CLAIM TODAY'S REWARD (+{rewardItem.coins.toLocaleString()} COINS)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
