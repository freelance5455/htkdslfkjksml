import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Coins, Lightbulb, Sparkles, Check, X } from 'lucide-react';

interface DailyRewardModalProps {
  currentStreak: number;
  canClaimToday: boolean;
  onClaim: (day: number) => void;
  onClose: () => void;
}

interface RewardItem {
  day: number;
  label: string;
  type: 'coins' | 'hint' | 'skin';
  amount?: number;
}

const REWARDS: RewardItem[] = [
  { day: 1, label: '+50 Coins', type: 'coins', amount: 50 },
  { day: 2, label: '+100 Coins', type: 'coins', amount: 100 },
  { day: 3, label: '+2 Hints', type: 'hint', amount: 2 },
  { day: 4, label: '+150 Coins', type: 'coins', amount: 150 },
  { day: 5, label: 'Neon Skin', type: 'skin' },
  { day: 6, label: '+250 Coins', type: 'coins', amount: 250 },
  { day: 7, label: '+500 Coins', type: 'coins', amount: 500 },
];

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  currentStreak,
  canClaimToday,
  onClaim,
  onClose,
}) => {
  const nextClaimDay = (currentStreak % 7) + 1;

  const renderRewardIcon = (type: string) => {
    switch (type) {
      case 'coins':
        return <Coins className="w-5 h-5 text-amber-500 fill-amber-400" />;
      case 'hint':
        return <Lightbulb className="w-5 h-5 text-amber-400" />;
      case 'skin':
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      default:
        return <Coins className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-100 dark:border-slate-700 p-6 flex flex-col items-center relative overflow-hidden"
      >
        <button
          id="btn-daily-close"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 flex items-center justify-center active:scale-95"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 flex items-center justify-center text-amber-500 mb-2">
          <Calendar className="w-7 h-7" />
        </div>

        <h3 className="text-xl font-black text-slate-800 dark:text-white">
          DAILY LOGIN REWARDS
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 mb-4">
          Check in every day to unlock bonus coins and rare cosmetics!
        </p>

        {/* 7 Day Grid */}
        <div className="w-full grid grid-cols-4 gap-2 mb-4">
          {REWARDS.slice(0, 4).map((r) => {
            const isClaimed = currentStreak >= r.day;
            const isReady = canClaimToday && nextClaimDay === r.day;
            return (
              <div
                key={r.day}
                className={`p-2 rounded-2xl flex flex-col items-center justify-center text-center border transition relative ${
                  isClaimed
                    ? 'bg-slate-100 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
                    : isReady
                    ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-400 shadow-md ring-2 ring-amber-400'
                    : 'bg-slate-50 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800'
                }`}
              >
                <span className="text-[10px] font-bold text-slate-400 mb-1">
                  DAY {r.day}
                </span>
                {renderRewardIcon(r.type)}
                <span className="text-[10px] font-extrabold text-slate-700 dark:text-slate-200 mt-1">
                  {r.label}
                </span>
                {isClaimed && (
                  <div className="absolute inset-0 rounded-2xl bg-slate-900/40 flex items-center justify-center">
                    <Check className="w-5 h-5 text-emerald-400 font-bold" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="w-full grid grid-cols-3 gap-2 mb-6">
          {REWARDS.slice(4).map((r) => {
            const isClaimed = currentStreak >= r.day;
            const isReady = canClaimToday && nextClaimDay === r.day;
            const isGrand = r.day === 7;
            return (
              <div
                key={r.day}
                className={`p-2.5 rounded-2xl flex flex-col items-center justify-center text-center border transition relative ${
                  isGrand ? 'bg-gradient-to-br from-amber-50 to-orange-100 dark:from-amber-950/40 dark:to-orange-950/40 border-amber-400' : ''
                } ${
                  isClaimed
                    ? 'bg-slate-100 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
                    : isReady
                    ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-400 shadow-md ring-2 ring-amber-400 animate-pulse'
                    : 'bg-slate-50 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800'
                }`}
              >
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 mb-1">
                  {isGrand ? 'GRAND DAY 7' : `DAY ${r.day}`}
                </span>
                {renderRewardIcon(r.type)}
                <span className="text-[10px] font-extrabold text-slate-700 dark:text-slate-200 mt-1">
                  {r.label}
                </span>
                {isClaimed && (
                  <div className="absolute inset-0 rounded-2xl bg-slate-900/40 flex items-center justify-center">
                    <Check className="w-5 h-5 text-emerald-400 font-bold" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Claim button */}
        <button
          id="btn-daily-claim"
          type="button"
          disabled={!canClaimToday}
          onClick={() => onClaim(nextClaimDay)}
          className={`w-full h-12 rounded-2xl font-bold flex items-center justify-center gap-2 transition active:scale-98 ${
            canClaimToday
              ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-lg shadow-amber-500/25'
              : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span>{canClaimToday ? `CLAIM DAY ${nextClaimDay} REWARD` : 'ALREADY CLAIMED TODAY'}</span>
        </button>
      </motion.div>
    </div>
  );
};
