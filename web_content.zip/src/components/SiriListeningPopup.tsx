import React from 'react';
import { Mic, MicOff, Square, Sparkles, Volume2, ShieldAlert } from 'lucide-react';
import { AssistantState } from '../types';

interface SiriListeningPopupProps {
  state: AssistantState;
  transcript: string;
  responseStatus: string;
  onStopListening: () => void;
  onManualTrigger: () => void;
  onStopSpeaking: () => void;
  onFinalizeSlowSpeech?: () => void;
  isPausedSpeaking?: boolean;
}

export const SiriListeningPopup: React.FC<SiriListeningPopupProps> = ({
  state,
  transcript,
  responseStatus,
  onStopListening,
  onManualTrigger,
  onStopSpeaking,
  onFinalizeSlowSpeech,
  isPausedSpeaking = false,
}) => {
  if (state === 'idle') return null;

  const isListening = state === 'listening';
  const isProcessing = state === 'processing';
  const isSpeaking = state === 'speaking';
  const isAlarm = state === 'alarm';

  return (
    <div className="fixed bottom-24 inset-x-4 max-w-md mx-auto z-50 pointer-events-auto transition-all duration-300">
      {/* Siri / JARVIS Glass Capsule */}
      <div className="relative overflow-hidden rounded-2xl bg-gray-950/85 backdrop-blur-xl border border-cyan-500/40 p-4 shadow-2xl glow-cyan">
        {/* Holographic animated side borders */}
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" />
        <div className="absolute -left-[1px] top-3 bottom-3 w-[2px] bg-cyan-400/80 animate-side-light" />
        <div className="absolute -right-[1px] top-3 bottom-3 w-[2px] bg-cyan-400/80 animate-side-light" />

        <div className="flex items-center gap-3">
          {/* Animated Core Icon */}
          <div className="relative flex-shrink-0">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all duration-300 ${
              isAlarm 
                ? 'border-red-500 bg-red-950/40 text-red-400 animate-bounce'
                : isListening
                ? 'border-cyan-400 bg-cyan-950/60 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.6)]'
                : isProcessing
                ? 'border-amber-400 bg-amber-950/40 text-amber-300 animate-spin'
                : 'border-emerald-400 bg-emerald-950/40 text-emerald-300'
            }`}>
              {isAlarm ? (
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              ) : isListening ? (
                <Mic className="w-6 h-6 animate-pulse" />
              ) : isProcessing ? (
                <Sparkles className="w-5 h-5" />
              ) : (
                <Volume2 className="w-6 h-6" />
              )}
            </div>

            {/* Siri-like frequency soundwave bars */}
            {isListening && (
              <div className="absolute -bottom-1 -right-1 flex items-center gap-[2px] bg-cyan-950/90 px-1 py-[2px] rounded-full border border-cyan-500/50">
                <span className="w-1 h-2 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1 h-3 bg-cyan-300 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1 h-2 bg-cyan-400 rounded-full animate-bounce" />
              </div>
            )}
          </div>

          {/* Transcript & Status text */}
          <div className="flex-1 min-w-0 pr-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-tech tracking-wider uppercase text-cyan-400/80 font-semibold">
                {isAlarm ? 'CRITICAL ALERT // ALARM' : isListening ? 'JARVIS LISTENING' : isProcessing ? 'AI BRAIN COMPUTING' : 'JARVIS VOCAL CORE'}
              </span>
              <span className="text-[10px] font-mono-tech text-cyan-300/60">
                {responseStatus || (isListening ? 'Say "Jarvis" command...' : 'Ready')}
              </span>
            </div>

            <p className="text-sm font-medium text-cyan-100 truncate mt-0.5">
              {transcript || (isListening ? 'Speak your query, Sir (slow speech supported)...' : responseStatus)}
            </p>
            {isListening && transcript && isPausedSpeaking && (
              <div className="flex items-center gap-1.5 mt-1 text-[10px] text-amber-300 font-mono-tech animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>Pause detected • Still listening (take your time)...</span>
              </div>
            )}
          </div>

          {/* Action button */}
          <div className="flex-shrink-0 flex items-center gap-1.5">
            {isListening && transcript && (
              <button
                onClick={onFinalizeSlowSpeech}
                title="Send Command Now (Skip remaining pause)"
                className="px-2.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-tech font-bold text-xs uppercase transition-colors"
              >
                Send
              </button>
            )}
            {isListening ? (
              <button
                onClick={onStopListening}
                title="Stop listening"
                className="p-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 active:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 transition-colors"
              >
                <MicOff className="w-4 h-4" />
              </button>
            ) : isSpeaking ? (
              <button
                onClick={onStopSpeaking}
                title="Stop speech"
                className="p-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/40 text-red-300 transition-colors"
              >
                <Square className="w-4 h-4 fill-current" />
              </button>
            ) : (
              <button
                onClick={onManualTrigger}
                title="Voice input"
                className="p-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-300 transition-colors"
              >
                <Mic className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
