import React from 'react';

export const EDUTOON_LOGO_SRC =
  '/assets/aistudio/EduToon_Education__Learn_with_Joy-removebg-preview_fc41e68e.png';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<LogoProps['size']>, string> = {
  xs: 'h-9 w-9',
  sm: 'h-11 w-11',
  md: 'h-14 w-14',
  lg: 'h-24 w-24',
  xl: 'h-44 w-44 sm:h-52 sm:w-52',
};

export const Logo: React.FC<LogoProps> = ({
  size = 'sm',
  glow = false,
  className = '',
}) => {
  return (
    <img
      src={EDUTOON_LOGO_SRC}
      alt="EduToon Education"
      referrerPolicy="no-referrer"
      draggable={false}
      className={`${SIZE_CLASSES[size]} object-contain select-none shrink-0 ${
        glow ? 'neon-blue-logo-glow' : ''
      } ${className}`}
    />
  );
};
