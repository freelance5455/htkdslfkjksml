interface LogoProps {
  variant?: "full" | "mark" | "wordmark";
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  monochrome?: boolean;
}

const sizeMap = {
  sm: { icon: "h-7 w-7", text: "text-lg", gap: "gap-2" },
  md: { icon: "h-9 w-9", text: "text-2xl", gap: "gap-2.5" },
  lg: { icon: "h-14 w-14", text: "text-4xl", gap: "gap-3" },
  xl: { icon: "h-20 w-20", text: "text-6xl", gap: "gap-4" },
};

export function LogoMark({ size = "md", className = "" }: { size?: LogoProps["size"]; className?: string }) {
  const s = sizeMap[size ?? "md"];
  return (
    <div
      className={`${s.icon} ${className} relative shrink-0 rounded-[28%] bg-ink dark:bg-offwhite flex items-center justify-center overflow-hidden`}
    >
      <svg viewBox="0 0 100 100" className="h-[62%] w-[62%]" fill="none">
        <path
          d="M20 72 L50 34 L50 28"
          stroke="currentColor"
          strokeWidth="9"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-offwhite dark:text-ink"
        />
        <path
          d="M34 40 a10 10 0 1 1 0.1 0"
          stroke="currentColor"
          strokeWidth="9"
          strokeLinecap="round"
          className="text-offwhite dark:text-ink"
        />
        <rect x="52" y="22" width="30" height="9" rx="4.5" className="fill-saffron" />
        <rect x="62" y="22" width="9" height="56" rx="4.5" className="fill-saffron" />
      </svg>
    </div>
  );
}

export function LogoWordmark({ size = "md", className = "" }: { size?: LogoProps["size"]; className?: string }) {
  const s = sizeMap[size ?? "md"];
  return (
    <div className={`flex items-baseline ${className}`}>
      <span className={`font-dev font-bold ${s.text} leading-none`}>श्</span>
      <span className={`font-display font-extrabold ${s.text} leading-none`}>
        <span>R</span>
        <span className="font-semibold lowercase">am</span>
      </span>
    </div>
  );
}

export default function Logo({ variant = "full", size = "md", className = "" }: LogoProps) {
  const s = sizeMap[size ?? "md"];
  if (variant === "mark") return <LogoMark size={size} className={className} />;
  if (variant === "wordmark") return <LogoWordmark size={size} className={className} />;
  return (
    <div className={`flex items-center ${s.gap} ${className}`}>
      <LogoMark size={size} />
      <LogoWordmark size={size} />
    </div>
  );
}
