import React, { useState, useEffect } from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showName?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showName = true }) => {
  const [imgError, setImgError] = useState(false);
  const [isDark, setIsDark] = useState(() => {
    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      return root.classList.contains('dark') || !root.classList.contains('light');
    }
    return true;
  });

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const checkDark = () => {
      setIsDark(root.classList.contains('dark') || !root.classList.contains('light'));
    };
    checkDark();

    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === 'attributes' && m.attributeName === 'class') {
          checkDark();
        }
      }
    });
    observer.observe(root, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const sizeClass = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-11 h-11' : 'w-9 h-9';
  const textClass = size === 'sm' ? 'text-base font-bold' : size === 'lg' ? 'text-2xl font-black' : 'text-lg font-extrabold';
  const logoSrc = isDark ? '/logo-dark.png' : '/logo-light.png';

  return (
    <div className={`flex items-center space-x-2 shrink-0 select-none ${className}`}>
      <div className={`relative flex items-center justify-center ${sizeClass}`}>
        {!imgError ? (
          <img
            src={logoSrc}
            alt="NOXORA Logo"
            className="w-full h-full object-contain"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full rounded-lg bg-gradient-to-tr from-[#00b8db] to-[#359efe] flex items-center justify-center font-black text-white text-xs shadow-md">
            N
          </div>
        )}
      </div>

      {showName && (
        <span
          className={`tracking-wider uppercase font-mono ${textClass} ${
            isDark ? 'text-white' : 'text-slate-900'
          }`}
        >
          NOXORA
        </span>
      )}
    </div>
  );
};
