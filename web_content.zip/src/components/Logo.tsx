import { cn } from '@/utils/cn';

export default function Logo({ size = 'lg', className }: { size?: 'lg' | 'sm'; className?: string }) {
  const big = size === 'lg';
  return (
    <div className={cn('flex flex-col items-center text-center', className)}>
      <div className={cn('flex items-center gap-3', big ? 'mb-1' : 'mb-0')}>
        <span className={cn('hidden text-gold drop-shadow-[0_2px_0_#5a3a08] sm:inline-block', big ? 'text-3xl' : 'text-xl')} aria-hidden>
          ✦
        </span>
        <h1
          className={cn(
            'logo-text whitespace-nowrap font-display font-black tracking-[0.1em] leading-none',
            big ? 'text-[clamp(2.1rem,9.2vw,5.5rem)]' : 'text-2xl sm:text-3xl',
          )}
        >
          WORD RUSH
        </h1>
        <span className={cn('hidden text-gold drop-shadow-[0_2px_0_#5a3a08] sm:inline-block', big ? 'text-3xl' : 'text-xl')} aria-hidden>
          ✦
        </span>
      </div>
      {big && (
        <p className="font-body text-xs font-black uppercase tracking-[0.35em] text-gold-light/90 sm:text-sm">
          Bible Trivia Runner
        </p>
      )}
    </div>
  );
}
