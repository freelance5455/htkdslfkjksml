import React from 'react';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
  variant?: 'default' | 'monochrome' | 'glow';
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  showTagline = false,
  className = '',
}) => {
  const sizeMap = {
    xs: { icon: 24, text: 'text-base', tag: 'text-[9px]' },
    sm: { icon: 32, text: 'text-lg', tag: 'text-[10px]' },
    md: { icon: 40, text: 'text-xl', tag: 'text-xs' },
    lg: { icon: 52, text: 'text-2xl', tag: 'text-xs' },
    xl: { icon: 72, text: 'text-4xl', tag: 'text-sm' },
  };

  const dim = sizeMap[size] || sizeMap.md;

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Visual Logo Icon */}
      <div
        className="relative shrink-0 flex items-center justify-center rounded-2xl p-0.5 shadow-md shadow-indigo-500/20 group transition-transform duration-300 hover:scale-105"
        style={{ width: dim.icon, height: dim.icon }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id={`grad-bg-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0f172a" />
              <stop offset="100%" stop-color="#020617" />
            </linearGradient>
            <linearGradient id={`grad-petal1-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#38bdf8" />
              <stop offset="100%" stop-color="#2563eb" />
            </linearGradient>
            <linearGradient id={`grad-petal2-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#818cf8" />
              <stop offset="100%" stop-color="#6366f1" />
            </linearGradient>
            <linearGradient id={`grad-petal3-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#c084fc" />
              <stop offset="100%" stop-color="#ec4899" />
            </linearGradient>
            <linearGradient id={`grad-petal4-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#f43f5e" />
              <stop offset="100%" stop-color="#f97316" />
            </linearGradient>
            <filter id={`glow-${size}`} x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Squircle pocket container */}
          <rect width="100" height="100" rx="26" fill={`url(#grad-bg-${size})`} />
          <rect
            width="98"
            height="98"
            x="1"
            y="1"
            rx="25"
            fill="none"
            stroke="rgba(255,255,255,0.15)"
            strokeWidth="1.5"
          />

          {/* Glowing Neural vortex / chat petal icon */}
          <g transform="translate(50, 50)" filter={`url(#glow-${size})`}>
            {/* North-West cyan/blue */}
            <path
              d="M 0,-4 C -16,-26 -28,-16 -32,-3 C -35,8 -24,19 -12,17 C -14,7 -10,-1 0,-4 Z"
              fill={`url(#grad-petal1-${size})`}
            />
            {/* North-East violet */}
            <path
              d="M 4,0 C 26,-16 16,-28 3,-32 C -8,-35 -19,-24 -17,-12 C -7,-14 1,-10 4,0 Z"
              fill={`url(#grad-petal2-${size})`}
            />
            {/* South-East magenta */}
            <path
              d="M 0,4 C 16,26 28,16 32,3 C 35,-8 24,-19 12,-17 C 14,-7 10,1 0,4 Z"
              fill={`url(#grad-petal3-${size})`}
            />
            {/* South-West amber */}
            <path
              d="M -4,0 C -26,16 -16,28 -3,32 C 8,35 19,24 17,12 C 7,14 -1,10 -4,0 Z"
              fill={`url(#grad-petal4-${size})`}
            />
            {/* Intelligent glowing core */}
            <circle cx="0" cy="0" r="5" fill="#ffffff" />
            <circle cx="0" cy="0" r="8.5" fill="none" stroke="#60a5fa" strokeWidth="1.2" opacity="0.85" />
          </g>
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col leading-tight">
          <span
            className={`font-bold tracking-tight text-slate-900 dark:text-white ${dim.text} flex items-center gap-1.5`}
          >
            <span>AI Pocket Chat</span>
          </span>
          {showTagline && (
            <span className={`text-slate-500 dark:text-slate-400 font-medium ${dim.tag}`}>
              Your Smart AI Assistant, Anywhere.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
