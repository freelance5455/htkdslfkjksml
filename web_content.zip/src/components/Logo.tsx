export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#inicio" className="group flex items-center gap-2.5" aria-label="TV LO3 — inicio">
      <svg
        width={compact ? 34 : 44}
        height={compact ? 34 : 44}
        viewBox="0 0 64 64"
        fill="none"
        aria-hidden="true"
        className="shrink-0 drop-shadow-[0_0_18px_rgba(56,189,248,0.45)] transition-transform duration-300 group-hover:scale-105"
      >
        <defs>
          <linearGradient id="lo3-g" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22d3ee" />
            <stop offset="0.45" stopColor="#2f7bff" />
            <stop offset="1" stopColor="#a855f7" />
          </linearGradient>
        </defs>
        <path
          d="M32 5 55 18.5v27L32 59 9 45.5v-27L32 5Z"
          stroke="url(#lo3-g)"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <path
          d="M27.5 24.6v14.8c0 1.9 2.1 3.1 3.8 2.1l12.2-7.4a2.5 2.5 0 0 0 0-4.2l-12.2-7.4c-1.7-1-3.8.2-3.8 2.1Z"
          fill="url(#lo3-g)"
        />
      </svg>
      <span className="leading-none">
        <span className="block font-display text-[1.35rem] font-bold tracking-tight text-white sm:text-2xl">
          TV <span className="text-cyanx">LO3</span>
        </span>
        {!compact && (
          <span className="mt-1 hidden text-[10px] font-medium uppercase tracking-[0.28em] text-slate-400 sm:block">
            Tu mundo en un solo lugar
          </span>
        )}
      </span>
    </a>
  );
}
