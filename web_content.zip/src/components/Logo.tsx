import React from 'react';

export const SULogo: React.FC<{ size?: 'sm' | 'md' }> = ({ size = 'sm' }) => {
  const dims = size === 'sm' ? 'w-9 h-9 text-sm' : 'w-11 h-11 text-base';
  return (
    <div
      className={`${dims} rounded-lg flex items-center justify-center font-display font-extrabold tracking-tight text-white shrink-0 select-none border border-emerald-400/40 shadow-sm`}
      style={{
        background: 'linear-gradient(135deg, #0B1F3A 0%, #163661 60%, #059669 140%)',
      }}
      aria-hidden="true"
    >
      <span>SU</span>
    </div>
  );
};
