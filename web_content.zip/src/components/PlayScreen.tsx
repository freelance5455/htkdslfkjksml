import { memo, useCallback, useEffect, useRef, useState } from "react";
import type { Game, Customer } from "../game/engine";
import { INGREDIENTS, ING_MAP, bn, taka, type Dish, type IngId, type Location, type Festival } from "../game/data";
import { sfx } from "../game/audio";
import { CartView, LightsView, PersonView, SilhouetteView, TrafficView, type Mood } from "./Sprites";

/* stable ref callbacks so React never detaches/reattaches on the 10Hz render */
const refCache = new Map<string, (el: HTMLElement | null) => void>();
function reg(g: Game, key: string) {
  let fn = refCache.get(key);
  if (!fn) {
    fn = (el: HTMLElement | null) => {
      g.register(key, el);
    };
    refCache.set(key, fn);
  }
  return fn;
}

/* ------------------------------- HUD ------------------------------- */

function Chip({
  children,
  tone = "dark",
  className = "",
}: {
  children: React.ReactNode;
  tone?: "dark" | "gold" | "red" | "teal" | "pink";
  className?: string;
}) {
  const tones: Record<string, string> = {
    dark: "bg-ink/70 border-cream/20 text-cream",
    gold: "bg-marigold border-ink/50 text-ink",
    red: "bg-chili border-ink/50 text-cream",
    teal: "bg-turq border-ink/50 text-ink",
    pink: "bg-rickshaw border-ink/50 text-cream",
  };
  return (
    <div className={`flex items-center gap-1 rounded-lg border-2 px-1.5 py-[2px] leading-none ${tones[tone]} ${className}`}>
      {children}
    </div>
  );
}

function Hud({ g }: { g: Game }) {
  const s = g.s;
  const pct = Math.max(0, Math.min(1, s.clock / s.dayLen));
  const tpct = Math.max(0, Math.min(1, s.dayEarned / s.target));
  const low = s.clock <= 15;
  const repTone = s.rep > 65 ? "#3fae5a" : s.rep > 32 ? "#ffb627" : "#e8384f";
  return (
    <div className="relative z-30 shrink-0">
      <div className="flex items-center gap-1.5 px-2 pt-2 sm:gap-2 sm:px-3">
        <Chip tone="gold" className="shrink-0">
          <span className="font-display text-[13px] font-extrabold sm:text-[15px]">দিন {bn(s.day)}</span>
          <span className="text-[12px]">{s.loc.icon}</span>
        </Chip>
        {s.fest && (
          <Chip tone="pink" className="anim-breathe shrink-0">
            <span className="text-[12px]">{s.fest.icon}</span>
            <span className="font-display text-[10.5px] font-bold sm:text-[12px]">{s.fest.bn}</span>
          </Chip>
        )}

        <div
          className={`relative flex h-7 flex-1 items-center gap-1 overflow-hidden rounded-lg border-2 px-1.5 ${
            low ? "border-chili bg-chili/25" : "border-cream/20 bg-ink/70"
          }`}
        >
          <div
            className="absolute inset-y-0 left-0 transition-[width] duration-150 ease-linear"
            style={{
              width: `${pct * 100}%`,
              background: low ? "rgba(232,56,79,.55)" : "linear-gradient(90deg,#17b8a6,#3fae5a)",
            }}
          />
          <span className={`relative text-[13px] ${low ? "anim-breathe" : ""}`}>⏳</span>
          <span className="relative font-display text-[13px] font-extrabold tabular-nums text-cream sm:text-[15px]">
            {bn(Math.ceil(s.clock))}
          </span>
          <span className="relative ml-auto hidden text-[10px] text-cream/70 sm:inline">⌛ লক্ষ্য {taka(s.target)}</span>
        </div>

        <div ref={reg(g, "hud_money")} className="shrink-0">
          <Chip tone="teal" className="h-7">
            <span className="text-[12px]">💰</span>
            <span key={s.wallet} className="anim-pop font-display text-[14px] font-extrabold tabular-nums sm:text-[16px]">
              {bn(s.wallet)}
            </span>
          </Chip>
        </div>

        <button
          className="btn3d flex h-7 w-8 shrink-0 items-center justify-center bg-plum text-[14px] text-cream"
          onPointerDown={(e) => {
            e.preventDefault();
            sfx.init();
            sfx.setMuted(!sfx.muted);
            g.mark();
          }}
          aria-label="শব্দ চালু বা বন্ধ"
        >
          {sfx.muted ? "🔇" : "🔊"}
        </button>
        <button
          className="btn3d flex h-7 w-8 shrink-0 items-center justify-center bg-plum text-[14px] text-cream"
          onPointerDown={(e) => {
            e.preventDefault();
            g.togglePause();
          }}
          aria-label="বিরতি"
        >
          ⏸
        </button>
      </div>

      <div className="mt-1 flex items-center gap-1.5 px-2 sm:px-3">
        <div className="relative h-[8px] flex-1 overflow-hidden rounded-full border border-ink/60 bg-ink/70">
          <div
            className="absolute inset-y-0 left-0 rounded-full transition-[width] duration-200 ease-out"
            style={{
              width: `${tpct * 100}%`,
              background: tpct >= 1 ? "linear-gradient(90deg,#3fae5a,#17b8a6)" : "linear-gradient(90deg,#ffb627,#ff4d8d)",
              boxShadow: tpct >= 1 ? "0 0 12px #17b8a6" : "none",
            }}
          />
          <span className="absolute inset-0 flex items-center justify-center text-[7.5px] font-bold text-cream/85">
            {taka(s.dayEarned)} / লক্ষ্য {taka(s.target)}
          </span>
        </div>
        <div className="relative h-[8px] w-14 overflow-hidden rounded-full border border-ink/60 bg-ink/70 sm:w-24">
          <div className="absolute inset-y-0 left-0 rounded-full transition-[width] duration-300" style={{ width: `${s.rep}%`, background: repTone }} />
        </div>
        <span className="w-10 shrink-0 text-right font-display text-[11px] font-bold tabular-nums" style={{ color: repTone }}>
          ⭐{bn(Math.round(s.rep))}
        </span>
      </div>
    </div>
  );
}

/* ---------------------------- floating chips ---------------------------- */

function StatusChips({ g }: { g: Game }) {
  const s = g.s;
  return (
    <div className="pointer-events-none absolute top-1 left-2 z-20 flex flex-col items-start gap-1">
      {s.combo >= 2 && (
        <div
          key={s.combo}
          className="anim-pop flex items-center gap-1 rounded-full border-2 border-ink/60 bg-gradient-to-r from-chili to-rickshaw px-2 py-[2px] shadow-lg"
        >
          <span className="text-[12px]">🔥</span>
          <span className="font-display text-[12px] font-extrabold text-cream">কম্বো ×{bn(s.combo)}</span>
          <span className="text-[9px] font-semibold text-cream/80">+{bn(Math.min(12, s.combo) * 5)}% দাম</span>
        </div>
      )}
      {s.popularity > 0 && (
        <div className="anim-glow flex items-center gap-1 rounded-full border-2 border-ink/60 bg-rickshaw px-2 py-[2px] shadow-lg">
          <span className="text-[12px]">📸</span>
          <span className="font-display text-[12px] font-extrabold text-cream">দ্বিগুণ টাকা!</span>
          <span className="rounded-full bg-ink/50 px-1 text-[9px] font-bold text-cream">{bn(s.popularity)} জন বাকি</span>
        </div>
      )}
      {s.rep < 30 && (
        <div className="anim-breathe flex items-center gap-1 rounded-full border-2 border-ink/60 bg-chili px-2 py-[2px]">
          <span className="text-[11px]">⚠️</span>
          <span className="font-display text-[11px] font-bold text-cream">রেটিং বিপদে!</span>
        </div>
      )}
    </div>
  );
}

function Toasts({ g }: { g: Game }) {
  const tones: Record<string, string> = {
    good: "border-leaf bg-leaf/95 text-cream",
    bad: "border-chili bg-chili/95 text-cream",
    info: "border-cream/30 bg-ink/90 text-cream",
    epic: "border-marigold bg-gradient-to-r from-rickshaw to-marigold text-ink",
  };
  return (
    <div className="pointer-events-none absolute inset-x-0 top-1 z-20 flex flex-col items-center gap-1 px-2">
      {g.s.toasts.map((t) => {
        const k = 1 - t.t / t.max;
        return (
          <div
            key={t.key}
            className={`anim-slide-up max-w-[94%] rounded-xl border-2 px-2.5 py-1 text-center shadow-xl ${tones[t.kind]}`}
            style={{ opacity: Math.min(1, k * 2.6) }}
          >
            <span className="font-display text-[11px] leading-tight font-bold sm:text-[13px]">{t.bn}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------ customer ------------------------------ */

const KEYS = ["Q", "W", "E", "R", "T"];

function CustomerCard({ g, c, w }: { g: Game; c: Customer; w: number }) {
  const s = g.s;
  const ratio = Math.max(0, Math.min(1, c.patience / c.maxPatience));
  const mood: Mood = c.state === "happy" ? "happy" : c.state === "angry" ? "angry" : ratio < 0.34 ? "low" : "wait";
  const ready = s.plates.some((p) => p.dish.id === c.order.id);
  const anim = c.state === "enter" ? "anim-walk" : c.state === "happy" ? "anim-happy" : c.state === "angry" ? "anim-angry" : "";
  const barColor = ratio > 0.6 ? "#3fae5a" : ratio > 0.34 ? "#ffb627" : "#e8384f";
  const size = Math.round(Math.min(74, Math.max(36, w * 0.66)));

  const onDown = useCallback(
    (e: React.PointerEvent) => {
      e.preventDefault();
      g.serve(c.key);
    },
    [g, c.key],
  );

  return (
    <div
      className="absolute bottom-1 flex flex-col items-center justify-end pb-0 transition-[left,width] duration-500 ease-out"
      style={{
        left: `${(c.slot * 100) / s.maxSlots}%`,
        width: `${100 / s.maxSlots}%`,
        height: "100%",
        zIndex: c.state === "wait" || c.state === "enter" ? 3 : 1,
      }}
    >
      {/* order bubble */}
      <div
        className={`relative z-10 mb-1 w-full px-[2px] ${mood === "low" ? "anim-urgent" : ""}`}
        style={{ opacity: c.state === "happy" ? 0 : 1, transition: "opacity 180ms" }}
      >
        <div
          className={`paper mx-auto flex max-w-full items-center justify-center gap-[3px] rounded-xl px-1 py-[3px] shadow-lg ${
            ready ? "ring-2 ring-leaf" : ""
          }`}
          style={{ animation: ready ? "breathe 1.1s ease-in-out infinite" : undefined }}
        >
          <span className="shrink-0 text-[15px] sm:text-[19px]">{c.order.icon}</span>
          <span className="min-w-0 truncate font-display text-[9px] leading-none font-extrabold sm:text-[12px]">{c.order.bn}</span>
        </div>
        <div className="mx-auto h-[7px] w-[86%] -translate-y-[4px] rotate-45 border-r-2 border-b-2 border-[rgba(58,36,18,.35)] bg-[#ffe3ac]" />
        <div className="mx-auto mt-[1px] h-[6px] w-[88%] overflow-hidden rounded-full border border-ink/60 bg-ink/60">
          <div
            className="h-full rounded-full transition-[width,background-color] duration-150 ease-linear"
            style={{
              width: `${ratio * 100}%`,
              background: barColor,
              boxShadow: ratio < 0.34 ? `0 0 8px ${barColor}` : "none",
            }}
          />
        </div>
      </div>

      <button
        ref={reg(g, "c_" + c.key)}
        onPointerDown={onDown}
        className={`relative touch-none ${anim} ${mood === "low" ? "anim-urgent" : ""}`}
        aria-label={`${c.type.bn} — ${c.order.bn} পরিবেশন করুন`}
      >
        {ready && (
          <span
            className="pointer-events-none absolute -inset-2 rounded-2xl border-2 border-leaf/80"
            style={{ animation: "ringPulse 1.1s ease-out infinite" }}
          />
        )}
        {s.selected >= 0 && c.state === "wait" && (
          <span className="pointer-events-none absolute -inset-2 rounded-2xl border-2 border-dashed border-marigold/80" />
        )}
        <PersonView type={c.type} mood={mood} w={size} />
        {c.state === "happy" && (
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-[18px]" style={{ animation: "floatUp 760ms ease-out both" }}>
            {c.perfect ? "😍" : "😊"}
          </span>
        )}
        <span className="pointer-events-none absolute -bottom-[3px] left-1/2 -translate-x-1/2 rounded bg-ink/60 px-1 text-[8px] font-bold text-cream/75">
          {KEYS[c.slot]}
        </span>
      </button>
    </div>
  );
}

/* -------------------------------- tray -------------------------------- */

function Tray({ g }: { g: Game }) {
  const s = g.s;
  const toward = g.buildingTowards();
  const ghost = toward.length === 1 ? toward[0] : null;
  return (
    <div ref={reg(g, "tray")} className="relative z-20 flex shrink-0 items-stretch gap-1.5 px-2 py-1 sm:px-3">
      <div className="panel flex min-h-[50px] flex-[1.4] items-center gap-1 rounded-xl px-1.5 py-1">
        <span className="shrink-0 font-display text-[9px] leading-tight font-bold text-cream/55">
          বানাচ্ছেন
          <br />
          <span className="text-[7.5px] text-cream/40">PLATE</span>
        </span>
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1">
          {s.current.length === 0 && !ghost && (
            <span className="truncate text-[10px] text-cream/40">উপাদান ট্যাপ শুরু করুন…</span>
          )}
          {s.current.map((id, i) => {
            const ing = ING_MAP[id];
            return (
              <span
                key={`${id}-${i}`}
                className="anim-pop flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 border-ink/50 text-[15px] shadow"
                style={{ background: ing.color, animationDelay: `${i * 12}ms` }}
              >
                {ing.icon}
              </span>
            );
          })}
          {ghost && (
            <span className="ml-auto flex shrink-0 items-center gap-1 rounded-lg border border-dashed border-cream/25 px-1 py-[2px]">
              <span className="text-[13px] opacity-45 grayscale">{ghost.icon}</span>
              <span className="font-display text-[9px] font-bold text-cream/55">{ghost.bn}</span>
            </span>
          )}
        </div>
        <button
          className="btn3d flex h-8 w-8 shrink-0 items-center justify-center bg-chili text-[14px]"
          onPointerDown={(e) => {
            e.preventDefault();
            g.trash();
          }}
          aria-label="ফেলে দিন"
        >
          🗑️
        </button>
      </div>

      <div className="panel flex min-h-[50px] min-w-0 flex-1 flex-wrap content-center items-center gap-1 rounded-xl px-1.5 py-1">
        {Array.from({ length: s.maxPlates }).map((_, i) => {
          const p = s.plates[i];
          return (
            <button
              key={i}
              ref={reg(g, "pl_" + i)}
              onPointerDown={(e) => {
                e.preventDefault();
                if (p) g.selectPlate(i);
                else sfx.click();
              }}
              className={`relative flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border-2 text-[16px] transition-transform sm:h-10 sm:w-10 sm:text-[19px] ${
                p
                  ? s.selected === i
                    ? "-translate-y-1 border-marigold bg-marigold/30 shadow-[0_0_14px_#ffb627]"
                    : "border-cream/35 bg-ink/60"
                  : "border-dashed border-cream/20 bg-ink/30"
              }`}
              aria-label={p ? p.dish.bn : "খালি প্লেট"}
            >
              {p ? <span className="anim-pop">{p.dish.icon}</span> : <span className="text-[9px] text-cream/25">প্লেট</span>}
              {p && s.selected === i && <span className="absolute -top-1 -right-1 text-[10px]">👆</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------ stations ------------------------------ */

function Stations({ g }: { g: Game }) {
  const s = g.s;
  const valid = new Set(g.validNext());
  const unlocked = new Set(s.unlocked);
  return (
    <div className="relative z-20 shrink-0 px-2 pb-2 sm:px-3 sm:pb-3">
      <div className="grid grid-cols-5 gap-1 sm:grid-cols-10 sm:gap-1.5">
        {INGREDIENTS.map((ing) => {
          const has = unlocked.has(ing.id);
          const hot = has && valid.has(ing.id);
          return (
            <button
              key={ing.id}
              ref={reg(g, "st_" + ing.id)}
              onPointerDown={(e) => {
                e.preventDefault();
                g.tapIng(ing.id as IngId);
              }}
              className={`btn3d relative flex h-[50px] flex-col items-center justify-center overflow-hidden px-0 pt-1 sm:h-[62px] ${
                hot ? "-translate-y-[2px]" : ""
              }`}
              style={{
                background: has ? `linear-gradient(180deg, ${ing.color}f2, ${ing.color}99)` : "linear-gradient(180deg,#3a2b4d,#241a33)",
                boxShadow: hot ? `0 5px 0 rgba(27,16,41,.55), 0 0 0 3px #fff3dc88, 0 0 20px ${ing.color}` : undefined,
              }}
              aria-label={ing.bn}
            >
              <span className={`text-[18px] leading-none sm:text-[23px] ${has ? "" : "opacity-35 grayscale"}`}>{has ? ing.icon : "🔒"}</span>
              <span className={`truncate px-[2px] font-display text-[7.5px] leading-tight font-bold sm:text-[9.5px] ${has ? "text-ink" : "text-cream/40"}`}>
                {ing.bn}
              </span>
              <span
                className={`absolute top-[2px] right-[3px] rounded px-[3px] font-display text-[8px] font-extrabold ${
                  has ? "bg-ink/55 text-cream" : "bg-ink/70 text-cream/40"
                }`}
              >
                {ing.key}
              </span>
              {hot && (
                <span
                  className="pointer-events-none absolute inset-0 rounded-[12px]"
                  style={{ animation: "ringPulse 1.3s ease-out infinite", border: `2px solid ${ing.color}` }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* --------------------------- chalkboard menu --------------------------- */

const Chalkboard = memo(function Chalkboard({ g }: { g: Game }) {
  const s = g.s;
  return (
    <div className="pointer-events-none absolute top-1 right-1 z-10 w-[128px] rounded-lg border-2 border-tamarind bg-[#1d2b23]/92 p-1.5 shadow-xl sm:w-[190px] sm:p-2">
      <div className="mb-1 flex items-center justify-between">
        <span className="font-display text-[9px] font-extrabold tracking-wide text-marigold sm:text-[11px]">📋 মেনু বোর্ড</span>
        <span className="text-[8px] text-cream/45">দাম ×{s.priceMul.toFixed(1)}</span>
      </div>
      <div className="flex flex-col gap-[3px]">
        {s.menu.map((d: Dish) => (
          <div key={d.id} className="flex items-center gap-1">
            <span className="text-[11px] sm:text-[13px]">{d.icon}</span>
            <span className="w-[42px] shrink-0 truncate font-display text-[8.5px] font-bold text-cream sm:w-[58px] sm:text-[10px]">{d.bn}</span>
            <span className="flex gap-[1px]">
              {d.recipe.map((r, i) => (
                <span key={i} className="text-[8px] opacity-85 sm:text-[10px]">
                  {ING_MAP[r].icon}
                </span>
              ))}
            </span>
            <span className="ml-auto font-display text-[8px] font-bold text-marigold sm:text-[9.5px]">{taka(d.price * s.priceMul)}</span>
          </div>
        ))}
      </div>
    </div>
  );
});

/* ------------------------------ background ------------------------------ */

const Scene = memo(function Scene({ loc, fest, day }: { loc: Location; fest?: Festival; day: number }) {
  const night = day >= 4;
  const [c1, c2, c3] = loc.sky;
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: `linear-gradient(180deg, ${c1} 0%, ${c2} 52%, ${c3} 100%)` }}>
      {night && (
        <div className="absolute inset-x-0 top-0 h-1/2">
          {Array.from({ length: 30 }).map((_, i) => (
            <span
              key={i}
              className="anim-flicker absolute rounded-full bg-cream"
              style={{ left: `${(i * 37) % 100}%`, top: `${(i * 53) % 46}%`, width: i % 5 === 0 ? 3 : 2, height: i % 5 === 0 ? 3 : 2, animationDelay: `${(i % 7) * 0.6}s`, opacity: 0.8 }}
            />
          ))}
        </div>
      )}
      <div
        className="absolute rounded-full"
        style={{
          right: "11%",
          top: "9%",
          width: 54,
          height: 54,
          background: fest?.id === "ramzan" ? "#fff3dc" : "radial-gradient(circle at 35% 35%, #fff3dc, #ffb627 60%, #f2714a)",
          boxShadow: `0 0 ${fest?.id === "ramzan" ? 30 : 60}px ${fest?.id === "ramzan" ? "#17b8a6" : "#ffb627"}aa`,
        }}
      />
      <SilhouetteView kind={loc.silo} tint={night ? "rgba(20,12,32,.86)" : "rgba(43,22,52,.68)"} />
      <div className="absolute inset-x-0 bottom-[14%] h-[26%]" style={{ background: `linear-gradient(180deg, transparent, ${c3}55)` }} />
      <TrafficView night={night} />
      <div className="absolute inset-x-0 bottom-0 h-[18%]" style={{ background: "linear-gradient(180deg,#3a2b45,#221730)" }}>
        <div className="absolute inset-x-0 top-1/2 flex -translate-y-1/2 justify-around opacity-40">
          {Array.from({ length: 12 }).map((_, i) => (
            <span key={i} className="h-[3px] w-[26px] rounded bg-marigold/70" />
          ))}
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-[16%] h-[3px] bg-cream/10" />
      {fest?.id === "boishakh" && (
        <div
          className="pointer-events-none absolute inset-0 opacity-20"
          style={{ background: "repeating-linear-gradient(45deg,#e8384f 0 18px,transparent 18px 36px)" }}
        />
      )}
      <LightsView bulbs={day >= 3 ? 16 : 12} color={fest?.tint ?? "#ffb627"} />
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 80% at 50% 40%, transparent 40%, rgba(20,10,30,.6))" }} />
    </div>
  );
});

/* ------------------------------ play screen ------------------------------ */

export function PlayScreen({ g }: { g: Game }) {
  const s = g.s;
  const cartBox = useRef<HTMLDivElement>(null);
  const [cs, setCs] = useState(0.62);

  useEffect(() => {
    const el = cartBox.current;
    if (!el) return;
    const measure = () => setCs(Math.max(0.44, Math.min(1.05, el.clientWidth / 200)));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  const hint =
    s.day === 1 && s.hintStage === 1
      ? "১️⃣ কাস্টমারের অর্ডার দেখুন — নিচের জ্বলজ্বলে উপাদানগুলো পরপর ট্যাপ করুন"
      : s.day === 1 && s.hintStage === 2
        ? "২️⃣ রেডি! সবুজ বলয়ওয়ালা কাস্টমারকে ট্যাপ করুন (অথবা Space)"
        : "";

  return (
    <>
      <Scene loc={s.loc} fest={s.fest} day={s.day} />
      <div className="relative z-10 flex h-full flex-col">
        <Hud g={g} />
        <main className="relative min-h-0 flex-1">
          <StatusChips g={g} />
          <Toasts g={g} />
          <Chalkboard g={g} />
          <div className="absolute inset-x-0 bottom-0 flex items-end gap-1 px-1 pb-[2.5%] sm:px-3">
            <div ref={cartBox} className="relative w-[31%] max-w-[215px] shrink-0 sm:w-[24%]" style={{ height: 208 * cs }}>
              <div className="absolute bottom-0 left-0 w-[200px] origin-bottom-left" style={{ transform: `scale(${cs})` }}>
                <div ref={reg(g, "cart")}>
                  <CartView upgrades={s.upgrades} sign="রাস্তার ধারের ফুডকার্ট" glow={s.fest?.tint ?? "#ffb627"} />
                </div>
              </div>
            </div>
            <div className="relative h-[136px] min-w-0 flex-1 sm:h-[172px]">
              <div
                className="absolute bottom-0 left-1/2 h-full -translate-x-1/2"
                style={{ width: `min(100%, ${s.maxSlots * 152}px)` }}
              >
                {s.customers.map((c) => (
                  <CustomerCard
                    key={c.key}
                    g={g}
                    c={c}
                    w={
                      Math.min(152, ((typeof window !== "undefined" ? window.innerWidth : 900) * 0.68) / s.maxSlots)
                    }
                  />
                ))}
                {s.customers.length === 0 && s.phase === "playing" && (
                  <div className="flex h-full w-full items-center justify-center">
                    <span className="font-display text-[12px] font-bold text-cream/45">কাস্টমার আসছে… 🚶</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
        {hint && (
          <div className="pointer-events-none relative z-30 flex shrink-0 justify-center px-3 pb-[3px]">
            <div className="anim-slide-up rounded-xl border-2 border-marigold bg-ink/92 px-2.5 py-1 text-center shadow-[0_6px_20px_rgba(0,0,0,.5)]">
              <span className="font-display text-[11px] leading-tight font-bold text-marigold sm:text-[13px]">{hint}</span>
            </div>
          </div>
        )}
        <Tray g={g} />
        <Stations g={g} />
      </div>
    </>
  );
}
