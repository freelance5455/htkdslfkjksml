import React, { useState } from 'react';
import { LanguageCode } from '../types';
import { Heart, Sparkles, Wand2, Copy, Check, X, ShieldAlert, MessageCircle, AlertCircle, Send } from 'lucide-react';

interface GirlsChatFixerModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
  onSendToChat?: (text: string) => void;
}

export const GirlsChatFixerModal: React.FC<GirlsChatFixerModalProps> = ({
  isOpen,
  onClose,
  language,
  onSendToChat,
}) => {
  const [problem, setProblem] = useState('');
  const [lastMessage, setLastMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFixChat = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!problem.trim() && !lastMessage.trim()) return;

    setIsLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/fix-girls-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problem: problem.trim(),
          lastMessage: lastMessage.trim(),
          language,
        }),
      });

      const data = await res.json();
      if (data.repairAdvice) {
        setResult(data.repairAdvice);
      } else {
        setResult('Unable to generate response. Please try again.');
      }
    } catch (err: any) {
      setResult(`⚠️ Error: ${err?.message || 'Failed to connect to relationship assistant'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const QUICK_SCENARIOS = [
    { label: '💔 Usne "k" / "hmm" likha hai (Dry reply)', problem: 'She replied with just "k" or "hmm". Conversation is dry.', msg: 'k' },
    { label: '😡 Gussa ho gayi hai (Angry / Upset)', problem: 'She is angry and hurt because of a misunderstanding.', msg: 'Mujhe aapse baat nahi karni.' },
    { label: '⏳ 5 ghante baad reply kiya (Delayed reply)', problem: 'She took hours to reply without explanation.', msg: 'Busy thi' },
    { label: '🌸 Pehli baar message shuru karna hai (First text)', problem: 'How to start conversation with charm, respect, and high value without being boring.', msg: 'Hi' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-zinc-950 border border-pink-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-white/10 bg-gradient-to-r from-pink-950/40 via-purple-950/30 to-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/30">
              <Heart className="w-5 h-5 fill-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>बातचीत सुधारक (Girls Chat Error Fixer)</span>
                <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  HIGH EQ
                </span>
              </h3>
              <p className="text-[11px] text-zinc-400">
                Fix awkward moments, misunderstanding, dry texting &amp; make her smile
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Quick Scenario Picker */}
          <div>
            <span className="block text-[11px] font-semibold text-zinc-400 mb-1.5">
              Quick Situations (1-Click Chunein):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {QUICK_SCENARIOS.map((sc, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setProblem(sc.problem);
                    setLastMessage(sc.msg);
                  }}
                  className="p-2 rounded-xl text-left bg-zinc-900/60 hover:bg-zinc-800 text-[11px] text-zinc-300 border border-white/5 truncate transition-all active:scale-98"
                >
                  {sc.label}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleFixChat} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Kya Galat Hua Ya Kya Situation Hai? *
              </label>
              <input
                type="text"
                value={problem}
                onChange={e => setProblem(e.target.value)}
                placeholder="e.g. Usne 'k' likha hai, ya wo gussa hai, ya baat aage nahi badh rahi..."
                className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Uska Aakhri Message (Her Last Message)
              </label>
              <input
                type="text"
                value={lastMessage}
                onChange={e => setLastMessage(e.target.value)}
                placeholder='e.g. "k", "hmm", "busy hoon", "mujhe nahi pata"...'
                className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500 font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || (!problem && !lastMessage)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-pink-500/25 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Fixing Error &amp; Formulating Charming Replies...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Fix Conversation &amp; Get Winning Replies 💖</span>
                </>
              )}
            </button>
          </form>

          {/* Result Section */}
          {result && (
            <div className="p-4 rounded-2xl bg-zinc-900/90 border border-pink-500/30 shadow-xl space-y-3 animate-fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-xs font-bold text-pink-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                  AI Relationship &amp; Charisma Diagnosis:
                </span>
                <button
                  onClick={() => handleCopy(result)}
                  className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-[11px] text-zinc-200 flex items-center gap-1 transition-all"
                >
                  {copiedText === result ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedText === result ? 'Copied All!' : 'Copy All'}</span>
                </button>
              </div>

              <div className="text-xs text-zinc-200 leading-relaxed whitespace-pre-wrap font-sans">
                {result}
              </div>

              {onSendToChat && (
                <div className="pt-2 border-t border-white/5 flex justify-end">
                  <button
                    onClick={() => {
                      onSendToChat(`Maine relationship repair check kiya: "${problem}". Ab agla step batao.`);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 text-xs font-semibold border border-pink-500/40 flex items-center gap-1.5 transition-all"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Send to Agent Chat</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
