import React from 'react';
import {
  Sliders,
  Sun,
  Moon,
  Sparkles,
  SunMedium,
  Check,
} from 'lucide-react';
import { AppSettings } from '../../types';
import { getThemeToneStyles } from '../../utils/theme';
import { toBanglaDigits } from '../../utils/formatters';

interface ThemeShadeBarProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  compact?: boolean;
}

export const ThemeShadeBar: React.FC<ThemeShadeBarProps> = ({
  appSettings,
  onUpdateSettings,
  compact = false,
}) => {
  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';
  const currentShade =
    typeof appSettings.themeShade === 'number' && !isNaN(appSettings.themeShade)
      ? appSettings.themeShade
      : 50;

  const toneConfig = getThemeToneStyles(
    appSettings.themeMode,
    currentShade,
    isEn
  );

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    onUpdateSettings({
      ...appSettings,
      themeShade: value,
    });
  };

  const handleSetPreset = (presetValue: number) => {
    onUpdateSettings({
      ...appSettings,
      themeShade: presetValue,
    });
  };

  const displayPercent =
    !isEn && appSettings.useBanglaDigits
      ? `${toBanglaDigits(currentShade)}%`
      : `${currentShade}%`;

  const presets = [
    { value: 15, labelEn: 'Soft', labelBn: 'হালকা' },
    { value: 35, labelEn: 'Medium', labelBn: 'মাঝারি' },
    { value: 50, labelEn: 'Balanced', labelBn: 'ব্যালেন্সড' },
    { value: 75, labelEn: 'Deep', labelBn: 'ডিপ' },
    { value: 95, labelEn: 'Ultra Deep', labelBn: 'অতি গাঢ়' },
  ];

  return (
    <div
      className={`rounded-2xl border transition-all duration-200 ${
        compact ? 'p-3.5 space-y-3' : 'p-4 sm:p-5 space-y-4'
      } ${
        isLight
          ? 'bg-slate-50/80 border-slate-200/90 text-slate-900'
          : 'bg-slate-900/60 border-slate-700/80 text-slate-100'
      }`}
      id="theme-shade-tone-container"
    >
      {/* 1. Header with Label & Tone Badge */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div
            className={`p-1.5 rounded-xl border ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700'
                : 'bg-slate-800 border-slate-700 text-indigo-400'
            }`}
          >
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-black tracking-tight flex items-center gap-1.5">
              <span>{isEn ? 'Shade & Tone' : 'শেড ও টোন (Shade & Tone)'}</span>
            </h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              {isEn
                ? 'Adjust selected theme: Light ◄► Deep'
                : 'নির্বাচিত থিম হালকা থেকে ডিপ (Light - Deep) কমবেশ করুন'}
            </p>
          </div>
        </div>

        {/* Live Active Tone Badge */}
        <span
          className={`text-[11px] font-extrabold px-2.5 py-1 rounded-full border shadow-2xs shrink-0 flex items-center gap-1.5 ${
            isLight
              ? 'bg-white text-slate-800 border-slate-200'
              : 'bg-slate-800 text-indigo-300 border-slate-600'
          }`}
          id="theme-shade-tone-badge"
        >
          <span
            className="w-2 h-2 rounded-full shrink-0 border border-black/20 dark:border-white/20"
            style={{ backgroundColor: toneConfig.cardBg }}
          />
          <span>{displayPercent}</span>
          <span className="opacity-40">•</span>
          <span className="truncate max-w-[110px] sm:max-w-none">
            {isEn ? toneConfig.tagEn : toneConfig.tagBn}
          </span>
        </span>
      </div>

      {/* 2. Interactive Range Slider Bar */}
      <div className="space-y-1.5 pt-1">
        <div className="relative flex items-center py-1">
          <input
            type="range"
            min="0"
            max="100"
            step="1"
            value={currentShade}
            onChange={handleSliderChange}
            aria-label={isEn ? 'Theme Shade and Tone' : 'থিম শেড ও টোন'}
            className="spectrum-slider w-full h-3 rounded-full appearance-none cursor-pointer border border-black/15 dark:border-white/15 focus:outline-hidden"
            style={{
              background: toneConfig.sliderTrackGradient,
            }}
            id="theme-shade-slider-input"
          />
        </div>

        {/* Slider Labels */}
        <div className="flex items-center justify-between text-[10px] font-semibold text-slate-500 dark:text-slate-400 px-0.5">
          <span className="flex items-center gap-1">
            <SunMedium className="w-3 h-3 text-amber-500" />
            <span>{isEn ? 'Light / Soft (0%)' : 'হালকা (০%)'}</span>
          </span>
          <span className="text-[9px] uppercase tracking-wider opacity-60">
            {isEn ? 'Drag to Adjust' : 'টেনে কমবেশ করুন'}
          </span>
          <span className="flex items-center gap-1">
            <Moon className="w-3 h-3 text-indigo-400" />
            <span>{isEn ? 'Deep / Dark (100%)' : 'গাঢ় (১০০%)'}</span>
          </span>
        </div>
      </div>

      {/* 3. Quick Preset Buttons */}
      <div className="flex items-center justify-between gap-1 sm:gap-1.5 pt-1">
        {presets.map((preset) => {
          const isPresetActive = Math.abs(currentShade - preset.value) <= 7;
          return (
            <button
              key={preset.value}
              type="button"
              onClick={() => handleSetPreset(preset.value)}
              className={`flex-1 py-1 px-1 rounded-xl text-[10px] font-bold border transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                isPresetActive
                  ? isLight
                    ? 'bg-white border-slate-400 text-slate-900 shadow-xs ring-2 ring-slate-300/40'
                    : 'bg-slate-800 border-indigo-400 text-white shadow-xs ring-2 ring-indigo-400/40'
                  : isLight
                  ? 'bg-white/70 border-slate-200/80 text-slate-600 hover:bg-white'
                  : 'bg-slate-800/60 border-slate-700/70 text-slate-400 hover:bg-slate-800'
              }`}
              id={`theme-preset-btn-${preset.value}`}
            >
              <span>{isEn ? preset.labelEn : preset.labelBn}</span>
              <span className="text-[9px] opacity-70 font-normal">
                {!isEn && appSettings.useBanglaDigits
                  ? `${toBanglaDigits(preset.value)}%`
                  : `${preset.value}%`}
              </span>
            </button>
          );
        })}
      </div>

      {/* 4. Live Mini Visual Preview Swatch */}
      <div
        className="rounded-xl p-2.5 border transition-colors flex items-center justify-between gap-2.5"
        style={{
          backgroundColor: toneConfig.outerBg,
          borderColor: toneConfig.cardBorder,
        }}
      >
        <div className="flex items-center gap-2 min-w-0">
          <div
            className="w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 shadow-2xs"
            style={{
              backgroundColor: toneConfig.cardBg,
              borderColor: toneConfig.cardBorder,
            }}
          >
            {appSettings.themeMode === 'light' ? (
              <Sun className="w-3.5 h-3.5 text-amber-500" />
            ) : appSettings.themeMode === 'dark' ? (
              <Moon className="w-3.5 h-3.5 text-indigo-400" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            )}
          </div>
          <div className="min-w-0">
            <p
              className="text-[11px] font-bold truncate leading-tight"
              style={{
                color: isLight ? '#0f172a' : '#f8fafc',
              }}
            >
              {isEn ? toneConfig.titleEn : toneConfig.titleBn}
            </p>
            <p
              className="text-[9px] truncate opacity-75"
              style={{
                color: isLight ? '#475569' : '#94a3b8',
              }}
            >
              {isEn
                ? 'Real-time background & card tone'
                : 'রিয়েল-টাইম ব্যাকগ্রাউন্ড ও কার্ড প্রিভিউ'}
            </p>
          </div>
        </div>

        <div
          className="px-2 py-0.5 rounded-md border text-[9px] font-extrabold shrink-0"
          style={{
            backgroundColor: toneConfig.cardBg,
            borderColor: toneConfig.cardBorder,
            color: isLight ? '#0369a1' : '#818cf8',
          }}
        >
          {isEn ? 'Preview' : 'প্রিভিউ'}
        </div>
      </div>
    </div>
  );
};
