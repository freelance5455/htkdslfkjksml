"use client";

import Link from "next/link";
import type * as React from "react";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import type { LearningPath } from "@/data/paths";
import { LessonList, useLessonProgress } from "@/components/lesson-list";
import { Quiz } from "@/components/quiz";
import { toArabicDigits } from "@/lib/site";

/** Homepage "الرحلة التعليمية" block: pick a stage, study its lessons, take its quiz. */
export function JourneyExplorer({ paths }: { paths: LearningPath[] }) {
  const [activeSlug, setActiveSlug] = useState(paths[0]?.slug ?? "");
  const active = paths.find((p) => p.slug === activeSlug) ?? paths[0];

  if (!active) return null;

  return (
    <>
      <div className="reveal [perspective:1600px]" style={{ "--reveal-delay": "0ms" } as React.CSSProperties}>
        <ol className="relative grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:[transform:rotateX(18deg)] lg:[transform-style:preserve-3d]">
          <svg
            className="pointer-events-none absolute inset-x-0 top-1/2 hidden h-24 w-full -translate-y-1/2 lg:block"
            viewBox="0 0 1000 100"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <path
              d="M1000 80 C 800 80, 750 20, 500 50 S 150 20, 0 20"
              fill="none"
              stroke="#B69A69"
              strokeWidth={2}
              strokeDasharray="6 8"
            />
          </svg>
          {paths.map((path, i) => (
            <StageButton
              key={path.slug}
              path={path}
              index={i}
              active={path.slug === active.slug}
              onSelect={() => setActiveSlug(path.slug)}
            />
          ))}
        </ol>
      </div>

      <div className="mt-16 grid gap-8 lg:grid-cols-[1fr_1.2fr]">
        <div className="reveal" style={{ "--reveal-delay": "0ms" } as React.CSSProperties}>
          <div className="rounded-3xl border border-border bg-stone/60 p-6 sm:p-8">
            <div className="mb-6 flex items-center justify-between gap-4">
              <h3 className="font-serif text-2xl font-bold text-navy">دروس: {active.title}</h3>
              <ProgressBadge pathSlug={active.slug} total={active.lessons.length} />
            </div>
            <LessonList key={active.slug} pathSlug={active.slug} lessons={active.lessons} />
            <Link
              className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-royal hover:text-gold"
              href={`/paths/${active.slug}`}
            >
              افتح المسار كاملًا <ArrowLeft className="size-4" aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="reveal" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
          <Quiz key={active.slug} title={active.title} questions={active.quiz} />
        </div>
      </div>
    </>
  );
}

function StageButton({
  path,
  index,
  active,
  onSelect,
}: {
  path: LearningPath;
  index: number;
  active: boolean;
  onSelect: () => void;
}) {
  const offset = -18 * index;
  return (
    <li className="relative" style={{ transform: `translateY(${offset}px)` }}>
      <button
        type="button"
        aria-pressed={active}
        onClick={onSelect}
        className={`group relative w-full overflow-hidden rounded-3xl border p-6 text-start transition-all duration-500 [transform-style:preserve-3d] ${
          active
            ? "border-gold bg-navy text-ivory shadow-[0_40px_60px_-30px_rgba(23,36,58,0.9)] lg:[transform:translateZ(40px)]"
            : "border-border bg-card text-navy shadow-[0_25px_40px_-30px_rgba(23,36,58,0.5)] hover:-translate-y-1 hover:border-gold/60"
        }`}
      >
        {active && <div className="pattern-lattice absolute inset-0 opacity-10" aria-hidden="true" />}
        <span
          className={`relative mb-5 grid size-14 place-items-center rounded-2xl font-serif text-2xl font-bold shadow-inner ${
            active ? "bg-gold text-navy" : "bg-stone text-gold"
          }`}
        >
          {toArabicDigits(index + 1)}
        </span>
        <span className={`relative block text-xs ${active ? "text-gold-light" : "text-gold"}`}>{path.stageLabel}</span>
        <span className="relative mt-1 block font-serif text-2xl font-bold">{path.title}</span>
        <span className={`relative mt-2 block text-sm leading-6 ${active ? "text-ivory/70" : "text-navy/60"}`}>
          {path.description}
        </span>
        <span className={`relative mt-4 block text-xs ${active ? "text-ivory/50" : "text-navy/40"}`}>
          {toArabicDigits(path.lessons.length)} دروس · اختبار
        </span>
      </button>
    </li>
  );
}

function ProgressBadge({ pathSlug, total }: { pathSlug: string; total: number }) {
  const [completed] = useLessonProgress(pathSlug);
  const done = Object.values(completed).filter(Boolean).length;
  return (
    <span className="text-sm text-gold tabular-nums">
      {toArabicDigits(Math.min(done, total))} / {toArabicDigits(total)}
    </span>
  );
}
