import React from 'react';
import { UserSession } from '../types';
import { Home, FolderTree, Code2, Eye, GraduationCap } from 'lucide-react';

interface MobileNavBarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  session: UserSession | null;
  siteTheme?: string;
}

export const MobileNavBar: React.FC<MobileNavBarProps> = ({
  activeTab,
  onSelectTab,
}) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'files', label: 'Files', icon: FolderTree },
    { id: 'editor', label: 'Editor', icon: Code2 },
    { id: 'preview', label: 'Preview', icon: Eye },
    { id: 'assignments', label: 'Tasks', icon: GraduationCap },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-14 theme-bg-header border-t theme-border flex items-center justify-around z-40 select-none md:hidden">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-lg transition-all cursor-pointer ${
              isActive
                ? 'text-[#359efe] font-bold'
                : 'theme-text-muted hover:theme-text-main'
            }`}
          >
            <Icon className="w-4 h-4 mb-0.5" />
            <span className="text-[10px]">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
