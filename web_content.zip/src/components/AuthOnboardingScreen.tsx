import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { SecretGossipLogo } from './SecretGossipLogo';
import { INDIA_COLLEGES_DATA } from '../utils/indiaCollegesData';
import { 
  ShieldCheck, 
  Lock, 
  Phone, 
  KeyRound, 
  GraduationCap, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft,
  CheckCircle2, 
  AlertCircle,
  Building2,
  Check,
  Send,
  Clock,
  Crown,
  MapPin,
  Map,
  MessageSquare,
  Smartphone,
  UserCheck,
  RefreshCw,
  BellRing
} from 'lucide-react';

const AVATAR_EMOJIS = [
  '🦊', '🦉', '🐱', '🐺', '🦁', '👻', '🔮', '⚡', 
  '🎭', '🦇', '🦝', '🚀', '👑', '🛡️', '🌙', '🌸'
];

export const AuthOnboardingScreen: React.FC = () => {
  const { 
    registerUser, 
    sendPhoneOtp, 
    verifyPhoneOtp, 
    isUsernameAvailable,
    checkPhoneNumber,
    loginExistingAccountByPhone,
    colleges,
    addNewCollege
  } = useApp();

  // Wizard Steps: 1: Phone & OTP, 2: Secret Username & Mask, 3: State -> District -> College
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Step 1: Phone & OTP
  const [phone, setPhone] = useState('');
  const [selectedChannel, setSelectedChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  // Validation States for Phone
  const [phoneTouched, setPhoneTouched] = useState(false);
  const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
  const isPhone10Digits = cleanPhone.length === 10;
  const isPhoneValidIndian = /^[6-9]\d{9}$/.test(cleanPhone);

  // WhatsApp One-Account-Per-Phone Detection
  const [isExistingAccount, setIsExistingAccount] = useState(false);
  const [existingAccountUser, setExistingAccountUser] = useState<any>(null);

  // Step 2: Username & Avatar
  const [customUsername, setCustomUsername] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('🦊');
  const [classInfo, setClassInfo] = useState("Student '26");
  const [email, setEmail] = useState('');

  // Step 3: State -> District -> College Hierarchy
  const [selectedState, setSelectedState] = useState<string>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedCollegeItem, setSelectedCollegeItem] = useState<{ id: string; name: string; badge: string } | null>(null);
  const [collegePasscode, setCollegePasscode] = useState('');
  
  // Custom manual college entry (only if institution not found in district)
  const [isManualEntry, setIsManualEntry] = useState(false);
  const [manualCollegeName, setManualCollegeName] = useState('');

  // Status
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check phone registry in real-time as user types 10 digits
  useEffect(() => {
    if (isPhoneValidIndian) {
      const check = checkPhoneNumber(cleanPhone);
      if (check.isRegistered && check.existingUser) {
        setIsExistingAccount(true);
        setExistingAccountUser(check.existingUser);
      } else {
        setIsExistingAccount(false);
        setExistingAccountUser(null);
      }
    } else {
      setIsExistingAccount(false);
      setExistingAccountUser(null);
    }
  }, [cleanPhone, isPhoneValidIndian, checkPhoneNumber]);

  // 1. Send OTP to Mobile Number (via WhatsApp or SMS)
  const handleSendOtp = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setPhoneTouched(true);

    if (!isPhone10Digits) {
      setErrorMsg('Kripya apna 10-digit ka mobile number enter karein.');
      return;
    }

    if (!isPhoneValidIndian) {
      setErrorMsg('Invalid Indian mobile number! Number 6, 7, 8, ya 9 se shuru hona chahiye.');
      return;
    }

    setIsSubmitting(true);
    const res = await sendPhoneOtp(cleanPhone, selectedChannel);
    setIsSubmitting(false);

    if (res.success) {
      setOtpSent(true);
      setOtpTimer(30);
      setOtp('');

      setSuccessMsg(`OTP successfully dispatched to +91 ${cleanPhone} via ${selectedChannel === 'whatsapp' ? 'WhatsApp' : 'SMS'}! Please check your phone.`);

      const interval = setInterval(() => {
        setOtpTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  // 2. Verify OTP & Proceed (Login Existing OR Proceed to Step 2)
  const handleVerifyOtpAndProceed = () => {
    setErrorMsg('');

    if (!otp.trim() || otp.trim().length !== 6) {
      setErrorMsg('Kripya apne phone par aaya 6-digit OTP code enter karein.');
      return;
    }

    const isValid = verifyPhoneOtp(cleanPhone, otp.trim());
    if (!isValid) {
      setErrorMsg('Galat OTP code! Kripya phone par aaya sahi 6-digit code dekhkar enter karein.');
      return;
    }

    // WHATSAPP POLICY: If account already exists, log in directly!
    if (isExistingAccount) {
      setSuccessMsg(`Welcome back @${existingAccountUser?.avatarName || 'Student'}! Aapke account mein login ho raha hai...`);
      setTimeout(() => {
        loginExistingAccountByPhone(cleanPhone);
      }, 600);
      return;
    }

    // NEW USER: Proceed to Step 2 to choose Unique Secret Username
    setSuccessMsg('Phone verify ho gaya! Ab apna unique secret username banayein.');
    setTimeout(() => {
      setSuccessMsg('');
      setStep(2);
    }, 500);
  };

  // 3. Username validation check
  const usernameClean = customUsername.trim();
  const isUnameAvailable = isUsernameAvailable(usernameClean);
  const isUnameValidLength = usernameClean.length >= 3;

  const handleProceedToCollegeStep = () => {
    setErrorMsg('');
    if (!isUnameValidLength) {
      setErrorMsg('Secret Username kam se kam 3 characters ka hona chahiye.');
      return;
    }
    if (!isUnameAvailable) {
      setErrorMsg('Yeh username pehle se kisi student ne le rakha hai! Koi doosra unique naam chunein.');
      return;
    }

    setStep(3);
  };

  // Selected State object & available districts
  const currentStateObj = INDIA_COLLEGES_DATA.find(s => s.state === selectedState);
  const availableDistricts = currentStateObj ? currentStateObj.districts : [];
  const currentDistrictObj = availableDistricts.find(d => d.district === selectedDistrict);
  const availableColleges = currentDistrictObj ? currentDistrictObj.colleges : [];

  // Check if chosen college is ALREADY activated on Secret Gossip
  const chosenCollegeName = isManualEntry ? manualCollegeName.trim() : (selectedCollegeItem?.name || '');
  const existingCollege = colleges.find(c => 
    c.name.trim().toLowerCase() === chosenCollegeName.toLowerCase() &&
    (c.district?.toLowerCase() === selectedDistrict.toLowerCase() || c.city.toLowerCase() === selectedDistrict.toLowerCase())
  );

  // 4. Submit College Activation or Join with Code
  const handleCollegeFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!selectedState) {
      setErrorMsg('Kripya apni State chunein.');
      return;
    }
    if (!selectedDistrict) {
      setErrorMsg('Kripya apna District / City chunein.');
      return;
    }
    if (!chosenCollegeName) {
      setErrorMsg('Kripya list mein se apna College chunein.');
      return;
    }
    if (!collegePasscode.trim()) {
      setErrorMsg('Kripya Secret College Code daalein.');
      return;
    }

    // CASE 1: College is ALREADY activated on Secret Gossip
    if (existingCollege) {
      if (existingCollege.secretPasscode && existingCollege.secretPasscode.trim().toUpperCase() !== collegePasscode.trim().toUpperCase()) {
        setErrorMsg(`Incorrect Secret Code for "${existingCollege.name}"! Yeh college pehle se registered hai. Kripya apne college ke admin ya students se sahi code lein.`);
        return;
      }

      setIsSubmitting(true);
      const success = registerUser(
        email || `${usernameClean.toLowerCase()}@campus.edu`,
        cleanPhone,
        existingCollege.code,
        classInfo,
        selectedEmoji,
        usernameClean,
        false
      );
      setIsSubmitting(false);

      if (!success) {
        setErrorMsg('Failed to join college. Please try again.');
      }
      return;
    }

    // CASE 2: College is NOT yet activated -> Activate it and become FOUNDER / ADMIN!
    setIsSubmitting(true);
    const res = addNewCollege(
      chosenCollegeName,
      selectedDistrict,
      collegePasscode,
      selectedCollegeItem?.badge || '🏛️',
      selectedState,
      selectedDistrict
    );

    if (!res.success) {
      setIsSubmitting(false);
      setErrorMsg(res.message);
      return;
    }

    if (res.college) {
      const regSuccess = registerUser(
        email || `${usernameClean.toLowerCase()}@campus.edu`,
        cleanPhone,
        res.college.code,
        classInfo,
        selectedEmoji,
        usernameClean,
        true // Founder & Admin!
      );
      setIsSubmitting(false);

      if (!regSuccess) {
        setErrorMsg('Error creating account.');
      }
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#05060b] text-slate-100 flex flex-col justify-center items-center p-3 sm:p-6 relative overflow-hidden">
      
      {/* Background Cyber Glow Ambience */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-tr from-pink-600/15 via-purple-600/20 to-cyan-500/15 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container Card */}
      <div className="relative z-10 w-full max-w-lg bg-gradient-to-b from-[#0c0f1d] to-[#070912] border border-slate-800/80 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-purple-950/20 backdrop-blur-xl">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <SecretGossipLogo size="lg" showText={true} />
          
          {/* Multi-step progress indicator */}
          <div className="flex items-center gap-2 mt-4">
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 1 ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Phone className="w-3 h-3" />
              <span>1. Phone Verification</span>
            </div>
            <span className="text-slate-700">›</span>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 2 ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Sparkles className="w-3 h-3" />
              <span>2. Secret ID</span>
            </div>
            <span className="text-slate-700">›</span>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 3 ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Building2 className="w-3 h-3" />
              <span>3. Campus</span>
            </div>
          </div>
        </div>

        {/* Error / Success Notifications */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-start gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* ================= STEP 1: MOBILE PHONE + REAL OTP (WHATSAPP POLICY) ================= */}
        {step === 1 && (
          <div className="space-y-4 animate-in fade-in duration-300">
            
            {/* 1. Phone Number Input with Real-time Validity Check */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Enter 10-Digit Mobile Number
                </label>
                {phone.length > 0 && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    isPhoneValidIndian ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {isPhoneValidIndian ? (
                      <>
                        <Check className="w-3 h-3" /> Valid Indian Number
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3 h-3" /> 
                        {cleanPhone.length < 10 ? `${10 - cleanPhone.length} digits remaining` : 'Must start with 6-9'}
                      </>
                    )}
                  </span>
                )}
              </div>

              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value.replace(/\D/g, ''));
                    setPhoneTouched(true);
                    setOtpSent(false);
                  }}
                  placeholder="Enter 10-digit mobile number"
                  className={`w-full pl-14 pr-4 py-3 rounded-2xl bg-slate-950/70 border text-sm font-mono text-slate-100 placeholder:text-slate-600 transition-all outline-none ${
                    isPhoneValidIndian 
                      ? 'border-emerald-500/50 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-500/30' 
                      : phoneTouched && phone.length > 0 
                        ? 'border-amber-500/50 focus:border-amber-400' 
                        : 'border-slate-800 focus:border-pink-500/60'
                  }`}
                />
              </div>

              {phoneTouched && phone.length === 10 && !isPhoneValidIndian && (
                <p className="text-[11px] text-amber-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  <span>Indian mobile numbers must start with 6, 7, 8, or 9.</span>
                </p>
              )}
            </div>

            {/* Existing Account Notice (WhatsApp 1-Account-Per-Number Enforcement) */}
            {isExistingAccount && (
              <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-1 animate-in fade-in">
                <div className="flex items-center gap-2 text-purple-300 text-xs font-bold">
                  <UserCheck className="w-4 h-4 text-purple-400" />
                  <span>Existing Account Found for +91 {cleanPhone}</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Aapke is number par pehle se ID bani hui hai: <strong className="text-white">@{existingAccountUser?.avatarName}</strong> ({existingAccountUser?.collegeName}).
                </p>
                <p className="text-[10px] text-purple-300/80">
                  WhatsApp ki tarah 1 number se 1 hi account banta hai. OTP daalte hi aap apne usi account mein login ho jayenge.
                </p>
              </div>
            )}

            {/* 2. Choose OTP Channel (Phone SMS vs WhatsApp) */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-slate-300">
                Choose Where to Receive Your OTP:
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedChannel('whatsapp');
                    if (otpSent) handleSendOtp();
                  }}
                  className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                    selectedChannel === 'whatsapp' 
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-950/50' 
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>WhatsApp OTP</span>
                  </div>
                  <span className="text-[10px] font-normal text-emerald-400/80">Receive on WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedChannel('sms');
                    if (otpSent) handleSendOtp();
                  }}
                  className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                    selectedChannel === 'sms' 
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-lg shadow-cyan-950/50' 
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <span>Phone SMS OTP</span>
                  </div>
                  <span className="text-[10px] font-normal text-cyan-400/80">Receive via SMS</span>
                </button>
              </div>
            </div>

            {/* 3. Send OTP Trigger Button (if not sent yet) */}
            {!otpSent && (
              <button
                type="button"
                onClick={handleSendOtp}
                disabled={!isPhoneValidIndian || isSubmitting}
                className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-pink-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
                <span>Send OTP to +91 {cleanPhone || 'Mobile'}</span>
              </button>
            )}

            {/* 4. Sent Confirmation Badge - Zero OTP Leakage */}
            {otpSent && (
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-1.5 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 text-xs font-bold text-white">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>OTP Dispatched to Mobile (+91 {cleanPhone})</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Aapke phone ke {selectedChannel === 'whatsapp' ? 'WhatsApp' : 'SMS'} par 6-digit security code bhej diya gaya hai. Kripya apna phone check karke code yahan enter karein.
                </p>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                  <Lock className="w-3 h-3 text-pink-400" />
                  <span>Security Guarantee: Code app screen par leak nahi hoga, seedha aapke SIM/Device par aayega.</span>
                </div>
              </div>
            )}

            {/* 5. Manual 6-Digit OTP Entry */}
            {otpSent && (
              <div className="space-y-2 pt-1 animate-in fade-in duration-300">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Enter 6-Digit OTP</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={otpTimer > 0}
                    className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 disabled:text-slate-600 transition-colors flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3 h-3 ${otpTimer > 0 ? 'animate-spin' : ''}`} />
                    <span>{otpTimer > 0 ? `Resend in ${otpTimer}s` : 'Resend OTP'}</span>
                  </button>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    maxLength={6}
                    autoFocus
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                    placeholder="• • • • • •"
                    className="w-full py-3.5 px-4 rounded-2xl bg-slate-950 border border-cyan-500/50 focus:border-cyan-400 text-center font-mono text-xl tracking-[0.4em] text-cyan-300 placeholder:text-slate-700 transition-all outline-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleVerifyOtpAndProceed}
                  disabled={otp.length !== 6}
                  className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-pink-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
                >
                  <span>{isExistingAccount ? 'Verify OTP & Log In' : 'Verify & Proceed to Secret ID'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

          </div>
        )}

        {/* ================= STEP 2: CUSTOM SECRET USERNAME ================= */}
        {step === 2 && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Write Your Secret Username
                </label>
                {usernameClean.length >= 3 && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    isUnameAvailable ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {isUnameAvailable ? (
                      <>
                        <Check className="w-3.5 h-3.5" /> Unique & Available
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3.5 h-3.5" /> Username Already Taken!
                      </>
                    )}
                  </span>
                )}
              </div>

              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">
                  @
                </span>
                <input
                  type="text"
                  maxLength={24}
                  value={customUsername}
                  onChange={(e) => setCustomUsername(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                  placeholder="e.g. shadow_tiger, midnight_canteen"
                  className={`w-full pl-8 pr-4 py-3 rounded-2xl bg-slate-950/70 border text-sm font-mono text-slate-100 placeholder:text-slate-600 transition-all outline-none ${
                    usernameClean.length >= 3
                      ? isUnameAvailable 
                        ? 'border-emerald-500/50 focus:border-emerald-400'
                        : 'border-rose-500/50 focus:border-rose-400'
                      : 'border-slate-800 focus:border-purple-500/60'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Kahin bhi 2 students ka same username nahi hoga. System uniqueness enforce karta hai.
              </p>
            </div>

            {/* Secret Avatar Emoji Picker */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Choose Secret Mask Avatar
              </label>
              <div className="grid grid-cols-8 gap-2 p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                {AVATAR_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setSelectedEmoji(emoji)}
                    className={`h-9 rounded-xl flex items-center justify-center text-lg transition-transform hover:scale-115 ${
                      selectedEmoji === emoji 
                        ? 'bg-gradient-to-tr from-purple-600 to-pink-500 text-white shadow-md shadow-pink-500/30 scale-110' 
                        : 'hover:bg-slate-900'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Degree / Branch Info */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Class / Degree / Year
              </label>
              <div className="relative">
                <GraduationCap className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={classInfo}
                  onChange={(e) => setClassInfo(e.target.value)}
                  placeholder="e.g. B.Tech Computer Science '26, B.Com 2nd Year"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-950/70 border border-slate-800 focus:border-purple-500/60 text-xs text-slate-100 placeholder:text-slate-600 outline-none"
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                type="button"
                onClick={handleProceedToCollegeStep}
                disabled={!isUnameValidLength || !isUnameAvailable}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-40"
              >
                <span>Proceed to College Selection</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: STATE -> DISTRICT -> COLLEGE DIRECTORY ================= */}
        {step === 3 && (
          <form onSubmit={handleCollegeFinalSubmit} className="space-y-3.5 animate-in fade-in duration-300">
            
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>Select Your College from India Directory</span>
              </h3>
            </div>

            {/* 1. STATE SELECTION */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                <Map className="w-3 h-3 text-pink-400" />
                <span>Step 1: Choose State *</span>
              </label>
              <select
                required
                value={selectedState}
                onChange={(e) => {
                  setSelectedState(e.target.value);
                  setSelectedDistrict('');
                  setSelectedCollegeItem(null);
                  setIsManualEntry(false);
                }}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-pink-500 text-xs text-slate-100 outline-none"
              >
                <option value="">-- Select State --</option>
                {INDIA_COLLEGES_DATA.map((st) => (
                  <option key={st.state} value={st.state}>
                    {st.state}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. DISTRICT SELECTION (Filtered by State) */}
            {selectedState && (
              <div className="animate-in fade-in">
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Building2 className="w-3 h-3 text-purple-400" />
                  <span>Step 2: Choose District / City *</span>
                </label>
                <select
                  required
                  value={selectedDistrict}
                  onChange={(e) => {
                    setSelectedDistrict(e.target.value);
                    setSelectedCollegeItem(null);
                    setIsManualEntry(false);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-slate-100 outline-none"
                >
                  <option value="">-- Select District in {selectedState} --</option>
                  {availableDistricts.map((d) => (
                    <option key={d.district} value={d.district}>
                      {d.district}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* 3. COLLEGE SELECTION (Filtered by District) */}
            {selectedDistrict && (
              <div className="space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step 3: Select College from List *</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsManualEntry(!isManualEntry);
                      setSelectedCollegeItem(null);
                    }}
                    className="text-[10px] text-cyan-400 hover:underline"
                  >
                    {isManualEntry ? 'Choose from list' : '+ College not listed?'}
                  </button>
                </div>

                {!isManualEntry ? (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {availableColleges.map((col) => {
                      const isSelected = selectedCollegeItem?.id === col.id;
                      const isAlreadyActivated = colleges.some(c => 
                        c.name.trim().toLowerCase() === col.name.trim().toLowerCase()
                      );

                      return (
                        <div
                          key={col.id}
                          onClick={() => setSelectedCollegeItem(col)}
                          className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                            isSelected 
                              ? 'bg-slate-900 border-cyan-400 shadow-md shadow-cyan-500/20' 
                              : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">{col.badge}</span>
                            <div>
                              <p className="text-xs font-bold text-white">{col.name}</p>
                              <p className="text-[10px] text-slate-400">
                                {selectedDistrict}, {selectedState}
                              </p>
                            </div>
                          </div>

                          {isAlreadyActivated ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              Active Campus
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                              Be Founder
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div>
                    <input
                      type="text"
                      required
                      value={manualCollegeName}
                      onChange={(e) => setManualCollegeName(e.target.value)}
                      placeholder="Type your exact college / university name"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-xs text-slate-100 outline-none"
                    />
                  </div>
                )}
              </div>
            )}

            {/* 4. COLLEGE CODE INPUT & STATUS */}
            {chosenCollegeName && (
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2 animate-in fade-in">
                {existingCollege ? (
                  // ALREADY ACTIVATED COLLEGE
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>This college is already active on Secret Gossip!</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Join karne ke liye apna <strong>College Secret Code</strong> daalein:
                    </p>
                    <div className="relative">
                      <KeyRound className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400" />
                      <input
                        type="text"
                        required
                        value={collegePasscode}
                        onChange={(e) => setCollegePasscode(e.target.value.toUpperCase())}
                        placeholder="Enter College Secret Code to join"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs font-mono text-cyan-300 outline-none uppercase"
                      />
                    </div>
                  </div>
                ) : (
                  // NEW COLLEGE ACTIVATION (BECOME ADMIN!)
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
                      <Crown className="w-4 h-4 shrink-0" />
                      <span>You will be the Official College Admin / Founder!</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Aap is college ko pehli baar activate kar rahe hain. Doosre students ke join karne ke liye ek <strong>Secret College Code</strong> set karein:
                    </p>
                    <div className="relative">
                      <KeyRound className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-amber-400" />
                      <input
                        type="text"
                        required
                        value={collegePasscode}
                        onChange={(e) => setCollegePasscode(e.target.value.toUpperCase())}
                        placeholder="Create College Passcode (e.g. DU2026, XAV123)"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-400 text-xs font-mono text-amber-300 outline-none uppercase"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                type="submit"
                disabled={!chosenCollegeName || !collegePasscode.trim() || isSubmitting}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
              >
                {existingCollege ? (
                  <span>Verify Code & Enter Campus 🚀</span>
                ) : (
                  <>
                    <Crown className="w-4 h-4" />
                    <span>Activate College & Enter as Admin 👑</span>
                  </>
                )}
              </button>
            </div>

          </form>
        )}

        {/* Security Footer Pledge */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 text-center">
          <p className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
            <Lock className="w-3 h-3 text-pink-400" />
            <span>Secret Gossip Security · 1 Account Per Phone · 100% Anonymous</span>
          </p>
        </div>

      </div>
    </div>
  );
};
