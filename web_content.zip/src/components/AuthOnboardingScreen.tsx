import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { SecretGossipLogo } from './SecretGossipLogo';
import { ThemeToggle } from './ThemeToggle';
import { GmailSmtpSetupModal } from './GmailSmtpSetupModal';
import { INDIA_COLLEGES_DATA } from '../utils/indiaCollegesData';
import { 
  Lock, 
  Phone, 
  KeyRound, 
  GraduationCap, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft,
  CheckCircle2, 
  AlertCircle,
  Building2,
  Check,
  Send,
  Crown,
  MapPin,
  Map,
  Mail,
  Smartphone,
  UserCheck,
  RefreshCw,
  ExternalLink,
  Inbox,
  ShieldCheck,
  Sun,
  Moon,
  Monitor
} from 'lucide-react';

const AVATAR_EMOJIS = ['🦊', '🐺', '🐱', '🐼', '🦁', '🐯', '🦅', '🦉', '🦄', '🐲', '👻', '🤖', '👾', '🎭', '🔮', '⚡'];

export const AuthOnboardingScreen: React.FC = () => {
  const { 
    registerUser, 
    sendEmailOtp, 
    verifyEmailOtp, 
    activeOtp,
    isUsernameAvailable,
    checkAccountBinding,
    checkAccountExists,
    loginExistingAccount,
    colleges,
    addNewCollege,
    themeMode,
    setThemeMode
  } = useApp();

  // Wizard Steps: 1: Phone & Email + Email OTP, 2: Secret Username & Mask, 3: State -> District -> College
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Tab Mode for Step 1: 'login' vs 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Step 1: Phone & Email
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [showSmtpModal, setShowSmtpModal] = useState(false);

  // Validation States for Phone
  const [phoneTouched, setPhoneTouched] = useState(false);
  const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
  const isPhone10Digits = cleanPhone.length === 10;
  const isPhoneValidIndian = /^[6-9]\d{9}$/.test(cleanPhone);

  // Validation States for Email
  const [emailTouched, setEmailTouched] = useState(false);
  const cleanEmail = email.trim().toLowerCase();
  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail);

  // 1 Phone & 1 Email = 1 Account Policy Detection
  const [isExistingAccount, setIsExistingAccount] = useState(false);
  const [existingAccountUser, setExistingAccountUser] = useState<any>(null);

  // Step 2: Username & Avatar
  const [customUsername, setCustomUsername] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('🦊');
  const [classInfo, setClassInfo] = useState("Student '26");

  // Step 3: State -> District -> College Hierarchy
  const [selectedState, setSelectedState] = useState<string>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedCollegeItem, setSelectedCollegeItem] = useState<{ id: string; name: string; badge: string } | null>(null);
  const [collegePasscode, setCollegePasscode] = useState('');

  // Custom manual college entry (only if institution not found in district)
  const [isManualEntry, setIsManualEntry] = useState(false);
  const [manualCollegeName, setManualCollegeName] = useState('');

  // Status
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Real-time Account Binding Evaluation
  const binding = checkAccountBinding(cleanPhone, cleanEmail);

  // Sync existing account state
  useEffect(() => {
    if (isPhoneValidIndian && isEmailValid) {
      if (binding.status === 'exact_match' && binding.user) {
        setIsExistingAccount(true);
        setExistingAccountUser(binding.user);
      } else {
        setIsExistingAccount(false);
        setExistingAccountUser(null);
      }
    } else {
      setIsExistingAccount(false);
      setExistingAccountUser(null);
    }
  }, [cleanPhone, cleanEmail, isPhoneValidIndian, isEmailValid, binding.status, binding.user]);

  // 1. Send OTP ONLY to Email Address
  const handleSendOtp = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setPhoneTouched(true);
    setEmailTouched(true);

    if (!isPhone10Digits) {
      setErrorMsg('Please enter your 10-digit mobile number.');
      return;
    }
    if (!isPhoneValidIndian) {
      setErrorMsg('Invalid mobile number. Must start with 6, 7, 8, or 9.');
      return;
    }
    if (!cleanEmail || !isEmailValid) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    if (authMode === 'login') {
      if (binding.status === 'phone_taken') {
        setErrorMsg(`This mobile number is registered with email (${binding.maskedEmail}). Please enter your registered email.`);
        return;
      }
      if (binding.status === 'email_taken') {
        setErrorMsg(`This email is registered with phone (${binding.maskedPhone}). Please enter your registered mobile number.`);
        return;
      }
      if (binding.status === 'available') {
        setErrorMsg(`No registered account found with these credentials. Please switch to 'New Registration'.`);
        return;
      }
    } else {
      // Register Mode
      if (binding.status === 'exact_match') {
        setErrorMsg(`An account with these credentials already exists (@${binding.user?.avatarName}). Please switch to 'Sign In'.`);
        return;
      }
      if (binding.status === 'phone_taken') {
        setErrorMsg(`This mobile number is already registered to another account.`);
        return;
      }
      if (binding.status === 'email_taken') {
        setErrorMsg(`This email address is already registered to another account.`);
        return;
      }
    }

    setIsSubmitting(true);
    const res = await sendEmailOtp(cleanEmail, cleanPhone);
    setIsSubmitting(false);

    if (res.success) {
      setOtpSent(true);
      setOtpTimer(30);
      setOtp('');
      setSuccessMsg(`Verification code sent to ${cleanEmail}. Please check the email inbox on your phone.`);

      const interval = setInterval(() => {
        setOtpTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  // 2. Verify Email OTP & Proceed (Login Existing OR Proceed to Step 2)
  const handleVerifyOtpAndProceed = () => {
    setErrorMsg('');
    if (!otp.trim() || otp.trim().length !== 6) {
      setErrorMsg('Please enter the 6-digit verification code sent to your email.');
      return;
    }

    const isValid = verifyEmailOtp(cleanEmail, otp.trim());
    if (!isValid) {
      setErrorMsg('Invalid verification code. Please check your email inbox and enter the 6-digit code.');
      return;
    }

    if (authMode === 'login' || (isExistingAccount && existingAccountUser)) {
      const target = existingAccountUser || binding.user;
      if (target) {
        setSuccessMsg(`Welcome back @${target.avatarName || 'Student'}! Signing you in...`);
        setTimeout(() => {
          loginExistingAccount(target);
        }, 500);
        return;
      }
    }

    // NEW USER: Proceed to Step 2 to choose Unique Secret Username
    setSuccessMsg('Email verified successfully! Choose your secret identity.');
    setTimeout(() => {
      setSuccessMsg('');
      setStep(2);
    }, 500);
  };

  // 3. Username validation check
  const usernameClean = customUsername.trim();
  const isUnameAvailable = isUsernameAvailable(usernameClean);
  const isUnameValidLength = usernameClean.length >= 3;

  const handleProceedToCollegeStep = () => {
    setErrorMsg('');
    if (!isUnameValidLength) {
      setErrorMsg('Secret Username must be at least 3 characters.');
      return;
    }
    if (!isUnameAvailable) {
      setErrorMsg('This secret username is already taken! Please choose another unique name.');
      return;
    }
    setStep(3);
  };

  // Selected State object & available districts
  const currentStateObj = INDIA_COLLEGES_DATA.find(s => s.state === selectedState);
  const availableDistricts = currentStateObj ? currentStateObj.districts : [];
  const currentDistrictObj = availableDistricts.find(d => d.district === selectedDistrict);
  const availableColleges = currentDistrictObj ? currentDistrictObj.colleges : [];

  // Check if chosen college is ALREADY activated on Secret Gossip
  const chosenCollegeName = isManualEntry ? manualCollegeName.trim() : (selectedCollegeItem?.name || '');
  const existingCollege = colleges.find(c => 
    c.name.trim().toLowerCase() === chosenCollegeName.toLowerCase() &&
    (c.district?.toLowerCase() === selectedDistrict.toLowerCase() || c.city.toLowerCase() === selectedDistrict.toLowerCase())
  );

  // 4. Submit College Activation or Join with Code
  const handleCollegeFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!selectedState) {
      setErrorMsg('Please select your State.');
      return;
    }
    if (!selectedDistrict) {
      setErrorMsg('Please select your District / City.');
      return;
    }
    if (!chosenCollegeName) {
      setErrorMsg('Please select your College from the list.');
      return;
    }
    if (!collegePasscode.trim()) {
      setErrorMsg('Please enter your Secret College Passcode.');
      return;
    }

    // CASE 1: College is ALREADY activated on Secret Gossip
    if (existingCollege) {
      if (existingCollege.secretPasscode && existingCollege.secretPasscode.trim().toUpperCase() !== collegePasscode.trim().toUpperCase()) {
        setErrorMsg(`Incorrect Secret Code for "${existingCollege.name}"! Please get the valid code from your college peers or admin.`);
        return;
      }
      setIsSubmitting(true);
      const success = registerUser(
        cleanEmail,
        cleanPhone,
        existingCollege.code,
        classInfo,
        selectedEmoji,
        usernameClean,
        false
      );
      setIsSubmitting(false);
      if (!success) {
        setErrorMsg('Failed to join college. Please try again.');
      }
      return;
    }

    // CASE 2: College is NOT yet activated -> Activate it and become FOUNDER / ADMIN!
    setIsSubmitting(true);
    const res = addNewCollege(
      chosenCollegeName,
      selectedDistrict,
      collegePasscode,
      selectedCollegeItem?.badge || '🏛️',
      selectedState,
      selectedDistrict
    );

    if (!res.success) {
      setIsSubmitting(false);
      setErrorMsg(res.message);
      return;
    }

    if (res.college) {
      const regSuccess = registerUser(
        cleanEmail,
        cleanPhone,
        res.college.code,
        classInfo,
        selectedEmoji,
        usernameClean,
        true // Founder & Admin!
      );
      setIsSubmitting(false);
      if (!regSuccess) {
        setErrorMsg('Error creating account.');
      }
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#05060b] text-slate-100 flex flex-col justify-center items-center p-3 sm:p-6 relative overflow-hidden">
      
      {/* Background Cyber Glow Ambience */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-tr from-pink-600/15 via-purple-600/20 to-cyan-500/15 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container Card */}
      <div className="relative z-10 w-full max-w-lg bg-gradient-to-b from-[#0c0f1d] to-[#070912] border border-slate-800/80 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-purple-950/20 backdrop-blur-xl">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-full flex items-center justify-between mb-4">
            <span className="text-[11px] font-semibold text-slate-400">Appearance Theme:</span>
            <ThemeToggle variant="buttons" className="max-w-[240px]" />
          </div>

          <SecretGossipLogo size="lg" showText={true} />
          
          {/* Multi-step progress indicator */}
          <div className="flex items-center gap-2 mt-4">
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 1 ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Mail className="w-3 h-3" />
              <span>1. Phone & Email</span>
            </div>
            <span className="text-slate-700">→</span>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 2 ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Sparkles className="w-3 h-3" />
              <span>2. Secret ID</span>
            </div>
            <span className="text-slate-700">→</span>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              step === 3 ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'bg-slate-900 text-slate-500'
            }`}>
              <Building2 className="w-3 h-3" />
              <span>3. Campus</span>
            </div>
          </div>
        </div>

        {/* Error / Success Notifications */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-start gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* ================= STEP 1: MOBILE PHONE + EMAIL ================= */}
        {step === 1 && (
          <div className="space-y-4 animate-in fade-in duration-300">
            
            {/* Mode Switcher: Sign In vs New Registration */}
            <div className="grid grid-cols-2 p-1 bg-slate-950/90 border border-slate-800 rounded-2xl mb-1 text-xs font-semibold">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setErrorMsg('');
                  setSuccessMsg('');
                  setOtpSent(false);
                }}
                className={`py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'login'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  setErrorMsg('');
                  setSuccessMsg('');
                  setOtpSent(false);
                }}
                className={`py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'register'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-slate-950 font-bold shadow-md shadow-pink-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>New Registration</span>
              </button>
            </div>

            {/* 1. Phone Number Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-cyan-400" />
                  <span>10-Digit Mobile Number *</span>
                </label>
                {phone.length > 0 && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    isPhoneValidIndian ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {isPhoneValidIndian ? (
                      <>
                        <Check className="w-3 h-3" /> Valid Indian Number
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3 h-3" /> 
                        {cleanPhone.length < 10 ? `${10 - cleanPhone.length} digits left` : 'Must start with 6-9'}
                      </>
                    )}
                  </span>
                )}
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value.replace(/\D/g, ''));
                    setPhoneTouched(true);
                    setOtpSent(false);
                  }}
                  placeholder="e.g. 9876543210"
                  className={`w-full pl-14 pr-4 py-3 rounded-2xl bg-slate-950/70 border text-sm font-mono text-slate-100 placeholder:text-slate-600 transition-all outline-none ${
                    isPhoneValidIndian 
                      ? 'border-emerald-500/50 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-500/30' 
                      : phoneTouched && phone.length > 0
                        ? 'border-amber-500/50 focus:border-amber-400'
                        : 'border-slate-800 focus:border-pink-500/60'
                  }`}
                />
              </div>
            </div>

            {/* 2. Email Address Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-pink-400" />
                  <span>College / Personal Email Address *</span>
                </label>
                {email.length > 0 && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    isEmailValid ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {isEmailValid ? (
                      <>
                        <Check className="w-3 h-3" /> Valid Email
                      </>
                    ) : (
                      'Enter valid email'
                    )}
                  </span>
                )}
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm">
                  @
                </span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setEmailTouched(true);
                    setOtpSent(false);
                  }}
                  placeholder="student@university.edu or student@gmail.com"
                  className={`w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-950/70 border text-sm text-slate-100 placeholder:text-slate-600 transition-all outline-none ${
                    isEmailValid 
                      ? 'border-emerald-500/50 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-500/30' 
                      : emailTouched && email.length > 0
                        ? 'border-amber-500/50 focus:border-amber-400'
                        : 'border-slate-800 focus:border-pink-500/60'
                  }`}
                />
              </div>
            </div>

            {/* Quick Demo Pre-fill Button */}
            {!otpSent && (
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-0.5">
                <span>Demo Account:</span>
                <button
                  type="button"
                  onClick={() => {
                    setPhone('9876543210');
                    setEmail('brahmprakashsingh8@gmail.com');
                    setPhoneTouched(true);
                    setEmailTouched(true);
                    setAuthMode('login');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 underline font-mono text-[11px]"
                >
                  Use Demo: 9876543210 & brahmprakashsingh8@gmail.com
                </button>
              </div>
            )}

            {/* Real-time Account Binding Status Badge */}
            {isPhoneValidIndian && isEmailValid && (
              <div className="animate-in fade-in duration-200">
                {authMode === 'login' && binding.status === 'exact_match' && (
                  <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 flex items-start gap-2.5">
                    <UserCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-cyan-200">
                        Account Matched: @{binding.user?.avatarName} ({binding.user?.collegeName})
                      </div>
                      <div className="text-[11px] text-slate-300 mt-0.5">
                        Click below to receive your login code on your registered email.
                      </div>
                    </div>
                  </div>
                )}
                {authMode === 'login' && binding.status === 'phone_taken' && (
                  <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-2.5 text-xs text-amber-300">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong>Email Mismatch:</strong> This mobile number is registered with email <span className="font-mono underline">{binding.maskedEmail}</span>.
                    </div>
                  </div>
                )}
                {authMode === 'login' && binding.status === 'email_taken' && (
                  <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-2.5 text-xs text-amber-300">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong>Phone Mismatch:</strong> This email address is registered with phone <span className="font-mono underline">{binding.maskedPhone}</span>.
                    </div>
                  </div>
                )}
                {authMode === 'login' && binding.status === 'available' && (
                  <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-2.5 text-xs text-slate-300">
                    <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      No account found with these details. To create a new account, 
                      <button 
                        type="button" 
                        onClick={() => setAuthMode('register')} 
                        className="text-pink-400 underline font-semibold ml-1"
                      >
                        switch to New Registration
                      </button>.
                    </div>
                  </div>
                )}
                {authMode === 'register' && binding.status === 'available' && (
                  <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex items-start gap-2.5 text-xs text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong>Ready to Register:</strong> This mobile number and email are available.
                    </div>
                  </div>
                )}
                {authMode === 'register' && (binding.status === 'exact_match' || binding.status === 'phone_taken' || binding.status === 'email_taken') && (
                  <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-2.5 text-xs text-amber-300">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      These credentials are already registered. Please 
                      <button 
                        type="button" 
                        onClick={() => setAuthMode('login')} 
                        className="text-cyan-400 underline font-semibold ml-1"
                      >
                        Sign In
                      </button>.
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 3. Send OTP Trigger Button (if not sent yet) */}
            {!otpSent && (
              <>
                <button
                  type="button"
                  onClick={handleSendOtp}
                  disabled={!isPhoneValidIndian || !isEmailValid || isSubmitting}
                  className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
                >
                  <Send className="w-4 h-4" />
                  <span>{authMode === 'login' ? 'Send Login Code to Email' : 'Send Verification Code to Email'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowSmtpModal(true)}
                  className="w-full py-2 px-3 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/30 text-slate-400 hover:text-cyan-300 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all mt-1"
                >
                  <Mail className="w-3 h-3 text-cyan-400" />
                  <span>Connect Real Gmail SMTP Dispatch (Live Inbox Delivery)</span>
                </button>
              </>
            )}

            {/* 4. Sent Confirmation Badge */}
            {otpSent && (
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-2.5 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 text-xs font-bold text-white">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Code Sent to Email: {cleanEmail}</span>
                </div>
                
                <p className="text-[11px] text-slate-200 leading-relaxed">
                  A 6-digit security code has been sent to your email address. Please open your Gmail or Mail app on your phone to view the code.
                </p>

                {/* Quick Button to open Mail / Gmail on Phone */}
                <div className="pt-1 flex items-center gap-2">
                  <a
                    href="https://mail.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Gmail</span>
                  </a>
                  <a
                    href={`mailto:${cleanEmail}`}
                    className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-semibold flex items-center gap-1 transition-all"
                  >
                    <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Mail App</span>
                  </a>
                </div>
              </div>
            )}

            {/* 5. 6-Digit OTP Entry */}
            {otpSent && (
              <div className="space-y-2 pt-1 animate-in fade-in duration-300">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Enter 6-Digit Email Code</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={otpTimer > 0}
                    className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 disabled:text-slate-600 transition-colors flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3 h-3 ${otpTimer > 0 ? 'animate-spin' : ''}`} />
                    <span>{otpTimer > 0 ? `Resend in ${otpTimer}s` : 'Resend Code'}</span>
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={6}
                    autoFocus
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••••"
                    className="w-full py-3.5 px-4 rounded-2xl bg-slate-950 border border-cyan-500/50 focus:border-cyan-400 text-center font-mono text-xl tracking-[0.4em] text-cyan-300 placeholder:text-slate-700 transition-all outline-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleVerifyOtpAndProceed}
                  disabled={otp.length !== 6}
                  className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-pink-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
                >
                  <span>{authMode === 'login' || isExistingAccount ? 'Verify Code & Sign In' : 'Verify Code & Continue'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* Instant Assistance if Gmail is delayed */}
                <div className="pt-2 px-1 flex items-center justify-between text-[11px] border-t border-slate-800/60 mt-1">
                  <span className="text-slate-400">Didn't receive code in Gmail?</span>
                  <button
                    type="button"
                    onClick={() => {
                      const codeToFill = activeOtp?.otp || '123456';
                      setOtp(codeToFill);
                      setSuccessMsg(`Verification code auto-filled: ${codeToFill}. Tap Verify to enter.`);
                    }}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold underline"
                  >
                    Tap to Auto-fill Code ({activeOtp?.otp || '123456'})
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= STEP 2: CUSTOM SECRET USERNAME ================= */}
        {step === 2 && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Write Your Secret Username
                </label>
                {usernameClean.length >= 3 && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    isUnameAvailable ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {isUnameAvailable ? (
                      <>
                        <Check className="w-3.5 h-3.5" /> Unique & Available
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3.5 h-3.5" /> Username Already Taken!
                      </>
                    )}
                  </span>
                )}
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">
                  @
                </span>
                <input
                  type="text"
                  maxLength={24}
                  value={customUsername}
                  onChange={(e) => setCustomUsername(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                  placeholder="e.g. shadow_tiger, midnight_canteen"
                  className={`w-full pl-8 pr-4 py-3 rounded-2xl bg-slate-950/70 border text-sm font-mono text-slate-100 placeholder:text-slate-600 transition-all outline-none ${
                    usernameClean.length >= 3
                      ? isUnameAvailable 
                        ? 'border-emerald-500/50 focus:border-emerald-400' 
                        : 'border-rose-500/50 focus:border-rose-400'
                      : 'border-slate-800 focus:border-purple-500/60'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Every secret username is unique across campus. Real identities are never revealed.
              </p>
            </div>

            {/* Secret Avatar Emoji Picker */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Choose Secret Mask Avatar
              </label>
              <div className="grid grid-cols-8 gap-2 p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                {AVATAR_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setSelectedEmoji(emoji)}
                    className={`h-9 rounded-xl flex items-center justify-center text-lg transition-transform hover:scale-115 ${
                      selectedEmoji === emoji 
                        ? 'bg-gradient-to-tr from-purple-600 to-pink-500 text-white shadow-md shadow-pink-500/30 scale-110' 
                        : 'hover:bg-slate-900'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Degree / Branch Info */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Class / Degree / Year
              </label>
              <div className="relative">
                <GraduationCap className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={classInfo}
                  onChange={(e) => setClassInfo(e.target.value)}
                  placeholder="e.g. B.Tech Computer Science '26, B.Com 2nd Year"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-950/70 border border-slate-800 focus:border-purple-500/60 text-xs text-slate-100 placeholder:text-slate-600 outline-none"
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                type="button"
                onClick={handleProceedToCollegeStep}
                disabled={!isUnameValidLength || !isUnameAvailable}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-40"
              >
                <span>Proceed to College Selection</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: STATE -> DISTRICT -> COLLEGE DIRECTORY ================= */}
        {step === 3 && (
          <form onSubmit={handleCollegeFinalSubmit} className="space-y-3.5 animate-in fade-in duration-300">
            
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>Select Your College from India Directory</span>
              </h3>
            </div>

            {/* 1. STATE SELECTION */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                <Map className="w-3 h-3 text-pink-400" />
                <span>Step 1: Choose State *</span>
              </label>
              <select
                required
                value={selectedState}
                onChange={(e) => {
                  setSelectedState(e.target.value);
                  setSelectedDistrict('');
                  setSelectedCollegeItem(null);
                  setIsManualEntry(false);
                }}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-pink-500 text-xs text-slate-100 outline-none"
              >
                <option value="">-- Select State --</option>
                {INDIA_COLLEGES_DATA.map((st) => (
                  <option key={st.state} value={st.state}>
                    {st.state}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. DISTRICT SELECTION (Filtered by State) */}
            {selectedState && (
              <div className="animate-in fade-in">
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Building2 className="w-3 h-3 text-purple-400" />
                  <span>Step 2: Choose District / City *</span>
                </label>
                <select
                  required
                  value={selectedDistrict}
                  onChange={(e) => {
                    setSelectedDistrict(e.target.value);
                    setSelectedCollegeItem(null);
                    setIsManualEntry(false);
                  }}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-slate-100 outline-none"
                >
                  <option value="">-- Select District in {selectedState} --</option>
                  {availableDistricts.map((d) => (
                    <option key={d.district} value={d.district}>
                      {d.district}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* 3. COLLEGE SELECTION (Filtered by District) */}
            {selectedDistrict && (
              <div className="space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step 3: Select College from List *</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsManualEntry(!isManualEntry);
                      setSelectedCollegeItem(null);
                    }}
                    className="text-[10px] text-cyan-400 hover:underline"
                  >
                    {isManualEntry ? 'Choose from list' : '+ College not listed?'}
                  </button>
                </div>

                {!isManualEntry ? (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {availableColleges.map((col) => {
                      const isSelected = selectedCollegeItem?.id === col.id;
                      const isAlreadyActivated = colleges.some(c => 
                        c.name.trim().toLowerCase() === col.name.trim().toLowerCase()
                      );

                      return (
                        <div
                          key={col.id}
                          onClick={() => setSelectedCollegeItem(col)}
                          className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                            isSelected 
                              ? 'bg-slate-900 border-cyan-400 shadow-md shadow-cyan-500/20' 
                              : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">{col.badge}</span>
                            <div>
                              <p className="text-xs font-bold text-white">{col.name}</p>
                              <p className="text-[10px] text-slate-400">
                                {selectedDistrict}, {selectedState}
                              </p>
                            </div>
                          </div>
                          {isAlreadyActivated ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              Active Campus
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                              Be Founder
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div>
                    <input
                      type="text"
                      required
                      value={manualCollegeName}
                      onChange={(e) => setManualCollegeName(e.target.value)}
                      placeholder="Type your exact college / university name"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-xs text-slate-100 outline-none"
                    />
                  </div>
                )}
              </div>
            )}

            {/* 4. COLLEGE CODE INPUT & STATUS */}
            {chosenCollegeName && (
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2 animate-in fade-in">
                {existingCollege ? (
                  // ALREADY ACTIVATED COLLEGE
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>This college is already active on Secret Gossip!</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Enter your <strong>College Secret Passcode</strong> to join campus:
                    </p>
                    <div className="relative">
                      <KeyRound className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400" />
                      <input
                        type="text"
                        required
                        value={collegePasscode}
                        onChange={(e) => setCollegePasscode(e.target.value.toUpperCase())}
                        placeholder="Enter College Secret Code to join"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs font-mono text-cyan-300 outline-none uppercase"
                      />
                    </div>
                  </div>
                ) : (
                  // NEW COLLEGE ACTIVATION (BECOME ADMIN!)
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
                      <Crown className="w-4 h-4 shrink-0" />
                      <span>You will be the Official College Admin / Founder!</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      You are activating this college for the first time. Create a <strong>Secret College Passcode</strong> for other students to join:
                    </p>
                    <div className="relative">
                      <KeyRound className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-amber-400" />
                      <input
                        type="text"
                        required
                        value={collegePasscode}
                        onChange={(e) => setCollegePasscode(e.target.value.toUpperCase())}
                        placeholder="Create College Passcode (e.g. DU2026, XAV123)"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-400 text-xs font-mono text-amber-300 outline-none uppercase"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                type="submit"
                disabled={!chosenCollegeName || !collegePasscode.trim() || isSubmitting}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
              >
                {existingCollege ? (
                  <span>Verify Code & Enter Campus →</span>
                ) : (
                  <>
                    <Crown className="w-4 h-4" />
                    <span>Activate College & Enter as Admin →</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* Security Footer Pledge */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 text-center">
          <p className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
            <Lock className="w-3 h-3 text-pink-400" />
            <span>Secret Gossip • 100% Anonymous & Secure Student Network</span>
          </p>
        </div>

        {/* Powered by saurabh chaudhary Watermark (Center Bottom) */}
        <div className="mt-3 text-center select-none">
          <p 
            style={{ fontFamily: '"Comic Sans MS", "Comic Sans", cursive, sans-serif' }}
            className="text-[11px] text-slate-500/70 tracking-wide font-normal inline-block"
          >
            Powered by saurabh chaudhary
          </p>
        </div>
      </div>

      {/* Outer Center Bottom Watermark */}
      <div className="mt-3 text-center select-none z-10">
        <span 
          style={{ fontFamily: '"Comic Sans MS", "Comic Sans", cursive, sans-serif' }}
          className="text-xs text-slate-500/60 font-medium tracking-wide"
        >
          Powered by saurabh chaudhary
        </span>
      </div>

      {/* Gmail SMTP Dispatch Setup Modal */}
      <GmailSmtpSetupModal
        isOpen={showSmtpModal}
        onClose={() => setShowSmtpModal(false)}
        defaultEmail={cleanEmail || 'brahmprakashsingh8@gmail.com'}
        onConfigSuccess={(userEmail) => {
          setSuccessMsg(`Gmail SMTP activated for ${userEmail}! OTPs will now be delivered live to Gmail.`);
        }}
      />
    </div>
  );
};
