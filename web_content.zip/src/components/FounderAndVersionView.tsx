import React, { useEffect, useState } from 'react';
import {
  Award,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Code2,
  Cpu,
  GitBranch,
  Info,
  Layers,
  ShieldCheck,
  Sparkles,
  User,
  Zap,
} from 'lucide-react';
import { api } from '../services/api.ts';
import type { FounderProfile, VersionMetadata } from '../types.ts';

export const FounderAndVersionView: React.FC = () => {
  const [founder, setFounder] = useState<FounderProfile | null>(null);
  const [versionMeta, setVersionMeta] = useState<VersionMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const [fRes, vRes] = await Promise.all([
          api.getFounderProfile().catch(() => null),
          api.getVersionMetadata().catch(() => null),
        ]);
        if (fRes?.founder) setFounder(fRes.founder);
        if (vRes?.version) setVersionMeta(vRes.version);
      } finally {
        setIsLoading(false);
      }
    };
    fetchMetadata();
  }, []);

  if (isLoading) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center font-mono text-xs text-slate-500">
        Loading Founder Profile & Version Metadata...
      </div>
    );
  }

  return (
    <div id="founder-and-version-pane" className="space-y-6">
      {/* 1. Founder Identity & Profile Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              AP
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  {founder?.name || 'Aaradhy Parmar'}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-[11px] font-mono font-bold">
                  {founder?.preferredAddress || 'Founder Sir'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {founder?.role || 'Founder / Developer / Architect of the JARVIS project'} • {founder?.academicLevel || 'Class 9'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-mono font-semibold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              VERIFIED FOUNDER IDENTITY
            </span>
          </div>
        </div>

        {/* Vision & Principles */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <span className="text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider block mb-2">
              PROJECT VISION
            </span>
            <p className="text-sm font-medium text-slate-800 leading-relaxed">
              &quot;{founder?.projectVision}&quot;
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <span className="text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider block mb-2">
              FOUNDATIONAL PRINCIPLES
            </span>
            <div className="flex flex-wrap gap-2">
              {founder?.projectPrinciples.map((principle, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-800 text-xs font-mono font-semibold shadow-2xs"
                >
                  {principle}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Interests & Domains */}
        <div className="mt-5 pt-4 border-t border-slate-100 space-y-3">
          <div>
            <span className="text-xs font-bold text-slate-700 block mb-2">
              Academic & Technical Focus (Class 9):
            </span>
            <div className="flex flex-wrap gap-2">
              {founder?.interests.map((item, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-900 border border-sky-200 text-xs font-medium"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          <div>
            <span className="text-xs font-bold text-slate-700 block mb-2">
              Long-Term Autonomous Project Domains:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {founder?.longTermInterests.map((item, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-mono"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Version Evolution Engine & Governance */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-purple-50 text-purple-700 border border-purple-200">
                <GitBranch className="w-4 h-4" />
              </span>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                {versionMeta?.productName || 'JARVIS 5.1'} System Evolution Ledger
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Version management is distinct from underlying model providers. Upgrades follow strict validation gates.
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="px-3 py-1 rounded-md bg-purple-50 text-purple-800 border border-purple-200 font-bold">
              VERSION: {versionMeta?.currentVersion}
            </span>
          </div>
        </div>

        {/* Decoupled Architecture Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[11px] font-mono text-slate-500 block mb-1">PRIMARY MODEL ENGINE</span>
            <span className="text-xs font-bold text-slate-800 block">
              {versionMeta?.underlyingArchitecture.primaryModelProvider}
            </span>
          </div>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[11px] font-mono text-slate-500 block mb-1">FALLBACK ENGINE</span>
            <span className="text-xs font-bold text-slate-800 block">
              {versionMeta?.underlyingArchitecture.fallbackProvider}
            </span>
          </div>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-[11px] font-mono text-slate-500 block mb-1">TOOL & SKILL COUNT</span>
            <span className="text-xs font-bold text-slate-800 block">
              {versionMeta?.underlyingArchitecture.registeredToolsCount} Tools / {versionMeta?.underlyingArchitecture.registeredCapabilitiesCount} Capabilities
            </span>
          </div>
        </div>

        {/* Governed Evolution Lifecycle */}
        <div className="mt-5 p-4 rounded-xl bg-sky-50/50 border border-sky-200">
          <span className="text-xs font-mono font-bold text-sky-900 block mb-2.5">
            MANDATORY EVOLUTION LIFECYCLE GATES:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {versionMeta?.evolutionLifecycle.map((stage, idx) => (
              <div
                key={idx}
                className="px-2.5 py-1.5 rounded-lg bg-white border border-sky-200 text-[11px] font-mono text-sky-950 flex items-center gap-1.5 shadow-2xs"
              >
                <ChevronRight className="w-3 h-3 text-sky-600 shrink-0" />
                <span>{stage}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Evolution Milestones */}
        <div className="mt-5 pt-4 border-t border-slate-100">
          <span className="text-xs font-mono font-bold text-slate-700 block mb-3">
            VERIFIED RELEASE LEDGER & CHECKPOINTS:
          </span>
          <div className="space-y-3">
            {versionMeta?.history.map((entry) => (
              <div
                key={entry.version}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-slate-900">
                      JARVIS {entry.version}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {entry.checkpointRef}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {new Date(entry.releaseDate).toLocaleDateString()}
                    </span>
                  </div>
                  <ul className="text-xs text-slate-600 list-disc list-inside space-y-0.5 mt-1">
                    {entry.changelog.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-mono font-semibold text-emerald-700 block">
                    {entry.testsPassedCount} Tests Passed (100%)
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    STATUS: AUDITED & SIGNED
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
