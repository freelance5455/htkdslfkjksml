import React from "react";
import { Plus, Sparkles, X, Wand2 } from "lucide-react";

interface CategoryChipsProps {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  onAddCategory: (newCat: string) => void;
  onRemoveCategory?: (cat: string) => void;
  onAutoOrganize?: () => void;
  countsByCategory: Record<string, number>;
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  onAddCategory,
  onRemoveCategory,
  onAutoOrganize,
  countsByCategory,
}) => {
  const [isAdding, setIsAdding] = React.useState(false);
  const [newCatName, setNewCatName] = React.useState("");

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCatName.trim();
    if (trimmed && !categories.includes(trimmed)) {
      onAddCategory(trimmed);
      onSelectCategory(trimmed);
      setNewCatName("");
      setIsAdding(false);
    }
  };

  return (
    <div className="flex items-center gap-1.5 overflow-x-auto py-1.5 px-0.5 sm:px-1 no-scrollbar w-full">
      {/* 1. Auto-Organize Action Button */}
      {onAutoOrganize && (
        <button
          onClick={onAutoOrganize}
          title="Notları yapay zeka (LLM semantik analiz) ile insan gibi okuyup anlamsal bağlama göre kategorile"
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700/60 whitespace-nowrap transition-all shadow-2xs active:scale-95 cursor-pointer shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse shrink-0" />
          <span>✨ AI<span className="hidden sm:inline"> Semantik</span> Düzenle</span>
        </button>
      )}

      {/* 2. Category Chips List */}
      {categories.map((cat) => {
        const count = countsByCategory[cat] ?? 0;
        const isSelected = selectedCategory === cat;
        const canDelete = cat !== "Tümü" && cat !== "Genel" && onRemoveCategory;

        return (
          <div
            key={cat}
            className={`group relative flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all select-none shrink-0 ${
              isSelected
                ? "bg-teal-700 text-white shadow-sm shadow-teal-700/20"
                : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200/80 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-700/50"
            }`}
          >
            <button
              onClick={() => onSelectCategory(cat)}
              className="flex items-center gap-1.5 cursor-pointer"
            >
              <span>{cat}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  isSelected
                    ? "bg-white/20 text-white"
                    : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
                }`}
              >
                {count}
              </span>
            </button>

            {/* Delete custom category button (only if empty or hovered) */}
            {canDelete && count === 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveCategory(cat);
                }}
                title={`"${cat}" bölümünü kaldır`}
                className="opacity-0 group-hover:opacity-100 p-0.5 ml-0.5 rounded-full hover:bg-black/10 dark:hover:bg-white/20 text-slate-400 hover:text-rose-500 transition-opacity"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        );
      })}

      {/* 3. Add Custom Category Button */}
      {isAdding ? (
        <form onSubmit={handleAddSubmit} className="flex items-center gap-1 shrink-0">
          <input
            type="text"
            autoFocus
            value={newCatName}
            onChange={(e) => setNewCatName(e.target.value)}
            placeholder="Yeni bölüm adı..."
            className="px-2.5 py-1 text-xs bg-white dark:bg-slate-800 border border-teal-500 rounded-full focus:outline-none w-32 text-slate-900 dark:text-white"
          />
          <button
            type="submit"
            className="px-2.5 py-1 text-xs bg-teal-600 text-white rounded-full font-semibold hover:bg-teal-500 cursor-pointer"
          >
            Ekle
          </button>
          <button
            type="button"
            onClick={() => setIsAdding(false)}
            className="px-1.5 py-1 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
          >
            ✕
          </button>
        </form>
      ) : (
        <button
          onClick={() => setIsAdding(true)}
          title="Yeni Bölüm / Kategori Ekle"
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-xs font-medium text-slate-500 dark:text-slate-400 border border-dashed border-slate-300 dark:border-slate-700 hover:border-teal-500 hover:text-teal-600 dark:hover:text-teal-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Yeni Bölüm</span>
        </button>
      )}
    </div>
  );
};
