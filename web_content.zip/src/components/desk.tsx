import { useEffect } from "react";
import { Manuscript } from "@/components/manuscript";
import { MusePanel } from "@/components/muse-panel";
import { StoryRail } from "@/components/story-rail";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { useActiveStory, useDesk, useUi } from "@/lib/desk-store";
import { slugify, storyToMarkdown, storyWords } from "@/lib/story";

export function Desk() {
  const desk = useDesk((state) => state.desk);
  const setDesk = useDesk((state) => state.setDesk);
  const patchStory = useDesk((state) => state.patchStory);
  const story = useActiveStory();
  const focus = useUi((state) => state.focus);
  const setFocus = useUi((state) => state.setFocus);
  const pane = useUi((state) => state.pane);
  const setPane = useUi((state) => state.setPane);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key === "\\") {
        event.preventDefault();
        setFocus(!useUi.getState().focus);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setFocus]);

  if (!story) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-desk text-ink">
        <p className="font-serif text-2xl">Opening the desk…</p>
      </main>
    );
  }

  const words = storyWords(story);

  return (
    <div data-desk={desk} className="flex h-dvh flex-col overflow-hidden bg-desk text-ink">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-3">
        <button
          type="button"
          className="shrink-0 font-serif text-xl italic"
          onClick={() => {
            setFocus(false);
            setPane("write");
          }}
        >
          Vellum
        </button>
        <input
          className="min-w-0 flex-1 bg-transparent font-serif text-lg text-ink outline-none"
          aria-label="Story title"
          value={story.title}
          onChange={(event) => patchStory(story.id, { title: event.target.value })}
        />
        <span className="hidden shrink-0 text-sm tabular-nums text-muted md:inline">
          {words.toLocaleString()} words
        </span>
        <Button
          tone="ghost"
          className="size-11 px-0"
          aria-label={desk === "night" ? "Day desk" : "Night desk"}
          aria-pressed={desk === "night"}
          onClick={() => setDesk(desk === "night" ? "day" : "night")}
        >
          {desk === "night" ? "Day" : "Night"}
        </Button>
        <Button
          tone="ghost"
          className="hidden size-11 px-0 sm:inline-flex"
          aria-label={focus ? "Leave focus" : "Focus mode"}
          aria-pressed={focus}
          onClick={() => setFocus(!focus)}
        >
          {focus ? "Exit" : "Focus"}
        </Button>
        <Button
          tone="ghost"
          className="size-11 px-0"
          aria-label="Download manuscript"
          onClick={() => {
            const blob = new Blob([storyToMarkdown(story)], { type: "text/markdown" });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = `${slugify(story.title)}.md`;
            link.click();
            URL.revokeObjectURL(url);
          }}
        >
          Save
        </Button>
      </header>
      <div className="flex min-h-0 flex-1">
        <StoryRail />
        <Manuscript />
        <MusePanel />
      </div>
      <nav
        className={cn(
          "grid shrink-0 grid-cols-3 border-t border-line bg-desk lg:hidden",
          focus && "hidden",
        )}
        aria-label="Desk sections"
      >
        {(
          [
            ["desk", "Desk"],
            ["write", "Page"],
            ["muse", "Ink"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={cn(
              "min-h-14 text-sm",
              pane === id ? "text-ink" : "text-muted",
            )}
            aria-current={pane === id ? "page" : undefined}
            onClick={() => setPane(id)}
          >
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}
