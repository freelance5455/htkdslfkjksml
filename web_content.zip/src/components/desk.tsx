import type { ReactNode } from "react";

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <section className={`border border-line bg-surface p-4 sm:p-5 ${className}`}>{children}</section>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="font-mono text-xs tracking-widest text-brass uppercase">{children}</p>;
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return <span className="text-sm text-muted">{children}</span>;
}
