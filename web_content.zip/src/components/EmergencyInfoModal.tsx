import React from 'react';
import { X, PhoneCall, AlertTriangle, Shield, Heart } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface EmergencyInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyInfoModal: React.FC<EmergencyInfoModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { t } = useTranslation();

  if (!isOpen) return null;

  const hotlines = [
    {
      country: 'France',
      flag: '🇫🇷',
      items: [
        {
          name: 'Numéro National de Prévention du Suicide',
          number: '3114',
          desc: 'Gratuit, confidentiel, accessible 24h/24 et 7j/7 par des professionnels de santé.',
          urgent: true,
        },
        {
          name: 'SAMU (Urgences Médicales)',
          number: '15',
          desc: 'En cas de détresse vitale immédiate ou d’intoxication médicamenteuse.',
          urgent: true,
        },
        {
          name: '119 - Enfance en Danger',
          number: '119',
          desc: 'Pour tout enfant en situation de danger, maltraitance ou détresse psychologique.',
          urgent: false,
        },
        {
          name: 'Fil Santé Jeunes',
          number: '0 800 235 236',
          desc: 'Pour les jeunes de 12 à 25 ans et leurs parents. Gratuit et anonyme.',
          urgent: false,
        },
      ],
    },
    {
      country: 'Europe',
      flag: '🇪🇺',
      items: [
        {
          name: 'Numéro d’urgence européen',
          number: '112',
          desc: 'Valable dans tous les pays de l’Union Européenne depuis n’importe quel téléphone.',
          urgent: true,
        },
        {
          name: 'Espagne - Línea 024 de atención a la conducta suicida',
          number: '024',
          desc: 'Gratuito, confidencial y disponible 24 horas al día, 365 días al año.',
          urgent: true,
        },
      ],
    },
    {
      country: 'Canada & USA',
      flag: '🇨🇦 🇺🇸',
      items: [
        {
          name: '988 Suicide & Crisis Lifeline',
          number: '988',
          desc: 'Free and confidential 24/7 service by call or text across USA and Canada.',
          urgent: true,
        },
        {
          name: 'Kids Help Phone (Canada)',
          number: '1-800-668-6868',
          desc: 'Text 686868. 24/7 support for kids and youth in English and French.',
          urgent: false,
        },
      ],
    },
    {
      country: 'Belgique & Suisse',
      flag: '🇧🇪 🇨🇭',
      items: [
        {
          name: 'Belgique - Centre de Prévention du Suicide',
          number: '0800 32 123',
          desc: 'Gratuit 24h/24, écoute empathique et bienveillante.',
          urgent: true,
        },
        {
          name: 'Suisse - La Main Tendue',
          number: '143',
          desc: 'Ligne d’aide et d’écoute 24h/24 pour adultes en crise.',
          urgent: true,
        },
        {
          name: 'Suisse - Pro Juventute (Enfants & Jeunes)',
          number: '147',
          desc: 'Conseils et soutien 24/7 pour les enfants, adolescents et leurs familles.',
          urgent: false,
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-100 dark:border-slate-800 flex flex-col my-auto max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-rose-50 dark:bg-rose-950/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-md">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base sm:text-lg">
                {t('emergency.title')}
              </h3>
              <p className="text-xs text-rose-800 dark:text-rose-200 font-medium">
                Vous n'êtes pas seul(e). Des équipes qualifiées sont là pour vous aider gratuitement.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>
              Si vous ou une personne à proximité êtes en danger physique immédiat, appelez sans attendre les secours de votre pays.
            </span>
          </div>

          {hotlines.map((group) => (
            <div key={group.country} className="space-y-3">
              <h4 className="text-sm font-extrabold text-slate-800 dark:text-slate-200 flex items-center gap-2 pb-1 border-b border-slate-100 dark:border-slate-800">
                <span>{group.flag}</span>
                <span>{group.country}</span>
              </h4>

              <div className="space-y-2.5">
                {group.items.map((item) => (
                  <div
                    key={item.name}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {item.name}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {item.desc}
                      </p>
                    </div>

                    <a
                      href={`tel:${item.number.replace(/\s+/g, '')}`}
                      className={`shrink-0 px-3.5 py-1.5 rounded-xl font-extrabold text-xs flex items-center gap-1.5 shadow-2xs transition-transform active:scale-95 ${
                        item.urgent
                          ? 'bg-rose-600 hover:bg-rose-700 text-white'
                          : 'bg-teal-600 hover:bg-teal-700 text-white'
                      }`}
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>{item.number}</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
