import React, { useState, useEffect } from 'react';
import {
  Crown,
  Sparkles,
  Coins,
  Gem,
  Gift,
  Target,
  Bell,
  Settings,
  Plus,
  Play,
  Layers,
  Users,
  Eye,
  Trophy,
  ShoppingCart,
  Briefcase,
  ShieldCheck,
  ChevronLeft,
  DollarSign,
  Mic,
  MicOff,
  Volume2,
  MessageSquare,
  LogOut,
} from 'lucide-react';
import { UserProfile, Friend } from '../types';
import { soundFX } from '../utils/soundEffects';
import { realAudioMic } from '../utils/audioCapture';

interface MainLobbyProps {
  currentUser: UserProfile;
  onOpenGames: () => void;
  onOpenSocial: () => void;
  onOpenCreateRoom: () => void;
  onOpenSpectator: () => void;
  onOpenTournaments: () => void;
  onOpenStore: () => void;
  onOpenInventory: () => void;
  onOpenAdmin: () => void;
  onOpenAuth: () => void;
  onOpenRealMoneyWallet: () => void;
  onStartTarneebMatch: () => void;
  onOpenSupport?: () => void;
  unreadSupportCount?: number;
  onOpenDailyBonus?: () => void;
  onOpenBecomeCashier?: () => void;
  onOpenCashierDesk?: () => void;
  onOpenSecurity?: () => void;
  onLogout?: () => void;
}

export const MainLobby: React.FC<MainLobbyProps> = ({
  currentUser,
  onOpenGames,
  onOpenSocial,
  onOpenCreateRoom,
  onOpenSpectator,
  onOpenTournaments,
  onOpenStore,
  onOpenInventory,
  onOpenAdmin,
  onOpenAuth,
  onOpenRealMoneyWallet,
  onStartTarneebMatch,
  onOpenSupport,
  unreadSupportCount = 0,
  onOpenDailyBonus,
  onOpenBecomeCashier,
  onOpenCashierDesk,
  onOpenSecurity,
  onLogout,
}) => {
  const isOwnerOrAdmin = ['OWNER', 'ADMIN'].includes(currentUser.role);
  const isCashier = currentUser.role === 'CASHIER';
  const isRegularPlayer = currentUser.role === 'PLAYER';

  const todayStr = new Date().toISOString().split('T')[0];
  const isBonusClaimedToday = currentUser.lastDailyBonusClaimDate === todayStr;
  const [activeTab, setActiveTab] = useState<string>('lobby');
  const [invitedFriends, setInvitedFriends] = useState<(Friend | null)[]>([null, null, null]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Real Microphone State in Lobby
  const [isMicOn, setIsMicOn] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [micStatusMsg, setMicStatusMsg] = useState<string | null>(null);
  const [lobbyToast, setLobbyToast] = useState<string | null>(null);

  const showLobbyToast = (msg: string) => {
    setLobbyToast(msg);
    setTimeout(() => setLobbyToast(null), 3500);
  };

  const toggleMic = async () => {
    soundFX.playButtonClick();
    if (isMicOn) {
      realAudioMic.stopMicrophone();
      setIsMicOn(false);
      setIsSpeaking(false);
      setMicLevel(0);
      setMicStatusMsg('تم كتم المايك');
      setTimeout(() => setMicStatusMsg(null), 2000);
    } else {
      setMicStatusMsg('جارِ تفعيل المايك الحي...');
      const res = await realAudioMic.startMicrophone(
        (level) => setMicLevel(level),
        (speaking) => setIsSpeaking(speaking)
      );

      if (res.success) {
        setIsMicOn(true);
        setMicStatusMsg('المايك متصل ويعمل حقيقيًا! تحدث للتجربة 🎙️');
        setTimeout(() => setMicStatusMsg(null), 3000);
      } else {
        setMicStatusMsg('تم تفعيل وضع محاكاة المايك الحي 🎙️');
        setIsMicOn(true);
        setTimeout(() => setMicStatusMsg(null), 3000);
      }
    }
  };

  useEffect(() => {
    return () => {
      if (realAudioMic.isActive()) {
        realAudioMic.stopMicrophone();
      }
    };
  }, []);

  // Active friends list matching screenshot IMG-20261009-WA0000.jpg
  const activeFriends: Friend[] = [
    { id: 'f1', name: 'Player 2', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop', level: 21, status: 'online' },
    { id: 'f2', name: 'Queen', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop', level: 18, status: 'in_room', game: 'طرنيب' },
    { id: 'f3', name: 'King', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&h=100&fit=crop', level: 17, status: 'online' },
    { id: 'f4', name: 'Ace', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop', level: 15, status: 'in_room', game: 'تركس' },
    { id: 'f5', name: 'Joker', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop', level: 13, status: 'busy' },
  ];

  const handleInviteSlot = (index: number) => {
    soundFX.playButtonClick();
    const candidate = activeFriends.find((f) => !invitedFriends.some((inv) => inv?.id === f.id));
    if (candidate) {
      const updated = [...invitedFriends];
      updated[index] = candidate;
      setInvitedFriends(updated);
    } else {
      onOpenSocial();
    }
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundFX.setMuted(!next);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#040806] text-white flex flex-col justify-between select-none">
      {/* Background Dark Felt & Atmosphere matching IMG-20261009-WA0000.jpg */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_#092e1b_0%,_#05180e_50%,_#020905_100%)] opacity-95 pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:28px_28px] opacity-10 pointer-events-none" />

      {/* Floating Lobby Toast Notification */}
      {lobbyToast && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 bg-emerald-950/95 border-2 border-emerald-400 text-emerald-100 text-xs font-bold rounded-2xl shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center gap-2 animate-in fade-in slide-in-from-top-3">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>{lobbyToast}</span>
        </div>
      )}

      {/* ========================================================
          1. TOP BAR (الشريط العلوي)
         ======================================================== */}
      <header className="relative z-20 px-4 py-2.5 bg-[#05110a]/90 backdrop-blur-md border-b border-amber-500/30 flex items-center justify-between">
        {/* Left (Profile Card): In RTL this is on the right, but layout in screenshot places avatar on one edge */}
        <div className="flex items-center gap-3">
          {/* Avatar with Circular Gold Border & Title */}
          <div
            onClick={() => {
              soundFX.playButtonClick();
              onOpenAuth();
            }}
            className={`flex items-center gap-2.5 cursor-pointer bg-[#071d12] hover:bg-[#0a2819] p-1.5 pr-2.5 rounded-2xl border transition-all ${
              isSpeaking
                ? 'border-emerald-400 ring-2 ring-emerald-400 ring-offset-2 ring-offset-black shadow-[0_0_15px_#10b981]'
                : 'border-amber-500/40 shadow-md'
            }`}
          >
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className={`w-11 h-11 rounded-full border-2 object-cover shadow-sm ${
                  isSpeaking ? 'border-emerald-300 scale-105' : 'border-amber-400'
                }`}
              />
              <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-black ${
                isSpeaking ? 'bg-emerald-400 animate-ping' : 'bg-emerald-500'
              }`} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-gray-100">{currentUser.name}</span>
                <span className="text-[10px] text-amber-400 font-mono">ID: {currentUser.id}</span>
                {isSpeaking && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-900 text-emerald-300 font-bold animate-pulse">
                    يتحدث 🎙️
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                  <Crown className="w-3 h-3 text-amber-400" />
                  {currentUser.title}
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-950 text-purple-200 border border-purple-500/40 font-bold">
                  Lv {currentUser.level}
                </span>
              </div>
              {/* XP mini bar */}
              <div className="w-24 h-1 bg-black/60 rounded-full overflow-hidden mt-1">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full"
                  style={{ width: `${(currentUser.xp / currentUser.nextLevelXp) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Center / Currency Badges: Real Cash, Coins, Gems */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* REAL CASH BADGE (النقود الحقيقية المفعلة) */}
          <div
            onClick={() => {
              soundFX.playButtonClick();
              onOpenRealMoneyWallet();
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-[#0c311c] to-[#072414] hover:from-[#114227] border-2 border-emerald-400/90 px-3 py-1.5 rounded-xl cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)] group"
            title="المحفظة النقدية الحقيقية (Real Money USD)"
          >
            <span className="text-base text-emerald-400 group-hover:scale-110 transition-transform">💵</span>
            <div className="flex flex-col text-right leading-none">
              <span className="text-[9px] text-emerald-300 font-bold">نقدي مفعّل</span>
              <span className="font-mono font-black text-amber-300 text-sm">
                ${currentUser.realCashBalance.toLocaleString()}
              </span>
            </div>
            <button className="w-4 h-4 rounded-full bg-emerald-400 text-black flex items-center justify-center font-black text-xs hover:bg-emerald-300">
              +
            </button>
          </div>

          {/* Coins Badge */}
          <div
            onClick={() => {
              soundFX.playButtonClick();
              onOpenStore();
            }}
            className="flex items-center gap-2 bg-[#05160d] hover:bg-[#082214] border border-amber-500/50 px-3 py-1.5 rounded-xl cursor-pointer shadow-inner"
          >
            <span className="text-base text-amber-400">🪙</span>
            <span className="font-mono font-black text-amber-300 text-sm">
              {currentUser.coins.toLocaleString()}
            </span>
            <button className="w-4 h-4 rounded-full bg-amber-500 text-black flex items-center justify-center font-black text-xs hover:bg-amber-400">
              +
            </button>
          </div>

          {/* Gems Badge */}
          <div
            onClick={() => {
              soundFX.playButtonClick();
              onOpenStore();
            }}
            className="flex items-center gap-2 bg-[#05160d] hover:bg-[#082214] border border-emerald-500/50 px-3 py-1.5 rounded-xl cursor-pointer shadow-inner"
          >
            <span className="text-base text-emerald-400">💎</span>
            <span className="font-mono font-black text-emerald-300 text-sm">
              {currentUser.gems.toLocaleString()}
            </span>
            <button className="w-4 h-4 rounded-full bg-emerald-500 text-black flex items-center justify-center font-black text-xs hover:bg-emerald-400">
              +
            </button>
          </div>
        </div>

        {/* Action Icons matching screenshot + Real Mic Audio Toggle */}
        <div className="flex items-center gap-1.5 md:gap-2">
          {/* REAL MICROPHONE TOGGLE & VISUAL EQUALIZER */}
          <div className="relative">
            <button
              onClick={toggleMic}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center text-[10px] min-w-[46px] transition-all ${
                isMicOn
                  ? 'bg-emerald-700 hover:bg-emerald-600 border-emerald-400 text-white shadow-[0_0_15px_#10b981]'
                  : 'bg-[#071a10] hover:bg-[#0c2a1a] border-amber-900/60 text-amber-300'
              }`}
              title={isMicOn ? 'المايك متصل ويعمل حقيقياً' : 'تفعيل المايك الحقيقي'}
            >
              {isMicOn ? (
                <Mic className="w-4 h-4 text-white animate-pulse" />
              ) : (
                <MicOff className="w-4 h-4 text-gray-400" />
              )}
              <span className="mt-0.5 font-bold">
                {isMicOn ? `${micLevel}%` : 'المايك'}
              </span>
            </button>

            {/* Live equalizer wave bars when mic is active */}
            {isMicOn && (
              <div className="absolute -bottom-2.5 inset-x-0 flex items-end justify-center gap-0.5 h-2">
                {[0.4, 0.8, 1, 0.6, 0.3].map((mult, idx) => (
                  <span
                    key={idx}
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                    style={{
                      height: `${Math.max(2, Math.min(8, (micLevel / 100) * 8 * mult))}px`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          {/* Daily Bonus Button */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              if (onOpenDailyBonus) onOpenDailyBonus();
            }}
            className="p-2 rounded-xl bg-gradient-to-b from-[#211604] to-[#0c0801] hover:from-[#362507] hover:to-[#171002] border border-amber-400/90 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[46px] relative shadow-[0_0_15px_rgba(245,158,11,0.3)] transition-all group"
            title="المكافأة اليومية (Daily Bonus)"
          >
            <Sparkles className="w-4 h-4 text-amber-300 group-hover:rotate-45 transition-transform" />
            <span className="mt-0.5 font-black text-amber-200">المكافأة</span>
            {!isBonusClaimedToday && (
              <>
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping border border-black" />
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 border border-black" />
              </>
            )}
          </button>

          {/* Gift */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenSocial();
            }}
            className="p-2 rounded-xl bg-[#071a10] hover:bg-[#0c2a1a] border border-amber-900/60 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[42px]"
            title="هدية"
          >
            <Gift className="w-4 h-4 text-amber-400" />
            <span className="mt-0.5">هدية</span>
          </button>

          {/* Missions */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              showLobbyToast('🎯 المهام اليومية: العب مباراتين طرنيب (+500 كوينز) • ادعُ صديقًا (+50 جوهرة)');
            }}
            className="p-2 rounded-xl bg-[#071a10] hover:bg-[#0c2a1a] border border-amber-900/60 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[42px]"
            title="المهام"
          >
            <Target className="w-4 h-4 text-amber-400" />
            <span className="mt-0.5">المهام</span>
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setNotificationsOpen(!notificationsOpen);
              }}
              className="p-2 rounded-xl bg-[#071a10] hover:bg-[#0c2a1a] border border-amber-900/60 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[42px] relative"
              title="الإشعارات"
            >
              <Bell className="w-4 h-4 text-amber-400" />
              <span className="mt-0.5">الإشعارات</span>
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            </button>

            {notificationsOpen && (
              <div className="absolute left-0 mt-2 w-64 bg-[#07160e] border border-amber-500/50 rounded-xl p-3 shadow-2xl z-50 text-right text-xs space-y-2">
                <div className="font-bold text-amber-300 border-b border-amber-950 pb-1">صندوق الإشعارات</div>
                <div className="p-2 rounded bg-[#040e08] text-gray-300">
                  👑 مرحبًا بك في موسم الملوك! جوائز كبرى بانتظارك.
                </div>
                <div className="p-2 rounded bg-[#040e08] text-gray-300">
                  🎁 أرسل لك أحمد هدية 100 كوينز.
                </div>
              </div>
            )}
          </div>

          {/* Settings */}
          <div className="relative">
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setSettingsOpen(!settingsOpen);
              }}
              className="p-2 rounded-xl bg-[#071a10] hover:bg-[#0c2a1a] border border-amber-900/60 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[42px]"
              title="الإعدادات"
            >
              <Settings className="w-4 h-4 text-amber-400" />
              <span className="mt-0.5">الإعدادات</span>
            </button>

            {settingsOpen && (
              <div className="absolute left-0 mt-2 w-60 bg-[#07160e] border border-amber-500/50 rounded-xl p-3 shadow-2xl z-50 text-right text-xs space-y-2.5">
                <div className="font-bold text-amber-300 border-b border-amber-950 pb-1">إعدادات المنصة</div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">المؤثرات الصوتية:</span>
                  <button
                    onClick={toggleSound}
                    className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                      soundEnabled ? 'bg-emerald-800 text-white' : 'bg-gray-800 text-gray-400'
                    }`}
                  >
                    {soundEnabled ? 'مفعل' : 'مكتوم'}
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">الاتجاه المعتمد:</span>
                  <span className="text-amber-400 font-bold">Landscape (أفقي)</span>
                </div>
                <div className="pt-1 border-t border-amber-950 space-y-1">
                  {isOwnerOrAdmin && (
                    <button
                      onClick={() => {
                        setSettingsOpen(false);
                        onOpenAdmin();
                      }}
                      className="w-full py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded border border-amber-500/40 text-[11px] font-bold flex items-center justify-center gap-1.5"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>لوحة التحكم والإدارة (المالك 👑)</span>
                    </button>
                  )}
                  {isCashier && (
                    <button
                      onClick={() => {
                        setSettingsOpen(false);
                        if (onOpenCashierDesk) onOpenCashierDesk();
                      }}
                      className="w-full py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 rounded border border-emerald-500/40 text-[11px] font-bold flex items-center justify-center gap-1.5"
                    >
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>مكتب الكاشير المعتمد 💼</span>
                    </button>
                  )}
                  {isRegularPlayer && (
                    <button
                      onClick={() => {
                        setSettingsOpen(false);
                        if (onOpenBecomeCashier) onOpenBecomeCashier();
                      }}
                      className="w-full py-1.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-200 rounded border border-amber-500/40 text-[11px] font-bold flex items-center justify-center gap-1.5"
                    >
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>تفعيل حسابي ككاشير 💼</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setSettingsOpen(false);
                      if (onLogout) onLogout();
                      else onOpenAuth();
                    }}
                    className="w-full py-1.5 bg-red-950/40 hover:bg-red-900/60 text-red-300 rounded border border-red-500/40 text-[11px] font-bold flex items-center justify-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5 rotate-180" />
                    <span>تسجيل الخروج من الحساب</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Customer Support Direct Icon */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              if (onOpenSupport) onOpenSupport();
            }}
            className="p-2 rounded-xl bg-gradient-to-b from-[#092b18] to-[#05170d] hover:from-[#0d3b22] hover:to-[#072414] border border-emerald-400/60 text-emerald-200 flex flex-col items-center justify-center text-[10px] min-w-[44px] relative shadow-md transition-all"
            title="دعم العملاء والدردشة المباشرة"
          >
            <MessageSquare className="w-4 h-4 text-emerald-300" />
            <span className="mt-0.5 font-bold text-amber-300">الدعم</span>
            {unreadSupportCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center animate-pulse border border-black">
                {unreadSupportCount}
              </span>
            )}
          </button>

          {/* Become Cashier button for regular players */}
          {isRegularPlayer && (
            <button
              onClick={() => {
                soundFX.playButtonClick();
                if (onOpenBecomeCashier) onOpenBecomeCashier();
              }}
              className="p-2 rounded-xl bg-gradient-to-b from-[#1c1303] to-[#0c0801] hover:from-[#2e2005] border border-amber-400 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[46px] shadow-sm relative group"
              title="تفعيل حسابي إلى كاشير معتمد"
            >
              <Briefcase className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
              <span className="mt-0.5 font-black text-amber-300">كن كاشير</span>
              <span className="absolute -top-1 -right-1 px-1 rounded-full bg-amber-500 text-black text-[8px] font-black animate-pulse">
                جديد
              </span>
            </button>
          )}

          {/* Cashier Desk button for Cashiers */}
          {isCashier && (
            <button
              onClick={() => {
                soundFX.playButtonClick();
                if (onOpenCashierDesk) onOpenCashierDesk();
              }}
              className="p-2 rounded-xl bg-gradient-to-b from-[#092a18] to-[#05170d] hover:from-[#0d3b22] border-2 border-emerald-400 text-emerald-200 flex flex-col items-center justify-center text-[10px] min-w-[46px] shadow-[0_0_15px_rgba(16,185,129,0.3)]"
              title="مكتب الكاشير المعتمد"
            >
              <Briefcase className="w-4 h-4 text-emerald-300 animate-pulse" />
              <span className="mt-0.5 font-black text-amber-300">الكاشير</span>
            </button>
          )}

          {/* Quick Admin Direct Icon - ONLY VISIBLE FOR OWNER/ADMIN (بتطلع بس عندي) */}
          {isOwnerOrAdmin && (
            <button
              onClick={() => {
                soundFX.playButtonClick();
                onOpenAdmin();
              }}
              className="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 flex flex-col items-center justify-center text-[10px] min-w-[42px] transition-all shadow-md"
              title="لوحة الإدارة المركزية (خاص بالمالك)"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span className="mt-0.5 font-bold">الإدارة</span>
            </button>
          )}

          {/* Quick Logout Button */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              if (onLogout) onLogout();
              else onOpenAuth();
            }}
            className="p-2 rounded-xl bg-[#140808] hover:bg-[#200a0a] border border-red-900/60 text-red-300 flex flex-col items-center justify-center text-[10px] min-w-[40px] transition-colors"
            title="تسجيل الخروج من الحساب"
          >
            <LogOut className="w-4 h-4 text-red-400 rotate-180" />
            <span className="mt-0.5 font-bold">خروج</span>
          </button>
        </div>
      </header>

      {/* ========================================================
          2. LOBBY CENTER STAGE (وسط اللوبي)
         ======================================================== */}
      <main className="relative z-10 flex-1 px-4 py-2 flex flex-col md:flex-row items-center justify-between gap-4 overflow-hidden">
        {/* Left Side: "موسم الملوك" Season Card */}
        <div className="w-full md:w-64 bg-gradient-to-b from-[#092518] to-[#04130b] border-2 border-amber-500/40 rounded-2xl p-4 shadow-xl flex flex-col justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-amber-300 text-sm">موسم الملوك</h3>
            </div>
            <div className="text-[11px] text-emerald-400 font-semibold mb-2">
              ينتهي خلال 12 يوم 18 ساعة
            </div>
            <p className="text-xs text-gray-300 leading-relaxed bg-[#05110a] p-2.5 rounded-xl border border-amber-950">
              أكمل 3 مباريات واربح مكافأة الـ VIP الحصرية ونقاط تصنيف مضاعفة!
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-amber-950 flex flex-col gap-2">
            <button
              onClick={() => {
                soundFX.playButtonClick();
                showLobbyToast('👑 موسم الملوك: 50 مستوى تنافسي مع جوائز كوينز وجواهر وسكنات حصرية!');
              }}
              className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 text-black font-extrabold text-xs rounded-xl shadow active:scale-95 transition-transform"
            >
              عرض الحدث
            </button>
            {/* Carousel dots */}
            <div className="flex justify-center gap-1.5 mt-1">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span className="w-1.5 h-1.5 rounded-full bg-gray-600" />
              <span className="w-1.5 h-1.5 rounded-full bg-gray-600" />
            </div>
          </div>
        </div>

        {/* Center: TABEONA Title & 4 Players Table Cards */}
        <div className="flex-1 flex flex-col items-center justify-center max-w-2xl w-full">
          {/* Royal Crown TABEONA Logo Header */}
          <div className="text-center mb-3">
            <div className="flex items-center justify-center gap-1.5 mb-0.5">
              <Crown className="w-7 h-7 text-amber-400 drop-shadow-[0_0_10px_rgba(245,158,11,0.7)]" />
            </div>
            <h1 className="font-cinzel text-3xl md:text-4xl font-black bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent tracking-widest drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
              TABEONA
            </h1>
            <span className="text-xs text-emerald-400 font-bold tracking-wider">
              لعبة الطرنيب
            </span>
          </div>

          {/* 4 Player Slots matching IMG-20261009-WA0000.jpg */}
          <div className="grid grid-cols-4 gap-2 md:gap-3 w-full mb-4">
            {/* Slot 1: You (Player 1) */}
            <div className="bg-gradient-to-b from-[#0e311f] to-[#06180f] border-2 border-amber-400/80 rounded-2xl p-2.5 flex flex-col items-center justify-between text-center shadow-lg relative min-h-[140px]">
              <div className="text-[10px] text-amber-300 font-bold px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40">
                أنت
              </div>
              <div className="relative my-1">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-14 h-14 rounded-full border-2 border-amber-400 object-cover shadow"
                />
                <Crown className="w-4 h-4 text-amber-400 absolute -top-1 -right-1" />
              </div>
              <div>
                <div className="font-bold text-xs text-white truncate max-w-[80px]">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-purple-300 font-bold mt-0.5 flex items-center justify-center gap-1">
                  <span>★</span>
                  <span>Lv {currentUser.level}</span>
                </div>
              </div>
            </div>

            {/* Slots 2, 3, 4: Friends Invitations */}
            {[0, 1, 2].map((slotIdx) => {
              const friend = invitedFriends[slotIdx];
              return (
                <div
                  key={slotIdx}
                  onClick={() => handleInviteSlot(slotIdx)}
                  className="bg-[#05140c]/80 hover:bg-[#071c11] border-2 border-dashed border-amber-900/60 hover:border-amber-500/60 rounded-2xl p-2.5 flex flex-col items-center justify-center text-center cursor-pointer transition-all min-h-[140px]"
                >
                  {friend ? (
                    <>
                      <img
                        src={friend.avatar}
                        alt={friend.name}
                        className="w-12 h-12 rounded-full border border-amber-400 object-cover mb-1"
                      />
                      <div className="font-bold text-xs text-white truncate max-w-[75px]">
                        {friend.name}
                      </div>
                      <div className="text-[10px] text-amber-400">Lv {friend.level}</div>
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-full bg-emerald-950 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-2 shadow-inner">
                        <Plus className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-amber-300/90">دعوة صديق</span>
                    </>
                  )}
                </div>
              );
            })}
          </div>

          {/* Big CTA Button matching IMG-20261009-WA0000.jpg: "العب الآن" (طرنيب • 4 لاعبين) */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onStartTarneebMatch();
            }}
            className="w-full max-w-md py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-700 hover:from-emerald-600 hover:to-emerald-600 border-2 border-amber-400 shadow-[0_0_25px_rgba(16,185,129,0.5)] flex items-center justify-center gap-3 transition-transform active:scale-95 group cursor-pointer"
          >
            <span className="text-2xl group-hover:rotate-12 transition-transform">🃏</span>
            <div className="text-center">
              <div className="font-black text-lg md:text-xl text-amber-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] tracking-wide">
                العب الآن
              </div>
              <div className="text-[11px] text-emerald-100 font-bold">طرنيب • 4 لاعبين</div>
            </div>
            <Play className="w-5 h-5 fill-amber-300 text-amber-300 mr-2" />
          </button>
        </div>

        {/* Right Side: "الأصدقاء المتصلون" Sidebar matching IMG-20261009-WA0000.jpg */}
        <div className="w-full md:w-64 bg-gradient-to-b from-[#092518] to-[#04130b] border-2 border-amber-500/40 rounded-2xl p-3 shadow-xl flex flex-col justify-between shrink-0">
          <div>
            <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-amber-950">
              <h3 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>الأصدقاء المتصلون</span>
              </h3>
              <span className="text-[10px] text-gray-400 font-mono">({activeFriends.length})</span>
            </div>

            <div className="space-y-1.5 max-h-[170px] overflow-y-auto">
              {activeFriends.map((f) => (
                <div
                  key={f.id}
                  className="flex items-center justify-between p-1.5 rounded-lg bg-[#05110a] border border-amber-950/60 hover:border-amber-700/50"
                >
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <img src={f.avatar} alt={f.name} className="w-8 h-8 rounded-full border border-amber-400/80 object-cover" />
                      <span
                        className={`absolute bottom-0 right-0 w-2 h-2 rounded-full border border-black ${
                          f.status === 'online' ? 'bg-emerald-500' : f.status === 'in_room' ? 'bg-amber-500' : 'bg-gray-500'
                        }`}
                      />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-200">{f.name}</div>
                      <div className="text-[9px] text-amber-400">Lv {f.level}</div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundFX.playButtonClick();
                      showLobbyToast(`✉️ تم إرسال دعوة انضمام لطاولة اللعب إلى ${f.name}`);
                    }}
                    className="text-[10px] px-2 py-1 rounded bg-emerald-950 hover:bg-emerald-800 text-emerald-300 border border-emerald-600/40 font-bold"
                  >
                    اتصال
                  </button>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenSocial();
            }}
            className="w-full mt-2 py-1.5 bg-[#071910] hover:bg-[#0c2a1a] text-amber-300 text-xs font-bold rounded-xl border border-amber-900/60"
          >
            عرض الكل
          </button>
        </div>
      </main>

      {/* ========================================================
          3. BOTTOM BAR (الشريط السفلي)
          Strictly 7 items as agreed and illustrated in IMG-20261009-WA0000.jpg:
          1. الألعاب
          2. الاجتماعي
          3. إنشاء غرفة
          4. المشاهدة
          5. البطولات
          6. المتجر
          7. المخزون
         ======================================================== */}
      <nav className="relative z-20 px-2 py-2 bg-[#051009]/95 backdrop-blur-md border-t border-amber-500/40">
        <div className="max-w-5xl mx-auto grid grid-cols-7 gap-1 md:gap-2">
          {/* 1. الألعاب */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenGames();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group"
          >
            <span className="text-xl md:text-2xl group-hover:scale-110 transition-transform">🃏</span>
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">الألعاب</span>
          </button>

          {/* 2. الاجتماعي */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenSocial();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group relative"
          >
            <Users className="w-5 h-5 md:w-6 md:h-6 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">الاجتماعي</span>
            <span className="absolute top-1 right-2 px-1.5 py-0.2 rounded-full bg-red-600 text-white text-[9px] font-bold">
              2
            </span>
          </button>

          {/* 3. إنشاء غرفة */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenCreateRoom();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group relative"
          >
            <Plus className="w-5 h-5 md:w-6 md:h-6 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">إنشاء غرفة</span>
            <span className="absolute top-1 right-2 px-1.5 py-0.2 rounded-full bg-emerald-600 text-white text-[9px] font-bold">
              +
            </span>
          </button>

          {/* 4. المشاهدة */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenSpectator();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group relative"
          >
            <Eye className="w-5 h-5 md:w-6 md:h-6 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">المشاهدة</span>
            <span className="absolute top-1 right-2 px-1.5 py-0.2 rounded-full bg-red-600 text-white text-[9px] font-bold">
              12
            </span>
          </button>

          {/* 5. البطولات */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenTournaments();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group"
          >
            <Trophy className="w-5 h-5 md:w-6 md:h-6 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">البطولات</span>
          </button>

          {/* 6. المتجر */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenStore();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group"
          >
            <ShoppingCart className="w-5 h-5 md:w-6 md:h-6 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">المتجر</span>
          </button>

          {/* 7. المخزون */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onOpenInventory();
            }}
            className="py-2 px-1 rounded-xl bg-gradient-to-b from-[#082215] to-[#04110a] hover:from-[#0d3420] border border-amber-500/30 hover:border-amber-400 flex flex-col items-center justify-center text-center transition-all group"
          >
            <Briefcase className="w-5 h-5 md:w-6 md:h-6 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-amber-200 mt-0.5">المخزون</span>
          </button>
        </div>
      </nav>
    </div>
  );
};
