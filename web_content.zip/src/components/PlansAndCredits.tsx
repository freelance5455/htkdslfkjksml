import React from 'react';
import { 
  BookOpen, 
  FileSpreadsheet, 
  Layers, 
  Megaphone, 
  Film, 
  Check, 
  Zap, 
  Sparkles,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { INITIAL_PLANS } from '../data/mockData';
import { Plan } from '../types';
import { useStore } from '../context/StoreContext';

interface PlansAndCreditsProps {
  onSelectPlanForCheckout: (plan: Plan) => void;
}

export const PlansAndCredits: React.FC<PlansAndCreditsProps> = ({ onSelectPlanForCheckout }) => {
  const { userCredits, purchasePlan, addToast } = useStore();

  const serviceCategories = [
    {
      icon: BookOpen,
      title: 'eBooks',
      description: 'Livros digitais completos com capa, pensados para vender como produto.'
    },
    {
      icon: FileSpreadsheet,
      title: 'Planilhas',
      description: 'Planilhas Excel com fórmulas automáticas — um produto que se vende sozinho.'
    },
    {
      icon: Layers,
      title: 'Capas 3D',
      description: 'Capas e mockups que fazem o produto parecer profissional.'
    },
    {
      icon: Megaphone,
      title: 'Anúncios e banners',
      description: 'Criativos para Facebook, Instagram e TikTok, e banners de checkout que convertem.'
    },
    {
      icon: Film,
      title: 'Anúncios em vídeo e VSL',
      description: 'Avatar a falar a tua oferta, com a tua voz ou voz de IA.'
    }
  ];

  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      
      {/* Title & Introduction matching screenshot 1 & 6 */}
      <div className="space-y-2">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Planos e créditos
          </h1>
          <div className="flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
            <span>Saldo Atual:</span>
            <span className="font-mono font-bold text-sm text-emerald-700">
              {userCredits} créditos
            </span>
          </div>
        </div>
        <p className="text-xs sm:text-sm text-slate-600">
          Para usar o EscaleBuilder precisas de um plano. Escolhe um abaixo para começar a criar.
        </p>
      </div>

      {/* Service capabilities cards matching screenshot 1 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {serviceCategories.map((service, index) => {
          const Icon = service.icon;
          return (
            <div 
              key={index}
              className="p-4 rounded-xl bg-white border border-slate-200/90 shadow-xs flex items-start gap-3"
            >
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 shrink-0">
                <Icon className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-900">{service.title}</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">{service.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Credit Explanation callout block matching screenshot 1 */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed space-y-1">
        <p>
          Um só saldo de créditos para tudo: eBooks, planilhas, capas, anúncios, áudio e vídeo. Antes de cada geração mostramos quantos créditos vai gastar — tu decides se avanças. Para VSL com mais de 15 min, recomendamos gerar só o áudio e editar o vídeo por fora, para poupar créditos.
        </p>
      </div>

      {/* Plans Pricing Grid matching screenshot 1 & 3 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
        {INITIAL_PLANS.map((plan) => {
          const isPro = plan.isPopular;

          // Color tokens tailored to screenshots
          let borderClass = 'border-slate-200 hover:border-slate-300';
          let btnClass = 'bg-slate-600 hover:bg-slate-700 text-white';
          let priceClass = 'text-slate-900';

          if (plan.id === 'plan-start') {
            borderClass = 'border-sky-300 ring-1 ring-sky-200 bg-sky-50/20';
            btnClass = 'bg-sky-500 hover:bg-sky-600 text-white shadow-sky-500/20';
            priceClass = 'text-sky-600';
          } else if (plan.id === 'plan-basico') {
            borderClass = 'border-emerald-300 ring-1 ring-emerald-200 bg-emerald-50/20';
            btnClass = 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20';
            priceClass = 'text-emerald-700';
          } else if (plan.id === 'plan-pro') {
            borderClass = 'border-purple-400 ring-2 ring-purple-300 bg-purple-50/20';
            btnClass = 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-600/20';
            priceClass = 'text-purple-700';
          }

          return (
            <div 
              key={plan.id}
              className={`relative rounded-2xl bg-white border p-6 flex flex-col justify-between shadow-xs transition-all duration-200 ${borderClass}`}
            >
              {/* Popular Tag for PRO plan */}
              {isPro && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-purple-600 text-white text-[10px] font-bold tracking-wider uppercase shadow-xs">
                  Mais Escolhido
                </div>
              )}

              <div className="space-y-4">
                {/* Plan Header */}
                <div>
                  <h3 className="text-base font-bold text-slate-900">{plan.name}</h3>
                  <div className="mt-2 flex items-baseline gap-1">
                    <span className={`text-3xl font-extrabold font-mono tracking-tight ${priceClass}`}>
                      {plan.price}MT
                    </span>
                    <span className="text-xs text-slate-500 font-medium">/único</span>
                  </div>
                  <div className="text-xs font-semibold text-emerald-700 mt-1">
                    {plan.credits} créditos (+{plan.bonusCredits} de bónus)
                  </div>
                </div>

                {/* Feature List matching bullet points in screenshot */}
                <ul className="space-y-2.5 pt-2 text-xs text-slate-600 border-t border-slate-100">
                  {plan.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 leading-snug">
                      <span className="text-slate-400 mt-0.5">•</span>
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Purchase Button */}
              <div className="pt-6 mt-6 border-t border-slate-100">
                <button
                  onClick={() => onSelectPlanForCheckout(plan)}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ${btnClass}`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Comprar créditos</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Assurance Footer */}
      <div className="p-4 rounded-xl bg-slate-900 text-white text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>Créditos vitalícios sem prazo de validade. Recarrega quando precisares via M-Pesa ou e-Mola.</span>
        </div>
        <div className="text-[11px] text-slate-400 whitespace-nowrap">
          Emissão automática de fatura MZN
        </div>
      </div>

    </div>
  );
};
