import React, { useState } from 'react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../translations';
import { Gauge, Sparkles, TrendingUp, AlertTriangle, Lightbulb, CheckCircle2, ArrowRight } from 'lucide-react';

interface ViralityCalculatorTabProps {
  language: LanguageCode;
}

export const ViralityCalculatorTab: React.FC<ViralityCalculatorTabProps> = ({ language }) => {
  const [title, setTitle] = useState('');
  const [niche, setNiche] = useState('YouTube Shorts & Viral Trends');
  const [hook, setHook] = useState('');
  const [format, setFormat] = useState('Shorts (< 60s)');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ score: number; evaluation: string } | null>(null);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || loading) return;

    setLoading(true);
    try {
      const res = await fetch('/api/virality-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, niche, hook, duration: format, language }),
      });
      const data = await res.json();
      setResult({
        score: data.calculatedScore || 85,
        evaluation: data.evaluation || 'Analysis complete.',
      });
    } catch (err) {
      console.error('Score calc failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-400 from-emerald-500 to-cyan-400';
    if (score >= 75) return 'text-cyan-400 from-cyan-500 to-blue-500';
    if (score >= 60) return 'text-amber-400 from-amber-500 to-orange-500';
    return 'text-rose-400 from-rose-500 to-red-500';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Input Form Column */}
      <div className="lg:col-span-5 space-y-4">
        <div className="p-5 rounded-2xl bg-zinc-950/80 border border-white/10 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Gauge className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {t.viralityScoreLabel}
              </h3>
              <p className="text-[11px] text-zinc-400">
                Audits title curiosity, 3-sec retention hook & CTR
              </p>
            </div>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Video Title or Concept *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. 5 Secret AI Websites That Feel Illegal to Know"
                className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Niche / Category
                </label>
                <select
                  value={niche}
                  onChange={e => setNiche(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-200 focus:outline-none focus:border-cyan-500"
                >
                  <option>Shorts & Reels</option>
                  <option>Tech & AI</option>
                  <option>Gaming & Setup</option>
                  <option>Desi Street Food & Vlogs</option>
                  <option>Music & Remixes</option>
                  <option>Comedy & Memes</option>
                  <option>Finance & Motivation</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Format
                </label>
                <select
                  value={format}
                  onChange={e => setFormat(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-200 focus:outline-none focus:border-cyan-500"
                >
                  <option>Shorts (&lt; 60s)</option>
                  <option>Mid-length (3-8 min)</option>
                  <option>Long-form (10-25 min)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                First 3-Second Script Hook (Optional)
              </label>
              <textarea
                rows={2}
                value={hook}
                onChange={e => setHook(e.target.value)}
                placeholder="e.g. Stop scrolling! If you don't delete this app right now..."
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !title.trim()}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-black font-bold text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Auditing Viral Probability...</span>
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4" />
                  <span>{t.calcBtn}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Algorithm Quick Tips Card */}
        <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/5 space-y-2">
          <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span>Algorithmic Golden Rules</span>
          </h4>
          <ul className="text-[11px] text-zinc-400 space-y-1.5 leading-relaxed">
            <li className="flex items-start gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-cyan-400 mt-0.5 shrink-0" />
              <span>Cut out 0.5s of silence at the very start; audio must hit immediately.</span>
            </li>
            <li className="flex items-start gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-cyan-400 mt-0.5 shrink-0" />
              <span>Use a loop hook at the end that connects smoothly back to the opening line.</span>
            </li>
            <li className="flex items-start gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-cyan-400 mt-0.5 shrink-0" />
              <span>Keep text overlays centered so YouTube Shorts buttons don't block them.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Output Results Column */}
      <div className="lg:col-span-7">
        {result ? (
          <div className="p-5 rounded-2xl bg-zinc-950/80 border border-white/10 shadow-xl space-y-4">
            {/* Score Banner */}
            <div className="p-4 rounded-2xl bg-zinc-900/90 border border-white/10 flex items-center justify-between gap-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                  Calculated Virality Potential
                </span>
                <h2 className={`text-4xl font-black bg-gradient-to-r ${getScoreColor(result.score)} bg-clip-text text-transparent mt-0.5`}>
                  {result.score} / 100
                </h2>
                <p className="text-xs text-zinc-300 mt-1">
                  {result.score >= 85
                    ? '🔥 High Breakout Probability! Strong algorithmic appeal.'
                    : '⚡ Moderate Potential. Implement hook recommendations below.'}
                </p>
              </div>

              <div className="w-20 h-20 rounded-full border-4 border-cyan-500/30 flex items-center justify-center p-2 relative shrink-0">
                <div
                  className="w-full h-full rounded-full border-4 border-cyan-400 flex items-center justify-center font-mono font-bold text-sm text-cyan-300 shadow-[0_0_15px_#00ffff]"
                >
                  {result.score}%
                </div>
              </div>
            </div>

            {/* Detailed AI Audit Output */}
            <div className="p-4 rounded-2xl bg-zinc-900/50 border border-white/5 font-sans text-xs text-zinc-300 leading-relaxed space-y-2 whitespace-pre-wrap">
              {result.evaluation}
            </div>
          </div>
        ) : (
          <div className="h-full min-h-[350px] rounded-2xl bg-zinc-950/40 border border-dashed border-white/10 flex flex-col items-center justify-center p-8 text-center text-zinc-500">
            <Gauge className="w-12 h-12 text-zinc-700 mb-3" />
            <h4 className="text-sm font-semibold text-zinc-400 mb-1">
              Ready to Audit Your Video Concept
            </h4>
            <p className="text-xs max-w-sm">
              Enter your title and hook on the left to calculate real-time algorithmic virality probability and get instant upgrades.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
