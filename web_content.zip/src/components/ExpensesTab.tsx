import React, { useState } from 'react';
import {
  Plus,
  Search,
  Receipt,
  Calendar,
  Trash2,
  X,
  Check,
  TrendingDown,
  PieChart,
} from 'lucide-react';
import type { ExpenseItem, ExpenseType } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic } from '../utils/calculations.ts';

interface ExpensesTabProps {
  expenses: ExpenseItem[];
  onAddExpense: (expense: Omit<ExpenseItem, 'id' | 'createdAt'>) => void;
  onDeleteExpense: (id: string) => void;
}

const EXPENSE_TYPES: ExpenseType[] = [
  'نقل وشحن',
  'إيجار المذخر',
  'كهرباء ومولد',
  'رواتب موظفين',
  'ضيافة ونثريات',
  'تالف ومنتهي',
  'صيانة ومعدات',
  'أخرى',
];

export const ExpensesTab: React.FC<ExpensesTabProps> = ({
  expenses,
  onAddExpense,
  onDeleteExpense,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');

  const todayStr = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(todayStr);
  const [type, setType] = useState<ExpenseType>('نقل وشحن');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!val || val <= 0) {
      alert('يرجى إدخال مبلغ صالح للمصروف');
      return;
    }

    onAddExpense({
      date,
      type,
      amount: val,
      note: note.trim(),
    });

    setShowAddModal(false);
    setAmount('');
    setNote('');
  };

  const filtered = expenses
    .filter((e) => {
      const matchSearch =
        !searchQuery ||
        e.note.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.type.toLowerCase().includes(searchQuery.toLowerCase());
      const matchType = selectedType === 'all' || e.type === selectedType;
      return matchSearch && matchType;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.createdAt - a.createdAt);

  const totalExpenses = filtered.reduce((sum, e) => sum + e.amount, 0);

  // Group by type for breakdown
  const typeBreakdown: Record<string, number> = {};
  for (const e of filtered) {
    typeBreakdown[e.type] = (typeBreakdown[e.type] || 0) + e.amount;
  }

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Top Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Receipt className="h-6 w-6 text-amber-600" />
            سجل المصاريف والنثريات
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            توثيق مصاريف النقل والإيجار والرواتب والمولد لحساب صافي الأرباح الحقيقي
          </p>
        </div>

        <button
          onClick={() => {
            setDate(todayStr);
            setShowAddModal(true);
          }}
          className="flex items-center justify-center gap-2 rounded-xl bg-amber-600 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-amber-700 active:scale-98 transition self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          إضافة مصروف جديد
        </button>
      </div>

      {/* Total Card */}
      <div className="rounded-2xl bg-amber-500 p-4 text-white shadow-sm flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-amber-100 flex items-center gap-1">
            <TrendingDown className="h-4 w-4" />
            إجمالي المصاريف المعروضة
          </span>
          <div className="text-2xl font-black mt-1">{formatIQD(totalExpenses)}</div>
        </div>
        <span className="text-xs bg-white/20 px-3 py-1 rounded-full font-bold">
          {filtered.length} قيد مصروف
        </span>
      </div>

      {/* Category Breakdown Badges */}
      <div className="flex flex-wrap gap-1.5 overflow-x-auto pb-1">
        <button
          onClick={() => setSelectedType('all')}
          className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
            selectedType === 'all'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          الكل ({expenses.length})
        </button>
        {EXPENSE_TYPES.map((t) => {
          const count = expenses.filter((e) => e.type === t).length;
          if (count === 0 && selectedType !== t) return null;
          return (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                selectedType === t
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {t} ({count})
            </button>
          );
        })}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="بحث في الملاحظات أو النوع..."
          className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pr-10 pl-3 text-xs placeholder:text-slate-400 focus:border-amber-500 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Expenses List */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-400">
          <Receipt className="mx-auto h-8 w-8 text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">لا توجد مصاريف مطابقة</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-amber-300 transition flex items-center justify-between"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-amber-50 border border-amber-200 px-2 py-0.5 text-xs font-bold text-amber-800">
                    {item.type}
                  </span>
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <Calendar className="h-3 w-3 text-slate-400" />
                    {formatDateArabic(item.date)}
                  </span>
                </div>
                <p className="text-xs text-slate-700 font-medium">{item.note || 'بدون ملاحظات'}</p>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-left font-black text-base text-amber-700">
                  {formatIQD(item.amount)}
                </div>
                <button
                  onClick={() => {
                    if (confirm('هل أنت متأكد من حذف هذا المصروف؟')) {
                      onDeleteExpense(item.id);
                    }
                  }}
                  className="text-slate-400 hover:text-rose-600 p-1 rounded-md transition"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Receipt className="h-5 w-5 text-amber-600" />
                إضافة قيد مصروف جديد
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تاريخ المصروف <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-amber-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  نوع المصروف <span className="text-rose-500">*</span>
                </label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as ExpenseType)}
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold focus:border-amber-500 focus:bg-white focus:outline-hidden"
                >
                  {EXPENSE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  المبلغ (د.ع) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  min="250"
                  step="250"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="مثال: 45000"
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold focus:border-amber-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات وتفاصيل المصروف
                </label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={2}
                  placeholder="مثال: أجور شحن كراتين الدواء، فاتورة بنزين السيارة..."
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-amber-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 rounded-xl bg-amber-600 px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-amber-700 transition"
                >
                  <Check className="h-4 w-4" />
                  حفظ المصروف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
