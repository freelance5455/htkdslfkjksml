import React, { useState } from 'react';
import { Camera, Sparkles, Copy, Check, Bookmark, ShieldCheck, Wand2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PhotoTabProps {
  onSave: (type: 'photo', title: string, subtitle: string, content: string) => void;
  showToast: (msg: string) => void;
}

export const PhotoTab: React.FC<PhotoTabProps> = ({ onSave, showToast }) => {
  const [subject, setSubject] = useState('');
  const [modifications, setModifications] = useState('');
  const [tool, setTool] = useState('Midjourney Vary (Region) Inpaint');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const presets = [
    {
      title: '👑 Royal Gold & Velvet Tuxedo',
      subject:
        '27-year-old handsome African man, neat clean fade haircut, warm deep caramel skin, expressive eyes, warm subtle smile, athletic build',
      mods:
        'Replace casual tee with a tailored midnight purple velvet tuxedo jacket with metallic gold floral lapels, silk bowtie, standing in a luxury marble grand foyer with warm chandelier bokeh',
      tool: 'Midjourney Vary (Region) Inpaint',
    },
    {
      title: '🌅 Sunset Lakeview Portrait',
      subject:
        'Young woman with braided crown hairstyle, glowing sun-kissed skin, natural skin texture, gentle confident gaze',
      mods:
        'Change dull indoor background to a private catamaran sailing on Lake Malawi during golden hour, soft golden breeze blowing hair flyaways, shimmering aqua water reflections',
      tool: 'FLUX.1 Inpainting / Fill',
    },
    {
      title: '💼 Executive Studio Headshot',
      subject:
        'Distinguished 35-year-old gentleman, well-groomed beard, short curly hair, genuine warm expression',
      mods:
        'Change casual polo to charcoal bespoke Italian three-piece suit, crisp white collar, seated in a high-rise Lilongwe corporate corner office with soft morning window light',
      tool: 'Adobe Photoshop Generative Fill',
    },
  ];

  const handleGenerate = async () => {
    if (!subject.trim() || !modifications.trim()) {
      showToast('Please describe both original subject and desired edits');
      return;
    }

    setIsGenerating(true);
    setResult(null);
    setSaved(false);

    try {
      const res = await fetch('/api/photo-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originalSubject: subject,
          requestedEdits: modifications,
          targetEngine: tool,
        }),
      });
      const data = await res.json();

      if (data.result) {
        setResult(data.result);
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 },
            colors: ['#fae48c', '#d4af37', '#10b981'],
          });
        } catch {
          // ignore
        }
      } else {
        showToast(data.error || 'Failed to generate photo editing prompt');
      }
    } catch {
      showToast('Network error while creating prompt');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    showToast('Photo prompts copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!result) return;
    const titleMatch = result.match(/^#\s*(.+)$/m);
    const title = titleMatch ? titleMatch[1].replace(/[*#]/g, '').trim() : 'Face-Safe Retouch';
    onSave('photo', title, `${tool} • ${modifications.slice(0, 30)}...`, result);
    setSaved(true);
    showToast('Saved to your vault!');
  };

  return (
    <div className="p-3.5 space-y-4 max-w-2xl mx-auto">
      {/* Title Card */}
      <div className="bg-[#1b0a33] border border-[#d4af37]/35 rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#d4af37]/15 to-transparent rounded-bl-full pointer-events-none" />

        <div className="flex items-center gap-2 mb-1">
          <ShieldCheck className="w-5 h-5 text-[#fae48c]" />
          <h2 className="royal-heading text-lg font-bold gold-gradient-text">
            Face-Safe Photo Helper
          </h2>
        </div>
        <p className="text-xs text-[#bfaad4] leading-relaxed">
          Preserve natural bone structure, authentic skin tone, and facial identity while swapping clothing, lighting, or backdrops across Midjourney, FLUX, Photoshop, and Stable Diffusion.
        </p>

        {/* Quick Presets */}
        <div className="mt-3 pt-3 border-t border-[#d4af37]/15">
          <label className="text-[10px] tracking-wider uppercase text-[#d4af37] font-semibold block mb-1.5">
            Retouch Presets
          </label>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSubject(preset.subject);
                  setModifications(preset.mods);
                  setTool(preset.tool);
                }}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-[#250f44] border border-[#d4af37]/25 hover:border-[#fae48c] text-[11px] text-[#fae48c] text-left transition-all active:scale-95"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        {/* Inputs */}
        <div className="mt-3.5 space-y-3">
          <div>
            <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
              Original Subject's Features
            </label>
            <textarea
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              rows={2}
              placeholder="e.g. 26-year-old Malawian man, short fade haircut, warm brown skin tone, gentle smile..."
              className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none placeholder-[#8771a3] transition-colors resize-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
              Desired Modifications (Outfit, Scenery, Lighting)
            </label>
            <textarea
              value={modifications}
              onChange={(e) => setModifications(e.target.value)}
              rows={3}
              placeholder="e.g. Change casual t-shirt to an emerald and gold tailored tuxedo, change living room background to a luxury rooftop overlooking city lights at twilight..."
              className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none placeholder-[#8771a3] transition-colors resize-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-1">
              Target AI Inpainting Platform
            </label>
            <select
              value={tool}
              onChange={(e) => setTool(e.target.value)}
              className="w-full bg-[#120524] border border-[#d4af37]/35 focus:border-[#fae48c] text-white text-xs rounded-xl p-2.5 outline-none transition-colors"
            >
              <option value="Midjourney Vary (Region) Inpaint">Midjourney Vary (Region) Inpainting</option>
              <option value="FLUX.1 Inpainting / Fill">FLUX.1 Fill / Inpainting</option>
              <option value="Adobe Photoshop Generative Fill">Adobe Photoshop Generative Fill</option>
              <option value="Stable Diffusion IP-Adapter / ControlNet Face">
                Stable Diffusion (ControlNet FaceID / IP-Adapter)
              </option>
            </select>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !subject.trim() || !modifications.trim()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#fae48c] via-[#d4af37] to-[#8d6f1a] text-[#120422] font-bold text-sm tracking-wide shadow-[0_3px_15px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {isGenerating ? 'Engineering Face-Safe Prompts...' : 'Generate Face-Safe Prompts'}
          </button>
        </div>
      </div>

      {/* Output Card */}
      {result && (
        <div className="bg-[#18082f] border border-[#d4af37]/40 rounded-2xl p-4 shadow-2xl space-y-3 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-[#d4af37]/20 pb-3 flex-wrap gap-2">
            <span className="text-xs uppercase font-bold tracking-widest gold-gradient-text flex items-center gap-1.5">
              <Wand2 className="w-4 h-4 text-[#fae48c]" />
              Face-Locked Retouch Guide
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#240e45] text-xs text-[#fae48c] border border-[#d4af37]/30 hover:bg-[#30125c] transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy All'}</span>
              </button>

              <button
                onClick={handleSave}
                disabled={saved}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#d4af37] text-xs text-[#120422] font-bold hover:brightness-110 transition-colors disabled:opacity-60"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{saved ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>

          <div className="text-[13px] leading-relaxed text-[#eee4f5] whitespace-pre-wrap font-sans bg-[#110424] p-3.5 rounded-xl border border-[#d4af37]/15 overflow-x-auto max-h-[520px] overflow-y-auto">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};
