"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { CATEGORY_ICON, Icon } from "@/components/ui/Icon";
import { Btn, Chip, Field, IconBtn, pushToast, Segmented, Sheet, Toggle } from "@/components/ui/primitives";
import { useApp } from "@/lib/store";
import {
  BILL_CATEGORIES,
  buildIcs,
  currentMonthKey,
  dayLabel,
  downloadText,
  EARN_CATEGORIES,
  googleCalendarUrl,
  monthLabel,
  relativeDay,
  shiftDay,
  SPEND_CATEGORIES,
  todayKey,
} from "@/lib/calendar";
import type { Tx } from "@/lib/types";

/* --------------------------- amount display --------------------------- */

function AmountInput({
  value,
  onChange,
  tone,
  symbol,
}: {
  value: string;
  onChange: (v: string) => void;
  tone: "earn" | "spend";
  symbol: string;
}) {
  return (
    <div
      className="relative flex items-center gap-2 rounded-2xl border px-4 py-3"
      style={{
        borderColor: `color-mix(in oklab, var(--c-${tone}) 40%, transparent)`,
        background: `color-mix(in oklab, var(--c-${tone}) 8%, var(--c-surface2))`,
      }}
    >
      <span className={`font-mono text-[22px] font-semibold`} style={{ color: `var(--c-${tone})` }}>
        {symbol}
      </span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
        inputMode="decimal"
        placeholder="0.00"
        className="tnum w-full bg-transparent font-display text-[34px] font-extrabold leading-none tracking-[-0.03em] outline-none placeholder:text-ink3/50"
      />
    </div>
  );
}

/* --------------------------- add / edit entry -------------------------- */

export function AddEntrySheet() {
  const { addSheet, closeAdd, addTx, updateTx, deleteTx, askConfirm, currency, money, profile } =
    useApp();
  const editing = addSheet.tx;
  const [kind, setKind] = useState<"earn" | "spend">(addSheet.kind);
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [day, setDay] = useState(todayKey());
  const [category, setCategory] = useState<string>("Other");
  const [note, setNote] = useState("");
  const [toCalendar, setToCalendar] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!addSheet.open) return;
    setKind(editing?.kind === "earn" ? "earn" : addSheet.kind);
    setTitle(editing?.title ?? "");
    setAmount(editing ? String(editing.amount) : "");
    setDay(editing?.day ?? addSheet.day ?? todayKey());
    setCategory(editing?.category ?? "Other");
    setNote(editing?.note ?? "");
    setToCalendar(false);
    setError(null);
  }, [addSheet.open, addSheet.kind, addSheet.day, editing]);

  const cats = kind === "earn" ? EARN_CATEGORIES : SPEND_CATEGORIES;
  const numeric = Number(amount);
  const valid = title.trim().length > 0 && Number.isFinite(numeric) && numeric > 0;

  async function save() {
    if (!valid) {
      setError("Add a title and an amount above zero.");
      return;
    }
    const payload = {
      kind,
      title: title.trim(),
      amount: Math.round(numeric * 100) / 100,
      day,
      category,
      note: note.trim() || null,
    };
    if (editing) await updateTx({ ...payload, id: editing.id });
    else await addTx(payload);

    if (toCalendar) {
      const url = googleCalendarUrl({
        title: `${kind === "earn" ? "💰 Earned" : "💸 Spent"} ${money(payload.amount)} — ${payload.title}`,
        day: payload.day,
        details: `Logged in Keep Tracked \u00b7 Category: ${payload.category}${payload.note ? ` \u00b7 Note: ${payload.note}` : ""}`,
      });
      window.open(url, "_blank", "noopener,noreferrer");
    }
    closeAdd();
  }

  return (
    <Sheet
      open={addSheet.open}
      onClose={closeAdd}
      title={editing ? "Edit entry" : "New entry"}
      subtitle={editing ? `#${editing.id} · ${dayLabel(editing.day)}` : "earning or spending"}
      footer={
        <div className="flex gap-2">
          {editing ? (
            <IconBtn
              name="trash"
              label="Delete entry"
              tone="danger"
              onClick={() =>
                askConfirm({
                  title: "Delete this entry?",
                  body: `"${editing.title}" will be removed from your ledger, graphs and calendar for good.`,
                  confirmLabel: "Delete",
                  tone: "danger",
                  onConfirm: () => {
                    void deleteTx(editing.id);
                    closeAdd();
                  },
                })
              }
            />
          ) : null}
          <Btn variant="outline" onClick={closeAdd}>
            Cancel
          </Btn>
          <Btn variant={kind === "earn" ? "brand" : "brand"} full icon={editing ? "check" : "plus"} onClick={save}>
            {editing ? "Save changes" : kind === "earn" ? "Log earning" : "Log spending"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4 pb-2 pt-1">
        <Segmented
          id="entry-kind"
          value={kind}
          onChange={(v) => {
            setKind(v);
            setCategory("Other");
          }}
          options={[
            { value: "spend", label: "Spending", icon: "down" },
            { value: "earn", label: "Earning", icon: "up" },
          ]}
        />

        <AmountInput
          value={amount}
          onChange={setAmount}
          tone={kind}
          symbol={currencySymbol(currency)}
        />

        <Field label="Title">
          <input
            className="field font-semibold"
            value={title}
            placeholder={kind === "earn" ? "e.g. March salary" : "e.g. Grocery run"}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={80}
          />
        </Field>

        <div>
          <p className="mb-1.5 font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink3">
            Category
          </p>
          <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
            {cats.map((c) => (
              <Chip
                key={c}
                tone={category === c ? "brand" : kind === "earn" ? "earn" : "spend"}
                active={category === c}
                icon={CATEGORY_ICON[c] ?? "dots"}
                onClick={() => setCategory(c)}
              >
                {c}
              </Chip>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-[1fr_auto] gap-2">
          <Field label="Date">
            <input type="date" className="field font-mono text-[13px]" value={day} max={shiftDay(todayKey(), 365)} onChange={(e) => setDay(e.target.value || todayKey())} />
          </Field>
          <div className="flex items-end gap-2 pb-1">
            <Chip tone="neutral" onClick={() => setDay(todayKey())}>
              Today
            </Chip>
            <Chip tone="neutral" onClick={() => setDay(shiftDay(todayKey(), -1))}>
              Y&apos;day
            </Chip>
          </div>
        </div>

        <Field label="Note (optional)">
          <input
            className="field"
            value={note}
            maxLength={240}
            placeholder="Split with friends, card ending 4417…"
            onChange={(e) => setNote(e.target.value)}
          />
        </Field>

        <button
          type="button"
          onClick={() => setToCalendar((v) => !v)}
          className="press flex w-full items-center gap-3 rounded-2xl border border-line bg-surface p-3.5 text-left"
        >
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-line bg-surface2 text-brandtext">
            <Icon name="calendarPlus" size={17} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display text-[13.5px] font-bold">
              Push to Google Calendar
            </span>
            <span className="block text-[11.5px] leading-snug text-ink2">
              Opens an all-day event on {relativeDay(day)} after saving
            </span>
          </span>
          <Toggle checked={toCalendar} onChange={setToCalendar} label="Push to Google Calendar" />
        </button>

        <AnimatePresence>
          {error ? (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="font-mono text-[11px] uppercase tracking-[0.12em] text-spend"
            >
              {error}
            </motion.p>
          ) : null}
        </AnimatePresence>

        {profile ? (
          <p className="text-center font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
            saving to {profile.username}&apos;s ledger
          </p>
        ) : null}
      </div>
    </Sheet>
  );
}

function currencySymbol(code: string) {
  const map: Record<string, string> = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    INR: "₹",
    LKR: "Rs",
    AUD: "A$",
    CAD: "C$",
    JPY: "¥",
    AED: "د.إ",
    NGN: "₦",
    ZAR: "R",
    BRL: "R$",
    PKR: "₨",
  };
  return map[code] ?? "$";
}

/* ----------------------------- bill editor ----------------------------- */

export function BillEditorSheet() {
  const { billSheet, closeBillEditor, addBill, updateBill, deleteBill, askConfirm } = useApp();
  const bill = billSheet.bill;
  const template = billSheet.template;
  const [name, setName] = useState("");
  const [category, setCategory] = useState<string>("Electricity");
  const [amount, setAmount] = useState("");
  const [dueDay, setDueDay] = useState("5");
  const [startMonth, setStartMonth] = useState(currentMonthKey());
  const [autoCarry, setAutoCarry] = useState(true);
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!billSheet.open) return;
    setName(bill?.name ?? template?.name ?? "");
    setCategory(bill?.category ?? template?.category ?? "Electricity");
    setAmount(bill ? String(bill.amount) : template?.amount ? String(template.amount) : "");
    setDueDay(String(bill?.dueDay ?? template?.dueDay ?? 5));
    setStartMonth(bill?.startMonth ?? currentMonthKey());
    setAutoCarry(bill?.autoCarry ?? true);
    setNote(bill?.note ?? "");
    setError(null);
  }, [billSheet.open, bill, template]);

  const numeric = Number(amount);
  const valid = name.trim().length > 0 && Number.isFinite(numeric) && numeric > 0;

  async function save() {
    if (!valid) {
      setError("Bill needs a name and a monthly amount.");
      return;
    }
    const payload = {
      name: name.trim(),
      category,
      amount: Math.round(numeric * 100) / 100,
      dueDay: Math.min(28, Math.max(1, Number(dueDay) || 1)),
      startMonth,
      autoCarry,
      active: bill?.active ?? true,
      note: note.trim() || null,
    };
    if (bill) await updateBill({ ...payload, id: bill.id });
    else await addBill(payload);
    closeBillEditor();
  }

  return (
    <Sheet
      open={billSheet.open}
      onClose={closeBillEditor}
      title={bill ? "Edit bill" : "Track a new bill"}
      subtitle={bill ? bill.category : "electricity · water · fuel · custom"}
      footer={
        <div className="flex gap-2">
          {bill ? (
            <IconBtn
              name="trash"
              label="Delete bill"
              tone="danger"
              onClick={() =>
                askConfirm({
                  title: "Remove this bill?",
                  body: `${bill.name} and its payment history will be deleted.`,
                  confirmLabel: "Remove",
                  tone: "danger",
                  onConfirm: () => {
                    void deleteBill(bill.id);
                    closeBillEditor();
                  },
                })
              }
            />
          ) : null}
          <Btn variant="outline" onClick={closeBillEditor}>
            Cancel
          </Btn>
          <Btn variant="brand" full icon="check" onClick={save}>
            {bill ? "Save bill" : "Start tracking"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4 pb-2 pt-1">
        <Field label="Bill name">
          <input
            className="field font-semibold"
            value={name}
            placeholder="e.g. Electricity — Colombo"
            maxLength={60}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>

        <div>
          <p className="mb-1.5 font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink3">Type</p>
          <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
            {BILL_CATEGORIES.map((c) => (
              <Chip
                key={c}
                tone="bill"
                active={category === c}
                icon={CATEGORY_ICON[c] ?? "sliders"}
                onClick={() => setCategory(c)}
              >
                {c}
              </Chip>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Monthly amount">
            <input
              className="field tnum font-mono"
              value={amount}
              inputMode="decimal"
              placeholder="0.00"
              onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
            />
          </Field>
          <Field label="Due day" hint="1–28">
            <input
              className="field tnum font-mono"
              value={dueDay}
              inputMode="numeric"
              onChange={(e) => setDueDay(e.target.value.replace(/[^\d]/g, "").slice(0, 2))}
            />
          </Field>
        </div>

        <Field label="Tracking starts from">
          <input
            type="month"
            className="field font-mono text-[13px]"
            value={startMonth}
            max={currentMonthKey()}
            onChange={(e) => setStartMonth(e.target.value || currentMonthKey())}
          />
        </Field>

        <div className="flex items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-3.5">
          <div className="min-w-0">
            <p className="font-display text-[13.5px] font-bold">Roll unpaid balance forward</p>
            <p className="mt-0.5 text-[11.5px] leading-snug text-ink2">
              A half-paid month adds its remainder to next month&apos;s due amount.
            </p>
          </div>
          <Toggle checked={autoCarry} onChange={setAutoCarry} label="Roll unpaid balance" />
        </div>

        <Field label="Note (optional)">
          <input
            className="field"
            value={note}
            maxLength={240}
            placeholder="Account 0021-4478 · auto-debit"
            onChange={(e) => setNote(e.target.value)}
          />
        </Field>

        {error ? (
          <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-spend">{error}</p>
        ) : null}
      </div>
    </Sheet>
  );
}

/* ------------------------------ pay bill ------------------------------- */

export function PayBillSheet() {
  const { paySheet, closePay, payBill, money, currency } = useApp();
  const bill = paySheet.bill;
  const [period, setPeriod] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  const target = useMemo(() => {
    if (!bill) return null;
    return bill.periods.find((p) => p.period === period) ?? bill.current;
  }, [bill, period]);

  useEffect(() => {
    if (!paySheet.open || !bill) return;
    const p = paySheet.period || bill.current.period;
    setPeriod(p);
    const found = bill.periods.find((x) => x.period === p) ?? bill.current;
    setAmount(found.remaining > 0 ? String(found.remaining) : "");
    setNote("");
    setError(null);
  }, [paySheet.open, paySheet.period, bill]);

  if (!bill || !target) return null;
  const numeric = Number(amount);

  async function submit() {
    if (!Number.isFinite(numeric) || numeric <= 0) {
      setError("Enter an amount greater than zero.");
      return;
    }
    await payBill({
      billId: bill!.id,
      period: target!.period,
      amount: Math.round(numeric * 100) / 100,
      note: note.trim() || null,
    });
    closePay();
  }

  const quick = [0.25, 0.5, 1].map((f) => Math.round(target.remaining * f * 100) / 100);

  return (
    <Sheet
      open={paySheet.open}
      onClose={closePay}
      title={`Pay ${bill.name}`}
      subtitle={`${monthLabel(target.period)} · due ${dayLabel(target.dueDay)}`}
      footer={
        <div className="flex gap-2">
          <Btn variant="outline" onClick={closePay}>
            Cancel
          </Btn>
          <Btn variant="brand" full icon="check" onClick={submit}>
            Record {money(numeric || 0)}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4 pb-2 pt-1">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink3">
              {monthLabel(target.period)} statement
            </span>
            <Chip tone={target.status === "paid" ? "earn" : target.status === "partial" ? "bill" : "spend"}>
              {target.status}
            </Chip>
          </div>
          <dl className="divide-y divide-line px-4 text-[13px]">
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-ink2">Base monthly charge</dt>
              <dd className="tnum font-mono">{money(target.baseDue)}</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-ink2">Carried from previous months</dt>
              <dd className={`tnum font-mono ${target.carry > 0 ? "text-bill" : ""}`}>
                {target.carry > 0 ? `+${money(target.carry)}` : money(0)}
              </dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="font-semibold">Total due</dt>
              <dd className="tnum font-mono font-semibold">{money(target.due)}</dd>
            </div>
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-ink2">Already paid</dt>
              <dd className="tnum font-mono text-earn">{money(target.paid)}</dd>
            </div>
            <div className="flex items-center justify-between py-3">
              <dt className="font-display text-[15px] font-bold">Remaining</dt>
              <dd
                className="tnum font-display text-[19px] font-extrabold"
                style={{ color: target.remaining > 0 ? "var(--c-spend)" : "var(--c-earn)" }}
              >
                {money(target.remaining)}
              </dd>
            </div>
          </dl>
        </div>

        <Field label="Period">
          <div className="relative">
            <select
              className="field pr-10 font-mono text-[13px]"
              value={period}
              onChange={(e) => {
                setPeriod(e.target.value);
                const found = bill.periods.find((x) => x.period === e.target.value);
                setAmount(found && found.remaining > 0 ? String(found.remaining) : "");
              }}
            >
              {bill.periods.map((p) => (
                <option key={p.period} value={p.period}>
                  {monthLabel(p.period)} — {p.status} · {money(p.remaining)} left
                </option>
              ))}
            </select>
            <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-ink3">
              <Icon name="chevron" size={16} />
            </span>
          </div>
        </Field>

        <AmountInput value={amount} onChange={setAmount} tone="earn" symbol={currencySymbol(currency)} />

        <div className="flex gap-2">
          {quick.map((q, i) => (
            <Chip key={i} tone="neutral" onClick={() => setAmount(String(q))}>
              {i === 2 ? "Full" : `${Math.round(q / Math.max(0.01, target.remaining) * 100)}%`} · {money(q)}
            </Chip>
          ))}
        </div>

        <Field label="Note (optional)">
          <input
            className="field"
            value={note}
            maxLength={160}
            placeholder="Half payment — rest next week"
            onChange={(e) => setNote(e.target.value)}
          />
        </Field>

        <a
          href={googleCalendarUrl({
            title: `Pay ${bill.name} (${money(target.due)})`,
            day: target.dueDay,
            details: `Keep Tracked bill reminder \u00b7 Due: ${money(target.due)} \u00b7 Remaining: ${money(target.remaining)}`,
          })}
          target="_blank"
          rel="noopener noreferrer"
          className="press flex items-center gap-2.5 rounded-2xl border border-line bg-surface p-3.5"
        >
          <span className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-surface2 text-brandtext">
            <Icon name="google" size={16} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display text-[13.5px] font-bold">
              Set a Google Calendar reminder
            </span>
            <span className="block text-[11.5px] text-ink2">Due {dayLabel(target.dueDay)}</span>
          </span>
          <Icon name="right" size={16} />
        </a>

        {error ? (
          <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-spend">{error}</p>
        ) : null}
      </div>
    </Sheet>
  );
}

/* ------------------------------ receipt -------------------------------- */

export function ReceiptSheet() {
  const { receipt, closeReceipt, openAdd, deleteTx, askConfirm, data, money, profile } = useApp();

  const running = useMemo(() => {
    if (!receipt || !data) return null;
    const asc = [...data.transactions].sort((a, b) =>
      a.day === b.day ? a.id - b.id : a.day.localeCompare(b.day),
    );
    let bal = profile?.startBalance ?? 0;
    let after = bal;
    for (const t of asc) {
      bal += t.kind === "earn" ? t.amount : -t.amount;
      if (t.id === receipt.id) after = bal;
    }
    return after;
  }, [receipt, data, profile?.startBalance]);

  if (!receipt) return null;
  const isEarn = receipt.kind === "earn";
  const ref = `KT-${String(Math.abs(receipt.id)).padStart(6, "0")}`;

  return (
    <Sheet
      open={!!receipt}
      onClose={closeReceipt}
      title="Receipt"
      subtitle={`${ref} · ${relativeDay(receipt.day)}`}
      footer={
        <div className="flex gap-2">
          <IconBtn
            name="trash"
            label="Delete entry"
            tone="danger"
            onClick={() =>
              askConfirm({
                title: "Delete this entry?",
                body: `"${receipt.title}" disappears from every graph, calendar and receipt.`,
                confirmLabel: "Delete",
                tone: "danger",
                onConfirm: () => {
                  void deleteTx(receipt.id);
                  closeReceipt();
                },
              })
            }
          />
          <Btn
            variant="outline"
            icon="edit"
            onClick={() => {
              const tx: Tx = receipt;
              openAdd(isEarn ? "earn" : "spend", { tx });
              closeReceipt();
            }}
          >
            Edit
          </Btn>
          <Btn
            variant="brand"
            full
            icon="download"
            onClick={() => {
              downloadText(
                `${ref}-${receipt.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.ics`,
                buildIcs([
                  {
                    title: `${isEarn ? "Earned" : "Spent"} ${money(receipt.amount)} — ${receipt.title}`,
                    day: receipt.day,
                    description: `Keep Tracked receipt ${ref}. Category ${receipt.category}.`,
                  },
                ]),
                "text/calendar",
              );
              pushToast("Calendar file downloaded");
            }}
          >
            Save .ics
          </Btn>
        </div>
      }
    >
      <div className="receipt mx-auto mb-3 max-w-[340px] px-5 pb-6 pt-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-display text-[17px] font-extrabold uppercase tracking-[0.06em]">
              Keep Tracked
            </p>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink3">
              {profile?.username ?? "ledger"} · personal ledger
            </p>
          </div>
          <span
            className="grid h-11 w-11 place-items-center rounded-2xl border"
            style={{
              borderColor: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 40%, transparent)`,
              color: `var(--c-${isEarn ? "earn" : "spend"})`,
              background: `color-mix(in oklab, var(--c-${isEarn ? "earn" : "spend"}) 12%, transparent)`,
            }}
          >
            <Icon name={CATEGORY_ICON[receipt.category] ?? (isEarn ? "up" : "down")} size={20} />
          </span>
        </div>

        <div className="perf my-4" />

        <p className="text-center font-mono text-[10px] uppercase tracking-[0.2em] text-ink3">
          {isEarn ? "money in" : "money out"}
        </p>
        <p
          className="tnum mt-1 text-center font-display text-[40px] font-extrabold leading-none tracking-[-0.04em]"
          style={{ color: `var(--c-${isEarn ? "earn" : "spend"})` }}
        >
          {isEarn ? "+" : "−"}
          {money(receipt.amount)}
        </p>
        <p className="mt-2 text-center font-display text-[16px] font-bold">{receipt.title}</p>

        <div className="perf my-4" />

        <dl className="space-y-2 font-mono text-[11.5px]">
          <Row k="DATE" v={dayLabel(receipt.day)} />
          <Row k="CATEGORY" v={receipt.category} />
          <Row k="REFERENCE" v={ref} />
          {receipt.note ? <Row k="NOTE" v={receipt.note} /> : null}
          <Row k="BALANCE AFTER" v={running !== null ? money(running) : "—"} />
        </dl>

        <div className="perf my-4" />
        <div className="flex items-center justify-center gap-1 text-ink3">
          {Array.from({ length: 26 }).map((_, i) => (
            <span
              key={i}
              className="block bg-current"
              style={{ width: i % 3 === 0 ? 2 : 1, height: 22, opacity: i % 2 ? 0.85 : 0.4 }}
            />
          ))}
        </div>
        <p className="mt-2 text-center font-mono text-[9px] uppercase tracking-[0.22em] text-ink3">
          thank you · keep tracked
        </p>
      </div>

      <a
        href={googleCalendarUrl({
          title: `${isEarn ? "Earned" : "Spent"} ${money(receipt.amount)} — ${receipt.title}`,
          day: receipt.day,
          details: `Keep Tracked receipt ${ref} \u00b7 Category: ${receipt.category}${receipt.note ? ` \u00b7 Note: ${receipt.note}` : ""}`,
        })}
        target="_blank"
        rel="noopener noreferrer"
        className="press mb-2 flex items-center gap-2.5 rounded-2xl border border-line bg-surface p-3.5"
      >
        <span className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-surface2 text-brandtext">
          <Icon name="google" size={16} />
        </span>
        <span className="flex-1 font-display text-[13.5px] font-bold">
          Add this day to Google Calendar
        </span>
        <Icon name="right" size={16} />
      </a>
    </Sheet>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="shrink-0 tracking-[0.14em] text-ink3">{k}</dt>
      <dd className="min-w-0 flex-1 text-right break-words">{v}</dd>
    </div>
  );
}
