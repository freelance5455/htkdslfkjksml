import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

export function ScreenHeader({
  title,
  subtitle,
  backTo = "/",
}: {
  title: string;
  subtitle: string;
  backTo?: string;
}) {
  return (
    <header className="mb-6">
      <Link
        to={backTo}
        className="mb-4 inline-flex size-11 items-center justify-center rounded-full bg-elevated text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        aria-label="Back"
      >
        <ArrowLeft className="size-5" />
      </Link>
      <h1 className="text-2xl font-semibold tracking-tight text-fg">{title}</h1>
      <p className="mt-1 text-sm leading-relaxed text-muted">{subtitle}</p>
    </header>
  );
}

export function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-xl bg-elevated px-3.5 py-3">
      <span className="shrink-0 text-sm text-muted">{label}</span>
      <span className="text-right text-sm font-medium text-fg tabular-nums">{value}</span>
    </div>
  );
}

export function IconBadge({
  children,
  className = "bg-primary/15 text-primary",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`inline-flex rounded-2xl p-3 ${className}`}>{children}</div>;
}

export function Panel({ children }: { children: ReactNode }) {
  return (
    <section className="rounded-card bg-surface p-5 shadow-[var(--shadow-border)]">{children}</section>
  );
}
