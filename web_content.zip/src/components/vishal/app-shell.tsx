import { Link } from "@tanstack/react-router";
import { Download } from "lucide-react";
import type { ReactNode } from "react";

export function AppShell({ children, peek = false }: { children: ReactNode; peek?: boolean }) {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[minmax(0,26.5rem)_minmax(0,1fr)] lg:gap-10 lg:px-8 lg:py-8">
        <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col bg-bg lg:max-w-none lg:min-h-[44rem] lg:overflow-hidden lg:rounded-[2rem] lg:shadow-[var(--shadow-border),0_24px_80px_rgba(0,0,0,0.45)]">
          {children}
        </div>
        {peek ? (
          <aside className="hidden flex-col justify-center lg:flex">
            <p className="text-sm font-medium uppercase tracking-widest text-primary">Android project</p>
            <h2 className="mt-3 max-w-md text-4xl font-semibold tracking-tight text-fg">
              Vishal Tools, ready for Android Studio.
            </h2>
            <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
              This preview uses your browser. The download is a real Kotlin + Jetpack Compose app
              you can open on your computer and build into an APK.
            </p>
            <Link
              to="/studio"
              className="mt-8 inline-flex h-12 w-fit items-center gap-2 rounded-2xl bg-primary px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <Download className="size-4" />
              Get Android Studio project
            </Link>
          </aside>
        ) : null}
      </div>
    </div>
  );
}

export function ScreenBody({ children }: { children: ReactNode }) {
  return (
    <div className="flex flex-1 flex-col px-5 pb-8 pt-4 lg:px-6 lg:pt-6">{children}</div>
  );
}
