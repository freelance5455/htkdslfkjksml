import React, { useState, useEffect } from 'react';
import { SecuritySettings, AppSettings } from '../../types';
import { AppLockSettingsCard } from '../AppLock';
import { BackupAndSyncSection } from '../BackupAndSync';
import { BackupAndRestoreCard } from '../BackupAndRestore';
import {
  X,
  Lock,
  HardDrive,
  ShieldCheck,
  FolderSync,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

export type SecurityPopupTab = 'app_lock' | 'backup_sync' | 'backup_restore';

interface SecurityPopupMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: SecurityPopupTab;
  securitySettings: SecuritySettings;
  onUpdateSecurity: (newSettings: SecuritySettings) => void;
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onLockNow: () => void;
  isSyncingDrive: boolean;
  syncStatusMsg: string;
  onTriggerSync: () => void;
  onDownloadBackup: () => void;
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  autoSnapshots: { dateStr: string; data: any }[];
  onResetAllData?: () => void;
}

export const SecurityPopupMenuModal: React.FC<SecurityPopupMenuModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'app_lock',
  securitySettings,
  onUpdateSecurity,
  appSettings,
  onUpdateSettings,
  onLockNow,
  isSyncingDrive,
  syncStatusMsg,
  onTriggerSync,
  onDownloadBackup,
  onFileUpload,
  autoSnapshots = [],
  onResetAllData,
}) => {
  const [activeTab, setActiveTab] = useState<SecurityPopupTab>(initialTab);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const modalBg = isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-900 text-slate-100';
  const headerBorder = isLight ? 'border-slate-200' : 'border-slate-800';

  const currentTabInfo = {
    app_lock: {
      title: isEn ? 'Lock & Security' : 'লক ও নিরাপত্তা (Lock & Security)',
      desc: isEn
        ? 'Configure PIN / Pattern protection and auto-lock timers'
        : 'পিন, ৩x৩ প্যাটার্ন লক এবং অটো-লক টাইমার সেটিংস পরিচালনা করুন',
      icon: <Lock className="w-5 h-5" />,
      themeClass: isLight
        ? 'bg-blue-100 text-blue-700 border-blue-200'
        : 'bg-blue-950/60 text-blue-400 border-blue-500/30',
    },
    backup_sync: {
      title: isEn ? 'Backup & Reset' : 'ব্যাকআপ ও রিসেট (Backup & Reset)',
      desc: isEn
        ? 'Offline ledger backup, cloud drive sync & reset data'
        : 'অফলাইন ব্যাকআপ, ক্লাউড অটো-সিঙ্ক ও ডেটা রিসেট',
      icon: <HardDrive className="w-5 h-5" />,
      themeClass: isLight
        ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
        : 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30',
    },
    backup_restore: {
      title: isEn ? 'Backup & Reset' : 'ব্যাকআপ ও রিসেট (Backup & Reset)',
      desc: isEn
        ? 'Offline ledger backup, cloud drive sync & reset data'
        : 'অফলাইন ব্যাকআপ, ক্লাউড অটো-সিঙ্ক ও ডেটা রিসেট',
      icon: <HardDrive className="w-5 h-5" />,
      themeClass: isLight
        ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
        : 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30',
    },
  }[activeTab];

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
      } p-3 sm:p-4 animate-in fade-in duration-200`}
    >
      {/* Click outside backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Dialog Content */}
      <div
        className={`relative z-10 w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl shadow-2xl border ${
          isLight ? 'border-sky-200 bg-white' : 'border-slate-700 bg-slate-900'
        } overflow-hidden animate-in fade-in zoom-in-95 duration-200`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between gap-3 ${headerBorder}`}>
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`p-2.5 rounded-2xl flex items-center justify-center shrink-0 border ${currentTabInfo.themeClass}`}
            >
              {currentTabInfo.icon}
            </div>
            <div className="truncate">
              <h3 className="text-sm sm:text-base font-black tracking-tight truncate">
                {currentTabInfo.title}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {currentTabInfo.desc}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`p-2 rounded-xl transition cursor-pointer shrink-0 ${
              isLight
                ? 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
                : 'hover:bg-slate-800 text-slate-400 hover:text-white'
            }`}
            title={isEn ? 'Close Popup' : 'পপআপ বন্ধ করুন'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Two Main Side-by-Side Menu Buttons: Backup & Restore and Cloud & Sync (Shown for Backup & Reset) */}
        {activeTab !== 'app_lock' && (
          <div className={`p-3 sm:px-5 border-b shrink-0 ${isLight ? 'border-slate-100 bg-slate-50/50' : 'border-slate-800/80 bg-slate-900/40'}`}>
            <div
              className="grid grid-cols-2 gap-2 p-1 rounded-2xl border transition-colors"
              style={{
                backgroundColor: isLight
                  ? `color-mix(in srgb, ${dualAccent.primary.hex} 10%, #ffffff)`
                  : `color-mix(in srgb, ${dualAccent.primary.hex} 12%, #0f172a)`,
                borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 25%, transparent)`,
              }}
            >
              <button
                type="button"
                onClick={() => setActiveTab('backup_restore')}
                id="modal-tab-backup-restore-btn"
                style={
                  activeTab === 'backup_restore'
                    ? {
                        backgroundColor: dualAccent.primary.hex,
                        color: '#ffffff',
                        boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                      }
                    : undefined
                }
                className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'backup_restore'
                    ? 'font-black text-white shadow-md'
                    : isLight
                    ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <HardDrive
                  className="w-4 h-4 shrink-0"
                  style={{ color: activeTab === 'backup_restore' ? '#ffffff' : dualAccent.primary.hex }}
                />
                <span className="truncate">{isEn ? 'Backup & Restore' : 'ব্যাকআপ ও রিস্টোর'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('backup_sync')}
                id="modal-tab-cloud-sync-btn"
                style={
                  activeTab === 'backup_sync'
                    ? {
                        backgroundColor: dualAccent.primary.hex,
                        color: '#ffffff',
                        boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                      }
                    : undefined
                }
                className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'backup_sync'
                    ? 'font-black text-white shadow-md'
                    : isLight
                    ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <FolderSync
                  className="w-4 h-4 shrink-0"
                  style={{ color: activeTab === 'backup_sync' ? '#ffffff' : dualAccent.primary.hex }}
                />
                <span className="truncate">{isEn ? 'Cloud & Sync' : 'ক্লাউড ও সিঙ্ক'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {activeTab === 'app_lock' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <AppLockSettingsCard
                securitySettings={securitySettings}
                onUpdateSecurity={onUpdateSecurity}
                appSettings={appSettings}
                onLockNow={() => {
                  onClose();
                  onLockNow();
                }}
                isPopupView={true}
              />
            </div>
          )}

          {activeTab === 'backup_sync' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <BackupAndSyncSection
                appSettings={appSettings}
                onUpdateSettings={onUpdateSettings}
                isSyncingDrive={isSyncingDrive}
                syncStatusMsg={syncStatusMsg}
                onTriggerSync={onTriggerSync}
                isPopupView={true}
              />
            </div>
          )}

          {activeTab === 'backup_restore' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <BackupAndRestoreCard
                appSettings={appSettings}
                onDownloadBackup={onDownloadBackup}
                onFileUpload={onFileUpload}
                autoSnapshots={autoSnapshots}
                onResetAllData={onResetAllData}
                isPopupView={true}
              />
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className={`p-3 sm:px-5 border-t flex items-center justify-between gap-2 text-xs ${headerBorder} bg-black/5 dark:bg-white/5`}>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>{isEn ? 'End-to-End Encrypted' : 'সম্পূর্ণ সুরক্ষিত ও এনক্রিপ্টেড'}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
              isLight
                ? 'bg-white hover:bg-slate-100 border-slate-300 text-slate-800'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-white'
            }`}
          >
            {isEn ? 'Done / Close' : 'সম্পন্ন / বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
