import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trophy, 
  Gift, 
  Clock, 
  Calendar, 
  ArrowRight,
  HelpCircle,
  Play,
  Hourglass
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizSubmission, UserProfile } from '../types';
import QuizDetailsModal from './QuizDetailsModal';
import QuizAdGateModal from './QuizAdGateModal';
import AllQuizzesModal from './AllQuizzesModal';

interface WeeklyQuizCardProps {
  language: string;
  userProfile?: UserProfile;
  refreshKey?: number;
  onJoinQuiz: (quiz: WeeklyQuiz) => void;
  onViewLeaderboard: (quiz: WeeklyQuiz) => void;
  onViewResult: (quiz: WeeklyQuiz, submission: WeeklyQuizSubmission) => void;
  onOpenAdmin?: () => void;
}

// Fallback high-resolution images for prizes
const PRIZE_FALLBACK_IMAGES = {
  smartphone: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=400&q=80',
  trophy: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=400&q=80',
  penSet: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=400&q=80',
  planner: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=400&q=80',
  watch: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'
};

// Robust parser for quiz start time
function parseQuizStartTime(startDate?: string, startTime?: string): number | null {
  if (!startDate) return null;
  
  // Clean up any parenthesized text e.g. "2026-08-27 (09:00 AM)" -> "2026-08-27"
  let cleanDate = startDate.replace(/\(.*?\)/g, '').trim();
  let cleanTime = (startTime || '09:00 AM').replace(/\(.*?\)/g, '').trim();

  // If cleanDate contains embedded time
  const embeddedTime = startDate.match(/(\d{1,2}:\d{2}\s*(?:AM|PM)?)/i);
  if (embeddedTime && (!startTime || startTime === '09:00 AM')) {
    cleanTime = embeddedTime[1];
  }

  // Parse hours and mins from cleanTime
  let hours = 9;
  let mins = 0;
  const timeMatch = cleanTime.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (timeMatch) {
    hours = parseInt(timeMatch[1], 10);
    mins = parseInt(timeMatch[2], 10);
    const meridiem = timeMatch[3]?.toUpperCase();
    if (meridiem === 'PM' && hours < 12) hours += 12;
    if (meridiem === 'AM' && hours === 12) hours = 0;
  }

  const months: Record<string, string> = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
    'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
  };

  const parts = cleanDate ? cleanDate.split(/[\s-]+/) : [];
  if (Array.isArray(parts) && parts.length >= 3 && parts[0] && parts[1] && parts[2]) {
    let day: number, monthNum: string, year: number;
    if (parts[0].length === 4) {
      // YYYY-MM-DD
      year = parseInt(parts[0], 10);
      const mKey = parts[1].toLowerCase().slice(0, 3);
      monthNum = months[mKey] || parts[1].padStart(2, '0');
      day = parseInt(parts[2], 10);
    } else {
      // DD-MM-YYYY or DD MMM YYYY
      day = parseInt(parts[0], 10);
      const mKey = parts[1].toLowerCase().slice(0, 3);
      monthNum = months[mKey] || parts[1].padStart(2, '0');
      year = parseInt(parts[2], 10);
    }

    if (!isNaN(day) && !isNaN(year)) {
      const iso = `${year}-${monthNum}-${String(day).padStart(2, '0')}T${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:00`;
      const dateObj = new Date(iso);
      if (!isNaN(dateObj.getTime())) {
        return dateObj.getTime();
      }
    }
  }

  const direct = new Date(`${cleanDate} ${cleanTime}`);
  return isNaN(direct.getTime()) ? null : direct.getTime();
}

export default function WeeklyQuizCard({
  language,
  userProfile,
  refreshKey,
  onJoinQuiz,
  onViewLeaderboard,
  onViewResult,
  onOpenAdmin
}: WeeklyQuizCardProps) {
  const [quizzesList, setQuizzesList] = useState<WeeklyQuiz[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedModalQuiz, setSelectedModalQuiz] = useState<WeeklyQuiz | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState<boolean>(false);
  const [showAllQuizzesModal, setShowAllQuizzesModal] = useState<boolean>(false);
  const [showAdGate, setShowAdGate] = useState<boolean>(false);
  const [pendingTakingQuiz, setPendingTakingQuiz] = useState<WeeklyQuiz | null>(null);

  // Live timestamp updated every second so the countdown ticks down smoothly in real-time
  const [currentTimeMs, setCurrentTimeMs] = useState<number>(Date.now());

  const isBn = language === 'bn';
  const userId = userProfile?.name 
    ? `user-${userProfile.name.toLowerCase().replace(/\s+/g, '-')}`
    : 'user-guest';

  // Fetch quizzes from API
  const fetchQuizzes = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/weekly-quizzes/all?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.quizzes && data.quizzes.length > 0) {
          setQuizzesList(data.quizzes);
          return;
        }
      }

      // Fallback
      const fallbackRes = await fetch('/api/weekly-quiz/current');
      if (fallbackRes.ok) {
        const fallbackData = await fallbackRes.json();
        if (fallbackData.quiz) {
          setQuizzesList([fallbackData.quiz]);
        }
      }
    } catch (err) {
      console.warn('Failed to load weekly quizzes:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQuizzes();
  }, [userProfile?.name, refreshKey]);

  // Real-time 1-second countdown interval
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTimeMs(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute effective quizzes with dynamic ticking countdown
  const effectiveQuizzes = useMemo(() => {
    let baseList: WeeklyQuiz[] = quizzesList.length > 0 ? [...quizzesList] : [
      {
        id: 'weekly-quiz-challenge-1',
        weekNumber: 1,
        title: 'Weekly Quiz #1',
        prizeName: 'Smartphone 5g',
        prizeValue: '₹12,999',
        questionCount: 16,
        timeLimit: 15,
        startDate: '2026-08-27',
        startTime: '09:00 AM',
        prizeImage: PRIZE_FALLBACK_IMAGES.smartphone,
        status: 'scheduled'
      },
      {
        id: 'weekly-quiz-challenge-5',
        weekNumber: 5,
        title: 'Weekly Quiz Challenge #5',
        prizeName: 'Premium Notebook Set',
        prizeValue: '₹750',
        questionCount: 20,
        timeLimit: 15,
        startDate: '2026-08-23',
        startTime: '09:00 AM',
        prizeImage: PRIZE_FALLBACK_IMAGES.trophy,
        status: 'ended'
      },
      {
        id: 'weekly-quiz-challenge-6',
        weekNumber: 6,
        title: 'Weekly Quiz Challenge #6',
        prizeName: 'Premium Pen Set',
        prizeValue: '₹500',
        questionCount: 20,
        timeLimit: 15,
        startDate: '2026-08-29',
        startTime: '09:00 AM',
        prizeImage: PRIZE_FALLBACK_IMAGES.penSet,
        status: 'ended'
      }
    ];

    return baseList.map(quiz => {
      const startTimeMs = parseQuizStartTime(quiz.startDate, quiz.startTime);
      let dynamicStatus = quiz.status;
      let remainingSecs = 0;
      let isFutureStart = false;

      if (startTimeMs) {
        const diffMs = startTimeMs - currentTimeMs;
        if (diffMs > 0) {
          remainingSecs = Math.floor(diffMs / 1000);
          isFutureStart = true;
          if (quiz.status === 'scheduled' || quiz.status === 'draft') {
            dynamicStatus = 'scheduled';
          }
        } else {
          // If past start time and was scheduled, make it live
          if (quiz.status === 'scheduled') {
            dynamicStatus = 'live';
          }
        }
      }

      const days = Math.floor(remainingSecs / 86400);
      const hrs = Math.floor((remainingSecs % 86400) / 3600);
      const mins = Math.floor((remainingSecs % 3600) / 60);
      const secs = remainingSecs % 60;

      let countdownString = '';
      if (days > 0) {
        countdownString = `${days}d ${String(hrs).padStart(2, '0')}h ${String(mins).padStart(2, '0')}m ${String(secs).padStart(2, '0')}s`;
      } else {
        countdownString = `${String(hrs).padStart(2, '0')}h ${String(mins).padStart(2, '0')}m ${String(secs).padStart(2, '0')}s`;
      }

      return {
        ...quiz,
        computedStatus: dynamicStatus,
        isFutureStart,
        remainingSecs,
        countdownString
      };
    });
  }, [quizzesList, currentTimeMs]);

  // Open details modal
  const openQuizDetails = (quiz: WeeklyQuiz) => {
    setSelectedModalQuiz(quiz);
    setShowDetailsModal(true);
  };

  // Play quiz handler with Ad-Gate integration
  const handlePlayQuiz = (quiz: WeeklyQuiz) => {
    const hasJoined = (quiz as any)?.hasJoined || 
      (quiz.joinedUserIds && quiz.joinedUserIds.includes(userId));
    const numberOfAds = quiz.numberOfAds ?? (quiz.requireAdsBeforeQuiz !== false ? 2 : 0);

    if (quiz.status === 'live' || (quiz as any).computedStatus === 'live') {
      if (!hasJoined && numberOfAds > 0) {
        setPendingTakingQuiz(quiz);
        setShowAdGate(true);
      } else {
        onJoinQuiz(quiz);
      }
    } else {
      openQuizDetails(quiz);
    }
  };

  return (
    <div id="quiz-challenge-main-section" className="space-y-3">
      
      {/* 🏆 Section Header */}
      <div className="flex items-center justify-between gap-3 px-1">
        <div className="flex items-center gap-2.5">
          <div className="text-2xl drop-shadow-sm">🏆</div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
              <span>{isBn ? 'কুইজ প্রতিযোগিতা' : 'Quiz Challenge'}</span>
            </h2>
            <p className="text-[11px] sm:text-xs text-slate-400 font-medium">
              {isBn ? 'নিজকে যাচাই করুন, আকর্ষণীয় পুরস্কার জিতুন!' : 'Test your skills, win physical prizes!'}
            </p>
          </div>
        </div>

        {/* View All Pill */}
        <button
          type="button"
          onClick={() => setShowAllQuizzesModal(true)}
          className="px-3.5 py-1.5 rounded-full bg-[#241348] hover:bg-[#341b68] border border-[#7c3aed]/50 text-[#c084fc] hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer shrink-0"
        >
          <span>{isBn ? 'সব কুইজ দেখুন' : 'View All'}</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#c084fc]" />
        </button>
      </div>

      {/* 📦 Quizzes Listing (Original Exact Clean Layout) */}
      <div className="space-y-3">
        {effectiveQuizzes.map((quiz, index) => {
          const isLive = quiz.computedStatus === 'live';
          const isScheduled = quiz.computedStatus === 'scheduled' || ((quiz as any).isFutureStart && quiz.status !== 'ended');
          const isEnded = quiz.computedStatus === 'ended' && !(quiz as any).isFutureStart;

          const displayImage = quiz.prizeImage || (
            index === 0 ? PRIZE_FALLBACK_IMAGES.smartphone :
            index === 1 ? PRIZE_FALLBACK_IMAGES.trophy :
            index === 2 ? PRIZE_FALLBACK_IMAGES.penSet :
            PRIZE_FALLBACK_IMAGES.planner
          );

          const remainingSecs = (quiz as any).remainingSecs || 0;
          const showCountdown = isScheduled && remainingSecs > 0;
          const countdownString = (quiz as any).countdownString || '';

          return (
            <div
              key={quiz.id || `quiz-${index}`}
              id={`quiz-card-${quiz.weekNumber || index + 1}`}
              onClick={() => openQuizDetails(quiz as WeeklyQuiz)}
              className="bg-[#0b1222] hover:bg-[#0f172a] border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-lg transition-all duration-200 cursor-pointer"
            >
              <div className="flex items-start gap-3.5">
                
                {/* Left square image with badge */}
                <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-800">
                  {displayImage ? (
                    <img 
                      src={displayImage} 
                      alt={quiz.prizeName || quiz.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-amber-400 bg-slate-900">
                      <Trophy className="w-8 h-8" />
                    </div>
                  )}

                  {/* Status Badge overlay */}
                  <div className="absolute top-1 left-1 z-10">
                    {isLive ? (
                      <span className="bg-emerald-500 text-slate-950 font-black text-[9px] px-1.5 py-0.5 rounded uppercase flex items-center gap-1 shadow">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping"></span>
                        <span>LIVE</span>
                      </span>
                    ) : isScheduled ? (
                      <span className="bg-indigo-600 text-white font-bold text-[9px] px-1.5 py-0.5 rounded uppercase shadow">
                        UPCOMING
                      </span>
                    ) : (
                      <span className="bg-slate-900/90 text-slate-300 font-bold text-[9px] px-1.5 py-0.5 rounded uppercase border border-slate-700">
                        ENDED
                      </span>
                    )}
                  </div>
                </div>

                {/* Right content details */}
                <div className="flex-1 min-w-0 space-y-1">
                  
                  {/* Tag + Price tag */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-indigo-400">
                      {isBn ? `সাপ্তাহিক কুইজ #${quiz.weekNumber || index + 1}` : `Weekly Quiz #${quiz.weekNumber || index + 1}`}
                    </span>

                    {quiz.prizeValue && (
                      <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded">
                        {quiz.prizeValue}
                      </span>
                    )}
                  </div>

                  {/* Quiz Title */}
                  <h3 className="text-sm sm:text-base font-bold text-white leading-snug truncate">
                    {quiz.title || `Weekly Quiz Challenge #${quiz.weekNumber || index + 1}`}
                  </h3>

                  {/* 1st Prize */}
                  {quiz.prizeName && (
                    <div className="text-xs text-amber-300 font-medium flex items-center gap-1.5">
                      <span>🎁 1st Prize: <strong className="text-white font-semibold">{quiz.prizeName}</strong></span>
                    </div>
                  )}

                  {/* Questions & Duration */}
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
                      <span>{quiz.questionCount || quiz.questions?.length || 16} Qs</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>{quiz.timeLimit || 15} Mins</span>
                    </span>
                  </div>

                  {/* Schedule Date */}
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 pt-0.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{quiz.startDate} ({quiz.startTime || '09:00 AM'})</span>
                  </div>

                  {/* ⏳ Real-Time Live Ticking Countdown (যতো সময় যাবে ততো কমবে) */}
                  {showCountdown && (
                    <div className="flex items-center gap-1.5 text-[11px] sm:text-xs font-black text-amber-300 bg-amber-500/10 border border-amber-500/30 px-2 py-1 rounded-lg mt-1 w-fit">
                      <Hourglass className="w-3.5 h-3.5 text-amber-400 animate-spin-slow shrink-0" />
                      <span>
                        {isBn ? 'শুরু হতে বাকি: ' : 'Starts in: '}
                        <span className="font-mono text-white font-bold tracking-wide">{countdownString}</span>
                      </span>
                    </div>
                  )}

                </div>

              </div>

              {/* Bottom Button (Leaderboard / Play Quiz / View Details) */}
              <div className="mt-3.5 pt-1">
                {isLive ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePlayQuiz(quiz as WeeklyQuiz);
                    }}
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm rounded-xl shadow cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>{isBn ? 'এখনই কুইজে অংশ নিন' : 'Play Quiz'}</span>
                  </button>
                ) : isScheduled ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openQuizDetails(quiz as WeeklyQuiz);
                    }}
                    className="w-full py-2.5 bg-[#1e1708] hover:bg-[#2b210d] text-amber-300 hover:text-amber-200 border border-amber-500/40 text-xs sm:text-sm font-bold rounded-xl cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <span>{isBn ? 'কুইজ বিবরণ ও নিয়ম' : 'View Details & Rules'}</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onViewLeaderboard(quiz as WeeklyQuiz);
                    }}
                    className="w-full py-2.5 bg-[#1e1708] hover:bg-[#2b210d] text-amber-300 hover:text-amber-200 border border-amber-500/40 text-xs sm:text-sm font-bold rounded-xl cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <span>{isBn ? 'লিডারবোর্ড' : 'Leaderboard'}</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* MODALS */}
      {selectedModalQuiz && (
        <QuizDetailsModal
          language={language}
          quiz={selectedModalQuiz}
          userProfile={userProfile}
          isOpen={showDetailsModal}
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedModalQuiz(null);
          }}
          onStartQuiz={(q) => {
            setShowDetailsModal(false);
            handlePlayQuiz(q);
          }}
          onJoinedSuccess={() => {
            fetchQuizzes();
          }}
          onViewLeaderboard={(q) => {
            setShowDetailsModal(false);
            onViewLeaderboard(q);
          }}
          onViewResult={(q, sub) => {
            setShowDetailsModal(false);
            onViewResult(q, sub);
          }}
        />
      )}

      {pendingTakingQuiz && showAdGate && (
        <QuizAdGateModal
          language={language}
          quiz={pendingTakingQuiz}
          onClose={() => {
            setShowAdGate(false);
            setPendingTakingQuiz(null);
          }}
          onPassGranted={() => {
            setShowAdGate(false);
            const q = pendingTakingQuiz;
            setPendingTakingQuiz(null);
            onJoinQuiz(q);
          }}
        />
      )}

      <AllQuizzesModal
        language={language}
        isOpen={showAllQuizzesModal}
        onClose={() => setShowAllQuizzesModal(false)}
        quizzes={quizzesList}
        userProfile={userProfile}
        onSelectQuiz={(q) => {
          setShowAllQuizzesModal(false);
          openQuizDetails(q);
        }}
        onTakeQuiz={(q) => {
          setShowAllQuizzesModal(false);
          handlePlayQuiz(q);
        }}
        onViewLeaderboard={(q) => {
          setShowAllQuizzesModal(false);
          onViewLeaderboard(q);
        }}
      />
    </div>
  );
}
