import React from 'react';
import { VpnServer, ConnectionStatus } from '../types/vpn';
import { USER_ORIGINAL_NETWORK } from '../data/servers';

interface WorldMapVisualProps {
  currentServer: VpnServer;
  status: ConnectionStatus;
  allServers: VpnServer[];
  onSelectServer: (server: VpnServer) => void;
}

export const WorldMapVisual: React.FC<WorldMapVisualProps> = ({
  currentServer,
  status,
  allServers,
  onSelectServer,
}) => {
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';

  // Origin point (Dhaka)
  const origin = USER_ORIGINAL_NETWORK.coordinates;
  // Destination point
  const dest = currentServer.coordinates;

  // Calculate an arched Bezier curve between origin and destination
  const midX = (origin.x + dest.x) / 2;
  const midY = Math.min(origin.y, dest.y) - Math.abs(origin.x - dest.x) * 0.25;
  const clampedMidY = Math.max(10, midY);
  const pathD = `M ${origin.x} ${origin.y} Q ${midX} ${clampedMidY} ${dest.x} ${dest.y}`;

  return (
    <div className="relative w-full h-56 sm:h-72 rounded-2xl overflow-hidden bg-slate-900/90 dark:bg-slate-950/90 border border-slate-800 text-white select-none">
      {/* Background World Map Vector Grid Pattern */}
      <svg
        className="absolute inset-0 w-full h-full opacity-20 pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
      >
        <defs>
          <pattern id="grid" width="5" height="5" patternUnits="userSpaceOnUse">
            <path d="M 5 0 L 0 0 0 5" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="0.2" />
          </pattern>
        </defs>
        <rect width="100" height="100" fill="url(#grid)" />
      </svg>

      {/* Stylized Continents silhouettes */}
      <svg
        viewBox="0 0 100 100"
        className="absolute inset-0 w-full h-full text-slate-800/80 fill-current opacity-60 pointer-events-none"
        preserveAspectRatio="none"
      >
        {/* Americas */}
        <path d="M 12 18 Q 22 15 28 22 Q 32 30 24 45 Q 16 48 18 58 Q 24 78 28 85 Q 22 88 18 75 Q 14 60 10 38 Z" />
        {/* Europe & Africa */}
        <path d="M 44 20 Q 56 16 58 26 Q 52 35 48 40 Q 58 52 56 70 Q 48 82 44 65 Q 40 45 42 30 Z" />
        {/* Asia */}
        <path d="M 60 18 Q 80 15 88 32 Q 92 48 82 58 Q 72 52 66 42 Q 62 30 60 18 Z" />
        {/* Australia */}
        <path d="M 80 70 Q 92 68 90 82 Q 78 86 80 70 Z" />
      </svg>

      {/* Interactive Active Route & Server Nodes */}
      <svg
        viewBox="0 0 100 100"
        className="absolute inset-0 w-full h-full pointer-events-auto"
        preserveAspectRatio="none"
      >
        {/* Route Line if connecting or connected */}
        {(isConnected || isConnecting) && (
          <>
            <path
              d={pathD}
              fill="none"
              stroke={isConnected ? '#10B981' : '#6366F1'}
              strokeWidth="0.8"
              strokeDasharray="2 1.5"
              className={isConnecting ? 'animate-pulse' : ''}
              opacity="0.8"
            />
            {/* Animated packet moving along curve */}
            <circle r="1" fill="#34D399" className="animate-ping" opacity="0.9">
              <animateMotion
                path={pathD}
                dur="2.5s"
                repeatCount="indefinite"
              />
            </circle>
          </>
        )}

        {/* Home / Origin Node (User Location) */}
        <g transform={`translate(${origin.x}, ${origin.y})`}>
          <circle r="1.5" fill="#38BDF8" />
          <circle r="3.5" fill="none" stroke="#38BDF8" strokeWidth="0.4" opacity="0.7">
            <animate attributeName="r" values="1.5;4.5" dur="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.8;0" dur="2s" repeatCount="indefinite" />
          </circle>
        </g>

        {/* Global Server Nodes */}
        {allServers.map((server) => {
          const isSelected = server.id === currentServer.id;
          const { x, y } = server.coordinates;

          return (
            <g
              key={server.id}
              transform={`translate(${x}, ${y})`}
              className="cursor-pointer group"
              onClick={() => onSelectServer(server)}
            >
              {isSelected && (isConnected || isConnecting) ? (
                <>
                  <circle
                    r="2.2"
                    fill={isConnected ? '#10B981' : '#818CF8'}
                    className="transition-colors"
                  />
                  <circle
                    r="5"
                    fill="none"
                    stroke={isConnected ? '#34D399' : '#818CF8'}
                    strokeWidth="0.5"
                  >
                    <animate attributeName="r" values="2;6.5" dur="1.8s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.9;0" dur="1.8s" repeatCount="indefinite" />
                  </circle>
                </>
              ) : (
                <circle
                  r={isSelected ? '1.8' : '1.1'}
                  fill={isSelected ? '#F59E0B' : 'rgba(255,255,255,0.45)'}
                  className="group-hover:fill-white transition-all group-hover:scale-125"
                />
              )}
            </g>
          );
        })}
      </svg>

      {/* Overlay Badges for User Origin & Selected Target */}
      <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-sky-400"></span>
        <span className="text-slate-300">
          Origin: <strong className="text-white font-medium">{USER_ORIGINAL_NETWORK.city}</strong> ({USER_ORIGINAL_NETWORK.country})
        </span>
      </div>

      <div className="absolute bottom-3 right-3 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs flex items-center gap-2">
        <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400' : isConnecting ? 'bg-indigo-400 animate-ping' : 'bg-amber-400'}`}></span>
        <span className="text-slate-300">
          Tunnel: <strong className="text-white font-medium">{currentServer.city}</strong> {currentServer.flag} ({currentServer.ping}ms)
        </span>
      </div>
    </div>
  );
};
