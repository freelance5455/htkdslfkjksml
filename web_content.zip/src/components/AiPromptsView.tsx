import React, { useState } from 'react';
import { Sparkles, Copy, Check, Terminal, ExternalLink, Image as ImageIcon } from 'lucide-react';

export const AiPromptsView: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyPrompt = (text: string, index: number) => {
    navigator.clipboard?.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const prompts = [
    {
      title: 'Prompt 1: Sewora Home Screen UI Mockup (Primary Recommended)',
      model: 'Midjourney v6.0 / DALL-E 3',
      description: 'The master UI mockup prompt inspired by Daraz layout, capturing search, banners, flash sale countdown, and Just For You feed.',
      prompt: 'Modern mobile app UI/UX design for an e-commerce platform named "Sewora", inspired by Daraz app design layout. Features a clean top navigation bar with search, promotional banner carousel, flash sale deal cards with countdown timer, grid layout for products under "Just For You" section, vibrant and clean orange and deep blue color accents, highly detailed Figma UI mockup, clean mobile interface design --ar 9:16 --v 6.0',
      sinhalaNote: 'ඔබට Sewora app එකේ Home Screen UI Mockup එකක් Image එකක් ලෙස generate කර ගැනීමට මෙම prompt එක භාවිතා කරන්න.'
    },
    {
      title: 'Prompt 2: Ultra High-Fidelity Figma Studio Mockup (Multi-Screen Showcase)',
      model: 'Midjourney v6.0',
      description: 'Side-by-side presentation mockup showing 3 screens (Home, PDP, and Checkout) on modern iPhone 16 Pro frames on a clean architectural studio background.',
      prompt: 'Clean Figma UI/UX presentation mockup of "Sewora" e-commerce mobile app, three iPhone 16 Pro screens angled side by side showing: 1) Home screen with orange search bar and flash sale timer, 2) Product detail page with sneaker photo carousel and size selector, 3) Checkout screen with card and cash on delivery payment options. Vibrant electric orange (#FF6600) and deep royal navy accents, clean minimalist typography, Dribbble trending, Behance award winner, ultra sharp 8k --ar 16:9 --v 6.0 --style raw',
      sinhalaNote: 'Figma සහ Behance style එකෙන් screens 3ක් එකවර පෙන්වන professional mockup එකක් සඳහා.'
    },
    {
      title: 'Prompt 3: Product Detail Page (PDP) Interactive Layout',
      model: 'Midjourney v6.0 / DALL-E 3',
      description: 'Focused close-up of the single product purchase screen with color swatches, reviews, and sticky bottom buy bar.',
      prompt: 'High-fidelity mobile UI design of a Product Detail Page (PDP) for marketplace app "Sewora", displaying a modern sneaker with multi-angle image gallery, discounted price Rs. 4,950 with 44% OFF badge, color variation chips, customer star reviews with user photos, verified store badge with 98% rating, and sticky bottom navigation with "Add to Cart" and "Buy Now" orange button, clean modern iOS interface, flat Figma vector aesthetic --ar 9:16 --v 6.0',
      sinhalaNote: 'Product Page එකේ විස්තර සහ Buy Now button සහිත screen එක generate කිරීමට.'
    },
    {
      title: 'Prompt 4: Checkout & Localized Payment Gateway Screen',
      model: 'Midjourney v6.0 / DALL-E 3',
      description: 'Checkout screen showcasing delivery address selection, order summary, and payment methods (Card, Cash on Delivery, Mobile Wallet).',
      prompt: 'Modern e-commerce checkout screen mobile UI design for "Sewora" app, delivery address card with location pin, delivery speed toggle (Standard vs Express), payment gateway selection list featuring Credit Card, Cash on Delivery (COD) badge, and Mobile Wallet options, order total breakdown, sticky "Place Order" CTA button, clean whitespace, trustworthy fintech styling, Figma design --ar 9:16 --v 6.0',
      sinhalaNote: 'Checkout සහ Payment options (COD, Cards, Mobile Wallets) සඳහා වන UI එක.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-[#FF6600] uppercase tracking-wider mb-1">
          <Sparkles className="w-4 h-4" />
          <span>AI Wireframe & Visual UI Generation Prompts</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          Sewora Visual Prompt Engineering Studio
        </h1>
        <p className="text-xs text-slate-600 mt-2 leading-relaxed">
          Use these ready-to-run prompts in Midjourney v6 or DALL-E 3 to generate high-fidelity 
          Figma-style visual mockups for client decks, design portfolios, and investor pitches.
        </p>
      </div>

      {/* Prompts List */}
      <div className="space-y-4">
        {prompts.map((p, index) => (
          <div key={index} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900">{p.title}</h3>
                <span className="text-[10px] font-mono font-bold bg-orange-100 text-[#FF6600] px-2 py-0.5 rounded">
                  {p.model}
                </span>
              </div>
              <button
                onClick={() => copyPrompt(p.prompt, index)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
              >
                {copiedIndex === index ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Prompt</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-normal">{p.description}</p>

            {/* Prompt Codebox */}
            <div className="bg-slate-900 text-slate-100 p-3.5 rounded-xl font-mono text-xs leading-relaxed border border-slate-800 relative select-all">
              {p.prompt}
            </div>

            {/* Sinhala Guidance Box */}
            <div className="bg-orange-50 border border-orange-200/80 rounded-xl p-3 text-xs text-slate-800 flex items-start gap-2">
              <span className="text-base shrink-0">💡</span>
              <div>
                <div className="font-bold text-[#FF6600] text-[11px] uppercase tracking-wide">
                  සිංහල උපදෙස් (Sinhala Guide)
                </div>
                <p className="mt-0.5 text-slate-700 leading-relaxed font-sans">{p.sinhalaNote}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Midjourney Tips Callout */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 text-xs text-slate-600 space-y-2">
        <h4 className="font-bold text-slate-900">Tips for Best Results in Midjourney:</h4>
        <ul className="list-disc pl-5 space-y-1 text-slate-600">
          <li>Always use <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">--ar 9:16</code> for smartphone screens or <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">--ar 16:9</code> for multi-device desktop frames.</li>
          <li>Add <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">--v 6.0 --style raw</code> to avoid Midjourney over-styling with artistic fantasy elements.</li>
          <li>Import generated images directly into Figma as fill layers to overlay vector buttons, interactive text, and icons.</li>
        </ul>
      </div>
    </div>
  );
};
