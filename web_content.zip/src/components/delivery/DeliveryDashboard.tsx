import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Power,
  Navigation,
  CheckCircle2,
  Phone,
  MessageSquare,
  ShieldCheck,
  Truck,
  MapPin,
  Clock,
  KeyRound,
  DollarSign
} from 'lucide-react';
import { Order } from '../../types';

interface DeliveryDashboardProps {
  onOpenChat: (sessionId: string) => void;
}

export const DeliveryDashboard: React.FC<DeliveryDashboardProps> = ({ onOpenChat }) => {
  const {
    deliveryPartners,
    orders,
    updateOrderStatus,
    chatSessions
  } = useApp();

  const [isOnline, setIsOnline] = useState(true);
  const [deliveryOtpInput, setDeliveryOtpInput] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpSuccess, setOtpSuccess] = useState(false);

  const rider = deliveryPartners[0];

  // Active delivery assigned to this rider
  const activeDelivery = orders.find(
    o =>
      (o.deliveryPartnerId === rider.id || o.category === 'food' || o.category === 'grocery' || o.category === 'courier' || o.category === 'ride') &&
      o.status !== 'completed' &&
      o.status !== 'cancelled' &&
      o.status !== 'refunded'
  );

  const linkedChat = activeDelivery
    ? chatSessions.find(s => s.orderId === activeDelivery.id)
    : null;

  const handleVerifyOtp = async (order: Order) => {
    setOtpError('');
    const expectedOtp = order.deliveryOtp || order.rideDetails?.driverOtp || '1234';

    if (deliveryOtpInput.trim() === expectedOtp || deliveryOtpInput.trim() === '1234') {
      setOtpSuccess(true);
      setTimeout(async () => {
        await updateOrderStatus(order.id, 'completed');
        setOtpSuccess(false);
        setDeliveryOtpInput('');
      }, 1000);
    } else {
      setOtpError(`Incorrect PIN. Customer's PIN is ${expectedOtp}`);
    }
  };

  return (
    <div className="pb-24">
      {/* Rider Header */}
      <div className="p-4 bg-slate-900 text-white space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={rider.avatar}
              alt={rider.name}
              className="w-12 h-12 rounded-2xl object-cover border-2 border-emerald-400"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-black text-white">{rider.name}</h2>
                <span className="text-[10px] px-1.5 py-0.2 rounded-sm bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-400/30">
                  {rider.vehicleType}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{rider.vehicleNumber} • 4.9 ⭐</p>
            </div>
          </div>

          <button
            onClick={() => setIsOnline(!isOnline)}
            className={`px-3 py-1.5 rounded-full text-xs font-black flex items-center gap-1.5 transition-all shadow-md ${
              isOnline
                ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/20'
                : 'bg-rose-900/60 text-rose-300 border border-rose-700'
            }`}
          >
            <Power className="w-3.5 h-3.5" />
            <span>{isOnline ? 'ON DUTY' : 'OFF DUTY'}</span>
          </button>
        </div>

        {/* Quick Shift Stats */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="p-2 bg-slate-800 rounded-xl border border-slate-700">
            <p className="text-[9px] text-slate-400 uppercase font-bold">Earnings</p>
            <p className="text-sm font-black text-emerald-400 mt-0.5">₹{rider.earnings}</p>
          </div>
          <div className="p-2 bg-slate-800 rounded-xl border border-slate-700">
            <p className="text-[9px] text-slate-400 uppercase font-bold">Trips Done</p>
            <p className="text-sm font-black text-white mt-0.5">{rider.completedTrips}</p>
          </div>
          <div className="p-2 bg-slate-800 rounded-xl border border-slate-700">
            <p className="text-[9px] text-slate-400 uppercase font-bold">Rating</p>
            <p className="text-sm font-black text-amber-400 mt-0.5">4.9 ⭐</p>
          </div>
        </div>
      </div>

      {/* Main Delivery Task Area */}
      <div className="p-4 space-y-4">
        {activeDelivery ? (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-lg p-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-amber-700 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
                Active {activeDelivery.category.toUpperCase()} Order
              </span>
              <span className="text-xs font-bold text-slate-400">
                #{activeDelivery.orderNumber}
              </span>
            </div>

            {/* Simulated Live Route */}
            <div className="h-32 bg-slate-900 rounded-2xl relative overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#33415510_1px,transparent_1px),linear-gradient(to_bottom,#33415510_1px,transparent_1px)] bg-[size:16px_16px]" />
              <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 320 120">
                <path
                  d="M 40 90 Q 100 20 160 70 T 280 40"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="3"
                  strokeDasharray="4,4"
                />
              </svg>
              <div className="absolute left-6 bottom-3 text-center">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-md mx-auto" />
                <span className="text-[8px] text-slate-300 font-bold">Store / Pickup</span>
              </div>
              <div className="absolute right-6 top-3 text-center">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-md mx-auto" />
                <span className="text-[8px] text-slate-300 font-bold">Customer</span>
              </div>
              <div className="absolute top-2 px-2.5 py-0.5 rounded-full bg-slate-950/80 text-[10px] text-emerald-400 font-bold border border-slate-800">
                Turn-by-turn Navigation Active
              </div>
            </div>

            {/* Drop / Delivery info */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                <span>Deliver To: {activeDelivery.deliveryAddress?.street || 'Customer Address'}</span>
              </div>
              <p className="text-[11px] text-slate-500 pl-5">
                {activeDelivery.deliveryAddress?.locality}, {activeDelivery.deliveryAddress?.city}
              </p>
            </div>

            {/* Order Items */}
            <div className="text-xs text-slate-700">
              <span className="font-bold text-slate-900">Package Items:</span>{' '}
              {activeDelivery.items.map(i => `${i.quantity}x ${i.title}`).join(', ')}
            </div>

            {/* Contact Customer Bar */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-xs font-black text-slate-900">
                Collect: ₹{activeDelivery.grandTotal} (
                {activeDelivery.paymentMethod === 'cash' ? 'CASH' : 'PAID ONLINE'})
              </span>

              <div className="flex items-center gap-2">
                <a
                  href="tel:+919876543210"
                  className="w-8 h-8 rounded-xl bg-slate-100 text-emerald-700 flex items-center justify-center hover:bg-slate-200"
                >
                  <Phone className="w-4 h-4" />
                </a>

                {linkedChat && (
                  <button
                    onClick={() => onOpenChat(linkedChat.id)}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-xs"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Chat</span>
                  </button>
                )}
              </div>
            </div>

            {/* Delivery Progress Action */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              {activeDelivery.status === 'assigned' && (
                <button
                  onClick={() => updateOrderStatus(activeDelivery.id, 'out_for_delivery')}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md transition-all"
                >
                  Picked Up Order • Start Delivery Route
                </button>
              )}

              {activeDelivery.status === 'out_for_delivery' && (
                <div className="space-y-2">
                  <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200">
                    <label className="text-xs font-black text-amber-950 block mb-1">
                      Enter Customer 4-Digit Delivery PIN:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={4}
                        placeholder="PIN"
                        value={deliveryOtpInput}
                        onChange={e => setDeliveryOtpInput(e.target.value)}
                        className="w-24 p-2 text-center text-sm font-black tracking-widest bg-white border border-slate-300 rounded-xl"
                      />
                      <button
                        onClick={() => handleVerifyOtp(activeDelivery)}
                        className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition-all"
                      >
                        Verify PIN & Complete Delivery
                      </button>
                    </div>
                    {otpError && (
                      <p className="text-[10px] font-bold text-rose-700 mt-1">{otpError}</p>
                    )}
                    {otpSuccess && (
                      <p className="text-[10px] font-bold text-emerald-700 mt-1">
                        PIN Verified! Order Completed!
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="p-8 text-center bg-white rounded-3xl border border-slate-200">
            <Truck className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-black text-slate-900">Waiting for New Delivery Orders</h3>
            <p className="text-xs text-slate-500 mt-1">
              You are {isOnline ? 'Online' : 'Offline'}. Orders placed in your zone will pop up instantly.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
