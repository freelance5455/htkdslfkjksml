import React, { useMemo, useState } from 'react';
import { ClanWarEntry, HistoryPoint, VillageCategory } from '../shared/cocData';
import { formatShortTimeRu } from '../utils/formatters';

export interface SeriesConfig {
  key: string;
  label: string;
  color: string;
  getValue: (pt: HistoryPoint) => number | undefined;
}

interface MultiLineProgressChartProps {
  history: HistoryPoint[];
  series: SeriesConfig[];
  height?: number;
  yMin?: number;
  yMax?: number;
  unit?: string;
}

export const MultiLineProgressChart: React.FC<MultiLineProgressChartProps> = ({
  history,
  series,
  height = 280,
  yMin,
  yMax = 100,
  unit = '%',
}) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const width = 760;
  const padLeft = 48;
  const padRight = 16;
  const padTop = 18;
  const padBottom = 30;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  const computedMin = useMemo(() => {
    if (yMin !== undefined) return yMin;
    let minVal = 100;
    for (const pt of history) {
      for (const s of series) {
        const v = s.getValue(pt);
        if (v !== undefined && v < minVal) minVal = v;
      }
    }
    return Math.max(0, Math.floor((minVal - 5) / 5) * 5);
  }, [history, series, yMin]);

  const safeSpan = Math.max(5, yMax - computedMin);

  const xPos = (i: number) =>
    history.length <= 1 ? padLeft + innerW / 2 : padLeft + (i / (history.length - 1)) * innerW;

  const yPos = (val: number) =>
    padTop + innerH - ((Math.min(yMax, Math.max(computedMin, val)) - computedMin) / safeSpan) * innerH;

  const yTicks = useMemo(() => {
    const steps = 4;
    const arr: number[] = [];
    for (let i = 0; i <= steps; i++) {
      arr.push(Math.round(computedMin + (safeSpan * i) / steps));
    }
    return arr;
  }, [computedMin, safeSpan]);

  if (history.length === 0) {
    return (
      <div className="flex h-[240px] items-center justify-center text-sm text-slate-400">
        Нет сохранённых снимков для построения графика
      </div>
    );
  }

  const activeIndex = hoverIdx !== null ? Math.min(history.length - 1, Math.max(0, hoverIdx)) : null;
  const activePoint = activeIndex !== null ? history[activeIndex] : null;

  return (
    <div className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        onMouseLeave={() => setHoverIdx(null)}
      >
        {yTicks.map((tick) => {
          const y = yPos(tick);
          return (
            <g key={tick}>
              <line
                x1={padLeft}
                x2={width - padRight}
                y1={y}
                y2={y}
                stroke="rgba(148, 163, 184, 0.12)"
                strokeDasharray="3 3"
              />
              <text
                x={padLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-500 text-[11px] font-mono tabular-nums"
              >
                {tick}{unit}
              </text>
            </g>
          );
        })}

        {history.map((pt, i) => {
          const step = history.length > 16 ? 5 : history.length > 9 ? 2 : 1;
          if (i !== 0 && i !== history.length - 1 && i % step !== 0) return null;
          return (
            <text
              key={pt.date}
              x={xPos(i)}
              y={height - 6}
              textAnchor="middle"
              className="fill-slate-500 text-[11px] font-mono"
            >
              {pt.label}
            </text>
          );
        })}

        {series.map((s) => {
          const pts: Array<{ x: number; y: number; v: number }> = [];
          history.forEach((pt, i) => {
            const v = s.getValue(pt);
            if (v !== undefined) pts.push({ x: xPos(i), y: yPos(v), v });
          });
          if (pts.length === 0) return null;
          const d = pts.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');

          return (
            <g key={s.key}>
              {pts.length > 1 && (
                <path
                  d={d}
                  fill="none"
                  stroke={s.color}
                  strokeWidth={2.2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}
              {pts.length === 1 && (
                <circle
                  cx={pts[0].x}
                  cy={pts[0].y}
                  r={4.5}
                  fill={s.color}
                  stroke="#0B0F17"
                  strokeWidth={2}
                />
              )}
              {activeIndex !== null && s.getValue(history[activeIndex]) !== undefined && (
                <circle
                  cx={xPos(activeIndex)}
                  cy={yPos(s.getValue(history[activeIndex])!)}
                  r={4.5}
                  fill={s.color}
                  stroke="#0B0F17"
                  strokeWidth={2}
                />
              )}
            </g>
          );
        })}

        {activeIndex !== null && (
          <line
            x1={xPos(activeIndex)}
            x2={xPos(activeIndex)}
            y1={padTop}
            y2={height - padBottom}
            stroke="rgba(245, 158, 11, 0.45)"
            strokeWidth={1}
          />
        )}

        {history.map((pt, i) => {
          const colW = innerW / Math.max(1, history.length - 1);
          const x = history.length <= 1 ? padLeft : xPos(i) - colW / 2;
          return (
            <rect
              key={pt.date}
              x={Math.max(padLeft, x)}
              y={padTop}
              width={history.length <= 1 ? innerW : colW}
              height={innerH}
              fill="transparent"
              onMouseEnter={() => setHoverIdx(i)}
            />
          );
        })}
      </svg>

      {activePoint && activeIndex !== null && (
        <div
          className="pointer-events-none absolute top-2 z-20 min-w-[180px] rounded-lg border border-slate-700/80 bg-[#121824]/95 px-3 py-2 shadow-xl backdrop-blur-sm"
          style={{
            left: activeIndex > history.length / 2 ? '16px' : undefined,
            right: activeIndex <= history.length / 2 ? '16px' : undefined,
          }}
        >
          <div className="mb-1.5 flex items-center justify-between gap-4 border-b border-slate-800 pb-1 text-xs font-medium text-slate-300">
            <span>{activePoint.label}</span>
            <span className="font-mono tabular-nums text-slate-400">+{activePoint.upgradesCount} апгр.</span>
          </div>
          <div className="space-y-1">
            {series.map((s) => {
              const val = s.getValue(activePoint);
              if (val === undefined) return null;
              return (
                <div key={s.key} className="flex items-center justify-between gap-4 text-xs">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <span className="inline-block h-2 w-2 rounded-xs" style={{ backgroundColor: s.color }} />
                    {s.label}
                  </span>
                  <span className="font-mono font-semibold tabular-nums text-slate-100">
                    {val.toFixed(1)}{unit}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

// Generic real-snapshot time series chart (used in Overview & History)
export interface SnapshotSeriesPoint {
  id: string;
  timestamp: string;
  values: Record<string, number>;
}

export interface SnapshotSeriesDef {
  key: string;
  label: string;
  color: string;
  unit?: string;
}

interface SnapshotTimeSeriesChartProps {
  points: SnapshotSeriesPoint[];
  series: SnapshotSeriesDef[];
  height?: number;
}

export const SnapshotTimeSeriesChart: React.FC<SnapshotTimeSeriesChartProps> = ({
  points,
  series,
  height = 260,
}) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const width = 760;
  const padLeft = 64;
  const padRight = 16;
  const padTop = 18;
  const padBottom = 30;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  const { minVal, maxVal } = useMemo(() => {
    let minV = Infinity;
    let maxV = -Infinity;
    for (const pt of points) {
      for (const s of series) {
        const v = pt.values[s.key];
        if (v !== undefined && Number.isFinite(v)) {
          if (v < minV) minV = v;
          if (v > maxV) maxV = v;
        }
      }
    }
    if (!Number.isFinite(minV) || !Number.isFinite(maxV)) {
      return { minVal: 0, maxVal: 100 };
    }
    if (minV === maxV) {
      const pad = Math.max(1, Math.round(Math.abs(minV) * 0.05));
      return { minVal: Math.max(0, minV - pad), maxVal: maxV + pad };
    }
    const span = maxV - minV;
    return {
      minVal: Math.max(0, Math.floor(minV - span * 0.12)),
      maxVal: Math.ceil(maxV + span * 0.12),
    };
  }, [points, series]);

  const span = Math.max(1, maxVal - minVal);
  const xPos = (i: number) =>
    points.length <= 1 ? padLeft + innerW / 2 : padLeft + (i / (points.length - 1)) * innerW;
  const yPos = (v: number) => padTop + innerH - ((v - minVal) / span) * innerH;

  const yTicks = useMemo(() => {
    const arr: number[] = [];
    for (let i = 0; i <= 4; i++) {
      arr.push(Math.round(minVal + (span * i) / 4));
    }
    return arr;
  }, [minVal, span]);

  if (points.length === 0) {
    return (
      <div className="flex h-[220px] items-center justify-center text-sm text-slate-400">
        История снимков начнётся после первого сохранения данных клана
      </div>
    );
  }

  const activeIdx = hoverIdx !== null ? Math.min(points.length - 1, Math.max(0, hoverIdx)) : null;
  const activePt = activeIdx !== null ? points[activeIdx] : null;

  return (
    <div className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        onMouseLeave={() => setHoverIdx(null)}
      >
        {yTicks.map((tick, idx) => {
          const y = yPos(tick);
          return (
            <g key={`${tick}-${idx}`}>
              <line
                x1={padLeft}
                x2={width - padRight}
                y1={y}
                y2={y}
                stroke="rgba(148, 163, 184, 0.12)"
                strokeDasharray="3 3"
              />
              <text
                x={padLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-500 text-[11px] font-mono tabular-nums"
              >
                {tick.toLocaleString('ru-RU')}
              </text>
            </g>
          );
        })}

        {points.map((pt, i) => {
          const step = points.length > 16 ? Math.ceil(points.length / 6) : points.length > 7 ? 2 : 1;
          if (i !== 0 && i !== points.length - 1 && i % step !== 0) return null;
          return (
            <text
              key={pt.id}
              x={xPos(i)}
              y={height - 6}
              textAnchor="middle"
              className="fill-slate-500 text-[10px] font-mono"
            >
              {formatShortTimeRu(pt.timestamp)}
            </text>
          );
        })}

        {series.map((s) => {
          const pts = points
            .map((pt, i) => {
              const v = pt.values[s.key];
              return v !== undefined ? { x: xPos(i), y: yPos(v), v } : null;
            })
            .filter((x): x is { x: number; y: number; v: number } => x !== null);

          if (pts.length === 0) return null;
          const d = pts.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');

          return (
            <g key={s.key}>
              {pts.length > 1 && (
                <path
                  d={d}
                  fill="none"
                  stroke={s.color}
                  strokeWidth={2.2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}
              {pts.map((p, idx) => (
                <circle
                  key={`${s.key}-${idx}`}
                  cx={p.x}
                  cy={p.y}
                  r={activeIdx === idx || pts.length === 1 ? 4.5 : 2.5}
                  fill={s.color}
                  stroke="#0B0F17"
                  strokeWidth={1.5}
                />
              ))}
            </g>
          );
        })}

        {activeIdx !== null && (
          <line
            x1={xPos(activeIdx)}
            x2={xPos(activeIdx)}
            y1={padTop}
            y2={height - padBottom}
            stroke="rgba(245, 158, 11, 0.45)"
            strokeWidth={1}
          />
        )}

        {points.map((pt, i) => {
          const colW = innerW / Math.max(1, points.length - 1);
          const x = points.length <= 1 ? padLeft : xPos(i) - colW / 2;
          return (
            <rect
              key={pt.id}
              x={Math.max(padLeft, x)}
              y={padTop}
              width={points.length <= 1 ? innerW : colW}
              height={innerH}
              fill="transparent"
              onMouseEnter={() => setHoverIdx(i)}
            />
          );
        })}
      </svg>

      {activePt && activeIdx !== null && (
        <div
          className="pointer-events-none absolute top-2 z-20 min-w-[190px] rounded-lg border border-slate-700/80 bg-[#121824]/95 px-3 py-2 shadow-xl backdrop-blur-sm"
          style={{
            left: activeIdx > points.length / 2 ? '16px' : undefined,
            right: activeIdx <= points.length / 2 ? '16px' : undefined,
          }}
        >
          <div className="mb-1.5 border-b border-slate-800 pb-1 font-mono text-[11px] text-slate-300">
            {formatShortTimeRu(activePt.timestamp)}
          </div>
          <div className="space-y-1">
            {series.map((s) => {
              const v = activePt.values[s.key];
              if (v === undefined) return null;
              return (
                <div key={s.key} className="flex items-center justify-between gap-4 text-xs">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <span className="inline-block h-2 w-2 rounded-xs" style={{ backgroundColor: s.color }} />
                    {s.label}
                  </span>
                  <span className="font-mono font-semibold tabular-nums text-slate-100">
                    {v.toLocaleString('ru-RU')}{s.unit ?? ''}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

interface VelocityBarChartProps {
  history: HistoryPoint[];
  height?: number;
}

const VELOCITY_COLORS: Array<{ key: VillageCategory | 'townhall'; label: string; color: string }> = [
  { key: 'defenses', label: 'Оборона', color: '#F59E0B' },
  { key: 'heroes', label: 'Герои', color: '#10B981' },
  { key: 'lab', label: 'Лаборатория', color: '#38BDF8' },
  { key: 'walls', label: 'Стены', color: '#A78BFA' },
  { key: 'traps', label: 'Ловушки', color: '#FB7185' },
];

export const VelocityBarChart: React.FC<VelocityBarChartProps> = ({ history, height = 220 }) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const width = 760;
  const padLeft = 36;
  const padRight = 12;
  const padTop = 16;
  const padBottom = 28;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  const maxTotal = useMemo(() => {
    let m = 5;
    for (const pt of history) {
      if (pt.upgradesCount > m) m = pt.upgradesCount;
    }
    return Math.ceil(m / 5) * 5;
  }, [history]);

  const barStep = innerW / Math.max(1, history.length);
  const barW = Math.max(6, Math.min(20, barStep * 0.65));

  return (
    <div className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        onMouseLeave={() => setHoverIdx(null)}
      >
        {[0, Math.round(maxTotal / 2), maxTotal].map((tick) => {
          const y = padTop + innerH - (tick / maxTotal) * innerH;
          return (
            <g key={tick}>
              <line
                x1={padLeft}
                x2={width - padRight}
                y1={y}
                y2={y}
                stroke="rgba(148, 163, 184, 0.12)"
                strokeDasharray="3 3"
              />
              <text
                x={padLeft - 6}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-500 text-[11px] font-mono tabular-nums"
              >
                {tick}
              </text>
            </g>
          );
        })}

        {history.map((pt, i) => {
          const x = padLeft + i * barStep + (barStep - barW) / 2;
          let yCursor = padTop + innerH;
          const step = history.length > 16 ? 5 : history.length > 9 ? 2 : 1;

          return (
            <g key={pt.date} onMouseEnter={() => setHoverIdx(i)}>
              <rect
                x={padLeft + i * barStep}
                y={padTop}
                width={barStep}
                height={innerH}
                fill={hoverIdx === i ? 'rgba(255,255,255,0.03)' : 'transparent'}
              />
              {VELOCITY_COLORS.map((cat) => {
                const count = pt.upgradesByCategory[cat.key] ?? 0;
                if (count <= 0) return null;
                const segH = (count / maxTotal) * innerH;
                yCursor -= segH;
                return (
                  <rect
                    key={cat.key}
                    x={x}
                    y={yCursor}
                    width={barW}
                    height={Math.max(1, segH)}
                    fill={cat.color}
                    opacity={hoverIdx === null || hoverIdx === i ? 0.92 : 0.45}
                    rx={1}
                  />
                );
              })}
              {(i === 0 || i === history.length - 1 || i % step === 0) && (
                <text
                  x={x + barW / 2}
                  y={height - 6}
                  textAnchor="middle"
                  className="fill-slate-500 text-[11px] font-mono"
                >
                  {pt.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {hoverIdx !== null && history[hoverIdx] && (
        <div className="pointer-events-none absolute right-3 top-2 z-20 rounded-lg border border-slate-700/80 bg-[#121824]/95 px-3 py-2 text-xs shadow-xl">
          <div className="mb-1 font-medium text-slate-200">
            {history[hoverIdx].label} · всего {history[hoverIdx].upgradesCount} апгр.
          </div>
          <div className="space-y-0.5">
            {VELOCITY_COLORS.map((cat) => {
              const v = history[hoverIdx].upgradesByCategory[cat.key] ?? 0;
              return (
                <div key={cat.key} className="flex items-center justify-between gap-4">
                  <span className="flex items-center gap-1.5 text-slate-400">
                    <span className="inline-block h-2 w-2 rounded-xs" style={{ backgroundColor: cat.color }} />
                    {cat.label}
                  </span>
                  <span className="font-mono tabular-nums text-slate-200">{v}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

interface WarEfficiencyChartProps {
  wars: ClanWarEntry[];
  height?: number;
}

export const WarEfficiencyChart: React.FC<WarEfficiencyChartProps> = ({ wars, height = 250 }) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const width = 760;
  const padLeft = 44;
  const padRight = 16;
  const padTop = 18;
  const padBottom = 30;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  if (wars.length === 0) {
    return (
      <div className="flex h-[220px] items-center justify-center text-sm text-slate-400">
        Нет открытых данных по журналу клановых войн
      </div>
    );
  }

  const colStep = innerW / Math.max(1, wars.length);
  const xCenter = (i: number) => padLeft + i * colStep + colStep / 2;
  const yPct = (pct: number) => padTop + innerH - (Math.min(100, Math.max(0, pct)) / 100) * innerH;

  const attackPoints = wars.map((w, i) => {
    const pct = w.maxStars > 0 ? (w.clanStars / w.maxStars) * 100 : 0;
    return { x: xCenter(i), y: yPct(pct), pct };
  });

  const destructionPoints = wars.map((w, i) => {
    const pct = w.clanDestruction;
    return { x: xCenter(i), y: yPct(pct), pct };
  });

  const attackPath = attackPoints
    .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');
  const destructionPath = destructionPoints
    .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  const hoveredWar = hoverIdx !== null ? wars[hoverIdx] : null;

  return (
    <div className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        onMouseLeave={() => setHoverIdx(null)}
      >
        {[0, 25, 50, 75, 100].map((tick) => {
          const y = yPct(tick);
          return (
            <g key={tick}>
              <line
                x1={padLeft}
                x2={width - padRight}
                y1={y}
                y2={y}
                stroke="rgba(148, 163, 184, 0.12)"
                strokeDasharray="3 3"
              />
              <text
                x={padLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-500 text-[11px] font-mono tabular-nums"
              >
                {tick}%
              </text>
            </g>
          );
        })}

        {wars.map((w, i) => {
          const barW = Math.min(28, colStep * 0.42);
          const starPct = w.maxStars > 0 ? (w.clanStars / w.maxStars) * 100 : 0;
          const barH = (starPct / 100) * innerH;
          const x = xCenter(i) - barW / 2;
          const y = padTop + innerH - barH;
          return (
            <g key={w.id} onMouseEnter={() => setHoverIdx(i)}>
              <rect
                x={padLeft + i * colStep}
                y={padTop}
                width={colStep}
                height={innerH}
                fill={hoverIdx === i ? 'rgba(255,255,255,0.03)' : 'transparent'}
              />
              <rect
                x={x}
                y={y}
                width={barW}
                height={Math.max(2, barH)}
                rx={2}
                fill={w.result === 'win' ? 'rgba(245, 158, 11, 0.22)' : 'rgba(244, 63, 94, 0.20)'}
                stroke={w.result === 'win' ? 'rgba(245, 158, 11, 0.45)' : 'rgba(244, 63, 94, 0.45)'}
                strokeWidth={1}
              />
              {(wars.length <= 10 || i % 2 === 0 || i === wars.length - 1) && (
                <text
                  x={xCenter(i)}
                  y={height - 6}
                  textAnchor="middle"
                  className="fill-slate-500 text-[10px] font-mono"
                >
                  {w.label}
                </text>
              )}
            </g>
          );
        })}

        {wars.length > 1 && (
          <>
            <path
              d={attackPath}
              fill="none"
              stroke="#10B981"
              strokeWidth={2.3}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d={destructionPath}
              fill="none"
              stroke="#38BDF8"
              strokeWidth={2.3}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </>
        )}

        {attackPoints.map((p, i) => (
          <circle
            key={`atk-${wars[i].id}`}
            cx={p.x}
            cy={p.y}
            r={hoverIdx === i ? 5 : 3.2}
            fill="#10B981"
            stroke="#0B0F17"
            strokeWidth={1.5}
          />
        ))}
        {destructionPoints.map((p, i) => (
          <circle
            key={`dest-${wars[i].id}`}
            cx={p.x}
            cy={p.y}
            r={hoverIdx === i ? 5 : 3.2}
            fill="#38BDF8"
            stroke="#0B0F17"
            strokeWidth={1.5}
          />
        ))}
      </svg>

      {hoveredWar && hoverIdx !== null && (
        <div
          className="pointer-events-none absolute top-2 z-20 min-w-[215px] rounded-lg border border-slate-700/80 bg-[#121824]/95 px-3 py-2 text-xs shadow-xl"
          style={{
            left: hoverIdx > wars.length / 2 ? '16px' : undefined,
            right: hoverIdx <= wars.length / 2 ? '16px' : undefined,
          }}
        >
          <div className="mb-1.5 flex items-center justify-between gap-3 border-b border-slate-800 pb-1">
            <span className="font-semibold text-slate-100 truncate">vs {hoveredWar.opponentName}</span>
            <span
              className={`font-medium ${
                hoveredWar.result === 'win' ? 'text-emerald-400' : hoveredWar.result === 'loss' ? 'text-rose-400' : 'text-amber-400'
              }`}
            >
              {hoveredWar.result === 'win' ? 'Победа' : hoveredWar.result === 'loss' ? 'Поражение' : 'Ничья'}
            </span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Звёзды:</span>
              <span className="font-mono font-semibold tabular-nums text-amber-400">
                {hoveredWar.clanStars} / {hoveredWar.maxStars} (враг {hoveredWar.opponentStars})
              </span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Успешность атак:</span>
              <span className="font-mono font-semibold tabular-nums text-emerald-400">
                {hoveredWar.maxStars > 0 ? ((hoveredWar.clanStars / hoveredWar.maxStars) * 100).toFixed(1) : '0.0'}%
              </span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Разрушение:</span>
              <span className="font-mono tabular-nums text-sky-400">
                {hoveredWar.clanDestruction.toFixed(1)}% vs {hoveredWar.opponentDestruction.toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
