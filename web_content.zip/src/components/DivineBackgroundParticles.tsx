import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  radius: number;
  color: string;
  speedY: number;
  speedX: number;
  alpha: number;
  pulseSpeed: number;
}

interface DivineBackgroundParticlesProps {
  particleColors?: string[];
  shadowGlow?: string;
}

export const DivineBackgroundParticles: React.FC<DivineBackgroundParticlesProps> = ({
  particleColors,
  shadowGlow = 'rgba(251, 191, 36, 0.8)'
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Create divine dust particles
    const particleCount = Math.min(60, Math.floor(window.innerWidth / 25));
    const particles: Particle[] = [];

    const activeColors = particleColors && particleColors.length > 0 ? particleColors : [
      'rgba(251, 191, 36, ',  // Amber 400
      'rgba(245, 158, 11, ',  // Amber 500
      'rgba(217, 119, 6, ',   // Amber 600
      'rgba(254, 240, 138, ', // Yellow 200
      'rgba(192, 132, 252, '  // Purple 400 accent
    ];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 2.2 + 0.8,
        color: activeColors[Math.floor(Math.random() * activeColors.length)],
        speedY: -(Math.random() * 0.3 + 0.1),
        speedX: Math.sin(Math.random() * Math.PI) * 0.2,
        alpha: Math.random() * 0.6 + 0.2,
        pulseSpeed: Math.random() * 0.02 + 0.005
      });
    }

    let time = 0;

    const render = () => {
      animId = requestAnimationFrame(render);
      time += 0.02;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.y += p.speedY;
        p.x += Math.sin(time + p.y * 0.01) * 0.2;
        p.alpha += Math.sin(time * p.pulseSpeed) * 0.01;

        // Reset if drifted off screen top
        if (p.y < -10) {
          p.y = canvas.height + 10;
          p.x = Math.random() * canvas.width;
        }

        const currentAlpha = Math.max(0.1, Math.min(0.8, p.alpha));

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${currentAlpha})`;
        ctx.shadowBlur = p.radius * 6;
        ctx.shadowColor = shadowGlow;
        ctx.fill();
        ctx.shadowBlur = 0;
      });
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [particleColors, shadowGlow]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 opacity-80"
    />
  );
};
