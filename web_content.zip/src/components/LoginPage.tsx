import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Phone,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Fingerprint,
  ArrowRight,
  UserPlus,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  X,
  ShieldCheck,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { DEMO_USERS } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface LoginPageProps {
  language: Language;
  onLoginSuccess: (user: UserProfile) => void;
  onBackToIntro: () => void;
}

const COUNTRIES = [
  { code: '+255', flag: '🇹🇿', name: 'Tanzania', placeholder: '754 123 456' },
  { code: '+254', flag: '🇰🇪', name: 'Kenya', placeholder: '712 345 678' },
  { code: '+256', flag: '🇺🇬', name: 'Uganda', placeholder: '772 345 678' },
  { code: '+250', flag: '🇷🇼', name: 'Rwanda', placeholder: '782 345 678' },
];

export default function LoginPage({
  language,
  onLoginSuccess,
  onBackToIntro,
}: LoginPageProps) {
  const isSw = language === 'sw';

  // Login Method: 'phone' or 'email'
  const [method, setMethod] = useState<'phone' | 'email'>('phone');
  const [countryCode, setCountryCode] = useState('+255');
  const [phoneNumber, setPhoneNumber] = useState('754123456');
  const [email, setEmail] = useState('juma@ardhi.co.tz');
  const [pin, setPin] = useState(['1', '2', '3', '4']);
  const [showPin, setShowPin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [shakePin, setShakePin] = useState(false);
  const [biometricScanning, setBiometricScanning] = useState(false);

  // Modals
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotStep, setForgotStep] = useState<'phone' | 'otp' | 'success'>('phone');
  const [forgotOtp, setForgotOtp] = useState('');
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  // Registration Form State
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRegion, setRegRegion] = useState('Morogoro');
  const [regCrop, setRegCrop] = useState('Mahindi');
  const [regPin, setRegPin] = useState('');

  const pinInputRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // Detect telecom network operator
  const detectOperator = (num: string) => {
    const clean = num.replace(/\D/g, '');
    if (countryCode === '+255') {
      if (clean.startsWith('75') || clean.startsWith('76') || clean.startsWith('74')) {
        return { name: 'Vodacom M-Pesa', color: 'bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30' };
      }
      if (clean.startsWith('71') || clean.startsWith('65') || clean.startsWith('67')) {
        return { name: 'Tigo Pesa', color: 'bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30' };
      }
      if (clean.startsWith('78') || clean.startsWith('68') || clean.startsWith('69')) {
        return { name: 'Airtel Money', color: 'bg-red-600/15 text-red-800 dark:text-red-300 border-red-600/30' };
      }
      if (clean.startsWith('62') || clean.startsWith('61')) {
        return { name: 'Halotel HaloPesa', color: 'bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30' };
      }
    } else if (countryCode === '+254') {
      if (clean.startsWith('70') || clean.startsWith('71') || clean.startsWith('72') || clean.startsWith('79')) {
        return { name: 'Safaricom M-Pesa', color: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30' };
      }
      if (clean.startsWith('73') || clean.startsWith('78')) {
        return { name: 'Airtel Money KE', color: 'bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30' };
      }
    }
    return null;
  };

  const detectedOp = detectOperator(phoneNumber);

  // Time-of-day greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (isSw) {
      if (hour < 12) return 'Habari za asubuhi';
      if (hour < 16) return 'Habari za mchana';
      return 'Habari za jioni';
    } else {
      if (hour < 12) return 'Good morning';
      if (hour < 16) return 'Good afternoon';
      return 'Good evening';
    }
  };

  // PIN Input Handling
  const handlePinChange = (index: number, val: string) => {
    playKeyTap();
    setErrorMessage(null);
    const clean = val.replace(/\D/g, '');

    if (clean.length > 1) {
      // User pasted full PIN
      const digits = clean.slice(0, 4).split('');
      const newPin = [...pin];
      digits.forEach((d, i) => {
        if (i < 4) newPin[i] = d;
      });
      setPin(newPin);
      pinInputRefs[Math.min(digits.length, 3)].current?.focus();
      return;
    }

    const newPin = [...pin];
    newPin[index] = clean;
    setPin(newPin);

    // Auto-advance
    if (clean && index < 3) {
      pinInputRefs[index + 1].current?.focus();
    }
  };

  const handlePinKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      pinInputRefs[index - 1].current?.focus();
    }
  };

  // Autofill demo farmer
  const fillDemoUser = (user: UserProfile) => {
    playKeyTap();
    setMethod('phone');
    setCountryCode('+255');
    setPhoneNumber(user.phone);
    setEmail(user.email);
    setPin(user.pin.split(''));
    setErrorMessage(null);
  };

  // Login handler
  const handleLoginSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    const enteredPin = pin.join('');

    setTimeout(() => {
      // Check against mock users
      let found = DEMO_USERS.find(
        (u) =>
          (method === 'phone' && u.phone === phoneNumber.replace(/\D/g, '')) ||
          (method === 'email' && u.email.toLowerCase() === email.toLowerCase())
      );

      // If user matched demo or entered 4-digit PIN for demo test
      if (found && found.pin === enteredPin) {
        playSuccessChime();
        setIsLoading(false);
        onLoginSuccess(found);
      } else if (enteredPin === '1234' || enteredPin.length === 4) {
        // Fallback demo approval for testing any 4 digits
        playSuccessChime();
        setIsLoading(false);
        const activeUser: UserProfile = found || {
          id: 'user-active',
          name: 'Juma Bakari',
          phone: phoneNumber || '754123456',
          email: email || 'juma@ardhi.co.tz',
          pin: enteredPin,
          region: 'Morogoro',
          primaryCrops: ['Mahindi', 'Mpunga'],
          avatar: 'JB',
          accountType: 'farmer',
        };
        onLoginSuccess(activeUser);
      } else {
        setIsLoading(false);
        setShakePin(true);
        setTimeout(() => setShakePin(false), 600);
        setErrorMessage(
          isSw
            ? 'PIN uliyoweka siyo sahihi. Jaribu PIN: 1234 au bofya akaunti ya mfano.'
            : 'Invalid PIN entered. Please try PIN: 1234 or tap a demo farmer.'
        );
      }
    }, 600);
  };

  // Biometric login simulation
  const handleBiometricLogin = () => {
    setBiometricScanning(true);
    playKeyTap();

    setTimeout(() => {
      setBiometricScanning(false);
      playSuccessChime();
      const user = DEMO_USERS[0];
      onLoginSuccess(user);
    }, 1200);
  };

  // Registration handler
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regPhone.trim() || regPin.length < 4) {
      return;
    }

    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name: regName,
      phone: regPhone,
      email: `${regName.toLowerCase().replace(/\s+/g, '')}@ardhi.co.tz`,
      pin: regPin,
      region: regRegion,
      primaryCrops: [regCrop],
      avatar: regName.slice(0, 2).toUpperCase(),
      accountType: 'farmer',
    };

    setShowRegisterModal(false);
    playSuccessChime();
    onLoginSuccess(newUser);
  };

  return (
    <div id="login-page-view" className="relative w-full h-full flex flex-col overflow-y-auto bg-[var(--paper)] text-[var(--ink)]">
      {/* Top Banner Hero with Agrarian Motif */}
      <div
        className="relative flex-shrink-0 h-36 overflow-hidden rounded-b-[38px] flex items-center justify-between px-6"
        style={{
          background: 'linear-gradient(135deg, var(--forest-dark) 0%, var(--forest) 70%, #3D6A53 100%)',
        }}
      >
        {/* Subtle decorative grain rays */}
        <svg
          className="absolute -right-6 -top-8 w-44 h-44 opacity-15 pointer-events-none"
          viewBox="0 0 140 140"
        >
          <circle cx="70" cy="70" r="60" fill="none" stroke="#F7F4E9" strokeWidth="2" strokeDasharray="4 4" />
          <path d="M70 10 L70 130 M10 70 L130 70" stroke="#F7F4E9" strokeWidth="1.5" />
          <path d="M70 40 Q40 50 40 80 Q70 70 70 40 Z" fill="#F7F4E9" />
          <path d="M70 40 Q100 50 100 80 Q70 70 70 40 Z" fill="#F7F4E9" />
        </svg>

        {/* Back to intro link */}
        <button
          id="login-back-to-intro-btn"
          onClick={onBackToIntro}
          className="relative z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-amber-100/90 bg-black/25 backdrop-blur-md border border-white/10 hover:bg-black/40 transition-colors"
        >
          <span>← {isSw ? 'Utangulizi' : 'Intro'}</span>
        </button>

        <div className="relative z-10 text-right">
          <div className="text-[11px] font-semibold tracking-wider text-amber-200 uppercase">
            {getGreeting()}
          </div>
          <div className="font-display text-lg font-bold text-[#F7F4E9]">
            {isSw ? 'Karibu Ardhi' : 'Welcome to Ardhi'}
          </div>
        </div>

        {/* Floating Brand Badge */}
        <div className="absolute left-1/2 -bottom-7 -translate-x-1/2 w-16 h-16 rounded-2xl bg-[var(--paper)] border-2 border-[#C89B3C]/40 shadow-xl flex items-center justify-center">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#2C4A3B] to-[#1D332A] flex items-center justify-center text-amber-300">
            <svg className="w-6 h-7" viewBox="0 0 30 36" fill="none">
              <path d="M15 34 C15 24 15 18 15 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              <path d="M15 18 C6 16 2 9 4 3 C13 5 17 12 15 18 Z" fill="#E7C273" />
              <circle cx="15" cy="8" r="3" fill="#E7C273" />
            </svg>
          </div>
        </div>
      </div>

      {/* Main Login Body Content */}
      <div className="flex-1 flex flex-col px-6 pt-11 pb-6 max-w-md mx-auto w-full">
        {/* Title Header */}
        <div className="text-center mb-5">
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Ingia kwenye Akaunti' : 'Sign in to Account'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-1 max-w-[280px] mx-auto">
            {isSw
              ? 'Fuatilia bei za mazao, kalenda ya kupanda, na wanunuzi wako.'
              : 'Track crop prices, planting schedules, and verified buyers.'}
          </p>
        </div>

        {/* Quick Demo Autofill Bar */}
        <div className="mb-4 bg-[var(--bg)] p-2.5 rounded-2xl border border-[var(--line)]">
          <div className="flex items-center justify-between mb-1.5 px-1">
            <span className="text-[11px] font-semibold text-[var(--ink-soft)] flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-600" />
              {isSw ? 'Akaunti za Mfano (Bonyeza Kujaribu):' : 'Demo Farmer Accounts (Click to autofill):'}
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {DEMO_USERS.map((user) => {
              const isSelected = phoneNumber === user.phone;
              return (
                <button
                  key={user.id}
                  id={`demo-user-btn-${user.id}`}
                  onClick={() => fillDemoUser(user)}
                  className={`text-[11px] font-medium py-1 px-2.5 rounded-lg border transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] font-semibold shadow-sm'
                      : 'bg-[var(--paper)] text-[var(--ink)] border-[var(--line)] hover:border-[var(--forest)]'
                  }`}
                >
                  <span>{user.avatar}</span>
                  <span>{user.name.split(' ')[0]}</span>
                  <span className="opacity-70 text-[10px]">({user.primaryCrops[0]})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Method Switcher Tabs */}
        <div className="flex bg-[var(--bg)] p-1 rounded-xl border border-[var(--line)] mb-4">
          <button
            id="login-method-phone"
            type="button"
            onClick={() => {
              playKeyTap();
              setMethod('phone');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              method === 'phone'
                ? 'bg-[var(--paper)] text-[var(--forest)] shadow-sm'
                : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>{isSw ? 'Namba ya Simu' : 'Phone Number'}</span>
          </button>
          <button
            id="login-method-email"
            type="button"
            onClick={() => {
              playKeyTap();
              setMethod('email');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              method === 'email'
                ? 'bg-[var(--paper)] text-[var(--forest)] shadow-sm'
                : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>{isSw ? 'Barua Pepe' : 'Email Address'}</span>
          </button>
        </div>

        <form onSubmit={handleLoginSubmit} className="space-y-4">
          {/* Phone Field */}
          {method === 'phone' ? (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-[var(--ink-soft)]">
                  {isSw ? 'Namba ya Simu' : 'Phone Number'}
                </label>
                {detectedOp && (
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${detectedOp.color}`}>
                    {detectedOp.name}
                  </span>
                )}
              </div>
              <div className="flex items-center rounded-xl bg-[var(--bg)] border border-[var(--line)] focus-within:border-[var(--forest)] focus-within:ring-2 focus-within:ring-[var(--forest)]/15 transition-all overflow-hidden">
                {/* Country selector */}
                <select
                  id="login-country-select"
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  className="bg-transparent text-xs font-semibold text-[var(--ink)] py-3 pl-3 pr-2 border-r border-[var(--line)] outline-none cursor-pointer"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c.code} value={c.code} className="bg-[var(--paper)] text-[var(--ink)]">
                      {c.flag} {c.code}
                    </option>
                  ))}
                </select>
                <input
                  id="login-phone-input"
                  type="tel"
                  inputMode="numeric"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder={COUNTRIES.find((c) => c.code === countryCode)?.placeholder || '754 123 456'}
                  className="w-full bg-transparent px-3 py-3 text-sm font-medium text-[var(--ink)] placeholder-[var(--ink-soft)]/50 outline-none"
                />
              </div>
            </div>
          ) : (
            /* Email Field */
            <div>
              <label className="block text-xs font-medium text-[var(--ink-soft)] mb-1.5">
                {isSw ? 'Barua Pepe' : 'Email Address'}
              </label>
              <div className="flex items-center rounded-xl bg-[var(--bg)] border border-[var(--line)] focus-within:border-[var(--forest)] focus-within:ring-2 focus-within:ring-[var(--forest)]/15 transition-all px-3 py-3">
                <Mail className="w-4 h-4 text-[var(--ink-soft)] mr-2 flex-shrink-0" />
                <input
                  id="login-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="juma@ardhi.co.tz"
                  className="w-full bg-transparent text-sm font-medium text-[var(--ink)] placeholder-[var(--ink-soft)]/50 outline-none"
                />
              </div>
            </div>
          )}

          {/* 4-Digit PIN Field */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-[var(--ink-soft)] flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" />
                <span>{isSw ? 'PIN ya Siri (tarakimu 4)' : 'Security PIN (4 digits)'}</span>
              </label>
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="text-[11px] text-[var(--ink-soft)] hover:text-[var(--forest)] flex items-center gap-1 transition-colors"
              >
                {showPin ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showPin ? (isSw ? 'Ficha' : 'Hide') : (isSw ? 'Onyesha' : 'Show')}</span>
              </button>
            </div>

            {/* PIN digit boxes */}
            <motion.div
              animate={shakePin ? { x: [-10, 10, -8, 8, -4, 4, 0] } : {}}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-4 gap-2.5"
            >
              {pin.map((digit, index) => (
                <input
                  key={index}
                  ref={pinInputRefs[index]}
                  id={`login-pin-box-${index}`}
                  type={showPin ? 'text' : 'password'}
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handlePinChange(index, e.target.value)}
                  onKeyDown={(e) => handlePinKeyDown(index, e)}
                  className="w-full aspect-square text-center font-display text-xl font-bold bg-[var(--bg)] text-[var(--ink)] rounded-xl border-2 border-[var(--line)] focus:border-[var(--forest)] focus:ring-2 focus:ring-[var(--forest)]/15 outline-none transition-all"
                />
              ))}
            </motion.div>

            <div className="flex justify-between items-center mt-2">
              <span className="text-[10px] text-[var(--ink-soft)]">
                {isSw ? 'PIN ya mfano: 1234' : 'Default demo PIN: 1234'}
              </span>
              <button
                id="login-forgot-pin-btn"
                type="button"
                onClick={() => {
                  setShowForgotModal(true);
                  setForgotStep('phone');
                }}
                className="text-xs font-semibold text-[var(--soil)] hover:underline"
              >
                {isSw ? 'Umesahau PIN?' : 'Forgot PIN?'}
              </button>
            </div>
          </div>

          {/* Error message alert */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Login Submit Button */}
          <button
            id="login-submit-btn"
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-5 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-semibold text-sm shadow-md shadow-[var(--forest)]/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all disabled:opacity-60 cursor-pointer"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{isSw ? 'Inathibitisha...' : 'Authenticating...'}</span>
              </>
            ) : (
              <>
                <span>{isSw ? 'Ingia Sasa' : 'Log in Now'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Biometric Quick Login */}
        <div className="mt-3">
          <button
            id="login-biometric-btn"
            type="button"
            onClick={handleBiometricLogin}
            disabled={biometricScanning}
            className="w-full py-2.5 px-4 rounded-xl bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink)] text-xs font-semibold flex items-center justify-center gap-2 transition-all"
          >
            <Fingerprint className={`w-4 h-4 text-[var(--forest)] ${biometricScanning ? 'animate-pulse text-amber-500' : ''}`} />
            <span>
              {biometricScanning
                ? (isSw ? 'Inasoma alama ya kidole...' : 'Scanning fingerprint...')
                : (isSw ? 'Ingia kwa Alama ya Kidole' : 'Sign in with Biometrics')}
            </span>
          </button>
        </div>

        {/* Divider */}
        <div className="relative my-4 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-[var(--line)]" />
          </div>
          <span className="relative bg-[var(--paper)] px-3 text-[11px] font-medium text-[var(--ink-soft)] uppercase">
            {isSw ? 'au' : 'or'}
          </span>
        </div>

        {/* New Farmer Sign Up Button */}
        <button
          id="login-signup-btn"
          type="button"
          onClick={() => setShowRegisterModal(true)}
          className="w-full py-3 px-4 rounded-xl border border-[var(--forest)] text-[var(--forest)] hover:bg-[var(--forest)]/10 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
        >
          <UserPlus className="w-4 h-4" />
          <span>{isSw ? 'Jisajili kama Mkulima Mpya' : 'Sign up as a New Farmer'}</span>
        </button>

        {/* Trust & Offline Capability Note */}
        <div className="mt-auto pt-5 text-center flex flex-col items-center gap-1 text-[11px] text-[var(--ink-soft)]">
          <div className="flex items-center gap-1.5 text-[var(--forest)] font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{isSw ? 'Data yako inalindwa na kufanya kazi nje ya mtandao' : 'End-to-end encrypted & offline accessible'}</span>
          </div>
          <p className="text-[10px] opacity-75">
            {isSw
              ? 'Kwa kuendelea unakubali Masharti ya Matumizi na Faragha ya Ardhi.'
              : 'By signing in, you agree to Ardhi Terms of Service & Privacy Policy.'}
          </p>
        </div>
      </div>

      {/* MODAL: Forgot PIN Flow */}
      <AnimatePresence>
        {showForgotModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-2xl p-5 border border-[var(--line)] shadow-2xl relative"
            >
              <button
                onClick={() => setShowForgotModal(false)}
                className="absolute top-4 right-4 p-1 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <h3 className="font-display text-lg font-bold text-[var(--ink)] mb-1">
                {isSw ? 'Weka Upya PIN ya Ardhi' : 'Reset Ardhi PIN'}
              </h3>

              {forgotStep === 'phone' && (
                <div className="space-y-3 mt-3">
                  <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                    {isSw
                      ? 'Weka namba yako ya simu. Tutakutumia msimbo mfupi wa kuthibitisha (SMS).'
                      : 'Enter your phone number. We will send you a verification code via SMS.'}
                  </p>
                  <div className="p-3 bg-[var(--bg)] rounded-xl border border-[var(--line)] text-sm font-semibold">
                    {countryCode} {phoneNumber}
                  </div>
                  <button
                    onClick={() => {
                      setForgotOtp('5821');
                      setForgotStep('otp');
                    }}
                    className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-semibold text-xs flex items-center justify-center gap-1.5"
                  >
                    <span>{isSw ? 'Tuma Msimbo wa SMS' : 'Send SMS Code'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {forgotStep === 'otp' && (
                <div className="space-y-3 mt-3">
                  <p className="text-xs text-[var(--ink-soft)]">
                    {isSw
                      ? `Msimbo wa SMS umetumwa kwenye ${countryCode} ${phoneNumber}. (Msimbo wa mfano: 5821)`
                      : `SMS code sent to ${countryCode} ${phoneNumber}. (Demo code: 5821)`}
                  </p>
                  <input
                    type="text"
                    maxLength={4}
                    value={forgotOtp}
                    onChange={(e) => setForgotOtp(e.target.value)}
                    placeholder="5821"
                    className="w-full text-center font-display text-2xl font-bold tracking-widest py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)]"
                  />
                  <button
                    onClick={() => {
                      setPin(['1', '2', '3', '4']);
                      setForgotStep('success');
                      setTimeout(() => {
                        setShowForgotModal(false);
                      }, 1500);
                    }}
                    className="w-full py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-semibold text-xs"
                  >
                    {isSw ? 'Thibitisha na Weka PIN (1234)' : 'Verify & Set PIN (1234)'}
                  </button>
                </div>
              )}

              {forgotStep === 'success' && (
                <div className="text-center py-4 space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto animate-bounce" />
                  <div className="font-semibold text-sm text-[var(--ink)]">
                    {isSw ? 'PIN Imewekwa Upya Kikamilifu!' : 'PIN Reset Successfully!'}
                  </div>
                  <div className="text-xs text-[var(--ink-soft)]">
                    {isSw ? 'Sasa unaweza kuingia kwa PIN: 1234' : 'You can now sign in with PIN: 1234'}
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Register New Farmer */}
      <AnimatePresence>
        {showRegisterModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-[var(--paper)] rounded-2xl p-5 border border-[var(--line)] shadow-2xl relative my-8"
            >
              <button
                onClick={() => setShowRegisterModal(false)}
                className="absolute top-4 right-4 p-1 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              <h3 className="font-display text-lg font-bold text-[var(--ink)] mb-1">
                {isSw ? 'Usajili wa Mkulima Mpya' : 'New Farmer Registration'}
              </h3>
              <p className="text-xs text-[var(--ink-soft)] mb-4">
                {isSw
                  ? 'Jiunge na maelfu ya wakulima wanaofaidika na masoko na hali ya hewa ya Ardhi.'
                  : 'Join thousands of farmers tracking market prices and optimal planting seasons.'}
              </p>

              <form onSubmit={handleRegisterSubmit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Jina Kamili' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder={isSw ? 'Mfano: Baraka Ally' : 'e.g. Baraka Ally'}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none focus:border-[var(--forest)]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Namba ya Simu' : 'Phone Number'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="755 000 111"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none focus:border-[var(--forest)]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                      {isSw ? 'Mkoa / Eneo' : 'Region'}
                    </label>
                    <select
                      value={regRegion}
                      onChange={(e) => setRegRegion(e.target.value)}
                      className="w-full px-2.5 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                    >
                      <option value="Morogoro">Morogoro</option>
                      <option value="Arusha">Arusha</option>
                      <option value="Iringa">Iringa</option>
                      <option value="Mbeya">Mbeya</option>
                      <option value="Kilimanjaro">Kilimanjaro</option>
                      <option value="Tanga">Tanga</option>
                      <option value="Dodoma">Dodoma</option>
                      <option value="Eldoret">Eldoret (KE)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                      {isSw ? 'Zao Kuu' : 'Primary Crop'}
                    </label>
                    <select
                      value={regCrop}
                      onChange={(e) => setRegCrop(e.target.value)}
                      className="w-full px-2.5 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
                    >
                      <option value="Mahindi">{isSw ? 'Mahindi' : 'Maize'}</option>
                      <option value="Mpunga">{isSw ? 'Mpunga' : 'Rice'}</option>
                      <option value="Kahawa">{isSw ? 'Kahawa' : 'Coffee'}</option>
                      <option value="Korosho">{isSw ? 'Korosho' : 'Cashew'}</option>
                      <option value="Maharage">{isSw ? 'Maharage' : 'Beans'}</option>
                      <option value="Karanga">{isSw ? 'Karanga' : 'Groundnuts'}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--ink-soft)] mb-1">
                    {isSw ? 'Weka PIN ya Siri (tarakimu 4)' : 'Set 4-Digit Security PIN'}
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={regPin}
                    onChange={(e) => setRegPin(e.target.value)}
                    placeholder="****"
                    className="w-full px-3 py-2 text-center font-display text-lg tracking-widest rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none focus:border-[var(--forest)]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-3 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md hover:bg-[var(--forest-dark)]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSw ? 'Kamilisha Usajili na Uingie' : 'Complete Registration & Sign In'}</span>
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
