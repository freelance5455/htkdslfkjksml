import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ArrowRight,
  Lock,
  Mail,
  Smartphone,
  User,
  ShieldCheck,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EventraLogo } from './ui/EventraLogo';
import {
  SUPPORTED_COUNTRIES,
  normalizePhoneToE164,
  isValidPhoneNumber,
} from '../utils/phoneUtils';

export const LoginPage: React.FC = () => {
  const {
    signInWithDemoPass,
    signInWithGoogle,
    signInWithEmail,
    registerWithEmail,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');

  // Sign in fields
  const [signInIdentifier, setSignInIdentifier] = useState('maya.lin@gmail.com');
  const [signInPassword, setSignInPassword] = useState('passcode123');

  // Sign up fields
  const [signUpName, setSignUpName] = useState('Maya Lin');
  const [signUpCountryCode, setSignUpCountryCode] = useState('+254');
  const [signUpPhone, setSignUpPhone] = useState('0712 345 678');
  const [signUpEmail, setSignUpEmail] = useState('maya.lin@gmail.com');
  const [signUpPassword, setSignUpPassword] = useState('passcode123');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);
    try {
      await signInWithEmail(signInIdentifier.trim(), signInPassword);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to sign in. Please verify your credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    if (!signUpName.trim() || !signUpEmail.trim()) {
      setErrorMessage('Please provide your legal full name and email address');
      return;
    }
    if (!isValidPhoneNumber(signUpPhone)) {
      setErrorMessage('Please enter a valid mobile number (e.g. 0712 345 678)');
      return;
    }

    setIsSubmitting(true);
    try {
      await registerWithEmail(
        signUpEmail.trim(),
        signUpPassword,
        signUpName.trim(),
        signUpPhone.trim(),
        signUpCountryCode
      );
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to create account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setIsSubmitting(true);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      setErrorMessage(err.message || 'Google Sign-In was cancelled or closed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickDemoPass = async () => {
    setErrorMessage(null);
    setIsSubmitting(true);
    try {
      await signInWithDemoPass();
    } catch {
      setErrorMessage('Demo authentication error. Please try email sign-in.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-[#090a0d] text-[#f4f4f6] overflow-hidden font-sans">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Card Container */}
      <div className="relative z-10 w-full max-w-[430px] bg-[#111317] rounded-[32px] p-7 sm:p-9 shadow-2xl border border-[#1f2229]">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="mb-3.5">
            <EventraLogo size="lg" showText={false} />
          </div>
          <div className="flex items-center gap-1.5">
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              {activeTab === 'signin' ? 'Sign in to Eventra' : 'Create Account'}
            </h1>
          </div>
          <p className="mt-1.5 text-xs text-[#9496a1] max-w-xs leading-relaxed">
            {activeTab === 'signin'
              ? 'Access your unified passbook, live bookings & host studio'
              : 'One passbook for live festivals, symphonies & stadium tickets'}
          </p>
        </div>

        {/* Error notification banner */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-2xl bg-red-950/60 border border-red-800/80 flex items-start gap-2.5 text-red-400 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed font-medium">{errorMessage}</p>
          </div>
        )}

        {/* Segmented Pill Switcher */}
        <div className="p-1 bg-[#17191f] border border-[#232733] rounded-full flex items-center justify-between mb-6 relative">
          <button
            type="button"
            onClick={() => {
              setActiveTab('signin');
              setErrorMessage(null);
            }}
            className={`relative flex-1 py-2 text-xs font-semibold rounded-full text-center transition-colors cursor-pointer z-10 ${
              activeTab === 'signin'
                ? 'text-white font-bold'
                : 'text-[#9496a1] hover:text-white'
            }`}
          >
            {activeTab === 'signin' && (
              <motion.div
                layoutId="authSegmentTab"
                className="absolute inset-0 bg-[#252834] rounded-full shadow-xs -z-10 border border-[#353a4b]"
                transition={{ type: 'spring', stiffness: 500, damping: 38 }}
              />
            )}
            Sign In
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setErrorMessage(null);
            }}
            className={`relative flex-1 py-2 text-xs font-semibold rounded-full text-center transition-colors cursor-pointer z-10 ${
              activeTab === 'signup'
                ? 'text-white font-bold'
                : 'text-[#9496a1] hover:text-white'
            }`}
          >
            {activeTab === 'signup' && (
              <motion.div
                layoutId="authSegmentTab"
                className="absolute inset-0 bg-[#252834] rounded-full shadow-xs -z-10 border border-[#353a4b]"
                transition={{ type: 'spring', stiffness: 500, damping: 38 }}
              />
            )}
            Create Account
          </button>
        </div>

        {/* Forms with Spacious, High-Contrast Inputs */}
        <AnimatePresence mode="wait">
          {activeTab === 'signin' ? (
            <motion.form
              key="signin-form"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.15 }}
              onSubmit={handleSignIn}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={signInIdentifier}
                    onChange={(e) => setSignInIdentifier(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full h-12 pl-11 pr-4 text-sm text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                  />
                  <Mail className="absolute left-4 top-3.5 w-4 h-4 text-[#787b89]" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full h-12 pl-11 pr-4 text-sm text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                  />
                  <Lock className="absolute left-4 top-3.5 w-4 h-4 text-[#787b89]" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-12 mt-2 flex items-center justify-center gap-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold active:scale-[0.98] transition-all cursor-pointer shadow-lg shadow-emerald-500/20 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <span>Continue to Eventra</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </motion.form>
          ) : (
            <motion.form
              key="signup-form"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.15 }}
              onSubmit={handleSignUp}
              className="space-y-3.5"
            >
              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Full Legal Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={signUpName}
                    onChange={(e) => setSignUpName(e.target.value)}
                    placeholder="Maya Lin"
                    className="w-full h-12 pl-11 pr-4 text-sm text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                  />
                  <User className="absolute left-4 top-3.5 w-4 h-4 text-[#787b89]" />
                </div>
              </div>

              {/* Primary Contact Identity: Country & Phone */}
              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Mobile Number (Kenya Default)
                </label>
                <div className="grid grid-cols-12 gap-2">
                  <select
                    value={signUpCountryCode}
                    onChange={(e) => setSignUpCountryCode(e.target.value)}
                    className="col-span-5 h-12 px-3 text-xs font-semibold text-[#f4f4f6] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500"
                  >
                    {SUPPORTED_COUNTRIES.map((c) => (
                      <option key={c.code} value={c.dialCode} className="bg-[#16181f] text-white">
                        {c.flag} {c.dialCode}
                      </option>
                    ))}
                  </select>

                  <div className="relative col-span-7">
                    <input
                      type="tel"
                      required
                      value={signUpPhone}
                      onChange={(e) => setSignUpPhone(e.target.value)}
                      placeholder="0712 345 678"
                      className="w-full h-12 pl-10 pr-3 text-sm font-mono text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                    />
                    <Smartphone className="absolute left-3.5 top-3.5 w-4 h-4 text-emerald-400" />
                  </div>
                </div>
                <span className="block text-[10px] text-[#646875] mt-1 ml-1">
                  E.164: {normalizePhoneToE164(signUpPhone, signUpCountryCode)}
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full h-12 pl-11 pr-4 text-sm text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                  />
                  <Mail className="absolute left-4 top-3.5 w-4 h-4 text-[#787b89]" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b8b9c2] mb-1.5 ml-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full h-12 pl-11 pr-4 text-sm text-[#f4f4f6] placeholder:text-[#5d606f] bg-[#16181f] rounded-2xl border border-[#262934] focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-medium"
                  />
                  <Lock className="absolute left-4 top-3.5 w-4 h-4 text-[#787b89]" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-12 mt-2 flex items-center justify-center gap-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold active:scale-[0.98] transition-all cursor-pointer shadow-lg shadow-emerald-500/20 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Creating account...</span>
                  </>
                ) : (
                  <>
                    <span>Create Eventra Account</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Divider */}
        <div className="relative my-5 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-[#1f2229]" />
          </div>
          <span className="relative px-3 text-[11px] font-semibold text-[#646875] bg-[#111317]">
            or continue with
          </span>
        </div>

        {/* Google Authentication */}
        <div>
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isSubmitting}
            className="w-full h-12 flex items-center justify-center gap-2.5 px-4 rounded-2xl bg-[#16181f] hover:bg-[#1c1f28] text-[#f4f4f6] text-xs font-semibold border border-[#262934] active:scale-[0.98] transition-all cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>
        </div>

        {/* Quick Demo Option & Cloud Sync Badge */}
        <div className="mt-5 pt-4 border-t border-[#1f2229] text-center space-y-2">
          <button
            type="button"
            onClick={handleQuickDemoPass}
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
          >
            Instant Passholder Demo (Maya Lin · Nairobi)
          </button>

          <div className="flex items-center justify-center gap-1.5 text-[10px] text-[#646875]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>Cross-Device Cloud Firestore & Safaricom STK Push</span>
          </div>
        </div>
      </div>
    </div>
  );
};
