import React from 'react';
import { Sparkles, Home, Shield, Music, Compass } from 'lucide-react';

interface NotFoundViewProps {
  onReturnHome: () => void;
}

export const NotFoundView: React.FC<NotFoundViewProps> = ({ onReturnHome }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background celestial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.08)_0%,transparent_70%)] pointer-events-none" />
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-yellow-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-md w-full bg-slate-900/90 border border-amber-500/30 rounded-3xl p-8 shadow-2xl text-center space-y-6 relative z-10 backdrop-blur-xl animate-fadeIn">
        <div className="w-20 h-20 bg-amber-500/20 border border-amber-500/40 rounded-3xl flex items-center justify-center mx-auto text-amber-400 shadow-lg shadow-amber-500/10 animate-bounce">
          <Sparkles className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold rounded-full uppercase tracking-wider">
            Sanctuary 404 - Page Not Found
          </span>
          <h1 className="text-3xl font-extrabold font-serif text-amber-100">
            Path Uncharted in the Spirit
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            The celestial pathway or URL you requested does not exist or has been translated in the glory. Let us guide you back to the sanctuary altar.
          </p>
        </div>

        <div className="pt-4 space-y-3">
          <button
            onClick={onReturnHome}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-sm flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-105"
          >
            <Home className="w-5 h-5" />
            <span>Return to Sanctuary (Worship)</span>
          </button>
        </div>

        <div className="pt-4 border-t border-slate-800 flex items-center justify-center space-x-2 text-xs text-slate-400">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>JUHNKRIX MUSIKA &bull; Prophet Juhnkrix Synvagord</span>
        </div>
      </div>
    </div>
  );
};
