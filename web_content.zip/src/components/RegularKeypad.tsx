import { Delete } from 'lucide-react';

export interface RegularKeypadProps {
  onDigit: (digit: string) => void;
  onDecimal: () => void;
  onOperator: (op: '+' | '−' | '×' | '÷') => void;
  onPercent: () => void;
  onToggleSign: () => void;
  onClear: () => void;
  onBackspace: () => void;
  onEquals: () => void;
  compact?: boolean;
}

export function RegularKeypad({
  onDigit,
  onDecimal,
  onOperator,
  onPercent,
  onToggleSign,
  onClear,
  onBackspace,
  onEquals,
  compact = false,
}: RegularKeypadProps) {
  const heightClass = compact ? 'h-12 sm:h-[52px]' : 'h-14 sm:h-16';
  const radiusClass = compact ? 'rounded-xl sm:rounded-2xl' : 'rounded-2xl';
  const numTextClass = compact ? 'text-xl sm:text-2xl' : 'text-2xl';
  const opTextClass = compact ? 'text-xl sm:text-2xl' : 'text-2xl';

  const baseKey = `calc-key ${heightClass} ${radiusClass} flex items-center justify-center font-semibold select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500`;
  const numberKey = `${baseKey} ${numTextClass} font-mono tabular-nums bg-zinc-100 hover:bg-zinc-200/85 active:bg-zinc-200 dark:bg-zinc-800/90 dark:hover:bg-zinc-700/90 text-zinc-900 dark:text-zinc-50`;
  const utilityKey = `${baseKey} text-lg sm:text-xl bg-zinc-200/75 hover:bg-zinc-300/80 dark:bg-zinc-800/45 dark:hover:bg-zinc-700/60 text-zinc-800 dark:text-zinc-200`;
  const clearKey = `${baseKey} text-lg sm:text-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400`;
  const operatorKey = `${baseKey} ${opTextClass} bg-blue-50 hover:bg-blue-100 dark:bg-blue-500/15 dark:hover:bg-blue-500/25 text-blue-700 dark:text-blue-300`;
  const equalsKey = `${baseKey} ${opTextClass} bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-600/25`;

  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-2.5">
      {/* Row 1 */}
      <button type="button" onClick={onClear} className={clearKey} aria-label="All Clear">
        AC
      </button>
      <button type="button" onClick={onBackspace} className={utilityKey} aria-label="Backspace">
        <Delete className="w-5 h-5 sm:w-6 sm:h-6" aria-hidden="true" />
      </button>
      <button type="button" onClick={onPercent} className={utilityKey} aria-label="Percent">
        %
      </button>
      <button type="button" onClick={() => onOperator('÷')} className={operatorKey} aria-label="Divide">
        ÷
      </button>

      {/* Row 2 */}
      <button type="button" onClick={() => onDigit('7')} className={numberKey}>
        7
      </button>
      <button type="button" onClick={() => onDigit('8')} className={numberKey}>
        8
      </button>
      <button type="button" onClick={() => onDigit('9')} className={numberKey}>
        9
      </button>
      <button type="button" onClick={() => onOperator('×')} className={operatorKey} aria-label="Multiply">
        ×
      </button>

      {/* Row 3 */}
      <button type="button" onClick={() => onDigit('4')} className={numberKey}>
        4
      </button>
      <button type="button" onClick={() => onDigit('5')} className={numberKey}>
        5
      </button>
      <button type="button" onClick={() => onDigit('6')} className={numberKey}>
        6
      </button>
      <button type="button" onClick={() => onOperator('−')} className={operatorKey} aria-label="Subtract">
        −
      </button>

      {/* Row 4 */}
      <button type="button" onClick={() => onDigit('1')} className={numberKey}>
        1
      </button>
      <button type="button" onClick={() => onDigit('2')} className={numberKey}>
        2
      </button>
      <button type="button" onClick={() => onDigit('3')} className={numberKey}>
        3
      </button>
      <button type="button" onClick={() => onOperator('+')} className={operatorKey} aria-label="Add">
        +
      </button>

      {/* Row 5 */}
      <button type="button" onClick={onToggleSign} className={numberKey} aria-label="Plus Minus">
        +/−
      </button>
      <button type="button" onClick={() => onDigit('0')} className={numberKey}>
        0
      </button>
      <button type="button" onClick={onDecimal} className={numberKey} aria-label="Decimal point">
        .
      </button>
      <button type="button" onClick={onEquals} className={equalsKey} aria-label="Equals">
        =
      </button>
    </div>
  );
}
