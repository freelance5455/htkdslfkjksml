import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { History, Trash2, Search, Filter, Download, ArrowLeft, RefreshCw, ShieldCheck, CheckCircle2, Copy, Check, Eye, AlertTriangle, Sparkles, Smartphone, Zap, DollarSign, Database, FileText } from 'lucide-react';
import { imsiEngine, ImsiMessageItem, ImsiLedgerTransaction, ImsiEngineConfig } from '../lib/imsiEngine';
import { financialMessenger } from '../lib/financialMessenger';

interface ImsiDataInfoViewProps {
  onBackToOwner?: () => void;
  onOpenConverto?: () => void;
}

export const ImsiDataInfoView: React.FC<ImsiDataInfoViewProps> = ({ onBackToOwner, onOpenConverto }) => {
  const [messages, setMessages] = useState<ImsiMessageItem[]>(() => imsiEngine.getMessages());
  const [ledger, setLedger] = useState<ImsiLedgerTransaction[]>(() => imsiEngine.getLedger());
  const [config, setConfig] = useState<ImsiEngineConfig>(() => imsiEngine.getConfig());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'INCOMING' | 'OUTGOING'>('ALL');
  const [selectedMessage, setSelectedMessage] = useState<ImsiMessageItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState<boolean>(false);
  const [itemToDelete, setItemToDelete] = useState<string | 'ALL' | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  useEffect(() => {
    const unsub = imsiEngine.subscribe(() => {
      setMessages(imsiEngine.getMessages());
      setLedger(imsiEngine.getLedger());
      setConfig(imsiEngine.getConfig());
    });
    return () => unsub();
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast(`✓ Copied to clipboard!`);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleDeleteItem = (id: string) => {
    imsiEngine.deleteMessage(id);
    showToast('✓ IMSI Transaction record deleted successfully.');
    if (selectedMessage?.id === id) {
      setSelectedMessage(null);
    }
  };

  const handleClearAll = () => {
    messages.forEach(m => imsiEngine.deleteMessage(m.id));
    imsiEngine.clearLedger();
    showToast('✓ All IMSI Transaction Data successfully purged.');
    setShowDeleteConfirmModal(false);
    setItemToDelete(null);
  };

  const handleSimulateNewIncoming = async () => {
    showToast('Simulating incoming carrier SMS with ₦5 deduction...');
    imsiEngine.simulateIncomingBatch();
  };

  const handleExportJson = () => {
    const data = {
      imsiBinding: config,
      messages,
      ledger,
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_IMSI_TRANSACTIONS_DATA_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('✓ IMSI Transactions Data exported as JSON!');
  };

  const handleExportCsv = () => {
    const headers = 'ID,IMSI_ID,SenderPhone,TargetPhone,Direction,MessageText,ChargeNGN,SimCarrier,DeductionType,CashCreditedNGN,BtcSatsCredited,TxHash,BankRef,Timestamp\n';
    const rows = messages.map(m =>
      `"${m.id}","${m.imsiId}","${m.senderPhone.replace(/"/g, '""')}","${m.targetPhone.replace(/"/g, '""')}","${m.direction}","${m.messageText.replace(/"/g, '""')}","${m.chargeNgn}","${m.simCarrier.replace(/"/g, '""')}","${m.deductionType}","${m.convertedCredit.cashNgn}","${m.convertedCredit.btcSats}","${m.convertedCredit.blockchainTxHash}","${m.convertedCredit.bankRefNumber}","${m.timestamp}"`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_IMSI_TRANSACTIONS_DATA_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('✓ IMSI Transactions Data exported as CSV!');
  };

  const filteredMessages = messages.filter(m => {
    const matchesSearch = !searchQuery.trim() ||
      m.senderPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.messageText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.simCarrier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.convertedCredit.bankRefNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.convertedCredit.blockchainTxHash.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDirection = filterDirection === 'ALL' ||
      (filterDirection === 'INCOMING' && m.direction === 'incoming') ||
      (filterDirection === 'OUTGOING' && m.direction === 'outgoing');
    return matchesSearch && matchesDirection;
  });

  return (
    <div className="space-y-8 animate-fadeIn text-slate-100 max-w-7xl mx-auto">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 border-2 border-amber-400 text-amber-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              {onBackToOwner && (
                <button
                  onClick={onBackToOwner}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-all flex items-center space-x-1 text-xs font-bold"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Owner Dashboard</span>
                </button>
              )}
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>IMSI DATA INFO & TELECOMMUNICATIONS ARCHIVE</span>
              </div>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-amber-100">
              IMSI Telecommunications & Transaction Information Page
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl">
              Dedicated storage archive for all International Mobile Subscriber Identity (IMSI) transactions, ₦5 carrier billing streams, airtime & data deductions, and blockchain ledger entries bound to <strong className="text-amber-200">07071918280</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleSimulateNewIncoming}
              className="px-4 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/30 transition-all hover:scale-105"
            >
              <Zap className="w-4 h-4 text-slate-950" />
              <span>Simulate Incoming SMS (₦5)</span>
            </button>

            {onOpenConverto && (
              <button
                onClick={onOpenConverto}
                className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center space-x-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>CONVERTO Engine</span>
              </button>
            )}

            <button
              onClick={() => {
                setItemToDelete('ALL');
                setShowDeleteConfirmModal(true);
              }}
              className="px-4 py-3 rounded-2xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-500/30 font-bold text-xs flex items-center space-x-2 transition-all"
            >
              <Trash2 className="w-4 h-4 text-rose-400" />
              <span>Purge All Data</span>
            </button>
          </div>
        </div>

        {/* Hardware Status Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Bound Mobile</span>
            <div className="text-sm font-extrabold text-amber-300">{config.boundPhoneNumber}</div>
            <div className="text-[10px] text-slate-500">Prophet JUHNKRIX</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">IMSI Hardware ID</span>
            <div className="text-xs font-mono font-extrabold text-amber-300 truncate">{config.imsiNumber}</div>
            <div className="text-[10px] text-emerald-400 font-bold">ONLINE ACTIVE</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Magic Fixed IP</span>
            <div className="text-xs font-mono font-extrabold text-amber-300">{config.magicIp}</div>
            <div className="text-[10px] text-slate-500">juhnkrixmusika.pages.dev</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Total Stored Records</span>
            <div className="text-sm font-extrabold text-amber-300">{messages.length} Transactions</div>
            <div className="text-[10px] text-emerald-400 font-bold">Auto-Persisted in Vault</div>
          </div>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="bg-slate-950 border border-amber-500/30 rounded-3xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search sender, message, carrier, txHash..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
            {(['ALL', 'INCOMING', 'OUTGOING'] as const).map((dir) => (
              <button
                key={dir}
                onClick={() => setFilterDirection(dir)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  filterDirection === dir
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-amber-200'
                }`}
              >
                {dir}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>

          <button
            onClick={handleExportJson}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Main Transactions List */}
      <div className="space-y-4">
        {filteredMessages.length === 0 ? (
          <div className="bg-slate-950 border border-slate-800 rounded-3xl p-12 text-center text-slate-400 space-y-3">
            <Smartphone className="w-12 h-12 mx-auto text-amber-400/40 animate-pulse" />
            <h3 className="text-base font-bold text-slate-200">No IMSI Transactions Found</h3>
            <p className="text-xs">No records match your query. Click &apos;Simulate Incoming SMS&apos; to generate test records.</p>
          </div>
        ) : (
          filteredMessages.map((msg) => (
            <div
              key={msg.id}
              className="bg-slate-950 border border-amber-500/20 hover:border-amber-500/50 rounded-3xl p-5 sm:p-6 transition-all shadow-xl space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-3">
                  <div className={`w-9 h-9 rounded-2xl flex items-center justify-center font-bold text-xs ${
                    msg.direction === 'incoming'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  }`}>
                    {msg.direction === 'incoming' ? 'IN' : 'OUT'}
                  </div>
                  <div>
                    <div className="text-sm font-extrabold text-slate-100 flex items-center space-x-2">
                      <span>{msg.senderPhone}</span>
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {msg.imsiId}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Carrier: <strong className="text-slate-300">{msg.simCarrier}</strong> • {msg.timestamp}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black">
                    ₦{msg.chargeNgn.toFixed(2)} Charged
                  </span>
                  <button
                    onClick={() => setSelectedMessage(msg)}
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1 transition-all"
                    title="View full transaction details"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Read Details</span>
                  </button>
                  <button
                    onClick={() => handleDeleteItem(msg.id)}
                    className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 text-rose-400 border border-rose-500/30 transition-colors"
                    title="Delete this transaction record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Message Payload Text */}
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans">
                <span className="text-slate-500 font-bold uppercase text-[10px] block mb-1">SMS Payload:</span>
                &quot;{msg.messageText}&quot;
              </div>

              {/* Financial Settlement & Blockchain Strip */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] bg-slate-900/40 p-3 rounded-2xl border border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[10px]">Settled Value:</span>
                  <span className="font-bold text-amber-300">
                    ₦{msg.convertedCredit.cashNgn.toFixed(2)} Cash / {msg.convertedCredit.btcSats} Sats ({msg.convertedCredit.btcFormatted})
                  </span>
                </div>

                <div className="truncate">
                  <span className="text-slate-500 block text-[10px]">Bank Reference:</span>
                  <span className="font-mono text-slate-300 truncate">{msg.convertedCredit.bankRefNumber}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="truncate">
                    <span className="text-slate-500 block text-[10px]">Blockchain TxHash:</span>
                    <span className="font-mono text-amber-400/80 text-[10px] truncate max-w-[150px] inline-block">{msg.convertedCredit.blockchainTxHash}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(msg.convertedCredit.blockchainTxHash, msg.id)}
                    className="text-slate-400 hover:text-amber-300 p-1"
                  >
                    {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Detailed Read Transaction Modal */}
      {selectedMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 border-2 border-amber-500/60 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-4">
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-black uppercase">
                  <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>IMSI TRANSACTION INSPECTOR</span>
                </div>
                <h3 className="text-xl font-bold font-serif text-amber-100">
                  Full Transaction & Telecommunications Breakdown
                </h3>
              </div>
              <button
                onClick={() => setSelectedMessage(null)}
                className="text-slate-400 hover:text-amber-200 text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Transaction ID</span>
                  <span className="font-mono text-amber-300">{selectedMessage.id}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">IMSI Identifier</span>
                  <span className="font-mono text-amber-300">{selectedMessage.imsiId}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Sender Mobile Number</span>
                  <span className="font-extrabold text-slate-200">{selectedMessage.senderPhone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Target Mobile Number</span>
                  <span className="font-extrabold text-slate-200">{selectedMessage.targetPhone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Telecom Carrier & Gateway</span>
                  <span className="text-slate-200">{selectedMessage.simCarrier}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Tariff Deduction Type</span>
                  <span className="text-emerald-400 font-bold uppercase">{selectedMessage.deductionType.replace('_', ' ')} (₦{selectedMessage.chargeNgn})</span>
                </div>
              </div>

              {/* Message Content */}
              <div className="bg-slate-900 p-4 rounded-2xl border border-amber-500/20 space-y-2">
                <span className="text-[10px] font-bold text-amber-300 uppercase">SMS Text Message Body:</span>
                <p className="text-sm text-slate-100 leading-relaxed font-serif bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {selectedMessage.messageText}
                </p>
              </div>

              {/* Financial Breakdown */}
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-[10px] font-bold text-amber-300 uppercase block">Financial & Blockchain Ledger Settlement:</span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">Cash Money Credited</span>
                    <span className="font-black text-emerald-400 text-sm">₦{selectedMessage.convertedCredit.cashNgn.toFixed(2)} NGN</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">Bitcoin Tokenized</span>
                    <span className="font-black text-amber-400 text-sm">{selectedMessage.convertedCredit.btcSats} Sats</span>
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-[11px] font-mono">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Bank Settlement Ref:</span>
                    <span className="text-slate-200">{selectedMessage.convertedCredit.bankRefNumber}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Blockchain TxHash:</span>
                    <span className="text-amber-400 truncate max-w-xs">{selectedMessage.convertedCredit.blockchainTxHash}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Payout Target:</span>
                    <span className="text-slate-300">{selectedMessage.convertedCredit.payoutDestination}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center border-t border-slate-800 pt-4">
              <button
                onClick={() => {
                  handleDeleteItem(selectedMessage.id);
                  setSelectedMessage(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center space-x-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete This Record</span>
              </button>

              <button
                onClick={() => setSelectedMessage(null)}
                className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clearing All Records */}
      {showDeleteConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-950 border-2 border-rose-500/80 rounded-3xl max-w-md w-full p-6 space-y-5 text-center shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-rose-500 mx-auto animate-bounce" />
            <h3 className="text-lg font-bold text-slate-100">Purge All IMSI Transaction Data?</h3>
            <p className="text-xs text-slate-400">
              Are you sure you want to delete all stored IMSI telecommunications and carrier deduction records? This action cannot be undone.
            </p>
            <div className="flex items-center justify-center space-x-3 pt-2">
              <button
                onClick={() => setShowDeleteConfirmModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center space-x-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Yes, Purge All</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
