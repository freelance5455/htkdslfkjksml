/**
 * GODEX Visual Design Inspector Component
 * Real engineering inspector for selected preview DOM elements.
 * Allows controlled modification of layout, spacing, typography, colors, borders, and flex/grid.
 * Generates proposed source code mutations with unified diff and blast radius.
 */

import React, { useState, useEffect } from 'react';
import { 
  Eye, 
  Layers, 
  Maximize2, 
  Type, 
  Palette, 
  ShieldCheck, 
  Sparkles, 
  Check, 
  X, 
  AlertTriangle, 
  Code2, 
  Sliders, 
  Crosshair, 
  FileCode,
  LayoutGrid
} from 'lucide-react';
import { VisualBridge, VisualMutationProposal } from '../services/visualBridge';
import { VisualElementInspection } from '../intelligence/visualLoopTypes';
import { MutationFirewall } from '../services/mutationFirewall';

interface VisualDesignInspectorProps {
  files: Record<string, string>;
  onApplyMutation?: (targetFile: string, newContent: string) => Promise<boolean>;
  onSelectFile?: (file: string) => void;
}

export const VisualDesignInspector: React.FC<VisualDesignInspectorProps> = ({
  files,
  onApplyMutation,
  onSelectFile
}) => {
  const [selectedElement, setSelectedElement] = useState<VisualElementInspection | null>(() => {
    return VisualBridge.getInstance().getSelectedElement();
  });
  const [isInspectMode, setIsInspectMode] = useState<boolean>(() => {
    return VisualBridge.getInstance().isInspectMode();
  });

  // Local property adjustments
  const [paddingVal, setPaddingVal] = useState<number>(4);
  const [marginVal, setMarginVal] = useState<number>(2);
  const [radiusVal, setRadiusVal] = useState<string>('md');
  const [bgVal, setBgVal] = useState<string>('indigo-600');
  const [textVal, setTextVal] = useState<string>('white');
  const [fontSizeVal, setFontSizeVal] = useState<string>('base');
  const [fontWeightVal, setFontWeightVal] = useState<string>('medium');
  const [gapVal, setGapVal] = useState<number>(2);

  const [activeProposal, setActiveProposal] = useState<VisualMutationProposal | null>(null);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [applyMessage, setApplyMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsub = VisualBridge.getInstance().subscribe((elem, inspectMode) => {
      setSelectedElement(elem);
      setIsInspectMode(inspectMode);
    });
    return () => unsub();
  }, []);

  const handleToggleInspect = () => {
    const next = !isInspectMode;
    VisualBridge.getInstance().setInspectMode(next);
  };

  const handleGenerateProposal = () => {
    if (!selectedElement) return;

    const propertyChanges: Record<string, string | number> = {
      padding: paddingVal,
      margin: marginVal,
      borderRadius: radiusVal,
      backgroundColor: bgVal,
      textColor: textVal,
      fontSize: fontSizeVal,
      fontWeight: fontWeightVal,
      gap: gapVal
    };

    const proposal = VisualBridge.getInstance().generateVisualMutationProposal({
      inspection: selectedElement,
      propertyChanges,
      workspaceFiles: files
    });

    setActiveProposal(proposal);
    setApplyMessage(null);
  };

  const handleApproveMutation = async () => {
    if (!activeProposal || !onApplyMutation) return;

    // Check MutationFirewall
    const firewall = MutationFirewall.getInstance();
    const decision = firewall.evaluateRequest(
      `Visual Design Inspector mutation on ${activeProposal.targetFile}`,
      'MODIFY'
    );
    const permission = firewall.assertPermission('write_file', decision);

    if (!permission.allowed) {
      setApplyMessage(`Mutation blocked by Firewall: ${permission.reason}`);
      return;
    }

    setIsApplying(true);
    try {
      const success = await onApplyMutation(activeProposal.targetFile, activeProposal.patchedContent);
      if (success) {
        setApplyMessage(`Successfully updated ${activeProposal.targetFile}`);
        setActiveProposal(null);
      } else {
        setApplyMessage('Failed to apply mutation to workspace file.');
      }
    } catch (err: any) {
      setApplyMessage(`Error applying mutation: ${err.message}`);
    } finally {
      setIsApplying(false);
    }
  };

  const handleRejectProposal = () => {
    setActiveProposal(null);
    setApplyMessage(null);
  };

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-neutral-200 text-xs overflow-y-auto">
      {/* Header Bar */}
      <div className="flex items-center justify-between p-3 border-b border-neutral-800 bg-neutral-900/80 sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <Crosshair className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-neutral-100 uppercase tracking-wider text-[11px]">Visual-to-AST Inspector</span>
        </div>
        <button
          onClick={handleToggleInspect}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
            isInspectMode 
              ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30' 
              : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>{isInspectMode ? 'Inspection Active' : 'Enable Inspector'}</span>
        </button>
      </div>

      <div className="p-4 space-y-4 flex-1">
        {/* Selected Element Overview Card */}
        {selectedElement ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-mono text-indigo-300 font-semibold text-xs">
                <span>&lt;{selectedElement.tagName}&gt;</span>
                {selectedElement.componentName && (
                  <span className="text-neutral-400 font-sans text-[10px]">({selectedElement.componentName})</span>
                )}
              </div>
              <span className="text-[10px] text-neutral-500 font-mono">
                {selectedElement.computedStyles.width} × {selectedElement.computedStyles.height}px
              </span>
            </div>

            {/* Source Mapping */}
            <div className="flex items-center justify-between bg-neutral-950/80 p-2 rounded border border-neutral-800/80 text-[11px]">
              <div className="flex items-center gap-1.5 text-neutral-300 font-mono truncate">
                <FileCode className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{selectedElement.sourceFile || 'src/App.tsx'}:{selectedElement.sourceLine || 1}</span>
              </div>
              {selectedElement.sourceFile && onSelectFile && (
                <button
                  onClick={() => onSelectFile(selectedElement.sourceFile!)}
                  className="text-[10px] text-indigo-400 hover:text-indigo-300 underline shrink-0 ml-2"
                >
                  View Code
                </button>
              )}
            </div>

            {/* Class Snippet */}
            {selectedElement.className && (
              <div className="bg-neutral-950 p-2 rounded border border-neutral-900 font-mono text-[10px] text-neutral-400 break-all">
                className="{selectedElement.className}"
              </div>
            )}
          </div>
        ) : (
          <div className="bg-neutral-900/40 border border-dashed border-neutral-800 rounded-lg p-6 text-center space-y-2">
            <Crosshair className="w-6 h-6 text-neutral-600 mx-auto" />
            <div className="text-neutral-300 font-medium">No Element Selected</div>
            <div className="text-[11px] text-neutral-500">
              Click <strong className="text-neutral-400">"Enable Inspector"</strong> and click any element in the Live Preview to inspect AST source coordinates & styles.
            </div>
          </div>
        )}

        {/* Visual Styling Controls */}
        {selectedElement && (
          <div className="space-y-3">
            <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>Controlled Style Adjustments</span>
            </div>

            {/* Spacing Controls */}
            <div className="grid grid-cols-2 gap-2 bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-3">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Padding (p-{paddingVal})</label>
                <input 
                  type="range" 
                  min="0" 
                  max="12" 
                  value={paddingVal}
                  onChange={(e) => setPaddingVal(Number(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer h-1.5 bg-neutral-800 rounded"
                />
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Margin (m-{marginVal})</label>
                <input 
                  type="range" 
                  min="0" 
                  max="8" 
                  value={marginVal}
                  onChange={(e) => setMarginVal(Number(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer h-1.5 bg-neutral-800 rounded"
                />
              </div>
            </div>

            {/* Appearance Controls */}
            <div className="grid grid-cols-2 gap-2 bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-3">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Corner Radius</label>
                <select
                  value={radiusVal}
                  onChange={(e) => setRadiusVal(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-200 text-[11px]"
                >
                  <option value="none">none (0px)</option>
                  <option value="sm">sm (2px)</option>
                  <option value="md">md (6px)</option>
                  <option value="lg">lg (8px)</option>
                  <option value="xl">xl (12px)</option>
                  <option value="2xl">2xl (16px - Max anti-slop)</option>
                  <option value="full">full (pill button)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Background Tone</label>
                <select
                  value={bgVal}
                  onChange={(e) => setBgVal(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-200 text-[11px]"
                >
                  <option value="neutral-900">neutral-900 (Dark)</option>
                  <option value="neutral-800">neutral-800 (Elevated)</option>
                  <option value="indigo-600">indigo-600 (Primary)</option>
                  <option value="emerald-600">emerald-600 (Success)</option>
                  <option value="amber-600">amber-600 (Warning)</option>
                  <option value="rose-600">rose-600 (Danger)</option>
                </select>
              </div>
            </div>

            {/* Typography Controls */}
            <div className="grid grid-cols-2 gap-2 bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-3">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Font Size</label>
                <select
                  value={fontSizeVal}
                  onChange={(e) => setFontSizeVal(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-200 text-[11px]"
                >
                  <option value="xs">xs (12px)</option>
                  <option value="sm">sm (14px)</option>
                  <option value="base">base (16px)</option>
                  <option value="lg">lg (18px)</option>
                  <option value="xl">xl (20px)</option>
                  <option value="2xl">2xl (24px)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Font Weight</label>
                <select
                  value={fontWeightVal}
                  onChange={(e) => setFontWeightVal(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-200 text-[11px]"
                >
                  <option value="normal">normal (400)</option>
                  <option value="medium">medium (500)</option>
                  <option value="semibold">semibold (600)</option>
                  <option value="bold">bold (700)</option>
                </select>
              </div>
            </div>

            {/* Action to Propose Safe Mutation */}
            <button
              onClick={handleGenerateProposal}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg shadow transition-colors flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Propose Source Code Mutation</span>
            </button>
          </div>
        )}

        {/* Proposed Mutation Diff Card */}
        {activeProposal && (
          <div className="bg-neutral-900 border border-indigo-500/50 rounded-lg p-3 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="font-semibold text-neutral-100 text-xs flex items-center gap-1.5">
                <Code2 className="w-4 h-4 text-indigo-400" />
                <span>Proposed Unified Diff ({activeProposal.targetFile})</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                Risk Score: {activeProposal.blastRadius.riskScore}/100
              </span>
            </div>

            <div className="bg-neutral-950 p-2 rounded border border-neutral-800 font-mono text-[10px] overflow-x-auto max-h-40 whitespace-pre text-neutral-300">
              {activeProposal.unifiedDiff}
            </div>

            <div className="flex items-center gap-2">
              <button
                disabled={isApplying}
                onClick={handleApproveMutation}
                className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium rounded transition-colors flex items-center justify-center gap-1"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Approve & Apply</span>
              </button>
              <button
                onClick={handleRejectProposal}
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-medium rounded transition-colors flex items-center justify-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reject</span>
              </button>
            </div>
          </div>
        )}

        {applyMessage && (
          <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{applyMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};
