import React, { useState, useEffect } from 'react';
import { ImageOff, Sparkles } from 'lucide-react';

interface SmartImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src?: string;
  alt: string;
  fallbackText?: string;
  containerClassName?: string;
  aspectRatio?: string;
  showFallbackText?: boolean;
}

export const SmartImage: React.FC<SmartImageProps> = ({
  src,
  alt,
  fallbackText,
  className = '',
  containerClassName = '',
  aspectRatio,
  showFallbackText = true,
  loading = 'lazy',
  ...props
}) => {
  const [imgStatus, setImgStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [currentSrc, setCurrentSrc] = useState<string>(src || '');
  const [hasTriedAlternative, setHasTriedAlternative] = useState(false);

  useEffect(() => {
    setCurrentSrc(src || '');
    setImgStatus(src ? 'loading' : 'error');
    setHasTriedAlternative(false);
  }, [src]);

  const handleError = () => {
    // If the image failed and it's an /uploads/ path with a subfolder like /uploads/covers/xyz.webp,
    // attempt to fallback to /uploads/misc/xyz.webp or /uploads/xyz.webp
    if (!hasTriedAlternative && currentSrc.startsWith('/uploads/')) {
      const parts = currentSrc.split('/');
      const filename = parts[parts.length - 1];
      if (parts.length > 3) {
        // Was /uploads/covers/name.webp -> try /uploads/misc/name.webp
        setHasTriedAlternative(true);
        setCurrentSrc(`/uploads/misc/${filename}`);
        return;
      } else if (parts.length === 3 && parts[1] === 'uploads') {
        // Was /uploads/name.webp -> try /uploads/covers/name.webp
        setHasTriedAlternative(true);
        setCurrentSrc(`/uploads/covers/${filename}`);
        return;
      }
    }

    setImgStatus('error');
  };

  const handleLoad = () => {
    setImgStatus('loaded');
  };

  return (
    <div
      className={`relative overflow-hidden bg-[#121829] flex items-center justify-center ${aspectRatio ? aspectRatio : ''} ${containerClassName}`}
    >
      {/* Loading Skeleton */}
      {imgStatus === 'loading' && (
        <div className="absolute inset-0 bg-gradient-to-r from-[#141b2e] via-[#1f2945] to-[#141b2e] animate-pulse flex items-center justify-center z-0">
          <Sparkles className="w-5 h-5 text-purple-500/30 animate-spin" />
        </div>
      )}

      {/* Actual Image */}
      {currentSrc && imgStatus !== 'error' && (
        <img
          {...props}
          src={currentSrc}
          alt={alt}
          loading={loading}
          onLoad={handleLoad}
          onError={handleError}
          className={`${className} transition-opacity duration-300 ${
            imgStatus === 'loaded' ? 'opacity-100' : 'opacity-0'
          }`}
        />
      )}

      {/* Fallback Display if Image Fails Completely */}
      {(!currentSrc || imgStatus === 'error') && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center bg-gradient-to-b from-[#151c30] to-[#0c101c] border border-purple-900/30">
          <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center mb-2 shadow-inner">
            <ImageOff className="w-5 h-5 text-purple-400" />
          </div>
          {showFallbackText && (
            <span className="text-[11px] font-bold text-gray-300 line-clamp-2 px-1 leading-snug">
              {fallbackText || alt || 'مانهوا هارت'}
            </span>
          )}
          <span className="text-[9px] text-purple-400/80 mt-1 font-mono">Manhwa Hart</span>
        </div>
      )}
    </div>
  );
};
