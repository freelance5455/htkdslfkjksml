import React, { useState, useEffect } from "react";
import { createFallbackSvgDataUrl } from "../utils/localImageGenerator";

interface SmartImageProps {
  src: string;
  alt: string;
  prompt?: string;
  className?: string;
  referrerPolicy?: React.HTMLAttributeReferrerPolicy;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export const SmartImage: React.FC<SmartImageProps> = ({
  src,
  alt,
  prompt = "AI Artwork",
  className = "",
  referrerPolicy,
  onClick,
  style,
}) => {
  const [imgSrc, setImgSrc] = useState(src);

  useEffect(() => {
    setImgSrc(src);
  }, [src]);

  const handleError = () => {
    // Replace broken image URL with clean local Base64 SVG
    const fallback = createFallbackSvgDataUrl(prompt);
    setImgSrc(fallback);
  };

  return (
    <img
      src={imgSrc}
      alt={alt}
      onError={handleError}
      className={className}
      referrerPolicy={referrerPolicy}
      onClick={onClick}
      style={style}
    />
  );
};
