import React from 'react';
import { motion } from 'motion/react';
import { BoardTile, Direction, ArrowColor } from '../types';
import { 
  RotateCw, 
  Lock, 
  Snowflake, 
  Bomb, 
  ShieldAlert, 
  Layers 
} from 'lucide-react';

interface ArrowTileProps {
  tile: BoardTile;
  tileSize: number;
  gap: number;
  padding?: number;
  arrowSkin: string;
  isBlockedShaking: boolean;
  onTap: (tile: BoardTile) => void;
}

// Visual color themes for the small square arrow tiles
// ALL arrows in a level ALWAYS use the equipped color from the Shop!
export const TILE_COLOR_CONFIGS: Record<
  ArrowColor | string,
  {
    name: string;
    tileBg: string;           // CSS background
    tileTopHighlight: string; // Inner top bevel
    tileBottomLip: string;    // 3D bottom extrusion color
    tileBorder: string;       // Subtle outline
    arrowFill: string;        // Color of the arrow shape
    arrowStroke: string;      // Outline of the arrow
    arrowShadow: string;      // Drop shadow for arrow
    glowColor: string;
  }
> = {
  // 1. Classic Starter
  black: {
    name: 'Black',
    tileBg: 'linear-gradient(180deg, #27272a 0%, #18181b 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.18)',
    tileBottomLip: '#09090b',
    tileBorder: '#3f3f46',
    arrowFill: '#f4f4f5',
    arrowStroke: 'rgba(0, 0, 0, 0.35)',
    arrowShadow: 'rgba(0, 0, 0, 0.5)',
    glowColor: 'rgba(0, 0, 0, 0.4)',
  },

  // 2. SPECIAL: RAINBOW (Multi-color spectrum blend)
  rainbow: {
    name: 'Rainbow Spectrum',
    tileBg: 'linear-gradient(135deg, #ef4444 0%, #f97316 20%, #eab308 40%, #10b981 60%, #06b6d4 80%, #a855f7 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.55)',
    tileBottomLip: '#6d28d9',
    tileBorder: '#fde047',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(0, 0, 0, 0.4)',
    arrowShadow: 'rgba(0, 0, 0, 0.5)',
    glowColor: 'rgba(244, 63, 94, 0.5)',
  },

  // 3. SPECIAL: DESIGN MATCH (Iridescent morphing preview)
  design_match: {
    name: 'Design Match',
    tileBg: 'linear-gradient(135deg, #0ea5e9 0%, #8b5cf6 50%, #ec4899 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.5)',
    tileBottomLip: '#4338ca',
    tileBorder: '#c4b5fd',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(0, 0, 0, 0.35)',
    arrowShadow: 'rgba(0, 0, 0, 0.45)',
    glowColor: 'rgba(139, 92, 246, 0.5)',
  },

  // Normal Colors & Shades
  red: {
    name: 'Red',
    tileBg: 'linear-gradient(180deg, #ef4444 0%, #b91c1c 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.28)',
    tileBottomLip: '#7f1d1d',
    tileBorder: '#f87171',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(127, 29, 29, 0.4)',
    arrowShadow: 'rgba(69, 10, 10, 0.4)',
    glowColor: 'rgba(239, 68, 68, 0.4)',
  },
  blue: {
    name: 'Blue',
    tileBg: 'linear-gradient(180deg, #3b82f6 0%, #1d4ed8 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.28)',
    tileBottomLip: '#1e3a8a',
    tileBorder: '#60a5fa',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(30, 58, 138, 0.4)',
    arrowShadow: 'rgba(15, 23, 42, 0.4)',
    glowColor: 'rgba(59, 130, 246, 0.4)',
  },
  green: {
    name: 'Green',
    tileBg: 'linear-gradient(180deg, #22c55e 0%, #15803d 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.3)',
    tileBottomLip: '#14532d',
    tileBorder: '#4ade80',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(20, 83, 45, 0.4)',
    arrowShadow: 'rgba(5, 46, 22, 0.4)',
    glowColor: 'rgba(34, 197, 94, 0.4)',
  },
  yellow: {
    name: 'Yellow',
    tileBg: 'linear-gradient(180deg, #facc15 0%, #ca8a04 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.45)',
    tileBottomLip: '#713f12',
    tileBorder: '#fde047',
    arrowFill: '#1c1917',
    arrowStroke: 'rgba(255, 255, 255, 0.4)',
    arrowShadow: 'rgba(113, 63, 18, 0.4)',
    glowColor: 'rgba(234, 179, 8, 0.4)',
  },
  orange: {
    name: 'Orange',
    tileBg: 'linear-gradient(180deg, #f97316 0%, #c2410c 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.3)',
    tileBottomLip: '#7c2d12',
    tileBorder: '#fb923c',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(124, 45, 18, 0.4)',
    arrowShadow: 'rgba(67, 20, 7, 0.4)',
    glowColor: 'rgba(249, 115, 22, 0.4)',
  },
  purple: {
    name: 'Purple',
    tileBg: 'linear-gradient(180deg, #a855f7 0%, #6b21a8 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.3)',
    tileBottomLip: '#3b0764',
    tileBorder: '#c084fc',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(59, 7, 100, 0.4)',
    arrowShadow: 'rgba(38, 6, 64, 0.4)',
    glowColor: 'rgba(168, 85, 247, 0.4)',
  },
  pink: {
    name: 'Pink',
    tileBg: 'linear-gradient(180deg, #ec4899 0%, #be185d 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.32)',
    tileBottomLip: '#700732',
    tileBorder: '#f472b6',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(112, 7, 50, 0.4)',
    arrowShadow: 'rgba(76, 5, 25, 0.4)',
    glowColor: 'rgba(236, 72, 153, 0.4)',
  },
  cyan: {
    name: 'Cyan',
    tileBg: 'linear-gradient(180deg, #06b6d4 0%, #0e7490 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.32)',
    tileBottomLip: '#164e63',
    tileBorder: '#22d3ee',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(22, 78, 99, 0.4)',
    arrowShadow: 'rgba(8, 51, 68, 0.4)',
    glowColor: 'rgba(6, 182, 212, 0.4)',
  },
  magenta: {
    name: 'Magenta',
    tileBg: 'linear-gradient(180deg, #d946ef 0%, #a21caf 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#701a75',
    tileBorder: '#e879f9',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(112, 26, 117, 0.4)',
    arrowShadow: 'rgba(74, 4, 78, 0.4)',
    glowColor: 'rgba(217, 70, 239, 0.4)',
  },
  lime: {
    name: 'Lime',
    tileBg: 'linear-gradient(180deg, #84cc16 0%, #4d7c0f 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#365314',
    tileBorder: '#a3e635',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(54, 83, 20, 0.4)',
    arrowShadow: 'rgba(26, 46, 5, 0.4)',
    glowColor: 'rgba(132, 204, 22, 0.4)',
  },
  teal: {
    name: 'Teal',
    tileBg: 'linear-gradient(180deg, #14b8a6 0%, #0f766e 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.32)',
    tileBottomLip: '#134e4a',
    tileBorder: '#2dd4bf',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(19, 78, 74, 0.4)',
    arrowShadow: 'rgba(4, 47, 46, 0.4)',
    glowColor: 'rgba(20, 184, 166, 0.4)',
  },
  coral: {
    name: 'Coral',
    tileBg: 'linear-gradient(180deg, #fb7185 0%, #e11d48 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.32)',
    tileBottomLip: '#881337',
    tileBorder: '#fda4af',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(136, 19, 55, 0.4)',
    arrowShadow: 'rgba(76, 5, 25, 0.4)',
    glowColor: 'rgba(251, 113, 133, 0.4)',
  },
  turquoise: {
    name: 'Turquoise',
    tileBg: 'linear-gradient(180deg, #2dd4bf 0%, #0d9488 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#115e59',
    tileBorder: '#5eead4',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(17, 94, 89, 0.4)',
    arrowShadow: 'rgba(4, 47, 46, 0.4)',
    glowColor: 'rgba(45, 212, 191, 0.4)',
  },
  mint: {
    name: 'Mint',
    tileBg: 'linear-gradient(180deg, #6ee7b7 0%, #059669 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.4)',
    tileBottomLip: '#064e3b',
    tileBorder: '#a7f3d0',
    arrowFill: '#064e3b',
    arrowStroke: 'rgba(255, 255, 255, 0.4)',
    arrowShadow: 'rgba(6, 78, 59, 0.3)',
    glowColor: 'rgba(110, 231, 183, 0.4)',
  },
  lavender: {
    name: 'Lavender',
    tileBg: 'linear-gradient(180deg, #c084fc 0%, #7e22ce 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#581c87',
    tileBorder: '#e9d5ff',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(88, 28, 135, 0.4)',
    arrowShadow: 'rgba(59, 7, 100, 0.4)',
    glowColor: 'rgba(192, 132, 252, 0.4)',
  },
  violet: {
    name: 'Violet',
    tileBg: 'linear-gradient(180deg, #7c3aed 0%, #5b21b6 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.3)',
    tileBottomLip: '#4c1d95',
    tileBorder: '#a78bfa',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(76, 29, 149, 0.4)',
    arrowShadow: 'rgba(46, 16, 101, 0.4)',
    glowColor: 'rgba(124, 58, 237, 0.4)',
  },
  indigo: {
    name: 'Indigo',
    tileBg: 'linear-gradient(180deg, #4f46e5 0%, #3730a3 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.3)',
    tileBottomLip: '#312e81',
    tileBorder: '#818cf8',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(49, 46, 129, 0.4)',
    arrowShadow: 'rgba(30, 27, 75, 0.4)',
    glowColor: 'rgba(79, 70, 229, 0.4)',
  },
  navy: {
    name: 'Navy',
    tileBg: 'linear-gradient(180deg, #1e3a8a 0%, #172554 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.25)',
    tileBottomLip: '#0f172a',
    tileBorder: '#3b82f6',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(15, 23, 42, 0.4)',
    arrowShadow: 'rgba(2, 6, 23, 0.5)',
    glowColor: 'rgba(30, 58, 138, 0.4)',
  },
  maroon: {
    name: 'Maroon',
    tileBg: 'linear-gradient(180deg, #881337 0%, #4c0519 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.25)',
    tileBottomLip: '#27030d',
    tileBorder: '#be123c',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(39, 3, 13, 0.4)',
    arrowShadow: 'rgba(20, 2, 7, 0.5)',
    glowColor: 'rgba(136, 19, 55, 0.4)',
  },
  gold: {
    name: 'Gold',
    tileBg: 'linear-gradient(180deg, #f59e0b 0%, #b45309 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.45)',
    tileBottomLip: '#451a03',
    tileBorder: '#fbbf24',
    arrowFill: '#fffbeb',
    arrowStroke: 'rgba(69, 26, 3, 0.45)',
    arrowShadow: 'rgba(69, 26, 3, 0.5)',
    glowColor: 'rgba(245, 158, 11, 0.5)',
  },
  silver: {
    name: 'Silver',
    tileBg: 'linear-gradient(180deg, #cbd5e1 0%, #64748b 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.5)',
    tileBottomLip: '#334155',
    tileBorder: '#e2e8f0',
    arrowFill: '#0f172a',
    arrowStroke: 'rgba(255, 255, 255, 0.4)',
    arrowShadow: 'rgba(51, 65, 85, 0.4)',
    glowColor: 'rgba(203, 213, 225, 0.4)',
  },
  brown: {
    name: 'Brown',
    tileBg: 'linear-gradient(180deg, #78350f 0%, #451a03 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.25)',
    tileBottomLip: '#291002',
    tileBorder: '#92400e',
    arrowFill: '#fef3c7',
    arrowStroke: 'rgba(41, 16, 2, 0.4)',
    arrowShadow: 'rgba(20, 8, 1, 0.5)',
    glowColor: 'rgba(120, 53, 15, 0.4)',
  },
  amber: {
    name: 'Amber',
    tileBg: 'linear-gradient(180deg, #d97706 0%, #92400e 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.4)',
    tileBottomLip: '#451a03',
    tileBorder: '#f59e0b',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(69, 26, 3, 0.4)',
    arrowShadow: 'rgba(69, 26, 3, 0.4)',
    glowColor: 'rgba(217, 119, 6, 0.4)',
  },
  emerald: {
    name: 'Emerald',
    tileBg: 'linear-gradient(180deg, #059669 0%, #047857 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#064e3b',
    tileBorder: '#34d399',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(6, 78, 59, 0.4)',
    arrowShadow: 'rgba(4, 47, 36, 0.4)',
    glowColor: 'rgba(5, 150, 105, 0.4)',
  },
  crimson: {
    name: 'Crimson',
    tileBg: 'linear-gradient(180deg, #991b1b 0%, #7f1d1d 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.25)',
    tileBottomLip: '#450a0a',
    tileBorder: '#dc2626',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(69, 10, 10, 0.4)',
    arrowShadow: 'rgba(30, 5, 5, 0.5)',
    glowColor: 'rgba(153, 27, 27, 0.4)',
  },
  sapphire: {
    name: 'Sapphire',
    tileBg: 'linear-gradient(180deg, #2563eb 0%, #1e40af 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#172554',
    tileBorder: '#60a5fa',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(23, 37, 84, 0.4)',
    arrowShadow: 'rgba(15, 23, 42, 0.4)',
    glowColor: 'rgba(37, 99, 235, 0.4)',
  },
  amethyst: {
    name: 'Amethyst',
    tileBg: 'linear-gradient(180deg, #9333ea 0%, #6b21a8 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.35)',
    tileBottomLip: '#3b0764',
    tileBorder: '#c084fc',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(59, 7, 100, 0.4)',
    arrowShadow: 'rgba(38, 6, 64, 0.4)',
    glowColor: 'rgba(147, 51, 234, 0.4)',
  },
  rose_gold: {
    name: 'Rose Gold',
    tileBg: 'linear-gradient(180deg, #f43f5e 0%, #be123c 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.4)',
    tileBottomLip: '#881337',
    tileBorder: '#fda4af',
    arrowFill: '#fff1f2',
    arrowStroke: 'rgba(136, 19, 55, 0.4)',
    arrowShadow: 'rgba(76, 5, 25, 0.4)',
    glowColor: 'rgba(244, 63, 94, 0.4)',
  },
  obsidian: {
    name: 'Obsidian',
    tileBg: 'linear-gradient(180deg, #1e293b 0%, #0f172a 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.2)',
    tileBottomLip: '#020617',
    tileBorder: '#475569',
    arrowFill: '#e2e8f0',
    arrowStroke: 'rgba(2, 6, 23, 0.5)',
    arrowShadow: 'rgba(0, 0, 0, 0.6)',
    glowColor: 'rgba(15, 23, 42, 0.5)',
  },
  diamond: {
    name: 'Diamond',
    tileBg: 'linear-gradient(135deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.65)',
    tileBottomLip: '#0284c7',
    tileBorder: '#ffffff',
    arrowFill: '#0369a1',
    arrowStroke: 'rgba(255, 255, 255, 0.6)',
    arrowShadow: 'rgba(2, 132, 199, 0.35)',
    glowColor: 'rgba(125, 211, 252, 0.6)',
  },

  // Legacy aliases
  neon: {
    name: 'Neon',
    tileBg: 'linear-gradient(180deg, #4c1d95 0%, #831843 100%)',
    tileTopHighlight: 'rgba(0, 240, 255, 0.45)',
    tileBottomLip: '#2e1065',
    tileBorder: '#00f0ff',
    arrowFill: '#00f0ff',
    arrowStroke: 'rgba(0, 0, 0, 0.6)',
    arrowShadow: 'rgba(0, 240, 255, 0.6)',
    glowColor: 'rgba(0, 240, 255, 0.5)',
  },
  crystal: {
    name: 'Crystal',
    tileBg: 'linear-gradient(180deg, #38bdf8 0%, #0284c7 100%)',
    tileTopHighlight: 'rgba(255, 255, 255, 0.5)',
    tileBottomLip: '#0369a1',
    tileBorder: '#bae6fd',
    arrowFill: '#ffffff',
    arrowStroke: 'rgba(3, 105, 161, 0.4)',
    arrowShadow: 'rgba(2, 44, 67, 0.4)',
    glowColor: 'rgba(56, 189, 248, 0.45)',
  },
};

export const ArrowTile: React.FC<ArrowTileProps> = ({
  tile,
  tileSize,
  gap,
  padding = 16,
  arrowSkin,
  isBlockedShaking,
  onTap,
}) => {
  const left = padding + tile.x * (tileSize + gap);
  const top = padding + tile.y * (tileSize + gap);

  // Direction rotation angle in degrees
  const getRotationDeg = (dir?: Direction) => {
    switch (dir) {
      case 'UP':
        return 0;
      case 'RIGHT':
        return 90;
      case 'DOWN':
        return 180;
      case 'LEFT':
        return 270;
      default:
        return 0;
    }
  };

  // Blocked shake animation variants
  const shakeOffset = 4;
  const shakeVariants = {
    idle: { x: 0, y: 0, scale: 1 },
    blocked:
      tile.direction === 'LEFT' || tile.direction === 'RIGHT'
        ? {
            x: tile.direction === 'LEFT' ? [-shakeOffset, shakeOffset, -2, 0] : [shakeOffset, -shakeOffset, 2, 0],
            transition: { duration: 0.2 },
          }
        : {
            y: tile.direction === 'UP' ? [-shakeOffset, shakeOffset, -2, 0] : [shakeOffset, -shakeOffset, 2, 0],
            transition: { duration: 0.2 },
          },
  };

  // Compute escape slide vector (smooth, fast slide off-board)
  const getEscapeMotion = () => {
    const dist = 550;
    switch (tile.direction) {
      case 'UP':
        return { y: -dist, opacity: 0, scale: 0.88 };
      case 'DOWN':
        return { y: dist, opacity: 0, scale: 0.88 };
      case 'LEFT':
        return { x: -dist, opacity: 0, scale: 0.88 };
      case 'RIGHT':
        return { x: dist, opacity: 0, scale: 0.88 };
      default:
        return { scale: 0, opacity: 0 };
    }
  };

  // Render non-arrow obstacle tiles
  if (tile.type === 'OBSTACLE_WALL') {
    return (
      <div
        id={`tile-${tile.id}`}
        className="absolute rounded-[6px] bg-slate-800 border border-slate-700 flex items-center justify-center shadow-sm select-none pointer-events-none"
        style={{
          width: tileSize,
          height: tileSize,
          left,
          top,
        }}
      >
        <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />
      </div>
    );
  }

  if (tile.type === 'OBSTACLE_WOOD') {
    return (
      <div
        id={`tile-${tile.id}`}
        className="absolute rounded-[6px] bg-amber-900 border border-amber-700 flex items-center justify-center shadow-sm select-none pointer-events-none"
        style={{
          width: tileSize,
          height: tileSize,
          left,
          top,
        }}
      >
        <Layers className="w-3.5 h-3.5 text-amber-300" />
      </div>
    );
  }

  // Active equipped skin: ALL tiles in a level MUST have the SAME equipped color!
  const skinKey = arrowSkin && TILE_COLOR_CONFIGS[arrowSkin] ? arrowSkin : 'black';
  const palette = TILE_COLOR_CONFIGS[skinKey] || TILE_COLOR_CONFIGS.black;
  const rotation = getRotationDeg(tile.direction);

  // Short, clear, bold arrow path centered in 100x100 space, pointing UP:
  // Distinct triangular arrowhead + short wide stem
  const shortArrowPath =
    'M 50,15 L 85,50 L 64,50 L 64,81 C 64,84 61,86 58,86 L 42,86 C 39,86 36,84 36,81 L 36,50 L 15,50 Z';

  return (
    <motion.button
      id={`tile-${tile.id}`}
      type="button"
      onClick={() => onTap(tile)}
      variants={shakeVariants}
      animate={
        tile.isEscaping
          ? getEscapeMotion()
          : isBlockedShaking
          ? 'blocked'
          : 'idle'
      }
      transition={
        tile.isEscaping
          ? { duration: 0.32, ease: [0.22, 1, 0.36, 1] }
          : { duration: 0.15 }
      }
      whileTap={{ scale: 0.88 }}
      className={`absolute flex items-center justify-center cursor-pointer select-none p-0 border-none outline-none focus:outline-none touch-manipulation ${
        tile.isHinted ? 'ring-2 ring-yellow-400 ring-offset-1 z-30' : ''
      }`}
      style={{
        width: tileSize,
        height: tileSize,
        left,
        top,
        zIndex: tile.isEscaping ? 50 : 10,
      }}
    >
      {/* 3D Rounded-Square Tile Block */}
      <div
        className="w-full h-full rounded-[6px] relative flex items-center justify-center shadow-sm overflow-hidden transition-all"
        style={{
          background: palette.tileBg,
          borderTop: `1px solid ${palette.tileTopHighlight}`,
          borderLeft: `1px solid ${palette.tileTopHighlight}`,
          borderRight: `1px solid ${palette.tileBottomLip}`,
          borderBottom: `2.5px solid ${palette.tileBottomLip}`,
          boxShadow: `0 1px 3px rgba(0,0,0,0.22), 0 0 0 0.5px ${palette.tileBorder}`,
        }}
      >
        {/* Subtle top gloss reflection */}
        <div
          className="absolute top-0 left-0 right-0 h-1/3 pointer-events-none rounded-t-[5px]"
          style={{
            background: 'linear-gradient(180deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 100%)',
          }}
        />

        {/* Clear Short Arrow Icon */}
        <svg
          viewBox="0 0 100 100"
          className="w-[72%] h-[72%] overflow-visible pointer-events-none"
          style={{
            transform: `rotate(${rotation}deg)`,
            filter: `drop-shadow(0 1px 2px ${palette.arrowShadow})`,
          }}
        >
          {/* Arrow Body */}
          <path
            d={shortArrowPath}
            fill={palette.arrowFill}
            stroke={palette.arrowStroke}
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Forward direction chevron highlight for extra crispness */}
          <path
            d="M 37,46 L 50,33 L 63,46"
            fill="none"
            stroke={palette.arrowStroke}
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={0.35}
          />
        </svg>

        {/* Special mechanic status badges */}
        {tile.isRotator && (
          <div className="absolute top-0.5 right-0.5 w-3 h-3 rounded-full bg-slate-900/80 border border-white/70 flex items-center justify-center shadow">
            <RotateCw className="w-2 h-2 text-cyan-300" />
          </div>
        )}

        {tile.isLocked && (
          <div className="absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-amber-950/80 border border-amber-300/80 flex items-center justify-center shadow">
            <Lock className="w-2 h-2 text-amber-300" />
          </div>
        )}

        {tile.isFrozen && (
          <div className="absolute inset-0 bg-sky-300/30 backdrop-blur-[0.5px] border border-sky-200/60 rounded-[6px] flex items-center justify-center">
            <Snowflake className="w-3.5 h-3.5 text-white animate-spin" style={{ animationDuration: '8s' }} />
          </div>
        )}

        {tile.isBomb && (
          <div className="absolute bottom-0.5 right-0.5 w-3 h-3 rounded-full bg-rose-950/80 border border-rose-400 flex items-center justify-center shadow">
            <Bomb className="w-2 h-2 text-rose-400" />
          </div>
        )}
      </div>
    </motion.button>
  );
};
