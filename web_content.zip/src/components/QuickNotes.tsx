import React, { useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import { TrainingNote, TrainingNoteCategory } from '../types/climbing';
import {
  FileEdit,
  Plus,
  Pin,
  Trash2,
  CheckCircle2,
  Circle,
  X,
  Sparkles,
  Calendar,
  Tag,
  StickyNote
} from 'lucide-react';

interface QuickNotesProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuickNotes: React.FC<QuickNotesProps> = ({ isOpen, onClose }) => {
  const { trainingNotes, addTrainingNote, deleteTrainingNote, toggleTrainingNote } = useClimbing();

  const [isCreating, setIsCreating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<TrainingNoteCategory>('Technique');
  const [isPinned, setIsPinned] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addTrainingNote({
      title: title.trim(),
      content: content.trim(),
      date: new Date().toISOString().split('T')[0],
      category,
      isPinned,
      isCompleted: false
    });

    setTitle('');
    setContent('');
    setIsCreating(false);
  };

  const filteredNotes = trainingNotes
    .filter(note => (selectedCategory === 'All' ? true : note.category === selectedCategory))
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.createdAt - a.createdAt;
    });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 w-full sm:max-w-md h-full flex flex-col shadow-2xl border-l border-slate-200 dark:border-slate-800 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/80 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold">
              <StickyNote className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold">Quick Training Notes</h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Urgent tips, warm-up drills & assessment reminders
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories Bar */}
        <div className="px-5 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-white dark:bg-slate-900">
          {['All', 'Technique', 'Safety', 'Conditioning', 'Assessment', 'General'].map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {isCreating ? (
            <form onSubmit={handleSubmit} className="p-4 rounded-xl border border-orange-200 dark:border-orange-900/60 bg-orange-50/50 dark:bg-orange-950/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-orange-800 dark:text-orange-400 uppercase tracking-wider">
                  New Training Note
                </span>
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  Cancel
                </button>
              </div>

              <div>
                <input
                  type="text"
                  required
                  placeholder="Note title (e.g., Focus on silent feet)..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-semibold"
                />
              </div>

              <div>
                <textarea
                  rows={3}
                  placeholder="Details, beta tips, reminder for next climbing session..."
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-between gap-2 pt-1">
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as TrainingNoteCategory)}
                  className="px-2.5 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-200"
                >
                  <option value="Technique">Technique</option>
                  <option value="Safety">Safety</option>
                  <option value="Conditioning">Conditioning</option>
                  <option value="Assessment">Assessment</option>
                  <option value="General">General</option>
                </select>

                <label className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPinned}
                    onChange={e => setIsPinned(e.target.checked)}
                    className="rounded text-orange-600 focus:ring-orange-500 w-3.5 h-3.5"
                  />
                  <span>Pin to top</span>
                </label>

                <button
                  type="submit"
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs"
                >
                  Save Note
                </button>
              </div>
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setIsCreating(true)}
              className="w-full py-2.5 px-3 rounded-xl border border-dashed border-orange-300 dark:border-orange-800/80 bg-orange-50/40 dark:bg-orange-950/20 text-orange-700 dark:text-orange-400 hover:bg-orange-100/50 flex items-center justify-center gap-1.5 text-xs font-semibold transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Jot Down Quick Note / Training Tip</span>
            </button>
          )}

          {/* Notes List */}
          {filteredNotes.length === 0 ? (
            <div className="py-12 text-center text-slate-400 dark:text-slate-500 space-y-1">
              <StickyNote className="w-8 h-8 mx-auto stroke-1" />
              <p className="text-xs">No notes in this category.</p>
            </div>
          ) : (
            filteredNotes.map(note => (
              <div
                key={note.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  note.isCompleted
                    ? 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 opacity-70'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <button
                      type="button"
                      onClick={() => toggleTrainingNote(note.id)}
                      className="mt-0.5 text-slate-400 hover:text-orange-600 transition-colors shrink-0"
                    >
                      {note.isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Circle className="w-4 h-4" />
                      )}
                    </button>
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {note.isPinned && (
                          <Pin className="w-3 h-3 text-orange-600 shrink-0 fill-orange-600" />
                        )}
                        <h4 className={`text-xs font-bold truncate ${note.isCompleted ? 'line-through text-slate-500' : 'text-slate-900 dark:text-white'}`}>
                          {note.title}
                        </h4>
                      </div>
                      {note.content && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed break-words whitespace-pre-wrap">
                          {note.content}
                        </p>
                      )}
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-500 pt-1 font-mono">
                        <span className="bg-slate-100 dark:bg-slate-700/60 px-1.5 py-0.5 rounded text-slate-600 dark:text-slate-300 font-sans">
                          {note.category}
                        </span>
                        <span>{note.date}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => deleteTrainingNote(note.id)}
                    className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
          <span>Notes persist in browser local storage.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
