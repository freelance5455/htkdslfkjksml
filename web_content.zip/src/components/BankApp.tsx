import React from 'react';
import { ArrowDownLeft, ArrowUpRight, Landmark, ShieldCheck, Wallet } from 'lucide-react';
import { SaveData } from '../types/game';

interface BankAppProps {
  save: SaveData;
  onDeposit: (amount: number) => void;
  onWithdraw: (amount: number) => void;
  onTakeLoan: (amount: number) => void;
  onRepayLoan: () => void;
}

export const BankApp: React.FC<BankAppProps> = ({
  save,
  onDeposit,
  onWithdraw,
  onTakeLoan,
  onRepayLoan,
}) => {
  const canBorrowMore = save.bankLoan < 200000;

  return (
    <div className="space-y-3">
      {/* Bank Account Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/40 space-y-2 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-black uppercase tracking-wider">
            <Landmark className="w-4 h-4" /> K-Bank Digital Account
          </div>
          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-black">
            +2% Profit
          </span>
        </div>

        <div className="text-[11px] font-mono text-slate-400">
          AC: {save.bankAccountNo}
        </div>

        <div className="pt-1">
          <div className="text-[10px] font-bold uppercase text-slate-400">Protected Bank Balance</div>
          <div className="text-2xl font-black text-white tabular-nums">
            Rs. {save.bankBalance.toLocaleString()}
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 border-t border-white/10 text-xs">
          <span className="text-slate-300 flex items-center gap-1">
            <Wallet className="w-3.5 h-3.5 text-amber-400" /> Pocket Cash:
            <strong className="text-amber-300 tabular-nums">Rs. {save.cash.toLocaleString()}</strong>
          </span>
          <span className="text-emerald-300 text-[10px] font-bold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Safe
          </span>
        </div>
      </div>

      {/* Deposit Section */}
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
        <div className="flex items-center gap-1.5 text-xs font-black text-emerald-400 uppercase tracking-wider">
          <ArrowDownLeft className="w-4 h-4" /> Deposit Cash to Bank
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: '+Rs. 5K', amount: 5000 },
            { label: '+Rs. 25K', amount: 25000 },
            { label: 'All Cash', amount: save.cash },
          ].map((btn) => (
            <button
              key={btn.label}
              type="button"
              disabled={save.cash <= 0 || btn.amount <= 0}
              onClick={() => onDeposit(Math.min(save.cash, btn.amount))}
              className="py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-black text-xs cursor-pointer"
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* Withdraw Section */}
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
        <div className="flex items-center gap-1.5 text-xs font-black text-sky-400 uppercase tracking-wider">
          <ArrowUpRight className="w-4 h-4" /> Withdraw Cash to Pocket
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: '-Rs. 5K', amount: 5000 },
            { label: '-Rs. 25K', amount: 25000 },
            { label: 'All Bank', amount: save.bankBalance },
          ].map((btn) => (
            <button
              key={btn.label}
              type="button"
              disabled={save.bankBalance <= 0 || btn.amount <= 0}
              onClick={() => onWithdraw(Math.min(save.bankBalance, btn.amount))}
              className="py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-black text-xs cursor-pointer"
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* Instant Loan & Repay */}
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
            Instant K-Bank Loan
          </span>
          <span className="text-[11px] font-bold text-slate-300 tabular-nums">
            Loan Due: <strong className={save.bankLoan > 0 ? 'text-rose-400' : 'text-emerald-400'}>
              Rs. {save.bankLoan.toLocaleString()}
            </strong>
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            disabled={!canBorrowMore}
            onClick={() => onTakeLoan(50000)}
            className="py-2 rounded-lg bg-amber-400 hover:bg-amber-300 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-black text-xs cursor-pointer"
          >
            Borrow Rs. 50K
          </button>
          <button
            type="button"
            disabled={save.bankLoan <= 0 || save.cash + save.bankBalance <= 0}
            onClick={onRepayLoan}
            className="py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 border border-slate-600 text-white font-black text-xs cursor-pointer"
          >
            Repay Loan
          </button>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
        <div className="text-[11px] font-black uppercase tracking-wider text-slate-400">
          Recent Transactions
        </div>
        {save.bankTransactions.length === 0 ? (
          <div className="text-xs text-slate-500 py-1">No transactions yet.</div>
        ) : (
          save.bankTransactions.slice(0, 6).map((tx) => {
            const isCredit = tx.type === 'deposit' || tx.type === 'interest' || tx.type === 'loan';
            return (
              <div
                key={tx.id}
                className="flex items-center justify-between text-xs py-1 border-b border-slate-800/70 last:border-b-0"
              >
                <div>
                  <div className="font-bold text-slate-200">{tx.label}</div>
                  <div className="text-[10px] text-slate-500">{tx.time}</div>
                </div>
                <span
                  className={`font-black tabular-nums ${
                    isCredit ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isCredit ? '+' : '-'}Rs. {tx.amount.toLocaleString()}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
