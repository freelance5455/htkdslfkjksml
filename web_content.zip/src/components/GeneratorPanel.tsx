"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import ResultView from "./results";
import { Pill, Spinner, useToast } from "./ui";
import { ApiError, apiPost } from "@/lib/client/api";
import { PLAN_RANK, type Field, type PlanTier, type ToolDef, type ToolId } from "@/lib/ai/tools";
import type { ToolOutput } from "@/lib/ai/types";

type UsageState = { remaining: number; limit: number; used: number; planName: string };

const FALLBACKS: Record<string, string> = {
  topic: "",
  description: "",
  content: "",
};

export default function GeneratorPanel({
  tool,
  toolDef,
  defaults,
  planKey,
  usage,
}: {
  tool: ToolId;
  toolDef: ToolDef;
  defaults: { platform: string; niche: string; tone: string };
  planKey: string;
  usage: UsageState;
}) {
  const initial = useRef<Record<string, string> | null>(null);
  if (!initial.current) {
    const seeded: Record<string, string> = {};
    for (const field of toolDef.fields) {
      const fb = FALLBACKS[field.name] ?? "";
      seeded[field.name] =
        fb ||
        (field.name === "platform" ? defaults.platform : field.name === "niche" ? defaults.niche : field.name === "tone" ? defaults.tone : "");
      if (field.type === "select" && !seeded[field.name] && field.options?.length) {
        seeded[field.name] = String(field.options[0].value);
      }
    }
    initial.current = seeded;
  }

  const [values, setValues] = useState<Record<string, string>>(initial.current);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{ message: string; code?: string; requiredPlan?: PlanTier } | null>(null);
  const [result, setResult] = useState<{ id: number | null; output: ToolOutput; engine: string } | null>(null);
  const [usageState, setUsageState] = useState(usage);
  const { show, node } = useToast();
  const resultsRef = useRef<HTMLDivElement | null>(null);

  const userTier = (planKey === "pro" ? "pro" : planKey === "creator" ? "creator" : "free") as PlanTier;
  const locked = PLAN_RANK[userTier] < PLAN_RANK[toolDef.minPlan];

  const setValue = (name: string, value: string) => setValues((v) => ({ ...v, [name]: value }));

  const lengthRequirement = (name: string): PlanTier | null => {
    if (tool !== "scripts") return null;
    const value = values.length;
    if (value === "longform") return "pro";
    if (value === "60s") return "creator";
    if (name === "length") return "free";
    return null;
  };

  const submit = async (event?: React.FormEvent) => {
    event?.preventDefault();
    if (loading) return; // duplicate-request guard
    setError(null);
    setLoading(true);
    try {
      const res = await apiPost<{
        id: number | null;
        output: ToolOutput;
        engine: string;
        usage: { used: number; limit: number; remaining: number };
      }>("/api/generate", { tool, ...values });
      setResult({ id: res.id, output: res.output, engine: res.engine });
      setUsageState((u) => ({
        ...u,
        remaining: res.usage.remaining,
        limit: res.usage.limit,
        used: res.usage.used,
      }));
      show("Generated — review before you post.");
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
    } catch (err) {
      if (err instanceof ApiError) {
        setError({ message: err.message, code: err.code, requiredPlan: undefined });
        if (err.code === "LIMIT_REACHED") setUsageState((u) => ({ ...u, remaining: 0 }));
      } else {
        setError({ message: "Generation failed. Please try again." });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {node}

      <div className="card p-4">
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/40 to-cyan-400/30 text-xl">
              {toolDef.emoji}
            </span>
            <div>
              <h1 className="text-lg font-bold leading-tight">{toolDef.name}</h1>
              <p className="text-sm text-[color:var(--muted)]">{toolDef.blurb}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Pill tone="brand">
              {usageState.remaining}/{usageState.limit} generations left
            </Pill>
            <Pill>{toolDef.credits} credit{toolDef.credits > 1 ? "s" : ""} per run</Pill>
          </div>
        </div>

        {locked ? (
          <div className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-4">
            <p className="text-sm font-semibold text-amber-100">
              {toolDef.name} is on the {toolDef.minPlan === "pro" ? "Pro" : "Creator"} plan
            </p>
            <p className="mt-1 text-sm text-amber-100/80">
              Upgrade to unlock this tool plus higher monthly limits. You keep everything you already saved.
            </p>
            <Link href="/pricing" className="btn btn-primary btn-sm mt-3">
              See plans
            </Link>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3" noValidate>
            <div className="grid gap-3 sm:grid-cols-2">
              {toolDef.fields.map((field) => (
                <FieldControl
                  key={field.name}
                  field={field}
                  value={values[field.name] ?? ""}
                  onChange={(v) => setValue(field.name, v)}
                  wide={field.type === "textarea"}
                  lockTier={lengthRequirement(field.name)}
                  planKey={planKey}
                />
              ))}
            </div>

            {error ? (
              <div className="rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-sm text-rose-100">
                <p>{error.message}</p>
                {error.code === "UPGRADE_REQUIRED" || error.code === "LIMIT_REACHED" ? (
                  <Link href="/pricing" className="btn btn-primary btn-sm mt-2">
                    Upgrade plan
                  </Link>
                ) : null}
              </div>
            ) : null}

            <div className="flex flex-wrap items-center gap-3">
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? (
                  <>
                    <Spinner /> Generating…
                  </>
                ) : (
                  <>{toolDef.cta}</>
                )}
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  setValues(initial.current ?? {});
                  setResult(null);
                  setError(null);
                }}
                disabled={loading}
              >
                Reset
              </button>
              <p className="text-xs text-[color:var(--muted)]">
                Results are suggestions — nothing is guaranteed to go viral.
              </p>
            </div>
          </form>
        )}
      </div>

      <div ref={resultsRef}>
        {loading ? <LoadingSkeleton /> : null}
        {!loading && result ? (
          <div className="space-y-2">
            <p className="px-1 text-xs text-[color:var(--muted)]">Engine: {result.engine}</p>
            <ResultView tool={tool} output={result.output} generationId={result.id} />
          </div>
        ) : null}
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-2" aria-live="polite">
      <p className="px-1 text-xs text-[color:var(--muted)]">Working on it…</p>
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="skeleton h-16 w-full opacity-70" />
      ))}
    </div>
  );
}

function FieldControl({
  field,
  value,
  onChange,
  wide,
  lockTier,
  planKey,
}: {
  field: Field;
  value: string;
  onChange: (value: string) => void;
  wide?: boolean;
  lockTier: PlanTier | null;
  planKey: string;
}) {
  const tier = lockTier ?? "free";
  const lockedByPlan = lockTier ? PLAN_RANK[planKey as PlanTier] < PLAN_RANK[tier] : false;
  return (
    <div className={wide ? "sm:col-span-2" : ""}>
      <label className="label" htmlFor={`${field.name}-${field.label}`}>
        {field.label}
        {field.required ? <span className="ml-1 text-violet-300">*</span> : null}
      </label>
      {field.type === "select" ? (
        <select
          id={`${field.name}-${field.label}`}
          className="select"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          {field.options?.map((opt) => (
            <option key={String(opt.value)} value={String(opt.value)}>
              {opt.label}
              {lockedByPlan && lockTier ? " 🔒" : ""}
            </option>
          ))}
        </select>
      ) : field.type === "textarea" ? (
        <textarea
          id={`${field.name}-${field.label}`}
          className="textarea"
          value={value}
          maxLength={field.maxLength}
          placeholder={field.placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <input
          id={`${field.name}-${field.label}`}
          className="input"
          value={value}
          maxLength={field.maxLength}
          placeholder={field.placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {field.help ? <p className="mt-1 text-[0.7rem] text-[color:var(--muted)]">{field.help}</p> : null}
    </div>
  );
}
