import React, { useState } from 'react';
import {
  X,
  Phone,
  MapPin,
  Calendar,
  CreditCard,
  ShoppingCart,
  Undo2,
  Navigation,
  CheckCircle2,
  XCircle,
  Clock,
  Edit,
  Crosshair,
} from 'lucide-react';
import { Customer, Visit } from '../db/indexedDB';
import { formatMoney } from '../utils/calc';
import { sound } from '../utils/sound';

interface CustomerCardModalProps {
  customer: Customer | null;
  visits: Visit[];
  isOpen: boolean;
  onClose: () => void;
  onQuickInvoice: (customer: Customer) => void;
  onPayment: (customer: Customer) => void;
  onReturn: (customer: Customer) => void;
  onEdit: (customer: Customer) => void;
  onSaveGPS: (customer: Customer) => void;
  onNavigateGPS: (customer: Customer) => void;
  onLogVisit: (customer: Customer, status: string, notes?: string) => void;
}

export const CustomerCardModal: React.FC<CustomerCardModalProps> = ({
  customer,
  visits,
  isOpen,
  onClose,
  onQuickInvoice,
  onPayment,
  onReturn,
  onEdit,
  onSaveGPS,
  onNavigateGPS,
  onLogVisit,
}) => {
  const [visitNote, setVisitNote] = useState('');

  if (!isOpen || !customer) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-right">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-xs font-mono font-bold bg-amber-500/20 text-amber-400 px-2.5 py-1 rounded-lg border border-amber-500/30">
              {customer.id}
            </span>
            <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded-md">
              خط سير: {customer.dayOfWeek}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* Main Info Card */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-850 p-4 rounded-2xl border border-slate-700/60 shadow-lg space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">{customer.name}</h3>
                <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{customer.address || 'لا يوجد عنوان مسجل'}</span>
                </div>
                {customer.phone && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-1">
                    <Phone className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <a href={`tel:${customer.phone}`} className="hover:underline font-mono">
                      {customer.phone}
                    </a>
                  </div>
                )}
              </div>

              {/* Debt indicator */}
              <div className="text-left bg-slate-900/80 p-2.5 rounded-xl border border-slate-700/50">
                <span className="text-[10px] text-slate-400 block">إجمالي المديونية</span>
                <span
                  className={`text-base font-black font-mono block ${
                    customer.balance > 0 ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {formatMoney(customer.balance)} ج.م
                </span>
              </div>
            </div>

            {/* GPS indicator status */}
            <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-700/40 text-slate-400">
              <div className="flex items-center gap-1">
                <Crosshair className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {customer.lat && customer.lng
                    ? `موقع محفوظ (${customer.lat.toFixed(4)}, ${customer.lng.toFixed(4)})`
                    : 'لم يُحفظ الموقع بعد'}
                </span>
              </div>
              {customer.lastVisit && (
                <div className="flex items-center gap-1 text-[11px] text-slate-400">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>آخر زيارة: {customer.lastVisit}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Transaction Actions */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => {
                onQuickInvoice(customer);
                onClose();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-900/30 active:scale-95 transition"
            >
              <ShoppingCart className="w-5 h-5 mb-1" />
              <span>فاتورة بيع</span>
            </button>

            <button
              onClick={() => onPayment(customer)}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-900/30 active:scale-95 transition"
            >
              <CreditCard className="w-5 h-5 mb-1" />
              <span>تحصيل كاش</span>
            </button>

            <button
              onClick={() => onReturn(customer)}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-900/30 active:scale-95 transition"
            >
              <Undo2 className="w-5 h-5 mb-1" />
              <span>تسجيل مرتجع</span>
            </button>
          </div>

          {/* Location & Navigation Actions */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => onSaveGPS(customer)}
              className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-amber-400 text-xs font-bold active:scale-95 transition"
            >
              <Crosshair className="w-4 h-4" />
              <span>حفظ موقعي</span>
            </button>

            <button
              onClick={() => onNavigateGPS(customer)}
              className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-sky-400 text-xs font-bold active:scale-95 transition"
            >
              <Navigation className="w-4 h-4" />
              <span>توجيه بالخرائط</span>
            </button>

            <button
              onClick={() => onEdit(customer)}
              className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-xs font-bold active:scale-95 transition"
            >
              <Edit className="w-4 h-4" />
              <span>تعديل البيانات</span>
            </button>
          </div>

          {/* Log Visit Form */}
          <div className="bg-slate-850 p-3.5 rounded-2xl border border-slate-750 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">تسجيل حالة الزيارة</span>
              <span className="text-[10px] text-slate-400">تحديث خط السير</span>
            </div>

            <input
              type="text"
              value={visitNote}
              onChange={(e) => setVisitNote(e.target.value)}
              placeholder="ملاحظات الزيارة (اختياري)..."
              className="w-full text-xs bg-slate-900 border border-slate-750 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  sound.playSuccess();
                  onLogVisit(customer, 'تمت الزيارة', visitNote);
                  setVisitNote('');
                }}
                className="flex items-center justify-center gap-1 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold active:scale-95 transition"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تمت الزيارة</span>
              </button>

              <button
                onClick={() => {
                  onLogVisit(customer, 'لم تتم - المحل مغلق', visitNote);
                  setVisitNote('');
                }}
                className="flex items-center justify-center gap-1 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-bold active:scale-95 transition"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>المحل مغلق</span>
              </button>

              <button
                onClick={() => {
                  onLogVisit(customer, 'مؤجلة', visitNote);
                  setVisitNote('');
                }}
                className="flex items-center justify-center gap-1 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-bold active:scale-95 transition"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>زيارة مؤجلة</span>
              </button>
            </div>
          </div>

          {/* Recent Visits History */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300">سجل الزيارات السابقة</span>
            {visits.length > 0 ? (
              <div className="space-y-1.5">
                {visits.slice(0, 4).map((v) => (
                  <div
                    key={v.id}
                    className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-750 text-xs flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-white block">{v.status}</span>
                      {v.notes && <span className="text-[11px] text-slate-400 block">{v.notes}</span>}
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">{v.date}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3 text-center text-xs text-slate-500 bg-slate-800/40 rounded-xl">
                لا توجد زيارات سابقة مسجلة لهذا العميل
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
