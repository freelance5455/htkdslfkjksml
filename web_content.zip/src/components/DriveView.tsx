import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Volume2, VolumeX } from "lucide-react";
import { inputBus, mountGame, type GameApi } from "@/game/game";

const GEARS = [
  [1, 3, 5],
  [2, 4, 6],
] as const;

export function DriveView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const speedRef = useRef<HTMLSpanElement>(null);
  const gearRef = useRef<HTMLSpanElement>(null);
  const rpmRef = useRef<HTMLSpanElement>(null);
  const lampRef = useRef<HTMLSpanElement>(null);
  const bestRef = useRef<HTMLSpanElement>(null);
  const api = useRef<GameApi | null>(null);
  const drag = useRef<{ id: number; x: number } | null>(null);

  const [started, setStarted] = useState(false);
  const [muted, setMuted] = useState(false);
  const [sens, setSens] = useState(1);
  const [tiltOn, setTiltOn] = useState(false);
  const [invert, setInvert] = useState(false);
  const [gear, setGear] = useState(1);

  useEffect(() => {
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    setTiltOn(coarse);
    inputBus.tiltOn = coarse;
  }, []);

  useEffect(() => {
    inputBus.sensitivity = sens;
  }, [sens]);

  useEffect(() => {
    inputBus.tiltOn = tiltOn;
  }, [tiltOn]);

  useEffect(() => {
    inputBus.invertTilt = invert;
  }, [invert]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = mountGame(canvas, {
      speed: speedRef.current,
      gear: gearRef.current,
      rpm: rpmRef.current,
      lamp: lampRef.current,
      best: bestRef.current,
    });
    api.current = game;
    const id = window.setInterval(() => {
      const text = gearRef.current?.textContent ?? "1";
      const next = text === "N" ? 0 : Number(text) || 0;
      setGear((g) => (g === next ? g : next));
    }, 150);
    return () => {
      window.clearInterval(id);
      game.dispose();
      api.current = null;
    };
  }, []);

  function start() {
    api.current?.start();
    setStarted(true);
  }

  function onPadDown(e: React.PointerEvent) {
    if ((e.target as HTMLElement).closest("[data-control]")) return;
    drag.current = { id: e.pointerId, x: e.clientX };
    inputBus.touchActive = true;
    inputBus.steerTouch = 0;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }

  function onPadMove(e: React.PointerEvent) {
    const d = drag.current;
    if (!d || d.id !== e.pointerId) return;
    const width = window.innerWidth || 1;
    inputBus.steerTouch = Math.max(-1, Math.min(1, (d.x - e.clientX) / (width * 0.28)));
  }

  function onPadUp(e: React.PointerEvent) {
    if (drag.current?.id !== e.pointerId) return;
    drag.current = null;
    inputBus.touchActive = false;
    inputBus.steerTouch = 0;
  }

  return (
    <main
      className="relative h-dvh w-full overflow-hidden bg-bg text-fg touch-none select-none"
      onPointerDown={onPadDown}
      onPointerMove={onPadMove}
      onPointerUp={onPadUp}
      onPointerCancel={onPadUp}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      <header className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-4">
        <div>
          <p className="font-display text-5xl leading-none tracking-wide text-fg">
            <span ref={gearRef}>1</span>
          </p>
          <div className="mt-2 grid grid-cols-3 gap-1">
            {GEARS.flat().map((g) => (
              <span
                key={g}
                className={
                  "flex h-5 w-5 items-center justify-center font-display text-xs " +
                  (gear === g ? "bg-accent text-bg" : "text-muted")
                }
              >
                {g}
              </span>
            ))}
          </div>
        </div>
        <div className="text-right">
          <p className="font-display text-5xl leading-none tracking-wide">
            <span ref={speedRef}>0</span>
          </p>
          <p className="text-xs tracking-[0.18em] text-muted">KM/H</p>
          <p className="mt-1 text-xs text-muted">
            BEST <span ref={bestRef}>—</span>
          </p>
        </div>
      </header>

      <div className="pointer-events-none absolute inset-x-0 top-28 flex flex-col items-center gap-2 px-8">
        <span
          ref={lampRef}
          className="font-display text-sm tracking-[0.28em] text-brake opacity-0"
        >
          SHIFT
        </span>
        <div className="h-1.5 w-full max-w-md overflow-hidden bg-line">
          <span ref={rpmRef} className="rpm-fill block h-full w-full bg-accent" style={{ transform: "scaleX(0.12)" }} />
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-3 safe-b">
        <button
          type="button"
          data-control
          className="flex h-16 min-w-24 items-center justify-center bg-brake px-4 font-display text-lg tracking-wider text-bg"
          onPointerDown={(e) => {
            e.stopPropagation();
            inputBus.brake = true;
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerUp={() => {
            inputBus.brake = false;
          }}
          onPointerCancel={() => {
            inputBus.brake = false;
          }}
        >
          BRAKE
        </button>

        <div className="flex items-center gap-2" data-control>
          <HoldSteer side={1} />
          <div className="flex flex-col gap-2">
            <button
              type="button"
              data-control
              aria-label="Shift up"
              className="flex h-11 w-14 items-center justify-center bg-surface text-fg"
              onPointerDown={(e) => {
                e.stopPropagation();
                inputBus.shiftUp += 1;
              }}
            >
              <ChevronUp className="size-6" />
            </button>
            <button
              type="button"
              data-control
              aria-label="Shift down"
              className="flex h-11 w-14 items-center justify-center bg-surface text-fg"
              onPointerDown={(e) => {
                e.stopPropagation();
                inputBus.shiftDown += 1;
              }}
            >
              <ChevronDown className="size-6" />
            </button>
          </div>
          <HoldSteer side={-1} />
        </div>

        <button
          type="button"
          data-control
          className="flex h-16 min-w-24 items-center justify-center bg-accent px-4 font-display text-lg tracking-wider text-bg"
          onPointerDown={(e) => {
            e.stopPropagation();
            inputBus.gas = true;
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerUp={() => {
            inputBus.gas = false;
          }}
          onPointerCancel={() => {
            inputBus.gas = false;
          }}
        >
          GAS
        </button>
      </div>

      <div className="absolute right-3 top-3 flex gap-2" data-control>
        <button
          type="button"
          data-control
          aria-label={muted ? "Unmute" : "Mute"}
          className="flex size-11 items-center justify-center bg-surface text-fg"
          onClick={(e) => {
            e.stopPropagation();
            const next = !muted;
            setMuted(next);
            api.current?.setMuted(next);
          }}
        >
          {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
        </button>
      </div>

      {!started && (
        <div className="absolute inset-0 flex items-end justify-center bg-bg/55 p-4 safe-b sm:items-center">
          <section className="w-full max-w-md bg-surface p-5 text-fg shadow-none">
            <p className="font-display text-xs tracking-[0.28em] text-accent">FIRST PERSON</p>
            <h1 className="mt-1 font-display text-5xl leading-none tracking-wide">OVERRUN</h1>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              One seat, a short dusk loop. Your hands stay on the wheel until you pull the lever.
              Right foot is gas. Left foot moves to the brake. Lift off high and it crackles.
            </p>
            <ul className="mt-4 space-y-1 text-sm text-fg">
              <li>Drag the glass, or the arrows, to steer. A and D on a keyboard.</li>
              <li>W gas, S brake. E shifts up, Q shifts down.</li>
              <li>Tilt the phone if you want the wheel to follow the device.</li>
            </ul>

            <label className="mt-4 block text-xs tracking-wider text-muted">
              STEERING SENSITIVITY {sens.toFixed(2)}
              <input
                data-control
                type="range"
                min={0.55}
                max={1.6}
                step={0.05}
                value={sens}
                onChange={(e) => setSens(Number(e.target.value))}
                className="mt-2 w-full accent-accent"
              />
            </label>

            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                data-control
                className={
                  "h-11 px-3 text-sm " + (tiltOn ? "bg-accent text-bg" : "bg-bg text-fg")
                }
                onClick={() => setTiltOn((v) => !v)}
              >
                Tilt steer {tiltOn ? "on" : "off"}
              </button>
              <button
                type="button"
                data-control
                className="h-11 bg-bg px-3 text-sm text-fg"
                onClick={() => setInvert((v) => !v)}
              >
                Invert tilt {invert ? "on" : "off"}
              </button>
              <button
                type="button"
                data-control
                className="h-11 bg-bg px-3 text-sm text-fg"
                onClick={() => api.current?.recenterTilt()}
              >
                Center tilt
              </button>
            </div>

            <button
              type="button"
              data-control
              className="mt-5 h-12 w-full bg-accent font-display text-xl tracking-[0.18em] text-bg"
              onClick={start}
            >
              Start driving
            </button>
          </section>
        </div>
      )}
    </main>
  );
}

function HoldSteer({ side }: { side: 1 | -1 }) {
  const label = side > 0 ? "Steer left" : "Steer right";
  return (
    <button
      type="button"
      data-control
      aria-label={label}
      className="flex size-14 items-center justify-center bg-surface/90 text-fg"
      onPointerDown={(e) => {
        e.stopPropagation();
        inputBus.padSteer = side;
        e.currentTarget.setPointerCapture(e.pointerId);
      }}
      onPointerUp={() => {
        inputBus.padSteer = 0;
      }}
      onPointerCancel={() => {
        inputBus.padSteer = 0;
      }}
    >
      {side > 0 ? <ChevronLeft className="size-7" /> : <ChevronRight className="size-7" />}
    </button>
  );
}
