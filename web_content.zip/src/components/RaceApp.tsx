import { useEffect, useRef, useState, type PointerEvent } from "react";
import { formatTime } from "@/game/format";
import { DEFAULT_SAVE, readSave } from "@/game/save";
import { SKINS, skinById } from "@/game/skins";
import type { GameHandle, Phase, RacerResult, SaveData } from "@/game/types";

const PLACES = ["", "الأول", "الثاني", "الثالث", "الرابع"];

export function RaceApp() {
  const viewRef = useRef<HTMLCanvasElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const hudRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<GameHandle | null>(null);
  const queued = useRef(false);
  const [phase, setPhase] = useState<Phase>("garage");
  const [save, setSave] = useState<SaveData>(DEFAULT_SAVE);
  const [results, setResults] = useState<RacerResult[]>([]);
  const [error, setError] = useState("");
  const [thumb, setThumb] = useState(50);

  useEffect(() => {
    const view = viewRef.current;
    const map = mapRef.current;
    const hud = hudRef.current;
    if (!view || !map || !hud) return;
    const loaded = readSave();
    setSave(loaded);
    let dead = false;
    let handle: GameHandle | null = null;
    void import("@/game/Game")
      .then(({ createGame }) => {
        if (dead) return;
        handle = createGame({
          view,
          map,
          hudRoot: hud,
          save: loaded,
          onPhase: (next, payload) => {
            setPhase(next);
            setSave((prev) => ({ ...prev, bestLap: payload.bestLap, bestRace: payload.bestRace }));
            if (payload.results) setResults(payload.results);
          },
        });
        gameRef.current = handle;
        if (queued.current) handle.start();
      })
      .catch((err: unknown) => {
        console.error(err);
        if (!dead) setError("تعذر تشغيل الرسوم. حدّث الصفحة وجرب مرة أخرى.");
      });
    return () => {
      dead = true;
      handle?.dispose();
      gameRef.current = null;
    };
  }, []);

  const skin = skinById(save.skin);
  const playerResult = results.find((r) => r.player);

  function start() {
    if (!gameRef.current) {
      queued.current = true;
      return;
    }
    gameRef.current.unlock();
    gameRef.current.start();
  }

  function hold(key: "gas" | "brake" | "drift") {
    return {
      onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        gameRef.current?.setHold(key, true);
      },
      onPointerUp: () => gameRef.current?.setHold(key, false),
      onPointerCancel: () => gameRef.current?.setHold(key, false),
    };
  }

  function onPad(e: React.PointerEvent<HTMLDivElement>) {
    e.preventDefault();
    if (!e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.setPointerCapture(e.pointerId);
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const steer = Math.max(-1, Math.min(1, (0.5 - nx) * 2));
    gameRef.current?.setPad(steer);
    setThumb(50 - steer * 36);
  }

  function endPad() {
    gameRef.current?.setPad(null);
    setThumb(50);
  }

  const showDrive = phase === "countdown" || phase === "race" || phase === "paused";

  return (
    <main className="race-root" onPointerDown={() => gameRef.current?.unlock()}>
      <canvas ref={viewRef} className="absolute inset-0 h-full w-full" aria-label="حلبة السباق" />

      <div
        ref={hudRef}
        className={
          phase === "garage" || phase === "finish"
            ? "pointer-events-none invisible"
            : "pointer-events-none"
        }
      >
        <div data-hud="boost" className="boost-vignette pointer-events-none absolute inset-0 opacity-0" />
        <div className="safe-top absolute inset-x-0 top-0 flex items-start justify-between gap-3 px-3" dir="ltr">
          <div className="pointer-events-auto flex gap-2">
            <button
              type="button"
              className="min-h-11 rounded-full bg-surface px-3 text-sm font-bold text-fg"
              onClick={() => (phase === "paused" ? gameRef.current?.resume() : gameRef.current?.pause())}
            >
              {phase === "paused" ? "كمّل" : "توقف"}
            </button>
            <button
              type="button"
              className="min-h-11 rounded-full bg-surface px-3 text-sm font-bold text-fg"
              onClick={() => gameRef.current?.rescue()}
            >
              إنقاذ
            </button>
            <button
              type="button"
              className="min-h-11 rounded-full bg-surface px-3 text-sm font-bold text-fg"
              onClick={() => gameRef.current?.cycleCam()}
            >
              كاميرا
            </button>
          </div>
          <div className="text-end" dir="rtl">
            <div className="flex items-end justify-end gap-2">
              <span data-hud="speed" className="font-display text-5xl leading-none text-primary tabular-nums">
                0
              </span>
              <span className="pb-1 text-sm text-muted">كم/س</span>
            </div>
            <p className="mt-1 text-sm text-fg">
              اللفة <span data-hud="lap" className="tabular-nums">1/3</span>
              <span className="px-2 text-muted">·</span>
              المركز <span data-hud="pos" className="tabular-nums">1/4</span>
            </p>
            <p className="text-sm text-muted tabular-nums" dir="ltr">
              <span data-hud="lapTime">0:00.00</span>
              <span className="px-1">/</span>
              <span data-hud="raceTime">0:00.00</span>
            </p>
            <p className="text-xs text-muted">
              أفضل لفة <span data-hud="best" className="tabular-nums" dir="ltr">0:00.00</span>
            </p>
            <div className="mt-2 h-2 w-36 overflow-hidden rounded-full bg-surface">
              <div data-hud="drift" className="h-full w-full origin-left scale-x-0 bg-accent" />
            </div>
          </div>
        </div>
        <div
          data-hud="wrong"
          className="absolute top-28 left-1/2 -translate-x-1/2 rounded-full bg-primary px-4 py-2 text-sm font-bold text-bg opacity-0"
        >
          راجع للوراء
        </div>
        <div
          data-hud="flash"
          className="absolute top-40 left-1/2 -translate-x-1/2 text-2xl font-extrabold text-accent opacity-0"
        />
        <div data-hud="countWrap" className="absolute inset-0 grid place-items-center" style={{ display: "none" }}>
          <div data-hud="count" className="font-display text-8xl text-primary">
            3
          </div>
        </div>
      </div>

      <canvas
        ref={mapRef}
        className="absolute top-24 left-3 z-10 h-24 w-24 rounded-xl border border-border bg-bg/80"
        aria-hidden="true"
      />

      {showDrive ? (
        <div className="safe-bottom pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 px-3" dir="ltr">
          <div
            className="pointer-events-auto relative h-32 w-40 rounded-2xl border border-border bg-surface/80"
            onPointerDown={onPad}
            onPointerMove={(e) => {
              if (e.currentTarget.hasPointerCapture(e.pointerId)) onPad(e);
            }}
            onPointerUp={endPad}
            onPointerCancel={endPad}
          >
            <span className="pointer-events-none absolute top-2 left-3 text-xs font-bold text-muted">يسار</span>
            <span className="pointer-events-none absolute top-2 right-3 text-xs font-bold text-muted">يمين</span>
            <span
              className="pointer-events-none absolute top-1/2 size-11 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary"
              style={{ left: `${thumb}%` }}
            />
          </div>
          <div className="pointer-events-auto flex items-end gap-2">
            <button type="button" className="min-h-14 min-w-16 rounded-2xl bg-surface px-3 text-sm font-bold text-fg" {...hold("drift")}>
              دريفت
            </button>
            <button type="button" className="min-h-14 min-w-16 rounded-2xl bg-surface px-3 text-sm font-bold text-fg" {...hold("brake")}>
              فرامل
            </button>
            <button type="button" className="min-h-20 min-w-20 rounded-2xl bg-primary text-base font-extrabold text-bg" {...hold("gas")}>
              غاز
            </button>
          </div>
        </div>
      ) : null}

      {phase === "paused" ? (
        <div className="absolute inset-0 grid place-items-center bg-bg/55 p-6">
          <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-5 text-center">
            <h2 className="text-2xl font-extrabold">متوقف</h2>
            <div className="mt-4 flex flex-col gap-2">
              <button type="button" className="min-h-12 rounded-xl bg-primary font-extrabold text-bg" onClick={() => gameRef.current?.resume()}>
                كمّل
              </button>
              <button type="button" className="min-h-12 rounded-xl bg-bg font-bold text-fg" onClick={() => gameRef.current?.toGarage()}>
                الكراج
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {phase === "finish" && playerResult ? (
        <div className="absolute inset-0 grid place-items-end bg-bg/50 p-4 sm:place-items-center">
          <div className="max-h-[80%] w-full max-w-sm overflow-auto rounded-2xl border border-border bg-surface p-5">
            <p className="text-sm font-bold text-accent">أنهيت السباق</p>
            <h2 className="mt-1 text-3xl font-extrabold text-primary">المركز {PLACES[playerResult.place] ?? playerResult.place}</h2>
            <p className="mt-1 text-sm text-muted tabular-nums" dir="ltr">
              {formatTime(playerResult.time ?? 0)}
            </p>
            <ol className="mt-4 flex flex-col gap-2">
              {results.map((r) => (
                <li
                  key={r.name}
                  className={
                    r.player
                      ? "flex items-center justify-between rounded-xl bg-primary/15 px-3 py-2"
                      : "flex items-center justify-between rounded-xl bg-bg px-3 py-2"
                  }
                >
                  <span className="font-bold">{r.place}</span>
                  <span className="font-bold">{r.name}</span>
                  <span className="text-sm tabular-nums" dir="ltr">
                    {r.time != null ? formatTime(r.time) : "لم يكمل"}
                  </span>
                </li>
              ))}
            </ol>
            <div className="mt-4 flex flex-col gap-2">
              <button type="button" className="min-h-12 rounded-xl bg-primary font-extrabold text-bg" onClick={start}>
                سباق جديد
              </button>
              <button type="button" className="min-h-12 rounded-xl bg-bg font-bold text-fg" onClick={() => gameRef.current?.toGarage()}>
                الكراج
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {phase === "garage" ? (
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between">
          <div className="safe-top px-4">
            <p className="text-sm font-bold tracking-wide text-accent">سباق ليلي</p>
            <h1 className="text-4xl font-extrabold text-primary">نيترو ديون</h1>
            <p className="max-w-xs text-sm text-muted">كثبان، نيون، ودفعة من بعد كل دريفت.</p>
          </div>
          <div className="pointer-events-auto safe-bottom max-h-[62%] overflow-auto rounded-t-2xl border border-border bg-surface/90 p-4">
            <div className="flex items-end justify-between gap-3">
              <div>
                <h2 className="text-2xl font-extrabold">{skin.name}</h2>
                <p className="text-sm text-muted">{skin.blurb}</p>
              </div>
              <p className="text-end text-xs text-muted">
                أفضل لفة
                <span className="mt-1 block font-display text-lg text-primary tabular-nums" dir="ltr">
                  {formatTime(save.bestLap)}
                </span>
              </p>
            </div>
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {SKINS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={
                    item.id === skin.id
                      ? "min-h-11 shrink-0 rounded-full bg-primary px-3 text-sm font-bold text-bg"
                      : "min-h-11 shrink-0 rounded-full bg-bg px-3 text-sm font-bold text-fg"
                  }
                  onClick={() => {
                    setSave((prev) => ({ ...prev, skin: item.id }));
                    gameRef.current?.setSkin(item.id);
                  }}
                >
                  {item.name}
                </button>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                className="min-h-11 flex-1 rounded-xl bg-bg text-sm font-bold text-fg"
                onClick={() => {
                  const next = !save.auto;
                  setSave((prev) => ({ ...prev, auto: next }));
                  gameRef.current?.setAuto(next);
                }}
              >
                غاز أوتو: {save.auto ? "شغّال" : "مطفّي"}
              </button>
              <button
                type="button"
                className="min-h-11 flex-1 rounded-xl bg-bg text-sm font-bold text-fg"
                onClick={() => {
                  const next = !save.mute;
                  setSave((prev) => ({ ...prev, mute: next }));
                  gameRef.current?.setMute(next);
                }}
              >
                الصوت: {save.mute ? "مطفّي" : "شغّال"}
              </button>
            </div>
            <p className="mt-3 text-sm text-muted">
              اسحب يسار ويمين. امسك دريفت في المنعطف، ومن بعد اتركو باش تجيك دفعة.
            </p>
            <p className="mt-1 hidden text-sm text-muted md:block" dir="ltr">
              W غاز · A يسار · D يمين · Space دريفت · S فرامل
            </p>
            {error ? <p className="mt-2 text-sm font-bold text-accent">{error}</p> : null}
            <button type="button" className="mt-3 min-h-14 w-full rounded-xl bg-primary text-lg font-extrabold text-bg" onClick={start}>
              ابدأ السباق
            </button>
          </div>
        </div>
      ) : null}
    </main>
  );
}
