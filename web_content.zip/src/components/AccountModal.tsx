import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useKingdom } from '../context/KingdomContext';
import {
  Crown,
  User,
  Mail,
  Cloud,
  CheckCircle2,
  LogOut,
  X,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  Link,
} from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({ isOpen, onClose }) => {
  const { user, logout, loginWithGoogle } = useAuth();
  const { kingdom, isSyncing, lastSyncedAt, saveKingdomToCloud } = useKingdom();
  const [linking, setLinking] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  if (!isOpen || !user) return null;

  const handleManualSave = async () => {
    await saveKingdomToCloud();
    setMsg('¡Partida sincronizada correctamente en la nube!');
    setTimeout(() => setMsg(null), 3500);
  };

  const handleLinkGoogle = async (directEmail?: string) => {
    setLinking(true);
    setMsg(null);
    try {
      await loginWithGoogle(directEmail || 'nachosunen@gmail.com');
      setMsg('¡Cuenta vinculada con éxito a Google!');
    } catch {
      setMsg('No se pudo vincular la cuenta en este momento.');
    } finally {
      setLinking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl relative text-stone-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 rounded-2xl bg-amber-950/70 border border-amber-800/60 text-amber-400 shadow-inner">
            <User className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-lg font-serif text-stone-100">
                Perfil de Soberano
              </h3>
              {user.isAnonymous ? (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-stone-800 border border-stone-700 text-stone-300">
                  Invitado
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 border border-emerald-800/80 text-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  Verificado
                </span>
              )}
            </div>
            <p className="text-xs text-stone-400">
              {kingdom?.kingdomName || 'Feudo sin nombre'} • {kingdom?.castleName || 'Castillo'}
            </p>
          </div>
        </div>

        {/* Feedback message */}
        {msg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/70 border border-emerald-800 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{msg}</span>
          </div>
        )}

        {/* Account Details Card */}
        <div className="space-y-3 mb-5">
          <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800 space-y-2 text-xs">
            <div className="flex items-center justify-between text-stone-400">
              <span className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-stone-500" />
                Cuenta / Correo:
              </span>
              <span className="font-mono text-stone-200 font-medium">
                {user.email || 'Sin correo (Modo Invitado)'}
              </span>
            </div>
            <div className="flex items-center justify-between text-stone-400 pt-1 border-t border-stone-800/60">
              <span className="flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 text-stone-500" />
                ID de Jugador:
              </span>
              <span className="font-mono text-[11px] text-amber-400">
                {user.uid.slice(0, 12)}...
              </span>
            </div>
            <div className="flex items-center justify-between text-stone-400 pt-1 border-t border-stone-800/60">
              <span className="flex items-center gap-1.5">
                <Cloud className="w-3.5 h-3.5 text-stone-500" />
                Estado en la nube:
              </span>
              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {isSyncing ? 'Sincronizando...' : 'Firestore Conectado'}
              </span>
            </div>
            {lastSyncedAt && (
              <div className="text-[10px] text-stone-500 text-right">
                Última copia: {lastSyncedAt.toLocaleTimeString()}
              </div>
            )}
          </div>

          {/* Guest Link Promo */}
          {user.isAnonymous && (
            <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-800/60 text-xs">
              <div className="flex items-center gap-2 text-amber-300 font-semibold mb-1">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>¿Quieres conservar tu reino para siempre?</span>
              </div>
              <p className="text-stone-400 text-[11px] mb-3 leading-relaxed">
                Vincula tu cuenta a Google para acceder desde cualquier ordenador o teléfono sin perder recursos ni soldados.
              </p>
              <button
                type="button"
                disabled={linking}
                onClick={() => handleLinkGoogle()}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-white hover:bg-stone-100 text-stone-900 font-semibold text-xs transition cursor-pointer shadow"
              >
                <Link className="w-3.5 h-3.5" />
                <span>{linking ? 'Vinculando...' : 'Vincular a cuenta de Google'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-2 pt-2 border-t border-stone-800">
          <button
            type="button"
            disabled={isSyncing}
            onClick={handleManualSave}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Guardando en la nube...' : 'Forzar guardado en la nube ahora'}</span>
          </button>
          <button
            type="button"
            onClick={async () => {
              onClose();
              await logout();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-red-950/40 hover:bg-red-950/70 border border-red-900/60 text-red-300 text-xs font-semibold transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Cerrar Sesión</span>
          </button>
        </div>
      </div>
    </div>
  );
};
