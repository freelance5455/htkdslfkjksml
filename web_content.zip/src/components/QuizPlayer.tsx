import React, { useState } from 'react';
import { Quiz } from '../types';
import {
  Trophy,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  BookOpen,
  Home,
  Lightbulb,
  Award,
  Sparkles,
  Clock
} from 'lucide-react';

interface QuizPlayerProps {
  quiz: Quiz;
  onExit: () => void;
}

export const QuizPlayer: React.FC<QuizPlayerProps> = ({ quiz, onExit }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(
    new Array(quiz.questions.length).fill(null)
  );
  const [isFinished, setIsFinished] = useState(false);

  const currentQ = quiz.questions[currentIndex];
  const selectedOption = userAnswers[currentIndex];

  const handleSelectOption = (index: number) => {
    const updated = [...userAnswers];
    updated[currentIndex] = index;
    setUserAnswers(updated);
  };

  const handleNext = () => {
    if (currentIndex < quiz.questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setIsFinished(true);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleRestart = () => {
    setUserAnswers(new Array(quiz.questions.length).fill(null));
    setCurrentIndex(0);
    setIsFinished(false);
  };

  // Calculate score
  const correctCount = userAnswers.reduce((acc, ans, idx) => {
    if (ans === quiz.questions[idx].correctIndex) return (acc as number) + 1;
    return acc;
  }, 0) as number;

  const percentage = Math.round((correctCount / quiz.questions.length) * 100);

  // Results View
  if (isFinished) {
    let performanceLabel = 'और अभ्यास करें';
    let performanceColor = 'text-amber-600 bg-amber-50 border-amber-200';
    if (percentage >= 80) {
      performanceLabel = 'उत्कृष्ट प्रदर्शन! (Excellent)';
      performanceColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
    } else if (percentage >= 50) {
      performanceLabel = 'अच्छा प्रयास! (Good Job)';
      performanceColor = 'text-blue-700 bg-blue-50 border-blue-200';
    }

    return (
      <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-200">
        {/* Scorecard Hero */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Trophy className="w-48 h-48" />
          </div>

          <div className="w-20 h-20 bg-gradient-to-tr from-amber-400 to-yellow-300 rounded-3xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20 mb-4 transform hover:scale-105 transition">
            <Trophy className="w-10 h-10 text-amber-900" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            टेस्ट समाप्त हुआ! (Test Completed)
          </h2>
          <p className="text-slate-500 text-sm mt-1">{quiz.title}</p>

          <div className="my-6 inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-4xl font-black text-blue-600 font-mono">
              {correctCount}
            </span>
            <span className="text-xl text-slate-400 font-medium">/</span>
            <span className="text-2xl font-bold text-slate-700 font-mono">
              {quiz.questions.length}
            </span>
            <span className={`ml-3 px-3 py-1 rounded-full text-xs font-bold border ${performanceColor}`}>
              {percentage}% अंक • {performanceLabel}
            </span>
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={handleRestart}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl transition flex items-center gap-2 shadow-sm"
            >
              <RotateCcw className="w-4 h-4" />
              <span>पुनः प्रयास करें (Try Again)</span>
            </button>
            <button
              onClick={onExit}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm rounded-xl transition flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              <span>सभी विषय (Home)</span>
            </button>
          </div>
        </div>

        {/* Detailed Review & Explanations */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-slate-200 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  उत्तर कुंजी एवं विस्तृत व्याख्या (Answer Key & Solutions)
                </h3>
                <p className="text-xs text-slate-500">
                  प्रत्येक प्रश्न का सही उत्तर और उसकी पूर्ण व्याख्या देखें।
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {quiz.questions.map((q, qIdx) => {
              const userPick = userAnswers[qIdx];
              const isCorrect = userPick === q.correctIndex;
              const isAttempted = userPick !== null;

              return (
                <div
                  key={qIdx}
                  className={`p-5 rounded-2xl border transition-all ${
                    !isAttempted
                      ? 'border-slate-200 bg-slate-50/50'
                      : isCorrect
                      ? 'border-emerald-300 bg-emerald-50/40'
                      : 'border-red-300 bg-red-50/40'
                  }`}
                >
                  {/* Question header */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-start gap-2.5">
                      <span className="font-bold text-sm px-2 py-0.5 rounded-lg bg-white border border-slate-200 text-slate-700 shadow-2xs">
                        Q{qIdx + 1}
                      </span>
                      <h4 className="font-bold text-slate-900 text-base leading-snug">
                        {q.text}
                      </h4>
                    </div>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full font-bold shrink-0 flex items-center gap-1 ${
                        !isAttempted
                          ? 'bg-slate-200 text-slate-700'
                          : isCorrect
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {isCorrect ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" /> सही (+1)
                        </>
                      ) : isAttempted ? (
                        <>
                          <XCircle className="w-3.5 h-3.5" /> गलत (0)
                        </>
                      ) : (
                        'अनुत्तरित'
                      )}
                    </span>
                  </div>

                  {/* Options list */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-3">
                    {q.options.map((opt, oIdx) => {
                      const isOptionCorrect = oIdx === q.correctIndex;
                      const isOptionUserPick = oIdx === userPick;

                      let badgeStyle = 'border-slate-200 bg-white text-slate-700';
                      if (isOptionCorrect) {
                        badgeStyle = 'border-emerald-500 bg-emerald-100/90 text-emerald-950 font-semibold shadow-2xs';
                      } else if (isOptionUserPick && !isOptionCorrect) {
                        badgeStyle = 'border-red-500 bg-red-100/90 text-red-950 font-medium';
                      }

                      return (
                        <div
                          key={oIdx}
                          className={`p-3 rounded-xl border text-xs sm:text-sm flex items-center justify-between ${badgeStyle}`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-lg bg-black/5 font-bold flex items-center justify-center text-xs">
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span>{opt}</span>
                          </div>
                          {isOptionCorrect && (
                            <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> सही उत्तर
                            </span>
                          )}
                          {isOptionUserPick && !isOptionCorrect && (
                            <span className="text-[11px] font-bold text-red-600 flex items-center gap-1">
                              <XCircle className="w-3.5 h-3.5" /> आपका चयन
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Detailed Hindi Explanation Box */}
                  <div className="mt-4 p-4 rounded-xl bg-amber-50/90 border border-amber-200/80 text-xs sm:text-sm text-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-amber-900">
                      <Lightbulb className="w-4 h-4 text-amber-600 fill-current" />
                      <span>विस्तृत व्याख्या (Explanation):</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed pl-5 font-normal">
                      {q.explanation || 'इस प्रश्न के लिए प्रामाणिक व्याख्या उपलब्ध है।'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Active Quiz Question View
  return (
    <div className="max-w-3xl mx-auto space-y-4 animate-in fade-in duration-200">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 flex items-center justify-between">
        <div>
          <span className="text-xs uppercase font-extrabold tracking-wider text-blue-600 block">
            {quiz.title}
          </span>
          <h3 className="text-sm sm:text-base font-bold text-slate-800">
            प्रश्न संख्या {currentIndex + 1} of {quiz.questions.length}
          </h3>
        </div>
        <button
          onClick={onExit}
          className="text-xs text-slate-500 hover:text-red-600 bg-slate-50 hover:bg-red-50 border border-slate-200 px-3 py-1.5 rounded-lg transition"
        >
          क्विज़ छोड़ें (Exit)
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
        <div
          className="bg-blue-600 h-full transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / quiz.questions.length) * 100}%` }}
        />
      </div>

      {/* Main Question Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-slate-200 space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
              प्रश्न {currentIndex + 1}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-relaxed">
            {currentQ.text}
          </h2>
        </div>

        {/* Options */}
        <div className="space-y-3 pt-2">
          {currentQ.options.map((opt, idx) => {
            const isSelected = selectedOption === idx;
            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                className={`w-full text-left p-4 rounded-2xl border-2 transition-all duration-200 flex items-center justify-between group ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-semibold shadow-xs'
                    : 'border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-8 h-8 rounded-xl font-bold flex items-center justify-center text-sm transition ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-blue-700'
                    }`}
                  >
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="text-sm sm:text-base leading-snug">{opt}</span>
                </div>
                {isSelected && (
                  <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Navigation buttons */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-sm font-semibold transition flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>पिछला प्रश्न</span>
          </button>

          <button
            onClick={handleNext}
            className={`px-6 py-2.5 rounded-xl text-white text-sm font-semibold transition flex items-center gap-2 shadow-md ${
              currentIndex === quiz.questions.length - 1
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            <span>
              {currentIndex === quiz.questions.length - 1 ? 'टेस्ट पूरा करें (Submit)' : 'अगला प्रश्न'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
