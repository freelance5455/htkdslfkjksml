import { useEffect, useState } from "react";
import { OutlookChart } from "@/components/charts";
import { Field } from "@/components/ui";
import { allocation, futureValue, portfolioValue, resolveRates, weightedExpectedReturn } from "@/lib/calc";
import { formatKrw, formatMan, parseNum } from "@/lib/format";
import { usePortfolio } from "@/lib/store";

export function OutlookView() {
  const data = usePortfolio();
  const total = portfolioValue(data.holdings, data.market.fx);
  const rows = allocation(data.holdings, data.classes, data.market.fx);
  const computed = weightedExpectedReturn(rows);
  const rates = resolveRates(computed, data.settings);
  const monthly = data.settings.contribution;
  const years = data.settings.years;
  const chart = Array.from({ length: years + 1 }, (_, year) => ({
    label: year === 0 ? "지금" : `${year}년`,
    low: futureValue(total, rates.pessimistic, monthly, year),
    mid: futureValue(total, rates.average, monthly, year),
    high: futureValue(total, rates.optimistic, monthly, year),
  }));
  const contributed = monthly * years * 12;
  const principal = total + contributed;

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-base font-semibold">앞으로의 자산</h2>
        <p className="text-sm text-muted">
          평균 수익률은 자산군 기대수익을 지금 비중으로 가중평균한 값입니다. 세 숫자 모두 직접 바꿀 수 있습니다.
        </p>
      </div>
      <section className="card p-4">
        <p className="text-xs text-muted">보유 기준 평균 {computed.toFixed(1)}%</p>
        <div className="mt-3 grid gap-3">
          <RateField
            label="비관"
            value={rates.pessimistic}
            auto={rates.pessimisticAuto}
            onAuto={() => data.updateSettings({ pessimistic: null })}
            onChange={(value) => data.updateSettings({ pessimistic: value })}
          />
          <RateField
            label="평균"
            value={rates.average}
            auto={rates.averageAuto}
            onAuto={() => data.updateSettings({ average: null })}
            onChange={(value) => data.updateSettings({ average: value })}
          />
          <RateField
            label="낙관"
            value={rates.optimistic}
            auto={rates.optimisticAuto}
            onAuto={() => data.updateSettings({ optimistic: null })}
            onChange={(value) => data.updateSettings({ optimistic: value })}
          />
        </div>
        <p className="mt-2 text-xs text-muted">자동이면 비관은 평균보다 4%p 낮고, 낙관은 3%p 높습니다.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <MoneyField
            label="매달 추가 투자"
            value={monthly}
            onChange={(value) => data.updateSettings({ contribution: Math.max(0, Math.round(value)) })}
          />
          <Field label="기간">
            <div className="flex items-center gap-2">
              <button type="button" className="size-11 rounded-lg bg-surface-2 text-lg" onClick={() => data.updateSettings({ years: Math.max(1, years - 1) })}>
                −
              </button>
              <span className="w-16 text-center text-sm font-medium tabular-nums">{years}년</span>
              <button type="button" className="size-11 rounded-lg bg-surface-2 text-lg" onClick={() => data.updateSettings({ years: Math.min(30, years + 1) })}>
                +
              </button>
            </div>
          </Field>
        </div>
      </section>
      <section className="card p-4">
        <div className="mb-2 flex flex-wrap gap-3 text-xs">
          <span className="text-muted">비관</span>
          <span className="text-primary">평균</span>
          <span style={{ color: "var(--color-c3)" }}>낙관</span>
        </div>
        <OutlookChart rows={chart} />
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <End label="비관" value={chart[chart.length - 1]?.low ?? total} principal={principal} />
          <End label="평균" value={chart[chart.length - 1]?.mid ?? total} principal={principal} />
          <End label="낙관" value={chart[chart.length - 1]?.high ?? total} principal={principal} />
        </div>
        <p className="mt-3 text-xs text-muted">
          원금은 지금 평가액 {formatMan(total)}에 앞으로 넣을 {formatMan(contributed)}을 더한 값입니다. 세금, 수수료, 환율 변동은 넣지 않았습니다.
        </p>
      </section>
      <section className="card p-4">
        <h3 className="text-sm font-semibold">자산군 기대수익률</h3>
        <p className="mt-1 mb-3 text-xs text-muted">이 값이 평균 시나리오의 재료입니다. 비중은 현황의 목표 조정에서 바꿉니다.</p>
        <ul className="space-y-2">
          {data.classes.map((item) => (
            <li key={item.id} className="flex items-center gap-3">
              <span className="size-2 shrink-0 rounded-full" style={{ background: item.color }} />
              <span className="min-w-0 flex-1 truncate text-sm">{item.name}</span>
              <input
                className="field w-24 text-right tabular-nums"
                inputMode="decimal"
                aria-label={`${item.name} 기대수익률`}
                defaultValue={String(item.expectedReturn)}
                key={`${item.id}-${item.expectedReturn}`}
                onBlur={(event) => {
                  const next = parseNum(event.target.value);
                  if (next == null) return;
                  data.updateClass(item.id, { expectedReturn: Math.min(40, Math.max(-20, next)) });
                }}
              />
              <span className="text-sm text-muted">%</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function End({ label, value, principal }: { label: string; value: number; principal: number }) {
  return (
    <div className="rounded-lg bg-surface-2 px-2 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-sm font-semibold tabular-nums">{formatMan(value)}</p>
      <p className="text-xs tabular-nums text-muted">수익 {formatMan(value - principal)}</p>
    </div>
  );
}

function RateField({
  label,
  value,
  auto,
  onChange,
  onAuto,
}: {
  label: string;
  value: number;
  auto: boolean;
  onChange: (value: number) => void;
  onAuto: () => void;
}) {
  const [text, setText] = useState(value.toFixed(1));
  const [focus, setFocus] = useState(false);
  useEffect(() => {
    if (!focus) setText(value.toFixed(1));
  }, [value, focus]);
  return (
    <div className="flex items-end gap-2">
      <Field label={`${label} 연수익률`}>
        <input
          className="field tabular-nums"
          inputMode="decimal"
          value={text}
          onFocus={() => setFocus(true)}
          onBlur={() => {
            setFocus(false);
            const next = parseNum(text);
            if (next == null) {
              setText(value.toFixed(1));
              return;
            }
            onChange(Math.min(25, Math.max(-15, next)));
          }}
          onChange={(event) => setText(event.target.value)}
        />
      </Field>
      <button type="button" className="mb-0 h-11 shrink-0 px-2 text-sm text-primary" onClick={onAuto}>
        {auto ? "자동" : "자동으로"}
      </button>
    </div>
  );
}

function MoneyField({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  const [text, setText] = useState(String(value));
  const [focus, setFocus] = useState(false);
  useEffect(() => {
    if (!focus) setText(String(value));
  }, [value, focus]);
  return (
    <Field label={label}>
      <input
        className="field tabular-nums"
        inputMode="numeric"
        value={text}
        onFocus={() => setFocus(true)}
        onBlur={() => {
          setFocus(false);
          const next = parseNum(text);
          if (next == null) {
            setText(String(value));
            return;
          }
          onChange(Math.min(100_000_000, Math.max(0, next)));
        }}
        onChange={(event) => setText(event.target.value)}
      />
    </Field>
  );
}
