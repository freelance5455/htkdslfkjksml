/**
 * HELENA - Menu Arquivos (Ponte PC ↔ Celular via Firebase Firestore)
 * Select what to transfer (3D Models, Photos, Files, Settings),
 * upload data to Firestore system database, and receive in real time.
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React, { useState, useEffect } from 'react';
import { 
  FolderSync, 
  X, 
  Smartphone, 
  Monitor, 
  Upload, 
  Download, 
  CheckCircle2, 
  Box, 
  Image as ImageIcon, 
  FileText, 
  Key, 
  RefreshCw, 
  Send,
  Radio,
  Clock,
  Sparkles
} from 'lucide-react';
import { AppSettings, Model3DItem } from '../types';
import { 
  getLocalDeviceId, 
  getLocalDeviceName, 
  setLocalDeviceName,
  registerDeviceHeartbeat, 
  listenOnlineDevices, 
  sendTransferItem, 
  listenIncomingTransfers, 
  completeTransfer,
  saveOwnerSettingsToFirestore,
  PairedDevice, 
  RealtimeTransfer 
} from '../services/firebase';
import { getAllModels, getModelBlob, saveModel } from '../services/indexedDb';
import { helenaVoice } from '../services/voice';

interface FilesModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onModelReceived?: () => void;
}

export const FilesModal: React.FC<FilesModalProps> = ({
  settings,
  isOpen,
  onClose,
  onModelReceived,
}) => {
  const [deviceId] = useState<string>(getLocalDeviceId);
  const [deviceName, setDeviceName] = useState<string>(getLocalDeviceName);
  const [isEditingDeviceName, setIsEditingDeviceName] = useState(false);

  const [onlineDevices, setOnlineDevices] = useState<PairedDevice[]>([]);
  const [incomingTransfers, setIncomingTransfers] = useState<RealtimeTransfer[]>([]);
  const [localModels, setLocalModels] = useState<Model3DItem[]>([]);

  // Selection states
  const [transferType, setTransferType] = useState<'model3d' | 'image' | 'file' | 'settings'>('model3d');
  const [selectedModelId, setSelectedModelId] = useState<string>('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetDevice, setTargetDevice] = useState<string>('Todos');

  // Status states
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [savingTransferId, setSavingTransferId] = useState<string | null>(null);

  // Initialize and listen to Firebase
  useEffect(() => {
    if (!isOpen) return;

    // Heartbeat
    registerDeviceHeartbeat(deviceName);
    const heartbeatInterval = setInterval(() => {
      registerDeviceHeartbeat(deviceName);
    }, 60000);

    // Listen to other online devices
    const unsubscribeDevices = listenOnlineDevices(deviceId, (devs) => {
      setOnlineDevices(devs);
    });

    // Listen to incoming transfers
    const unsubscribeTransfers = listenIncomingTransfers(deviceId, (transfers) => {
      setIncomingTransfers(transfers);
    });

    // Load local models for selection
    getAllModels().then((models) => {
      setLocalModels(models);
      if (models.length > 0 && !selectedModelId) {
        setSelectedModelId(models[0].id);
      }
    });

    return () => {
      clearInterval(heartbeatInterval);
      unsubscribeDevices();
      unsubscribeTransfers();
    };
  }, [isOpen, deviceId, deviceName]);

  const handleUpdateDeviceName = () => {
    setLocalDeviceName(deviceName);
    registerDeviceHeartbeat(deviceName);
    setIsEditingDeviceName(false);
  };

  // Convert Blob/File to Base64
  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        resolve(res);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  // Upload & Transmit to Firestore
  const handleUploadAndSend = async () => {
    setIsUploading(true);
    setUploadSuccess(null);

    try {
      if (transferType === 'model3d') {
        const model = localModels.find((m) => m.id === selectedModelId);
        if (!model) throw new Error('Selecione um modelo 3D da biblioteca.');

        const blob = await getModelBlob(model.id);
        if (!blob) throw new Error('Arquivo do modelo não encontrado no IndexedDB.');

        const base64Data = await blobToBase64(blob);

        await sendTransferItem({
          name: model.name,
          type: 'model3d',
          sizeBytes: blob.size,
          senderDevice: deviceName,
          targetDevice,
          payloadData: base64Data,
          modelProperties: {
            ...model.customProperties,
            originalId: model.id,
            sourceSpace: model.sourceSpace,
          },
        });

        setUploadSuccess(`Modelo 3D "${model.name}" enviado com sucesso via Firestore!`);
        helenaVoice.speak(`Modelo ${model.name} enviado para a ponte.`);
      } else if (transferType === 'image' || transferType === 'file') {
        if (!selectedFile) throw new Error('Selecione um arquivo para transferir.');

        const base64Data = await blobToBase64(selectedFile);

        await sendTransferItem({
          name: selectedFile.name,
          type: transferType,
          sizeBytes: selectedFile.size,
          senderDevice: deviceName,
          targetDevice,
          payloadData: base64Data,
        });

        setUploadSuccess(`Arquivo "${selectedFile.name}" transmitido com sucesso!`);
        helenaVoice.speak('Arquivo transmitido para a ponte.');
      } else if (transferType === 'settings') {
        await saveOwnerSettingsToFirestore(settings);
        setUploadSuccess('Configurações e chaves salvas com segurança no Firestore!');
        helenaVoice.speak('Configurações salvas no banco do sistema.');
      }
    } catch (err: any) {
      alert(`Falha no envio: ${err?.message || 'Erro desconhecido'}`);
    } finally {
      setIsUploading(false);
    }
  };

  // Save received 3D model into IndexedDB
  const handleSaveReceivedModel = async (transfer: RealtimeTransfer) => {
    if (!transfer.payloadData) return;
    setSavingTransferId(transfer.id);

    try {
      // Decode data URL to Blob
      const res = await fetch(transfer.payloadData);
      const blob = await res.blob();

      const newModel: Model3DItem = {
        id: `model_rx_${Date.now()}`,
        name: `${transfer.name} (recebido de ${transfer.senderDevice})`,
        createdAt: new Date().toISOString(),
        sizeBytes: blob.size,
        photoCount: 4,
        sourceSpace: transfer.modelProperties?.sourceSpace || 'Ponte PC-Celular',
        customProperties: transfer.modelProperties || {
          scale: 1.0,
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0,
          colorTint: '#17B35A',
          wireframe: false,
        },
      };

      await saveModel(newModel, blob);
      await completeTransfer(transfer.id);
      onModelReceived?.();
      helenaVoice.speak('Modelo 3D salvo com sucesso na sua Biblioteca local.');
      alert('Modelo 3D recebido e gravado na sua Biblioteca 3D!');
    } catch (err: any) {
      alert(`Falha ao salvar modelo: ${err?.message}`);
    } finally {
      setSavingTransferId(null);
    }
  };

  // Download received file
  const handleDownloadReceivedFile = async (transfer: RealtimeTransfer) => {
    if (!transfer.payloadData) return;
    const a = document.createElement('a');
    a.href = transfer.payloadData;
    a.download = transfer.name;
    a.click();
    await completeTransfer(transfer.id);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 md:p-6 overflow-y-auto animate-fade-in">
      <div 
        className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-2xl w-full p-5 md:p-6 space-y-6 shadow-2xl max-h-[92vh] flex flex-col text-[#CDEBD8]"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#14502D]/60">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#0E7A3D]/20 border border-[#0E7A3D] rounded-xl text-[#2FD16F]">
              <FolderSync className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white tracking-wide">
                Ponte PC ↔ Celular (Firebase Firestore)
              </h2>
              <span className="text-[11px] text-[#2FD16F] flex items-center space-x-1 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2FD16F] animate-pulse" />
                <span>Conectado em tempo real ao banco do sistema</span>
              </span>
            </div>
          </div>

          <button 
            onClick={onClose} 
            className="p-1 text-[#CDEBD8]/70 hover:text-white rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Device Status & Paired Devices Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-black/60 border border-[#14502D]/80 rounded-xl p-3">
          {/* Current Device */}
          <div className="flex items-center justify-between border-b sm:border-b-0 sm:border-r border-[#14502D]/60 pb-2 sm:pb-0 sm:pr-3">
            <div className="flex items-center space-x-2">
              {deviceName.toLowerCase().includes('celular') ? (
                <Smartphone className="w-4 h-4 text-[#2FD16F]" />
              ) : (
                <Monitor className="w-4 h-4 text-[#2FD16F]" />
              )}
              <div>
                <span className="text-[10px] text-[#CDEBD8]/50 font-mono block">Este aparelho:</span>
                {isEditingDeviceName ? (
                  <input
                    type="text"
                    value={deviceName}
                    onChange={(e) => setDeviceName(e.target.value)}
                    onBlur={handleUpdateDeviceName}
                    onKeyDown={(e) => e.key === 'Enter' && handleUpdateDeviceName()}
                    className="px-2 py-0.5 bg-black border border-[#2FD16F] rounded text-xs text-white"
                    autoFocus
                  />
                ) : (
                  <button
                    onClick={() => setIsEditingDeviceName(true)}
                    className="text-xs font-semibold text-white hover:text-[#2FD16F] transition-colors"
                  >
                    {deviceName} ✎
                  </button>
                )}
              </div>
            </div>
            <span className="text-[10px] text-[#CDEBD8]/50 font-mono">ID: {deviceId.slice(0, 8)}</span>
          </div>

          {/* Other Online Devices */}
          <div className="flex items-center justify-between sm:pl-3">
            <div className="space-y-0.5">
              <span className="text-[10px] text-[#CDEBD8]/50 font-mono block">Aparelhos pareados online:</span>
              <div className="flex items-center space-x-1.5">
                {onlineDevices.length === 0 ? (
                  <span className="text-xs text-[#CDEBD8]/60">Aguardando outro aparelho entrar...</span>
                ) : (
                  onlineDevices.map((dev) => (
                    <span
                      key={dev.id}
                      className="px-2 py-0.5 bg-[#0E7A3D]/30 border border-[#0E7A3D] rounded-full text-[10px] text-[#2FD16F] font-mono flex items-center space-x-1"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-[#2FD16F]" />
                      <span>{dev.name}</span>
                    </span>
                  ))
                )}
              </div>
            </div>
            <button
              onClick={() => registerDeviceHeartbeat(deviceName)}
              className="p-1 text-[#CDEBD8]/50 hover:text-[#2FD16F]"
              title="Atualizar presença"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Transfer Selector & Upload Section */}
        <div className="flex-1 overflow-y-auto space-y-4">
          <div className="bg-black/60 border border-[#14502D]/80 rounded-2xl p-4 space-y-4">
            <h3 className="text-xs font-semibold text-white tracking-wide flex items-center space-x-1.5">
              <Send className="w-3.5 h-3.5 text-[#2FD16F]" />
              <span>O que você deseja transferir para o outro aparelho?</span>
            </h3>

            {/* Type selector tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setTransferType('model3d')}
                className={`p-2.5 rounded-xl border text-left transition-all min-h-[48px] ${
                  transferType === 'model3d'
                    ? 'bg-[#0E7A3D]/40 border-[#2FD16F] text-white shadow-sm'
                    : 'bg-black/40 border-[#14502D] text-[#CDEBD8]/70 hover:text-white'
                }`}
              >
                <Box className="w-4 h-4 mb-1 text-[#2FD16F]" />
                <span className="text-xs font-medium block">Modelo 3D</span>
                <span className="text-[10px] text-[#CDEBD8]/50 block">Da Biblioteca</span>
              </button>

              <button
                type="button"
                onClick={() => setTransferType('image')}
                className={`p-2.5 rounded-xl border text-left transition-all min-h-[48px] ${
                  transferType === 'image'
                    ? 'bg-[#0E7A3D]/40 border-[#2FD16F] text-white shadow-sm'
                    : 'bg-black/40 border-[#14502D] text-[#CDEBD8]/70 hover:text-white'
                }`}
              >
                <ImageIcon className="w-4 h-4 mb-1 text-[#2FD16F]" />
                <span className="text-xs font-medium block">Foto / Campo</span>
                <span className="text-[10px] text-[#CDEBD8]/50 block">Galeria ou Câmera</span>
              </button>

              <button
                type="button"
                onClick={() => setTransferType('file')}
                className={`p-2.5 rounded-xl border text-left transition-all min-h-[48px] ${
                  transferType === 'file'
                    ? 'bg-[#0E7A3D]/40 border-[#2FD16F] text-white shadow-sm'
                    : 'bg-black/40 border-[#14502D] text-[#CDEBD8]/70 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4 mb-1 text-[#2FD16F]" />
                <span className="text-xs font-medium block">Arquivo / PDF</span>
                <span className="text-[10px] text-[#CDEBD8]/50 block">Documentos</span>
              </button>

              <button
                type="button"
                onClick={() => setTransferType('settings')}
                className={`p-2.5 rounded-xl border text-left transition-all min-h-[48px] ${
                  transferType === 'settings'
                    ? 'bg-[#0E7A3D]/40 border-[#2FD16F] text-white shadow-sm'
                    : 'bg-black/40 border-[#14502D] text-[#CDEBD8]/70 hover:text-white'
                }`}
              >
                <Key className="w-4 h-4 mb-1 text-[#2FD16F]" />
                <span className="text-xs font-medium block">Chaves & Dados</span>
                <span className="text-[10px] text-[#CDEBD8]/50 block">Backup no Banco</span>
              </button>
            </div>

            {/* Sub-inputs based on selected type */}
            <div className="pt-2">
              {transferType === 'model3d' && (
                <div className="space-y-2">
                  <label className="text-[11px] text-[#CDEBD8]/70 block">
                    Escolha o Modelo 3D da sua biblioteca local:
                  </label>
                  {localModels.length === 0 ? (
                    <p className="text-xs text-[#CDEBD8]/50 italic bg-black/40 p-3 rounded-xl border border-[#14502D]">
                      Nenhum modelo customizado na biblioteca ainda.
                    </p>
                  ) : (
                    <select
                      value={selectedModelId}
                      onChange={(e) => setSelectedModelId(e.target.value)}
                      className="w-full px-3 py-2 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] font-mono min-h-[44px]"
                    >
                      {localModels.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} ({(m.sizeBytes / 1024).toFixed(0)} KB)
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              )}

              {(transferType === 'image' || transferType === 'file') && (
                <div className="space-y-2">
                  <label className="text-[11px] text-[#CDEBD8]/70 block">
                    Selecione o arquivo do seu aparelho:
                  </label>
                  <input
                    type="file"
                    accept={transferType === 'image' ? 'image/*' : '*/*'}
                    onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                    className="w-full text-xs text-[#CDEBD8] file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border file:border-[#0E7A3D] file:text-xs file:font-medium file:bg-[#0E7A3D]/30 file:text-[#2FD16F] hover:file:bg-[#0E7A3D]/50 cursor-pointer min-h-[44px]"
                  />
                  {selectedFile && (
                    <p className="text-[11px] text-[#2FD16F] font-mono">
                      Selecionado: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(0)} KB)
                    </p>
                  )}
                </div>
              )}

              {transferType === 'settings' && (
                <div className="p-3 bg-black/40 border border-[#14502D] rounded-xl text-xs text-[#CDEBD8] space-y-1">
                  <p className="font-semibold text-[#2FD16F]">Upload de Configurações para o Firestore:</p>
                  <p className="text-[11px] text-[#CDEBD8]/70">
                    Envia com segurança suas chaves (Gemini, Groq) para o banco do sistema, permitindo restaurá-las no outro aparelho com o mesmo login do proprietário.
                  </p>
                </div>
              )}
            </div>

            {/* Target device & Upload button */}
            <div className="pt-2 border-t border-[#14502D]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <span className="text-[11px] text-[#CDEBD8]/70">Destino:</span>
                <select
                  value={targetDevice}
                  onChange={(e) => setTargetDevice(e.target.value)}
                  className="px-2.5 py-1.5 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none font-mono min-h-[40px]"
                >
                  <option value="Todos">Todos os Aparelhos</option>
                  {onlineDevices.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleUploadAndSend}
                disabled={isUploading}
                className="px-5 py-2.5 bg-[#0E7A3D] hover:bg-[#17B35A] disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all shadow-md cursor-pointer min-h-[44px]"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{isUploading ? 'Enviando ao Firestore...' : 'Fazer Upload & Transmitir'}</span>
              </button>
            </div>

            {uploadSuccess && (
              <div className="p-2.5 rounded-xl bg-green-950/50 border border-green-800 text-xs text-green-300 flex items-center space-x-2 animate-fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{uploadSuccess}</span>
              </div>
            )}
          </div>

          {/* Incoming Queue from Firestore */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-semibold text-white flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-[#2FD16F]" />
                <span>Arquivos Recebidos da Ponte (Em Tempo Real)</span>
              </span>
              <span className="text-[10px] text-[#CDEBD8]/50 font-mono">
                {incomingTransfers.length} {incomingTransfers.length === 1 ? 'item' : 'itens'}
              </span>
            </h3>

            {incomingTransfers.length === 0 ? (
              <div className="text-center py-6 border border-dashed border-[#14502D] rounded-xl text-[#CDEBD8]/50 text-xs">
                Nenhum arquivo recebido de outro aparelho recentemente.
              </div>
            ) : (
              <div className="space-y-2">
                {incomingTransfers.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-black/60 border border-[#14502D] rounded-xl flex items-center justify-between"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center space-x-2">
                        {item.type === 'model3d' && <Box className="w-3.5 h-3.5 text-[#2FD16F]" />}
                        {item.type === 'image' && <ImageIcon className="w-3.5 h-3.5 text-[#2FD16F]" />}
                        {item.type === 'file' && <FileText className="w-3.5 h-3.5 text-[#2FD16F]" />}
                        <span className="text-xs font-medium text-white">{item.name}</span>
                      </div>
                      <span className="text-[10px] text-[#CDEBD8]/50 font-mono block">
                        De {item.senderDevice} • {(item.sizeBytes / 1024).toFixed(0)} KB •{' '}
                        {new Date(item.createdAt).toLocaleTimeString('pt-BR')}
                      </span>
                    </div>

                    <div>
                      {item.type === 'model3d' ? (
                        <button
                          onClick={() => handleSaveReceivedModel(item)}
                          disabled={savingTransferId === item.id || item.status === 'completed'}
                          className="px-3 py-1.5 bg-[#0E7A3D]/40 hover:bg-[#0E7A3D] border border-[#2FD16F] rounded-lg text-xs text-white font-medium flex items-center space-x-1.5 transition-colors disabled:opacity-40 min-h-[40px]"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>
                            {item.status === 'completed'
                              ? 'Já Salvo'
                              : savingTransferId === item.id
                              ? 'Salvando...'
                              : 'Salvar na Biblioteca'}
                          </span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleDownloadReceivedFile(item)}
                          className="px-3 py-1.5 bg-black/60 hover:bg-[#14502D] border border-[#14502D] rounded-lg text-xs text-white font-medium flex items-center space-x-1.5 transition-colors min-h-[40px]"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Baixar</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#14502D]/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-black/60 hover:bg-[#14502D]/40 border border-[#14502D] text-xs text-[#CDEBD8] rounded-xl transition-colors min-h-[44px]"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
