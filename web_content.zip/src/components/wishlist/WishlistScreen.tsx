import React from 'react';
import { ArrowLeft, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../../types';

interface WishlistScreenProps {
  wishlistProducts: Product[];
  onBack: () => void;
  onRemoveFromWishlist: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  onSelectProduct: (product: Product) => void;
  onStartShopping: () => void;
}

export const WishlistScreen: React.FC<WishlistScreenProps> = ({
  wishlistProducts,
  onBack,
  onRemoveFromWishlist,
  onAddToCart,
  onSelectProduct,
  onStartShopping,
}) => {
  return (
    <div className="w-full min-h-screen bg-slate-50/70 pb-24 flex flex-col">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#EAEAEA] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
              My Wishlist ({wishlistProducts.length})
            </h1>
            <p className="text-[10px] text-slate-500 font-medium">
              Items saved for later
            </p>
          </div>
        </div>

        {wishlistProducts.length > 0 && (
          <button
            onClick={onStartShopping}
            className="text-xs font-bold text-[#000000] hover:underline cursor-pointer"
          >
            Add More
          </button>
        )}
      </div>

      <div className="max-w-4xl mx-auto w-full px-4 py-4 flex-1">
        {wishlistProducts.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-20 text-center max-w-sm mx-auto">
            <div className="w-20 h-20 rounded-full bg-[#FAFAFA] text-[#000000] flex items-center justify-center mb-4">
              <Heart className="w-10 h-10 stroke-[1.5]" />
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
              Your Wishlist is Empty
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Save your favorite footwear, backpacks, watches, and accessories to track price drops and order anytime!
            </p>
            <button
              onClick={onStartShopping}
              className="mt-6 px-6 py-3 rounded-2xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs shadow-md shadow-black/10 cursor-pointer transition-colors"
            >
              Explore Trending Products
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {wishlistProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl sm:rounded-3xl border border-slate-200/90 p-2.5 sm:p-3 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div
                    onClick={() => onSelectProduct(product)}
                    className="relative w-full aspect-square rounded-xl bg-[#FAFAFA] overflow-hidden flex items-center justify-center cursor-pointer group"
                  >
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover object-center group-hover:scale-106 transition-transform duration-300"
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveFromWishlist(product);
                      }}
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/95 text-[#000000] hover:bg-[#FAFAFA] flex items-center justify-center shadow-xs cursor-pointer transition-colors"
                      aria-label="Remove from wishlist"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="mt-2.5">
                    <h3
                      onClick={() => onSelectProduct(product)}
                      className="text-xs sm:text-sm font-bold text-slate-900 hover:text-[#000000] line-clamp-1 cursor-pointer"
                    >
                      {product.name}
                    </h3>
                    <div className="flex items-baseline gap-1.5 mt-1">
                      <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                        ₹{product.price.toLocaleString()}
                      </span>
                      {product.originalPrice > product.price && (
                        <span className="text-[10px] text-slate-400 line-through">
                          ₹{product.originalPrice}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <button
                  onClick={(e) => onAddToCart(product, e)}
                  className="mt-3 w-full py-2 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Move to Cart</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
