import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  onSelectProduct: (product: Product) => void;
  onContinueShopping: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveFromWishlist,
  onAddToCart,
  onSelectProduct,
  onContinueShopping,
}) => {
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        <div className="p-4 sm:p-5 border-b border-[#EAEAEA] flex items-center justify-between bg-white sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#000000] fill-[#000000]" />
            <h2 className="text-base font-bold text-slate-900">{t('myWishlist')}</h2>
            <span className="text-xs bg-[#EAEAEA] text-[#111111] font-bold px-2 py-0.5 rounded-full">
              {wishlistProducts.length} {t('items')}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={t('close')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-slate-100">
          {wishlistProducts.length === 0 ? (
            <div className="py-16 text-center">
              <div className="w-16 h-16 rounded-full bg-[#FAFAFA] text-[#000000] flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-1">{t('emptyWishlist')}</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto mb-6">
                {t('emptyWishlistDesc')}
              </p>
              <button
                onClick={() => {
                  onClose();
                  onContinueShopping();
                }}
                className="px-6 py-2.5 rounded-full bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs shadow-md transition-colors cursor-pointer"
              >
                {t('exploreProducts')}
              </button>
            </div>
          ) : (
            wishlistProducts.map((prod) => (
              <div
                key={prod.id}
                className="py-3.5 flex items-center gap-3 group"
              >
                <img
                  src={prod.images[0]}
                  alt={prod.name}
                  onClick={() => {
                    onSelectProduct(prod);
                    onClose();
                  }}
                  className="w-16 h-16 rounded-xl object-cover bg-[#FAFAFA] border border-[#EAEAEA] cursor-pointer flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4
                    onClick={() => {
                      onSelectProduct(prod);
                      onClose();
                    }}
                    className="text-xs font-bold text-slate-900 truncate hover:text-[#000000] cursor-pointer"
                  >
                    {prod.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs font-extrabold text-[#000000]">
                      ₹{prod.price.toLocaleString()}
                    </span>
                    {prod.discount > 0 && (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1 rounded">
                        {prod.discount}% {t('off')}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={(e) => {
                      onAddToCart(prod, e);
                      onRemoveFromWishlist(prod);
                    }}
                    className="px-2.5 py-1.5 bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#000000] rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{t('moveToCart')}</span>
                  </button>
                  <button
                    onClick={() => onRemoveFromWishlist(prod)}
                    className="p-1.5 text-slate-400 hover:text-[#000000] transition-colors cursor-pointer"
                    aria-label={t('delete')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
