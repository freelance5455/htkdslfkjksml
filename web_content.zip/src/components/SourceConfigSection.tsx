import { useRef, useState } from 'react';
import {
  Code2,
  FileCode2,
  Globe,
  Loader2,
  Plus,
  Trash2,
  Upload,
} from 'lucide-react';
import type {
  ApkBuildConfig,
  HtmlAssetFile,
  SourceMode,
  UrlInspectionResult,
} from '../types/apk';
import {
  HTML_STARTER_TEMPLATES,
  decodeBase64Utf8,
  encodeUtf8Base64,
  templateToAssetFiles,
} from '../lib/templates';

interface SourceConfigSectionProps {
  config: ApkBuildConfig;
  inspection: UrlInspectionResult | null;
  inspecting: boolean;
  inspectError: string | null;
  onChange: (patch: Partial<ApkBuildConfig>) => void;
  onInspectUrl: () => void;
}

function guessMimeType(filename: string): string {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'text/html';
  if (lower.endsWith('.css')) return 'text/css';
  if (lower.endsWith('.js') || lower.endsWith('.mjs')) return 'text/javascript';
  if (lower.endsWith('.json')) return 'application/json';
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  return 'application/octet-stream';
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
    reader.onload = () => {
      const result = String(reader.result);
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.readAsDataURL(file);
  });
}

const STORE_SNIPPET_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Coin & Store App</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, sans-serif; }
    body { background: #0f172a; color: #f8fafc; padding: 20px; display: flex; flex-direction: column; gap: 16px; min-height: 100vh; }
    .wallet { background: #1e293b; border-radius: 14px; padding: 16px; display: flex; justify-content: space-between; align-items: center; }
    .bal { font-size: 24px; font-weight: 700; color: #4ade80; font-variant-numeric: tabular-nums; }
    .item { background: #1e293b; border-radius: 12px; padding: 14px; display: flex; justify-content: space-between; align-items: center; }
    button { border: 0; background: #16a34a; color: #fff; padding: 9px 14px; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    button.sec { background: #334155; }
    footer { margin-top: auto; display: flex; justify-content: space-between; font-size: 12px; color: #94a3b8; }
    a { color: #94a3b8; }
  </style>
</head>
<body>
  <div class="wallet">
    <div>
      <div style="font-size:12px;color:#94a3b8;">Balance</div>
      <div class="bal"><span id="coins">100</span> Coins</div>
    </div>
    <button class="sec" onclick="window.AndroidNative?.removeAds()">Remove Ads</button>
  </div>
  <div class="item">
    <div>
      <div style="font-weight:600;">500 Gold Coins</div>
      <div style="font-size:12px;color:#94a3b8;">Consumable Pack</div>
    </div>
    <button onclick="buyPack('coins_500', 500)">$0.99</button>
  </div>
  <div class="item">
    <div>
      <div style="font-weight:600;">2,500 Gold Coins</div>
      <div style="font-size:12px;color:#94a3b8;">Best Value Pack</div>
    </div>
    <button onclick="buyPack('coins_2500', 2500)">$3.99</button>
  </div>
  <footer>
    <a href="developer.html">Developer & Socials</a>
    <span id="msg">Ready</span>
  </footer>
  <script>
    let coins = Number(localStorage.getItem('coins') || 100);
    const coinsEl = document.getElementById('coins');
    const msgEl = document.getElementById('msg');
    coinsEl.textContent = coins;
    function buyPack(sku, amt) {
      if (window.AndroidNative) {
        window.AndroidNative.purchase(sku, 'inapp');
        msgEl.textContent = 'Opening Google Play...';
      } else {
        coins += amt;
        localStorage.setItem('coins', coins);
        coinsEl.textContent = coins;
        msgEl.textContent = '+' + amt + ' Coins added (Preview)';
      }
    }
    window.addEventListener('android:currencyGranted', (e) => {
      msgEl.textContent = 'Purchased ' + e.detail.sku;
    });
  </script>
</body>
</html>`;

export function SourceConfigSection({
  config,
  inspection,
  inspecting,
  inspectError,
  onChange,
  onInspectUrl,
}: SourceConfigSectionProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFilePath, setSelectedFilePath] = useState<string>(
    config.htmlEntryFile || 'index.html'
  );
  const [dragOver, setDragOver] = useState(false);

  const activeFile =
    config.htmlFiles.find((f) => f.path === selectedFilePath) ||
    config.htmlFiles[0] ||
    null;

  const isTextEditable =
    activeFile &&
    (activeFile.mimeType.startsWith('text/') ||
      activeFile.mimeType.includes('javascript') ||
      activeFile.mimeType.includes('json') ||
      activeFile.mimeType.includes('svg'));

  const handleFilesAdded = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const incoming: HtmlAssetFile[] = [];
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const base64 = await fileToBase64(file);
      const cleanName = file.name.replace(/^\/+/, '');
      incoming.push({
        path: cleanName,
        contentBase64: base64,
        mimeType: file.type || guessMimeType(cleanName),
        size: file.size,
      });
    }

    const merged = new Map<string, HtmlAssetFile>();
    for (const existing of config.htmlFiles) {
      merged.set(existing.path, existing);
    }
    for (const item of incoming) {
      merged.set(item.path, item);
    }
    const nextFiles = Array.from(merged.values());
    const htmlCandidate =
      nextFiles.find((f) => f.path.toLowerCase() === 'index.html')?.path ||
      nextFiles.find((f) => f.path.toLowerCase().endsWith('.html'))?.path ||
      config.htmlEntryFile;

    onChange({
      htmlFiles: nextFiles,
      htmlEntryFile: htmlCandidate,
    });
    if (incoming[0]) {
      setSelectedFilePath(incoming[0].path);
    }
  };

  const handleLoadTemplate = (templateId: string) => {
    const tpl = HTML_STARTER_TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    const files = templateToAssetFiles(tpl);
    onChange({
      sourceMode: 'html',
      htmlFiles: files,
      htmlEntryFile: tpl.entryFile,
      appName: tpl.name,
      packageId: tpl.packageId,
      themeColor: tpl.themeColor,
    });
    setSelectedFilePath(tpl.entryFile);
  };

  const handleAddBlankFile = () => {
    let idx = 1;
    let candidate = 'page.html';
    while (config.htmlFiles.some((f) => f.path === candidate)) {
      idx += 1;
      candidate = `page-${idx}.html`;
    }
    const content = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${config.appName}</title>
</head>
<body style="font-family: system-ui, sans-serif; padding: 24px;">
  <h1>${config.appName}</h1>
  <p>Edit this HTML file directly in Web2APK Studio.</p>
</body>
</html>`;
    const encoded = encodeUtf8Base64(content);
    const nextFile: HtmlAssetFile = {
      path: candidate,
      contentBase64: encoded,
      mimeType: 'text/html',
      size: content.length,
    };
    onChange({
      htmlFiles: [...config.htmlFiles, nextFile],
    });
    setSelectedFilePath(candidate);
  };

  const handleUpdateActiveFileContent = (newCode: string) => {
    if (!activeFile) return;
    const encoded = encodeUtf8Base64(newCode);
    const nextFiles = config.htmlFiles.map((f) =>
      f.path === activeFile.path
        ? { ...f, contentBase64: encoded, size: new TextEncoder().encode(newCode).length }
        : f
    );
    onChange({ htmlFiles: nextFiles });
  };

  const handleDeleteFile = (pathToRemove: string) => {
    const nextFiles = config.htmlFiles.filter((f) => f.path !== pathToRemove);
    const nextEntry =
      config.htmlEntryFile === pathToRemove
        ? nextFiles.find((f) => f.path.toLowerCase().endsWith('.html'))?.path || ''
        : config.htmlEntryFile;
    onChange({
      htmlFiles: nextFiles,
      htmlEntryFile: nextEntry,
    });
    if (selectedFilePath === pathToRemove && nextFiles[0]) {
      setSelectedFilePath(nextFiles[0].path);
    }
  };

  return (
    <div className="space-y-6">
      {/* 3-Mode Source Switcher */}
      <div>
        <label className="block text-xs font-medium text-slate-700 mb-2">
          Input Source Mode
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {(
            [
              {
                mode: 'url' as SourceMode,
                title: 'Website URL',
                desc: 'Wrap any live web app inside an Android WebView APK.',
                icon: Globe,
              },
              {
                mode: 'code' as SourceMode,
                title: 'Paste HTML Code',
                desc: 'Write or paste raw HTML/CSS/JS directly and compile straight to APK.',
                icon: Code2,
              },
              {
                mode: 'html' as SourceMode,
                title: 'HTML File Bundle',
                desc: 'Upload multi-file HTML, CSS, JS, and images for offline execution.',
                icon: FileCode2,
              },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            const active = config.sourceMode === item.mode;
            return (
              <button
                key={item.mode}
                type="button"
                onClick={() => onChange({ sourceMode: item.mode })}
                className={`text-left p-3.5 rounded-xl border transition-colors ${
                  active
                    ? 'border-emerald-600 bg-emerald-50/40'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      active ? 'text-emerald-700' : 'text-slate-500'
                    }`}
                  />
                  <span className="text-xs font-display font-semibold text-slate-900">
                    {item.title}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">
                  {item.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {config.sourceMode === 'url' && (
        <div className="space-y-4">
          <div>
            <label
              htmlFor="website-url-input"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Target Website URL
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                id="website-url-input"
                type="url"
                value={config.websiteUrl}
                onChange={(e) => onChange({ websiteUrl: e.target.value })}
                placeholder="https://example.com"
                className="flex-1 px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
              />
              <button
                type="button"
                onClick={onInspectUrl}
                disabled={inspecting}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-slate-900 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200/70 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
              >
                {inspecting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Inspecting
                  </>
                ) : (
                  'Inspect URL'
                )}
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-1.5">
              Inspecting fetches the page title, theme color, favicon, and embedding headers to prefill your Android manifest.
            </p>
          </div>

          {inspectError && (
            <div className="p-3.5 rounded-lg border border-red-200 bg-red-50 text-xs text-red-700">
              {inspectError}
            </div>
          )}

          {inspection && (
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-2">
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm font-medium text-slate-900 truncate">
                  {inspection.title}
                </span>
                <span className="text-xs font-mono tabular-nums text-slate-500 shrink-0">
                  HTTP {inspection.statusCode} · {inspection.isHttps ? 'HTTPS' : 'HTTP'}
                </span>
              </div>
              {inspection.description && (
                <p className="text-xs text-slate-600 line-clamp-2">
                  {inspection.description}
                </p>
              )}
              <div className="text-xs text-slate-500 font-mono flex flex-wrap items-center gap-x-2 gap-y-1">
                <span>Suggested Package: {inspection.suggestedPackageId}</span>
                {inspection.themeColor && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>Theme: {inspection.themeColor}</span>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {config.sourceMode === 'code' && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-xs text-slate-600">
              Compiles directly into <code className="font-mono">assets/index.html</code> · Works 100% offline
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onChange({ rawHtmlCode: STORE_SNIPPET_HTML })}
                className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200/70 transition-colors whitespace-nowrap"
              >
                Insert Store & Coins Demo
              </button>
              <button
                type="button"
                onClick={() =>
                  onChange({
                    rawHtmlCode: `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${config.appName}</title>\n</head>\n<body style="font-family:system-ui,sans-serif;padding:24px;">\n  <h1>${config.appName}</h1>\n  <p>Built straight from HTML code.</p>\n</body>\n</html>`,
                  })
                }
                className="px-2.5 py-1 text-xs font-medium text-slate-600 border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap"
              >
                Reset Boilerplate
              </button>
            </div>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-3.5 py-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs font-mono text-slate-600">
              <span>index.html</span>
              <span className="tabular-nums">
                {new TextEncoder().encode(config.rawHtmlCode).length} bytes
              </span>
            </div>
            <textarea
              value={config.rawHtmlCode}
              onChange={(e) => onChange({ rawHtmlCode: e.target.value })}
              spellCheck={false}
              rows={16}
              placeholder="Paste your complete <!DOCTYPE html>...</html> code here..."
              className="w-full p-4 font-mono text-xs leading-relaxed bg-slate-900 text-slate-100 focus:outline-none resize-y"
            />
          </div>
        </div>
      )}

      {config.sourceMode === 'html' && (
        <div className="space-y-5">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              void handleFilesAdded(e.dataTransfer.files);
            }}
            className={`p-5 rounded-xl border border-dashed transition-colors text-center ${
              dragOver
                ? 'border-emerald-600 bg-emerald-50/50'
                : 'border-slate-300 bg-slate-50/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".html,.htm,.css,.js,.mjs,.json,.svg,.png,.jpg,.jpeg,.webp"
              onChange={(e) => void handleFilesAdded(e.target.files)}
              className="hidden"
            />
            <Upload className="w-5 h-5 text-slate-500 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-900">
              Drop HTML, CSS, JS, or image files here
            </p>
            <p className="text-xs text-slate-500 mt-1">
              All files are bundled inside <code className="font-mono">assets/</code> for offline execution.
            </p>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
              >
                Choose Files
              </button>
              <button
                type="button"
                onClick={handleAddBlankFile}
                className="inline-flex items-center gap-1 px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                New HTML File
              </button>
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-700 mb-2">
              Load Offline Starter Template
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {HTML_STARTER_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => handleLoadTemplate(tpl.id)}
                  className="text-left p-3 rounded-lg border border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/70 transition-colors"
                >
                  <div className="text-xs font-semibold text-slate-900">
                    {tpl.name}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                    {tpl.summary}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {config.htmlFiles.length > 0 && (
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
              <div className="px-3.5 py-2.5 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                  {config.htmlFiles.map((file) => {
                    const isSelected = activeFile?.path === file.path;
                    const isEntry = config.htmlEntryFile === file.path;
                    return (
                      <div
                        key={file.path}
                        className={`inline-flex items-center rounded-md border text-xs ${
                          isSelected
                            ? 'bg-white border-slate-300 text-slate-900 font-medium'
                            : 'bg-transparent border-transparent text-slate-600 hover:bg-slate-200/50'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setSelectedFilePath(file.path)}
                          className="px-2.5 py-1 font-mono whitespace-nowrap"
                        >
                          {file.path}
                          {isEntry ? ' (Entry)' : ''}
                        </button>
                        {config.htmlFiles.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteFile(file.path)}
                            title={`Remove ${file.path}`}
                            className="pr-2 text-slate-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <label
                    htmlFor="entry-file-select"
                    className="text-[11px] text-slate-500"
                  >
                    Launch file:
                  </label>
                  <select
                    id="entry-file-select"
                    value={config.htmlEntryFile}
                    onChange={(e) => onChange({ htmlEntryFile: e.target.value })}
                    className="text-xs font-mono bg-white border border-slate-200 rounded-md px-2 py-1 text-slate-800"
                  >
                    {config.htmlFiles
                      .filter(
                        (f) =>
                          f.path.toLowerCase().endsWith('.html') ||
                          f.path.toLowerCase().endsWith('.htm')
                      )
                      .map((f) => (
                        <option key={f.path} value={f.path}>
                          {f.path}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {activeFile && isTextEditable ? (
                <textarea
                  value={decodeBase64Utf8(activeFile.contentBase64)}
                  onChange={(e) => handleUpdateActiveFileContent(e.target.value)}
                  spellCheck={false}
                  rows={14}
                  className="w-full p-4 font-mono text-xs leading-relaxed bg-slate-900 text-slate-100 focus:outline-none resize-y"
                />
              ) : activeFile ? (
                <div className="p-6 text-xs text-slate-600 font-mono">
                  Binary asset: {activeFile.path} ({(activeFile.size / 1024).toFixed(1)} KB)
                </div>
              ) : null}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
