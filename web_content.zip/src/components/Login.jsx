import React,{useState} from "react";
import {LockKeyhole,Mail,ShieldCheck,X} from "lucide-react";
import {useApp} from "../context/AppContext";
export default function Login(){
 const {setLoggedIn}=useApp(); const [u,setU]=useState(""); const [p,setP]=useState(""); const [forgot,setForgot]=useState(false); const [email,setEmail]=useState(""); const [toast,setToast]=useState("");
 function login(e){e.preventDefault(); if(u.trim() && p.trim()){setLoggedIn(true)} else setToast("Enter your username and password.");}
 return <div className="min-h-screen flex items-center justify-center p-6 bg-[radial-gradient(circle_at_top,#12365a,#07111f_60%)]">
  <div className="glass glow w-full max-w-md rounded-3xl p-8">
   <div className="flex items-center gap-3 mb-8"><div className="p-3 rounded-2xl bg-cyan-400/10"><ShieldCheck/></div><div><h1 className="text-2xl font-black">VLOGGER BHAU STUDIO</h1><p className="text-xs text-slate-400">Proprietary Local AI Production Suite</p></div></div>
   <form onSubmit={login} className="space-y-4">
    <input value={u} onChange={e=>setU(e.target.value)} autoComplete="username" placeholder="Username" className="w-full rounded-xl bg-black/20 border border-white/10 p-3 outline-none focus:border-cyan-400"/>
    <input value={p} onChange={e=>setP(e.target.value)} type="password" autoComplete="current-password" placeholder="Password" className="w-full rounded-xl bg-black/20 border border-white/10 p-3 outline-none focus:border-cyan-400"/>
    <button className="w-full rounded-xl bg-cyan-400 text-slate-950 font-bold p-3"><LockKeyhole className="inline mr-2" size={18}/>Secure Login</button>
   </form>
   <button onClick={()=>setForgot(true)} className="text-sm text-cyan-300 mt-5">Forgot Password?</button>
   {toast && <p className="text-sm text-amber-300 mt-4">{toast}</p>}
  </div>
  {forgot&&<div className="fixed inset-0 bg-black/70 flex items-center justify-center p-5">
    <div className="glass rounded-2xl p-6 w-full max-w-md"><div className="flex justify-between"><h2 className="font-bold">Password Recovery</h2><button onClick={()=>setForgot(false)}><X/></button></div>
    <p className="text-sm text-slate-400 mt-2">Enter the registered email.</p><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Registered email" type="email" className="w-full mt-4 rounded-xl bg-black/20 border border-white/10 p-3"/>
    <button onClick={()=>{setToast("A password reset link has been sent to your registered email ID");setForgot(false)}} className="w-full mt-4 rounded-xl bg-cyan-400 text-slate-950 font-bold p-3"><Mail className="inline mr-2" size={18}/>Send Reset Link</button></div>
  </div>}
 </div>
}