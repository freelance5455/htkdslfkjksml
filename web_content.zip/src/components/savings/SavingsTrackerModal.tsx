import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import { SavingsGoal } from '../../types';
import confetti from 'canvas-confetti';
import {
  PiggyBank,
  Plus,
  X,
  TrendingUp,
  TrendingDown,
  Trash2,
  Trophy,
  Calendar,
  Check
} from 'lucide-react';

export const SavingsTrackerModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    savingsGoals,
    addSavingsGoal,
    updateGoalSavings,
    deleteSavingsGoal,
    totalSavings,
    language,
    t
  } = useKhata();

  const [showAddGoal, setShowAddGoal] = useState(false);
  const [selectedGoalForAction, setSelectedGoalForAction] = useState<SavingsGoal | null>(null);
  const [actionType, setActionType] = useState<'deposit' | 'withdraw'>('deposit');
  const [actionAmount, setActionAmount] = useState('');
  const [actionNote, setActionNote] = useState('');

  // Add goal form state
  const [newTitle, setNewTitle] = useState('');
  const [newTarget, setNewTarget] = useState('');
  const [newDeadline, setNewDeadline] = useState('');

  if (activeModal !== 'savings-modal') return null;

  const handleActionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoalForAction) return;
    const amt = parseFloat(actionAmount);
    if (!amt || amt <= 0) return;

    updateGoalSavings(selectedGoalForAction.id, amt, actionType, actionNote);

    // If reached 100% after deposit, trigger confetti!
    if (actionType === 'deposit' && selectedGoalForAction.currentAmount + amt >= selectedGoalForAction.targetAmount) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }

    setSelectedGoalForAction(null);
    setActionAmount('');
    setActionNote('');
  };

  const handleAddGoalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(newTarget);
    if (!newTitle.trim() || !target || target <= 0) return;

    addSavingsGoal({
      titleHi: newTitle.trim(),
      titleEn: newTitle.trim(),
      targetAmount: target,
      deadline: newDeadline || undefined,
      icon: 'PiggyBank',
      color: '#15803d'
    });

    setShowAddGoal(false);
    setNewTitle('');
    setNewTarget('');
    setNewDeadline('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-2">
            <PiggyBank className="w-5 h-5 text-emerald-700" />
            <h3 className="text-base font-bold text-slate-900">{t.savingsGoalsTitle}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Total Savings Card */}
          <div className="bg-gradient-to-r from-emerald-800 to-teal-700 p-4 rounded-2xl text-white shadow-md flex items-center justify-between">
            <div>
              <span className="text-emerald-100 text-xs font-semibold">{t.totalSavings}</span>
              <div className="text-2xl sm:text-3xl font-extrabold tabular-nums">
                {formatRupee(totalSavings)}
              </div>
            </div>
            <button
              onClick={() => setShowAddGoal(true)}
              className="px-3 py-2 bg-white/20 hover:bg-white/30 rounded-xl text-xs font-bold transition flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addNewGoal}</span>
            </button>
          </div>

          {/* Goal List */}
          <div className="space-y-3">
            {savingsGoals.map(goal => {
              const percent = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
              const isCompleted = percent >= 100;

              return (
                <div
                  key={goal.id}
                  className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">
                          {language === 'hi' ? goal.titleHi : goal.titleEn}
                        </h4>
                        {isCompleted && (
                          <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                            <Trophy className="w-3 h-3 text-amber-600" /> पूरा हुआ!
                          </span>
                        )}
                      </div>
                      {goal.deadline && (
                        <span className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3" />
                          लक्ष्य तिथि: {formatIndianDate(goal.deadline, language)}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        if (window.confirm('क्या आप इस बचत लक्ष्य को हटाना चाहते हैं?')) {
                          deleteSavingsGoal(goal.id);
                        }
                      }}
                      className="text-slate-300 hover:text-rose-600 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Progress Bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1 tabular-nums">
                      <span className="text-emerald-700">{formatRupee(goal.currentAmount)}</span>
                      <span className="text-slate-400">लक्ष्य: {formatRupee(goal.targetAmount)} ({percent}%)</span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>

                  {/* Deposit / Withdraw Action Buttons */}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => {
                        setSelectedGoalForAction(goal);
                        setActionType('withdraw');
                      }}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1"
                    >
                      <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
                      <span>{t.withdrawMoney}</span>
                    </button>
                    <button
                      onClick={() => {
                        setSelectedGoalForAction(goal);
                        setActionType('deposit');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1 shadow-xs"
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>{t.addDeposit}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* ADD GOAL SUB-FORM */}
          {showAddGoal && (
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-emerald-900">{t.addNewGoal}</h4>
                <button onClick={() => setShowAddGoal(false)} className="text-slate-400">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddGoalSubmit} className="space-y-2.5">
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="लक्ष्य का नाम (उदा. नया लैपटॉप, बच्चों की पढ़ाई...)"
                  className="w-full px-3 py-2 text-xs border rounded-xl bg-white"
                  autoFocus
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    required
                    value={newTarget}
                    onChange={e => setNewTarget(e.target.value)}
                    placeholder="लक्ष्य राशि (₹ 50,000)"
                    className="w-full px-3 py-2 text-xs border rounded-xl bg-white font-mono"
                  />
                  <input
                    type="date"
                    value={newDeadline}
                    onChange={e => setNewDeadline(e.target.value)}
                    className="w-full px-3 py-2 text-xs border rounded-xl bg-white"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs"
                >
                  {t.save}
                </button>
              </form>
            </div>
          )}

          {/* ACTION MODAL (DEPOSIT / WITHDRAW) */}
          {selectedGoalForAction && (
            <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/60 p-4">
              <div className="w-full max-w-xs rounded-2xl bg-white p-5 shadow-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">
                    {actionType === 'deposit' ? t.addDeposit : t.withdrawMoney}
                  </h4>
                  <button onClick={() => setSelectedGoalForAction(null)} className="text-slate-400">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-slate-500">
                  {selectedGoalForAction.titleHi || selectedGoalForAction.titleEn}
                </p>

                <form onSubmit={handleActionSubmit} className="space-y-3">
                  <input
                    type="number"
                    required
                    value={actionAmount}
                    onChange={e => setActionAmount(e.target.value)}
                    placeholder="₹ राशि"
                    className="w-full px-3 py-2 text-xl font-bold border rounded-xl font-mono text-center"
                    autoFocus
                  />
                  <input
                    type="text"
                    value={actionNote}
                    onChange={e => setActionNote(e.target.value)}
                    placeholder="विवरण (उदा. दीपावली बोनस)"
                    className="w-full px-3 py-2 text-xs border rounded-xl"
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl"
                  >
                    {t.save}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
