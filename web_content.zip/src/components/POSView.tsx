import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, Layers, Search, Tag } from 'lucide-react';
import { fmtQty, getCategoryTemplate } from '../categoryTemplates';
import type { Product, Sale, SaleItem, StoreData } from '../types';
import { findProductByBarcodeOrSku, fmtMoney, uid } from '../utils';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { Icon } from './Icon';
import { CustomSelect, Modal, SmartComboField } from './SharedUI';

interface POSViewProps {
  data: StoreData;
  t: Record<string, string>;
  onCompleteSale: (sale: Sale) => void;
  onQuickCreateProduct: (prod: Product, recordStockIn: boolean) => void;
  onTouchRecentCategory: (categoryName: string) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

const roundQty = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);
const isFractionalUnit = (unit?: string) => ['kg', 'g', 'l', 'ml', 'meter'].includes((unit || '').toLowerCase());

export const POSView: React.FC<POSViewProps> = ({
  data,
  t,
  onCompleteSale,
  onQuickCreateProduct,
  onTouchRecentCategory,
  notify,
}) => {
  const [searchMode, setSearchMode] = useState<'product' | 'category'>('product');
  const [query, setQuery] = useState('');
  const [catQuery, setCatQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');
  const [selectedSubCat, setSelectedSubCat] = useState('all');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [amountDrafts, setAmountDrafts] = useState<Record<string, string>>({});
  const [customerId, setCustomerId] = useState(data.settings.defaultCustomerId || 'walk-in');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [discount, setDiscount] = useState('');
  const [paidAmount, setPaidAmount] = useState('');
  const [scannerOpen, setScannerOpen] = useState(false);

  // Quick-add modal if user scans a new barcode not yet in inventory
  const [missingBarcode, setMissingBarcode] = useState<string | null>(null);
  const [qpName, setQpName] = useState('');
  const [qpCat, setQpCat] = useState(data.categories[0]?.name || 'Mobile & Gadgets');
  const [qpSubCat, setQpSubCat] = useState('');
  const [qpBrand, setQpBrand] = useState('');
  const [qpModel, setQpModel] = useState('');
  const [qpUnit, setQpUnit] = useState('pcs');
  const [qpPurchase, setQpPurchase] = useState('');
  const [qpSelling, setQpSelling] = useState('');
  const [qpQty, setQpQty] = useState('10');

  const searchRef = useRef<HTMLInputElement>(null);
  const catSearchRef = useRef<HTMLInputElement>(null);
  const qpNameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const defId = data.settings.defaultCustomerId || 'walk-in';
    if (data.customers.some((c) => c.id === defId)) {
      setCustomerId(defId);
    }
  }, [data.settings.defaultCustomerId, data.customers]);

  const qpTemplate = useMemo(() => getCategoryTemplate(qpCat, data.categories), [qpCat, data.categories]);
  const qpModelSuggestions = useMemo(() => {
    const brandModels = qpBrand && qpTemplate.modelsByBrand?.[qpBrand] ? qpTemplate.modelsByBrand[qpBrand] : [];
    return Array.from(new Set([...brandModels, ...qpTemplate.genericModels]));
  }, [qpBrand, qpTemplate]);

  // Keep most-recently-used/searched categories at the very front across POS visits
  const orderedCategories = useMemo(() => {
    const recent = data.recentCategories || [];
    const rankMap = new Map<string, number>();
    recent.forEach((name, idx) => rankMap.set(name.toLowerCase(), idx));

    return [...data.categories].sort((a, b) => {
      const ra = rankMap.get(a.name.toLowerCase());
      const rb = rankMap.get(b.name.toLowerCase());
      if (ra !== undefined && rb !== undefined) return ra - rb;
      if (ra !== undefined) return -1;
      if (rb !== undefined) return 1;
      return 0;
    });
  }, [data.categories, data.recentCategories]);

  // Filter visible category chips dynamically as user types into Category Search
  const visibleCategories = useMemo(() => {
    const cq = catQuery.trim().toLowerCase();
    if (!cq) return orderedCategories;
    return orderedCategories.filter((c) => c.name.toLowerCase().includes(cq));
  }, [orderedCategories, catQuery]);

  // Sub-categories & Brands present in products of selectedCat (for multi-step POS filtering e.g. Back Cover -> Samsung)
  const categoryProducts = useMemo(
    () => (selectedCat === 'all' ? data.products : data.products.filter((p) => p.category === selectedCat)),
    [data.products, selectedCat]
  );

  const subCatFilters = useMemo(() => {
    if (selectedCat === 'all') return [];
    const set = new Set<string>();
    categoryProducts.forEach((p) => {
      if (p.subCategory?.trim()) set.add(p.subCategory.trim());
    });
    return Array.from(set);
  }, [categoryProducts, selectedCat]);

  const brandFilters = useMemo(() => {
    if (selectedCat === 'all') return [];
    const set = new Set<string>();
    categoryProducts.forEach((p) => {
      if (selectedSubCat !== 'all' && p.subCategory !== selectedSubCat) return;
      if (p.brand?.trim()) set.add(p.brand.trim());
    });
    return Array.from(set);
  }, [categoryProducts, selectedCat, selectedSubCat]);

  const handleSelectCategory = useCallback(
    (catName: string) => {
      setSelectedCat(catName);
      setSelectedSubCat('all');
      setSelectedBrand('all');
      if (catName !== 'all') {
        onTouchRecentCategory(catName);
      }
    },
    [onTouchRecentCategory]
  );

  const handleModeSwitch = (mode: 'product' | 'category') => {
    setSearchMode(mode);
    setTimeout(() => {
      if (mode === 'product') searchRef.current?.focus();
      else catSearchRef.current?.focus();
    }, 40);
  };

  const handleCategorySearchChange = (val: string) => {
    setCatQuery(val);
    const cq = val.trim().toLowerCase();
    if (!cq) return;
    if (selectedCat !== 'all' && !selectedCat.toLowerCase().includes(cq)) {
      setSelectedCat('all');
      setSelectedSubCat('all');
      setSelectedBrand('all');
    }
  };

  const handleCategorySearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && catQuery.trim()) {
      e.preventDefault();
      if (visibleCategories.length > 0) {
        handleSelectCategory(visibleCategories[0].name);
        setCatQuery('');
      }
    }
  };

  const filteredProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    const cq = catQuery.trim().toLowerCase();
    const matchingCatNames = cq ? new Set(visibleCategories.map((c) => c.name.toLowerCase())) : null;

    return data.products.filter((p) => {
      if (selectedCat !== 'all') {
        if (p.category !== selectedCat) return false;
      } else if (cq) {
        const prodCatLower = (p.category || '').toLowerCase();
        const subLower = (p.subCategory || '').toLowerCase();
        const brandLower = (p.brand || '').toLowerCase();
        const matchesCat =
          prodCatLower.includes(cq) ||
          subLower.includes(cq) ||
          brandLower.includes(cq) ||
          (matchingCatNames ? matchingCatNames.has(prodCatLower) : false);
        if (!matchesCat) return false;
      }

      if (selectedSubCat !== 'all' && (p.subCategory || '') !== selectedSubCat) return false;
      if (selectedBrand !== 'all' && (p.brand || '') !== selectedBrand) return false;

      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        (p.sku || '').toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q) ||
        (p.model || '').toLowerCase().includes(q) ||
        (p.brand || '').toLowerCase().includes(q) ||
        (p.subCategory || '').toLowerCase().includes(q) ||
        (p.variantSpec || '').toLowerCase().includes(q) ||
        (p.category || '').toLowerCase().includes(q)
      );
    });
  }, [query, catQuery, selectedCat, selectedSubCat, selectedBrand, visibleCategories, data.products]);

  const addToCart = useCallback(
    (product: Product, customStep?: number) => {
      if (product.quantity <= 0) {
        notify(`${product.name}: ${t.insufficientStock}`, 'error');
        return false;
      }
      const step = customStep ?? (isFractionalUnit(product.unit) && product.quantity < 1 ? product.quantity : 1);
      let added = true;
      setCart((prev) => {
        const existing = prev.find((i) => i.productId === product.id);
        if (existing) {
          const nextQty = roundQty(existing.qty + step);
          if (nextQty > product.quantity + 0.0001) {
            added = false;
            notify(t.cannotExceedStock, 'error');
            return prev;
          }
          return prev.map((i) => (i.productId === product.id ? { ...i, qty: nextQty } : i));
        }
        const initialQty = Math.min(product.quantity, step);
        return [
          ...prev,
          {
            productId: product.id,
            name: product.name,
            model: [product.brand, product.model].filter(Boolean).join(' · '),
            unit: product.unit || 'pcs',
            purchasePrice: product.purchasePrice,
            sellingPrice: product.sellingPrice,
            maxStock: product.quantity,
            qty: roundQty(initialQty),
          },
        ];
      });
      return added;
    },
    [notify, t]
  );

  const openQuickAddBarcode = useCallback(
    (code: string) => {
      const fallbackCat =
        selectedCat !== 'all' ? selectedCat : orderedCategories[0]?.name || data.categories[0]?.name || 'Mobile & Gadgets';
      const tmpl = getCategoryTemplate(fallbackCat, data.categories);
      setMissingBarcode(code);
      setQpName('');
      setQpCat(fallbackCat);
      setQpSubCat('');
      setQpBrand('');
      setQpModel('');
      setQpUnit(tmpl.defaultUnit);
      setQpPurchase('');
      setQpSelling('');
      setQpQty('10');
      setTimeout(() => qpNameRef.current?.focus(), 80);
    },
    [selectedCat, orderedCategories, data.categories]
  );

  const handleBarcodeDetected = useCallback(
    (rawCode: string) => {
      const clean = rawCode.trim();
      if (!clean) return;
      const matched = findProductByBarcodeOrSku(data.products, clean);
      if (matched) {
        onTouchRecentCategory(matched.category);
        setSelectedCat(matched.category);
        setSelectedSubCat('all');
        setSelectedBrand('all');
        setCatQuery('');
        setQuery('');
        if (addToCart(matched)) {
          notify(`${matched.name} (${matched.category}) · ${matched.barcode || matched.sku} (+1)`);
        }
      } else {
        setQuery(clean);
        openQuickAddBarcode(clean);
      }
    },
    [data.products, addToCart, notify, openQuickAddBarcode, onTouchRecentCategory]
  );

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && query.trim()) {
      const clean = query.trim();
      const matched = findProductByBarcodeOrSku(data.products, clean);
      if (matched) {
        e.preventDefault();
        onTouchRecentCategory(matched.category);
        if (addToCart(matched)) {
          notify(`${matched.name} (+1)`);
          setQuery('');
        }
      } else if (filteredProducts.length === 1) {
        e.preventDefault();
        onTouchRecentCategory(filteredProducts[0].category);
        if (addToCart(filteredProducts[0])) {
          notify(`${filteredProducts[0].name} (+1)`);
          setQuery('');
        }
      } else {
        e.preventDefault();
        openQuickAddBarcode(clean);
      }
    }
  };

  const handleQuickAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = (missingBarcode || '').trim();
    const resolvedName =
      qpName.trim() || [qpBrand.trim(), qpModel.trim(), qpSubCat.trim()].filter(Boolean).join(' ');
    const qtyNum = Math.max(0.01, roundQty(Number(qpQty || '1')));
    const resolvedCategory = qpCat.trim() || data.categories[0]?.name || 'General';
    if (!resolvedName || qpPurchase === '' || qpSelling === '') {
      notify(t.fillRequiredFields, 'error');
      return;
    }

    const newProd: Product = {
      id: uid(),
      name: resolvedName,
      sku: code ? `SKU-${code.slice(-6).toUpperCase()}` : `SKU-${Date.now().toString().slice(-5)}`,
      barcode: code,
      category: resolvedCategory,
      subCategory: qpSubCat.trim() || undefined,
      brand: qpBrand.trim() || undefined,
      model: qpModel.trim(),
      unit: qpUnit || 'pcs',
      purchasePrice: Math.max(0, Number(qpPurchase || 0)),
      sellingPrice: Math.max(0, Number(qpSelling || 0)),
      quantity: qtyNum,
      minStock: data.settings.defaultLowStockLimit ?? 5,
      supplier: '',
      notes: 'Quick-added during POS scan',
    };

    onQuickCreateProduct(newProd, true);
    setSelectedCat(resolvedCategory);
    setCatQuery('');
    addToCart(newProd);
    notify(`${newProd.name} (${resolvedCategory}) saved & added`);
    setMissingBarcode(null);
    setQuery('');
  };

  const updateCartQty = (productId: string, nextQtyRaw: number) => {
    const prod = data.products.find((p) => p.id === productId);
    const max = prod ? prod.quantity : 0;
    const nextQty = roundQty(nextQtyRaw);
    if (Number.isNaN(nextQty) || nextQty <= 0) {
      setCart((prev) => prev.filter((i) => i.productId !== productId));
      return;
    }
    if (nextQty > max + 0.0001) {
      notify(t.cannotExceedStock, 'error');
      return;
    }
    setCart((prev) => prev.map((i) => (i.productId === productId ? { ...i, qty: nextQty } : i)));
  };

  const applyAmountToQty = (item: SaleItem, takaVal: string) => {
    setAmountDrafts((prev) => ({ ...prev, [item.productId]: takaVal }));
    const num = Number(takaVal);
    if (!takaVal || Number.isNaN(num) || num <= 0 || item.sellingPrice <= 0) return;
    const calcQty = roundQty(num / item.sellingPrice);
    const prod = data.products.find((p) => p.id === item.productId);
    const max = prod ? prod.quantity : calcQty;
    if (calcQty > max) {
      notify(t.cannotExceedStock, 'error');
      return;
    }
    if (calcQty > 0) {
      setCart((prev) => prev.map((i) => (i.productId === item.productId ? { ...i, qty: calcQty } : i)));
    }
  };

  const subtotal = useMemo(() => cart.reduce((sum, i) => sum + i.sellingPrice * i.qty, 0), [cart]);
  const discountNum = Math.max(0, Math.min(subtotal, Number(discount || 0)));
  const grandTotal = Math.max(0, subtotal - discountNum);
  const paidNum = paidAmount === '' ? grandTotal : Math.max(0, Number(paidAmount || 0));
  const dueAmount = Math.max(0, grandTotal - paidNum);
  const changeReturn = Math.max(0, paidNum - grandTotal);

  const handleSubmitSale = () => {
    if (cart.length === 0) {
      notify(t.cartEmpty, 'error');
      return;
    }
    if (data.settings.allowCreditSales === false && dueAmount > 0) {
      notify(t.creditDisabledWarning, 'error');
      return;
    }
    const cust = data.customers.find((c) => c.id === customerId) || data.customers[0];
    const totalCost = cart.reduce((sum, i) => sum + i.purchasePrice * i.qty, 0);
    const profit = grandTotal - totalCost;
    const maxNum = data.sales.reduce(
      (m, s) => Math.max(m, parseInt((s.invoiceNo || '').replace(/\D/g, ''), 10) || 1000),
      1000
    );
    const saleObj: Sale = {
      id: uid(),
      invoiceNo: `INV-${maxNum + 1}`,
      date: new Date().toISOString(),
      customerId: cust.id,
      customerName: cust.name,
      paymentMethod,
      items: cart.map((i) => ({ ...i })),
      subtotal,
      discount: discountNum,
      grandTotal,
      paidAmount: Math.min(paidNum, grandTotal),
      tenderedAmount: paidNum,
      dueAmount,
      changeReturn,
      profit,
    };
    onCompleteSale(saleObj);
    setCart([]);
    setAmountDrafts({});
    setDiscount('');
    setPaidAmount('');
    setQuery('');
    searchRef.current?.focus();
  };

  const customerOptions = useMemo(
    () =>
      data.customers.map((c) => ({
        value: c.id,
        label: c.name,
        sublabel: c.phone && c.phone !== '-' ? c.phone : undefined,
      })),
    [data.customers]
  );

  const paymentOptions = useMemo(
    () => ['Cash', 'bKash', 'Nagad', 'Bank', 'Other'].map((m) => ({ value: m, label: t[m] || m })),
    [t]
  );

  const categoryOptions = useMemo(
    () =>
      orderedCategories.length > 0
        ? orderedCategories.map((c) => ({ value: c.name, label: c.name }))
        : [{ value: 'General', label: 'General' }],
    [orderedCategories]
  );

  const hasAnyFilter = selectedCat !== 'all' || selectedSubCat !== 'all' || selectedBrand !== 'all' || !!catQuery.trim() || !!query.trim();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-7 space-y-4">
        {/* Dual-Mode Search Switcher + Search Bars + Smart Category Chips */}
        <div className="surface-card p-4 space-y-3">
          {/* Dual-Mode Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="segmented-bar">
              <button
                type="button"
                onClick={() => handleModeSwitch('product')}
                className={`segmented-option inline-flex items-center gap-1.5 ${
                  searchMode === 'product' ? 'segmented-option-active !text-blue-700' : ''
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>Product Search</span>
              </button>
              <button
                type="button"
                onClick={() => handleModeSwitch('category')}
                className={`segmented-option inline-flex items-center gap-1.5 ${
                  searchMode === 'category' ? 'segmented-option-active !text-blue-700' : ''
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Category Search</span>
              </button>
            </div>

            {selectedCat !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold">
                <Check className="w-3.5 h-3.5" />
                <span>{selectedCat}</span>
                <button
                  type="button"
                  onClick={() => handleSelectCategory('all')}
                  className="ml-0.5 text-blue-500 hover:text-blue-900"
                  aria-label="Clear category filter"
                >
                  ×
                </button>
              </span>
            )}
          </div>

          {/* Search Bar matching active mode (with intelligent barcode scan always accessible) */}
          {searchMode === 'product' ? (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={searchRef}
                  type="text"
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={handleSearchKeyDown}
                  placeholder={t.posSearchPlaceholder}
                  className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm font-medium"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <Icon name="x" className="w-4 h-4" />
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setScannerOpen(true)}
                className="btn-dark px-3.5 py-2.5 text-xs sm:text-sm shrink-0"
                title={t.scanBarcode}
              >
                <Icon name="barcode" className="w-4 h-4 shrink-0" />
                <span>{t.scanBarcode}</span>
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-4 h-4 text-blue-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={catSearchRef}
                  type="text"
                  value={catQuery}
                  onChange={(e) => handleCategorySearchChange(e.target.value)}
                  onKeyDown={handleCategorySearchKeyDown}
                  placeholder={t.posCategorySearchPlaceholder}
                  className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-blue-200 bg-blue-50/30 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm font-medium"
                />
                {catQuery && (
                  <button
                    type="button"
                    onClick={() => setCatQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <Icon name="x" className="w-4 h-4" />
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setScannerOpen(true)}
                className="btn-dark px-3.5 py-2.5 text-xs sm:text-sm shrink-0"
                title={t.scanBarcode}
              >
                <Icon name="barcode" className="w-4 h-4 shrink-0" />
                <span>Scan</span>
              </button>
            </div>
          )}

          {/* Dynamic Category Chips (filtered by catQuery, ordered by most recently used/searched first) */}
          <div className="flex gap-2 overflow-x-auto pb-0.5 custom-scrollbar items-center">
            {!catQuery.trim() && (
              <button
                type="button"
                onClick={() => handleSelectCategory('all')}
                className={`option-chip ${selectedCat === 'all' ? 'option-chip-active' : ''}`}
              >
                {t.allCategories}
              </button>
            )}
            {visibleCategories.length === 0 ? (
              <span className="text-xs text-slate-400 py-1 px-1">No matching category for "{catQuery.trim()}"</span>
            ) : (
              visibleCategories.map((c) => {
                const count = data.products.filter((p) => p.category === c.name).length;
                const active = selectedCat === c.name;
                return (
                  <button
                    type="button"
                    key={c.id}
                    onClick={() => handleSelectCategory(c.name)}
                    className={`option-chip ${active ? 'option-chip-active !bg-blue-600 !border-blue-600' : ''}`}
                  >
                    {active && <Check className="w-3 h-3 stroke-[2.75]" />}
                    <span>{c.name}</span>
                    {count > 0 && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md tabular-nums ${
                          active ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {count}
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>

          {/* Sub-Category & Brand Drill-down Pills when a category has structured items */}
          {selectedCat !== 'all' && (subCatFilters.length > 0 || brandFilters.length > 0) && (
            <div className="pt-2 border-t border-slate-100 space-y-2">
              {subCatFilters.length > 0 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 custom-scrollbar">
                  <span className="text-[11px] font-bold text-slate-500 shrink-0">Type:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedSubCat('all');
                      setSelectedBrand('all');
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border whitespace-nowrap ${
                      selectedSubCat === 'all'
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}
                  >
                    All
                  </button>
                  {subCatFilters.map((sc) => (
                    <button
                      type="button"
                      key={sc}
                      onClick={() => {
                        setSelectedSubCat(sc);
                        setSelectedBrand('all');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border whitespace-nowrap ${
                        selectedSubCat === sc
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {sc}
                    </button>
                  ))}
                </div>
              )}

              {brandFilters.length > 0 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 custom-scrollbar">
                  <span className="text-[11px] font-bold text-slate-500 shrink-0">Brand:</span>
                  <button
                    type="button"
                    onClick={() => setSelectedBrand('all')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border whitespace-nowrap ${
                      selectedBrand === 'all'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}
                  >
                    All
                  </button>
                  {brandFilters.map((br) => (
                    <button
                      type="button"
                      key={br}
                      onClick={() => setSelectedBrand(br)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border whitespace-nowrap ${
                        selectedBrand === br
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {br}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Product Grid */}
        <div className="surface-card p-4 sm:p-5 min-h-[380px]">
          {hasAnyFilter && (
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100 text-xs">
              <div className="flex flex-wrap items-center gap-1.5 font-bold text-slate-700">
                <span>
                  {selectedCat !== 'all'
                    ? selectedCat
                    : catQuery.trim()
                    ? `Categories matching "${catQuery.trim()}"`
                    : 'Filtered Products'}
                </span>
                {selectedSubCat !== 'all' && <span className="text-slate-400">› {selectedSubCat}</span>}
                {selectedBrand !== 'all' && <span className="text-emerald-700">› {selectedBrand}</span>}
                <span className="text-blue-600 tabular-nums">({filteredProducts.length} items)</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedCat('all');
                  setSelectedSubCat('all');
                  setSelectedBrand('all');
                  setCatQuery('');
                  setQuery('');
                }}
                className="text-slate-500 hover:text-slate-900 font-semibold"
              >
                Clear Filters
              </button>
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center py-14 px-4 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
                <Icon name="search" className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-slate-500">{t.noMatchingProducts}</p>
              {query.trim() && (
                <button
                  type="button"
                  onClick={() => openQuickAddBarcode(query.trim())}
                  className="btn-primary px-4 py-2.5 text-xs"
                >
                  <Icon name="plus" className="w-4 h-4" />
                  <span>Add &amp; Sell "{query.trim()}"</span>
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredProducts.map((p) => {
                const inCartQty = cart.find((i) => i.productId === p.id)?.qty || 0;
                const unitLabel = p.unit && p.unit !== 'pcs' ? `/${p.unit}` : '';
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => {
                      onTouchRecentCategory(p.category);
                      addToCart(p);
                    }}
                    disabled={p.quantity <= 0}
                    className={`text-left p-4 rounded-xl border flex flex-col justify-between ${
                      p.quantity <= 0
                        ? 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed'
                        : inCartQty > 0
                        ? 'bg-blue-50/45 border-blue-400 shadow-[0_2px_8px_-2px_rgba(37,99,235,0.18)]'
                        : 'bg-white border-slate-200/90 hover:border-blue-400 hover:bg-slate-50/50 shadow-[0_1px_2px_rgba(15,23,42,0.04)]'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="font-bold text-slate-900 text-sm leading-snug">{p.name}</h5>
                        <span className="font-extrabold text-blue-600 text-sm shrink-0 tabular-nums">
                          {fmtMoney(p.sellingPrice)}
                          {unitLabel && <span className="text-[11px] font-semibold text-slate-500">{unitLabel}</span>}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        {p.category}
                        {p.subCategory ? ` · ${p.subCategory}` : ''}
                        {p.brand ? ` · ${p.brand}` : ''}
                        {p.model ? ` · ${p.model}` : ''}
                      </p>
                      <p className="text-[11px] font-mono text-slate-400 mt-0.5">
                        SKU: {p.sku || '-'} {p.barcode ? `· ${p.barcode}` : ''}
                      </p>
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                      <span className={`text-xs font-semibold tabular-nums ${p.quantity > 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {p.quantity > 0 ? `${t.inStock}: ${fmtQty(p.quantity, p.unit)}` : t.outOfStock}
                      </span>
                      <span className="text-xs font-bold text-blue-600 whitespace-nowrap">
                        {inCartQty > 0 ? `${fmtQty(inCartQty, p.unit)} in cart · +` : `+ ${t.addToCart}`}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Cart & Checkout Panel */}
      <div className="lg:col-span-5 lg:sticky lg:top-20">
        <div className="surface-card flex flex-col">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80 rounded-t-2xl">
            <div>
              <h3 className="font-bold text-slate-900">{t.cart}</h3>
              <p className="text-xs text-slate-500 tabular-nums">
                {cart.length} {cart.length === 1 ? 'item' : 'items'}
              </p>
            </div>
            {cart.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setCart([]);
                  setAmountDrafts({});
                }}
                className="text-xs font-semibold text-rose-600 hover:underline whitespace-nowrap"
              >
                {t.clearCart}
              </button>
            )}
          </div>

          <div className="p-4 space-y-2.5 max-h-80 overflow-y-auto custom-scrollbar border-b border-slate-100">
            {cart.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-8">{t.cartEmpty}</p>
            ) : (
              cart.map((item) => {
                const weighted = isFractionalUnit(item.unit);
                const step = weighted ? 0.25 : 1;
                return (
                  <div key={item.productId} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-slate-800 truncate">{item.name}</p>
                        <p className="text-xs text-slate-500 tabular-nums">
                          {fmtMoney(item.sellingPrice)}
                          {item.unit && item.unit !== 'pcs' ? `/${item.unit}` : ''} × {fmtQty(item.qty, item.unit)} ={' '}
                          <span className="font-bold text-slate-900">{fmtMoney(item.sellingPrice * item.qty)}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => updateCartQty(item.productId, item.qty - step)}
                          className="w-7 h-8 rounded-lg bg-white border border-slate-200 font-bold text-slate-700 hover:bg-slate-100"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          step="any"
                          min="0.01"
                          max={item.maxStock}
                          value={item.qty}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            if (!Number.isNaN(val)) updateCartQty(item.productId, val);
                          }}
                          className="w-16 text-center text-xs sm:text-sm font-bold border border-slate-200 rounded-lg py-1.5 bg-white tabular-nums"
                        />
                        <button
                          type="button"
                          onClick={() => updateCartQty(item.productId, item.qty + step)}
                          className="w-7 h-8 rounded-lg bg-white border border-slate-200 font-bold text-slate-700 hover:bg-slate-100"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Quick weight/amount calculator for kg, g, L, ml, meter items */}
                    {weighted && (
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-200/70">
                        <div className="flex gap-1">
                          {[0.25, 0.5, 1, 2].map((w) => (
                            <button
                              type="button"
                              key={w}
                              onClick={() => updateCartQty(item.productId, w)}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold border tabular-nums ${
                                Math.abs(item.qty - w) < 0.001
                                  ? 'bg-slate-900 text-white border-slate-900'
                                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {w} {item.unit}
                            </button>
                          ))}
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] font-semibold text-slate-500">By ৳:</span>
                          <input
                            type="number"
                            min="1"
                            step="any"
                            value={amountDrafts[item.productId] || ''}
                            onChange={(e) => applyAmountToQty(item, e.target.value)}
                            placeholder="Amount"
                            className="w-16 px-2 py-0.5 text-[11px] font-bold rounded-md border border-slate-200 bg-white tabular-nums outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          <div className="p-5 space-y-3.5 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.customer}</label>
                <CustomSelect value={customerId} onChange={setCustomerId} options={customerOptions} searchable />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.paymentMethod}</label>
                <CustomSelect value={paymentMethod} onChange={setPaymentMethod} options={paymentOptions} />
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100 tabular-nums">
              <div className="flex justify-between text-slate-600">
                <span>{t.subtotal}</span>
                <span className="font-semibold text-slate-900">{fmtMoney(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-600">{t.discount}</span>
                <input
                  type="number"
                  min="0"
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                  placeholder="0.00"
                  className="w-28 text-right rounded-lg border border-slate-200 px-2.5 py-1.5 text-sm font-semibold tabular-nums"
                />
              </div>
              <div className="flex justify-between text-base font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                <span>{t.grandTotal}</span>
                <span className="text-blue-600">{fmtMoney(grandTotal)}</span>
              </div>
              <div className="flex items-center justify-between gap-4 pt-1">
                <span className="text-slate-600 font-medium">{t.paidAmount}</span>
                <input
                  type="number"
                  min="0"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder={grandTotal.toFixed(2)}
                  className="w-32 text-right rounded-lg border border-slate-200 px-2.5 py-1.5 text-sm font-bold tabular-nums"
                />
              </div>
              {grandTotal > 0 && (
                <div className="flex flex-wrap gap-1.5 justify-end">
                  <button
                    type="button"
                    onClick={() => setPaidAmount(String(grandTotal))}
                    className="btn-secondary px-2.5 py-1 text-[11px]"
                  >
                    Exact
                  </button>
                  {[500, 1000, 2000].map((amt) => (
                    <button
                      type="button"
                      key={amt}
                      onClick={() => setPaidAmount(String(amt))}
                      className="btn-secondary px-2.5 py-1 text-[11px] tabular-nums"
                    >
                      ৳{amt}
                    </button>
                  ))}
                </div>
              )}
              {dueAmount > 0 && (
                <div className="flex justify-between text-rose-600 font-bold">
                  <span>{t.dueAmount}</span>
                  <span>{fmtMoney(dueAmount)}</span>
                </div>
              )}
              {data.settings.allowCreditSales === false && dueAmount > 0 && (
                <p className="text-[11px] font-semibold text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-2.5 py-1.5">
                  {t.creditDisabledWarning}
                </p>
              )}
              {changeReturn > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>{t.changeReturn}</span>
                  <span>{fmtMoney(changeReturn)}</span>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleSubmitSale}
              disabled={cart.length === 0}
              className="btn-primary w-full py-3.5 text-sm disabled:opacity-45 disabled:shadow-none disabled:cursor-not-allowed tabular-nums"
            >
              {t.completeSale} · {fmtMoney(grandTotal)}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Add New Barcode Product Modal right inside POS with Category Features */}
      <Modal
        open={missingBarcode !== null}
        onClose={() => setMissingBarcode(null)}
        title={t.quickCreateBarcodeTitle}
        maxWidth="max-w-lg"
      >
        <form noValidate onSubmit={handleQuickAddSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">{t.barcode}</label>
            <input
              value={missingBarcode || ''}
              onChange={(e) => setMissingBarcode(e.target.value)}
              className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-mono outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">{t.productName} *</label>
            <input
              ref={qpNameRef}
              value={qpName}
              onChange={(e) => setQpName(e.target.value)}
              placeholder="Enter product name..."
              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-semibold outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">{t.category}</label>
              <CustomSelect
                value={qpCat}
                onChange={(val) => {
                  setQpCat(val);
                  const tmpl = getCategoryTemplate(val, data.categories);
                  setQpUnit(tmpl.defaultUnit);
                  setQpSubCat('');
                  setQpBrand('');
                  setQpModel('');
                }}
                options={categoryOptions}
                searchable
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">{qpTemplate.subCategoryLabel}</label>
              <SmartComboField
                value={qpSubCat}
                onChange={setQpSubCat}
                suggestions={qpTemplate.subCategories}
                placeholder="Tap or type 2-3 letters..."
                quickChipsCount={3}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">{qpTemplate.brandLabel}</label>
              <SmartComboField
                value={qpBrand}
                onChange={(v) => {
                  setQpBrand(v);
                  setQpModel('');
                }}
                suggestions={qpTemplate.brands}
                placeholder="Tap or type..."
                quickChipsCount={3}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">{qpTemplate.modelLabel}</label>
              <SmartComboField
                value={qpModel}
                onChange={setQpModel}
                suggestions={qpModelSuggestions}
                placeholder="Tap or type..."
                quickChipsCount={3}
              />
            </div>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Unit</label>
              <CustomSelect
                value={qpUnit}
                onChange={setQpUnit}
                options={qpTemplate.units.map((u) => ({ value: u, label: u }))}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Cost *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={qpPurchase}
                onChange={(e) => setQpPurchase(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm tabular-nums outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Price *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={qpSelling}
                onChange={(e) => setQpSelling(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm tabular-nums outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Qty ({qpUnit}) *</label>
              <input
                type="number"
                step="any"
                min="0.01"
                value={qpQty}
                onChange={(e) => setQpQty(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm tabular-nums outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setMissingBarcode(null)} className="btn-secondary px-4 py-2 text-xs">
              {t.cancel}
            </button>
            <button type="submit" className="btn-primary px-4 py-2 text-xs">
              {t.saveAndAddToCart}
            </button>
          </div>
        </form>
      </Modal>

      <BarcodeScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onDetected={handleBarcodeDetected}
        title={`${t.scanBarcode} — ${t.nav_pos}`}
        t={t}
        products={data.products}
      />
    </div>
  );
};
