import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { motion, AnimatePresence } from 'motion/react';
import {
  PieChart as PieIcon,
  DollarSign,
  Zap,
  Radio,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  Coins,
  Smartphone,
  Layers,
  Info,
  CheckCircle2
} from 'lucide-react';
import { ImsiWalletBalances } from '../lib/imsiEngine';
import { currencyConverter, DisplayCurrency } from '../lib/currencyConverter';

interface GlobalAssetAllocationChartProps {
  wallet?: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
}

export interface AssetCategoryItem {
  id: string;
  name: string;
  category: 'CRYPTO' | 'CASH' | 'TELECOM' | 'RESERVE';
  valueUsd: number;
  valueNgn: number;
  percentage: number;
  color: string;
  gradientStart: string;
  gradientEnd: string;
  icon: string;
  sublabel: string;
  description: string;
}

export const GlobalAssetAllocationChart: React.FC<GlobalAssetAllocationChartProps> = ({
  wallet,
  onShowToast
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const [activeSlice, setActiveSlice] = useState<AssetCategoryItem | null>(null);
  const [viewMetric, setViewMetric] = useState<'USD' | 'NGN' | 'PERCENT'>('USD');
  const [selectedCurrency, setSelectedCurrency] = useState<DisplayCurrency>(() => currencyConverter.getCurrency());

  useEffect(() => {
    const unsub = currencyConverter.subscribe((curr) => {
      setSelectedCurrency(curr);
    });
    return () => unsub();
  }, []);

  // Compute allocation slices based on live wallet balances
  const allocationData = useMemo<AssetCategoryItem[]>(() => {
    const cashNgn = wallet?.cashNgn ?? 12500000;
    const btcSats = wallet?.bitcoinSats ?? 2500000; // 0.025 BTC
    const dataCreditsMb = wallet?.unusedDataMb ?? 85000; // 85 GB

    const btcUsd = (btcSats / 100000000) * 96420;
    const btcNgn = btcUsd * 1550;

    const cashUsd = cashNgn / 1550;
    
    // Telecom data value at ~₦1,200 per 1,000 MB ($0.77 / GB)
    const telecomNgn = (dataCreditsMb / 1000) * 1200;
    const telecomUsd = telecomNgn / 1550;

    // CONVERTO Sovereign token reserve (e.g. 50,000 CVT @ $0.45)
    const reserveUsd = 22500;
    const reserveNgn = reserveUsd * 1550;

    const totalUsd = btcUsd + cashUsd + telecomUsd + reserveUsd;

    const rawList: Omit<AssetCategoryItem, 'percentage'>[] = [
      {
        id: 'crypto',
        name: 'Bitcoin & Digital Assets',
        category: 'CRYPTO',
        valueUsd: btcUsd,
        valueNgn: btcNgn,
        color: '#f59e0b',
        gradientStart: '#fbbf24',
        gradientEnd: '#d97706',
        icon: '₿',
        sublabel: `${(btcSats / 100000000).toFixed(4)} BTC (${btcSats.toLocaleString()} Sats)`,
        description: 'Hard-cap sovereign proof-of-work vault reserve'
      },
      {
        id: 'cash',
        name: 'Liquid Cash & Banking',
        category: 'CASH',
        valueUsd: cashUsd,
        valueNgn: cashNgn,
        color: '#10b981',
        gradientStart: '#34d399',
        gradientEnd: '#059669',
        icon: '₦',
        sublabel: `₦${cashNgn.toLocaleString(undefined, { maximumFractionDigits: 0 })} NGN`,
        description: 'Instant NIBSS, SEPA & commercial bank clearing balance'
      },
      {
        id: 'telecom',
        name: 'Mobile Telecom Data Credit',
        category: 'TELECOM',
        valueUsd: telecomUsd,
        valueNgn: telecomNgn,
        color: '#38bdf8',
        gradientStart: '#60a5fa',
        gradientEnd: '#0284c7',
        icon: '📱',
        sublabel: `${(dataCreditsMb / 1000).toFixed(1)} GB Telecom Data Capacity`,
        description: 'Convertible carrier airtime, IMSI data & SMS revenue'
      },
      {
        id: 'reserve',
        name: 'CONVERTO Sovereign Reserve',
        category: 'RESERVE',
        valueUsd: reserveUsd,
        valueNgn: reserveNgn,
        color: '#a855f7',
        gradientStart: '#c084fc',
        gradientEnd: '#7e22ce',
        icon: '🛡️',
        sublabel: '50,000 CVT Protocol Staked Reserve',
        description: 'Algorithmic liquidity backstop & validator governance pool'
      }
    ];

    return rawList.map((item) => ({
      ...item,
      percentage: totalUsd > 0 ? (item.valueUsd / totalUsd) * 100 : 25
    }));
  }, [wallet]);

  const totalPortfolioUsd = allocationData.reduce((acc, item) => acc + item.valueUsd, 0);
  const totalPortfolioNgn = totalPortfolioUsd * 1550;

  // D3 Pie / Donut Chart Render
  useEffect(() => {
    if (!svgRef.current || !containerRef.current || allocationData.length === 0) return;

    const width = 340;
    const height = 340;
    const margin = 20;
    const radius = Math.min(width, height) / 2 - margin;
    const innerRadius = radius * 0.62; // Donut hole

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('width', '100%')
      .attr('height', '100%');

    // Defs for radial/linear gradients
    const defs = svg.append('defs');
    allocationData.forEach((d) => {
      const grad = defs
        .append('linearGradient')
        .attr('id', `grad-${d.id}`)
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '100%')
        .attr('y2', '100%');
      grad.append('stop').attr('offset', '0%').attr('stop-color', d.gradientStart);
      grad.append('stop').attr('offset', '100%').attr('stop-color', d.gradientEnd);
    });

    const g = svg
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    // D3 Pie Generator
    const pie = d3
      .pie<AssetCategoryItem>()
      .value((d) => d.valueUsd)
      .sort(null)
      .padAngle(0.035);

    // D3 Arc Generator
    const arc = d3
      .arc<d3.PieArcDatum<AssetCategoryItem>>()
      .innerRadius(innerRadius)
      .outerRadius(radius)
      .cornerRadius(8);

    // Hover Arc Generator (slightly expanded)
    const arcHover = d3
      .arc<d3.PieArcDatum<AssetCategoryItem>>()
      .innerRadius(innerRadius)
      .outerRadius(radius + 8)
      .cornerRadius(8);

    // Draw Slices
    const paths = g
      .selectAll('path')
      .data(pie(allocationData))
      .enter()
      .append('path')
      .attr('d', arc as any)
      .attr('fill', (d) => `url(#grad-${d.data.id})`)
      .attr('stroke', '#0f172a')
      .attr('stroke-width', 2.5)
      .style('cursor', 'pointer')
      .style('transition', 'all 0.25s ease')
      .on('mouseover', function (event, d) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', arcHover as any);
        setActiveSlice(d.data);
      })
      .on('mouseout', function () {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', arc as any);
      })
      .on('click', (event, d) => {
        setActiveSlice(d.data);
        onShowToast?.(`Selected ${d.data.name}: ${d.data.percentage.toFixed(1)}% of total portfolio`);
      });

    // Central Label Group
    const centerG = g.append('g').attr('text-anchor', 'middle');

    centerG
      .append('text')
      .attr('dy', '-0.5em')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .attr('fill', '#94a3b8')
      .attr('letter-spacing', '0.08em')
      .text('TOTAL PORTFOLIO');

    centerG
      .append('text')
      .attr('dy', '0.9em')
      .attr('font-size', '16px')
      .attr('font-weight', '900')
      .attr('fill', '#fbbf24')
      .attr('font-family', 'monospace')
      .text(`$${Math.round(totalPortfolioUsd).toLocaleString()}`);

    centerG
      .append('text')
      .attr('dy', '2.5em')
      .attr('font-size', '9px')
      .attr('font-weight', '600')
      .attr('fill', '#34d399')
      .text(`₦${(totalPortfolioNgn / 1000000).toFixed(2)}M NGN`);
  }, [allocationData, totalPortfolioUsd, totalPortfolioNgn]);

  const displaySlice = activeSlice || allocationData[0];

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <PieIcon className="w-4 h-4 text-amber-400" />
            <span>D3.JS GLOBAL ASSET ALLOCATION & LIQUIDITY MATRIX</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Multi-Asset Balance Distribution
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Interactive D3.js donut visualization mapping the live ratio of cryptocurrency holdings, liquid cash balances, and mobile telecom data credits.
          </p>
        </div>

        {/* View Metric Toggles */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['USD', 'NGN', 'PERCENT'] as const).map((metric) => (
            <button
              key={metric}
              onClick={() => setViewMetric(metric)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                viewMetric === metric
                  ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              {metric === 'USD' ? '$ USD' : metric === 'NGN' ? '₦ NGN' : '% Share'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* D3 Donut Chart Viewport */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center p-4 bg-slate-950/70 border border-amber-500/20 rounded-3xl relative">
          <div ref={containerRef} className="w-72 h-72 sm:w-80 sm:h-80 relative flex items-center justify-center">
            <svg ref={svgRef} className="w-full h-full select-none" />
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-2 text-center">
            Hover over arc segments to inspect detailed asset parameters
          </span>
        </div>

        {/* Breakdown Cards & Selected Slice Detail */}
        <div className="lg:col-span-7 space-y-4">
          {/* Active Highlight Card */}
          {displaySlice && (
            <div className="bg-slate-900/95 border-2 border-amber-500/40 rounded-2xl p-4 sm:p-5 space-y-3 shadow-xl">
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-2.5">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-black shadow-md"
                    style={{ background: displaySlice.color, color: '#0f172a' }}
                  >
                    {displaySlice.icon}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-amber-100">{displaySlice.name}</h3>
                    <p className="text-xs text-slate-400">{displaySlice.sublabel}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xl font-black text-amber-300 font-mono">
                    {displaySlice.percentage.toFixed(1)}%
                  </span>
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Of Net Portfolio</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                {displaySlice.description}
              </p>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">USD Valuation</span>
                  <span className="text-sm font-black text-amber-200 font-mono">
                    ${displaySlice.valueUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-[10px] text-slate-500 uppercase block font-mono">Local NGN Peg</span>
                  <span className="text-sm font-black text-emerald-300 font-mono">
                    ₦{displaySlice.valueNgn.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Allocation Slices Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {allocationData.map((item) => {
              const isSelected = displaySlice?.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSlice(item);
                    onShowToast?.(`Selected ${item.name}`);
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-amber-400 shadow-md ring-1 ring-amber-400'
                      : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <span
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ background: item.color }}
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-200 truncate max-w-[140px]">{item.name}</p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        {viewMetric === 'USD'
                          ? `$${Math.round(item.valueUsd).toLocaleString()}`
                          : viewMetric === 'NGN'
                          ? `₦${(item.valueNgn / 1000000).toFixed(2)}M`
                          : `${item.percentage.toFixed(1)}%`}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-black text-amber-300 font-mono ml-2">
                    {item.percentage.toFixed(1)}%
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Portfolio Health Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800">
        <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 uppercase block font-mono">Diversification Score</span>
          <span className="text-base font-black text-emerald-300 font-mono">96 / 100</span>
          <span className="text-[9px] text-emerald-400 block font-bold">Optimal Risk Spread</span>
        </div>

        <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 uppercase block font-mono">Instant Liquidity</span>
          <span className="text-base font-black text-cyan-300 font-mono">
            {((allocationData.find((a) => a.id === 'cash')?.percentage || 0) + (allocationData.find((a) => a.id === 'crypto')?.percentage || 0)).toFixed(0)}%
          </span>
          <span className="text-[9px] text-cyan-400 block font-bold">T+0 Real-Time Available</span>
        </div>

        <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 uppercase block font-mono">Dominant Asset</span>
          <span className="text-base font-black text-amber-300 font-mono">
            {allocationData.reduce((prev, curr) => (prev.percentage > curr.percentage ? prev : curr)).name.split(' ')[0]}
          </span>
          <span className="text-[9px] text-amber-400 block font-bold">Sovereign Proof-of-Work</span>
        </div>

        <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 uppercase block font-mono">Total Valuation Peg</span>
          <span className="text-base font-black text-amber-100 font-mono">
            ${totalPortfolioUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
          <span className="text-[9px] text-slate-400 block font-bold">Updated Live</span>
        </div>
      </div>
    </div>
  );
};
