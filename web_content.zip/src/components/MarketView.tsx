import React, { useState } from 'react';
import { Check, Store, X } from 'lucide-react';
import {
  ALL_HABITAT_IDS,
  OUTSIDE_PEN_CAPACITY,
  PUP_ADULT_AGE_SEC,
  formatDurationShort,
  formatLocationLabel,
} from '../data/kennelConstants';
import { estimateDogMarketValue } from '../engine/genetics';
import { isPup } from '../engine/simulation';
import { GameState, HabitatLocationId } from '../types/kennel';
import { DogPortrait } from './DogPortrait';

interface MarketViewProps {
  state: GameState;
  onAcceptListing: (listingId: string, dest: HabitatLocationId, customName?: string) => void;
  onRefuseListing: (listingId: string) => void;
  onSellOrRehome: (dogId: string) => void;
}

export const MarketView: React.FC<MarketViewProps> = ({
  state,
  onAcceptListing,
  onRefuseListing,
  onSellOrRehome,
}) => {
  const [placingId, setPlacingId] = useState<string | null>(null);
  const [customNames, setCustomNames] = useState<Record<string, string>>({});
  const [confirmRemoveId, setConfirmRemoveId] = useState<string | null>(null);

  const outsideCount = state.dogs.filter((d) => d.location === 'outside_pen').length;

  const availableDestinations = ALL_HABITAT_IDS.filter((id) => {
    if (id === 'nursery_pen') return false;
    if (id === 'outside_pen') return outsideCount < OUTSIDE_PEN_CAPACITY;
    return !state.dogs.some((d) => d.location === id);
  });

  return (
    <div className="space-y-8">
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#DFDBD0]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18]">
            Kennel Trade Market
          </h1>
          <p className="mt-1 text-sm text-[#5C584F]">
            3–6 randomized dingoes arrive every 8 minutes. Accept a trade into any open stall or refuse it to open the slot for another listing.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono-tabular text-[#5C584F]">
          <span>Credits: {state.kennelCredits}</span>
          <span aria-hidden="true">·</span>
          <span>Next rotation: {formatDurationShort(state.nextMarketRefreshSec)}</span>
        </div>
      </section>

      {/* Incoming Trade Listings */}
      <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {state.marketListings.map((listing) => {
          const dog = listing.dog;
          const pup = isPup(dog);
          const canAfford = state.kennelCredits >= listing.price;
          const isPlacing = placingId === listing.id;
          const skillAvg = Math.round(
            (dog.skills.foraging +
              dog.skills.tracking +
              dog.skills.agility +
              dog.skills.watchfulness +
              dog.skills.socialGrace) /
              5
          );

          return (
            <article
              key={listing.id}
              className="rounded-2xl bg-white border border-[#DFDBD0] p-4 flex flex-col justify-between gap-4"
            >
              <div className="space-y-3">
                <DogPortrait name={dog.name} genetics={dog.genetics} isPup={pup} compact />

                <div className="flex items-baseline justify-between gap-2">
                  <h2 className="font-display text-xl font-semibold text-[#1C1B18]">
                    {dog.name}
                  </h2>
                  <span className="font-mono-tabular text-sm font-semibold text-[#1F4E3D]">
                    {listing.price} cr
                  </span>
                </div>

                <p className="text-xs text-[#5C584F] capitalize">
                  {dog.gender} · {pup ? `Pup (${formatDurationShort(PUP_ADULT_AGE_SEC - dog.ageSeconds)} to adult)` : `Adult (${formatDurationShort(dog.ageSeconds)})`} · {dog.genetics.coat} · {dog.genetics.bodyType} ·{' '}
                  {pup ? `Patternless pup (${dog.genetics.pattern} at maturity)` : dog.genetics.pattern}
                </p>

                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-[#4A463E] font-mono-tabular bg-[#F7F5F0] rounded-xl p-2.5 border border-[#E5E1D6]">
                  <span>Health: {Math.round(dog.stats.health)}%</span>
                  <span>Skill avg: {skillAvg}%</span>
                  <span>Energy: {Math.round(dog.stats.energy)}%</span>
                  <span>Intelligence: {Math.round(dog.stats.intelligence)}%</span>
                  <span>Agility: {Math.round(dog.skills.agility)}%</span>
                  <span>Tracking: {Math.round(dog.skills.tracking)}%</span>
                </div>

                <p className="text-xs text-[#5C584F]">
                  Initial impression: {dog.traits.slice(0, 2).join(', ')} (full traits logged in Journal once observed).
                </p>
              </div>

              {!isPlacing ? (
                <div className="flex items-center gap-2 pt-2 border-t border-[#EFECE4]">
                  <button
                    type="button"
                    disabled={!canAfford || availableDestinations.length === 0}
                    onClick={() => setPlacingId(listing.id)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 py-2 text-xs font-semibold rounded-xl bg-[#1F4E3D] text-white hover:bg-[#173B2E] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>
                      {availableDestinations.length === 0
                        ? 'Kennel Full'
                        : canAfford
                        ? 'Accept & Place'
                        : 'Insufficient Credits'}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onRefuseListing(listing.id)}
                    className="inline-flex items-center justify-center gap-1 min-h-[44px] px-3 py-2 text-xs font-medium rounded-xl border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Refuse</span>
                  </button>
                </div>
              ) : (
                <div className="pt-3 border-t border-[#EFECE4] space-y-2.5">
                  <label className="block text-xs font-medium text-[#5C584F]">
                    Optional name before intake:
                    <input
                      type="text"
                      value={customNames[listing.id] ?? dog.name}
                      onChange={(e) =>
                        setCustomNames((prev) => ({ ...prev, [listing.id]: e.target.value }))
                      }
                      maxLength={24}
                      className="mt-1 w-full rounded-lg border border-[#D8D3C6] bg-[#F7F5F0] px-3 py-2 text-xs text-[#1C1B18] focus:outline-none focus:border-[#1F4E3D]"
                    />
                  </label>
                  <p className="text-xs font-medium text-[#5C584F]">Place into open box or pen:</p>
                  <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                    {availableDestinations.map((dest) => (
                      <button
                        key={dest}
                        type="button"
                        onClick={() => {
                          onAcceptListing(listing.id, dest, customNames[listing.id]);
                          setPlacingId(null);
                        }}
                        className="min-h-[36px] px-2.5 py-1 text-xs rounded-lg border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#1F4E3D] hover:text-white transition-colors cursor-pointer"
                      >
                        {formatLocationLabel(dest)}
                      </button>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => setPlacingId(null)}
                    className="text-xs text-[#5C584F] hover:underline cursor-pointer"
                  >
                    Cancel placement
                  </button>
                </div>
              )}
            </article>
          );
        })}
      </section>

      {/* Sell Pup / Rehome Adult Section */}
      <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-4">
        <div className="flex items-center gap-2">
          <Store className="w-4 h-4 text-[#1F4E3D]" aria-hidden="true" />
          <h2 className="font-display text-xl font-semibold text-[#1C1B18]">
            Sell Pups &amp; Rehome Adults
          </h2>
        </div>
        <p className="text-xs text-[#5C584F]">
          Pups can be sold to registered handlers; adults can be rehomed to partner kennels to free stalls.
        </p>

        {state.dogs.length === 0 ? (
          <p className="text-sm text-[#7A7467]">No dogs currently housed.</p>
        ) : (
          <div className="divide-y divide-[#EFECE4]">
            {state.dogs.map((dog) => {
              const pup = isPup(dog);
              const payout = pup
                ? Math.round(estimateDogMarketValue(dog) * 0.85)
                : Math.round(estimateDogMarketValue(dog) * 0.45);
              const confirming = confirmRemoveId === dog.id;

              return (
                <div
                  key={dog.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="font-semibold text-sm text-[#1C1B18]">
                      {dog.name}{' '}
                      <span className="font-normal text-xs text-[#5C584F] capitalize">
                        · {pup ? 'Pup' : 'Adult'} · {dog.gender} · {formatLocationLabel(dog.location)}
                      </span>
                    </div>
                    <div className="text-xs text-[#5C584F] capitalize mt-0.5">
                      {dog.genetics.coat} · {dog.genetics.bodyType} · {dog.genetics.pattern}
                    </div>
                  </div>

                  {!confirming ? (
                    <button
                      type="button"
                      onClick={() => setConfirmRemoveId(dog.id)}
                      className="min-h-[40px] px-3.5 py-2 text-xs font-semibold rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors self-start sm:self-auto cursor-pointer"
                    >
                      {pup ? `Sell Pup (+${payout} cr)` : `Rehome Adult (+${payout} cr)`}
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onSellOrRehome(dog.id);
                          setConfirmRemoveId(null);
                        }}
                        className="min-h-[40px] px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#9A5B13] text-white hover:bg-[#7D490E] cursor-pointer"
                      >
                        Confirm {pup ? 'Sale' : 'Rehome'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmRemoveId(null)}
                        className="min-h-[40px] px-3 py-2 text-xs rounded-lg border border-[#D8D3C6] text-[#5C584F] hover:bg-[#EFECE4] cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
