import React, { useState } from 'react';
import { MarketItem, UserProfile, ItemCategory } from '../types';
import { ShoppingBag, Sparkles, Check, Coins, Search, Ticket, ShieldCheck, Flame, Palette } from 'lucide-react';
import { playPurchaseSound, playErrorSound, playEquipSound } from '../utils/soundEffects';
import { triggerConfetti } from '../utils/confetti';

interface MarketViewProps {
  items: MarketItem[];
  user: UserProfile;
  onBuyItem: (item: MarketItem) => void;
  onEquipItem: (category: ItemCategory, itemIdOrValue: string) => void;
  onOpenCouponModal: () => void;
  soundEnabled: boolean;
}

export const MarketView: React.FC<MarketViewProps> = ({
  items,
  user,
  onBuyItem,
  onEquipItem,
  onOpenCouponModal,
  soundEnabled,
}) => {
  const [activeCategory, setActiveCategory] = useState<ItemCategory>('title');
  const [filterMode, setFilterMode] = useState<'all' | 'available' | 'owned'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewItem, setPreviewItem] = useState<MarketItem | null>(null);

  const categories: { key: ItemCategory; label: string; icon: string; count: number }[] = [
    { key: 'title', label: 'الألقاب', icon: '📜', count: items.filter((i) => i.category === 'title').length },
    { key: 'frame', label: 'الإطارات البصرية', icon: '🖼️', count: items.filter((i) => i.category === 'frame').length },
    { key: 'avatar', label: 'الأفاتارات', icon: '🎭', count: items.filter((i) => i.category === 'avatar').length },
    { key: 'theme', label: 'الثيمات', icon: '🎨', count: items.filter((i) => i.category === 'theme').length },
  ];

  const filteredItems = items
    .filter((item) => item.category === activeCategory)
    .filter((item) => {
      const isOwned = user.inventory.includes(item.id);
      if (filterMode === 'owned') return isOwned;
      if (filterMode === 'available') return !isOwned;
      return true;
    })
    .filter((item) => {
      if (!searchQuery.trim()) return true;
      return (
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    });

  const handlePurchase = (item: MarketItem) => {
    if (user.inventory.includes(item.id)) return;

    if (user.coins < item.price) {
      if (soundEnabled) playErrorSound();
      alert(`عذراً! رصيدك (${user.coins} نقطة) لا يكفي لشراء ${item.name} (${item.price} نقطة). يمكنك إنجاز مهام، جلسات بومودورو، أو استخدام كوبون هدية.`);
      return;
    }

    if (soundEnabled) playPurchaseSound();
    triggerConfetti();
    onBuyItem(item);

    // Prompt to equip right away
    const shouldEquip = confirm(`🎉 تهانينا! قمت بشراء «${item.name}» بنجاح!\n\nهل ترغب في تجهيزه وتفعيله فوراً على حسابك الآن؟`);
    if (shouldEquip) {
      if (soundEnabled) playEquipSound();
      if (item.category === 'title') onEquipItem('title', item.name);
      else if (item.category === 'frame') onEquipItem('frame', item.cssClass || item.id);
      else if (item.category === 'avatar') onEquipItem('avatar', item.customDrawing || item.icon || '🦅');
      else if (item.category === 'theme') onEquipItem('theme', item.id);
    }
  };

  const rarityBadges = {
    common: 'text-slate-400 bg-slate-800/80 border-slate-700',
    rare: 'text-blue-400 bg-blue-950/60 border-blue-500/40',
    epic: 'text-purple-400 bg-purple-950/60 border-purple-500/40',
    legendary: 'text-amber-400 bg-amber-950/60 border-amber-500/40',
  };

  const rarityLabels = {
    common: 'عادي',
    rare: 'نادر 💎',
    epic: 'ملحمي 🔮',
    legendary: 'أسطوري 👑',
  };

  return (
    <div className="py-3 px-2 max-w-2xl mx-auto">
      
      {/* Top Banner with Coins Balance & Redeem Coupon */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/30 mb-5 shadow-lg">
        <div className="text-right">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl sm:text-2xl font-black text-white">
              ماركت المقتنيات الحية (45+ عنصر)
            </h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            اشترِ الألقاب، الإطارات المتوهجة، الأفاتارات، والثيمات بنقاط إنجازك!
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-300 font-black text-sm">
            <Coins className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>رصيدك: {user.coins.toLocaleString('ar-EG')}</span>
          </div>

          <button
            onClick={onOpenCouponModal}
            className="py-1.5 px-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer transition-colors"
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>كود كوبون 🎟️</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => {
              setActiveCategory(cat.key);
              setPreviewItem(null);
            }}
            className={`py-2.5 px-3 rounded-2xl border text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeCategory === cat.key
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 border-indigo-400 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-300'
            }`}
          >
            <span className="text-base">{cat.icon}</span>
            <span>{cat.label}</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-950/60 text-slate-300">
              {cat.count}
            </span>
          </button>
        ))}
      </div>

      {/* Search and Ownership Filter */}
      <div className="flex flex-col sm:flex-row gap-2 mb-5">
        <div className="relative flex-1">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن مقتنى أو تأثير..."
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-3.5 py-2 pl-9 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-right"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        <div className="flex bg-slate-950/80 p-1 rounded-2xl border border-slate-800 shrink-0">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1 text-xs font-bold rounded-xl transition-all ${
              filterMode === 'all' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setFilterMode('available')}
            className={`px-3 py-1 text-xs font-bold rounded-xl transition-all ${
              filterMode === 'available' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            متاح للشراء
          </button>
          <button
            onClick={() => setFilterMode('owned')}
            className={`px-3 py-1 text-xs font-bold rounded-xl transition-all ${
              filterMode === 'owned' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            مملوك لدي
          </button>
        </div>
      </div>

      {/* Grid of Market Items */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredItems.map((item) => {
          const isOwned = user.inventory.includes(item.id);
          const rarity = item.rarity || 'rare';

          return (
            <div
              key={item.id}
              className={`relative p-4 rounded-3xl border transition-all duration-200 flex flex-col justify-between ${
                isOwned
                  ? 'bg-slate-900/40 border-slate-800/60'
                  : 'bg-slate-900/90 hover:bg-slate-900 border-slate-800 hover:border-indigo-500/40 shadow-sm'
              }`}
            >
              <div>
                {/* Header: Icon, Rarity & Name */}
                <div className="flex items-start justify-between gap-2 mb-2.5">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${rarityBadges[rarity]}`}>
                    {rarityLabels[rarity]}
                  </span>

                  {item.isCustom && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-black">
                      👑 حصري من المؤسس
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3 mb-2">
                  {/* Visual Preview / Icon */}
                  <div className="relative shrink-0">
                    {item.category === 'frame' ? (
                      <div
                        style={
                          item.customFrameConfig
                            ? {
                                borderWidth: `${item.customFrameConfig.borderWidth || 3}px`,
                                borderStyle: 'solid',
                                borderColor: item.customFrameConfig.borderColor1,
                                boxShadow: `0 0 20px ${item.customFrameConfig.glowColor}`,
                              }
                            : undefined
                        }
                        className={`w-12 h-12 rounded-full flex items-center justify-center bg-slate-950 text-xl shadow-md ${
                          item.customFrameConfig
                            ? item.customFrameConfig.animation === 'spin'
                              ? 'animate-spin'
                              : 'animate-pulse'
                            : item.cssClass || 'border-2 border-slate-700'
                        }`}
                      >
                        {user.avatar && user.avatar.startsWith('data:image/') ? (
                          <img src={user.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-contain" />
                        ) : (
                          user.avatar || '🦅'
                        )}
                      </div>
                    ) : item.category === 'theme' ? (
                      <div
                        style={
                          item.customThemePalette
                            ? {
                                backgroundColor: item.customThemePalette.bg,
                                borderColor: item.customThemePalette.border,
                              }
                            : undefined
                        }
                        className="w-12 h-12 rounded-2xl flex items-center justify-center border text-2xl shadow-md bg-gradient-to-tr from-slate-950 to-indigo-950 border-slate-700"
                      >
                        {item.icon || '🎨'}
                      </div>
                    ) : item.customDrawing ? (
                      <div className="w-12 h-12 rounded-2xl overflow-hidden bg-slate-950 border border-indigo-500/40 shadow-md flex items-center justify-center p-1">
                        <img src={item.customDrawing} alt={item.name} className="w-full h-full object-contain rounded-xl" />
                      </div>
                    ) : (
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-slate-950 border border-slate-800 text-2xl shadow-md">
                        {item.icon || '✨'}
                      </div>
                    )}
                  </div>

                  <div className="text-right flex-1 min-w-0">
                    <h3 className="text-sm font-black text-slate-100 truncate">
                      {item.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Price and Action Button */}
              <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-black text-amber-300">
                    {item.price === 0 ? 'مجاني' : `${item.price} نقطة`}
                  </span>
                </div>

                {isOwned ? (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                    <Check className="w-3.5 h-3.5" />
                    <span>تم الاقتناء ✓</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handlePurchase(item)}
                    className="py-1.5 px-4 rounded-xl font-bold text-xs bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20 transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>شراء الآن</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
