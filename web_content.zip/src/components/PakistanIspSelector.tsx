import React from 'react';
import { PAKISTAN_ISPS } from '../utils/pingTester';
import { Radio, Zap, Info, ShieldCheck, Check } from 'lucide-react';

interface PakistanIspSelectorProps {
  selectedIsp: string;
  onSelectIsp: (ispId: string) => void;
  language: 'en' | 'ur';
}

export const PakistanIspSelector: React.FC<PakistanIspSelectorProps> = ({
  selectedIsp,
  onSelectIsp,
  language,
}) => {
  return (
    <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">🇵🇰</span>
            <h3 className="text-base font-bold text-slate-100">
              {language === 'ur' ? 'پاکستان نیٹ ورک اور سم پرووائیڈر' : 'Pakistan Telecom & ISP Gaming Profiles'}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'فری فائر کے لیے جاز، زونگ، نیاٹیل اور پی ٹی سی ایل کے خصوصی ڈی این ایس سیٹنگز'
              : 'Select your Pakistan carrier/fiber for tuned MTU, APN routing & Free Fire low-latency profile'}
          </p>
        </div>
        <div className="text-xs text-slate-400 font-mono flex items-center gap-1.5 self-start sm:self-auto">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>PK-IXPN Peering Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {PAKISTAN_ISPS.map((isp) => {
          const isSelected = selectedIsp === isp.id;
          return (
            <button
              key={isp.id}
              onClick={() => onSelectIsp(isp.id)}
              className={`p-3.5 rounded-xl text-left border transition-all duration-200 relative flex flex-col justify-between ${
                isSelected
                  ? 'bg-amber-950/20 border-amber-500/60 shadow-lg shadow-amber-500/5 ring-1 ring-amber-500/30'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-sm text-slate-100">{isp.name}</span>
                    {isSelected && (
                      <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[11px] font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                      {isp.badge}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">MTU: {isp.mtu}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 font-mono flex items-center gap-1.5 truncate">
                <Info className="w-3 h-3 text-slate-500 shrink-0" />
                <span className="truncate">{isp.apnTip}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
