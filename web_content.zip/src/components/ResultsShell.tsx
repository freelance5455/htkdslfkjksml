import { Copy, Download, Hand, Languages, RefreshCw, Share2, Smartphone, Crosshair } from "lucide-react";
import { toast } from "sonner";
import { DevicePicker } from "@/components/DevicePicker";
import { SettingsView } from "@/components/SettingsView";
import { SpecsView } from "@/components/SpecsView";
import { TouchTestView } from "@/components/TouchTestView";
import { Button } from "@/components/ui/button";
import { formatSettingsText } from "@/lib/engine/calculate";
import { useCaliber, type Tab } from "@/lib/store";
import { cn } from "@/lib/utils";

export function ResultsShell() {
  const { dict, lang, tab, setTab, reset, toggleLang, hardware, settings } = useCaliber();

  const tabs: { id: Tab; label: string }[] = [
    { id: "specs", label: dict.specs },
    { id: "settings", label: dict.settings },
    { id: "touch", label: dict.touch },
  ];

  const text = hardware && settings ? formatSettingsText(hardware, settings, lang) : "";

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(dict.copied);
    } catch {
      toast.error(dict.unavailable);
    }
  };

  const onShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: dict.shareTitle, text });
        return;
      }
      await navigator.clipboard.writeText(text);
      toast.message(dict.noShare);
    } catch {
      try {
        await navigator.clipboard.writeText(text);
        toast.message(dict.noShare);
      } catch {
        toast.error(dict.unavailable);
      }
    }
  };

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pb-28 pt-4 sm:max-w-2xl">
      <header className="mb-4 flex items-center justify-between gap-2">
        <div>
          <div className="font-display text-sm font-semibold tracking-[0.22em] text-primary">CALIBER</div>
          <div className="text-[11px] text-muted">
            {hardware ? `${hardware.manufacturer} ${hardware.model}` : dict.app}
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={toggleLang} aria-label={dict.language}>
            <Languages className="size-4" />
            <span className="hidden sm:inline">{dict.language}</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={reset}>
            <RefreshCw className="size-4" />
            {dict.rescan}
          </Button>
        </div>
      </header>

      <div className="mb-4 grid grid-cols-3 gap-1 rounded-lg bg-surface p-1 shadow-[var(--shadow-border)]">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "flex h-10 items-center justify-center gap-1.5 rounded-md text-xs font-medium transition-colors duration-150",
              tab === t.id ? "bg-bg text-fg" : "text-muted hover:text-fg",
            )}
          >
            {t.id === "specs" ? <Smartphone className="size-3.5" /> : null}
            {t.id === "settings" ? <Crosshair className="size-3.5" /> : null}
            {t.id === "touch" ? <Hand className="size-3.5" /> : null}
            {t.label}
          </button>
        ))}
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <DevicePicker />
        <a
          href="/caliber-android.zip"
          download
          className="inline-flex h-11 items-center gap-2 rounded-md px-3 text-sm text-muted hover:text-fg"
        >
          <Download className="size-4" />
          {dict.downloadApk}
        </a>
      </div>

      {tab === "specs" ? <SpecsView /> : null}
      {tab === "settings" ? <SettingsView /> : null}
      {tab === "touch" ? <TouchTestView /> : null}

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 px-4 py-3 backdrop-blur-sm">
        <div className="mx-auto grid max-w-lg grid-cols-2 gap-2 sm:max-w-2xl">
          <Button onClick={() => void onCopy()} disabled={!text}>
            <Copy className="size-4" />
            {dict.copy}
          </Button>
          <Button variant="secondary" onClick={() => void onShare()} disabled={!text}>
            <Share2 className="size-4" />
            {dict.share}
          </Button>
        </div>
      </div>
    </div>
  );
}
