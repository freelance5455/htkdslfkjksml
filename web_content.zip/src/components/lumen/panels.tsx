import {
  Bell,
  Calendar as CalendarIcon,
  Check,
  ChevronLeft,
  Clock,
  ListTodo,
  Plus,
  StickyNote,
  Trash2,
  UserRound,
} from "lucide-react";
import { useMemo, useState } from "react";
import { formatWhen, msToClock } from "@/lib/assistant/dates";
import { convertUnits, evalMath } from "@/lib/assistant/math";
import type { ModuleId } from "@/lib/assistant/types";
import { exportPayload, useLumen } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const TITLES: Record<Exclude<ModuleId, "home">, string> = {
  talk: "Talk",
  tasks: "Tasks",
  notes: "Notes",
  reminders: "Reminders",
  calendar: "Calendar",
  timer: "Time",
  lists: "Lists",
  people: "People",
  drafts: "Drafts",
  focus: "Focus",
  calc: "Numbers",
  journal: "Journal",
  settings: "Settings",
};

export function ModuleFrame({
  module,
  onBack,
}: {
  module: Exclude<ModuleId, "home">;
  onBack: () => void;
}) {
  return (
    <section className="flex min-h-0 flex-1 flex-col">
      <header className="flex shrink-0 items-center gap-2 px-3 pt-3">
        <Button variant="ghost" size="icon" onClick={onBack} aria-label="Back">
          <ChevronLeft className="size-5" />
        </Button>
        <h2 className="font-display text-2xl tracking-tight">{TITLES[module]}</h2>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-3">
        {module === "talk" && <TalkPanel />}
        {module === "tasks" && <TasksPanel />}
        {module === "notes" && <NotesPanel />}
        {module === "reminders" && <RemindersPanel />}
        {module === "calendar" && <CalendarPanel />}
        {module === "timer" && <TimerPanel />}
        {module === "lists" && <ListsPanel />}
        {module === "people" && <PeoplePanel />}
        {module === "drafts" && <DraftsPanel />}
        {module === "focus" && <FocusPanel />}
        {module === "calc" && <CalcPanel />}
        {module === "journal" && <JournalPanel />}
        {module === "settings" && <SettingsPanel />}
      </div>
    </section>
  );
}

function FieldRow({
  onSubmit,
  placeholder,
}: {
  onSubmit: (v: string) => void;
  placeholder: string;
}) {
  const [v, setV] = useState("");
  return (
    <form
      className="mb-4 flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const t = v.trim();
        if (!t) return;
        onSubmit(t);
        setV("");
      }}
    >
      <Input value={v} onChange={(e) => setV(e.target.value)} placeholder={placeholder} />
      <Button type="submit" size="icon" aria-label="Add">
        <Plus className="size-4" />
      </Button>
    </form>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="py-10 text-center text-sm text-muted">{text}</p>;
}

function TalkPanel() {
  const messages = useLumen((s) => s.messages);
  if (!messages.length) return <Empty text="Nothing in the log yet. Speak from the dock below." />;
  return (
    <ol className="flex flex-col gap-3">
      {messages.map((m) => (
        <li
          key={m.id}
          className={cn(
            "max-w-[92%] rounded-xl px-3.5 py-2.5 text-sm leading-relaxed",
            m.role === "user"
              ? "ml-auto bg-primary text-primary-foreground"
              : "bg-card shadow-[var(--shadow-border)] text-foreground",
          )}
        >
          {m.text}
        </li>
      ))}
    </ol>
  );
}

function TasksPanel() {
  const tasks = useLumen((s) => s.tasks);
  const addTask = useLumen((s) => s.addTask);
  const toggleTask = useLumen((s) => s.toggleTask);
  const removeTask = useLumen((s) => s.removeTask);
  return (
    <>
      <FieldRow placeholder="Add a task" onSubmit={(t) => addTask(t, null)} />
      {!tasks.length ? (
        <Empty text="No tasks. Tell Lumen “add buy groceries”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {tasks.map((t) => (
            <li
              key={t.id}
              className="flex items-center gap-3 rounded-xl bg-card px-3 py-2.5 shadow-[var(--shadow-border)]"
            >
              <button
                type="button"
                onClick={() => toggleTask(t.id)}
                className={cn(
                  "flex size-7 shrink-0 items-center justify-center rounded-full shadow-[var(--shadow-border)]",
                  t.done ? "bg-success text-background" : "bg-card-2 text-muted",
                )}
                aria-label={t.done ? "Mark open" : "Mark done"}
              >
                <Check className="size-3.5" />
              </button>
              <div className="min-w-0 flex-1">
                <p className={cn("text-sm", t.done && "text-muted line-through")}>{t.title}</p>
                {t.dueAt ? <p className="text-xs text-muted">{formatWhen(t.dueAt)}</p> : null}
              </div>
              <button type="button" className="size-11 text-muted" onClick={() => removeTask(t.id)} aria-label="Delete">
                <Trash2 className="mx-auto size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function NotesPanel() {
  const notes = useLumen((s) => s.notes);
  const addNote = useLumen((s) => s.addNote);
  const removeNote = useLumen((s) => s.removeNote);
  const [body, setBody] = useState("");
  return (
    <>
      <form
        className="mb-4 flex flex-col gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const t = body.trim();
          if (!t) return;
          addNote(t.split(" ").slice(0, 6).join(" "), t);
          setBody("");
        }}
      >
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="A note to keep on this device" />
        <Button type="submit" className="self-end">
          Save note
        </Button>
      </form>
      {!notes.length ? (
        <Empty text="No notes yet. “Note the wifi is harbor-guest”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {notes.map((n) => (
            <li key={n.id} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
              <div className="flex items-start justify-between gap-2">
                <p className="font-medium">{n.title}</p>
                <button type="button" className="size-11 text-muted" onClick={() => removeNote(n.id)} aria-label="Delete">
                  <Trash2 className="mx-auto size-4" />
                </button>
              </div>
              <p className="mt-1 whitespace-pre-wrap text-sm text-muted">{n.body}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function RemindersPanel() {
  const reminders = useLumen((s) => s.reminders);
  const toggleReminder = useLumen((s) => s.toggleReminder);
  const addReminder = useLumen((s) => s.addReminder);
  const sorted = useMemo(() => [...reminders].sort((a, b) => a.at - b.at), [reminders]);
  return (
    <>
      <FieldRow
        placeholder="Title — uses +1 hour if no time"
        onSubmit={(t) => addReminder(t, Date.now() + 3_600_000)}
      />
      {!sorted.length ? (
        <Empty text="No reminders. “Remind me to stretch at 7pm”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {sorted.map((r) => (
            <li key={r.id} className="flex items-center gap-3 rounded-xl bg-card px-3 py-3 shadow-[var(--shadow-border)]">
              <Bell className="size-4 text-muted" />
              <div className="min-w-0 flex-1">
                <p className={cn("text-sm", r.done && "text-muted line-through")}>{r.title}</p>
                <p className="font-mono text-xs tabular-nums text-muted">{formatWhen(r.at)}</p>
              </div>
              <Button size="sm" variant={r.done ? "secondary" : "outline"} onClick={() => toggleReminder(r.id)}>
                {r.done ? "Open" : "Done"}
              </Button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function CalendarPanel() {
  const events = useLumen((s) => s.events);
  const addEvent = useLumen((s) => s.addEvent);
  const removeEvent = useLumen((s) => s.removeEvent);
  const sorted = useMemo(() => [...events].sort((a, b) => a.startAt - b.startAt), [events]);
  return (
    <>
      <FieldRow placeholder="New event in one hour" onSubmit={(t) => addEvent(t, Date.now() + 3_600_000, "")} />
      {!sorted.length ? (
        <Empty text="Calendar is empty. “Schedule dentist Friday at 3pm”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {sorted.map((e) => (
            <li key={e.id} className="flex items-start gap-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
              <CalendarIcon className="mt-0.5 size-4 text-muted" />
              <div className="min-w-0 flex-1">
                <p className="text-sm">{e.title}</p>
                <p className="font-mono text-xs tabular-nums text-muted">{formatWhen(e.startAt)}</p>
                {e.place ? <p className="text-xs text-muted">{e.place}</p> : null}
              </div>
              <button type="button" className="size-11 text-muted" onClick={() => removeEvent(e.id)} aria-label="Delete">
                <Trash2 className="mx-auto size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function TimerPanel() {
  const timers = useLumen((s) => s.timers);
  const alarms = useLumen((s) => s.alarms);
  const now = useLumen((s) => s.now);
  const startTimer = useLumen((s) => s.startTimer);
  const pauseTimer = useLumen((s) => s.pauseTimer);
  const resumeTimer = useLumen((s) => s.resumeTimer);
  const cancelTimers = useLumen((s) => s.cancelTimers);
  const addAlarm = useLumen((s) => s.addAlarm);
  const toggleAlarm = useLumen((s) => s.toggleAlarm);
  const live = timers.filter((t) => t.status !== "done");
  const [alarm, setAlarm] = useState("07:00");
  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Timers</p>
        <div className="mb-3 flex flex-wrap gap-2">
          {[1, 5, 10, 25].map((m) => (
            <Button key={m} variant="secondary" size="sm" onClick={() => startTimer(m * 60_000, `${m} min`)}>
              {m} min
            </Button>
          ))}
          <Button variant="outline" size="sm" onClick={cancelTimers}>
            Clear
          </Button>
        </div>
        {!live.length ? (
          <p className="text-sm text-muted">No running timer.</p>
        ) : (
          live.map((t) => {
            const left = t.status === "running" ? t.endsAt - now : t.remainingMs;
            return (
              <div key={t.id} className="mb-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
                <p className="font-mono text-3xl tabular-nums tracking-tight">{msToClock(left)}</p>
                <p className="mt-1 text-sm text-muted">{t.label}</p>
                <div className="mt-3 flex gap-2">
                  {t.status === "running" ? (
                    <Button size="sm" variant="secondary" onClick={() => pauseTimer(t.id)}>
                      Pause
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => resumeTimer(t.id)}>
                      Resume
                    </Button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Alarms</p>
        <form
          className="mb-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const [h, m] = alarm.split(":").map(Number);
            addAlarm(h ?? 7, m ?? 0, "Alarm");
          }}
        >
          <Input type="time" value={alarm} onChange={(e) => setAlarm(e.target.value)} />
          <Button type="submit">Add</Button>
        </form>
        {!alarms.length ? (
          <p className="text-sm text-muted">No alarms. “Wake me at 6:30”.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {alarms.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-3 rounded-xl bg-card px-3 py-2 shadow-[var(--shadow-border)]">
                <div className="flex min-w-0 items-center gap-2">
                  <Clock className="size-4 shrink-0 text-muted" />
                  <span className="font-mono tabular-nums">
                    {String(a.hour).padStart(2, "0")}:{String(a.minute).padStart(2, "0")}
                  </span>
                  <span className="truncate text-sm text-muted">{a.label}</span>
                </div>
                <Button size="sm" variant={a.enabled ? "default" : "secondary"} onClick={() => toggleAlarm(a.id)}>
                  {a.enabled ? "On" : "Off"}
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function ListsPanel() {
  const lists = useLumen((s) => s.lists);
  const addListItem = useLumen((s) => s.addListItem);
  const toggleListItem = useLumen((s) => s.toggleListItem);
  const ensureList = useLumen((s) => s.ensureList);
  const [active, setActive] = useState(lists[0]?.id ?? "");
  const list = lists.find((l) => l.id === active) ?? lists[0];
  return (
    <>
      <div className="mb-3 flex flex-wrap gap-2">
        {lists.map((l) => (
          <Button key={l.id} size="sm" variant={l.id === list?.id ? "default" : "secondary"} onClick={() => setActive(l.id)}>
            {l.name}
          </Button>
        ))}
        <Button size="sm" variant="outline" onClick={() => ensureList(`List ${lists.length + 1}`)}>
          New list
        </Button>
      </div>
      {list ? (
        <>
          <FieldRow placeholder={`Add to ${list.name}`} onSubmit={(t) => addListItem(list.name, t)} />
          {!list.items.length ? (
            <Empty text={`Nothing on ${list.name}. “Add milk to shopping”.`} />
          ) : (
            <ul className="flex flex-col gap-2">
              {list.items.map((i) => (
                <li key={i.id}>
                  <button
                    type="button"
                    onClick={() => toggleListItem(list.id, i.id)}
                    className="flex min-h-11 w-full items-center gap-3 rounded-xl bg-card px-3 text-left shadow-[var(--shadow-border)]"
                  >
                    <span
                      className={cn(
                        "flex size-5 items-center justify-center rounded-full shadow-[var(--shadow-border)]",
                        i.done ? "bg-success" : "bg-card-2",
                      )}
                    >
                      {i.done ? <Check className="size-3 text-background" /> : null}
                    </span>
                    <span className={cn("text-sm", i.done && "text-muted line-through")}>{i.text}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </>
      ) : null}
    </>
  );
}

function PeoplePanel() {
  const contacts = useLumen((s) => s.contacts);
  const addContact = useLumen((s) => s.addContact);
  const removeContact = useLumen((s) => s.removeContact);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  return (
    <>
      <form
        className="mb-4 grid gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) return;
          addContact(name.trim(), phone.trim(), email.trim());
          setName("");
          setPhone("");
          setEmail("");
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" inputMode="tel" />
        <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" inputMode="email" />
        <Button type="submit">Save person</Button>
      </form>
      {!contacts.length ? (
        <Empty text="No people yet. “Add contact Maya 5550100”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {contacts.map((c) => (
            <li key={c.id} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <UserRound className="size-4 text-muted" />
                  <p className="font-medium">{c.name}</p>
                </div>
                <button type="button" className="size-11 text-muted" onClick={() => removeContact(c.id)} aria-label="Delete">
                  <Trash2 className="mx-auto size-4" />
                </button>
              </div>
              {c.phone ? <p className="mt-1 font-mono text-sm text-muted">{c.phone}</p> : null}
              {c.email ? <p className="text-sm text-muted">{c.email}</p> : null}
              <div className="mt-3 flex flex-wrap gap-2">
                {c.phone ? (
                  <Button size="sm" asChild>
                    <a href={`tel:${c.phone.replace(/\s/g, "")}`}>Call</a>
                  </Button>
                ) : null}
                {c.phone ? (
                  <Button size="sm" variant="secondary" asChild>
                    <a href={`sms:${c.phone.replace(/\s/g, "")}`}>Text</a>
                  </Button>
                ) : null}
                {c.email ? (
                  <Button size="sm" variant="outline" asChild>
                    <a href={`mailto:${c.email}`}>Email</a>
                  </Button>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function DraftsPanel() {
  const drafts = useLumen((s) => s.drafts);
  const removeDraft = useLumen((s) => s.removeDraft);
  if (!drafts.length) return <Empty text="No drafts. “Text Sam I will be late”." />;
  return (
    <ul className="flex flex-col gap-2">
      {drafts.map((d) => {
        const href =
          d.kind === "email"
            ? `mailto:${d.toAddress}?subject=${encodeURIComponent(d.subject)}&body=${encodeURIComponent(d.body)}`
            : `sms:${d.toAddress.replace(/\s/g, "")}?body=${encodeURIComponent(d.body)}`;
        return (
          <li key={d.id} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="text-xs uppercase tracking-wide text-muted">{d.kind === "email" ? "Email" : "Message"}</p>
            <p className="mt-1 font-medium">{d.toName}</p>
            <p className="mt-1 whitespace-pre-wrap text-sm text-muted">{d.body || "Empty body"}</p>
            <div className="mt-3 flex gap-2">
              {d.toAddress ? (
                <Button size="sm" asChild>
                  <a href={href}>Send</a>
                </Button>
              ) : (
                <p className="text-sm text-warn">Missing address</p>
              )}
              <Button size="sm" variant="ghost" onClick={() => removeDraft(d.id)}>
                Discard
              </Button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function FocusPanel() {
  const focus = useLumen((s) => s.focus);
  const now = useLumen((s) => s.now);
  const startFocus = useLumen((s) => s.startFocus);
  const stopFocus = useLumen((s) => s.stopFocus);
  const left = focus?.running ? focus.endsAt - now : 0;
  return (
    <div className="flex flex-col items-center py-8 text-center">
      <p className="font-mono text-5xl tabular-nums tracking-tight">{focus?.running ? msToClock(left) : "25:00"}</p>
      <p className="mt-2 text-sm text-muted">{focus?.running ? "Stay with the work." : "A quiet 25 minutes."}</p>
      <div className="mt-6 flex gap-2">
        {focus?.running ? (
          <Button onClick={stopFocus}>End session</Button>
        ) : (
          <>
            <Button onClick={() => startFocus(25)}>Start 25</Button>
            <Button variant="secondary" onClick={() => startFocus(50)}>
              Start 50
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

function CalcPanel() {
  const [expr, setExpr] = useState("");
  const [out, setOut] = useState("");
  return (
    <div className="flex flex-col gap-3">
      <Input
        value={expr}
        onChange={(e) => setExpr(e.target.value)}
        placeholder="18% of 64 · 10 km to miles · 12 * 8"
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            const conv = expr.match(/(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+to\s+([a-z°]+)/i);
            if (conv) {
              setOut(convertUnits(Number(conv[1]), conv[2] ?? "", conv[3] ?? "") ?? "Cannot convert");
              return;
            }
            setOut(evalMath(expr) ?? "Cannot read that");
          }
        }}
      />
      <Button
        onClick={() => {
          const conv = expr.match(/(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+to\s+([a-z°]+)/i);
          if (conv) {
            setOut(convertUnits(Number(conv[1]), conv[2] ?? "", conv[3] ?? "") ?? "Cannot convert");
            return;
          }
          setOut(evalMath(expr) ?? "Cannot read that");
        }}
      >
        Calculate
      </Button>
      {out ? <p className="font-mono text-3xl tabular-nums">{out}</p> : null}
      <p className="text-sm text-muted">Tip, split, percent, and unit conversion all run on this device.</p>
    </div>
  );
}

function JournalPanel() {
  const journal = useLumen((s) => s.journal);
  const addJournal = useLumen((s) => s.addJournal);
  const [body, setBody] = useState("");
  return (
    <>
      <form
        className="mb-4 flex flex-col gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!body.trim()) return;
          addJournal(body.trim());
          setBody("");
        }}
      >
        <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="What happened today" />
        <Button type="submit" className="self-end">
          Write
        </Button>
      </form>
      {!journal.length ? (
        <Empty text="The journal is empty. “Journal today I shipped the draft”." />
      ) : (
        <ul className="flex flex-col gap-2">
          {journal.map((e) => (
            <li key={e.id} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
              <p className="text-xs text-muted">{new Date(e.createdAt).toLocaleString()}</p>
              <p className="mt-1 whitespace-pre-wrap text-sm">{e.body}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function SettingsPanel() {
  const settings = useLumen((s) => s.settings);
  const patchSettings = useLumen((s) => s.patchSettings);
  const replaceAll = useLumen((s) => s.replaceAll);
  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">You</p>
        <Input
          value={settings.name}
          onChange={(e) => patchSettings({ name: e.target.value })}
          placeholder="What should Lumen call you"
        />
      </div>
      <div className="rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]">
        <Switch
          checked={settings.voiceReplies}
          onCheckedChange={(v) => patchSettings({ voiceReplies: v })}
          label="Speak replies"
        />
      </div>
      <div className="rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]">
        <Switch
          checked={settings.thinkOnline}
          onCheckedChange={(v) => patchSettings({ thinkOnline: v })}
          label="Use Grok for open questions"
        />
        <p className="mt-1 text-xs text-muted">Commands always run on device. Grok is only for “think …”.</p>
      </div>
      <div className="flex flex-col gap-2">
        <Button
          variant="secondary"
          onClick={() => {
            const blob = new Blob([JSON.stringify(exportPayload(), null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "lumen-board.json";
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          Export board
        </Button>
        <label className="inline-flex h-11 items-center justify-center rounded-md bg-card text-sm font-medium shadow-[var(--shadow-border)]">
          Import board
          <input
            type="file"
            accept="application/json"
            className="sr-only"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              try {
                const data = JSON.parse(await file.text()) as Parameters<typeof replaceAll>[0];
                replaceAll(data);
              } catch {
                /* ignore */
              }
            }}
          />
        </label>
      </div>
      <p className="text-sm text-muted">
        Lumen stores everything in this browser. Call, text, and email buttons open the phone when a number exists.
      </p>
    </div>
  );
}

export function iconFor(id: ModuleId) {
  switch (id) {
    case "tasks":
      return ListTodo;
    case "notes":
      return StickyNote;
    case "reminders":
      return Bell;
    case "calendar":
      return CalendarIcon;
    case "timer":
      return Clock;
    default:
      return ListTodo;
  }
}
