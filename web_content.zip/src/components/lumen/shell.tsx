import {
  Bell,
  Calculator,
  Calendar,
  Clock,
  Focus,
  ListTodo,
  Mic,
  NotebookPen,
  Send,
  Settings,
  ShoppingBag,
  Sparkles,
  Square,
  StickyNote,
  UserRound,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Toaster, toast } from "sonner";
import { askGrok } from "@/lib/ai/ask-grok";
import { composeBriefing, greeting } from "@/lib/assistant/briefing";
import { formatWhen, msToClock } from "@/lib/assistant/dates";
import { parseActionBlock } from "@/lib/assistant/execute-action";
import type { ModuleId } from "@/lib/assistant/types";
import { beep, canListen, notify, speak, startListening, stopSpeaking, vibrate } from "@/lib/speech";
import { useLumen } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ModuleFrame } from "@/components/lumen/panels";
import { cn } from "@/lib/utils";

const APPS: { id: ModuleId; label: string; Icon: typeof ListTodo }[] = [
  { id: "tasks", label: "Tasks", Icon: ListTodo },
  { id: "notes", label: "Notes", Icon: StickyNote },
  { id: "reminders", label: "Remind", Icon: Bell },
  { id: "calendar", label: "Plan", Icon: Calendar },
  { id: "timer", label: "Time", Icon: Clock },
  { id: "lists", label: "Lists", Icon: ShoppingBag },
  { id: "people", label: "People", Icon: UserRound },
  { id: "focus", label: "Focus", Icon: Focus },
  { id: "calc", label: "Numbers", Icon: Calculator },
  { id: "journal", label: "Journal", Icon: NotebookPen },
  { id: "talk", label: "Talk", Icon: Sparkles },
  { id: "settings", label: "Settings", Icon: Settings },
];

const CHIPS = [
  "Set a 5 minute timer",
  "Remind me to stretch at 7pm",
  "Add milk to shopping",
  "What's on today",
];

export function LumenShell() {
  const module = useLumen((s) => s.module);
  const setModule = useLumen((s) => s.setModule);
  const setNow = useLumen((s) => s.setNow);
  const now = useLumen((s) => s.now);
  const settings = useLumen((s) => s.settings);
  const lastResult = useLumen((s) => s.lastResult);
  const timers = useLumen((s) => s.timers);
  const reminders = useLumen((s) => s.reminders);
  const alarms = useLumen((s) => s.alarms);
  const focus = useLumen((s) => s.focus);
  const finishTimer = useLumen((s) => s.finishTimer);
  const markReminderNotified = useLumen((s) => s.markReminderNotified);
  const markAlarmFired = useLumen((s) => s.markAlarmFired);
  const stopFocus = useLumen((s) => s.stopFocus);
  const pushMessage = useLumen((s) => s.pushMessage);
  const execute = useLumen((s) => s.execute);
  const submit = useLumen((s) => s.submit);

  const [draft, setDraft] = useState("");
  const [listening, setListening] = useState(false);
  const [thinking, setThinking] = useState(false);
  const stopListen = useRef<(() => void) | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [setNow]);

  useEffect(() => {
    for (const t of timers) {
      if (t.status === "running" && t.endsAt <= Date.now()) {
        finishTimer(t.id);
        beep();
        vibrate();
        void notify("Lumen", `${t.label} is done.`);
        toast("Timer finished");
        if (useLumen.getState().settings.voiceReplies) speak("Time is up.");
      }
    }
    for (const r of reminders) {
      if (!r.done && !r.notified && r.at <= Date.now()) {
        markReminderNotified(r.id);
        beep();
        vibrate();
        void notify("Lumen", r.title);
        toast(r.title);
        if (useLumen.getState().settings.voiceReplies) speak(r.title);
      }
    }
    const d = new Date();
    const key = `${d.toDateString()}-${d.getHours()}-${d.getMinutes()}`;
    for (const a of alarms) {
      if (a.enabled && a.hour === d.getHours() && a.minute === d.getMinutes() && a.lastFiredKey !== key) {
        markAlarmFired(a.id, key);
        beep();
        vibrate();
        void notify("Lumen", a.label);
        toast(`Alarm · ${a.label}`);
      }
    }
    if (focus?.running && focus.endsAt <= Date.now()) {
      stopFocus();
      beep();
      toast("Focus session complete");
    }
  }, [now, timers, reminders, alarms, focus, finishTimer, markReminderNotified, markAlarmFired, stopFocus]);

  async function run(text: string) {
    const trimmed = text.trim();
    if (!trimmed || thinking) return;
    setDraft("");
    stopSpeaking();
    const { intent, result } = submit(trimmed);
    const wantsThink =
      intent.type === "think" || (intent.type === "unknown" && useLumen.getState().settings.thinkOnline);

    if (wantsThink) {
      setThinking(true);
      const snap = snapshotText();
      try {
        const res = await askGrok({ data: { prompt: trimmed, snapshot: snap } });
        if (res.ok && res.text) {
          const parsed = parseActionBlock(res.text);
          if (parsed.intent) execute(parsed.intent);
          const reply = parsed.clean || res.text;
          pushMessage({ role: "lumen", text: reply, open: "talk" });
          useLumen.setState({ lastResult: reply, module: "talk" });
          if (useLumen.getState().settings.voiceReplies) speak(reply);
          return;
        }
        throw new Error(res.ok ? "empty" : res.error);
      } catch {
        if (intent.type === "unknown") {
          const local = execute(intent);
          pushMessage({ role: "lumen", text: local.text, open: local.open });
          useLumen.setState({ lastResult: local.text, module: local.open ?? "talk" });
          if (useLumen.getState().settings.voiceReplies) speak(local.text);
        } else {
          const fallback =
            "Grok is not reachable. I can still run timers, tasks, notes, and the rest on this device.";
          pushMessage({ role: "lumen", text: fallback, open: "talk" });
          useLumen.setState({ lastResult: fallback, module: "talk" });
          if (useLumen.getState().settings.voiceReplies) speak(fallback);
        }
      } finally {
        setThinking(false);
      }
      return;
    }

    if (result.href) {
      window.location.href = result.href;
    }
    if (settings.voiceReplies) speak(result.text);
  }

  function toggleMic() {
    if (listening) {
      stopListen.current?.();
      stopListen.current = null;
      setListening(false);
      return;
    }
    if (!canListen()) {
      toast("Voice input is not available in this browser.");
      inputRef.current?.focus();
      return;
    }
    setListening(true);
    stopListen.current = startListening((text, final) => {
      setDraft(text);
      if (final) {
        setListening(false);
        stopListen.current = null;
        void run(text);
      }
    });
  }

  const clock = new Date(now);
  const timeLabel = clock.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const dateLabel = clock.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
  const running = timers.find((t) => t.status === "running");
  const nextRem = reminders.filter((r) => !r.done && r.at >= now).sort((a, b) => a.at - b.at)[0];
  const tasks = useLumen((s) => s.tasks);
  const messages = useLumen((s) => s.messages);
  const openTasks = tasks.filter((t) => !t.done).length;
  const brief = composeBriefing({
    tasks,
    reminders,
    events: useLumen.getState().events,
    timers,
    alarms,
    lists: useLumen.getState().lists,
    now,
  });

  const dock = (
    <form
      className="shrink-0 bg-background px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2"
      onSubmit={(e) => {
        e.preventDefault();
        void run(draft);
      }}
    >
      {lastResult ? (
        <p className="mb-2 line-clamp-2 rounded-xl bg-card px-3.5 py-2 text-sm text-foreground shadow-[var(--shadow-border)]">
          {thinking ? "Thinking…" : lastResult}
        </p>
      ) : null}
      <div className="flex items-end gap-2 rounded-2xl bg-card p-2 shadow-[var(--shadow-border)]">
        <label className="sr-only" htmlFor="lumen-command">
          Tell Lumen
        </label>
        <input
          id="lumen-command"
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Tell Lumen…"
          autoComplete="off"
          className="h-11 min-w-0 flex-1 bg-transparent px-3 text-base text-foreground placeholder:text-subtle focus:outline-none"
        />
        <Button
          type="button"
          size="icon"
          variant={listening ? "default" : "secondary"}
          onClick={toggleMic}
          aria-label={listening ? "Stop listening" : "Voice input"}
        >
          {listening ? <Square className="size-4" /> : <Mic className="size-4" />}
        </Button>
        <Button type="submit" size="icon" disabled={thinking} aria-label="Send">
          <Send className="size-4" />
        </Button>
      </div>
    </form>
  );

  const home = (
    <main className="min-h-0 flex-1 overflow-y-auto px-5 pb-4 pt-6">
      <p className="text-sm text-muted">{dateLabel}</p>
      <h1 suppressHydrationWarning className="font-display text-6xl leading-none tracking-tight">
        {timeLabel}
      </h1>
      <p suppressHydrationWarning className="mt-4 font-display text-2xl italic text-foreground/90">
        {greeting(clock, settings.name)}
      </p>
      <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">{brief}</p>

      <div className="mt-5 flex flex-wrap gap-2">
        {CHIPS.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => void run(c)}
            className="min-h-11 rounded-full bg-card px-3.5 text-left text-sm text-muted shadow-[var(--shadow-border)]"
          >
            {c}
          </button>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-2">
        <Widget label="Tasks" value={`${openTasks} open`} onClick={() => setModule("tasks")} />
        <Widget
          label="Timer"
          value={running ? msToClock(running.endsAt - now) : "Idle"}
          mono
          onClick={() => setModule("timer")}
        />
        <Widget
          label="Next"
          value={nextRem ? `${nextRem.title} · ${formatWhen(nextRem.at, now)}` : "No reminder"}
          onClick={() => setModule("reminders")}
        />
        <Widget
          label="Focus"
          value={focus?.running ? msToClock(focus.endsAt - now) : "Ready"}
          mono={Boolean(focus?.running)}
          onClick={() => setModule("focus")}
        />
      </div>

      <p className="mt-8 text-xs font-medium uppercase tracking-wide text-muted">Board</p>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {APPS.map((app) => (
          <button
            key={app.id}
            type="button"
            onClick={() => setModule(app.id)}
            className="flex min-h-24 flex-col items-start justify-between rounded-xl bg-card p-3 text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
          >
            <app.Icon className="size-4 text-muted" />
            <span className="text-sm font-medium">{app.label}</span>
          </button>
        ))}
      </div>
    </main>
  );

  return (
    <div className="min-h-dvh bg-background">
      <Toaster theme="dark" position="top-center" />
      <div className="mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[28rem_minmax(0,1fr)]">
        <section className="relative flex h-dvh flex-col overflow-hidden bg-background">
          <header className="flex items-center justify-between px-5 pt-5">
            <Badge>On device</Badge>
            <button
              type="button"
              className="size-11 text-muted"
              onClick={() => setModule("settings")}
              aria-label="Settings"
            >
              <Settings className="mx-auto size-4" />
            </button>
          </header>
          <div className="relative flex min-h-0 flex-1 flex-col">
            {home}
            {module !== "home" ? (
              <div className="absolute inset-0 z-10 flex flex-col bg-background lg:hidden">
                <ModuleFrame module={module} onBack={() => setModule("home")} />
              </div>
            ) : null}
          </div>
          {dock}
        </section>

        <aside className="hidden h-dvh flex-col border-l border-border lg:flex">
          {module !== "home" ? (
            <ModuleFrame module={module} onBack={() => setModule("home")} />
          ) : (
            <div className="flex min-h-0 flex-1 flex-col px-8 py-8">
              <p className="text-xs font-medium uppercase tracking-wide text-muted">Talk</p>
              <h2 className="mt-2 font-display text-3xl tracking-tight">Tell Lumen what to do.</h2>
              <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">
                Timers, reminders, notes, lists, calls, and drafts all stay on this device. Open questions can use Grok
                if you prefix with “think”.
              </p>
              <div className="mt-8 min-h-0 flex-1 overflow-y-auto">
                {!messages.length ? (
                  <p className="text-sm text-muted">No conversation yet.</p>
                ) : (
                  <ol className="flex flex-col gap-3">
                    {messages.map((m) => (
                      <li
                        key={m.id}
                        className={cn(
                          "max-w-md rounded-xl px-3.5 py-2.5 text-sm leading-relaxed",
                          m.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-card text-foreground shadow-[var(--shadow-border)]",
                        )}
                      >
                        {m.text}
                      </li>
                    ))}
                  </ol>
                )}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

function Widget({
  label,
  value,
  onClick,
  mono,
}: {
  label: string;
  value: string;
  onClick: () => void;
  mono?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="min-h-24 rounded-xl bg-card p-3.5 text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
    >
      <p className="text-xs uppercase tracking-wide text-muted">{label}</p>
      <p className={cn("mt-2 text-sm leading-snug", mono && "font-mono text-xl tabular-nums")}>{value}</p>
    </button>
  );
}

function snapshotText(): string {
  const s = useLumen.getState();
  const tasks = s.tasks
    .filter((t) => !t.done)
    .slice(0, 8)
    .map((t) => t.title)
    .join("; ");
  const rems = s.reminders
    .filter((r) => !r.done)
    .slice(0, 5)
    .map((r) => `${r.title} @ ${new Date(r.at).toISOString()}`)
    .join("; ");
  const people = s.contacts.map((c) => c.name).join(", ");
  const lists = s.lists.map((l) => `${l.name}: ${l.items.filter((i) => !i.done).map((i) => i.text).join(", ")}`).join(" | ");
  return `tasks: ${tasks || "none"}\nreminders: ${rems || "none"}\npeople: ${people || "none"}\nlists: ${lists || "none"}`;
}
