import { useMemo, useState } from 'react';
import type { Chess, Square, PieceSymbol, Color } from 'chess.js';
import wK from '../assets/pieces/wK.svg';
import wQ from '../assets/pieces/wQ.svg';
import wR from '../assets/pieces/wR.svg';
import wB from '../assets/pieces/wB.svg';
import wN from '../assets/pieces/wN.svg';
import wP from '../assets/pieces/wP.svg';
import bK from '../assets/pieces/bK.svg';
import bQ from '../assets/pieces/bQ.svg';
import bR from '../assets/pieces/bR.svg';
import bB from '../assets/pieces/bB.svg';
import bN from '../assets/pieces/bN.svg';
import bP from '../assets/pieces/bP.svg';

const IMG: Record<string, string> = { wK, wQ, wR, wB, wN, wP, bK, bQ, bR, bB, bN, bP };

export const THEMES = {
  classic: { light: '#f0d9b5', dark: '#b58863' },
  green: { light: '#eeeed2', dark: '#769656' },
  blue: { light: '#dee3e6', dark: '#8ca2ad' },
  gray: { light: '#e4e4e7', dark: '#8f9199' },
} as const;

export interface ArrowSpec {
  from: string;
  to: string;
  rank: number; // 0 = лучший
}

export const ARROW_COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#a855f7', '#ec4899'];

interface Props {
  chess: Chess;
  flipped: boolean;
  theme: keyof typeof THEMES;
  lastMove: { from: string; to: string } | null;
  arrows: ArrowSpec[];
  showCoords: boolean;
  showLegal: boolean;
  showLastMove: boolean;
  interactive: boolean;
  onMove: (from: string, to: string, promotion?: string) => void;
}

const FILES = 'abcdefgh';

function Arrow({ a, flipped }: { a: ArrowSpec; flipped: boolean }) {
  const pos = (sq: string) => {
    const f = FILES.indexOf(sq[0]);
    const r = parseInt(sq[1], 10) - 1;
    return { x: (flipped ? 7 - f : f) + 0.5, y: (flipped ? r : 7 - r) + 0.5 };
  };
  const s = pos(a.from);
  const e = pos(a.to);
  const dx = e.x - s.x;
  const dy = e.y - s.y;
  const len = Math.hypot(dx, dy);
  if (len < 0.01) return null;
  const ux = dx / len,
    uy = dy / len;
  const nx = -uy,
    ny = ux;
  const w = Math.max(0.07, 0.15 - a.rank * 0.02) / 2;
  const hw = w * 2.6;
  const hl = 0.34;
  const sx = s.x + ux * 0.18,
    sy = s.y + uy * 0.18;
  const ex = e.x - ux * 0.08,
    ey = e.y - uy * 0.08;
  const bx = ex - ux * hl,
    by = ey - uy * hl;
  const pts = [
    [sx + nx * w, sy + ny * w],
    [bx + nx * w, by + ny * w],
    [bx + nx * hw, by + ny * hw],
    [ex, ey],
    [bx - nx * hw, by - ny * hw],
    [bx - nx * w, by - ny * w],
    [sx - nx * w, sy - ny * w],
  ];
  return (
    <polygon
      points={pts.map((p) => p.join(',')).join(' ')}
      fill={ARROW_COLORS[a.rank % ARROW_COLORS.length]}
      opacity={a.rank === 0 ? 0.88 : 0.7}
      stroke="rgba(0,0,0,0.25)"
      strokeWidth={0.015}
      strokeLinejoin="round"
    />
  );
}

export default function Board({
  chess,
  flipped,
  theme,
  lastMove,
  arrows,
  showCoords,
  showLegal,
  showLastMove,
  interactive,
  onMove,
}: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [promo, setPromo] = useState<{ from: string; to: string } | null>(null);
  const colors = THEMES[theme];

  const board = chess.board();
  const turn = chess.turn();
  const fenKey = chess.fen();

  const legal = useMemo(() => {
    if (!selected) return [] as { to: string; capture: boolean }[];
    return chess
      .moves({ square: selected as Square, verbose: true })
      .map((m) => ({ to: m.to as string, capture: !!m.captured || m.flags.includes('e') }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected, fenKey]);

  const checkSq = useMemo(() => {
    if (!chess.inCheck()) return null;
    for (let r = 0; r < 8; r++)
      for (let c = 0; c < 8; c++) {
        const p = board[r][c];
        if (p && p.type === 'k' && p.color === turn) return p.square;
      }
    return null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fenKey]);

  const tryMove = (from: string, to: string) => {
    const mv = chess.moves({ square: from as Square, verbose: true }).filter((m) => m.to === to);
    setSelected(null);
    if (!mv.length) return;
    if (mv[0].promotion) {
      setPromo({ from, to });
      return;
    }
    onMove(from, to);
  };

  const clickSquare = (sq: string, piece: { color: Color } | null) => {
    if (!interactive) return;
    if (selected && legal.some((l) => l.to === sq)) {
      tryMove(selected, sq);
      return;
    }
    if (piece && piece.color === turn) setSelected(sq === selected ? null : sq);
    else setSelected(null);
  };

  const squares = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      const file = c; // 0..7 a..h
      const rank = 7 - r; // 0..7 -> 1..8
      const sq = `${FILES[file]}${rank + 1}`;
      const col = flipped ? 7 - file : file;
      const row = flipped ? rank : 7 - rank;
      const isLight = (file + rank) % 2 === 1;
      const isLast = showLastMove && lastMove && (lastMove.from === sq || lastMove.to === sq);
      const isSel = selected === sq;
      const lg = showLegal ? legal.find((l) => l.to === sq) : undefined;
      const canDrag = interactive && piece && piece.color === turn;
      const showFile = row === 7;
      const showRank = col === 0;
      const textColor = isLight ? colors.dark : colors.light;

      squares.push(
        <div
          key={sq}
          onClick={() => clickSquare(sq, piece)}
          onDragOver={(e) => interactive && e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            const from = e.dataTransfer.getData('text/plain');
            if (interactive && from && from !== sq) tryMove(from, sq);
          }}
          className="absolute select-none"
          style={{
            left: `${col * 12.5}%`,
            top: `${row * 12.5}%`,
            width: '12.5%',
            height: '12.5%',
            background: isLight ? colors.light : colors.dark,
          }}
        >
          {isLast && <div className="absolute inset-0" style={{ background: 'rgba(255, 213, 0, 0.42)' }} />}
          {isSel && <div className="absolute inset-0" style={{ background: 'rgba(80, 160, 255, 0.5)' }} />}
          {checkSq === sq && (
            <div
              className="absolute inset-0"
              style={{
                background:
                  'radial-gradient(circle, rgba(239,68,68,0.95) 0%, rgba(239,68,68,0.55) 45%, rgba(239,68,68,0) 75%)',
              }}
            />
          )}
          {showCoords && showRank && (
            <span
              className="pointer-events-none absolute left-[4%] top-[2%] font-semibold leading-none"
              style={{ color: textColor, fontSize: 'max(9px, calc(var(--bs) / 8 * 0.17))' }}
            >
              {rank + 1}
            </span>
          )}
          {showCoords && showFile && (
            <span
              className="pointer-events-none absolute bottom-[2%] right-[5%] font-semibold leading-none"
              style={{ color: textColor, fontSize: 'max(9px, calc(var(--bs) / 8 * 0.17))' }}
            >
              {FILES[file]}
            </span>
          )}
          {piece && (
            <img
              src={IMG[piece.color + piece.type.toUpperCase()]}
              alt=""
              draggable={!!canDrag}
              onDragStart={(e) => {
                e.dataTransfer.setData('text/plain', sq);
                e.dataTransfer.effectAllowed = 'move';
                setSelected(sq);
              }}
              className="absolute left-[5%] top-[5%] h-[90%] w-[90%]"
              style={{ cursor: canDrag ? 'grab' : 'default', filter: 'drop-shadow(0 1px 1px rgba(0,0,0,0.25))' }}
            />
          )}
          {lg &&
            (lg.capture ? (
              <div
                className="pointer-events-none absolute inset-[4%] rounded-full"
                style={{ border: 'calc(var(--bs) / 8 * 0.09) solid rgba(20,20,20,0.28)' }}
              />
            ) : (
              <div
                className="pointer-events-none absolute rounded-full"
                style={{ left: '35%', top: '35%', width: '30%', height: '30%', background: 'rgba(20,20,20,0.27)' }}
              />
            ))}
        </div>,
      );
    }
  }

  return (
    <div
      className="relative overflow-hidden rounded-md shadow-2xl shadow-black/50 ring-1 ring-black/40"
      style={{ width: 'var(--bs)', height: 'var(--bs)' }}
    >
      {squares}
      <svg viewBox="0 0 8 8" className="pointer-events-none absolute inset-0 h-full w-full">
        {arrows
          .slice()
          .reverse()
          .map((a) => (
            <Arrow key={a.from + a.to} a={a} flipped={flipped} />
          ))}
      </svg>
      {promo && (
        <div
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/55"
          onClick={() => setPromo(null)}
        >
          <div
            className="flex gap-2 rounded-xl bg-zinc-900/95 p-3 shadow-xl ring-1 ring-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            {(['q', 'r', 'b', 'n'] as PieceSymbol[]).map((t) => (
              <button
                key={t}
                className="rounded-lg bg-zinc-700/70 p-1 transition hover:bg-emerald-600"
                style={{ width: 'calc(var(--bs) / 8 * 0.95)', height: 'calc(var(--bs) / 8 * 0.95)' }}
                onClick={() => {
                  onMove(promo.from, promo.to, t);
                  setPromo(null);
                }}
              >
                <img src={IMG[turn + t.toUpperCase()]} alt={t} className="h-full w-full" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
