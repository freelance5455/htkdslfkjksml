import { GLYPH, isLightSquare, parseFen, squareList, type PieceColor } from "../lib/chess";
import { cn } from "../utils/cn";

interface BoardProps {
  fen: string;
  orientation?: PieceColor;
  selected?: string | null;
  targets?: string[];
  lastMove?: { from: string; to: string } | null;
  checkSquare?: string | null;
  hintSquares?: string[];
  onSquareClick?: (square: string) => void;
  className?: string;
}

export default function Board({
  fen,
  orientation = "w",
  selected = null,
  targets = [],
  lastMove = null,
  checkSquare = null,
  hintSquares = [],
  onSquareClick,
  className,
}: BoardProps) {
  const pieces = parseFen(fen);
  const squares = squareList(orientation);
  const targetSet = new Set(targets);
  const hintSet = new Set(hintSquares);

  return (
    <div
      className={cn(
        "relative aspect-square w-full select-none overflow-hidden rounded-xl shadow-2xl ring-1 ring-black/40",
        className,
      )}
    >
      <div className="grid h-full w-full grid-cols-8 grid-rows-8">
        {squares.map((square) => {
          const piece = pieces[square];
          const light = isLightSquare(square);
          const isTarget = targetSet.has(square);
          const isSelected = selected === square;
          const isLast = lastMove && (lastMove.from === square || lastMove.to === square);
          const file = square[0];
          const rank = square[1];
          const showFile = orientation === "w" ? rank === "1" : rank === "8";
          const showRank = orientation === "w" ? file === "a" : file === "h";

          return (
            <button
              key={square}
              type="button"
              onClick={() => onSquareClick?.(square)}
              className={cn(
                "relative flex items-center justify-center transition-colors duration-100",
                light ? "bg-[#eadfc8]" : "bg-[#9a6f4a]",
                isLast && (light ? "bg-[#e6d98a]" : "bg-[#b89a4d]"),
                hintSet.has(square) && "bg-emerald-400/70",
                isSelected && "bg-emerald-500/80",
                checkSquare === square && "bg-rose-500/80",
                onSquareClick ? "cursor-pointer" : "cursor-default",
              )}
            >
              {showFile && (
                <span
                  className={cn(
                    "pointer-events-none absolute bottom-0.5 right-1 text-[0.5rem] font-bold sm:text-[0.6rem]",
                    light ? "text-[#9a6f4a]" : "text-[#eadfc8]",
                  )}
                >
                  {file}
                </span>
              )}
              {showRank && (
                <span
                  className={cn(
                    "pointer-events-none absolute left-1 top-0.5 text-[0.5rem] font-bold sm:text-[0.6rem]",
                    light ? "text-[#9a6f4a]" : "text-[#eadfc8]",
                  )}
                >
                  {rank}
                </span>
              )}

              {isTarget && !piece && (
                <span className="pointer-events-none block h-1/4 w-1/4 rounded-full bg-black/25" />
              )}
              {isTarget && piece && (
                <span className="pointer-events-none absolute inset-[6%] rounded-full ring-[0.3rem] ring-black/25" />
              )}

              {piece && (
                <span
                  className={cn(
                    "pointer-events-none relative z-10 leading-none",
                    "text-[min(8.5vw,2.9rem)] sm:text-[min(5.5vw,3.3rem)]",
                    piece.color === "w" ? "text-white" : "text-neutral-900",
                  )}
                  style={{
                    WebkitTextStroke:
                      piece.color === "w" ? "1.2px rgba(0,0,0,.65)" : "1.2px rgba(255,255,255,.35)",
                    filter: "drop-shadow(0 2px 2px rgba(0,0,0,.35))",
                  }}
                >
                  {GLYPH[piece.type]}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
