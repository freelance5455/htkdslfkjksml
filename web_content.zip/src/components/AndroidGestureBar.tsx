import React from 'react';
import { ArrowLeft, Home, Layers } from 'lucide-react';

interface AndroidGestureBarProps {
  onBack: () => void;
  onHome: () => void;
  onOverview: () => void;
  canGoBack: boolean;
}

export const AndroidGestureBar: React.FC<AndroidGestureBarProps> = ({
  onBack,
  onHome,
  onOverview,
  canGoBack,
}) => {
  return (
    <div className="w-full h-10 bg-slate-950/95 backdrop-blur-md flex items-center justify-around px-8 border-t border-slate-800/60 z-30 select-none">
      {/* Android Back Button */}
      <button
        id="android-back-btn"
        onClick={onBack}
        disabled={!canGoBack}
        className={`p-2 rounded-full transition-colors active:scale-95 ${
          canGoBack ? 'text-slate-300 hover:text-white hover:bg-slate-800/60' : 'text-slate-600 cursor-not-allowed'
        }`}
        aria-label="Back"
      >
        <ArrowLeft className="w-4 h-4" />
      </button>

      {/* Android Center Home Pill */}
      <button
        id="android-home-btn"
        onClick={onHome}
        className="group py-2 px-6 flex items-center justify-center cursor-pointer active:scale-95"
        aria-label="Home"
      >
        <div className="w-24 h-1 rounded-full bg-slate-400/80 group-hover:bg-slate-200 transition-colors" />
      </button>

      {/* Android Overview / Recent Apps button */}
      <button
        id="android-overview-btn"
        onClick={onOverview}
        className="p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-full transition-colors active:scale-95"
        aria-label="Recent Tabs Overview"
      >
        <Layers className="w-4 h-4" />
      </button>
    </div>
  );
};
