import React, { useMemo, useRef, useState } from 'react';
import { Check, MonitorSmartphone, Plus, Search, Upload, X } from 'lucide-react';
import { CustomFont, DetectedPdfFont, UILanguage } from '../types/pdf';
import { BUNDLED_FONTS, GOOGLE_FONTS_CATALOG } from '../utils/fonts';
import { UI_COPY } from '../utils/i18n';

interface FontManagerModalProps {
  isOpen: boolean;
  lang: UILanguage;
  customFonts: CustomFont[];
  detectedFonts: DetectedPdfFont[];
  onClose: () => void;
  onUploadFonts: (files: File[]) => Promise<void> | void;
  onLoadDeviceFonts: () => Promise<{ supported: boolean; count: number }>;
  onAddGoogleFont: (fontName: string) => Promise<CustomFont>;
  onApplyFontToDetected: (rawName: string, fontId: string) => void;
}

export const FontManagerModal: React.FC<FontManagerModalProps> = ({
  isOpen,
  lang,
  customFonts,
  detectedFonts,
  onClose,
  onUploadFonts,
  onLoadDeviceFonts,
  onAddGoogleFont,
  onApplyFontToDetected,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);
  const [googleQuery, setGoogleQuery] = useState('');
  const [isAddingGoogle, setIsAddingGoogle] = useState(false);
  const [googleFeedback, setGoogleFeedback] = useState<{
    type: 'ok' | 'err';
    msg: string;
  } | null>(null);

  const filteredCatalog = useMemo(() => {
    const q = googleQuery.trim().toLowerCase();
    if (!q) return GOOGLE_FONTS_CATALOG.slice(0, 12);
    return GOOGLE_FONTS_CATALOG.filter((item) =>
      item.family.toLowerCase().includes(q)
    ).slice(0, 12);
  }, [googleQuery]);

  if (!isOpen) return null;

  const t = UI_COPY[lang];

  const handleOneClickDeviceFonts = async () => {
    setIsScanning(true);
    setScanMessage(null);
    try {
      const res = await onLoadDeviceFonts();
      setScanMessage(`${res.count} ${t.deviceFontsResult}`);
    } finally {
      setIsScanning(false);
    }
  };

  const handleSearchOrAddGoogleFont = async (fontNameToLoad: string) => {
    const clean = fontNameToLoad.trim();
    if (!clean) return;
    setIsAddingGoogle(true);
    setGoogleFeedback(null);
    try {
      const added = await onAddGoogleFont(clean);
      setGoogleFeedback({
        type: 'ok',
        msg: `${added.name} — ${t.googleFontAdded}`,
      });
      setGoogleQuery('');
    } catch {
      setGoogleFeedback({
        type: 'err',
        msg: t.googleFontNotFound,
      });
    } finally {
      setIsAddingGoogle(false);
    }
  };

  const addedFontNamesLower = new Set(
    customFonts.map((cf) => cf.name.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[1px] flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[88vh] flex flex-col shadow-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              {t.fontManagerTitle}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.fontManagerDesc}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            data-tooltip={t.close}
            aria-label={t.close}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5">
          {/* 1-Click Mobile/Device Fonts + Optional File Import */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              disabled={isScanning}
              onClick={handleOneClickDeviceFonts}
              className="py-3 px-4 border border-blue-600 bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg text-xs font-semibold text-white flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <MonitorSmartphone className="w-4 h-4 shrink-0" />
              <span className="truncate">
                {isScanning ? t.loadingDeviceFonts : t.loadDeviceFonts}
              </span>
            </button>

            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="py-3 px-4 border border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-800 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4 shrink-0 text-blue-700" />
              <span className="truncate">{t.uploadCustomFont}</span>
            </button>

            <input
              ref={inputRef}
              type="file"
              accept=".ttf,.otf,.woff,.woff2"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = e.target.files ? Array.from(e.target.files) : [];
                if (files.length > 0) void onUploadFonts(files);
                e.target.value = '';
              }}
            />
          </div>

          {scanMessage && (
            <div className="px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-medium text-emerald-800 flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 shrink-0" />
              <span>{scanMessage}</span>
            </div>
          )}

          {/* Google Fonts Search & Instant Add */}
          <div className="border border-slate-200 rounded-xl p-4 bg-[#FAFAFB] space-y-3">
            <div className="text-xs font-semibold text-slate-800">
              {t.googleFontSearchHeading}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                void handleSearchOrAddGoogleFont(googleQuery);
              }}
              className="flex items-center gap-2"
            >
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={googleQuery}
                  onChange={(e) => setGoogleQuery(e.target.value)}
                  placeholder={t.googleFontSearchPlaceholder}
                  className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>
              <button
                type="submit"
                disabled={isAddingGoogle || !googleQuery.trim()}
                className="px-3.5 py-2 text-xs font-semibold bg-slate-900 hover:bg-slate-800 disabled:opacity-45 text-white rounded-lg inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAddingGoogle ? t.googleFontLoading : t.googleFontAddBtn}</span>
              </button>
            </form>

            {googleFeedback && (
              <div
                className={`text-xs font-medium ${
                  googleFeedback.type === 'ok' ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {googleFeedback.msg}
              </div>
            )}

            <div>
              <div className="text-[11px] text-slate-500 mb-2">
                {t.googleFontsQuickList}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                {filteredCatalog.map((gf) => {
                  const alreadyAdded = addedFontNamesLower.has(gf.family.toLowerCase());
                  return (
                    <button
                      key={gf.family}
                      type="button"
                      disabled={isAddingGoogle}
                      onClick={() => void handleSearchOrAddGoogleFont(gf.family)}
                      className={`px-2.5 py-2 rounded-md border text-left text-xs flex items-center justify-between gap-1.5 transition-colors cursor-pointer ${
                        alreadyAdded
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-white border-slate-200 hover:border-blue-500 text-slate-800'
                      }`}
                    >
                      <span className="truncate font-medium">{gf.family}</span>
                      {alreadyAdded ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      ) : (
                        <Plus className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Device, Google & Custom Fonts List */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold text-slate-700">
                {t.customFontsHeading}
              </h3>
              <span className="text-xs font-mono tabular-nums text-slate-400">
                {customFonts.length}
              </span>
            </div>
            {customFonts.length === 0 ? (
              <p className="text-xs text-slate-500">{t.noCustomFonts}</p>
            ) : (
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg max-h-52 overflow-y-auto">
                {customFonts.map((cf) => (
                  <div
                    key={cf.id}
                    className="px-4 py-2 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-900 truncate">
                        {cf.name}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">{cf.fileName}</div>
                    </div>
                    <div
                      className="text-sm text-slate-700 shrink-0"
                      style={{
                        fontFamily: `"${cf.familyName}", "Noto Sans Bengali Local", "Noto Naskh Arabic", sans-serif`,
                      }}
                    >
                      বাংলা · عربي · ABC
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Detected fonts in active PDF */}
          {detectedFonts.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-slate-700 mb-2">
                {t.detectedInDocHeading}
              </h3>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                {detectedFonts.map((df) => (
                  <div
                    key={`${df.rawName}-${df.isBold}-${df.isItalic}`}
                    className="px-4 py-2.5 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">
                        {df.displayName}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {df.isBold ? 'Bold' : 'Regular'}
                        {' · '}
                        {df.hasArabic
                          ? 'Arabic RTL'
                          : df.hasBangla
                          ? 'Bangla + Unicode'
                          : 'Latin / English'}
                        {df.isBijoyEncoded ? ' · Bijoy ANSI' : ''}
                        {' · '}
                        <span className="font-mono tabular-nums">{df.count} lines</span>
                      </div>
                    </div>

                    <select
                      value={df.matchedFontId}
                      onChange={(e) =>
                        onApplyFontToDetected(df.rawName, e.target.value)
                      }
                      className="text-xs border border-slate-200 rounded-md px-2.5 py-1.5 bg-white text-slate-800 max-w-[200px]"
                    >
                      {customFonts.map((cf) => (
                        <option key={cf.id} value={cf.id}>
                          {cf.name}
                        </option>
                      ))}
                      {BUNDLED_FONTS.map((bf) => (
                        <option key={bf.id} value={bf.id}>
                          {lang === 'bn' ? bf.labelBn : bf.label}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bundled studio fonts */}
          <div>
            <h3 className="text-xs font-semibold text-slate-700 mb-2">
              {t.bundledFontsHeading}
            </h3>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
              {BUNDLED_FONTS.map((bf) => (
                <div
                  key={bf.id}
                  className="px-4 py-2.5 flex items-center justify-between gap-4"
                >
                  <div className="text-xs font-medium text-slate-700">
                    {lang === 'bn' ? bf.labelBn : bf.label}
                  </div>
                  <div
                    className="text-sm text-slate-900"
                    style={{ fontFamily: bf.cssFamily }}
                  >
                    {bf.sampleText}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="px-5 py-3 border-t border-slate-200 bg-[#FAFAFB] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
