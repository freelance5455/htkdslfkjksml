import React from 'react';
import { X, Sparkles, DollarSign, Key, ExternalLink, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface ImageSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerPaidFlow?: () => void;
}

export const ImageSetupModal: React.FC<ImageSetupModalProps> = ({
  isOpen,
  onClose,
  onTriggerPaidFlow,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div 
        className="relative w-full max-w-xl max-h-[90vh] overflow-hidden rounded-2xl bg-[#110726] border border-purple-500/40 shadow-[0_0_50px_rgba(168,85,247,0.3)] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-purple-950/30">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-violet-500 flex items-center justify-center shadow-lg shadow-purple-600/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Langkah Setup & Kos Model Imej
              </h3>
              <p className="text-xs text-purple-300">
                Model: <span className="font-mono text-purple-200 font-semibold">gemini-3.1-flash-lite-image</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-purple-900/30 transition-colors"
            title="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-slate-200 text-xs sm:text-sm">
          {/* Status Box */}
          <div className="p-3.5 rounded-xl bg-purple-900/25 border border-purple-500/30 flex items-start gap-3">
            <DollarSign className="w-5 h-5 text-fuchsia-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-purple-100 text-sm">Anggaran Kos Penjanaan & Suntingan Imej</h4>
              <p className="text-xs text-purple-200 mt-1 leading-relaxed">
                Model penjanaan imej Gemini ialah model premium Google AI. Kos adalah berasaskan penggunaan (Pay-as-you-go):
              </p>
              <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-lg bg-black/40 border border-purple-800/40">
                  <span className="text-[11px] text-purple-300 block">Kos Per Imej:</span>
                  <span className="font-bold text-white font-mono text-sm">~$0.03 – $0.04 USD</span>
                  <span className="text-[10px] text-slate-400 block">(anggaran ~RM 0.14 - RM 0.18)</span>
                </div>
                <div className="p-2 rounded-lg bg-black/40 border border-purple-800/40">
                  <span className="text-[11px] text-purple-300 block">Model Chatbot (Teks):</span>
                  <span className="font-bold text-emerald-400 font-mono text-sm">PERCUMA</span>
                  <span className="text-[10px] text-slate-400 block">(Bawah kuota asas percuma)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Setup Steps */}
          <div>
            <h4 className="font-bold text-white text-sm mb-2.5 flex items-center gap-2">
              <Key className="w-4 h-4 text-purple-400" />
              <span>3 Langkah Mudah Mengaktifkan Model Imej:</span>
            </h4>
            <div className="space-y-2.5">
              <div className="p-3 rounded-xl bg-[#170a30] border border-purple-900/50 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-200 text-xs font-bold flex items-center justify-center shrink-0 border border-purple-500/40">
                  1
                </span>
                <div>
                  <h5 className="font-semibold text-xs text-purple-100">Buka Google AI Studio / Google Cloud Console</h5>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                    Log masuk ke akaun Google anda di Google AI Studio (<code className="text-purple-300 font-mono">aistudio.google.com</code>) atau Google Cloud.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#170a30] border border-purple-900/50 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-200 text-xs font-bold flex items-center justify-center shrink-0 border border-purple-500/40">
                  2
                </span>
                <div>
                  <h5 className="font-semibold text-xs text-purple-100">Aktifkan Pengebilan (Billing Account)</h5>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                    Pautkan kaedah pembayaran (kad debit/kredit). Google memberikan kuota permulaan percuma untuk pengguna baru, dan anda hanya dicaj mengikut jumlah imej yang diedit tanpa komitmen bulanan.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#170a30] border border-purple-900/50 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-200 text-xs font-bold flex items-center justify-center shrink-0 border border-purple-500/40">
                  3
                </span>
                <div>
                  <h5 className="font-semibold text-xs text-purple-100">Pilih API Key dalam AI Studio</h5>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                    Gunakan butang <strong>"Pilih API Key Berbayar"</strong> di bawah untuk memilih projek Google Cloud anda dengan satu klik. Kunci API akan dikemas kini secara automatik dan selamat di pelayan.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Fungsi chatbot teks biasa kekal 100% percuma & aktif.</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-purple-900/40 bg-[#0c041c] flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-purple-900/30 hover:bg-purple-800/40 text-xs font-semibold text-purple-200 border border-purple-700/40 transition-colors"
          >
            Tutup
          </button>
          {onTriggerPaidFlow && (
            <button
              onClick={() => {
                onClose();
                onTriggerPaidFlow();
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-violet-500 hover:from-purple-500 hover:to-fuchsia-500 text-white text-xs font-bold shadow-lg shadow-purple-900/50 transition-all hover:scale-[1.02]"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Pilih API Key Berbayar</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
