import React from 'react';
import {
  FileArchive,
  FolderOpen,
  FolderPlus,
  RefreshCw,
  Sparkles,
  Trash2,
} from 'lucide-react';
import type { LibraryFolder } from '../types/comic';
import { supportsDirectoryPicker } from '../utils/localFolderScanner';

interface FoldersViewProps {
  folders: LibraryFolder[];
  scanningMessage: string | null;
  onPickDirectory: () => void;
  onTriggerUploadFolder: () => void;
  onTriggerUploadFiles: () => void;
  onRescanFolder: (folder: LibraryFolder) => void;
  onRemoveFolder: (folder: LibraryFolder) => void;
  onLoadSamples: () => void;
  onSelectFolderFilter: (folderId: string) => void;
}

export const FoldersView: React.FC<FoldersViewProps> = ({
  folders,
  scanningMessage,
  onPickDirectory,
  onTriggerUploadFolder,
  onTriggerUploadFiles,
  onRescanFolder,
  onRemoveFolder,
  onLoadSamples,
  onSelectFolderFilter,
}) => {
  const canPickDir = supportsDirectoryPicker();

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-zinc-900 dark:text-zinc-100">
            Local Comic Folders
          </h2>
          <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            Select a folder or group of folders on your device. Metadata, covers, and bookmarks stay cached locally for instant offline browsing.
          </p>
        </div>
      </div>

      {/* Action Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {canPickDir ? (
          <button
            type="button"
            onClick={onPickDirectory}
            className="min-h-[56px] px-4 py-3 rounded-2xl text-white font-medium text-sm flex items-center justify-center gap-2.5 transition-opacity hover:opacity-90"
            style={{ backgroundColor: 'var(--app-accent)' }}
          >
            <FolderPlus className="w-4 h-4 shrink-0" />
            <span>Link Device Folder</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onTriggerUploadFolder}
            className="min-h-[56px] px-4 py-3 rounded-2xl text-white font-medium text-sm flex items-center justify-center gap-2.5 transition-opacity hover:opacity-90"
            style={{ backgroundColor: 'var(--app-accent)' }}
          >
            <FolderPlus className="w-4 h-4 shrink-0" />
            <span>Select Folder</span>
          </button>
        )}

        <button
          type="button"
          onClick={onTriggerUploadFolder}
          className="min-h-[56px] px-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 font-medium text-sm flex items-center justify-center gap-2.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/80 transition-colors"
        >
          <FolderOpen className="w-4 h-4 shrink-0" />
          <span>Import Folder Offline</span>
        </button>

        <button
          type="button"
          onClick={onTriggerUploadFiles}
          className="min-h-[56px] px-4 py-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 font-medium text-sm flex items-center justify-center gap-2.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/80 transition-colors"
        >
          <FileArchive className="w-4 h-4 shrink-0" />
          <span>Add CBZ / CBR Files</span>
        </button>
      </div>

      {scanningMessage && (
        <div className="px-4 py-3 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-sm text-zinc-700 dark:text-zinc-300">
          {scanningMessage}
        </div>
      )}

      {/* Linked Folders List */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
            Watched &amp; Cached Sources ({folders.length})
          </h3>
          <button
            type="button"
            onClick={onLoadSamples}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3 rounded-xl text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Restore Sample Editions</span>
          </button>
        </div>

        {folders.length === 0 ? (
          <div className="p-8 rounded-2xl border border-dashed border-zinc-300 dark:border-zinc-800 text-center space-y-3">
            <p className="text-sm font-medium text-zinc-800 dark:text-zinc-200">
              No folders linked yet
            </p>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-md mx-auto">
              Link a local comic folder or drop CBZ, CBR, ZIP, and RAR archives anywhere to begin reading.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-zinc-200/80 dark:divide-zinc-800 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl bg-white dark:bg-zinc-900/60 overflow-hidden">
            {folders.map((folder) => {
              const dateStr = new Date(folder.lastScannedAt).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric',
              });
              const sourceLabel =
                folder.sourceType === 'fs-access'
                  ? 'Device Folder'
                  : folder.sourceType === 'sample'
                    ? 'Built-in Sample'
                    : 'Offline Cached Folder';

              return (
                <div
                  key={folder.id}
                  className="px-4 py-3.5 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    onClick={() => onSelectFolderFilter(folder.id)}
                    className="flex items-center gap-3.5 min-w-0 flex-1 text-left"
                  >
                    <div className="w-10 h-10 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center shrink-0">
                      <FolderOpen className="w-5 h-5 text-zinc-600 dark:text-zinc-300" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100 truncate">
                        {folder.name}
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono-nums truncate">
                        {folder.comicCount} {folder.comicCount === 1 ? 'comic' : 'comics'} · {sourceLabel} · Scanned {dateStr}
                      </p>
                    </div>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    {folder.sourceType === 'fs-access' && folder.handle && (
                      <button
                        type="button"
                        onClick={() => onRescanFolder(folder)}
                        className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                        title="Re-scan folder"
                        aria-label={`Re-scan ${folder.name}`}
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onRemoveFolder(folder)}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-zinc-500 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                      title="Remove folder"
                      aria-label={`Remove ${folder.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="p-4 rounded-2xl bg-zinc-100/70 dark:bg-zinc-900/50 border border-zinc-200/70 dark:border-zinc-800 text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed space-y-1">
        <p className="font-medium text-zinc-800 dark:text-zinc-200">
          Supported Archive &amp; Image Formats
        </p>
        <p>
          Archives: CBZ, CBR, ZIP, RAR (RAR4 &amp; RAR5 via WebAssembly) · Images: JPEG XL (.jxl), WebP, AVIF, JPEG, PNG, GIF · Metadata: Full ComicInfo.xml &amp; &lt;Bookmarks&gt; TOC parsing.
        </p>
      </section>
    </div>
  );
};
