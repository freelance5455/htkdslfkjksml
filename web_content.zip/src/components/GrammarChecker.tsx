import React, { useState, useEffect } from 'react';
import { StudentProfile, GrammarResult, GrammarIssue, SavedHistoryItem } from '../types';
import {
  SpellCheck,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Copy,
  Volume2,
  VolumeX,
  RotateCcw,
  Wand2,
  BookOpen,
  ArrowRight,
  TrendingUp,
  ThumbsUp,
  SlidersHorizontal,
  FileText
} from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface GrammarCheckerProps {
  profile: StudentProfile;
  initialText?: string;
  onSaveHistory: (item: Omit<SavedHistoryItem, 'id' | 'timestamp'>) => void;
  onUpdateStats: (key: keyof StudentProfile) => void;
}

export const GrammarChecker: React.FC<GrammarCheckerProps> = ({
  profile,
  initialText = '',
  onSaveHistory,
  onUpdateStats,
}) => {
  const [text, setText] = useState(initialText);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GrammarResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'grammar' | 'spelling' | 'punctuation' | 'clarity' | 'vocabulary'>('all');

  useEffect(() => {
    if (initialText) {
      setText(initialText);
    }
  }, [initialText]);

  // Sample student texts with common errors to demonstrate instant feedback
  const sampleStudentDrafts = [
    {
      title: 'Science Homework Draft',
      text: 'Their is many reasons why global warming effect the oceans. When carbon dioxide go up in the atmosphere the water gets more acid. Also the sea levels rises up fast and its very bad for fish.',
    },
    {
      title: 'History Opinion Draft',
      text: 'Abraham Lincoln was one of the most great presidents because he signed the Emancipation Proclamation. He believed that all people should be free and he stood up for what is right even when everyone was mad at him.',
    },
    {
      title: 'Literature Analysis',
      text: 'In the book the main character feels very sad and alone because their friends left. This shows that people needs friendship to survive and be happy in life.',
    },
  ];

  const handleCheckGrammar = async (draftText?: string) => {
    const textToCheck = draftText !== undefined ? draftText : text;
    if (!textToCheck.trim()) {
      setError('Please type or paste some text to check.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/check-grammar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToCheck.trim(),
          grade: profile.grade,
          studentName: profile.name,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to analyze text.');
      }

      setResult(data.data);
      onUpdateStats('checkedGrammarCount');
      if (data.data.overallScore >= 80) {
        fireCelebration();
      }

      onSaveHistory({
        type: 'grammar',
        title: `Grammar Check (${data.data.overallScore}/100)`,
        data: data.data,
        gradeWhenCreated: profile.grade,
      });
    } catch (err: any) {
      setError(err.message || 'Error occurred while checking writing.');
    } finally {
      setLoading(false);
    }
  };

  const applySingleFix = (issue: GrammarIssue) => {
    if (!text) return;
    // Replace the first occurrence of originalText
    const updated = text.replace(issue.originalText, issue.suggestedReplacement);
    setText(updated);

    // Remove the applied issue from the result list
    if (result) {
      setResult({
        ...result,
        issues: result.issues.filter((i) => i.id !== issue.id),
      });
    }
  };

  const applyAllFixes = () => {
    if (!result?.correctedText) return;
    setText(result.correctedText);
    setResult({
      ...result,
      issues: [],
      overallScore: 100,
    });
    fireCelebration();
  };

  const copyText = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleSpeech = () => {
    if (!text || !('speechSynthesis' in window)) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.onend = () => setSpeaking(false);
      utterance.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setSpeaking(true);
    }
  };

  // Real-time draft stats
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;
  const sentenceCount = text.trim() ? (text.match(/[.!?]+(?=\s+|$)/g) || []).length || 1 : 0;

  const filteredIssues = result?.issues.filter((issue) => {
    if (activeFilter === 'all') return true;
    return issue.type === activeFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <SpellCheck className="w-3.5 h-3.5" />
            Grammar & Style Coach
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Real-Time Writing Feedback
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Fix grammar, spelling, punctuation, and elevate sentence structure to{' '}
            <span className="font-semibold text-amber-700">{profile.grade}</span> standards with 1-click improvements.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-2xl flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Main Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Editor */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Your Draft
              </span>

              {/* Live counts */}
              <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
                <span>{wordCount} words</span>
                <span>•</span>
                <span>{charCount} characters</span>
                <span>•</span>
                <span>{sentenceCount} sentences</span>
              </div>
            </div>

            {/* Textarea */}
            <textarea
              rows={12}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste or start typing your paragraph, essay, or homework answer here..."
              className="w-full p-4 rounded-2xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 text-slate-800 text-sm sm:text-base leading-relaxed transition resize-y font-serif"
            />

            {/* Editor Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={toggleSpeech}
                  disabled={!text.trim()}
                  className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition cursor-pointer disabled:opacity-40"
                  title={speaking ? 'Stop speech' : 'Hear your text read aloud'}
                >
                  {speaking ? <VolumeX className="w-4 h-4 text-rose-600" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={copyText}
                  disabled={!text.trim()}
                  className="px-3 py-2 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? 'Copied!' : 'Copy'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setText('');
                    setResult(null);
                  }}
                  className="px-3 py-2 rounded-xl text-slate-400 hover:text-slate-700 text-xs font-semibold transition"
                >
                  Clear
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleCheckGrammar()}
                disabled={loading || !text.trim()}
                className={`py-2.5 px-6 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center gap-2 transition cursor-pointer ${
                  loading || !text.trim()
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                    : 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white shadow-amber-500/25'
                }`}
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Analyzing grammar for {profile.grade}...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Check Writing Real-Time</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick-test Student Draft Samples */}
          <div className="bg-slate-50/80 rounded-3xl p-5 border border-slate-200/80 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
              Try Sample Student Drafts
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {sampleStudentDrafts.map((sample, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    setText(sample.text);
                    handleCheckGrammar(sample.text);
                  }}
                  className="p-3 bg-white hover:bg-amber-50/60 border border-slate-200 hover:border-amber-300 rounded-2xl transition text-left space-y-1 group cursor-pointer"
                >
                  <span className="text-xs font-bold text-slate-800 group-hover:text-amber-800 block truncate">
                    {sample.title}
                  </span>
                  <span className="text-[11px] text-slate-500 line-clamp-2">
                    {sample.text}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Feedback, Score & Suggestions */}
        <div className="lg:col-span-5 space-y-6">
          {!result && !loading && (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs">
              <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
                <SpellCheck className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">
                Ready for grammar feedback
              </h3>
              <p className="text-sm text-slate-500 max-w-sm mt-1">
                Type or paste your writing on the left and click "Check Writing Real-Time". The coach will detect mistakes, highlight vocabulary upgrades, and offer instant fixes!
              </p>
            </div>
          )}

          {loading && (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs space-y-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-amber-100 border-t-amber-600 animate-spin" />
                <Sparkles className="w-6 h-6 text-amber-500 absolute animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Reviewing Grammar, Tone & Clarity
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Auditing writing against {profile.grade} rubrics for spelling, punctuation, and academic style...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-5 animate-in fade-in duration-300">
              {/* Score and Readability Card */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Overall Writing Score
                    </span>
                    <div className="flex items-baseline gap-2 mt-0.5">
                      <span className="text-3xl font-extrabold text-slate-900">
                        {result.overallScore}
                      </span>
                      <span className="text-sm font-bold text-slate-400">/ 100</span>
                      <span
                        className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                          result.overallScore >= 90
                            ? 'bg-emerald-100 text-emerald-800'
                            : result.overallScore >= 75
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {result.overallScore >= 90
                          ? 'Excellent'
                          : result.overallScore >= 75
                          ? 'Good Progress'
                          : 'Needs Polish'}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Readability Level
                    </span>
                    <span className="text-sm font-bold text-indigo-700 block">
                      {result.readabilityGrade}
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      Tone: {result.toneDetected}
                    </span>
                  </div>
                </div>

                {/* Accept All Button */}
                {result.issues && result.issues.length > 0 && (
                  <button
                    onClick={applyAllFixes}
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Wand2 className="w-3.5 h-3.5" />
                    Accept All {result.issues.length} Corrections
                  </button>
                )}
              </div>

              {/* Encouragement / Strengths */}
              {result.positiveStrengths && result.positiveStrengths.length > 0 && (
                <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 space-y-2">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                    <ThumbsUp className="w-3.5 h-3.5 text-emerald-600" />
                    Writing Strengths
                  </span>
                  <ul className="space-y-1 text-xs text-slate-700">
                    {result.positiveStrengths.map((strength, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-500 font-bold">✓</span>
                        <span>{strength}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Issues Filter Pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
                {(['all', 'grammar', 'spelling', 'punctuation', 'clarity', 'vocabulary'] as const).map(
                  (cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveFilter(cat)}
                      className={`px-3 py-1 text-xs font-bold rounded-xl whitespace-nowrap transition cursor-pointer capitalize ${
                        activeFilter === cat
                          ? 'bg-amber-600 text-white shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {cat}
                    </button>
                  )
                )}
              </div>

              {/* Issues List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Feedback & Suggestions ({filteredIssues?.length || 0})
                  </span>
                </div>

                {filteredIssues?.length === 0 ? (
                  <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center space-y-1">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
                    <p className="text-xs font-bold text-slate-800">
                      No issues found in this category!
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Great job applying correct conventions.
                    </p>
                  </div>
                ) : (
                  filteredIssues?.map((issue) => (
                    <div
                      key={issue.id}
                      className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-2.5 hover:border-amber-300 transition"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                          {issue.type}
                        </span>
                        <button
                          onClick={() => applySingleFix(issue)}
                          className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3 h-3" /> Apply Fix
                        </button>
                      </div>

                      <div className="flex items-center gap-2 text-xs flex-wrap">
                        <span className="line-through text-rose-500 font-mono bg-rose-50 px-2 py-0.5 rounded">
                          {issue.originalText}
                        </span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                        <span className="text-emerald-700 font-bold font-mono bg-emerald-50 px-2 py-0.5 rounded">
                          {issue.suggestedReplacement}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {issue.explanation}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Grade-Level Vocabulary Upgrades */}
              {result.vocabularyUpgrades && result.vocabularyUpgrades.length > 0 && (
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2.5">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-indigo-600" />
                    Vocabulary Upgrades for {profile.grade}
                  </span>
                  <div className="space-y-2">
                    {result.vocabularyUpgrades.map((vocab, i) => (
                      <div
                        key={i}
                        className="p-2.5 bg-white rounded-xl border border-slate-200 text-xs flex items-center justify-between gap-2"
                      >
                        <div>
                          <span className="text-slate-500">Instead of: </span>
                          <span className="font-semibold text-slate-700">"{vocab.originalWord}"</span>
                          <span className="text-slate-500">, try: </span>
                          <span className="font-bold text-indigo-700">"{vocab.suggestedWord}"</span>
                        </div>
                        <span className="text-[10px] text-slate-400 shrink-0 italic">{vocab.reason}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
